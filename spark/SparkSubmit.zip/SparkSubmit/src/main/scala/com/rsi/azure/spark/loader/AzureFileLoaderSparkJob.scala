package com.rsi.azure.spark.loader

import java.time.{ZoneId, ZonedDateTime}
import java.util

import com.google.gson.Gson
import com.typesafe.config.{Config, ConfigFactory}
import org.apache.kafka.clients.producer.{KafkaProducer, ProducerConfig, ProducerRecord}
import org.apache.spark.sql.SparkSession

object AzureFileLoaderSparkJob {


  def main(args: Array[String]): Unit = {
   // Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver")
    //val spark = SparkSession.builder().appName("test").master("local").getOrCreate()

    /**
      * Reading the configs
      */
    val conf = ConfigFactory.load

    val serverName = conf.getString("database.serverName")
    val portNumber = conf.getString("database.portNumber")
    val databaseName = conf.getString("database.databaseName")
    val userName = conf.getString("database.userName")
    val password = conf.getString("database.password")

    println(" servername,portNumber,databaseName,userName,password",serverName,portNumber,databaseName,userName,password)
    val url = "jdbc:sqlserver://" + serverName + ":" + portNumber


    val spark = SparkSession
      .builder()
      .config("spark.sql.crossJoin.enabled", "true")
      .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      .config("spark.sql.broadcastTimeout", "300")
      .config("spark.yarn.driver.memoryOverhead", "1G")
      .config("spark.yarn.executor.memoryOverhead", "1G")
      .config("spark.speculation", "true")
      .config("spark.speculation.interval", "30s")
      .config("spark.speculation.multiplier", "1.5")
      .config("spark.speculation.quantile", "0.75")
      .config("spark.shuffle.file.buffer", "100K")
      .getOrCreate()

    val utcZoneId = ZoneId.of("UTC")
    val zonedDateTime = ZonedDateTime.now
    val utcDateTime = zonedDateTime.withZoneSameInstant(utcZoneId)
    val driverClass = conf.getString("database.driverClass")
    val connectionProperties = new java.util.Properties()
    connectionProperties.setProperty("Driver", driverClass)


    // reading inputs config


    val jsonRec = args(0)
    val gson = new Gson()
    val dataStreamAudit = gson.fromJson(jsonRec, classOf[DatastreamAuditParam]);
    println("***************json request*****************"+gson.toJson(dataStreamAudit))
    dataStreamAudit.loadStartDate = System.currentTimeMillis()
    val fileName = dataStreamAudit.fileName
    val inputFiles = dataStreamAudit.azureFileLocation
    println("inputFiles *********************************************************"+inputFiles)
    /*val jsvalue = Json.parse(jsonRec)
    implicit val auditParam = Json.format[DatastreamAuditParam]

    val auditJson = Json.fromJson[DatastreamAuditParam](jsvalue)

    val getAuditParam = auditJson.get
    val fileName = getAuditParam.fileName
    val inputFiles = getAuditParam.azure_fileLocation*/


   // val readFileHeadereTableName = conf.getString("input.readFileHeader.TableName")

    /*val datastreamFileHeaderFile = conf.getString("datastreamFileHeader.QueryLocation") + "/" + conf.getString("datastreamFileHeader.QueryName")
    val fileHeaderQuery = spark.read.textFile(datastreamFileHeaderFile).reduce(_ + " " + _)
    val datastreamFileHeaderQuery = fileHeaderQuery.format(fileName)

    val readFileHeader = spark.read.format("jdbc")
      .option("url", url)
      .option("databaseName", databaseName)
      .option("dbtable", datastreamFileHeaderQuery)
      .option("user", userName)
      .option("password", password)
      .load()


    val formatId = readFileHeader.select("format_id").first().getAs[Int](0)
    val headerId = readFileHeader.select("header_id").first().getAs[Int](0)
    val datastream = readFileHeader.select("datastream").first().getAs[String](0)
    val datastream_sub = readFileHeader.select("datastream_sub").first().getAs[String](0)
    val vendorKey = readFileHeader.select("vendor_key").first().getAs[Int](0)
    val retailerKey = readFileHeader.select("retailer_key").first().getAs[Int](0)
    val dcRetailerKey = readFileHeader.select("dc_retailer_key").first().getAs[Int](0)
    val rawTableName = readFileHeader.select("raw_table").first().getAs[String](0)

    dataStreamAudit.headerId = headerId
    dataStreamAudit.formatId = formatId
    dataStreamAudit.datastream = datastream
    dataStreamAudit.datastreamSub = datastream_sub
    dataStreamAudit.retailerKey = retailerKey
    dataStreamAudit.vendorKey = vendorKey
    dataStreamAudit.dcRetailerKey = dcRetailerKey
    dataStreamAudit.rawTable = rawTableName*/

    val layoutDataQueryFile = conf.getString("layoutDataQuery.QueryLocation") + "/" + conf.getString("layoutDataQuery.QueryName")
    val layoutDataQuery = spark.read.textFile(layoutDataQueryFile).reduce(_ + " " + _)
    val layoutDataFormattedQuery = layoutDataQuery.format(dataStreamAudit.formatId)

    val layoutDataDF = spark.read.format("jdbc")
      .option("url", url)
      .option("databaseName", databaseName)
      .option("dbtable", layoutDataFormattedQuery)
      .option("user", userName)
      .option("password", password)
      .load()

    val columnIndexList = layoutDataDF.select("FILE_COLUMN_ORDER").rdd.map(r => "_c" + r(0)).collect.toList
    val columnNameList = layoutDataDF.select("FILE_COLUMN_NAME").rdd.map(r => r(0)).collect.toList

    val columnIndex = columnIndexList mkString ","
    val columnName = columnNameList mkString ","


    // val inputFiles = conf.getString("input.inputFile.File")
    val inputFileTableName = conf.getString("input.inputFile.TableName")
     val inputFileType = conf.getString("input.inputFile.FileType")
    //val inputFileDelim = conf.getString("input.inputFile.Delimiter")
   // val inputFileHeaderFlag = conf.getBoolean("input.inputFile.Header")
    val inputFileDF = inputFileType match {
      case "csv" => spark.read.format("com.databricks.spark.csv").
        option("delimiter", dataStreamAudit.delimiter).option("header", dataStreamAudit.hasHeder).
        option("inferSchema", "true").
        load(inputFiles)
      case "Parquet" => spark.read.parquet(inputFiles)
    }
    inputFileDF.createOrReplaceTempView(inputFileTableName)


    val selectedColumn = spark.sql(s"select $columnIndex from DATASTREAM_INPUT_FILE")

    selectedColumn.createOrReplaceTempView("INPUT_FILE_COLUMN_INDEX")

    val strQuery = new StringBuilder
    val columnSize = columnIndexList.size
    println(columnSize)
    for (i <- 0 to columnSize - 1) {
      if (i == columnSize - 1) {
        strQuery ++= columnIndexList(i).toString + " AS " + columnNameList(i).toString + " "
      } else {
        strQuery ++= columnIndexList(i).toString + " AS " + columnNameList(i).toString + ","
      }
      selectedColumn.withColumnRenamed(columnIndexList(i).toString, columnNameList(i).toString)
    }
    selectedColumn.createOrReplaceTempView("INPUT_FILE_COLUMN_INDEX")

    val fileWithNewHeaders = spark.sql(s"select $strQuery from INPUT_FILE_COLUMN_INDEX")
    //  val timestamp = System.currentTimeMillis();
    // reading outputs config
    val outputMode = conf.getString("output.mode")
    val outputFile = conf.getString("output.OutputFile")
    val outputFileFormat = conf.getString("output.OutputFileType")
    //val timestamp = System.currentTimeMillis();

    outputFileFormat match {
      case "Parquet" => {
        if (outputMode == null || outputMode == "") {
          fileWithNewHeaders.write.parquet(outputFile + "/" + fileName + "/")
        } else {
          fileWithNewHeaders.write.mode(outputMode).parquet(outputFile + "/" + fileName + "/")
        }
      }
    }

    if (outputMode == null || outputMode == "") {
      fileWithNewHeaders.write.parquet(outputFile + "/" + fileName + "/")
    } else {
      fileWithNewHeaders.write.mode(outputMode).parquet(outputFile + "/" + fileName + "/")
    }

    dataStreamAudit.rowCount =fileWithNewHeaders.count()
    dataStreamAudit.status = "COMPLETE"
    dataStreamAudit.loadCompleteDate = System.currentTimeMillis()
    val jsonStr = gson.toJson(dataStreamAudit)
    //val jsonStr = jsvalueAuditParam.toString()
    println(" string json " + jsonStr)
    wrtiteToKafka(jsonStr,conf,dataStreamAudit.fileId)
    // writing the output
    println("Saving the query results!!!")

    println("Finished Writing Query Results!!!")


  }

  def wrtiteToKafka(json: String,conf:Config,fileId:Int) = {
    val kafkaTopic = conf.getString("producer.datastreamAuditTopic") // command separated list of topics
    val bootstrapServers = conf.getString("producer.bootstrapServers")
    val keySerializer = conf.getString("producer.keySerializer")
    val valueSerializer= conf.getString("producer.valueSerializer")
    val partitionerClass= conf.getString("producer.partitionerClass")


    val props = new util.HashMap[String, Object]()
    props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers)
    props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,keySerializer)
    props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,valueSerializer)
    props.put("producer.partitioner.class",partitionerClass)

    val producer = new KafkaProducer[String, String](props)

    val message = new ProducerRecord[String, String](kafkaTopic, fileId.toString, json)

    println(" sending message to kafka " + json)
    producer.send(message)

    producer.close();
  }
}
