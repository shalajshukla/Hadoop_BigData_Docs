package org.cyb.spark

import org.json.simple.JSONArray
import org.json.simple.JSONObject
import org.json.simple.parser.JSONParser

import com.sun.jersey.api.client.Client
import com.sun.jersey.api.client.ClientResponse
import com.sun.jersey.api.client.WebResource

import sun.misc.BASE64Encoder

object RestAPIDBCall {
  def main(a: Array[String]): Unit = {
    var url: String = "http://172.27.147.51:8080/RESTFulJersey/webapi/log/"
    val name: String = "user"
    val password: String = "password!"
    val authString: String = name + ":" + password
    val authStringEnc: String = new BASE64Encoder().encode(authString.getBytes)
    println("Base64 encoded auth string: " + authStringEnc)
    val restClient: Client = Client.create()
    val webResource: WebResource = restClient.resource(url)
    
    val inputJson = "{\"dataprovider\":\"DCM\",\"clientid\":\"1234\",\"type\":\"activity\",\"filedate\":\"2017-08-01\", \"filename\":\"example.gz\",\"status\":\"success\",\"errormessage\":\"\",\"trace\":\"\"}"
//first way to get response
    val resp: ClientResponse = webResource.accept("application/json").`type`("application/json").header("Authorization", "Basic " + authStringEnc).post(classOf[ClientResponse],inputJson)
    if (resp.getStatus != 200) {
      System.err.println("Unable to connect to the server")
    }
    val output: String = resp.getEntity(classOf[String])
    println("response: " + output)
    val parser: JSONParser = new JSONParser()
    val json: JSONObject = parser.parse(output).asInstanceOf[JSONObject]
    val status: String = json.get("status").asInstanceOf[String]
    println(" status " + status)
   
  }
}
