package org.cyb.spark

import java.io.File
import java.nio.file.{Files, Path, StandardCopyOption}

object MoveFiles {
    def main(args: Array[String]): Unit = {
      val d1 = new File("D:\\ShalajS\\COE_Analysis\\Dentsu\\DTv2\\data\\dcm_account2621_activity_20161116_20161117_030627_311999667.csv").toPath
      val d2 = new File("D:\\ShalajS\\COE_Analysis\\Dentsu\\DTv2\\dest\\").toPath
      
      Files.copy(d1, d2)
    }
}