package org.cyb.spark

import java.util.concurrent.{Executors, ExecutorService}

object ThreadExample {

  def main(args: Array[String]): Unit = {
    val pool: ExecutorService = Executors.newFixedThreadPool(2000)
    
    /*while (true) {
      pool.execute(new MyRunnable())
    }*/
    pool.execute(new MyRunnable())
    pool.execute(new MyRunnable())
    pool.execute(new MyRunnable())
    pool.execute(new MyRunnable())
    pool.execute(new MyRunnable())
    pool.execute(new MyRunnable())
    
    println(" finished ")
    /*Thread.sleep(5000);
    System.exit(0)*/
    
    pool.shutdown
     println(" final finished ")
    
  }
}
class MyRunnable extends Runnable {
    def run() {
      println(Thread.currentThread.getName + " executing ")
      Thread.sleep(10000);    
      println(Thread.currentThread.getName + " finished ")
  }

}