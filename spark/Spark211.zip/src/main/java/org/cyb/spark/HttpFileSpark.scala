package org.cyb.spark

import org.apache.spark.sql.SparkSession

object HttpFileSpark {
  
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().appName("HTTP File ").master("local")getOrCreate()
    
    
    /*val html = scala.io.Source.fromURL("http://localhost:8080/examples/").mkString
    println(html)
    val rdds = spark.sparkContext.parallelize(html)
    val count = rdds.count()
    println(count)*/
    
    val html = scala.io.Source.fromURL("http://localhost:8080/examples/dcm_account2621_click_2016111606_20161116_221031_311735299.csv.gz").mkString
    println(html)
    val rdds = spark.sparkContext.parallelize(html)
    val count = rdds.count()
    println(count)
    
   /* val SourceData   = spark.read
                .format("com.databricks.spark.csv")                
                .option("inferSchema", "true")
                .option("delimiter", ",")
                //.option("header", "true")
                .load("D:\\ShalajS\\COE_Analysis\\Dentsu\\DTv2\\dcm_account2621_click_2016111606_20161116_221031_311735299.csv.gz")

   SourceData.write.mode("append").save("D:\\ShalajS\\COE_Analysis\\Dentsu\\parquet")    */            
  }
  
  
  

}