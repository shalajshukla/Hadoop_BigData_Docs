package org.cyb.spark

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext


object simpleSpark {
  def main(args : Array[String]){
    
    val Array(firstname,lastname)=args.take(2)
    
    println(" arguments *********************************************** "+firstname+" ************************************************"+lastname)
       
    //println("hi1")
    //val conf = new SparkConf().setAppName("Simple Application").setMaster("local[2]").set("spark.executor.memory", "1g")
    val conf = new SparkConf().setAppName(firstname+"_"+lastname)//.setMaster("local")
    val sc = new SparkContext(conf)
    
    
    /*val myFile = sc.textFile("/root/full_timeslot.csv")
    val wordspair =myFile.flatMap(row =>row.split(",")).map(x=>(x,1)).reduceByKey(_+_)
    wordspair.foreach(println)
    wordspair.saveAsTextFile("myoutputfolder");*/
    
    val list = List(1,2,3,4,5,6,7,8,9)
    
   val listrdd = sc.parallelize(list)
   listrdd.foreach(println)
   Thread.sleep(1*30*1000)
   listrdd.collect()
   
   sc.stop();
    
  }
}
