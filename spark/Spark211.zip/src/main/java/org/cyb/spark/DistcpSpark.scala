package org.cyb.spark

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.Path
import org.apache.hadoop.tools.DistCp
import org.apache.hadoop.tools.DistCpOptions
import org.apache.hadoop.util.ToolRunner
import org.apache.hadoop.fs.FileSystem
import java.util.Properties
/*import com.typesafe.config.{Config, ConfigFactory}
import java.io.File*/

object DistcpSpark {
  
  def main(args: Array[String]): Unit = {
    //val srcPath = new Path(args(0))
    
    val filepaths: Array[String] = Array(args(0), args(1))
    
    executeDistCp(filepaths)
    
    
  }
  def executeDistCp(filepaths: Array[String]) {
    val conf: Configuration = new Configuration()
    
      
    /*val props: Config = ConfigFactory.parseFile(new File("application.properties"))
    
    val keyFile = props.getConfig("dev").getString("google.cloud.keyfile")
    val mapredClasspath = props.getConfig("dev").getString("mapred.classpath")
    val hadoopClasspath = props.getConfig("dev").getString("hadoop.classpath")
    val accesskey = props.getConfig("dev").getString("accessKey")
    val secretKey = props.getConfig("dev").getString("secretKey")*/
    
   
    
    conf.set("fs.gs.impl", "com.google.cloud.hadoop.fs.gcs.GoogleHadoopFileSystem")
    conf.set("fs.AbstractFileSystem.gs.impl","com.google.cloud.hadoop.fs.gcs.GoogleHadoopFS")
    conf.set("google.cloud.auth.service.account.enable", "true")
    conf.set("fs.gs.project.id", "resolute-future-168712")
    conf.set("google.cloud.auth.service.account.json.keyfile","/tmp/GCP-key.json")
    conf.set("fs.s3n.awsAccessKeyId", "AKIAI2I6BCCB3V6G6VMQ")
    conf.set("fs.s3n.awsSecretAccessKey","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")
    
    conf.set("mapreduce.application.classpath","$HADOOP_MAPRED_HOME/share/hadoop/mapreduce/*,$HADOOP_MAPRED_HOME/share/hadoop/mapreduce/lib/*,/usr/lib/hadoop-lzo/lib/*,/usr/share/aws/emr/emrfs/conf,/usr/share/aws/emr/emrfs/lib/*,/usr/share/aws/emr/emrfs/auxlib/*,/usr/share/aws/emr/lib/*,/usr/share/aws/emr/ddb/lib/emr-ddb-hadoop.jar,/usr/share/aws/emr/goodies/lib/emr-hadoop-goodies.jar,/usr/share/aws/emr/cloudwatch-sink/lib/*,/usr/share/aws/aws-java-sdk/*,/tmp/gcs-connector-latest-hadoop2.jar")
    conf.set("HADOOP_CLASSPATH","$HADOOP_CLASSPATH:/tmp/gcs-connector-latest-hadoop2.jar")
   
    
    val outputDir: Path = new Path(filepaths(1))
    outputDir.getFileSystem(conf).delete(outputDir, true)
    
    val distCp: DistCp = new DistCp(conf,null)
    
    ToolRunner.run(distCp, filepaths)
    
    
   }

}