package org.cyb.spark

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.SaveMode
import java.util.Properties
import org.apache.spark.sql.SQLContext

object SparkSQLExample {

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().appName("Spark Sql Example").master("local[2]").getOrCreate()
    
    import spark.implicits._
    
    /*val df = spark.read.json("src/test/resources/Person.json")
    df.show()
    df.printSchema()
   df.select("first_name").show()
    
    df.select($"first_name", $"age"+1).show()
    
    df.filter($"age" > 21).show()
    
    df.groupBy("age").count().show()*/
    
    
   /* val df = spark.read.format("com.databricks.spark.csv")
    .option("header", true)
    .option("ignoreLeadingWhiteSpace", true)
    .load("src/test/resources/test")
        
    df.show()*/
    
    
    //df.write.mode(SaveMode.Append).insertInto("parttab")
    
    val dataframe_mysql = spark.sqlContext.read.format("jdbc")
     .option("url", "jdbc:mysql://172.27.155.92:3306/test?serverTimezone=UTC")
     .option("driver", "com.mysql.jdbc.Driver")
     .option("dbtable", "temp")
     .option("user", "root")
     .option("password", "password").load()
     
     dataframe_mysql.show
     
    /*val rows = dataframe_mysql.sqlContext.sql("select * from test.temp limit 2")
     
    rows.show*/
    
     val connectionProperties = new Properties()
    connectionProperties.put("user", "root")
    connectionProperties.put("password", "password")
    
   // spark.sql("select * from temp limit 2")
    val jdbcUrl = "jdbc:mysql://172.27.155.92:3306/test"
    
    /*val df = (spark.read.format(
       url=jdbcUrl,
      dbtable="temp",
      columnName="emp_no",
      lowerBound=1L,
      upperBound=100000L,
     numPartitions=100,
      connectionProperties=connectionProperties))*/
      
     val df =  spark
              .read
              .format("jdbc")
              .option("url", "jdbc:mysql://172.27.155.92:3306/test?serverTimezone=UTC")
              .option("driver", "com.mysql.jdbc.Driver")
              .option("dbtable", "temp")
              .option("user", "root")
              .option("password", "password")
              .load()
              
             
      df.show
    
    
  }
}