package org.cyb.spark

import org.apache.spark.launcher.SparkLauncher
import java.util.concurrent.{Executors, ExecutorService}
//import scala.collection.JavaConversions._
import com.typesafe.config.{Config, ConfigFactory}
import java.io.File

object SparkLaunch extends App {

 
  // application.properties file should be under class path (/src/main/resource)
  //val props: Config = ConfigFactory.load()
  // file under the same directory where jar file is placed
   val props: Config = ConfigFactory.parseFile(new File("application.properties"))
   
  println(props.getConfig("prod").getString("spark_home"))
  
  val col = props.getConfig("dev").getString("column")
  val array = col.split(",")
  array.foreach { 
   x => val p = x.split("#")
   
   println(p(0)+ " "+p(1) +" "+ p (2))
 }
  /*  val spark = new SparkLauncher()
    .setSparkHome("D:\\ShalajS\\sw\\spark-2.1.0-bin-hadoop2.7")
    .setAppResource("D:\\ShalajS\\scala_projects\\Spark211\target\\Spark211-0.0.1-SNAPSHOT.jar")
    .setMainClass("org.cyb.spark.simpleSpark")
    .setMaster("local[*]")
    .setVerbose(true)
    .addSparkArg("firstname")
    .addSparkArg("lastname")
    .launch();*/
   /* val spark = new SparkLauncher()
    .setSparkHome("/home/spark")
    .setAppResource("/home/jars/Spark211-0.0.1-SNAPSHOT.jar")
    .setMainClass("org.cyb.spark.simpleSpark")
    .setMaster("spark://mac53:7077")
    .setVerbose(true)
    //.addSparkArg("firstname")
    //.addSparkArg("lastname")
    .launch();
    println(" executing job")*/
  
  //spark.waitFor();
    
     //println("Finish")
     
 /*val list = (1 to 5)
  val pool: ExecutorService = Executors.newFixedThreadPool(list.size)
  
  //list.foreach { x => pool.execute(new SparkSubmitRunnable()) }
 
    pool.execute(new SparkSubmitRunnable("shalaj","shuukla"))
    pool.execute(new SparkSubmitRunnable("shalaj1","shuukla1"))
    pool.execute(new SparkSubmitRunnable("shalaj2","shuukla2"))
    pool.execute(new SparkSubmitRunnable("shalaj3","shuukla3"))
    pool.execute(new SparkSubmitRunnable("shalaj4","shuukla4"))
  
     pool.shutdown()*/
}
class SparkSubmitRunnable(firstname:String,lastname:String) extends Runnable {
  
  
  def run() {
    val spark = new SparkLauncher()
    .setSparkHome("/home/spark")
    .setAppResource("/home/jars/Spark211-0.0.1-SNAPSHOT.jar")
    .setMainClass("org.cyb.spark.simpleSpark")
    .setMaster("spark://mac53:7077")
    .setVerbose(true)
    .addAppArgs(firstname,lastname)
    .launch();
     println (" launching spark job"+ Thread.currentThread().getName)
      
  spark.waitFor();
    
     println("Finish"+ Thread.currentThread().getName)
  }
  
}