package org.cyb.spark

import org.apache.spark.SparkConf
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.hadoop.io.Text
import org.apache.hadoop.io.IntWritable
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object TestSpark {

  def main (args:Array[String]) {
    val conf = new SparkConf().setMaster("local").setAppName("test spark").set("spark.executor.memory","2g")
    
   
    val sc = new SparkContext(conf)
    //// normally we need to do export 
    //$ export AWS_SECRET_ACCESS_KEY=ed+11LI1zsT62cPFRUmjXswWL7lEa9a5Tcm25VfC
  //$ export AWS_ACCESS_KEY_ID=AKIAJOEX7YHFQ5OYSLIQ
     sc.hadoopConfiguration.set("fs.s3n.awsAccessKeyId", "AKIAI2I6BCCB3V6G6VMQ")
     sc.hadoopConfiguration.set("fs.s3n.awsSecretAccessKey","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")
   // val myfile=sc.textFile("D:\\ShalajS\\COE_Analysis\\ESPlus\\new_dataset\\18_07_2016\\4_1-7-2016_10-14-14_06096.txt")
    
   //val textFile = sc.textFile("s3n://cyb-dentsu//shalaj//shalaj_1.csv")
    
   // textFile.collect.foreach (println)
    
   // val x = sc.textFile("d://test//*") // we can just specify all the files.
    val textFile = sc.textFile("s3n://cyb-dentsu//shalaj/")
   // textFile.filter { x => x }
    //textFile.take(5) //# to make sure we read it correctly
    //sc.hadoopConfiguration.set("mapreduce.output.basename", "text")
    textFile.saveAsTextFile("s3n://cyb-dentsu//shalaj2/")
    
    
    val spark = SparkSession.builder().appName("Spark Example").master("local").getOrCreate()
    val inputPath: String = "s3n://cyb-dentsu//shalaj"

  /* spark.read.text(inputPath)
      .select(input_file_name, $"value")
      .as[(String, String)] // Optionally convert to Dataset
      .rdd */
    
    
    // upload file
    
    
    /*val input = sc.wholeTextFiles("d://files//file")
    println(input.partitions.size)
    println(input.getNumPartitions)*/
    
    /*val result = input.mapValues{y =>
      val nums = y.split(",").map(x => x.toDouble)
     // println(nums)
      nums.sum / nums.size.toDouble
    }
    println(result)*/
    
   /* val data = sc.sequenceFile("path/to/sequnce file", classOf[Text], classOf[IntWritable]).
    map{case (x, y) => (x.toString, y.get())}*/
    //or
   //val data = sc.sequenceFile[Text, IntWritable]("path/to/sequnce file").
   // map{case (x, y) => (x.toString, y.get())}
   
    //val data :RDD[(Text, IntWritable)] = sc.parallelize(List((new Text("Panda"), new IntWritable(3)), (new Text("Kay"), new IntWritable(6)), (new Text("Snail"), new IntWritable(2))))
    
    
    
  }
  
}