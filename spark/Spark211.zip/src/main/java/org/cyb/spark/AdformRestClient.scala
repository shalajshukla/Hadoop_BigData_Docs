package org.cyb.spark

import java.text.SimpleDateFormat
import java.util.Calendar
import org.json.simple.JSONArray
import org.json.simple.JSONObject
import org.json.simple.parser.JSONParser
import com.amazonaws.auth.AWSCredentials
import com.amazonaws.auth.BasicAWSCredentials
import com.amazonaws.services.s3.AmazonS3
import com.amazonaws.services.s3.AmazonS3Client
import com.sun.jersey.api.client.Client
import com.sun.jersey.api.client.ClientResponse
import com.sun.jersey.api.client.WebResource
import com.amazonaws.services.s3.model.PutObjectRequest
import org.glassfish.jersey.client.ClientProperties

object AdformRestClient {
  def main(a: Array[String]): Unit = {
     
     val ticket =getTicket
     if (ticket != null)
       downloadAndCopyToS3(ticket)
   }
  def downloadAndCopyToS3(authTicket :String) {
       val masterid="4196e1f8-4cac-4f08-a43a-0997ccb706f3"
       val masterUrl = "http://masterdata.adform.com:8652/list/%s?render=json&authTicket=%s".format(masterid,authTicket)
       //val masterUrl = "http://localhost:8080/examples/adforms1.txt"
       val credentials: AWSCredentials = new BasicAWSCredentials("AKIAI2I6BCCB3V6G6VMQ","H2KO7uT2YkBb4hAX78MZZ5O1j8iPM3Jdgz4is600")
       val s3client: AmazonS3 = new AmazonS3Client(credentials)

        try{
            val restClient: Client = Client.create()
            
            /*restClient.setConnectTimeout(0)
            restClient.setReadTimeout(1000000)
            println(restClient.getProperties())*/
            

            var webResource = restClient.resource(masterUrl)
            
            val getfilelist = webResource.accept("application/json").get(classOf[ClientResponse])
            
            if (getfilelist.getStatus != 200) {
              System.err.println("Unable to connect to the server")
            }
            
            
            val output = getfilelist.getEntity(classOf[String])
            
            println("get file list response: " + output)
            
            val parser: JSONParser = new JSONParser()
            val json = parser.parse(output).asInstanceOf[JSONObject]
        
            val jsonArray = json.get("files").asInstanceOf[JSONArray]
            
            val iterator = jsonArray.iterator
            val dateformat = new SimpleDateFormat("yMMd")
            val dateformat1 = new SimpleDateFormat("MMM dd,yyyy hh:mm:ss a")
            val cal = Calendar.getInstance();
            cal.add(Calendar.DATE, -7);
            val downloadDate = dateformat.format(cal.getTime());
            while (iterator.hasNext) {
              val json: JSONObject = iterator.next.asInstanceOf[JSONObject]
              val absolutePath = json.get("absolutePath").asInstanceOf[String]
              val fileName = absolutePath.split("/").last
              val filedate = json.get("created").asInstanceOf[String]
              
              val parseddate = dateformat1.parse(filedate);
              val targetDate = dateformat.format(parseddate.getTime)
              //println(downloadDate)
              //println(targetDate)
              if(downloadDate.equals(targetDate) ) {
                if (fileName.contains("Impression")) {
                                    
                } else if (fileName.contains("Click")) {
                  println(absolutePath)
                  println(fileName)
                  println(filedate)
                  println(targetDate)
                  
                  val getpath = absolutePath+"?authTicket="+authTicket
                  webResource = restClient.resource(getpath)
                  
                  val response = webResource.get(classOf[ClientResponse])
                  if (response.getStatus != 200) {
                    System.err.println("Unable to connect to the server")
                  }
                  val inputStream = response.getEntityInputStream
                  s3client.putObject(new PutObjectRequest("cyb-dentsu", "click/"+fileName, inputStream,null));
                }
              }
              
            }
          
        } catch {
          case e:Exception => e.printStackTrace();println(" exception occur while getting master data from adform" + e.getMessage)
        }
  }
  def getTicket:String = {
    
        val url = "https://api.adform.com/Services/Security/Login"
        var ticket : String = null
        try{
          
          val restClient: Client = Client.create()
          val webResource: WebResource = restClient.resource(url)
        
        
         val userprofile = "{\"Username\":\"vingmaster\",\"Password\":\"Abcd.1234\"}";
        
         val resp: ClientResponse = webResource.accept("application/json").post(classOf[ClientResponse],userprofile)
        
         if (resp.getStatus != 200) {
           println("Unable to connect to the server")
         }
         val  output = resp.getEntity(classOf[String])
         println("response: " + output)
          
         val parser: JSONParser = new JSONParser()
        
         val json: JSONObject = parser.parse(output).asInstanceOf[JSONObject]
        
         ticket = json.get("Ticket").asInstanceOf[String]
         
        }catch {
          case e:Exception => println(" exception occur while getting suth ticket from adform" + e.getMessage)
        }
        ticket
   }
}