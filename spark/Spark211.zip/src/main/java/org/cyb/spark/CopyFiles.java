package org.cyb.spark;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;

public class CopyFiles implements FileFilter {
	
	private Pattern pattern;
	
	public CopyFiles(String filePattern) {
		pattern = Pattern.compile(filePattern,Pattern.CASE_INSENSITIVE);
	}

	public static void main(String[] args) throws IOException {
		
		CopyFiles cp = new CopyFiles ("dcm_account2621_.*.csv.gz");
		
		FileUtils.copyDirectory(new File("D:\\ShalajS\\COE_Analysis\\Dentsu\\DTv2\\data\\")
		,new File("D:\\ShalajS\\COE_Analysis\\Dentsu\\DTv2\\Dest")
		,cp);
	}

	@Override
	public boolean accept(File file) {
		Matcher fileNameMatcher = pattern.matcher(file.getName());
		if (fileNameMatcher.matches()) {
            return true;
        }
        return false;
	}
	
}
