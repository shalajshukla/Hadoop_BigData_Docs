package org.cyb.spark
import org.apache.spark.sql.SparkSession
object GCPToS3Text {

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().appName("GCP to S3").master("local")
    .getOrCreate()
    
    val sc = spark.sparkContext 
    sc.hadoopConfiguration.set("fs.gs.impl", "com.google.cloud.hadoop.fs.gcs.GoogleHadoopFileSystem")
    sc.hadoopConfiguration.set("fs.AbstractFileSystem.gs.impl", "com.google.cloud.hadoop.fs.gcs.GoogleHadoopFS")
    
    sc.hadoopConfiguration.set("google.cloud.auth.service.account.enable", "true")
    /*sc.hadoopConfiguration.set("fs.gs.project.id", "resolute-future-168712")
    sc.hadoopConfiguration.set("google.cloud.auth.service.account.json.keyfile", "D:/GCP-key.json")*/
    
    sc.hadoopConfiguration.set("fs.gs.project.id", "dentsu-1048")
    sc.hadoopConfiguration.set("google.cloud.auth.service.account.json.keyfile", "d:/Dentsu-db1b1e898db6.json")
    
    sc.hadoopConfiguration.set("fs.s3n.awsAccessKeyId","AKIAI2I6BCCB3V6G6VMQ")
    sc.hadoopConfiguration.set("fs.s3n.awsSecretAccessKey","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")
     
     
    
    
    //val srcBucketPath ="gs://shraddha_24july/*_"+date+"_*.csv.gz"
    //val srcBucketPath ="gs://shraddha_24july/*activity*.csv.gz"
     val srcBucketPath ="gs://dcdt_-dcm_account2621/dcm_account2621_click_2017061621_20170617_095056_572673457.csv.gz"
     print(srcBucketPath)
    // val srcBucketPath ="gs://dcdt_-dcm_account2621/dcm_account2621_activity_20170608_20170609_042251_569481095.csv.gz"
    //val df = spark.read.csv(srcBucketPath);
   val df = spark.read.format("com.databricks.spark.csv").option("inferSchema", "true").option("delimiter", ",").option("header", "true").load(srcBucketPath)
  //  val files = sc.textFile(srcBucketPath)
    df.write.mode("append").format("com.databricks.spark.csv").option("header", "true").option("codec", "org.apache.hadoop.io.compress.GzipCodec").save("s3n://cyb-dentsu/shalaj2")
    //files.saveAsTextFile("s3n://cyb-dentsu/temp3")
   // files.saveAsTextFile("s3n://cyb-dentsu/temp4", classOf[org.apache.hadoop.io.compress.GzipCodec])
    
  }
}