package org.cyb.spark

//import org.apache.spark.annotation.InterfaceStability
import org.apache.spark.sql.SparkSession


object S3TOS3 {  
    def main (args:Array[String]) {
    //val conf = new SparkConf().setMaster("local").setAppName("test spark")
    // val sc = new SparkContext(conf)
      
    //read configuration file
   
    
    val spark = SparkSession.builder().appName("S3 to S3").master("local")getOrCreate()
     
    spark.sparkContext.hadoopConfiguration.set("fs.s3n.awsAccessKeyId","AKIAI2I6BCCB3V6G6VMQ") //Providing client AWS Bucket Credentials to Spark Configuration
    spark.sparkContext.hadoopConfiguration.set("fs.s3n.awsSecretAccessKey","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") //Providing client AWS Credentials to Spark Configuration
     
    //create s3 client for dentsu s3 
   /* val credentials = new BasicAWSCredentials("AKIAI2I6BCCB3V6G6VMQ", "H2KO7uT2YkBb4hAX78MZZ5O1j8iPM3Jdgz4is600"); 
    val s3client = new AmazonS3Client(credentials);*/
  
      
    val SourceData = spark.read
                .format("com.databricks.spark.csv")                
                .option("inferSchema", "true")
                .option("delimiter", ",")
                .option("header", "true")
                .load("s3n://cyb-dentsu/src/")
                
   // val SourceData = spark.read.csv("s3n://cyb-dentsu/src/");                
                
    SourceData.write.mode("append").format("com.databricks.spark.csv").option("header", "true").option("codec", "org.apache.hadoop.io.compress.GzipCodec").save("s3n://cyb-dentsu/dest2")

    }
    


}
