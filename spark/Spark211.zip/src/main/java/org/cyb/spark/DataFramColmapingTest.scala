package org.cyb.spark

import org.apache.spark.sql.SparkSession
import com.typesafe.config.{Config, ConfigFactory}
import java.io.File

object DataFramColmapingTest {

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().appName("DataFrame").master("local")getOrCreate()
    val environment = args(0)
     val SourceData   = spark.read
                .format("com.databricks.spark.csv")                
                .option("inferSchema", "true")
                .option("delimiter", ",")
                .option("header", "true")
                .load("D:\\ShalajS\\Rnd\\RandomValues\\customer1.csv")
                
    val props: Config = ConfigFactory.parseFile(new File("application.properties"))
    
    val col = props.getConfig("click").getString("column")
    
    val colproperties = col.split(",")
    
   
  
    colproperties.foreach { 
       x => val p = x.split("#")
       
       List(p(0),p(1),p(2))
     }
    
    val columnNames = Seq("col1","col2")
    val result = SourceData.select(columnNames.head, columnNames.tail: _*)
    
    println(result)
   // val result1 = SourceData.select(columnNames.map(c => col(c)): _*)
 
    
    
    /*var FormatedColumn = SourceData.select(
        SourceData.columns.map {
          case "Event Time"  => SourceData("Event Time").cast("LongType").as("event_time")
          case other => SourceData(other)
          }: _*
    )*/
    
    
  }
}