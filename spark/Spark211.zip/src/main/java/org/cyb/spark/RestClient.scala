package org.cyb.spark

import sun.misc.BASE64Encoder

import java.util.Iterator

import org.json.simple.JSONArray

import org.json.simple.JSONObject

import org.json.simple.parser.JSONParser

import org.json.simple.parser.ParseException



import com.sun.jersey.api.client.Client

import com.sun.jersey.api.client.ClientResponse

import com.sun.jersey.api.client.GenericType

import com.sun.jersey.api.client.WebResource

//remove if not needed
import scala.collection.JavaConversions._

object RestApiClient {

  def main(a: Array[String]): Unit = {
    var url: String =
      "http://localhost:8080/RESTFulJersey/webapi/order-inventory/order/1"
    val name: String = "java2novice"
    val password: String = "Simple4u!"
    val authString: String = name + ":" + password
    val authStringEnc: String = new BASE64Encoder().encode(authString.getBytes)
    println("Base64 encoded auth string: " + authStringEnc)
    val restClient: Client = Client.create()
    var webResource: WebResource = restClient.resource(url)
//first way to get response
    var resp: ClientResponse = webResource
      .accept("application/json")
      .header("Authorization", "Basic " + authStringEnc)
      .get(classOf[ClientResponse])
    if (resp.getStatus != 200) {
      System.err.println("Unable to connect to the server")
    }
    var output: String = resp.getEntity(classOf[String])
    println("response: " + output)
    var parser: JSONParser = new JSONParser()
    val json: JSONObject = parser.parse(output).asInstanceOf[JSONObject]
    val address: String = json.get("address").asInstanceOf[String]
    println(" address " + address)
    println("amount " + json.get("amount"))
// directoly cast json to object
    /*val order: Order = webResource
      .accept("application/json")
      .header("Authorization", "Basic " + authStringEnc)
      .get(new GenericType[Order](classOf[Order]))
    println("response: " + order.getAddress)*/
    url = "http://localhost:8080/RESTFulJersey/webapi/order-inventory/order/"
    webResource = restClient.resource(url)
//first way to get response
    resp = webResource
      .accept("application/json")
      .header("Authorization", "Basic " + authStringEnc)
      .get(classOf[ClientResponse])
    if (resp.getStatus != 200) {
      System.err.println("Unable to connect to the server")
    }
    output = resp.getEntity(classOf[String])
    println("response: " + output)
    parser = new JSONParser()
    val list: JSONArray = parser.parse(output).asInstanceOf[JSONArray]
    val iterator = list.iterator
    while (iterator.hasNext) {
      val json: JSONObject = iterator.next.asInstanceOf[JSONObject]
      val address: String = json.get("address").asInstanceOf[String]
      println(" address " + address)
      println("amount " + json.get("amount"))
    }
  }

}