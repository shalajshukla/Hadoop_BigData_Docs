package org.cyb.spark;

import java.util.ArrayList;
import java.util.List;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.elasticmapreduce.AmazonElasticMapReduce;
import com.amazonaws.services.elasticmapreduce.AmazonElasticMapReduceClient;
import com.amazonaws.services.elasticmapreduce.model.AddJobFlowStepsRequest;
import com.amazonaws.services.elasticmapreduce.model.AddJobFlowStepsResult;
import com.amazonaws.services.elasticmapreduce.model.HadoopJarStepConfig;
import com.amazonaws.services.elasticmapreduce.model.StepConfig;
import com.amazonaws.services.elasticmapreduce.util.StepFactory;

public class AddSparkStepJava {

	public static void main(String[] args) {
		AWSCredentials credentials = new BasicAWSCredentials("AKIAI2I6BCCB3V6G6VMQ", "H2KO7uT2YkBb4hAX78MZZ5O1j8iPM3Jdgz4is600");
		AmazonElasticMapReduce emr = new AmazonElasticMapReduceClient(credentials);
		 
		//StepFactory stepFactory = new StepFactory();
		//AmazonElasticMapReduceClient emr = new AmazonElasticMapReduceClient(credentials);
		AddJobFlowStepsRequest req = new AddJobFlowStepsRequest();
		req.withJobFlowId("j-1K48XXXXXXHCB");

		List<StepConfig> stepConfigs = new ArrayList<StepConfig>();
				
		HadoopJarStepConfig sparkStepConf = new HadoopJarStepConfig()
					.withJar("command-runner.jar")
					.withArgs("spark-submit","--executor-memory","1g","--class","org.apache.spark.examples.SparkPi","/usr/lib/spark/lib/spark-examples.jar","10");			
				
		StepConfig sparkStep = new StepConfig()
					.withName("Spark Step")
					.withActionOnFailure("CONTINUE")
					.withHadoopJarStep(sparkStepConf);

		stepConfigs.add(sparkStep);
		req.withSteps(stepConfigs);
		AddJobFlowStepsResult result = emr.addJobFlowSteps(req);
	}
}
