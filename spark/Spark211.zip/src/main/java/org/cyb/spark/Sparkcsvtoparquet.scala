package org.cyb.spark

import java.io.File
import org.apache.spark.sql.types._
import org.apache.spark.SparkConf
import org.apache.spark
import org.apache.spark._
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.SparkConf
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SparkSession
import java.text.SimpleDateFormat
import java.util.Calendar
import org.apache.hadoop.conf.Configuration
import com.amazonaws.services.s3.AmazonS3
import com.amazonaws.services.s3.model.ListObjectsRequest
import com.amazonaws.services.s3.model.S3ObjectSummary
import com.amazonaws.auth.BasicAWSCredentials
import com.amazonaws.services.s3.AmazonS3Client
import scala.collection.JavaConversions._
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat
import org.apache.hadoop.io.compress.GzipCodec
import org.apache.hadoop.io.compress.CompressionCodec

object Sparkcsvtoparquet {
    
  def main(args: Array[String]){
    
      //val conf = new SparkConf().setAppName("Spark CSV to Parquet").setMaster("local[2]") //.set("fs.s3a.access.key","AKIAI2I6BCCB3V6G6VMQ").set("fs.s3a.secret.key","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")     
     //.hadoopConfiguration.set("fs.s3a.access.key","AKIAI2I6BCCB3V6G6VMQ")
     //.hadoopConfiguration.set("fs.s3a.secret.key","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")     
     // val sc = new SparkContext(conf)
      //sc.hadoopConfiguration.set("fs.s3.impl", "org.apache.hadoop.fs.s3native.NativeS3FileSystem")
    //  sc.hadoopConfiguration.set("fs.s3a.access.key","AKIAI2I6BCCB3V6G6VMQ")
      //sc.hadoopConfiguration.set("fs.s3a.secret.key","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")
      //val spark = SparkSession.builder().config(conf).getOrCreate() 
      //val sqlContext = new SQLContext(sc)
      val AWS_ACCESS_KEY_ID ="AKIAI2I6BCCB3V6G6VMQ";
      val AWS_SECRET_ACCESS_KEY="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";
      
      val spark = SparkSession.builder().appName("Spark CSV to Parquet").master("local")getOrCreate()
      
      spark.sparkContext.hadoopConfiguration.set("fs.s3a.access.key","AKIAI2I6BCCB3V6G6VMQ")
      spark.sparkContext.hadoopConfiguration.set("fs.s3a.secret.key","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")

      spark.sparkContext.hadoopConfiguration.set("fs.s3n.awsAccessKeyId",AWS_ACCESS_KEY_ID)
      spark.sparkContext.hadoopConfiguration.set("fs.s3n.awsSecretAccessKey",AWS_SECRET_ACCESS_KEY)
      
      val credentials = new BasicAWSCredentials(AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY);

      val s3client = new AmazonS3Client(credentials);
      
      /*spark.conf.set("spark.hadoop.fs.s3.awsAccessKeyId", "AKIAI2I6BCCB3V6G6VMQ")
      spark.conf.set("spark.hadoop.fs.s3.awsSecretAccessKey", "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")*/
     
      
      //spark.hadoopConfiguration.set("fs.s3a.secret.key","H2KO7uT2YkBb4hAX78MZZ5O1j8iPM3Jdgz4is600")    
      
      //spark.hadoopConfiguration.set("fs.s3a.access.key","AKIAI2I6BCCB3V6G6VMQ")
      
      //spark.hadoopConfiguration.set("fs.s3a.secret.key","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")     
      
      //spark.hadoopConfiguration.set("fs.s3.impl", "org.apache.hadoop.fs.s3native.NativeS3FileSystem")
      //.hadoopConfiguration.set("fs.s3a.access.key","AKIAI2I6BCCB3V6G6VMQ")
      //.hadoopConfiguration.set("fs.s3a.secret.key","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")
      //val configpath: String = args(0)
      //val config = ConfigFactory.parseFile(new File(configpath))      
      //val input = config.getString("input")     
      
      val dateformat = new SimpleDateFormat("yMMd")
      //val date = dateformat.format(Calendar.getInstance().getTime()).toString()     
      val cal = Calendar.getInstance();
      
      cal.add(Calendar.DATE, -1);
      
      
      val date = dateformat.format(cal.getTime());
      
      
      
      
    /*  val listoffiles = Array("dcm_account2621_activity_20161116_20161117_030627_311999667.csv",
          "dcm_account2622_click_2016111606_20161116_221031_311735299.csv",
          "dcm_account2623_impression_2016111605_20161116_221808_311685411.csv",
          "dcm_account2624_rich_media_2016111606_20161116_192542_311735300.csv")*/
      //val filePath = "D:\\ShalajS\\COE_Analysis\\Dentsu\\DTv2\\data\\"
      // val filePath = "/root/dentsu/data/"
       
      val srcBucketPath="s3n://cyb-dentsu//src//";
      
      
     // val textFile = spark.sparkContext.textFile("s3n://cyb-dentsu//src")
      
      //val listoffiles = getListOfFiles(filePath)
      val listoffiles = getListOfFiles("cyb-dentsu","src/","/",s3client);
      
      for (i <- 0 until listoffiles.length){
              println(listoffiles(i))
        val pattern1 = "([A-Za-z]+_[A-Za-z]+([0-9]+))".r
        
        var clientid = pattern1.findFirstIn(listoffiles(i)).getOrElse("no match")
        
        val pattern2 = """(\d{8})""".r
        
        var filedate = pattern2.findFirstIn(listoffiles(i)).getOrElse("no match")
        
        val SourceData   = spark.read
                .format("com.databricks.spark.csv")                
                .option("inferSchema", "true")
                .option("delimiter", ",")
                .option("header", "true")
                .load(srcBucketPath + listoffiles(i))
                
        
 
                
               
        var RemovedSpacefromColumn = SourceData
        
        for(col <- SourceData.columns){
        RemovedSpacefromColumn = RemovedSpacefromColumn.withColumnRenamed(col,col.replaceAll("[^\\w]", ""))
          //RemovedSpacefromColumn = RemovedSpacefromColumn.withColumnRenamed(col,col.replaceAll("[^\\w\\s\\]", ""))
          //.withColumnRenamed(col,col.replaceAll("\\s", "_"))
          //RemovedSpacefromColumn = RemovedSpacefromColumn.withColumnRenamed(col,col.replaceAll("\\(", ""))
          //RemovedSpacefromColumn = RemovedSpacefromColumn.withColumnRenamed(col,col.replaceAll("\\)", ""))    
        }
                //.toDF("Userid","Date","label")
       //trainingData.write.mode("append").format("parquet").save("/root/"+ date+".parquet")
    
      //RemovedSpacefromColumn.write.mode("append").parquet("/root/Clientid=" + clientid + "/" + filedate + "/")
        //RemovedSpacefromColumn.write.mode("append").parquet("s3n://AKIAI2I6BCCB3V6G6VMQ:H2KO7uT2YkBb4hAX78MZZ5O1j8iPM3Jdgz4is600@cyb-dentsu//test//Clientid=" + clientid + "//" + filedate + "//")
        RemovedSpacefromColumn.write.mode("append").parquet("s3n://cyb-dentsu//test//Clientid=" + clientid + "//" + filedate + "//")
  }       
 }
   def getListOfFiles(dir: String):List[String] = {
    val d = new File(dir)
    if (d.exists && d.isDirectory) {
        d.listFiles.filter(_.isFile).map ( x => x.getName ).toList
    } else {
        List[String]()
    }
  }
   def getListOfFiles (bucketName :String,prefix:String,delimiter : String, s3Client : AmazonS3) : List[String] = {
     val listObjectRequest = new ListObjectsRequest().
              withBucketName(bucketName).
              withPrefix(prefix).
              withDelimiter(delimiter);
     
     val objectListing = s3Client.listObjects(listObjectRequest)
     
     val summaryList  = objectListing.getObjectSummaries
     var fileList = List[String]()
     for(s3ObjectSummary <- summaryList) {
        if(!s3ObjectSummary.getKey().equals(prefix)){
           val key = s3ObjectSummary.getKey();
          println(key.substring(key.lastIndexOf(delimiter)+delimiter.length()));
          fileList = key.substring(key.lastIndexOf(delimiter)+delimiter.length) :: fileList
           //fileList.++(key.substring(key.lastIndexOf(delimiter)+delimiter.length()));
       }
     }
     
     println(summaryList)
     /*var fileList = List[String]()
     val iterator = summaryList.iterator
     while(iterator.hasNext) {
       val s3ObjectSummary = iterator.next
       println(s3ObjectSummary.getKey())
       if(!s3ObjectSummary.getKey().equals(prefix)){
           val key = s3ObjectSummary.getKey();
          println(key.substring(key.lastIndexOf(delimiter)+delimiter.length()));
          fileList = key.substring(key.lastIndexOf(delimiter)+delimiter.length) :: fileList
           //fileList.++(key.substring(key.lastIndexOf(delimiter)+delimiter.length()));
       }
     }*/
     println(fileList)
     fileList
  
   }
   
}
