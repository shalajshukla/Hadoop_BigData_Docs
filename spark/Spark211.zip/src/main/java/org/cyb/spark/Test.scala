package org.cyb.spark

import org.apache.spark.SparkConf
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.hadoop.io.Text
import org.apache.hadoop.io.IntWritable
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.typesafe.config.ConfigFactory
import com.typesafe.config.Config
import java.io.File
import java.util.Calendar
import java.text.SimpleDateFormat
import scala.collection.JavaConversions._
import com.amazonaws.auth.AWSCredentials
import com.amazonaws.auth.BasicAWSCredentials
import com.amazonaws.services.s3.AmazonS3
import com.amazonaws.services.s3.AmazonS3Client
import com.amazonaws.services.s3.model.Bucket
import com.amazonaws.services.s3.model.ListObjectsRequest
import com.amazonaws.services.s3.model.ObjectListing
import com.amazonaws.services.s3.model.S3ObjectSummary
import org.apache.spark.sql.types.StringType



object Test {  
    def main (args:Array[String]) {

    //read configuration file
     
    val spark = SparkSession.builder().appName("Spark CSV to Parquet").master("local")getOrCreate()
     
    spark.sparkContext.hadoopConfiguration.set("fs.s3n.awsAccessKeyId","AKIAIZKOMVLY475DKMEQ") //Providing client AWS Bucket Credentials to Spark Configuration
    spark.sparkContext.hadoopConfiguration.set("fs.s3n.awsSecretAccessKey","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") //Providing client AWS Credentials to Spark Configuration
    
    val SourceData = spark.read.format("com.databricks.spark.csv").option("inferSchema", "true").option("delimiter", ",")
                   .option("header", "true").load("s3n://adcelerate-copyoperation/TestFiles/*match_table_states_*.csv.gz")
                   
    
   /*var FormatedColumn = SourceData.select("State/Region","State/Region Full Name")
       
            FormatedColumn = FormatedColumn.select(
            FormatedColumn.columns.map {
            case "State/Region"                     => SourceData("State/Region").cast(StringType).as("state_region")
            case "State/Region Full Name"             => SourceData("State/Region Full Name").cast(StringType).as("state_region_full_name")            
            case other => FormatedColumn(other)
     }: _*
           )  */
//FormatedColumn.write.mode("append").parquet("s3n://adcelerate-datapipeline-output/" + S3Path )
                   
    
    SourceData.write.mode("append").format("com.databricks.spark.csv").option("header", "true").option("codec", "org.apache.hadoop.io.compress.GzipCodec").save("d://gz/")
    
    val SourceData1 = spark.read.format("com.databricks.spark.csv").option("inferSchema", "true").option("delimiter", ",")
                  .option("header", "true").load("d://gz/*.gz")
                   
    var FormatedColumn = SourceData1.select("State/Region","State/Region Full Name")
       
            FormatedColumn = FormatedColumn.select(
            FormatedColumn.columns.map {
            case "State/Region"                     => SourceData1("State/Region").cast(StringType).as("state_region")
            case "State/Region Full Name"             => SourceData1("State/Region Full Name").cast(StringType).as("state_region_full_name")            
            case other => FormatedColumn(other)
     }: _*
           )                  
                   
    FormatedColumn.write.mode("append").parquet("d://parquet/")

    }
}
