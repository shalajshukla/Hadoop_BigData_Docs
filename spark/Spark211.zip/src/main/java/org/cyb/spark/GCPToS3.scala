package org.cyb.spark

import org.apache.spark.sql.SparkSession
import java.util.Calendar
import java.text.SimpleDateFormat 

object GCPToS3 {

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().appName("GCP to S3").master("local")getOrCreate()
    
    val sc = spark.sparkContext 
    sc.hadoopConfiguration.set("fs.gs.impl", "com.google.cloud.hadoop.fs.gcs.GoogleHadoopFileSystem")
    sc.hadoopConfiguration.set("fs.AbstractFileSystem.gs.impl", "com.google.cloud.hadoop.fs.gcs.GoogleHadoopFS")
    
    sc.hadoopConfiguration.set("google.cloud.auth.service.account.enable", "true")
    /*sc.hadoopConfiguration.set("fs.gs.project.id", "resolute-future-168712")
    sc.hadoopConfiguration.set("google.cloud.auth.service.account.json.keyfile", "D:/GCP-key.json")*/
    
    sc.hadoopConfiguration.set("fs.gs.project.id", "dentsu-1048")
    sc.hadoopConfiguration.set("google.cloud.auth.service.account.json.keyfile", "D:/Dentsu-db1b1e898db6.json")
    
    
    
    sc.hadoopConfiguration.set("fs.s3n.awsAccessKeyId","AKIAI2I6BCCB3V6G6VMQ")
    sc.hadoopConfiguration.set("fs.s3n.awsSecretAccessKey","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")
     
     
    // read csv file and write to s3 in gzip format
    
    val dateformat = new SimpleDateFormat("yMMdd")
    val cal = Calendar.getInstance();
    cal.add(Calendar.DATE, -2);
    val date = dateformat.format(cal.getTime());
    
    
    //val srcBucketPath ="gs://shraddha_24july/*_"+date+"_*.csv.gz"
    //val srcBucketPath ="gs://shraddha_24july/*activity*.csv.gz"
     val srcBucketPath ="gs://dcdt_-dcm_account2621/dcm_account2621_click_2017061621_20170617_095056_572673457.csv.gz"
     print(srcBucketPath)
    // val srcBucketPath ="gs://dcdt_-dcm_account2621/dcm_account2621_activity_20170608_20170609_042251_569481095.csv.gz"
    //val df = spark.read.csv(srcBucketPath);
    
    // spark.udf.register("get_only_file_name", (fullPath: String) => fullPath.split("/").last)
     import org.apache.spark.sql.functions._
     // we can register one more column which will get the file name full path it uses pre-existed function input_file_name under package below 
     val df = spark.read.format("com.databricks.spark.csv").option("inferSchema", "true").option("delimiter", ",").option("header", "true").load(srcBucketPath).withColumn("input_file_name", input_file_name)
    
    df.write.mode("append").format("com.databricks.spark.csv").option("header", "true").option("codec", "org.apache.hadoop.io.compress.GzipCodec").save("s3n://cyb-dentsu/shalaj3")
    
    df.select("input_file_name").show(10)
  }
}