package org.cyb.spark

import java.util.ArrayList
import java.util.List

import com.amazonaws.auth.AWSCredentials
import com.amazonaws.auth.BasicAWSCredentials
import com.amazonaws.services.elasticmapreduce.AmazonElasticMapReduce
import com.amazonaws.services.elasticmapreduce.AmazonElasticMapReduceClient
import com.amazonaws.services.elasticmapreduce.model.AddJobFlowStepsRequest
import com.amazonaws.services.elasticmapreduce.model.AddJobFlowStepsResult
import com.amazonaws.services.elasticmapreduce.model.HadoopJarStepConfig
import com.amazonaws.services.elasticmapreduce.model.StepConfig

//spark-submit --executor-memory 1g --class org.apache.spark.examples.SparkPi /usr/lib/spark/lib/spark-examples.jar 10
//--executor-memory 1g --class org.apache.spark.examples.SparkPi /usr/lib/spark/lib/spark-examples.jar 10

object AddSparkStep {

  def main(args: Array[String]): Unit = {
    val credentials: AWSCredentials = new BasicAWSCredentials("AKIAI2I6BCCB3V6G6VMQ","H2KO7uT2YkBb4hAX78MZZ5O1j8iPM3Jdgz4is600")
    val emr: AmazonElasticMapReduce = new AmazonElasticMapReduceClient(credentials)

    val req: AddJobFlowStepsRequest = new AddJobFlowStepsRequest()
    req.withJobFlowId("j-1K48XXXXXXHCB")
    
    val stepConfigs: List[StepConfig] = new ArrayList[StepConfig]()
    val sparkStepConf: HadoopJarStepConfig = new HadoopJarStepConfig()
                                              .withJar("D:\\ShalajS\\COE_Analysis\\Dentsu\\commandrunner-0.0.1.jar")
                                              .withArgs("spark-submit","--executor-memory","1g",
                                                        "--class", "org.apache.spark.examples.SparkPi",
                                                        "/usr/lib/spark/lib/spark-examples.jar",
                                                        "10")
  val sparkStepConf1: HadoopJarStepConfig = new HadoopJarStepConfig()
                                              //.withJar("command-runner.jar")
                                              .withJar("D:\\ShalajS\\COE_Analysis\\Dentsu\\commandrunner-0.0.1.jar")
                                              .withArgs("spark-submit","--executor-memory","1g",
                                                        "--class", "org.apache.spark.examples.SparkPi",
                                                        "/usr/lib/spark/lib/spark-examples.jar",
                                                        "20")                                                        
    val sparkStep: StepConfig = new StepConfig().withName("Spark Step").withActionOnFailure("CONTINUE")
                                .withHadoopJarStep(sparkStepConf)
                                .withHadoopJarStep(sparkStepConf1)
    
    stepConfigs.add(sparkStep)
     
    req.withSteps(stepConfigs)
    val result: AddJobFlowStepsResult = emr.addJobFlowSteps(req)
  }
}