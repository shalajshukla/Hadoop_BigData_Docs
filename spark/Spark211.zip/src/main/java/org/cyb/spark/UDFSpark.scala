package org.cyb.spark

import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SparkSession

//https://jaceklaskowski.gitbooks.io/mastering-apache-spark/spark-sql-udfs.html
object UDFSpark {

  def main(args: Array[String]): Unit = {
    
    val spark = SparkSession.builder().appName("GCP to S3").master("local")getOrCreate()
    
    val sqlContext = new SQLContext(spark.sparkContext)
    
    import sqlContext.implicits._
    
    val df = Seq((0, "hello"), (1, "world")).toDF("id", "text")
    
    // toUpper function take string and return string
    val toUpper: String => String = _.toUpperCase
    
    import org.apache.spark.sql.functions.udf
    
    val upper = udf(toUpper)
    
    // You can register UDFs to use in SQL-based query expressions via UDFRegistration
    //spark.udf.register("upperFunction", toUpper)
     spark.udf.register("myupper", (input: String) => input.toUpperCase)
     
     // check spark catlog to get the list of function
     spark.catalog.listFunctions.filter('name like "%upper%").show(false)
    
    //added one more column upper to dataframe and applied udf on function
    
    df.withColumn("upper", upper('text)).show
    
    
    val upperUDF = udf { s: String => s.toUpperCase }
    
    val upperUDF1 = udf[String, String](_.toUpperCase)
    
    
    df.withColumn("upper", upperUDF('text)).show
    
    
  }
}