package org.cyb.spark

import com.amazonaws.auth.AWSCredentials
import com.amazonaws.auth.BasicAWSCredentials
import com.amazonaws.services.s3.AmazonS3
import com.amazonaws.services.s3.AmazonS3Client
import com.sun.jersey.api.client.Client
import com.sun.jersey.api.client.ClientResponse
import com.amazonaws.services.s3.model.PutObjectRequest

object HttpToS3 {

  def main(args: Array[String]): Unit = {
    downloadAndCopyToS3
  }
  def downloadAndCopyToS3() {
        val masterid="4196e1f8-4cac-4f08-a43a-0997ccb706f3"
        val masterUrl = "http://localhost:8080/examples/dcm_account2621_click_2016111606_20161116_221031_311735299.csv.gz"
        val credentials: AWSCredentials = new BasicAWSCredentials("AKIAI2I6BCCB3V6G6VMQ","H2KO7uT2YkBb4hAX78MZZ5O1j8iPM3Jdgz4is600")
        val s3client: AmazonS3 = new AmazonS3Client(credentials)
        
        val filename = masterUrl.split('/').last
        
        //println(masterUrl.split('/').last)
        
        try{
            val restClient: Client = Client.create()
            val webResource = restClient.resource(masterUrl)
            
            val response = webResource.get(classOf[ClientResponse])
            
            if (response.getStatus != 200) {
              System.err.println("Unable to connect to the server")
            }
            val inputStream = response.getEntityInputStream
            s3client.putObject(new PutObjectRequest("cyb-dentsu", "stream/"+filename, inputStream,null));
            
        } catch {
          case e:Exception => println(" exception occur " + e.getMessage)
        }
  }
}