package org.cyb.spark;

import java.util.Properties;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.tools.DistCp;
import org.apache.hadoop.tools.DistCpOptions;
import org.apache.hadoop.util.ToolRunner;

public class DistcpTest {
	
	//hadoop jar original-Spark211-0.0.1-SNAPSHOT.jar org.cyb.spark.DistcpTest hdfs://mac55:8020/user/shalaj/ hdfs://mac55:8020/user/shalaj/outputs2
	//hadoop jar original-Spark211-0.0.1-SNAPSHOT.jar org.cyb.spark.DistcpTest gs://shraddha_24july/ s3n://cyb-dentsu/dest


	public static void main(String[] c) throws Exception {
		
		/*Path srcPath = new Path("hdfs://mac55:8020/user/shalaj/command_oozie.txt");
		Path destPath = new Path("hdfs://mac55:8020/user/shalaj/outputs/");*/
		/*Path srcPath = new Path("gs://shraddha_24july/* ");
		Path destPath = new Path("s3a://cyb-dentsu/dest");*/
		Path srcPath = new Path(c[0]);
		Path destPath = new Path(c[1]);
	
		       
		DistCpOptions options = new DistCpOptions (srcPath,destPath);
		String[] filepaths =  new String[] {c[0],c[1]};
		
		new DistcpTest().executeDistCp (options,filepaths);
	}

	
	/*public void testCopyFromLocalToLocal() throws Exception {
	  Configuration conf = new Configuration();
	  FileSystem localfs = FileSystem.get(LOCAL_FS, conf);
	 // MyFile[] files = createFiles(LOCAL_FS, TEST_ROOT_DIR+"/srcdat");
	  ToolRunner.run(new DistCp(new Configuration()),
	                         new String[] {"file:///"+"TEST_ROOT_DIR"+"/srcdat",
	                                       "file:///"+"TEST_ROOT_DIR"+"/destdat"});
	  assertTrue("Source and destination directories do not match.",
	             checkFiles(localfs, TEST_ROOT_DIR+"/destdat", files));
	  //deldir(localfs, TEST_ROOT_DIR+"/destdat");
	//  deldir(localfs, TEST_ROOT_DIR+"/srcdat");
	}*/
	
	
	
	protected Boolean executeDistCp(DistCpOptions options,String[] filepaths)
	    throws Exception
	{
		Configuration conf = new Configuration();
		conf.set("fs.gs.impl", "com.google.cloud.hadoop.fs.gcs.GoogleHadoopFileSystem");
	    conf.set("fs.AbstractFileSystem.gs.impl", "com.google.cloud.hadoop.fs.gcs.GoogleHadoopFS");
	    
	    conf.set("google.cloud.auth.service.account.enable", "true");
	    conf.set("fs.gs.project.id", "resolute-future-168712");
	    conf.set("google.cloud.auth.service.account.json.keyfile", "/home/gcp/GCP-key.json");
	    
	        
	    conf.set("fs.s3n.awsAccessKeyId","AKIAI2I6BCCB3V6G6VMQ");
	    conf.set("fs.s3n.awsSecretAccessKey","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");
	  //Add Additional Default arguments to the array below which gets merged
	  //with the arguments as sent in by the Derived Service
	  //Configuration conf = destCluster.getHadoopConf();
	  Path outputDir = new Path( filepaths[1] );
	  outputDir.getFileSystem(conf).delete(outputDir, true);
	  DistCp distCp = new DistCp(conf, options);
	  try {
	    //distCp.execute();
		ToolRunner.run(distCp,filepaths);
	  } catch (Exception e) {
	    throw e;
	  }
	  return true;
	}
	public void doBackup() throws Exception {
		Properties prop = new Properties();
	    System.out.println("Beginning Distcp");
	    DistCpOptions options = new DistCpOptions(
	            new Path(prop.getProperty("sourceClusterDirectory") + "/" + prop.getProperty("tablename")
	                    + "/distcp.txt"),
	            new Path(prop.getProperty("targetCluster") + prop.getProperty("targetClusterDirectory")));

	    System.out.println("Disctp between--->" + prop.getProperty("sourceClusterDirectory")+ "/distcp.txt" + "AND" + prop.getProperty("targetCluster")
	            + prop.getProperty("targetClusterDirectory"));
	    DistCp distcp = new DistCp(new Configuration(), options);
	    Job job = distcp.execute();

	    job.waitForCompletion(true);

	    System.out.println("DistCp Completed Successfully");


	}
}
