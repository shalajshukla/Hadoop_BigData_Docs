package org.cyb.spark

import java.util.List

import com.amazonaws.auth.AWSCredentials

import com.amazonaws.auth.BasicAWSCredentials

import com.amazonaws.services.s3.AmazonS3

import com.amazonaws.services.s3.AmazonS3Client

import com.amazonaws.services.s3.model.Bucket

import com.amazonaws.services.s3.model.ListObjectsRequest

import com.amazonaws.services.s3.model.ObjectListing

import com.amazonaws.services.s3.model.S3ObjectSummary

//remove if not needed
import scala.collection.JavaConversions._

object TestAWSS3 {

  def main(args: Array[String]): Unit = {
    val credentials: AWSCredentials = new BasicAWSCredentials(
      "AKIAI2I6BCCB3V6G6VMQ",
      "H2KO7uT2YkBb4hAX78MZZ5O1j8iPM3Jdgz4is600")
    val s3client: AmazonS3 = new AmazonS3Client(credentials)

    val ol: ObjectListing = s3client.listObjects("cyb-dentsu")
    val summaryList: List[S3ObjectSummary] = ol.getObjectSummaries
    for (s3ObjectSummary <- summaryList) {
      println(s3ObjectSummary.getKey)
    }
  }
}