package org.cyb.spark

object SimpleApp {

}
//import java.io.Serializable;


//import org.apache.hadoop.conf.Configuration;
//import org.apache.hadoop.fs.FileSystem;
//import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable
import org.apache.hadoop.mapred.lib.MultipleTextOutputFormat

class RDDMultipleTextOutputFormat extends org.apache.hadoop.mapred.lib.MultipleTextOutputFormat[Any, Any]  {
override def generateActualKey(key: Any, value: Any): Any = org.apache.hadoop.io.NullWritable.get()

override def generateFileNameForKeyValue(key: Any, value: Any, name: String): String =
  return key.asInstanceOf[String] +"_"+ name;
}