package org.cyb.spark

import java.io.File
import java.util.Calendar
import java.text.SimpleDateFormat 


object testScala {

  def main(args: Array[String]): Unit = {
   /* val listFiles = getListOfFiles("D:\\ShalajS\\COE_Analysis\\Dentsu\\DTv2\\data")
    
    listFiles.foreach { println }*/
    
    /*val pattern1 = "([A-Za-z]+_[A-Za-z]+([0-9]+))".r
        
    var clientid = pattern1.findFirstIn("dcm_account2621_activity_20161116_20161117_030627_311999667.csv").getOrElse("no match")
    
    println(clientid)*/
    formatDate
    
  }
  def getListOfFiles(dir: String):List[String] = {
    val d = new File(dir)
    if (d.exists && d.isDirectory) {
        d.listFiles.filter(_.isFile).map ( x => x.getName ).toList
    } else {
        List[String]()
    }
  }
  
  def formatDate () {
    val str = "Aug 4, 2017 12:30:09 PM"
    
    val dateformat = new SimpleDateFormat("MMM dd,yyyy hh:mm:ss a")
    val date = dateformat.parse(str)
    
    println(date)
    
  }
}