package org.cyb.spark
import sys.process._

object RunCommand {
  def main(args: Array[String]): Unit = {
    val result = "dir" !
  }
}