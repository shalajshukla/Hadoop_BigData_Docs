package org.cyb.spark

import java.sql._

import java.util.Properties

object AthenaJDBCDemo {

  val athenaUrl: String = "jdbc:awsathena://athena.us-east-1.amazonaws.com:443"

  def main(args: scala.Array[String]): Unit = {
    var conn: Connection = null
    var statement: Statement = null
    try {
      Class.forName("com.amazonaws.athena.jdbc.AthenaDriver")
      val info: Properties = new Properties()
      info.put("s3_staging_dir", "s3://cyb-dentsu/test/")
     // info.put("log_path", "D:/athena/athenajdbc.log")
      info.put("aws_credentials_provider_class","com.amazonaws.auth.PropertiesFileCredentialsProvider")
      info.put("aws_credentials_provider_arguments", "application.properties")
      
     // info.put("aws_credentials_provider_class","com.amazonaws.auth.BasicAWSCredentials")
      //info.put("aws_credentials_provider_arguments", "AKIAI2I6BCCB3V6G6VMQ,H2KO7uT2YkBb4hAX78MZZ5O1j8iPM3Jdgz4is600")
      
     
      println("Connecting to Athena...")
      
      conn = DriverManager.getConnection(athenaUrl, info)
      statement = conn.createStatement()
      
      
          val sql = "show tables in sampledb"
          
          val rs = statement.executeQuery(sql);

          while (rs.next()) {
              //Retrieve table column.
              val name = rs.getString("tab_name");

              //Display values.
              println("Name: " + name);
          }
          rs.close();
      
      /*val createdbsql = "create database if not exists dcm"
      statement.execute(createdbsql)
      
      val sql = "create external table if not exists dcm.test (key string, value string) partitioned by (clientid string, dt string) ROW FORMAT DELIMITED FIELDS TERMINATED BY ',' LOCATION 's3://cyb-dentsu/shalaj' "
      statement.execute(sql)
      
      val mscksql = "MSCK Repair table dcm.test"
      statement.execute(mscksql)*/
      
      conn.close()
    } catch {
      case ex: Exception => ex.printStackTrace()

    } finally {
      try if (statement != null) statement.close()
      catch {
        case ex: Exception => {}
      }
      try if (conn != null) conn.close()
      catch {
        case ex: Exception => ex.printStackTrace()

      }
    }
    println("Finished connectivity test.")
  }

}