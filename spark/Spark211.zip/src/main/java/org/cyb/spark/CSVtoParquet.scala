package org.cyb.spark

import org.apache.spark.sql.SparkSession
import java.io.File
import org.apache.spark.sql.types._
import org.apache.spark.SparkConf
import org.apache.spark
import org.apache.spark._
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.SparkConf
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SparkSession
import java.text.SimpleDateFormat
import java.util.Calendar
import org.apache.hadoop.conf.Configuration
import com.amazonaws.services.s3.AmazonS3
import com.amazonaws.services.s3.model.ListObjectsRequest
import com.amazonaws.services.s3.model.S3ObjectSummary
import com.amazonaws.auth.BasicAWSCredentials
import com.amazonaws.services.s3.AmazonS3Client
import scala.collection.JavaConversions._
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat
import org.apache.hadoop.io.compress.GzipCodec
import org.apache.hadoop.io.compress.CompressionCodec

object CSVtoParquet {

  def main(args: Array[String]): Unit = {
       val AWS_ACCESS_KEY_ID ="AKIAI2I6BCCB3V6G6VMQ";
      val AWS_SECRET_ACCESS_KEY="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";
     val spark = SparkSession.builder().appName("Spark CSV to Parquet").master("local")getOrCreate()
     
    /* val SourceData   = spark.read
                .format("com.databricks.spark.csv")                
                .option("inferSchema", "true")
                .option("delimiter", ",")
                .option("header", "true")
                .load("d:\\test\\shalaj.csv")
     
      SourceData.write.mode("append").parquet("D:\\ShalajS\\COE_Analysis\\Dentsu\\parquet")*/
      
      
      spark.sparkContext.hadoopConfiguration.set("fs.s3n.awsAccessKeyId",AWS_ACCESS_KEY_ID)
      spark.sparkContext.hadoopConfiguration.set("fs.s3n.awsSecretAccessKey",AWS_SECRET_ACCESS_KEY)
      
      val credentials = new BasicAWSCredentials(AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY);

      val s3client = new AmazonS3Client(credentials);
      
       val listObjectRequest = new ListObjectsRequest().
              withBucketName("cyb-dentsu").
              withPrefix("click1DCM/click/account2621/20170805/").
              withMarker("20170805/").
              withDelimiter("/");
       
       val objectListing = s3client.listObjects(listObjectRequest)
       val summaryList  = objectListing.getObjectSummaries
       for(s3ObjectSummary <- summaryList) {
         val key = s3ObjectSummary.getKey();
         println(key)
       }
  }
}