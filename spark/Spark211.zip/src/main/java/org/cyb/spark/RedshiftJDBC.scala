package org.cyb.spark

import java.sql._

import java.util.Properties

object RedshiftJDBC {

  val athenaUrl: String = "jdbc:redshift://localhost:5432/test"

  def main(args: scala.Array[String]): Unit = {
    var conn: Connection = null
    var statement: Statement = null
    try {
      Class.forName("com.amazon.redshift.jdbc.Driver")
     
      println("Connecting to redshift...")
      
      conn = DriverManager.getConnection(athenaUrl,"root","9qWvrAk7")
      statement = conn.createStatement()
      
     val createSchemaSql = "create external schema if not exists athena_schema from data catalog "+
                "database 'dcm' "+
                "iam_role 'arn:aws:iam::571510948918:role/mySpectrumRole' "+
                "region 'us-east-1'";
          
       statement.execute(createSchemaSql)
       
       /*val sql ="select * from athena_schema.employee"
       val rs = statement.executeQuery(sql)
       
       while (rs.next()){
         println(rs.getString(2))
         println(rs.getString(1))
       }
       rs.close*/
     
     
      conn.close()
    } catch {
      case ex: Exception => ex.printStackTrace()

    } finally {
      try if (statement != null) statement.close()
      catch {
        case ex: Exception => {}
      }
      try if (conn != null) conn.close()
      catch {
        case ex: Exception => ex.printStackTrace()

      }
    }
    println("Finished connectivity test.")
  }
}