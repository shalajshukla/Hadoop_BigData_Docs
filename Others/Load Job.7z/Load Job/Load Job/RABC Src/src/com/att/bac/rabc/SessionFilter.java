/*
 * Module description: 
 * This class performs filtering tasks on either a request or a response
 * or both. It is used to store the http header and request info in session.
 * 
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 *
 * Modification History:                                     
 * SBCUID		Date			Description                         	    	
 * ------		--------		-----------
 * PD2951		20051216		Initial version for EAP 556010  
 */

package com.att.bac.rabc;

import java.io.IOException;
import java.util.Enumeration;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

public class SessionFilter implements Filter {
	private static Logger logger = Logger.getLogger(SessionFilter.class);
	
	private ServletContext ctx = null;
	
	public void init(FilterConfig config) throws ServletException {
		ctx = config.getServletContext();
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest httprequest = (HttpServletRequest)request;
        String home = null;
        String auth_home = null;
        Enumeration enumer = null;
        String parameterName = null;
        String showSideMenu = null;
        
        try {
            Context context = (Context)new InitialContext().lookup("java:/comp/env");
            home = (String)context.lookup("authentication_link");
            auth_home = (String)context.lookup("authentication_logout");
        } catch(Exception e){
            logger.warn("Unable to find 'authentication_link'. Using default.", e);
        	home = "https://controls.sbc.com/cfdocs/New_Authentication/Main_Application_lib/bac_logout.cfm";
        }
        
        //Don't validate requests for / and /index.jsp
        if(httprequest.getRequestURI().endsWith("index.jsp") || httprequest.getRequestURI().endsWith("/")){
            logger.debug("Skipping session validation for: "+httprequest.getRequestURI());
        	chain.doFilter(request, response);
        	//If the user got a session before going to this page then invalidate it before returning them to it
            HttpSession session = httprequest.getSession(false);
            if(session!=null){
                session.invalidate();
            }
          
            return;
        }
        
        //If user is logging in establish a session, otherwise try to get the current session
        HttpSession session = httprequest.getSession(false);
        
        // Add code to invalidate the session first if it comes from authentication so that a new session is created
        if (request.getParameter("forwardTo")!=null && "fromAuth".equals(request.getParameter("forwardTo")) && session != null){
            session.invalidate();
            session = httprequest.getSession(false);            
        }
        
        if(session == null && request.getParameter("uBACUserID") != null){
            session = httprequest.getSession(true);
            //Set the session parameters
            session.setAttribute("referer",httprequest.getHeader("Referer"));
            session.setAttribute("applicationLink",request.getParameter("uApplicationLink").trim());
            session.setAttribute("bacHome",request.getParameter("uBACHome").trim());
            session.setAttribute("bacLogonMode",request.getParameter("uBACLogonMode").trim());
            session.setAttribute("bacUserID",request.getParameter("uBACUserID").toUpperCase().trim());
            session.setAttribute("userName",request.getParameter("uUserName").replace('%',' ').trim());
            session.setAttribute("userFunctCd",request.getParameter("uUserFunctCd").trim());
            session.setAttribute("supvsorID",request.getParameter("uSupvsorID").trim());
            session.setAttribute("cmpyID",request.getParameter("uCmpyID").trim());
            session.setAttribute("applID",request.getParameter("uApplId").trim());
            session.setAttribute("applName",request.getParameter("uApplName").trim());
            session.setAttribute("cmpyName",request.getParameter("uCmpyName").trim());
            session.setAttribute("region",request.getParameter("uCmpyID").trim());
            session.setAttribute("homeLink",home.trim());
            logger.debug("'" + (String)session.getAttribute("userName") + "'");
            logger.debug("'" + (String)session.getAttribute("cmpyName") + "'");
        } else if ((request.getParameter("schedTask") != null) && (request.getParameter("schedTask").trim().equals("Y"))){
        	session = httprequest.getSession(true);
        	if (request.getParameter("uCmpyID") != null && !request.getParameter("uCmpyID").trim().equals(""))
        		session.setAttribute("region",request.getParameter("uCmpyID").trim());
        }
        
        //If the user has no session, send them back to the login page, otherwise complete their request
        if(session==null){
            response.setContentType("text/html");
            response.getWriter().write("<script>alert('Your RABC session has expired, please log in again.'); document.location.href='"+auth_home+"';</script>");
        } else {
        	enumer = request.getParameterNames();
        	//Is the region being switched from the side menu?
        	if (request.getParameter("uNewReg") != null) {
        		//Invalidate the old session...
        		session.invalidate();
        		//Create a new session...
        		session = httprequest.getSession(true);
        		//Set the new session parameters
                session.setAttribute("referer",httprequest.getHeader("Referer"));
                session.setAttribute("applicationLink",request.getParameter("uApplicationLink").trim());
                session.setAttribute("bacHome",request.getParameter("uBACHome").trim());
                session.setAttribute("bacLogonMode",request.getParameter("uBACLogonMode").trim());
                session.setAttribute("bacUserID",request.getParameter("uBACUserID").toUpperCase().trim());
                session.setAttribute("userName",request.getParameter("uUserName").replace('%',' ').trim());
                session.setAttribute("userFunctCd",request.getParameter("uUserFunctCd").trim());
                session.setAttribute("supvsorID",request.getParameter("uSupvsorID").trim());
                session.setAttribute("cmpyID",request.getParameter("uCmpyID").trim());
                session.setAttribute("applID",request.getParameter("uApplId").trim());
                session.setAttribute("applName",request.getParameter("uApplName").trim());
                session.setAttribute("cmpyName",request.getParameter("uCmpyName").trim());
                session.setAttribute("region",request.getParameter("uCmpyID").trim());
                session.setAttribute("homeLink",home.trim());
                logger.debug("'" + (String)session.getAttribute("userName") + "'");
                logger.debug("'" + (String)session.getAttribute("cmpyName") + "'");
                logger.debug("'" + (String)session.getAttribute("region") + "'");
        	}
            while (enumer.hasMoreElements()){
            	parameterName = (String) enumer.nextElement();
            	if ("showSideMenu".equals(parameterName)){
            		showSideMenu = request.getParameter(parameterName);
            		session.setAttribute("showSideMenu",showSideMenu);
            		break;
            	}
            }
        	chain.doFilter(request, response);
        }	
	}

	public void destroy() {
	}

}

