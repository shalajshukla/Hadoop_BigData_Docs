/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.rpt;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.Set;

import org.apache.log4j.Logger;

import com.att.bac.rabc.DataTblDdlBean;
import com.att.bac.rabc.ExcelReport;
import com.att.bac.rabc.MyDate;
import com.att.bac.rabc.PresnId;
import com.att.bac.rabc.PresnIdDAO;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.StaticDataLoader;

/**
 * This class handles processing related to Next Data, Previous  
 * data buttons and also creating EXCEL report.
 * 
 * @author Nalina Pandiyan - NP5434
 */
public class AlertsLinkTemplateActionService {
	private static final Logger logger = Logger.getLogger(AlertsLinkTemplateActionService.class);
	public static final String DEFAULT_LABEL_RESOURCES = "com.att.bac.rabc.LabelResources";
	private static ResourceBundle labelProperties;
	
	private AlertReportParameters alertReportParameters = null;
	private Connection connection = null;
	private List failureList = null;

	List dataTblDdlList = null;
	List rabcPresnList = null;

	// The following MAP contains alert rule as key and AlertRuleInfoStruct as value. 
	private HashMap alertRuleMap = null;

	private final static String getProcTableName = " select distinct * from RABC_DATA_TBL_DDL " +
			"WHERE Alert_Proc_Tbl = (SELECT Presn_Tbl_Name FROM RABC_PRESN_ID WHERE EXEC_PRESN_SEQ_NUM = 1 AND Presn_ID = {0})";
	
	private final static String qryNextPreviousDate = "SELECT {0} AS qStartDate from {1} {2} {3} {4}";
	private static final String rabcPresnSQL = "select distinct * from RABC_PRESN_ID where Presn_id in ({0})";
	
	private static final int PREVIOUS_BUTTON = 1;
	private static final int NEXT_BUTTON = 2;
	private static final String PAGE_11 = "RABCPSF00011";
	private static final String PAGE_12 = "RABCPSF00012";
	private static final String PAGE_14 = "RABCPSF00014";

	/**
	 * This method is used as a template - use to configure the label resources properties file.
	 */
	public AlertsLinkTemplateActionService() {
		try {
			labelProperties = ResourceBundle.getBundle(DEFAULT_LABEL_RESOURCES);
		} catch (MissingResourceException e) {
			logger.error("Unable to configure properties file. Exception details: " + e.getMessage(), e);
		}		
	}

	/**
	 * This is a method to get AlertsLinkTemplateActionService and returns the AlertsLinkTemplateActionService.
	 * 
	 * @return AlertsLinkTemplateActionService
	 */
	public static AlertsLinkTemplateActionService getAlertsLinkTemplateActionService() {
		return new AlertsLinkTemplateActionService();
	}

	/**
	 * @param alertReportParameters The alertReportParameters to set.
	 */
	public void setAlertReportParameters(AlertReportParameters alertReportParameters) {
		this.alertReportParameters = alertReportParameters;
	}

	/**
	 * @param connection The connection to set.
	 */
	public void setConnection(Connection connection) {
		this.connection = connection;
	}
	
	/**
	 * @param failureList The failureList to set.
	 */
	public void setFailureList(List failureList) {
		this.failureList = failureList;
	}

	/**
	 * @param alertRuleMap The alertRuleMap to set.
	 */
	public void setAlertRuleMap(HashMap alertRuleMap) {
		this.alertRuleMap = alertRuleMap;
	}

	/**
	 * This is a method to get the label for the passed key.
	 * 
	 * @param key
	 * @return String
	 */
	public static String getLabel(String key) {
		try {
			return labelProperties.getString(key);
		} catch (MissingResourceException e) {
			logger.error("Unable to configure properties file. Exception details: " + e.getMessage(), e);
			return null;
		}
	}
	
	/**
	 * This method prepares the excel report for the passed alertReportView and report.
	 * 
	 * @param alertReportView
	 * @param report
	 */
	public void prepareExcelReport(AlertReportView alertReportView, ExcelReport report) {
		int i,j,k;
		int nbrOfTables, size1, size2;
		AlertData alertData = null;
		AlertRow alertRow = null;
		AlertCell alertCell = null;
		List alertDataList = null;
		List tmpList1 = null;
		List tmpList2 = null;
		String tmpStr = null;
		
		try {
			// begin report
			report.addRaw("<html xmlns:x=urn:schemas-microsoft-com:office:excel>");
			report.addRaw("<head>");
			if (alertReportParameters.getWebPageId().equals(PAGE_11)) {
				report.addRaw("<title>RABC Plus Control Alert Details Report</title>");
			}
			if (alertReportParameters.getWebPageId().equals(PAGE_14)) {
				report.addRaw("<title>RABC Plus Control Alert Details Report</title>");
			}
			if (alertReportParameters.getWebPageId().equals(PAGE_12)) {
				report.addRaw("<title>RABC Plus Control Alert Details Report</title>");
			}
			report.addRaw("<style>.xl33{ mso-number-format:'\\##\\,\\##\\##0\\.00';}");
			report.addRaw(" @page{margin:.5in .25in .5in .25in;mso-header-margin:.5in;mso-footer-margin:.5in;mso-page-orientation:landscape;} table{color:black;font-family:Arial} </style>");
			report.addRaw("</head>");
			report.addRaw("<body>");
			report.addRaw("<font face=Arial>");
			
			//add headers
			report.addRaw("<table width=100% cellpadding=0 cellspacing=0>");
			report.addRaw("<tr bgColor=White>");
			report.addRaw("<td valign=middle nowrap><font size=+2 color=navy><b>" + alertReportParameters.getHeader1() +" </b></font></td>");
			report.addRaw("</tr>");
			report.addRaw("<tr bgColor=White>");
			report.addRaw("<td valign=middle nowrap><font size=+1 color=navy><b>" + alertReportParameters.getHeader2() +" </b></font></td>"); 
			report.addRaw("</tr>");
			report.addRaw("<tr bgColor=White>");
			report.addRaw("<td valign=middle align=left nowrap><font size=+1 color=navy><b>" + alertReportParameters.getHeader3() +" </b></font></td>"); 
			report.addRaw("</tr>");
			if ("WE".equalsIgnoreCase(alertReportParameters.getRegion()) || "C2".equalsIgnoreCase(alertReportParameters.getRegion())) {
				report.addRaw("<tr bgColor=White>");
				report.addRaw("<td valign=middle align=left nowrap><font size=+1 color=navy><b>Cycle(s):" + alertReportParameters.getCycles() +" </b></font></td>"); 
				report.addRaw("</tr>");
				report.addRaw("<tr bgColor=White>");
				report.addRaw("<td>&nbsp;</td>"); 
				report.addRaw("</tr>");
			}else {
				report.addRaw("<tr bgColor=White>");
				report.addRaw("<td>&nbsp;</td>"); 
				report.addRaw("</tr>");
			}
			report.addRaw("</table>");
			report.flush();
			
			//Add selected criterias
			report.addRaw("<table width=100% cellpadding=0 cellspacing=0>");
			report.addRaw("<tr bgColor=White>");
			report.addRaw("<td valign=middle nowrap><b> Report Criteria: </b></td>");
			report.addRaw("</tr>");
			String region = alertReportParameters.getRegion();
			if ((alertReportParameters.getDivisionName() != null) && !(alertReportParameters.getDivisionName().equals(""))) {
				report.addRaw("<tr bgColor=White>");
				report.addRaw("<td valign=middle align=left nowrap><b> Division: </b></td>");
				if (alertReportParameters.getDivisionName().equals("ALL")) {
					List divisionList = alertReportParameters.getDivisionList();
					int size = 0;
					if (divisionList != null) {
						size = divisionList.size();
					}
					String divisionListString = "";
					for (i=1; i<size; i++) {
						if (i == size-1) {
							divisionListString += ((AlertReportDivision) divisionList.get(i)).getDivisionName() + " (" + StaticDataLoader.getDivisionDesc(region, ((AlertReportDivision) divisionList.get(i)).getDivisionName()) + ")";
						} else {
							divisionListString += ((AlertReportDivision) divisionList.get(i)).getDivisionName() + " (" + StaticDataLoader.getDivisionDesc(region, ((AlertReportDivision) divisionList.get(i)).getDivisionName()) + "), ";
						}
					}
					report.addRaw("<td valign=middle align=left nowrap>" + divisionListString + "</td>");
				} else {
					report.addRaw("<td valign=middle align=left nowrap>" + alertReportParameters.getDivisionName() + " (" + StaticDataLoader.getDivisionDesc(region, alertReportParameters.getDivisionName()) + ")</td>");
				}
				report.addRaw("</tr>");
			}
			if ((alertReportParameters.getKey2Label() != null) && !(alertReportParameters.getKey2Label().equals(""))
					&& (alertReportParameters.getKeysAt(1) != null) && !(alertReportParameters.getKeysAt(1).equals(""))) {
				report.addRaw("<tr bgColor=White>");
				report.addRaw("<td valign=middle align=left nowrap><b>" + alertReportParameters.getKey2Label() + ":</b></td>");
				report.addRaw("<td valign=middle align=left nowrap style=mso-number-format:\\@>" + alertReportParameters.getKeysAt(1) + "</td>");
				report.addRaw("</tr>");
			}
			/*
			 * key3 as criteria --- Added to filter the page 11 and 14 on key3 (phase II change)
			 */
			if ((alertReportParameters.getKey3Label() != null) && !(alertReportParameters.getKey3Label().equals(""))
					&& (alertReportParameters.getKeysAt(2) != null) && !(alertReportParameters.getKeysAt(2).equals(""))) {
				report.addRaw("<tr bgColor=White>");
				report.addRaw("<td valign=middle align=left nowrap><b>" + alertReportParameters.getKey3Label() + ":</b></td>");
				report.addRaw("<td valign=middle align=left nowrap style=mso-number-format:\\@>" + alertReportParameters.getKeysAt(2) + "</td>");
				report.addRaw("</tr>");
			}
			if ((alertReportParameters.getAlertItem() != null) && !(alertReportParameters.getAlertItem().equals("0"))) {
				report.addRaw("<tr bgColor=White>");
				report.addRaw("<td valign=middle align=left nowrap><b> Alert Item: </b></td>");
				report.addRaw("<td valign=middle align=left nowrap>" + alertReportParameters.getAlertItem() + "</td>");
				report.addRaw("</tr>");
			}
			if (alertReportParameters.getWebPageId().equals(PAGE_11)) {
				if ((alertReportParameters.getAlertTimeInd() != null) && !(alertReportParameters.getAlertTimeInd().equals("0"))) {
					report.addRaw("<tr bgColor=White>");
					report.addRaw("<td valign=middle align=left nowrap><b> Alert Rule Timing: </b></td>");
					if (alertReportParameters.getAlertTimeInd().equals("D")) {
						if (alertReportParameters.getAlertTimeValueWD().equals("-1")) {
							report.addRaw("<td valign=middle align=left nowrap> Call Day Week - All </td>");
						} else if (alertReportParameters.getAlertTimeValueWD().equals("1")) {
							report.addRaw("<td valign=middle align=left nowrap> Call Day Week - Sunday </td>");
						} else if (alertReportParameters.getAlertTimeValueWD().equals("2")) {
							report.addRaw("<td valign=middle align=left nowrap> Call Day Week - Monday </td>");
						} else if (alertReportParameters.getAlertTimeValueWD().equals("3")) {
							report.addRaw("<td valign=middle align=left nowrap> Call Day Week - Tuesday </td>");
						} else if (alertReportParameters.getAlertTimeValueWD().equals("4")) {
							report.addRaw("<td valign=middle align=left nowrap> Call Day Week - Wednesday </td>");
						} else if (alertReportParameters.getAlertTimeValueWD().equals("5")) {
							report.addRaw("<td valign=middle align=left nowrap> Call Day Week - Thursday </td>");
						} else if (alertReportParameters.getAlertTimeValueWD().equals("6")) {
							report.addRaw("<td valign=middle align=left nowrap> Call Day Week - Friday </td>");
						} else if (alertReportParameters.getAlertTimeValueWD().equals("7")) {
							report.addRaw("<td valign=middle align=left nowrap> Call Day Week - Saturday </td>");
						}
					} else if (alertReportParameters.getAlertTimeInd().equals("B")) {
						String timeIndLabel = "Bill Cycle";
						if ("MW".equals(alertReportParameters.getRegion())){
							timeIndLabel = "Process Group";
						}
						if (alertReportParameters.getAlertTimeValueBR().equals("-1")) {
							report.addRaw("<td valign=middle align=left nowrap> " + timeIndLabel + " - All </td>");
						} else {
							report.addRaw("<td valign=middle align=left nowrap> "+ timeIndLabel + " - " + alertReportParameters.getAlertTimeValueBR() + " </td>");
						}
					}
					report.addRaw("</tr>");
				}
			}
			if (alertReportParameters.getWebPageId().equals(PAGE_11)) {
				if ((alertReportParameters.getStartDate() != null) && !(alertReportParameters.getStartDate().equals("")) && (alertReportParameters.getEndDate() != null) && !(alertReportParameters.getEndDate().equals(""))) {
					report.addRaw("<tr bgColor=White>");
					report.addRaw("<td valign=middle align=left nowrap><b> File Dates: </b></td>");
					report.addRaw("<td valign=middle align=left nowrap>" + alertReportParameters.getStartDate() + " - " + alertReportParameters.getEndDate() + "</td>");
					report.addRaw("</tr>");
				}
			}
			report.addRaw("<tr bgColor=White>");
			report.addRaw("<td>&nbsp;</td>"); 
			report.addRaw("</tr>");
			report.addRaw("</table>");
			report.flush();
			
			nbrOfTables = alertReportView.getAlertDataList().size();
			alertDataList = alertReportView.getAlertDataList();
			nbrOfTables = alertDataList.size();
			if (alertReportParameters.getDataPresent().equals("Y")) {
				for (i=0; i<nbrOfTables; i++) {
					report.flush();
					report.addRaw("<table width=100% border=1 cellpadding=0 cellspacing=0>");
					alertData = (AlertData) alertDataList.get(i);
					report.addRaw("<tr bgColor=\"#0059B3\"></tr>");
					report.addRaw("<tr bgColor=White>");	
					if (!alertData.getKey1Value().equals("")) {
						report.addRaw("<td valign=middle class=selectLabel>&nbsp;");
						if ("Division".equalsIgnoreCase(alertData.getKey1Label().trim())) {
							report.addRaw(alertData.getKey1Label() + ":" + StaticDataLoader.getDivisionDesc(region, alertData.getKey1Value()));
						}else {
							report.addRaw(alertData.getKey1Label() + ":" + alertData.getKey1Value());
						}
						report.addRaw("</td></tr>");
					}
					if (!alertData.getAlertRule().equals("")) {
						report.addRaw("<td valign=middle class=selectLabel>&nbsp;");
						report.addRaw(alertData.getAlertRuleLabel() + ":" + alertData.getAlertRule());
						report.addRaw("</td></tr>");
					}
					tmpList1 = alertData.getColumnNames();
					size1 = tmpList1.size();
					report.addRaw("<tr bgColor=White>");
					for (j=0; j<size1; j++) {
						report.addRaw("<td align=center valign=top class=cellLabel>" + (String) tmpList1.get(j) + "</td>");
					}
					report.addRaw("</tr>");
					// add rows
					tmpList1 = alertData.getRows();
					size1 = tmpList1.size();
					for (j=0; j<size1; j++) {
						report.flush();
						alertRow = (AlertRow) tmpList1.get(j);
						report.addRaw("<tr bgcolor=" + alertRow.getRowColor() + ">");
						
						tmpList2 = alertRow.getColumnData();
						size2 = tmpList2.size();
						for (k=0; k<size2; k++) {
							alertCell = (AlertCell) tmpList2.get(k);
							report.addRaw("<td class=" + alertCell.getThisClass() + " title=" + alertCell.getTitle());
							report.addRaw(" bgcolor=" + alertCell.getBgColor() + " align=" + alertCell.getAlign());
							report.addRaw(" valign=" + alertCell.getValign()); 
							if (!alertCell.getNowrap().equals("")) report.addRaw(" " + alertCell.getNowrap());
							if ("T".equals(alertCell.getExcelDataType())){
								report.addRaw(" style=mso-number-format:\\@ >");
							}else {
								report.addRaw(" >");
							}
							
							report.addRaw(alertCell.getValue());
							if ((alertCell.getAddlnValue() != null) && (alertCell.getAddlnValue().length() != 0)) {
								report.addRaw("&nbsp;<span style='color:red'><b>" + alertCell.getAddlnValue() + "</b></span>");
							}
							report.addRaw("</td>");
						}
						report.addRaw("</tr>");
					}
					report.addRaw("</table>");
				}
			} else {
				report.addRaw("<table width=100% border=1 cellpadding=0 cellspacing=0>");
				report.addRaw("<tr bgColor=White><td>");
				report.addRaw("<table width=100% border=0 cellpadding=2 cellspacing=0><tr>");
				report.addRaw("<td colspan=2 valign=middle height=40 class=selectLabel>");
				report.addRaw("There is currently nothing to report for the following options selected:</td></tr>");

				report.addRaw("<tr><td width=25>&nbsp;</td><td>");
				report.addRaw("<table width=400 border=1 cellpadding=2 cellspacing=0 style=border: 1px solid #clr_DarkBlue#;<tr>");
				if (alertReportParameters.getCntrlPtCd().length() != 0) {
					report.addRaw("<td width=100 align=right class=formLabel>"+getLabel("alertReport.label.controlPoint") + ":</td>");
					report.addRaw("<td width=300 align=left class=cellText>" + alertReportParameters.getCntrlPtCd() + "</td></tr>");					
				} else {
					report.addRaw("<td width=100 align=right class=formLabel>"+getLabel("alertReport.label.alertRule") + ":</td>");
					report.addRaw("<td width=300 align=left class=cellText>" + alertReportParameters.getAlertRule() + "</td></tr>");
				}

				report.addRaw("<tr><td align=right class=formLabel>"+getLabel("alertReport.label.division")+":</td>");
				//TO add divisions
				tmpStr = alertReportParameters.getKey1s();
				if (tmpStr.length() == 0) {
					tmpStr = alertReportParameters.getDivisionName().replace('\'',' ');
				}
				report.addRaw("<td align=left class=cellText>" + tmpStr + "</td></tr>");				
				report.addRaw("<tr><td align=right class=formLabel>"+getLabel("alertReport.label.startDate")+":</td><td align=left class=cellText>" + alertReportParameters.getStartDate().toString() + "</td></tr>");
				report.addRaw("<tr><td align=right class=formLabel>"+getLabel("alertReport.label.endDate")+":</td><td align=left class=cellText>" + alertReportParameters.getEndDate().toString() + "</td></tr>");
				if (alertReportParameters.getFileSeqNum().intValue() != -1) {
					report.addRaw("<tr><td align=right class=formLabel>"+getLabel("alertReport.label.fileSeqNumber")+":</td><td align=left class=cellText>"+ alertReportParameters.getFileSeqNum().toString() +"</td></tr>");
				}
				report.addRaw("</table></td></tr></table></td></tr></table>");
			}
			report.addRaw("</font>");
			report.addRaw("</body>");
			report.addRaw("</html>");
			report.flush();
		} catch (IOException e) {
			logger.error(RABCMessages.getMessage("ERR_CREATE_ALERT_REPORT", null) + " Exception details: " + e.getMessage(), e);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CREATE_ALERT_REPORT", null) + " Exception details: " + e.getMessage(), e));		
		}
	}
}
