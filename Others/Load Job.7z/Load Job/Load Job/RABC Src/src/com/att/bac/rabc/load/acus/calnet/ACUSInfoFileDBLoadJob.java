/*
 * Module description: 
 * This module will insert rows into the RABC_ACUS_CIS_INFO table from the RABC.ACUS.CIS.INFO flat file. 
 *
 * Copyright 2007 ATT Knowledge Ventures. All rights reserved.
 *
 * Modification History:                                     
 * SBCUID		Date			Description                         	    	
 * ------		--------		-----------
 * KW2478		20070314		Initial version for EAP 286915
 * KW2478		20070412		Added new field acusInvoiceAdjAmount
 * KW2478		20070501		Changed insertInfoRecord method to use String for the fields that are int or double 
 * 								to allow insertion of nulls for the nullable table columns
 * KW2478		20070515		Changed the getFileId returned name to CIS.INFO to be consistent with the
 * 								RABC_FILE_MASH table 
 * PB3879		20070531		Added DIV_CD.  It will be assigned a constant value or "AC".
 * KW2478		20070606		Added code to pass the header date (procDate) from the super to insert into the 
 * 								DATA_CREATE_DATE on the RABC_ACUS_CIS_INFO table 
 */
package com.att.bac.rabc.load.acus.calnet;

import java.io.File;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Properties;

import com.att.carat.util.Email;
import com.att.carat.util.JDBCUtil;
//changes done for M168 by as635b
import com.att.carat.load.Application;
//import com.sbc.bac.load.Application;

/**
 * @author Kevin Woodside - kw2478
 *
 */
public class ACUSInfoFileDBLoadJob extends ACUSFileDBLoadJob {
	
	// prepared statement String for the Insert into the RABC_ACUS_CIS_INFO table
	private static final String INSERT_QUERY = "insert into RABC_ACUS_CIS_INFO (DATA_CREATE_DT, BP_BTN, " +
											   "ACUS_BILL_PAYER_ACCT, ACUS_INV_DT, PROV_NM, PROV_INV_DT," +
											   "PROV_BILL_RND, CIS_PROV_RECEIVED_AMT, CIS_PROV_PROCESSED_AMT," +
									   	 	   "AGY_ID, ACUS_ADMIN_FEE, ACUS_BTN_INV_AMT, ACUS_INV_CHARGES," +
									   	 	   "ACUS_INV_ADJ_AMT, DIVISION)" +
										 	   "values " + "(?, UPPER(?), UPPER(?), ?, UPPER(?), ?, ?, ?, ?, UPPER(?), ?, ?, ?, ?, ?)";

	private PreparedStatement insertDetail;
//	private static final int BATCH_SIZE = 5000;
//	private int infoRecordCounter = 0;
	private static final String DIV_CD = "AC";
	private static java.util.Date dataCreateDate;
//	private static final Date currentDt = new Date(new java.util.Date().getTime());
	private String emailAddress="";
	private String emailSubject="";
	ArrayList<String> duplicateRecord = null; 

	/* (non-Javadoc)
	 * @see com.sbc.bac.rabc.load.FilePatternLoadJob#configure(com.sbc.bac.load.Application, java.util.Properties)
	 */
	protected boolean configure(Application application, Properties configuration) {
        boolean success = super.configure(application, configuration);
        if(success){
	        //gets parameters' values from config file acusInfo.cfg
	        emailAddress = configuration.getProperty("status_to_addresses").trim();
	        emailSubject = configuration.getProperty("email_subject").trim();
	        
			if (emailAddress.equals("")){ 
				severe("Please specify status_to_addresses in acusInfo.cfg");
				return false;
			}
			if (emailSubject.equals("")){ 
				severe("Please specify email_subject in acusInfo.cfg");
				return false;
			}
        }
        return success;   
	}
	
	/**
	 * Inserts a row into the RABC_ACUS_CIS_INFO table using the InfoBean 
	 * 
	 * @param detail the AccountDetailBean to insert.
	 * @param procDate - contains the date from the header record to be inserted into DATA_CREATE_DATE.
	 * @return SUCCESS or ERROR
	 * @throws SQLException
	 * @throws ParseException 
	 */
		protected int insertInfoRecord(InfoBean detail, String procDate) throws SQLException, ParseException {
		try {
//			insertDetail.setDate(1, currentDt);
			DateFormat sdf = new SimpleDateFormat("MM-dd-yyyy");
			dataCreateDate	= sdf.parse(procDate);		
			insertDetail.setDate(1, new Date(dataCreateDate.getTime()));
			insertDetail.setString(2, detail.getBtn());					
			insertDetail.setString(3, detail.getBillPayerAccount() );	
			insertDetail.setDate(4, new Date (detail.getAcusInvoiceDate().getTime()));	
			insertDetail.setString(5, detail.getProviderName());		
	
			if (detail.getProviderInvoiceDate() == null)
			{
				insertDetail.setDate(6, null);
			}
			else
			{
				insertDetail.setDate(6, new Date (detail.getProviderInvoiceDate().getTime()));
			}
			
			insertDetail.setString(7, detail.getBillRound());			
			insertDetail.setString(8, detail.getProviderReceivedAmount());
			insertDetail.setString(9, detail.getProviderProcessedAmount());	
			insertDetail.setString(10, detail.getAgencyId());			
			insertDetail.setString(11, detail.getAdminFee());
			insertDetail.setString(12, detail.getBtnInvoiceAmount());
			insertDetail.setString(13, detail.getInvoiceCharge());
			insertDetail.setString(14, detail.getAcusInvAdjAmount());
			insertDetail.setString(15, DIV_CD);
			
			try{
				insertDetail.executeQuery();
			}
			catch(SQLException sqle){
				if(sqle.getErrorCode()==1){
					//add duplicate records to an arraylist
					duplicateRecord.add(detail.getBtn() + "|" + detail.getBillPayerAccount() + "|" + (new Date (detail.getAcusInvoiceDate().getTime())).toString() + "|" + detail.getProviderName());
				}
				else{
					throw sqle;
				}
			}
			// increment the lineCount to be used for comparison against the Trailer Record Count in superclass 
			lineCount++;
			return SUCCESS;
			
		} catch (SQLException e) {
			severe("insert into RABC_ACUS_CIS_INFO table failed with an SQLException "+e, e);
			throw e;
		}
	}
		
		/**
		 * Determine if the Input File is valid.  Create prepared statement for the Insert if the File is valid. 
		 * 
		 * @return true or false
		 * @throws SQLException
		 */

		protected boolean preprocessFile(File file) {

			boolean success = super.preprocessFile(file);

			if (!success) {
				return false;
			}
			try {
				duplicateRecord = new ArrayList<String>();
				//setup the preparedstatement for the table insert.
				info("preparing statement for INSERT_QUERY");
				insertDetail = connection.prepareStatement(INSERT_QUERY);
			} catch (SQLException e) {
				severe("prepareStatement for RABC_ACUS_CIS_INFO table failed with an SQLException "+e, e);
				return false;
			}
			return success;
		}
		
		/**
		 * Close the insertDetail preparedStatement. Return boolean to the superclass.
		 * 
		 * @return true or false
		 * @throws SQLException
		 */
		public boolean postprocessFile(File file, boolean success) {

			if (!success){
				return super.postprocessFile(file, success);
			}
			
			try {
  
				if(!duplicateRecord.isEmpty()){
					info("duplicate record found");
					String emailBody = "The following duplicate records found in file "
						+ file.getName() + ", and have been ignored :\r\n"
						+ "BTN | Bill Payer Account | ACUS Invoice Date | Prov. Name \r\n";
					for(String value : duplicateRecord) {
						emailBody += value + "\r\n";
					}
					//Send an e-mail with duplicate records to the specified email-id
					Email.sendEmail(emailAddress, emailSubject, emailBody);
				}
			} catch (Exception e) {
				severe("postprocessFile Send duplicate record mail Failed "+e, e);
				success = false;
			}finally{
				//close off the preparedstatement once done.
				info("closing prepared statement for insertDetail");
				JDBCUtil.closeStatement(insertDetail);
			}

			return super.postprocessFile(file, success);
		}	

	/**
	 * Handles the parsing of a line from the ACUS.CIS.INFO flat file.  
	 * 
	 * @param line - a String in the CIS Info Detail Record Layout.
	 * @param procDate - contains the date from the header record to be inserted into DATA_CREATE_DATE.
	 * @return SUCCESS or ERROR 
	 * @throws ParseException 
	 * @throws SQLException
	 */

		protected int processRecord(String line, String procDate) throws SQLException, ParseException {

			try {
				// parse the input CIS Info Detail record
				InfoBean detail = InfoBean.valueOf(line);
				return insertInfoRecord(detail, procDate);
			} catch (SQLException e) {
				severe("insert into RABC_ACUS_CIS_INFO table failed with an SQLException "+line, e);
				throw e;
			} catch (ParseException e) {
				severe("InfoBean failed due to ParseException "+line ,e);
				throw e;
			}
		}

	/**
	 * Returns the filename being processed.  
	 * 
	 * @return name of file being processed
	 */

		public String getFileId(){
		    	return "CIS.INFO";
		}

		    
}
