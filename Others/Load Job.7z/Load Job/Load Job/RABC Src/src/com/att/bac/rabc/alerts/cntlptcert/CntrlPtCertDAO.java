/*
 * Module description:
 * 
 * This is a DAO that will connect to the RABC_CNTRL_PT_CERT table for 
 * SELECT, INSERT, UPDATE and DELETE queries.
 * 
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 * 
 * Modification History:
 * SBCUID        Date            Description
 * ------        --------        -----------
 * VD3159        20060124        Initial Version for EAP 556010
 * 
*/
package com.att.bac.rabc.alerts.cntlptcert;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.carat.util.JDBCUtil;


/**
 * CntrlPtCertDAO performs SELECT, INSERT and UPDATE on RABC_CNTRL_PT_CERT table
 * For INSERT and UPDATE, no commit or rollback happens here.
 *
 */
public class CntrlPtCertDAO {
	private static final Logger logger = Logger.getLogger(CntrlPtCertDAO.class);

	/**
	 * Executes SELECT statement on RABC_CNTRL_PT_CERT table and returns
	 * CntrlPtCert objects in List. Exceptions if any are return in failures List.
	 */
	public List get(Connection conn, List failures, List args, String baseSQL) {
		List cntrlPtCertList = null;
		CntrlPtCert cntrlPtCert = null;
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		
		try
		{
			logger.info("Processing SELECT from RABC_CNTRL_PT_CERT table....");
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("CntrlPtCertDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			logger.debug("SQL - Execution complete.");
			
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage());
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return null;
		}finally {
			JDBCUtil.closeStatement(stmt);
		}
		
		if (rs == null) {
			// result set null
			logger.info("Found zero records from RABC_CNTRL_PT_CERT table....");
			return null;
		}
		
		logger.info("Preparing CntrlPtCert objects .....");
		cntrlPtCertList = new ArrayList();
		try
		{
			while (rs.next()) {
				cntrlPtCertList.add(buildCntrlPtCert(rs));
			}
			
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage());
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return null;
		}finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closeStatement(stmt);
		}
		
		return cntrlPtCertList;
	}

	/**
	 * Build CntrlPtCert objects from current record and returns it
	 *
	 */
	private CntrlPtCert buildCntrlPtCert(ResultSet rs) throws SQLException {
		CntrlPtCert cntrlPtCert = new CntrlPtCert();
		
		cntrlPtCert.setCertNum(rs.getInt("CERT_NUM"));
		cntrlPtCert.setRunDate(rs.getDate("RUN_DATE"));
		cntrlPtCert.setDivision(rs.getString("DIVISION"));
		cntrlPtCert.setCntrlPtCode(rs.getString("CNTRL_PT_CODE"));
		cntrlPtCert.setCertInd(rs.getString("CERT_IND"));
		cntrlPtCert.setIssueInd(rs.getString("ISSUE_IND"));
		cntrlPtCert.setUserId(rs.getString("USER_ID"));
		cntrlPtCert.setIssueRevenueCr(rs.getInt("ISSUE_REVENUE_CR"));
		cntrlPtCert.setIssueRevenueDb(rs.getInt("ISSUE_REVENUE_DB"));
		cntrlPtCert.setIssueLostRevenue(rs.getInt("ISSUE_LOST_REVENUE"));
		cntrlPtCert.setTimeStamp(rs.getDate("TIME_STAMP"));
		return cntrlPtCert;
	}

	/**
	 * Executes INSERT, UPDATE or DELETE statement on RABC_CNTRL_PT_CERT table.
	 * Exceptions if any are return in failures List.
	 */
	public void executeUpdate(Connection conn, List failures, List args, String baseSQL) {
		int rowsUpdated = 0;
		Statement stmt = null;
		String sqlStmt = null;
		
		try
		{
			logger.info("Processing executeUpdate on RABC_CNTRL_PT_CERT table....");
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("CntrlPtCertDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rowsUpdated = stmt.executeUpdate(sqlStmt);
			logger.debug("SQL - Execution complete."+ String.valueOf(rowsUpdated) + "  rows updated");
			
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage());
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return;
		}finally {
			JDBCUtil.closeStatement(stmt);
		}
	}

	/**
	 * Closes statement and logger error if any as warning
	 *
	 */
	private void closeStatement(Statement stmt) {
		try
		{
			if (stmt != null) {
				stmt.close();
			}
		} catch(SQLException sx) {
			logger.warn("CntrlPtCertDAO - Closing SQL Statement results in this error: " + sx.getMessage());
		}
	}
}
