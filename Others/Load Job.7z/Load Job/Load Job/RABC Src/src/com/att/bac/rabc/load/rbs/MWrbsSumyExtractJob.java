package com.att.bac.rabc.load.rbs;

import java.net.UnknownHostException;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import com.att.bac.rabc.util.EmcisEventLogger;
import com.att.carat.util.Email;
import com.att.carat.util.JDBCUtil;
import com.att.carat.util.NetUtil;
import com.sbc.bac.rabc.load.CheckDB2Extract;
import com.sbc.bac.rabc.load.RabcLoadJobTrig;

/**
 * @author pt6471
 * 
 *   This job will extract DB2 table data into RABC_RBS_BLG_SUMY table by running query from RABC_DATA_EXTRCT_QUERY
 *   table. This table holds the extraction query .. Run is controlled by FILE ID. File ID for scheduled jobs are defined in 
 *   RABC_DATA_EXTRCT_SCHEDULE. which is the primary key  for table RABC_DATA_EXTRCT_QUERY .. 
 *
 */

public class MWrbsSumyExtractJob extends CheckDB2Extract{

	private PreparedStatement insertDB2Extracts = null;

	private static final long DAY_IN_MILLI_SEC = 86400*1000;

	private Date billDate;
	private String division, billRnd;
	
	protected boolean preprocess(){
		
		boolean success = super.preprocess();
		if(success){
			try {
				insertDB2Extracts = ORAconnection.prepareStatement(" INSERT INTO RABC_RBS_BLG_SUMY (RUN_DATE, DIVISION, " +
						"BILL_RND, OCN, BAL_DUE_AMT, PREV_BLG_AMT, CURR_CHRG_AMT, " +
						"PAYMENT_AMT, ADJ_AMT, LPC_AMT, RECUR_CHRG_AMT, " +
						"RECUR_CREDIT_AMT, NON_RECUR_CHRG_AMT, NON_RECUR_CREDIT_AMT, DSCT_AMT)" +
						"VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ");
				
			} catch (SQLException e) {
				severe("Exception while creating statements "+e, e );
				success = false;
			}
		}
			return success;
	}
	

	protected boolean action() {

		ResultSet scheduledJobs = null;
		boolean status = true;
		boolean returnStatus = true;
		try {
			
			// get check SQL and extract SQL for given file ID.  
			getExtractQry.setString(1,getFile_id());
			scheduledJobs = getExtractQry.executeQuery();
			if (!scheduledJobs.next())
				return false;

			String sourceTable = scheduledJobs.getString("EXTRCT_TO_TBL");
			String checkSQL = scheduledJobs.getString("CHECK_QUERY");
			String insertSQL = scheduledJobs.getString("EXTRACT_QUERY");
			
			// check if schedule job is ready to run.  If YES, then extract the schedule and loop thru per division
			if (isScheduledRun()) {
				setScheduledRun(false);
				
				getExtractSchedule.setString(1,getFile_id());
				scheduledJobs = getExtractSchedule.executeQuery();
				
				while (scheduledJobs.next()){
					// Why to convert between DIVISION & STATE? 	
					// Because, division ( like I for INdiana ) used in RABC, state Like IN is used in MVS .. Since 
					// this conversion don't match with DIVISION table need to keep a hash map ref.
					
					division = scheduledJobs.getString("DIVISION");
					String state = DIVISION_MAP.get(scheduledJobs.getString("DIVISION")).toString();
					billRnd = scheduledJobs.getString("BILL_RND");
					if (billRnd.length() == 1)
						billRnd = "0"+billRnd;
					//billDate = scheduledJobs.getDate("BILL_RND_DT"); 
					billDate = getBillroundDate(scheduledJobs.getDate("BILL_RND_DT"), billRnd);
					 
					String extractTimeInd = scheduledJobs.getString("EXTRCT_TIME_IND");
					Date procDt = scheduledJobs.getDate("PROC_DT");
					boolean skip_load = false;
					
					status = db2TableCheck(state, billDate,billRnd, checkSQL);
					
					status = status && processScheduledExtract(state, billDate, billRnd, sourceTable, insertSQL);
					
					if (System.currentTimeMillis() - billDate.getTime() > 5 * DAY_IN_MILLI_SEC && !status){
						updateSchedule(extractTimeInd, procDt, billRnd, division);
						Email.sendEmail(notify_users, "DB2 extraction SKIPPED for DIVISION >> " + division + " for FILEID - " + getFile_id() , " Please Investigate MW ACIS/CAMPS contact -- " + billDate.toString());
						info ("DB2 extraction SKIPPED for DIVISION >> " + division + " for FILEID - " + getFile_id());
						sendAlertMessage(getFile_id(), division, billDate,"skipping DB2 data load to TBL: RABC_RBS_BLG_SUMY");
						skip_load = true;
					}
					else 
						status =  status && updateSchedule(extractTimeInd, procDt, billRnd, division);
				
					if (skip_load)
						insertExtractCompLog(division, billDate, billRnd, getFile_id(), sourceTable, skip_load);
					else 
						status = status && insertExtractCompLog(division, billDate, billRnd, getFile_id(), sourceTable, skip_load);
					
					status = status && insertTrigger();
					
				}
				
			}

			// check if for the given FILEID any of the loads need to rerun to extract data .. 
			if (isRerunInd()){
				setRerunInd(false);
				
				getRerunLog.setString(1,getFile_id());
				scheduledJobs = getRerunLog.executeQuery();
				
				while(scheduledJobs.next()){
					division = scheduledJobs.getString("DIVISION");
					String state = DIVISION_MAP.get(scheduledJobs.getString("DIVISION")).toString();
					billDate = scheduledJobs.getDate("RUN_DATE"); 
					billRnd = scheduledJobs.getString("BILL_RND");
					status = db2TableCheck(state, billDate,billRnd, checkSQL);
					status = status && deleteRerunData(division, billDate, billRnd, sourceTable);
					status = status && processScheduledExtract(state, billDate, billRnd, sourceTable, insertSQL);
					status = status && insertTrigger();
					//reset rerun INDICATOR to NULL once rerun completed.
					if (status) {
						updateRerunLog.setString(1, getFile_id());
						updateRerunLog.setDate(2,billDate);
						updateRerunLog.setString(3, division);
						updateRerunLog.executeUpdate();
					}
				}
				
			}
			
		} catch (SQLException e) {
			severe("Exception while creating statements "+e, e );
			returnStatus = false;
		} catch (ParseException e) {
			e.printStackTrace();
		}finally {
			JDBCUtil.closeResultSet(scheduledJobs);
		}
		
		return returnStatus;
	}

private boolean db2TableCheck(String state, Date billDate,String billRnd, String checkSQL){
		
		boolean status = false;
		ResultSet db2Check = null;
		PreparedStatement checkForDB2Data = null;
		
		try {
			checkForDB2Data = DB2connection.prepareStatement(checkSQL);
			
			checkForDB2Data.setDate(1,billDate);
			checkForDB2Data.setString(2,state);
			checkForDB2Data.setString(3,billRnd);
			checkForDB2Data.setDate(4,billDate);
			checkForDB2Data.setString(5,state);
			checkForDB2Data.setString(6,billRnd);
			checkForDB2Data.setDate(7,billDate);
			checkForDB2Data.setString(8,state);
			checkForDB2Data.setString(9,billRnd);
			
			db2Check = checkForDB2Data.executeQuery();

			// check for DB2 table(s) has any data loaded with RUN_DATE data..
			
			// removed the check for CNT2 ( table:GOBBTAS3 )which is a DISCOUNT info. Which may or may not have values in it  
			if (db2Check.next())
				//if (db2Check.getInt("CNT1") > 0 && db2Check.getInt("CNT2") > 0 && db2Check.getInt("CNT3") > 0) {
				if (db2Check.getInt("CNT1") > 0 && db2Check.getInt("CNT3") > 0) {
					status = true;
				}
		}  catch (SQLException e) {
			severe("Exception while processing ResultSet "+e, e );
			return false;
		}finally {
			JDBCUtil.closeResultSet(db2Check);
			JDBCUtil.closePreparedStatement(checkForDB2Data);
		}
		
		return status;
	}

	private boolean processScheduledExtract(String state, Date billDate, String billRnd, String sourceTable, String insertSQL){
		
	
		ResultSet db2ExtractedData = null;
		PreparedStatement db2Extract = null;
		
		try {
			// db2Extract = DB2connection.prepareStatement(config.getProperty(sourceTable));
			db2Extract = DB2connection.prepareStatement(insertSQL);
			db2Extract.setDate(1,billDate);
			db2Extract.setString(2,state);
			db2Extract.setString(3,billRnd);
			db2Extract.setDate(4,billDate);
			db2Extract.setString(5,state);
			db2Extract.setString(6,billRnd);
			db2Extract.setDate(7,billDate);
			db2Extract.setString(8,state);
			db2Extract.setString(9,billRnd);
			
			db2ExtractedData = db2Extract.executeQuery();
			
			int recordCnt = 0;
			String ocn = null;
			String prevOcn = null;
			int RECUR_CHRG_AMT = 8;
			int RECUR_CREDIT_AMT = 12;
			int NON_RECUR_CHRG_AMT =26;
			int NON_RECUR_CREDIT_AMT = 28;
			
			MWrbsSumyData rbsData = new MWrbsSumyData();
			
			while (db2ExtractedData.next()){
				recordCnt++;

				ocn = db2ExtractedData.getString("OCN");
				
				if (prevOcn == null){
					prevOcn = ocn;
					rbsData.setBillDate(db2ExtractedData.getDate("BILL_DATE"));
					rbsData.setStateId(DIVISION_MAP.get(db2ExtractedData.getString("STATE_ID")).toString());
					rbsData.setProcessGroup(Integer.parseInt(db2ExtractedData.getString("PG")));
					rbsData.setBalanceDueAmt(db2ExtractedData.getDouble("BAL_DUE_AMT"));
					rbsData.setPrevBillingAmt(db2ExtractedData.getDouble("PREV_BLG_AMT"));
					rbsData.setCurrChargeAmt(db2ExtractedData.getDouble("CURR_CHRG_AMT"));
					rbsData.setPaymentAmt(db2ExtractedData.getDouble("PAYMENT_AMT"));
					rbsData.setAdjAmt(db2ExtractedData.getDouble("ADJ_AMT"));
					rbsData.setLatePaymentAmt(db2ExtractedData.getDouble("LPC_AMT"));
					rbsData.setDiscountAmt(db2ExtractedData.getDouble("DSCT_AMT"));
				}
				else if (!prevOcn.equals(ocn))
				{
					insertDB2Extracts.setDate(1,rbsData.getBillDate());
					insertDB2Extracts.setString(2,rbsData.getStateId());
					insertDB2Extracts.setInt(3,rbsData.getProcessGroup());
					insertDB2Extracts.setString(4,prevOcn);
					insertDB2Extracts.setDouble(5,rbsData.getBalanceDueAmt());
					insertDB2Extracts.setDouble(6,rbsData.getPrevBillingAmt());
					insertDB2Extracts.setDouble(7,rbsData.getCurrChargeAmt());
					insertDB2Extracts.setDouble(8,rbsData.getPaymentAmt());
					insertDB2Extracts.setDouble(9,rbsData.getAdjAmt());
					insertDB2Extracts.setDouble(10,rbsData.getLatePaymentAmt());
					insertDB2Extracts.setDouble(15,rbsData.getDiscountAmt());

					insertDB2Extracts.setDouble(11,rbsData.getBilled_amt(RECUR_CHRG_AMT)); //  
					insertDB2Extracts.setDouble(12,rbsData.getBilled_amt(RECUR_CREDIT_AMT));
					insertDB2Extracts.setDouble(13,rbsData.getBilled_amt(NON_RECUR_CHRG_AMT));
					insertDB2Extracts.setDouble(14,rbsData.getBilled_amt(NON_RECUR_CREDIT_AMT));
					insertDB2Extracts.addBatch();
					
					if (recordCnt % 1000 == 0) {
						insertDB2Extracts.executeBatch();
					}
					
					prevOcn = ocn;
					rbsData = new MWrbsSumyData();
					rbsData.setBillDate(db2ExtractedData.getDate("BILL_DATE"));
					rbsData.setStateId(DIVISION_MAP.get(db2ExtractedData.getString("STATE_ID")).toString());
					rbsData.setProcessGroup(Integer.parseInt(db2ExtractedData.getString("PG")));
					rbsData.setBalanceDueAmt(db2ExtractedData.getDouble("BAL_DUE_AMT"));
					rbsData.setPrevBillingAmt(db2ExtractedData.getDouble("PREV_BLG_AMT"));
					rbsData.setCurrChargeAmt(db2ExtractedData.getDouble("CURR_CHRG_AMT"));
					rbsData.setPaymentAmt(db2ExtractedData.getDouble("PAYMENT_AMT"));
					rbsData.setAdjAmt(db2ExtractedData.getDouble("ADJ_AMT"));
					rbsData.setLatePaymentAmt(db2ExtractedData.getDouble("LPC_AMT"));
					rbsData.setDiscountAmt(db2ExtractedData.getDouble("DSCT_AMT"));
				} 
					rbsData.setBilled_amt(db2ExtractedData.getInt("OCC_CATEGORY"), db2ExtractedData.getDouble("BILLED_AMT"));
			}

			if (prevOcn != null){
				
				insertDB2Extracts.setDate(1,rbsData.getBillDate());
				insertDB2Extracts.setString(2,rbsData.getStateId());
				insertDB2Extracts.setInt(3,rbsData.getProcessGroup());
				insertDB2Extracts.setString(4,prevOcn);
				insertDB2Extracts.setDouble(5,rbsData.getBalanceDueAmt());
				insertDB2Extracts.setDouble(6,rbsData.getPrevBillingAmt());
				insertDB2Extracts.setDouble(7,rbsData.getCurrChargeAmt());
				insertDB2Extracts.setDouble(8,rbsData.getPaymentAmt());
				insertDB2Extracts.setDouble(9,rbsData.getAdjAmt());
				insertDB2Extracts.setDouble(10,rbsData.getLatePaymentAmt());
				insertDB2Extracts.setDouble(15,rbsData.getDiscountAmt());
				insertDB2Extracts.setDouble(11,rbsData.getBilled_amt(RECUR_CHRG_AMT)); //  
				insertDB2Extracts.setDouble(12,rbsData.getBilled_amt(RECUR_CREDIT_AMT));
				insertDB2Extracts.setDouble(13,rbsData.getBilled_amt(NON_RECUR_CHRG_AMT));
				insertDB2Extracts.setDouble(14,rbsData.getBilled_amt(NON_RECUR_CREDIT_AMT));
				insertDB2Extracts.addBatch();
				
			}
			
			if (recordCnt > 0)
				insertDB2Extracts.executeBatch();
			
			info (" number of records processed on: " + billDate.toString() + " for table - " + sourceTable + " - for STATE << " + state + " >> " + recordCnt);
			
		} catch (SQLException e) {
			severe("Exception while processing ResultSet "+e, e );
			return false;
		}finally {
			JDBCUtil.closeResultSet(db2ExtractedData);
			JDBCUtil.closePreparedStatement(db2Extract);
		}
		
		return true;		
		
	}
	
	// insert Trigger to RABC_TRIG table.
	private boolean insertTrigger() {
		DateFormat df = new SimpleDateFormat("MMddyyyy");
		String run_date = df.format(billDate);
		SimpleDateFormat sdf_for_Time = new SimpleDateFormat("HHmmss");
		SimpleDateFormat sdf_for_Date = new SimpleDateFormat("yyyyDDD");
		
		String file_name = getFile_id() + ".D" +  sdf_for_Date.format(new java.util.Date().getTime()) + 
			".T" + sdf_for_Time.format(new java.util.Date().getTime()) + ".TXT"; 
				
		if(!RabcLoadJobTrig.insertTrigger(ORAconnection, file_name, getFile_id(), division, run_date, null, billRnd))
			return false;
		 
		return true;
	
	}
	
	protected boolean postprocess(boolean success) {
		// close all preparedStatements ..
		JDBCUtil.closePreparedStatement(insertDB2Extracts);
		
		try{
			//Log the file information to EMCIS_EVENT_LOG and EMCIS_EVENT_LOG_DETAIL
			EmcisEventLogger emcisLogger = new EmcisEventLogger();
			String event_id = "RABC_RBSBSUMY_MW";
            String host = NetUtil.getLocalHostName();
            String hostIP = NetUtil.getLocalIpAddress();
			int sequence = emcisLogger.getEMCISSequence(ORAconnection);
			emcisLogger.insertEventLog(ORAconnection, sequence, event_id, billDate, host, hostIP);
			emcisLogger.insertEventLogDetail(ORAconnection, sequence, "DB", "RBS-"+new java.sql.Date(new java.util.Date().getTime()));
		}catch (UnknownHostException e) {
            severe("Error getting EMCIS host information ", e);
        }
		success = super.postprocess(success);
		return success;
	}
	
}
