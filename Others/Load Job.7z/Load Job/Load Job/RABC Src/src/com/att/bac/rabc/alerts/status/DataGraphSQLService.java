/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.alerts.status;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.att.bac.rabc.DataTblDdlBean;
import com.att.bac.rabc.MyDate;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.StaticDataLoader;
import com.att.bac.rabc.admin.alert.rule.AlertProcDAO;

/**
 * This is a sql service class to execute the sql queries pertaining to the data graph and to 
 * return the result to the service class.
 * 
 * @author Shailesh Hemdev - SH8512
 */
public class DataGraphSQLService extends GraphSQLService {
	private static final Logger logger = Logger.getLogger(DataGraphSQLService.class);
	private static final String RABC_EXTRCT_SUMY_DATA = "RABC_EXTRCT_SUMY_DATA";
	private static final String RABC_CALC_ALERT_DATA = "RABC_CALC_ALERT_DATA";
	private static final String RABC_ALERT_HIST = "RABC_ALERT_HIST";
	
	/*
	 * Variables to represent the sql statements.
	 */
	private static final String qrySumExtrData_1a = "Select sum({0}) as sum_extrct_data {1} " 
												+ " from rabc_extrct_sumy_data where parti_ref_id = {2} {3} AND PRESN_CD IN ('A', 'B') " 
												+ " {4} ";
	private static final String qrySumExtrData_1b = "Select {0} as sum_extrct_data, sum({1}) as sum_total_data {2} " 
												+ " from rabc_extrct_sumy_data where parti_ref_id = {3} {4} " 
												+ " {5} ";
	
	private static final String qrySumExtrData_2 = "Select sum({0}) as sum_extrct_data {1} "
												+ " from rabc_extrct_sumy_data where parti_ref_id = {3} {4} AND PRESN_CD IN ('A', 'B') "
												+ " {5} ";
	
	private static final String qryAlertProcTbl = "SELECT ALERT_RULE, ALERT_TYPE, ALERT_ITEM_DDL_NAME, ALERT_ITEM_DDL_DATA, " 
												+ "ALERT_ITEM_AVG_NAME, ALERT_PROC_TBL, ALERT_PROC_AVG_TBL, ALERT_CREATE_IND, ALERT_MSG_SUPP_DATA_IND, " 
												+ "ALERT_THRSHLD_DFLT_IND, ALERT_CALC_NUM, ALERT_TBL_SEL_NUM, PARTI_REF_ID FROM RABC_ALERT_PROC " 
												+ "WHERE ALERT_RULE = ''{0}'' and	rownum = 1";
	
	
	private static final String qrySumExtrData_3 = "Select sum({0}) as sum_extrct_data {1} "
												+ " from {2} where {3} {4} ";
	
	private static final String qrySumExtrData_4 = qrySumExtrData_3;
	private static final String qrySumExtrData_5 = qrySumExtrData_3;
	private static final String qrySumExtrData_6 = qrySumExtrData_3;
	
	private static final String qryRightSideButtons = "SELECT ALERT_ITEM_EXTRCT_TBL FROM RABC_TRACK_FILE_DTL WHERE ALERT_RULE = ''{0}'' ORDER BY ALERT_ITEM_ORD";
		
	private boolean isProcDateDate = true;
	private boolean isAlertTrendTime = true;
	
	/**
	 * Constructor for the DataGraphSQLService class.
	 * 
	 * @param graphParameters
	 */
	public DataGraphSQLService(GraphParameters graphParameters) {
		super(graphParameters);
	}

	/**
	 * @return Returns the isProcDateDate.
	 */
	public boolean isProcDateDate() {
		return isProcDateDate;
	}
	/**
	 * @param isProcDateDate The isProcDateDate to set.
	 */
	public void setProcDateDate(boolean isProcDateDate) {
		this.isProcDateDate = isProcDateDate;
	}
	
	/**
	 * @return Returns the isAlertTrendTime.
	 */
	public boolean isAlertTrendTime() {
		return isAlertTrendTime;
	}
	/**
	 * @param isAlertTrendTime The isAlertTrendTime to set.
	 */
	public void setAlertTrendTime(boolean isAlertTrendTime) {
		this.isAlertTrendTime = isAlertTrendTime;
	}
	
	/**
	 * Method to return the list of arguments to execute the sql statement 
	 * to get the list of ExtrctSumyData objects. 
	 * This method will be invoked for the following condition:
	 * alertRule neq "" and data_extrct_ind eq "Y" and extrctDataLeftCt > 0.
	 * 
	 * @param selectString
	 * @param rightColumn
	 * @return List
	 */
	private List buildCondition1Arguments(String selectString, String rightColumn){
		List args = new ArrayList();
		StringBuffer selectClause = new StringBuffer();
		StringBuffer whereClause = new StringBuffer();
		StringBuffer groupByClause = new StringBuffer();

		args.add(selectString);
		args.add(rightColumn);
		/*
		 * Form the select clause & add it in the argument list
		 */
		if (this.getGraphParameters().getFileSeqNum()!=null){
			selectClause.append(",file_seq_num");
			this.setAlertTrendTime(false);
		} else if (this.getGraphParameters().getAlertTimeInd()!=null){
			if ("B".equals(this.getGraphParameters().getAlertTimeInd().trim()) || "AB".equals(this.getGraphParameters().getAlertTimeInd().trim())) {
				selectClause.append(",to_char(" + this.getGraphParameters().getExtractDateName() + ",'DD-MON-YY') proc_date");
				selectClause.append(",alert_trend_time ");
				this.setProcDateDate(false);
			}else if ("M".equals(this.getGraphParameters().getAlertTimeInd().trim())){
				selectClause.append(",to_char(" + this.getGraphParameters().getExtractDateName() + ",'MON-YY') proc_date");
				this.setProcDateDate(false);
				this.setAlertTrendTime(false);
			} else {
				selectClause.append("," + this.getGraphParameters().getExtractDateName());
				this.setAlertTrendTime(false);
			}
		} else {
			selectClause.append("," + this.getGraphParameters().getExtractDateName());
			this.setAlertTrendTime(false);
		}

		args.add(selectClause.toString());
		args.add(Integer.toString(this.getGraphParameters().getPartiRefId()));
		/*
		 * Form the where clause & add it in the argument list
		 */
		if (this.getGraphParameters().getStartDate()!=null){
			whereClause.append(" AND ");
			whereClause.append(this.getGraphParameters().getExtractDateName());
			whereClause.append(" >= to_date('");
			whereClause.append(this.getGraphParameters().getStartDate().toString());
			whereClause.append("','mm/dd/yyyy')");		
		}
		
		if (this.getGraphParameters().getProcDate()!=null){
			whereClause.append(" AND ");
			whereClause.append(this.getGraphParameters().getExtractDateName());
			whereClause.append(" <= to_date('");
			whereClause.append(this.getGraphParameters().getProcDate().toString());
			whereClause.append("','mm/dd/yyyy')");	
		}

		if ("B".equals(this.getGraphParameters().getAlertTimeInd()) || "D".equals(this.getGraphParameters().getAlertTimeInd())){
			if (this.getGraphParameters().getAlertTimeValue()==null){
				whereClause.append(" and alert_trend_time is null");
			}else {
				whereClause.append(" and alert_trend_time ='");
				whereClause.append(this.getGraphParameters().getAlertTimeValue());
				whereClause.append("'");
			}
		}
		
		if (this.getGraphParameters().getAlertItem()==null){
			whereClause.append(" and extrct_item is null");
		}else {
			whereClause.append(" and extrct_item ='");
			whereClause.append(this.getGraphParameters().getAlertItem());
			whereClause.append("'");
		}
		
		if (this.getGraphParameters().getKey1()!=null){
			whereClause.append(" and extrct_key1 = '");
			whereClause.append(this.getGraphParameters().getKey1());
			whereClause.append("'");
		}
		if (this.getGraphParameters().getKey2()!=null){
			whereClause.append(" and extrct_key2 = '");
			whereClause.append(this.getGraphParameters().getKey2());
			whereClause.append("'");
		}
		if (this.getGraphParameters().getKey3()!=null){
			whereClause.append(" and extrct_key3 = '");
			whereClause.append(this.getGraphParameters().getKey3());
			whereClause.append("'");
		}
		if (this.getGraphParameters().getKey4()!=null){
			whereClause.append(" and extrct_key4 = '");
			whereClause.append(this.getGraphParameters().getKey4());
			whereClause.append("'");
		}
		if (this.getGraphParameters().getKey5()!=null){
			whereClause.append(" and extrct_key5 = '");
			whereClause.append(this.getGraphParameters().getKey5());
			whereClause.append("'");
		}

		whereClause.append(" AND PRESN_CD IN ('A', 'B')");
		args.add(whereClause.toString());
		
		/*
		 * Form the group by clause & add it in the argument list
		 */
		if (this.getGraphParameters().getFileSeqNum()!=null){
			groupByClause.append(" group by file_seq_num order by file_seq_num  asc ");
		}else if (this.getGraphParameters().getAlertTimeInd()!=null){
			if ("B".equals(this.getGraphParameters().getAlertTimeInd().trim()) || "AB".equals(this.getGraphParameters().getAlertTimeInd().trim())) {
				groupByClause.append(" group by to_char(" + this.getGraphParameters().getExtractDateName() + ",'DD-MON-YY'), alert_trend_time ");
				groupByClause.append(" order by to_date(proc_date,'DD-MON-YY') asc, to_number(alert_trend_time) asc ");
			}else if ("M".equals(this.getGraphParameters().getAlertTimeInd().trim())){
				groupByClause.append(" group by to_char(" + this.getGraphParameters().getExtractDateName() + ",'MON-YY')");
				groupByClause.append(" order by to_date(proc_date,'MON-YY') asc ");
			}else {
				groupByClause.append(" group by " + this.getGraphParameters().getExtractDateName());
				groupByClause.append(" order by ");
				groupByClause.append(this.getGraphParameters().getExtractDateName());
				groupByClause.append(" asc ");
			}
		}else {
			groupByClause.append(" group by " + this.getGraphParameters().getExtractDateName());
			groupByClause.append(" order by ");
			groupByClause.append(this.getGraphParameters().getExtractDateName());
			groupByClause.append(" asc ");
		}

		args.add(groupByClause.toString());
		
		return args;
	}
	
	/**
	 * Method to return the list of arguments to execute the sql statement 
	 * to get the list of ExtrctSumyData objects. 
	 * This method will be invoked for the following condition:
	 * alertRule neq "" and data_extrct_ind eq "Y" and extrctDataLeftCt = 0.
	 * 
	 * @param selectString
	 * @param rightColumn
	 * @return List
	 */
	private List buildCondition2Arguments(String selectString, String rightColumn){
		List args = new ArrayList();
		StringBuffer selectClause = new StringBuffer();
		StringBuffer whereClause = new StringBuffer();
		StringBuffer groupByClause = new StringBuffer();
		
		args.add(selectString);
		/*
		 * Form the select clause & add it in the argument list
		 */
		if (this.getGraphParameters().getFileSeqNum()!=null){
			selectClause.append(",file_seq_num");
			this.setAlertTrendTime(false);
		} if ("B".equals(this.getGraphParameters().getAlertTimeInd().trim()) || "AB".equals(this.getGraphParameters().getAlertTimeInd().trim())) {
			selectClause.append(",to_char(" + this.getGraphParameters().getExtractDateName() + ",'DD-MON-YY') proc_date");
			selectClause.append(",alert_trend_time ");
			this.setProcDateDate(false);
		}else if ("M".equals(this.getGraphParameters().getAlertTimeInd().trim())){
			selectClause.append(",to_char(" + this.getGraphParameters().getExtractDateName() + ",'MON-YY') proc_date");
			this.setProcDateDate(false);
			this.setAlertTrendTime(false);
		} else {
			selectClause.append("," + this.getGraphParameters().getExtractDateName());
			this.setAlertTrendTime(false);
		}
		
		args.add(selectClause.toString());
		args.add(Integer.toString(this.getGraphParameters().getPartiRefId()));
		
		/*
		 * Form the where clause & add it in the argument list
		 */
		if (this.getGraphParameters().getStartDate()!=null){
			whereClause.append(" AND ");
			whereClause.append(this.getGraphParameters().getExtractDateName());
			whereClause.append(" >= to_date('");
			whereClause.append(this.getGraphParameters().getStartDate().toString());
			whereClause.append("','mm/dd/yyyy')");		
		}
		
		if (this.getGraphParameters().getProcDate()!=null){
			whereClause.append(" AND ");
			whereClause.append(this.getGraphParameters().getExtractDateName());
			whereClause.append(" <= to_date('");
			whereClause.append(this.getGraphParameters().getProcDate().toString());
			whereClause.append("','mm/dd/yyyy')");		
		}
		
		if (this.getGraphParameters().getAlertTimeInd()!=null){
			if ("B".equals(this.getGraphParameters().getAlertTimeInd()) || "D".equals(this.getGraphParameters().getAlertTimeInd())){
				if (this.getGraphParameters().getAlertTimeValue()==null){
					whereClause.append(" and alert_trend_time is null");
				}else {
					whereClause.append(" and alert_trend_time ='");
					whereClause.append(this.getGraphParameters().getAlertTimeValue());
					whereClause.append("'");
				}
			}
		}

		if (this.getGraphParameters().getAlertItem()==null){
			whereClause.append(" and extrct_item is null");
		}else {
			whereClause.append(" and extrct_item ='");
			whereClause.append(this.getGraphParameters().getAlertItem());
			whereClause.append("'");
		}
		
		if (this.getGraphParameters().getKey1()!=null){
			whereClause.append(" and extrct_key1 = '");
			whereClause.append(this.getGraphParameters().getKey1());
			whereClause.append("'");
		}
		if (this.getGraphParameters().getKey2()!=null){
			whereClause.append(" and extrct_key2 = '");
			whereClause.append(this.getGraphParameters().getKey2());
			whereClause.append("'");
		}
		if (this.getGraphParameters().getKey3()!=null){
			whereClause.append(" and extrct_key3 = '");
			whereClause.append(this.getGraphParameters().getKey3());
			whereClause.append("'");
		}
		if (this.getGraphParameters().getKey4()!=null){
			whereClause.append(" and extrct_key4 = '");
			whereClause.append(this.getGraphParameters().getKey4());
			whereClause.append("'");
		}
		if (this.getGraphParameters().getKey5()!=null){
			whereClause.append(" and extrct_key5 = '");
			whereClause.append(this.getGraphParameters().getKey5());
			whereClause.append("'");
		}
		
		args.add(whereClause.toString());
		
		/*
		 * Form the group by clause & add it in the argument list
		 */
		if (this.getGraphParameters().getFileSeqNum()!=null){
			groupByClause.append(" group by file_seq_num order by file_seq_num  asc ");
		}else if ("B".equals(this.getGraphParameters().getAlertTimeInd().trim()) || "AB".equals(this.getGraphParameters().getAlertTimeInd().trim())) {
			groupByClause.append(" group by to_char(" + this.getGraphParameters().getExtractDateName() + ",'DD-MON-YY'), alert_trend_time ");
			groupByClause.append(" order by to_date(proc_date,'DD-MON-YY') asc, to_number(alert_trend_time) asc ");
		}else if ("M".equals(this.getGraphParameters().getAlertTimeInd().trim())){
			groupByClause.append(" group by to_char(" + this.getGraphParameters().getExtractDateName() + ",'MON-YY')");
			groupByClause.append(" order by to_date(proc_date,'MON-YY') asc ");
		}else {
			groupByClause.append(" group by ");
			groupByClause.append(this.getGraphParameters().getExtractDateName());
			groupByClause.append(" order by ");
			groupByClause.append(this.getGraphParameters().getExtractDateName());
			groupByClause.append(" asc ");
		}
		
		args.add(groupByClause.toString());
		
		return args;
	}
	
	/**
	 * Method to return the list of arguments to execute the sql statement 
	 * to get the list of ExtrctSumyData objects. 
	 * This method will be invoked for the following condition:
	 * alertRule neq "" and data_extrct_ind eq "N" and
	 * (alertTimeInd = 'B' or 'AB' && dataTblDdlBean.getTblBillRndDdlMon()!=null 
	 * && dataTblDdlBean.getTblBillRndDdlYear()!=null).
	 * 
	 * @param selectString
	 * @param args1
	 * @param region
	 * @return List
	 */
	private List buildCondition3Arguments(String selectString, List args1, String region){
		List args = new ArrayList();
		StringBuffer selectClause = new StringBuffer();
		StringBuffer whereClause = new StringBuffer();
		StringBuffer groupByClause = new StringBuffer();
		
		String alertProcTbl = (String) args1.get(0);
		String alertItemDdlName = (String) args1.get(1);

		DataTblDdlBean dataTblDdlBean = qryDataColumn(alertProcTbl,this.getGraphParameters(),region);
		args.add(selectString);
		
		if (this.getGraphParameters().getFileSeqNum()!=null){
			if (RABC_EXTRCT_SUMY_DATA.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl()) || RABC_CALC_ALERT_DATA.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl()) || RABC_ALERT_HIST.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl())){
				selectClause.append(",file_seq_num");
			}else {
				selectClause.append(",Decode(seq_num,null,'no data',seq_num) file_seq_num");
			}
			this.setAlertTrendTime(false);
		} else if (!RABC_EXTRCT_SUMY_DATA.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl()) && !RABC_CALC_ALERT_DATA.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl()) && !RABC_ALERT_HIST.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl())){
			selectClause.append(",TO_CHAR(TO_DATE(TO_CHAR(" + dataTblDdlBean.getTblBillRndDdlMon() + ",'09')|| '-' || TO_CHAR(" + dataTblDdlBean.getTblBillRndDdlYear() + ",'9999'),'MM-YYYY'),'MON-YY') as proc_date ");
			this.setAlertTrendTime(false);
		} else if (dataTblDdlBean.getTblBillRndDdlMon()!=null && dataTblDdlBean.getTblBillRndDdlYear()!=null) {
			selectClause.append(",TO_CHAR(TO_DATE(TO_CHAR(" + dataTblDdlBean.getTblBillRndDdlMon() + ",'09')|| '-' || TO_CHAR(" + dataTblDdlBean.getTblBillRndDdlYear() + ",'9999'),'MM-YYYY'),'MON-YY') as proc_date ");
			this.setAlertTrendTime(false);
		}else if ("B".equals(this.getGraphParameters().getAlertTimeInd()) || "AB".equals(this.getGraphParameters().getAlertTimeInd())) {
			selectClause.append(",to_char(trunc(");
			selectClause.append(dataTblDdlBean.getTblProcDateDdlName());
			selectClause.append("),'DD-MON-YY') as proc_date ");
			selectClause.append(", alert_trend_time ");
		}else if ("M".equals(this.getGraphParameters().getAlertTimeInd())){
			selectClause.append(",to_char(trunc(");
			selectClause.append(dataTblDdlBean.getTblProcDateDdlName());
			selectClause.append("),'MON-YY') as proc_date ");
			this.setAlertTrendTime(false);
		} else {
			selectClause.append(",to_char(trunc(");
			selectClause.append(dataTblDdlBean.getTblProcDateDdlName());
			selectClause.append("),'DD-MON-YY') as proc_date ");
			this.setAlertTrendTime(false);
		}
		
		args.add(selectClause.toString());
		args.add(dataTblDdlBean.getAlertProcTbl());
		
		/*
		 * Form the where clause & add it in the argument list
		 */
		if (this.getGraphParameters().getStartDate()!=null){
			String whereStartDate = "to_char(" + dataTblDdlBean.getTblBillRndDdlMon() + ")||" + "'/01/'" + "|| to_char(" + dataTblDdlBean.getTblBillRndDdlYear() + ")";
			whereClause.append(" to_date(");
			whereClause.append(whereStartDate);
			whereClause.append(",'mm/dd/yyyy')");
			whereClause.append(" >= to_date('");
			whereClause.append(this.getGraphParameters().getStartDate().toString());
			whereClause.append("','mm/dd/yyyy')");		
			whereClause.append(" AND ");
			whereClause.append(" to_date(");
			whereClause.append(whereStartDate);
			whereClause.append(",'mm/dd/yyyy')");
			whereClause.append(" <= to_date('");
			whereClause.append(this.getGraphParameters().getProcDate().toString());
			whereClause.append("','mm/dd/yyyy') ");		
		} else {
			whereClause.append("to_char(");
			whereClause.append(dataTblDdlBean.getTblBillRndDdlMon());
			whereClause.append(") = to_char(to_date('");
			whereClause.append(this.getGraphParameters().getProcDate().toString());
			whereClause.append("','mm/dd/yyyy'),'MM')");
			whereClause.append(" AND to_char(");
			whereClause.append(dataTblDdlBean.getTblBillRndDdlYear());
			whereClause.append(") = to_char(to_date('");
			whereClause.append(this.getGraphParameters().getProcDate().toString());
			whereClause.append("','mm/dd/yyyy'),'YYYY')");
		}
		
		if (this.getGraphParameters().getKey1()!=null){
			whereClause.append(" and ");
			whereClause.append(dataTblDdlBean.getTblDdlKey1Name());
			whereClause.append("='");
			whereClause.append(this.getGraphParameters().getKey1());
			whereClause.append("' ");
		}
		if (this.getGraphParameters().getKey2()!=null){
			whereClause.append(" and ");
			whereClause.append(dataTblDdlBean.getTblDdlKey2Name());
			whereClause.append("='");
			whereClause.append(this.getGraphParameters().getKey2());
			whereClause.append("' ");
		}
		if (this.getGraphParameters().getKey3()!=null){
			whereClause.append(" and ");
			whereClause.append(dataTblDdlBean.getTblDdlKey3Name());
			whereClause.append("='");
			whereClause.append(this.getGraphParameters().getKey3());
			whereClause.append("' ");
		}
		if (this.getGraphParameters().getKey4()!=null){
			whereClause.append(" and ");
			whereClause.append(dataTblDdlBean.getTblDdlKey4Name());
			whereClause.append("='");
			whereClause.append(this.getGraphParameters().getKey4());
			whereClause.append("' ");
		}
		if (this.getGraphParameters().getKey5()!=null){
			whereClause.append(" and ");
			whereClause.append(dataTblDdlBean.getTblDdlKey5Name());
			whereClause.append("='");
			whereClause.append(this.getGraphParameters().getKey5());
			whereClause.append("' ");
		}
		
		if (this.getGraphParameters().getAlertItem()!=null){
			whereClause.append(" and ");
			whereClause.append(alertItemDdlName);
			whereClause.append("='");
			whereClause.append(this.getGraphParameters().getAlertItem());
			whereClause.append("' ");
		}
		
		if (dataTblDdlBean.getTblBillRndDdlName()!=null){
			whereClause.append(" and ");
			whereClause.append(dataTblDdlBean.getTblBillRndDdlName());
			whereClause.append("=");
			whereClause.append(this.getGraphParameters().getAlertTimeValue());
		}
		
		
		args.add(whereClause.toString());
		
		if (this.getGraphParameters().getFileSeqNum()!=null){
			if (RABC_EXTRCT_SUMY_DATA.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl()) || RABC_CALC_ALERT_DATA.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl()) || RABC_ALERT_HIST.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl())){
				groupByClause.append(" group by file_seq_num order by file_seq_num asc ");
			} else {
				groupByClause.append(" group by Decode(seq_num,null,'no data',seq_num) order by to_number(Decode(seq_num,null,'no data',seq_num)) asc ");
			}
		}else if (dataTblDdlBean.getTblBillRndDdlMon()!=null && dataTblDdlBean.getTblBillRndDdlYear()!=null) {
			groupByClause.append(" group by TO_CHAR(");
			groupByClause.append(dataTblDdlBean.getTblBillRndDdlMon());
			groupByClause.append(" ,'09')|| '-' || TO_CHAR(");
			groupByClause.append(dataTblDdlBean.getTblBillRndDdlYear());
			groupByClause.append(",'9999')");
			groupByClause.append(" order by to_date(proc_date, 'MM-YYYY') asc ");
		}else if ("B".equals(this.getGraphParameters().getAlertTimeInd()) || "AB".equals(this.getGraphParameters().getAlertTimeInd())) {
			groupByClause.append(" group by to_char(trunc(");
			groupByClause.append(dataTblDdlBean.getTblProcDateDdlName());
			groupByClause.append(" ), 'DD-MON-YY'), alert_trend_time ");
			groupByClause.append(" order by to_date(PROC_DATE,'DD-MON-YY')  asc, to_number(alert_trend_time) ");
		} else if ("M".equals(this.getGraphParameters().getAlertTimeInd())){
			groupByClause.append(" group by to_char(trunc(");
			groupByClause.append(dataTblDdlBean.getTblProcDateDdlName());
			groupByClause.append(" ), 'MON-YY')");
			groupByClause.append(" order by to_date(PROC_DATE,'MON-YY')  asc ");
		}else {
			groupByClause.append(" group by to_char(trunc(");
			groupByClause.append(dataTblDdlBean.getTblProcDateDdlName());
			groupByClause.append(" ), 'DD-MON-YY')");
			groupByClause.append(" order by to_date(proc_date,'DD-MON-YY') asc ");
		}
		
		args.add(groupByClause.toString());
		
		return args;
	}
	
	/**
	 * Method to return the list of arguments to execute the sql statement 
	 * to get the list of ExtrctSumyData objects. 
	 * This method will be invoked for the following condition:
	 * alertRule neq "" and data_extrct_ind eq "N" and
	 * !(alertTimeInd = 'B' or 'AB' && dataTblDdlBean.getTblBillRndDdlMon()!=null 
	 * && dataTblDdlBean.getTblBillRndDdlYear()!=null).
	 * 
	 * @param selectString
	 * @param args1
	 * @param region
	 * @return List
	 */
	private List buildCondition4Arguments(String selectString, List args1, String region){
		List args = new ArrayList();
		StringBuffer selectClause = new StringBuffer();
		StringBuffer whereClause = new StringBuffer();
		StringBuffer groupByClause = new StringBuffer();

		String alertProcTbl = (String) args1.get(0);
		String alertItemDdlName = (String) args1.get(1);

		DataTblDdlBean dataTblDdlBean = qryDataColumn(alertProcTbl,this.getGraphParameters(),region);
		args.add(selectString);
		
		if (this.getGraphParameters().getFileSeqNum()!=null){
			if (RABC_EXTRCT_SUMY_DATA.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl()) || RABC_CALC_ALERT_DATA.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl()) || RABC_ALERT_HIST.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl())){
				selectClause.append(",file_seq_num");
			}else {
				selectClause.append(",Decode(seq_num,null,'no data',seq_num) file_seq_num");
			}
			this.setAlertTrendTime(false);
		} else if (dataTblDdlBean.getTblBillRndDdlMon()!=null && dataTblDdlBean.getTblBillRndDdlYear()!=null) {
			selectClause.append(",TO_CHAR(TO_DATE(TO_CHAR(" + dataTblDdlBean.getTblBillRndDdlMon() + ",'09')|| '-' || TO_CHAR(" + dataTblDdlBean.getTblBillRndDdlYear() + ",'9999'),'MM-YYYY'),'MON-YY') as proc_date ");
			this.setAlertTrendTime(false);
		}else if ("B".equals(this.getGraphParameters().getAlertTimeInd()) || "AB".equals(this.getGraphParameters().getAlertTimeInd())) {
			selectClause.append(",to_char(trunc(");
			selectClause.append(dataTblDdlBean.getTblProcDateDdlName());
			selectClause.append("),'DD-MON-YY') as proc_date ");
			selectClause.append(", alert_trend_time ");
		}else if ("M".equals(this.getGraphParameters().getAlertTimeInd())){
			selectClause.append(",to_char(trunc(");
			selectClause.append(dataTblDdlBean.getTblProcDateDdlName());
			selectClause.append("),'MON-YY') as proc_date ");
			this.setAlertTrendTime(false);
		}else {
			selectClause.append(",to_char(");
			selectClause.append(dataTblDdlBean.getTblProcDateDdlName());
			selectClause.append(",'DD-MON-YY') as proc_date ");
			this.setAlertTrendTime(false);
		}
		
		args.add(selectClause.toString());
		args.add(dataTblDdlBean.getAlertProcTbl());


		if (dataTblDdlBean.getTblBillRndDdlMon()!=null && dataTblDdlBean.getTblBillRndDdlYear()!=null){
			if (this.getGraphParameters().getStartDate()!=null){
				String whereStartDate = "to_char(" + dataTblDdlBean.getTblBillRndDdlMon() + ")||" + "'/01/'" + "|| to_char(" + dataTblDdlBean.getTblBillRndDdlYear() + ")";
				whereClause.append(" to_date(");
				whereClause.append(whereStartDate);
				whereClause.append(",'mm/dd/yyyy')");
				whereClause.append(" >= to_date('");
				whereClause.append(this.getGraphParameters().getStartDate().toString());
				whereClause.append("','mm/dd/yyyy')");		
				whereClause.append(" AND ");
				whereClause.append(" to_date(");
				whereClause.append(whereStartDate);
				whereClause.append(",'mm/dd/yyyy')");
				whereClause.append(" <= to_date('");
				whereClause.append(this.getGraphParameters().getProcDate().toString());
				whereClause.append("','mm/dd/yyyy') ");		
			} else {
				whereClause.append("to_char(");
				whereClause.append(dataTblDdlBean.getTblBillRndDdlMon());
				whereClause.append(") = to_char(to_date('");
				whereClause.append(this.getGraphParameters().getProcDate().toString());
				whereClause.append("','mm/dd/yyyy'),'MM')");
				whereClause.append(" AND to_char(");
				whereClause.append(dataTblDdlBean.getTblBillRndDdlYear());
				whereClause.append(") = to_char(to_date('");
				whereClause.append(this.getGraphParameters().getProcDate().toString());
				whereClause.append("','mm/dd/yyyy'),'YYYY')");
			}
		} else {
			if (RABC_EXTRCT_SUMY_DATA.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl()) || RABC_CALC_ALERT_DATA.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl()) || RABC_ALERT_HIST.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl())){
				if (this.getGraphParameters().getStartDate()!=null){
					whereClause.append(dataTblDdlBean.getTblProcDateDdlName());
					whereClause.append(" >= to_date('");
					whereClause.append(this.getGraphParameters().getStartDate().toString());
					whereClause.append("','mm/dd/yyyy') AND ");		
				}
				whereClause.append(dataTblDdlBean.getTblProcDateDdlName());
				whereClause.append(" <= to_date('");
				whereClause.append(this.getGraphParameters().getProcDate().toString());
				whereClause.append("','mm/dd/yyyy') ");	
			}else {
				if (this.getGraphParameters().getStartDate()!=null){
					whereClause.append("trunc( " ) ;
					whereClause.append(dataTblDdlBean.getTblProcDateDdlName());
					whereClause.append(") >= to_date('");
					whereClause.append(this.getGraphParameters().getStartDate().toString());
					whereClause.append("','mm/dd/yyyy') AND ");	
				}
				whereClause.append("trunc( " ) ;
				whereClause.append(dataTblDdlBean.getTblProcDateDdlName());
				whereClause.append(") <= to_date('");
				whereClause.append(this.getGraphParameters().getProcDate().toString());
				whereClause.append("','mm/dd/yyyy') ");
			}
		}
		
		if (this.getGraphParameters().getKey1()!=null){
			whereClause.append(" and ");
			whereClause.append(dataTblDdlBean.getTblDdlKey1Name());
			whereClause.append("='");
			whereClause.append(this.getGraphParameters().getKey1());
			whereClause.append("' ");
		}
		if (this.getGraphParameters().getKey2()!=null){
			whereClause.append(" and ");
			whereClause.append(dataTblDdlBean.getTblDdlKey2Name());
			whereClause.append("='");
			whereClause.append(this.getGraphParameters().getKey2());
			whereClause.append("' ");
		}
		if (this.getGraphParameters().getKey3()!=null){
			whereClause.append(" and ");
			whereClause.append(dataTblDdlBean.getTblDdlKey3Name());
			whereClause.append("='");
			whereClause.append(this.getGraphParameters().getKey3());
			whereClause.append("' ");
		}
		if (this.getGraphParameters().getKey4()!=null){
			whereClause.append(" and ");
			whereClause.append(dataTblDdlBean.getTblDdlKey4Name());
			whereClause.append("='");
			whereClause.append(this.getGraphParameters().getKey4());
			whereClause.append("' ");
		}
		if (this.getGraphParameters().getKey5()!=null){
			whereClause.append(" and ");
			whereClause.append(dataTblDdlBean.getTblDdlKey5Name());
			whereClause.append("='");
			whereClause.append(this.getGraphParameters().getKey5());
			whereClause.append("' ");
		}
		
		if (("B".equals(this.getGraphParameters().getAlertTimeInd()) || "D".equals(this.getGraphParameters().getAlertTimeInd())) && (RABC_EXTRCT_SUMY_DATA.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl()) || RABC_CALC_ALERT_DATA.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl()) || RABC_ALERT_HIST.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl()))){
			if (this.getGraphParameters().getAlertTimeValue()==null){
				whereClause.append(" and alert_trend_time is null");
			}else {
				whereClause.append(" and alert_trend_time ='");
				whereClause.append(this.getGraphParameters().getAlertTimeValue());
				whereClause.append("'");
			}
		}
		
		if ("D".equals(this.getGraphParameters().getAlertTimeInd()) && dataTblDdlBean.getTblProcDateDdlName()!=null && ((this.getGraphParameters().getAlertrule() != null || this.getGraphParameters().getPartiRefId() != -1) ||(this.getGraphParameters().getAlertrule() == null && this.getGraphParameters().getPartiRefId() == -1 && this.getGraphParameters().getAlertTimeValue() != null )))	{
			whereClause.append(" and to_char( ") ;
			whereClause.append(dataTblDdlBean.getTblProcDateDdlName());
			whereClause.append(",'D') = to_char(to_date('") ;
			whereClause.append(this.getGraphParameters().getProcDate().toString());
			whereClause.append("', 'mm/dd/yyyy'), 'D')") ;
		} else if ("B".equals(this.getGraphParameters().getAlertTimeInd()) ) {
			if (dataTblDdlBean.getTblBillRndDdlName() != null ) {
				whereClause.append(" AND " ) ;
				whereClause.append(dataTblDdlBean.getTblBillRndDdlName()) ;
				whereClause.append(" = " ) ;
				whereClause.append(this.getGraphParameters().getAlertTimeValue() ) ;
			} 
		}
		
		if ("RABC_ALERT_HIST".equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl())){
			whereClause.append(" AND PRESN_CD IN ('A', 'B') ");
		}
		if (this.getGraphParameters().getAlertItem()!=null){
			whereClause.append(" and ");
			whereClause.append(alertItemDdlName);
			whereClause.append("= '");
			whereClause.append(this.getGraphParameters().getAlertItem());
			whereClause.append("'");
		}
		
		args.add(whereClause.toString());
		
		if (this.getGraphParameters().getFileSeqNum()!=null){
			if (RABC_EXTRCT_SUMY_DATA.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl()) || RABC_CALC_ALERT_DATA.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl()) || RABC_ALERT_HIST.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl())){
				groupByClause.append(" group by file_seq_num order by file_seq_num asc ");
			} else {
				groupByClause.append(" group by Decode(seq_num,null,'no data',seq_num) order by to_number(Decode(seq_num,null,'no data',seq_num)) asc ");
			}
		}else if (dataTblDdlBean.getTblBillRndDdlMon()!=null && dataTblDdlBean.getTblBillRndDdlYear()!=null) {	
			groupByClause.append(" group by TO_CHAR(");
			groupByClause.append(dataTblDdlBean.getTblBillRndDdlMon());
			groupByClause.append(" ,'09')" + "||'-'||" + " TO_CHAR(");
			groupByClause.append(dataTblDdlBean.getTblBillRndDdlYear());
			groupByClause.append(",'9999')");
			groupByClause.append(" order by to_date(TO_CHAR( " ) ;
			groupByClause.append(dataTblDdlBean.getTblBillRndDdlMon());
			groupByClause.append(" ,'09')|| '-' || TO_CHAR(");
			groupByClause.append(dataTblDdlBean.getTblBillRndDdlYear());
			groupByClause.append(",'9999') , 'MM-YYYY') asc ");	
		}else if ("B".equals(this.getGraphParameters().getAlertTimeInd()) || "AB".equals(this.getGraphParameters().getAlertTimeInd())) {
			groupByClause.append(" group by to_char(trunc(");
			groupByClause.append(dataTblDdlBean.getTblProcDateDdlName());
			groupByClause.append(" ), 'DD-MON-YY'), alert_trend_time ");
			groupByClause.append(" order by to_date(PROC_DATE,'DD-MON-YY')  asc, to_number(alert_trend_time) ");
		}else if ("M".equals(this.getGraphParameters().getAlertTimeInd())){
			groupByClause.append(" group by to_char(trunc(");
			groupByClause.append(dataTblDdlBean.getTblProcDateDdlName());
			groupByClause.append(" ), 'MON-YY')");
			groupByClause.append(" order by to_date(PROC_DATE,'MON-YY')  asc ");
		}else {
			groupByClause.append(" group by TO_CHAR(");
			groupByClause.append(dataTblDdlBean.getTblProcDateDdlName());
			groupByClause.append(", 'DD-MON-YY')  " ) ;
			groupByClause.append("order by to_date(proc_date,'DD-MON-YY')  asc ") ; 
		}
		
		args.add(groupByClause.toString());
		
		return args;
	}
	
	/**
	 * Method to return the list of arguments to execute the sql statement 
	 * to get the list of ExtrctSumyData objects. 
	 * This method will be invoked for the following condition:
	 * alertRule= "" or alertRuleFlag = "N" and alertTimeInd = null.
	 * 
	 * @param selectString
	 * @param args1
	 * @param region
	 * @return List
	 */
	private List buildCondition5Arguments(String selectString, List args1, String region){
		List args = new ArrayList();
		StringBuffer selectClause = new StringBuffer();
		StringBuffer whereClause = new StringBuffer();
		StringBuffer groupByClause = new StringBuffer();

		String alertProcTbl = (String) args1.get(0);
		String alertItemDdlName = (String) args1.get(1);

		DataTblDdlBean dataTblDdlBean = qryDataColumn(alertProcTbl,this.getGraphParameters(),region);
		args.add(selectString);
		
		if (this.getGraphParameters().getFileSeqNum()!=null){
			if (RABC_EXTRCT_SUMY_DATA.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl()) || RABC_CALC_ALERT_DATA.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl()) || RABC_ALERT_HIST.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl())){
				selectClause.append(",file_seq_num");
			}else {
				selectClause.append(",Decode(seq_num,null,'no data',seq_num) file_seq_num");
			}
			this.setAlertTrendTime(false);
		} else if (!RABC_EXTRCT_SUMY_DATA.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl()) && !RABC_CALC_ALERT_DATA.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl()) && !RABC_ALERT_HIST.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl())){
			selectClause.append(",TO_CHAR(TO_DATE(TO_CHAR(" + dataTblDdlBean.getTblBillRndDdlMon() + ",'09')||'-'||TO_CHAR(" + dataTblDdlBean.getTblBillRndDdlYear() + ",'9999'),'MM-YYYY'),'MON-YY') as proc_date ");
			this.setAlertTrendTime(false);
		} else if (dataTblDdlBean.getTblBillRndDdlMon()!=null && dataTblDdlBean.getTblBillRndDdlYear()!=null) {
			selectClause.append(",TO_CHAR(TO_DATE(TO_CHAR(" + dataTblDdlBean.getTblBillRndDdlMon() + ",'09')||'-'||TO_CHAR(" + dataTblDdlBean.getTblBillRndDdlYear() + ",'9999'),'MM-YYYY'),'MON-YY') as proc_date ");
			this.setAlertTrendTime(false);
		}else if ("B".equals(this.getGraphParameters().getAlertTimeInd()) || "AB".equals(this.getGraphParameters().getAlertTimeInd())) {
			selectClause.append(",to_char(trunc(");
			selectClause.append(dataTblDdlBean.getTblProcDateDdlName());
			selectClause.append("),'DD-MON-YY') as proc_date ");
			if (dataTblDdlBean.getTblBillRndDdlName()!=null){
				selectClause.append(", ");
				selectClause.append(dataTblDdlBean.getTblBillRndDdlName());
				selectClause.append(" alert_trend_time ");
			}
		}else if ("M".equals(this.getGraphParameters().getAlertTimeInd())){
			selectClause.append(",to_char(trunc(");
			selectClause.append(dataTblDdlBean.getTblProcDateDdlName());
			selectClause.append("),'MON-YY') as proc_date ");
			this.setAlertTrendTime(false);
		}else {
			selectClause.append(",to_char(trunc(");
			selectClause.append(dataTblDdlBean.getTblProcDateDdlName());
			selectClause.append("),'DD-MON-YY') as proc_date ");
			this.setAlertTrendTime(false);
		}
		
		args.add(selectClause.toString());
		args.add(dataTblDdlBean.getAlertProcTbl());
		
		/*
		 * Start forming the where clause
		 */
		if (dataTblDdlBean.getTblBillRndDdlMon()!=null && dataTblDdlBean.getTblBillRndDdlYear()!=null){
			if (this.getGraphParameters().getStartDate()!=null){
				String whereStartDate = "'01-'||to_char(" + dataTblDdlBean.getTblBillRndDdlMon() + ")||'-'||to_char(" + dataTblDdlBean.getTblBillRndDdlYear() + ")";
				whereClause.append(" to_date(");
				whereClause.append(whereStartDate);
				whereClause.append(",'DD-MM-YYYY')");
				whereClause.append(" >= to_date('");
				whereClause.append(this.getGraphParameters().getStartDate().toString());
				whereClause.append("','mm/dd/yyyy')");		
				whereClause.append(" and ");
				whereClause.append(" to_date(");
				whereClause.append(whereStartDate);
				whereClause.append(",'DD-MM-YYYY')");
				whereClause.append(" <= to_date('");
				whereClause.append(this.getGraphParameters().getProcDate().toString());
				whereClause.append("','mm/dd/yyyy') ");		
			} else {
				whereClause.append(" to_char(");
				whereClause.append(dataTblDdlBean.getTblBillRndDdlMon());
				whereClause.append(" )=to_char(to_date('");
				whereClause.append(this.getGraphParameters().getProcDate().toString());
				whereClause.append("','mm/dd/yyyy'),'MM')");
				whereClause.append("and to_char(");
				whereClause.append(dataTblDdlBean.getTblBillRndDdlYear());
				whereClause.append(" )=to_char(to_date('");
				whereClause.append(this.getGraphParameters().getProcDate().toString());
				whereClause.append("','mm/dd/yyyy'),'YYYY')");
			}
		} else {
			if (this.getGraphParameters().getStartDate()!=null){
				whereClause.append("(to_char( " ) ;
				whereClause.append(dataTblDdlBean.getTblBillRndDdlMon()) ;
				whereClause.append(") >= to_char(to_date('" ) ;
				whereClause.append(this.getGraphParameters().getStartDate().toString());
				whereClause.append("','mm/dd/yyyy'),'MM') " ) ;
				whereClause.append(" AND " ) ;
				whereClause.append("to_char( " ) ;
				whereClause.append(dataTblDdlBean.getTblBillRndDdlYear()) ;
				whereClause.append(") = to_char(to_date('" ) ;
				whereClause.append(this.getGraphParameters().getStartDate().toString());
				whereClause.append("','mm/dd/yyyy'),'YYYY')) " ) ;
				whereClause.append(" AND " ) ;
				whereClause.append("(to_char( " ) ;
				whereClause.append(dataTblDdlBean.getTblBillRndDdlMon()) ;
				whereClause.append(") <= to_char(to_date('" ) ;
				whereClause.append(this.getGraphParameters().getProcDate().toString());
				whereClause.append("','mm/dd/yyyy'),'MM') " ) ;
				whereClause.append(" AND " ) ;
				whereClause.append("to_char( " ) ;
				whereClause.append(dataTblDdlBean.getTblBillRndDdlYear()) ;
				whereClause.append(") = to_char(to_date('" ) ;
				whereClause.append(this.getGraphParameters().getProcDate().toString());
				whereClause.append("','mm/dd/yyyy'),'YYYY')) " ) ;
				
				
			} else {
				whereClause.append("to_char( " ) ;
				whereClause.append(dataTblDdlBean.getTblBillRndDdlMon()) ; 
				whereClause.append(") = to_char(to_date(' " ) ;
				whereClause.append(this.getGraphParameters().getProcDate().toString());
				whereClause.append("','mm/dd/yyyy'),'MM') " ) ;
				whereClause.append(" AND " ) ;
				whereClause.append("to_char( " ) ;
				whereClause.append(dataTblDdlBean.getTblBillRndDdlYear()) ; 
				whereClause.append(") = to_char(to_date(' " ) ;
				whereClause.append(this.getGraphParameters().getProcDate().toString());
				whereClause.append("','mm/dd/yyyy'),'YYYY') " ) ;
			}
		}
		
		if (RABC_EXTRCT_SUMY_DATA.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl()) || RABC_CALC_ALERT_DATA.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl()) || RABC_ALERT_HIST.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl())){
			if (RABC_EXTRCT_SUMY_DATA.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl())){
				if (this.getGraphParameters().getAlertItem()!=null){
					whereClause.append(" and extrct_item = '");
					whereClause.append(this.getGraphParameters().getAlertItem());
					whereClause.append("' ");
				} else {
					whereClause.append(" and extrct_item is null");
				}
			} else {
				if (this.getGraphParameters().getAlertItem()!=null){
					whereClause.append(" and alert_item = '");
					whereClause.append(this.getGraphParameters().getAlertItem());
					whereClause.append("' ");
				} else {
					whereClause.append(" and alert_item is null");
				}
			}
			
			whereClause.append(" and parti_ref_id=");
			whereClause.append(this.getGraphParameters().getPartiRefId());
			
			if (this.getGraphParameters().getAlertTimeInd()!=null && this.getGraphParameters().getAlertTimeValue()!=null){
				whereClause.append(" and alert_trend_time = '");
				whereClause.append(this.getGraphParameters().getAlertTimeValue());
				whereClause.append("'");
			}
			
			/*
			 * Changes made in the logic of getting the key values after error reported in Graph for 
			 * Control Data History Report on 4th April 2006. We now check for presense of single quotes in the 
			 * key values; if present then we don't add our own
			 */
			if (this.getGraphParameters().getAkey1()!=null){
				String tempKey1=this.getGraphParameters().getAkey1();
				if (tempKey1.indexOf("to_date")!=-1){
					whereClause.append(" and ");
					whereClause.append(dataTblDdlBean.getTblDdlKey1Name());
					whereClause.append("=");
					whereClause.append(this.getGraphParameters().getAkey1());
				}else if (tempKey1.indexOf("'")!=-1) {
					whereClause.append(" and ");
					whereClause.append(dataTblDdlBean.getTblDdlKey1Name());
					whereClause.append("=");
					whereClause.append(this.getGraphParameters().getAkey1());
				}else {
					whereClause.append(" and ");
					whereClause.append(dataTblDdlBean.getTblDdlKey1Name());
					whereClause.append("='");
					whereClause.append(this.getGraphParameters().getAkey1());
					whereClause.append("' ");
				}
			}
			
			if (this.getGraphParameters().getAkey2()!=null){
				String tempKey2=this.getGraphParameters().getAkey2();
				if (tempKey2.indexOf("=")!=-1){
					int lenKey2complete = tempKey2.trim().length();
					String key2 = tempKey2.substring(2,tempKey2.indexOf("="));
					String key2Value = tempKey2.substring((tempKey2.indexOf("=")+1),lenKey2complete);
					whereClause.append(" and ");
					whereClause.append(key2);
					whereClause.append(" = ");
					whereClause.append(key2Value);
				}else if (tempKey2.indexOf("'")!=-1) {
					whereClause.append(" and ");
					whereClause.append(dataTblDdlBean.getTblDdlKey2Name());
					whereClause.append("=");
					whereClause.append(this.getGraphParameters().getAkey2());
				}else {
					whereClause.append(" and ");
					whereClause.append(dataTblDdlBean.getTblDdlKey2Name());
					whereClause.append("='");
					whereClause.append(this.getGraphParameters().getAkey2());
					whereClause.append("' ");
				}
			}
			
			if (this.getGraphParameters().getAkey3()!=null){
				String tempKey3=this.getGraphParameters().getAkey3();
				if (tempKey3.indexOf("=")!=-1){
					int lenKey3complete = tempKey3.trim().length();
					String key3 = tempKey3.substring(2,tempKey3.indexOf("="));
					String key3Value = tempKey3.substring((tempKey3.indexOf("=")+1),lenKey3complete);
					whereClause.append(" and ");
					whereClause.append(key3);
					whereClause.append(" = ");
					whereClause.append(key3Value);
				}else if (tempKey3.indexOf("'")!=-1) {
					whereClause.append(" and ");
					whereClause.append(dataTblDdlBean.getTblDdlKey3Name());
					whereClause.append("=");
					whereClause.append(this.getGraphParameters().getAkey3());
				}else {
					whereClause.append(" and ");
					whereClause.append(dataTblDdlBean.getTblDdlKey3Name());
					whereClause.append("='");
					whereClause.append(this.getGraphParameters().getAkey3());
					whereClause.append("' ");
				}
			}
			
			if (this.getGraphParameters().getAkey4()!=null){
				String tempKey4=this.getGraphParameters().getAkey4();
				if (tempKey4.indexOf("=")!=-1){
					int lenKey4complete = tempKey4.trim().length();
					String key4 = tempKey4.substring(2,tempKey4.indexOf("="));
					String key4Value = tempKey4.substring((tempKey4.indexOf("=")+1),lenKey4complete);
					whereClause.append(" and ");
					whereClause.append(key4);
					whereClause.append(" = ");
					whereClause.append(key4Value);
				}else if (tempKey4.indexOf("'")!=-1) {
					whereClause.append(" and ");
					whereClause.append(dataTblDdlBean.getTblDdlKey4Name());
					whereClause.append("=");
					whereClause.append(this.getGraphParameters().getAkey4());
				}else {
					whereClause.append(" and ");
					whereClause.append(dataTblDdlBean.getTblDdlKey4Name());
					whereClause.append("='");
					whereClause.append(this.getGraphParameters().getAkey4());
					whereClause.append("' ");
				}
			}
			
			if (this.getGraphParameters().getAkey5()!=null){
				String tempKey5=this.getGraphParameters().getAkey5();
				if (tempKey5.indexOf("=")!=-1){
					int lenKey5complete = tempKey5.trim().length();
					String key5 = tempKey5.substring(2,tempKey5.indexOf("="));
					String key5Value = tempKey5.substring((tempKey5.indexOf("=")+1),lenKey5complete);
					whereClause.append(" and ");
					whereClause.append(key5);
					whereClause.append(" = ");
					whereClause.append(key5Value);
				}else if (tempKey5.indexOf("'")!=-1) {
					whereClause.append(" and ");
					whereClause.append(dataTblDdlBean.getTblDdlKey5Name());
					whereClause.append("=");
					whereClause.append(this.getGraphParameters().getAkey5());
				}else {
					whereClause.append(" and ");
					whereClause.append(dataTblDdlBean.getTblDdlKey5Name());
					whereClause.append("='");
					whereClause.append(this.getGraphParameters().getAkey5());
					whereClause.append("' ");
				}
			}
			
			if ("RABC_ALERT_HIST".equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl()) || "RABC_EXTRCT_SUMY_DATA".equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl())){
				whereClause.append("AND PRESN_CD IN ('A', 'B')");
			}
		}else {
			if (this.getGraphParameters().getKey1()!=null && this.getGraphParameters().getKey1colname()!=null){
				if (!("AB".equals(this.getGraphParameters().getAlertTimeInd()) && this.getGraphParameters().getKey1colname().equalsIgnoreCase(dataTblDdlBean.getTblBillRndDdlName()))){
					if (this.getGraphParameters().getKey1().indexOf("to_date")!=-1){
						whereClause.append(" and ");
						whereClause.append(this.getGraphParameters().getKey1colname());
						if (this.getGraphParameters().getKey1().indexOf("=")==-1 && this.getGraphParameters().getKey1colname().indexOf("=")==-1){
							whereClause.append("=");
						}
						whereClause.append(this.getGraphParameters().getKey1());
					}else if (this.getGraphParameters().getKey1().indexOf("is null")!=-1){
						whereClause.append(" and ");
						whereClause.append(this.getGraphParameters().getKey1());
					}else if (this.getGraphParameters().getKey1().indexOf("=")==-1 && this.getGraphParameters().getKey1colname().indexOf("=")==-1){
						whereClause.append(" and ");
						whereClause.append(this.getGraphParameters().getKey1colname());
						whereClause.append("=");
						if (this.getGraphParameters().getKey1().indexOf("'")==-1){
							whereClause.append("'");
						}
						whereClause.append(this.getGraphParameters().getKey1());
						if (this.getGraphParameters().getKey1().indexOf("'")==-1){
							whereClause.append("' ");
						}
					}else {
						whereClause.append(" and ");
						whereClause.append(this.getGraphParameters().getKey1colname());
						whereClause.append(" = ");
						whereClause.append(this.getGraphParameters().getKey1());
					}
				}
			}
			
			if (this.getGraphParameters().getKey2()!=null){
				String tempKey2=this.getGraphParameters().getKey2();
				if (tempKey2.indexOf("=")!=-1){
					int lenKey2complete = tempKey2.trim().length();
					String key2 = tempKey2.substring(2,tempKey2.indexOf("="));
					String key2Value = tempKey2.substring((tempKey2.indexOf("=")+1),lenKey2complete);
					
					if (!("AB".equals(this.getGraphParameters().getAlertTimeInd()) && key2.equalsIgnoreCase(dataTblDdlBean.getTblBillRndDdlName()))) {
						whereClause.append(" and ");
						whereClause.append(key2);
						whereClause.append(" = ");
						whereClause.append(key2Value);
					}	
				}
			}
			
			if (this.getGraphParameters().getKey3()!=null){
				String tempKey3=this.getGraphParameters().getKey3();
				if (tempKey3.indexOf("=")!=-1){
					int lenKey3complete = tempKey3.trim().length();
					String key3 = tempKey3.substring(2,tempKey3.indexOf("="));
					String key3Value = tempKey3.substring((tempKey3.indexOf("=")+1),lenKey3complete);
					
					if (!("AB".equals(this.getGraphParameters().getAlertTimeInd()) && key3.equalsIgnoreCase(dataTblDdlBean.getTblBillRndDdlName()))){
						whereClause.append(" and ");
						whereClause.append(key3);
						whereClause.append(" = ");
						whereClause.append(key3Value);
					}
				}
			}
			
			if (this.getGraphParameters().getKey4()!=null){
				String tempKey4=this.getGraphParameters().getKey4();
				if (tempKey4.indexOf("=")!=-1){
					int lenKey4complete = tempKey4.trim().length();
					String key4 = tempKey4.substring(2,tempKey4.indexOf("="));
					String key4Value = tempKey4.substring((tempKey4.indexOf("=")+1),lenKey4complete);
					
					if (!("AB".equals(this.getGraphParameters().getAlertTimeInd()) && key4.equalsIgnoreCase(dataTblDdlBean.getTblBillRndDdlName()))){
						whereClause.append(" and ");
						whereClause.append(key4);
						whereClause.append(" = ");
						whereClause.append(key4Value);
					}
				}
			}
			
			if (this.getGraphParameters().getKey5()!=null){
				String tempKey5=this.getGraphParameters().getKey5();
				if (tempKey5.indexOf("=")!=-1){
					int lenKey5complete = tempKey5.trim().length();
					String key5 = tempKey5.substring(2,tempKey5.indexOf("="));
					String key5Value = tempKey5.substring((tempKey5.indexOf("=")+1),lenKey5complete);
					
					if (!("AB".equals(this.getGraphParameters().getAlertTimeInd()) && key5.equalsIgnoreCase(dataTblDdlBean.getTblBillRndDdlName()))){
						whereClause.append(" and ");
						whereClause.append(key5);
						whereClause.append(" = ");
						whereClause.append(key5Value);
					}
				}
			}
		}
		
		if (dataTblDdlBean.getTblBillRndDdlName()!=null && this.getGraphParameters().getAlertTimeValue()!=null && !"AB".equals(this.getGraphParameters().getAlertTimeInd())){
			whereClause.append(" and ");
			whereClause.append(dataTblDdlBean.getTblBillRndDdlName());
			whereClause.append("=");
			whereClause.append(this.getGraphParameters().getAlertTimeValue());
		}
		
		args.add(whereClause.toString());
		
		if (this.getGraphParameters().getFileSeqNum()!=null){
			if (RABC_EXTRCT_SUMY_DATA.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl()) || RABC_CALC_ALERT_DATA.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl()) || RABC_ALERT_HIST.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl())){
				groupByClause.append(" group by file_seq_num order by file_seq_num asc ");
			} else {
				groupByClause.append(" group by Decode(seq_num,null,'no data',seq_num) order by to_number(Decode(seq_num,null,'no data',seq_num)) asc ");
			}
		}else if (!RABC_EXTRCT_SUMY_DATA.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl()) && !RABC_CALC_ALERT_DATA.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl()) && !RABC_ALERT_HIST.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl())){
			groupByClause.append(" group by TO_CHAR( ");
			groupByClause.append(dataTblDdlBean.getTblBillRndDdlMon() + ",'09') || '-' || TO_CHAR(" + dataTblDdlBean.getTblBillRndDdlYear() + ",'9999')");
			groupByClause.append(" order by to_date(TO_CHAR( ");
			groupByClause.append(dataTblDdlBean.getTblBillRndDdlMon() + ",'09') || '-' || TO_CHAR(" + dataTblDdlBean.getTblBillRndDdlYear() + " ,'9999'),'MM-YYYY') asc ");
		} else if (dataTblDdlBean.getTblBillRndDdlMon()!=null && dataTblDdlBean.getTblBillRndDdlYear()!=null) {
			groupByClause.append(" group by TO_CHAR( ");
			groupByClause.append(dataTblDdlBean.getTblBillRndDdlMon() + ",'09') || '-' || TO_CHAR(" + dataTblDdlBean.getTblBillRndDdlYear() + ",'9999')");
			groupByClause.append(" order by to_date(TO_CHAR( ");
			groupByClause.append(dataTblDdlBean.getTblBillRndDdlMon() + ",'09') || '-' || TO_CHAR(" + dataTblDdlBean.getTblBillRndDdlYear() + " ,'9999'),'MM-YYYY') asc ");
		}else if ("B".equals(this.getGraphParameters().getAlertTimeInd()) || "AB".equals(this.getGraphParameters().getAlertTimeInd())) {
			groupByClause.append(" group by to_char(trunc(");
			groupByClause.append(dataTblDdlBean.getTblProcDateDdlName());
			groupByClause.append(" ), 'DD-MON-YY')");
			if (dataTblDdlBean.getTblBillRndDdlName()!=null){
				groupByClause.append(", ");
				groupByClause.append(dataTblDdlBean.getTblBillRndDdlName());
			}
			groupByClause.append(" order by to_date(PROC_DATE,'DD-MON-YY')  asc");
			if (dataTblDdlBean.getTblBillRndDdlName()!=null){
				groupByClause.append(", to_number(");
				groupByClause.append(dataTblDdlBean.getTblBillRndDdlName());
				groupByClause.append(") asc");
			}
		} else if ("M".equals(this.getGraphParameters().getAlertTimeInd())){
			groupByClause.append(" group by to_char(trunc(");
			groupByClause.append(dataTblDdlBean.getTblProcDateDdlName());
			groupByClause.append(" ), 'MON-YY')");
			groupByClause.append(" order by to_date(PROC_DATE,'MON-YY')  asc ");
		}else {
			groupByClause.append(" group by to_char(trunc(");
			groupByClause.append(dataTblDdlBean.getTblProcDateDdlName());
			groupByClause.append(" ), 'DD-MON-YY') ");
			groupByClause.append(" order by to_date(proc_date,'DD-MON-YY')  asc ");
		}
		
		args.add(groupByClause.toString());
		
		return args;
	}
	
	/**
	 * Method to return the list of arguments to execute the sql statement 
	 * to get the list of ExtrctSumyData objects. 
	 * This method will be invoked for the following condition:
	 * alertRule= "" or alertRuleFlag = "N" and 
	 * (alertTimeInd = 'B' or 'M' or 'AB' and dataTblDdlBean.getTblBillRndDdlMon()!=null 
	 * and dataTblDdlBean.getTblBillRndDdlYear()!=null).
	 * 
	 * @param selectString
	 * @param args1
	 * @param region
	 * @return List
	 */
	private List buildCondition6Arguments(String selectString, List args1, String region){
		List args = new ArrayList();
		StringBuffer selectClause = new StringBuffer();
		StringBuffer whereClause = new StringBuffer();
		StringBuffer groupByClause = new StringBuffer();

		String alertProcTbl = (String) args1.get(0);
		String alertItemDdlName = (String) args1.get(1);
		String month = getMonth(this.getGraphParameters().getProcDate());
		
		DataTblDdlBean dataTblDdlBean = qryDataColumn(alertProcTbl,this.getGraphParameters(),region);
		args.add(selectString);
		
		if (this.getGraphParameters().getFileSeqNum()!=null){
			if (RABC_EXTRCT_SUMY_DATA.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl()) || RABC_CALC_ALERT_DATA.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl()) || RABC_ALERT_HIST.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl())){
				selectClause.append(",file_seq_num");
			}else {
				selectClause.append(",Decode(seq_num,null,'no data',seq_num) file_seq_num");
			}
			this.setAlertTrendTime(false);
		}else if (dataTblDdlBean.getTblBillRndDdlMon()!=null && dataTblDdlBean.getTblBillRndDdlYear()!=null && month.equals(dataTblDdlBean.getTblBillRndDdlMon())) {
			selectClause.append(",TO_CHAR(TO_DATE(TO_CHAR(" + dataTblDdlBean.getTblBillRndDdlMon() + ",'09')||'-'|| TO_CHAR(" + dataTblDdlBean.getTblBillRndDdlYear() + ",'9999'),'MM-YYYY'),'MON-YY') as proc_date ");
			this.setAlertTrendTime(false);
		}else if (dataTblDdlBean.getTblProcDateDdlName()!=null){
			if ("B".equals(this.getGraphParameters().getAlertTimeInd()) || "AB".equals(this.getGraphParameters().getAlertTimeInd())) {
				selectClause.append(",to_char(trunc(");
				selectClause.append(dataTblDdlBean.getTblProcDateDdlName());
				selectClause.append("),'DD-MON-YY') as proc_date ");
				if (dataTblDdlBean.getTblBillRndDdlName()!=null){
					selectClause.append(", ");
					selectClause.append(dataTblDdlBean.getTblBillRndDdlName());
					selectClause.append(" alert_trend_time ");
				}
			}else if ("M".equals(this.getGraphParameters().getAlertTimeInd())){
				selectClause.append(",to_char(trunc(");
				selectClause.append(dataTblDdlBean.getTblProcDateDdlName());
				selectClause.append("),'MON-YY') as proc_date ");
				this.setAlertTrendTime(false);
			}else {
				selectClause.append(",to_char(trunc(");
				selectClause.append(dataTblDdlBean.getTblProcDateDdlName());
				selectClause.append("),'DD-MON-YY') as proc_date");
				this.setAlertTrendTime(false);
			}
		}else {
			selectClause.append(",TBL_BILL_RND_DDL_MON as proc_date");
			this.setAlertTrendTime(false);
		}
		
		args.add(selectClause.toString());
		args.add(dataTblDdlBean.getAlertProcTbl());
		
		if (dataTblDdlBean.getTblBillRndDdlMon()!=null && dataTblDdlBean.getTblBillRndDdlYear()!=null && month.equals(dataTblDdlBean.getTblBillRndDdlMon())){
			if (this.getGraphParameters().getStartDate()!=null){
				String whereStartDate = "'01-'||to_char(" + dataTblDdlBean.getTblBillRndDdlMon() + ")||'-'||to_char(" + dataTblDdlBean.getTblBillRndDdlYear() + ")";
				whereClause.append(" to_date(");
				whereClause.append(whereStartDate);
				whereClause.append(",'DD-MM-YYYY')");
				whereClause.append(" >= to_date('");
				whereClause.append(this.getGraphParameters().getStartDate().toString());
				whereClause.append("','mm/dd/yyyy')");		
				whereClause.append(" AND ");
				whereClause.append(" to_date(");
				whereClause.append(whereStartDate);
				whereClause.append(",'DD-MM-YYYY')");
				whereClause.append(" <= to_date('");
				whereClause.append(this.getGraphParameters().getProcDate().toString());
				whereClause.append("','mm/dd/yyyy') ");		
			} else {
				whereClause.append(" to_char(");
				whereClause.append(dataTblDdlBean.getTblBillRndDdlMon());
				whereClause.append(" )=to_char(to_date('");
				whereClause.append(this.getGraphParameters().getProcDate().toString());
				whereClause.append("','mm/dd/yyyy'),'MM')");
				whereClause.append("AND to_char(");
				whereClause.append(dataTblDdlBean.getTblBillRndDdlYear());
				whereClause.append(" )=to_char(to_date('");
				whereClause.append(this.getGraphParameters().getProcDate().toString());
				whereClause.append("','mm/dd/yyyy'),'YYYY')");
			}
		} else {
			if (this.getGraphParameters().getStartDate()!=null){
				if (RABC_EXTRCT_SUMY_DATA.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl()) || RABC_CALC_ALERT_DATA.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl()) || RABC_ALERT_HIST.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl())){
					whereClause.append(dataTblDdlBean.getTblProcDateDdlName());
					whereClause.append(" >= to_date('");
					whereClause.append(this.getGraphParameters().getStartDate().toString());
					whereClause.append("' ,'mm/dd/yyyy') and ");
					whereClause.append(dataTblDdlBean.getTblProcDateDdlName());
					whereClause.append(" <= to_date('");
					whereClause.append(this.getGraphParameters().getProcDate().toString());
					whereClause.append("' ,'mm/dd/yyyy')");
				}else {
					whereClause.append(" trunc(");
					whereClause.append(dataTblDdlBean.getTblProcDateDdlName());
					whereClause.append(") >= to_date('");
					whereClause.append(this.getGraphParameters().getStartDate().toString());
					whereClause.append("','mm/dd/yyyy')");
					whereClause.append(" and trunc(");
					whereClause.append(dataTblDdlBean.getTblProcDateDdlName());
					whereClause.append(") <= to_date('");
					whereClause.append(this.getGraphParameters().getProcDate().toString());
					whereClause.append("' ,'mm/dd/yyyy')");
				}
			}else {
				if (RABC_EXTRCT_SUMY_DATA.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl()) || RABC_CALC_ALERT_DATA.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl()) || RABC_ALERT_HIST.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl())){
					whereClause.append(dataTblDdlBean.getTblProcDateDdlName());
					whereClause.append(" <= to_date('");
					whereClause.append(this.getGraphParameters().getProcDate().toString());
					whereClause.append("' ,'mm/dd/yyyy')");
				}else {
					whereClause.append(" trunc(");
					whereClause.append(dataTblDdlBean.getTblProcDateDdlName());
					whereClause.append(") <= to_date('");
					whereClause.append(this.getGraphParameters().getProcDate().toString());
					whereClause.append("' ,'mm/dd/yyyy')");
				}
			}
		}
		
		if (RABC_EXTRCT_SUMY_DATA.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl()) || RABC_CALC_ALERT_DATA.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl()) || RABC_ALERT_HIST.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl())){
			if (RABC_EXTRCT_SUMY_DATA.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl())){
				if (this.getGraphParameters().getAlertItem()!=null){
					whereClause.append(" and extrct_item = '");
					whereClause.append(this.getGraphParameters().getAlertItem());
					whereClause.append("' ");
				} else {
					whereClause.append(" and extrct_item is null");
				}
			} else {
				if (this.getGraphParameters().getAlertItem()!=null){
					whereClause.append(" and alert_item = '");
					whereClause.append(this.getGraphParameters().getAlertItem());
					whereClause.append("' ");
				} else {
					whereClause.append(" and alert_item is null");
				}
			}
			
			whereClause.append(" and parti_ref_id=");
			whereClause.append(this.getGraphParameters().getPartiRefId());
			
			if (this.getGraphParameters().getAlertTimeInd()!=null){
				if (!"AB".equals(this.getGraphParameters().getAlertTimeInd()) && !"AW".equals(this.getGraphParameters().getAlertTimeInd()) & this.getGraphParameters().getAlertTimeValue()!=null){
					whereClause.append(" and alert_trend_time = '");
					whereClause.append(this.getGraphParameters().getAlertTimeValue());
					whereClause.append("' ");
				}
			}
			
			/*
			 * Changes made in the logic of getting the key values after error reported in Graph for 
			 * Control Data History Report on 4th April 2006. We now check for presense of single quotes in the 
			 * key values; if present then we don't add our own
			 */
			if (this.getGraphParameters().getAkey1()!=null){
				String tempKey1=this.getGraphParameters().getAkey1();
				if (tempKey1.indexOf("to_date")!=-1){
					whereClause.append(" and ");
					whereClause.append(dataTblDdlBean.getTblDdlKey1Name());
					whereClause.append("=");
					whereClause.append(this.getGraphParameters().getAkey1());
				}else if (tempKey1.indexOf("'")!=-1) {
					whereClause.append(" and ");
					whereClause.append(dataTblDdlBean.getTblDdlKey1Name());
					whereClause.append("=");
					whereClause.append(this.getGraphParameters().getAkey1());
				}else {
					whereClause.append(" and ");
					whereClause.append(dataTblDdlBean.getTblDdlKey1Name());
					whereClause.append("='");
					whereClause.append(this.getGraphParameters().getAkey1());
					whereClause.append("' ");
				}
			}
			
			if (this.getGraphParameters().getAkey2()!=null){
				String tempKey2=this.getGraphParameters().getAkey2();
				if (tempKey2.indexOf("=")!=-1){
					int lenKey2complete = tempKey2.trim().length();
					String key2 = tempKey2.substring(2,tempKey2.indexOf("="));
					String key2Value = tempKey2.substring((tempKey2.indexOf("=")+1),lenKey2complete);
					whereClause.append(" and ");
					whereClause.append(key2);
					whereClause.append(" = ");
					whereClause.append(key2Value);
				}else if (tempKey2.indexOf("'")!=-1) {
					whereClause.append(" and ");
					whereClause.append(dataTblDdlBean.getTblDdlKey2Name());
					whereClause.append("=");
					whereClause.append(this.getGraphParameters().getAkey2());
				}else {
					whereClause.append(" and ");
					whereClause.append(dataTblDdlBean.getTblDdlKey2Name());
					whereClause.append("='");
					whereClause.append(this.getGraphParameters().getAkey2());
					whereClause.append("' ");
				}
			}
			
			if (this.getGraphParameters().getAkey3()!=null){
				String tempKey3=this.getGraphParameters().getAkey3();
				if (tempKey3.indexOf("=")!=-1){
					int lenKey3complete = tempKey3.trim().length();
					String key3 = tempKey3.substring(2,tempKey3.indexOf("="));
					String key3Value = tempKey3.substring((tempKey3.indexOf("=")+1),lenKey3complete);
					whereClause.append(" and ");
					whereClause.append(key3);
					whereClause.append(" = ");
					whereClause.append(key3Value);
				}else if (tempKey3.indexOf("'")!=-1) {
					whereClause.append(" and ");
					whereClause.append(dataTblDdlBean.getTblDdlKey3Name());
					whereClause.append("=");
					whereClause.append(this.getGraphParameters().getAkey3());
				}else {
					whereClause.append(" and ");
					whereClause.append(dataTblDdlBean.getTblDdlKey3Name());
					whereClause.append("='");
					whereClause.append(this.getGraphParameters().getAkey3());
					whereClause.append("' ");
				}
			}
			
			if (this.getGraphParameters().getAkey4()!=null){
				String tempKey4=this.getGraphParameters().getAkey4();
				if (tempKey4.indexOf("=")!=-1){
					int lenKey4complete = tempKey4.trim().length();
					String key4 = tempKey4.substring(2,tempKey4.indexOf("="));
					String key4Value = tempKey4.substring((tempKey4.indexOf("=")+1),lenKey4complete);
					whereClause.append(" and ");
					whereClause.append(key4);
					whereClause.append(" = ");
					whereClause.append(key4Value);
				}else if (tempKey4.indexOf("'")!=-1) {
					whereClause.append(" and ");
					whereClause.append(dataTblDdlBean.getTblDdlKey4Name());
					whereClause.append("=");
					whereClause.append(this.getGraphParameters().getAkey4());
				}else {
					whereClause.append(" and ");
					whereClause.append(dataTblDdlBean.getTblDdlKey4Name());
					whereClause.append("='");
					whereClause.append(this.getGraphParameters().getAkey4());
					whereClause.append("' ");
				}
			}
			
			if (this.getGraphParameters().getAkey5()!=null){
				String tempKey5=this.getGraphParameters().getAkey5();
				if (tempKey5.indexOf("=")!=-1){
					int lenKey5complete = tempKey5.trim().length();
					String key5 = tempKey5.substring(2,tempKey5.indexOf("="));
					String key5Value = tempKey5.substring((tempKey5.indexOf("=")+1),lenKey5complete);
					whereClause.append(" and ");
					whereClause.append(key5);
					whereClause.append(" = ");
					whereClause.append(key5Value);
				}else if (tempKey5.indexOf("'")!=-1) {
					whereClause.append(" and ");
					whereClause.append(dataTblDdlBean.getTblDdlKey5Name());
					whereClause.append("=");
					whereClause.append(this.getGraphParameters().getAkey5());
				}else {
					whereClause.append(" and ");
					whereClause.append(dataTblDdlBean.getTblDdlKey5Name());
					whereClause.append("='");
					whereClause.append(this.getGraphParameters().getAkey5());
					whereClause.append("' ");
				}
			}
			
			if ("RABC_ALERT_HIST".equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl()) || "RABC_EXTRCT_SUMY_DATA".equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl())){
				whereClause.append(" AND PRESN_CD IN ('A', 'B') ");
			}
		}else {
			if (this.getGraphParameters().getKey1()!=null && this.getGraphParameters().getKey1colname()!=null){
				if (this.getGraphParameters().getKey1().indexOf("to_date")!=-1){
					whereClause.append(" and ");
					whereClause.append(this.getGraphParameters().getKey1colname());
					if (this.getGraphParameters().getKey1().indexOf("=")==-1 && this.getGraphParameters().getKey1colname().indexOf("=")==-1){
						whereClause.append("=");
					}
					whereClause.append(this.getGraphParameters().getKey1());
				}else if (this.getGraphParameters().getKey1().indexOf("is null")!=-1){
					whereClause.append(" and ");
					whereClause.append(this.getGraphParameters().getKey1());
				}else if (this.getGraphParameters().getKey1().indexOf("=")==-1 && this.getGraphParameters().getKey1colname().indexOf("=")==-1){
					whereClause.append(" and ");
					whereClause.append(this.getGraphParameters().getKey1colname());
					whereClause.append("=");
					if (this.getGraphParameters().getKey1().indexOf("'")==-1){
						whereClause.append("'");
					}
					whereClause.append(this.getGraphParameters().getKey1());
					if (this.getGraphParameters().getKey1().indexOf("'")==-1){
						whereClause.append("'");
					}
				}else {
					whereClause.append(" and ");
					whereClause.append(this.getGraphParameters().getKey1colname());
					whereClause.append(" = ");
					whereClause.append(this.getGraphParameters().getKey1());
				}
			}
			
			if (this.getGraphParameters().getKey2()!=null){
				String tempKey2=this.getGraphParameters().getKey2();
				if (tempKey2.indexOf("=")!=-1){
					int lenKey2complete = tempKey2.trim().length();
					String key2 = tempKey2.substring(2,tempKey2.indexOf("="));
					String key2Value = tempKey2.substring((tempKey2.indexOf("=")+1),lenKey2complete);
					whereClause.append(" and ");
					whereClause.append(key2);
					whereClause.append(" = ");
					whereClause.append(key2Value);
				}
			}
			
			if (this.getGraphParameters().getKey3()!=null){
				String tempKey3=this.getGraphParameters().getKey3();
				if (tempKey3.indexOf("=")!=-1){
					int lenKey3complete = tempKey3.trim().length();
					String key3 = tempKey3.substring(2,tempKey3.indexOf("="));
					String key3Value = tempKey3.substring((tempKey3.indexOf("=")+1),lenKey3complete);
					whereClause.append(" and ");
					whereClause.append(key3);
					whereClause.append(" = ");
					whereClause.append(key3Value);
				}
			}
			
			if (this.getGraphParameters().getKey4()!=null){
				String tempKey4=this.getGraphParameters().getKey4();
				if (tempKey4.indexOf("=")!=-1){
					int lenKey4complete = tempKey4.trim().length();
					String key4 = tempKey4.substring(2,tempKey4.indexOf("="));
					String key4Value = tempKey4.substring((tempKey4.indexOf("=")+1),lenKey4complete);
					whereClause.append(" and ");
					whereClause.append(key4);
					whereClause.append(" = ");
					whereClause.append(key4Value);
				}
			}
			
			if (this.getGraphParameters().getKey5()!=null){
				String tempKey5=this.getGraphParameters().getKey5();
				if (tempKey5.indexOf("=")!=-1){
					int lenKey5complete = tempKey5.trim().length();
					String key5 = tempKey5.substring(2,tempKey5.indexOf("="));
					String key5Value = tempKey5.substring((tempKey5.indexOf("=")+1),lenKey5complete);
					whereClause.append(" and ");
					whereClause.append(key5);
					whereClause.append(" = ");
					whereClause.append(key5Value);
				}
			}
		}

		if (this.getGraphParameters().getAlertTimeInd()!=null){
			if (("B".equals(this.getGraphParameters().getAlertTimeInd()) || "D".equals(this.getGraphParameters().getAlertTimeInd())) && (RABC_EXTRCT_SUMY_DATA.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl()) || RABC_CALC_ALERT_DATA.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl()) || RABC_ALERT_HIST.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl()))){
				if (this.getGraphParameters().getAlertTimeValue()!=null){
					whereClause.append(" and alert_trend_time= '");
					whereClause.append(this.getGraphParameters().getAlertTimeValue());
					whereClause.append("' ");
				}else {
					whereClause.append("and alert_trend_time is null");
				}
			}
			
			if ("D".equals(this.getGraphParameters().getAlertTimeInd())&& ((this.getGraphParameters().getAlertRule()!=null || this.getGraphParameters().getPartiRefId()!=-1) || (this.getGraphParameters().getAlertRule()==null && this.getGraphParameters().getPartiRefId()==-1 && this.getGraphParameters().getAlertTimeValue()!=null)) ){
				whereClause.append(" and to_char(");
				whereClause.append(dataTblDdlBean.getTblProcDateDdlName());
				whereClause.append(" ,'D') = to_char(to_date('");
				whereClause.append(this.getGraphParameters().getProcDate().toString());
				whereClause.append("', 'MM/DD/YYYY'), 'D')");
			}else if ("B".equals(this.getGraphParameters().getAlertTimeInd())){
				if (dataTblDdlBean.getTblBillRndDdlName()!=null && this.getGraphParameters().getAlertTimeValue()!=null){
					whereClause.append(" AND ");
					whereClause.append(dataTblDdlBean.getTblBillRndDdlName());
					whereClause.append("  = ");
					whereClause.append(this.getGraphParameters().getAlertTimeValue());
				}
			}
		}

		args.add(whereClause.toString());
		
		if (this.getGraphParameters().getFileSeqNum()!=null){
			if (RABC_EXTRCT_SUMY_DATA.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl()) || RABC_CALC_ALERT_DATA.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl()) || RABC_ALERT_HIST.equalsIgnoreCase(dataTblDdlBean.getAlertProcTbl())){
				groupByClause.append(" group by file_seq_num order by file_seq_num asc ");
			} else {
				groupByClause.append(" group by Decode(seq_num,null,'no data',seq_num) order by to_number(Decode(seq_num,null,'no data',seq_num)) asc ");
			}
		} else if (dataTblDdlBean.getTblBillRndDdlMon()!=null && dataTblDdlBean.getTblBillRndDdlYear()!=null && month.equals(dataTblDdlBean.getTblBillRndDdlMon())) {
			groupByClause.append(" group by TO_CHAR( ");
			groupByClause.append(dataTblDdlBean.getTblBillRndDdlMon() + ",'09') || '-' || TO_CHAR(" + dataTblDdlBean.getTblBillRndDdlYear() + ",'9999')");
			groupByClause.append(" order by to_date(TO_CHAR( ");
			groupByClause.append(dataTblDdlBean.getTblBillRndDdlMon() + ",'09') || '-' || TO_CHAR(" + dataTblDdlBean.getTblBillRndDdlYear() + " ,'9999'),'MM-YYYY') asc ");
		}else if ("B".equals(this.getGraphParameters().getAlertTimeInd()) || "AB".equals(this.getGraphParameters().getAlertTimeInd())) {
			groupByClause.append(" group by to_char(trunc(");
			groupByClause.append(dataTblDdlBean.getTblProcDateDdlName());
			groupByClause.append(" ), 'DD-MON-YY')");
			if (dataTblDdlBean.getTblBillRndDdlName()!=null){
				groupByClause.append(", ");
				groupByClause.append(dataTblDdlBean.getTblBillRndDdlName());
			}
			groupByClause.append(" order by to_date(PROC_DATE,'DD-MON-YY')  asc");
			if (dataTblDdlBean.getTblBillRndDdlName()!=null){
				groupByClause.append(", to_number(");
				groupByClause.append(dataTblDdlBean.getTblBillRndDdlName());
				groupByClause.append(") asc");
			}
		} else if ("M".equals(this.getGraphParameters().getAlertTimeInd())){
			groupByClause.append(" group by to_char(trunc(");
			groupByClause.append(dataTblDdlBean.getTblProcDateDdlName());
			groupByClause.append(" ), 'MON-YY')");
			groupByClause.append(" order by to_date(PROC_DATE,'MON-YY')  asc ");
		}else {
			groupByClause.append(" group by to_char(trunc(");
			groupByClause.append(dataTblDdlBean.getTblProcDateDdlName());
			groupByClause.append(" ), 'DD-MON-YY') ");
			groupByClause.append(" order by to_date(proc_date,'DD-MON-YY')  asc ");
		}
		
		args.add(groupByClause.toString());
		
		return args;
	}
	
	/**
	 * Method to execute statement on RABC_EXTRCT_SUMY_DATA table depending upon the condition 
	 * and returns the list of ExtrctSumyData objects.
	 * 
	 * @param conn
	 * @param failures
	 * @param condition
	 * @param selectString
	 * @param args1
	 * @param region
	 * @return List
	 */
	public List getQrySumExtrData(Connection conn, List failures, int condition, String selectString, List args1, String region){
		List extrctSumyDataList = null;
		ExtrctSumyData extrctSumyData = null;
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		String baseSQL;
		List args;

		switch (condition){
			case 1:
				baseSQL = qrySumExtrData_1b;
				args = buildCondition1Arguments(selectString, (String)args1.get(0));
				break;
			case 2:
				baseSQL =qrySumExtrData_2;
				args = buildCondition2Arguments(selectString, (String)args1.get(0));
				break;
			case 3:
				baseSQL =qrySumExtrData_3;
				args = buildCondition3Arguments(selectString, args1, region);
				break;
			case 4:
				baseSQL =qrySumExtrData_4;
				args = buildCondition4Arguments(selectString, args1, region);
				break;
			case 5:
				baseSQL =qrySumExtrData_5;
				args = buildCondition5Arguments(selectString, args1, region);
				break;
			case 6:
				baseSQL =qrySumExtrData_6;
				args = buildCondition6Arguments(selectString, args1, region);
				break;
			default:
				baseSQL =qrySumExtrData_1b;
				args = buildCondition1Arguments(selectString, (String)args1.get(0));
				break;
		}
		
		try {
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("qrySumExtrData - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			if (rs != null) {
				extrctSumyDataList = new ArrayList();
				while (rs.next()) {
					extrctSumyDataList.add(buildExtrctSumyData(rs,condition));
				}
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return null;
		} finally {
			SQLHelper.closeStatement(stmt, failures, logger);
			SQLHelper.closeResultSet(rs, failures, logger);
		}
		
		return extrctSumyDataList;
	}
	
	/**
	 * Private method to return the ExtrctSumyData object. It accepts the result set and set the
	 * attributes of ExtrctSumyData object by getting the values from the result set.
	 * 
	 * @param rs
	 * @param condition
	 * @return ExtrctSumyData
	 * @throws SQLException
	 */
	private ExtrctSumyData buildExtrctSumyData(ResultSet rs, int condition) throws SQLException {
		ExtrctSumyData extrctSumyData = new ExtrctSumyData();
		
		extrctSumyData.setSumExtrctData(rs.getDouble("sum_extrct_data"));
		
		if (condition != 5 && condition != 6){
			extrctSumyData.setSumTotalData(rs.getDouble("sum_total_data"));
		}
		
		if (this.getGraphParameters().getFileSeqNum()!=null){
			extrctSumyData.setFileSeqNum(rs.getInt("FILE_SEQ_NUM"));
		} else {
			if (condition != 1 && condition != 2){
				String procDate = rs.getString("proc_date");
				extrctSumyData.setProcDateString(procDate);
			}else if ((condition == 1 || condition == 2)&& this.isProcDateDate()==false){
				String procDate = rs.getString("proc_date");
				extrctSumyData.setProcDateString(procDate);
			}else {
				Date procDate = rs.getDate("PROC_DATE");
				if (procDate != null) {
					extrctSumyData.setProcDate(new MyDate(procDate));
				}
			}
			if (this.isAlertTrendTime()==true){
				if ("B".equals(this.getGraphParameters().getAlertTimeInd()) || "AB".equals(this.getGraphParameters().getAlertTimeInd())){
					extrctSumyData.setAlertTrendTime(rs.getString("alert_trend_time"));
				}
			}
		}
		
		return extrctSumyData;
	}
	
	/**
	 * Method invoked when the data_extrct_ind = "N". It checks whether the alert rule has some data in the 
	 * RABC_ALERT_PROC table & returns appropriate values.
	 * 
	 * @param graphParameters
	 * @param connection
	 * @param failureList
	 * @return List
	 */
	protected List checkAlertProcTbl(GraphParameters graphParameters, Connection connection, List failureList){
		AlertProcDAO alertProcDAO = new AlertProcDAO();
		List args = new ArrayList();
		args.add(graphParameters.getAlertrule());
		
		List alertProcList = alertProcDAO.get(connection,failureList, args,qryAlertProcTbl);
		
		return alertProcList;
	}
	
	/**
	 * Method invoked when the data_extrct_ind = "N". It checks whether the column exists 
	 * in RABC_DATA_TBL_DDL table.
	 * 
	 * @param alertProcTbl
	 * @param graphParameters
	 * @param region
	 * @return DataTblDdlBean
	 */
	protected DataTblDdlBean qryDataColumn(String alertProcTbl, GraphParameters graphParameters, String region){
		DataTblDdlBean dataTblDdlBean = null;
		List dataTblDdlBeanList = null;
		
		if (graphParameters.getItemDDlName()!=null){
			dataTblDdlBeanList = StaticDataLoader.getDataTblDdlByTblDdlName(alertProcTbl, graphParameters.getItemDDlName(), region);
			dataTblDdlBean = (DataTblDdlBean)dataTblDdlBeanList.get(0);
		}
		
		return dataTblDdlBean;
	}
	
	/**
	 * Method will return the table names used for each right side item
	 * @return
	 */
	protected List getTableNameList(Connection conn, String alertRule, List failures){
		Statement stmt = null;
		ResultSet rs = null;
		String sqlStmt = "";
		List args = new ArrayList();
		List tableNames = new ArrayList();
		args.add(alertRule);
		try {		
			MessageFormat mf = new MessageFormat(qryRightSideButtons);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("qryRightSideButtons - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			if (rs != null) {
				while (rs.next()) {
					tableNames.add(rs.getString(1));
				}
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return null;
		} finally {
			SQLHelper.closeStatement(stmt, failures, logger);
			SQLHelper.closeResultSet(rs, failures, logger);
		}
		
		return tableNames;
	}
	
	/**
	 * Private method to return the month for the passed proc date as parameter.
	 * 
	 * @param procDate
	 * @return String
	 */
	private String getMonth(MyDate procDate) {
		String month;
		
		String procDateString = procDate.toString();
		String procDateMonth = procDateString.substring(0,2);
		int mnth = Integer.parseInt(procDateMonth);
		
		switch (mnth){
			case 1:
				month = "1";
				break;
			case 2:
				month = "2";
				break;
			case 3:
				month = "3";
				break;
			case 4:
				month = "4";
				break;
			case 5:
				month = "5";
				break;
			case 6:
				month = "6";
				break;
			case 7:
				month = "7";
				break;
			case 8:
				month = "8";
				break;
			case 9:
				month = "9";
				break;
			case 10:
				month = "10";
				break;
			case 11:
				month = "11";
				break;
			case 12:
				month = "12";
				break;
			default:
				month = "1";
				break;
		}
		
		return month;
	}
	
}
