/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.admin.alert.rule;

import java.util.ArrayList;
import java.util.List;

import com.att.bac.rabc.PickList;

/**
 * This is a Data Object for Supplement Type.
 * 
 * @author Shashank Weginwar - SW3562
 */
public class SupplementType {
	private String alertItemName;
	private String [] selectedSupplementType;
	private List supplementTypeOptionsList;
	
	/**
	 * Default constructor
	 */
	public SupplementType(){
		this.selectedSupplementType = new String[0];
		this.supplementTypeOptionsList = new ArrayList();
	}
	
	/**
	 * @return Returns the alertItemName.
	 */
	public String getAlertItemName() {
		return alertItemName;
	}
	/**
	 * @param alertItemName The alertItemName to set.
	 */
	public void setAlertItemName(String alertItemName) {
		this.alertItemName = alertItemName;
	}
	/**
	 * @return Returns the supplementTypeList.
	 */
	public List getSupplementTypeOptionsList() {
		return supplementTypeOptionsList;
	}
	/**
	 * @param supplementTypeList The supplementTypeList to set.
	 */
	public void addSupplementTypeOption(PickList supplementTypeOption) {
		this.supplementTypeOptionsList.add(supplementTypeOption);
	}
	/**
	 * @return Returns the selectedSupplementType.
	 */
	public String[] getSelectedSupplementType() {
		return selectedSupplementType;
	}
	/**
	 * @param selectedSupplementType The selectedSupplementType to set.
	 */
	public void setSelectedSupplementType(String[] selectedSupplementType) {
		this.selectedSupplementType = selectedSupplementType;
	}
}
