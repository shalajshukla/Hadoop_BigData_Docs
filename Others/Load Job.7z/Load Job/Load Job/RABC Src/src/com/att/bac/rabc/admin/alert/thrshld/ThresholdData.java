/* Component Name: RABCPPG00520
 * Module Name: ThresholdData.java
 * Created on Feb 25, 2006
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.admin.alert.thrshld;

import java.io.Serializable;

/**This is a transfer object class for the Alert Threshold process.  The purpose of this class is to 
 * contain threshold data extracted from the AdminAlertThresholdDAO.java class that is sent back to the 
 * AdminAlertThresholdForm.java class via the AdminAlertThresholdService.java class.
 * 
 * @author js3175
 */
public class ThresholdData implements Serializable {
	private static final long serialVersionUID = 0L;
	
	private String standardHigh = "";
	private String standardMedium = "";
	private String standardLow = "";
	private String lowRangeHigh = "";
	private String lowRangeMedium = "";
	private String lowRangeLow = "";
	private String highRangeHigh = "";
	private String highRangeMedium = "";
	private String highRangeLow = "";
	private String alertMinHigh = "";
	private String alertMinMedium = "";
	private String alertMinLow = "";
	private int defaultIndicator = 0;
	private double standardDeviation = 0.0;
	private int editMode = 0;
	private int ruleDefaultMode = 0;
	private String thresholdLevel = AdminAlertThresholdForm.KEY_LEVEL;
	private int alertType = 0;
	private int thresholdFound = 1;
	private String lastUpdatedDate = "";
	
	/**
	 * @return Returns the alertMinHigh.
	 */
	public String getAlertMinHigh() {
		return alertMinHigh;
	}
	/**
	 * @param alertMinHigh The alertMinHigh to set.
	 */
	public void setAlertMinHigh(String alertMinHigh) {
		this.alertMinHigh = alertMinHigh;
	}
	/**
	 * @return Returns the alertMinLow.
	 */
	public String getAlertMinLow() {
		return alertMinLow;
	}
	/**
	 * @param alertMinLow The alertMinLow to set.
	 */
	public void setAlertMinLow(String alertMinLow) {
		this.alertMinLow = alertMinLow;
	}
	/**
	 * @return Returns the alertMinMedium.
	 */
	public String getAlertMinMedium() {
		return alertMinMedium;
	}
	/**
	 * @param alertMinMedium The alertMinMedium to set.
	 */
	public void setAlertMinMedium(String alertMinMedium) {
		this.alertMinMedium = alertMinMedium;
	}
	/**
	 * @return Returns the highRangeHigh.
	 */
	public String getHighRangeHigh() {
		return highRangeHigh;
	}
	/**
	 * @param highRangeHigh The highRangeHigh to set.
	 */
	public void setHighRangeHigh(String highRangeHigh) {
		this.highRangeHigh = highRangeHigh;
	}
	/**
	 * @return Returns the highRangeLow.
	 */
	public String getHighRangeLow() {
		return highRangeLow;
	}
	/**
	 * @param highRangeLow The highRangeLow to set.
	 */
	public void setHighRangeLow(String highRangeLow) {
		this.highRangeLow = highRangeLow;
	}
	/**
	 * @return Returns the highRangeMedium.
	 */
	public String getHighRangeMedium() {
		return highRangeMedium;
	}
	/**
	 * @param highRangeMedium The highRangeMedium to set.
	 */
	public void setHighRangeMedium(String highRangeMedium) {
		this.highRangeMedium = highRangeMedium;
	}
	/**
	 * @return Returns the lowRangeHigh.
	 */
	public String getLowRangeHigh() {
		return lowRangeHigh;
	}
	/**
	 * @param lowRangeHigh The lowRangeHigh to set.
	 */
	public void setLowRangeHigh(String lowRangeHigh) {
		this.lowRangeHigh = lowRangeHigh;
	}
	/**
	 * @return Returns the lowRangeLow.
	 */
	public String getLowRangeLow() {
		return lowRangeLow;
	}
	/**
	 * @param lowRangeLow The lowRangeLow to set.
	 */
	public void setLowRangeLow(String lowRangeLow) {
		this.lowRangeLow = lowRangeLow;
	}
	/**
	 * @return Returns the lowRangeMedium.
	 */
	public String getLowRangeMedium() {
		return lowRangeMedium;
	}
	/**
	 * @param lowRangeMedium The lowRangeMedium to set.
	 */
	public void setLowRangeMedium(String lowRangeMedium) {
		this.lowRangeMedium = lowRangeMedium;
	}
	/**
	 * @return Returns the standardHigh.
	 */
	public String getStandardHigh() {
		return standardHigh;
	}
	/**
	 * @param standardHigh The standardHigh to set.
	 */
	public void setStandardHigh(String standardHigh) {
		this.standardHigh = standardHigh;
	}
	/**
	 * @return Returns the standardLow.
	 */
	public String getStandardLow() {
		return standardLow;
	}
	/**
	 * @param standardLow The standardLow to set.
	 */
	public void setStandardLow(String standardLow) {
		this.standardLow = standardLow;
	}
	/**
	 * @return Returns the standardMedium.
	 */
	public String getStandardMedium() {
		return standardMedium;
	}
	/**
	 * @param standardMedium The standardMedium to set.
	 */
	public void setStandardMedium(String standardMedium) {
		this.standardMedium = standardMedium;
	}
	/**
	 * @return Returns the defaultIndicator.
	 */
	public int getDefaultIndicator() {
		return defaultIndicator;
	}
	/**
	 * @param defaultIndicator The defaultIndicator to set.
	 */
	public void setDefaultIndicator(int defaultIndicator) {
		this.defaultIndicator = defaultIndicator;
	}
	/**
	 * @return Returns the standardDeviation.
	 */
	public double getStandardDeviation() {
		return standardDeviation;
	}
	/**
	 * @param standardDeviation The standardDeviation to set.
	 */
	public void setStandardDeviation(double standardDeviation) {
		this.standardDeviation = standardDeviation;
	}
	/**
	 * @return Returns the editMode.
	 */
	public int getEditMode() {
		return editMode;
	}
	/**
	 * @param editMode The editMode to set.
	 */
	public void setEditMode(int editMode) {
		this.editMode = editMode;
	}
	/**
	 * @return Returns the ruleDefaultMode.
	 */
	public int getRuleDefaultMode() {
		return ruleDefaultMode;
	}
	/**
	 * @param ruleDefaultMode The ruleDefaultMode to set.
	 */
	public void setRuleDefaultMode(int ruleDefaultMode) {
		this.ruleDefaultMode = ruleDefaultMode;
	}
	/**
	 * @return Returns the thresholdLevel.
	 */
	public String getThresholdLevel() {
		return thresholdLevel;
	}
	/**
	 * @param thresholdLevel The thresholdLevel to set.
	 */
	public void setThresholdLevel(String thresholdLevel) {
		this.thresholdLevel = thresholdLevel;
	}
	/**
	 * @return Returns the alertType.
	 */
	public int getAlertType() {
		return alertType;
	}
	/**
	 * @param alertType The alertType to set.
	 */
	public void setAlertType(int alertType) {
		this.alertType = alertType;
	}
	/**
	 * @return Returns the thresholdFound.
	 */
	public int getThresholdFound() {
		return thresholdFound;
	}
	/**
	 * @param thresholdFound The thresholdFound to set.
	 */
	public void setThresholdFound(int thresholdFound) {
		this.thresholdFound = thresholdFound;
	}
	/**
	 * @return the lastUpdatedDate
	 */
	public String getLastUpdatedDate() {
		return lastUpdatedDate;
	}
	/**
	 * @param lastUpdatedDate the lastUpdatedDate to set
	 */
	public void setLastUpdatedDate(String lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}
}
