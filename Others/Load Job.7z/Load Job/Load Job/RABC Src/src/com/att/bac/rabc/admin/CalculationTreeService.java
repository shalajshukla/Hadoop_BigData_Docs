/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.admin;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.att.bac.rabc.DataTblDdlBean;
import com.att.bac.rabc.StaticDataLoader;
import com.att.bac.rabc.TreeService;

/**
 * This is Calculation Tree service class which extends Tree Service class. Class is used to generate tree on calculation 
 * page
 * 
 * @author Shailesh Hemdev - VD3159
 */
public class CalculationTreeService extends TreeService {
	private static final Logger logger = Logger.getLogger(CalculationTreeService.class);
	
	/**
	 * Returns the list of dataTblDdl.
	 * 
	 * @param dbNodeId
	 * @param region
	 * @return List
	 */
	public List getDataTblDdlList(String dbNodeId, String region){
		List dataTblDdlList = StaticDataLoader.getDataTblDdlByTblSubsysId(dbNodeId, region);
		List filteredDataTblDdlList = new ArrayList();
		
		int dataTblDdlListSize = dataTblDdlList.size();
		
		for (int i=0;i<dataTblDdlListSize;i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblDdlList.get(i);

			if ("1".equals(dataTblDdlBean.getTblDdlDataType().trim()) || "3".equals(dataTblDdlBean.getTblDdlDataType().trim())){
				filteredDataTblDdlList.add(dataTblDdlBean);
			}
		}
		
		return filteredDataTblDdlList;
		
	}
}
