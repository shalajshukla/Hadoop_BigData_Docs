/* Component Name: RABCPPG00519
 * Module Name: KeyData.java
 * Created on Feb 13, 2006
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.admin.alert.thrshld;

import java.io.Serializable;

/**This is a transfer object class for the Alert Threshold process.  The purpose of this class is to 
 * contain keys row data extracted from the AdminAlertThresholdDAO.java class that is sent back to the 
 * AdminAlertThresholdForm.java class via the AdminAlertThresholdService.java class.
 * 
 * @author js3175
 */
public class KeyData implements Serializable {
	private static final long serialVersionUID = 0L;
	
	private String dataItem = "";
	private String divisionValue = "";
	private String divisionDesc = "";
	private String [] keys = new String[0];
	private String trendTime = "";
	private String trendTimeDescription = "";
	private String userId = "";
	private String endEffectiveDate = "";
	private String timestamp = "";
	
	public KeyData (String dataItem, String divisionValue, String divisionDesc, String trendTime, String userId, String endEffDate, String timestamp) {
		this.dataItem = dataItem;
		this.divisionValue = divisionValue;
		this.divisionDesc = divisionDesc;
		this.trendTime = trendTime;
		this.userId = userId;
		this.endEffectiveDate = endEffDate;
		this.timestamp = timestamp;
	}
	
	public KeyData (String dataItem, String divisionValue, String divisionDesc, String [] keys, String trendTime, String userId, String endEffDate, String timestamp) {
		this.dataItem = dataItem;
		this.divisionValue = divisionValue;
		this.divisionDesc = divisionDesc;
		this.keys = keys;
		this.trendTime = trendTime;
		this.userId = userId;
		this.endEffectiveDate = endEffDate;
		this.timestamp = timestamp;
	}
	
	/**
	 * @return Returns the dataItem.
	 */
	public String getDataItem() {
		return dataItem;
	}
	/**
	 * @param dataItem The dataItem to set.
	 */
	public void setDataItem(String dataItem) {
		this.dataItem = dataItem;
	}
	/**
	 * @return Returns the divisionDesc.
	 */
	public String getDivisionDesc() {
		return divisionDesc;
	}
	/**
	 * @param divisionDesc The divisionDesc to set.
	 */
	public void setDivisionDesc(String divisionDesc) {
		this.divisionDesc = divisionDesc;
	}
	/**
	 * @return Returns the divisionValue.
	 */
	public String getDivisionValue() {
		return divisionValue;
	}
	/**
	 * @param divisionValue The divisionValue to set.
	 */
	public void setDivisionValue(String divisionValue) {
		this.divisionValue = divisionValue;
	}
	/**
	 * @return Returns the keys.
	 */
	public String [] getKeys() {
		return keys;
	}
	/**
	 * @return Returns the keys one at a time.
	 */
	public String getKey(int i) {
		if (keys[i] == null)
			return " ";
		else
			return keys[i];
	}
	/**
	 * @param key1 The key1 to set.
	 */
	public void setKeys(String [] keys) {
		this.keys = keys;
	}

	/**
	 * @return Returns the effectiveDate.
	 */
	public String getEndEffectiveDate() {
		return endEffectiveDate;
	}

	/**
	 * @param effectiveDate The effectiveDate to set.
	 */
	public void setEndEffectiveDate(String endEffectiveDate) {
		this.endEffectiveDate = endEffectiveDate;
	}

	/**
	 * @return Returns the timestamp.
	 */
	public String getTimestamp() {
		return timestamp;
	}

	/**
	 * @param timestamp The timestamp to set.
	 */
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	/**
	 * @return Returns the trendTime.
	 */
	public String getTrendTime() {
		return trendTime;
	}

	/**
	 * @param trendTime The trendTime to set.
	 */
	public void setTrendTime(String trendTime) {
		this.trendTime = trendTime;
	}

	/**
	 * @return Returns the userId.
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId The userId to set.
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @return Returns the trendTimeDescription.
	 */
	public String getTrendTimeDescription() {
		return trendTimeDescription;
	}

	/**
	 * @param trendTimeDescription The trendTimeDescription to set.
	 */
	public void setTrendTimeDescription(String trendTimeDescription) {
		this.trendTimeDescription = trendTimeDescription;
	}
}
