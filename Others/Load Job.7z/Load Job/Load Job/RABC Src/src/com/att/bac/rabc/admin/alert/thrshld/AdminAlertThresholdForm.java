/* Component Name: RABCPPG00518
 * Module Name: AdminAlertThresholdForm.java
 * Created on Jan 18, 2006
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.admin.alert.thrshld;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.apache.struts.Globals;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import org.apache.struts.util.MessageResources;

/**This is the struts Form class for the admin alert threshold process.  The purpose of this bean class
 * is to hold data to be presented in the web pages AdminAlertThreshold.jsp, AdminAlertThresholdKey.jsp,
 * AdminAlertThresholdDetail.jsp, & AdminAlertThresholdDelete.jsp.
 * 
 * @author js3175
 */
public class AdminAlertThresholdForm extends ActionForm {
	private static final Logger logger = Logger.getLogger(AdminAlertThresholdForm.class);
	private static final long serialVersionUID = 0L;
	
	public static String RULE_DEFAULT = "Rule";
	public static String KEY_LEVEL = "Key";
	
	public static String TRENDING_RULE = "TREND";
	public static String TRACKING_RULE = "TRACK";
	
	private String dispatch = "";
	private String typeOfUpdate = "";
	private String region = "";
	private String userId = "";
	
	//Alert Threshold Maintenance Page
	private String [] alertRules = new String[0];
	private String selectedAlertRule = "";
	private String thresholdLevel = RULE_DEFAULT;
	private int disabled = 0;
	
	//Alert Threshold Key Page
	private KeyData [] activeKeyData = new KeyData[0];
	private KeyData [] deactiveKeyData = new KeyData[0];
	private String [] keyHeaders = new String[0];
	private ArrayList dataItems = new ArrayList();
	private ArrayList divisions = new ArrayList();
	private ArrayList alertTrendTimes = new ArrayList();
	private String selectedAlertRuleDesc = "";
	private String selectedNewDataItem = "";
	private String selectedNewDivision = "";
	private String selectedNewKey2 = "";
	private String selectedNewKey3 = "";
	private String selectedNewKey4 = "";
	private String selectedNewKey5 = "";
	private String selectedNewTrendTime = "";
	private String selectedNewEndEffDate = "";
	private String selectedDataItem = "";
	private String selectedDivision = "";
	private String selectedKey2 = "";
	private String selectedKey3 = "";
	private String selectedKey4 = "";
	private String selectedKey5 = "";
	private String selectedTrendTime = "";
	private String selectedTrendTimeDesc = "";
	private String selectedEndEffDate = "";
	private String selectedUserId = "";
	private String selectedProcDate = "";
	private String selectedTimestamp = "";
	private int updatePermission = 0;
	private int alertKeyLevel = 0;
	private int divisionKeyLevel = 0;
	private int editMode = 0;
	private int ruleDefaultMode = 0;
	private String selectedAlertRuleType = "";
	private String selectedAlertTimeInd = "";
	
	//Alert Threshold Detail Page
	private ThresholdData thresholdData = new ThresholdData();
	private String lastUpdated = "";
	private int showHigh = 0;
	private int showLow = 0;
	private int alertType = 0;
	private String selectedDivisionDesc = "";
	private int popUpPage = 0;
	private double average = 0.0;
	private int thresholdFound = 1;
	
	// Variables added for calendar page
	private String procDates;
	private String billRounds;
	private String holidayIndicators;
	private String loadedDataDates;
	
	//This method is called by the container.	
	public ActionErrors validate(ActionMapping mapping, HttpServletRequest req ){
		ActionErrors errors = new ActionErrors();
		MessageResources resources = (MessageResources)req.getAttribute(Globals.MESSAGES_KEY);

		//Check for data item. If it doesn't exist goback to previous page.
		if (this.selectedAlertRule == null || this.selectedAlertRule.trim().equals("")) {
			ActionMessage error = new ActionMessage("error.admin.alert.thrshld.requiredfield", resources.getMessage("label.admin.alert.thrshld.slctdAlrtRule"));
			errors.add(ActionMessages.GLOBAL_MESSAGE, error);
		}
		logger.debug("Finished processing in AdminAlertThresholdForm.validate");
		return errors;
	}
	
	//This method is called by the container.
	public void reset(ActionMapping mapping, HttpServletRequest request) {
		logger.debug("Finished processing in AdminAlertThresholdForm.reset");
	}
	
	//Accessor methods...
	
	/**
	 * @return String loadedDataDates
	 */			
	public String getLoadedDataDates() {
		return loadedDataDates;
	}

	/**
	 * @param loadedDataDates String
	 */
	public void setLoadedDataDates(String loadedDataDates) {
		this.loadedDataDates = loadedDataDates;
	}
	
	
	/**
	 * @return Returns the dispatch.
	 */
	public String getDispatch() {
		return dispatch;
	}
	/**
	 * @param dispatch The dispatch to set.
	 */
	public void setDispatch(String dispatch) {
		this.dispatch = dispatch;
	}
	/**
	 * @return Returns the typeOfUpdate.
	 */
	public String getTypeOfUpdate() {
		return typeOfUpdate;
	}
	/**
	 * @param typeOfUpdate The typeOfUpdate to set.
	 */
	public void setTypeOfUpdate(String typeOfUpdate) {
		this.typeOfUpdate = typeOfUpdate;
	}
	/**
	 * @return Returns the region.
	 */
	public String getRegion() {
		return region;
	}
	/**
	 * @param region The region to set.
	 */
	public void setRegion(String region) {
		this.region = region;
	}
	/**
	 * @return Returns the userId.
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @param userId The userId to set.
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	/**
	 * @return Returns the alertRules.
	 */
	public String [] getAlertRules() {
		if (this.alertRules[0].trim().equals("no alert rules found")) {
			disabled = 1;
		}
		return alertRules;
	}
	/**
	 * @param alertRules The alertRules to set.
	 */
	public void setAlertRules(String [] alertRules) {
		this.alertRules = alertRules;
	}
	/**
	 * @return Returns the alertRule.
	 */
	public String getSelectedAlertRule() {
		return selectedAlertRule;
	}
	/**
	 * @param alertRule The alertRule to set.
	 */
	public void setSelectedAlertRule(String selectedAlertRule) {
		this.selectedAlertRule = selectedAlertRule;
	}
	/**
	 * @return Returns the selectedAlertRuleDesc.
	 */
	public String getSelectedAlertRuleDesc() {
		return selectedAlertRuleDesc;
	}
	/**
	 * @param selectedAlertRuleDesc The selectedAlertRuleDesc to set.
	 */
	public void setSelectedAlertRuleDesc(String selectedAlertRuleDesc) {
		this.selectedAlertRuleDesc = selectedAlertRuleDesc;
	}
	/**
	 * @return Returns the thresholdLevel.
	 */
	public String getThresholdLevel() {
		return thresholdLevel;
	}
	/**
	 * @param thresholdLevel The thresholdLevel to set.
	 */
	public void setThresholdLevel(String thresholdLevel) {
		this.thresholdLevel = thresholdLevel;
	}
	/**
	 * @return Returns the alertKeyLevel.
	 */
	public int getAlertKeyLevel() {
		return alertKeyLevel;
	}
	/**
	 * @param alertKeyLevel The alertKeyLevel to set.
	 */
	public void setAlertKeyLevel(int alertKeyLevel) {
		this.alertKeyLevel = alertKeyLevel;
	}
	/**
	 * @return Returns the divisionKeyLevel.
	 */
	public int getDivisionKeyLevel() {
		return divisionKeyLevel;
	}
	/**
	 * @param divisionKeyLevel The divisionKeyLevel to set.
	 */
	public void setDivisionKeyLevel(int divisionKeyLevel) {
		this.divisionKeyLevel = divisionKeyLevel;
	}
	/**
	 * @return Returns the defaultData.
	 */
	public ThresholdData getThresholdData() {
		return thresholdData;
	}
	/**
	 * @param defaultData The defaultData to set.
	 */
	public void setThresholdData(ThresholdData thresholdData) {
		this.thresholdData = thresholdData;
	}
	/**
	 * @return Returns the activeKeyData array.
	 */
	public KeyData [] getActiveKeyData() {
		return activeKeyData;
	}
	/**
	 * @return Returns one row of the activeKeyData array.
	 */
	public KeyData getActiveKeyData(int i) {
		return activeKeyData[i];
	}
	/**
	 * @param activeKeyData The activeKeyData array to set.
	 */
	public void setActiveKeyData(KeyData [] activeKeyData) {
		this.activeKeyData = activeKeyData;
	}
	/**
	 * @return Returns the deactiveKeyData array.
	 */
	public KeyData [] getDeactiveKeyData() {
		return deactiveKeyData;
	}
	/**
	 * @return Returns one row of the deactiveKeyData array.
	 */
	public KeyData getDeactiveKeyData(int i) {
		return deactiveKeyData[i];
	}
	/**
	 * @param keyData The deactiveKeyData array to set.
	 */
	public void setDeactiveKeyData(KeyData [] deactiveKeyData) {
		this.deactiveKeyData = deactiveKeyData;
	}
	/**
	 * @return Returns the dataItems.
	 */
	public ArrayList getDataItems() {
		return dataItems;
	}
	/**
	 * @param dataItems The dataItems to set.
	 */
	public void setDataItems(ArrayList dataItems) {
		this.dataItems = dataItems;
	}
	/**
	 * @param dataItems The dataItems to set one at a time.
	 */
	public void setDataItem(String dataItem) {
		this.dataItems.add(dataItem);
	}
	/**
	 * @return Returns the divisions.
	 */
	public ArrayList getDivisions() {
		return divisions;
	}
	/**
	 * @param divisions The divisions to set.
	 */
	public void setDivisions(ArrayList divisions) {
		this.divisions = divisions;
	}
	/**
	 * @return Returns the selectedDataItem.
	 */
	public String getSelectedDataItem() {
		return selectedDataItem;
	}
	/**
	 * @param selectedDataItem The selectedDataItem to set.
	 */
	public void setSelectedDataItem(String selectedDataItem) {
		this.selectedDataItem = selectedDataItem;
	}
	/**
	 * @return Returns the selectedDivision.
	 */
	public String getSelectedDivision() {
		return selectedDivision;
	}
	/**
	 * @param selectedDivision The selectedDivision to set.
	 */
	public void setSelectedDivision(String selectedDivision) {
		this.selectedDivision = selectedDivision;
	}
	/**
	 * @return Returns the selectedKey2.
	 */
	public String getSelectedKey2() {
		return selectedKey2;
	}
	/**
	 * @param selectedKey2 The selectedKey2 to set.
	 */
	public void setSelectedKey2(String selectedKey2) {
		this.selectedKey2 = selectedKey2;
	}
	/**
	 * @return Returns the selectedKey3.
	 */
	public String getSelectedKey3() {
		return selectedKey3;
	}
	/**
	 * @param selectedKey3 The selectedKey3 to set.
	 */
	public void setSelectedKey3(String selectedKey3) {
		this.selectedKey3 = selectedKey3;
	}
	/**
	 * @return Returns the selectedKey4.
	 */
	public String getSelectedKey4() {
		return selectedKey4;
	}
	/**
	 * @param selectedKey4 The selectedKey4 to set.
	 */
	public void setSelectedKey4(String selectedKey4) {
		this.selectedKey4 = selectedKey4;
	}
	/**
	 * @return Returns the selectedKey5.
	 */
	public String getSelectedKey5() {
		return selectedKey5;
	}
	/**
	 * @param selectedKey5 The selectedKey5 to set.
	 */
	public void setSelectedKey5(String selectedKey5) {
		this.selectedKey5 = selectedKey5;
	}
	/**
	 * @return Returns the lastUpdated.
	 */
	public String getLastUpdated() {
		return lastUpdated;
	}
	/**
	 * @param lastUpdated The lastUpdated to set.
	 */
	public void setLastUpdated(String lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
	/**
	 * @return Returns the showHigh.
	 */
	public int getShowHigh() {
		return showHigh;
	}
	/**
	 * @param showHigh The showHigh to set.
	 */
	public void setShowHigh(int showHigh) {
		this.showHigh = showHigh;
	}
	/**
	 * @return Returns the showLow.
	 */
	public int getShowLow() {
		return showLow;
	}
	/**
	 * @param showLow The showLow to set.
	 */
	public void setShowLow(int showLow) {
		this.showLow = showLow;
	}
	/**
	 * @return Returns the editMode.
	 */
	public int getEditMode() {
		return editMode;
	}
	/**
	 * @param editMode The editMode to set.
	 */
	public void setEditMode(int editMode) {
		this.editMode = editMode;
	}
	/**
	 * @return Returns the ruleDefaultMode.
	 */
	public int getRuleDefaultMode() {
		return ruleDefaultMode;
	}
	/**
	 * @param ruleDefaultMode The ruleDefaultMode to set.
	 */
	public void setRuleDefaultMode(int ruleDefaultMode) {
		this.ruleDefaultMode = ruleDefaultMode;
	}
	/**
	 * @return Returns the alertType.
	 */
	public int getAlertType() {
		return alertType;
	}
	/**
	 * @param alertType The alertType to set.
	 */
	public void setAlertType(int alertType) {
		this.alertType = alertType;
	}
	/**
	 * @return Returns the selectedNewDataItem.
	 */
	public String getSelectedNewDataItem() {
		return selectedNewDataItem;
	}
	/**
	 * @param selectedNewDataItem The selectedNewDataItem to set.
	 */
	public void setSelectedNewDataItem(String selectedNewDataItem) {
		this.selectedNewDataItem = selectedNewDataItem;
	}
	/**
	 * @return Returns the selectedNewDivision.
	 */
	public String getSelectedNewDivision() {
		return selectedNewDivision;
	}
	/**
	 * @param selectedNewDivision The selectedNewDivision to set.
	 */
	public void setSelectedNewDivision(String selectedNewDivision) {
		this.selectedNewDivision = selectedNewDivision;
	}
	/**
	 * @return Returns the selectedNewKey2.
	 */
	public String getSelectedNewKey2() {
		return selectedNewKey2;
	}
	/**
	 * @param selectedNewKey2 The selectedNewKey2 to set.
	 */
	public void setSelectedNewKey2(String selectedNewKey2) {
		this.selectedNewKey2 = selectedNewKey2;
	}
	/**
	 * @return Returns the selectedNewKey3.
	 */
	public String getSelectedNewKey3() {
		return selectedNewKey3;
	}
	/**
	 * @param selectedNewKey3 The selectedNewKey3 to set.
	 */
	public void setSelectedNewKey3(String selectedNewKey3) {
		this.selectedNewKey3 = selectedNewKey3;
	}
	/**
	 * @return Returns the selectedNewKey4.
	 */
	public String getSelectedNewKey4() {
		return selectedNewKey4;
	}
	/**
	 * @param selectedNewKey4 The selectedNewKey4 to set.
	 */
	public void setSelectedNewKey4(String selectedNewKey4) {
		this.selectedNewKey4 = selectedNewKey4;
	}
	/**
	 * @return Returns the selectedNewKey5.
	 */
	public String getSelectedNewKey5() {
		return selectedNewKey5;
	}
	/**
	 * @param selectedNewKey5 The selectedNewKey5 to set.
	 */
	public void setSelectedNewKey5(String selectedNewKey5) {
		this.selectedNewKey5 = selectedNewKey5;
	}
	/**
	 * @return Returns the disabled.
	 */
	public int getDisabled() {
		return disabled;
	}
	/**
	 * @param disabled The disabled to set.
	 */
	public void setDisabled(int disabled) {
		this.disabled = disabled;
	}
	/**
	 * @return Returns the keyHeaders.
	 */
	public String[] getKeyHeaders() {
		return keyHeaders;
	}
	/**
	 * @return Returns the keyHeaders one at a time.
	 */
	public String getKeyHeader(int i) {
		return keyHeaders[i];
	}
	/**
	 * @param keyHeaders The keyHeaders to set.
	 */
	public void setKeyHeaders(String[] keyHeaders) {
		this.keyHeaders = keyHeaders;
	}
	/**
	 * @param keyHeaders The keyHeaders to set one at a time.
	 */
	public void setKeyHeader(int i, String keyHeader) {
		this.keyHeaders[i] = keyHeader;
	}
	/**
	 * @return Returns the updatePermission.
	 */
	public int getUpdatePermission() {
		return updatePermission;
	}
	/**
	 * @param updatePermission The updatePermission to set.
	 */
	public void setUpdatePermission(int updatePermission) {
		this.updatePermission = updatePermission;
	}
	/**
	 * @return Returns the selectedDivisionDesc.
	 */
	public String getSelectedDivisionDesc() {
		return selectedDivisionDesc;
	}
	/**
	 * @param selectedDivisionDesc The selectedDivisionDesc to set.
	 */
	public void setSelectedDivisionDesc(String selectedDivisionDesc) {
		this.selectedDivisionDesc = selectedDivisionDesc;
	}

	/**
	 * @return Returns the alertRuleType.
	 */
	public String getSelectedAlertRuleType() {
		return selectedAlertRuleType;
	}

	/**
	 * @param alertRuleType The alertRuleType to set.
	 */
	public void setSelectedAlertRuleType(String selectedAlertRuleType) {
		this.selectedAlertRuleType = selectedAlertRuleType;
	}

	/**
	 * @return Returns the selectedEndEffDate.
	 */
	public String getSelectedEndEffDate() {
		return selectedEndEffDate;
	}

	/**
	 * @param selectedEndEffDate The selectedEndEffDate to set.
	 */
	public void setSelectedEndEffDate(String selectedEffDate) {
		this.selectedEndEffDate = selectedEffDate;
	}

	/**
	 * @return Returns the selectedNewEndEffDate.
	 */
	public String getSelectedNewEndEffDate() {
		return selectedNewEndEffDate;
	}

	/**
	 * @param selectedNewEndEffDate The selectedNewEndEffDate to set.
	 */
	public void setSelectedNewEndEffDate(String selectedNewEffDate) {
		this.selectedNewEndEffDate = selectedNewEffDate;
	}

	/**
	 * @return Returns the selectedNewTrendTime.
	 */
	public String getSelectedNewTrendTime() {
		return selectedNewTrendTime;
	}

	/**
	 * @param selectedNewTrendTime The selectedNewTrendTime to set.
	 */
	public void setSelectedNewTrendTime(String selectedNewTrendTime) {
		this.selectedNewTrendTime = selectedNewTrendTime;
	}

	/**
	 * @return Returns the selectedTrendTime.
	 */
	public String getSelectedTrendTime() {
		return selectedTrendTime;
	}

	/**
	 * @param selectedTrendTime The selectedTrendTime to set.
	 */
	public void setSelectedTrendTime(String selectedTrendTime) {
		this.selectedTrendTime = selectedTrendTime;
	}

	/**
	 * @return Returns the alertTrendTimes.
	 */
	public ArrayList getAlertTrendTimes() {
		return alertTrendTimes;
	}

	/**
	 * @param alertTrendTimes The alertTrendTimes to set.
	 */
	public void setAlertTrendTimes(ArrayList alertTrendTimes) {
		this.alertTrendTimes = alertTrendTimes;
	}

	/**
	 * @return Returns the selectedAlertTimeInd.
	 */
	public String getSelectedAlertTimeInd() {
		return selectedAlertTimeInd;
	}

	/**
	 * @param selectedAlertTimeInd The selectedAlertTimeInd to set.
	 */
	public void setSelectedAlertTimeInd(String selectedAlertTimeInd) {
		this.selectedAlertTimeInd = selectedAlertTimeInd;
	}

	/**
	 * @return Returns the popUpPage.
	 */
	public int getPopUpPage() {
		return popUpPage;
	}

	/**
	 * @param popUpPage The popUpPage to set.
	 */
	public void setPopUpPage(int popUpPage) {
		this.popUpPage = popUpPage;
	}

	/**
	 * @return Returns the average.
	 */
	public double getAverage() {
		return average;
	}

	/**
	 * @param average The average to set.
	 */
	public void setAverage(double average) {
		this.average = average;
	}

	/**
	 * @return Returns the selectedTrendTimeDesc.
	 */
	public String getSelectedTrendTimeDesc() {
		return selectedTrendTimeDesc;
	}

	/**
	 * @param selectedTrendTimeDesc The selectedTrendTimeDesc to set.
	 */
	public void setSelectedTrendTimeDesc(String selectedTrendTimeDesc) {
		this.selectedTrendTimeDesc = selectedTrendTimeDesc;
	}

	/**
	 * @return Returns the selectedTimestamp.
	 */
	public String getSelectedTimestamp() {
		return selectedTimestamp;
	}

	/**
	 * @param selectedTimestamp The selectedTimestamp to set.
	 */
	public void setSelectedTimestamp(String selectedTimestamp) {
		this.selectedTimestamp = selectedTimestamp;
	}

	/**
	 * @return Returns the selectedUserId.
	 */
	public String getSelectedUserId() {
		return selectedUserId;
	}

	/**
	 * @param selectedUserId The selectedUserId to set.
	 */
	public void setSelectedUserId(String selectedUserId) {
		this.selectedUserId = selectedUserId;
	}
	
	/**
	 * @return Returns the thresholdFound.
	 */
	public int getThresholdFound() {
		return thresholdFound;
	}

	/**
	 * @param thresholdFound The thresholdFound to set.
	 */
	public void setThresholdFound(int thresholdFound) {
		this.thresholdFound = thresholdFound;
	}

	/**
	 * @return billRound
	 */
	public String getBillRounds() {
		return billRounds;
	}

	/**
	 * Set Bill Round
	 * @param billRounds
	 */
	public void setBillRounds(String billRounds) {
		this.billRounds = billRounds;
	}

	/**
	 * @return holidayIndicators
	 */
	public String getHolidayIndicators() {
		return holidayIndicators;
	}

	/**
	 * Set holidayIndicators
	 * @param holidayIndicators
	 */
	public void setHolidayIndicators(String holidayIndicators) {
		this.holidayIndicators = holidayIndicators;
	}

	/**
	 * @return prodDates
	 */
	public String getProcDates() {
		return procDates;
	}

	/**
	 * @param procDates 
	 */
	public void setProcDates(String procDates) {
		this.procDates = procDates;
	}

	/**
	 * @return selectedProcDate
	 */
	public String getSelectedProcDate() {
		return selectedProcDate;
	}

	/**
	 * @param selectedProcDate
	 */
	public void setSelectedProcDate(String selectedProcDate) {
		this.selectedProcDate = selectedProcDate;
	}

}
