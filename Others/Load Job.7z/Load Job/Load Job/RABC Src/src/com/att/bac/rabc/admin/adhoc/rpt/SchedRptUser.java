/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.admin.adhoc.rpt;

/**
 * This is a Data Object to represent RABC_SCHED_RPT_USER table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class SchedRptUser {
	private int presnId;
	private int schedRptNum;
	private String userId;

	/**
	 * @return Returns the PresnId.
	 */
	public int getPresnId() {
		return presnId;
	}
	/**
	 * @return Returns the SchedRptNum.
	 */
	public int getSchedRptNum() {
		return schedRptNum;
	}
	/**
	 * @return Returns the UserId.
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param PresnId The presnId to set.
	 */
	public void setPresnId(int presnId) {
		this.presnId = presnId;
	}
	/**
	 * @param SchedRptNum The schedRptNum to set.
	 */
	public void setSchedRptNum(int schedRptNum) {
		this.schedRptNum = schedRptNum;
	}
	/**
	 * @param UserId The userId to set.
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
}
