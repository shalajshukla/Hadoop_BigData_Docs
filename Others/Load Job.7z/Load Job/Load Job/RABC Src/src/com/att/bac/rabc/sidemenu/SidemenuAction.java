/* Component Name: RABCPPG00534
 * Module Name: SidemenuAction.java
 * Created on Jan 12, 2006
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.sidemenu;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

/**This is the struts Action class for the Side Menu process.    The purpose of this bean class is to populate data
 * in the SidemenuForm.java class then direct this data to either page 11, page 13, or to the error page.
 * 
 * @author pt6471
 */
public class SidemenuAction extends Action {
    private static Logger logger = Logger.getLogger(SidemenuAction.class);
    
	/**This is the only method of this Action class.  Its purpose is to populate the struts Form bean then
	 * direct that data to the appropriate page.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of AdminAlertThresholdForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return newActionForward  the ActionForward object returned to the struts framework when
	 *                           clicking on the tree.
	 * @return result  the ActionForward object returned for the error page.
	 */
    public ActionForward execute (ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
    	logger.debug("Starting SidemenuAction.execute()...");
    	ActionForward result = mapping.findForward("error");
    	SidemenuForm sidemenuForm = (SidemenuForm)form;
    	sidemenuForm.setRegion((String)request.getSession().getAttribute("region"));
    	sidemenuForm.setUserId((String)request.getSession().getAttribute("bacUserID"));
    	
        if (sidemenuForm.getTreeid() == null || sidemenuForm.getTreeid().equals("")){
        	sidemenuForm.setTreeid("0");
        }
    	if (sidemenuForm.getForwardTo() == null || sidemenuForm.getForwardTo().equals("")){
    		logger.debug("Finished SidemenuAction.execute(), forward to error.");
    		return result;
    	} else if (sidemenuForm.getForwardTo().equals("AdhocRpt.do")){
        	ActionForward actionForward = mapping.findForward("adHocRpt");
        	ActionForward newActionForward = new ActionForward("AdhocRpt.do","/", true);
        	String link = "?presnIdAsString=" + sidemenuForm.getPresnIdAsString();
        	link += "&procDate=" + sidemenuForm.getProcDate();
        	if (sidemenuForm.getSelectedDivision() != null && sidemenuForm.getSelectedDivision() != "")
    			link += "&divisionName=" + sidemenuForm.getSelectedDivision();
    		else
    			link += "&divisionName=";
    		if (sidemenuForm.getStartDate() == null || sidemenuForm.getStartDate().equals("")){
    			link += "&startDate=" + sidemenuForm.getProcDate();	
    			sidemenuForm.setStartDate(sidemenuForm.getProcDate());
    		} else 
    			link += "&startDate=" + sidemenuForm.getStartDate();
    		if (sidemenuForm.getEndDate() == null || sidemenuForm.getEndDate().equals("")){
    			link += "&endDate=" + sidemenuForm.getProcDate();
    			sidemenuForm.setEndDate(sidemenuForm.getProcDate());
    		} else 
    			link += "&endDate=" + sidemenuForm.getEndDate();
        	newActionForward.setPath(actionForward.getPath() + link);
        	logger.debug("Finished SidemenuAction.execute(), forward to AdhocRpt.do.");
       		return newActionForward;
    	} else if (sidemenuForm.getForwardTo().equals("AlertTrckMainPage.do")){
    		ActionForward actionForward = mapping.findForward("alertTrackMain");
    		ActionForward newActionForward = new ActionForward("AlertTrckMainPage.do","/", true);
    		String link = "?presnIDSelect="  + sidemenuForm.getPresnIDSelect();
    		link += "&alertRuleSelect=" + sidemenuForm.getAlertRuleSelect();
    		link += "&procDate=" + sidemenuForm.getProcDate();
    		if (sidemenuForm.getSelectedDivision() != null && sidemenuForm.getSelectedDivision() != "")
    			link += "&divisionName=" + sidemenuForm.getSelectedDivision();
    		else
    			link += "&divisionName=";
    		if (sidemenuForm.getCntrlPtCd() != null && sidemenuForm.getCntrlPtCd() != "")
    			link += "&cntrlPtCd=" + sidemenuForm.getCntrlPtCd();
    		if (sidemenuForm.getStartDate() == null || sidemenuForm.getStartDate().equals("")){
    			link += "&startDate=" + sidemenuForm.getProcDate();	
    			sidemenuForm.setStartDate(sidemenuForm.getProcDate());
    		} else 
    			link += "&startDate=" + sidemenuForm.getStartDate();
    		if (sidemenuForm.getEndDate() == null || sidemenuForm.getEndDate().equals("")){
    			link += "&endDate=" + sidemenuForm.getProcDate();
    			sidemenuForm.setEndDate(sidemenuForm.getProcDate());
    		} else 
    			link += "&endDate=" + sidemenuForm.getEndDate();
    		newActionForward.setPath(actionForward.getPath() + link);
    		logger.debug("Finished SidemenuAction.execute(), forward to AlertTrckMainPage.do.");
    		return newActionForward;
    	} else if (sidemenuForm.getForwardTo().equals("fromAuth")){
    		ActionForward actionForward = null;
    		String newAction = "";
    		String newUrl = "";
    		if ("EN".equals(sidemenuForm.getRegion())){
    			newAction = "CntrlPtCert.do";
    			newUrl = "/CntrlPtCert.do?";
    		} else {
    			newAction = "AlertDashboard.do";
    			newUrl = "/AlertDashboard.do?";
    		}
    		
    		// Pass the parameters obtained from request
    		Enumeration e = request.getParameterNames();
    		while (e.hasMoreElements()){
    			String paramName = (String)e.nextElement();
				String paramValue = request.getParameter(paramName);
				newUrl += paramName + "=" + paramValue + "&";
    		}
    		
    		actionForward = new ActionForward(newAction,newUrl, true);
    		return actionForward;
    	} else {
    		ActionForward actionForward = new ActionForward(sidemenuForm.getForwardTo(),"/" + sidemenuForm.getForwardTo(), true);
    		return actionForward;
    	}
    }
}
