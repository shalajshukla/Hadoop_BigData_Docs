/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc;

import java.util.ArrayList;
import java.util.List;

import org.apache.struts.action.ActionForm;

import com.att.bac.rabc.admin.AlertGroup;

/**
 * This is an action form to represent the email user's selection page.
 * 
 * @author Vijay Dubey - VD3159
 */
public class EmailUserForm extends ActionForm {
	private String dispatch;
	private String alertGroup;
	private List alertGroupList = new ArrayList();
	private List userList = new ArrayList();
	private String selectedUsers;
	private String parentForm;
	private String senderUserName;
	private String senderEmailAddress;
	private String errorDetails;
	
	/**
	 * @return Returns the alertGroup.
	 */
	public String getAlertGroup() {
		return alertGroup;
	}
	/**
	 * @param alertGroup The alertGroup to set.
	 */
	public void setAlertGroup(String alertGroup) {
		this.alertGroup = alertGroup;
	}
	/**
	 * @return Returns the alertGroupList.
	 */
	public List getAlertGroupList() {
		return alertGroupList;
	}
	/**
	 * @param alertGroup The alertGroup to add.
	 */
	public void addAlertGroup(AlertGroup alertGroup) {
		this.alertGroupList.add(alertGroup);
	}
	/**
	 * @return Returns the dispatch.
	 */
	public String getDispatch() {
		return dispatch;
	}
	/**
	 * @param dispatch The dispatch to set.
	 */
	public void setDispatch(String dispatch) {
		this.dispatch = dispatch;
	}
	/**
	 * @return Returns the selectedUsers.
	 */
	public String getSelectedUsers() {
		return selectedUsers;
	}
	/**
	 * @param selectedUsers The selectedUsers to set.
	 */
	public void setSelectedUsers(String selectedUsers) {
		this.selectedUsers = selectedUsers;
	}
	/**
	 * @return Returns the userList.
	 */
	public List getUserList() {
		return userList;
	}
	/**
	 * @param user The user to add.
	 */
	public void addUser(PickList user) {
		this.userList.add(user);
	}
	/**
	 * @return Returns the parentForm.
	 */
	public String getParentForm() {
		return parentForm;
	}
	/**
	 * @param parentForm The parentForm to set.
	 */
	public void setParentForm(String parentForm) {
		this.parentForm = parentForm;
	}
	/**
	 * @return Returns the errorDetails.
	 */
	public String getErrorDetails() {
		return errorDetails;
	}
	/**
	 * @param errorDetails The errorDetails to set.
	 */
	public void setErrorDetails(String errorDetails) {
		this.errorDetails = errorDetails;
	}
	/**
	 * @return Returns the senderEmailAddress.
	 */
	public String getSenderEmailAddress() {
		return senderEmailAddress;
	}
	/**
	 * @param senderEmailAddress The senderEmailAddress to set.
	 */
	public void setSenderEmailAddress(String senderEmailAddress) {
		this.senderEmailAddress = senderEmailAddress;
	}
	/**
	 * @return Returns the senderUserName.
	 */
	public String getSenderUserName() {
		return senderUserName;
	}
	/**
	 * @param senderUserName The senderUserName to set.
	 */
	public void setSenderUserName(String senderUserName) {
		this.senderUserName = senderUserName;
	}
}
