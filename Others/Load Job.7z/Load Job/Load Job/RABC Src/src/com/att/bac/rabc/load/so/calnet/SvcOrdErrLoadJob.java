/* Created by Gaurav Bhargava (GB0741) on Dec 8, 2006.
Copyright 2006-2008 AT&T Knowledge Ventures. All rights reserved. */

package com.att.bac.rabc.load.so.calnet;

import java.io.File;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import com.att.bac.rabc.load.calnet.CalnetException;
import com.att.bac.rabc.load.calnet.CalnetLoadJob;
import com.att.bac.rabc.util.EmcisEventLogger;
import com.att.carat.util.NetUtil;
import com.sbc.bac.rabc.load.StaticErrorMsgKeys;

/**
 * This class reads the data from files whose name fits the pattern:
 * WE.[CI].C[0-9]{4}.XT33SODE.* . It gets the files from input folder name specified
 * in ErredSO.cfg file. It parses the file line by line and inserts the records into
 * the RABC_SVC_ORD_ERR table.
 * @author GB0741
 */
public class SvcOrdErrLoadJob extends CalnetLoadJob {

	List rabcSvcOrdErr = null;
	private String fileName, region;

	/**
	 * @return ID of the file being processed
	 */
	public String getFileId() {
		return "XT33SODE";
	}

	/**
	 * @return Table Name for inserting the records.
	 */
	public String getTable() {
		return "RABC_SVC_ORD_ERR";
	}

	/**
	 * Initiailizes the list to hold data transfer objects. It parses the filename to
	 * set the values for region, division, cycle, run date, bill round date and
	 * bill round.
	 * @param file object representing the file to be processed
	 */
	public boolean preprocessFile(File file){
		fileName = file.getName();
		region   =	file.getName().substring(0,2);
		rabcSvcOrdErr = new ArrayList();
		return super.preprocessFile(file);
	}

	/**
	 * Processes a single record from the load file. A line contains fields that are
	 * semicolon delimited in the format: <FileId>;<AgencyId>;<ErrorCode>;<ErrorCount>
	 *
	 * @param line record from load file
	 * @return int indicating the return status as Success or Error
	 * @throws Exception Throws exception if there is an error in parsing the fields.
	 */
	protected int processRecord(String line) throws Exception {
		int success;

		RabcSvcOrdErr rabcSvcErr = new RabcSvcOrdErr();
		try{
			String[] tokens = line.split(";");

			rabcSvcErr.setRunDate(sqlRunDate);
			rabcSvcErr.setDivision(division);
			rabcSvcErr.setCycle(cycle);
			rabcSvcErr.setAgencyID(tokens[1].trim());
			rabcSvcErr.setErrorCd(tokens[2].trim());
			rabcSvcErr.setErrorCt(Integer.parseInt(tokens[3].trim()));
			rabcSvcOrdErr.add(rabcSvcErr);
			lineCount++;
			success = SUCCESS;
		}catch(Exception ex){
			severe(StaticErrorMsgKeys.PARSELINE_ERROR + " AgencyID " + rabcSvcErr.getAgencyID() + ex.getMessage(), ex);
			success = ERROR;
		}
	return success;
}

	/**
	 * Inserts the processed data into RABC_SVC_ORD_ERR table.
	 * Calls postprocessFile method of base class in the end.
	 * @param file object representing load file
	 * @param success boolean indicating success or failure of previous action
	 * @return boolean indicating success or failure
	 */
	public boolean postprocessFile(File file, boolean success) {
		try{
			//Log the file information to EMCIS_EVENT_LOG and EMCIS_EVENT_LOG_DETAIL
			EmcisEventLogger emcisLogger = new EmcisEventLogger();
			String event_id = "RABC_"+getFileId()+"_"+region;
            String host = NetUtil.getLocalHostName();
            String hostIP = NetUtil.getLocalIpAddress();
			int sequence = emcisLogger.getEMCISSequence(connection);
			emcisLogger.insertEventLog(connection, sequence, event_id, sqlRunDate, host, hostIP);
			emcisLogger.insertEventLogDetail(connection, sequence, "FileName", fileName);
			
		}catch (UnknownHostException e) {
            severe("Error getting EMCIS host information ", e);
        }
		if(success){
			RabcSvcOrdErrDAO dao = new RabcSvcOrdErrDAO();
			try{
				success = dao.insertBatchOfRecords(connection, rabcSvcOrdErr, 1000);
			}catch(CalnetException ex){
				severe(ex.getMessage(), ex);
				success = false;
			}
		}
		rabcSvcOrdErr = null;
		return super.postprocessFile(file, success);
	}
}
