/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/

package com.att.bac.rabc.alerts.dashboard;

import com.att.bac.rabc.MyDate;

/**
 * This class represents the data object that holds the attributes required
 * to represent the file date wise count in case of file date. 
 * 
 * @author Vijay Dubey - VD3159
 */
public class FileDateWiseAlertSummary {
	private MyDate procDate;
	private int count;
	
	/**
	 * @return Returns the count.
	 */
	public int getCount() {
		return count;
	}
	/**
	 * @param count The count to set.
	 */
	public void setCount(int count) {
		this.count = count;
	}
	/**
	 * @return Returns the procDate.
	 */
	public MyDate getProcDate() {
		return procDate;
	}
	/**
	 * @param procDate The procDate to set.
	 */
	public void setProcDate(MyDate procDate) {
		this.procDate = procDate;
	}
}
