/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.rpt;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.att.bac.rabc.ExcelReport;
import com.att.bac.rabc.ProgressBar;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;

/**
 * This class represents the Service which handles processing of 
 * various request for AlertsReportDataService (page 12).
 * 
 * @author Nalina Pandiyan - NP5434
 */
public class AlertsReportDataService {
	private static final Logger logger = Logger.getLogger(AlertsReportDataService.class);

	private List columns = new ArrayList();
	private List qryGetDataList = new ArrayList();
	private List qryKeyColList = new ArrayList();
	private List qryAlertRulePresnElemList = new ArrayList();
	private AlertReportParameters alertReportParameters = null;
	private Connection connection = null;
	private List failureList = null;
	
	private AlertsReportDataSQLService alertsReportDataSQLService = null;
	private AlertsReportDataViewService alertsReportDataViewService = null;
	private AlertReportView alertReportView = null;
	private AlertsGenFilterTemplate alertsGenFilterTemplate = null;
	private AlertsLinkTemplateActionService alertsLinkTemplateActionService = null;

	/**
	 * This method is used to return the object of AlertsReportDataService class.
	 * 
	 * @return AlertsReportDataService
	 */
	public static AlertsReportDataService getAlertsReportDataService() {
		return new AlertsReportDataService();
	}

	/**
	 * Method which sets the alertsReportDataSQLService, alertsReportDataViewService,
	 * alertsGenFilterTemplate.
	 * 
	 */
	public AlertsReportDataService() {
		alertReportView = new AlertReportView();
		
		this.alertsReportDataSQLService = AlertsReportDataSQLService.getAlertsReportDataSQLService();
		this.alertsReportDataViewService = AlertsReportDataViewService.getAlertsReportDataViewService();
		this.alertsGenFilterTemplate = AlertsGenFilterTemplate.getAlertsGenFilterTemplate();		
	}

	/**
	 * This method initializes Alert Data Parameters to process view request.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertReportParameters
	 * @param progressBar
	 * @return AlertReportView
	 */
	public AlertReportView processViewRequest(Connection connection, List failures, AlertReportParameters alertReportParameters, ProgressBar progressBar) {
		int nbrOfRows = 0;
		logger.debug("Initializing Alert Data Parameters.");
		if (!init(connection, failures, alertReportParameters)) return alertReportView;
		progressBar.setProgressPercent(20);
		nbrOfRows = processAlertDataRequest(progressBar); 
		alertsGenFilterTemplate.addStandardButtons();
		alertsGenFilterTemplate.setHeaderText(alertReportParameters.getRegion());		
		//alertsGenFilterTemplate.processViewSize(nbrOfRows);
		return alertReportView;
	}

	/**
	 * This method initializes Alert Data Parameters to process create report request.
	 * 
	 * @param connection
	 * @param failureList
	 * @param alertReportParameters
	 * @param report
	 * @param progressBar
	 * @return AlertReportView
	 */
	public AlertReportView processCreateReportRequest(Connection connection, List failureList, AlertReportParameters alertReportParameters, ExcelReport report, ProgressBar progressBar) {
		if (!init(connection, failureList, alertReportParameters)) return alertReportView;
		if (!initAdditional(connection, failureList, alertReportParameters)) return alertReportView;
		processAlertDataRequest(progressBar); 
		alertsGenFilterTemplate.addStandardButtons();
		alertsGenFilterTemplate.setHeaderText(alertReportParameters.getRegion());		
		alertsLinkTemplateActionService.prepareExcelReport(alertReportView, report);		
		return alertReportView;
	}
	
	/**
	 * This method to get Alert Rule details from RABC_ALERT_RULE & RABC_PRESN_ID tables. 
	 * It processes AlertDataRequest.
	 * 
	 * @param progressBar
	 * @return int
	 */
	public int processAlertDataRequest(ProgressBar progressBar) {
		/*
		 * Getting Alert Rule details from RABC_ALERT_RULE & RABC_PRESN_ID tables.
		 */
		alertsReportDataSQLService.getAlertRuleInfo();
		if (!failureList.isEmpty()) return 0;
		
		updateAlertDataParameters(alertReportParameters);
		progressBar.setProgressPercent(30);
		
		alertsReportDataSQLService.executeQrySumyPresnRules();
		if (!failureList.isEmpty()) return 0;
		progressBar.setProgressPercent(40);
		
		// execute qryAlertRulePresnElem, compute totCnt, seqCnt, build qryKeyCol, uniqueTables, UniquePresnIDs
		alertsReportDataSQLService.executeQryAlertRulePresnElem();
		if (!failureList.isEmpty()) return 0;
		progressBar.setProgressPercent(50);

		// Loop through qryKeyCol to identify unique key columns
		alertsReportDataSQLService.processQryKeyCol();
		progressBar.setProgressPercent(60);
		alertsReportDataViewService.addStandardColumns();
		alertsReportDataSQLService.processDataColumns();
		if (!failureList.isEmpty()) return 0;
		progressBar.setProgressPercent(70);

		if(!qryAlertRulePresnElemList.isEmpty()){
			alertsReportDataSQLService.buildDynamicQueries();
			if (!failureList.isEmpty()) return 0;
			alertsReportDataSQLService.executeQryGetData();
		}		
		
		alertsGenFilterTemplate.setGeneralFilter();
		progressBar.setProgressPercent(80);

		if (!qryGetDataList.isEmpty()) {
			alertReportParameters.setDataPresent("Y");
			return alertsReportDataViewService.prepareAlertReportView();
			
		} else {
			alertReportParameters.setDataPresent("N");
			return 0;
		}
	}
	
	/**
	 * Private method which sets the updateAlertDataParameters for passed parameters.
	 * 
	 * @param alertReportParameters
	 */
	private void updateAlertDataParameters(AlertReportParameters alertReportParameters) {
		// set allInfoIndicator
		alertReportParameters.setAllInfoIndicator("N");
		int index = (alertReportParameters.getDivisionNameKeyLvl().intValue()<=0?0:alertReportParameters.getDivisionNameKeyLvl().intValue());
		if ((alertReportParameters.getCurrentDataLink().equals("N")) && 
			((alertReportParameters.getAlertKeyLvl().intValue() == 0) || 
			((index > 1) && (alertReportParameters.getDivisionName().equals("ALL"))) || 
			((index == 1) && (alertReportParameters.getKeysAt(index-1).equals(""))))) {
			alertReportParameters.setAllInfoIndicator("Y");
		}
		/*if ((index > 0) && (alertReportParameters.getDivisionName().equals("")) && 
			(!alertReportParameters.getKeysAt(index - 1).equals(""))) {
			alertReportParameters.setDivisionName(alertReportParameters.getKeysAt(index - 1));
		}*/

		if (alertReportParameters.getDivisionName().equals("")) {
			alertReportParameters.setDivisionName("ALL");
		}

		// set Division Name list
		if ((alertReportParameters.getDivisionName().equals("ALL")) && (alertReportParameters.getDivisionNameKeyLvl().intValue() > 0)) {
			alertReportParameters.setDivisionNameList(alertsReportDataSQLService.getDivisionNameList());
		} else {
			String division = "";
			String tmpStr = alertReportParameters.getDivisionName().trim() + " ";
			for (int i = 0; i < tmpStr.length(); i++) {
				if (tmpStr.charAt(i) == ' ') {
					alertReportParameters.addKey1s(division);
					division = "";
				} else {
					division += tmpStr.charAt(i); 
				}
			}
			//alertReportParameters.setDivisionNameList(divisionList);
		}
	}

	/**
	 * This method initializes the parameters of AlertsReportDataSQLService object, 
	 * AlertsReportDataViewService object and AlertsGenFilterTemplate object.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertReportParameters
	 * @return boolean
	 */
	private boolean init(Connection connection, List failures, AlertReportParameters alertReportParameters) {
		this.connection = connection;
		this.failureList = failures;
		this.alertReportParameters = alertReportParameters;
		
		alertsReportDataSQLService.setConnection(connection);
		alertsReportDataSQLService.setAlertDataParameters(alertReportParameters);
		alertsReportDataSQLService.setFailures(failures);
		alertsReportDataSQLService.setColumns(columns);
		alertsReportDataSQLService.setQryGetDataList(qryGetDataList);
		alertsReportDataSQLService.setQryAlertRulePresnElemList(qryAlertRulePresnElemList);
		alertsReportDataSQLService.setQryKeyColList(qryKeyColList);
		alertsReportDataSQLService.setColumns(columns);
		
		alertsReportDataViewService.setConnection(connection);
		alertsReportDataViewService.setAlertReportParameters(alertReportParameters);
		alertsReportDataViewService.setFailures(failures);
		alertsReportDataViewService.setColumns(columns);
		alertsReportDataViewService.setQryGetDataList(qryGetDataList);
		alertsReportDataViewService.setQryKeyColList(qryKeyColList);			
		alertsReportDataViewService.setQryAlertRulePresnElemList(qryAlertRulePresnElemList);
		alertsReportDataViewService.setAlertReportView(alertReportView);

		alertsGenFilterTemplate.setConnection(connection);
		alertsGenFilterTemplate.setAlertReportParameters(alertReportParameters);
		alertsGenFilterTemplate.setFailureList(failures);
		alertsGenFilterTemplate.setAlertReportView(alertReportView);
		
		if (alertReportParameters.getProcDate() == null) {
			logger.debug(RABCMessages.getMessage("ERR_PROC_DATE_REQ", null));
			failures.add(new RABCException(RABCMessages.getMessage("ERR_PROC_DATE_REQ", null)));
			return false;
		}

		if (alertReportParameters.getAlertRule() == null) {
			logger.debug(RABCMessages.getMessage("ERR_ALERT_RULE_REQ", null));
			failures.add(new RABCException(RABCMessages.getMessage("ERR_ALERT_RULE_REQ", null)));
			return false;
		}
		if (alertReportParameters.getStartDate() == null) {
			alertReportParameters.setStartDate(alertReportParameters.getProcDate());
		}
		if (alertReportParameters.getEndDate() == null) {
			alertReportParameters.setEndDate(alertReportParameters.getProcDate());
		}
		if (alertReportParameters.getFileSeqNum().intValue() == -1) {
			alertReportParameters.setCurrentDataLink("N");				
		}
		
		return true;
	}

	/**
	 * This method initializes the parameters of AlertsLinkTemplateActionService object.
	 * 
	 * @param connection
	 * @param failureList
	 * @param alertReportParameters
	 * @return boolean
	 */
	private boolean initAdditional(Connection connection, List failureList, AlertReportParameters alertReportParameters) {
		alertsLinkTemplateActionService = AlertsLinkTemplateActionService.getAlertsLinkTemplateActionService();
		alertsLinkTemplateActionService.setConnection(connection);
		alertsLinkTemplateActionService.setFailureList(failureList);
		alertsLinkTemplateActionService.setAlertReportParameters(alertReportParameters);
		
		return true;
	}
	
	/**
	 * Method to return the default division.
	 * 
	 * @param connection
	 * @param failures
	 * @param userId
	 * @return String
	 */
	public String getDefaultDivision(Connection connection, List failures, String userId) {
		return alertsReportDataSQLService.getDefaultDivision(connection, failures, userId);
	}

	/**
	 * Method to return the default line count.
	 * 
	 * @param connection
	 * @param failures
	 * @param userId
	 * @return int
	 */
	public int getDefaultLineCount(Connection connection, List failures, String userId) {
		return alertsReportDataSQLService.getDefaultLineCount(connection, failures, userId);
	}
}
