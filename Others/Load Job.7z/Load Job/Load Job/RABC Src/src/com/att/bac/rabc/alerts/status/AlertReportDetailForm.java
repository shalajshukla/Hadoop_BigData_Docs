/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.alerts.status;

import java.util.ArrayList;
import java.util.List;

import com.att.bac.rabc.PickList;
import com.att.bac.rabc.SortedForm;
import com.att.bac.rabc.admin.AlertGroup;
import com.att.bac.rabc.admin.alert.rule.AlertRule;

/**
 * This is an action form to represent the Alert Report Selection Criteria page and Alert Report Detail page.
 * This is actualy a sub class of SortedForm which extends the PagedForm which in turn extends the ActionForm.
 * 
 * @author Abhilash - AC6952
 */
public class AlertReportDetailForm extends SortedForm {
	/*
	 * Variables to represent the fields on Alert Report Selection Criteria page.
	 */
	private String webPageId = "RABCPSF00009";
	private String dateType = "file";
	private int reportData = 1;
	private String fileStartDate;
	private String fileEndDate;
	private String processPoint;
	private List processPointList = new ArrayList();
	private String controlPoint;
	private List controlPointList = new ArrayList();
	private String alertRule;
	private List alertRuleList = new ArrayList();
	private String division;
	private List divisionList = new ArrayList();
	private String alertRuleTiming;
	private List alertRuleTimingList = new ArrayList();
	private String alertRuleTimingIndicator;
	private String alertStatus;
	private List alertStatusList = new ArrayList();
	private String alertSeverity;
	private List alertSeverityList = new ArrayList();
	private String groupAlerted;
	private List groupAlertedList = new ArrayList();
	private String revenueImpactValue;
	private int revenueImpactIndicator = 1;
	private String systemErrorType;
	private List systemErrorTypeList = new ArrayList();
	private String rootCauseCategory;
	private List rootCauseCategoryList = new ArrayList();
	private String lastUpdateStartDate;
	private String lastUpdateEndDate;
	private String fromPage;
	private String timeStampInd = "NO";
	private String fileStartDateHidden;
	private String fileEndDateHidden;
	private String controlPointHidden;
	private String divisionHidden;
	private String alertRuleTimingIndicatorHidden;
	private String rootCauseCategoryHidden;
	private String systemErrorTypeHidden;
	private double revenueImpactValueHidden;
	
	/*
	 * Variables to represent the fields on Alert Report Detail page.
	 */
	private List alertReportDetailList = new ArrayList();
	private String cycle;
	private int totalAlerts;
	private int key2Column = 0;
	private int seqColumn = 0;
	private int updateAccessAll = 0;
	private String statusColor = "#0059B3";
	private int pageshow;
	private String selectedAlerts;
	private boolean alertSelectIndicatorAll = false;
	private boolean alertSelectIndicatorAll1 = false;
	private String emailRecipients;
	
	/*
	 * Variables to show Bill Cycle and to indicate holiday on calendar page.
	 */
	private String procDates;
	private String billRounds;
	private String holidayIndicators;
	private String loadedDataDates;
	
	/*
	 * Variable to represent count of total selected alerts from all pages.
	 */
	String selectedAlertsCount;
	
	/*
	 * Variable to represent whether the report is in expanded mode.
	 */
	String expandMode = "N";	//"Y" or "N"
	
	/*
	 * Change on 28-Nov-2006 to show bill rounds from RABC_REGION_BILL_RND
	 */
	private String billRoundList;
	
	/**
	 * Default constructor which sets the default sort item, sort order and previous sort item.
	 */
	public AlertReportDetailForm() {
		this.setPreviousSortItem("bams.proc_date");
		this.setSortItem("bams.proc_date");
		this.setSortOrder("ASC");
	}
	
	/**
	 * @return String loadedDataDates
	 */			
	public String getLoadedDataDates() {
		return loadedDataDates;
	}

	/**
	 * @param loadedDataDates String
	 */
	public void setLoadedDataDates(String loadedDataDates) {
		this.loadedDataDates = loadedDataDates;
	}
	
	/**
	 * @return Returns the dateType.
	 */
	public String getDateType() {
		return dateType;
	}
	/**
	 * @param dateType The dateType to set.
	 */
	public void setDateType(String dateType) {
		this.dateType = dateType;
	}
	/**
	 * @return Returns the webPageId.
	 */
	public String getWebPageId() {
		return webPageId;
	}
	/**
	 * @param webPageId The webPageId to set.
	 */
	public void setWebPageId(String webPageId) {
		this.webPageId = webPageId;
	}
	/**
	 * @return Returns the totalAlerts.
	 */
	public int getTotalAlerts() {
		return totalAlerts;
	}
	/**
	 * @param totalAlerts The totalAlerts to set.
	 */
	public void setTotalAlerts(int totalAlerts) {
		this.totalAlerts = totalAlerts;
	}
	/**
	 * @return Returns the cycle.
	 */
	public String getCycle() {
		return cycle;
	}
	/**
	 * @param cycle The cycle to set.
	 */
	public void setCycle(String cycle) {
		this.cycle = cycle;
	}
	/**
	 * @return Returns the alertReportDetailList.
	 */
	public List getAlertReportDetailList() {
		return alertReportDetailList;
	}
	/**
	 * @param alertReportDetailList The alertReportDetailList to add.
	 */
	public void addAlertReportDetail(AlertReportDetail alertReportDetail) {
		this.alertReportDetailList.add(alertReportDetail);
	}
	/**
	 * @return Returns the alertRule.
	 */
	public String getAlertRule() {
		return alertRule;
	}
	/**
	 * @param alertRule The alertRule to set.
	 */
	public void setAlertRule(String alertRule) {
		this.alertRule = alertRule;
	}
	/**
	 * @return Returns the alertRuleTimingIndicator.
	 */
	public String getAlertRuleTimingIndicator() {
		return alertRuleTimingIndicator;
	}
	/**
	 * @param alertRuleTimingIndicator The alertRuleTimingIndicator to set.
	 */
	public void setAlertRuleTimingIndicator(String alertRuleTimingIndicator) {
		this.alertRuleTimingIndicator = alertRuleTimingIndicator;
	}
	/**
	 * @return Returns the alertSeverity.
	 */
	public String getAlertSeverity() {
		return alertSeverity;
	}
	/**
	 * @param alertSeverity The alertSeverity to set.
	 */
	public void setAlertSeverity(String alertSeverity) {
		this.alertSeverity = alertSeverity;
	}
	/**
	 * @return Returns the alertStatus.
	 */
	public String getAlertStatus() {
		return alertStatus;
	}
	/**
	 * @param alertStatus The alertStatus to set.
	 */
	public void setAlertStatus(String alertStatus) {
		this.alertStatus = alertStatus;
	}
	/**
	 * @return Returns the controlPoint.
	 */
	public String getControlPoint() {
		return controlPoint;
	}
	/**
	 * @param controlPoint The controlPoint to set.
	 */
	public void setControlPoint(String controlPoint) {
		this.controlPoint = controlPoint;
	}
	/**
	 * @return Returns the division.
	 */
	public String getDivision() {
		return division;
	}
	/**
	 * @param division The division to set.
	 */
	public void setDivision(String division) {
		this.division = division;
	}
	/**
	 * @return Returns the fileEndDate.
	 */
	public String getFileEndDate() {
		return fileEndDate;
	}
	/**
	 * @param fileEndDate The fileEndDate to set.
	 */
	public void setFileEndDate(String fileEndDate) {
		this.fileEndDate = fileEndDate;
	}
	/**
	 * @return Returns the fileStartDate.
	 */
	public String getFileStartDate() {
		return fileStartDate;
	}
	/**
	 * @param fileStartDate The fileStartDate to set.
	 */
	public void setFileStartDate(String fileStartDate) {
		this.fileStartDate = fileStartDate;
	}
	/**
	 * @return Returns the groupAlerted.
	 */
	public String getGroupAlerted() {
		return groupAlerted;
	}
	/**
	 * @param groupAlerted The groupAlerted to set.
	 */
	public void setGroupAlerted(String groupAlerted) {
		this.groupAlerted = groupAlerted;
	}
	/**
	 * @return Returns the lastUpdateEndDate.
	 */
	public String getLastUpdateEndDate() {
		return lastUpdateEndDate;
	}
	/**
	 * @param lastUpdateEndDate The lastUpdateEndDate to set.
	 */
	public void setLastUpdateEndDate(String lastUpdateEndDate) {
		this.lastUpdateEndDate = lastUpdateEndDate;
	}
	/**
	 * @return Returns the lastUpdateStartDate.
	 */
	public String getLastUpdateStartDate() {
		return lastUpdateStartDate;
	}
	/**
	 * @param lastUpdateStartDate The lastUpdateStartDate to set.
	 */
	public void setLastUpdateStartDate(String lastUpdateStartDate) {
		this.lastUpdateStartDate = lastUpdateStartDate;
	}
	/**
	 * @return Returns the reportData.
	 */
	public int getReportData() {
		return reportData;
	}
	/**
	 * @param reportData The reportData to set.
	 */
	public void setReportData(int reportData) {
		this.reportData = reportData;
	}
	/**
	 * @return Returns the revenueImpactIndicator.
	 */
	public int getRevenueImpactIndicator() {
		return revenueImpactIndicator;
	}
	/**
	 * @param revenueImpactIndicator The revenueImpactIndicator to set.
	 */
	public void setRevenueImpactIndicator(int revenueImpactIndicator) {
		this.revenueImpactIndicator = revenueImpactIndicator;
	}
	/**
	 * @return Returns the revenueImpactValue.
	 */
	public String getRevenueImpactValue() {
		return revenueImpactValue;
	}
	/**
	 * @param revenueImpactValue The revenueImpactValue to set.
	 */
	public void setRevenueImpactValue(String revenueImpactValue) {
		this.revenueImpactValue = revenueImpactValue;
	}
	/**
	 * @return Returns the rootCauseCategory.
	 */
	public String getRootCauseCategory() {
		return rootCauseCategory;
	}
	/**
	 * @param rootCauseCategory The rootCauseCategory to set.
	 */
	public void setRootCauseCategory(String rootCauseCategory) {
		this.rootCauseCategory = rootCauseCategory;
	}
	/**
	 * @return Returns the systemErrorType.
	 */
	public String getSystemErrorType() {
		return systemErrorType;
	}
	/**
	 * @param systemErrorType The systemErrorType to set.
	 */
	public void setSystemErrorType(String systemErrorType) {
		this.systemErrorType = systemErrorType;
	}
	/**
	 * @return Returns the alertRuleList.
	 */
	public List getAlertRuleList() {
		return alertRuleList;
	}
	/**
	 * @param alertRule The alertRule to add.
	 */
	public void addAlertRule(AlertRule alertRule) {
		this.alertRuleList.add(alertRule);
	}
	/**
	 * @return Returns the alertRuleTiming.
	 */
	public String getAlertRuleTiming() {
		return alertRuleTiming;
	}
	/**
	 * @param alertRuleTiming The alertRuleTiming to set.
	 */
	public void setAlertRuleTiming(String alertRuleTiming) {
		this.alertRuleTiming = alertRuleTiming;
	}
	/**
	 * @return Returns the alertRuleTimingList.
	 */
	public List getAlertRuleTimingList() {
		return alertRuleTimingList;
	}
	/**
	 * @param alertRuleTiming The alertRuleTiming to add.
	 */
	public void addAlertRuleTiming(PickList alertRuleTiming) {
		this.alertRuleTimingList.add(alertRuleTiming);
	}
	/**
	 * @return Returns the alertSeverityList.
	 */
	public List getAlertSeverityList() {
		return alertSeverityList;
	}
	/**
	 * @param alertSeverity The alertSeverity to add.
	 */
	public void addAlertSeverity(PickList alertSeverity) {
		this.alertSeverityList.add(alertSeverity);
	}
	/**
	 * @return Returns the alertStatusList.
	 */
	public List getAlertStatusList() {
		return alertStatusList;
	}
	/**
	 * @param alertStatus The alertStatus to add.
	 */
	public void addAlertStatus(PickList alertStatus) {
		this.alertStatusList.add(alertStatus);
	}
	/**
	 * @return Returns the controlPointList.
	 */
	public List getControlPointList() {
		return controlPointList;
	}
	/**
	 * @param controlPoint The controlPoint to add.
	 */
	public void addControlPoint(PickList controlPoint) {
		this.controlPointList.add(controlPoint);
	}
	/**
	 * @return Returns the divisionList.
	 */
	public List getDivisionList() {
		return divisionList;
	}
	/**
	 * @param division The division to add.
	 */
	public void addDivision(PickList division) {
		this.divisionList.add(division);
	}
	/**
	 * @return Returns the groupAlertedList.
	 */
	public List getGroupAlertedList() {
		return groupAlertedList;
	}
	/**
	 * @param groupAlerted The groupAlerted to add.
	 */
	public void addGroupAlerted(AlertGroup groupAlerted) {
		this.groupAlertedList.add(groupAlerted);
	}
	/**
	 * @return Returns the rootCauseCategoryList.
	 */
	public List getRootCauseCategoryList() {
		return rootCauseCategoryList;
	}
	/**
	 * @param rootCauseCategory The rootCauseCategory to add.
	 */
	public void addRootCauseCategory(RootCategory rootCauseCategory) {
		this.rootCauseCategoryList.add(rootCauseCategory);
	}
	/**
	 * @return Returns the systemErrorTypeList.
	 */
	public List getSystemErrorTypeList() {
		return systemErrorTypeList;
	}
	/**
	 * @param systemErrorType The systemErrorType to add.
	 */
	public void addSystemErrorType(SysErr systemErrorType) {
		this.systemErrorTypeList.add(systemErrorType);
	}	
	/**
	 * @return Returns the alertSelectIndicatorAll.
	 */
	public boolean isAlertSelectIndicatorAll() {
		return alertSelectIndicatorAll;
	}
	/**
	 * @param alertSelectIndicatorAll The alertSelectIndicatorAll to set.
	 */
	public void setAlertSelectIndicatorAll(boolean alertSelectIndicatorAll) {
		this.alertSelectIndicatorAll = alertSelectIndicatorAll;
	}
	/**
	 * @return Returns the fileEndDateHidden.
	 */
	public String getFileEndDateHidden() {
		return fileEndDateHidden;
	}
	/**
	 * @param fileEndDateHidden The fileEndDateHidden to set.
	 */
	public void setFileEndDateHidden(String fileEndDateHidden) {
		this.fileEndDateHidden = fileEndDateHidden;
	}
	/**
	 * @return Returns the fileStartDateHidden.
	 */
	public String getFileStartDateHidden() {
		return fileStartDateHidden;
	}
	/**
	 * @param fileStartDateHidden The fileStartDateHidden to set.
	 */
	public void setFileStartDateHidden(String fileStartDateHidden) {
		this.fileStartDateHidden = fileStartDateHidden;
	}
	/**
	 * @return Returns the alertRuleTimingIndicatorHidden.
	 */
	public String getAlertRuleTimingIndicatorHidden() {
		return alertRuleTimingIndicatorHidden;
	}
	/**
	 * @param alertRuleTimingIndicatorHidden The alertRuleTimingIndicatorHidden to set.
	 */
	public void setAlertRuleTimingIndicatorHidden(
			String alertRuleTimingIndicatorHidden) {
		this.alertRuleTimingIndicatorHidden = alertRuleTimingIndicatorHidden;
	}
	/**
	 * @return Returns the controlPointHidden.
	 */
	public String getControlPointHidden() {
		return controlPointHidden;
	}
	/**
	 * @param controlPointHidden The controlPointHidden to set.
	 */
	public void setControlPointHidden(String controlPointHidden) {
		this.controlPointHidden = controlPointHidden;
	}
	/**
	 * @return Returns the divisionHidden.
	 */
	public String getDivisionHidden() {
		return divisionHidden;
	}
	/**
	 * @param divisionHidden The divisionHidden to set.
	 */
	public void setDivisionHidden(String divisionHidden) {
		this.divisionHidden = divisionHidden;
	}
	/**
	 * @return Returns the selectedAlerts.
	 */
	public String getSelectedAlerts() {
		return selectedAlerts;
	}
	/**
	 * @param selectedAlerts The selectedAlerts to set.
	 */
	public void setSelectedAlerts(String selectedAlerts) {
		this.selectedAlerts = selectedAlerts;
	}
	/**
	 * @return Returns the alertSelectIndicatorAll1.
	 */
	public boolean isAlertSelectIndicatorAll1() {
		return alertSelectIndicatorAll1;
	}
	/**
	 * @param alertSelectIndicatorAll1 The alertSelectIndicatorAll1 to set.
	 */
	public void setAlertSelectIndicatorAll1(boolean alertSelectIndicatorAll1) {
		this.alertSelectIndicatorAll1 = alertSelectIndicatorAll1;
	}
	/**
	 * @return Returns the key2Column.
	 */
	public int getKey2Column() {
		return key2Column;
	}
	/**
	 * @param key2Column The key2Column to set.
	 */
	public void setKey2Column(int key2Column) {
		this.key2Column = key2Column;
	}
	/**
	 * @return Returns the processPoint.
	 */
	public String getProcessPoint() {
		return processPoint;
	}
	/**
	 * @param processPoint The processPoint to set.
	 */
	public void setProcessPoint(String processPoint) {
		this.processPoint = processPoint;
	}
	/**
	 * @return Returns the processPointList.
	 */
	public List getProcessPointList() {
		return processPointList;
	}
	/**
	 * @param processPoint The processPoint to add.
	 */
	public void addProcessPoint(PickList processPoint) {
		this.processPointList.add(processPoint);
	}
	/**
	 * @return Returns the emailRecipients.
	 */
	public String getEmailRecipients() {
		return emailRecipients;
	}
	/**
	 * @param emailRecipients The emailRecipients to set.
	 */
	public void setEmailRecipients(String emailRecipients) {
		this.emailRecipients = emailRecipients;
	}
	/**
	 * @return Returns the pageshow.
	 */
	public int getPageshow() {
		return pageshow;
	}
	/**
	 * @param pageshow The pageshow to set.
	 */
	public void setPageshow(int pageshow) {
		this.pageshow = pageshow;
	}
	/**
	 * @return Returns the fromPage.
	 */
	public String getFromPage() {
		return fromPage;
	}
	/**
	 * @param fromPage The fromPage to set.
	 */
	public void setFromPage(String fromPage) {
		this.fromPage = fromPage;
	}
	/**
	 * @return Returns the timeStampInd.
	 */
	public String getTimeStampInd() {
		return timeStampInd;
	}
	/**
	 * @param timeStampInd The timeStampInd to set.
	 */
	public void setTimeStampInd(String timeStampInd) {
		this.timeStampInd = timeStampInd;
	}
	/**
	 * @return Returns the updateAccessAll.
	 */
	public int getUpdateAccessAll() {
		return updateAccessAll;
	}
	/**
	 * @param updateAccessAll The updateAccessAll to set.
	 */
	public void setUpdateAccessAll(int updateAccessAll) {
		this.updateAccessAll = updateAccessAll;
	}
	/**
	 * @return Returns the seqColumn.
	 */
	public int getSeqColumn() {
		return seqColumn;
	}
	/**
	 * @param seqColumn The seqColumn to set.
	 */
	public void setSeqColumn(int seqColumn) {
		this.seqColumn = seqColumn;
	}
	/**
	 * @return Returns the rootCauseCategoryHidden.
	 */
	public String getRootCauseCategoryHidden() {
		return rootCauseCategoryHidden;
	}
	/**
	 * @param rootCauseCategoryHidden The rootCauseCategoryHidden to set.
	 */
	public void setRootCauseCategoryHidden(String rootCauseCategoryHidden) {
		this.rootCauseCategoryHidden = rootCauseCategoryHidden;
	}
	/**
	 * @return Returns the systemErrorTypeHidden.
	 */
	public String getSystemErrorTypeHidden() {
		return systemErrorTypeHidden;
	}
	/**
	 * @param systemErrorTypeHidden The systemErrorTypeHidden to set.
	 */
	public void setSystemErrorTypeHidden(String systemErrorTypeHidden) {
		this.systemErrorTypeHidden = systemErrorTypeHidden;
	}
	/**
	 * @return Returns the revenueImpactValueHidden.
	 */
	public double getRevenueImpactValueHidden() {
		return revenueImpactValueHidden;
	}
	/**
	 * @param revenueImpactValueHidden The revenueImpactValueHidden to set.
	 */
	public void setRevenueImpactValueHidden(double revenueImpactValueHidden) {
		this.revenueImpactValueHidden = revenueImpactValueHidden;
	}
	/**
	 * @return Returns the statusColor.
	 */
	public String getStatusColor() {
		return statusColor;
	}
	/**
	 * @param statusColor The statusColor to set.
	 */
	public void setStatusColor(String statusColor) {
		this.statusColor = statusColor;
	}
	
	/**
	 * @return Returns the billRounds.
	 */
	public String getBillRounds() {
		return billRounds;
	}
	/**
	 * @param billRounds The billRounds to set.
	 */
	public void setBillRounds(String billRounds) {
		this.billRounds = billRounds;
	}
	/**
	 * @return Returns the holidayIndicators.
	 */
	public String getHolidayIndicators() {
		return holidayIndicators;
	}
	/**
	 * @param holidayIndicators The holidayIndicators to set.
	 */
	public void setHolidayIndicators(String holidayIndicators) {
		this.holidayIndicators = holidayIndicators;
	}
	/**
	 * @return Returns the procDates.
	 */
	public String getProcDates() {
		return procDates;
	}
	/**
	 * @param procDates The procDates to set.
	 */
	public void setProcDates(String procDates) {
		this.procDates = procDates;
	}
	/**
	 * @return Returns the selectedAlertsCount.
	 */
	public String getSelectedAlertsCount() {
		return selectedAlertsCount;
	}
	/**
	 * @param selectedAlertsCount The selectedAlertsCount to set.
	 */
	public void setSelectedAlertsCount(String selectedAlertsCount) {
		this.selectedAlertsCount = selectedAlertsCount;
	}
	/**
	 * @return Returns the expandMode.
	 */
	public String getExpandMode() {
		return expandMode;
	}
	/**
	 * @param expandMode The expandMode to set.
	 */
	public void setExpandMode(String expandMode) {
		this.expandMode = expandMode;
	}
	
	/**
	 * @return Returns the billRoundList.
	 */
	public String getBillRoundList() {
		return billRoundList;
	}
	/**
	 * @param billRoundList The billRoundList to set.
	 */
	public void setBillRoundList(String billRoundList) {
		this.billRoundList = billRoundList;
	}
}
