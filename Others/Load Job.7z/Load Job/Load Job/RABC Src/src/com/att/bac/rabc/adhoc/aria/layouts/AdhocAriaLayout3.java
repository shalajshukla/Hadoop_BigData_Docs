/*
 * Copyright  2002-2006 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.adhoc.aria.layouts;

import java.io.OutputStream;

import org.apache.struts.action.ActionForm;

import com.sbc.bac.aria.ARIAHTMLPage13Processor;


/**
 * Layout 3 for Adhoc reporting. This is "page 13".
 * 
 * <p>
 * <hr>
 * <h3>Release History</h3>
 * <p>
 * <ul>
 * 
 * <li>jb6494 Aug 01, 2006 Created class.
 * 
 * </ul>
 * <p>
 * 
 */
class AdhocAriaLayout3 extends AdhocAriaLayout1 {
	
	
    /**
     * Create layout 3
     * 
     * @param form
     * @param os
     * @param userid
     */
    public AdhocAriaLayout3(ActionForm form, OutputStream os, String userid) {
        super(form, os, userid);
    }

    /**
     * Add the total labels
     * @param buf
     */
    protected void addTotalLabel(ARIAHTMLPage13Processor proc, StringBuffer buf, String value){
    	int currentRowCnt = getCurrentRowCount() ; 
    	int totalRowCnt =  getActualRows() ; 
    	if (proc.getPaging().getCurrentPage() == proc.getPaging().getTotalPages()) {
    		if (currentRowCnt==(totalRowCnt+1)){
        		value = "Grand Total";
        	} else {
        		value = "Total";
        	}
    	}else {
    		value = "Total";
    	}
    	buf.append(value) ;
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see com.att.bac.rabc.adhoc.aria.AbstractAdhocAriaLayout#createProcessor(java.io.OutputStream)
    
    protected ARIAHTMLPage13Processor createProcessor(OutputStream os) {
        ARIAHTMLPage13Processor p = super.createProcessor(os);
        p.setSubTotalLabel(SIX_MONTH_TOTALS);
        return p;
    } */
}
