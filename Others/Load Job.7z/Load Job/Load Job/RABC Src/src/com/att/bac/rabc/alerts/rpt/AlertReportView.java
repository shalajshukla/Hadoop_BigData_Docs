/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.rpt;

import java.util.ArrayList;
import java.util.List;

/**
 * This class represents the data object that holds the attributes required
 * to represent the Alert Report view(Control Alert Detail) page.
 * 
 * @author Nalina Pandiyan - NP5434
 */
public class AlertReportView {
	private List divisions = new ArrayList(); // alertReportDivision objects
	private List standardButtons = new ArrayList(); // String objects
	private List alertDataList = new ArrayList(); // alertData Objects

	/**
	 * @return Returns the alertDataList.
	 */
	public List getAlertDataList() {
		return alertDataList;
	}
	/**
	 * @return Returns the divisions.
	 */
	public List getDivisions() {
		return divisions;
	}

	/**
	 * @return Returns the standardButtons.
	 */
	/**
	 * @return
	 */
	public List getStandardButtons() {
		return standardButtons;
	}
	
	/**
	 * @param alertData The alertData to set.
	 */
	public void addAlertData(AlertData alertData) {
		this.alertDataList.add(alertData);
	}
		
	/**
	 * @param alertReportDivision The alertReportDivision to set.
	 */
	public void addDivisions(AlertReportDivision alertReportDivision) {
		this.divisions.add(alertReportDivision);
	}
	
	/**
	 * @param standardButtons The standardButtons to set.
	 */
	public void setStandardButtons(List standardButtons) {
		this.standardButtons = standardButtons;
	}
}
