/* Component Name: RABCPPG00507
 * Module Name: UserAccessTO.java
 * Created on Mar 1, 2006
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.admin.alert.grp;

import java.io.Serializable;

/**This is a transfer object class for the Alert Group process.  The purpose of this class is to 
 * contain an alert group and its associated application functions as well as alert rules.  This data
 * is extracted from the AdminAlertGroupDAO.java class and is sent back to the AdminAlertGroupForm.java
 * class via the AdminAlertGroupService.java class.
 * 
 * @author js3175
 */
public class UserAccessTO implements Serializable {
	private static final long serialVersionUID = 0L;
	
	private String alertGroup = "";
	private String [] alertRules = new String[0];
	private String [] adhocReports = new String[0];
	
	/**
	 * @return Returns the adhocReports.
	 */
	public String[] getAdhocReports() {
		return adhocReports;
	}
	/**
	 * @param adhocReports The adhocReports to set.
	 */
	public void setAdhocReports(String[] adhocReports) {
		this.adhocReports = adhocReports;
	}
	/**
	 * @return Returns the alertGroup.
	 */
	public String getAlertGroup() {
		return alertGroup;
	}
	/**
	 * @param alertGroup The alertGroup to set.
	 */
	public void setAlertGroup(String alertGroup) {
		this.alertGroup = alertGroup;
	}
	/**
	 * @return Returns the alertRules.
	 */
	public String[] getAlertRules() {
		return alertRules;
	}
	/**
	 * @param alertRules The alertRules to set.
	 */
	public void setAlertRules(String[] alertRules) {
		this.alertRules = alertRules;
	}
}
