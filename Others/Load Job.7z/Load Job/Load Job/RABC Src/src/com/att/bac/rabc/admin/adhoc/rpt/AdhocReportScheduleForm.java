/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.admin.adhoc.rpt;

import java.util.List;

import org.apache.struts.action.ActionForm;

import com.att.bac.rabc.PickList;
import com.att.bac.rabc.PresnId;

/**
 * Module description: 
 * 
 * This is a scheduler page Form Bean for the adhoc report component. 
 *
 * @author Anup Thomas - AT1862
 */
public class AdhocReportScheduleForm extends ActionForm {
	private String dispatch;
	private List adhocReportScheduleList; 
	
	// Variable to indicate the presnId was not selected
	private int presnId=0; 
	
	// Variable to store the selected schedule Id for the given presn_id
	private String selectedScheduleId = "0"; 
	
	// List of report names obtained from the database
	private List reportNameList; 
	
	/*
	 * Data members for the static list attributes; obtained from the constant lists
	 */
	private List frequencyList;
	private List frequencyDataWeeklyList;
	private List frequencyDataMonthlyList;
	private List frequencyDataCycleCodeList;
	private List frequencyDataRunDayList; 
	private List divisionList;
	
	/*
	 * Data attributes to capture insert related values for Ad hoc Schedule from the JSP
	 */
	private String startDate;
	private String days;
	private String frequency;
	private String frequencyDataWeekly;
	private String frequencyDataMonthly;
	private String frequencyDataYearly;
	private String frequencyDataCycleCode;
	private String frequencyDataRunDay;
	private String emailTo;
	private String saveToDisk;
	private String rptType;
	private String hasPermissionToSave;
	private String division;

	/*
	 * Data attributes to capture update related values for Ad hoc Schedule from the JSP
	 */
	private String startDateEdit;
	private String daysEdit;
	private String frequencyEdit;
	private String frequencyDataWeeklyEdit;
	private String frequencyDataMonthlyEdit;
	private String frequencyDataYearlyEdit;
	private String frequencyDataCycleCodeEdit;
	private String frequencyDataRunDayEdit;
	private String emailToEdit;
	private String saveToDiskEdit;
	private String rptTypeEdit;
	private String divisionEdit;
	
	/*
	 * Variables added for calendar page
	 */
	private String procDates;
	private String billRounds;
	private String holidayIndicators;
	private String loadedDataDates;
	
	/**
	 * @return String loadedDataDates
	 */			
	public String getLoadedDataDates() {
		return loadedDataDates;
	}

	/**
	 * @param loadedDataDates String
	 */
	public void setLoadedDataDates(String loadedDataDates) {
		this.loadedDataDates = loadedDataDates;
	}
	
	/**
	 * @return Returns the hasPermissionToSave.
	 */
	public String getHasPermissionToSave() {
		return hasPermissionToSave;
	}
	/**
	 * @param hasPermissionToSave The hasPermissionToSave to set.
	 */
	public void setHasPermissionToSave(String hasPermissionToSave) {
		this.hasPermissionToSave = hasPermissionToSave;
	}
	/**
	 * @return Returns the rptType.
	 */
	public String getRptType() {
		return rptType;
	}
	/**
	 * @param rptType The rptType to set.
	 */
	public void setRptType(String rptType) {
		this.rptType = rptType;
	}
	/**
	 * @return Returns the rptTypeEdit.
	 */
	public String getRptTypeEdit() {
		return rptTypeEdit;
	}
	/**
	 * @param rptTypeEdit The rptTypeEdit to set.
	 */
	public void setRptTypeEdit(String rptTypeEdit) {
		this.rptTypeEdit = rptTypeEdit;
	}
	/**
	 * @return Returns the adhocReportScheduleList.
	 */
	public List getAdhocReportScheduleList() {
		return adhocReportScheduleList;
	}
	/**
	 * @param adhocReportScheduleList The adhocReportScheduleList to set.
	 */
	public void addAdhocReportSchedule(AdhocReportSchedule adhocReportSchedule) {
		this.adhocReportScheduleList.add(adhocReportSchedule);
	}
	/**
	 * @return Returns the reportNameList.
	 */
	public List getReportNameList() {
		return reportNameList;
	}
	/**
	 * @param reportNameList The reportNameList to set.
	 */
	public void addReportName(PresnId presnId) {
		this.reportNameList.add(presnId);
	}
	
	/**
	 * @return Returns the frequencyList.
	 */
	public List getFrequencyList() {
		return frequencyList;
	}
	/**
	 * @param frequencyList The frequencyList to set.
	 */
	public void addFrequency(PickList frequency) {
		this.frequencyList.add(frequency);
	}
	/**
	 * @return Returns the frequencyDataCycleCodeList.
	 */
	public List getFrequencyDataCycleCodeList() {
		return frequencyDataCycleCodeList;
	}
	/**
	 * @param frequencyDataCycleCodeList The frequencyDataCycleCodeList to set.
	 */
	public void addFrequencyDataCycleCode(PickList frequencyDataCycleCode) {
		this.frequencyDataCycleCodeList.add(frequencyDataCycleCode);
	}
	
	/**
	 * @return Returns the frequencyDataMonthlyList.
	 */
	public List getFrequencyDataMonthlyList() {
		return frequencyDataMonthlyList;
	}
	/**
	 * @param frequencyDataMonthlyList The frequencyDataMonthlyList to set.
	 */
	public void addFrequencyDataMonthly(PickList frequencyDataMonthly) {
		this.frequencyDataMonthlyList.add(frequencyDataMonthly);
	}
	
	/**
	 * @return Returns the frequencyDataRunDay.
	 */
	public String getFrequencyDataRunDay() {
		return frequencyDataRunDay;
	}
	/**
	 * @param frequencyDataRunDay The frequencyDataRunDay to set.
	 */
	public void setFrequencyDataRunDay(String frequencyDataRunDay) {
		this.frequencyDataRunDay = frequencyDataRunDay;
	}
	/**
	 * @return Returns the frequencyDataRunDayList.
	 */
	public List getFrequencyDataRunDayList() {
		return frequencyDataRunDayList;
	}
	
	/**
	 * @param frequencyDataRunDayList The frequencyDataRunDayList to set.
	 */
	public void setFrequencyDataRunDayList(List frequencyDataRunDayList) {
		this.frequencyDataRunDayList = frequencyDataRunDayList;
	}
	/**
	 * @param frequencyDataRunDayList The frequencyDataRunDayList to set.
	 */
	public void addFrequencyDataRunDay(PickList frequencyDataRunDay) {
		this.frequencyDataRunDayList.add(frequencyDataRunDay);
	}
	/**
	 * @return Returns the frequencyDataWeeklyList.
	 */
	public List getFrequencyDataWeeklyList() {
		return frequencyDataWeeklyList;
	}
	/**
	 * @param frequencyDataWeeklyList The frequencyDataWeeklyList to set.
	 */
	public void addFrequencyDataWeekly(PickList frequencyDataWeekly) {
		this.frequencyDataWeeklyList.add(frequencyDataWeekly);
	}
	/**
	 * @return Returns the days.
	 */
	public String getDays() {
		return days;
	}
	/**
	 * @param days The days to set.
	 */
	public void setDays(String days) {
		this.days = days;
	}
	/**
	 * @return Returns the daysEdit.
	 */
	public String getDaysEdit() {
		return daysEdit;
	}
	/**
	 * @param daysEdit The daysEdit to set.
	 */
	public void setDaysEdit(String daysEdit) {
		this.daysEdit = daysEdit;
	}
	/**
	 * @return Returns the dispatch.
	 */
	public String getDispatch() {
		return dispatch;
	}
	/**
	 * @param dispatch The dispatch to set.
	 */
	public void setDispatch(String dispatch) {
		this.dispatch = dispatch;
	}
	/**
	 * @return Returns the emailTo.
	 */
	public String getEmailTo() {
		return emailTo;
	}
	/**
	 * @param emailTo The emailTo to set.
	 */
	public void setEmailTo(String emailTo) {
		this.emailTo = emailTo;
	}
	/**
	 * @return Returns the emailToEdit.
	 */
	public String getEmailToEdit() {
		return emailToEdit;
	}
	/**
	 * @param emailToEdit The emailToEdit to set.
	 */
	public void setEmailToEdit(String emailToEdit) {
		this.emailToEdit = emailToEdit;
	}
	/**
	 * @return Returns the frequency.
	 */
	public String getFrequency() {
		return frequency;
	}
	/**
	 * @param frequency The frequency to set.
	 */
	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}
	/**
	 * @return Returns the frequencyDataCycleCode.
	 */
	public String getFrequencyDataCycleCode() {
		return frequencyDataCycleCode;
	}
	/**
	 * @param frequencyDataCycleCode The frequencyDataCycleCode to set.
	 */
	public void setFrequencyDataCycleCode(String frequencyDataCycleCode) {
		this.frequencyDataCycleCode = frequencyDataCycleCode;
	}
	/**
	 * @return Returns the frequencyDataCycleCodeEdit.
	 */
	public String getFrequencyDataCycleCodeEdit() {
		return frequencyDataCycleCodeEdit;
	}
	/**
	 * @param frequencyDataCycleCodeEdit The frequencyDataCycleCodeEdit to set.
	 */
	public void setFrequencyDataCycleCodeEdit(String frequencyDataCycleCodeEdit) {
		this.frequencyDataCycleCodeEdit = frequencyDataCycleCodeEdit;
	}
	/**
	 * @return Returns the frequencyDataMonthly.
	 */
	public String getFrequencyDataMonthly() {
		return frequencyDataMonthly;
	}
	/**
	 * @param frequencyDataMonthly The frequencyDataMonthly to set.
	 */
	public void setFrequencyDataMonthly(String frequencyDataMonthly) {
		this.frequencyDataMonthly = frequencyDataMonthly;
	}
	/**
	 * @return Returns the frequencyDataMonthlyEdit.
	 */
	public String getFrequencyDataMonthlyEdit() {
		return frequencyDataMonthlyEdit;
	}
	/**
	 * @param frequencyDataMonthlyEdit The frequencyDataMonthlyEdit to set.
	 */
	public void setFrequencyDataMonthlyEdit(String frequencyDataMonthlyEdit) {
		this.frequencyDataMonthlyEdit = frequencyDataMonthlyEdit;
	}
	/**
	 * @return Returns the frequencyDataRunDayEdit.
	 */
	public String getFrequencyDataRunDayEdit() {
		return frequencyDataRunDayEdit;
	}
	/**
	 * @param frequencyDataRunDayEdit The frequencyDataRunDayEdit to set.
	 */
	public void setFrequencyDataRunDayEdit(String frequencyDataRunDayEdit) {
		this.frequencyDataRunDayEdit = frequencyDataRunDayEdit;
	}
	/**
	 * @return Returns the frequencyDataWeekly.
	 */
	public String getFrequencyDataWeekly() {
		return frequencyDataWeekly;
	}
	/**
	 * @param frequencyDataWeekly The frequencyDataWeekly to set.
	 */
	public void setFrequencyDataWeekly(String frequencyDataWeekly) {
		this.frequencyDataWeekly = frequencyDataWeekly;
	}
	/**
	 * @return Returns the frequencyDataWeeklyEdit.
	 */
	public String getFrequencyDataWeeklyEdit() {
		return frequencyDataWeeklyEdit;
	}
	/**
	 * @param frequencyDataWeeklyEdit The frequencyDataWeeklyEdit to set.
	 */
	public void setFrequencyDataWeeklyEdit(String frequencyDataWeeklyEdit) {
		this.frequencyDataWeeklyEdit = frequencyDataWeeklyEdit;
	}
	/**
	 * @return Returns the frequencyDataYearly.
	 */
	public String getFrequencyDataYearly() {
		return frequencyDataYearly;
	}
	/**
	 * @param frequencyDataYearly The frequencyDataYearly to set.
	 */
	public void setFrequencyDataYearly(String frequencyDataYearly) {
		this.frequencyDataYearly = frequencyDataYearly;
	}
	/**
	 * @return Returns the frequencyDataYearlyEdit.
	 */
	public String getFrequencyDataYearlyEdit() {
		return frequencyDataYearlyEdit;
	}
	/**
	 * @param frequencyDataYearlyEdit The frequencyDataYearlyEdit to set.
	 */
	public void setFrequencyDataYearlyEdit(String frequencyDataYearlyEdit) {
		this.frequencyDataYearlyEdit = frequencyDataYearlyEdit;
	}
	/**
	 * @return Returns the frequencyEdit.
	 */
	public String getFrequencyEdit() {
		return frequencyEdit;
	}
	/**
	 * @param frequencyEdit The frequencyEdit to set.
	 */
	public void setFrequencyEdit(String frequencyEdit) {
		this.frequencyEdit = frequencyEdit;
	}
	/**
	 * @return Returns the presnId.
	 */
	public int getPresnId() {
		return presnId;
	}
	/**
	 * @param presnId The presnId to set.
	 */
	public void setPresnId(int presnId) {
		this.presnId = presnId;
	}
	/**
	 * @return Returns the saveToDisk.
	 */
	public String getSaveToDisk() {
		return saveToDisk;
	}
	/**
	 * @param saveToDisk The saveToDisk to set.
	 */
	public void setSaveToDisk(String saveToDisk) {
		this.saveToDisk = saveToDisk;
	}
	/**
	 * @return Returns the saveToDiskEdit.
	 */
	public String getSaveToDiskEdit() {
		return saveToDiskEdit;
	}
	/**
	 * @param saveToDiskEdit The saveToDiskEdit to set.
	 */
	public void setSaveToDiskEdit(String saveToDiskEdit) {
		this.saveToDiskEdit = saveToDiskEdit;
	}
	/**
	 * @return Returns the selectedScheduleId.
	 */
	public String getSelectedScheduleId() {
		return selectedScheduleId;
	}
	/**
	 * @param selectedScheduleId The selectedScheduleId to set.
	 */
	public void setSelectedScheduleId(String selectedScheduleId) {
		this.selectedScheduleId = selectedScheduleId;
	}
	/**
	 * @return Returns the startDate.
	 */
	public String getStartDate() {
		return startDate;
	}
	/**
	 * @param startDate The startDate to set.
	 */
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	/**
	 * @return Returns the startDateEdit.
	 */
	public String getStartDateEdit() {
		return startDateEdit;
	}
	/**
	 * @param startDateEdit The startDateEdit to set.
	 */
	public void setStartDateEdit(String startDateEdit) {
		this.startDateEdit = startDateEdit;
	}
	
	
	
	/**
	 * @return Returns the division.
	 */
	public String getDivision() {
		return division;
	}
	/**
	 * @param division The division to set.
	 */
	public void setDivision(String division) {
		this.division = division;
	}
	/**
	 * @return Returns the divisionEdit.
	 */
	public String getDivisionEdit() {
		return divisionEdit;
	}
	/**
	 * @param divisionEdit The divisionEdit to set.
	 */
	public void setDivisionEdit(String divisionEdit) {
		this.divisionEdit = divisionEdit;
	}
	/**
	 * @return Returns the divisionList.
	 */
	public List getDivisionList() {
		return divisionList;
	}
	/**
	 * @param divisionList The divisionList to set.
	 */
	public void setDivisionList(List divisionList) {
		this.divisionList = divisionList;
	}
	
	/**
	 * @return Returns the billRounds.
	 */
	public String getBillRounds() {
		return billRounds;
	}
	/**
	 * @param billRounds The billRounds to set.
	 */
	public void setBillRounds(String billRounds) {
		this.billRounds = billRounds;
	}
	/**
	 * @return Returns the holidayIndicators.
	 */
	public String getHolidayIndicators() {
		return holidayIndicators;
	}
	/**
	 * @param holidayIndicators The holidayIndicators to set.
	 */
	public void setHolidayIndicators(String holidayIndicators) {
		this.holidayIndicators = holidayIndicators;
	}
	/**
	 * @return Returns the procDates.
	 */
	public String getProcDates() {
		return procDates;
	}
	/**
	 * @param procDates The procDates to set.
	 */
	public void setProcDates(String procDates) {
		this.procDates = procDates;
	}
	
	/**
	 * @param adhocReportScheduleList The adhocReportScheduleList to set.
	 */
	public void setAdhocReportScheduleList(List adhocReportScheduleList) {
		this.adhocReportScheduleList = adhocReportScheduleList;
	}
	/**
	 * @param frequencyDataCycleCodeList The frequencyDataCycleCodeList to set.
	 */
	public void setFrequencyDataCycleCodeList(List frequencyDataCycleCodeList) {
		this.frequencyDataCycleCodeList = frequencyDataCycleCodeList;
	}
	/**
	 * @param frequencyDataMonthlyList The frequencyDataMonthlyList to set.
	 */
	public void setFrequencyDataMonthlyList(List frequencyDataMonthlyList) {
		this.frequencyDataMonthlyList = frequencyDataMonthlyList;
	}
	/**
	 * @param frequencyDataWeeklyList The frequencyDataWeeklyList to set.
	 */
	public void setFrequencyDataWeeklyList(List frequencyDataWeeklyList) {
		this.frequencyDataWeeklyList = frequencyDataWeeklyList;
	}
	/**
	 * @param frequencyList The frequencyList to set.
	 */
	public void setFrequencyList(List frequencyList) {
		this.frequencyList = frequencyList;
	}
	/**
	 * @param reportNameList The reportNameList to set.
	 */
	public void setReportNameList(List reportNameList) {
		this.reportNameList = reportNameList;
	}
}
