/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc;

import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

/**
 * This is a singleton class that loads all error messages from MessageResources.properties file.
 * 
 * @author Vijay Dubey - VD3159
 */
public class RABCMessages {
	private static final Logger logger = Logger.getLogger(RABCMessages.class);
	public static final String DEFAULT_MESSAGE_RESOURCES = "com.att.bac.rabc.MessageResources";
	private static RABCMessages rabcMessages;
	private static ResourceBundle messageProperties;
	
	/**
	 * Contructor to read the properties file & create resource bundle.
	 */
	private RABCMessages() {
		try {
			messageProperties = ResourceBundle.getBundle(DEFAULT_MESSAGE_RESOURCES);
		} catch (MissingResourceException mre) {
			logger.error("Unable to configure properties file", mre);
		}
	}
	
	/**
	 * Synchronized method to return the instance of RABCMessages object.
	 * It checks the existance of the instance of RABCMessages and if it does not exists
	 * then creates one instance of RABCMessages and returns otherwise it returns the
	 * existing instance of RABCMessages.
	 * 
	 * @return RABCMessages
	 */
	public static synchronized RABCMessages getRABCMessages(){
		if (rabcMessages == null){
			rabcMessages = new RABCMessages();
		}	
		return rabcMessages;
	}
	
	/**
	 * Method to load messages from a file containing the properties resource bundle.
	 * 
	 * @param msgFile
	 */
	public void load(String msgFile) {
		messageProperties = ResourceBundle.getBundle(msgFile, Locale.getDefault());
	}

	/**
	 * Method to load messages using the default file.
	 */
	public void load() {
		load(DEFAULT_MESSAGE_RESOURCES);
	}

	/**
	 * Returns a message based on the specified <code>key</code>
	 */
	
	/**
	 * Method to return a message based on the specified key.
	 * 
	 * @param key
	 * @return String
	 */
	public static String getMessage(String key) {
		if (messageProperties == null) {
			getRABCMessages().load();
		}
		try {
			return messageProperties.getString(key);
		} catch (MissingResourceException mre) {
			return "Missing Message Resources";
		}
	}
	
	/**
	 * Method to returns a message based on the specified key & subsitution parameters.
	 * 
	 * @param key
	 * @param substitutions
	 * @return String
	 */
	public static String getMessage(String key, String[] substitutions) {
		String msg = getMessage(key);

		return substitute(msg, substitutions);
	}
	
	/**
	 * Private method to return the formated message after substituting the substitution parameters
	 * in the passed message.
	 * 
	 * @param msg
	 * @param subst
	 * @return String
	 */
	private static String substitute(String msg, String[] subst) {
		StringBuffer newMsg = new StringBuffer(msg);
		String replaceable;
		String strNewMsg;
		int index;
		
		for (int i = 0;; i++) {
			replaceable = new String("{" + i + "}");
			strNewMsg = newMsg.toString();
			index = strNewMsg.indexOf(replaceable);

			if (index < 0) {
				break; // if no more {i} occurence then stop
			}

			if (i < subst.length) {
				// If subsitution is provided, then use it
				newMsg.replace(index, index + replaceable.length(), subst[i]);
			} else {
				// otherwise, substitute with blanks
				newMsg.replace(index, index + replaceable.length(), "");
			}
		}

		return newMsg.toString();
	}

}
