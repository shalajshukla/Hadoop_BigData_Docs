package com.att.bac.rabc.load.rbs;

import java.sql.Date;
import java.util.HashMap;

import com.sbc.bac.rabc.load.StaticFieldKeys;

public class MWrbsUSOCData {
	private double DOUBLE_ZERO=0.0;
	private int INT_ZERO=0;
	private String fieldSeperator = StaticFieldKeys.SEMICOLON;
	
	private HashMap billAMtByCategory = new HashMap();
	private Date billDate;
	private String stateId;
	private int processGroup;
	private String usoc;
	private String busType;
	private double discountAmt;
	//Variable to hold EXCH_CD rb2163
	private String exchCD;
	
	
	public double getBilled_amt(int occCategory) {
		if (billAMtByCategory.get(new Integer(occCategory)) != null){
			String[] lineFields = billAMtByCategory.get(new Integer(occCategory)).toString().split(fieldSeperator);
			return Double.valueOf(lineFields[0].trim()).doubleValue();
		}
		else 
			return DOUBLE_ZERO; 
	}

	public void setBilled_amt_qty(int occCategory, double billed_amt, int quantity) {
		billAMtByCategory.put(new Integer(occCategory),new StringBuffer(billed_amt+";"+quantity).toString());
	}

	public int getBilled_qty(int occCategory) {
		if (billAMtByCategory.get(new Integer(occCategory)) != null){
			String[] lineFields = billAMtByCategory.get(new Integer(occCategory)).toString().split(fieldSeperator);
			return Integer.valueOf(lineFields[1].trim()).intValue();
		}
		else 
			return INT_ZERO; 
	}
	
	/**
	 * @return Returns the billDate.
	 */
	public Date getBillDate() {
		return billDate;
	}
	/**
	 * @param billDate The billDate to set.
	 */
	public void setBillDate(Date billDate) {
		this.billDate = billDate;
	}
	/**
	 * @return Returns the processGroup.
	 */
	public int getProcessGroup() {
		return processGroup;
	}
	/**
	 * @param processGroup The processGroup to set.
	 */
	public void setProcessGroup(int processGroup) {
		this.processGroup = processGroup;
	}
	/**
	 * @return Returns the stateId.
	 */
	public String getStateId() {
		return stateId;
	}
	/**
	 * @param stateId The stateId to set.
	 */
	public void setStateId(String stateId) {
		this.stateId = stateId;
	}

	/**
	 * @return Returns the busType.
	 */
	public String getBusType() {
		return busType;
	}

	/**
	 * @param busType The busType to set.
	 */
	public void setBusType(String busType) {
		this.busType = busType;
	}

	/**
	 * @return Returns the discountAmt.
	 */
	public double getDiscountAmt() {
		return discountAmt;
	}

	/**
	 * @param discountAmt The discountAmt to set.
	 */
	public void setDiscountAmt(double discountAmt) {
		this.discountAmt = discountAmt;
	}

	/**
	 * @return Returns the usoc.
	 */
	public String getUsoc() {
		return usoc;
	}

	/**
	 * @param usoc The usoc to set.
	 */
	public void setUsoc(String usoc) {
		this.usoc = usoc;
	}
	
	/**
	 * rb2163
	 * @return Returns Exchange Code exchCD
	 */
	public String getExchCD() {
		return exchCD;
	}
	
	/**
	 * rb2163
	 * @param exchCD The Exchange Code to set
	 */
	public void setExchCD(String exchCD) {
		this.exchCD = exchCD;
	}
	
}
