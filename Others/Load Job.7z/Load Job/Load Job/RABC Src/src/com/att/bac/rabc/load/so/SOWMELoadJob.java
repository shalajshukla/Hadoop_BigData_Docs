/*
 * Created on Feb 24, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.att.bac.rabc.load.so;

import java.io.File;
import java.net.UnknownHostException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.StringTokenizer;

import com.att.bac.rabc.util.EmcisEventLogger;
import com.att.carat.util.NetUtil;
import com.sbc.bac.rabc.load.FilePatternLoadJob;
import com.sbc.bac.rabc.load.PrepareTableForRerun;
import com.sbc.bac.rabc.load.RetrieveStaticInfo;
import com.sbc.bac.rabc.load.StaticErrorMsgKeys;
import com.sbc.bac.rabc.load.StaticFieldKeys;

/**
 * @author pt6471
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class SOWMELoadJob extends FilePatternLoadJob {
	
	 //private static final String FILEPATTERN = "WE.[CI].C[0-9]{4}.XT16SOME.*";

	 //AGE_3_CYCLE_CT, AGE_7_CYCLE_CT, AGE_14_CYCLE_CT, AGE_GT_14_CYCLE_CT
	
	 private static final int AGE_3_CYCLE = 3;    
	 private static final int AGE_7_CYCLE = 7;	 
	 private static final int AGE_14_CYCLE = 14; 
	 
	 private PreparedStatement insert_xt16some, insert_xt16some_summary;
	 private String division, bill_rnd, run_date;
	 
	 private File currentFile;
	 
	 private String saveOrderType, fileToken, fileName;
	
	 private int cycle, lineCount;
	 
	 private java.sql.Date sqlrun_date;
	 
	 private boolean firstRcd;
	
	 private int[] ageCycleCt = new int[4];
	 
	 public boolean preprocess() {
	 super.preprocess();

	  try {
			StringBuffer sql = new StringBuffer();
			sql.append(" insert into  RABC_SVC_ORD_INFO (DIVISION, RUN_DATE, SVC_ORD, CREATE_CYCLE, AGE_CYCLE) ");
			sql.append(" VALUES (?, ?, ?, ?, ? )");
			insert_xt16some = connection.prepareStatement(sql.toString());
			sql.setLength(0);
			
			sql.append("insert into RABC_SVC_ORD_AGE (RUN_DATE, DIVISION, AGE_3_CYCLE_CT, AGE_7_CYCLE_CT, AGE_14_CYCLE_CT, AGE_GT_14_CYCLE_CT)");
			sql.append("VALUES (?, ?, ?, ?, ?, ?)");
			insert_xt16some_summary = connection.prepareStatement(sql.toString());
			sql.setLength(0);
			
		} catch (SQLException e) {
			severe(StaticErrorMsgKeys.PREPROCESS_ERROR + e.getMessage());
			return false;
		}
		return true;
	}

	public boolean preprocessFile(File file) {
		boolean success = super.preprocessFile(file);
		fileName = file.getName();
		fileToken = "XT16SOME";
		for (int i=0;i < ageCycleCt.length;i++)
			ageCycleCt[i]=0;

		firstRcd  = true;

		if (success) {
			try {
				
				if 	(file.getName().charAt(3) == StaticFieldKeys.C)	
				  division = StaticFieldKeys.PACBELLNORTH;
				else if (file.getName().charAt(3) == StaticFieldKeys.I)	
				  division = StaticFieldKeys.PACBELLSOUTH;
				else 
					return false;
				
				cycle = Integer.parseInt(file.getName().substring(6, 10));
				
				run_date = RetrieveStaticInfo.getProc_dtByCycle(connection, cycle);
				if (run_date.equals(StaticFieldKeys.ZERO)){
					severe(StaticErrorMsgKeys.NORECORD_RABC_CYCLE_CALENDAR + cycle);
					throw new Exception();	
				}
				
				
				DateFormat df = new SimpleDateFormat("MMddyyyy");
				sqlrun_date = new java.sql.Date(df.parse(run_date).getTime());

				lineCount = 0;

				String tableNm = "RABC_SVC_ORD_INFO";
				success = PrepareTableForRerun.deleteTableData(connection,tableNm,division,sqlrun_date);

				tableNm = "RABC_SVC_ORD_AGE";
				success = PrepareTableForRerun.deleteTableData(connection,tableNm,division,sqlrun_date);
				
			} catch (Exception e) {
				severe(
					StaticErrorMsgKeys.PREPROCESSFILE_ERROR
						+ StaticErrorMsgKeys.FILE_NAME_PARSING_ERROR
						+ e);
				return false;
			}
		}

		try {

				
			bill_rnd = RetrieveStaticInfo.getBillRndByCycle(connection, cycle);
			/*
			if (bill_rnd.equals(StaticFieldKeys.ZERO) || bill_rnd.equals(StaticFieldKeys.ZERO2)){
			 severe(StaticErrorMsgKeys.PREPROCESSFILE_ERROR+":No Bill Round");
			 return false;
			}
			*/

		} catch (SQLException e) {
			success = false;
			severe(StaticErrorMsgKeys.PREPROCESSFILE_ERROR + e.getMessage());
		}

		currentFile = file;
		return success;
	}

	
	
	public int parseLine(String line) throws Exception {
		boolean status;

			status = process16XTSOME(line);
			return SUCCESS;
	}
	

	private boolean process16XTSOME(String line ) throws Exception {
		
		
		lineCount++;
		
		StringTokenizer DataLine = new StringTokenizer(line, StaticFieldKeys.SEMICOLON);
		String recordId 	= DataLine.nextToken().trim();
		String serviceOrd	= DataLine.nextToken().trim();
		int startCycle		= Integer.parseInt(DataLine.nextToken().trim());
		int ageCycle 		= (cycle - startCycle) + 1;
		
		// If ageCycle is greater than 999, it is a bad record .. So, change it to 999 and capture(LOAD) for investigation
		
		if (ageCycle > 999) ageCycle = 999;	
		
		try {
			insert_xt16some.setString(1,division);		
			insert_xt16some.setDate(2,sqlrun_date);
			insert_xt16some.setString(3,serviceOrd);
			insert_xt16some.setInt(4,startCycle);
			insert_xt16some.setInt(5,ageCycle);
			insert_xt16some.addBatch();
			
			if (lineCount % 1000 == 0){
				insert_xt16some.executeBatch();
			}
			
			if (ageCycle <= AGE_3_CYCLE ) ageCycleCt[0]++;
			else if (ageCycle > AGE_3_CYCLE && ageCycle <= AGE_7_CYCLE) ageCycleCt[1]++;
			else if (ageCycle > AGE_7_CYCLE && ageCycle <= AGE_14_CYCLE) ageCycleCt[2]++;
			else if (ageCycle > AGE_14_CYCLE) ageCycleCt[3]++;
			else return false;
			
		}catch (SQLException sqle){
			severe(StaticErrorMsgKeys.INSERT_ERROR + sqle.getMessage());
			 throw new Exception("Exception is from method process16XTSOME");
		}
		
		return true;
	}
	
	
	public boolean postprocessFile(File file, boolean success) {
		try{
			//Log the file information to EMCIS_EVENT_LOG and EMCIS_EVENT_LOG_DETAIL
			EmcisEventLogger emcisLogger = new EmcisEventLogger();
			String event_id = "RABC_"+fileToken+"_WE";
            String host = NetUtil.getLocalHostName();
            String hostIP = NetUtil.getLocalIpAddress();
			int sequence = emcisLogger.getEMCISSequence(connection);
			emcisLogger.insertEventLog(connection, sequence, event_id, sqlrun_date, host, hostIP);
			emcisLogger.insertEventLogDetail(connection, sequence, "FileName", fileName);

		}catch (UnknownHostException e) {
            severe("Error getting EMCIS host information ", e);
        }
		if (success) {

			try {

				insert_xt16some.executeBatch();
				
				insert_xt16some_summary.setDate(1,sqlrun_date);	
				insert_xt16some_summary.setString(2,division);
				insert_xt16some_summary.setInt(3,ageCycleCt[0]);
				insert_xt16some_summary.setInt(4,ageCycleCt[1]);
				insert_xt16some_summary.setInt(5,ageCycleCt[2]);
				insert_xt16some_summary.setInt(6,ageCycleCt[3]);
				
				int summary_cnt = insert_xt16some_summary.executeUpdate();
				info(" insert to summary count: " + summary_cnt);

			
			}catch (SQLException sqle){
				severe(StaticErrorMsgKeys.INSERT_ERROR + sqle.getMessage());
				success = false;
			}
			
			}
		return super.postprocessFile(file, success);
	}

	
	public boolean postprocess(boolean success) {

		try {
			
			insert_xt16some.close();
			insert_xt16some_summary.close();

		} catch (SQLException e) {
			severe(
				StaticErrorMsgKeys.POSTPROCESS_ERROR
					+ StaticErrorMsgKeys.SQL_CLOSE_ERROR
					+ e);
			success = false;
		}

		return super.postprocess(success);
	}


}
