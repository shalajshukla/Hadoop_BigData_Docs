package com.att.bac.rabc.load.calnet;

import java.io.File;
import java.sql.Date;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import com.sbc.bac.rabc.load.FilePatternLoadJob;
import com.sbc.bac.rabc.load.PrepareTableForRerun;
import com.sbc.bac.rabc.load.RabcLoadJobTrig;
import com.sbc.bac.rabc.load.RetrieveStaticInfo;
import com.sbc.bac.rabc.load.StaticErrorMsgKeys;
import com.sbc.bac.rabc.load.StaticFieldKeys;

/**
 * Abstract class which has common functionality of all the calnet load jobs
 * 
 * @author HB3137
 */
public abstract class CalnetLoadJob extends FilePatternLoadJob {

	protected String region;
	protected String division;
	protected int cycle;
	protected String runDate;
	protected String billRndDate;
	protected Date sqlRunDate;
	protected int lineCount;
	protected String backoutRecovery;
	protected String billRnd;
	protected File currentFile;

	/**
	 * Returns the file id.
	 * 
	 * @return File ID
	 */
	public abstract String getFileId();

	/**
	 * Returns the table name.
	 * 
	 * @return Table Name
	 */
	public abstract String getTable();

	/**
	 * Parses the filename and sets the values for region, division, cycle, run date, bill round
	 * date, bill round, current file, bill day file
	 * 
	 * @param file
	 *            object representing the file to be processed
	 * @return boolean indicating success or failure
	 */
	protected boolean preprocessFile(File file) {

		boolean success = super.preprocessFile(file);

		if (success) {
			try {

				region = file.getName().substring(0, 2);

				if (file.getName().charAt(3) == StaticFieldKeys.C || file.getName().charAt(3) == StaticFieldKeys.NORTH)
					division = StaticFieldKeys.PACBELLNORTH;
				else if (file.getName().charAt(3) == StaticFieldKeys.I
						|| file.getName().charAt(3) == StaticFieldKeys.SOUTH)
					division = StaticFieldKeys.PACBELLSOUTH;
				else
					return false;

				cycle = Integer.parseInt(file.getName().substring(6, 10));

				runDate = RetrieveStaticInfo.getProc_dtByCycle(connection, cycle);
				billRndDate = RetrieveStaticInfo.getbillRndDt_ByCycle(connection, cycle);
				if (runDate.equals(StaticFieldKeys.ZERO)) {
					severe(StaticErrorMsgKeys.NORECORD_RABC_CYCLE_CALENDAR + cycle);
					throw new Exception();
				}

				DateFormat df = new SimpleDateFormat("MMddyyyy");
				sqlRunDate = new java.sql.Date(df.parse(runDate).getTime());

				lineCount = 0;

				backoutRecovery = null;

				if (RabcLoadJobTrig.IsFileLoaded(connection, file)) {
					success = deleteTable();
				}
			}
			catch (Exception e) {
				severe(StaticErrorMsgKeys.PREPROCESSFILE_ERROR + StaticErrorMsgKeys.FILE_NAME_PARSING_ERROR + e);
				return false;
			}
		}
		if (success) {
			try {
				billRnd = RetrieveStaticInfo.getBillRndByCycle(connection, cycle).trim();
			}
			catch (SQLException e) {
				success = false;
				severe(StaticErrorMsgKeys.PREPROCESSFILE_ERROR + e.getMessage());
			}
			currentFile = file;
		}
		return success;
	}

	/**
	 * Inserts a record into RABC_TRIG table indicating that file has been processed for a given run
	 * date
	 * 
	 * @return boolean indicating success or failure
	 */
	protected boolean insertTrigger() {

		if (!RabcLoadJobTrig.insertTrigger(connection, currentFile.getName(), getFileId(), division, runDate,
				backoutRecovery, billRnd)) {
			return false;
		}
		return true;

	}

	/**
	 * Calls the insert trigger method
	 * 
	 * @param file
	 *            object representing the file to be processed
	 * @param boolean
	 *            indicating whether load job has been success or failure
	 * @return boolean indicating whether the post processing has been successful or failed
	 */
	public boolean postprocessFile(File file, boolean success) {

		if (success) {
			if (!insertTrigger()) {
				severe(StaticErrorMsgKeys.POSTPROCESSFILE_ERROR + StaticErrorMsgKeys.TIGGER_TABLE_INSERT_ERROR);
				success = false;
			}
		}
		return super.postprocessFile(file, success);
	}

	/**
	 * Parses a line from a CALNET-2 MVS file. The HEADER line is skipped. The number of lines
	 * processed is verified against the number of records that were expected to be processed, which
	 * is contained in the TRAILER line. All other lines are processed by calling the processRecord
	 * method.
	 * 
	 * @throws Exception
	 * @see com.sbc.bac.load.FileDBLoadJob#parseLine(java.lang.String)
	 */
	public int parseLine(String line) throws Exception {

		debug("line: " + line);
		// Do not process the header.
		if (isHeader(line)) {
			return SKIPPED;
		}
		if (isTrailer(line)) {
			// Check if the trailer count equals the number of lines processed.
			if (getTrailerCount(line) == lineCount) {
				return SKIPPED;
			}
			else {
				severe("Number of lines processed (" + lineCount + ") does not equal number in trailer ("
						+ getTrailerCount(line) + ").");
				return ERROR;
			}
		}
		else {
			return processRecord(line);
		}
	}

	/**
	 * Processes a record in the file.
	 * 
	 * @param line
	 * @return the status of the record
	 * @throws Exception
	 */
	protected abstract int processRecord(String line) throws Exception;

	/**
	 * Determines whether a line in the file is the header record.
	 * 
	 * @param line
	 * @return
	 */
	protected boolean isHeader(String line) {
		return line.startsWith("HEADER");
	}

	/**
	 * Determines whether a line in the file is the trailer record.
	 * 
	 * @param line
	 * @return
	 */
	protected boolean isTrailer(String line) {
		return line.startsWith("TRAILER");
	}

	/**
	 * Deletes the records from a given table.
	 * 
	 * @return success if deletion is successful.
	 */
	protected boolean deleteTable() {
		boolean success;
		backoutRecovery = "Y";
		success = PrepareTableForRerun.deleteTableData(connection, getTable(), division, sqlRunDate);
		return success;
	}

	/**
	 * Returns the record count in the trailer.
	 * 
	 * @param trailerLine
	 * @return the number of records in the file that should be processed
	 */
	protected int getTrailerCount(String trailerLine) {
		return Integer.parseInt(trailerLine.substring(31, 40));
	}
}
