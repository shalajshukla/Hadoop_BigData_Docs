/* Created by Gaurav Bhargava (GB0741) on Dec 8, 2006.
Copyright 2006-2008 AT&T Knowledge Ventures. All rights reserved. */

package com.att.bac.rabc.load.so.calnet;

import java.util.Date;

import com.att.bac.rabc.load.calnet.CalnetDTO;

/**
 * This class represents table RABC_SVC_ORD_Info. It has fields corresponding
 * to columns in the this table and provide getter & setter methods to populate
 * the fields.
 * @author GB0741
 */
	public class RabcSvcOrdInfo extends CalnetDTO {
	private Date runDate;
	private String division;
	private String agencyID;
	private String svcOrd;
	private int createCycle;
	private int ageCycle;
	private int cycle;

	/**
	 * @return Returns the ageCycle.
	 */
	public int getAgeCycle() {
		return ageCycle;
	}
	/**
	 * @param ageCycle The ageCycle to set.
	 */
	public void setAgeCycle(int ageCycle) {
		this.ageCycle = ageCycle;
	}
	/**
	 * @return Returns the agencyID.
	 */
	public String getAgencyID() {
		return agencyID;
	}
	/**
	 * @param agencyID The agencyID to set.
	 */
	public void setAgencyID(String agencyID) {
		this.agencyID = agencyID;
	}
	/**
	 * @return Returns the createCycle.
	 */
	public int getCreateCycle() {
		return createCycle;
	}
	/**
	 * @param createCycle The createCycle to set.
	 */
	public void setCreateCycle(int createCycle) {
		this.createCycle = createCycle;
	}
	/**
	 * @return Returns the cycle.
	 */
	public int getCycle() {
		return cycle;
	}
	/**
	 * @param cycle The cycle to set.
	 */
	public void setCycle(int cycle) {
		this.cycle = cycle;
	}
	/**
	 * @return Returns the division.
	 */
	public String getDivision() {
		return division;
	}
	/**
	 * @param division The division to set.
	 */
	public void setDivision(String division) {
		this.division = division;
	}
	/**
	 * @return Returns the runDate.
	 */
	public Date getRunDate() {
		return runDate;
	}
	/**
	 * @param runDate The runDate to set.
	 */
	public void setRunDate(Date runDate) {
		this.runDate = runDate;
	}
	/**
	 * @return Returns the svcOrd.
	 */
	public String getSvcOrd() {
		return svcOrd;
	}
	/**
	 * @param svcOrd The svcOrd to set.
	 */
	public void setSvcOrd(String svcOrd) {
		this.svcOrd = svcOrd;
	}
}