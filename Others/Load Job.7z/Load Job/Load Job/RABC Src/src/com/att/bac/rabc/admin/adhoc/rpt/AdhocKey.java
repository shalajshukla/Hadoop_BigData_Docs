/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.admin.adhoc.rpt;

import java.util.List;
import java.util.ArrayList;

/**
 * Module description: 
 * 
 * This is an adhoc report data object used to hold the keys. 
 *
 * @author Anup Thomas - AT1862
 */
public class AdhocKey {
	/*
	 * Variables to represent the fields on Adhoc Report Step 3 page.
	 */
	private String key1=null;
	private String key2=null;
	private String key3=null;
	private String key4=null;
	private String key5=null;
	private String tableName=null;
	private List columnList = new ArrayList();
	
	/**
	 * @return Returns the tableName.
	 */
	public String getTableName() {
		return tableName;
	}
	/**
	 * @param tableName The tableName to set.
	 */
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	/**
	 * @return Returns the columnList.
	 */
	public List getColumnList() {
		return columnList;
	}
	/**
	 * @param columnList The columnList to set.
	 */
	public void setColumnList(List columnList) {
		this.columnList = columnList;
	}
	/**
	 * @return Returns the key1.
	 */
	public String getKey1() {
		return key1;
	}
	/**
	 * @param key1 The key1 to set.
	 */
	public void setKey1(String key1) {
		this.key1 = key1;
	}
	/**
	 * @return Returns the key2.
	 */
	public String getKey2() {
		return key2;
	}
	/**
	 * @param key2 The key2 to set.
	 */
	public void setKey2(String key2) {
		this.key2 = key2;
	}
	/**
	 * @return Returns the key3.
	 */
	public String getKey3() {
		return key3;
	}
	/**
	 * @param key3 The key3 to set.
	 */
	public void setKey3(String key3) {
		this.key3 = key3;
	}
	/**
	 * @return Returns the key4.
	 */
	public String getKey4() {
		return key4;
	}
	/**
	 * @param key4 The key4 to set.
	 */
	public void setKey4(String key4) {
		this.key4 = key4;
	}
	/**
	 * @return Returns the key5.
	 */
	public String getKey5() {
		return key5;
	}
	/**
	 * @param key5 The key5 to set.
	 */
	public void setKey5(String key5) {
		this.key5 = key5;
	}
}
