/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/

package com.att.bac.rabc.admin.adhoc.rpt;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import com.att.bac.rabc.PresnId;
import com.att.bac.rabc.PresnIdDAO;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;

import com.att.bac.rabc.admin.MenuIndexDAO;
import com.att.bac.rabc.admin.PresnHeader;

import org.apache.log4j.Logger;

/**
 * Module description: 
 * 
 * This is a Service class used for adhoc report Deletion
 *
 * @author Anup Thomas - AT1862
 */
public class AdhocReportDeleteService {
	private static final Logger logger = Logger.getLogger(AdhocReportDeleteService.class);
	private static AdhocReportDeleteService adhocReportDeleteService; 
	
	/*
	 * Variables to represent the sql statement.
	 */
	protected static final String delReport = "UPDATE RABC_PRESN_ID SET Adhoc_RPT_STATUS = ''Delete''"
												+" WHERE 	Presn_ID = {0}";	
	
	//	 to check which user directories are empty , if yes then delete these directories from RABC_MENU_INDEX
	private static final String selEmptyUserDir = "SELECT PRESN_SEQ_NUM " +
			" FROM rabc_menu_index WHERE presn_lvl = 2 AND presn_seq_num > 2 " +
			" AND assoc_parent_id = 4 AND presn_id IS NULL AND alert_rule IS NULL " +
			" AND presn_seq_num NOT IN ( SELECT DISTINCT sub_assoc_parent_id FROM rabc_menu_index WHERE sub_assoc_parent_id " +
			" IN (SELECT presn_seq_num FROM rabc_menu_index WHERE presn_lvl = 2 AND presn_seq_num > 2 AND assoc_parent_id = 4 AND presn_id IS NULL AND alert_rule IS NULL )" +
			" AND presn_id IN (SELECT presn_id FROM rabc_presn_id WHERE UPPER (adhoc_rpt_status) = ''ACTIVE'')) " ; 	
	
	private static final String delMenuIndexDIR = "DELETE FROM RABC_MENU_INDEX "
		+" WHERE presn_lvl = 2 and PRESN_SEQ_NUM in ( {0} ) and assoc_parent_id = 4 and presn_id is null and alert_rule is null " 
		+" and presn_seq_num NOT IN ( SELECT DISTINCT sub_assoc_parent_id FROM rabc_menu_index WHERE sub_assoc_parent_id " 
		+" IN (SELECT presn_seq_num FROM rabc_menu_index WHERE presn_lvl = 2 AND presn_seq_num > 2 AND assoc_parent_id = 4 AND presn_id IS NULL AND alert_rule IS NULL )" 
		+" AND presn_id IN (SELECT presn_id FROM rabc_presn_id WHERE UPPER (adhoc_rpt_status) = ''ACTIVE'')) " ;
	
	
	/**
	 * Synchronized method to return the instance of AdhocReportDeleteService object.
	 * It checks the existance of the instance of AdhocReportDeleteService and if it does not exists
	 * then creates one instance of AdhocReportDeleteService and returns otherwise it returns the
	 * existing instance of AdhocReportDeleteService.
	 * 
	 * @return AdhocReportDeleteService
	 */
	public static synchronized AdhocReportDeleteService getAdhocReportDeleteService(){
		if (adhocReportDeleteService == null){
			adhocReportDeleteService = new AdhocReportDeleteService();
		}
		return adhocReportDeleteService;
	}
	
	/**
	 * This method is used to get the adhoc report definition for selected adhoc report
	 * @param connection
	 * @param failures
	 * @param args
	 * @return AdhocReportDefinition
	 */
	public AdhocReportDefinition getAdhocReportDefinition(Connection connection, List failures, List args ){
		
		AdhocReportDefinition adhocReportDefinition = new AdhocReportDefinition();
		
		AdhocReportDefinitionService   adhocReportDefinitionService = new AdhocReportDefinitionService();
		
		List presnIdList = adhocReportDefinitionService.getPresenDetails(connection,failures,args);
		PresnId presnId = (PresnId)presnIdList.get(0);
		adhocReportDefinition.setPresnId(presnId.getPresnId());
		adhocReportDefinition.setPresnDesc(presnId.getPresnIdDesc());
		adhocReportDefinition.setRptType(presnId.getPresnTrendTime());
		adhocReportDefinition.setAlertGroup(adhocReportDefinitionService.getAlertGroupSelected(connection,failures,args));
		adhocReportDefinition.setDataNode(presnId.getDbNodeId());
		List presnHeaderList =  adhocReportDefinitionService.getRABCPresnHeaderList(connection,failures,args) ;
		adhocReportDefinition.setHeader1(((PresnHeader)presnHeaderList.get(0)).getHeader1()) ;
		adhocReportDefinition.setHeader2(((PresnHeader)presnHeaderList.get(0)).getHeader2()) ;
		adhocReportDefinition.setHeader3(((PresnHeader)presnHeaderList.get(0)).getHeader3()) ;
		
		return(adhocReportDefinition);
	}
	
	/**
	 * This method is used to update the selected adhoc report as Deleted status
	 * @param connection
	 * @param failures
	 * @param presnId
	 */
	public void confirmDelete(Connection connection, List failures,String presnId){
		PresnIdDAO presnIdDAO= new PresnIdDAO();
		List insArgs = new ArrayList();
		insArgs.add(presnId); 
		presnIdDAO.executeUpdate(connection,failures,insArgs,delReport);
		
		deleteMenuIndexUserDirectory(connection,failures);
	}
	
	/**
	 * Private method to get the list of user directories against which no adhoc report defined .
	 * It looks for direcory name entered on page is exists, if it exists , will return presn seq number else -1 .
	 * Purposefully used integer value because same method can be used to set presn_se number attribute. 
	 * @param connection
	 * @param failureList
	 * @param adhocReportDefinition
	 * @return List
	 */
	private List getEmptyUserDirList(Connection connection,List failureList) {
		
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		List args = new ArrayList();
		List selEmptyUserDirList = new ArrayList();

		try	{
			MessageFormat mf = new MessageFormat(selEmptyUserDir);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			
			while(rs.next()){
				selEmptyUserDirList.add(new Integer (rs.getInt(1))) ; 
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		return (selEmptyUserDirList);
	}
	
	/**
	 * Private method to carry out delete operation from RABC_MENU_INDEX table for those user directories which does not 
	 * conatin any adhoc report  
	 * @param connection
	 * @param failureList
	 * @param adhocReportDefinition
	 */
	private void deleteMenuIndexUserDirectory(Connection connection, List failureList){
		MenuIndexDAO menuIndexDAO = new MenuIndexDAO();
		List selEmptyDirList = new ArrayList(); 
		List delDirArgs = new ArrayList();
		int selEmptyDirListSize ;
		String presnSeqNumStr = "" ;
		
		// Get list of empty directories 
		selEmptyDirList = getEmptyUserDirList (connection,failureList) ;
		
		selEmptyDirListSize = selEmptyDirList.size() ;
		
		if (selEmptyDirListSize > 0 ) {
			for (int i = 0 ; i < selEmptyDirListSize ; i++ ){
					if (i == (selEmptyDirListSize-1) ) {
						presnSeqNumStr += selEmptyDirList.get(i) ;	
					}else {
						presnSeqNumStr += selEmptyDirList.get(i) + "," ;
					} 
			}
		}
		if (!("").equals(presnSeqNumStr)) {
			delDirArgs.add(presnSeqNumStr) ;
			if (delDirArgs.size()  > 0 ) {
				menuIndexDAO.executeUpdate(connection,failureList,delDirArgs,delMenuIndexDIR);
			}
		}
	}
}
