/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.rpt;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.text.MessageFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.att.bac.rabc.MouseOverLink;
import com.att.bac.rabc.MouseOverLinkDAO;
import com.att.bac.rabc.MyDate;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.StaticDataLoader;

/**
 * This class represents the Service which handles processing of 
 * various SQL requests for AlertsReportDataViewService (page 12).
 * 
 * @author Nalina Pandiyan - NP5434
 */
public class AlertsReportDataViewService {
	private static final Logger logger = Logger.getLogger(AlertsReportDataViewService.class);

	private AlertReportParameters alertReportParameters = null;
	private Connection connection = null;
	private List failures = null;
	private List columns = null;
	private List qryGetDataList = null;
	private List qryKeyColList = null;
	private List qryAlertRulePresnElemList = null;
	private AlertReportView alertReportView = null;
	private List qryMouseOverLinks = new ArrayList();

	public static final String qryMouseOverLinksSQL ="SELECT PRESN_ID,webid,EXEC_PRESN_SEQ_NUM,MOUSE_OVER_NUM,link_tbl_key_name,link_tbl_key_data,link_tbl_name FROM rabc_mouse_over_link " +
										"WHERE webid = ''{0}'' AND presn_id in ({1})";
	
	public static final String qryMouseOverLookupSQL = "SELECT {0} MouseOverText FROM {1} WHERE	{2} = ''{3}''";
	
	/**
	 * This method is used to return the object of AlertsReportDataViewService class.
	 * 
	 * @return AlertsReportDataViewService
	 */
	public static AlertsReportDataViewService getAlertsReportDataViewService() {
		return new AlertsReportDataViewService();
	}

	/**
	 * @param qryAlertRulePresnElemList The qryAlertRulePresnElemList to set.
	 */
	public void setQryAlertRulePresnElemList(List qryAlertRulePresnElemList) {
		this.qryAlertRulePresnElemList = qryAlertRulePresnElemList;
	}

	/**
	 * @param connection The connection to set.
	 */
	public void setConnection(Connection connection) {
		this.connection = connection;
	}

	/**
	 * @param failures The failures to set.
	 */
	public void setFailures(List failures) {
		this.failures = failures;
	}

	/**
	 * @param alertReportParameters The alertReportParameters to set.
	 */
	public void setAlertReportParameters(AlertReportParameters alertReportParameters) {
		this.alertReportParameters = alertReportParameters;
	}

	/**
	 * @param columns The columns to set.
	 */
	public void setColumns(List columns) {
		this.columns = columns;
	}
	
	/**
	 * @param qryGetDataList The qryGetDataList to set.
	 */
	public void setQryGetDataList(List qryGetDataList) {
		this.qryGetDataList = qryGetDataList;
	}

	/**
	 * @param alertReportView The alertReportView to set.
	 */
	public void setAlertReportView(AlertReportView alertReportView) {
		this.alertReportView = alertReportView;
	}

	/**
	 * @param qryKeyColList The qryKeyColList to set.
	 */
	public void setQryKeyColList(List qryKeyColList) {
		this.qryKeyColList = qryKeyColList;
	}

	/**
	 * Method prepares AlertReportView to return processQryGetData.
	 * 
	 * @return int
	 */
	public int prepareAlertReportView() {
		buildMouseOverLinks();
		return processQryGetData();
	}
	/**
	 * This method prepares qryMouseOverLinksSQL SQL statment.
	 */
	private void buildMouseOverLinks() {
		MessageFormat mf = null;

		logger.debug("Preparing qryMouseOverLinksSQL SQL statment ....");
		List args = new ArrayList();

		args.add(alertReportParameters.getWebPageId());		

		args.add(alertReportParameters.getPresnIds());
		
		MouseOverLinkDAO mouseOverLinkDAO = new MouseOverLinkDAO();
		qryMouseOverLinks = mouseOverLinkDAO.get(connection, failures, args, qryMouseOverLinksSQL);
	}

	/**
	 * This method processes QryGetData.
	 * 
	 * @return int
	 */
	public int processQryGetData() {
		int i = 0, j = 0;
		int totalRows = 0;
		int nbrOfRows = 0;
		int size = qryGetDataList.size();
		int sizeOfColumns = columns.size();
		boolean rabcTable = false;
		QryGetData qryGetData = null;
		AlertData alertData = null;		
		AlertRow alertRow = null;
		AlertCell alertCell = null;
		String keyDdlName[];
		MyDate fileProcessDate = null;
		String tmpColName = null;
		String tmpColSeqNum= null;
		String tmpQryColVal = null;
		String tmpQryDDLName = null;
		String tmpQryTableName = null;
		boolean printedTotal = false;
		int totCols = 0;
		boolean showCol = false;
		MyDate tmpDate = null;
		QryDataAttrib qryDataAttrib = null;
		String linkBegin = null;
		String linkEnd = null;
		int dataLinkNum=-1;
		int mouseOverNum=-1;
		String showGraph = "";
		String unitInd = "";
		String dataLinkToPgm = "";
		String value;
		String fileDIV;
		String qsAlertRule="";
		String qsPartiRefId="";
		String qsPresnId="";
		String qsPresnIdAsString="";
		String qsFileSeqNum="";
		String qsStartDate="";
		String qsProcDate="";
		String qsProcDateDdl="";
		String qsEndDate="";
		String qsDivisionName="";
		String qsKey1Val="";
		String qsKey2Val="";
		String qsKey3Val="";
		String qsKey4Val="";
		String qsKey5Val="";
		String qsAKey1Val="";
		String qsAKey2Val="";
		String qsAKey3Val="";
		String qsAKey4Val="";
		String qsAKey5Val="";
		String qsKey1ValOdr="";
		String qsKey2ValOdr="";
		String qsKey3ValOdr="";
		String qsKey4ValOdr="";
		String qsKey5ValOdr="";
		String qsAKey1ValOdr="";
		String qsAKey2ValOdr="";
		String qsAKey3ValOdr="";
		String qsAKey4ValOdr="";
		String qsAKey5ValOdr="";
		String qsKeyValAll="";
		String qsAKeyValAll="";
		String qsKeyValOdrAll="";
		String qsAKeyValOdrAll="";
		String qsAlertItem="";
		String qsThisAlertTimeInd="";
		String qsGraphParam="";
		String mouseOverText="";
		String tmpQryAlertItem = "";
		int nbrOfKeys = alertReportParameters.getNbrOfKeys();
		alertData = new AlertData();
		displayColumns(alertData);
		for(i = 0; i < size; i++) {
			qryGetData = (QryGetData) qryGetDataList.get(i);
			fileProcessDate = qryGetData.getFileProcessDate();
			if ((alertReportParameters.getAllInfoIndicator().equals("Y")) || (fileProcessDate.compareTo(alertReportParameters.getProcDate()) > -1)) {
				alertRow = new AlertRow();
				if ((qryGetData.getThisTable().equals("RABC_EXTRCT_SUMY_DATA")) |
					(qryGetData.getThisTable().equals("RABC_CALC_ALERT_DATA")) |
					(qryGetData.getThisTable().equals("RABC_ALERT_HIST"))) {
					rabcTable = true;
				} else {
					rabcTable = false;	
				}
				keyDdlName = getKeyCols(qryGetData.getThisTable(), qryGetData.getPresnId());

				qsAlertRule="alertrule=" + alertReportParameters.getAlertRule();
				qsPresnId="presnId=" + qryGetData.getPresnId();
				qsPresnIdAsString="presnIdAsString=" + qryGetData.getPresnId();
				qsPartiRefId="partiRefId=" + qryGetData.getThisPartiRefId();
				qsProcDateDdl="extractDateName=" + qryGetData.getThisProcDate().toString();
				qsFileSeqNum="fileSeqNum=" + qryGetData.getSequenceNumber();
				qsThisAlertTimeInd="alertTimeInd=" + qryGetData.getThisAlertTimeInd();
				qsProcDate="procDate=" +alertReportParameters.getProcDate().toString();

				int index = (alertReportParameters.getDivisionNameKeyLvl().intValue()<=0?0:alertReportParameters.getDivisionNameKeyLvl().intValue());
				if(alertReportParameters.getDivisionNameKeyLvl().intValue() > 0 && qryGetData.isExist("key"+index)){
					qsDivisionName="divisionName="+qryGetData.getValueFor("key"+index);
				}else{
					qsDivisionName="divisionName= ";
				}
				
				if(qryGetData.isExist("key1")){
					qsKey1Val="key1="+qryGetData.getValueFor("key1");
					qsAKey1Val="aKey1="+qryGetData.getValueFor("key1");
					qsKey1ValOdr="key1="+keyDdlName[0]+"="+qryGetData.getValueFor("key1");
					qsAKey1ValOdr="aKey1="+qryGetData.getValueFor("key1");
				}else{
					qsKey1Val="key1=";
					qsAKey1Val="aKey1=";
					qsKey1ValOdr="key1=1=1";
					qsAKey1ValOdr="aKey1=";
				}
				if(qryGetData.isExist("key2")){
					qsKey2Val="key2="+qryGetData.getValueFor("key2");
					qsAKey2Val="aKey2="+qryGetData.getValueFor("key2");
					qsKey2ValOdr="key2="+keyDdlName[1]+"="+qryGetData.getValueFor("key2");
					qsAKey2ValOdr="aKey2="+qryGetData.getValueFor("key2");
				}else{
					qsKey2Val="key2=";
					qsAKey2Val="aKey2=";
					qsKey2ValOdr="key2=1=1";
					qsAKey2ValOdr="aKey2=";
				}
				if(qryGetData.isExist("key3")){
					qsKey3Val="key3="+qryGetData.getValueFor("key3");
					qsAKey3Val="aKey3="+qryGetData.getValueFor("key3");
					qsKey3ValOdr="key3="+keyDdlName[2]+"="+qryGetData.getValueFor("key3");
					qsAKey3ValOdr="aKey3="+qryGetData.getValueFor("key3");
				}else{
					qsKey3Val="key3=";
					qsAKey3Val="aKey3=";
					qsKey3ValOdr="key3=1=1";
					qsAKey3ValOdr="aKey3=";
				}
				if(qryGetData.isExist("key4")){
					qsKey4Val="key4="+qryGetData.getValueFor("key4");
					qsAKey4Val="aKey4="+qryGetData.getValueFor("key4");
					qsKey4ValOdr="key4="+keyDdlName[3]+"="+qryGetData.getValueFor("key4");
					qsAKey4ValOdr="aKey4="+qryGetData.getValueFor("key4");
				}else{
					qsKey4Val="key4=";
					qsAKey4Val="aKey4=";
					qsKey4ValOdr="key4=1=1";
					qsAKey4ValOdr="aKey4=";
				}
				if(qryGetData.isExist("key5")){
					qsKey5Val="key5="+qryGetData.getValueFor("key5");
					qsAKey5Val="aKey5="+qryGetData.getValueFor("key5");
					qsKey5ValOdr="key5="+keyDdlName[4]+"="+qryGetData.getValueFor("key5");
					qsAKey5ValOdr="aKey5="+qryGetData.getValueFor("key5");
				}else{
					qsKey5Val="key5=";
					qsAKey5Val="aKey5=";
					qsKey5ValOdr="key5=1=1";
					qsAKey5ValOdr="aKey5=";
				}
				qsKeyValAll=qsKey1Val+"&"+qsKey2Val+"&"+qsKey3Val+"&"+qsKey4Val+"&"+qsKey5Val;
				qsAKeyValAll=qsAKey1Val+"&"+qsAKey2Val+"&"+qsAKey3Val+"&"+qsAKey4Val+"&"+qsAKey5Val;
				qsKeyValOdrAll=qsKey1ValOdr+"&"+qsKey2ValOdr+"&"+qsKey3ValOdr+"&"+qsKey4ValOdr+"&"+qsKey5ValOdr;
				qsAKeyValOdrAll=qsAKey1ValOdr+"&"+qsAKey2ValOdr+"&"+qsAKey3ValOdr+"&"+qsAKey4ValOdr+"&"+qsAKey5ValOdr;
				qsAlertItem="";
				qsThisAlertTimeInd="";
				if(rabcTable){
					if(qryGetData.getSequenceNumber()!=0) {
						qsGraphParam=qsAlertRule+"&"+qsFileSeqNum+"&"+qsKeyValAll+"&"+qsAKeyValAll+"&"+qsProcDate+"&"+qsPartiRefId+"&"+qsProcDateDdl+"&PartiRefId=" + qryGetData.getThisPartiRefId()+"&ProcDate=" +alertReportParameters.getProcDate().toString();
					} else {
						qsGraphParam=qsAlertRule+"&"+qsKeyValAll+"&"+qsAKeyValAll+"&"+qsProcDate+"&"+qsPartiRefId+"&"+qsProcDateDdl+"&PartiRefId=" + qryGetData.getThisPartiRefId()+"&ProcDate=" +alertReportParameters.getProcDate().toString();
					}
				}else{
					if(qryGetData.getSequenceNumber()!=0) {
						qsGraphParam=qsAlertRule+"&"+qsFileSeqNum+"&"+qsKeyValOdrAll+"&"+qsAKeyValOdrAll+"&"+qsProcDate+"&"+qsPartiRefId+"&"+qsProcDateDdl+"&PartiRefId=" + qryGetData.getThisPartiRefId()+"&ProcDate=" +alertReportParameters.getProcDate().toString();
					} else {
						qsGraphParam=qsAlertRule+"&"+qsKeyValOdrAll+"&"+qsAKeyValOdrAll+"&"+qsProcDate+"&"+qsPartiRefId+"&"+qsProcDateDdl+"&PartiRefId=" + qryGetData.getThisPartiRefId()+"&ProcDate=" +alertReportParameters.getProcDate().toString();
					}
				}
				
				alertRow.setRowColor("#ffffff");
				if (fileProcessDate.compareTo(alertReportParameters.getProcDate()) == -1) {
					alertRow.setRowColor("#cccccc"); // gray color
				}
				printedTotal = false;
				totCols = 0;
				for(j = 0; j < sizeOfColumns; j++) {
					alertCell = new AlertCell();
					tmpColName = ((String) columns.get(j)).trim();
					tmpColSeqNum = null;
					if (tmpColName.indexOf("~")!=-1){
						String [] tmpColNameArr = tmpColName.split("~");
						tmpColName = tmpColNameArr[0];
						tmpColSeqNum = tmpColNameArr[1];
					}
					tmpColName = tmpColName.replace('.','_');
					tmpColName = tmpColName.replace(' ','_');
					if (tmpColSeqNum!=null){
						tmpQryColVal = qryGetData.getValueFor(tmpColName + "~" + tmpColSeqNum);
						tmpQryDDLName = "";
						tmpQryTableName = "";
						if (qryGetData.isExist(tmpColName + "~" + tmpColSeqNum + "_D")) {
							tmpQryDDLName = qryGetData.getValueFor(tmpColName + "~" + tmpColSeqNum + "_D");
							tmpQryTableName = qryGetData.getThisTable();
						}
					} else {
						tmpQryColVal = qryGetData.getValueFor(tmpColName);
						tmpQryDDLName = "";
						tmpQryTableName = "";
						if (qryGetData.isExist(tmpColName + "_D")) {
							tmpQryDDLName = qryGetData.getValueFor(tmpColName + "_D");
							tmpQryTableName = qryGetData.getThisTable();
						}
					}
					
					//
					tmpQryAlertItem = "";
					if (qryGetData.isExist("Alert_Item~1")) {
						tmpQryAlertItem = qryGetData.getValueFor("Alert_Item~1").toString();
					} else if (qryGetData.isExist("Alert_Item~2")) {
						tmpQryAlertItem = qryGetData.getValueFor("Alert_Item~2").toString();
					} 
					showCol = true;
					if ((qryGetData.getThisTotInd().equals("Y")) && (!printedTotal)) {
						if (tmpQryTableName.equals("")) {
							alertCell.setValign("top");
							alertCell.setNowrap("nowrap");
							alertCell.setThisClass("cellText");
							if ((tmpColName.equals(AlertsReportDataSQLService.getLabel("alertData.label.fileProcessDate").replace(' ','_'))) && (qryGetData.getThisPrevTotInd().equals("Y"))) {
								try {
									tmpDate = new MyDate(tmpQryColVal);
								} catch (ParseException e) {
									tmpDate = null;
								}
								if (tmpDate != null) {
									if (tmpDate.compareTo(alertReportParameters.getProcDate()) == -1) {
										tmpDate = new MyDate(qryGetData.getFileProcessDate());
										alertCell.setValue(tmpDate.toString() + "- Previous Data");
									}
								} else {
									tmpDate = new MyDate(qryGetData.getFileProcessDate());
									alertCell.setValue(tmpDate.toString());									
								}
							} else {
								alertCell.setValue(tmpQryColVal==null?"":tmpQryColVal);
							}
							totCols += 1;
							showCol = false;
						} else {
							if (!qryGetData.getThisPrevTotInd().equals("Y")) {
								alertCell.setValue(getPresnDesc(qryGetData.getPresnId()));
							}
							showCol = true;
							printedTotal = true;
						}
					}
					if (showCol) {
						alertCell.setThisClass("cellText");
						alertCell.setValign("top");
						alertCell.setAlign("left");
						
						if ((isNumeric(tmpQryColVal)) && (j >= nbrOfKeys)) {
							// current column is not the key column
							alertCell.setAlign("right");
							if (!tmpColName.equals(AlertsReportDataSQLService.getLabel("alertData.label.seqNumber").replace(' ','_'))) {
								if (tmpQryAlertItem.indexOf("CALLS") > -1) {
									tmpQryColVal = FormatNumber(tmpQryColVal, ",");
								} else {
									if (tmpColName.equalsIgnoreCase("BILL_RND") || tmpColName.equalsIgnoreCase("BILL-RND")) {
										tmpQryColVal = FormatNumber(tmpQryColVal, new String(","));
									} else {
										tmpQryColVal = FormatNumber(tmpQryColVal, new String(",.99"));
									}
								}
							}
							alertCell.setNowrap("nowrap");
						}
						if (tmpQryColVal == null || tmpQryColVal.equals("")) {
							alertCell.setValue("");
						} else {
							if (j < nbrOfKeys) {
								alertCell.setExcelDataType("T");
								alertCell.setValue(tmpQryColVal==null?"":tmpQryColVal);
								// Key Column
								qryDataAttrib = getQryDataAttrib(qryGetData.getPresnId(),null,j);
								if (qryDataAttrib.keyDataLinkInd!=null && qryDataAttrib.keyDataLinkInd.equals("Y")) {
									dataLinkNum = qryDataAttrib.keyDataLinkNum;
									linkBegin ="AdhocRpt.do?"+qsProcDate+"&"+qsPresnId+"&"+qsPresnIdAsString+"&"+qsFileSeqNum+"&"+qsKeyValAll+"&clickLevel="+j+ "&popup="+(alertReportParameters.getPopup()?"Y":"N");
									linkEnd="";
								} else {
									dataLinkNum = -1;
									linkBegin = "";
									linkEnd="";									
								}
								mouseOverNum = -1;
								if (qryDataAttrib.keyDescInd!=null && qryDataAttrib.keyDescInd.equals("Y")) {
									mouseOverNum = qryDataAttrib.keyMouseOverNum; 
								}
								showGraph = "";
								unitInd = "";
								if ("DIVISION".equalsIgnoreCase(tmpColName)){
									mouseOverText = StaticDataLoader.getDivisionDesc(alertReportParameters.getRegion(),tmpQryColVal);
								} else {
									mouseOverText = getMouseOverText(mouseOverNum, tmpQryColVal);
								}
								alertCell.setTitle(mouseOverText);
							} else {
								// data column
								alertCell.setExcelDataType("N");
								alertCell.setValue(tmpQryColVal==null?"":tmpQryColVal);
								unitInd = "";
								showGraph = "";
								mouseOverNum = -1;
								dataLinkNum = -1;
								dataLinkToPgm = "";
								if (tmpColSeqNum!=null) {
									qryDataAttrib = getQryDataAttrib(qryGetData.getPresnId(),tmpColName + "~" + tmpColSeqNum,-1);
								} else {
									qryDataAttrib = getQryDataAttrib(qryGetData.getPresnId(),tmpColName,-1);
								}
								if(qryDataAttrib!=null) {
									unitInd = qryDataAttrib.presnUnitInd;
									showGraph = qryDataAttrib.graphPresnInd;
									mouseOverNum = qryDataAttrib.dataMouseOverNum;
									dataLinkNum = qryDataAttrib.dataLinkNum;
									dataLinkToPgm = qryDataAttrib.dataLinkToPgm;
								}
								if (dataLinkNum > 0) {
									if (tmpColName.equals(AlertsReportDataSQLService.getLabel("alertData.label.seqNumber").replace(' ','_'))) {
										linkBegin = qryDataAttrib.dataLinkToPgm+"?"+qsPartiRefId+"&"+qsFileSeqNum+"&"+qsProcDate+"&"+qsDivisionName+ "&popup="+(alertReportParameters.getPopup()?"Y":"N");
										linkEnd="";
										alertCell.setTitle("View Sequence Number Alert Details Report");
									} else {
										linkBegin = qryDataAttrib.dataLinkToPgm+"?"+qsProcDate+"&"+qsPresnId+"&"+qsPresnIdAsString+"&"+qsFileSeqNum+"&"+qsKeyValAll+ "&popup="+(alertReportParameters.getPopup()?"Y":"N");
										linkEnd = "";
									}
								} else {
									linkBegin = "";
									linkEnd="";																		
								}
							}
							if (mouseOverNum > 0) {
								mouseOverText = getMouseOverText(mouseOverNum, tmpQryColVal);
							} else {
								mouseOverText = "";
							}
							if (tmpColName.equals(AlertsReportDataSQLService.getLabel("alertData.label.seqNumber").replace(' ','_'))) {
								if (tmpQryColVal!=null && tmpQryColVal.equals("0")) alertCell.setValue("");
								linkBegin = "AlertTrckMainSeqPage.do?"+qsPartiRefId+"&"+qsFileSeqNum+"&"+qsProcDate+"&"+qsDivisionName+ "&popup="+(alertReportParameters.getPopup()?"Y":"N");
								linkEnd = "";						
								alertCell.setTitle("View Sequence Number Alert Details Report");
							}
							alertCell.setHref(linkBegin + linkEnd);
							//alertCell.setTitle(mouseOverText);
							value = "";
							if (unitInd!=null && unitInd.equals("D")) {
								value = "$ ";
							}
							value = value + tmpQryColVal;
							if (unitInd!=null && unitInd.equals("P")) {
								value = value + "%";
							}
							if (tmpColName.equals(AlertsReportDataSQLService.getLabel("alertData.label.fileProcessDate").replace(' ','_'))) {
								try {
									tmpDate = new MyDate(tmpQryColVal);
								} catch (ParseException e) {
									tmpDate = null;
								}
								if (tmpDate != null) {
									if (tmpDate.compareTo(alertReportParameters.getProcDate()) == -1) {
										value = value + "- Previous Data";
									}
								} 
							}
							if (tmpColName.equals(AlertsReportDataSQLService.getLabel("alertData.label.seqNumber").replace(' ','_'))) {
								if (tmpQryColVal!=null && tmpQryColVal.equals("0")) {
									alertCell.setValue("");
									alertCell.setThisClass("");
									alertCell.setHrefForImage("");
									alertCell.setImageSrc("");
									alertCell.setTitle("");
									alertCell.setAddlnTitle("");
								} else {
									fileDIV  = qryGetData.getValueFor("key"+alertReportParameters.getDivisionNameKeyLvl());
									//<!--- Build href for image link --->
									alertCell.setThisClass("DataLink");
									alertCell.setHrefForImage("javascript:popWin(15,'" + qsPartiRefId + "&" +qsFileSeqNum+"&"+qsDivisionName+"&"+qsProcDate+"&"+"fileDIV="+fileDIV+"')");
									alertCell.setImageSrc("db1.gif");
									alertCell.setTitle("View File Names for Sequence Number");
									alertCell.setAddlnTitle("View File Names for Sequence Number");
								}
							}
							if (showGraph!=null && showGraph.equals("Y")) {
								//show graph
								qsAlertItem = "alertItem="+urlEncodedFormat(tmpQryAlertItem);
								alertCell.setThisClass("DataLink");
								alertCell.setHrefForImage("javascript:popWin(1,'" + urlEncodedFormat(qsGraphParam + "&" +qsAlertItem) +"&Header="+tmpColName+"&tableName="+tmpQryTableName+"&itemDDlName="+tmpQryDDLName+"');");
								alertCell.setImageSrc("graph.gif");
								alertCell.setTitle("View Data Graph");
								alertCell.setAddlnTitle("View Data Graph");
							}
							showGraph = "";
						} // value not blank
						alertRow.addColumnData(alertCell);
					} // end of Show Col
				} // end column loop
				alertData.addAlertRow(alertRow);
				totalRows++;
				nbrOfRows++;
				alertRow = null;
			}
		} // end of row loop
		if (alertRow != null) {
			alertData.addAlertRow(alertRow);
			nbrOfRows++;
			totalRows++;
		}
		alertData.setNbrOfColumns(new Integer(alertData.getColumnNames().size()));
		alertData.setNbrOfRows(new Integer(nbrOfRows));
		alertReportView.addAlertData(alertData);
		return totalRows;
	}

	/**
	 * This method is used to get MouseOverText for the passed mouseOverNum and colName.
	 * 
	 * @param mouseOverNum
	 * @param colName
	 * @return String
	 */
	private String getMouseOverText(int mouseOverNum, String colName) {
		int i = 0;
		int size = qryMouseOverLinks.size();
		MouseOverLink mouseOverLink = null;
		for (i = 0; i < size; i++) {
			mouseOverLink = (MouseOverLink) qryMouseOverLinks.get(i);
			if (mouseOverLink.getMouseOverNum() == mouseOverNum) {
				if ((!mouseOverLink.getLinkTblName().equals("")) && (!mouseOverLink.getLinkTblKeyName().equals(""))) {
					return mouseOverLookup(mouseOverLink, colName);
				}
			}
		}
		return "no description found";
	}

	/**
	 * This method executes query for Mouse Over Links with table Name.
	 * 
	 * @param mouseOverLink
	 * @param colName
	 * @return String
	 */
	private String mouseOverLookup(MouseOverLink mouseOverLink, String colName) {
		Statement stmt = null;
		ResultSet rs = null;
		String returnValue = null;
		String qryMouseOverLookupSQLStmt = null;
		try {
			logger.debug("Executing query for Mouse Over Links with table Name = " + mouseOverLink.getLinkTblName() + ", Column Name = " + mouseOverLink.getLinkTblKeyData() + ", key = " + mouseOverLink.getLinkTblKeyName() + " ....");
			MessageFormat mf = new MessageFormat(qryMouseOverLookupSQL);
			qryMouseOverLookupSQLStmt = mf.format(new String[]{mouseOverLink.getLinkTblKeyData(), mouseOverLink.getLinkTblName(), mouseOverLink.getLinkTblKeyName(), colName});
			logger.debug("qryMouseOverLookupSQLStmt statement = " + qryMouseOverLookupSQLStmt);			
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qryMouseOverLookupSQLStmt);
			if (rs != null) {
				while (rs.next()) {								
					returnValue = rs.getString("MouseOverText");
					break;
				}
			} else {
				return "no description found";
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryMouseOverLookupSQLStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryMouseOverLookupSQLStmt}), sx));
			return "no description found";
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
		
		return returnValue;
	}
	
	/**
	 * This method returns the string for urlEncodedFormat.
	 * 
	 * @param s
	 * @return String
	 */
	private String urlEncodedFormat(String s) {
		if (s == null) return null;
		try {
			return URLEncoder.encode(s, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			return null;
		}
	}

	/**
	 * This method is used to get QryDataAttrib for the passed presnId, tmpColName and keyNum.
	 * 
	 * @param presnId
	 * @param tmpColName
	 * @param keyNum
	 * @return QryDataAttrib
	 */
	private QryDataAttrib getQryDataAttrib(int presnId, String tmpColName, int keyNum) {
		int i = 0;
		int size = qryAlertRulePresnElemList.size();
		QryDataAttrib qryDataAttrib = null;
		QryAlertRulePresnElem qryAlertRulePresnElem = null;
		
		// Check whether column has a PRESN_SEQ_NUM tagged
		String tmpColSeqNum = null;
		if (tmpColName!=null && tmpColName.indexOf("~")!=-1){
			String [] tmpColNameArr = tmpColName.split("~");
			tmpColName = tmpColNameArr[0];
			tmpColSeqNum = tmpColNameArr[1];
		}
		
		for (i = 0; i < size; i++) {
			qryAlertRulePresnElem = (QryAlertRulePresnElem) qryAlertRulePresnElemList.get(i);
			if (qryAlertRulePresnElem.getPresnId() == presnId) {
				if (tmpColName == null) {
					// request for key column
					qryDataAttrib = new QryDataAttrib();
					if (keyNum > 4) {
						logger.warn("LOGIC Error - key num is  = " + keyNum);
						keyNum = 0;
					}
					qryDataAttrib.keyDataLinkInd = qryAlertRulePresnElem.getKeyDataLinkIndAt(keyNum);
					qryDataAttrib.keyDataLinkNum = qryAlertRulePresnElem.getKeyDataLinkNumAt(keyNum);
					qryDataAttrib.keyDescInd = qryAlertRulePresnElem.getKeyDescIndAt(keyNum);
					qryDataAttrib.keyMouseOverNum = qryAlertRulePresnElem.getKeyMouseOverNumAt(keyNum);
					return qryDataAttrib; 
				} else {
					// request for data column
					String presnName = qryAlertRulePresnElem.getPresnName();
					int presnSeqNum = qryAlertRulePresnElem.getPresnSeqNum();
					presnName = presnName.replace(' ','_');
					
					// Additional condition in case of a sequence number
					if (tmpColSeqNum != null && presnName.equals(tmpColName) && Integer.parseInt(tmpColSeqNum) == presnSeqNum){
						qryDataAttrib = new QryDataAttrib();
						qryDataAttrib.presnUnitInd = qryAlertRulePresnElem.getPresnUnitInd();
						qryDataAttrib.dataMouseOverNum = qryAlertRulePresnElem.getDataMouseOverNum();
						qryDataAttrib.dataLinkNum = qryAlertRulePresnElem.getDataLinkNum();
						qryDataAttrib.graphPresnInd = qryAlertRulePresnElem.getGraphPresnInd();
						qryDataAttrib.dataLinkToPgm = qryAlertRulePresnElem.getDataLinkToPgm();
						return qryDataAttrib;
					} else if (tmpColSeqNum == null && presnName.equals(tmpColName)) {
						qryDataAttrib = new QryDataAttrib();
						qryDataAttrib.presnUnitInd = qryAlertRulePresnElem.getPresnUnitInd();
						qryDataAttrib.dataMouseOverNum = qryAlertRulePresnElem.getDataMouseOverNum();
						qryDataAttrib.dataLinkNum = qryAlertRulePresnElem.getDataLinkNum();
						qryDataAttrib.graphPresnInd = qryAlertRulePresnElem.getGraphPresnInd();
						qryDataAttrib.dataLinkToPgm = qryAlertRulePresnElem.getDataLinkToPgm();
						return qryDataAttrib;
					}
				}
			}
		}
		return null;
	}

	/**
	 * This method returns the value for the given FormatNumber.
	 * 
	 * @param tmpQryColVal
	 * @param format
	 * @return String
	 */
	private String FormatNumber(String tmpQryColVal, String format) {
		double dVal = Double.parseDouble(tmpQryColVal);

		String value = "";
		String formatNum="";
		if(format.equals(",")){
			formatNum = "##,###,###,###,###";
		}else if(format.equals(",.99")){
			formatNum = "##,###,###,###,###";
			formatNum = formatNum + ".00";
		}
		if(dVal!=0){
			NumberFormat formatter = new DecimalFormat(formatNum);
			value = formatter.format(dVal);
		}else{
			value="0.00";
		}
		return value;
	}

	/**
	 * This method returns the boolean value for the passed tmpQryColVal in isNumeric class.
	 * 
	 * @param tmpQryColVal
	 * @return boolean
	 */
	private static boolean isNumeric(String tmpQryColVal) {
		if (tmpQryColVal == null) return false;
		try {
			Double tmpValue = new Double(tmpQryColVal);
			return true;
		} catch (NumberFormatException e) {
			return false;
		}
	}

	/**
	 * This method is used to get PresnDesc for the passed presnId.
	 * 
	 * @param presnId
	 * @return String
	 */
	private String getPresnDesc(int presnId) {
		int i = 0;
		int size = qryAlertRulePresnElemList.size();
		QryAlertRulePresnElem qryAlertRulePresnElem = null;
		for (i = 0; i < size; i++) {
			qryAlertRulePresnElem = (QryAlertRulePresnElem) qryAlertRulePresnElemList.get(i);
			if (qryAlertRulePresnElem.getPresnId() == presnId) {
				return qryAlertRulePresnElem.getPresnIdDesc();
			}
		}
		return "";
	}

	/**
	 * This method returns a string array to get KeyCols for the passed presnId.
	 * 
	 * @param thisTable
	 * @param presnId
	 * @return String[]
	 */
	private String[] getKeyCols(String thisTable, int presnId) {
		int i = 0;
		int size = qryAlertRulePresnElemList.size();
		QryAlertRulePresnElem qryAlertRulePresnElem = null;
		String[] keys = {"","","","",""};
		for (i = 0; i < size; i++) {
			qryAlertRulePresnElem = (QryAlertRulePresnElem) qryAlertRulePresnElemList.get(i);
			if ((qryAlertRulePresnElem.getDataTbl().equals(thisTable)) && (qryAlertRulePresnElem.getPresnId() == presnId)) {
				keys[0] = qryAlertRulePresnElem.getKeyDdlNameAt(0);
				keys[1] = qryAlertRulePresnElem.getKeyDdlNameAt(1);
				keys[2] = qryAlertRulePresnElem.getKeyDdlNameAt(2);
				keys[3] = qryAlertRulePresnElem.getKeyDdlNameAt(3);
				keys[4] = qryAlertRulePresnElem.getKeyDdlNameAt(4);
				return keys;
			}
		}
		return null;
	}

	/**
	 * This method is used to add standard columns from AlertsReportDataSQLService.
	 */
	public void addStandardColumns() {
		columns.add(AlertsReportDataSQLService.getLabel("alertData.label.fileProcessDate"));
		if(alertReportParameters.getSeqCnt() > 0){
			columns.add(AlertsReportDataSQLService.getLabel("alertData.label.seqNumber"));
		}
		alertReportParameters.setNbrStdColumns(new Integer(columns.size() - alertReportParameters.getNbrOfKeys()));
	}

	/**
	 * This method is used to display Columns for the passed alertData.
	 * 
	 * @param alertData
	 */
	private void displayColumns(AlertData alertData) {
		int i = 0;
		int size = columns.size();
		String colName;
		String tmpName = AlertsReportDataSQLService.getLabel("alertData.label.fileProcessDate");
		for(i = 0; i < size; i++) {
			colName = (String) columns.get(i);
			if (colName.indexOf("~")!=-1){
				colName = colName.substring(0,colName.indexOf("~"));
			}
			colName = colName.replaceAll("DW_RABC","ODR");
			colName = colName.replace('.',' '); 
			if (colName.equals(tmpName)) {
				colName = AlertsReportDataSQLService.getLabel("alertData.label.fileDate");
			}
			
			if ("DIVISION".equalsIgnoreCase(colName)){
				alertData.addColumnName("Division");
			}else if ("CYCLE".equalsIgnoreCase(colName)){
				alertData.addColumnName("Cycle");
			}else {
				alertData.addColumnName(colName);
			}
		}
	}
	
	/**
	 * This class handles QryDataAttrib with its parameters.
	 */
	private class QryDataAttrib {
		private String keyDataLinkInd;
		private int keyDataLinkNum;
		private String keyDescInd;
		private int keyMouseOverNum;
		private String presnUnitInd;
		private int dataMouseOverNum;
		private int dataLinkNum;
		private String graphPresnInd;
		private String dataLinkToPgm;
	}

	/**
	 * This class handles QryMouseover with its parameters.
	 */
	private class QryMouseover{
		private String linkTblName;
		private String linkTblKeyData;
		private String linkTblKeyName;
	}

}
