/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.alerts.status;

import com.att.bac.rabc.MyDate;

/**
 * This is a Data Object used to represent data obtained from RABC_EXTRCT_SUMY_DATA table 
 * or ExtrctSumyData is java representation for RABC_EXTRCT_SUMY_DATA table.
 * 
 * @author Shailesh Hemdev - SH8512
 */
public class ExtrctSumyData {
	private double extrctData1;
	private double extrctData2;
	private double extrctData3;
	private double extrctData4;
	private double extrctData5;
	private double extrctData6;
	private double extrctData7;
	private double extrctData8;
	private double extrctData9;
	private double extrctData10;
	private double extrctData11;
	private double extrctData12;
	private double extrctData13;
	private double extrctData14;
	private double extrctData15;
	private int partiRefId;
	private int presnCd;
	private int fileSeqNum;
	private MyDate procDate;
	private String alertTrendTime;
	private String extrctKey1;
	private String extrctKey2;
	private String extrctKey3;
	private String extrctKey4;
	private String extrctKey5;
	private MyDate timeStamp;
	private double sumExtrctData;
	private double sumTotalData = -1;
	private String procDateString;
	
	/**
	 * @return Returns the alertTrendTime.
	 */
	public String getAlertTrendTime() {
		return alertTrendTime;
	}
	/**
	 * @param alertTrendTime The alertTrendTime to set.
	 */
	public void setAlertTrendTime(String alertTrendTime) {
		this.alertTrendTime = alertTrendTime;
	}
	/**
	 * @return Returns the extrctData1.
	 */
	public double getExtrctData1() {
		return extrctData1;
	}
	/**
	 * @param extrctData1 The extrctData1 to set.
	 */
	public void setExtrctData1(double extrctData1) {
		this.extrctData1 = extrctData1;
	}
	/**
	 * @return Returns the extrctData10.
	 */
	public double getExtrctData10() {
		return extrctData10;
	}
	/**
	 * @param extrctData10 The extrctData10 to set.
	 */
	public void setExtrctData10(double extrctData10) {
		this.extrctData10 = extrctData10;
	}
	/**
	 * @return Returns the extrctData11.
	 */
	public double getExtrctData11() {
		return extrctData11;
	}
	/**
	 * @param extrctData11 The extrctData11 to set.
	 */
	public void setExtrctData11(double extrctData11) {
		this.extrctData11 = extrctData11;
	}
	/**
	 * @return Returns the extrctData12.
	 */
	public double getExtrctData12() {
		return extrctData12;
	}
	/**
	 * @param extrctData12 The extrctData12 to set.
	 */
	public void setExtrctData12(double extrctData12) {
		this.extrctData12 = extrctData12;
	}
	/**
	 * @return Returns the extrctData13.
	 */
	public double getExtrctData13() {
		return extrctData13;
	}
	/**
	 * @param extrctData13 The extrctData13 to set.
	 */
	public void setExtrctData13(double extrctData13) {
		this.extrctData13 = extrctData13;
	}
	/**
	 * @return Returns the extrctData14.
	 */
	public double getExtrctData14() {
		return extrctData14;
	}
	/**
	 * @param extrctData14 The extrctData14 to set.
	 */
	public void setExtrctData14(double extrctData14) {
		this.extrctData14 = extrctData14;
	}
	/**
	 * @return Returns the extrctData15.
	 */
	public double getExtrctData15() {
		return extrctData15;
	}
	/**
	 * @param extrctData15 The extrctData15 to set.
	 */
	public void setExtrctData15(double extrctData15) {
		this.extrctData15 = extrctData15;
	}
	/**
	 * @return Returns the extrctData2.
	 */
	public double getExtrctData2() {
		return extrctData2;
	}
	/**
	 * @param extrctData2 The extrctData2 to set.
	 */
	public void setExtrctData2(double extrctData2) {
		this.extrctData2 = extrctData2;
	}
	/**
	 * @return Returns the extrctData3.
	 */
	public double getExtrctData3() {
		return extrctData3;
	}
	/**
	 * @param extrctData3 The extrctData3 to set.
	 */
	public void setExtrctData3(double extrctData3) {
		this.extrctData3 = extrctData3;
	}
	/**
	 * @return Returns the extrctData4.
	 */
	public double getExtrctData4() {
		return extrctData4;
	}
	/**
	 * @param extrctData4 The extrctData4 to set.
	 */
	public void setExtrctData4(double extrctData4) {
		this.extrctData4 = extrctData4;
	}
	/**
	 * @return Returns the extrctData5.
	 */
	public double getExtrctData5() {
		return extrctData5;
	}
	/**
	 * @param extrctData5 The extrctData5 to set.
	 */
	public void setExtrctData5(double extrctData5) {
		this.extrctData5 = extrctData5;
	}
	/**
	 * @return Returns the extrctData6.
	 */
	public double getExtrctData6() {
		return extrctData6;
	}
	/**
	 * @param extrctData6 The extrctData6 to set.
	 */
	public void setExtrctData6(double extrctData6) {
		this.extrctData6 = extrctData6;
	}
	/**
	 * @return Returns the extrctData7.
	 */
	public double getExtrctData7() {
		return extrctData7;
	}
	/**
	 * @param extrctData7 The extrctData7 to set.
	 */
	public void setExtrctData7(double extrctData7) {
		this.extrctData7 = extrctData7;
	}
	/**
	 * @return Returns the extrctData8.
	 */
	public double getExtrctData8() {
		return extrctData8;
	}
	/**
	 * @param extrctData8 The extrctData8 to set.
	 */
	public void setExtrctData8(double extrctData8) {
		this.extrctData8 = extrctData8;
	}
	/**
	 * @return Returns the extrctData9.
	 */
	public double getExtrctData9() {
		return extrctData9;
	}
	/**
	 * @param extrctData9 The extrctData9 to set.
	 */
	public void setExtrctData9(double extrctData9) {
		this.extrctData9 = extrctData9;
	}
	/**
	 * @return Returns the extrctKey1.
	 */
	public String getExtrctKey1() {
		return extrctKey1;
	}
	/**
	 * @param extrctKey1 The extrctKey1 to set.
	 */
	public void setExtrctKey1(String extrctKey1) {
		this.extrctKey1 = extrctKey1;
	}
	/**
	 * @return Returns the extrctKey2.
	 */
	public String getExtrctKey2() {
		return extrctKey2;
	}
	/**
	 * @param extrctKey2 The extrctKey2 to set.
	 */
	public void setExtrctKey2(String extrctKey2) {
		this.extrctKey2 = extrctKey2;
	}
	/**
	 * @return Returns the extrctKey3.
	 */
	public String getExtrctKey3() {
		return extrctKey3;
	}
	/**
	 * @param extrctKey3 The extrctKey3 to set.
	 */
	public void setExtrctKey3(String extrctKey3) {
		this.extrctKey3 = extrctKey3;
	}
	/**
	 * @return Returns the extrctKey4.
	 */
	public String getExtrctKey4() {
		return extrctKey4;
	}
	/**
	 * @param extrctKey4 The extrctKey4 to set.
	 */
	public void setExtrctKey4(String extrctKey4) {
		this.extrctKey4 = extrctKey4;
	}
	/**
	 * @return Returns the extrctKey5.
	 */
	public String getExtrctKey5() {
		return extrctKey5;
	}
	/**
	 * @param extrctKey5 The extrctKey5 to set.
	 */
	public void setExtrctKey5(String extrctKey5) {
		this.extrctKey5 = extrctKey5;
	}
	/**
	 * @return Returns the fileSeqNum.
	 */
	public int getFileSeqNum() {
		return fileSeqNum;
	}
	/**
	 * @param fileSeqNum The fileSeqNum to set.
	 */
	public void setFileSeqNum(int fileSeqNum) {
		this.fileSeqNum = fileSeqNum;
	}
	/**
	 * @return Returns the partiRefId.
	 */
	public int getPartiRefId() {
		return partiRefId;
	}
	/**
	 * @param partiRefId The partiRefId to set.
	 */
	public void setPartiRefId(int partiRefId) {
		this.partiRefId = partiRefId;
	}
	/**
	 * @return Returns the presnCd.
	 */
	public int getPresnCd() {
		return presnCd;
	}
	/**
	 * @param presnCd The presnCd to set.
	 */
	public void setPresnCd(int presnCd) {
		this.presnCd = presnCd;
	}
	/**
	 * @return Returns the procDate.
	 */
	public MyDate getProcDate() {
		return procDate;
	}
	/**
	 * @param procDate The procDate to set.
	 */
	public void setProcDate(MyDate procDate) {
		this.procDate = procDate;
	}
	/**
	 * @return Returns the timeStamp.
	 */
	public MyDate getTimeStamp() {
		return timeStamp;
	}
	/**
	 * @param timeStamp The timeStamp to set.
	 */
	public void setTimeStamp(MyDate timeStamp) {
		this.timeStamp = timeStamp;
	}
	/**
	 * @return Returns the sumExtrctData.
	 */
	public double getSumExtrctData() {
		return sumExtrctData;
	}
	/**
	 * @param sumExtrctData The sumExtrctData to set.
	 */
	public void setSumExtrctData(double sumExtrctData) {
		this.sumExtrctData = sumExtrctData;
	}
	/**
	 * @return Returns the sumTotalData.
	 */
	public double getSumTotalData() {
		return sumTotalData;
	}
	/**
	 * @param sumTotalData The sumTotalData to set.
	 */
	public void setSumTotalData(double sumTotalData) {
		this.sumTotalData = sumTotalData;
	}
	/**
	 * @return Returns the procDateString.
	 */
	public String getProcDateString() {
		return procDateString;
	}
	/**
	 * @param procDateString The procDateString to set.
	 */
	public void setProcDateString(String procDateString) {
		this.procDateString = procDateString;
	}
}
