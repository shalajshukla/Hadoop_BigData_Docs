/* Created by GB0741 on 06-Nov-07
 * Copyright 2008 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.load.calnet.telcoacus;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.att.bac.rabc.Report;
import com.att.carat.util.Email;
//changes done for M168 by as635b
import com.att.carat.load.Application;
import com.att.carat.load.TimedLoadJob;
//import com.sbc.bac.load.Application;
//import com.sbc.bac.load.TimedLoadJob;

/**
 * This component controls the generation of excel reports of bill amount discrepancies and btn discrepancies 
 * and sending these reports to the recipients.
 *
 */
public class CrisAcusReportLoadJob extends TimedLoadJob{
    public static Logger logger = Logger.getLogger(CrisAcusReportLoadJob.class);
    
    private Report 	billAmtExcel 		= null;
    private Report 	btnExcel 			= null;
	private File 	billAmtReportFile 	= null;
	private File 	btnReportFile 		= null;
	private String  fileLocation		= null;
	private String  recipient_email		= "";
	private String  emailBody			= "";
	private String  emailSubject		= "";
	private String  billAmtReportName	= "";
	private String  btnReportName		= "";
	protected SimpleDateFormat dateFormat 	= new SimpleDateFormat("MMddyyyy");
	
	public CrisAcusReportLoadJob() {
	}
	
   /* (non-Javadoc)
    * @see com.sbc.bac.load.TimedLoadJob#configure(com.sbc.bac.load.Application, java.util.Properties)
    */
	protected boolean configure(Application application, Properties configuration) {
        boolean success = super.configure(application, configuration);
        if (success) {
 			info("CrisAcusReportLoadJob is scheduled to run on "
			        + new java.util.Date(this.runtime.getTimeInMillis()));
 			
 			// gets parameters' values from config file CrisAcus.cfg
 			fileLocation 		= configuration.getProperty("file_location").trim();
 			emailBody 	 		= configuration.getProperty("email_body").trim();
 			emailSubject 		= configuration.getProperty("email_subject").trim();
 			billAmtReportName 	= configuration.getProperty("billAmt_report_name").trim();
 			btnReportName 	  	= configuration.getProperty("btn_report_name").trim();
 			
			if (fileLocation.equals("")){ 
				severe("Please specify file_location in CrisAcusReport.cfg");
				return false;
			}
			
			if (emailBody.equals("")){ 
				severe("Please specify email_body in CrisAcusReport.cfg");
				return false;
			}
			
			if (emailSubject.equals("")){ 
				severe("Please specify email_subject in CrisAcusReport.cfg");
				return false;
			}
			
			if (billAmtReportName.equals("")){ 
				severe("Please specify billAmt_report_name in CrisAcusReport.cfg");
				return false;
			}
			
			if (btnReportName.equals("")){ 
				severe("Please specify btn_report_name in CrisAcusReport.cfg");
				return false;
			}
        }
         return success;
    }

	/**
	 * This method gets the bill amount discrepancies and btn discrepancies of cris acus reocords from DAO 
	 * and calls method to generate and send these discrepancies' excel files to the recipients. 
 	 */
	public boolean action() {
		boolean success = false;
		
		List<CrisAcus> billAmtReport = new ArrayList<CrisAcus>();
		List<CrisAcus> btnReport  	 = new ArrayList<CrisAcus>();
		String[] recipientId = null;

		try {
			CrisAcusDAO dao = new CrisAcusDAO();
			
			// gets the list of bill amount discrepancies
			billAmtReport = dao.billAmtRecords(connection);
			if(billAmtReport.size()==0) {
				info("No Cris Acus Bill Amount discrepancy found.");
			} 
			
			// gets the list of btn discrepancies
			btnReport = dao.btnRecords(connection);				
			if(btnReport.size()==0) {
				info("No Cris Acus BTN discrepancy found.");
			}
			// make recipient email as blank before each run of report to avoid concatenation of emails 
			recipient_email = "";
			recipientId = null;
			
			// if discrepacies found, process the data to send email else, return true.
			if(!(billAmtReport.size()==0)){
				// gets recipient's email-id
				recipientId = dao.getRecipientId(connection); 
				if(recipientId.length== 0){
					info("Recipient's email-id not found.");
					success= false;
				} else{
					for(int i=0; i < recipientId.length; i++){
						recipient_email += recipientId[i] + ";" ;
					}
					//remove the trailing semi-colon.
					recipient_email = recipient_email.substring(0, recipient_email.length()-1);
					
					// calls method to generate and send excel files of these records
					success = sendReport(connection, billAmtReport, btnReport);
				}	
			} else{
				success = true;
			}
			info("success: " + success);
		}
		catch (Exception exc) {
			severe("Error generating reports.", exc);
		}
		return success;
	}
   
	/**
	 * This method generates the excel files of bill amount discrepancies and btn discrepancies of cris acus 
	 * reocords and  send these reports to the recipients. 
 	 * @param connection
	 * @param billAmtRecordsList
	 * @param btnRecordsList
	 * @return
	 * @throws CrisAcusException
	 */
	private boolean sendReport(Connection connection, List billAmtRecordsList, List btnRecordsList) throws CrisAcusException {
	    
		boolean success= false;
	    try {
		    // Gets bill Amtount discrepancies report
	    	if (billAmtRecordsList.size()>0){
		        billAmtReportFile = new File(fileLocation+ "\\"+ billAmtReportName+ "_" + 
		        								dateFormat.format(runtime.getTime())+ ".xls");
		        OutputStream out1 = new FileOutputStream(billAmtReportFile);
		        billAmtExcel = new Report(out1);
	    	}

	    	// Gets btn discrepancies report
	    	if (btnRecordsList.size()>0){
		        btnReportFile = new File(fileLocation+ "\\"+ btnReportName+ "_" + 
											dateFormat.format(runtime.getTime())+ ".xls");
		        OutputStream out2 = new FileOutputStream(btnReportFile);
		        btnExcel = new Report(out2);
	    	}    
	    } catch(IOException ioe){
	        throw new CrisAcusException("Unable to create temporary report files", ioe);
	    }
	    
	    // calls method to create bill excel reports 
		boolean result = createExcelSheets(connection, billAmtRecordsList, btnRecordsList);

		// send discrepancy excel reports in email to the recipient
		if(result){
			// get the list of files to be e-mailed
			ArrayList<File> fileList = new ArrayList<File>(); 
			if (billAmtRecordsList.size()>0) {
				fileList.add(billAmtReportFile);
			}
			if (btnRecordsList.size()>0) {
				fileList.add(btnReportFile);
			}
			
			File[] files = (File[]) fileList.toArray(new File[fileList.size()]);
			
			//Send e-mail with excel reports as attachment
			Email.sendEmail(recipient_email, emailSubject, emailBody, files);
			info("Cris Acus Discrepacy Reports sent to " +recipient_email);
			
			success= true;
		} 
		return success;
	}
	
	/**
	 * This method populates the excel files
	 * @param connection
	 * @param billAmtRecordsList
	 * @param btnRecordsList
	 * @return
	 * @throws CrisAcusException
	 */
	private boolean createExcelSheets(Connection connection, List billAmtRecordsList, List btnRecordsList) throws CrisAcusException {
	     try {
	    	boolean success = false;

	    	// populate bill Amount discrepancy report
	    	if (billAmtRecordsList.size()>0){
		    	billAmtExcel.beginReport();
		        
		        //Add report title
		        billAmtExcel.beginRow().addTitle("BillAmount Discrepancies Report", 11).endRow();
		        billAmtExcel.beginRow().endRow();
		
	        	// Add data columns
		        billAmtExcel.beginRow();
		        billAmtExcel.addRaw("<th rowspan=2>CRIS BTN</th>");
		        billAmtExcel.addRaw("<th rowspan=2>CRIS Current Month<br>Charge Amount</th>");        	
		        billAmtExcel.addRaw("<th rowspan=2>CRIS Bill Round</th>");        	
		        billAmtExcel.addRaw("<th rowspan=2>CRIS Bill Month</th>");
		        billAmtExcel.addRaw("<th rowspan=2>CRIS Year</th>");
		        billAmtExcel.addRaw("<th rowspan=2>ACUS BTN</th>");
		        billAmtExcel.addRaw("<th rowspan=2>ACUS Provider<br>Received Amount</th>");
		        billAmtExcel.addRaw("<th rowspan=2>ACUS Provider<br>Bill Round</th>");
		        billAmtExcel.addRaw("<th rowspan=2>ACUS Provider<br>Invoice Month</th>");
		        billAmtExcel.addRaw("<th rowspan=2>ACUS Provider<br>Invoice Year</th>");
		        billAmtExcel.addRaw("<th rowspan=2>Data Extract Date</th>");
		        billAmtExcel.endRow();
	
		        // Row separator
		        billAmtExcel.beginRow();
		        billAmtExcel.endRow();
	        	            	
	        	// Loop through all the elements for data
		       	for (int i= 0;i < billAmtRecordsList.size();i++) {
	        	    CrisAcus crisAcus = (CrisAcus) billAmtRecordsList.get(i);
	        	    billAmtExcel.beginRow();
	        		billAmtExcel.addNumberColumn(crisAcus.getCrisBtn());
	        		billAmtExcel.addColumn(Double.parseDouble(crisAcus.getCrisBillAmt()));
	        		billAmtExcel.addColumn(crisAcus.getCrisBillRnd());
	        		billAmtExcel.addColumn(crisAcus.getCrisBillMm());
	        		billAmtExcel.addColumn(crisAcus.getCrisYear());
	        		billAmtExcel.addNumberColumn(crisAcus.getAcusBtn());
	        		billAmtExcel.addColumn(Double.parseDouble(crisAcus.getAcusReceivedAmt()));
	        		billAmtExcel.addColumn(crisAcus.getAcusBillRnd());
	        		billAmtExcel.addColumn(crisAcus.getAcusBillMm());
	        		billAmtExcel.addColumn(crisAcus.getAcusYear());
	        		billAmtExcel.addColumn(crisAcus.getDataExtractDt());
	        		billAmtExcel.endRow();
		       	}
		       	billAmtExcel.endReport();
	    	}
	    	
		  	// populate btn discrepancy report
		    if (btnRecordsList.size()>0){
		    	btnExcel.beginReport();
		        
		        //Add report title
		        btnExcel.beginRow().addTitle("BTNs in CRIS but not in ACUS Report", 6).endRow();
		        btnExcel.beginRow().endRow();
		
	        	// Add data columns
		        btnExcel.beginRow();
		        btnExcel.addRaw("<th rowspan=2>CRIS BTN</th>");
		        btnExcel.addRaw("<th rowspan=2>CRIS Current Month<br>Charge Amount</th>");        	
		        btnExcel.addRaw("<th rowspan=2>CRIS Bill Round</th>");        	
		        btnExcel.addRaw("<th rowspan=2>CRIS Bill Month</th>");
		        btnExcel.addRaw("<th rowspan=2>CRIS Year</th>");
		        btnExcel.addRaw("<th rowspan=2>Data Extract Date</th>");
		        btnExcel.endRow();
	
		        // Row separator
		        btnExcel.beginRow();
		        btnExcel.endRow();
		        
	        	// Loop through all the elements for data
		       	for (int i= 0;i < btnRecordsList.size();i++) {
	        	    CrisAcus crisAcus = (CrisAcus) btnRecordsList.get(i);
	        	    btnExcel.beginRow();
	        		btnExcel.addNumberColumn(crisAcus.getCrisBtn());
	        		btnExcel.addColumn(Double.parseDouble(crisAcus.getCrisBillAmt()));
	        		btnExcel.addColumn(crisAcus.getCrisBillRnd());
	        		btnExcel.addColumn(crisAcus.getCrisBillMm());
	        		btnExcel.addColumn(crisAcus.getCrisYear());
	        		btnExcel.addColumn(crisAcus.getDataExtractDt());
	        		btnExcel.endRow();
		       	}
		       	btnExcel.endReport();
		    }    
	    success = true;
		return success;
	    } catch(IOException ioe){
	        throw new CrisAcusException("Unable to create reports",ioe);
	    }
	}
		
    /* (non-Javadoc)
     * @see com.sbc.bac.load.TimedLoadJob#postprocess(boolean)
     */
    protected boolean postprocess(boolean success) {
        success = super.postprocess(success);
        if (success) {
            info(load_job_name + " is scheduled to run again on " 
            		 + new java.util.Date(this.runtime.getTimeInMillis()));
        }
        return success;
    }
}
