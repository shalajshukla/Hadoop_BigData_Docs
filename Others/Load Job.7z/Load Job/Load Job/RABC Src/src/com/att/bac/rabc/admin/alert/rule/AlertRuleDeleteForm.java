/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.admin.alert.rule;

import org.apache.struts.action.ActionForm;

/**
 * This is a Struts Action form for Alert Rule Deletion Page.
 * 
 * @author Shailesh Hemdev - SH8512
 */
public class AlertRuleDeleteForm extends ActionForm {
	private String dispatch;
	private String actionType = "DELETE";
	private String alertRule;
	private AlertRuleDefinition alertRuleDefinition = new AlertRuleDefinition("WE");

	/**
	 * @return Returns the actionType.
	 */
	public String getActionType() {
		return actionType;
	}
	/**
	 * @param actionType The actionType to set.
	 */
	public void setActionType(String actionType) {
		this.actionType = actionType;
	}
	/**
	 * @return Returns the alertRuleDefinition.
	 */
	public AlertRuleDefinition getAlertRuleDefinition() {
		return alertRuleDefinition;
	}
	/**
	 * @param alertRuleDefinition The alertRuleDefinition to set.
	 */
	public void setAlertRuleDefinition(AlertRuleDefinition alertRuleDefinition) {
		this.alertRuleDefinition = alertRuleDefinition;
	}
	/**
	 * @return Returns the dispatch.
	 */
	public String getDispatch() {
		return dispatch;
	}
	/**
	 * @param dispatch The dispatch to set.
	 */
	public void setDispatch(String dispatch) {
		this.dispatch = dispatch;
	}

	/**
	 * @return Returns the alertRule.
	 */
	public String getAlertRule() {
		return alertRule;
	}
	/**
	 * @param alertRule The alertRule to set.
	 */
	public void setAlertRule(String alertRule) {
		this.alertRule = alertRule;
	}
}
