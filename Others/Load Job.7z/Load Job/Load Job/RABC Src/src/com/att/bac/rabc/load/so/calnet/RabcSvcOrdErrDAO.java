/* Created by Gaurav Bhargava (GB0741) on Dec 8, 2006.
Copyright 2006-2008 AT&T Knowledge Ventures. All rights reserved. */

package com.att.bac.rabc.load.so.calnet;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.att.bac.rabc.load.calnet.CalnetDAO;
import com.att.bac.rabc.load.calnet.CalnetDTO;
import com.att.bac.rabc.load.calnet.CalnetException;

/**
 * Data Access Object class for RABC_SVC_ORD_ERR table.
 * It is used to perform database operation on this table.
 * @author GB0741
 */
public class RabcSvcOrdErrDAO extends CalnetDAO {

	private static final String INSERT_SQL = "INSERT INTO RABC_SVC_ORD_ERR(RUN_DATE,DIVISION,CYCLE,AGENCY_ID,ERROR_CD,ERROR_CT) VALUES(?,?,?,?,?,?)";

	/**
	 * Returns the insert statement used to insert a record into RABC_SVC_ORD_ERR
	 * table.
	 * @return Returns the insert statement
	 */
	protected String getInsertSql(){
		return INSERT_SQL;
	}

	/**
	 * Reads the field values from passed DTO object and sets as corresponding
	 * parameters of the PreparedStatement
	 * @param pstmt - PreparedStatement object for setting the parameters.
	 * @param dataTransferObject - CalnetDTO for reading the field values.
	 * @throws CalnetException Throws exception when there is an error in setting
	 * the parameter.
	 */
	protected void setValues(PreparedStatement pstmt, CalnetDTO dataTransferObject)
				throws CalnetException{
		RabcSvcOrdErr rabcSvcErr = (RabcSvcOrdErr)dataTransferObject;
		try{
			pstmt.setDate(1, new Date(rabcSvcErr.getRunDate().getTime()));
			pstmt.setString(2, rabcSvcErr.getDivision());
			pstmt.setInt(3,rabcSvcErr.getCycle());
			pstmt.setString(4, rabcSvcErr.getAgencyID());
			pstmt.setString(5, rabcSvcErr.getErrorCd());
			pstmt.setInt(6, rabcSvcErr.getErrorCt());
		}catch(SQLException ex){
			throw new CalnetException("Error setting values in prepared statement: Agency ID "
											+ rabcSvcErr.getAgencyID() + ex.getMessage(), ex);
		}
	}
}
