/*
 * Copyright  2002-2006 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.adhoc.aria;

import java.util.HashMap;
import java.util.Map;
import java.util.Stack;


/**
 * Structure to hold keys in pivot reports
 * 
 * <p>
 * <hr>
 * <h3>Release History</h3>
 * <p>
 * <ul>
 * 
 * <li>jb6494 Nov 16, 2006 Created class.
 * 
 * </ul>
 * <p>
 * 
 */
class RowKeys {
    public Object[] key = new Object[5];

    public Map sections = new HashMap();


    public RowKeys(Object k1, Object k2, Object k3, Object k4, Object k5) {
        super();
        key[0] = k1;
        key[1] = k2;
        key[2] = k3;
        key[3] = k4;
        key[4] = k5;
    }


    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    public boolean equals(Object obj) {
        return equals(obj, 0, key.length - 1);
    }


    /**
     * Convenience method to get all the keys as a stack
     * 
     * @return
     */
    public Stack keysAsStack() {
        Stack stack = new Stack();
        for (int i = 4; i >= 0; i--) {
            if (key[i] != null) {
                stack.push(key[i]);
            }
        }
        return stack;
    }


    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    public String toString() {
        StringBuffer buf = new StringBuffer(100);
        for (int i = 0; i < key.length; i++) {
            buf.append("key");
            buf.append(i + 1);
            buf.append("=");
            buf.append(key[i]);
            buf.append(", ");
        }
        buf.append("sections.size=");
        buf.append(sections.size());
        return buf.toString();
    }


    /**
     * Determine if keys in the range are equal to the object.
     * 
     * @param obj
     * @param fromIndex
     * @param toIndex
     * @return
     */
    private boolean equals(Object obj, int fromIndex, int toIndex) {
        if (obj == null) {
            return false;
        }
        if (obj instanceof RowKeys) {
            RowKeys o1 = (RowKeys) obj;
            boolean b = true;

            // check to see if everything is null
            for (int i = fromIndex; i <= toIndex; i++) {
                b &= o1.key[i] == null ? o1.key[i] == null : false;
            }
            if (b) {
                return true;
            }

            // test each key
            b = true;
            for (int i = fromIndex; i <= toIndex; i++) {
                if (o1.key[i] == null) {
                    b &= key[i] == null;
                } else {
                    b &= o1.key[i].equals(key[i]);
                }
            }
            return b;
        }
        return false;
    }


    /**
     * Determines if an inner break has occurred.
     * 
     * @param prevRow
     * @return
     */
    boolean isInnerBreak(RowKeys prevRow) {
        return !equals(prevRow, 2, 4);
    }


    /**
     * Determines if an outer break has occurred.
     * 
     * @param prevRow
     * @return
     */
    boolean isOuterBreak(RowKeys prevRow) {
        return !equals(prevRow, 0, 1);
    }
}
