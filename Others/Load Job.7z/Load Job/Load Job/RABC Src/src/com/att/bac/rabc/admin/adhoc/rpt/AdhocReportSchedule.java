/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.admin.adhoc.rpt;

import java.util.ArrayList;

import java.util.List;

import com.att.bac.rabc.PickList;
import com.att.bac.rabc.RABCConstantsLists;
import com.att.bac.rabc.StaticDataLoader;

/**
 * Module description: 
 * 
 * This is a adhoc report scheduler object. 
 *
 * @author Anup Thomas - AT1862
 */
public class AdhocReportSchedule {
	private int  presnId; // report id
	private String reportName; // report name
	private String startDate;
	private String days;
	private String frequency;
	private String emailTo;
	private String saveToDisk="N";
	private String schedRptNum; // unique id for a schedule
	private String frequencyDataWeekly;
	private String frequencyDataMonthly;
	private String frequencyDataYearly;
	private String frequencyDataCycleCode;
	private String frequencyDataRunDay;
	private String frequencyDataYearlyMonth;
	private String frequencyDataYearlyYear;
	private String division;
	
	/*
	 * List for the various options
	 */
	private List frequencyList;
	private List frequencyDataWeeklyList;
	private List frequencyDataMonthlyList;
	private List frequencyDataCycleCodeList;
	private List frequencyDataRunDayList;
	private List divisionList;

	/**
	 * Default constructor
	 * @param region
	 */
	public AdhocReportSchedule(String region){
		this.frequencyList = new ArrayList();
		List frequencyList = RABCConstantsLists.getRABCConstantsLists().getAdhocSchedulerFrequencyList(region);
		if (!frequencyList.isEmpty()){
			int frequencyListSize = frequencyList.size();
			for (int i=0;i<frequencyListSize;i++){
				PickList frequency = (PickList)frequencyList.get(i);
				this.addFrequency(frequency);
			}
		}
		
		this.frequencyDataWeeklyList = new ArrayList();
		List frequencyDataWeeklyList = RABCConstantsLists.getRABCConstantsLists().getAdhocSchedulerWeekDaysList();
		if (!frequencyDataWeeklyList.isEmpty()){
			int frequencyDataWeeklyListSize = frequencyDataWeeklyList.size();
			for (int i=0;i<frequencyDataWeeklyListSize;i++){
				PickList frequencyDataWeekly= (PickList)frequencyDataWeeklyList.get(i);
				this.addFrequencyDataWeekly(frequencyDataWeekly);
			}
		}
		
		this.frequencyDataMonthlyList = new ArrayList();
		List frequencyDataMonthlyList = RABCConstantsLists.getRABCConstantsLists().getAdhocSchedulerMonthDaysList();
		if (!frequencyDataMonthlyList.isEmpty()){
			int frequencyDataMonthlySize = frequencyDataMonthlyList.size();
			for (int i=0;i<frequencyDataMonthlySize;i++){
				PickList frequencyDataMonthly= (PickList)frequencyDataMonthlyList.get(i);
				this.addFrequencyDataMonthly(frequencyDataMonthly);
			}
		}
		
		this.frequencyDataCycleCodeList = new ArrayList();
		List frequencyDataCycleCodeList = StaticDataLoader.getBillRndByRegion(region);//RABCConstantsLists.getRABCConstantsLists().getAdhocSchedulerCycleCodeList();
		if (!frequencyDataCycleCodeList.isEmpty()){
			int frequencyDataCycleCodeListSize = frequencyDataCycleCodeList.size();
			for (int i=0;i<frequencyDataCycleCodeListSize;i++){
				String cycleCode = (String)frequencyDataCycleCodeList.get(i);
				PickList frequencyDataCycleCode= new PickList(cycleCode, cycleCode);
				this.addFrequencyDataCycleCode(frequencyDataCycleCode);
			}
		}
		
		this.frequencyDataRunDayList = new ArrayList();
		List frequencyDataRunDayList = RABCConstantsLists.getRABCConstantsLists().getAdhocSchedulerRunDayList();
		if (!frequencyDataRunDayList.isEmpty()){
			int frequencyDataRunDayListSize = frequencyDataRunDayList.size();
			for (int i=0;i<frequencyDataRunDayListSize;i++){
				PickList frequencyDataRunDay= (PickList)frequencyDataRunDayList.get(i);
				this.addFrequencyDataRunDay(frequencyDataRunDay);
			}
		}	
		
		this.divisionList = StaticDataLoader.getDivisionsByRegion(region);
	}

	/**
	 * @return Returns the saveToDisk.
	 */
	public String getSaveToDisk() {
		return saveToDisk;
	}
	/**
	 * @return Returns the frequencyDataYearlyMonth.
	 */
	public String getFrequencyDataYearlyMonth() {
		return frequencyDataYearlyMonth;
	}
	/**
	 * @param frequencyDataYearlyMonth The frequencyDataYearlyMonth to set.
	 */
	public void setFrequencyDataYearlyMonth(String frequencyDataYearlyMonth) {
		this.frequencyDataYearlyMonth = frequencyDataYearlyMonth;
	}
	/**
	 * @return Returns the frequencyDataYearlyYear.
	 */
	public String getFrequencyDataYearlyYear() {
		return frequencyDataYearlyYear;
	}
	/**
	 * @param frequencyDataYearlyYear The frequencyDataYearlyYear to set.
	 */
	public void setFrequencyDataYearlyYear(String frequencyDataYearlyYear) {
		this.frequencyDataYearlyYear = frequencyDataYearlyYear;
	}
	/**
	 * @return Returns the days.
	 */
	public String getDays() {
		return days;
	}
	/**
	 * @param days The days to set.
	 */
	public void setDays(String days) {
		this.days = days;
	}
	/**
	 * @return Returns the emailTo.
	 */
	public String getEmailTo() {
		return emailTo;
	}
	/**
	 * @param emailTo The emailTo to set.
	 */
	public void setEmailTo(String emailTo) {
		this.emailTo = emailTo;
	}
	/**
	 * @return Returns the frequency.
	 */
	public String getFrequency() {
		return frequency;
	}
	/**
	 * @param frequency The frequency to set.
	 */
	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}
	/**
	 * @return Returns the frequencyDataCycleCode.
	 */
	public String getFrequencyDataCycleCode() {
		return frequencyDataCycleCode;
	}
	/**
	 * @param frequencyDataCycleCode The frequencyDataCycleCode to set.
	 */
	public void setFrequencyDataCycleCode(String frequencyDataCycleCode) {
		this.frequencyDataCycleCode = frequencyDataCycleCode;
	}
	/**
	 * @return Returns the frequencyDataCycleCodeList.
	 */
	public List getFrequencyDataCycleCodeList() {
		return frequencyDataCycleCodeList;
	}

	/**
	 * @return Returns the frequencyDataMonthly.
	 */
	public String getFrequencyDataMonthly() {
		return frequencyDataMonthly;
	}
	/**
	 * @param frequencyDataMonthly The frequencyDataMonthly to set.
	 */
	public void setFrequencyDataMonthly(String frequencyDataMonthly) {
		this.frequencyDataMonthly = frequencyDataMonthly;
	}
	/**
	 * @return Returns the frequencyDataMonthlyList.
	 */
	public List getFrequencyDataMonthlyList() {
		return frequencyDataMonthlyList;
	}

	/**
	 * @return Returns the frequencyDataRunDay.
	 */
	public String getFrequencyDataRunDay() {
		return frequencyDataRunDay;
	}
	/**
	 * @param frequencyDataRunDay The frequencyDataRunDay to set.
	 */
	public void setFrequencyDataRunDay(String frequencyDataRunDay) {
		this.frequencyDataRunDay = frequencyDataRunDay;
	}
	/**
	 * @return Returns the frequencyDataRunDayList.
	 */
	public List getFrequencyDataRunDayList() {
		return frequencyDataRunDayList;
	}

	/**
	 * @return Returns the frequencyDataWeekly.
	 */
	public String getFrequencyDataWeekly() {
		return frequencyDataWeekly;
	}
	/**
	 * @param frequencyDataWeekly The frequencyDataWeekly to set.
	 */
	public void setFrequencyDataWeekly(String frequencyDataWeekly) {
		this.frequencyDataWeekly = frequencyDataWeekly;
	}
	/**
	 * @return Returns the frequencyDataWeeklyList.
	 */
	public List getFrequencyDataWeeklyList() {
		return frequencyDataWeeklyList;
	}

	/**
	 * @return Returns the frequencyDataYearly.
	 */
	public String getFrequencyDataYearly() {
		return frequencyDataYearly;
	}
	/**
	 * @param frequencyDataYearly The frequencyDataYearly to set.
	 */
	public void setFrequencyDataYearly(String frequencyDataYearly) {
		this.frequencyDataYearly = frequencyDataYearly;
	}
	/**
	 * @return Returns the frequencyList.
	 */
	public List getFrequencyList() {
		return frequencyList;
	}

	/**
	 * @return Returns the presnId.
	 */
	public int getPresnId() {
		return presnId;
	}
	/**
	 * @param presnId The presnId to set.
	 */
	public void setPresnId(int presnId) {
		this.presnId = presnId;
	}
	/**
	 * @return Returns the reportName.
	 */
	public String getReportName() {
		return reportName;
	}
	/**
	 * @param reportName The reportName to set.
	 */
	public void setReportName(String reportName) {
		this.reportName = reportName;
	}
	/**
	 * @return Returns the saveToDisk.
	 */
	public String isSaveToDisk() {
		return saveToDisk;
	}
	/**
	 * @param saveToDisk The saveToDisk to set.
	 */
	public void setSaveToDisk(String saveToDisk) {
		this.saveToDisk = saveToDisk;
	}
	/**
	 * @return Returns the schedRptNum.
	 */
	public String getSchedRptNum() {
		return schedRptNum;
	}
	/**
	 * @param schedRptNum The schedRptNum to set.
	 */
	public void setSchedRptNum(String schedRptNum) {
		this.schedRptNum = schedRptNum;
	}
	/**
	 * @return Returns the startDate.
	 */
	public String getStartDate() {
		return startDate;
	}
	/**
	 * @param startDate The startDate to set.
	 */
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	
	
	/**
	 * @param frequencyDataCycleCodeList The frequencyDataCycleCodeList to set.
	 */
	public void addFrequencyDataCycleCode(PickList frequencyDataCycleCode) {
		this.frequencyDataCycleCodeList.add(frequencyDataCycleCode);
	}
	/**
	 * @param frequencyDataMonthlyList The frequencyDataMonthlyList to set.
	 */
	public void addFrequencyDataMonthly(PickList frequencyDataMonthly) {
		this.frequencyDataMonthlyList.add(frequencyDataMonthly);
	}
	/**
	 * @param frequencyDataRunDayList The frequencyDataRunDayList to set.
	 */
	public void addFrequencyDataRunDay(PickList frequencyDataRunDay) {
		this.frequencyDataRunDayList.add(frequencyDataRunDay);
	}
	/**
	 * @param frequencyDataWeeklyList The frequencyDataWeeklyList to set.
	 */
	public void addFrequencyDataWeekly(PickList frequencyDataWeekly) {
		this.frequencyDataWeeklyList.add(frequencyDataWeekly);
	}
	/**
	 * @param frequencyList The frequencyList to set.
	 */
	public void addFrequency(PickList frequency) {
		this.frequencyList.add(frequency);
	}
	
	/**
	 * @return Returns the division.
	 */
	public String getDivision() {
		return division;
	}
	/**
	 * @param division The division to set.
	 */
	public void setDivision(String division) {
		this.division = division;
	}
	/**
	 * @return Returns the divisionList.
	 */
	public List getDivisionList() {
		return divisionList;
	}
	/**
	 * @param divisionList The divisionList to set.
	 */
	public void setDivisionList(List divisionList) {
		this.divisionList = divisionList;
	}
}
