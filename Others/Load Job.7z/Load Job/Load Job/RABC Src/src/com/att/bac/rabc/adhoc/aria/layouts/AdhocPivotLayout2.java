/*
 * Copyright  2002-2006 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.adhoc.aria.layouts;

import java.io.BufferedWriter;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeMap;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;

import com.att.bac.rabc.RABCConstantsLists;
import com.att.bac.rabc.adhoc.AdhocConstants;
import com.att.bac.rabc.adhoc.aria.ARIAReportRABC;
import com.att.bac.rabc.adhoc.aria.AbstractAriaLayoutPivot;
import com.att.bac.rabc.adhoc.aria.LayoutHelper;
import com.att.bac.rabc.adhoc.aria.pivot.AdhocPivotData;
import com.att.bac.rabc.adhoc.aria.pivot.DatedCompositeKey;
import com.att.bac.rabc.adhoc.aria.pivot.Page13PivotHTMLProcessor;
import com.att.bac.rabc.adhoc.rpt.AdhocRptDataTO;
import com.sbc.bac.aria.ARIAReportException;
import com.sbc.bac.aria.ARIAReportProcessor;

/**
 * Layout 2A = Monthly Report
 * 
 * <p>
 * <hr>
 * <h3>Release History</h3>
 * <p>
 * <ul>
 * 
 * <li>jb6494 Sep 06, 2006 Created class.
 * <li>jb6494 Mar 09, 2007 KC issue: previous data still referenced lag function
 * <li>jb6494 Mar 14, 2007 ML21 Trapped number format errors and replaced with "NaN"
 * <li>jb6494 Mar 15, 2007 ML19: show headers when no data found
 * 
 * </ul>
 * <p>
 * 
 */
public class AdhocPivotLayout2 extends AbstractAriaLayoutPivot implements AdhocConstants {
    protected static final boolean DEBUG = false;
    public static Logger logger = Logger.getLogger(AdhocPivotLayout2.class);
    
    /**
     * Create layout 2
     * 
     * @param form
     * @param os
     * @param userid
     */
    public AdhocPivotLayout2(ActionForm form, OutputStream os, String userid) {
        super(form, os, userid);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.att.bac.rabc.adhoc.rpt.AbstractAdhocAriaLayout#execute(com.sbc.bac.aria.ARIAReport[],
     *      com.att.bac.rabc.adhoc.rpt.AdhocRptDataTO)
     */
    public void execute(ARIAReportRABC[] reports, AdhocRptDataTO dto) throws Exception {
        setDtoBase(dto);

        try {
            Page13PivotHTMLProcessor processor = createProcessor(os); 
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(os));
  
            if (reports != null) {              
                /*
                 * Main loop to execute each report section.
                 */
                for (int i = 0; i < reports.length; i++) {
                    setDto(reports[i].getDto()); 
                    setSection(i);
                    processor.setSectionNo(i);
                    
                    // Get previous data loaded
                    setupPreviousDataTable(i); 
                    
                    // Clear all old values
                    clear();
                    
                    /*
                     * Only show paging on the 1st section
                     */
                    if (isOutputExcel()) {
                        processor.setShowPaging(Page13PivotHTMLProcessor.PAGING_OFF);
                    }
                    
                    // Build the ad hoc data set objects 
                    formAdhocDataSets(reports[i],processor);

                    // Write total number of data sets for this section
                    if (!isOutputExcel()){
                    	 if (reports.length > 1) {
                         	bw.write("<span class=\"Title\" title=\"Number of data sets (each grouped table is a data set)\">Total Data Sets (Section " + (i+1) + "):</span>");
                         } else {
                         	bw.write("<span class=\"Title\" title=\"Number of data sets (each grouped table is a data set)\">Total Data Sets:</span>");
                         }
                         bw.write("<span style=' font-size:16px;color:purple;'>&nbsp;" + getTotalDataSets() + "</span><br>\n");
                         bw.flush();	
                    }

                    // Internal Execute method which executes the report
                    execute(processor);
                    
                    bw.write("<br>\n");
                    bw.flush();
                }
            }
            
            dto.setPagedHtml(processor.getPagedHtml());
            
            bw.flush();
            bw.close();

            /*
             * probably not needed, but it is good house keeping anyway
             */
            processor.setReportRenderer(null);
            processor.setTableRenderer(null);
            processor.setHeaderRenderer(null);
            processor.setRowRenderer(null);
            processor.setCellFormatter(null);
        } finally {
            closeConnection();
            dto = getDtoBase();
        }
    }
    
    /**
     * 
     * @param reportProcessor
     * @return
     * @throws ARIAReportException
     */
    public int execute(Page13PivotHTMLProcessor reportProcessor) throws ARIAReportException {
        reportProcessor.beginReport();
        
        TreeMap adhocDataSetMap = this.getAdhocDataSetMap();
        Set adhocDataSet = adhocDataSetMap.keySet();
        Iterator adhocDataSetIterator = adhocDataSet.iterator();
        int counter = 0;
        
        while (adhocDataSetIterator.hasNext()){
        	AdhocPivotData adhocData = (AdhocPivotData)adhocDataSetIterator.next();
        	counter++;
        	if (!isOutputExcel() && counter > RABCConstantsLists.getRABCConstantsLists().getAdhocDataSetSize()){
        		break;
        	}
        	
        	reportProcessor.setAdhocDataSet(adhocData);
        	reportProcessor.beginTable();

        	// Write the headers
        	reportProcessor.renderHeaders();
        	
        	// Write the key row
        	String [] keyNames = adhocData.getKeyColumnNames();
        	if (keyNames.length > 0){
        		boolean keyEndDone = false;
        		reportProcessor.beginKeyRow();
        		for (int i=0;i<keyNames.length;i++){
        			if ((adhocData.getKeyColumnIndexes()[i]+1) > dto.getKeysRow1ColumnsList().size()){
        				if (!isIndicatorIn((String) dto.getPresnSuppressIndList().get(adhocData.getKeyColumnIndexes()[i]), "Y") && !keyEndDone){
        					reportProcessor.endKeyRow();
        					keyEndDone = true;
        					reportProcessor.beginAttributeRow();
        				}
        			}
        			
            		reportProcessor.addKeyCell(keyNames[i], adhocData.getKeyColumnValues()[i], false,adhocData.getKeyColumnIndexes()[i]);
            	}
        		if (!keyEndDone){
        			reportProcessor.endKeyRow();
        		} else {
        			reportProcessor.endAttributeRow();
        		}
        	}
        	
        	// Write the data rows
        	String[] dataColumnNames = adhocData.getDataColumnNames();
        	String[] dataColumnHeaderNames = adhocData.getDataColumnHeaderNames();
        	double [][] dataColumnValues = adhocData.getDataColumnValues();
        	if (dataColumnNames.length > 0){
        		for (int i=0;i<dataColumnNames.length;i++){
        			if (!"Y".equals((String)dto.getPresnSuppressIndList().get(adhocData.getDataColumnIndexes()[i]))){
        				reportProcessor.setTotalLabel(null);
            			double total = 0;
            			
            			reportProcessor.beginDataRow();
            			reportProcessor.addDataLabelCell(dataColumnNames[i], false);
            			
            			for (int j=0;j<dataColumnHeaderNames.length;j++){
            				if (dataColumnHeaderNames[j].indexOf("Total")==-1 && dataColumnValues[i][j]!=Double.NEGATIVE_INFINITY){
            					total += dataColumnValues[i][j];
            				}
            				
            				if (dataColumnValues[i][j]==Double.NEGATIVE_INFINITY) {
            					reportProcessor.addDataValueCell(adhocData.getDataColumnIndexes()[i],dataColumnHeaderNames[j],"no data", false);
            				} else if (!isIndicatorIn((String) dto.getPresnUnitIndList().get(adhocData.getDataColumnIndexes()[i]), "D") && !isIndicatorIn((String) dto.getPresnUnitIndList().get(adhocData.getDataColumnIndexes()[i]), "P")){
            					long value = Math.round(dataColumnValues[i][j]);
            					reportProcessor.addDataValueCell(adhocData.getDataColumnIndexes()[i],dataColumnHeaderNames[j],"" + value + "", false);
            				} else {
            					reportProcessor.addDataValueCell(adhocData.getDataColumnIndexes()[i],dataColumnHeaderNames[j],"" + dataColumnValues[i][j] + "", false);
            				}
            			}
            			
            			// Add total
            			reportProcessor.setTotalLabel(TOTAL);
            			if (!isIndicatorIn((String) dto.getPresnUnitIndList().get(adhocData.getDataColumnIndexes()[i]), "D") && !isIndicatorIn((String) dto.getPresnUnitIndList().get(adhocData.getDataColumnIndexes()[i]), "P")){
            				long value = Math.round(total);
            				reportProcessor.addDataValueCell(adhocData.getDataColumnIndexes()[i],TOTAL,Long.toString(value), false);
            			} else {
            				reportProcessor.addDataValueCell(adhocData.getDataColumnIndexes()[i],TOTAL,Double.toString(total), false);
            			}
            			
            			reportProcessor.endDataRow();
        			}
        		}
        	}
        	reportProcessor.endTable();
        }

        if (logger != null) {
        	logger.debug("PivotLayout2.execute: finished writing report.");
        }
        
        reportProcessor.endReport();
        
        return adhocDataSet.size();
    }

	/**
	 * Renders the headers
	 */
	public String renderHeader(ARIAReportProcessor processor) {
		Page13PivotHTMLProcessor page13 = (Page13PivotHTMLProcessor) processor;
		AdhocPivotData adhocDataSet = page13.getAdhocDataSet();
		
		StringBuffer buf = new StringBuffer(100); 
		buf.append("<tr class='title'>");
		buf.append("<th class='tableHeader'> &nbsp; </th>");
		
		String [] dataColumnHeaders = adhocDataSet.getDataColumnHeaderNames();
		String [] billRndArr = adhocDataSet.getBillRndArr();
		
		int monthTotalCount = 0;
		
		for (int i=0;i<dataColumnHeaders.length;i++){
			page13.setTotalLabel(null);
			buf.append("<th class='tableHeader' ");
			if (isPreviousExists()){
				if (dataColumnHeaders[i].indexOf("Total")!=-1){
					monthTotalCount++;
				} 
				buf.append(" colspan = 2 ");
			}
			buf.append(">");
			buf.append(dataColumnHeaders[i]);
			if ("B".equals(dto.getPresnTrendTime())){
				buf.append(billRndArr[i]);
			}
			buf.append("</th>");
			
		}
		
		// Render header for total
		if (isPreviousExists()){
			buf.append("<th class='tableHeader'> &nbsp; </th>");
		} else {
			page13.setTotalLabel(TOTAL);
			buf.append("<th class='tableHeader' >");
			buf.append(page13.getTotalLabel());
			buf.append("</th>");
		}

		// 2nd row if there is Previous Data
		if (isPreviousExists()){
			buf.append("</tr>");
			buf.append("<tr class='title'>");
			buf.append("<th class='tableHeader'> &nbsp; </th>");
			for (int i=0;i<dataColumnHeaders.length;i++){
				page13.setTotalLabel(null);
				if (dataColumnHeaders[i].indexOf("Total")==-1){
					buf.append("<th class='tableHeader'> Current </th>");
					buf.append("<th class='tableHeader'> Previous </th>");
				} else {
					buf.append("<th class='tableHeader' colspan='2'> &nbsp;</th>");
				}
			}
			page13.setTotalLabel(TOTAL);
			buf.append("<th class='tableHeader' >");
			buf.append(page13.getTotalLabel());
			buf.append("</th>");
		}
		
		buf.append("</tr>");

		return buf.toString();
	}

	/**
	 * Renders the data value
	 */
	public String renderDataValueCell(ARIAReportProcessor processor, int elementIndex, String procDate, String value, boolean escape) {
		try {
			Page13PivotHTMLProcessor proc = (Page13PivotHTMLProcessor) processor;
			AdhocPivotData adhocPivotData = proc.getAdhocDataSet();
			
			StringBuffer buf = new StringBuffer(40);
			buf.append("<td class=\"cellText mso\" ");
			
			if (proc.isTotal()){
				buf.append("  align='right' >");
				formatCellData(proc.getTotalLabel(), value, false, elementIndex, buf);
				buf.append("</td>");
				return buf.toString();
			} else if (procDate.indexOf("Total")!=-1) {
				if (isPreviousExists()){
					buf.append("  colspan='2' ");
				}
				buf.append("  align='right' >");
				formatCellData(procDate, value, false, elementIndex, buf);
				buf.append("</td>");
				return buf.toString();
			}
			
			if (elementIndex >= 0) {
                if (!isIndicatorIn((String) dto.getPresnSumIndList().get(elementIndex), "N")) {
                    buf.append(" align='right' ");
                } else if (isIndicatorIn((String) dto.getPresnUnitIndList().get(elementIndex), "D")) {
                    buf.append(" align='right' ");
                } else {
               	 	buf.append(" align='right' ");
                }
            }

           // buf.append(" title='"+ getMouseOverDescription(elementIndex, "", value) + "' "); // Mouse over is not required for data
            buf.append(">");

            if ("no data".equals(value)) {
            	buf.append(value);
            }else if (isOutputExcel()){
            	formatCellData((String) dto.getColumnsToExtractList().get(elementIndex),value, escape, elementIndex, buf);	
            } else {
            	formatDataCellWithLinks((String) dto.getColumnsToExtractList().get(elementIndex), proc, value, escape, elementIndex, buf, adhocPivotData, procDate);
            }

            buf.append("</td>");
            
            if (elementIndex >= 0) {
                if (isPreviousExists() && isIndicatorIn((String) dto.getPrevDataIndList().get(elementIndex), "Y")) {
                    DatedCompositeKey datedKey = getDatedKey(procDate);
                    datedKey.setNumKeys(adhocPivotData.getKeyColumnValues().length + 1);
                    int deduct = 0;
                    if (datedKey != null) {
                        for (int i=0;i<adhocPivotData.getKeyColumnValues().length;i++){
                        	if (LayoutHelper.checkIfRunDate(dto,adhocPivotData.getKeyColumnIndexes()[i])){
                        		deduct++;
                        	}else {
                        		datedKey.addKey(adhocPivotData.getKeyColumnValues()[i]);
                        	}
                        }
                        datedKey.setNumKeys(datedKey.getNumKeys()-deduct);
                        
                        // Add the column
                        datedKey.addKey((String)dto.getColumnsTablesList().get(elementIndex) + "." + (String)dto.getColumnsAsOracleList().get(elementIndex));
                        
                        String previousData = (String) prevData.findPreviousData(datedKey, dto.getPresnTrendTime(),dto);
                        value = previousData == null ? "no data" : previousData;
                        buf.append("<td class=\"cellText mso\" ");
                        
                        if ("no data".equals(value)){
                        	buf.append(" align='center' ");
                        	buf.append(">");
                        	buf.append(value);
                        	buf.append("</td>");
                        	return buf.toString();
                        }
                        
                        if (elementIndex >= 0) {
                            if (!isIndicatorIn((String) dto.getPresnSumIndList().get(elementIndex), "N")) {
                                buf.append(" align='right' ");
                            }else if (isIndicatorIn((String) dto.getPresnUnitIndList().get(elementIndex), "D")) {
                                buf.append(" align='right' ");
                            } else {
                            	 buf.append(" align='right' ");
                            }
                        }
                        buf.append(">");

                        formatCellData((String) dto.getColumnsToExtractList().get(elementIndex), value, escape, elementIndex, buf);

                        buf.append("</td>");
                    } else {
                        buf.append("<td>&nbsp;</td>");
                    }
                } else if (isPreviousExists()) {
                	buf.append("<td align='center' class=\"cellText mso\" >n/a</td>");
                }
            }
            
            return buf.toString();
		} catch (Exception e) {
            logger.error("renderDataCell", e);
            return "<td>&nbsp;</td>";
        }
	}
}
