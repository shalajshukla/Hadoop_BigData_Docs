/*
 * Module description: 
 * This bean will parse an input record from the RABC.ACUS.BILL.PAYER flat file. 
 *
 * Copyright 2007 ATT Knowledge Ventures. All rights reserved.
 *
 * Modification History:                                     
 * SBCUID		Date			Description                         	    	
 * ------		--------		-----------
 * PB3879		20070426		Changed from Tokenizer.
 * PB3879		20070314		Initial version for EAP 286915
 */
package com.att.bac.rabc.load.acus.calnet;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class BillPaidBean {
	private static DateFormat date_formatter = new SimpleDateFormat("MM-dd-yyyy");

//	detail record values... these will be inserted into the detail table (RABC_ACUS_BILL_PAYER).
	private String  billPayerAccount;

	private String 	paidAmount;
						
	private Date 	acusInvoiceDate;

	public static BillPaidBean valueOf(String value) throws ParseException{
		
		date_formatter.setLenient(false);
		String strDate = null;
		BillPaidBean detail = new BillPaidBean();

		String[] tokens = value.split("\\|",-1);
		
		detail.billPayerAccount = tokens[0].trim();
		
		strDate = tokens[1].trim();
		
		detail.acusInvoiceDate = date_formatter.parse(strDate);
		
//		The following checks the value of the non-key field to see if it is null.  If so, it assigns a default value.

		String sToken = tokens[2].trim();
		
		if (sToken.equals("")){
			detail.paidAmount = null;
		}
		else {
			double pdAmount = Double.parseDouble(sToken);
			detail.paidAmount = sToken;
		}
		
		return detail;
	}

	public Date getAcusInvoiceDate() {
		return acusInvoiceDate;
	}
	public String getBillPayerAccount() {
		return billPayerAccount;
	}
	public String getPaidAmount() {
		return paidAmount;
	}


}
