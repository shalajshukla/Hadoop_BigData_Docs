/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.alerts.status;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.text.MessageFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.ExcelReport;
import com.att.bac.rabc.MyDate;
import com.att.bac.rabc.PickList;
import com.att.bac.rabc.ProgressBar;
import com.att.bac.rabc.RABCConstantsLists;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.StaticDataLoader;
import com.att.bac.rabc.admin.AlertGroupDAO;
import com.att.bac.rabc.admin.UpdateGrp;
import com.att.bac.rabc.admin.UpdateGrpDAO;
import com.att.bac.rabc.admin.alert.rule.AlertRule;
import com.att.bac.rabc.alerts.dashboard.CycleCalendar;
import com.att.bac.rabc.alerts.dashboard.CycleCalendarDAO;

/**
 * This is a service class to provide the business logic. The methods in this class are called by the
 * action class. They internaly calls the DAO classes to do the required manipulation and returns the 
 * result to the action class. This paricular service class serves the business logic to populate the
 * Alert Report Selection Criteria page and Alert Report Detail page.
 * 
 * @author Vijay Dubey - VD3159
 */
public class AlertReportDetailService {
	private static final Logger logger = Logger.getLogger(AlertReportDetailService.class);
	private static AlertReportDetailService alertReportDetailService;
	
	/*
	 * Variables to represent the sql statements.
	 */
	private static final String getAlertRule = "select distinct alert_rule "
		+ "from rabc_alert_msg "
		+ "order by alert_rule";
	
	private static final String getGrpAlerted = "select distinct alert_grp, alert_grp_desc, funct_cd, pnt_alert_grp_ind "
		+ "from rabc_alert_grp "
		+ "order by upper(alert_grp)";
	
	private static final String getSysErrorType = "select distinct sys_err_cd, "
		+ "sys_err_cd_desc "
		+ "from rabc_sys_err_cd "
		+ "order by sys_err_cd_desc";
	
	private static final String getRootCatgyCd = "select distinct root_catgy_cd, "
		+ "root_catgy_cd_desc "
		+ "from rabc_root_catgy_cd "
		+ "order by root_catgy_cd_desc";
	
	private static final String query_getCycle = "select cycle, bill_rnd, proc_dt, bill_rnd_dt " 
		+ "from rabc_cycle_calendar {0}";
	
	private static final String getAlertList = "select * from ( "
		+ "select rownum rn, T.outMsgNo outMsgNo, "
		+ "T.outAlertTimeValue outAlertTimeValue, "
		+ "T.outAlertTimeInd outAlertTimeInd, "
		+ "T.outSeverColor outSeverColor, "
		+ "T.outKeyLevel outKeyLevel, "
		+ "T.outProcDate outProcDate, "
		+ "T.outTimeStamp outTimeStamp, "
		+ "T.outAlertRule outAlertRule, "
		+ "T.outFileSeqNum outFileSeqNum, "
		+ "T.outAlertItem outAlertItem, "
		+ "T.outAlertActual outAlertActual, "
		+ "T.outVariance outVariance, " 
		+ "T.outRevenueImpact outRevenueImpact, "
		+ "T.outStatus outStatus, "
		+ "T.outRootCatgyCd outRootCatgyCd, "
		+ "T.outRootCause outRootCause, "
		+ "T.outError outError, "
		+ "T.outMsg  outMsg, "
		+ "T.outKey1 outKey1, "
		+ "T.outKey2 outKey2, "
		+ "T.outKey3 outKey3, "
		+ "T.outKey4 outKey4, "
		+ "T.outKey5 outKey5, "
		+ "T.urlKey1 urlKey1, "
		+ "T.urlKey2 urlKey2, "
		+ "T.urlKey3 urlKey3, "
		+ "T.urlKey4 urlKey4, "
		+ "T.urlKey5 urlKey5, "
		+ "T.outSuppInfo as outSuppInfo, "
		+ "T.outType as outType, "
		+ "T.alert_rule_run_dt as alert_rule_run_dt, "
		+ "T.presn_id presn_id, "
		+ "T.outLostRevenue outLostRevenue, "
		+ "T.divisionDesc divisionDesc "
		+ "from ( "
		+ "select rownum rn, "
		+ "bams.msg_num outMsgNo, "
		+ "bams.alert_time_value outAlertTimeValue, "
		+ "bams.alert_time_ind outAlertTimeInd, "
		+ "bams.alert_severe_lvl_ind outSeverColor, "
		+ "bams.alert_key_lvl outKeyLevel, "
		+ "bams.proc_date outProcDate, "
		+ "bams.time_stamp outTimeStamp, "
		+ "bams.alert_rule outAlertRule, "
		+ "bams.file_seq_num outFileSeqNum, "
		+ "bams.alert_item outAlertItem, "
		+ "bams.alert_actual outAlertActual, "
		+ "bams.alert_pct outVariance, " 
		+ "bams.alert_revenue outRevenueImpact, "
		+ "bams.alert_status outStatus, "
		+ "bams.alert_root_catgy_cd outRootCatgyCd, "
		+ "bams.alert_root_cause outRootCause, "
		+ "bams.alert_sys_err_cd outError, "
		+ "bams.alert_msg  outMsg, "
		+ "bams.alert_key1 outKey1, "
		+ "bams.alert_key2 outKey2, "
		+ "bams.alert_key3 outKey3, "
		+ "bams.alert_key4 outKey4, "
		+ "bams.alert_key5 outKey5, "
		+ "bams.alert_data1 as urlKey1, "
		+ "bams.alert_data2 as urlKey2, "
		+ "bams.alert_data3 as urlKey3, "
		+ "bams.alert_data4 as urlKey4, "
		+ "bams.alert_data5 as urlKey5, "
		+ "bams.alert_supp_ind as outSuppInfo, "
		+ "bams.alert_type as outType, "
		+ "bams.alert_rule_run_dt as alert_rule_run_dt, "
		+ "bpi.presn_id presn_id, "
		+ "bams.alert_lost_revenue outLostRevenue, "
		+ "bd.division_desc as divisionDesc "
		+ "from rabc_alert_msg bams, rabc_alert_rule bar, rabc_presn_id bpi, rabc_division bd "
		+ "where bams.alert_rule = bar.alert_rule "
		+ "and bams.alert_data1 = bd.division "
		+ "and bar.presn_id = bpi.presn_id "
		+ "and {0} {1} {2} {3} {4} {5} "
		+ "{6} {7} {8} {9} {10} {11} {12} "
		+ "bams.alert_severe_lvl_ind != ''S'' "
		+ "and upper(bar.alert_rule_status) = ''ACTIVE'' "
		+ "and bar.ALERT_RULE in (select a.ALERT_RULE from RABC_UPDATE_GRP a, RABC_ALERT_GRP_USER b where a.ALERT_GRP = b.ALERT_GRP and b.USER_ID = ''{13}'') "
		+ "{14} "
		+ ") T ) t {15}";
	
	private static final String getTotalAlerts = "select count(*) "
		+ "from rabc_alert_msg bams, rabc_alert_rule bar, rabc_presn_id bpi "
		+ "where bams.alert_rule = bar.alert_rule "
		+ "and bar.presn_id = bpi.presn_id "
		+ "and {0} {1} {2} {3} {4} {5} "
		+ "{6} {7} {8} {9} {10} {11} {12} "
		+ "bams.alert_severe_lvl_ind != ''S'' "
		+ "and upper(bar.alert_rule_status) = ''ACTIVE'' "
		+ "and bar.ALERT_RULE in (select a.ALERT_RULE from RABC_UPDATE_GRP a, RABC_ALERT_GRP_USER b where a.ALERT_GRP = b.ALERT_GRP and b.USER_ID = ''{13}'') ";
	
	private static final String qMsgCodes = "{0}";
	
	private static final String qVarTypes = "select a.alert_item, b.alert_rule "
		+ "from rabc_alert_hist a, rabc_alert_rule b, rabc_alert_proc p "
		+ "where a.parti_ref_id = b.parti_ref_id "
		+ "and b.parti_ref_id = p.parti_ref_id "
		+ "and p.alert_create_ind = ''Y'' "
		+ "and a.alert_item = p.alert_item_ddl_name "
		+ "and b.alert_rule in ( {0} ) "
		+ "order by a.alert_item";
	
	private static final String getacctinstkeys = "select alert_rule, alert_key_lvl "
		+ "from rabc_alert_rule "
		+ "where alert_rule in ( {0} )";
	
	private static final String qRuleGroups = "select distinct alert_rule, alert_grp, presn_id "
		+ "from rabc_update_grp "
		+ "where alert_rule in ( {0} ) "
		+ "order by alert_rule, alert_grp";
	
	private static final String qUsers = "select a.alert_rule, b.user_id "
		+ "from rabc_update_grp a, rabc_alert_grp_user b "
		+ "where a.alert_grp = b.alert_grp and a.alert_rule in ( {0} ) "
		+ "order by a.alert_rule";
	
	private static final String getSuppInfo = "{0}";
	
	private static final String getDefaultLineCount = "SELECT LINE_CT FROM RABC_USER_DEFAULT_RPT_LINE WHERE USER_ID = ''{0}''";
	
	private static final String getDefaultDivision = "SELECT DIVISION FROM RABC_USER_DEFAULT_DIVISION WHERE USER_ID = ''{0}''";
	
	/**
	 * Synchronized method to return the instance of AlertReportDetailService object.
	 * It checks the existance of the instance of AlertReportDetailService and if it does not exists
	 * then creates one instance of AlertReportDetailService and returns otherwise it returns the
	 * existing instance of AlertReportDetailService.
	 * 
	 * @return AlertReportDetailService
	 */
	protected static synchronized AlertReportDetailService getAlertReportDetailService(){
		if (alertReportDetailService == null) {
			alertReportDetailService = new AlertReportDetailService();
		}
		return alertReportDetailService;
	}
	
	/**
	 * Method to return the list of process points.
	 * It calls the StaticDataLoader to get the list of distinct process points.
	 * 
	 * @param region
	 * @return List
	 */
	protected List getProcessPointList(String region) {
		List processPointList = new ArrayList();
		List tempList = StaticDataLoader.getDistinctProcesses(region);
		int i = 0;
		int size = tempList.size();
		for (i=0; i<size; i++) {
			processPointList.add(new PickList((String)tempList.get(i), (String)tempList.get(i)));
		}
		return processPointList;
	}
	
	/**
	 * Method to return the list of Control Points.
	 * It calls the StaticDataLoader to get the list of control points.
	 * 
	 * @param region
	 * @return List
	 */
	protected List getControlPointList(String region) {
		List controlPointList = new ArrayList();
		controlPointList = StaticDataLoader.getCntrlPtList(region);	
		return controlPointList;
	}

	/**
	 * Method to return the list of Alert Rules.
	 * 
	 * @param connection
	 * @param failureList
	 * @return List
	 */
	protected List getAlertRuleList(Connection connection, List failureList) {
		List alertRuleList = new ArrayList();
		AlertRule alertRule = null;
		String selectSQL = getAlertRule;
		List args = new ArrayList();
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		try{
			MessageFormat mf = new MessageFormat(selectSQL);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("To get Alert Rule List - Executing SQL statement: "+ prepareStatement);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			if (rs != null) {
				while(rs.next()){
					alertRule = new AlertRule();
					alertRule.setAlertRule(rs.getString(1));
					alertRuleList.add(alertRule);
				}
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
			return null;
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		
		return alertRuleList;
	}
	
	/**
	 * Method to return the list of Divisions.
	 * It calls the StaticDataLoader to get the list of divisions.
	 * 
	 * @param region
	 * @return List
	 */
	protected List getDivisions(String region) {
		List divisionList = new ArrayList();
		divisionList = StaticDataLoader.getDivisionsByRegion(region);
		return divisionList;
	}
	
	/**
	 * Method to return the list of Alert Rule Timings.
	 * It calls the RABCConstantsLists class to get the list of Alert Rule Timings.
	 * 
	 * @return List
	 */
	protected List getAlertRuleTimingList(String region) {
		List alertRuleTimingList = new ArrayList();
		alertRuleTimingList = RABCConstantsLists.getRABCConstantsLists().getStatusAlertRuleTimingList(region);	
		return alertRuleTimingList;
	}
	
	/**
	 * Method to return the list of Alert Status.
	 * It calls the RABCConstantsLists class to get the list of Alert Status.
	 * 
	 * @return List
	 */
	protected List getAlertStatusList() {
		List alertStatusList = new ArrayList();
		alertStatusList = RABCConstantsLists.getRABCConstantsLists().getAlertStatusList();	
		return alertStatusList;
	}
	
	/**
	 * Method to return the list of Alert Severity.
	 * It calls the RABCConstantsLists class to get the list of Alert Severity.
	 * 
	 * @return List
	 */
	protected List getAlertSeverityList() {
		List alertSeverityList = new ArrayList();
		alertSeverityList = RABCConstantsLists.getRABCConstantsLists().getAlertSeverityList();	
		return alertSeverityList;
	}
	
	/**
	 * Method to return the list of Alert Groups.
	 * It calls the AlertGroupDAO class to get the list of Alert Groups.
	 * 
	 * @param connection
	 * @param failureList
	 * @return List
	 */
	protected List getGroupAlertedList(Connection connection, List failureList) {
		List groupAlertedList = new ArrayList();
		String query = getGrpAlerted;
		List args = new ArrayList();
		groupAlertedList = new AlertGroupDAO().get(connection, failureList, args, query);
		
		if (!failureList.isEmpty()) {
			return null;
		}
		return groupAlertedList;
	}
	
	/**
	 * Method to return the list of System Error Types.
	 * It calls the SysErrDAO class to get the list of System Error Types.
	 * 
	 * @param connection
	 * @param failureList
	 * @return List
	 */
	protected List getSystemErrorTypeList(Connection connection, List failureList) {
		List tempSystemErrorTypeList = new ArrayList();
		List systemErrorTypeList = new ArrayList();
		SysErr sysErr = null;
		String query = getSysErrorType;
		List args = new ArrayList();
		
		tempSystemErrorTypeList = new SysErrDAO().get(connection, failureList, args, query);
		if (!failureList.isEmpty()) {
			return null;
		}
		if (tempSystemErrorTypeList != null) {
			int counter = 0;
			int tempSystemErrorTypeListSize = tempSystemErrorTypeList.size();
			for(counter = 0; counter < tempSystemErrorTypeListSize; counter++) {
				sysErr = (SysErr) tempSystemErrorTypeList.get(counter);
				sysErr.setSysErrCdDesc(sysErr.getSysErrCd() + " - " + sysErr.getSysErrCdDesc());
				systemErrorTypeList.add(sysErr);
			}
		}
		
		return systemErrorTypeList;
	}
	
	/**
	 * Method to return the list of Root Cause Categories.
	 * It calls the RootCategoryDAO class to get the list of Root Cause Categories.
	 * 
	 * @param connection
	 * @param failureList
	 * @return List
	 */
	protected List getRootCauseCategoryList(Connection connection, List failureList) {
		List tempRootCauseCategoryList = new ArrayList();
		List rootCauseCategoryList = new ArrayList();
		RootCategory rootCategory = null;
		String query = getRootCatgyCd;
		List args = new ArrayList();
		
		tempRootCauseCategoryList = new RootCategoryDAO().get(connection, failureList, args, query);
		if (!failureList.isEmpty()) {
			return null;
		}
		if (tempRootCauseCategoryList != null) {
			int counter = 0;
			int tempRootCauseCategoryListSize = tempRootCauseCategoryList.size();
			for(counter = 0; counter < tempRootCauseCategoryListSize; counter++) {
				rootCategory = (RootCategory) tempRootCauseCategoryList.get(counter);
				rootCategory.setRootCatgyCdDesc(rootCategory.getRootCatgyCd() + " - " + rootCategory.getRootCatgyCdDesc());
				rootCauseCategoryList.add(rootCategory);
			}
		}
		
		return rootCauseCategoryList;
	}
	
	/**
	 * Method to return the list of Cycles for the entered file start date and end date.
	 * It calls the CycleCalendarDAO class to get the list of cycles.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return List
	 */
	protected List getCycleCalendarList(Connection connection, List failureList, List args) {
		List cycleList = new ArrayList();
		List cycleArgsList = new ArrayList();
		String query = query_getCycle;
		String startDate = (String) args.get(1);
		String endDate = (String) args.get(2);
		
		if((startDate != null && !"".equals(startDate)) && (endDate == null || "".equals(endDate))) {
			cycleArgsList.add("where proc_dt = to_date('"+startDate+"','MM/DD/YYYY')");
		} else if((startDate != null && !"".equals(startDate))  && (endDate != null && !"".equals(endDate)) && startDate.equals(endDate)) {
			cycleArgsList.add("where proc_dt  = to_date('"+startDate+"','MM/DD/YYYY')");
		} else if((startDate != null && !"".equals(startDate))  && (endDate != null && !"".equals(endDate)) && (!startDate.equals(endDate))) {
			cycleArgsList.add("where proc_dt  between  to_date('"+startDate+"','MM/DD/YYYY') and to_date('"+endDate+"','MM/DD/YYYY')");
		} else {
			cycleArgsList.add("");
		}
		cycleList = new CycleCalendarDAO().get(connection, failureList, cycleArgsList, query);
		if (!failureList.isEmpty()) {
			return null;
		}
		return cycleList;
	}
    
	/**
	 * Private method to return a list of arguments to be used to execute the sql query to get 
	 * the list of AlertReportDetail objects.
	 * 
	 * @param args
	 * @return List
	 */
	private List populateAlertArgsList(List args) {
    	List alertArgs = new ArrayList();
    	String userId = (String) args.get(0);
    	String fileStartDate = (String) args.get(1);
    	String fileEndDate = (String) args.get(2);
    	String controlPoint = (String) args.get(3);
    	String alertRule = (String) args.get(4);
    	String division = (String) args.get(5);
    	String alertRuleTiming = (String) args.get(6);
    	String alertRuleTimingInd = (String) args.get(7);
    	String alertStatus = (String) args.get(8);
    	String alertSeverity = (String) args.get(9);
    	String groupAlerted = (String) args.get(10);
    	String revenueImpactValue = (String)args.get(11);
    	int revenueImpactInd = ((Integer)args.get(12)).intValue();
    	String systemErrorType = (String) args.get(13);
    	String alertRootCtgyCd = (String) args.get(14);
    	String lastUpdatedStartDate = (String) args.get(15);
    	String lastUpdatedEndDate = (String) args.get(16);
    	String webPageId = (String) args.get(17);
    	String dateType = (String) args.get(18);
    	String processPoint = (String) args.get(19);
    	String sortItem = (String) args.get(20);
    	String sortOrder = (String) args.get(21);
    	String dispatch = (String) args.get(22);
    	String fromPage = (String) args.get(23);
    	String timeStampInd = (String) args.get(24);
    	int pageSize = ((Integer)args.get(25)).intValue();
    	int page = ((Integer)args.get(27)).intValue();
    	int pages = ((Integer)args.get(28)).intValue();
    	
		int startCounter = (page - 1) * pageSize + 1;
		int endCounter = page * pageSize;
    	
    	/*
    	 * alertArgs(0)
    	 */
		if ("file".equals(dateType)) {
    		alertArgs.add("(bams.proc_date >= to_date('" + fileStartDate + "','MM/DD/YYYY') "
    				+ "and bams.proc_date < (to_date('" + fileEndDate + "','MM/DD/YYYY') + 1)) and ");
    	} else {
    		alertArgs.add("(bams.alert_rule_run_dt >= to_date('" + fileStartDate + "','MM/DD/YYYY') "
    				+ "and bams.alert_rule_run_dt < (to_date('" + fileEndDate + "','MM/DD/YYYY') + 1)) and ");
    	}
    	
    	/*
    	 * alertArgs(1)
    	 */
    	if (!"NO".equals(timeStampInd)) {
    		alertArgs.add("bams.alert_rule_run_dt = to_date('" + timeStampInd + "','MM/DD/YYYY') and ");
    	} else {
    		alertArgs.add("");
    	}
    	
    	/*
    	 * alertArgs(2)
    	 */
    	if (((processPoint != null) && !(processPoint.equals(""))) 
    			|| ((controlPoint != null) && !(controlPoint.equals(""))) 
				|| ((alertRule != null) && !(alertRule.equals("")))) {
	    	String alertRuleCondition = "(";
	    	if ((processPoint != null) && !(processPoint.equals(""))) {
	    		alertRuleCondition += "bams.alert_rule in (select alert_rule from rabc_cntrl_pt_alert where cntrl_pt_cd in (select cntrl_pt_cd from rabc_process where process= '" + processPoint + "')) ";
	    	}
	    	if ((controlPoint != null) && !(controlPoint.equals(""))) {
	    		if ((processPoint != null) && !(processPoint.equals(""))) {
	    			alertRuleCondition +=  "or bams.alert_rule in (select alert_rule from rabc_cntrl_pt_alert where cntrl_pt_cd = '" + controlPoint + "') ";
	    		} else {
	    			alertRuleCondition +=  "bams.alert_rule in (select alert_rule from rabc_cntrl_pt_alert where cntrl_pt_cd = '" + controlPoint + "') ";
	    		}
	    	}
	    	if ((alertRule != null) && !(alertRule.equals(""))) {
	    		if (((processPoint != null) && !(processPoint.equals(""))) || ((controlPoint != null) && !(controlPoint.equals("")))) {
	    			alertRuleCondition += "or bams.alert_rule = '" + alertRule + "' ";
	    		} else {
	    			alertRuleCondition += "bams.alert_rule = '" + alertRule + "' ";
	    		}
	    	}
	    	alertRuleCondition += ") and ";
	    	alertArgs.add(alertRuleCondition);
    	} else {
    		alertArgs.add("");
    	}
		
    	/*
    	 * alertArgs(3)
    	 */
		if ((division != null) && (division.length() > 0)) {
			//alertArgs.add("bams.alert_key1 = (select division_desc from rabc_division where division = '" + division + "') and ");
			alertArgs.add("bams.alert_data1 = '" + division + "' and ");
    	} else {
    		alertArgs.add("");
    	}
		
		/*
    	 * alertArgs(4)
    	 */
		if ((alertStatus != null) && (alertStatus.length() > 0)) {
			alertArgs.add("upper(bams.alert_status) = upper('" + alertStatus + "') and ");
    	} else {
    		alertArgs.add("");
    	}
		
		/*
    	 * alertArgs(5)
    	 */
		if ((fromPage != null) && (("RABCPSF00002".equals(fromPage)) || "RABCPSF00003".equals(fromPage))) {
			/*if ((alertStatus == null) || (alertStatus.length() == 0)) {
				alertArgs.add("upper(bams.alert_status) in ('WARNING','PENDING') and ");
			} else {
				alertArgs.add("");
			}*/
			alertArgs.add("");
		} else {
			alertArgs.add("");
		}
		
		/*
    	 * alertArgs(6)
    	 */
		if ((alertRuleTiming != null) && (alertRuleTiming.length() > 0)) {
			if (alertRuleTiming.equals("B") || alertRuleTiming.equals("D")) {
				alertArgs.add("bams.alert_time_ind = '" + alertRuleTiming + "' and ltrim(rtrim(bams.alert_time_value,' '),'0 ') = ltrim('" + alertRuleTimingInd + "','0') and");
			} else {
				alertArgs.add("bams.alert_time_ind is null and ");
			}
    	} else {
    		alertArgs.add("");
    	}
		
		/*
    	 * alertArgs(7)
    	 */
		if ((alertRootCtgyCd != null) && (alertRootCtgyCd.length() > 0)) {
			alertArgs.add("bams.msg_num in (select distinct msg_num from rabc_warn_cd where alert_root_catgy_cd = '" + alertRootCtgyCd + "') and ");
    	} else {
    		alertArgs.add("");
    	}
		
		/*
    	 * alertArgs(8)
    	 */
		if ((groupAlerted != null) && (groupAlerted.length() > 0)) {
			alertArgs.add("bams.alert_rule in (select distinct alert_rule from rabc_update_grp where ltrim(rtrim(alert_grp)) = '" + groupAlerted + "') and ");
    	} else {
    		alertArgs.add("");
    	}
		
		/*
    	 * alertArgs(9)
    	 */
		if ((revenueImpactValue != null) && (!revenueImpactValue.trim().equals(""))) {
			double revenueImpactValue1 = (new Double(revenueImpactValue.trim())).doubleValue();
    		if (revenueImpactInd == 1) {
    			alertArgs.add("abs(bams.alert_revenue) > " + revenueImpactValue1 + " and ");
    		} else if (revenueImpactInd == 2) {
    			alertArgs.add("abs(bams.alert_revenue) = " + revenueImpactValue1 + " and ");
    		} else if (revenueImpactInd == 3) {
    			alertArgs.add("abs(bams.alert_revenue) < " + revenueImpactValue1 + " and ");
    		}
    	} else {
    		alertArgs.add("");
    	}
		
		/*
    	 * alertArgs(10)
    	 */
		if ((lastUpdatedStartDate != null) && !(lastUpdatedStartDate.equals("")) && (lastUpdatedEndDate != null) && !(lastUpdatedEndDate.equals(""))) {
			alertArgs.add("(bams.time_stamp >= to_date('" + lastUpdatedStartDate + "','MM/DD/YYYY') "
    				+ "and bams.time_stamp < (to_date('" + lastUpdatedEndDate + "','MM/DD/YYYY') + 1)) and ");
    	} else {
    		alertArgs.add("");
    	}
		
		/*
    	 * alertArgs(11)
    	 */
		if ((alertSeverity != null) && (alertSeverity.length() > 0)) {
			alertArgs.add("bams.alert_severe_lvl_ind = '" + alertSeverity + "' and upper(bams.alert_status) in ('WARNING','PENDING') and ");
    	} else {
    		alertArgs.add("");
    	}
		
		/*
    	 * alertArgs(12)
    	 */
		if ((systemErrorType != null) && (systemErrorType.length() > 0)) {
			alertArgs.add("bams.alert_sys_err_cd='" + systemErrorType + "' and ");
    	} else {
    		alertArgs.add("");
    	}
		
		/*
    	 * alertArgs(13)
    	 */
		if ((sortItem != null) && !("".equals(sortItem))) {
			alertArgs.add("order by " + sortItem + " " + sortOrder + ", bams.file_seq_num " + sortOrder);
		} else {
			alertArgs.add("");
		}
		
		/*
    	 * alertArgs(14)
    	 */
		if (dispatch == null) {
			alertArgs.add("where t.rn between " + startCounter + " and " + endCounter);
    	} else {
	    	if ("createReport".equals(dispatch) || "emailReport".equals(dispatch)) {
	    		alertArgs.add("");
			} else {
				alertArgs.add("where t.rn between " + startCounter + " and " + endCounter);
			}
    	}
		
    	return alertArgs;
    }
	
	/**
	 * Method to return the total count of AlertRportDetail objects for the criterias selected.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return int
	 */
	protected int getTotalAlerts(Connection connection, List failureList, List args) {
		/*
		 * Call the private method populateAlertArgsList(args) to populate the the array list with the
		 * arguments required to execute the query.
		 */
		List alertArgs = populateAlertArgsList(args);
		alertArgs.add(13, args.get(0));
		
		/*
		 * Call the private method getTotalAlertsCount(connection, failureList, alertArgs) to
		 * return the total count of alert report detail objects.
		 */
		int totalAlerts = getTotalAlertsCount(connection, failureList, alertArgs);
		if (!failureList.isEmpty()) {
			return 0;
		}
		
		return totalAlerts;
	}
	
	/**
	 * Private method to return the total count of AlertRportDetail objects. It executes the sql to
	 * get the total count of records for the criterias selected by the user.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return int
	 */
	private int getTotalAlertsCount(Connection connection, List failureList, List args){
		int totalCount = 0;
		String selectSQL = getTotalAlerts;
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		
		try{
			MessageFormat mf = new MessageFormat(selectSQL);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("To get the total count of Alerts - Executing SQL statement: "+ prepareStatement);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			if (rs != null) {
				while(rs.next()){
					totalCount = rs.getInt(1);
				}
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
		} finally{
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		
		return totalCount;
	}
	
	/**
	 * Method to return the list of AlertReportDetail objects.
	 * The action class calls this method to get the list of AlertReportDetail objects
	 * and sets that list to the form.
	 * This method first get the list of AlertReportDetail objects, then it creates various maps to maintain
	 * the maps with the keys either message no. or alert rule of returuned alerts. In last it updates the
	 * list of AlertReportDetail objects by using those maps.  
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param progressBar
	 * @return List
	 */
	protected List getAlertReportDetailList(Connection connection, List failureList, 
			List args, ProgressBar progressBar) {
		/*
		 * Call the private method populateAlertArgsList(args) to populate the the array list with the
		 * arguments required to execute the query.
		 */
		List alertArgs = populateAlertArgsList(args);
		alertArgs.add(13, args.get(0));

		
		/*
		 * Call the private method getAlertList(connection, failureList, alertArgs) to
		 * return the list of AlertReportDetail objects.
		 */
		List alertReportDetailList = getAlertList(connection, failureList, alertArgs);
		if (!failureList.isEmpty()) {
			return null;
		}
		progressBar.setProgressPercent(progressBar.getPercent() + 10);
		
		/*
		 * Call the private method getMsgNums(alertReportDetailList) to get a list of strings that contains
		 * all the distinct message nos. (maximum 1000) seperated by comma of the returned list of 
		 * AlertReportDetail objects.
		 */
		List messageNumbers = getMsgNums(alertReportDetailList);
		
		/*
		 * Call the private method getAlertRules(alertReportDetailList) to get a string that contains
		 * all the distinct alert rules seperated by comma of the returned list of AlertReportDetail objects.
		 */
		String alertRules = getAlertRules(alertReportDetailList);
		if (alertRules.equals("")) {
			alertRules = "''";
		} else {
			alertRules = alertRules.substring(0, alertRules.length()-1);
		}
		
		HashMap msgNumWiseRootCatgyCdMap = getMsgNnmWiseRootCatgyCd(connection, failureList, messageNumbers);
		if (!failureList.isEmpty()) {
			return null;
		}
		
		HashMap alertRuleWiseKeyLevelsMap = getAlertRuleWiseKeyLevels(connection, failureList, alertRules);
		if (!failureList.isEmpty()) {
			return null;
		}
		progressBar.setProgressPercent(progressBar.getPercent() + 10);
		
		HashMap alertRuleWiseAlertGroupsMap = getAlertRuleWiseAlertGroups(connection, failureList, alertRules);
		if (!failureList.isEmpty()) {
			return null;
		}
		progressBar.setProgressPercent(progressBar.getPercent() + 10);
		
		HashMap alertRuleWiseAccessMap = getAlertRuleWiseAccessMap(connection, failureList, alertRules);
		if (!failureList.isEmpty()) {
			return null;
		}
		progressBar.setProgressPercent(progressBar.getPercent() + 10);
		
		HashMap msgNnmWiseSuppDataMap = getMsgNnmWiseSuppData(connection, failureList, messageNumbers);
		if (!failureList.isEmpty()) {
			return null;
		}
		progressBar.setProgressPercent(progressBar.getPercent() + 10);
		
		String userId = (String) args.get(0);
		
		/*
		 * Call the private method to update the list of AlertReportDetail objects using the maps.
		 */
		alertReportDetailList = updateAlertReportDetailList(alertReportDetailList, userId,
				msgNumWiseRootCatgyCdMap, alertRuleWiseKeyLevelsMap, 
				alertRuleWiseAlertGroupsMap, alertRuleWiseAccessMap, msgNnmWiseSuppDataMap);
		progressBar.setProgressPercent(progressBar.getPercent() + 10);
		
		//Call the private method to update the list of AlertReportDetail objects  for mouse over decription for key values
		updateAlertReportDetailsListForMouseOver(connection, failureList, alertReportDetailList);
		
		return alertReportDetailList;
	}
	
	/**
	 * Private method to return list of alertReportDetail objects. All attributes of
	 * these objects will not be set in here.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return List
	 */
	private List getAlertList(Connection connection, List failureList, List args) {
		List alertReportDetailList = new ArrayList();
		AlertReportDetail alertReportDetail = null;
		String selectSQL = getAlertList;
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		
		try {
			MessageFormat mf = new MessageFormat(selectSQL);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("To get Alert List - Executing SQL statement: "+ prepareStatement);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			if (rs != null) {
				while(rs.next()){
					/*
					 * Call the private method buildAlertReportDetail(resultset) to build the
					 * AlertReportDetail object.
					 */
					alertReportDetail = buildAlertReportDetail(rs);
					alertReportDetailList.add(alertReportDetail);
				}
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
		} finally{
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		
		return alertReportDetailList;
	}
	
	/**
	 * Private method to return the AlertReportDetail object. It accepts the result set and set the
	 * attributes of AlertReportDetail object by getting the values from the result set.
	 * 
	 * @param rs
	 * @return AlertReportDetail
	 * @throws SQLException
	 */
	private AlertReportDetail buildAlertReportDetail(ResultSet rs) throws SQLException {
		AlertReportDetail alertReportDetail = new AlertReportDetail();
		StringBuffer graphUrlBuffer = new StringBuffer();
		String graphUrl = null;
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy"); 
		
		alertReportDetail.setMsgNo(rs.getInt("outMsgNo"));
		alertReportDetail.setAlertTimeValue(rs.getString("outAlertTimeValue"));
		alertReportDetail.setAlertTimeInd(rs.getString("outAlertTimeInd"));
		alertReportDetail.setAlertSeverityLevelInd(rs.getString("outSeverColor"));
		Date procDate = rs.getDate("outProcDate");
		if (procDate != null) {
			alertReportDetail.setProcDate(new MyDate(procDate));
		}
		Date timeStamp = rs.getDate("outTimeStamp");
		if (timeStamp != null) {
			alertReportDetail.setTimeStamp(new MyDate(timeStamp));
		}
		alertReportDetail.setAlertItem(rs.getString("outAlertItem"));
		alertReportDetail.setAlertRule(rs.getString("outAlertRule"));
		String outFileSeqNum = rs.getString("outFileSeqNum");
		if (outFileSeqNum != null) {
			alertReportDetail.setFileSeqNum(new Integer(outFileSeqNum));
		} else {
			alertReportDetail.setFileSeqNum(null);
		}
		String outAlertActual = rs.getString("outAlertActual");
		if (outAlertActual != null) {
			alertReportDetail.setAlertActual(new Double(outAlertActual));
		} else {
			alertReportDetail.setAlertActual(null);
		}
		String outVariance = rs.getString("outVariance");
		if (outVariance != null) {
			alertReportDetail.setAlertPct(new Double(outVariance));
		} else {
			alertReportDetail.setAlertPct(null);
		}
		String outRevenueImpact = rs.getString("outRevenueImpact");
		if (outRevenueImpact != null) {
			alertReportDetail.setAlertRevenue(new Double(outRevenueImpact));
		} else {
			alertReportDetail.setAlertRevenue(null);
		}
		alertReportDetail.setAlertStatus(rs.getString("outStatus"));
		alertReportDetail.setAlertRootCause(rs.getString("outRootCause"));
		alertReportDetail.setAlertSysErrCd(rs.getInt("outError"));
		alertReportDetail.setAlertMsg(rs.getString("outMsg"));
		
		String alertKey1 = rs.getString("outKey1");
		String alertKey2 = rs.getString("outKey2");
		String alertKey3 = rs.getString("outKey3");
		String alertKey4 = rs.getString("outKey4");
		String alertKey5 = rs.getString("outKey5");
		String alertKey1Text = RABCConstantsLists.getRABCConstantsLists().getText1(rs.getString("outKey1"), false);
		String alertKey2Text = RABCConstantsLists.getRABCConstantsLists().getText1(rs.getString("outKey2"), false);
		String alertKey3Text = RABCConstantsLists.getRABCConstantsLists().getText1(rs.getString("outKey3"), false);
		String alertKey4Text = RABCConstantsLists.getRABCConstantsLists().getText1(rs.getString("outKey4"), false);
		String alertKey5Text = RABCConstantsLists.getRABCConstantsLists().getText1(rs.getString("outKey5"), false);		
		
		alertReportDetail.setAlertKey1(alertKey1Text);
		alertReportDetail.setAlertKey2(alertKey2Text);
		alertReportDetail.setAlertKey3(alertKey3Text);
		alertReportDetail.setAlertKey4(alertKey4Text);
		alertReportDetail.setAlertKey5(alertKey5Text);
		
		// The map is used to get exact key for abbrevation while getting mouse over description for key
		Map abbrevationKeyMap = new HashMap();
		abbrevationKeyMap.put(alertKey1Text, alertKey1);
		abbrevationKeyMap.put(alertKey2Text, alertKey2);
		abbrevationKeyMap.put(alertKey3Text, alertKey3);
		abbrevationKeyMap.put(alertKey4Text, alertKey4);
		abbrevationKeyMap.put(alertKey5Text, alertKey5);
		alertReportDetail.setAlertKeyAbbrevationMap(abbrevationKeyMap);
		
		
		alertReportDetail.setAlertData1(rs.getString("urlKey1"));
		String urlKey2 = rs.getString("urlKey2");
		String urlKey3 = rs.getString("urlKey3");
		String urlKey4 = rs.getString("urlKey4");
		String urlKey5 = rs.getString("urlKey5");
		alertReportDetail.setAlertData2(urlKey2);
		alertReportDetail.setAlertData3(urlKey3);
		alertReportDetail.setAlertData4(urlKey4);
		alertReportDetail.setAlertData5(urlKey5);
		if ((urlKey2 == null || urlKey2.equals("")) && (urlKey3 == null || urlKey3.equals("")) && (urlKey4 == null || urlKey4.equals("")) 
				&& (urlKey5 == null || urlKey5.equals(""))) {
			alertReportDetail.setKeyRow(0);
		} else {
			alertReportDetail.setKeyRow(1);
		}
		alertReportDetail.setAlertSuppInd(rs.getString("outSuppInfo"));
		alertReportDetail.setAlertType(rs.getString("outType"));
		Date alertRuleRunDate = rs.getDate("alert_rule_run_dt");
		if (alertRuleRunDate != null) {
			alertReportDetail.setAlertRuleRunDate(new MyDate(alertRuleRunDate));
		}
		alertReportDetail.setPresnId(rs.getInt("presn_id"));
		String outLostRevenue = rs.getString("outLostRevenue");
		if (outLostRevenue != null) {
			alertReportDetail.setAlertLostRevenue(new Double(outLostRevenue));
		} else {
			alertReportDetail.setAlertLostRevenue(null);
		}
		alertReportDetail.setDivisionDesc(RABCConstantsLists.getRABCConstantsLists().getText(rs.getString("divisionDesc"), true));
		
		/*
		 * Code to prepare the Graph URL.
		 */
		graphUrlBuffer.append("alertrule=").append(alertReportDetail.getAlertRule())
				.append("&extractDateName=proc_date")
				.append("&Header=Data Item")
				.append("&itemDDlName=alert_data")
				.append("&tableName=rabc_alert_hist")
				.append("&ProcDate=").append(sdf.format(alertReportDetail.getProcDate()))
				.append("&key1=").append(alertReportDetail.getAlertData1())
				.append("&aKey1=").append(alertReportDetail.getAlertData1());
		if ((alertReportDetail.getFileSeqNum() != null) && (!alertReportDetail.getFileSeqNum().equals(""))) {
			graphUrlBuffer.append("&fileSeqNum=").append(alertReportDetail.getFileSeqNum());
		}
		if (alertReportDetail.getAlertTimeValue() != null && !"".equals(alertReportDetail.getAlertTimeValue())) {
			graphUrlBuffer.append("&alertTimeValue=").append(alertReportDetail.getAlertTimeValue());
		}
		if (alertReportDetail.getAlertTimeInd() != null && !"".equals(alertReportDetail.getAlertTimeInd()) && !"M".equals(alertReportDetail.getAlertTimeInd())) {
			graphUrlBuffer.append("&alertTimeInd=").append(alertReportDetail.getAlertTimeInd());
		}
		if (alertReportDetail.getAlertItem() != null && !"".equals(alertReportDetail.getAlertItem())) {
			graphUrlBuffer.append("&alertItem=").append(alertReportDetail.getAlertItem());
		}
		if (alertReportDetail.getAlertData2() != null && !"".equals(alertReportDetail.getAlertData2())) {
			graphUrlBuffer.append("&key2=").append(alertReportDetail.getAlertData2());
			graphUrlBuffer.append("&aKey2=").append(alertReportDetail.getAlertData2());
		}
		if (alertReportDetail.getAlertData3() != null && !"".equals(alertReportDetail.getAlertData3())) {
			graphUrlBuffer.append("&key3=").append(alertReportDetail.getAlertData3());
			graphUrlBuffer.append("&aKey3=").append(alertReportDetail.getAlertData3());
		}
		if (alertReportDetail.getAlertData4() != null && !"".equals(alertReportDetail.getAlertData4())) {
			graphUrlBuffer.append("&key4=").append(alertReportDetail.getAlertData4());
			graphUrlBuffer.append("&aKey4=").append(alertReportDetail.getAlertData4());
		}
		if (alertReportDetail.getAlertData5() != null && !"".equals(alertReportDetail.getAlertData5())) {
			graphUrlBuffer.append("&key5=").append(alertReportDetail.getAlertData5());
			graphUrlBuffer.append("&aKey5=").append(alertReportDetail.getAlertData5());
		}
		graphUrl = graphUrlBuffer.toString();		
		alertReportDetail.setGraphUrl(graphUrl);

		return alertReportDetail;
	}
	
	/**
	 * Private method to return the list of strings having the distinct message nos. (fetched from the
	 * list of AlertReportDetail objects) seperated by comma. One string has the maximum of 1000 message numbers. 
	 * 
	 * @param alertReportDetailList
	 * @return List
	 */
	private List getMsgNums(List alertReportDetailList) {
	     List msgNums = new ArrayList();
	     String result = null;
	     StringBuffer resultBuffer = new StringBuffer();
	     if (alertReportDetailList != null) {
		     for(int i=0; i<alertReportDetailList.size(); i++) {
		        if(resultBuffer.indexOf(new Integer(((AlertReportDetail)alertReportDetailList.get(i)).getMsgNo()).toString()) == -1) { 
			     	resultBuffer.append('\'').append(((AlertReportDetail)alertReportDetailList.get(i)).getMsgNo()).append('\'').append(',');
		        }
		        if ((i+1) % 1000 == 0) {
		        	result = resultBuffer.toString();
		        	msgNums.add(result);
		        	resultBuffer = new StringBuffer();
		        }
		     }
	     }
	     if (resultBuffer.length() > 0) {
		     result = resultBuffer.toString();
		     msgNums.add(result);
	     }
	     return msgNums;
	}
	
	/**
	 * Private method to return the string having all the distinct alert rules (fetched from the
	 * list of AlertReportDetail objects) seperated by comma.
	 * 
	 * @param alertReportDetailList
	 * @return String
	 */
	private String getAlertRules(List alertReportDetailList) {
	     String result = "";
	     StringBuffer resultBuffer = new StringBuffer();
	     if (alertReportDetailList != null) {
		     for(int i=0; i<alertReportDetailList.size(); i++) {
		     	if(resultBuffer.indexOf(((AlertReportDetail)alertReportDetailList.get(i)).getAlertRule()) == -1) {
		     		resultBuffer.append('\'').append(((AlertReportDetail)alertReportDetailList.get(i)).getAlertRule()).append('\'').append(',');
		     	}
		     }
	     }
	     result = resultBuffer.toString();
	     return result;
	}
	
	/**
	 * Private method to return a hashmap of message number wise root category codes.
	 * This method accepts the list of strings of message nos. seperated by comma and uses it 
	 * as IN clause in the query.
	 * 
	 * @param connection
	 * @param failureList
	 * @param messageNumbers
	 * @return HashMap
	 */
	private HashMap getMsgNnmWiseRootCatgyCd(Connection connection, List failureList, List messageNumbers){
		HashMap msgNumWiseRootCatgyCdMap = new HashMap();
		List rootCtgyCdList = null;
		String selectSQL = qMsgCodes;
		String tempSql = null;
		String msgNums = null;
		List args = new ArrayList();
		int currentMsgNo = 0;
		int previousMsgNo = 0;
		String rootCtgy = null;
		List rootCtgyList = new ArrayList();
		
		if (messageNumbers.size() > 0) {
			for (int i=0; i<messageNumbers.size(); i++) {
				msgNums = (String) messageNumbers.get(i);
				if (msgNums.equals("")) {
					msgNums = "''";
				} else {
					msgNums = msgNums.substring(0, msgNums.length()-1);
				}
				if (i == 0) {
					tempSql = " select msg_num, alert_root_catgy_cd from rabc_warn_cd where msg_num in ( " + msgNums + " ) ";
				} else {
					tempSql += " union select msg_num, alert_root_catgy_cd from rabc_warn_cd where msg_num in ( " + msgNums + " ) ";
				}
			}
			tempSql = tempSql + " order by msg_num, alert_root_catgy_cd";
			args.add(tempSql);
			rootCtgyCdList = new WarningDAO().get(connection, failureList, args, selectSQL);
			if (!failureList.isEmpty()) {
				return null;
			}
		}

		if (rootCtgyCdList != null) {
			int counter = 0;
			int rootCtgyCdListSize = rootCtgyCdList.size();
			for (counter = 0; counter < rootCtgyCdListSize; counter++) {
				currentMsgNo = ((Warning) rootCtgyCdList.get(counter)).getMsgNum();
				rootCtgy = ((Warning) rootCtgyCdList.get(counter)).getAlertRootCatgyCd();
				if ((rootCtgyList.size() > 0) && (currentMsgNo != previousMsgNo)) {
					msgNumWiseRootCatgyCdMap.put(new Integer(previousMsgNo), rootCtgyList);
					rootCtgyList = new ArrayList();
				}
				rootCtgyList.add(rootCtgy);
				previousMsgNo = currentMsgNo;
			}
			msgNumWiseRootCatgyCdMap.put(new Integer(previousMsgNo), rootCtgyList);
		}
		
		return msgNumWiseRootCatgyCdMap;
	}
	
	/**
	 * Private method to return a hashmap of alert rule wise alert items.
	 * This method accepts the string of alert rules seperated by comma and uses it 
	 * as IN clause in the query.
	 * 
	 * @param connection
	 * @param failureList
	 * @param alertRules
	 * @return HashMap
	 */
	private HashMap getAlertRuleWiseAlertItems(Connection connection, List failureList, String alertRules){
		HashMap alertRuleWiseAlertItemsMap = new HashMap();
		String selectSQL = qVarTypes;
		List args = new ArrayList();
		args.add(alertRules);
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		
		try{
			MessageFormat mf = new MessageFormat(selectSQL);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			if (rs != null) {
				while(rs.next()) {
					alertRuleWiseAlertItemsMap.put(rs.getString(2), rs.getString(1));
				}
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
			return null;
		} finally{
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		
		return alertRuleWiseAlertItemsMap;
	}
	
	/**
	 * Private method to return a hashmap of alert rule wise key levels.
	 * This method accepts the string of alert rules seperated by comma and uses it 
	 * as IN clause in the query.
	 * 
	 * @param connection
	 * @param failureList
	 * @param alertRules
	 * @return HashMap
	 */
	private HashMap getAlertRuleWiseKeyLevels(Connection connection, List failureList, String alertRules){
		HashMap alertRuleWiseKeyLevelsMap = new HashMap();
		String selectSQL = getacctinstkeys;
		List args = new ArrayList();
		args.add(alertRules);
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		
		try{
			MessageFormat mf = new MessageFormat(selectSQL);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			if (rs != null) {
				while(rs.next()) {
					alertRuleWiseKeyLevelsMap.put(rs.getString(1), new Integer(rs.getInt(2)));
				}
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
			return null;
		} finally{
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		
		return alertRuleWiseKeyLevelsMap;
	}
	
	/**
	 * Private method to return a hashmap of alert rule wise alert groups.
	 * This method accepts the string of alert rules seperated by comma and uses it 
	 * as IN clause in the query.
	 * 
	 * @param connection
	 * @param failureList
	 * @param alertRules
	 * @return HashMap
	 */
	private HashMap getAlertRuleWiseAlertGroups(Connection connection, List failureList, String alertRules){
		HashMap alertRuleWiseAlertGroupsMap = new HashMap();
		String selectSQL = qRuleGroups;
		List args = new ArrayList();
		args.add(alertRules);
		String currentAlertRule = null;
		String previousAlertRule = null;
		String alertGroup = null;
		List alertGroupList = new ArrayList();
		
		List allAlertGroupList = new UpdateGrpDAO().get(connection, failureList, args, selectSQL);
		if (!failureList.isEmpty()) {
			return null;
		}
		if (allAlertGroupList != null) {
			int counter = 0;
			int allAlertGroupListSize = allAlertGroupList.size();
			for (counter = 0; counter < allAlertGroupListSize; counter++) {
				currentAlertRule = ((UpdateGrp) allAlertGroupList.get(counter)).getAlertRule();
				alertGroup = ((UpdateGrp) allAlertGroupList.get(counter)).getAlertGrp();
				if ((alertGroupList.size() > 0) && (!currentAlertRule.equals(previousAlertRule))) {
					alertRuleWiseAlertGroupsMap.put(previousAlertRule, alertGroupList);
					alertGroupList = new ArrayList();
				}
				alertGroupList.add(alertGroup);
				previousAlertRule = currentAlertRule;
			}
			alertRuleWiseAlertGroupsMap.put(previousAlertRule, alertGroupList);
		}
		
		return alertRuleWiseAlertGroupsMap;
	}
	
	/**
	 * Private method to return a hashmap of alert rule wise list of users which have access 
	 * to update that alert rule.
	 * This method accepts the string of alert rules seperated by comma and uses it 
	 * as IN clause in the query.
	 * 
	 * @param connection
	 * @param failureList
	 * @param alertRules
	 * @return HashMap
	 */
	private HashMap getAlertRuleWiseAccessMap(Connection connection, List failureList, String alertRules){
		HashMap alertRuleWiseAccessMap = new HashMap();
		String selectSQL = qUsers;
		List args = new ArrayList();
		args.add(alertRules);
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		String currentAlertRule = null;
		String previousAlertRule = null;
		String userId = null;
		List userIdList = new ArrayList();
		try{
			MessageFormat mf = new MessageFormat(selectSQL);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			if (rs != null) {
				while(rs.next()) {
					currentAlertRule = rs.getString(1);
					userId = rs.getString(2);
					if ((userIdList.size() > 0) && (!currentAlertRule.equals(previousAlertRule))) {
						alertRuleWiseAccessMap.put(previousAlertRule, userIdList);
						userIdList = new ArrayList();
					}
					userIdList.add(userId);
					previousAlertRule = currentAlertRule;
				}
				alertRuleWiseAccessMap.put(previousAlertRule, userIdList);
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
			return null;
		} finally{
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		
		return alertRuleWiseAccessMap;
	}
	
	/**
	 * Private method to return a hashmap of message number wise list of suplement data.
	 * This method accepts the list of strings of message nos. seperated by comma and uses it 
	 * as IN clause in the query.
	 * 
	 * @param connection
	 * @param failureList
	 * @param messageNumbers
	 * @return HashMap
	 */
	private HashMap getMsgNnmWiseSuppData(Connection connection, List failureList, List messageNumbers){
		HashMap msgNumWiseSuppDataMap = new HashMap();
		String selectSQL = getSuppInfo;
		String tempSql = null;
		String msgNums = null;
		List args = new ArrayList();
		List totalSuppInfoList = null;
		int currentMsgNo = 0;
		int previousMsgNo = 0;
		AlertSuppInfo alertSuppInfo = null;
		List suppInfoList = new ArrayList();
		
		if (messageNumbers.size() > 0) {
			for (int i=0; i<messageNumbers.size(); i++) {
				msgNums = (String) messageNumbers.get(i);
				if (msgNums.equals("")) {
					msgNums = "''";
				} else {
					msgNums = msgNums.substring(0, msgNums.length()-1);
				}
				if (i == 0) {
					tempSql = " select distinct msg_num, supp_seq_num, supp_presn_name, supp_pic_link, supp_data from rabc_alert_supp_info where supp_presn_name is not null and msg_num in ( " + msgNums + " ) ";
				} else {
					tempSql += " union select distinct msg_num, supp_seq_num, supp_presn_name, supp_pic_link, supp_data from rabc_alert_supp_info where supp_presn_name is not null and msg_num in ( " + msgNums + " ) ";
				}
			}
			args.add(tempSql);
			totalSuppInfoList = new AlertSuppInfoDAO().get(connection, failureList, args, selectSQL);
			if (!failureList.isEmpty()) {
				return null;
			}
		}
		
		if (totalSuppInfoList != null) {
			int counter = 0;
			int totalSuppInfoListSize = totalSuppInfoList.size();
			for (counter=0; counter<totalSuppInfoListSize; counter++) {
				alertSuppInfo = (AlertSuppInfo) totalSuppInfoList.get(counter);
				currentMsgNo = alertSuppInfo.getMsgNum();
				if ((suppInfoList.size() > 0) && (currentMsgNo != previousMsgNo)) {
					msgNumWiseSuppDataMap.put(new Integer(previousMsgNo), suppInfoList);
					suppInfoList = new ArrayList();
				}
				suppInfoList.add(alertSuppInfo);
				previousMsgNo = currentMsgNo;
			}
			msgNumWiseSuppDataMap.put(new Integer(previousMsgNo), suppInfoList);
		}
		
		return msgNumWiseSuppDataMap;
	}
	
	/**
	 * Private method to return the updated list of the AlertReportDetail objects by 
	 * using the respective hash maps like msgNumWiseRootCatgyCdMap, alertRuleWiseAlertItemsMap, etc.
	 * 
	 * @param alertReportDetailList
	 * @param loggedUserId
	 * @param msgNumWiseRootCatgyCdMap
	 * @param alertRuleWiseKeyLevelsMap
	 * @param alertRuleWiseAlertGroupsMap
	 * @param alertRuleWiseAccessMap
	 * @param msgNnmWiseSuppDataMap
	 * @return List
	 */
	private List updateAlertReportDetailList(List alertReportDetailList, String loggedUserId,
			HashMap msgNumWiseRootCatgyCdMap, HashMap alertRuleWiseKeyLevelsMap, 
			HashMap alertRuleWiseAlertGroupsMap, HashMap alertRuleWiseAccessMap, HashMap msgNnmWiseSuppDataMap){
		List newAlertReportDetailList = new ArrayList();
		AlertReportDetail alertReportDetail = null;
		
		for (int i=0; i<alertReportDetailList.size(); i++) {
			alertReportDetail = (AlertReportDetail)alertReportDetailList.get(i);
			int msgNum = alertReportDetail.getMsgNo();
			String alertRule = alertReportDetail.getAlertRule();
			
			if (msgNumWiseRootCatgyCdMap.containsKey(new Integer(msgNum))) {
				List rootCtgyList = (List) msgNumWiseRootCatgyCdMap.get(new Integer(msgNum));
				for (int j=0; j<rootCtgyList.size(); j++) {
					alertReportDetail.addAlertRootCatgy((String)rootCtgyList.get(j));
				}
			}
			
			if (alertRuleWiseKeyLevelsMap.containsKey(alertRule)) {
				alertReportDetail.setAlertKeyLevel(((Integer)alertRuleWiseKeyLevelsMap.get(alertRule)).intValue());
			}
			
			if (alertRuleWiseAlertGroupsMap.containsKey(alertRule)) {
				List alertGroupList = (List) alertRuleWiseAlertGroupsMap.get(alertRule);
				for (int k=0; k<alertGroupList.size(); k++) {
					alertReportDetail.addAlertGroup((String)alertGroupList.get(k));
				}
			}
			
			if (alertRuleWiseAccessMap.containsKey(alertRule)) {
				List userIdList = (List) alertRuleWiseAccessMap.get(alertRule);
				if (userIdList.contains(loggedUserId)) {
					alertReportDetail.setUpdateAccess(1);
				} else {
					alertReportDetail.setUpdateAccess(0);
				}
			}
			
			if (msgNnmWiseSuppDataMap.containsKey(new Integer(msgNum))) {
				List suppInfoList = (List) msgNnmWiseSuppDataMap.get(new Integer(msgNum));
				if (suppInfoList != null) {
					for (int k=0; k<suppInfoList.size(); k++) {
						alertReportDetail.addAlertSuppInfo((AlertSuppInfo) suppInfoList.get(k));
					}
					alertReportDetail.setKeyRow(1);
				}
			}			
			
			newAlertReportDetailList.add(alertReportDetail);
		}
		
		return newAlertReportDetailList;
	}
	
	private void updateAlertReportDetailsListForMouseOver(Connection connection, List failureList,  List alertReportDetailList){
		for(int i = 0; i < alertReportDetailList.size(); i++){
			AlertReportDetail alertReportDetail = (AlertReportDetail) alertReportDetailList.get(i);
		
			int presn_id = alertReportDetail.getPresnId();
			String alertKey1 = getKeyForAbbrevation(alertReportDetail, alertReportDetail.getAlertKey1());
			String alertKey2 = getKeyForAbbrevation(alertReportDetail,alertReportDetail.getAlertKey2());
			String alertKey3 = getKeyForAbbrevation(alertReportDetail,alertReportDetail.getAlertKey3());
			String alertKey4 = getKeyForAbbrevation(alertReportDetail,alertReportDetail.getAlertKey4());
			String alertKey5 = getKeyForAbbrevation(alertReportDetail,alertReportDetail.getAlertKey5());
			String alertData1 = alertReportDetail.getAlertData1();
			String alertData2 = alertReportDetail.getAlertData2();
			String alertData3 = alertReportDetail.getAlertData3();
			String alertData4 = alertReportDetail.getAlertData4();
			String alertData5 = alertReportDetail.getAlertData5();			
			
			String prepareStatement1 = "Select LINK_TBL_KEY_DATA, LINK_TBL_NAME from rabc_mouse_over_link where presn_id = ? and WEBID = 'RABCPSF00011' and LINK_TBL_KEY_NAME = ? ";
			String prepareStatement2 = "";
			PreparedStatement preparedStmt1 = null;
			PreparedStatement preparedStmt2 = null;			
			ResultSet rs1 = null;
			ResultSet rs2 = null;
			String linkTblKeyData = null;
			String linkTblName = null;
			String mouseOverDescription = null;			
			try {
				preparedStmt1 = connection.prepareStatement(prepareStatement1);		
			
				if(alertKey1 != null && !alertKey1.equals("") && alertData1 != null && !alertData1.equals("")){
					linkTblKeyData = null;
					linkTblName = null;
					preparedStmt1.setInt(1, presn_id);
					preparedStmt1.setString(2, alertKey1);
					rs1 = preparedStmt1.executeQuery();
					if(rs1.next()){
						linkTblKeyData = rs1.getString(1);
						linkTblName = rs1.getString(2);
					}
					
					if(linkTblKeyData != null && linkTblName != null && !linkTblKeyData.equals("") && !linkTblName.equals("")){
						prepareStatement2 = "Select " + linkTblKeyData + " from " + linkTblName + " where " + alertKey1 + " = ?"; 
						preparedStmt2 = connection.prepareStatement(prepareStatement2);						
						preparedStmt2.setString(1, alertData1);
						rs2 = preparedStmt2.executeQuery();	
						
						if(rs2.next()){
							mouseOverDescription = rs2.getString(1);	
							alertReportDetail.setAlertMouseOver1(mouseOverDescription);
						}
					}
				}
				
				if(alertKey2 != null && !alertKey2.equals("") && alertData2 != null && !alertData2.equals("")){
					linkTblKeyData = null;
					linkTblName = null;
					preparedStmt1.setInt(1, presn_id);
					preparedStmt1.setString(2, alertKey2);
					rs1 = preparedStmt1.executeQuery();
					if(rs1.next()){
						linkTblKeyData = rs1.getString(1);
						linkTblName = rs1.getString(2);
					}
					
					if(linkTblKeyData != null && linkTblName != null && !linkTblKeyData.equals("") && !linkTblName.equals("")){
						prepareStatement2 = "Select " + linkTblKeyData + " from " + linkTblName + " where " + alertKey2 + " = ?"; 
						preparedStmt2 = connection.prepareStatement(prepareStatement2);						
						preparedStmt2.setString(1, alertData2);
						rs2 = preparedStmt2.executeQuery();
						if(rs2.next()){
							mouseOverDescription = rs2.getString(1);	
							alertReportDetail.setAlertMouseOver2(mouseOverDescription);
						}
					}
				}
				
				if(alertKey3 != null && !alertKey3.equals("") && alertData3 != null && !alertData3.equals("")){
					linkTblKeyData = null;
					linkTblName = null;
					preparedStmt1.setInt(1, presn_id);
					preparedStmt1.setString(2, alertKey3);
					rs1 = preparedStmt1.executeQuery();
					if(rs1.next()){
						linkTblKeyData = rs1.getString(1);
						linkTblName = rs1.getString(2);
					}
					
					if(linkTblKeyData != null && linkTblName != null && !linkTblKeyData.equals("") && !linkTblName.equals("")){
						prepareStatement2 = "Select " + linkTblKeyData + " from " + linkTblName + " where " + alertKey3 + " = ?"; 
						preparedStmt2 = connection.prepareStatement(prepareStatement2);						
						preparedStmt2.setString(1, alertData3);
						rs2 = preparedStmt2.executeQuery();
						if(rs2.next()){
							mouseOverDescription = rs2.getString(1);	
							alertReportDetail.setAlertMouseOver3(mouseOverDescription);
						}
					}
				}
				
				if(alertKey4 != null && !alertKey4.equals("") && alertData4 != null && !alertData4.equals("")){
					linkTblKeyData = null;
					linkTblName = null;
					preparedStmt1.setInt(1, presn_id);
					preparedStmt1.setString(2, alertKey4);
					rs1 = preparedStmt1.executeQuery();
					if(rs1.next()){
						linkTblKeyData = rs1.getString(1);
						linkTblName = rs1.getString(2);
					}
					
					if(linkTblKeyData != null && linkTblName != null && !linkTblKeyData.equals("") && !linkTblName.equals("")){
						prepareStatement2 = "Select " + linkTblKeyData + " from " + linkTblName + " where " + alertKey4 + " = ?"; 
						preparedStmt2 = connection.prepareStatement(prepareStatement2);						
						preparedStmt2.setString(1, alertData4);
						rs2 = preparedStmt2.executeQuery();
						if(rs2.next()){
							mouseOverDescription = rs2.getString(1);	
							alertReportDetail.setAlertMouseOver4(mouseOverDescription);
						}
					}
				}
				
				if(alertKey5 != null && !alertKey5.equals("") && alertData5 != null && !alertData5.equals("")){
					linkTblKeyData = null;
					linkTblName = null;
					preparedStmt1.setInt(1, presn_id);
					preparedStmt1.setString(2, alertKey5);
					rs1 = preparedStmt1.executeQuery();
					if(rs1.next()){
						linkTblKeyData = rs1.getString(1);
						linkTblName = rs1.getString(2);
					}
					
					if(linkTblKeyData != null && linkTblName != null && !linkTblKeyData.equals("") && !linkTblName.equals("")){
						prepareStatement2 = "Select " + linkTblKeyData + " from " + linkTblName + " where " + alertKey5 + " = ?"; 
						preparedStmt2 = connection.prepareStatement(prepareStatement2);						
						preparedStmt2.setString(1, alertData5);
						rs2 = preparedStmt2.executeQuery();
						if(rs2.next()){
							mouseOverDescription = rs2.getString(1);	
							alertReportDetail.setAlertMouseOver5(mouseOverDescription);
						}
					}
				}
			
			} catch (SQLException sx) {
				logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement1, prepareStatement2}) + " Exception details: " + sx.getMessage(), sx);
				failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement1, prepareStatement2}), sx));				
			} finally{
				SQLHelper.closeResultSet(rs1, failureList, logger);
				SQLHelper.closeStatement(preparedStmt1, failureList, logger);
				SQLHelper.closeResultSet(rs2, failureList, logger);
				SQLHelper.closeStatement(preparedStmt2, failureList, logger);
			}
		}		
	}
	
	
	private String getKeyForAbbrevation(AlertReportDetail alertReportDetail, String key){
		Map map = alertReportDetail.getAlertKeyAbbrevationMap();
		if(map.containsKey(key)){
			return (String) map.get(key);
		}
		else{
			return key;
		}
		
	}
	/**
	 * Method to generate the excel report of Alert Report Detail. Internaly, it calls the service class method
	 * to get the list of AlertReportDetail objects and by looping through that list it pouplates the excel report.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param hiddenArgs
	 * @param report
	 * @param progressBar
	 */
	protected void getExcelReport(Connection connection, List failureList, List args, List hiddenArgs, 
			ExcelReport report, ProgressBar progressBar) {
		int counter = 0;
		int counter1 = 0;
		int totalAlerts = 0;
		boolean seqColumn = false;
		String cycle = "";
		List alertRootCatgyList = null;
		List alertGroupList = null;
		int size = 0;
		NumberFormat numberFormat = new DecimalFormat(",##0");
		NumberFormat decimalFormat = new DecimalFormat(",##0.00");
		NumberFormat dollarFormat = new DecimalFormat("$ ,##0.00");
		
		String userId = (String) args.get(0);
    	String fileStartDate = (String) args.get(1);
    	String fileEndDate = (String) args.get(2);
    	String alertRule = (String) args.get(4);
    	String alertRuleTiming = (String) args.get(6);
    	String alertStatus = (String) args.get(8);
    	String alertSeverity = (String) args.get(9);
    	String groupAlerted = (String) args.get(10);
    	String revenueImpactValue = (String)args.get(11);
    	int revenueImpactInd = ((Integer)args.get(12)).intValue();
    	String lastUpdatedStartDate = (String) args.get(15);
    	String lastUpdatedEndDate = (String) args.get(16);
    	String webPageId = (String) args.get(17);
    	String dateType = (String) args.get(18);
    	String processPoint = (String) args.get(19);
    	String region = (String) args.get(26);
    	
    	String controlPoint = (String) hiddenArgs.get(0);
    	String division = (String) hiddenArgs.get(1);
    	String alertRuleTimingInd = (String) hiddenArgs.get(2);
    	String alertRootCtgy = (String) hiddenArgs.get(3);
    	String systemErrorType = (String) hiddenArgs.get(4);
    	
    	if ("WE".equalsIgnoreCase(region)) {
			List cycleList = alertReportDetailService.getCycleCalendarList(connection, failureList, args);
			if (cycleList != null) {
				int cycleListSize = cycleList.size();
				if (cycleListSize > 0) {
					if (cycleListSize == 1) {
						cycle = ((new StringBuffer())
								.append("Cycle(s):")
								.append((new Integer(((CycleCalendar) cycleList.get(0)).getCycle())).toString()))
								.toString();
					} else {
						cycle = ((new StringBuffer())
								.append("Cycle(s):")
								.append((new Integer(((CycleCalendar) cycleList.get(0)).getCycle())).toString())
								.append(" - ")
								.append((new Integer(((CycleCalendar) cycleList.get(cycleListSize-1)).getCycle())).toString()))
								.toString();
					}
				} else {
					cycle = "";
				}
			} else {
				cycle = "";
			}
    	}
		progressBar.setProgressPercent(progressBar.getPercent() + 10);
		
		List alertList = alertReportDetailService.getAlertReportDetailList(connection, failureList, args, progressBar);
		
		try {
			if (alertList != null) {
				totalAlerts = alertList.size();
				AlertReportDetail alertReportDetail = null;
				for(counter = 0; counter < totalAlerts; counter++) {
					alertReportDetail = (AlertReportDetail)alertList.get(counter);
					if (seqColumn == false) {
						if ((alertReportDetail.getFileSeqNum() != null) && (!alertReportDetail.getFileSeqNum().equals(""))) {
							seqColumn = true;
						}
					}
				}
				
				report.beginReport();
					report.beginTable();
						report.beginRow();
							report.addRptHeaderLine1("Alert Report");
						report.endRow();
						
						if (totalAlerts > 0) {
							if ("file".equals(dateType)) {
								report.addCriteriaRow("From File Dates", fileStartDate + " - " + fileEndDate + "  " + cycle);
							} else if ("run".equals(dateType)) {
								report.addCriteriaRow("From Alert Run Dates", fileStartDate + " - " + fileEndDate + "  " + cycle);
							}
						}
						
						report.beginRow();
							report.addLabel("Report Criteria");
						report.endRow();
						if ((fileStartDate != null) && !(fileStartDate.equals("")) && (fileEndDate != null) && !(fileEndDate.equals(""))) {
							if ("file".equals(dateType)) {
								report.addCriteriaRow("File Dates", fileStartDate + " - " + fileEndDate);
							} else if ("run".equals(dateType)) {
								report.addCriteriaRow("Alert Run Dates", fileStartDate + " - " + fileEndDate);
							}
						}
						if ((lastUpdatedStartDate != null) && !(lastUpdatedStartDate.equals("")) && (lastUpdatedEndDate != null) && !(lastUpdatedEndDate.equals(""))) {
							report.addCriteriaRow("Last Update Dates", lastUpdatedStartDate + " - " + lastUpdatedEndDate);
						}
						if ((processPoint != null) && !(processPoint.equals(""))) {
							report.addCriteriaRow("Process Point", processPoint);
						}
						if ((controlPoint != null) && !(controlPoint.equals(""))) {
							report.addCriteriaRow("Control Point", controlPoint);
						}
						if ((alertRule != null) && !(alertRule.equals(""))) {
							report.addCriteriaRow("Alert Rule", alertRule);
						}
						if ((alertSeverity != null) && (alertSeverity.length() > 0)) {
							if (alertSeverity.equals("1")) {
								report.addCriteriaRow("Alert Severity", "High");
							} else if (alertSeverity.equals("2")) {
								report.addCriteriaRow("Alert Severity", "Medium");
							} else if (alertSeverity.equals("3")) {
								report.addCriteriaRow("Alert Severity", "Low");
							}
						}
						if ((alertRuleTiming != null) && (alertRuleTiming.length() > 0)) {
							if (alertRuleTiming.equals("R")) {
								report.addCriteriaRow("Alert Rule Timing", "Record");
							} else if (alertRuleTiming.equals("B")) {
								report.addCriteriaRow("Alert Rule Timing", "Bill Cycle" + " - "  + alertRuleTimingInd);
							} else if (alertRuleTiming.equals("D")) {
								report.addCriteriaRow("Alert Rule Timing", "Call Day Week" + " - "  + alertRuleTimingInd);
							}
						}
						if ((revenueImpactValue != null) && (!revenueImpactValue.trim().equals(""))) {
							double revenueImpactValue1 = (new Double(revenueImpactValue.trim())).doubleValue();
							if (revenueImpactInd == 1) {
								report.addCriteriaRow("Revenue Impact", "Greater than " + dollarFormat.format(revenueImpactValue1));
							} else if (revenueImpactInd == 2) {
								report.addCriteriaRow("Revenue Impact", "Equal to " + dollarFormat.format(revenueImpactValue1));
							} else if (revenueImpactInd == 3) {
								report.addCriteriaRow("Revenue Impact", "Less than " + dollarFormat.format(revenueImpactValue1));
							}
						}
						if ((alertStatus != null) && !(alertStatus.equals(""))) {
							report.addCriteriaRow("Alert Status", alertStatus);
						}
						if ((alertRootCtgy != null) && !(alertRootCtgy.equals(""))) {
							report.addCriteriaRow("Root Category", alertRootCtgy);
						}
						if ((groupAlerted != null) && !(groupAlerted.equals(""))) {
							report.addCriteriaRow("Group Alerted", groupAlerted);
						}
						if ((systemErrorType != null) && !(systemErrorType.equals(""))) {
							report.addCriteriaRow("System Error", systemErrorType);
						}
						
						report.beginRow();
						report.endRow();
						
						report.beginRow();
							report.addColumn("Total Alerts:", "#FFFFFF", true, "left");
							report.addColumn(numberFormat.format(totalAlerts), "#FFFFFF", false, "left");
						report.endRow();
						
						report.beginRow();
						report.endRow();
						
						report.addRaw("<table width=100% border=2>");
						report.beginRow();
							report.addHeader("Alert Rule");
							if (seqColumn == true) {
								report.addHeader("Seq#");
							}
							report.addHeader("Division");
							report.addHeader("File Date");
							report.addHeader("Data Item");
							report.addHeader("Actual Data");
							report.addHeader("% Variance");
							report.addHeader("Status");
							report.addHeader("Dollar Impact");
							report.addHeader("Root Cause Category");
							report.addHeader("Group(s) Alerted");
							report.addHeader("Alert Last Update");
						report.endRow();
						progressBar.setProgressPercent(progressBar.getPercent() + 10);
						
						if (totalAlerts > 0) {
							for(counter=0; counter<totalAlerts; counter++) {
								alertReportDetail = (AlertReportDetail) alertList.get(counter);
								report.beginRow();
									report.addColumn(alertReportDetail.getAlertRule(), "#FFFFFF", false, "center");
									if (seqColumn == true) {
										if ((alertReportDetail.getFileSeqNum() != null) && (!alertReportDetail.getFileSeqNum().equals(""))) {
											report.addColumn(numberFormat.format(alertReportDetail.getFileSeqNum()), "#FFFFFF", false, "right");
										} else {
											report.addColumn("");
										}
									}
									report.addColumn(alertReportDetail.getAlertData1(), "#FFFFFF", false, "center");
									report.addColumn(alertReportDetail.getProcDate().toString(), "#FFFFFF", false, "center");//It should be date.
									report.addColumn(alertReportDetail.getAlertItem(), "#FFFFFF", false, "center");
									if ((alertReportDetail.getAlertActual() != null) && (!alertReportDetail.getAlertActual().equals(""))) {
										report.addColumn(decimalFormat.format(alertReportDetail.getAlertActual()), "#FFFFFF", false, "right");
									} else {
										report.addColumn("");
									}
									if ((alertReportDetail.getAlertPct() != null) && (!alertReportDetail.getAlertPct().equals(""))) {
										report.addColumn(decimalFormat.format(alertReportDetail.getAlertPct())+"%", "#FFFFFF", false, "right");
									} else {
										report.addColumn("");
									}
									report.addColumn(alertReportDetail.getAlertStatus(), "#FFFFFF", true, "center");
									if ((alertReportDetail.getAlertRevenue() != null) && (!alertReportDetail.getAlertRevenue().equals(""))) {
										report.addColumn(dollarFormat.format(alertReportDetail.getAlertRevenue()), "#FFFFFF", false, "right");
									} else {
										report.addColumn("");
									}
									alertRootCatgyList = alertReportDetail.getAlertRootCatgyList();
									report.addRaw("<td>");
									if (alertRootCatgyList != null) {
										size = alertRootCatgyList.size();
										for (counter1=0; counter1<size; counter1++) {
											report.addRaw((String)alertRootCatgyList.get(counter1));
											report.addBreak();
										}
									}
									report.addRaw("</td>");
									alertGroupList = alertReportDetail.getAlertGroupList();
									report.addRaw("<td>");
									if (alertGroupList != null) {
										size = alertGroupList.size();
										for (counter1=0; counter1<size; counter1++) {
											report.addRaw((String)alertGroupList.get(counter1));
											report.addBreak();
										}
									}
									report.addRaw("</td>");
									report.addColumn(alertReportDetail.getTimeStamp().toString(), "#FFFFFF", false, "center");//It should be time stamp.
								report.endRow();
								if (alertReportDetail.getKeyRow() == 1) {
									report.beginRow();
										if ((alertReportDetail.getAlertData2() != null) && (!alertReportDetail.getAlertData2().equals(""))) {
											if ((alertReportDetail.getAlertKey2() != null) && (!alertReportDetail.getAlertKey2().equals(""))) {
												report.addColumn(alertReportDetail.getAlertKey2()+":", "#FFFFFF", true, "left");
											} else {
												report.addColumn("Key2:", "#FFFFFF", true, "left");
											}
											report.addColumn(alertReportDetail.getAlertData2(), "#FFFFFF", false, "left");
										}
										if ((alertReportDetail.getAlertData3() != null) && (!alertReportDetail.getAlertData3().equals(""))) {
											if ((alertReportDetail.getAlertKey3() != null) && (!alertReportDetail.getAlertKey3().equals(""))) {
												report.addColumn(alertReportDetail.getAlertKey3()+":", "#FFFFFF", true, "left");
											} else {
												report.addColumn("Key3:", "#FFFFFF", true, "left");
											}
											report.addColumn(alertReportDetail.getAlertData3(), "#FFFFFF", false, "left");
										}
										if ((alertReportDetail.getAlertData4() != null) && (!alertReportDetail.getAlertData4().equals(""))) {
											if ((alertReportDetail.getAlertKey4() != null) && (!alertReportDetail.getAlertKey4().equals(""))) {
												report.addColumn(alertReportDetail.getAlertKey4()+":", "#FFFFFF", true, "left");
											} else {
												report.addColumn("Key4:", "#FFFFFF", true, "left");
											}
											report.addColumn(alertReportDetail.getAlertData4(), "#FFFFFF", false, "left");
										}
										if ((alertReportDetail.getAlertData5() != null) && (!alertReportDetail.getAlertData5().equals(""))) {
											if ((alertReportDetail.getAlertKey5() != null) && (!alertReportDetail.getAlertKey5().equals(""))) {
												report.addColumn(alertReportDetail.getAlertKey5()+":", "#FFFFFF", true, "left");
											} else {
												report.addColumn("Key5:", "#FFFFFF", true, "left");
											}
											report.addColumn(alertReportDetail.getAlertData5(), "#FFFFFF", false, "left");
										}
										List alertSuppInfoList = alertReportDetail.getAlertSuppInfoList();
										if (alertSuppInfoList != null) {
											int alertSuppInfoListSize = alertSuppInfoList.size();
											for(counter1=0; counter1<alertSuppInfoListSize; counter1++) {
												AlertSuppInfo alertSuppInfo = (AlertSuppInfo) alertSuppInfoList.get(counter1);
												String suppPresnName = alertSuppInfo.getSuppPresnName();
												int suppData = alertSuppInfo.getSuppData();
												report.addColumn(suppPresnName+":", "#FFFFFF", true, "left");
												report.addColumn(String.valueOf(suppData), "#FFFFFF", false, "left");
											}
										}
									report.endRow();
								}
							}
						} else {
							report.beginRow();
								report.addColumn("No Data Found.", "#33CCFF", true, "center");
							report.beginRow();
						}
						report.addRaw("</table>");
					report.endTable();
				report.endReport();
			}
		} catch(IOException iox) {
			logger.error("Error in creting the excel report of Alert Report Detail. Exception details: " + iox.getMessage(), iox);
		  	failureList.add(new RABCException("Error in creting the excel report of Alert Report Detail.", iox));
		}
	}
	
	/**
	 * Method to return the default line count for the logged in user. It first checks the default line count
	 * for the logged in user in database and if it exists, return it otherwise it calls the RABCConstantsLists
	 * class to get the default line count.
	 * 
	 * @param connection
	 * @param failureList
	 * @param userId
	 * @return int
	 */
	protected int getDefaultLineCount(Connection connection, List failureList, String userId) {
		int defaultLineCount = 0;
		String selectSQL = getDefaultLineCount;
		List args = new ArrayList();
		args.add(userId);
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		try{
			MessageFormat mf = new MessageFormat(selectSQL);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			if (rs != null && rs.next()) {
				defaultLineCount = rs.getInt(1);
			} else {
				defaultLineCount = RABCConstantsLists.getRABCConstantsLists().getPageSize();
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		
		return defaultLineCount;
	}
	
	/**
	 * Get the default division
	 * @param connection
	 * @param failureList
	 * @param userId
	 * @return
	 */
	protected String getDefaultDivision(Connection connection, List failureList, String userId) {
		String defaultDivision = "";
		String selectSQL = getDefaultDivision;
		List args = new ArrayList();
		args.add(userId);
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		try{
			MessageFormat mf = new MessageFormat(selectSQL);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			if (rs != null && rs.next()) {
				defaultDivision = rs.getString(1);
			} 
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		
		return defaultDivision;
	}
}
