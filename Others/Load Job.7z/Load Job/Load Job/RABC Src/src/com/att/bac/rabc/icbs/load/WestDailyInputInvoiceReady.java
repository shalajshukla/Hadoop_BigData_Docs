/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.icbs.load;

import java.io.File;
import java.net.UnknownHostException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Iterator;

import com.att.bac.rabc.util.EmcisEventLogger;
import com.att.bac.util.NetUtil;
import com.sbc.bac.rabc.load.FilePatternLoadJob;
import com.sbc.bac.rabc.load.PrepareTableForRerun;
import com.sbc.bac.rabc.load.RabcLoadJobTrig;
import com.sbc.bac.rabc.load.RetrieveStaticInfo;
import com.sbc.bac.rabc.load.StaticErrorMsgKeys;
import com.sbc.bac.rabc.load.StaticFieldKeys;

/**
 * This is a Load job for loading Daily input Invoice ready (IB00) data for West region 
 * into RABC_ICBS_INVOICE_READY.
 * 
 * @author Shailesh Hemdev - SH8512
 */
public class WestDailyInputInvoiceReady extends FilePatternLoadJob {
	private static final SimpleDateFormat MMDDYY_FORMAT = new SimpleDateFormat("MM-dd-yy");
	private static final SimpleDateFormat MMDDYYYY_FORMAT = new SimpleDateFormat("MMddyyyy");
	
	private static final String RABC_ICBS_INVOICE_READY = "RABC_ICBS_INVOICE_READY";
	private static final String RABC_TRIG = "RABC_TRIG";
	
	private static final String FILE_ID = "WEICBSIB";
	
	private static final String fieldSeperator = StaticFieldKeys.SEMICOLON;
	
	private PreparedStatement insert_IB00;
	
	private String runDate;
	private java.sql.Date sqlRunDate;
	private String division, fileName, fileToken;
	private String backoutRecovery = null;
	private File currentFile;
	private String billRnd;
	
	private int recordCount;
	private int batchCounter;
	
	/*
	 * HashMap variables to contain the groups for various tables.
	 */
	private HashMap icbsDataMap;
	
	/*
	 * boolean variables indicating whether trigger to be inserted for that file id.
	 */
	boolean isInvoiceReady;
	
	/*
	 * boolean variables indicating whether the file to be processed or not.
	 */
	boolean isHeaderExists;
	boolean isTrailerExists;
	boolean isDateRecordExists;
	boolean isRecordCountMatches;
	
	/**
	 * Overriding preprocess() method. 
	 * It is executed prior to processing the load job.
	 * Forms the actual prepared statements which need to be fired on to the database.
	 * 
	 * @see com.sbc.bac.load.LoadJob#preprocess()
	 */
	public boolean preprocess() {
		boolean success = super.preprocess();

		if (success) {
			try {
				StringBuffer sql = new StringBuffer();
/*				sql.append("  INSERT INTO RABC_ICBS_INVOICE_READY (RUN_DATE, DIVISION,ENTITY_CD, TRN_TYPE, DAILY_INPUT_MSG_CT, DAILY_INPUT_AMT, EMS_ERR_MSG_CT, EMS_ERR_AMT, RTN_MSG_CT, RTN_MSG_AMT, BLG_MSG_CT, BLG_MSG_AMT, CRUDE_OUT_MSG_CT, CRUDE_OUT_MSG_AMT, TOT_MSG_INPUT_CT, TOT_MSG_PROC_CT, TOT_MSG_INPUT_AMT, TOT_MSG_PROC_AMT, BILL_RND) ");
				sql.append("  VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?, ?, ?, ?, ?, ? ) ");
*/				
				sql.append("  INSERT INTO RABC_ICBS_INVOICE_READY (RUN_DATE, DIVISION,ENTITY_CD, TRN_TYPE, DAILY_INPUT_MSG_CT, DAILY_INPUT_AMT, EMS_ERR_MSG_CT, EMS_ERR_AMT, RTN_MSG_CT, RTN_MSG_AMT, BLG_MSG_CT, BLG_MSG_AMT, TOT_MSG_INPUT_CT, TOT_MSG_PROC_CT, TOT_MSG_INPUT_AMT, TOT_MSG_PROC_AMT, BILL_RND," +
																	"MASTER_MSG_CT, MASTER_REV_AMT, REENTERED_MSG_CT, REENTERED_REV_AMT, BEGIN_MSG_CT, BEGIN_REV_AMT, EMS_IN_MSG_CT, EMS_IN_REV_AMT) ");
				sql.append("  VALUES(?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ) ");
				
				insert_IB00 = connection.prepareStatement(sql.toString());
				sql.setLength(0);
			} catch (SQLException e) {
				severe(StaticErrorMsgKeys.PREPROCESS_ERROR + e.getMessage(), e);
				success = false;
			}
		}
		
		return success;
	}
	
	/**
	 * Overriding preprocessFile(file) method.
	 * It is executed prior to processing the file to be loaded.
	 * It includes the following steps:
	 * 	1) Marks the backoutRecovery flag to "Y" if this file has already been processed earlier.
	 * 	2) Initializes the global variables with default values.
	 * 
	 * @see com.sbc.bac.load.FileDBLoadJob#preprocessFile(java.io.File)
	 */	
	public boolean preprocessFile(File file) {
		boolean success = super.preprocessFile(file);
		fileName = file.getName();
		fileToken = "RA160F01";
		if (success) {
			try {
				/*
				 * Check whether this file has been processed before and if yes,
				 * mark the backoutRecovery flag to "Y".
				 */
				if (RabcLoadJobTrig.IsOriginalFileLoaded(connection, file, file.getName().length())) {
					backoutRecovery = "Y";
				}
			} catch (Exception e) {
				severe(StaticErrorMsgKeys.PREPROCESSFILE_ERROR + e.getMessage(), e);
				success = false;
			}
		}
		
		/*
		 * Initialize the global variables with default values.
		 */
		currentFile = file;
		recordCount = 0;
		isHeaderExists = false;
		isTrailerExists = false;
		isDateRecordExists=false;
		isRecordCountMatches = false;
		batchCounter = 0;
		icbsDataMap = new HashMap();
		isInvoiceReady = false;
		
		return success;
	}
	
	/**
	 * Overriding parseLine(line) method.
	 * It accepts a single line and checks whether it is header, trailer, date or detail record.
	 * Depending upon the record type, it calls the respective internal private methods to process the line.
	 * 
	 * @see com.sbc.bac.load.FileDBLoadJob#parseLine(java.lang.String)
	 */
	protected int parseLine(String line) throws Exception {
		boolean status = true;
		String recordIndicator = getRecordType(line);
		
		if ("HEADER".equalsIgnoreCase(recordIndicator)) {
			isHeaderExists = true;
			status = processIB00Header(line);
		} else if ("DATE".equalsIgnoreCase(recordIndicator)) {
			if (!isHeaderExists) {
				throw new Exception("Either header record is not present in the file or it is not the first record.");
			} else {
				isDateRecordExists = true;
				recordCount++;
				status = processCycleRecord(line);
			}
		}else if ("TRAILER".equalsIgnoreCase(recordIndicator)) {
			if (!isHeaderExists) {
				throw new Exception("Either header record is not present in the file or it is not the first record.");
			}else if (!isDateRecordExists){
				throw new Exception("Either date record is not present in the file or it is not the second record.");
			}else {
				isTrailerExists = true;
				status = processIB00Trailer(line);
			}
		}  else if ("DETAIL".equalsIgnoreCase(recordIndicator)) {
			if (!isHeaderExists) {
				throw new Exception("Either header record is not present in the file or it is not the first record.");
			} else if (!isDateRecordExists) {
				throw new Exception("Either date record is not present in the file or it is not the second record.");
			} else if (isTrailerExists) {
				throw new Exception("Trailer record is not the last record.");
			} else {
				recordCount++;
				status = processIB00(line);
			}
		} else {
			recordCount++;
			status = false;
		}
		
		if (status) {
			return SUCCESS;
		} else {
			return ERROR;
		}
	}
	
	/**
	 * Private method to return the record type of the line to be processed.
	 * 
	 * @param line
	 * @return String
	 * @throws Exception
	 */
	private String getRecordType(String line) throws Exception {
		String recordType = null;
		
		String [] lineFields = line.split(fieldSeperator);
		
		if (lineFields.length > 1) {
			String firstField			= lineFields[0].trim();
			String secondField			= lineFields[1].trim();
			
			if ("HEADER".equals(firstField)) {
				recordType = "HEADER";
			} else if ("TRAILER".equals(firstField)) {
				recordType = "TRAILER";
			} else {
				if ("RA16ICBS".equals(firstField)) {
					if ("01".equals(secondField)) {
						recordType = "DATE";
					} else if (("02".equals(secondField))||("10".equals(secondField))) {
						recordType = "DETAIL";
					}
				}
			}
		}
		
		return recordType;
	}
	
	/**
	 * Private method to process the header record.
	 * 
	 * @param line
	 * @return boolean
	 * @throws Exception
	 */
	private boolean processIB00Header(String line) throws Exception {
		boolean success = false;
		
		String [] lineFields = line.split(fieldSeperator);
		
		/*
		 * Populate the instance variable for division.
		 */
		if (lineFields.length > 2) {
			division = lineFields[2].trim();
			division = getDivision(division);
			success = true;
		}
		
		return success;
	}
	
	/**
	 * Private method to process the trailer record.
	 * It checks that whether the total number of records (excluding header and trailer records)
	 * in the file is eqaul to the count in the trailer record or not.
	 *  
	 * @param line
	 * @return boolean
	 * @throws Exception
	 */
	private boolean processIB00Trailer(String line) throws Exception {
		boolean success = false;
		int trailerCount = 0;
		
		String [] lineFields = line.split(fieldSeperator);
		
		if (lineFields.length > 5) {
			trailerCount = Integer.parseInt(lineFields[5].trim());
			success = true;
		}
		
		if (success) {
			if (trailerCount == recordCount) {
				isRecordCountMatches = true;
			}
		}
		
		return success;
	}
	
	/**
	 * Private method to process the date record. It does the following steps:
	 * 	1) Retrieves the cycle date from the date record.
	 * 	2) Deletes the records matching with the date and division retrieved form the file from the table 
	 * 	   RABC_ICBS_INVOICE_READY if the backoutRecovery flag is "Y", i.e. this file has already been processed earlier.
	 * 
	 * @param line
	 * @return boolean
	 * @throws Exception
	 */
	private boolean processCycleRecord(String line) throws Exception {
		boolean success = false;
		
		String [] lineFields = line.split(fieldSeperator);
		
		/*
		 * Populate the instance variable for runDate.
		 */
		if (lineFields.length > 2) {
			runDate = lineFields[2].trim();
			success = true;
		}
		
		if (success) {
			sqlRunDate = new java.sql.Date(MMDDYY_FORMAT.parse(runDate).getTime());
			runDate = MMDDYYYY_FORMAT.format(MMDDYY_FORMAT.parse(runDate));
			
			String runDatequery = "SELECT PROC_DT FROM RABC_CYCLE_CALENDAR WHERE PROC_DT = to_date('" + runDate + "','MMddyyyy')";
			boolean isRunDateExists	= RetrieveStaticInfo.isProcDateExists(connection, runDatequery);
			
			if (!isRunDateExists) {
				throw new Exception("The cycle date " + runDate + " does not exist in RABC_CYCLE_CALENDAR table.");
			}
			
			String query =	"SELECT to_char(BILL_RND,'00') FROM RABC_CYCLE_CALENDAR WHERE PROC_DT = to_date('" + runDate + "','MMddyyyy')";
			billRnd	= RetrieveStaticInfo.getBillRnd(connection, query);
			if ("0".equals(billRnd) || "00".equals(billRnd) || "".equals(billRnd.trim())) {
				billRnd = "0";
			}
			
			if ("Y".equals(backoutRecovery)) {
				if (!PrepareTableForRerun.deleteTableData(connection, RABC_ICBS_INVOICE_READY, division, sqlRunDate)) {
					throw new Exception("Error occurred attempting to backup and recover for rerun for table: " + RABC_ICBS_INVOICE_READY);
				}
			}
		}

		return success;
	}
	
	/**
	 * Private method to process the deatil records.
	 * It does the following steps:
	 * 	1) Retrieves the fields from the line.
	 * 	2) Does conversion of data from String to appropriate data types as well as interpretation for amount.
	 * 	3) Creates the objects of ICBSData type.
	 * 	4) Populates the hash map with those objects.
	 * 
	 * @param line
	 * @return boolean
	 * @throws Exception
	 */
	private boolean processIB00(String line) throws Exception {
		boolean success = false;
		
		String [] lineFields = line.split(fieldSeperator);
		if (lineFields.length == 21) {
//			if (lineFields.length == 18) {			
				String rule		 		= lineFields[0].trim();
				String ruleNo			= lineFields[1].trim();
				String trnType			= lineFields[2].trim();
				String entityCode		= getEntityCode(lineFields[3].trim());
	/*			String rawInputCount	= lineFields[4].trim();
				String erredCount		= lineFields[5].trim();
				String rawInputAmount	= lineFields[6].trim();
				String erredAmount		= lineFields[7].trim();
				String returnedCount	= lineFields[8].trim();
				String returnedAmount	= lineFields[9].trim();
				String billingCount		= lineFields[10].trim();
				String billingAmount	= lineFields[11].trim();
				String crudeCount		= lineFields[12].trim();
				String crudeAmount		= lineFields[13].trim();
				String inputCount		= lineFields[14].trim();
				String processedCount	= lineFields[15].trim();
				String inputAmount		= lineFields[16].trim();
				String processedAmount	= lineFields[17].trim();
	*/
				String beginMsgCount	= lineFields[4].trim();
				String masterMsgCount	= lineFields[5].trim();
				String beginMsgAmount	= lineFields[6].trim();
				String masterMsgAmount	= lineFields[7].trim();
				String rawInputCount	= lineFields[8].trim();
				String erredCount		= lineFields[9].trim();
				String rawInputAmount	= lineFields[10].trim();
				String erredAmount		= lineFields[11].trim();
				String errDroppedCount	= lineFields[12].trim();
				String returnedCount	= lineFields[13].trim();
				String errDroppedAmount	= lineFields[14].trim();
				String returnedAmount	= lineFields[15].trim();
				String reEnteredCount	= lineFields[16].trim();
				String billingCount		= lineFields[17].trim();
				String reEnteredAmount	= lineFields[18].trim();
				String billingAmount	= lineFields[19].trim();
				String inputCount		= lineFields[20].trim();
				
				if (!"".equals(entityCode) && (("ADJUSTMENTS".equalsIgnoreCase(trnType) || "ADJUSTMENT".equalsIgnoreCase(trnType) || "TOLL REVENUE".equalsIgnoreCase(trnType)))) {
					/*
					 * Process the values obtained from the file. 
					 * In case of count convert to appropriate primitive using wrapper whereas in
					 * case of amounts strip off the dollar sign as well as check whether 
					 * the amount is +ve (debit) or -ve (credit)
					 */
					double beginMsgAmt;
					double masterMsgAmt;
					double dailyInputMsgAmt;
					double emsErrorMsgAmt;
					double emsInMsgAmt;
					double returnedMsgAmt;
					double reenterMsgAmt;
					double billedMsgAmt;
//					double crudeOutMsgAmt;
					
					// BEGINING MESSAGES
					long beginMessageCnt		= Long.parseLong(beginMsgCount);	
					beginMsgAmt = convertValue(beginMsgAmount);
/*					String tempBeginMsgAmt	= beginMsgAmount.substring(1,beginMsgAmount.length()).replaceAll(",","");
					if (tempBeginMsgAmt.indexOf("CR")==-1 && tempBeginMsgAmt.indexOf("cr")==-1){
						beginMsgAmt = Double.parseDouble(tempBeginMsgAmt);
					} else {
						beginMsgAmt = -(Double.parseDouble(tempBeginMsgAmt.substring(0,tempBeginMsgAmt.length()-2)));
					}
*/					
					// MASTER MESSAGES
					long masterMsgCnt		= Long.parseLong(masterMsgCount);	
					masterMsgAmt = convertValue(masterMsgAmount);

					// EMS IN REVENUE - count of erred/dropped Charges
					long emsInMsgCnt			= Long.parseLong(errDroppedCount);	
					emsInMsgAmt = convertValue(errDroppedAmount);

					// REENTERED REVENUE 
					long reenteredCnt			= Long.parseLong(reEnteredCount);	
					reenterMsgAmt = convertValue(reEnteredAmount);
					
					// DAILY INPUT MESSAGES
					long dailyInputMsgCnt		= Long.parseLong(rawInputCount);	
					dailyInputMsgAmt = convertValue(rawInputAmount);
					
					// EMS ERROR CHARGES
					long emsErrorMsgCnt			= Long.parseLong(erredCount);
					emsErrorMsgAmt = convertValue(erredAmount);
					
					// RETURNED MESSAGES
					long returnedMsgCnt			= Long.parseLong(returnedCount);
					returnedMsgAmt = convertValue(returnedAmount);
					
					// BILLED MESSAGES
					long billedMsgCnt			= Long.parseLong(billingCount);
					billedMsgAmt = convertValue(billingAmount);
					
					// INPUT MESSAGES
					long inputMsgCnt			= Long.parseLong(inputCount);
										
					// CRUDE OUT MESSAGES
	/*				long crudeOutMsgCnt			= Long.parseLong(crudeCount);
					String tempCrudeOutMsgAmt	= crudeAmount.substring(1,crudeAmount.length()).replaceAll(",","");
					if (tempCrudeOutMsgAmt.indexOf("CR")==-1 && tempCrudeOutMsgAmt.indexOf("cr")==-1){
						crudeOutMsgAmt = Double.parseDouble(tempCrudeOutMsgAmt);
					} else {
						crudeOutMsgAmt = -(Double.parseDouble(tempCrudeOutMsgAmt.substring(0,tempCrudeOutMsgAmt.length()-2)));
					}
	*/				
					if (inputMsgCnt != 0) {
						success = true;					
						/*
						 * Create an object of ICBSData type
						 */
						ICBSData icbsData	= new ICBSData();
						icbsData.setRunDate(MMDDYYYY_FORMAT.parse(runDate));
						icbsData.setDivision(division);
						icbsData.setEntityCd(entityCode);
						if ("ADJUSTMENTS".equalsIgnoreCase(trnType) || "ADJUSTMENT".equalsIgnoreCase(trnType)) {
							icbsData.setTrnType("ADJ");
						} else if ("TOLL REVENUE".equalsIgnoreCase(trnType)) {
							icbsData.setTrnType("TOLL");
						}  /*else if ("COMBINED".equalsIgnoreCase(trnType)) {
							icbsData.setTrnType("COMB");
						}*/
						
						/*
						 * Check whether the above object is present in the hash map
						 */
						ICBSData objRef = null;
						objRef = (ICBSData)icbsDataMap.get(icbsData);
						
						if (objRef != null){
							dailyInputMsgCnt += objRef.getDailyInputMsgCt();
							dailyInputMsgAmt += objRef.getDailyInputMsgAmt();
							emsErrorMsgCnt	 += objRef.getEmsErrMsgCt();
							emsErrorMsgAmt	 += objRef.getEmsErrMsgAmt();
							returnedMsgCnt	 += objRef.getRtnMsgCt();
							returnedMsgAmt	 += objRef.getRtnMsgAmt();
							billedMsgCnt	 += objRef.getBlgMsgCt();
							billedMsgAmt	 += objRef.getBlgMsgAmt();
//							crudeOutMsgCnt	 += objRef.getCrudeOutMsgCt();
//							crudeOutMsgAmt	 += objRef.getCrudeOutMsgAmt();
							beginMessageCnt	 += objRef.getBegMsgCt();
							beginMsgAmt		 += objRef.getBegMsgAmt();
							masterMsgCnt	 += objRef.getMasMsgCt();
							masterMsgAmt	 += objRef.getMasMsgAmt();
							emsInMsgCnt		 += objRef.getEmsMsgCt();
							emsInMsgAmt 	 += objRef.getEmsMsgAmt();
							reenteredCnt	 += objRef.getReentMsgCt();
							reenterMsgAmt 	 += objRef.getReentMsgAmt();						
							
							objRef.setDailyInputMsgCt(dailyInputMsgCnt);
							objRef.setDailyInputMsgAmt(dailyInputMsgAmt);
							objRef.setEmsErrMsgCt(emsErrorMsgCnt);
							objRef.setEmsErrMsgAmt(emsErrorMsgAmt);
							objRef.setRtnMsgCt(returnedMsgCnt);
							objRef.setRtnMsgAmt(returnedMsgAmt);
							objRef.setBlgMsgCt(billedMsgCnt);
							objRef.setBlgMsgAmt(billedMsgAmt);
//							objRef.setCrudeOutMsgCt(crudeOutMsgCnt);
//							objRef.setCrudeOutMsgAmt(crudeOutMsgAmt);
							objRef.setBegMsgCt(beginMessageCnt);
							objRef.setBegMsgAmt(beginMsgAmt);
							objRef.setMasMsgCt(masterMsgCnt);
							objRef.setMasMsgAmt(masterMsgAmt);
							objRef.setEmsMsgCt(emsInMsgCnt);
							objRef.setEmsMsgAmt(emsInMsgAmt);
							objRef.setReentMsgCt(reenteredCnt);
							objRef.setReentMsgAmt(reenterMsgAmt);
							
							icbsDataMap.put(objRef,objRef);
						} else {
							icbsData.setDailyInputMsgCt(dailyInputMsgCnt);
							icbsData.setDailyInputMsgAmt(dailyInputMsgAmt);
							icbsData.setEmsErrMsgCt(emsErrorMsgCnt);
							icbsData.setEmsErrMsgAmt(emsErrorMsgAmt);
							icbsData.setRtnMsgCt(returnedMsgCnt);
							icbsData.setRtnMsgAmt(returnedMsgAmt);
							icbsData.setBlgMsgCt(billedMsgCnt);
							icbsData.setBlgMsgAmt(billedMsgAmt);
//							icbsData.setCrudeOutMsgCt(crudeOutMsgCnt);
//							icbsData.setCrudeOutMsgAmt(crudeOutMsgAmt);
							icbsData.setBegMsgCt(beginMessageCnt);
							icbsData.setBegMsgAmt(beginMsgAmt);
							icbsData.setMasMsgCt(masterMsgCnt);
							icbsData.setMasMsgAmt(masterMsgAmt);
							icbsData.setEmsMsgCt(emsInMsgCnt);
							icbsData.setEmsMsgAmt(emsInMsgAmt);
							icbsData.setReentMsgCt(reenteredCnt);
							icbsData.setReentMsgAmt(reenterMsgAmt);						
							icbsDataMap.put(icbsData,icbsData);
						}
					}
				}
		} else if (lineFields.length == 8) {
//		if (lineFields.length == 18) {			
			String rule		 		= lineFields[0].trim();
			String ruleNo			= lineFields[1].trim();
			String trnType			= lineFields[2].trim();
			String entityCode		= getEntityCode(lineFields[3].trim());
			String inputCount		= lineFields[4].trim();
			String processedCount	= lineFields[5].trim();
			String inputAmount		= lineFields[6].trim();
			String processedAmount	= lineFields[7].trim();
			
			if (!"".equals(entityCode) && (("ADJUSTMENTS".equalsIgnoreCase(trnType) || "ADJUSTMENT".equalsIgnoreCase(trnType) || "TOLL REVENUE".equalsIgnoreCase(trnType)))) {
				/*
				 * Process the values obtained from the file. 
				 * In case of count convert to appropriate primitive using wrapper whereas in
				 * case of amounts strip off the dollar sign as well as check whether 
				 * the amount is +ve (debit) or -ve (credit)
				 */
				double inputMsgAmt;
				double processedMsgAmt;
				
				// INPUT MESSAGES
				long inputMsgCnt			= Long.parseLong(inputCount);
				inputMsgAmt = convertValue(inputAmount);
/*				String tempInputMsgAmt	= inputAmount.substring(1,inputAmount.length()).replaceAll(",","");
				if (tempInputMsgAmt.indexOf("CR")==-1 && tempInputMsgAmt.indexOf("cr")==-1){
					inputMsgAmt = Double.parseDouble(tempInputMsgAmt);
				} else {
					inputMsgAmt = -(Double.parseDouble(tempInputMsgAmt.substring(0,tempInputMsgAmt.length()-2)));
				}
*/				
				// PROCESSED MESSAGES
				long processedMsgCnt		= Long.parseLong(processedCount);
				processedMsgAmt = convertValue(processedAmount);
				
				ICBSData icbsData	= new ICBSData();
				icbsData.setRunDate(MMDDYYYY_FORMAT.parse(runDate));
				icbsData.setDivision(division);
				icbsData.setEntityCd(entityCode);
				if ("ADJUSTMENTS".equalsIgnoreCase(trnType) || "ADJUSTMENT".equalsIgnoreCase(trnType)) {
					icbsData.setTrnType("ADJ");
				} else if ("TOLL REVENUE".equalsIgnoreCase(trnType)) {
					icbsData.setTrnType("TOLL");
				}  /*else if ("COMBINED".equalsIgnoreCase(trnType)) {
					icbsData.setTrnType("COMB");
				}*/
				
				/*
				 * Check whether the above object is present in the hash map
				 */
				ICBSData objRef = null;
				objRef = (ICBSData)icbsDataMap.get(icbsData);
				if (inputMsgCnt != 0) {
					success = true;
					/*
					 * Create an object of ICBSData type
					 */
					if (objRef != null){
						inputMsgCnt		 += objRef.getTotalInputMsgCt();
						inputMsgAmt		 += objRef.getTotalInputMsgAmt();
						processedMsgCnt	 += objRef.getTotalPostedMsgCt();
						processedMsgAmt	 += objRef.getTotalPostedMsgAmt();

						objRef.setTotalInputMsgCt(inputMsgCnt);
						objRef.setTotalInputMsgAmt(inputMsgAmt);
						objRef.setTotalPostedMsgCt(processedMsgCnt);
						objRef.setTotalPostedMsgAmt(processedMsgAmt);
						
						icbsDataMap.put(objRef,objRef);
					} 
				} 
			}
		}
		
		return success;
	}
	
	/**
	 * Private method to return the entity code  to be inserted into the table.
	 * 
	 * @param entityCd
	 * @return String
	 */
	private String getEntityCode(String entityCd) {
		String entityCode = entityCd;
		
		if (entityCd.length() > 5) {
			entityCode = entityCd.substring(3, entityCd.length()-3);
			if (entityCode.length() > 8) {
				entityCode = entityCode.substring(0, 8);
			}
		}
		
		return entityCode;
	}
	
	/**
	 * Overriding postProcessFile(file, success) method.
	 * It is executed post to processing the file to be loaded.
	 * It includes the following steps:
	 * 	1) It checks whether the header and trailer records exists and 
	 * 	   whether the total number of records (excluding header and trailer records)
	 * 	   in the file is eqaul to the count in the trailer record.
	 * 	   If it is then prcoceeds to next step else return false.
	 * 	2) Loop through the map icbsDataMap and insert entries into RABC_ICBS_INVOICE_READY table.
	 * 	3) Makes the entries into RABC_TRIG table.
	 * 
	 * @see com.sbc.bac.load.FileDBLoadJob#postprocessFile(java.io.File, boolean)
	 */
	public boolean postprocessFile(File file, boolean success) {
		try{
			//Log the file information to EMCIS_EVENT_LOG and EMCIS_EVENT_LOG_DETAIL
			EmcisEventLogger emcisLogger = new EmcisEventLogger();
			String event_id = "RABC_"+fileToken+"_WE";
            String host = NetUtil.getLocalHostName();
            String hostIP = NetUtil.getLocalIpAddress();
			int sequence = emcisLogger.getEMCISSequence(connection);
			emcisLogger.insertEventLog(connection, sequence, event_id, sqlRunDate, host, hostIP);
			emcisLogger.insertEventLogDetail(connection, sequence, "FileName", fileName);

		}catch (UnknownHostException e) {
            severe("Error getting EMCIS host information ", e);
        }
		if (success) {
			 if (!isTrailerExists) {
				severe("Trailer record is not present in the file.");
				success = false;
			} else if (!isRecordCountMatches) {
				severe("Total number of records in the file is not eqaul to the count in the trailer record.");
				success = false;
			} else {
				try {
					/*
					 * Iterate through the entire hash map and insert entries into the RABC_ICBS_INVOICE_READY table
					 */
					Iterator icbsDataIterator = icbsDataMap.keySet().iterator();
					
					while (icbsDataIterator.hasNext()){
						batchCounter++;
						
						ICBSData icbsData = (ICBSData)icbsDataIterator.next();
						insert_IB00.setDate(1,sqlRunDate);
						insert_IB00.setString(2,division);	
						insert_IB00.setString(3,icbsData.getEntityCd());
						insert_IB00.setString(4,icbsData.getTrnType());
						insert_IB00.setLong(5,icbsData.getDailyInputMsgCt());
						insert_IB00.setDouble(6,icbsData.getDailyInputMsgAmt());
						insert_IB00.setLong(7,icbsData.getEmsErrMsgCt());
						insert_IB00.setDouble(8,icbsData.getEmsErrMsgAmt());
						insert_IB00.setLong(9,icbsData.getRtnMsgCt());
						insert_IB00.setDouble(10,icbsData.getRtnMsgAmt());
						insert_IB00.setLong(11,icbsData.getBlgMsgCt());
						insert_IB00.setDouble(12,icbsData.getBlgMsgAmt());
//						insert_IB00.setLong(13,icbsData.getCrudeOutMsgCt());
//						insert_IB00.setDouble(14,icbsData.getCrudeOutMsgAmt());
//						insert_IB00.setLong(15,icbsData.getTotalInputMsgCt());
//						insert_IB00.setDouble(17,icbsData.getTotalInputMsgAmt());
//						insert_IB00.setLong(16,icbsData.getTotalPostedMsgCt());
//						insert_IB00.setDouble(18,icbsData.getTotalPostedMsgAmt());
//						insert_IB00.setInt(19,Integer.parseInt(billRnd));
						insert_IB00.setLong(13,icbsData.getTotalInputMsgCt());
						insert_IB00.setLong(14,icbsData.getTotalPostedMsgCt());						
						insert_IB00.setDouble(15,icbsData.getTotalInputMsgAmt());
						insert_IB00.setDouble(16,icbsData.getTotalPostedMsgAmt());
						insert_IB00.setInt(17,Integer.parseInt(billRnd));
						
						insert_IB00.setLong(18,icbsData.getMasMsgCt());
						insert_IB00.setDouble(19,icbsData.getMasMsgAmt());
						insert_IB00.setLong(20,icbsData.getReentMsgCt());
						insert_IB00.setDouble(21,icbsData.getReentMsgAmt());						
						insert_IB00.setLong(22,icbsData.getBegMsgCt());
						insert_IB00.setDouble(23,icbsData.getBegMsgAmt());
						insert_IB00.setLong(24,icbsData.getEmsMsgCt());
						insert_IB00.setDouble(25,icbsData.getEmsMsgAmt());
						insert_IB00.addBatch();
						
						if (batchCounter % 1000 == 0){
							insert_IB00.executeBatch();
						}
						isInvoiceReady = true;
					}
					
					/*
					 * Execute the last batch
					 */
					insert_IB00.executeBatch();
					
					/*
					 * Call the private method to make the entries into RABC_TRIG table
					 */
					if (!insertTrigger()) {
						success = false;
					}	
				} catch (SQLException sqle){
					severe(StaticErrorMsgKeys.INSERT_ERROR + sqle.getMessage(), sqle);
					success = false;
				}
			}
		}
		
		return super.postprocessFile(file, success);
	}
	
	/**
	 * Private method to insert entry into RABC_TRIG table.
	 * 
	 * @return boolean
	 */
	private boolean insertTrigger() {
		/*
		 * Check whether there were any invoice ready record inserted, if yes then insert into trigger
		 */
		if (isInvoiceReady) {
			if(!RabcLoadJobTrig.insertTrigger(connection, currentFile.getName().substring(4,currentFile.getName().length()), currentFile.getName(), FILE_ID, division, runDate , backoutRecovery, billRnd, RABC_TRIG)) {
				return false;	
			}
		}
		
		return true;
	}

	/**
	 * Overriding postProcess(success) method.
	 * It is executed post to processing the load job.
	 * It includes the following steps:
	 * 	1) Closes statements that were opened for this load job.
	 * 
	 * @see com.sbc.bac.load.LoadJob#postprocess(boolean)
	 */
	public boolean postprocess(boolean success) {
		try {
			insert_IB00.close();
		} catch (SQLException e) {
			severe(StaticErrorMsgKeys.POSTPROCESS_ERROR + StaticErrorMsgKeys.SQL_CLOSE_ERROR + e.getMessage(), e);
			success = false;
		}

		return super.postprocess(success);
	}
	
	/**
	 * Method returns the division
	 * @param division
	 * @return
	 */
	private String getDivision(String division){
		if ("F".equals(division)){
			return "PN";
		}else if ("S".equals(division)){
			return "PS";
		}else {
			return "PN";
		}
	}
	
	public double convertValue(String input){
		String tempInput = input.substring(1,input.length()).replaceAll(",","");
		
		if (tempInput.indexOf("CR")==-1 && tempInput.indexOf("cr")==-1){
			return Double.parseDouble(tempInput);
		} else {
			return -(Double.parseDouble(tempInput.substring(0,tempInput.length()-2)));
		}
	}	
}
