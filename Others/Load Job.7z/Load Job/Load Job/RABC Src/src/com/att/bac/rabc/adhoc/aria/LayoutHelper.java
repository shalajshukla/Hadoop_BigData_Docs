package com.att.bac.rabc.adhoc.aria;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.naming.NamingException;

import org.apache.log4j.Logger;

import com.att.bac.rabc.DataTblDdlBean;
import com.att.bac.rabc.DateUtil;
import com.att.bac.rabc.PickList;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.StaticDataLoader;
import com.att.bac.rabc.adhoc.AdhocConstants;
import com.att.bac.rabc.adhoc.aria.pivot.AdhocPivotData;
import com.att.bac.rabc.adhoc.aria.pivot.DatedCompositeKey;
import com.att.bac.rabc.adhoc.aria.pivot.PreviousDataLookup;
import com.att.bac.rabc.adhoc.rpt.AdhocRptDAO;
import com.att.bac.rabc.adhoc.rpt.AdhocRptDataTO;
import com.att.bac.rabc.adhoc.rpt.AdhocRptUtil;
import com.att.bac.rabc.adhoc.rpt.PreviousDataGeneratorMediator;
import com.att.bac.rabc.adhoc.rpt.generator.Calculation;
import com.att.carat.util.JDBCUtil;
import com.sbc.bac.aria.ARIAPaging;
import com.sbc.bac.aria.ARIAReportException;
import com.sbc.bac.aria.ARIAReportProcessor;
import com.sbc.bac.aria.ARIAUtil;
import com.sbc.bac.aria.RowElement;

public class LayoutHelper{
    private static final String LINK_TO_PGM_FOR_FSN = "AlertsReportFileNames.do";
    private static final String MOUSEOVER_FOR_FSN = "File Sequence Number";
    private static final String GRAPH_LINK_ACTION = "Graph.do";
    public static final int MAX_ROWS = 65536;
    private static final SimpleDateFormat MMDDYYYY_FORMAT	= new SimpleDateFormat("MM/dd/yyyy");
    private static final SimpleDateFormat YYYYMMDD_FORMAT	= new SimpleDateFormat("yyyyMMdd");
    
    /**
     * 
     * @param dto
     * @param url
     * @param columnName
     * @param tableIndex
     * @param value
     * @param dtoBase
     * @param connection
     * @param logger
     * @return
     * @throws ParseException
     * @throws RABCException
     */
	public static String buildUrl(AdhocRptDataTO dto, String url, String columnName, int tableIndex, String value,AdhocRptDataTO dtoBase, Connection connection, Logger logger) throws ParseException, RABCException {
		StringBuffer buf = new StringBuffer(100);
        String pgmName = "";
        String linkTitle = "";
        boolean popup = false;

        if (columnName.equalsIgnoreCase("file_seq_num")) {
            pgmName = LINK_TO_PGM_FOR_FSN;
            linkTitle = MOUSEOVER_FOR_FSN;
            popup = true;
        }

        if (tableIndex >= 0) {
            if (dto.getAdhocTest().equalsIgnoreCase("N") && dto.getDataLinkIndList().get(tableIndex).toString().equalsIgnoreCase("Y")) {
                pgmName = (String) dto.getDataLinkToPgmList().get(tableIndex);
                if (!dto.getDataMouseOverNumList().get(tableIndex).toString().equals("") && Integer.parseInt(dto.getDataMouseOverNumList().get(tableIndex).toString()) > 0 && !dto.getDataDescIndList().get(tableIndex).toString().equalsIgnoreCase("")) {
                   linkTitle = getMouseOverDescription(tableIndex, value, value, dto, dtoBase, connection, logger);
                }
            }
        }

        if (!popup) {
            buf.append("<a href=\"");
        } else {
            buf.append("<a href=\"javascript:graphpopup('alertGraph','");
        }
        
        buf.append(pgmName);
        buf.append("?");
        buf.append(url);
        buf.append("\" class=\"dataLink\"");
        buf.append(" title=\"");
        buf.append(linkTitle);
        buf.append("\">\n");

        return buf.toString();
	}
	
	/**
	 * 
	 * @param dto
	 * @param columnName
	 * @param rowMap
	 * @param tableIndex
	 * @return
	 * @throws ParseException
	 * @throws UnsupportedEncodingException
	 */
	public static String getBaseUrl(AdhocRptDataTO dto,String columnName, List<RowElement> rowMap, int tableIndex) throws ParseException, UnsupportedEncodingException {
//		String displayDate = formatDateForDisplay(rowMap.get("File Date").toString(),dto);
	    String displayDate = formatDateForDisplay((ARIAUtil.findColumn(rowMap, "File Date")==null?"":ARIAUtil.findColumn(rowMap, "File Date").getValue().toString()),dto);
//        String fileSeqNum = (String) rowMap.get("file_seq_num");
        String fileSeqNum =(ARIAUtil.findColumn(rowMap, "file_seq_num")==null?"":(String)ARIAUtil.findColumn(rowMap, "file_seq_num").getValue());

        StringBuffer url = new StringBuffer(100);
        url.append("PresnId=");
        url.append(dto.getPresnId());

        url.append("&presnIdAsString=");
        url.append(dto.getPresnIdAsString());

        if (displayDate.length() == 8) {
            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
            displayDate = sdf.format(DateUtil.parseDate(displayDate, "yyyyMMdd"));
        }else if (displayDate.length() == 4) { // Yearly report 
        	displayDate = "01/01/" + displayDate ;
        }

        url.append("&ProcDate=");
        url.append(displayDate);

        url.append("&procDate=");
        url.append(displayDate);

        url.append("&clickLvl=");
        url.append(dto.getClickLvl());

        url.append("&divisionName=");
        url.append(dto.getDivisionName());

        // Kin - 3/21/07
        // When I click on the link on first report. I expect the program pass the date in the row over to the next
        // report. program should not pass the current report date range over to next report otherwise will be too many
        // rows return.
        url.append("&genEndDate=");
        // url.append(dto.getEndDate());
        url.append(displayDate);

        // Kin - 3/21/07
        // When I click on the link on first report. I expect the program pass the date in the row over to the next
        // report. program should not pass the current report date range over to next report otherwise will be too many
        // rows return.
        url.append("&endDate=");
        // url.append(dto.getEndDate());
        url.append(displayDate);

        url.append("&showSideMenu=\\'document.all.showSideMenu.value;\\'");

        if (dto.getFileSeqNumInd().equalsIgnoreCase("Y")) {
            url.append("&fileSeqNum=");
                        
            if (!fileSeqNum.equalsIgnoreCase("no data")) {
                url.append(fileSeqNum);
            }
        }

        int graphAlertTimeValue = -1;
        String cname = columnName.toUpperCase();
        if (cname.indexOf("BILL_RND") != -1 || cname.indexOf("ALERT_TREND_TIME") != -1 || cname.indexOf("STATIC_CYCLE_CODE") != -1) {
//            graphAlertTimeValue = ((BigDecimal) rowMap.get(columnName)).intValue();
            graphAlertTimeValue =  ((BigDecimal)ARIAUtil.findColumn(rowMap, columnName).getValue()).intValue();
            
        }

        url = appendAlertTimeToGraphURL(dto, rowMap, displayDate, graphAlertTimeValue, url);

        List keyValueList = new ArrayList();
        for (int i = 0; i < dto.getKeysRow1ColumnsList().size(); i++) {
//            keyValueList.add(rowMap.get(dto.getColumnsHeadersList().get(i)));
            keyValueList.add(ARIAUtil.findColumn(rowMap, (String) dto.getColumnsHeadersList().get(i)).getValue());
        }

        String prevPresnId = dto.getPresnIdAsString();
        for (int i = 0; i < dto.getColumnsHeadersList().size(); i++) {
            int keyPosition = AdhocRptUtil.listContainsNoCase(dto.getRow1Columns(), dto.getColumnsToExtractList().get(i).toString(), ',');
            if (keyPosition != -1) {
                int keySuffix = keyPosition + 1;
                url.append("&key");
                url.append(keySuffix);
                url.append("=");
                url.append(keyValueList.get(keyPosition));
            }
        }
        if (tableIndex >= 0) {
            if (!dto.getDataLinkPresnIdList().get(tableIndex).toString().equals("")) {
                String tempString = "PresnId=" + prevPresnId + "&presnIdAsString=" + prevPresnId;
                String nextString = "PresnId=" + dto.getDataLinkPresnIdList().get(tableIndex) + "&presnIdAsString=" + dto.getDataLinkPresnIdList().get(tableIndex);
                String changedUrl = url.toString().replaceFirst(tempString, nextString);
                url.setLength(0);
                url.append(changedUrl);
                prevPresnId = dto.getDataLinkPresnIdList().get(tableIndex).toString();
            }
        }

        url.append("&divNameKeyLvl=");
        url.append(dto.getDivNameKeyLvl());

        return url.toString();
	}
	
	/**
	 * 
	 * @param dto
	 * @param columnName
	 * @param tableIndex
	 * @param procDate
	 * @param adhocPivotData
	 * @return
	 * @throws ParseException
	 * @throws UnsupportedEncodingException
	 */
	public static String getBaseUrl(AdhocRptDataTO dto,String columnName,int tableIndex,String procDate, AdhocPivotData adhocPivotData) throws ParseException, UnsupportedEncodingException {
		Calendar lCal = Calendar.getInstance();
        lCal.add(Calendar.DATE, -1);
        String month = null;
        String day = null;
        String year = null;
        String displayDate = null;
        
        StringBuffer url = new StringBuffer(100);
        url.append("PresnId=");
        url.append(dto.getPresnId());

        url.append("&presnIdAsString=");
        url.append(dto.getPresnIdAsString());

        /*
         * If procDate parameter is null which is what we will do for keys
         */
        if (procDate == null){
        	if (lCal.get(Calendar.MONTH) < 9){
    	    	month = "0" + Integer.toString(lCal.get(Calendar.MONTH)+1);
    	    }else{
    	    	month = Integer.toString(lCal.get(Calendar.MONTH)+1);
    	    } 
            
            if (lCal.get(Calendar.DATE) < 10){
    	    	day = "0" + Integer.toString(lCal.get(Calendar.DATE));
    	    }else{
    	    	day = Integer.toString(lCal.get(Calendar.DATE));
    	    }
            year = Integer.toString(lCal.get(Calendar.YEAR));
      		
            displayDate = month + "/" + day +"/" + year;
            
            if (displayDate.length() == 8) {
                SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
                displayDate = sdf.format(DateUtil.parseDate(displayDate, "yyyyMMdd"));
            }else if (displayDate.length() == 4) { // Yearly report 
            	displayDate = "01/01/" + displayDate ;
            }
            
            url.append("&genStartDate=");
            url.append(dto.getStartDate());

            url.append("&startDate=");
            url.append(dto.getStartDate());
            
            url.append("&genEndDate=");
            url.append(dto.getEndDate());

            url.append("&endDate=");
            url.append(dto.getEndDate());
        } else {
        	 displayDate = procDate;
             
             if (displayDate.length() == 8) {
                 SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
                 displayDate = sdf.format(DateUtil.parseDate(displayDate, "yyyyMMdd"));
             }else if (displayDate.length() == 4) { // Yearly report 
             	displayDate = "01/01/" + displayDate ;
             }
             
             url.append("&genEndDate=");
             url.append(displayDate);
             
             url.append("&endDate=");
             url.append(displayDate);
        }

        // TODO Check with Kin on what we need to do for file_seq_num parameter
        /*if (dto.getFileSeqNumInd().equalsIgnoreCase("Y")) {
            url.append("&fileSeqNum=");
            if (!fileSeqNum.equalsIgnoreCase("no data")) {
                url.append(fileSeqNum);
            }
        }*/

        url.append("&ProcDate=");
        url.append(displayDate);

        url.append("&procDate=");
        url.append(displayDate);

        url.append("&clickLvl=");
        url.append(dto.getClickLvl());

        url.append("&divisionName=");
        url.append(dto.getDivisionName());

        url.append("&divNameKeyLvl=");
        url.append(dto.getDivNameKeyLvl());
        
        url.append("&showSideMenu=\\'document.all.showSideMenu.value;\\'");
       
        // Compare this logic with that used otherwise
        int graphAlertTimeValue = -1;
        url = appendAlertTimeToGraphURL(dto, displayDate, graphAlertTimeValue, url);

        List keyValueList = new ArrayList();
        int [] keyIndexes = adhocPivotData.getKeyColumnIndexes();
        for (int i = 0; i < dto.getKeysRow1ColumnsList().size(); i++) {
            for (int k=0;k<keyIndexes.length;k++){
            	if (i==keyIndexes[k]){
            		keyValueList.add(adhocPivotData.getKeyColumnValues()[k]);
            		break;
            	}
            }
        }

        String prevPresnId = dto.getPresnIdAsString();
        for (int i = 0; i < dto.getColumnsHeadersList().size(); i++) {
            int keyPosition = AdhocRptUtil.listContainsNoCase(dto.getRow1Columns(), dto.getColumnsToExtractList().get(i).toString(), ',');
            if (keyPosition != -1) {
                int keySuffix = keyPosition + 1;
                url.append("&key");
                url.append(keySuffix);
                url.append("=");
                url.append(keyValueList.get(keyPosition));
            }
        }
        if (tableIndex >= 0) {
            if (!dto.getDataLinkPresnIdList().get(tableIndex).toString().equals("")) {
                String tempString = "PresnId=" + prevPresnId + "&presnIdAsString=" + prevPresnId;
                String nextString = "PresnId=" + dto.getDataLinkPresnIdList().get(tableIndex) + "&presnIdAsString=" + dto.getDataLinkPresnIdList().get(tableIndex);
                String changedUrl = url.toString().replaceFirst(tempString, nextString);
                url.setLength(0);
                url.append(changedUrl);
                prevPresnId = dto.getDataLinkPresnIdList().get(tableIndex).toString();
            }
        }

        return url.toString();
	}
	
	/**
	 * 
	 * @param dto
	 * @param columnName
	 * @param url
	 * @param logger
	 * @param connection
	 * @param dtoBase
	 * @param adhocPivotData
	 * @return
	 * @throws SQLException
	 */
	public static String recreateKeyLinks(AdhocRptDataTO dto, String columnName, String url,Logger logger, Connection connection, AdhocRptDataTO dtoBase, AdhocPivotData adhocPivotData) throws SQLException {
		String tempParms = "";
        try {
            String k1Type = (String) dto.getKeysRow1ColumnsList().get(0);
            String k2Type = (dto.getKeysRow1ColumnsList().size() >= 2) ? (String) dto.getKeysRow1ColumnsList().get(1) : "";
            String k3Type = (dto.getKeysRow1ColumnsList().size() >= 3) ? (String) dto.getKeysRow1ColumnsList().get(2) : "";

            if (url != null) {

                StringTokenizer z = new StringTokenizer(url, "&");
                int targetID = 0;
                String k1Value = "";
                String k2Value = "";
                String k3Value = "";
                while (z.hasMoreTokens()) {
                    String parm = z.nextToken();

                    if (parm.indexOf("PresnId") >= 0) {
                        targetID = Integer.parseInt(parm.substring(parm.indexOf('=') + 1));
                    }

                    if (parm.indexOf("key1=") >= 0) {                        
                    	k1Value = parm.substring(parm.indexOf('=') + 1).trim();
                    }

                    if (parm.indexOf("key2=") >= 0) {
                        k2Value = parm.substring(parm.indexOf('=') + 1);
                    }

                    if (parm.indexOf("key3=") >= 0) {
                        k3Value = parm.substring(parm.indexOf('=') + 1);
                    }

                }
                if (targetID > 0) {
                    AdhocRptDAO dao = new AdhocRptDAO();
                    List targetHeaders = dao.getTargetKeyHeaders(connection, targetID);
                    String toK1Type = (String) targetHeaders.get(0);
                    String toK2Type = (String) targetHeaders.get(1);
                    String toK3Type = (String) targetHeaders.get(2);

                    if (toK1Type == null) {
                        toK1Type = "";
                    }
                    if (toK2Type == null) {
                        toK2Type = "";
                    }
                    if (toK3Type == null) {
                        toK3Type = "";
                    }

                    boolean k1TypeEqualToK1Type = k1Type.equalsIgnoreCase(toK1Type);
                    boolean k2TypeEqualToK2Type = k2Type.equalsIgnoreCase(toK2Type);
                    boolean k3TypeEqualToK3Type = k3Type.equalsIgnoreCase(toK3Type);

                    boolean toK2TypeEqualK1Type = toK2Type.equalsIgnoreCase(k1Type);
                    boolean toK3TypeEqualK1Type = toK3Type.equalsIgnoreCase(k1Type);
                    boolean toK3TypeEqualK2Type = toK3Type.equalsIgnoreCase(k2Type);

                    boolean toK1TypeEqualColName = toK1Type.equalsIgnoreCase(columnName);
                    boolean toK2TypeEqualColName = toK2Type.equalsIgnoreCase(columnName);
                    boolean toK3TypeEqualColName = toK3Type.equalsIgnoreCase(columnName);

                    String value = "";
                    String [] keyNames = adhocPivotData.getKeyColumnNames();
                    for (int k=0;k<keyNames.length;k++){
                    	if (keyNames[k].equals(columnName)){
                    		value = adhocPivotData.getKeyColumnValues()[k];
                    		break;
                    	}
                    }

                    if (k1TypeEqualToK1Type) {
                        // pass key1 value
                        if (k2TypeEqualToK2Type) {
                            // pass key2 value
                            if (k3TypeEqualToK3Type) {
                                // pass key3 value
                            }
                        } else {
                            if (toK2TypeEqualColName) {
                                // pass the link column key2_value
                                k2Value = value;
                            } else if (toK3TypeEqualColName) {
                                k3Value = value;
                            } else {
                                k2Value = "";
                                k3Value = "";
                            }
                        }
                    } else {
                        if (toK2TypeEqualK1Type) {
                            // pass the link column value as key1_value, no value for key2
                            k1Value = value;
                            k2Value = "";
                        } else if (toK3TypeEqualK1Type) {
                            // pass the link column value as key1_value, no value for key2
                            k1Value = value;
                            k2Value = "";
                            k3Value = "";
                        } else if (toK3TypeEqualK2Type) {
                            k2Value = value;
                            k3Value = "";
                        } else if (toK1TypeEqualColName) {
                            k1Value = value;
                            k2Value = "";
                        } else {
                            // no key1 or key2 value pass over.
                            k1Value = "";
                            k2Value = "";
                        }
                    }
                }

                // Remake the link
                z = new StringTokenizer(url, "&");
                while (z.hasMoreTokens()) {
                    String parm = z.nextToken();
                    if (parm.indexOf("key1=") >= 0) {
                    	parm = "key1=" + k1Value.trim();
                    }
                    if (parm.indexOf("key2=") >= 0) {
                        parm = "key2=" + k2Value;
                    }
                    if (parm.indexOf("key3=") >= 0) {
                        parm = "key3=" + k3Value;
                    }
                    tempParms += parm;
                    if (z.hasMoreTokens()) {
                        tempParms += "&";
                    }
                }
            }
        } catch (Exception e) {
            logger.error("recreateKeyLinks", e);
        }
        return tempParms;
	}
	
	/**
	 * 
	 * @param dto
	 * @param columnName
	 * @param rowMap
	 * @param url
	 * @param logger
	 * @param connection
	 * @param dtoBase
	 * @return
	 * @throws SQLException
	 */
	public static String recreateKeyLinks(AdhocRptDataTO dto, String columnName, List<RowElement> rowMap, String url,Logger logger, Connection connection, AdhocRptDataTO dtoBase) throws SQLException {
		String tempParms = "";
        try {
            String k1Type = (String) dto.getKeysRow1ColumnsList().get(0);
            String k2Type = (dto.getKeysRow1ColumnsList().size() >= 2) ? (String) dto.getKeysRow1ColumnsList().get(1) : "";
            String k3Type = (dto.getKeysRow1ColumnsList().size() >= 3) ? (String) dto.getKeysRow1ColumnsList().get(2) : "";

            if (url != null) {

                StringTokenizer z = new StringTokenizer(url, "&");
                int targetID = 0;
                String k1Value = "";
                String k2Value = "";
                String k3Value = "";
                while (z.hasMoreTokens()) {
                    String parm = z.nextToken();

                    if (parm.indexOf("PresnId") >= 0) {
                        targetID = Integer.parseInt(parm.substring(parm.indexOf('=') + 1));
                    }

                    if (parm.indexOf("key1=") >= 0) {
                    	k1Value = parm.substring(parm.indexOf('=') + 1).trim();
                    }

                    if (parm.indexOf("key2=") >= 0) {
                        k2Value = parm.substring(parm.indexOf('=') + 1);
                    }

                    if (parm.indexOf("key3=") >= 0) {
                        k3Value = parm.substring(parm.indexOf('=') + 1);
                    }

                }
                if (targetID > 0) {
                    AdhocRptDAO dao = new AdhocRptDAO();
                    List targetHeaders = dao.getTargetKeyHeaders(connection, targetID);
                    String toK1Type = (String) targetHeaders.get(0);
                    String toK2Type = (String) targetHeaders.get(1);
                    String toK3Type = (String) targetHeaders.get(2);

                    if (toK1Type == null) {
                        toK1Type = "";
                    }
                    if (toK2Type == null) {
                        toK2Type = "";
                    }
                    if (toK3Type == null) {
                        toK3Type = "";
                    }

                    boolean k1TypeEqualToK1Type = k1Type.equalsIgnoreCase(toK1Type);
                    boolean k2TypeEqualToK2Type = k2Type.equalsIgnoreCase(toK2Type);
                    boolean k3TypeEqualToK3Type = k3Type.equalsIgnoreCase(toK3Type);

                    boolean toK2TypeEqualK1Type = toK2Type.equalsIgnoreCase(k1Type);
                    boolean toK3TypeEqualK1Type = toK3Type.equalsIgnoreCase(k1Type);
                    boolean toK3TypeEqualK2Type = toK3Type.equalsIgnoreCase(k2Type);

                    boolean toK1TypeEqualColName = toK1Type.equalsIgnoreCase(columnName);
                    boolean toK2TypeEqualColName = toK2Type.equalsIgnoreCase(columnName);
                    boolean toK3TypeEqualColName = toK3Type.equalsIgnoreCase(columnName);

                    String value = (ARIAUtil.findColumn(rowMap,columnName)==null?"":ARIAUtil.findColumn(rowMap,columnName).getValue().toString());

                    if (k1TypeEqualToK1Type) {
                        // pass key1 value
                        if (k2TypeEqualToK2Type) {
                            // pass key2 value
                            if (k3TypeEqualToK3Type) {
                                // pass key3 value
                            }
                        } else {
                            if (toK2TypeEqualColName) {
                                // pass the link column key2_value
                                k2Value = value;
                            } else if (toK3TypeEqualColName) {
                                k3Value = value;
                            } else {
                                k2Value = "";
                                k3Value = "";
                            }
                        }
                    } else {
                        if (toK2TypeEqualK1Type) {
                            // pass the link column value as key1_value, no value for key2
                            k1Value = value;
                            k2Value = "";
                        } else if (toK3TypeEqualK1Type) {
                            // pass the link column value as key1_value, no value for key2
                            k1Value = value;
                            k2Value = "";
                            k3Value = "";
                        } else if (toK3TypeEqualK2Type) {
                            k2Value = value;
                            k3Value = "";
                        } else if (toK1TypeEqualColName) {
                            k1Value = value;
                            k2Value = "";
                        } else {
                            // no key1 or key2 value pass over.
                            k1Value = "";
                            k2Value = "";
                        }
                    }
                }

                // Remake the link
                z = new StringTokenizer(url, "&");
                while (z.hasMoreTokens()) {
                    String parm = z.nextToken();
                    if (parm.indexOf("key1=") >= 0) {
                    	parm = "key1=" + k1Value.trim();
                    }
                    if (parm.indexOf("key2=") >= 0) {
                        parm = "key2=" + k2Value;
                    }
                    if (parm.indexOf("key3=") >= 0) {
                        parm = "key3=" + k3Value;
                    }
                    tempParms += parm;
                    if (z.hasMoreTokens()) {
                        tempParms += "&";
                    }
                }
            }
        } catch (Exception e) {
            logger.error("recreateKeyLinks", e);
        }
        return tempParms;
	}
		
	/**
	 * 
	 * @param dto
	 * @param weekdayOptions
	 * @return
	 * @throws RABCException
	 */
	public static AdhocRptDataTO createReportFilters(AdhocRptDataTO dto, HashMap weekdayOptions) throws RABCException {
        AdhocRptDAO dao = new AdhocRptDAO();
        dto = dao.updateReportHeaders(dto);
        int dataKeyLvl = dao.getDataKeyLvl(dto);

        StringBuffer header3 = new StringBuffer(100);
        header3.append(dto.getRptHeader3());
        if (dto.getStartDate() != null) {
            if (dto.getRptHeaderDateInd().equals("1")) {
                header3.append(" for: " + dto.getStartDate());
                if (dto.getEndDate() != null && !dto.getStartDate().equalsIgnoreCase(dto.getEndDate())) {
                    header3.append(" - " + dto.getEndDate());
                }
            } else if (dto.getRptHeaderDateInd().equals("2")) {
                header3.append("  as Of: " + dto.getStartDate());
            }
        }
        dto.setRptHeader3(header3.toString());

        dto = formatReportHeaders(dto);

        // decide whether to show or hide buttons
        if (!dto.isHidePrev()) {
            dto.setHidePrev(dao.isButtonHidden(dto.getPresnId(), dto.getWebId(), "Previous Data", dto.getRegion()));
        }
        if (!dto.isHideNext()) {
            dto.setHideNext(dao.isButtonHidden(dto.getPresnId(), dto.getWebId(), "Next Data", dto.getRegion()));
        }
        dto.setHideView(dao.isButtonHidden(dto.getPresnId(), dto.getWebId(), "View Report", dto.getRegion()));
        dto.setHideCreate(dao.isButtonHidden(dto.getPresnId(), dto.getWebId(), "Create Report", dto.getRegion()));
        dto.setHideEmail(dao.isButtonHidden(dto.getPresnId(), dto.getWebId(), "Email Report", dto.getRegion()));

        // decide which filtering criteria to display
        // for SortKeyList...
        if (dto.getKeysRow1ColumnsList().size() > 0 && dto.getDivNameKeyLvl() != 1) {
            dto.setHideSortKeyList(false);
            dto.setLabelSortKeyList(dto.getColumnsHeadersList().get(0).toString().trim());
        }

        // for Division...
        if ((dto.getDivNameKeyLvl() == 1 || dto.getDivNameKeyLvl() == 2) && dto.getFileSeqNumInd().equalsIgnoreCase("Y")) {
            if (StaticDataLoader.getDivisionsByRegion(dto.getRegion()).size() > 0) {
                if (dto.getDivisionYes().equalsIgnoreCase("Y")) {
                }
                dto.setHideDivDropDown(false);
            }
        } else if (dto.getDivNameKeyLvl() == 1 || dto.getDivNameKeyLvl() == 2) {
            if (StaticDataLoader.getDivisionsByRegion(dto.getRegion()).size() > 0) {
                if (dto.getDivisionYes().equalsIgnoreCase("Y")) {
                }
                dto.setHideDivCheckBox(false);
            }
        }

        // for File Seq Num...
        if (dto.getFileSeqNumInd().equalsIgnoreCase("Y")) {
            dto.setHideFileSeqNum(false);
        }

        // for SortKeyList2...
        if (dataKeyLvl > 1 && dto.getDivNameKeyLvl() != 2) {
            dto.setHideSortKeyList2(false);
            // dto.setLabelSortKeyList2(dto.getColumnsHeadersList().get(1).toString().trim());
            dto.setLabelSortKeyList2(getColumnHeader(dto.getColumnsHeadersList().get(1).toString().trim(), 1,dto));
        }

        // display Alert Rule Timing only if the TIMING_FILTER_CODE is 1, 2 or 3
        if (dto.getTimingFilterCode() != null && !dto.getTimingFilterCode().trim().equals("")) {
            int tfCode = Integer.parseInt(dto.getTimingFilterCode());
            if (tfCode == 1 || tfCode == 2) {
                if (!dto.getFileSeqNumInd().equalsIgnoreCase("Y") && dto.getTableNames().toUpperCase().indexOf(dto.getPresnTblName().toUpperCase()) > -1) {
                    dto.setHideAlertRuleTiming(false);

                    // store alert time indicator options
                    ArrayList options1 = new ArrayList();
                    options1.add(new PickList("", "-- Select --"));
                    if (tfCode == 1 ) {
                        options1.add(new PickList("D", "Call Day Week"));
                    }
                    if (tfCode == 2 ) {
                    	if ("MW".equals(dto.getRegion())){
                    		options1.add(new PickList("B", "Process Group"));
                    	} else {
                    		options1.add(new PickList("B", "Bill Cycle"));
                    	}
                    }
                    dto.setAlertTimeIndOptions(options1);

                    // store alert time value options
                    // ...default option
                    ArrayList options2 = new ArrayList();
                    options2.add(new PickList(Integer.toString(-1), "-- Select --"));
                    dto.setAlertTimeValueOptions(options2);

                    // ...options for call day week
                    // Horrible...absolutely, horrible
                    ArrayList options2a = new ArrayList();
                    options2a.add(new PickList(Integer.toString(-1), "-- Select --"));
                    if (dto.getPresnModel() != 4) { // TODO Check with Kin
                        options2a.add(new PickList(Integer.toString(0), "All"));
                    }

                    if (weekdayOptions == null) {
                        weekdayOptions = new HashMap();
                        weekdayOptions.put(Integer.toString(1), "Sunday");
                        weekdayOptions.put(Integer.toString(2), "Monday");
                        weekdayOptions.put(Integer.toString(3), "Tuesday");
                        weekdayOptions.put(Integer.toString(4), "Wednesday");
                        weekdayOptions.put(Integer.toString(5), "Thursday");
                        weekdayOptions.put(Integer.toString(6), "Friday");
                        weekdayOptions.put(Integer.toString(7), "Saturday");
                    }

                    options2a.add(new PickList(Integer.toString(2), weekdayOptions.get(Integer.toString(2)).toString()));
                    options2a.add(new PickList(Integer.toString(3), weekdayOptions.get(Integer.toString(3)).toString()));
                    options2a.add(new PickList(Integer.toString(4), weekdayOptions.get(Integer.toString(4)).toString()));
                    options2a.add(new PickList(Integer.toString(5), weekdayOptions.get(Integer.toString(5)).toString()));
                    options2a.add(new PickList(Integer.toString(6), weekdayOptions.get(Integer.toString(6)).toString()));
                    options2a.add(new PickList(Integer.toString(7), weekdayOptions.get(Integer.toString(7)).toString()));
                    options2a.add(new PickList(Integer.toString(1), weekdayOptions.get(Integer.toString(1)).toString()));
                    dto.setAlertTimeValueOptionsWD(options2a);

                    // ...options for bill day
                    ArrayList options2b = new ArrayList();
                    options2b.add(new PickList(Integer.toString(-1), "-- Select --"));
                    ArrayList list = StaticDataLoader.getBillRndByRegion(dto.getRegion());
                    for (int i = 0; i < list.size(); i++) {
                        if (Integer.parseInt(list.get(i).toString()) < 10) {
                            options2b.add(new PickList(list.get(i).toString(), "0" + list.get(i).toString()));
                        } else {
                            options2b.add(new PickList(list.get(i).toString(), list.get(i).toString()));
                        }
                    }
                    dto.setAlertTimeValueOptionsBR(options2b);

                    // ...finally set display options for all the above 3 drop down lists
                    if (dto.getAlertTimeInd().equalsIgnoreCase("D") && dto.getAlertTimeValue() != -1) {
                        dto.setStyleAlertTimeValue("display:none");
                        dto.setStyleAlertTimeValueWD("display:inline");
                        dto.setStyleAlertTimeValueBR("display:none");
                    } else if (dto.getAlertTimeInd().equalsIgnoreCase("B") && dto.getAlertTimeValue() != -1) {
                        dto.setStyleAlertTimeValue("display:none");
                        dto.setStyleAlertTimeValueWD("display:none");
                        dto.setStyleAlertTimeValueBR("display:inline");
                    } else {
                        dto.setStyleAlertTimeValue("display:inline");
                        dto.setStyleAlertTimeValueWD("display:none");
                        dto.setStyleAlertTimeValueBR("display:none");
                    }

                }
            }
        } 

        // Kin: 3/20/2007
        // To make life simpler, just create a monthly option for presn__trend_time equal to 'D','B', and null for
        // layout 1 and 2
        if (dto.getTimingFilterCode() != null && !dto.getTimingFilterCode().trim().equals("")) {
        	int tfCode = Integer.parseInt(dto.getTimingFilterCode());
        	if (tfCode == 1 || tfCode == 2 || tfCode == 5) {
                 dto.setHideMonthYear(false);

                 // store options for month drop down list
                 ArrayList options3 = new ArrayList();
                 options3.add(new PickList("", ""));
                 options3.add(new PickList(Integer.toString(1), "January"));
                 options3.add(new PickList(Integer.toString(2), "February"));
                 options3.add(new PickList(Integer.toString(3), "March"));
                 options3.add(new PickList(Integer.toString(4), "April"));
                 options3.add(new PickList(Integer.toString(5), "May"));
                 options3.add(new PickList(Integer.toString(6), "June"));
                 options3.add(new PickList(Integer.toString(7), "July"));
                 options3.add(new PickList(Integer.toString(8), "August"));
                 options3.add(new PickList(Integer.toString(9), "September"));
                 options3.add(new PickList(Integer.toString(10), "October"));
                 options3.add(new PickList(Integer.toString(11), "November"));
                 options3.add(new PickList(Integer.toString(12), "December"));
                 dto.setMonthSelectOptions(options3);

                 // store options for year drop down list
                 ArrayList options4 = new ArrayList();
                 Calendar cal = new GregorianCalendar();
                 options4.add(new PickList("", ""));
                 options4.add(new PickList(Integer.toString(cal.get(Calendar.YEAR)), Integer.toString(cal.get(Calendar.YEAR))));
                 options4.add(new PickList(Integer.toString(cal.get(Calendar.YEAR) - 1), Integer.toString(cal.get(Calendar.YEAR) - 1)));
                 options4.add(new PickList(Integer.toString(cal.get(Calendar.YEAR) - 2), Integer.toString(cal.get(Calendar.YEAR) - 2)));
                 dto.setYearSelectOptions(options4);
        	} 
        } else {
        	dto.setHideMonthYear(false);
        }

        if (dto.getDivisionName() != null && !dto.getDivisionName().equals("") && dto.getSelectedDivs().length == 0) {
            ArrayList divList = AdhocRptUtil.stringToArrayList(dto.getDivisionName(), ",");
            String[] divArray = new String[divList.size()];
            for (int i = 0; i < divList.size(); i++) {
                divArray[i] = divList.get(i).toString();
            }
            dto.setSelectedDivs(divArray);
        }
        
        /*
         * Code to set the check box hide boolean to true
         */
        if ("B".equals(dto.getPresnTrendTime())){
        	dto.setHideBillRoundCheck(false);
        }
        
        return dto;
	 }
	 
    /**
     * 
     * #10) Information before colons (labels) should be bold (including the colon). Information after the colon (data)
     * should not be bold. i.e. on the report page: Alert Rule: AIMS_Actvt. "Alert Rule:" should be bold. "AIMS_Actvt."
     * should not be bold. "Trending Alert Rule For: 03/01/2007 - "Trending Alert Rule for:" should be bold,
     * "03/01/2007" should not be bold. Notice also for should not capitalized (articles - and, the, etc. should not be
     * capitalized).
     * 
     */
    private static AdhocRptDataTO formatReportHeaders(AdhocRptDataTO dto) {
        String[] headers = new String[3];
        headers[0] = dto.getRptHeader1();
        headers[1] = dto.getRptHeader2();
        headers[2] = dto.getRptHeader3();
        for (int i = 0; i < headers.length; i++) {
            if (headers[i] != null) {
                int index = headers[i].indexOf("Trending Alert Rule for:");
                if (index != -1) {
                    headers[i] = headers[i].substring(0, index + 20) + "for:&nbsp;</b>" + headers[i].substring(i + 23);
                }

                index = headers[i].indexOf("Tracking Alert Rule for:");
                if (index != -1) {
                    headers[i] = headers[i].substring(0, index + 20) + "for:&nbsp;</b>" + headers[i].substring(i + 23);
                }

                index = headers[i].indexOf("Alert Rule:");
                if (index != -1) {
                    headers[i] = headers[i].substring(0, index + 11) + "</b>&nbsp;" + headers[i].substring(i + 11);
                }
            }
        }

        dto.setRptHeader1(headers[0]);
        dto.setRptHeader2(headers[1]);
        dto.setRptHeader3(headers[2]);
        return dto;
    }
    
    /**
     * Expanded header solution
     * 
     * @param header
     * @param index
     * @return
     */
    public static String getColumnHeader(String header, int index, AdhocRptDataTO dto) {
        if (header.startsWith("__")) {
            header = (String) dto.getColumnsHeadersListExpanded().get(index);
        }
        return header.replace('.', ' ');
    }
    
    /**
     * Test the character indicator to see if it contains the value specified. If the indicator is null it will return
     * false.
     * <p>
     * example: isIndicatorIn(myInd, "YN") = true if the indicator is either 'Y' or 'N'
     * 
     * @param ind
     * @param test
     * @return
     */
    public static boolean isIndicatorIn(String ind, String test) {
        if (ind == null) {
            return false;
        }

        if (ind.trim().length() == 0) {
            return false;
        }

        return test.indexOf(ind) >= 0;
    }
    
    /**
     * 
     * @param inputDate
     * @param dto
     * @return
     * @throws ParseException
     */
    public static String formatDateForDisplay(String inputDate, AdhocRptDataTO dto) throws ParseException {
        // translate timestamp into a simple date
        if (inputDate.length() > 20) {
            inputDate = inputDate.substring(0, 10).replaceAll("-", "");
        }
        
      

        if ((inputDate.equals(AdhocConstants.TOTAL)) || (inputDate.equals(AdhocConstants.GRAND_TOTAL))) {
            return inputDate;
        }

        if (inputDate.indexOf('/') > 0) {
            return inputDate;
        }

        String displayDate = null;
        if (dto.getPresnTrendTime().equalsIgnoreCase("B") && dto.getProcDateInd().equalsIgnoreCase("P")) {
            displayDate = inputDate;

        } else if (dto.getNoProcDate().equalsIgnoreCase("Y") && dto.getPresnTrendTime().equalsIgnoreCase("M")) {
            displayDate = inputDate;

        } else if (dto.getNoProcDate().equalsIgnoreCase("Y") && dto.getPresnTrendTime().equalsIgnoreCase("Y")) {
            displayDate = inputDate;

        } else if (dto.getPresnTrendTime().equalsIgnoreCase("B")) {
        	if (dto.getMonthSelect()!=0 && dto.getYearSelect()!=0 && dto.getPresnModel()==1){
        		displayDate = inputDate;
        	} else {
        		 if (inputDate.length() == 8) {
                     displayDate = inputDate.substring(4, 6) + "/" + inputDate.substring(6, 8) + "/" + inputDate.substring(0, 4);
                 } else if (inputDate.length() == 6) {
                     displayDate = dto.getBillRnd() + "/" + inputDate.substring(4, 6) + "/" + inputDate.substring(0, 4);
                 }
        	}
           

        } else if (dto.getPresnTrendTime().equalsIgnoreCase("M") && dto.getNoProcDate().equalsIgnoreCase("N")) {
            if (inputDate.equals("")) {
                displayDate = "";
            } else {
                if (inputDate.length() == 6) {
                    displayDate = inputDate.substring(4, 6) + "/" + inputDate.substring(0, 4);
                }
            }

        } else if (dto.getPresnTrendTime().equalsIgnoreCase("Y") && dto.getNoProcDate().equalsIgnoreCase("N")) {
            displayDate = inputDate;

        } else if (dto.getNoProcDate().equalsIgnoreCase("N")) {
            if (inputDate.equals("")) {
                displayDate = "";
            } else {
            	if (dto.getMonthSelect()!=0 && dto.getYearSelect()!=0 && dto.getPresnModel()==1){
            		displayDate = inputDate;
            	}else if (inputDate.length() >= 8) {
                    displayDate = inputDate.substring(4, 6) + "/" + inputDate.substring(6, 8) + "/" + inputDate.substring(0, 4);
                }
            }

        } else if (dto.getNoProcDate().equalsIgnoreCase("Y")) {
            displayDate = inputDate;
        }

        // if date is still not formatted, do hard-coded format
        if (displayDate != null && displayDate.indexOf("-") != -1 && inputDate.length() >= 10) {
            displayDate = inputDate.substring(5, 7) + "/" + inputDate.substring(8, 10) + "/" + inputDate.substring(0, 4);
        }

        // still another possibility...
        if ((displayDate == null)&& inputDate.indexOf("-") != -1 && inputDate.length() >= 10) {
        	 displayDate = inputDate.substring(5, 7) + "/" + inputDate.substring(8, 10) + "/" + inputDate.substring(0, 4);
        }
        
        // still another possibility...
        if ((displayDate == null) && inputDate.length() == 8) {
            displayDate = inputDate.substring(4, 6) + "/" + inputDate.substring(6, 8) + "/" + inputDate.substring(0, 4);
        }


        return displayDate == null ? inputDate : displayDate;
    }
    
    /**
     * Inappropriately located method to get mouse over description. This should really be in the DAO.
     * 
     * @param tableIndex
     * @param mouseKey
     * @param value TODO
     * @return
     * @throws RABCException
     */
    public static String getMouseOverDescription(int tableIndex, String mouseKey, String value,AdhocRptDataTO dto, AdhocRptDataTO dtoBase,Connection connection, Logger logger) {
        if (tableIndex < 0) {
            return "";
        }

        if (dto.getDataMouseOverNumList().get(tableIndex) == null) {
            return "";
        }
        
        if (dto.getDataMouseOverNumList().get(tableIndex).toString().length() == 0) {
            return "";
        }
        
        if (Integer.parseInt((String) dto.getDataMouseOverNumList().get(tableIndex)) == 0) {
            return "";
        }

        String columnName = dto.getDataLinkTblKeyDataList().get(tableIndex).toString();
        String tableName = dto.getDataLinkTblNameList().get(tableIndex).toString();
        String whereClauseKey = dto.getDataLinkTblKeyNameList().get(tableIndex).toString();

        if ((columnName.length() == 0) || (tableName.length() == 0) || (whereClauseKey.length() == 0)) {
            return "";
        }

        String mouseOverDesc = "";
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            String sql = "SELECT " + columnName + " FROM " + tableName + " WHERE " + whereClauseKey + " = ?";
            ps = connection.prepareStatement(sql);
            ps.setString(1, value);
            rs = ps.executeQuery();
            while (rs.next()) {
                mouseOverDesc = rs.getString(1) == null ? "" : rs.getString(1).trim();
            }
        } catch (SQLException sqle) {
            logger.fatal("getMouseOverDescription", sqle);
        } finally {
            JDBCUtil.closeResultSet(rs);
            JDBCUtil.closePreparedStatement(ps);
        }
        return mouseOverDesc;
    }
    
    /**
     * 
     * @param columnName
     * @param value
     * @param escape
     * @param elementIndex
     * @param buf
     * @param dto
     * @param logger
     * @param section
     * @return
     * @throws RABCException
     */
    public static StringBuffer formatCellData(String columnName, String value, boolean escape, int elementIndex, StringBuffer buf,AdhocRptDataTO dto, Logger logger, int section) throws RABCException {
        String suffix = "";

        if (elementIndex < 0) {
            if (isDateHeader(columnName)) {
                try {
                    value = formatDateForDisplay(value,dto);
                } catch (ParseException e) {
                    logger.warn("Date value of " + value + " could not be formatted.");
                }
            }
            buf.append(ARIAUtil.escape(value));
            return buf;
        }

        if (isIndicatorIn((String) dto.getPresnUnitIndList().get(elementIndex), "P")) {
            suffix = "%";
        }

        if (value == null) {
            buf.append("");
            return buf;
        }

        if (isIndicatorIn((String) dto.getPresnUnitIndList().get(elementIndex), "D")) {
            value = escape ? ARIAUtil.escape(value) : value;
            try {
            	NumberFormat fmt = NumberFormat.getNumberInstance();
                fmt.setMinimumFractionDigits(2);
                fmt.setMaximumFractionDigits(2);
                // quick BTN fix
                if("BTN".equals(columnName)) {
                	buf.append(ARIAUtil.escape(value));
                	buf.append(suffix);
                } else if (Double.parseDouble(value)<0){
                	buf.append("-");
                	buf.append("$ ");
                	buf.append(fmt.format(Math.abs(Double.parseDouble(value))));
                } else {
                	buf.append("$ ");
                	buf.append(fmt.format(Double.parseDouble(value)));
                }
                
                //buf.append(NumberFormat.getCurrencyInstance().format(Double.parseDouble(value)));
            } catch (NumberFormatException e) {
                buf.append("NaN");
            }
            return buf;
        }

        if (isBizarroNumeric(elementIndex,dto) || suffix.equals("%")) {
            value = escape ? ARIAUtil.escape(value) : value;
            NumberFormat fmt = NumberFormat.getNumberInstance();
            fmt.setMinimumFractionDigits((value.indexOf('.') >= 0) ? 2 : 0);
            fmt.setMaximumFractionDigits(2);
            try {
                buf.append(fmt.format(Double.parseDouble(value)));
            } catch (NumberFormatException e) {
                buf.append("NaN");
            }
            buf.append(suffix);
            return buf;
        }

        // this is a hack. Didn't have time to properly fix calc formatting.
        String calcNum = (String) dto.getPresnCalcNumList().get(elementIndex);
        if ((calcNum != null) && (calcNum.length() > 0)) {
            value = escape ? ARIAUtil.escape(value) : value;
            NumberFormat fmt = NumberFormat.getNumberInstance();
            Calculation calc = new AdhocRptDAO().getCalcElem(dto, calcNum, section);
            fmt.setMinimumFractionDigits(calc.getPrecision());
            fmt.setMaximumFractionDigits(calc.getPrecision());
            try {
                buf.append(fmt.format(Double.parseDouble(value)));
            } catch (NumberFormatException e) {
                buf.append("NaN");
            }
            buf.append(suffix);
            return buf;
        }

        if (((String) dto.getColumnsAsOracleList().get(elementIndex)).indexOf("DIV") != -1) {
            if (escape) {
            	 buf.append(ARIAUtil.escape(StaticDataLoader.getDivisionDesc(dto.getRegion().trim(), value.trim())));
            } else {
            	buf.append(StaticDataLoader.getDivisionDesc(dto.getRegion().trim(), value.trim()));
            }
            buf.append(suffix);
            return buf;
        }

        if (isDateHeader(columnName)) {
            try {
                value = formatDateForDisplay(value, dto);
            } catch (ParseException e) {
                logger.warn("Date value of " + value + " could not be formatted.");
            }
        }
        if (escape) {
            buf.append(ARIAUtil.escape(value));
        } else {
            buf.append(value);
        }
        buf.append(suffix);
        return buf;
    }
    
    /**
     * determine if the column is a date
     * 
     * @param columnName
     * @return
     */
    public static boolean isDateHeader(String columnName) {
        String name = columnName.toUpperCase();
        if (name.indexOf("DATE") != -1 || name.indexOf("DT") != -1) {
            return true;
        }
        return false;
    }
    
    /**
     * bizarro way of determining if this is a numeric value "You can use the presn_sum_ind as the yard stick. It you
     * can sum must be numeric."
     */
    public static boolean isBizarroNumeric(int elementIndex, AdhocRptDataTO dto) {
        boolean bizarro1 = true;// (dto.getPresnUnitIndList().get(elementIndex).toString().length() != 0);
        boolean bizaro2 = (dto.getPresnSumIndList().get(elementIndex).toString().length() == 0) || (dto.getPresnSumIndList().get(elementIndex).equals("Y"));
        return bizarro1 & bizaro2;
    }
    
    /**
     * Create the graph href url
     * 
     * @param columnName
     * @param rowMap
     * @param tableIndex
     * @return
     * @throws ParseException
     * @throws UnsupportedEncodingException
     */
    public static String getGraphUrl(String columnName, List<RowElement> rowMap, int tableIndex,AdhocRptDataTO dto) throws ParseException, UnsupportedEncodingException {
        StringBuffer buf = new StringBuffer(100);
        buf.append(GRAPH_LINK_ACTION + "?");
        String urlString = getBaseUrl(dto,columnName, rowMap, tableIndex);
        int strPos = urlString.indexOf("&key");
        if (strPos == -1) {
            buf.append(urlString);
        } else {
            buf.append(urlString.substring(0, strPos));
        }

        String tempAlertItem = "";

        RowElement alertItemValue = ARIAUtil.findColumn(rowMap, "Alert Item");//searchRowMap(rowMap, "Alert Item");
        if (alertItemValue != null) {  
            if (alertItemValue.getValue().toString().equalsIgnoreCase("no data")) {
                tempAlertItem = "";
            } else {
                String value = alertItemValue.getValue().toString();
                if (value.equals("-1")) {
                    tempAlertItem = "";
                } else {
                    tempAlertItem = value;
                }
            }
        }

        if (dto.getAdhocTest().equalsIgnoreCase("N") && !dto.getColumnsAsOracleList().get(tableIndex).equals("")) {
            buf.append("&tableName=");
            buf.append(dto.getColumnsTablesList().get(tableIndex));
            buf.append("&alertItem=");
            buf.append(urlEncodedFormat(tempAlertItem));
            buf.append("&itemDDlName=");
            buf.append(dto.getColumnsToExtractList().get(tableIndex));
            buf.append("&PartiRefId=");
            buf.append(dto.getPartiRefIdList().get(tableIndex));
            buf.append(getKeyStructString(dto, rowMap, tableIndex));
            buf.append("&Header=");
            buf.append(dto.getColumnsHeadersList().get(tableIndex));
        }
        return buf.toString();
    }
    
    /**
     * 
     * @param columnName
     * @param tableIndex
     * @param dto
     * @param adhocPivotData
     * @param procDate
     * @return
     * @throws ParseException
     * @throws UnsupportedEncodingException
     */
    public static String getGraphUrl(String columnName, int tableIndex,AdhocRptDataTO dto, AdhocPivotData adhocPivotData, String procDate) throws ParseException, UnsupportedEncodingException {
        StringBuffer buf = new StringBuffer(100);
        buf.append(GRAPH_LINK_ACTION + "?");
        String urlString = getBaseUrl(dto,columnName,tableIndex, procDate, adhocPivotData);
        int strPos = urlString.indexOf("&key");
        if (strPos == -1) {
            buf.append(urlString);
        } else {
            buf.append(urlString.substring(0, strPos));
        }

        // Since this method is overridden especially for Layouts 2 & 4 there would be no alert item
        String tempAlertItem = "";

        if (dto.getAdhocTest().equalsIgnoreCase("N") && !dto.getColumnsAsOracleList().get(tableIndex).equals("")) {
            buf.append("&tableName=");
            buf.append(dto.getColumnsTablesList().get(tableIndex));
            buf.append("&alertItem=");
            buf.append(urlEncodedFormat(tempAlertItem));
            buf.append("&itemDDlName=");
            buf.append(dto.getColumnsToExtractList().get(tableIndex));
            buf.append("&PartiRefId=");
            buf.append(dto.getPartiRefIdList().get(tableIndex));
            buf.append(getKeyStructString(dto, tableIndex,adhocPivotData));
            buf.append("&Header=");
            buf.append(dto.getColumnsHeadersList().get(tableIndex));
        }
        return buf.toString();
    }
    
    /**
     * Gets the param key info for links.
     * <p>
     * Legacy
     * 
     * @param dto
     * @param arrayIndex
     * @param columnsAsOracleValueList
     * @return
     */
    public static String getKeyStructString(AdhocRptDataTO dto, List<RowElement> rowMap, int arrayIndex) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        ArrayList columnsAsOracleValueList = new ArrayList();
        for (int i = 0; i < dto.getKeysRow1ColumnsList().size(); i++) {
//            columnsAsOracleValueList.add(rowMap.get(dto.getColumnsHeadersList().get(i).toString()));
            columnsAsOracleValueList.add(ARIAUtil.findColumn(rowMap, (String) dto.getColumnsHeadersList().get(i)).getValue());
        }

        StringBuffer keyBuffer = new StringBuffer();
        boolean isRABCTbl = (StaticDataLoader.getDataTblDdlByAlertProcTbl("SYSTEM", dto.getColumnsTablesList().get(arrayIndex).toString(), dto.getRegion()).size() > 0 ? true : false);
        if (isRABCTbl) {
            for (int i = 0; i < dto.getKeysRow1ColumnsList().size(); i++) {
                int keySuffix = i + 1;
                keyBuffer.append("&key");
                keyBuffer.append(keySuffix);
                keyBuffer.append("=");
                if (!dto.getColumnsToExtractList().get(i).equals("") || columnsAsOracleValueList.get(i).toString().equalsIgnoreCase("no data")) {
                    keyBuffer.append(columnsAsOracleValueList.get(i));
                } else {
                    keyBuffer.append(" ");
                }
                keyBuffer.append("&aKey");
                keyBuffer.append(keySuffix);
                keyBuffer.append("=");
                
                if (columnsAsOracleValueList.get(i) instanceof Date) {
                    keyBuffer.append(sdf.format(columnsAsOracleValueList.get(i)));
                    keyBuffer.append(" 00:00:00.0");
                } else {
                    keyBuffer.append(columnsAsOracleValueList.get(i));    
                }
            }
        } else {
            for (int i = 0; i < dto.getKeysRow1ColumnsList().size(); i++) {
                int keySuffix = i + 1;
                keyBuffer.append("&key");
                keyBuffer.append(keySuffix);
                keyBuffer.append("=");
                String temp = "K" + i;
                if (!dto.getColumnsToExtractList().get(i).equals("") || columnsAsOracleValueList.get(i).toString().equalsIgnoreCase("no data")) {
                    if (dto.getColumnsAsOracleList().get(i).toString().indexOf(temp) > -1) {
                        keyBuffer.append(dto.getKeysRow1ColumnsList().get(i));
                    } else {
                        keyBuffer.append(dto.getColumnsAsOracleList().get(i));
                    }
                } else {
                    if (dto.getColumnsAsOracleList().get(i).toString().indexOf(temp) > -1) {
                        keyBuffer.append(dto.getKeysRow1ColumnsList().get(i));
                    } else {
                        keyBuffer.append(dto.getColumnsAsOracleList().get(i));
                    }
                }
                keyBuffer.append("=\\'");
                if (columnsAsOracleValueList.get(i) instanceof Date) {
                    keyBuffer.append(sdf.format(columnsAsOracleValueList.get(i)));
                    keyBuffer.append(" 00:00:00.0");
                } else {
                    keyBuffer.append(columnsAsOracleValueList.get(i));    
                }
                keyBuffer.append("\\'");
                keyBuffer.append("&aKey");
                keyBuffer.append(keySuffix);
                keyBuffer.append("=\\'");
                keyBuffer.append(columnsAsOracleValueList.get(i));
                keyBuffer.append("\\'");
            }
        }
        return keyBuffer.toString();
    }
    
    /**
     * 
     * @param dto
     * @param arrayIndex
     * @param adhocPivotData
     * @return
     */
    public static String getKeyStructString(AdhocRptDataTO dto, int arrayIndex, AdhocPivotData adhocPivotData) {
        String [] keyColumnValues = adhocPivotData.getKeyColumnValues();
        int [] keyColumnIndexes = adhocPivotData.getKeyColumnIndexes();
        StringBuffer keyBuffer = new StringBuffer();
        
        for (int i = 0; i < dto.getKeysRow1ColumnsList().size(); i++) {
            int keySuffix = i + 1;
            keyBuffer.append("&key");
            keyBuffer.append(keySuffix);
            keyBuffer.append("=");
            String temp = "K" + i;
            for (int k=0;k<keyColumnIndexes.length;k++){
            	if (i==keyColumnIndexes[k]){
            		keyBuffer.append(temp);
            		keyBuffer.append(dto.getKeysRow1ColumnsList().get(i));
            		keyBuffer.append("=\\'");
            		keyBuffer.append(keyColumnValues[k]);
            		keyBuffer.append("\\'");
                    keyBuffer.append("&aKey");
                    keyBuffer.append(keySuffix);
                    keyBuffer.append("=\\'");
                    keyBuffer.append(keyColumnValues[k]);
                    keyBuffer.append("\\'");
            		break;
            	}
            }   
        }
        
        return keyBuffer.toString();
    }
    
    /**
     * Search the row map for a value. This is case insensitive.
     * 
     * @param rowMap
     * @param key
     * @return
     */
    public static Object searchRowMap(Map rowMap, String key) {
        Iterator i = rowMap.keySet().iterator();
        while (i.hasNext()) {
            String aKey = (String) i.next();
            if (aKey.equalsIgnoreCase(key)) {
                return rowMap.get(aKey);
            }
        }
        return null;
    }
    
    /**
     * Get the link url.
     * 
     * @param columnName
     * @param rowMap
     * @param tableIndex
     * @param value
     * @return
     * @throws ParseException
     * @throws RABCException
     * @throws SQLException
     * @throws UnsupportedEncodingException
     */
    public static String getUrl(String columnName,List<RowElement> rowMap, int tableIndex, String value,AdhocRptDataTO dto,AdhocRptDataTO dtoBase, Connection connection,Logger logger) throws ParseException, RABCException, SQLException, UnsupportedEncodingException {
        String url = getBaseUrl(dto,columnName, rowMap, tableIndex);
        url = recreateKeyLinks(dto,columnName, rowMap, url,logger,connection,dtoBase);
        return buildUrl(dto,url, columnName, tableIndex, value,dtoBase,connection,logger);
    }
    
    /**
     * 
     * @param columnName
     * @param tableIndex
     * @param value
     * @param dto
     * @param dtoBase
     * @param connection
     * @param logger
     * @param adhocPivotData
     * @param procDate
     * @return
     * @throws ParseException
     * @throws RABCException
     * @throws SQLException
     * @throws UnsupportedEncodingException
     */
    public static String getUrl(String columnName, int tableIndex, String value,AdhocRptDataTO dto,AdhocRptDataTO dtoBase, Connection connection,Logger logger, AdhocPivotData adhocPivotData, String procDate) throws ParseException, RABCException, SQLException, UnsupportedEncodingException {
        String url = getBaseUrl(dto,columnName, tableIndex, procDate,adhocPivotData);
        url = recreateKeyLinks(dto,columnName,url,logger,connection,dtoBase,adhocPivotData);
        return buildUrl(dto,url, columnName, tableIndex, value,dtoBase,connection,logger);
    }
    
    /**
     * Append the proper parameters to graph links.
     * 
     * @param dto
     * @param displayDate
     * @param graphAlertTimeValue
     * @param url
     */
    public static StringBuffer appendAlertTimeToGraphURL(AdhocRptDataTO dto, List<RowElement> rowMap, String displayDate, int graphAlertTimeValue, StringBuffer url) {
        if (graphAlertTimeValue == -1) {
        	RowElement searchResult = ARIAUtil.findColumn(rowMap, "BILL_RND");//searchRowMap(rowMap, "BILL_RND");
            if (searchResult != null) {            	
                String billRnd = searchResult.getValue().toString();
                graphAlertTimeValue = billRnd == null ? 0 : Integer.parseInt(billRnd);
            } 
        }

        if (dto.getPartiRefId() == -1) {
            url.append("&alertTimeInd=");
            if ("DBM".indexOf(dto.getPresnTrendTime()) >= 0) {
                url.append(dto.getPresnTrendTime());
            }
        } else {
            url.append("&alertTimeInd=");
            if ("DB".indexOf(dto.getAlertTimeInd()) >= 0) {
                url.append(dto.getAlertTimeInd());
            }
        }

        boolean isD = url.charAt(url.length() - 1) == 'D';
        boolean isB = url.charAt(url.length() - 1) == 'B';
        
        url.append("&alertTimeValue=");
        if (isD) {
            try {
                Date d = DateUtil.parseUnknown(displayDate);
                if (d != null) {
                    url.append(DateUtil.getDayOfWeek(d));
                }
            } catch (Exception e) {
            }
        } else if (isB) {
       	 	try {
       	 		Date d = DateUtil.parseUnknown(displayDate);
	            if (d != null) {
	            	String formattedDisplayDt = MMDDYYYY_FORMAT.format(d);
	            		
	            	String procDates = StaticDataLoader.getProcDates(dto.getRegion());
	             	String billRounds = StaticDataLoader.getBillRounds(dto.getRegion());
	             	
	             	String [] procDtArr = procDates.split("~");
	             	String [] billRndArr = billRounds.split("~");
	             	
	             	for (int i=0;i<procDtArr.length;i++){
	             		if (!"".equals(procDtArr[i]) && formattedDisplayDt.equals(procDtArr[i])){
	             			url.append(billRndArr[i]);
	             		}
	             	}
	             }
       	 	} catch (Exception e) {
       	 		url.append("0");
       	 	}
        }else {
            if (!Integer.toString(dto.getAlertTimeValue()).equals("") && dto.getAlertTimeValue() != -1) {
                url.append(dto.getAlertTimeValue());
            } else {
                url.append("0");
            }
        }
        
        return url;
    }
    
    /**
     * Code added for graph UTL
     * @param dto
     * @param displayDate
     * @param graphAlertTimeValue
     * @param url
     * @return
     */
    public static StringBuffer appendAlertTimeToGraphURL(AdhocRptDataTO dto, String displayDate, int graphAlertTimeValue, StringBuffer url) {     
        if (dto.getPartiRefId() == -1) {
            url.append("&alertTimeInd=");
            if ("DBM".indexOf(dto.getPresnTrendTime()) >= 0) {
                url.append(dto.getPresnTrendTime());
            }
        } else {
            url.append("&alertTimeInd=");
            if ("DB".indexOf(dto.getAlertTimeInd()) >= 0) {
                url.append(dto.getAlertTimeInd());
            }
        }

        boolean isD = url.charAt(url.length() - 1) == 'D';
        boolean isB = url.charAt(url.length() - 1) == 'B';
        
        url.append("&alertTimeValue=");
        if (isD) {
            try {
                Date d = DateUtil.parseUnknown(displayDate);
                if (d != null) {
                    url.append(DateUtil.getDayOfWeek(d));
                }
            } catch (Exception e) {
            }
        } else if (isB) {
        	 try {
                 Date d = DateUtil.parseUnknown(displayDate);
                 if (d != null) {
                	String formattedDisplayDt = MMDDYYYY_FORMAT.format(d);
                		
                	String procDates = StaticDataLoader.getProcDates(dto.getRegion());
                 	String billRounds = StaticDataLoader.getBillRounds(dto.getRegion());
                 	
                 	String [] procDtArr = procDates.split("~");
                 	String [] billRndArr = billRounds.split("~");
                 	
                 	for (int i=0;i<procDtArr.length;i++){
                 		if (!"".equals(procDtArr[i]) && formattedDisplayDt.equals(procDtArr[i])){
                 			url.append(billRndArr[i]);
                 		}
                 	}
                 }
             } catch (Exception e) {
            	 url.append("0");
             }
        } else {
            if (!Integer.toString(dto.getAlertTimeValue()).equals("") && dto.getAlertTimeValue() != -1) {
                url.append(dto.getAlertTimeValue());
            } else {
                url.append("0");
            }
        }
        
        return url;
    }
    
    /**
     * If previous data exists, setup the table for it.
     * 
     * @param report
     * @throws ARIAReportException
     * @throws NamingException
     * @throws SQLException
     * @throws ARIAReportException
     * @throws NamingException
     * @throws SQLException
     * @throws RABCException
     */
    public static PreviousDataLookup setupPreviousDataTable(int section,AdhocRptDataTO dto,AdhocRptDataTO dtoBase,PreviousDataLookup prevData, Connection connection, Logger logger) throws SQLException, NamingException, ARIAReportException, RABCException {
        boolean previousExists = false;
        for (int i = 0; i < dto.getPrevDataIndList().size(); i++) {
            if (isIndicatorIn((String) dto.getPrevDataIndList().get(i), "Y")) {
                previousExists = true;
                break;
            }
        }

        if (!previousExists) {
            return prevData;
        }

        prevData = new PreviousDataLookup();

//        Map rowData;
       // List<RowElement> rowData = new ArrayList<RowElement>();
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            PreviousDataGeneratorMediator mediator = new PreviousDataGeneratorMediator();
            String sql = mediator.generatePreviousDataQuery(dto, section).toSQL();
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            ResultSetMetaData md = rs.getMetaData();
            int count =0;
            while (rs.next()) {
            	
                if (rs.getObject(1).equals(AdhocConstants.TOTAL) || rs.getObject(1).equals(AdhocConstants.GRAND_TOTAL)) {
                    // skip
                } else {
                	List<RowElement> rowData = new ArrayList<RowElement>();
                    for (int i = 1; i <= md.getColumnCount(); i++) {
//                        rowData.put(md.getColumnName(i), rs.getObject(i));
                    	
                        rowData.add(new RowElement(i,md, rs.getObject(i)));
                    }
                    /* Made required changes to get the previous data, for PMT #M169, issue #M12 */
                    AdhocRptDataTO dto1 = new  AdhocRptDataTO();
                    dto1 = (AdhocRptDataTO)dto.clone();    
                    dto1.setQueryValue(sql);
                    dto1.setRowDataCnt(count);
//                    List rowData1 = new ArrayList();
//                    rowData1.add(count,rowData);
                    dto1.setRowData(rowData);
                   // dto.setRowData(rowData);
                    prevData.put(getDatedKey(rowData,dto1), dto1);
                  //  rowData.clear();                
                    count = count+1;     
                 /* End requirement, for PMT #M169, issue #M12 */
                }
            }
        } finally {
            JDBCUtil.closeResultSet(rs);
            JDBCUtil.closePreparedStatement(ps);
        }
        
        return prevData;
    }
    
  

    /**
     * If previous data exists, setup the table for it.
     * 
     * @param report
     * @throws ARIAReportException
     * @throws NamingException
     * @throws SQLException
     * @throws ARIAReportException
     * @throws NamingException
     * @throws SQLException
     * @throws RABCException
     */
    public static PreviousDataLookup setupPivotPreviousDataTable(int section,AdhocRptDataTO dto,AdhocRptDataTO dtoBase,PreviousDataLookup prevData, Connection connection, Logger logger, boolean previousExists) throws SQLException, NamingException, ParseException, ARIAReportException, RABCException {
        if (!previousExists) {
            return prevData;
        }

        // Create a new PreviousDataLookup object
        prevData = new PreviousDataLookup();

        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            PreviousDataGeneratorMediator mediator = new PreviousDataGeneratorMediator();
            ps = connection.prepareStatement(mediator.generatePreviousDataQuery(dto, section).toSQL());
            rs = ps.executeQuery();
            
       	 	String fileDate = null;
       	 
    	   	if (!dto.getColumnsDataTypeList().isEmpty()){
    	   		int colSize = dto.getColumnsDataTypeList().size();
    	   		while (rs.next()) {
    	   			int counter = 0;
    	       	 	ArrayList pseudoKeyList = new ArrayList();
    	       	 	ArrayList dataColumnList = new ArrayList();
    	       	 	ArrayList dataValueList = new ArrayList();
    	       	 	
    	   			int cols = rs.getMetaData().getColumnCount();
    	   			if (cols == (colSize+1)){
        	   			for (int i = 0; i < cols; i++) {
        	   				String colName = rs.getMetaData().getColumnName(i+1);
        	   				
        	   				if ("File Date".equals(colName)){
        	   					fileDate = getFileDate(rs,dto);
        	   				} else {
        	   					String dataType = (String)dto.getColumnsDataTypeList().get(counter) ;
        	   					
    	   						if ("C".equals(dataType)){
        		   					dataColumnList.add((String)dto.getColumnsTablesList().get(counter) + "." + (String)dto.getColumnsAsOracleList().get(counter));
        		   					dataValueList.add(rs.getString(colName));
        		   				} else {
        		   					pseudoKeyList.add(rs.getString(colName));
        		   				}
        	   					
        	   					counter++;
        	   				}
        	   			}
        	       	}
    	   			
    	   			// Now form the dated keys for all the data columns
    	   			if (fileDate != null){
    	   				int dataColumnListSize = dataColumnList.size();
    	   				int pseudoKeyListSize = pseudoKeyList.size();
        	   			for (int i = 0; i < dataColumnListSize; i++) {
        	   				String columnName = (String)dataColumnList.get(i);
        	   				String columnValue = (String)dataValueList.get(i);
        	   				
        	   				// Form the composite keys with the pseudo key list & set number of keys
        	   				DatedCompositeKey datedKey = getDatedKey(fileDate);
        	   				datedKey.setNumKeys(pseudoKeyListSize + 1); // 1 added for the column name
        	   				
        	   				// Add all the key values first - these include Actual Keys & non-calculable column
        	   				for (int j = 0; j < pseudoKeyListSize; j++) {
        	   					String pseudoKey = (String)pseudoKeyList.get(j);
        	   					datedKey.addKey(pseudoKey);
        	   				}
        	   				
        	   				// Now that all keys are added add the column name also as key so as to fetch the proper value
        	   				datedKey.addKey(columnName);
        	   				
        	   				// Put this object in the Map
        	   				prevData.put(datedKey, columnValue);
        	   			}	
    	   			}
    	   		}
    	   	}
        } finally {
            JDBCUtil.closeResultSet(rs);
            JDBCUtil.closePreparedStatement(ps);
        }
        
        return prevData;
    }
    
    /**
     * Construct a composite key with date
     * 
     * @param column
     * @param processor
     * @return
     */
//    public static DatedCompositeKey getDatedKey(Map rowData,AdhocRptDataTO dto) {
    public static DatedCompositeKey getDatedKey(List<RowElement> rowElement,AdhocRptDataTO dto) {
//        Object obj = rowData.get("File Date");
    	RowElement rowElem = ARIAUtil.findColumn(rowElement, "File Date");
        Date d = null;
        if (rowElem.getValue() instanceof Date) {
            d = (Date) rowElem.getValue();
            // if it isn't a date type (i.e. subclass) then push it back up.
            d = new Date(d.getTime());
        } else {
            d = parseDate((String) rowElem.getValue());
        }
        if (d == null) {
            return null;
        }

        // Code added for addressing issue in case of monthly option layout 1
        ArrayList columnDataTypeList = dto.getColumnsDataTypeList();
        int nonCalcColumnsSize = 0;
        List colIndexList = new ArrayList();
        
        if (!columnDataTypeList.isEmpty()){
			int columnDataTypeListSize = columnDataTypeList.size();
			
			for (int i=0;i<columnDataTypeListSize;i++){
				String columnDataType = (String)columnDataTypeList.get(i);
				
				if ("K".equals(columnDataType)){
					nonCalcColumnsSize++;
					colIndexList.add(new Integer(i));
				} 
			}
		}
		
        int deduct = 0;
		DatedCompositeKey key = new DatedCompositeKey(d);
		int numKeys = dto.getKeysRow1ColumnsList().size();	
        for (int i = 0; i < numKeys; i++) {
        	if (checkIfRunDate(dto,i)){
        		deduct++;
        	} else {
//        		key.addKey(rowData.get(dto.getColumnsHeadersList().get(i)));
        	    key.addKey(ARIAUtil.findColumn(rowElement, (String) dto.getColumnsHeadersList().get(i)).getValue());
        	}
        }
        key.setNumKeys(nonCalcColumnsSize-deduct);
        deduct = 0;
		for (int i = numKeys; i < nonCalcColumnsSize; i++) {
			if (checkIfRunDate(dto,((Integer)colIndexList.get(i)).intValue())){
				deduct++;
			}else {
//				key.addKey(rowData.get(dto.getColumnsHeadersList().get(((Integer)colIndexList.get(i)).intValue())));
			    key.addKey(ARIAUtil.findColumn(rowElement, (String) dto.getColumnsHeadersList().get(i)).getValue());
			}	
	    }
		key.setNumKeys(key.getNumKeys()-deduct);
		
        return key;
    }
    
    /**
     * Construct a composite key with date - overloaded method specifically for layouts 2 & 4
     * 
     * @param columnp
     * @param processor
     * @return
     */
    public static DatedCompositeKey getDatedKey(String fileDate) {
    	Date d = null;
    	try {
    		if (fileDate.matches("\\d{2}[/]\\d{2}[/]\\d{4}")) {
    			d = MMDDYYYY_FORMAT.parse(fileDate);
    		} else if(fileDate.matches("\\d{4}")){
    			fileDate = "01/01/" + fileDate;
    			d = MMDDYYYY_FORMAT.parse(fileDate);
    		} else if(fileDate.matches("\\d{2}[/]\\d{4}")){
    			fileDate = fileDate.substring(0, 2) + "/01/" + fileDate.substring(3, fileDate.length());
    			d = MMDDYYYY_FORMAT.parse(fileDate);
    		} else {
    			d = MMDDYYYY_FORMAT.parse(fileDate);
    		}
    	} catch (ParseException pe){
    		d = null;
    	}
    	
    	if (d == null) {
            return null;
        }
        
        DatedCompositeKey key = new DatedCompositeKey(d);
        return key;
    }
    
    /**
     * Method to check whether the key is run date or not
     * @param dto
     * @param colName
     * @param index
     * @return
     */
    public static boolean checkIfRunDate(AdhocRptDataTO dto, int index){
    	String dataDdlName = (String) dto.getColumnsAsOracleList().get(index);
    	String dataTblName = (String)dto.getColumnsTablesList().get(index);
    	
    	if (dataTblName.startsWith("VW")){
    		try {
				String sourceTblName = new AdhocRptDAO().getTableNameFromView(dto, dataTblName);
				if (sourceTblName != null && !"".equals(sourceTblName)){
					dataTblName = sourceTblName;
				}
			} catch (RABCException e) {
				// Add a warning message here
			}
    	}
    	
    	List dataTblDdlList = StaticDataLoader.getDataTblDdlByAlertProcTbl(dataTblName, dto.getRegion());
    	String procDtDdlName = null;
    	if (!dataTblDdlList.isEmpty()){
    		for (int i=0;i<dataTblDdlList.size();i++){
    			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblDdlList.get(i);
    			if (dataTblDdlBean.getTblProcDateDdlName()!=null){
    				procDtDdlName = dataTblDdlBean.getTblProcDateDdlName();
    				break;
    			}
    		}
    	}
    	
    	if (dataDdlName.startsWith("K")){
    		dataDdlName = dataDdlName.substring(2, dataDdlName.length());
    	}
    	if (dataDdlName.equals(procDtDdlName)){
    		return true;
    	}else {
    		return false;
    	}
    }
    /**
     * Expand possible date conversions
     * 
     * @param dateString
     * @return
     */
    public static Date parseDate(String dateString) {
        Date d = null;
        try {
            d = DateUtil.parseUnknown(dateString);
            if (d == null) {
                if (dateString.matches("\\d{6}")) {
                    d = DateUtil.parseDate(dateString, "yyyyMM");
                } else if (dateString.matches("\\d{2}[/]\\d{4}")){
                	d = DateUtil.parseDate(dateString, "MM/yyyy");
                } else if (dateString.matches("\\d{4}")) {
                    d = DateUtil.parseDate(dateString, "yyyy");
                } 
            }
        } catch (ParseException e) {
            throw new IllegalArgumentException(dateString + " is not a know date format.");
        }
        return d;
    }
    
    /**
	 * Private method will return the file date based on the format of PROC_DATE
	 * @param fileDate
	 * @return
	 */
	private static String getFileDate(ResultSet rs,AdhocRptDataTO dto) throws SQLException, ParseException {
		String fileDate = rs.getString("File Date");
		
		if ("MM/DD/YYYY".equals(dto.getProcDateFormat())){
			return fileDate;
		} else if ("MM/YYYY".equals(dto.getProcDateFormat())){
			return fileDate;
		} else if ("YYYY".equals(dto.getProcDateFormat())){
			return fileDate;
		} else if ("YYYYMM".equals(dto.getProcDateFormat())){
			String yr = fileDate.substring(0,4);
			String mth = fileDate.substring(4,fileDate.length());
			fileDate = mth + "/" + yr;
			return fileDate;
		} else if ("YYYYMMDD".equals(dto.getProcDateFormat())){
			Date fileDt = YYYYMMDD_FORMAT.parse(fileDate);
			fileDate = MMDDYYYY_FORMAT.format(fileDt);
			return fileDate;
		} else if ("YYYY/MM".equals(dto.getProcDateFormat())){
			String yr = fileDate.substring(0,4);
			String mth = fileDate.substring(5,fileDate.length());
			fileDate = mth + "/" + yr;
			return fileDate;
		} else if ("DATE".equals(dto.getProcDateFormat())){
			Date fileDt = rs.getDate("File Date");
			fileDate = MMDDYYYY_FORMAT.format(fileDt);
			return fileDate;
		} else {
			return fileDate;
		}
	}
    
    /**
     * Create a TD tag with the style provided. If the DTO unit indicator is N, P, or D then right align. The tag is
     * appended to the supplied StringBuffer.
     * 
     * @param style
     * @param colIndex
     * @param buf
     */
    public static StringBuffer createTD(String style, int colIndex, StringBuffer buf,AdhocRptDataTO dto) {
        if (style != null) {
            buf.append("<td nowrap class=\"");
            buf.append(style);
            buf.append("\"");
        }

        if (colIndex < dto.getPresnUnitIndList().size()) {
            if (isIndicatorIn((String) dto.getPresnUnitIndList().get(colIndex), "NPD") || isBizarroNumeric(colIndex, dto)) {
                buf.append(" align=right");
            }
        }
        buf.append(">");
        return buf;
    }
    
    /**
     * 
     * @return
     */
    public static String beginExcelTable() {
        return "<table class=\"BACTable\">\n";
    }
    
    /**
     * Close a table tag
     * 
     * @return
     */
    public static String endExcelTable() {
        return "</table>\n";
    }
    
    /**
     * 
     * @param processor
     * @return
     */
    public static String renderBeginExcelRow(ARIAReportProcessor processor) {
    	// TODO Check the logic for max rows in Excel sheet
        return "<tr>";
    }
    
    /**
     * 
     * @param processor
     * @return
     */
    public static String renderEndExcelRow(ARIAReportProcessor processor) {
        return "</tr>\n";
    }
    
    /**
     * Add a table data "label" for the value
     * 
     * @param value
     * @return
     */
    public static String addExcelLabel(String value) {
        if (value == null) {
            value = "";
        } else {
            value = ARIAUtil.escape(value) + ":";
        }
        return "<td style=\"border-style: none; font-weight: bold;\">" + value + "</td>";
    }
    
    /**
     * Method will return the paging related buttons
     * @param paging
     * @return
     */
    public static String getPaging(ARIAPaging paging) {
        StringBuffer buf = new StringBuffer(100);
        buf.append("<table border=\"0\" width=\"99%\">");
        buf.append("<td align=\"right\">");

        // Goto first page button
        buf.append("<input type=\"button\"");
        if (paging.getCurrentPage() == 1) {
            buf.append(" disabled ");
        }
        buf.append("id=\"goto_first_page\" value=\"<<\" onclick=\"setDispatch('first');submit();\">");
        buf.append("&nbsp;\n");

        // Goto previous page button
        buf.append("<input type=\"button\"");
        if (paging.getCurrentPage() == 1) {
            buf.append(" disabled ");
        }
        buf.append("id=\"goto_previous_page\" value=\"<\" onclick=\"setDispatch('previous');submit();\">");
        buf.append("&nbsp;\n");

        // Goto selected page textfield
        buf.append("<span class=\"data\"> Page </span>");
        buf.append("<input name=\"gotoPage\" size=5 value=");
        buf.append(paging.getCurrentPage());
        if (paging.getCurrentPage() == paging.getTotalPages()) {
            buf.append(" disabled ");
        }
        buf.append("></span>");
        buf.append("<span class=\"data\"> of ");
        buf.append(paging.getTotalPages());
        buf.append("</span>");
        buf.append("&nbsp;\n");

        // Goto next page button
        buf.append("<input type=\"button\"");
        if (paging.getCurrentPage() == paging.getTotalPages()) {
            buf.append(" disabled ");
        }
        buf.append("id=\"goto_next_page\" value=\">\" onclick=\"setDispatch('next');submit();\">");
        buf.append("&nbsp;\n");

        // Goto last page button
        buf.append("<input type=\"button\"");
        if (paging.getCurrentPage() == paging.getTotalPages()) {
            buf.append(" disabled ");
        }
        buf.append("id=\"goto_last_page\" value=\">>\" onclick=\"setDispatch('last');submit();\">");
        buf.append("&nbsp;\n");

        // Goto selected page button
        buf.append("<input type=\"button\" value=\"View\" id=\"goto_page\" onclick=\"setDispatch('gotoPage');submit();\"");
        if (paging.getCurrentPage() == paging.getTotalPages()) {
            buf.append(" disabled ");
        }
        buf.append(">");
        buf.append("</input>");
        buf.append("&nbsp;\n");

        buf.append("</td></table>");
        return buf.toString();
    }
    
    /**
     * Static method will return the distinct key SQL
     * @param realSQL
     * @param dto
     * @return
     */
    public static String getKeySQL(String realSQL, AdhocRptDataTO dto){
		// Create a new string buffer to store the SQL
		StringBuffer sqlBuf = new StringBuffer();

		// Boolean
		boolean isFirst = true;
		
		// Loop through the list of columns
		for (int i = 0; i < dto.getColumnsAsOracleList().size(); i++) {
            String element = (String) dto.getColumnsAsOracleList().get(i);
            element = element.trim();
            if (!dto.getColumnsDataTypeList().get(i).toString().equalsIgnoreCase("C")) {
            	 String header = dto.getColumnsHeadersList().get(i).toString();
                 if (header.indexOf(".") != -1) {
                     header = header.replace('.', ' ');
                 } else if (header.equalsIgnoreCase("RTOTAL")) {
                     header = "Right Side Total";
                 } else if (dto.getColumnsHeadersList().get(i).toString().equalsIgnoreCase("LTOTAL")) {
                     header = "Left Side Total";
                 }
                 if (!isFirst){
                	 sqlBuf.append(",");
                 } else {
                	 sqlBuf.append("SELECT DISTINCT ");
                 }
                 sqlBuf.append("\"");
                 sqlBuf.append(header);
                 sqlBuf.append("\"");
                 isFirst = false;
            }
	    }
		
		if (sqlBuf.length()>0){
			 sqlBuf.append(" FROM (");
			 sqlBuf.append(realSQL);
			 sqlBuf.append(" )");
		}
		
		// Now form the order by clause
		int sortIndex = dto.getUserSortColumn()==null || "".equals(dto.getUserSortColumn())? 0:Integer.parseInt(dto.getUserSortColumn());
		boolean orderBy = false;
		if (!"C".equals((String) dto.getColumnsDataTypeList().get(sortIndex))) {
			sqlBuf.append(" ORDER BY ");
			sqlBuf.append("\"");
			orderBy = true;
			String sortedColName = dto.getColumnsHeadersList().get(sortIndex).toString();
			if (sortedColName.indexOf(".") != -1) {
				sortedColName = sortedColName.replace('.', ' ');
	        } else if (sortedColName.equalsIgnoreCase("RTOTAL")) {
	        	sortedColName = "Right Side Total";
	        } else if (dto.getColumnsHeadersList().get(sortIndex).toString().equalsIgnoreCase("LTOTAL")) {
	        	sortedColName = "Left Side Total";
	        }
	        sqlBuf.append(sortedColName);
	        sqlBuf.append("\"");
	        if (dto.getUserSortType()=='D'){
	        	sqlBuf.append(" DESC ");
	        } 
		}

		for (int i = 0; i < dto.getColumnsAsOracleList().size(); i++) {
            String element = (String) dto.getColumnsAsOracleList().get(i);
            element = element.trim();
            if (!dto.getColumnsDataTypeList().get(i).toString().equalsIgnoreCase("C")) {
            	if (sortIndex != i){
            		if (!orderBy){
            			sqlBuf.append(" ORDER BY ");
            			orderBy = true;
            		} else {
            			sqlBuf.append(",");
            		}
            		
            		String header = dto.getColumnsHeadersList().get(i).toString();
                    if (header.indexOf(".") != -1) {
                        header = header.replace('.', ' ');
                    } else if (header.equalsIgnoreCase("RTOTAL")) {
                        header = "Right Side Total";
                    } else if (dto.getColumnsHeadersList().get(i).toString().equalsIgnoreCase("LTOTAL")) {
                        header = "Left Side Total";
                    }

                    sqlBuf.append("\"");
                    sqlBuf.append(header);
                    sqlBuf.append("\"");
            	} 
            }
	    }
		
		return sqlBuf.toString();
	}
    
    /**
	 * Call method to render sub header row
	 * @param colspan
	 * @return
	 */
	public static String getSubHeader(AdhocRptDataTO dto, Connection connection,int section, Logger logger){
		StringBuffer buf = new StringBuffer(40);
		String subheader = null;
		if (dto.getDataKeyLvl()>1){
			subheader = getOptionalSubHeader2(dto, connection,section, logger);
		} else {
			subheader = getOptionalSubHeader1(dto, connection,section, logger);
		}
		
		if (!"".equals(subheader)){
			buf.append("&nbsp;");
			buf.append("<strong><font color='blue'>Subheader:</font></strong>");
			buf.append("&nbsp;");
	        buf.append("<a> ");
	        buf.append(subheader);
	        buf.append("</a>");
		}
		
		return buf.toString();
	}
	
	/**
     * Get the "optional sub-header"
     * 
     * @return
     */
    private static String getOptionalSubHeader1(AdhocRptDataTO dto, Connection connection,int section, Logger logger) {
        String SQL = "SELECT main_key1_line_header FROM rabc_presn_key1_header WHERE  presn_id =? AND webid =? AND exec_presn_seq_num = ?";
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = connection.prepareStatement(SQL);
            ps.setString(1, dto.getPresnIdAsString());
            ps.setString(2, dto.getWebId());
            ps.setInt(3, ((Integer) dto.getDistExecPresnSeqNumList().get(section)).intValue());

            rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getString(1) == null ? "" : rs.getString(1);
            }
            return "";
        } catch (Exception e) {
            logger.warn(logger.getClass().getName(), "getOptionalSubHeader1", e);
            return "";
        } finally {
            JDBCUtil.closeResultSet(rs);
            JDBCUtil.closePreparedStatement(ps);
        }
    }


    /**
     * Get the "optional sub-header"
     * 
     * @return
     */
    private static String getOptionalSubHeader2(AdhocRptDataTO dto, Connection connection,int section, Logger logger) {
        String SQL = "SELECT main_key2_line_header FROM rabc_presn_key2_header WHERE  presn_id =? AND webid =? AND exec_presn_seq_num = ?";
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = connection.prepareStatement(SQL);
            ps.setString(1, dto.getPresnIdAsString());
            ps.setString(2, dto.getWebId());
            ps.setInt(3, ((Integer) dto.getDistExecPresnSeqNumList().get(section)).intValue());

            rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getString(1) == null ? "" : rs.getString(1);
            }
            return "";
        } catch (Exception e) {
        	logger.warn(logger.getClass().getName(), "getOptionalSubHeader1", e);
            return "";
        } finally {
            JDBCUtil.closeResultSet(rs);
            JDBCUtil.closePreparedStatement(ps);
        }
    }
    
    /**
	 * This method returns the string for urlEncodedFormat.
	 * 
	 * @param s
	 * @return String
	 */
	private static String urlEncodedFormat(String s) {
		if (s == null) return null;
		try {
			return URLEncoder.encode(s, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			return null;
		}
	}
}
