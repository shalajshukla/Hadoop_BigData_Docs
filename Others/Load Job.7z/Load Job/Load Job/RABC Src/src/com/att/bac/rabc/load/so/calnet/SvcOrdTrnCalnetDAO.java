/* Created by Peter Foo (pf7941) on Nov 22, 2006.
 Copyright 2006-2008 AT&T Knowledge Ventures. All rights reserved. */

package com.att.bac.rabc.load.so.calnet;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.att.bac.rabc.load.calnet.CalnetDAO;
import com.att.bac.rabc.load.calnet.CalnetDTO;
import com.att.bac.rabc.load.calnet.CalnetException;


/**
 * Data access object for the RABC_SVC_ORD_TRN table.
 * @author pf7941
 *
 */
public class SvcOrdTrnCalnetDAO extends CalnetDAO {

	private static final String INSERT_SQL = "INSERT INTO RABC_SVC_ORD_TRN (RUN_DATE, DIVISION, CYCLE, AGENCY_ID, SVC_ORD_TYPE, SVC_ORD_STATUS, SVC_ORD_STATUS_CT) VALUES(?, ?, ?, ?, ?, ?, ?) ";

	/* (non-Javadoc)
	 * @see com.att.bac.rabc.load.calnet.CalnetDAO#setValues(java.sql.PreparedStatement, com.att.bac.rabc.load.calnet.CalnetDTO)
	 */
	public void setValues(PreparedStatement pstmt, CalnetDTO dataTransferObject) throws CalnetException {
		SvcOrdTrn svcOrdTrn = (SvcOrdTrn) dataTransferObject;
		try {
			pstmt.setDate(1, svcOrdTrn.getRunDate());
			pstmt.setString(2, svcOrdTrn.getDivision());
			pstmt.setInt(3, svcOrdTrn.getCycle());
			pstmt.setString(4, svcOrdTrn.getAgencyId());
			pstmt.setString(5, svcOrdTrn.getSvcOrdType());
			pstmt.setString(6, svcOrdTrn.getSvcOrdStatus());
			pstmt.setInt(7, svcOrdTrn.getSvcOrdStatusCt());
		}
		catch (SQLException e) {
			throw new CalnetException("Error occurred while setting values for PreparedStatement. SvcOrdTrn: "
					+ svcOrdTrn, e);
		}
	}

	/* (non-Javadoc)
	 * @see com.att.bac.rabc.load.calnet.CalnetDAO#getInsertSql()
	 */
	protected String getInsertSql() {
		return INSERT_SQL;
	}

}
