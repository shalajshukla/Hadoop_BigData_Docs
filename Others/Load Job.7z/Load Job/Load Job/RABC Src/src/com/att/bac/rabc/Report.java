/* 
 * Created by GB0741 on 06-Nov-07
 * Copyright 2008 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.sql.Date;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.Format;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;

/**
 * The Class Report is used to the creation of an excel report.
 * @author ankur_gupta07
 */
public class Report {
    
    /** The Constant MAX_ROWS. */
    public static final int MAX_ROWS = 65536;
    private final Format defaultDateFormat = new SimpleDateFormat("MM/dd/yyyy");
    private final Format defaultTimeFormat = new SimpleDateFormat("HH:mm:ss");
    private final Format defaultCurrencyFormat = NumberFormat.getCurrencyInstance();
    
    private String path = null;
    private String user = null;
    private BufferedWriter out = null;
    private int rows = 0;
    
    /**
	 * The Constructor.
	 * @param out
	 *            the out
	 */
    public Report(OutputStream out){
        this.out = new BufferedWriter(new OutputStreamWriter(out));
    }
    
    /**
	 * The Constructor.
	 */
    public Report() {
    	
    }
    
    /**
	 * Gets the user.
	 * @return the user
	 */
    public String getUser() {
        return user;
    }
    
    /**
	 * Sets the username.
	 * @param user
	 *            the username
	 */
    public void setUser(String user) {
        this.user = user;
    }
    
    /**
	 * Gets the path.
	 * @return the path
	 */
    public String getPath() {
        return path;
    }
    
    /**
	 * Create the Header of the report.
	 * @return  Report
	 * @throws IOException
	 *              IO exception
	 */
    public Report beginReport() throws IOException {
	    out.write("<html>\n");
	    out.write("<head>\n");
	    out.write("<style>\n");
	    out.write("\t.BACTable {}\n");
	    out.write("\t.BACTable TD {border: thin solid #000000; text-align: left;}\n");
	    out.write("\t.BACTable TH {border: thin solid #000000; text-align: center; background-color: lightgrey; font-weight: bold;}\n");
	    out.write("</style>\n");
	    out.write("</head>\n");
	    out.write("<body>\n");
	    out.write("<table class=\"BACTable\">\n");
	    return this;
	}
        
	/**
	 * To End the report.
	 * @return Report
	 * @throws IOException
	 *             IO exception
	 */
	public Report endReport() throws IOException {
	    out.write("</table>");
	    out.write("</body>");
	    out.write("</html>");
	    out.close();
	    return this;
	}

	/**
	 * To add a row to the report.
	 * @return  Report
	 * @throws IOException
	 *             the IO exception
	 */
	public Report beginRow() throws IOException {
	    rows++;
	    if(rows>MAX_ROWS){
	        throw new IOException("Maximum number of Excel rows <"+MAX_ROWS+"> exceeded");
	    }
	    out.write("<tr>");
	    return this;
	}
        
	/**
	 * To end a row.
	 * @return Report
	 * @throws IOException
	 *             the IO exception
	 */
	public Report endRow() throws IOException {
	    out.write("</tr>\n");
	    return this;
	}
	
	/**
	 * Adds the criteria to the row.
	 * @param label
	 *            the label to be added to the report 
	 * @param criteria
	 *            the int criteria is added to the report
	 * @return  Report
	 * @throws IOException
	 *             IO exception
	 */
	public Report addCriteriaRow(String label, int criteria) throws IOException {
	    beginRow().addLabel(label).addCriteria(criteria).endRow();
	    return this;
	}
	
	/**
	 * Adds the criteria to the row.
	 * @param label
	 *            the label to be added to the report 
	 * @param criteria
	 *            the string criteria is added to the report
	 * @return the Report
	 * @throws IOException
	 *             the IO exception
	 */
	public Report addCriteriaRow(String label, String criteria) throws IOException {
	    beginRow().addLabel(label).addCriteria(criteria).endRow();
	    return this;
	}
	
	/**
	 * Adds the criteria row.
	 * @param label
	 *            the label to be added to the report 
	 * @param criteria
	 *            the Date criteria is added to the report
	 * @return the Report
	 * @throws IOException
	 *             the IO exception
	 */
	public Report addCriteriaRow(String label, Date criteria) throws IOException {
	    beginRow().addLabel(label).addCriteria(criteria).endRow();
	    return this;
	}
	
	/**
	 * Adds a string to the report. 
	 * @param delimiter
	 *            the delimiter
	 * @param array
	 *            the array
	 * @return the report
	 * @throws IOException
	 *             the IO exception
	 */
	public Report addColumn(String[] array, String delimiter) throws IOException {
	    StringBuffer buf = new StringBuffer();
	    if(array!=null){
	        for(int i=0; i<array.length; i++){
	            buf.append(array[i]);
	            if(i<array.length-1) buf.append(delimiter);
	    	}
	    }
	    addColumn(buf.toString());
	    return this;
	}
	
	/**
	 * Adds the title to the report.
	 * @param title
	 *            the title
	 * @param colSpan
	 * 				Column span for the report title
	 * @return the report
	 * @throws IOException
	 *             the IO exception
	 */
	public Report addTitle(String title, int colSpan) throws IOException {
	    out.write("<td colspan=\"" + colSpan + "\" style=\"border-style: none; font-size: 20; font-weight: bold; color: #191970;\">" + escape(title) + "</td>");
	    return this;
	}
    
	/**
	 * Adds the sub title to the report.
	 * @param title
	 *            the title
	 * @return the report
	 * @throws IOException
	 *             the IO exception
	 */
	public Report addSubTitle(String title) throws IOException {
	    out.write("<td colspan=\"10\" style=\"border-style: none; font-size: 16; font-weight: bold; color: #191970;\">"+escape(title)+"</td>");
	    return this;
	}
	
	/**
	 * Adds the label to the report.
	 * @param value
	 *            the value
	 * @return the report
	 * @throws IOException
	 *             the IO exception
	 */
	public Report addLabel(String value) throws IOException {
	    out.write("<td style=\"border-style: none; text-align: right; font-weight: bold;\">"+escape(value)+":</td>");
	    return this;
	}
        
	/**
	 * Adds the criteria to the report..
	 * @param value
	 *            the value
	 * @return the report
	 * @throws IOException
	 *             the IO exception
	 */
	public Report addCriteria(String value) throws IOException {
	    out.write("<td colspan=\"10\" style=\"border-style: none;\">"+escape(value)+"</td>");
	    return this;
	}
    
	/**
	 * Writes a  String to the report  
	 * @param delimiter
	 *            the delimiter
	 * @param array
	 *            the array
	 * @return the report
	 * @throws IOException
	 *             the IO exception
	 */
	public Report addCriteria(String[] array, String delimiter) throws IOException {
	    StringBuffer buf = new StringBuffer();
	    if(array!=null){
	        for(int i=0; i<array.length; i++){
	            buf.append(array[i]);
	            if(i<array.length-1) buf.append(delimiter);
	    	}
	    }
	    addCriteria(buf.toString());
	    return this;
	}
	
	/**
	 * Writes an int to the report.
	 * @param value
	 *            the value
	 * @return the report
	 * @throws IOException
	 *             the IO exception
	 */
	public Report addCriteria(int value) throws IOException {
	    out.write("<td colspan=\"10\" style=\"border-style: none;\">"+value+"</td>");
	    return this;
	}
    
	/**
	 * Writes an Date to the report.
	 * @param value
	 *            the value
	 * @return the report
	 * @throws IOException
	 *             the IO exception
	 */
	public Report addCriteria(Date value) throws IOException {
	    if(value==null){
	        out.write("<td colspan=\"10\" style=\"border-style: none;\"></td>");
	    } else {
	        out.write("<td colspan=\"10\" style=\"border-style: none;\">"+defaultDateFormat.format(value)+"</td>");
	    }
	    return this;
	}
	
	/**
	 * Adds raw data to the report.
	 * @param value
	 *            the value
	 * @return the report
	 * @throws IOException
	 *             the IO exception
	 */
	public Report addRaw(String value) throws IOException {
	    out.write(value);
	    return this;
	}
        
	/**
	 * Adds the header to the report.
	 * @param value
	 *            the value
	 * @return the report
	 * @throws IOException
	 *             the IO exception
	 */
	public Report addHeader(String value) throws IOException {
	    out.write("<th>"+escape(value)+"</th>");
	    return this;
	}
        
	/**
	 * Writes a String to the Report.
	 * @param value
	 *            the value
	 * @param escape
	 *            the escape
	 * @return the report
	 * @throws IOException
	 *             the IO exception
	 */
	public Report addColumn(String value, boolean escape) throws IOException {
	    //For Showing null value columns in GREY Color.
	    if(value==null || value.equals("null") || value==""){
	        out.write("<td></td>"); //Nulls should be blank
	    } else {
	        out.write("<td>"+(escape?escape(value):value)+"</td>");	
	    }
	    return this;
	}
 
	/**
	 * Writes a Number coverted as Text to the Report.
	 * @param value  the value
	 * @return the report
	 * @throws IOException the IO exception
	 */
	public Report addNumberColumn(String value) throws IOException {
	    if(value==null || value.equals("null") ||  value==""){
	        out.write("<td></td>"); //Nulls should be blank
	    } else {
	        out.write("<td style='mso-number-format:\\@'>"+value+"</td>");
	    }
	    return this;
	}

	
	/**
	 * Writes a double to the Report.
	 * @param value
	 *            the value
	 * @return the report
	 * @throws IOException
	 *             the IO exception
	 */
	public Report addColumn(double value) throws IOException {
	    out.write("<td>"+value+"</td>");
	    return this;
	}
	
	/**
	 * Writes a int to the Report.
	 * @param value
	 *            the value
	 * @return the report
	 * @throws IOException
	 *             the IO exception
	 */
	public Report addColumn(int value) throws IOException {
	    out.write("<td>"+value+"</td>");
	    return this;
	}
	
	/**
	 * Adds the column to the report.
	 * @param value
	 *            the value
	 * @return the report
	 * @throws IOException
	 *             the IO exception
	 */
	public Report addColumn(String value) throws IOException {
	    //change done by AC6952 for checking null value String on sept-08-2005
	    if(value != null){
	        addColumn(value,true);
	    }else{
	        addColumn("null",true);
	    }
	    return this;
	}
	
	/**
	 * Adds the currency to the report.
	 * @param value
	 *            the value
	 * @return the report
	 * @throws IOException
	 *             the IO exception
	 */
	public Report addCurrency(double value) throws IOException {
	    addCurrency(new Double(value));
	    return this;
	}
	
	/** The number formats. */
	public HashMap numberFormats = new HashMap();
	
	/**
	 * Adds the number.
	 * @param value
	 *            the value
	 * @param format
	 *            the format
	 * @return the report
	 * @throws IOException
	 *             the IO exception
	 */
	public Report addNumber(Double value, String format) throws IOException {
	    if(value==null){
	        addColumn("null");
	    } else {
	        NumberFormat formatObject = (NumberFormat)numberFormats.get(format);
	        if(formatObject==null){
	            formatObject = new DecimalFormat(format);
	            numberFormats.put(format,formatObject);
	        }
	        addColumn(formatObject.format(value),false);
	    }
	    return this;
	    
	}
	
	/**
	 * Adds the currency.
	 * @param value
	 *            the value
	 * @return the report
	 * @throws IOException
	 *             the IO exception
	 */
	public Report addCurrency(Double value) throws IOException {
	    String s = value==null?"":defaultCurrencyFormat.format(value);
	    addColumn(s,false);
	    return this;
	}
	
	/**
	 * Adds the column.
	 * @param value
	 *            the value
	 * @return the report
	 * @throws IOException
	 *             the IO exception
	 */
	public Report addColumn(Double value) throws IOException {
	    addColumn(value==null?"null":value.toString(),false);
	    return this;
	}

	/**
	 * Adds the column.
	 * @param value
	 *            the value
	 * @return the report
	 * @throws IOException
	 *             the IO exception
	 */
	public Report addColumn(Integer value) throws IOException {
	    addColumn(value==null?"null":value.toString(),false);
	    return this;
	}

	/**
	 * Adds the column.
	 * @param value
	 *            the value
	 * @return the report
	 * @throws IOException
	 *             the IO exception
	 */
	public Report addColumn(Date value) throws IOException {
	    if(value==null){
	        addColumn("null");
	    } else {
	        addColumn(defaultDateFormat.format(value),false);
	    }
	    return this;
	}

	private HashMap dateFormats = new HashMap();
	
	/**
	 * Adds the column.
	 * @param value
	 *            the value
	 * @param format
	 *            the format
	 * @return the report
	 * @throws IOException
	 *             the IO exception
	 */
	public Report addColumn(Date value, String format) throws IOException {
	    if(value==null){
	        addColumn("null");
	    } else {
	        SimpleDateFormat formatObject = (SimpleDateFormat)dateFormats.get(format);
	        if(formatObject==null){
	            formatObject = new SimpleDateFormat(format);
	            dateFormats.put(format,formatObject);
	        }
	        addColumn(formatObject.format(value),false);
	    }
	    return this;
	}
	
	/**
	 * Adds the column.
	 * @param value
	 *            the value
	 * @return the report
	 * @throws IOException
	 *             the IO exception
	 */
	public Report addColumn(Timestamp value) throws IOException {
	    if(value==null){
	        addColumn("null");
	    } else {
	        addColumn(defaultDateFormat.format(value)+" "+defaultTimeFormat.format(value),false);
	    }
	    return this;
	}
    	
	/**
	 * Escape.
	 * @param string
	 *            the string
	 * @return the string
	 */
	public static String escape(String string) {
	    if(string==null) return null;
	    StringBuffer sb = new StringBuffer(string.length());
	    boolean lastWasBlankChar = false;
	    char c;
	    for (int i = 0; i < string.length(); i++) {
	        c = string.charAt(i);
	        if (c == ' ') {
	            if (lastWasBlankChar) {
	                lastWasBlankChar = false;
	                sb.append("&nbsp;");
	            } else {
	                lastWasBlankChar = true;
	                sb.append(' ');
	            }
	        } else {
	            lastWasBlankChar = false;
	            // HTML Special Chars
	            if (c == '"'){
	                sb.append("&quot;");
	            } else if (c == '&'){
	                sb.append("&amp;");
	            } else if (c == '<'){
	                sb.append("&lt;");
	            } else if (c == '>'){
	                sb.append("&gt;");
	            } else if (c == '\n'){
	                sb.append("<br/>");
	            } else {
	                int ci = 0xffff & c;
	                if (ci < 160){ //7 Bit
	                    sb.append(c);
	                } else { // unicode
	                    sb.append("&#");
	                    sb.append(new Integer(ci).toString());
	                    sb.append(';');
	                }
	            }
	        }
	    }
	    return sb.toString();
	}
	
	/**
	 * Write.
	 * @throws Exception
	 *             the exception
	 */
	public void write() throws Exception {		
	}

}
