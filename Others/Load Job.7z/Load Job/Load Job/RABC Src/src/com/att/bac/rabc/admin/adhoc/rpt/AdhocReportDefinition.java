/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.admin.adhoc.rpt;

import java.util.ArrayList;
import java.util.List;
/**
 * Module description: 
 * 
 * This is an adhoc report definition data object.
 *
 * @author Umesh Deole- UD7153
 */
public class AdhocReportDefinition {
	/*
	 * Variables to represent Adhoc Report definition page step 1 .
	 */
	private int presnId;
	private String presnDesc; 
	private String rptType;	
	private String[] alertGroup ;// For selected alert groups 
	private String dataNode;
	private String header1;
	private String header2;
	private String header3;
	private int nbrRptSections;
	private List reportTypeList = new ArrayList();
	private List alertGroupList = new ArrayList();// for multiple list box to populate all values 
	private List dataSourceList = new ArrayList();
	
	private String userDirectorySelected = "";
	private List userDirectoryList = new ArrayList();
	private String userDirectoryHidden ;
	private String userDirRadioOption ;
	private String userDirNameText ;
	private int presnSeqNumber ; 
	/*
	 * Variables to represent Adhoc Report definition page step 2 .
	 */
	private List sortList = new ArrayList();
	private List unitList = new ArrayList();
	private List reportLinkList = new ArrayList();
	private List mouseOverList = new ArrayList();
	
	private int currentSection;
	private boolean copyReport = false; 
	private String activeSectionStr = "" ; 
	private int sectionIndex = 0 ; 
	private String keyHeaderStr = "" ;
	private String keyHeaderStrHidden = "" ;
	private String sectionToEdit = "" ; 
	private List sectionList = new ArrayList();
	private String newSection = "N" ;
	
	// Objects for Step 2 & 3
	private List adhocReportStep2List = new ArrayList();  
	private List adhocReportStep3List = new ArrayList();  

	/**
	 * @return Returns the copyReport.
	 */
	public boolean isCopyReport() {
		return copyReport;
	}
	/**
	 * @param copyReport The copyReport to set.
	 */
	public void setCopyReport(boolean copyReport) {
		this.copyReport = copyReport;
	}
	/**
	 * @return Returns the mouseOverList.
	 */
	public List getMouseOverList() {
		return mouseOverList;
	}
	/**
	 * @param mouseOverList The mouseOverList to set.
	 */
	public void setMouseOverList(List mouseOverList) {
		this.mouseOverList = mouseOverList;
	}
	/**
	 * @return Returns the reportLinkList.
	 */
	public List getReportLinkList() {
		return reportLinkList;
	}
	/**
	 * @param reportLinkList The reportLinkList to set.
	 */
	public void setReportLinkList(List reportLinkList) {
		this.reportLinkList = reportLinkList;
	}
	/**
	 * @return Returns the presnId.
	 */
	public int getPresnId() {
		return presnId;
	}
	/**
	 * @param presnId The presnId to set.
	 */
	public void setPresnId(int presnId) {
		this.presnId = presnId;
	}
	/**
	 * @return Returns the currentSection.
	 */
	public int getCurrentSection() {
		return currentSection;
	}
	/**
	 * @param currentSection The currentSection to set.
	 */
	public void setCurrentSection(int currentSection) {
		this.currentSection = currentSection;
	}
	/**
	 * @return Returns the dataNode.
	 */
	public String getDataNode() {
		return dataNode;
	}
	/**
	 * @param dataNode The dataNode to set.
	 */
	public void setDataNode(String dataNode) {
		this.dataNode = dataNode;
	}
	/**
	 * @return Returns the header1.
	 */
	public String getHeader1() {
		return header1;
	}
	/**
	 * @param header1 The header1 to set.
	 */
	public void setHeader1(String header1) {
		this.header1 = header1;
	}
	/**
	 * @return Returns the header2.
	 */
	public String getHeader2() {
		return header2;
	}
	/**
	 * @param header2 The header2 to set.
	 */
	public void setHeader2(String header2) {
		this.header2 = header2;
	}
	/**
	 * @return Returns the header3.
	 */
	public String getHeader3() {
		return header3;
	}
	/**
	 * @param header3 The header3 to set.
	 */
	public void setHeader3(String header3) {
		this.header3 = header3;
	}
	/**
	 * @return Returns the nbrRptSections.
	 */
	public int getNbrRptSections() {
		return nbrRptSections;
	}
	/**
	 * @param nbrRptSections The nbrRptSections to set.
	 */
	public void setNbrRptSections(int nbrRptSections) {
		this.nbrRptSections = nbrRptSections;
	}
	/**
	 * @return Returns the presnDesc.
	 */
	public String getPresnDesc() {
		return presnDesc;
	}
	/**
	 * @param presnDesc The presnDesc to set.
	 */
	public void setPresnDesc(String presnDesc) {
		this.presnDesc = presnDesc;
	}
	/**
	 * @return Returns the rptType.
	 */
	public String getRptType() {
		return rptType;
	}
	/**
	 * @param rptType The rptType to set.
	 */
	public void setRptType(String rptType) {
		this.rptType = rptType;
	}
	
	/**
	 * @return Returns the adhocReportStep2List.
	 */
	public List getAdhocReportStep2List() {
		return adhocReportStep2List;
	}
	/**
	 * @return Returns the adhocReportStep3List.
	 */
	public List getAdhocReportStep3List() {
		return adhocReportStep3List;
	}
	/**
	 * @return Returns the alertGroupList.
	 */
	public List getAlertGroupList() {
		return alertGroupList;
	}
	
	/**
	 * @return Returns the dataSourceList.
	 */
	public List getDataSourceList() {
		return dataSourceList;
	}
	/**
	 * @return Returns the reportTypeList.
	 */
	public List getReportTypeList() {
		return reportTypeList;
	}
	
	public void addAdhocReportStep2List(AdhocReportStep2 adhocReportStep2) {
		this.adhocReportStep2List.add(adhocReportStep2);
	}

	public void addAdhocReportStep3List(AdhocReportStep3 adhocReportStep3) {
		this.adhocReportStep3List.add(adhocReportStep3);
	}
	/**
	 * @param alertGroupList The alertGroupList to set.
	 */
	public void setAlertGroupList(List alertGroupList) {
		this.alertGroupList = alertGroupList;
	}
	/**
	 * @param dataSourceList The dataSourceList to set.
	 */
	public void setDataSourceList(List dataSourceList) {
		this.dataSourceList = dataSourceList;
	}
	/**
	 * @param reportTypeList The reportTypeList to set.
	 */
	public void setReportTypeList(List reportTypeList) {
		this.reportTypeList = reportTypeList;
	}
	/**
	 * @return Returns the sortList.
	 */
	public List getSortList() {
		return sortList;
	}
	/**
	 * @param sortList The sortList to set.
	 */
	public void setSortList(List sortList) {
		this.sortList = sortList;
	}
	/**
	 * @return Returns the unitList.
	 */
	public List getUnitList() {
		return unitList;
	}
	/**
	 * @param unitList The unitList to set.
	 */
	public void setUnitList(List unitList) {
		this.unitList = unitList;
	}
	/**
	 * @return Returns the alertGroup.
	 */
	public String[] getAlertGroup() {
		return alertGroup;
	}
	/**
	 * @param alertGroup The alertGroup to set.
	 */
	public void setAlertGroup(String[] alertGroup) {
		this.alertGroup = alertGroup;
	}
	
	/**
	 * @return Returns the activeSectionStr.
	 */
	public String getActiveSectionStr() {
		return activeSectionStr;
	}
	/**
	 * @param activeSectionStr The activeSectionStr to set.
	 */
	public void setActiveSectionStr(String activeSectionStr) {
		this.activeSectionStr = activeSectionStr;
	}
	/**
	 * @return Returns the sectionIndex.
	 */
	public int getSectionIndex() {
		return sectionIndex;
	}
	/**
	 * @param sectionIndex The sectionIndex to set.
	 */
	public void setSectionIndex(int sectionIndex) {
		this.sectionIndex = sectionIndex;
	}
	/**
	 * @return Returns the keyHeaderStr.
	 */
	public String getKeyHeaderStr() {
		return keyHeaderStr;
	}
	/**
	 * @param keyHeaderStr The keyHeaderStr to set.
	 */
	public void setKeyHeaderStr(String keyHeaderStr) {
		this.keyHeaderStr = keyHeaderStr;
	}
	/**
	 * @return Returns the sectionList.
	 */
	public List getSectionList() {
		return sectionList;
	}
	/**
	 * @param sectionList The sectionList to set.
	 */
	public void setSectionList(List sectionList) {
		this.sectionList = sectionList;
	}
	/**
	 * @return Returns the sectionToEdit.
	 */
	public String getSectionToEdit() {
		return sectionToEdit;
	}
	/**
	 * @param sectionToEdit The sectionToEdit to set.
	 */
	public void setSectionToEdit(String sectionToEdit) {
		this.sectionToEdit = sectionToEdit;
	}
	/**
	 * @return Returns the newSection.
	 */
	public String getNewSection() {
		return newSection;
	}
	/**
	 * @param newSection The newSection to set.
	 */
	public void setNewSection(String newSection) {
		this.newSection = newSection;
	}
	/**
	 * @return Returns the keyHeaderStrHidden.
	 */
	public String getKeyHeaderStrHidden() {
		return keyHeaderStrHidden;
	}
	/**
	 * @param keyHeaderStrHidden The keyHeaderStrHidden to set.
	 */
	public void setKeyHeaderStrHidden(String keyHeaderStrHidden) {
		this.keyHeaderStrHidden = keyHeaderStrHidden;
	}
	
	/**
	 * @return Returns the UserDirectory.
	 */
	public String getUserDirectorySelected() {
		return userDirectorySelected;
	}
	
	/**
	 * @param userDirectory The userDirectory to set.
	 */
	public void setUserDirectorySelected(String userDirectorySelected) {
		this.userDirectorySelected = userDirectorySelected;
	}
	
	/**
	 * @return Returns the userDirectoryList.
	 */
	public List getUserDirectoryList() {
		return userDirectoryList;
	}
	
	/**
	 * @param userDirectoryList The userDirectoryList to set.
	 */
	public void setUserDirectoryList(List userDirectoryList) {
		this.userDirectoryList = userDirectoryList;
	}
	
	/**
	 * @return the userDirectoryHidden
	 */
	public String getUserDirectoryHidden() {
		return userDirectoryHidden;
	}
	/**
	 * @param userDirectoryHidden the userDirectoryHidden to set
	 */
	public void setUserDirectoryHidden(String userDirectoryHidden) {
		this.userDirectoryHidden = userDirectoryHidden;
	}
	/**
	 * @return the presnSeqNumber
	 */
	public int getPresnSeqNumber() {
		return presnSeqNumber;
	}
	/**
	 * @param presnSeqNumber the presnSeqNumber to set
	 */
	public void setPresnSeqNumber(int presnSeqNumber) {
		this.presnSeqNumber = presnSeqNumber;
	}
	/**
	 * @return the userDirRadioOption
	 */
	public String getUserDirRadioOption() {
		return userDirRadioOption;
	}
	/**
	 * @param userDirRadioOption the userDirRadioOption to set
	 */
	public void setUserDirRadioOption(String userDirRadioOption) {
		this.userDirRadioOption = userDirRadioOption;
	}
	/**
	 * @return the userDirNameText
	 */
	public String getUserDirNameText() {
		return userDirNameText;
	}
	/**
	 * @param userDirNameText the userDirNameText to set
	 */
	public void setUserDirNameText(String userDirNameText) {
		this.userDirNameText = userDirNameText;
	}
}
