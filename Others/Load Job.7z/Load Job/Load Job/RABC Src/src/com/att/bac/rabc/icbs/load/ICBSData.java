/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.icbs.load;

import java.util.Date;

import com.sbc.bac.rabc.load.HashCodeUtil;

/**
 * This is a data object representing entries in RABC_ICBS_INVOICE_READY table.
 * 
 * @author Shailesh Hemdev - SH8512
 */
public class ICBSData {
	private Date runDate;
	private String division;
	private String entityCd;
	private String trnType;
	private long dailyInputMsgCt;
	private double dailyInputMsgAmt;
	private long emsErrMsgCt;
	private double emsErrMsgAmt;
	private long rtnMsgCt;
	private double rtnMsgAmt;
	private long blgMsgCt;
	private double blgMsgAmt;
//	private long crudeOutMsgCt;
//	private double crudeOutMsgAmt;
	private long totalInputMsgCt;
	private double totalInputMsgAmt;
	private long totalPostedMsgCt;
	private double totalPostedMsgAmt;
	private long begMsgCt;
	private double begMsgAmt;
	private long masMsgCt;
	private double masMsgAmt;
	private long emsMsgCt;
	private double emsMsgAmt;
	private long reentMsgCt;
	private double reentMsgAmt;		
	public long getBegMsgCt() {
		return begMsgCt;
	}
	public void setBegMsgCt(long begMsgCt) {
		this.begMsgCt = begMsgCt;
	}
	public double getBegMsgAmt() {
		return begMsgAmt;
	}
	public void setBegMsgAmt(double begMsgAmt) {
		this.begMsgAmt = begMsgAmt;
	}
	public long getMasMsgCt() {
		return masMsgCt;
	}
	public void setMasMsgCt(long masMsgCt) {
		this.masMsgCt = masMsgCt;
	}
	public double getMasMsgAmt() {
		return masMsgAmt;
	}
	public void setMasMsgAmt(double masMsgAmt) {
		this.masMsgAmt = masMsgAmt;
	}
	public long getEmsMsgCt() {
		return emsMsgCt;
	}
	public void setEmsMsgCt(long emsMsgCt) {
		this.emsMsgCt = emsMsgCt;
	}
	public double getEmsMsgAmt() {
		return emsMsgAmt;
	}
	public void setEmsMsgAmt(double emsMsgAmt) {
		this.emsMsgAmt = emsMsgAmt;
	}
	public long getReentMsgCt() {
		return reentMsgCt;
	}
	public void setReentMsgCt(long reentMsgCt) {
		this.reentMsgCt = reentMsgCt;
	}
	public double getReentMsgAmt() {
		return reentMsgAmt;
	}
	public void setReentMsgAmt(double reentMsgAmt) {
		this.reentMsgAmt = reentMsgAmt;
	}
	/**
	 * @return Returns the division.
	 */
	public String getDivision() {
		return division;
	}
	/**
	 * @param division The division to set.
	 */
	public void setDivision(String division) {
		this.division = division;
	}
	/**
	 * @return Returns the entityCd.
	 */
	public String getEntityCd() {
		return entityCd;
	}
	/**
	 * @param entityCd The entityCd to set.
	 */
	public void setEntityCd(String entityCd) {
		this.entityCd = entityCd;
	}
	/**
	 * @return Returns the runDate.
	 */
	public Date getRunDate() {
		return runDate;
	}
	/**
	 * @param runDate The runDate to set.
	 */
	public void setRunDate(Date runDate) {
		this.runDate = runDate;
	}
	/**
	 * @return Returns the trnType.
	 */
	public String getTrnType() {
		return trnType;
	}
	/**
	 * @param trnType The trnType to set.
	 */
	public void setTrnType(String trnType) {
		this.trnType = trnType;
	}
	
	/**
	 * @return Returns the blgMsgAmt.
	 */
	public double getBlgMsgAmt() {
		return blgMsgAmt;
	}
	/**
	 * @param blgMsgAmt The blgMsgAmt to set.
	 */
	public void setBlgMsgAmt(double blgMsgAmt) {
		this.blgMsgAmt = blgMsgAmt;
	}
	/**
	 * @return Returns the blgMsgCt.
	 */
	public long getBlgMsgCt() {
		return blgMsgCt;
	}
	/**
	 * @param blgMsgCt The blgMsgCt to set.
	 */
	public void setBlgMsgCt(long blgMsgCt) {
		this.blgMsgCt = blgMsgCt;
	}

	/**
	 * @return Returns the dailyInputMsgAmt.
	 */
	public double getDailyInputMsgAmt() {
		return dailyInputMsgAmt;
	}
	/**
	 * @param dailyInputMsgAmt The dailyInputMsgAmt to set.
	 */
	public void setDailyInputMsgAmt(double dailyInputMsgAmt) {
		this.dailyInputMsgAmt = dailyInputMsgAmt;
	}
	/**
	 * @return Returns the dailyInputMsgCt.
	 */
	public long getDailyInputMsgCt() {
		return dailyInputMsgCt;
	}
	/**
	 * @param dailyInputMsgCt The dailyInputMsgCt to set.
	 */
	public void setDailyInputMsgCt(long dailyInputMsgCt) {
		this.dailyInputMsgCt = dailyInputMsgCt;
	}
	/**
	 * @return Returns the emsErrMsgAmt.
	 */
	public double getEmsErrMsgAmt() {
		return emsErrMsgAmt;
	}
	/**
	 * @param emsErrMsgAmt The emsErrMsgAmt to set.
	 */
	public void setEmsErrMsgAmt(double emsErrMsgAmt) {
		this.emsErrMsgAmt = emsErrMsgAmt;
	}
	/**
	 * @return Returns the emsErrMsgCt.
	 */
	public long getEmsErrMsgCt() {
		return emsErrMsgCt;
	}
	/**
	 * @param emsErrMsgCt The emsErrMsgCt to set.
	 */
	public void setEmsErrMsgCt(long emsErrMsgCt) {
		this.emsErrMsgCt = emsErrMsgCt;
	}
	/**
	 * @return Returns the rtnMsgAmt.
	 */
	public double getRtnMsgAmt() {
		return rtnMsgAmt;
	}
	/**
	 * @param rtnMsgAmt The rtnMsgAmt to set.
	 */
	public void setRtnMsgAmt(double rtnMsgAmt) {
		this.rtnMsgAmt = rtnMsgAmt;
	}
	/**
	 * @return Returns the rtnMsgCt.
	 */
	public long getRtnMsgCt() {
		return rtnMsgCt;
	}
	/**
	 * @param rtnMsgCt The rtnMsgCt to set.
	 */
	public void setRtnMsgCt(long rtnMsgCt) {
		this.rtnMsgCt = rtnMsgCt;
	}
	/**
	 * @return Returns the totalInputMsgAmt.
	 */
	public double getTotalInputMsgAmt() {
		return totalInputMsgAmt;
	}
	/**
	 * @param totalInputMsgAmt The totalInputMsgAmt to set.
	 */
	public void setTotalInputMsgAmt(double totalInputMsgAmt) {
		this.totalInputMsgAmt = totalInputMsgAmt;
	}
	/**
	 * @return Returns the totalInputMsgCt.
	 */
	public long getTotalInputMsgCt() {
		return totalInputMsgCt;
	}
	/**
	 * @param totalInputMsgCt The totalInputMsgCt to set.
	 */
	public void setTotalInputMsgCt(long totalInputMsgCt) {
		this.totalInputMsgCt = totalInputMsgCt;
	}
	/**
	 * @return Returns the totalPostedMsgAmt.
	 */
	public double getTotalPostedMsgAmt() {
		return totalPostedMsgAmt;
	}
	/**
	 * @param totalPostedMsgAmt The totalPostedMsgAmt to set.
	 */
	public void setTotalPostedMsgAmt(double totalPostedMsgAmt) {
		this.totalPostedMsgAmt = totalPostedMsgAmt;
	}
	/**
	 * @return Returns the totalPostedMsgCt.
	 */
	public long getTotalPostedMsgCt() {
		return totalPostedMsgCt;
	}
	/**
	 * @param totalPostedMsgCt The totalPostedMsgCt to set.
	 */
	public void setTotalPostedMsgCt(long totalPostedMsgCt) {
		this.totalPostedMsgCt = totalPostedMsgCt;
	}
	
	/**
	 * Equals method overridden for this object so that it can be stored in a hash map where the key 
	 * would be combination of the following 4 attributes:
	 * run date
	 * division
	 * entity code
	 * transaction type
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object o) {
		// Do a quick check for an identical object reference
	    if (this == o) {
	      return true;
	    }
	    if (!(o instanceof ICBSData)) {
	    	return false;
	    } else {
	    	if (((ICBSData)o).getRunDate().getTime() == this.getRunDate().getTime()
					&& ((ICBSData)o).getDivision().equalsIgnoreCase(this.getDivision())
					&& ((ICBSData)o).getEntityCd().equalsIgnoreCase(this.getEntityCd())	
					&& ((ICBSData)o).getTrnType().equalsIgnoreCase(this.getTrnType())
				) {
	    		return true;
			} else {
				return false;
			}
	    }
	}
	
	/**
	 * Hash code method overridden for this object to categorize this object in sets 
	 * so that the hash collections can search this object efficiently.
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		int hashCode = HashCodeUtil.SEED;
		hashCode = HashCodeUtil.hash( hashCode, this.getEntityCd());
	    return hashCode;
	}
}
