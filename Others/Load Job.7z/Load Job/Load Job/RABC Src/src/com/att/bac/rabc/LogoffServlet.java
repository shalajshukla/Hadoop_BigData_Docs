/*
 * LogoffServlet to reset all session parameters .. 
 * PT6471
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc;

import java.io.IOException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

public class LogoffServlet extends HttpServlet {
	private static final long serialVersionUID = 0L;
	public static Logger  logger = Logger.getLogger(LogoffServlet.class);
	
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String location = "";
       	String home = "";
        //Invalidate session
      	session.invalidate();
       	if (request.getParameter("mode") != null && request.getParameter("mode").trim().equals("HOME")) {
       		location = "authentication_link";
       	} else {
       		location = "authentication_logout";
       	}
       	//Get bac authentication URL
        try {
            Context context = (Context)new InitialContext().lookup("java:/comp/env");
            home = (String)context.lookup(location);
            System.out.println(home);
        } catch(Exception e){
        	logger.warn(e.getMessage(), e);
        }
        if(home==null){
            home = "https://controls.sbc.com/cfdocs/New_Authentication/Main_Application_lib/bac_logout.cfm";
        }
        response.sendRedirect(home);
        //Send redirect to home page
        //response.sendRedirect(home+"?uRedirect=true");
    }
}
