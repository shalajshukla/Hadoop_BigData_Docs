/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/

package com.att.bac.rabc.alerts.rpt;

import java.util.ArrayList;
import java.util.List;

/**
 * This class represents the data object that holds the attributes required
 * to represent the Alert Report (Control Alert Detail) page.
 * 
 * @author Nalina Pandiyan - NP5434
 */
public class AlertData {
	private String key1Label;
	private String key1Value;
	private String key1FullDesc;
	private String alertRuleLabel;
	private String alertRule;
	private Integer nbrOfRows;
	private Integer nbrOfColumns;
	private List columnNames = null; // String object
	private List rows = null;	// alertRow object

	/**
	 * Default constructor which sets the default key1Label, key1Value, alertRuleLabel, 
	 * alertRule, nbrOfRows, columnNames and rows attributes.
	 */
	public AlertData() {
		this.key1Label = "";
		this.key1Value = "";
		this.alertRuleLabel = "";
		this.alertRule = "";		
		this.nbrOfRows = new Integer(0);
		this.columnNames = new ArrayList();
		this.rows = new ArrayList();
	}
	
	/**
	 * @return Returns the key1Label.
	 */
	public String getKey1Label() {
		return key1Label;
	}
	/**
	 * @param key1Label The key1Label to set.
	 */
	public void setKey1Label(String key1Label) {
		this.key1Label = key1Label;
	}
	/**
	 * @return Returns the key1Value.
	 */
	public String getKey1Value() {
		return key1Value;
	}
	/**
	 * @param key1Value The key1Value to set.
	 */
	public void setKey1Value(String key1Value) {
		this.key1Value = key1Value;
	}

	/**
	 * @return Returns the key1FullDesc.
	 */
	public String getKey1FullDesc() {
		return key1FullDesc;
	}
	/**
	 * @param key1FullDesc The key1FullDesc to set.
	 */
	public void setKey1FullDesc(String key1FullDesc) {
		this.key1FullDesc = key1FullDesc;
	}
	
	/**
	 * @return Returns the columnNames.
	 */
	public List getColumnNames() {
		return columnNames;
	}
	/**
	 * @return Returns the rows.
	 */
	public List getRows() {
		return rows;
	}
	public void addColumnName(String colName) {
		this.columnNames.add(colName);
	}
	public void addAlertRow(AlertRow alertRow) {
		this.rows.add(alertRow);
	}
	/**
	 * @return Returns the alertRule.
	 */
	public String getAlertRule() {
		return alertRule;
	}

	/**
	 * @param alertRule The alertRule to set.
	 */
	public void setAlertRule(String alertRule) {
		this.alertRule = alertRule;
	}

	/**
	 * @return Returns the alertRuleLabel.
	 */
	public String getAlertRuleLabel() {
		return alertRuleLabel;
	}

	/**
	 * @param alertRuleLabel The alertRuleLabel to set.
	 */
	public void setAlertRuleLabel(String alertRuleLabel) {
		this.alertRuleLabel = alertRuleLabel;
	}

	/**
	 * @return Returns the nbrOfColumns.
	 */
	public Integer getNbrOfColumns() {
		return nbrOfColumns;
	}

	/**
	 * @param nbrOfColumns The nbrOfColumns to set.
	 */
	public void setNbrOfColumns(Integer nbrOfColumns) {
		this.nbrOfColumns = nbrOfColumns;
	}

	/**
	 * @return Returns the nbrOfRows.
	 */
	public Integer getNbrOfRows() {
		return nbrOfRows;
	}
	/**
	 * @param nbrOfRows The nbrOfRows to set.
	 */
	public void setNbrOfRows(Integer nbrOfRows) {
		this.nbrOfRows = nbrOfRows;
	}
}
