/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.rpt;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.ArrayList;
import java.text.MessageFormat;

import org.apache.log4j.Logger;

import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.RABCException;

/**
 * This is a DAO that performs SELECT, INSERT and UPDATE on RABC_ALERT_MSG table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class AlertMsgDAO {
	private static final Logger logger = Logger.getLogger(AlertMsgDAO.class);

	/**
	 * Returns the list of AlertMsg objects.
	 * 
	 * @param conn 
	 * @param failures
	 * @param args
	 * @param baseSQL
	 * @return List
	 */
	public List get(Connection conn, List failures, List args, String baseSQL) {
		List alertMsgList = null;		
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		
		try
		{
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("AlertMsgDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			alertMsgList = new ArrayList();
			while (rs.next()) {
				alertMsgList.add(buildAlertMsg(rs));
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return null;
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
		
		return alertMsgList;
	}

	/**
	 * Private method to build AlertMsg object and return it to caller.
	 * 
	 * @param rs
	 * @return AlertMsg
	 * @throws SQLException
	 */
	private AlertMsg buildAlertMsg(ResultSet rs) throws SQLException {
		AlertMsg alertMsg = new AlertMsg();
		String value = null;
		
		alertMsg.setMsgNum(rs.getInt("MSG_NUM"));
		alertMsg.setProcDate(rs.getDate("PROC_DATE"));
		alertMsg.setFileSeqNum(rs.getInt("FILE_SEQ_NUM"));
		alertMsg.setAlertRule(rs.getString("ALERT_RULE"));
		alertMsg.setAlertType(rs.getString("ALERT_TYPE"));
		alertMsg.setAlertTimeInd(rs.getString("ALERT_TIME_IND"));
		alertMsg.setAlertTimeValue(rs.getString("ALERT_TIME_VALUE"));
		alertMsg.setAlertKeyLvl(rs.getInt("ALERT_KEY_LVL"));
		
		value = rs.getString("ALERT_KEY1");
		alertMsg.setAlertKeyAt(0,(value==null?"":value));
		value = rs.getString("ALERT_KEY2");
		alertMsg.setAlertKeyAt(1,(value==null?"":value));
		value = rs.getString("ALERT_KEY3");
		alertMsg.setAlertKeyAt(2,(value==null?"":value));
		value = rs.getString("ALERT_KEY4");
		alertMsg.setAlertKeyAt(3,(value==null?"":value));
		value = rs.getString("ALERT_KEY5");
		alertMsg.setAlertKeyAt(4,(value==null?"":value));
		
		value = rs.getString("ALERT_DATA1");
		alertMsg.setAlertDataAt(0,(value==null?"":value));
		value = rs.getString("ALERT_DATA2");
		alertMsg.setAlertDataAt(1,(value==null?"":value));
		value = rs.getString("ALERT_DATA3");
		alertMsg.setAlertDataAt(2,(value==null?"":value));
		value = rs.getString("ALERT_DATA4");
		alertMsg.setAlertDataAt(3,(value==null?"":value));
		value = rs.getString("ALERT_DATA5");
		alertMsg.setAlertDataAt(4,(value==null?"":value));

		value = rs.getString("ALERT_ITEM");		
		alertMsg.setAlertItem((value==null?"":value));
		
		alertMsg.setAlertSuppInd(rs.getString("ALERT_SUPP_IND"));
		alertMsg.setAlertActual(rs.getDouble("ALERT_ACTUAL"));
		alertMsg.setAlertUnitInd(rs.getString("ALERT_UNIT_IND"));
		alertMsg.setIAlertData(rs.getDouble("ALERT_DATA"));
		alertMsg.setAlertPct(rs.getDouble("ALERT_PCT"));
		alertMsg.setAlertUserId(rs.getString("ALERT_USER_ID"));
		alertMsg.setAlertGrp(rs.getString("ALERT_GRP"));
		alertMsg.setAlertRevenue(rs.getDouble("ALERT_REVENUE"));
		alertMsg.setAlertStatus(rs.getString("ALERT_STATUS"));
		alertMsg.setAlertMsg(rs.getString("ALERT_MSG"));
		alertMsg.setAlertRootCatgyCd(rs.getString("ALERT_ROOT_CATGY_CD"));
		alertMsg.setAlertRootCause(rs.getString("ALERT_ROOT_CAUSE"));
		alertMsg.setAlertSevereLvlInd(rs.getString("ALERT_SEVERE_LVL_IND"));
		alertMsg.setAlertSysErrCd(rs.getInt("ALERT_SYS_ERR_CD"));
		alertMsg.setTimeStamp(rs.getDate("TIME_STAMP"));
		alertMsg.setAlertRuleRunDt(rs.getDate("ALERT_RULE_RUN_DT"));
		alertMsg.setAlertLostRevenue(rs.getDouble("ALERT_LOST_REVENUE"));
		return alertMsg;
	}

	/**
	 * Execute the insert or update statement on RABC_ALERT_MSG table.
	 * 
	 * @param conn
	 * @param failures
	 * @param args
	 * @param baseSQL
	 */
	public void executeUpdate(Connection conn, List failures, List args, String baseSQL) {
		int rowsUpdated = 0;
		Statement stmt = null;
		String sqlStmt = null;
		
		try
		{
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("AlertMsgDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rowsUpdated = stmt.executeUpdate(sqlStmt);
			logger.debug("SQL - Execution complete."+ String.valueOf(rowsUpdated) + "  rows updated");
			
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return;
		} finally {
			SQLHelper.closeStatement(stmt, failures, logger);
		}
	}

}
