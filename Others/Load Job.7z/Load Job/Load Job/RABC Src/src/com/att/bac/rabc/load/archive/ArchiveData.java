package com.att.bac.rabc.load.archive;


public class ArchiveData {
	private String tblName;
	private String division;
	private int numberOfDays;

	
	public String getDivision() {
		return division;
	}
	public void setDivision(String division) {
		this.division = division;
	}
	/**
	 * @return Returns the numberOfDays.
	 */
	public int getNumberOfDays() {
		return numberOfDays;
	}
	/**
	 * @param numberOfDays The numberOfDays to set.
	 */
	public void setNumberOfDays(int numberOfDays) {
		this.numberOfDays = numberOfDays;
	}
	/**
	 * @return Returns the tblName.
	 */
	public String getTblName() {
		return tblName;
	}
	/**
	 * @param tblName The tblName to set.
	 */
	public void setTblName(String tblName) {
		this.tblName = tblName;
	}
	

}
