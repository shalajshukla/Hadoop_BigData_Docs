/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.alerts.status;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.att.bac.rabc.DataTblDdlBean;
import com.att.bac.rabc.ExtrctTblDef;
import com.att.bac.rabc.PickList;
import com.att.bac.rabc.admin.alert.rule.AlertProc;
import com.att.bac.rabc.admin.alert.rule.AlertRule;
import com.att.bac.rabc.admin.alert.rule.AlertRuleDAO;

/**
 * This is a service class to provide the business logic. The methods in this class are called by the
 * action class. They do the required manipulation and returns the result to the action class. 
 * This paricular service class serves the business logic to generate data graph.
 * 
 * @author Shailesh Hemdev - SH8512
 */
public class DataGraphService extends GraphService {
	private static final String RABC_EXTRCT_SUMY_DATA = "RABC_EXTRCT_SUMY_DATA";
	private static final String RABC_CALC_ALERT_DATA = "RABC_CALC_ALERT_DATA";
	private static final String RABC_ALERT_HIST = "RABC_ALERT_HIST";
	private static final String DATA_GRAPH_TITLE = "Data Graph";
	
	private static final Logger logger = Logger.getLogger(DataGraphService.class);
	private static DataGraphService dataGraphService;
	
	/**
	 * Synchronized method to return the instance of DataGraphService object.
	 * It checks the existance of the instance of DataGraphService and if it does not exists
	 * then creates one instance of DataGraphService and returns otherwise it returns the
	 * existing instance of DataGraphService.
	 * 
	 * @return DataGraphService
	 */
	public static synchronized DataGraphService getDataGraphService(){
		if (dataGraphService == null){
			dataGraphService = new DataGraphService();
		}	
		return dataGraphService;
	}
	
	/**
	 * Method to return the title to be displayed on top of the graph page.
	 * 
	 * @param graphParameters
	 * @param percentGraphFlag
	 * @param connection
	 * @param failureList
	 * @return String
	 */
	protected String getTitle(GraphParameters graphParameters, String percentGraphFlag, Connection connection, List failureList){
		String title = null;
		
		if (graphParameters.getAlertrule()!=null || (graphParameters.getTableName()!=null && (RABC_EXTRCT_SUMY_DATA.equalsIgnoreCase(graphParameters.getTableName().trim().toUpperCase()) || RABC_CALC_ALERT_DATA.equalsIgnoreCase(graphParameters.getTableName().trim().toUpperCase()) || RABC_ALERT_HIST.equalsIgnoreCase(graphParameters.getTableName().trim().toUpperCase())))){
			String dataGraphAppend = "";
			if ("Y".equals(percentGraphFlag)){
				dataGraphAppend = DATA_GRAPH_TITLE;
			}
			
			if (graphParameters.getAlertrule()!=null){
				title = "Alert Rule: " + graphParameters.getAlertrule() + " " + dataGraphAppend;
			}else {
				title = getPage13Title(graphParameters,connection, failureList);
				if (title==null){
					title = DATA_GRAPH_TITLE;
				}else {
					title = title + dataGraphAppend;
				}
			}
		}else {
			title = DATA_GRAPH_TITLE;
		}
		
		return title;
	}
	
	/**
	 * Method to return a string having the criterias selected to generate the graph.
	 * 
	 * @param graphParameters
	 * @param connection
	 * @param failureList
	 * @return String
	 */
	protected String getSelectionCriteria(GraphParameters graphParameters, Connection connection, List failureList, String region){
		String selectionCriteria = "";
		
		if (graphParameters.getStartDate()!=null){
			selectionCriteria = selectionCriteria + "Start Date:" + graphParameters.getStartDate().toString() + ",";
		}
		if (graphParameters.getProcDate()!=null){
			selectionCriteria = selectionCriteria + "End Date:" + graphParameters.getProcDate().toString();
		}

		/*
		 * Get the key names
		 */
		List keyNameList = getKeyNames(connection, failureList, graphParameters);
		
		if (graphParameters.getKey1()!=null){
			if ( graphParameters.getKey1colname()!=null && graphParameters.getKey1colname().indexOf("=")==-1 ){
				if (!"".equals(graphParameters.getKey1colname())){
					String key1Value = graphParameters.getKey1();
					if (key1Value.indexOf("to_date")!=-1) {
						key1Value = key1Value.substring(key1Value.indexOf("to_date")+9, key1Value.indexOf(",")-1);
					}else if (key1Value.indexOf("'")!=-1){
						key1Value = key1Value.substring((key1Value.indexOf("'")+1),key1Value.length()-1);
					}
					selectionCriteria = selectionCriteria + "," + graphParameters.getKey1colname() + " (Key 1):" + key1Value+ "";
				}else {
					String keyName = (String)keyNameList.get(0);
					if (!"".equals(keyName)){
						selectionCriteria = selectionCriteria + "," + keyName + " (Key 1):" + graphParameters.getKey1() + "";
					}else {
						selectionCriteria = selectionCriteria + ",Key 1: " + graphParameters.getKey1() + "";
					}
				}
			}else {
				String keyName = (String)keyNameList.get(0);
				if (!"".equals(keyName)){
					selectionCriteria = selectionCriteria + "," + keyName + " (Key 1):" + graphParameters.getKey1() + "";
				}else {
					selectionCriteria = selectionCriteria + ",Key 1: " + graphParameters.getKey1() + "";
				}
			}
		}
		
		if (graphParameters.getKey2()!=null){
			String tempKey2=graphParameters.getKey2();
			if (tempKey2.indexOf("=")!=-1){
				if (tempKey2.indexOf("to_date")!=-1) {
					tempKey2 = tempKey2.substring(0, tempKey2.indexOf(","));
				}
				int lenKey2complete = tempKey2.trim().length();
				String key2Field = tempKey2.substring(2,tempKey2.indexOf("="));
				String key2Value = tempKey2.substring((tempKey2.indexOf("=")+1),lenKey2complete);
				if (tempKey2.indexOf("'")!=-1){
					key2Value = tempKey2.substring((tempKey2.indexOf("'")+1),lenKey2complete-1);
				}
				selectionCriteria = selectionCriteria + "," + key2Field + " (Key 2):"+ key2Value + "";
			} else {
				String keyName = (String)keyNameList.get(1);
				if (!"".equals(keyName)){
					selectionCriteria = selectionCriteria + "," + keyName + " (Key 2):" + graphParameters.getKey2() + "";
				}else {
					selectionCriteria = selectionCriteria + ",Key 2: " + graphParameters.getKey2() + "";
				}
			}
		}
		if (graphParameters.getKey3()!=null){
			String tempKey3=graphParameters.getKey3();
			if (tempKey3.indexOf("=")!=-1){
				if (tempKey3.indexOf("to_date")!=-1) {
					tempKey3 = tempKey3.substring(0, tempKey3.indexOf(","));
				}
				int lenKey3complete = tempKey3.trim().length();
				String key3Field = tempKey3.substring(2,tempKey3.indexOf("="));
				String key3Value = tempKey3.substring((tempKey3.indexOf("=")+1),lenKey3complete);
				if (tempKey3.indexOf("'")!=-1){
					key3Value = tempKey3.substring((tempKey3.indexOf("'")+1),lenKey3complete-1);
				}
				selectionCriteria = selectionCriteria + "," + key3Field + " (Key 3):"+ key3Value + "";
			} else {
				String keyName = (String)keyNameList.get(2);
				if (!"".equals(keyName)){
					selectionCriteria = selectionCriteria + "," + keyName + " (Key 3):" + graphParameters.getKey3() + "";
				}else {
					selectionCriteria = selectionCriteria + ",Key 3: " + graphParameters.getKey3() + "";
				}
			}
		}
		if (graphParameters.getKey4()!=null){
			String tempKey4=graphParameters.getKey4();
			if (tempKey4.indexOf("=")!=-1){
				if (tempKey4.indexOf("to_date")!=-1) {
					tempKey4 = tempKey4.substring(0, tempKey4.indexOf(","));
				}
				int lenKey4complete = tempKey4.trim().length();
				String key4Field = tempKey4.substring(2,tempKey4.indexOf("="));
				String key4Value = tempKey4.substring((tempKey4.indexOf("=")+1),lenKey4complete);
				if (tempKey4.indexOf("'")!=-1){
					key4Value = tempKey4.substring((tempKey4.indexOf("'")+1),lenKey4complete-1);
				}
				selectionCriteria = selectionCriteria + "," + key4Field + " (Key 4):"+ key4Value + "";
			} else {
				String keyName = (String)keyNameList.get(3);
				if (!"".equals(keyName)){
					selectionCriteria = selectionCriteria + "," + keyName + " (Key 4):" + graphParameters.getKey4() + "";
				}else {
					selectionCriteria = selectionCriteria + ",Key 4: " + graphParameters.getKey4() + "";
				}
			}
		}
		if (graphParameters.getKey5()!=null){
			String tempKey5=graphParameters.getKey5();
			if (tempKey5.indexOf("=")!=-1){
				if (tempKey5.indexOf("to_date")!=-1) {
					tempKey5 = tempKey5.substring(0, tempKey5.indexOf(","));
				}
				int lenKey5complete = tempKey5.trim().length();
				String key5Field = tempKey5.substring(2,tempKey5.indexOf("="));
				String key5Value = tempKey5.substring((tempKey5.indexOf("=")+1),lenKey5complete);
				if (tempKey5.indexOf("'")!=-1){
					key5Value = tempKey5.substring((tempKey5.indexOf("'")+1),lenKey5complete-1);
				}
				selectionCriteria = selectionCriteria + "," + key5Field + " (Key 5):"+ key5Value + "";
			} else {
				String keyName = (String)keyNameList.get(4);
				if (!"".equals(keyName)){
					selectionCriteria = selectionCriteria + "," + keyName + " (Key 5):" + graphParameters.getKey5() + "";
				}else {
					selectionCriteria = selectionCriteria + ",Key 5: " + graphParameters.getKey5() + "";
				}
			}
		}
		
		if (graphParameters.getAlertItem()!=null && !"".equals(graphParameters.getAlertItem())){
			selectionCriteria = selectionCriteria + ",Alert Item: " + graphParameters.getAlertItem() + "";
		}
		
		if ("D".equals(graphParameters.getAlertTimeInd())){
			selectionCriteria = selectionCriteria + ", Week Day:   " + dayOfWeek(Integer.parseInt(graphParameters.getAlertTimeValue()));
		}else if ("B".equals(graphParameters.getAlertTimeInd())){
			if ("MW".equals(region)){
				selectionCriteria = selectionCriteria + ", Process Group:  " + graphParameters.getAlertTimeValue();
			}else {
				selectionCriteria = selectionCriteria + ", Bill Cycle:  " + graphParameters.getAlertTimeValue();
			}
		}
		
		return selectionCriteria;
	}
	
	/**
	 * Utility method to return the day of the week.
	 * 
	 * @param day
	 * @return String
	 */
	private String dayOfWeek(int day){
		String dayOfWeek = "";
		
		switch (day){
			case 1:
				dayOfWeek = "Sunday";
				break;
			case 2:
				dayOfWeek = "Monday";
				break;
			case 3:
				dayOfWeek = "Tuesday";
				break;
			case 4:
				dayOfWeek = "Wednesday";
				break;
			case 5:
				dayOfWeek = "Thursday";
				break;
			case 6:
				dayOfWeek = "Friday";
				break;
			case 7:
				dayOfWeek = "Saturday";
				break;
		}
		return dayOfWeek;
	}
	
	/**
	 * Method to return the list of DataGraphData onjects and it called from the action. 
	 * It builds the list of DataGraphData objects taking into consideration the 6 scenarios. 
	 * The data would be obtained from the rabc_extrct_sumy_data table for which the 
	 * dataGraphSQLService will be used. There are 6 methods to build the argumen list for the 6 conditions.
	 * 
	 * @param graphParameters
	 * @param connection
	 * @param failureList
	 * @param region
	 * @return List
	 */
	protected List buildDataGraph(GraphParameters graphParameters, Connection connection, List failureList, String region){
		List dataGraphDataList = null;
		List extrctSumyDataList = null;
		/*
		 * Use the DataGraphSQLService to perform the SQL queries
		 */
		DataGraphSQLService dataGraphSQLService = new DataGraphSQLService(graphParameters);
		GraphSQLService graphSQLService = new GraphSQLService(graphParameters);
		this.setGraphSQLService(graphSQLService);
		
		AlertRule alertRule = null;
		List extrctTblDefList = null;
		
		graphParameters.setAlertRuleFlag("N");

		if (graphParameters.getAlertrule()!=null) {
			List alertRuleArgs = new ArrayList();
			alertRuleArgs.add(graphParameters.getAlertrule());
			alertRule = this.chkAlertRule(connection,failureList,alertRuleArgs);
			
			if (alertRule !=null) {
				graphParameters.setAlertRule(alertRule);
				
				graphParameters.setPartiRefId(alertRule.getPartiRefId());
				extrctTblDefList = dataGraphSQLService.getExtrctTblDefList(graphParameters,connection, failureList);

				if (extrctTblDefList!=null) {
					if (!extrctTblDefList.isEmpty()) {
						ExtrctTblDef extrctTblDef = (ExtrctTblDef)extrctTblDefList.get(0);
						graphParameters.setExtrctTblDef(extrctTblDef);
						graphParameters = this.getAlertRuleFlag(graphParameters,extrctTblDefList.size(),extrctTblDef.getExtrctDataLeftCt(),extrctTblDef.getExtrctDataRightCt());
					}
				}
			}
		} 

		if (alertRule!=null && "Y".equals(graphParameters.getAlertRuleFlag())){
			if ("Y".equals(alertRule.getDataExtrctInd())) {
				extrctTblDefList = dataGraphSQLService.getExtrctTblDefList(graphParameters,connection, failureList);
				if (extrctTblDefList!=null){
					if (!extrctTblDefList.isEmpty()){
						ExtrctTblDef extrctTblDef = (ExtrctTblDef)extrctTblDefList.get(0);
						graphParameters.setExtrctTblDef(extrctTblDef);
						
						if (extrctTblDef.getExtrctDataLeftCt()>0){
							extrctSumyDataList = buildDataGraphCondition1(graphParameters, connection, failureList, extrctTblDef,dataGraphSQLService, region);
							
							/*
							 * Logic for buttons
							 */
							if (extrctTblDef.getExtrctDataLeftCt()>1 || extrctTblDef.getExtrctDataRightCt()>1){
								if (graphParameters.getColumnValue()!=null){
									graphParameters.addButton(new PickList("extrct_ind_item","Track Items"));
									graphParameters.setYaxisTitle(graphParameters.getColumnValue());
								}else {
									graphParameters.setYaxisTitle("Input Data");
								}
								
								/*
								 * Condition for left count
								 */
								if (extrctTblDef.getExtrctDataLeftCt()>1 ){
									for (int k=1;k<=2;k++){
										String t_data_name = "extrct_data" + k + "_name";
										String t_column_name = "extrct_data" + k;
										
										if (graphParameters.getColumnValue()!=null && t_column_name.equals(graphParameters.getColumnValue())){
											graphParameters.setYaxisTitle(graphParameters.getColumnName());
										}else {
											String t_string = "";
											if (k==1){
												t_string = extrctTblDef.getExtrctData1Name();
											}else {
												t_string = extrctTblDef.getExtrctData2Name();
											}
											
											String t_string1 = t_string.replace(' ' ,'_');
											graphParameters.addButton(new PickList(t_string,t_column_name, t_string1,"extrct_ind_item_"+k));
										}
									}
								}
								
								/*
								 * Condition for right count
								 */
								if (extrctTblDef.getExtrctDataRightCt()>1 ){
									// Get the table names
									List tableNames = dataGraphSQLService.getTableNameList(connection, alertRule.getAlertRule(),failureList);
									
									int toCt = extrctTblDef.getExtrctDataLeftCt() + extrctTblDef.getExtrctDataRightCt();
									int fromCt = extrctTblDef.getExtrctDataLeftCt() + 1;
									for (int k=fromCt;k<=toCt;k++){
										String t_data_name = "extrct_data" + k + "_name";
										String t_column_name = "extrct_data" + k;
										
										if (graphParameters.getColumnValue()!=null && t_column_name.equals(graphParameters.getColumnValue())){
											graphParameters.setYaxisTitle(graphParameters.getColumnName());
										}else {
											String t_string = "";
											switch (k){
												case 1:
													t_string = extrctTblDef.getExtrctData1Name();
													if (!tableNames.isEmpty()){
														String tblNm = (String) tableNames.get(0);
														if (tblNm.indexOf("_PREV")!=-1){
															t_string += " - Previous";
														}
													}
													break;
												case 2:
													t_string = extrctTblDef.getExtrctData2Name();
													if (!tableNames.isEmpty()){
														String tblNm = (String) tableNames.get(1);
														if (tblNm.indexOf("_PREV")!=-1){
															t_string += " - Previous";
														}
													}
													break;
												case 3:
													t_string = extrctTblDef.getExtrctData3Name();
													if (!tableNames.isEmpty()){
														String tblNm = (String) tableNames.get(2);
														if (tblNm.indexOf("_PREV")!=-1){
															t_string += " - Previous";
														}
													}
													break;
												case 4:
													t_string = extrctTblDef.getExtrctData4Name();
													if (!tableNames.isEmpty()){
														String tblNm = (String) tableNames.get(3);
														if (tblNm.indexOf("_PREV")!=-1){
															t_string += " - Previous";
														}
													}
													break;
												case 5:
													t_string = extrctTblDef.getExtrctData5Name();
													if (!tableNames.isEmpty()){
														String tblNm = (String) tableNames.get(4);
														if (tblNm.indexOf("_PREV")!=-1){
															t_string += " - Previous";
														}
													}
													break;
												case 6:
													t_string = extrctTblDef.getExtrctData6Name();
													if (!tableNames.isEmpty()){
														String tblNm = (String) tableNames.get(5);
														if (tblNm.indexOf("_PREV")!=-1){
															t_string += " - Previous";
														}
													}
													break;
												case 7:
													t_string = extrctTblDef.getExtrctData7Name();
													if (!tableNames.isEmpty()){
														String tblNm = (String) tableNames.get(6);
														if (tblNm.indexOf("_PREV")!=-1){
															t_string += " - Previous";
														}
													}
													break;
												case 8:
													t_string = extrctTblDef.getExtrctData8Name();
													if (!tableNames.isEmpty()){
														String tblNm = (String) tableNames.get(7);
														if (tblNm.indexOf("_PREV")!=-1){
															t_string += " - Previous";
														}
													}
													break;
												case 9:
													t_string = extrctTblDef.getExtrctData9Name();
													if (!tableNames.isEmpty()){
														String tblNm = (String) tableNames.get(8);
														if (tblNm.indexOf("_PREV")!=-1){
															t_string += " - Previous";
														}
													}
													break;
												case 10:
													t_string = extrctTblDef.getExtrctData10Name();
													if (!tableNames.isEmpty()){
														String tblNm = (String) tableNames.get(9);
														if (tblNm.indexOf("_PREV")!=-1){
															t_string += " - Previous";
														}
													}
													break;
												case 11:
													t_string = extrctTblDef.getExtrctData11Name();
													if (!tableNames.isEmpty()){
														String tblNm = (String) tableNames.get(10);
														if (tblNm.indexOf("_PREV")!=-1){
															t_string += " - Previous";
														}
													}
													break;
												case 12:
													t_string = extrctTblDef.getExtrctData12Name();
													if (!tableNames.isEmpty()){
														String tblNm = (String) tableNames.get(11);
														if (tblNm.indexOf("_PREV")!=-1){
															t_string += " - Previous";
														}
													}
													break;
												case 13:
													t_string = extrctTblDef.getExtrctData13Name();
													if (!tableNames.isEmpty()){
														String tblNm = (String) tableNames.get(12);
														if (tblNm.indexOf("_PREV")!=-1){
															t_string += " - Previous";
														}
													}
													break;
												case 14:
													t_string = extrctTblDef.getExtrctData14Name();
													if (!tableNames.isEmpty()){
														String tblNm = (String) tableNames.get(13);
														if (tblNm.indexOf("_PREV")!=-1){
															t_string += " - Previous";
														}
													}
													break;
												case 15:
													t_string = extrctTblDef.getExtrctData15Name();
													if (!tableNames.isEmpty()){
														String tblNm = (String) tableNames.get(14);
														if (tblNm.indexOf("_PREV")!=-1){
															t_string += " - Previous";
														}
													}
													break;
												default:
													t_string = extrctTblDef.getExtrctData1Name();
													if (!tableNames.isEmpty()){
														String tblNm = (String) tableNames.get(0);
														if (tblNm.indexOf("_PREV")!=-1){
															t_string += " - Previous";
														}
													}
													break;
											}

											String t_string1 = t_string.replace(' ' ,'_');
											graphParameters.addButton(new PickList(t_string,t_column_name, t_string,"extrct_ind_item_"+k));
										}
									}
								}
							}
						}else if (extrctTblDef.getExtrctDataLeftCt()==0){
							if (graphParameters.getAlertItem()!=null){
								extrctSumyDataList = buildDataGraphCondition2(graphParameters, connection, failureList, extrctTblDef, dataGraphSQLService, region);
							}else {
								graphParameters.setError("Error : Alert Item cannot be null when the left data count is 0 or null");
							}
						}else {
							graphParameters.setError("Error : Valid data could not be obtained in table RABC_EXTRCT_TBL_DEF for Parti Ref Id :" + graphParameters.getPartiRefId());
						}
					} else {
						graphParameters.setError("Error : No data obtained in table RABC_EXTRCT_TBL_DEF for Parti Ref Id :" + graphParameters.getPartiRefId());
					}
				} else {
					graphParameters.setError("Error : No data obtained in table RABC_EXTRCT_TBL_DEF for Parti Ref Id :" + graphParameters.getPartiRefId());
				}
			} else if ("N".equals(alertRule.getDataExtrctInd())) {
				extrctSumyDataList = buildDataGraphCondition3and4(graphParameters,connection,failureList,dataGraphSQLService,region);
			}
		} else if (alertRule==null || "N".equals(graphParameters.getAlertRuleFlag())) {
			if (graphParameters.getTableName()!=null && graphParameters.getItemDDlName()!=null){
				extrctSumyDataList = buildDataGraphCondition5and6(graphParameters,connection,failureList, dataGraphSQLService,region);
			}else {
				graphParameters.setError("Error: If AlertRule not present/passed, TableName & ItemDDLName should have valid values");
			}
		} 
		
		/*
		 * Depending on the query result list build the data graph list
		 */
		if (extrctSumyDataList!=null){
			dataGraphDataList=buildDataGraphData(extrctSumyDataList,graphParameters);
		}
		
		return dataGraphDataList;
	}
	
	/**
	 * Private method to return the list of ExtrctSumyData objects for the following condition:
	 * alertRule neq "" and data_extrct_ind eq "Y" and extrctDataLeftCt > 0 - condition 1.
	 * 
	 * Internally it calls the DataGraphSQLService to get the list of ExtrctSumyData objects.
	 * 
	 * @param graphParameters
	 * @param connection
	 * @param failureList
	 * @param extrctTblDef
	 * @param dataGraphSQLService
	 * @param region
	 * @return List
	 */
	private List buildDataGraphCondition1(GraphParameters graphParameters, Connection connection, List failureList, ExtrctTblDef extrctTblDef, DataGraphSQLService dataGraphSQLService, String region){
		List extrctSumyDataList = null;
		String extrctRightData="";
		String sumExtrctData = null;

		if (extrctTblDef.getExtrctDataRightCt()==1){
			extrctRightData = "extrct_data" + (extrctTblDef.getExtrctDataLeftCt() + extrctTblDef.getExtrctDataRightCt());
		} else if (extrctTblDef.getExtrctDataLeftCt()==1 && extrctTblDef.getExtrctDataRightCt()>1){
			extrctRightData = "extrct_data" + (extrctTblDef.getExtrctDataLeftCt() + extrctTblDef.getExtrctDataRightCt() + 1);
		}else if (extrctTblDef.getExtrctDataLeftCt()>1 && extrctTblDef.getExtrctDataRightCt()>1){
			extrctRightData = "extrct_data" + (extrctTblDef.getExtrctDataLeftCt() + extrctTblDef.getExtrctDataRightCt() + 2);
		}

		if (graphParameters.getColumnValue()!=null){
			sumExtrctData = "sum(" + graphParameters.getColumnValue() + ")";
		}else {
			for (int i=1;i<=extrctTblDef.getExtrctDataLeftCt();i++){
				if (sumExtrctData==null){
					sumExtrctData = "sum(extrct_data" + i + ")";
				}else {
					sumExtrctData =sumExtrctData + " + sum(extrct_data" + i + ")";
				}
			}
		}
		
		List args1 = new ArrayList();
		args1.add(extrctRightData);
		extrctSumyDataList = dataGraphSQLService.getQrySumExtrData(connection,failureList,1,sumExtrctData,args1,region);
		
		return extrctSumyDataList;
	}
	
	/**
	 * Private method to return the list of ExtrctSumyData objects for the following condition:
	 * alertRule neq "" and data_extrct_ind eq "Y" and extrctDataLeftCt = 0 - condition 2.
	 * 
	 * Internally it calls the DataGraphSQLService to get the list of ExtrctSumyData objects.
	 * 
	 * @param graphParameters
	 * @param connection
	 * @param failureList
	 * @param extrctTblDef
	 * @param dataGraphSQLService
	 * @param region
	 * @return List
	 */
	private List buildDataGraphCondition2(GraphParameters graphParameters, Connection connection, List failureList, ExtrctTblDef extrctTblDef, DataGraphSQLService dataGraphSQLService, String region){
		List extrctSumyDataList = null;
		String extrctDataItem ="";
		String sumExtrctData = null;

		for (int i=1;i<=15;i++){
			switch (i){
				case 1:
					if (graphParameters.getAlertItem().equalsIgnoreCase(extrctTblDef.getExtrctData1Name())){
						extrctDataItem = extrctTblDef.getExtrctData1Name().substring(1,12);
						sumExtrctData = "sum(" + extrctDataItem + ")";
						break;
					}
				case 2:
					if (graphParameters.getAlertItem().equalsIgnoreCase(extrctTblDef.getExtrctData2Name())){
						extrctDataItem = extrctTblDef.getExtrctData2Name().substring(1,12);
						sumExtrctData = "sum(" + extrctDataItem + ")";
						break;
					}
				case 3:
					if (graphParameters.getAlertItem().equalsIgnoreCase(extrctTblDef.getExtrctData3Name())){
						extrctDataItem = extrctTblDef.getExtrctData3Name().substring(1,12);
						sumExtrctData = "sum(" + extrctDataItem + ")";
						break;
					}
				case 4:
					if (graphParameters.getAlertItem().equalsIgnoreCase(extrctTblDef.getExtrctData4Name())){
						extrctDataItem = extrctTblDef.getExtrctData4Name().substring(1,12);
						sumExtrctData = "sum(" + extrctDataItem + ")";
						break;
					}
				case 5:
					if (graphParameters.getAlertItem().equalsIgnoreCase(extrctTblDef.getExtrctData5Name())){
						extrctDataItem = extrctTblDef.getExtrctData5Name().substring(1,12);
						sumExtrctData = "sum(" + extrctDataItem + ")";
						break;
					}
				case 6:
					if (graphParameters.getAlertItem().equalsIgnoreCase(extrctTblDef.getExtrctData6Name())){
						extrctDataItem = extrctTblDef.getExtrctData6Name().substring(1,12);
						sumExtrctData = "sum(" + extrctDataItem + ")";
						break;
					}
				case 7:
					if (graphParameters.getAlertItem().equalsIgnoreCase(extrctTblDef.getExtrctData7Name())){
						extrctDataItem = extrctTblDef.getExtrctData7Name().substring(1,12);
						sumExtrctData = "sum(" + extrctDataItem + ")";
						break;
					}
				case 8:
					if (graphParameters.getAlertItem().equalsIgnoreCase(extrctTblDef.getExtrctData8Name())){
						extrctDataItem = extrctTblDef.getExtrctData8Name().substring(1,12);
						sumExtrctData = "sum(" + extrctDataItem + ")";
						break;
					}
				case 9:
					if (graphParameters.getAlertItem().equalsIgnoreCase(extrctTblDef.getExtrctData9Name())){
						extrctDataItem = extrctTblDef.getExtrctData9Name().substring(1,12);
						sumExtrctData = "sum(" + extrctDataItem + ")";
						break;
					}
				case 10:
					if (graphParameters.getAlertItem().equalsIgnoreCase(extrctTblDef.getExtrctData10Name())){
						extrctDataItem = extrctTblDef.getExtrctData10Name().substring(1,12);
						sumExtrctData = "sum(" + extrctDataItem + ")";
						break;
					}
				case 11:
					if (graphParameters.getAlertItem().equalsIgnoreCase(extrctTblDef.getExtrctData11Name())){
						extrctDataItem = extrctTblDef.getExtrctData11Name().substring(1,12);
						sumExtrctData = "sum(" + extrctDataItem + ")";
						break;
					}
				case 12:
					if (graphParameters.getAlertItem().equalsIgnoreCase(extrctTblDef.getExtrctData12Name())){
						extrctDataItem = extrctTblDef.getExtrctData12Name().substring(1,12);
						sumExtrctData = "sum(" + extrctDataItem + ")";
						break;
					}
				case 13:
					if (graphParameters.getAlertItem().equalsIgnoreCase(extrctTblDef.getExtrctData14Name())){
						extrctDataItem = extrctTblDef.getExtrctData14Name().substring(1,12);
						sumExtrctData = "sum(" + extrctDataItem + ")";
						break;
					}
				case 14:
					if (graphParameters.getAlertItem().equalsIgnoreCase(extrctTblDef.getExtrctData14Name())){
						extrctDataItem = extrctTblDef.getExtrctData14Name().substring(1,12);
						sumExtrctData = "sum(" + extrctDataItem + ")";
						break;
					}
				case 15:
					if (graphParameters.getAlertItem().equalsIgnoreCase(extrctTblDef.getExtrctData15Name())){
						extrctDataItem = extrctTblDef.getExtrctData15Name().substring(1,12);
						sumExtrctData = "sum(" + extrctDataItem + ")";
						break;
					}
				default:
					if (graphParameters.getAlertItem().equalsIgnoreCase(extrctTblDef.getExtrctData1Name())){
						extrctDataItem = extrctTblDef.getExtrctData1Name().substring(1,12);
						sumExtrctData = "sum(" + extrctDataItem + ")";
						break;
					}
			}
		}

		if (sumExtrctData!=null){
			List args1 = new ArrayList();
			args1.add(sumExtrctData);
			extrctSumyDataList = dataGraphSQLService.getQrySumExtrData(connection,failureList,2,sumExtrctData,args1,region);
		}

		return extrctSumyDataList;
	}
	
	/**
	 * Private method to return the list of ExtrctSumyData objects for the following condition:
	 * alertRule neq "" and data_extrct_ind eq "N" and
	 * (alertTimeInd = 'B' or 'AB' && dataTblDdlBean.getTblBillRndDdlMon()!=null 
	 * && dataTblDdlBean.getTblBillRndDdlYear()!=null) - condition 3.
	 * "OR"
	 * alertRule neq "" and data_extrct_ind eq "N" and
	 * !(alertTimeInd = 'B' or 'AB' && dataTblDdlBean.getTblBillRndDdlMon()!=null 
	 * && dataTblDdlBean.getTblBillRndDdlYear()!=null) - condition 4.
	 * 
	 * Internally it calls the DataGraphSQLService to get the list of ExtrctSumyData objects.
	 * 
	 * @param graphParameters
	 * @param connection
	 * @param failureList
	 * @param dataGraphSQLService
	 * @param region
	 * @return List
	 */
	private List buildDataGraphCondition3and4(GraphParameters graphParameters, Connection connection, List failureList, DataGraphSQLService dataGraphSQLService, String region){
		List alertProcList = null;
		List extrctSumyDataList = null;
		String sumExtrctData = null;
		String alertProcTable = null;
		
		alertProcList = dataGraphSQLService.checkAlertProcTbl(graphParameters,connection,failureList);
		if (alertProcList!=null){
			if (!alertProcList.isEmpty()){
				AlertProc alertProc = (AlertProc)alertProcList.get(0);
				
				DataTblDdlBean dataTblDdlBean = dataGraphSQLService.qryDataColumn(alertProc.getAlertProcTbl(),graphParameters,region);
				
				if (dataTblDdlBean!=null){
					sumExtrctData = dataTblDdlBean.getTblDdlName() ;
					
					if (("B".equals(graphParameters.getAlertTimeInd()) || "AB".equals(graphParameters.getAlertTimeInd())) && dataTblDdlBean.getTblBillRndDdlMon()!=null && dataTblDdlBean.getTblBillRndDdlYear()!=null){
						List args1 = new ArrayList();
						args1.add(dataTblDdlBean.getAlertProcTbl());
						args1.add(alertProc.getAlertItemDdlName());
						
						extrctSumyDataList = dataGraphSQLService.getQrySumExtrData(connection,failureList,3,sumExtrctData,args1,region);
					} else {
						List args1 = new ArrayList();
						args1.add(dataTblDdlBean.getAlertProcTbl());
						args1.add(alertProc.getAlertItemDdlName());
						
						extrctSumyDataList=dataGraphSQLService.getQrySumExtrData(connection,failureList,4,sumExtrctData,args1,region);
					}
				} else {
					graphParameters.setError("Error : No data in table RABC_DATA_TBL_DDL for alert proc table: " + alertProc.getAlertProcTbl());
				}
			}else {
				graphParameters.setError("Error : No data in table RABC_ALERT_PROC for alert_rule: " + graphParameters.getAlertrule() + " and alert_item: " + graphParameters.getAlertItem());
			}
		}else {
			graphParameters.setError("Error : No data in table RABC_ALERT_PROC for alert_rule: " + graphParameters.getAlertrule() + " and alert_item: " + graphParameters.getAlertItem());
		}

		return extrctSumyDataList;
	}
	
	/**
	 * Private method to return the list of ExtrctSumyData objects for the following condition:
	 * alertRule= "" or alertRuleFlag = "N" and alertTimeInd = null - condition 5.
	 * "OR"
	 * alertRule= "" or alertRuleFlag = "N" and 
	 * (alertTimeInd = 'B' or 'M' or 'AB' and dataTblDdlBean.getTblBillRndDdlMon()!=null 
	 * and dataTblDdlBean.getTblBillRndDdlYear()!=null) - condition 6.
	 * 
	 * Internally it calls the DataGraphSQLService to get the list of ExtrctSumyData objects.
	 * 
	 * @param graphParameters
	 * @param connection
	 * @param failureList
	 * @param dataGraphSQLService
	 * @param region
	 * @return List
	 */
	private List buildDataGraphCondition5and6(GraphParameters graphParameters, Connection connection, List failureList, DataGraphSQLService dataGraphSQLService, String region){
		List extrctSumyDataList = null;
		String sumExtrctData = null;
		String alertProcTable = null;
		
		graphParameters.setError(null);
		DataTblDdlBean dataTblDdlBean = dataGraphSQLService.qryDataColumn(graphParameters.getTableName(),graphParameters,region);
		
		if (dataTblDdlBean!=null){
			sumExtrctData = dataTblDdlBean.getTblDdlName() ;
			
			if (graphParameters.getAlertTimeInd()==null){
				List args1 = new ArrayList();
				args1.add(dataTblDdlBean.getAlertProcTbl());
				args1.add(dataTblDdlBean.getTblDdlName());
				
				extrctSumyDataList = dataGraphSQLService.getQrySumExtrData(connection,failureList,6,sumExtrctData,args1,region);
			}else if (("B".equals(graphParameters.getAlertTimeInd()) || "AB".equals(graphParameters.getAlertTimeInd())|| "M".equals(graphParameters.getAlertTimeInd())) && dataTblDdlBean.getTblBillRndDdlMon()!=null && dataTblDdlBean.getTblBillRndDdlYear()!=null ){
				List args1 = new ArrayList();
				args1.add(dataTblDdlBean.getAlertProcTbl());
				args1.add(dataTblDdlBean.getTblDdlName());
				
				extrctSumyDataList = dataGraphSQLService.getQrySumExtrData(connection,failureList,5,sumExtrctData,args1,region);
			} else {
				List args1 = new ArrayList();
				args1.add(dataTblDdlBean.getAlertProcTbl());
				args1.add(dataTblDdlBean.getTblDdlName());
				
				extrctSumyDataList = dataGraphSQLService.getQrySumExtrData(connection,failureList,6,sumExtrctData,args1,region);
			}
			
			if (extrctSumyDataList==null){
				graphParameters.setError("No data found");
			}else {
				if (extrctSumyDataList.isEmpty()){
					graphParameters.setError("No data found");
				}
			}
		} else {
			graphParameters.setError("Error : No data in table RABC_DATA_TBL_DDL for table: " + graphParameters.getTableName());
		}

		return extrctSumyDataList;
	}
	
	/**
	 * Private method to return the list of DataGrapgData objects. 
	 * It uses the extrctSumyDataList (containing ExtrctSumyData objects) & build the list of DataGraphData objects. 
	 * Each such object would be eventually rendered by the DataSetProducer.
	 * 
	 * @param extrctSumyDataList
	 * @param graphParameters
	 * @return List
	 */
	private List buildDataGraphData(List extrctSumyDataList,GraphParameters graphParameters){
		List dataGraphDataList = new ArrayList();
		
		if (!extrctSumyDataList.isEmpty()) {
			int extrctSumyDataListSize = extrctSumyDataList.size();
			
			for (int i=0;i<extrctSumyDataListSize;i++){
				ExtrctSumyData extrctSumyData = (ExtrctSumyData)extrctSumyDataList.get(i);
				DataGraphData dataGraphData = new DataGraphData();

				if (graphParameters.getFileSeqNum()!=null){
					dataGraphData.setFileSeqNum(extrctSumyData.getFileSeqNum());
				}else {
					if (extrctSumyData.getProcDate()==null){
						dataGraphData.setProcDateString(extrctSumyData.getProcDateString());
					}else {
						dataGraphData.setProcDate(extrctSumyData.getProcDate());
					}
				}
				
				if ("B".equals(graphParameters.getAlertTimeInd()) || "AB".equals(graphParameters.getAlertTimeInd())){
					dataGraphData.setAlertTrendTime(extrctSumyData.getAlertTrendTime());
				}
				
				dataGraphData.setSumData(extrctSumyData.getSumExtrctData());
				dataGraphData.setTotalData(extrctSumyData.getSumTotalData());
				
				dataGraphDataList.add(dataGraphData);
			}
		}
			
		return dataGraphDataList;
	}
	
	/**
	 * Method to return the title to be displayed on top of the graph page when the 
	 * graph page is generated from Page 13.
	 * 
	 * @param graphParameters
	 * @param connection
	 * @param failureList
	 * @return String
	 */
	protected String getPage13Title(GraphParameters graphParameters, Connection connection,List failureList ){
		if (graphParameters.getAlertRule()==null){
			if (graphParameters.getPresnId()!=-1){
				List args1 = new ArrayList();
				args1.add(Integer.toString(graphParameters.getPresnId()));
				
				AlertRuleDAO alertRuleDAO = new AlertRuleDAO();
				List alertRuleList = alertRuleDAO.get(connection,failureList,args1,GraphSQLService.alertRuleQuery);
				
				if (alertRuleList!=null){
					if (!alertRuleList.isEmpty()){
						AlertRule alertRule = (AlertRule)alertRuleList.get(0);
						return "Alert Rule: " + alertRule.getAlertRule();
					}
				}
			}
		}else {
			return "Alert Rule: " + graphParameters.getAlertRule().getAlertRule();
		}
		
		return null;
	}
}
