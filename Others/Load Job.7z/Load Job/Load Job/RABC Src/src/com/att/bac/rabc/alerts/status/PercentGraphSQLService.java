/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.alerts.status;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.att.bac.rabc.DateUtil;
import com.att.bac.rabc.MyDate;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;

/**
 * This is a sql service class to execute the sql queries pertaining to the percent graph and to 
 * return the result to the service class.
 * 
 * @author Shailesh Hemdev - SH8512
 */
public class PercentGraphSQLService extends GraphSQLService {
	private static final Logger logger = Logger.getLogger(PercentGraphSQLService.class);
	
	private static final String qryAlertData = "Select  alert_data, {0} proc_date,file_seq_num,parti_ref_id,alert_item, "
											+ " alert_key1,alert_key2,alert_key3,alert_key4,alert_key5, "
											+ " alert_trend_time,ALERT_VARIANCE_PCT,"
											+ " ALERT_VARIANCE_DATA,ALERT_ACTUAL_DATA from rabc_calc_alert_data "
											+ " where {1} {2} ";
	
	private static final String qrySumExtrData = "Select EXTRCT_DATA1, EXTRCT_DATA2,EXTRCT_DATA3, EXTRCT_DATA4, "
												+ " EXTRCT_DATA5,EXTRCT_DATA6,EXTRCT_DATA7,EXTRCT_DATA8, "
												+ " EXTRCT_DATA9,EXTRCT_DATA10,EXTRCT_DATA11,EXTRCT_DATA12,"
												+ " EXTRCT_DATA13, EXTRCT_DATA14, EXTRCT_DATA15, PROC_DATE, "
												+ " FILE_SEQ_NUM from rabc_extrct_sumy_data where parti_ref_id= {0} "
												+ " {1} ";
	
	/**
	 * Constructor for the PercentGraphSQLService class.
	 * 
	 * @param graphParameters
	 */
	public PercentGraphSQLService(GraphParameters graphParameters){
		super(graphParameters);
	}
	
	/**
	 * Method to return the list of arguments to execute the sql statement 
	 * to get the list of CalcAlertData objects.
	 * 
	 * @return List
	 */
	private List buildQryAlertDataArguments(){
		List args = new ArrayList();
		StringBuffer whereClause = new StringBuffer();
		StringBuffer orderByClause = new StringBuffer();
		
		if ("B".equals(this.getGraphParameters().getAlertTimeInd())|| "M".equals(this.getGraphParameters().getAlertTimeInd()) || "AB".equals(this.getGraphParameters().getAlertTimeInd())){
			StringBuffer selectClause = new StringBuffer();
			selectClause.append("to_char(");
			selectClause.append(this.getGraphParameters().getExtractDateName());
			selectClause.append(",'mm/yyyy')");
			args.add(selectClause.toString());
		}else {
			args.add(this.getGraphParameters().getExtractDateName());
		}
		
		
		if (this.getGraphParameters().getStartDate()!=null){
			whereClause.append(this.getGraphParameters().getExtractDateName());
			whereClause.append(">=to_date('");
			whereClause.append(this.getGraphParameters().getStartDate());
			whereClause.append("','MM/dd/yyyy')");
			whereClause.append(" and ");
		}
		if (this.getGraphParameters().getProcDate()!=null){
			whereClause.append(this.getGraphParameters().getExtractDateName());
			whereClause.append("<= to_date('");
			whereClause.append(this.getGraphParameters().getProcDate());
			whereClause.append("','MM/dd/yyyy')");
			whereClause.append(" and ");
		}
		
		whereClause.append("parti_ref_id");
		whereClause.append("=");
		whereClause.append(this.getGraphParameters().getPartiRefId());

		whereClause.append(" and ");
		whereClause.append("alert_item");
		whereClause.append("='");
		whereClause.append(this.getGraphParameters().getAlertItem());
		whereClause.append("'");
		
		if (this.getGraphParameters().getAlertTimeValue()!=null){
			if ("B".equals(this.getGraphParameters().getAlertTimeInd()) || "D".equals(this.getGraphParameters().getAlertTimeInd())){
				whereClause.append(" and ");
				whereClause.append("alert_trend_time");
				whereClause.append("='");
				whereClause.append(this.getGraphParameters().getAlertTimeValue());
				whereClause.append("'");
			}
		}
		
		if (this.getGraphParameters().getKey1()!=null){
			whereClause.append(" and alert_key1 = '");
			whereClause.append(this.getGraphParameters().getKey1());
			whereClause.append("'");
		}
		if (this.getGraphParameters().getKey2()!=null){
			whereClause.append(" and alert_key2 = '");
			whereClause.append(this.getGraphParameters().getKey2());
			whereClause.append("'");
		}
		if (this.getGraphParameters().getKey3()!=null){
			whereClause.append(" and alert_key3 = '");
			whereClause.append(this.getGraphParameters().getKey3());
			whereClause.append("'");
		}
		if (this.getGraphParameters().getKey4()!=null){
			whereClause.append(" and alert_key4 = '");
			whereClause.append(this.getGraphParameters().getKey4());
			whereClause.append("'");
		}
		if (this.getGraphParameters().getKey5()!=null){
			whereClause.append(" and alert_key5 = '");
			whereClause.append(this.getGraphParameters().getKey5());
			whereClause.append("'");
		}
		
		args.add(whereClause.toString());
		
		orderByClause.append(" order by ");
		if (this.getGraphParameters().getFileSeqNum()!=null){
			orderByClause.append(" file_seq_num ");
		}else {
			if ("B".equals(this.getGraphParameters().getAlertTimeInd()) || "M".equals(this.getGraphParameters().getAlertTimeInd())  || "AB".equals(this.getGraphParameters().getAlertTimeInd())){
				orderByClause.append(" to_date(proc_date,'mm/yyyy') ");
			} else {
				orderByClause.append(" proc_date ");
			}
		}
		
		args.add(orderByClause.toString());
		
		return args;
	}
	
	/**
	 * Method to execute statement on RABC_CALC_ALERT_DATA table 
	 * and returns the list of CalcAlertData objects.
	 * 
	 * @param conn
	 * @param failures
	 * @return List
	 */
	public List getQryAlertData(Connection conn, List failures) {
		List calcAlertDataList = null;
		CalcAlertData calcAlertData = null;
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		String baseSQL = qryAlertData;
		List args = buildQryAlertDataArguments();
		
		try
		{
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("qryAlertData - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			if (rs != null) {
				calcAlertDataList = new ArrayList();
				while (rs.next()) {
					calcAlertDataList.add(buildCalcAlertData(rs));
				}
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return null;
		} finally {
			SQLHelper.closeStatement(stmt, failures, logger);
			SQLHelper.closeResultSet(rs, failures, logger);
		}
		
		return calcAlertDataList;
	}
	
	/**
	 * Private method to return the CalcAlertData object. It accepts the result set and set the
	 * attributes of CalcAlertData object by getting the values from the result set.
	 * 
	 * @param rs
	 * @return CalcAlertData
	 * @throws SQLException
	 */
	private CalcAlertData buildCalcAlertData(ResultSet rs) throws SQLException {
		CalcAlertData calcAlertData = new CalcAlertData();

		calcAlertData.setAlertData(rs.getDouble("ALERT_DATA"));
		
		if ("B".equals(this.getGraphParameters().getAlertTimeInd())|| "M".equals(this.getGraphParameters().getAlertTimeInd()) || "AB".equals(this.getGraphParameters().getAlertTimeInd())){
			calcAlertData.setProcMonth(rs.getString("PROC_DATE"));
		}else {
			Date timeStamp = rs.getDate("PROC_DATE");
			if (timeStamp != null) {
				calcAlertData.setProcDate(new MyDate(timeStamp));
			}
		}

		if (rs.getString("FILE_SEQ_NUM")!=null){
			if (!"".equals(rs.getString("FILE_SEQ_NUM").trim())){
				calcAlertData.setFileSeqNum(rs.getInt("FILE_SEQ_NUM"));
			}
		}		
		
		calcAlertData.setPartiRefId(rs.getInt("PARTI_REF_ID"));
		calcAlertData.setAlertItem(rs.getString("ALERT_ITEM"));
		calcAlertData.setAlertKey1(rs.getString("ALERT_KEY1"));
		calcAlertData.setAlertKey2(rs.getString("ALERT_KEY2"));
		calcAlertData.setAlertKey3(rs.getString("ALERT_KEY3"));
		calcAlertData.setAlertKey4(rs.getString("ALERT_KEY4"));
		calcAlertData.setAlertKey5(rs.getString("ALERT_KEY5"));
		calcAlertData.setAlertTrendTime(rs.getString("ALERT_TREND_TIME"));
		calcAlertData.setAlertVariancePct(rs.getDouble("ALERT_VARIANCE_PCT"));
		calcAlertData.setAlertVariance(rs.getDouble("ALERT_VARIANCE_DATA"));
		calcAlertData.setAlertActualData(rs.getDouble("ALERT_ACTUAL_DATA"));

		return calcAlertData;
	}
	
	/**
	 * Method to return the list of arguments to execute the sql statement 
	 * to get the list of ExtrctSumyData objects.
	 * 
	 * @param calcAlertData
	 * @return List
	 */
	private List buildQrySumExtrDataArguments(CalcAlertData calcAlertData){
		List args = new ArrayList();
		StringBuffer whereClause = new StringBuffer();
		StringBuffer orderByClause = new StringBuffer();
		
		args.add("" + this.getGraphParameters().getPartiRefId());

		MyDate endDate = null;
		if ("B".equals(this.getGraphParameters().getAlertTimeInd()) || "M".equals(this.getGraphParameters().getAlertTimeInd()) || "AB".equals(this.getGraphParameters().getAlertTimeInd())){
			String procDateDay = "01";
            String procDateMonth = calcAlertData.getProcMonth().substring(0,2);
            String procDateYear = calcAlertData.getProcMonth().substring(3,calcAlertData.getProcMonth().length());
            
            Date newEndDate = DateUtil.getDate(Integer.parseInt(procDateYear),Integer.parseInt(procDateMonth),Integer.parseInt(procDateDay));
            endDate = new MyDate(DateUtil.getLastDayOfMonth(newEndDate));          
		}else {
			endDate = calcAlertData.getProcDate();
		}
		
		if ("B".equals(this.getGraphParameters().getAlertTimeInd()) || "M".equals(this.getGraphParameters().getAlertTimeInd()) || "AB".equals(this.getGraphParameters().getAlertTimeInd())){
			whereClause.append(" and ");
			whereClause.append(this.getGraphParameters().getExtractDateName());
			whereClause.append(">= to_date('");
			whereClause.append(calcAlertData.getProcMonth());
			whereClause.append("','mm/yyyy')");
			whereClause.append(" and ");
			whereClause.append(this.getGraphParameters().getExtractDateName());
			whereClause.append("<= to_date('");
			whereClause.append(endDate.toString());
			whereClause.append("','MM/dd/yyyy')");
		} else {
			whereClause.append(" and ");
			whereClause.append(this.getGraphParameters().getExtractDateName());
			whereClause.append("= to_date('");
			whereClause.append(calcAlertData.getProcDate().toString());
			whereClause.append("','MM/dd/yyyy')");
		}
		
		if (calcAlertData.getFileSeqNum()!=-1){
			whereClause.append(" and file_seq_num = ");
			whereClause.append(calcAlertData.getFileSeqNum());
		}
		
		whereClause.append(" and extrct_item= '");
		whereClause.append(calcAlertData.getAlertItem());
		whereClause.append("'");
		
		if ("B".equals(this.getGraphParameters().getAlertTimeInd()) || "D".equals(this.getGraphParameters().getAlertTimeInd())){
			whereClause.append(" and alert_trend_time = '");
			whereClause.append(calcAlertData.getAlertTrendTime());
			whereClause.append("'");
		}
		
		if (this.getGraphParameters().getKey1()!=null){
			whereClause.append(" and extrct_key1 = '");
			whereClause.append(calcAlertData.getAlertKey1());
			whereClause.append("'");
		}
		if (this.getGraphParameters().getKey2()!=null){
			whereClause.append(" and extrct_key2 = '");
			whereClause.append(calcAlertData.getAlertKey2());
			whereClause.append("'");
		}
		if (this.getGraphParameters().getKey3()!=null){
			whereClause.append(" and extrct_key3 = '");
			whereClause.append(calcAlertData.getAlertKey3());
			whereClause.append("'");
		}
		if (this.getGraphParameters().getKey4()!=null){
			whereClause.append(" and extrct_key4 = '");
			whereClause.append(calcAlertData.getAlertKey4());
			whereClause.append("'");
		}
		if (this.getGraphParameters().getKey5()!=null){
			whereClause.append(" and extrct_key5 = '");
			whereClause.append(calcAlertData.getAlertKey5());
			whereClause.append("'");
		}
		
		whereClause.append(" AND PRESN_CD IN ('A', 'B') ");
		
		args.add(whereClause.toString());

		return args;
	}
	
	/**
	 * Method to execute statement on RABC_EXTRCT_SUMY_DATA table 
	 * and returns the list of ExtrctSumyData objects.
	 * 
	 * @param conn
	 * @param failures
	 * @param calcAlertData
	 * @return List
	 */
	public List getQrySumExtrData(Connection conn, List failures,CalcAlertData calcAlertData){
		List extrctSumyDataList = null;
		ExtrctSumyData extrctSumyData = null;
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		String baseSQL = qrySumExtrData;
		List args = buildQrySumExtrDataArguments(calcAlertData);
		
		try
		{
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("qrySumExtrData - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			if (rs != null) {
				extrctSumyDataList = new ArrayList();
				while (rs.next()) {
					extrctSumyDataList.add(buildExtrctSumyData(rs));
				}
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return null;
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}

		return extrctSumyDataList;
	}
	
	/**
	 * Private method to return the ExtrctSumyData object. It accepts the result set and set the
	 * attributes of ExtrctSumyData object by getting the values from the result set.
	 * 
	 * @param rs
	 * @return ExtrctSumyData
	 * @throws SQLException
	 */
	private ExtrctSumyData buildExtrctSumyData(ResultSet rs) throws SQLException {
		ExtrctSumyData extrctSumyData = new ExtrctSumyData();
		
		extrctSumyData.setExtrctData1(rs.getDouble("EXTRCT_DATA1"));
		extrctSumyData.setExtrctData2(rs.getDouble("EXTRCT_DATA2"));
		extrctSumyData.setExtrctData3(rs.getDouble("EXTRCT_DATA3"));
		extrctSumyData.setExtrctData4(rs.getDouble("EXTRCT_DATA4"));
		extrctSumyData.setExtrctData5(rs.getDouble("EXTRCT_DATA5"));
		extrctSumyData.setExtrctData6(rs.getDouble("EXTRCT_DATA6"));
		extrctSumyData.setExtrctData7(rs.getDouble("EXTRCT_DATA7"));
		extrctSumyData.setExtrctData8(rs.getDouble("EXTRCT_DATA8"));
		extrctSumyData.setExtrctData9(rs.getDouble("EXTRCT_DATA9"));
		extrctSumyData.setExtrctData10(rs.getDouble("EXTRCT_DATA10"));
		extrctSumyData.setExtrctData11(rs.getDouble("EXTRCT_DATA11"));
		extrctSumyData.setExtrctData12(rs.getDouble("EXTRCT_DATA12"));
		extrctSumyData.setExtrctData13(rs.getDouble("EXTRCT_DATA13"));
		extrctSumyData.setExtrctData14(rs.getDouble("EXTRCT_DATA14"));
		extrctSumyData.setExtrctData15(rs.getDouble("EXTRCT_DATA15"));
		
		Date procDate = rs.getDate("PROC_DATE");
		if (procDate != null) {
			extrctSumyData.setProcDate(new MyDate(procDate));
		}
		
		extrctSumyData.setFileSeqNum(rs.getInt("FILE_SEQ_NUM"));

		return extrctSumyData;
	}

}
