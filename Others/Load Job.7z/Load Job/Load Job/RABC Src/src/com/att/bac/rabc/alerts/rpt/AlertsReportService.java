/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.rpt;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.att.bac.rabc.ExcelReport;
import com.att.bac.rabc.MyDate;
import com.att.bac.rabc.PickList;
import com.att.bac.rabc.ProgressBar;
import com.att.bac.rabc.StaticDataLoader;
import com.att.bac.rabc.alerts.dashboard.CycleCalendar;
import com.att.bac.rabc.alerts.dashboard.CycleCalendarDAO;

/**
 * This class represents the Service class which handles processing of 
 * various requests and has buisness logic related to ALERT REPORT Service 
 * for PAGE 11 and PAGE 14.
 * 
 * @author Nalina Pandiyan - NP5434
 */
public class AlertsReportService {
	private static final Logger logger = Logger.getLogger(AlertsReportService.class);
	AlertReportView alertReportView = null;
	
	private static final String PAGE_14 = "RABCPSF00014";
	private static final String PAGE_11 = "RABCPSF00011";
	
	private AlertsReportSQLService alertsReportSQLService = null;
	private AlertsReportViewService alertsReportViewService = null;
	private AlertsGenFilterTemplate alertsGenFilterTemplate = null;
	private AlertsLinkTemplateActionService alertsLinkTemplateActionService = null;

	private AlertReportParameters alertReportParameters = null;
	private Connection connection = null;
	private List failureList = null;
	
	private final String query_getCycle = "SELECT CYCLE,BILL_RND,PROC_DT,BILL_RND_DT "
		+ "FROM rabc_cycle_calendar {0} ORDER BY PROC_DT";
	
	/**
	 * This method is used to return the object of AlertsReportService class.
	 * 
	 * @return AlertsReportService
	 */
	public static AlertsReportService getAlertsReportService() {
		return new AlertsReportService();
	}

	/**
	 * Default constructor which sets the default alertsReportSQLService, alertsReportViewService
	 * and alertsGenFilterTemplate.  
	 */
	public AlertsReportService() {
		alertReportView = new AlertReportView();
		this.alertsReportSQLService = AlertsReportSQLService.getAlertsReportSQLService();
		this.alertsReportViewService = AlertsReportViewService.getAlertsReportViewService();
		this.alertsGenFilterTemplate = AlertsGenFilterTemplate.getAlertsGenFilterTemplate();
	}

	/**
	 * This method is used to return the AlertReportView for process view request.
	 * 
	 * @param connection
	 * @param failureList
	 * @param alertReportParameters
	 * @param progressBar
	 * @return AlertReportView
	 */
	public AlertReportView processViewRequest(Connection connection, List failureList, AlertReportParameters alertReportParameters, ProgressBar progressBar) {
		int nbrOfRows;
		
		if (!init(connection, failureList, alertReportParameters)) return null;

		if (alertReportParameters.getSelectedButton() != -1) {
			// means NEXT DATA or PREVIOUS DATA button is clicked
			if (!initAdditional(connection, failureList, alertReportParameters)) return null;
			//alertsLinkTemplateActionService.setStartEndDates();			
		}
		progressBar.setProgressPercent(20);
		
		nbrOfRows = processAlertReportRequest(progressBar);
		//if (alertReportParameters.getAlertRule()==null) return alertReportView;
		alertsGenFilterTemplate.addStandardButtons();

		Integer savePresnId = alertReportParameters.getPresnId();
		if (alertReportParameters.getWebPageId().equals(PAGE_14)) {
			alertReportParameters.setPresnId(new Integer(0));
		}
		alertsGenFilterTemplate.setHeaderText(alertReportParameters.getRegion());		

		if (alertReportParameters.getWebPageId().equals(PAGE_14)) {
			alertReportParameters.setPresnId(savePresnId);
		}
		//alertsGenFilterTemplate.processViewSize(nbrOfRows);
		return alertReportView;
	}								

	/**
	 * This is a method to handel the request for generating
	 * the report of AlertsReportService. 
	 * 
	 * @param connection
	 * @param failureList
	 * @param alertReportParameters
	 * @param report
	 * @param progressBar
	 * @return AlertReportView
	 */
	public AlertReportView processCreateReportRequest(Connection connection, List failureList, AlertReportParameters alertReportParameters, ExcelReport report, ProgressBar progressBar) {
		if (!init(connection, failureList, alertReportParameters)) return null;
		if (!initAdditional(connection, failureList, alertReportParameters)) return null;
		progressBar.setProgressPercent(20);

		alertsGenFilterTemplate.addStandardButtons();
		processAlertReportRequest(progressBar); 

		Integer savePresnId = alertReportParameters.getPresnId();
		if (alertReportParameters.getWebPageId().equals(PAGE_14)) {
			alertReportParameters.setPresnId(new Integer(0));
		}
		alertsGenFilterTemplate.setHeaderText(alertReportParameters.getRegion());		
		
		if (alertReportParameters.getWebPageId().equals(PAGE_14)) {
			alertReportParameters.setPresnId(savePresnId);
		}
		alertsLinkTemplateActionService.prepareExcelReport(alertReportView, report);
		
		return alertReportView;
	}
	
	/**
	 * This is a method to get alert rule details from RABC_ALERT_RULE table
	 * to process AlertReportRequest for the passed progressBar.
	 * 
	 * @param progressBar
	 * @return int
	 */
	private int processAlertReportRequest(ProgressBar progressBar) {
		if ((alertReportParameters.getCntrlPtCd().length() != 0) && (alertReportParameters.getAlertRules().length() == 0)) {
			// This request will only be for PAGE 11
			// cntrl_pt_cd is passed, hence get all the alert rules and add it to alertReportParameters.alertRules
			logger.debug("Alert Report Page 11 is being processed with cntrl_pt_cd");
			alertsReportSQLService.getAlertRulesByCntrlPtCd();
			if (!failureList.isEmpty()) return 0;
		}

		if (alertReportParameters.getWebPageId().equals(PAGE_14)) {
			// Find all alert rules which are present in the file seq num being passed
			logger.debug("Alert Report Page 14 is being processed, getting alert rules present in file seq num.");
			alertsReportSQLService.getAlertRules();
			if (!failureList.isEmpty()) return 0;
		}
		progressBar.setProgressPercent(30);

		logger.debug("Getting alert rule details from RABC_ALERT_RULE table.");
		alertsReportSQLService.getDefaultAlertRuleInfo();
		if (!failureList.isEmpty()) return 0;
		progressBar.setProgressPercent(40);

		if (alertReportParameters.getWebPageId().equals(PAGE_11)) {			
			logger.debug("Finding all the alert rules which are in the related group(s) to the specific alert rule being processed.");
			alertsReportSQLService.updateAlertRulesAndSumyPresn();
			if (!failureList.isEmpty()) return 0;
		}
		progressBar.setProgressPercent(50);
		
		// execute QryAlertRule. set partiRefIDs, SeqCnt, presnIdINString and execPresnSeqNumINString
		alertsReportSQLService.executeQryAlertRule();
		if (!failureList.isEmpty()) return 0;
		progressBar.setProgressPercent(60);
		
		//Set the value of showAlertRuleTimingIOption in AlertReportParameter class
		if (alertReportParameters.getWebPageId().equals(PAGE_11)) {			
			//Set default value to ""
			alertReportParameters.setAlertRuleTimingIndicator("");
			List distinctTimeIndicatorList = alertsReportSQLService.getDistinctAlertRuleTimingIndicators();
			if(distinctTimeIndicatorList.size()==1){
				String timeIndicator = (String) distinctTimeIndicatorList.get(0);
				if(timeIndicator != null && (timeIndicator.equalsIgnoreCase("B") || timeIndicator.equalsIgnoreCase("D"))){
					alertReportParameters.setAlertRuleTimingIndicator(timeIndicator);
				}				
			}//end of if(distinctTimeIndicatorList.size()==1)	
			
			this.buildAlertTimingValues(alertReportParameters);
		}//end of if (alertReportParameters.getWebPageId().equals(PAGE_11))

		// means NEXT DATA or PREVIOUS DATA button is clicked
		if (alertReportParameters.getSelectedButton() != -1) {
			alertsReportSQLService.setStartEndDates();			
		}
		
		// execute QryAlertHistAll and set noData flag
		alertsReportSQLService.executeQryAlertHistAll();
		
		if (!failureList.isEmpty()) return 0;
		progressBar.setProgressPercent(70);

		if (alertReportParameters.getWebPageId().equals(PAGE_11)) {
			alertsGenFilterTemplate.setGeneralFilter();	
		}
		
		if (alertReportParameters.getWebPageId().equals(PAGE_11)) {
			alertsReportSQLService.getAlertItemOptions();
			if (!failureList.isEmpty()) return 0;
		}
		progressBar.setProgressPercent(80);
		
		if (alertReportParameters.getDataPresent().equals("Y")) {
			// Qry Alert Hist does contain data in the range requested, hence process
			// execute qryAlertMsg
			alertsReportSQLService.executeQryAlertMsg();
			
			// execute QryPrevData
			if (alertReportParameters.getWebPageId().equals(PAGE_11)) {
				alertsReportSQLService.executeQryPrevData();
				
				if (alertReportParameters.getSevereLvl().intValue() == 0) {
					// execute notCompleteFilesQry1
					logger.debug("Executing Query figuring out what groups of alert_items (proc_data,file_seq_num) don't have all the alert items they are supposed to.");
					alertsReportSQLService.executeNotCompleteFilesQry1();
					if (!failureList.isEmpty()) return 0;
				} 
			}
			
			// build qryAlertData, compute sum(calcCnt), sum(SeqCnt), totCnt, determine maxDate, minDate, build keyColumnList and build arKeyColMap
			alertsReportSQLService.buildQryAlertData();
			
			// Clear qryAlertRuleList and qryAlertHistAll as it is not required any more
			alertsReportSQLService.clearQryAlertRuleList();
			alertsReportSQLService.clearQryAlertHistAllList();
			progressBar.setProgressPercent(90);
			
			// prepare AlertReportView for showing in the browser
			return alertsReportViewService.prepareAlertReportView();
		} else {
			progressBar.setProgressPercent(90);
			return 0;
		}
	}

	/**
	 * This method initializes the parameters of AlertsReportSQLService object, 
	 * AlertsReportViewService object and AlertsGenFilterTemplate object.
	 * 
	 * @param connection
	 * @param failureList
	 * @param alertReportParameters
	 * @return boolean
	 */
	private boolean init(Connection connection, List failureList, AlertReportParameters alertReportParameters) {
		this.connection = connection;
		this.failureList = failureList;
		this.alertReportParameters = alertReportParameters;
		
		/*
		 * Code added to display the drop downs for alert time ind & value
		 */
		if (alertReportParameters.getWebPageId().equals(PAGE_11)) {
			buildAlertTimingValues(alertReportParameters);
		}
		
		alertsReportSQLService.setConnection(connection);
		alertsReportSQLService.setAlertReportParameters(alertReportParameters);
		alertsReportSQLService.setFailureList(failureList);

		alertsReportSQLService.setQryAlertDataList(alertsReportViewService.getQryAlertDataList());
		alertsReportSQLService.setNotCompleteFilesQryList(alertsReportViewService.getNotCompleteFilesQryList());
		alertsReportSQLService.setNotCompleteFilesQry1List(alertsReportViewService.getNotCompleteFilesQry1List());
		alertsReportSQLService.setPreviousDataList(alertsReportViewService.getPreviousDataList());
		alertsReportSQLService.setQryAlertMsgList(alertsReportViewService.getQryAlertMsgList());
		alertsReportSQLService.setAlertRuleMap(alertsReportViewService.getAlertRuleMap());
		
		alertsReportViewService.setConnection(connection);
		alertsReportViewService.setAlertReportParameters(alertReportParameters);
		alertsReportViewService.setFailureList(failureList);
		alertsReportViewService.setAlertReportView(alertReportView);

		alertsGenFilterTemplate.setConnection(connection);
		alertsGenFilterTemplate.setAlertReportParameters(alertReportParameters);
		alertsGenFilterTemplate.setFailureList(failureList);
		alertsGenFilterTemplate.setAlertReportView(alertReportView);
		alertsGenFilterTemplate.setAlertRuleMap(alertsReportViewService.getAlertRuleMap());
		
		if (alertReportParameters.getWebPageId().equals(PAGE_11)) {
			String divisionList = "";
			if (alertReportParameters.getDivisionName() == null) {
				alertReportParameters.setDivisionName(new String("ALL"));
			}
			if ((alertReportParameters.getDivisionName() != null) && (alertReportParameters.getDivisionName().length() == 0)) {
				alertReportParameters.setDivisionName("ALL");
			}
			if (!alertReportParameters.getDivisionName().equals("ALL")) {
				// divisions are space separated, prepare list 
				String key1 = "";
				String tmpStr = alertReportParameters.getDivisionName().trim() + " ";
				for (int i = 0; i < tmpStr.length(); i++) {
					if (tmpStr.charAt(i) == ' ') {
						alertReportParameters.addKey1s(key1);
						key1 = "";
					} else {
						key1 += tmpStr.charAt(i); 
					}
				}
			}
			if (alertReportParameters.getStartDate() == null) {
				alertReportParameters.setStartDate(new MyDate());
			}
			if (alertReportParameters.getEndDate() == null) {
				alertReportParameters.setEndDate(new MyDate());
			}
		}
		if (alertReportParameters.getWebPageId().equals(PAGE_14)) {
			// init StartDate
			alertReportParameters.setStartDate(alertReportParameters.getProcDate());				
		}
		
		return true;
	}

	/**
	 * This method initializes the parameters of AlertsLinkTemplateActionService object.
	 * 
	 * @param connection
	 * @param failureList
	 * @param alertReportParameters
	 * @return boolean
	 */
	private boolean initAdditional(Connection connection, List failureList, AlertReportParameters alertReportParameters) {
		alertsLinkTemplateActionService = AlertsLinkTemplateActionService.getAlertsLinkTemplateActionService();
		alertsLinkTemplateActionService.setConnection(connection);
		alertsLinkTemplateActionService.setFailureList(failureList);
		alertsLinkTemplateActionService.setAlertReportParameters(alertReportParameters);
		alertsLinkTemplateActionService.setAlertRuleMap(alertsReportViewService.getAlertRuleMap());
		
		return true;
	}
	
	/**
	 * This method builds AlertTimingValues for the passed AlertReportParameters.
	 * 
	 * @param alertReportParameters 
	 */
	private void buildAlertTimingValues(AlertReportParameters alertReportParameters){
		ArrayList options1 = new ArrayList();
		
		if(alertReportParameters.getAlertRuleTimingIndicator().equalsIgnoreCase("B")){
			options1.add(new PickList("0", "-- Select --"));			
			if ("MW".equals(alertReportParameters.getRegion())){
				options1.add(new PickList("B", "Process Group"));
			}else {
				options1.add(new PickList("B", "Bill Cycle"));
			}
			alertReportParameters.setAlertTimeIndOptions(options1);
		}
		else if(alertReportParameters.getAlertRuleTimingIndicator().equalsIgnoreCase("D")){
			options1.add(new PickList("0", "-- Select --"));
			options1.add(new PickList("D", "Call Day Week"));			
			alertReportParameters.setAlertTimeIndOptions(options1);
		}
		else{
			options1.add(new PickList("0", "-- Select --"));
			options1.add(new PickList("D", "Call Day Week"));
			
			if ("MW".equals(alertReportParameters.getRegion())){
				options1.add(new PickList("B", "Process Group"));
			}else {
				options1.add(new PickList("B", "Bill Cycle"));
			}
			alertReportParameters.setAlertTimeIndOptions(options1);
		}		
		
		ArrayList options2 = new ArrayList();
		options2.add(new PickList(Integer.toString(-1), "-- Select --"));
		alertReportParameters.setAlertTimeValueOptions(options2);
		
		/*
		 * options for call day week
		 */
		ArrayList options2a = new ArrayList();
		options2a.add(new PickList(Integer.toString(-1), "-- Select --"));
		options2a.add(new PickList(Integer.toString(2), "Monday"));
		options2a.add(new PickList(Integer.toString(3), "Tuesday"));
		options2a.add(new PickList(Integer.toString(4), "Wednesday"));
		options2a.add(new PickList(Integer.toString(5), "Thursday"));
		options2a.add(new PickList(Integer.toString(6), "Friday"));
		options2a.add(new PickList(Integer.toString(7), "Saturday"));
		options2a.add(new PickList(Integer.toString(1), "Sunday"));
		alertReportParameters.setAlertTimeValueOptionsWD(options2a);
		
		/*
		 * options for bill day
		 */
		ArrayList options2b = new ArrayList();
		options2b.add(new PickList(Integer.toString(-1), "-- Select --"));
		ArrayList list = StaticDataLoader.getBillRndByRegion(alertReportParameters.getRegion());
		for (int i=0; i<list.size(); i++){
			if (Integer.parseInt(list.get(i).toString()) < 10){
				options2b.add(new PickList(list.get(i).toString(), "0" + list.get(i).toString()));
			}else{
				options2b.add(new PickList(list.get(i).toString(), list.get(i).toString()));
			}
		}
		alertReportParameters.setAlertTimeValueOptionsBR(options2b);
	}

	/**
	 * Method to return the default division.
	 * 
	 * @param connection
	 * @param failures
	 * @param userId
	 * @return String
	 */
	public String getDefaultDivision(Connection connection, List failures, String userId) {
		return alertsReportSQLService.getDefaultDivision(connection, failures, userId);
	}

	/**
	 * Method to return the default line count.
	 * 
	 * @param connection
	 * @param failures
	 * @param userId
	 * @return
	 */
	public int getDefaultLineCount(Connection connection, List failures, String userId) {
		return alertsReportSQLService.getDefaultLineCount(connection, failures, userId);
	}

	/**
	 * Method to return the list of cycles.
	 * It calls the CycleCalendarDAO to get the list of cycles.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return List
	 */
	protected List getCycleCalendarList(Connection connection, List failureList, List args ){
		List cycleCalendarList = new ArrayList();
		List cycleList = new ArrayList();
		CycleCalendar cycleCalendar= null;
		List cycleArgsList = new ArrayList();
		
		String startDate = (String) args.get(0);
		String endDate = (String) args.get(1);
		
		if((startDate != null && !"".equals(startDate)) && (endDate == null || "".equals(endDate))) {
			cycleArgsList.add("where proc_dt = to_date('" + startDate + "','MM/dd/yyyy')");
		} else if((startDate != null && !"".equals(startDate))  && (endDate != null && !"".equals(endDate)) && startDate.equals(endDate)) {
			cycleArgsList.add("where proc_dt  = to_date('" + startDate + "','MM/dd/yyyy')");
		} else if((startDate != null && !"".equals(startDate))  && (endDate != null && !"".equals(endDate)) && (!startDate.equals(endDate))) {
			cycleArgsList.add("where proc_dt  between  to_date('" + startDate + "','MM/dd/yyyy') and to_date('" + endDate + "','MM/dd/yyyy')");
		} else {
			cycleArgsList.add(" ");
		}
		
		cycleCalendarList = new CycleCalendarDAO().get(connection, failureList, cycleArgsList, query_getCycle);
		if (!failureList.isEmpty()) {
			return null;
		}
		
		if (cycleCalendarList != null) {
			int i = 0;
			int cycleCalendarListSize = cycleCalendarList.size();
			for (i=0; i<cycleCalendarListSize; i++) {
				cycleCalendar = (CycleCalendar)cycleCalendarList.get(i);
				cycleList.add(new Integer(cycleCalendar.getCycle()));
			}
		}
		return cycleList;
	}
	
}
