/* Component Name: RABCPPG00503
 * Module Name: AdminAlertGroupDAO.java
 * Created on Jan 20, 2006
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.admin.alert.grp;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.User;
import com.att.carat.util.JDBCUtil;

/**This is the Data Access Object class for the admin alert group process.  The purpose of this class
 * is to interact with the database to either create new alert groups, update existing alert groups, or
 * delete alert groups that are not needed anymore and return this data to the AdminAlertGroupService.java
 * class.  All exceptions are thrown back to the AdminAlertGroupAction.java class via the AdminAlertGroupService.java
 * class.
 * 
 * @author js3175
 */
public class AdminAlertGroupDAO {
	private static final Logger logger = Logger.getLogger(AdminAlertGroupDAO.class);
	
	/**This static method is called by the service class to set the variable that gives the level of permissions
	 * the user has on the exempt pages.
	 * 
	 * @param conn  the connection created in the service class
	 * @param userid  the user's AT&T user ID
	 * @return superAdmin  1 means the user is part of the Super Admin AG alert group, 0 means the user isn't.
	 */
	protected static int getSuperPermission(Connection conn, String userid) throws RABCException {
		int superAdmin = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String superAdminPerm = "SELECT FUNCT_CD " +
								"FROM RABC_ALERT_GRP_FUNCT " +
								"WHERE ALERT_GRP IN (SELECT DISTINCT ALERT_GRP " +
								"                    FROM RABC_ALERT_GRP_USER " +
								"                    WHERE UPPER(USER_ID) = ?)";
		try {
			ps = conn.prepareStatement(superAdminPerm);
			ps.setString(1, userid.trim().toUpperCase());
			rs = ps.executeQuery();
			logger.debug("Starting rs loop...");
			while (rs.next()) {
				if (rs.getString("FUNCT_CD").toUpperCase().equals("AG")) {
					superAdmin = 1;
					break;
				}
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in determining super admin permission using superAdminPerm query: ", sqle);
		} catch (NumberFormatException nfe) {
			throw new RABCException("Error parsing numeric value: ", nfe);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
		return superAdmin;
	}
	
	/**This static method is called by the service class to get the alert groups to be displayed in a
	 * drop down on the main page.
	 * 
	 * @param conn  the connection created in the service class
	 * @return list  an ArrayList object of alert groups.
	 */
	protected static ArrayList getGroups(Connection conn) throws RABCException {
		ArrayList list = new ArrayList();
		Statement stmt = null;
		ResultSet rs = null;
		String getAlertGroups = "SELECT DISTINCT ALERT_GRP " +
								"FROM RABC_ALERT_GRP " +
								"ORDER BY UPPER(ALERT_GRP)";
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(getAlertGroups);
			logger.debug("Starting rs loop...");
			while (rs.next()) {
				list.add(rs.getString("ALERT_GRP"));
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving alert groups using getAlertGroups query: ", sqle);
		} catch (NumberFormatException nfe) {
			throw new RABCException("Error parsing numeric value: ", nfe);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closeStatement(stmt);
		}
		return list;
	}
	
	/**This static method is called by the service class to set the variable that gives the level of permissions
	 * the user has on the group pages.
	 * 
	 * @param conn  the connection created in the service class
	 * @param alertGroup  the alert group the user is accessing
	 * @return alrtGrpTO  the alert group transfer object containing the alert group name and description.
	 */
	protected static AlertGroupTO getSelectedAlertGroup(Connection conn, String alertGroup) throws RABCException {
		AlertGroupTO alrtGrpTO = new AlertGroupTO();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String getAlertGroup = "SELECT DISTINCT ALERT_GRP, ALERT_GRP_DESC " +
							   "FROM RABC_ALERT_GRP " +
							   "WHERE UPPER(ALERT_GRP) = ?";
		try {
			ps = conn.prepareStatement(getAlertGroup);
			ps.setString(1, alertGroup.trim().toUpperCase());
			rs = ps.executeQuery();
			if (rs.next()) {
				alrtGrpTO.setAlertGroup(rs.getString("ALERT_GRP"));
				alrtGrpTO.setAlertGroupDescription(rs.getString("ALERT_GRP_DESC"));
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving alert groups using getAlertGroup query: ", sqle);
		} catch (NumberFormatException nfe) {
			throw new RABCException("Error parsing out numeric value: ", nfe);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
		return alrtGrpTO;
	}
	
	/**This static method is called by the service class to check to see if the alert group name the user
	 * is using for an alert group he is creating has already been used.
	 * 
	 * @param conn  the connection created in the service class
	 * @param alertGroup  the alert group the user is creating
	 * @return duplicate  1 means the name has been used already, 0 means the name isn't a duplicate.
	 */
	protected static int checkDuplAlertGroup(Connection conn, String alertGroup) throws RABCException {
		int duplicate = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String checkAlertGroup = "SELECT DISTINCT ALERT_GRP " +
								 "FROM RABC_ALERT_GRP " +
								 "WHERE UPPER(ALERT_GRP) = ?";
		try {
			ps = conn.prepareStatement(checkAlertGroup);
			ps.setString(1, alertGroup.trim().toUpperCase());
			rs = ps.executeQuery();
			if (rs.next()) {
				duplicate = 1;
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving alert group using checkAlertGroup query: ", sqle);
		} catch (NumberFormatException nfe) {
			throw new RABCException("Error parsing out numeric value: ", nfe);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
		return duplicate;
	}
	
	/**This static method is called by the service class to set the variable that gives the level of permissions
	 * the user has on the group pages.
	 * 
	 * @param conn  the connection created in the service class
	 * @param alertGroup  the alert group the user is accessing
	 * @param userid  the user's AT&T user ID
	 * @return updatePermission  1 allows updating and deleting, 0 is view only.
	 */
	protected static int getPermission(Connection conn, String alertGroup, String userid) throws RABCException {
		int updatePermission = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String updatePerm = "SELECT DISTINCT ALERT_GRP " +
							"FROM RABC_ALERT_GRP_USER " +
							"WHERE UPPER(USER_ID) = ?";
		try {
			ps = conn.prepareStatement(updatePerm);
			ps.setString(1, userid.trim().toUpperCase());
			rs = ps.executeQuery();
			while (rs.next()) {
				if (rs.getString("ALERT_GRP").trim().equals(alertGroup.trim())) {
					updatePermission = 1;
					break;
				}
				if (rs.getString("ALERT_GRP").trim().equals("Super Admin AG")) {
					updatePermission = 1;
					break;
				}
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in checking update permissions using getPermission query: ", sqle);
		} catch (NumberFormatException nfe) {
			throw new RABCException("Error parsing out numeric values: ", nfe);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
		return updatePermission;
	}
	
	/**This static method is called by the service class to retrieve all the user ID's and names of the people
	 * with access to the RABC tool.
	 * 
	 * @param conn  the connection created in the service class
	 * @return (User[]) list.toArray(new User[list.size()])  everyone who has access to the RABC tool.
	 */
	protected static User [] getAllUsers(Connection conn) throws RABCException {
		ArrayList list = new ArrayList();
		Statement stmt = null;
		ResultSet rs = null;
		String getUsers = "SELECT USER_ID, UPPER(USER_NAME) USER_NAME " +
						  "FROM RABC_USER " +
						  "ORDER BY UPPER(USER_NAME)";
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(getUsers);
			logger.debug("Starting rs loop...");
			while (rs.next()) {
				User user = new User();
				user.setUserId(rs.getString("USER_ID"));
				user.setUserName(rs.getString("USER_NAME"));
				list.add(user);
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving alert groups using getUsers query: ", sqle);
		} catch (NumberFormatException nfe) {
			throw new RABCException("Error parsing out numeric values: ", nfe);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closeStatement(stmt);
		}
		return (User[]) list.toArray(new User[list.size()]);
	}
	
	/**This static method is called by the service class to retrieve all the user ID's and names of the people
	 * with access to the RABC tool.
	 * 
	 * @param conn  the connection created in the service class
	 * @param alertGroup  the alert group the user is accessing
	 * @return (User[]) list.toArray(new User[list.size()])  everyone who is in the accessed alert group.
	 */
	protected static User [] getAllCurrentUsers(Connection conn, String alertGroup) throws RABCException {
		ArrayList list = new ArrayList();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String getCurrUsers = "SELECT DISTINCT BAGU.USER_ID USER_ID, UPPER(BUSR.USER_NAME) USER_NAME " +
							  "FROM RABC_ALERT_GRP_USER BAGU, RABC_USER BUSR " +
							  "WHERE BAGU.ALERT_GRP = ? " +
							  "  AND UPPER(BAGU.USER_ID) = UPPER(BUSR.USER_ID) " +
							  "ORDER BY UPPER(BUSR.USER_NAME)";
		try {
			ps = conn.prepareStatement(getCurrUsers);
			ps.setString(1, alertGroup.trim());
			rs = ps.executeQuery();
			logger.debug("Starting rs loop...");
			while (rs.next()) {
				User user = new User();
				user.setUserId(rs.getString("USER_ID"));
				user.setUserName(rs.getString("USER_NAME"));
				list.add(user);
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving users using getCurrUsers query: ", sqle);
		} catch (NumberFormatException nfe) {
			throw new RABCException("Error parsing out numeric value: ", nfe);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
		return (User[]) list.toArray(new User[list.size()]);
	}
	
	/**This static method is called by the service class to retrieve the names of the user ID's added to an
	 * alert group.
	 * 
	 * @param conn  the connection created in the service class
	 * @param selectedUsers  the alert group the user is accessing
	 * @return (User[]) list.toArray(new User[list.size()])  everyone who is selected to be in the alert group.
	 */
	protected static User [] getSelectUsers(Connection conn, String [] selectedUsers) throws RABCException {
		logger.debug("number of users selected = " + selectedUsers.length);
		ArrayList list = new ArrayList();
		StringBuffer sb = new StringBuffer();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String getSelUsers = "SELECT USER_ID, UPPER(USER_NAME) USER_NAME " +
							 "FROM {0} " +
							 "WHERE USER_ID IN {1} " +
							 "ORDER BY UPPER(USER_NAME)";
		MessageFormat mf = new MessageFormat(getSelUsers);
		String [] arguments = new String[2];
		arguments[0] = "RABC_USER";
		try {
			sb.append("(");
			int j = selectedUsers.length - 1;
			for (int i = 0; i < j; i++) {
				sb.append("?,");
			}
			sb.append("?)");
			arguments[1] = sb.toString();
			ps = conn.prepareStatement(mf.format(arguments).toString());
			for (int i = 0; i < selectedUsers.length; i++) {
				ps.setString(i+1, selectedUsers[i].trim());
			}
			rs = ps.executeQuery();
			logger.debug("Starting rs loop...");
			while (rs.next()) {
				User user = new User();
				user.setUserId(rs.getString("USER_ID"));
				user.setUserName(rs.getString("USER_NAME"));
				list.add(user);
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving the users selected to be in this alert group using getSelUsers query: ", sqle);
		} catch (NumberFormatException nfe) {
			throw new RABCException("Error parsing out numeric value: ", nfe);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
		return (User[]) list.toArray(new User[list.size()]);
	}
	
	/**This static method is called by the service class to retrieve all the application functions in RABC.
	 * 
	 * @param conn  the connection created in the service class
	 * @return (SelectRowTO[]) list.toArray(new SelectRowTO[list.size()])  all the application functions
	 *                                                                     an alert group can have.
	 */
	protected static SelectRowTO [] getAllApplFuncts(Connection conn) throws RABCException {
		ArrayList list = new ArrayList();
		Statement stmt = null;
		ResultSet rs = null;
		String getApplFuncts = "SELECT DISTINCT INITCAP(PGM_DESC) PGM_DESC, FUNCT_CD " +
							   "FROM RABC_ALERT_PGM_FUNCT " +
							   "WHERE ALERT_GRP_TYPE = 'A' " +
							   "ORDER BY UPPER(PGM_DESC)";
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(getApplFuncts);
			logger.debug("Starting rs loop...");
			while (rs.next()) {
				SelectRowTO selectRow = new SelectRowTO();
				selectRow.setRowID(rs.getString("FUNCT_CD"));
				selectRow.setRowName(rs.getString("PGM_DESC"));
				list.add(selectRow);
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving application functions using getApplFuncts query: ", sqle);
		} catch (NumberFormatException nfe) {
			throw new RABCException("Error parsing out numeric values: ", nfe);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closeStatement(stmt);
		}
		return (SelectRowTO[]) list.toArray(new SelectRowTO[list.size()]);
	}
	
	/**This static method is called by the service class to retrieve all the application functions the alert
	 * group accesses.  These values are then matched against all application functions and those selected are
	 * checked on the details page.
	 * 
	 * @param conn  the connection created in the service class
	 * @param alertGroup  the alert group the user is accessing
	 * @return (String[]) list.toArray(new String[list.size()])  the application functions the alert group has
	 *                                                           access to.
	 */
	protected static String [] getSelectApplFuncts(Connection conn, String alertGroup) throws RABCException {
		ArrayList list = new ArrayList();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String getSelApplFuncts = "SELECT FUNCT_CD " +
								  "FROM RABC_ALERT_GRP_FUNCT " +
								  "WHERE ALERT_GRP = ?";
		try {
			ps = conn.prepareStatement(getSelApplFuncts);
			ps.setString(1, alertGroup.trim());
			rs = ps.executeQuery();
			logger.debug("Starting rs loop...");
			while (rs.next()) {
				list.add(rs.getString("FUNCT_CD"));
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving application functions using getSelApplFuncts query: ", sqle);
		} catch (NumberFormatException nfe) {
			throw new RABCException("Error parsing out numeric value: ", nfe);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
		return (String[]) list.toArray(new String[list.size()]);
	}
	
	/**This static method is called by the service class to retrieve all the alert rules in RABC.  Alert
	 * rules that have been removed are not included in this list.
	 * 
	 * @param conn  the connection created in the service class
	 * @return (SelectRowTO[]) list.toArray(new SelectRowTO[list.size()])  all the alert rules an
	 *                                                                     alert group can have.
	 */
	protected static SelectRowTO [] getAllAlrtRules(Connection conn) throws RABCException {
		ArrayList list = new ArrayList();
		Statement stmt = null;
		ResultSet rs = null;
		String getAlrtRules = "SELECT DISTINCT A.ALERT_RULE ALERT_RULE " +
							  "FROM RABC_ALERT_RULE A, RABC_PRESN_ID B " +
							  "WHERE (A.ALERT_RULE_STATUS IS NULL OR " +
							  "		  A.ALERT_RULE_STATUS <> 'DELETED')	" +
							  "  AND A.ALERT_RULE_PRESN_IND = 'Y' " +
							  "  AND A.PRESN_ID = B.PRESN_ID " +
							  "ORDER BY UPPER(ALERT_RULE)";
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(getAlrtRules);
			logger.debug("Starting rs loop...");
			while (rs.next()) {
				SelectRowTO selectRow = new SelectRowTO();
				selectRow.setRowID(rs.getString("ALERT_RULE"));
				selectRow.setRowName(rs.getString("ALERT_RULE"));
				list.add(selectRow);
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving alert rules using getAlrtRules query: ", sqle);
		} catch (NumberFormatException nfe) {
			throw new RABCException("Error parsing numeric values: ", nfe);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closeStatement(stmt);
		}
		return (SelectRowTO[]) list.toArray(new SelectRowTO[list.size()]);
	}
	
	/**This static method is called by the service class to retrieve all the alert rules the alert
	 * group accesses.  These values are then matched against all alert rules and those selected are
	 * checked on the details page.
	 * 
	 * @param conn  the connection created in the service class
	 * @param alertGroup  the alert group the user is accessing
	 * @return (String[]) list.toArray(new String[list.size()])  the alert rules the alert group has access to.
	 */
	protected static String [] getSelectAlrtRules(Connection conn, String alertGroup) throws RABCException {
		ArrayList list = new ArrayList();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String getAlrtRules = "SELECT DISTINCT C.ALERT_RULE ALERT_RULE " +
							  "FROM RABC_ALERT_RULE A, RABC_PRESN_ID B, RABC_UPDATE_GRP C " +
							  "WHERE C.ALERT_GRP = ? " +
							  "  AND (A.ALERT_RULE_STATUS IS NULL OR " +
							  "		  A.ALERT_RULE_STATUS <> 'DELETED')	" +
							  "  AND A.ALERT_RULE_PRESN_IND = 'Y' " +
							  "  AND A.PRESN_ID = B.PRESN_ID " +
							  "  AND C.ALERT_RULE = A.ALERT_RULE " +
							  "ORDER BY UPPER(ALERT_RULE)";
		try {
			ps = conn.prepareStatement(getAlrtRules);
			ps.setString(1, alertGroup.trim());
			rs = ps.executeQuery();
			logger.debug("Starting rs loop...");
			while (rs.next()) {
				list.add(rs.getString("ALERT_RULE"));
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving alert rules using getAlrtRules query: ", sqle);
		} catch (NumberFormatException nfe) {
			throw new RABCException("Error parsing out numeric value: ", nfe);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
		return (String[]) list.toArray(new String[list.size()]);
	}
	
	/**This static method is called by the service class to retrieve all the alert rules the alert
	 * group will send a system message to the alert group members.  These values are then matched
	 * against all alert rules and those selected have their system messages check box checked on
	 * the details page.
	 * 
	 * @param conn  the connection created in the service class
	 * @param alertGroup  the alert group the user is accessing
	 * @return (String[]) list.toArray(new String[list.size()])  the alert rules system messages are sent for.
	 */
	protected static String [] getSendSystemMssgs(Connection conn, String alertGroup) throws RABCException {
		ArrayList list = new ArrayList();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String getSystMssgs = "SELECT DISTINCT C.ALERT_RULE ALERT_RULE " +
							  "FROM RABC_ALERT_RULE A, RABC_PRESN_ID B, RABC_PROC_RESPONSIBLE C " +
							  "WHERE C.ALERT_GRP = ? " +
							  "  AND C.ROLE_CD = '1' " +
							  "  AND (A.ALERT_RULE_STATUS IS NULL OR " +
							  "		  A.ALERT_RULE_STATUS <> 'DELETED')	" +
							  "  AND A.ALERT_RULE_PRESN_IND = 'Y' " +
							  "  AND A.PRESN_ID = B.PRESN_ID " +
							  "  AND C.ALERT_RULE = A.ALERT_RULE " +
							  "ORDER BY UPPER(ALERT_RULE)";
		try {
			ps = conn.prepareStatement(getSystMssgs);
			ps.setString(1, alertGroup.trim());
			rs = ps.executeQuery();
			logger.debug("Starting rs loop...");
			while (rs.next()) {
				list.add(rs.getString("ALERT_RULE"));
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving alert rules using getSystMssgs query: ", sqle);
		} catch (NumberFormatException nfe) {
			throw new RABCException("Error parsing out numeric values: ", nfe);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
		return (String[]) list.toArray(new String[list.size()]);
	}
	
	/**This static method is called by the service class to retrieve all the alert rules the alert
	 * group will send an application message to the alert group members.  These values are then matched
	 * against all alert rules and those selected have their application messages check box checked on
	 * the details page.
	 * 
	 * @param conn  the connection created in the service class
	 * @param alertGroup  the alert group the user is accessing
	 * @return (String[]) list.toArray(new String[list.size()])  the alert rules application messages are sent for.
	 */
	protected static String [] getSendApplicationMssgs(Connection conn, String alertGroup) throws RABCException {
		ArrayList list = new ArrayList();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String getApplMssgs = "SELECT DISTINCT C.ALERT_RULE ALERT_RULE " +
							  "FROM RABC_ALERT_RULE A, RABC_PRESN_ID B, RABC_PROC_RESPONSIBLE C " +
							  "WHERE C.ALERT_GRP = ? " +
							  "  AND C.ROLE_CD = '2' " +
							  "  AND (A.ALERT_RULE_STATUS IS NULL OR " +
							  "		  A.ALERT_RULE_STATUS <> 'DELETED')	" +
							  "  AND A.ALERT_RULE_PRESN_IND = 'Y' " +
							  "  AND A.PRESN_ID = B.PRESN_ID " +
							  "  AND C.ALERT_RULE = A.ALERT_RULE " +
							  "ORDER BY UPPER(ALERT_RULE)";
		try {
			ps = conn.prepareStatement(getApplMssgs);
			ps.setString(1, alertGroup.trim());
			rs = ps.executeQuery();
			logger.debug("Starting rs loop...");
			while (rs.next()) {
				list.add(rs.getString("ALERT_RULE"));
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving alert rules using getSystMssgs query: ", sqle);
		} catch (NumberFormatException nfe) {
			throw new RABCException("Error parsing out numeric values: ", nfe);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
		return (String[]) list.toArray(new String[list.size()]);
	}
	
	/**This static method is called by the service class to check which alert rules are attached to more
	 * than one alert group when deleting the selected alert group.  If an alert rule is attached only to
	 * the alert group being deleted, the confirm page will indicate this.
	 * 
	 * @param conn  the connection created in the service class
	 * @param alertRules  the alert rules being checked to see which ones can be deleted.
	 * @return alertRules  the alert rules that that are attached to more than one alert group
	 *                     and those attached only to this alert group.
	 */
	protected static SelectRowTO [] checkAlrtRules(Connection conn, SelectRowTO [] alertRules) throws RABCException {
		PreparedStatement ps = null;
		ResultSet rs = null;
		String chkAlrtRules = "SELECT DISTINCT ALERT_GRP " +
							  "FROM RABC_UPDATE_GRP " +
							  "WHERE ALERT_RULE = ?";
		int numberOfAlertGroups = 0;
		try {
			ps = conn.prepareStatement(chkAlrtRules);
			for (int i = 0; i < alertRules.length; i++) {
				alertRules[i].setCanDelete(0);
				if (alertRules[i].getIsSelected() == 1) {
					ps.setString(1, alertRules[i].getRowID().trim());
					rs = ps.executeQuery();
					logger.debug("Starting rs loop...");
					while (rs.next()) {
						numberOfAlertGroups++;
					}
					if (numberOfAlertGroups < 2) {
						alertRules[i].setCanDelete(1);
					}
					numberOfAlertGroups = 0;
				}
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error getting list of alert groups using the chkAlrtRules query: ", sqle);
		} catch (NumberFormatException nfe) {
			throw new RABCException("Error parsing out numeric values: ", nfe);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
		return alertRules;
	}
	
	/**This static method is called by the service class to check which alert rules are attached to more
	 * than one alert group when updating the selected alert group.  If an alert rule is on the previous alert
	 * rule list but not on the updated version and is attached only to the alert group being updated, the
	 * confirm page will indicate this.
	 * 
	 * @param conn  the connection created in the service class
	 * @param alertRules  the alert rules being checked to see which ones can be deleted from the alert
	 *                    group.
	 * @param prevAlertRules  the alert rules attached to the alert group before updates were made.
	 * @return alertRules  the alert rules that that are attached to more than one alert group
	 *                     and those attached only to this alert group.
	 */
	protected static SelectRowTO [] checkUpdatedAlrtRules(Connection conn, SelectRowTO [] alertRules, SelectRowTO [] prevAlertRules) throws RABCException {
		ArrayList list = new ArrayList();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String chkUpdatedAlrtRules = "SELECT DISTINCT ALERT_GRP " +
									 "FROM RABC_UPDATE_GRP " +
									 "WHERE ALERT_RULE = ?";
		int numberOfAlertGroups = 0;
		String [] removedAlertRules = new String[0];
		boolean found = false;
		try {
			for (int i = 0; i < prevAlertRules.length; i++) {
				for (int j = 0; j < alertRules.length; j++) {
					if (alertRules[j].getRowID().trim().equals(prevAlertRules[i].getRowID().trim())) {
						alertRules[j].setCanDelete(0);
						if (alertRules[j].getIsSelected() == prevAlertRules[i].getIsSelected())
							found = true;
						else if (alertRules[j].getIsSelected() == 1 && prevAlertRules[i].getIsSelected() == 0)
							found = true;
						else
							continue;
						break;
					}
				}
				if (!found)
					list.add(prevAlertRules[i].getRowID().trim());
				found = false;
			}
			removedAlertRules = (String[]) list.toArray(new String[list.size()]);
			ps = conn.prepareStatement(chkUpdatedAlrtRules);
			if (removedAlertRules.length > 0) {
				for (int i = 0; i < removedAlertRules.length; i++) {
					ps.setString(1, removedAlertRules[i].trim());
					rs = ps.executeQuery();
					logger.debug("Starting rs loop...");
					while (rs.next()) {
						numberOfAlertGroups++;
					}
					for (int j = 0; j < alertRules.length; j++) {
						if (alertRules[j].getRowID().trim().equals(removedAlertRules[i].trim())) {
							if (numberOfAlertGroups < 2)
								alertRules[j].setCanDelete(1);
							break;
						}
					}
					numberOfAlertGroups = 0;
				}
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving alert rules update check using chkUpdatedAlrtRules query: ", sqle);
		} catch (NumberFormatException nfe) {
			throw new RABCException("Error parsing out numeric values: ", nfe);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
		return alertRules;
	}
	
	/**This static method is called by the service class to retrieve all the ad hoc reports in RABC.  Ad hoc
	 * reports that have been removed are not included in this list.
	 * 
	 * @param conn  the connection created in the service class
	 * @return (SelectRowTO[]) list.toArray(new SelectRowTO[list.size()])  all the ad hoc reports an
	 *                                                                     alert group can have.
	 */
	protected static SelectRowTO [] getAllAdhocRpts(Connection conn) throws RABCException {
		ArrayList list = new ArrayList();
		Statement stmt = null;
		ResultSet rs = null;
		String getAllAdhoc = "SELECT DISTINCT PRESN_ID_DESC, PRESN_ID " +
							 "FROM RABC_PRESN_ID " +
							 "WHERE PRESN_ID IS NOT NULL " +
							 "AND UPPER(ADHOC_RPT_STATUS) = 'ACTIVE' " +
							 "ORDER BY PRESN_ID_DESC";
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(getAllAdhoc);
			logger.debug("Starting rs loop...");
			while (rs.next()) {
				SelectRowTO selectRow = new SelectRowTO();
				selectRow.setRowID(rs.getString("PRESN_ID"));
				selectRow.setRowName(rs.getString("PRESN_ID_DESC"));
				list.add(selectRow);
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving adhoc reports using getAllAdhoc query: ", sqle);
		} catch (NumberFormatException nfe) {
			throw new RABCException("Error parsing out numeric values: ", nfe);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closeStatement(stmt);
		}
		return (SelectRowTO[]) list.toArray(new SelectRowTO[list.size()]);
	}
	
	/**This static method is called by the service class to retrieve all the ad hoc reports tied to
	 * the alert group.  This method is accessed only when deleting an alert group.  These values are
	 * then matched against all active ad hoc reports and those selected are marked with a 'Y' on the
	 * confirm page.
	 * 
	 * @param conn  the connection created in the service class
	 * @param alertGroup  the alert group the user is accessing
	 * @return (String[]) list.toArray(new String[list.size()])  the alert rules the alert group has access to.
	 */
	protected static String [] getSelectedAdhocRpts(Connection conn, String alertGroup) throws RABCException {
		ArrayList list = new ArrayList();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String getSelAdhoc = "SELECT DISTINCT BPI.PRESN_ID_DESC PRESN_ID_DESC, BUG.PRESN_ID PRESN_ID " +
							 "FROM RABC_UPDATE_GRP BUG, RABC_PRESN_ID BPI " +
							 "WHERE UPPER(BUG.ALERT_GRP) = ? " +
							 "  AND BUG.PRESN_ID IS NOT NULL " +
							 "  AND UPPER(BPI.ADHOC_RPT_STATUS) = 'ACTIVE' " +
							 "  AND BPI.PRESN_ID = BUG.PRESN_ID " +
							 "ORDER BY PRESN_ID_DESC";
		try {
			ps = conn.prepareStatement(getSelAdhoc);
			ps.setString(1, alertGroup.trim().toUpperCase());
			rs = ps.executeQuery();
			logger.debug("Starting rs loop...");
			while (rs.next()) {
				list.add(rs.getString("PRESN_ID"));
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving adhoc reports using getSelAdhoc query: ", sqle);
		} catch (NumberFormatException nfe) {
			throw new RABCException("Error parsing out numeric values: ", nfe);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
		return (String[]) list.toArray(new String[list.size()]);
	}
	
	/**This static method is called by the service class to check which ad hoc reports are attached to more
	 * than one alert group when deleting the selected alert group.  If an ad hoc report is attached only to
	 * the alert group being deleted, the confirm page will indicate this.
	 * 
	 * @param conn  the connection created in the service class
	 * @param adhocReports  the ad hoc reports being checked to see which ones can be deleted.
	 * @return adhocReports  the ad hoc reports that are attached to more than one alert group
	 *                       and those attached only to this alert group.
	 */
	protected static SelectRowTO [] checkAdhocRpts(Connection conn, SelectRowTO [] adhocReports) throws RABCException {
		PreparedStatement ps = null;
		ResultSet rs = null;
		String chkAdhocRpts = "SELECT DISTINCT ALERT_GRP " +
							  "FROM RABC_UPDATE_GRP " +
							  "WHERE PRESN_ID = ?";
		int numberOfAlertGroups = 0;
		try {
			ps = conn.prepareStatement(chkAdhocRpts);
			for (int i = 0; i < adhocReports.length; i++) {
				adhocReports[i].setCanDelete(0);
				if (adhocReports[i].getIsSelected() == 1) {
					ps.setInt(1, Integer.parseInt(adhocReports[i].getRowID().trim()));
					rs = ps.executeQuery();
					logger.debug("Starting rs loop...");
					while (rs.next()) {
						numberOfAlertGroups++;
					}
					if (numberOfAlertGroups < 2) {
						adhocReports[i].setCanDelete(1);
					}
					numberOfAlertGroups = 0;
				}
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving alert rules delete check using chkAdhocRpts query: ", sqle);
		} catch (NumberFormatException nfe) {
			throw new RABCException("Error parsing out numeric values: ", nfe);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
		return adhocReports;
	}
	
	/**This static method is called by the service class to delete the selected alert group from the RABC_ALERT_GRP,
	 * RABC_ALERT_GRP_USER, RABC_UPDATE_GRP, RABC_ALERT_GRP_FUNCT, and RABC_PROC_RESPONSIBLE tables.  This method
	 * is accessed when either deleting or updating an alert group.
	 * 
	 * @param conn  the connection created in the service class
	 * @param alertGroup  the alert group being deleted or updated.
	 */
	protected static void deleteGroup(Connection conn, String alertGroup) throws RABCException {
		PreparedStatement ps1 = null;
		PreparedStatement ps2 = null;
		PreparedStatement ps3 = null;
		PreparedStatement ps4 = null;
		PreparedStatement ps5 = null;
		String deleteFromAlertGroup = "DELETE FROM RABC_ALERT_GRP WHERE UPPER(ALERT_GRP) = ?";
		String deleteFromAlertGroupUser = "DELETE FROM RABC_ALERT_GRP_USER WHERE UPPER(ALERT_GRP) = ?";
		String deleteFromAlertGroupUpdate = "DELETE FROM RABC_UPDATE_GRP WHERE UPPER(ALERT_GRP) = ?";
		String deleteFromAlertGroupFunct = "DELETE FROM RABC_ALERT_GRP_FUNCT WHERE UPPER(ALERT_GRP) = ? AND FUNCT_CD <> 'AG'";
		String deleteFromProcResponsible = "DELETE FROM RABC_PROC_RESPONSIBLE WHERE UPPER(ALERT_GRP) = ?";
		try {
			logger.debug("Starting deletes...");
			ps1 = conn.prepareStatement(deleteFromAlertGroup);
			ps1.setString(1, alertGroup.trim().toUpperCase());
			ps1.execute();
			ps2 = conn.prepareStatement(deleteFromAlertGroupUser);
			ps2.setString(1, alertGroup.trim().toUpperCase());
			ps2.execute();
			ps3 = conn.prepareStatement(deleteFromAlertGroupUpdate);
			ps3.setString(1, alertGroup.trim().toUpperCase());
			ps3.execute();
			ps4 = conn.prepareStatement(deleteFromAlertGroupFunct);
			ps4.setString(1, alertGroup.trim().toUpperCase());
			ps4.execute();
			ps5 = conn.prepareStatement(deleteFromProcResponsible);
			ps5.setString(1, alertGroup.trim().toUpperCase());
			ps5.execute();
		} catch (SQLException sqle) {
			throw new RABCException("Error in deleting alert groups: ", sqle);
		} catch (NumberFormatException nfe) {
			throw new RABCException("Error parsing out numeric values: ", nfe);
		} finally {
			JDBCUtil.closePreparedStatement(ps1);
			JDBCUtil.closePreparedStatement(ps2);
			JDBCUtil.closePreparedStatement(ps3);
			JDBCUtil.closePreparedStatement(ps4);
			JDBCUtil.closePreparedStatement(ps5);
		}
	}
	
	/**This static method is called by the service class to insert the selected alert group into the RABC_ALERT_GRP,
	 * RABC_ALERT_GRP_USER, RABC_UPDATE_GRP, RABC_ALERT_GRP_FUNCT, and RABC_PROC_RESPONSIBLE tables.  This method
	 * is accessed when either inserting or updating an alert group.
	 * 
	 * @param conn  the connection created in the service class
	 * @param alertGroup  the alert group being inserted or updated.
	 * @param String alertGroupDesc  the description of the alert group being inserted or updated.
	 * @param users  the members of an alert group being inserted or updated.
	 * @param alertRules  the alert rules associated with the alert group being inserted or updated.
	 * @param applicationFunctions  the application functions associated with the alert group being
	 *                              inserted or updated.
	 */
	protected static void insertGroup(Connection conn, String alertGroup, String alertGroupDesc, User [] users, SelectRowTO [] alertRules, SelectRowTO [] applicationFunctions) throws RABCException {
		PreparedStatement ps1 = null;
		PreparedStatement ps2 = null;
		PreparedStatement ps3 = null;
		PreparedStatement ps4 = null;
		PreparedStatement ps5 = null;
		PreparedStatement ps6 = null;
		String insertIntoAlertGroup = "INSERT INTO RABC_ALERT_GRP (ALERT_GRP, ALERT_GRP_DESC) VALUES (?, ?)";
		String insertIntoAlertGroupUser = "INSERT INTO RABC_ALERT_GRP_USER (ALERT_GRP, USER_ID) VALUES (?, ?)";
		String insertIntoAlertGroupUpdate = "INSERT INTO RABC_UPDATE_GRP (ALERT_GRP, ALERT_RULE) VALUES (?, ?)";
		String insertIntoAlertGroupFunct = "INSERT INTO RABC_ALERT_GRP_FUNCT (ALERT_GRP, FUNCT_CD) VALUES (?, ?)";
		String insertIntoProcResponsibleSystem = "INSERT INTO RABC_PROC_RESPONSIBLE (ALERT_GRP, ALERT_RULE, ROLE_CD) VALUES (?, ?, 1)";
		String insertIntoProcResponsibleApplication = "INSERT INTO RABC_PROC_RESPONSIBLE (ALERT_GRP, ALERT_RULE, ROLE_CD) VALUES (?, ?, 2)";
		try {
			logger.debug("Starting inserts...");
			ps1 = conn.prepareStatement(insertIntoAlertGroup);
			ps1.setString(1, alertGroup.trim());
			ps1.setString(2, alertGroupDesc.trim());
			ps1.execute();
			ps2 = conn.prepareStatement(insertIntoAlertGroupUser);
			for (int i = 0; i < users.length; i++) {
				ps2.setString(1, alertGroup.trim());
				ps2.setString(2, users[i].getUserId().trim());
				ps2.addBatch();
			}
			ps2.executeBatch();
			ps3 = conn.prepareStatement(insertIntoAlertGroupUpdate);
			ps5 = conn.prepareStatement(insertIntoProcResponsibleSystem);
			ps6 = conn.prepareStatement(insertIntoProcResponsibleApplication);
			for (int i = 0; i < alertRules.length; i++) {
				if (alertRules[i].getIsSelected() == 1) {
					ps3.setString(1, alertGroup.trim());
					ps3.setString(2, alertRules[i].getRowID().trim());
					ps3.addBatch();
				}
				if (alertRules[i].getSystemMessage() == 1) {
					ps5.setString(1, alertGroup.trim());
					ps5.setString(2, alertRules[i].getRowID().trim());
					ps5.addBatch();
				}
				if (alertRules[i].getApplicationMessage() == 1) {
					ps6.setString(1, alertGroup.trim());
					ps6.setString(2, alertRules[i].getRowID().trim());
					ps6.addBatch();
				}
			}
			ps3.executeBatch();
			ps5.executeBatch();
			ps6.executeBatch();
			ps4 = conn.prepareStatement(insertIntoAlertGroupFunct);
			for (int i = 0; i < applicationFunctions.length; i++) {
				if (applicationFunctions[i].getIsSelected() == 1) {
					ps4.setString(1, alertGroup.trim());
					ps4.setString(2, applicationFunctions[i].getRowID().trim());
					ps4.addBatch();
				}
			}
			ps4.executeBatch();
		} catch (SQLException sqle) {
			throw new RABCException("Error in inserting alert groups: ", sqle);
		} catch (NumberFormatException nfe) {
			throw new RABCException("Error parsing out numeric values: ", nfe);
		} finally {
			JDBCUtil.closePreparedStatement(ps1);
			JDBCUtil.closePreparedStatement(ps2);
			JDBCUtil.closePreparedStatement(ps3);
			JDBCUtil.closePreparedStatement(ps4);
			JDBCUtil.closePreparedStatement(ps5);
			JDBCUtil.closePreparedStatement(ps6);
		}
	}
	
	/**This static method is called by the service class to re-insert the adhoc reports associated with the alert
	 * group back into the RABC_UPDATE_GRP table.  This method is accessed when updating an alert group.
	 * 
	 * @param conn  the connection created in the service class
	 * @param alertGroup  the alert group being inserted or updated.
	 * @param adhocReports  the adhoc reports that need to be re-inserted into RABC_UPDATE_GRP.
	 */
	protected static void reinsertAdhocReports(Connection conn, String alertGroup, String [] adhocReports) throws RABCException {
		PreparedStatement ps = null;
		ResultSet rs = null;
		String reinsertAdhocRpts = "INSERT INTO RABC_UPDATE_GRP (ALERT_GRP, PRESN_ID) VALUES (?, ?)";
		try {
			ps = conn.prepareStatement(reinsertAdhocRpts);
			for (int i = 0; i < adhocReports.length; i++) {
				ps.setString(1, alertGroup.trim());
				ps.setString(2, adhocReports[i].trim());
				ps.addBatch();
			}
			ps.executeBatch();
		} catch (SQLException sqle) {
			throw new RABCException("Error re-inserting ad hoc reports : ", sqle);
		} catch (NumberFormatException nfe) {
			throw new RABCException("Error parsing out numeric values: ", nfe);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
	}
	
	/**This static method is called by the service class to show what alert groups a particular RABC user is
	 * associated with.  The application functions and alert rules associated with that alert group are also
	 * shown.
	 * 
	 * @param conn  the connection created in the service class
	 * @param userID  the RABC user being checked on.
	 * @return (UserAccessTO[]) list.toArray(new UserAccessTO[list.size()])  the alert groups associated with the
	 *                                                                       RABC user along with application functions
	 *                                                                       and alert rules associated with the alert
	 *                                                                       group.
	 */
	protected static UserAccessTO [] getUserAccList(Connection conn, String userID) throws RABCException {
		ArrayList list = new ArrayList();
		ArrayList subList = new ArrayList();
		PreparedStatement ps1 = null;
		PreparedStatement ps2 = null;
		PreparedStatement ps3 = null;
		ResultSet rs1 = null;
		ResultSet rs2 = null;
		ResultSet rs3 = null;
		String getAlrtGrps = "SELECT DISTINCT ALERT_GRP " +
							 "FROM RABC_ALERT_GRP_USER " +
							 "WHERE UPPER(USER_ID) = ? " +
							 "ORDER BY ALERT_GRP";
		String getAlrtRules = "SELECT BUG.ALERT_RULE AS ALERT_RULE " +
							  "FROM RABC_UPDATE_GRP BUG, RABC_ALERT_RULE BAR " +
							  "WHERE UPPER(BUG.ALERT_GRP) = ? " +
							  "AND (BAR.ALERT_RULE_STATUS IS NULL OR BAR.ALERT_RULE_STATUS <> 'DELETED') " +
							  "AND BAR.ALERT_RULE_PRESN_IND = 'Y' " +
							  "AND BUG.ALERT_RULE = BAR.ALERT_RULE " +
							  "ORDER BY BUG.ALERT_RULE";
		String getAdhocRpts = "SELECT DISTINCT BPI.PRESN_ID_DESC AS PRESN_ID_DESC " +
							  "FROM RABC_UPDATE_GRP BUG, RABC_PRESN_ID BPI " +
							  "WHERE UPPER(BUG.ALERT_GRP) = ? " +
							  "AND BUG.PRESN_ID IS NOT NULL " +
							  "AND UPPER(BPI.ADHOC_RPT_STATUS) = 'ACTIVE' " +
							  "AND BPI.PRESN_ID = BUG.PRESN_ID " +
							  "ORDER BY BPI.PRESN_ID_DESC";
		try {
			ps1 = conn.prepareStatement(getAlrtGrps);
			ps2 = conn.prepareStatement(getAlrtRules);
			ps3 = conn.prepareStatement(getAdhocRpts);
			ps1.setString(1, userID.trim().toUpperCase());
			rs1 = ps1.executeQuery();
			logger.debug("Starting rs1 loop...");
			while (rs1.next()) {
				UserAccessTO userAccess = new UserAccessTO();
				userAccess.setAlertGroup(rs1.getString("ALERT_GRP"));
				
				ps2.setString(1, userAccess.getAlertGroup().trim().toUpperCase());
				rs2 = ps2.executeQuery();
				logger.debug("Starting rs2 loop...");
				if (rs2.next()) {
					subList.add(rs2.getString("ALERT_RULE"));
					while (rs2.next()) {
						subList.add(rs2.getString("ALERT_RULE"));
					}
				} else {
					subList.add("None");
				}
				userAccess.setAlertRules((String[]) subList.toArray(new String[subList.size()]));
				subList.clear();
				
				ps3.setString(1, userAccess.getAlertGroup().trim().toUpperCase());
				rs3 = ps3.executeQuery();
				logger.debug("Starting rs3 loop...");
				if (rs3.next()) {
					subList.add(rs3.getString("PRESN_ID_DESC"));
					while (rs3.next()) {
						subList.add(rs3.getString("PRESN_ID_DESC"));
					}
				} else {
					subList.add("None");
				}
				userAccess.setAdhocReports((String[]) subList.toArray(new String[subList.size()]));
				subList.clear();
				
				list.add(userAccess);
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving user access data using user access queries: ", sqle);
		} catch (NumberFormatException nfe) {
			throw new RABCException("Error parsing out numeric values: ", nfe);
		} finally {
			JDBCUtil.closeResultSet(rs1);
			JDBCUtil.closeResultSet(rs2);
			JDBCUtil.closeResultSet(rs3);
			JDBCUtil.closePreparedStatement(ps1);
			JDBCUtil.closePreparedStatement(ps2);
			JDBCUtil.closePreparedStatement(ps3);
		}
		return (UserAccessTO[]) list.toArray(new UserAccessTO[list.size()]);
	}
}
