/* Created on Oct 07, 2007 by GB0741
 * Copyright 2008 AT&T Knowledge Ventures. All rights reserved
 */
package com.att.bac.rabc.load.calnet.telcoacus;


public class CrisAcusException extends Exception {
    
	/**
	 * Constructor without parameters
	 */
	public CrisAcusException() {
        super();
    }
	
    /**
     * Constructor with one parameter
     * @param arg0
     */
    public CrisAcusException(String arg0) {
        super(arg0);
    }
    
    /**
     * Constructor with throwable parameter
     * @param arg0 -- throwable parameter
     */
    public CrisAcusException(Throwable arg0) {
        super(arg0);
    }
    
    /**
     * Constructor with 2 parameters
     * @param arg0
     * @param arg1 -- throwable parameter
     */
    public CrisAcusException(String arg0, Throwable arg1) {
        super(arg0, arg1);
    }
}
