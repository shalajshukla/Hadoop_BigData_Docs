/*
 * copyright 2002-2007 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.adhoc.rpt;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import com.att.bac.rabc.DataTblDdlBean;
import com.att.bac.rabc.StaticDataLoader;
import com.att.bac.rabc.adhoc.AdhocConstants;
import com.sbc.bac.aria.RowElement;


/**
 * Module description: This is the Adhoc Report data transfer object for all form fields.
 * 
 * <p>
 * <hr>
 * <h3>Release History</h3>
 * <p>
 * <ul>
 * 
 * <li>PD2951 20051216 Initial version for EAP 556010
 * <li>JB6494 05/08/2006 Added method to clear "lists"
 * <li>JB6494 10/31/2006 Removed dead code.
 * <li>JB6494 02/09/2007 Added user selected sort information (sorted form)
 * <li>jb6494 Mar 03, 2007 Updated sorting for ST ML#08
 * 
 * </ul>
 * <p>
 * 
 * 
 */
public class AdhocRptDataTO implements Serializable, AdhocConstants, Cloneable {

    private String adhocTest = "N"; // to check if Adhoc Report Test button is clicked

    private String alertTimeInd = "";

    private ArrayList alertTimeIndOptions = new ArrayList();

    private int alertTimeValue = -1; // 0=All, 1-7=Sunday-Saturday, or, bill round

    private int alertTimeValueBR = -1;

    private ArrayList alertTimeValueOptions = new ArrayList();

    private ArrayList alertTimeValueOptionsBR = new ArrayList();

    private ArrayList alertTimeValueOptionsWD = new ArrayList();

    private int alertTimeValueWD = -1;

    private String aliasNames = null;

    private int begSubTotLvl = -1;

    private int billRnd = 0;

    private ArrayList billRndOptions = new ArrayList();

    private String clickLvl = "1";

    private ArrayList columnsAsOracleList = new ArrayList(); // <CFSET COLUMNSASORACLE = ARRAYNEW(1)>

    private ArrayList columnsHeadersList = new ArrayList(); // <CFSET COLUMNSHEADERS = ARRAYNEW(1)>

    /**
     * Keep long named columns here and replace them with a generic in the columnsHeadersList. This offsets errors if
     * the name is too long.
     */
    private List columnsHeadersListExpanded = new ArrayList(); // temporary until code can be changed.

    private ArrayList columnsTablesList = new ArrayList(); // <CFSET COLUMNSTABLES = ARRAYNEW(1)>

    private ArrayList columnsToExtractList = new ArrayList(); // <CFSET COLUMNSTOEXTRACT = ARRAYNEW(1)>

    private String databaseNode = "BACAUTHUNIX";

    private ArrayList dataDescIndList = new ArrayList(); // <CFSET A_DATA_DESC_IND = ARRAYNEW(1)>

    private ArrayList dataLinkIndList = new ArrayList(); // <CFSET A_DATA_LINK_IND = ARRAYNEW(1)>

    private ArrayList dataLinkPresnIdList = new ArrayList(); // <CFSET A_DATA_LINK_PRESN_ID = ARRAYNEW(1)>

    private ArrayList dataLinkTblKeyDataList = new ArrayList(); // <CFSET A_DATA_LINK_TBL_KEY_DATA = ARRAYNEW(1)>

    private ArrayList dataLinkTblKeyNameList = new ArrayList(); // <CFSET A_DATA_LINK_TBL_KEY_NAME = ARRAYNEW(1)>

    private ArrayList dataLinkTblNameList = new ArrayList(); // <CFSET A_DATA_LINK_TBL_NAME = ARRAYNEW(1)>

    private ArrayList dataLinkToPgmList = new ArrayList(); // <CFSET A_DATA_LINK_TO_PGM = ARRAYNEW(1)>

    private ArrayList dataMouseOverNumList = new ArrayList(); // <CFSET A_DATA_MOUSE_OVER_NUM = ARRAYNEW(1)>

    private ArrayList distExecPresnSeqNumList = new ArrayList(); // <CFSET A_DIST_EXEC_PRESN_SEQ_NUM =ARRAYNEW(1)>

    private String divisionList = null;

    private String divisionName = null; // original CFMX var storing a comma separated list of selected division codes

    private String divisionName1 = null; // same list as above except that the division codes are enclosed by "'"

    private transient ArrayList divisions = new ArrayList(); // contains PickList objects with key=div code and

    private String divisionYes = "N";

    private int divNameKeyLvl = -1;

    private String emailReport = "N";

    private String endDate = null;

    private int endSubTotLvl = -1;

    private int fileSeqNum = -1;

    private String fileSeqNumAsString = null;

    private String fileSeqNumInd = null;

    private String fromPage = null;

    private String genEndDate = null;

    private String genStartDate = null;

    private ArrayList graphPresnIndList = new ArrayList(); // <CFSET A_GRAPH_PRESN_IND = ARRAYNEW(1)>

    private ArrayList headerLinkIndList = new ArrayList(); // <CFSET A_HEADER_LINK_IND = ARRAYNEW(1)>

    private ArrayList headerLinkPresnIdList = new ArrayList(); // <CFSET A_HEADER_LINK_PRESN_ID = ARRAYNEW(1)>

    private ArrayList headerLinkToPgmList = new ArrayList(); // <CFSET A_HEADER_LINK_TO_PGM = ARRAYNEW(1)>

    private ArrayList headerMouseOverNumList = new ArrayList(); // <CFSET A_HEADER_MOUSE_OVER_NUM = ARRAYNEW(1)>

    private boolean hideAlertRuleTiming = true;

    private boolean hideCreate = false;

    private boolean hideDivCheckBox = true;

    // private boolean hideDivLabel = true;
    private boolean hideDivDropDown = true;

    private boolean hideEmail = false;

    private boolean hideFileSeqNum = true;

    private boolean hideMonthYear = true;

    private boolean hideNext = false;

    private boolean hidePrev = false;

    private boolean hideSortKeyList = true;

    private boolean hideSortKeyList2 = true;

    private boolean hideView = false;

    private String key1 = null;

    private String key2 = null;

    private String key3 = null;

    private String key4 = null;

    private String key5 = null;

    private ArrayList keysRow1AliasList = new ArrayList(); // <CFSET KEYSROW1ALIAS = ARRAYNEW(1)>

    private ArrayList keysRow1ColumnsList = new ArrayList(); // <CFSET KEYSROW1COLUMNS = ARRAYNEW(1)>

    private String labelSortKeyList = null;

    private String labelSortKeyList2 = null;

    private int monthSelect = 0;

    private ArrayList monthSelectOptions = new ArrayList();

    private String newGenUrlString = null;

    private String newUrl = null;

    private String noProcDate = null;

    private boolean onlySelected = false;

    private int partiRefId = -1;

    private ArrayList partiRefIdList = new ArrayList(); // <CFSET A_PARTI_REF_ID = ARRAYNEW(1)>

    private ArrayList presnCalcNumList = new ArrayList(); // <CFSET A_PRESN_CALC_NUM = ARRAYNEW(1)>

    private ArrayList presnFormatList = new ArrayList(); // <CFSET A_PRESN_FORMAT = ARRAYNEW(1)>

    private int presnId = -1;

    private String presnIdAsString = null;

    private int presnModel = 1;

    private ArrayList presnOrdIndList = new ArrayList(); // <CFSET A_PRESN_ORD_IND = ARRAYNEW(1)>

    private ArrayList presnSumIndList = new ArrayList(); // <CFSET A_PRESN_SUM_IND = ARRAYNEW(1)>

    private ArrayList presnSuppressIndList = new ArrayList(); // <CFSET A_PRESN_SUPPRESS_IND = ARRAYNEW(1)>

    private String presnTblName = null;

    private String presnTrendTime = null;

    private ArrayList presnUnitIndList = new ArrayList(); // <CFSET A_PRESN_UNIT_IND = ARRAYNEW(1)>

    private List previous = new ArrayList();
    private List difference = new ArrayList();

    private String procDate = null;

    private String procDateInd = "X";

    private String queryValue = null;

    private boolean recCountFlag = false;

    private String region = null;

    private String row1Columns = null;

    private String rptHeader1 = null;

    private String rptHeader2 = null;

    private String rptHeader3 = null;

    private String rptHeaderDateInd = null;

    private String[] selectedDivs = new String[0]; // populated when checkboxes are selected

    private boolean selectUniqRows = false;

    private String sortKeyList = "";

    private String sortKeyList2 = "";

    private String startDate = null;

    private String styleAlertTimeValue = "display:inline";

    private String styleAlertTimeValueBR = "display:none";

    private String styleAlertTimeValueWD = "display:none";

    private String tableNames = null;

    private String timingFilterCode = null;

    private char userSortType = 'A'; // A, D, blank

    private String userSortColumn = null;

    private ArrayList viewNameList = new ArrayList(); // <CFSET A_VIEW_NAME = ARRAYNEW(1)>

    private final String webId = "RABCPSF00013";

    private int yearSelect = 0;

    private ArrayList yearSelectOptions = new ArrayList();

    private List generatedSQL = new ArrayList();

    private ArrayList columnsDataTypeList = new ArrayList();// New list variable added to get the column data types
    
    private String procDateFormat;
    
    private String billRoundCheck;
    
    private boolean hideBillRoundCheck = true;
    
    private int dataKeyLvl;
    
    private String pagedHtml;

    //New added for row data for previous logic. PMT #M169
    private List<RowElement> rowData = new ArrayList<RowElement>();
  //New added for row data for previous logic. PMT #M169
    private int rowDataCnt = 0 ; 
    
    /**
     * Clear all entries in the "data lists".
     */
    public void clearListData() {
        headerLinkIndList.clear();
        headerMouseOverNumList.clear();
        dataLinkIndList.clear();
        dataDescIndList.clear();
        dataMouseOverNumList.clear();
        headerLinkToPgmList.clear();
        headerLinkPresnIdList.clear();
        dataLinkToPgmList.clear();
        dataLinkPresnIdList.clear();
        dataLinkTblKeyDataList.clear();
        dataLinkTblNameList.clear();
        dataLinkTblKeyNameList.clear();
        graphPresnIndList.clear();
        presnUnitIndList.clear();
        presnSumIndList.clear();
        presnCalcNumList.clear();
        presnSuppressIndList.clear();
        viewNameList.clear();
        presnOrdIndList.clear();
        presnFormatList.clear();
        previous.clear();
        difference.clear();
        partiRefIdList.clear();
        columnsHeadersList.clear();
        columnsToExtractList.clear();
        columnsAsOracleList.clear();
        columnsTablesList.clear();
        keysRow1ColumnsList.clear();
        keysRow1AliasList.clear();
        generatedSQL.clear();
        columnsDataTypeList.clear();
        rowData.clear();
    }


    /**
     * A clone by any other name. Deep clone
     * 
     * @return
     */
    public AdhocRptDataTO duplicate() {
        try {
            ByteArrayOutputStream os = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(os);
            oos.writeObject(this);
            oos.flush();
            os.flush();

            ByteArrayInputStream is = new ByteArrayInputStream(os.toByteArray());
            ObjectInputStream ois = new ObjectInputStream(is);
            AdhocRptDataTO clone = (AdhocRptDataTO) ois.readObject();

            os.close();
            oos.close();
            is.close();
            ois.close();

            return clone;

        } catch (Exception e) {
            throw new IllegalArgumentException("Unable to duplicate DTO: e=" + e);
        }
    }


    /**
     * @return
     */
    public String getAdhocTest() {
        return adhocTest;
    }


    /**
     * @return
     */
    public String getAlertTimeInd() {
        return alertTimeInd;
    }


    /**
     * @return
     */
    public ArrayList getAlertTimeIndOptions() {
        return alertTimeIndOptions;
    }


    /**
     * @return
     */
    public int getAlertTimeValue() {
        return alertTimeValue;
    }


    /**
     * @return
     */
    public int getAlertTimeValueBR() {
        return alertTimeValueBR;
    }


    /**
     * @return
     */
    public ArrayList getAlertTimeValueOptions() {
        return alertTimeValueOptions;
    }


    /**
     * @return
     */
    public ArrayList getAlertTimeValueOptionsBR() {
        return alertTimeValueOptionsBR;
    }


    /**
     * @return
     */
    public ArrayList getAlertTimeValueOptionsWD() {
        return alertTimeValueOptionsWD;
    }


    /**
     * @return
     */
    public int getAlertTimeValueWD() {
        return alertTimeValueWD;
    }


    /**
     * SQL generated by ARIA. For debugging purposes
     * 
     * @return
     */
    public List getGeneratedSQL() {
        return generatedSQL;
    }


    /**
     * @return
     */
    public String getAliasNames() {
        return aliasNames;
    }


    /**
     * @return
     */
    public int getBegSubTotLvl() {
        return begSubTotLvl;
    }


    /**
     * @return
     */
    public int getBillRnd() {
        return billRnd;
    }


    /**
     * @return
     */
    public ArrayList getBillRndOptions() {
        return billRndOptions;
    }


    /**
     * @return
     */
    public String getClickLvl() {
        return clickLvl;
    }


    /**
     * @return
     */
    public ArrayList getColumnsAsOracleList() {
        return columnsAsOracleList;
    }


    /**
     * @return
     */
    public ArrayList getColumnsHeadersList() {
        return columnsHeadersList;
    }


    /**
     * @return Returns the columnsHeadersListExpanded.
     */
    public List getColumnsHeadersListExpanded() {
        return columnsHeadersListExpanded;
    }


    /**
     * @return
     */
    public ArrayList getColumnsTablesList() {
        return columnsTablesList;
    }


    /**
     * @return
     */
    public ArrayList getColumnsToExtractList() {
        return columnsToExtractList;
    }


    /**
     * @return
     */
    public String getDatabaseNode() {
        return databaseNode;
    }


    /**
     * @return
     */
    public ArrayList getDataDescIndList() {
        return dataDescIndList;
    }


    /**
     * @return
     */
    public ArrayList getDataLinkIndList() {
        return dataLinkIndList;
    }


    /**
     * @return
     */
    public ArrayList getDataLinkPresnIdList() {
        return dataLinkPresnIdList;
    }


    /**
     * @return
     */
    public ArrayList getDataLinkTblKeyDataList() {
        return dataLinkTblKeyDataList;
    }


    /**
     * @return
     */
    public ArrayList getDataLinkTblKeyNameList() {
        return dataLinkTblKeyNameList;
    }


    /**
     * @return
     */
    public ArrayList getDataLinkTblNameList() {
        return dataLinkTblNameList;
    }


    /**
     * @return
     */
    public ArrayList getDataLinkToPgmList() {
        return dataLinkToPgmList;
    }


    /**
     * @return
     */
    public ArrayList getDataMouseOverNumList() {
        return dataMouseOverNumList;
    }


    /**
     * @return
     */
    public ArrayList getDistExecPresnSeqNumList() {
        return distExecPresnSeqNumList;
    }


    /**
     * @return
     */
    public String getDivisionList() {
        return divisionList;
    }


    /**
     * @return
     */
    public String getDivisionName() {
        return divisionName;
    }


    /**
     * @return
     */
    public String getDivisionName1() {
        return divisionName1;
    }


    /**
     * @return
     */
    public ArrayList getDivisions() {
        return divisions;
    }


    /**
     * @return
     */
    public String getDivisionYes() {
        return divisionYes;
    }


    /**
     * @return
     */
    public int getDivNameKeyLvl() {
        return divNameKeyLvl;
    }


    /**
     * @return
     */
    public String getEmailReport() {
        return emailReport;
    }


    /**
     * @return
     */
    public String getEndDate() {
        return endDate;
    }


    /**
     * @return
     */
    public int getEndSubTotLvl() {
        return endSubTotLvl;
    }


    /**
     * @return
     */
    public int getFileSeqNum() {
        return fileSeqNum;
    }


    /**
     * @return
     */
    public String getFileSeqNumAsString() {
        return fileSeqNumAsString;
    }


    /**
     * @return
     */
    public String getFileSeqNumInd() {
        return fileSeqNumInd;
    }


    /**
     * @return
     */
    public String getFromPage() {
        return fromPage;
    }


    /**
     * @return
     */
    public String getGenEndDate() {
        return genEndDate;
    }


    /**
     * @return
     */
    public String getGenStartDate() {
        return genStartDate;
    }


    /**
     * @return
     */
    public ArrayList getGraphPresnIndList() {
        return graphPresnIndList;
    }


    /**
     * @return
     */
    public ArrayList getHeaderLinkIndList() {
        return headerLinkIndList;
    }


    /**
     * @return
     */
    public ArrayList getHeaderLinkPresnIdList() {
        return headerLinkPresnIdList;
    }


    /**
     * @return
     */
    public ArrayList getHeaderLinkToPgmList() {
        return headerLinkToPgmList;
    }


    /**
     * @return
     */
    public ArrayList getHeaderMouseOverNumList() {
        return headerMouseOverNumList;
    }


    /**
     * @return
     */
    public String getKey1() {
        return key1;
    }


    /**
     * @return
     */
    public String getKey2() {
        return key2;
    }


    /**
     * @return
     */
    public String getKey3() {
        return key3;
    }


    /**
     * @return
     */
    public String getKey4() {
        return key4;
    }


    /**
     * @return
     */
    public String getKey5() {
        return key5;
    }


    /**
     * @return
     */
    public ArrayList getKeysRow1AliasList() {
        return keysRow1AliasList;
    }


    /**
     * @return
     */
    public ArrayList getKeysRow1ColumnsList() {
        return keysRow1ColumnsList;
    }


    /**
     * @return
     */
    public String getLabelSortKeyList() {
        return labelSortKeyList;
    }


    /**
     * @return
     */
    public String getLabelSortKeyList2() {
        return labelSortKeyList2;
    }


    /**
     * @return
     */
    public int getMonthSelect() {
        return monthSelect;
    }


    /**
     * @return
     */
    public ArrayList getMonthSelectOptions() {
        return monthSelectOptions;
    }


    /**
     * @return
     */
    public String getNewGenUrlString() {
        return newGenUrlString;
    }


    /**
     * @return
     */
    public String getNewUrl() {
        return newUrl;
    }


    /**
     * @return
     */
    public String getNoProcDate() {
        return noProcDate;
    }


    /**
     * @return
     */
    public int getPartiRefId() {
        return partiRefId;
    }


    /**
     * @return
     */
    public ArrayList getPartiRefIdList() {
        return partiRefIdList;
    }


    /**
     * @return
     */
    public ArrayList getPresnCalcNumList() {
        return presnCalcNumList;
    }


    /**
     * @return
     */
    public ArrayList getPresnFormatList() {
        return presnFormatList;
    }


    /**
     * @return
     */
    public int getPresnId() {
        return presnId;
    }


    /**
     * @return
     */
    public String getPresnIdAsString() {
        return presnIdAsString;
    }


    /**
     * @return
     */
    public int getPresnModel() {
        return presnModel;
    }


    /**
     * @return
     */
    public ArrayList getPresnOrdIndList() {
        return presnOrdIndList;
    }


    /**
     * @return
     */
    public ArrayList getPresnSumIndList() {
        return presnSumIndList;
    }


    /**
     * @return
     */
    public ArrayList getPresnSuppressIndList() {
        return presnSuppressIndList;
    }


    /**
     * @return
     */
    public String getPresnTblName() {
        return presnTblName;
    }


    /**
     * @return
     */
    public String getPresnTrendTime() {
        return presnTrendTime;
    }


    /**
     * @return
     */
    public ArrayList getPresnUnitIndList() {
        return presnUnitIndList;
    }


    /**
     * Previous indicator, used in generator
     * 
     * @return
     */
    public List getPrevDataIndList() {
        return previous;
    }
    
    public List getDiffDataIndList() {
        return difference;
    }


    /**
     * @return
     */
    public String getProcDate() {
        return procDate;
    }


    /**
     * @return
     */
    public String getProcDateInd() {
        return procDateInd;
    }


    /**
     * @return
     */
    public String getQueryValue() {
        return queryValue;
    }


    /**
     * @return
     */
    public String getRegion() {
        return region;
    }


    /**
     * @return
     */
    public String getRow1Columns() {
        return row1Columns;
    }


    /**
     * @return
     */
    public String getRptHeader1() {
        return rptHeader1;
    }


    /**
     * @return
     */
    public String getRptHeader2() {
        return rptHeader2;
    }


    /**
     * @return
     */
    public String getRptHeader3() {
        return rptHeader3;
    }


    /**
     * @return
     */
    public String getRptHeaderDateInd() {
        return rptHeaderDateInd;
    }


    /**
     * @return
     */
    public String[] getSelectedDivs() {
        return selectedDivs;
    }


    /**
     * @return
     */
    public String getSortKeyList() {
        return sortKeyList;
    }


    /**
     * @return
     */
    public String getSortKeyList2() {
        return sortKeyList2;
    }


    /**
     * @return
     */
    public String getStartDate() {
        return startDate;
    }


    /**
     * @return
     */
    public String getStyleAlertTimeValue() {
        return styleAlertTimeValue;
    }


    /**
     * @return
     */
    public String getStyleAlertTimeValueBR() {
        return styleAlertTimeValueBR;
    }


    /**
     * @return
     */
    public String getStyleAlertTimeValueWD() {
        return styleAlertTimeValueWD;
    }


    /**
     * @return
     */
    public String getTableNames() {
        return tableNames;
    }


    /**
     * @return
     */
    public String getTimingFilterCode() {
        return timingFilterCode;
    }


    public String getUserSortColumn() {
        return userSortColumn;
    }


    /**
     * @return
     */
    public ArrayList getViewNameList() {
        return viewNameList;
    }


    /**
     * @return
     */
    public String getWebId() {
        return webId;
    }


    /**
     * @return
     */
    public int getYearSelect() {
        return yearSelect;
    }


    /**
     * @return
     */
    public ArrayList getYearSelectOptions() {
        return yearSelectOptions;
    }

    /**
	 * @return the columnsDataTypeList
	 */
	public ArrayList getColumnsDataTypeList() {
		return columnsDataTypeList;
	}


	/**
     * Return true if this DTO should subtotal. This is determined by the subtotal information from the report
     * definition and the user sort column. If the user has sorted by clicking on a column then subtotaling is turned
     * off
     * 
     * @return
     */
    public boolean hasSubTotaling() {
        return (getEndSubTotLvl() > 0) && ((getUserSortColumn() == null) || (getUserSortColumn().length() == 0));
    }


    /**
     * Is the test date within the start/end date range of this object
     * 
     * @param testDate
     * @return
     * @throws Exception
     */
    public boolean isDateInRange(Date testDate) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

            Calendar start = Calendar.getInstance();
            start.setTime(sdf.parse(getStartDate()));

            Calendar end = Calendar.getInstance();
            end.setTime(sdf.parse(getEndDate()));

            String trendTime = getPresnTrendTime();

            if (trendTime.equals(TREND_TIME_MONTHLY)) {
                start.set(Calendar.DATE, start.getActualMinimum(Calendar.DATE));
                end.set(Calendar.DATE, end.getActualMaximum(Calendar.DATE));
            }

            if (trendTime.equals(TREND_TIME_YEARLY)) {
                start.set(Calendar.MONTH, 0);
                end.set(Calendar.DATE, end.getActualMaximum(Calendar.MONTH));
                start.set(Calendar.DATE, 1);
                end.set(Calendar.DATE, end.getActualMaximum(Calendar.DATE));
            }

            if (trendTime.equals(TREND_TIME_BILL_ROUND)) {
                start.set(Calendar.DATE, start.getActualMinimum(Calendar.DATE));
                end.set(Calendar.DATE, end.getActualMaximum(Calendar.DATE));
            }

            boolean b = start.getTime().equals(testDate) || testDate.after(start.getTime());
            b &= end.getTime().equals(testDate) || testDate.before(end.getTime());
            return b;
        } catch (Exception e) {
            throw new IllegalArgumentException("Start or end date is invalid");
        }
    }


    /**
     * @return
     */
    public boolean isHideAlertRuleTiming() {
        return hideAlertRuleTiming;
    }


    /**
     * @return
     */
    public boolean isHideCreate() {
        return hideCreate;
    }


    /**
     * @return
     */
    public boolean isHideDivCheckBox() {
        return hideDivCheckBox;
    }


    /**
     * @return
     */
    public boolean isHideDivDropDown() {
        return hideDivDropDown;
    }


    /**
     * @return
     */
    public boolean isHideEmail() {
        return hideEmail;
    }


    /**
     * @return
     */
    public boolean isHideFileSeqNum() {
        return hideFileSeqNum;
    }


    /**
     * @return
     */
    public boolean isHideMonthYear() {
        return hideMonthYear;
    }


    /**
     * @return
     */
    public boolean isHideNext() {
        return hideNext;
    }


    /**
     * @return
     */
    public boolean isHidePrev() {
        return hidePrev;
    }


    /**
     * @return
     */
    public boolean isHideSortKeyList() {
        return hideSortKeyList;
    }


    /**
     * @return
     */
    public boolean isHideSortKeyList2() {
        return hideSortKeyList2;
    }


    /**
     * @return
     */
    public boolean isHideView() {
        return hideView;
    }


    /**
     * @return
     */
    public boolean isOnlySelected() {
        return onlySelected;
    }


    /**
     * @return
     */
    public boolean isRecCountFlag() {
        return recCountFlag;
    }


    /**
     * @return
     */
    public boolean isSelectUniqRows() {
        return selectUniqRows;
    }


    public char getUserSortType() {
        return userSortType;
    }


    /**
     * @param adhocTest
     */
    public void setAdhocTest(String adhocTest) {
        this.adhocTest = adhocTest;
    }


    /**
     * @param alertTimeInd
     */
    public void setAlertTimeInd(String alertTimeInd) {
        this.alertTimeInd = alertTimeInd;
    }


    /**
     * @param alertTimeIndOptions
     */
    public void setAlertTimeIndOptions(ArrayList alertTimeIndOptions) {
        this.alertTimeIndOptions = alertTimeIndOptions;
    }


    /**
     * @param alertTimeValue
     */
    public void setAlertTimeValue(int alertTimeValue) {
        this.alertTimeValue = alertTimeValue;
    }


    /**
     * @param alertTimeValueBR
     */
    public void setAlertTimeValueBR(int alertTimeValueBR) {
        this.alertTimeValueBR = alertTimeValueBR;
    }


    /**
     * @param alertTimeValueOptions
     */
    public void setAlertTimeValueOptions(ArrayList alertTimeValueOptions) {
        this.alertTimeValueOptions = alertTimeValueOptions;
    }


    /**
     * @param alertTimeValueOptionsBR
     */
    public void setAlertTimeValueOptionsBR(ArrayList alertTimeValueOptionsBR) {
        this.alertTimeValueOptionsBR = alertTimeValueOptionsBR;
    }


    /**
     * @param alertTimeValueOptionsWD
     */
    public void setAlertTimeValueOptionsWD(ArrayList alertTimeValueOptionsWD) {
        this.alertTimeValueOptionsWD = alertTimeValueOptionsWD;
    }


    /**
     * @param alertTimeValueWD
     */
    public void setAlertTimeValueWD(int alertTimeValueWD) {
        this.alertTimeValueWD = alertTimeValueWD;
    }


    /**
     * @param aliasNames
     */
    public void setAliasNames(String aliasNames) {
        this.aliasNames = aliasNames;
    }


    /**
     * @param begSubTotLvl
     */
    public void setBegSubTotLvl(int begSubTotLvl) {
        this.begSubTotLvl = begSubTotLvl;
    }


    /**
     * @param billRnd
     */
    public void setBillRnd(int billRnd) {
        this.billRnd = billRnd;
    }


    /**
     * @param billRndOptions
     */
    public void setBillRndOptions(ArrayList billRndOptions) {
        this.billRndOptions = billRndOptions;
    }


    /**
     * @param clickLvl
     */
    public void setClickLvl(String clickLvl) {
        this.clickLvl = clickLvl;
    }


    /**
     * @param columnsAsOracleList
     */
    public void setColumnsAsOracleList(ArrayList columnsAsOracleList) {
        this.columnsAsOracleList = columnsAsOracleList;
    }


    /**
     * @param columnsHeadersList
     */
    public void setColumnsHeadersList(ArrayList columnsHeadersList) {
        this.columnsHeadersList = columnsHeadersList;
    }


    /**
     * @param columnsTablesList
     */
    public void setColumnsTablesList(ArrayList columnsTablesList) {
        this.columnsTablesList = columnsTablesList;
    }


    /**
     * @param columnsToExtractList
     */
    public void setColumnsToExtractList(ArrayList columnsToExtractList) {
        this.columnsToExtractList = columnsToExtractList;
    }


    /**
     * @param databaseNode
     */
    public void setDatabaseNode(String databaseNode) {
        this.databaseNode = databaseNode;
    }


    /**
     * @param dataDescIndList
     */
    public void setDataDescIndList(ArrayList dataDescIndList) {
        this.dataDescIndList = dataDescIndList;
    }


    /**
     * @param dataLinkIndList
     */
    public void setDataLinkIndList(ArrayList dataLinkIndList) {
        this.dataLinkIndList = dataLinkIndList;
    }


    /**
     * @param dataLinkPresnIdList
     */
    public void setDataLinkPresnIdList(ArrayList dataLinkPresnIdList) {
        this.dataLinkPresnIdList = dataLinkPresnIdList;
    }


    /**
     * @param dataLinkTblKeyDataList
     */
    public void setDataLinkTblKeyDataList(ArrayList dataLinkTblKeyDataList) {
        this.dataLinkTblKeyDataList = dataLinkTblKeyDataList;
    }


    /**
     * @param dataLinkTblKeyNameList
     */
    public void setDataLinkTblKeyNameList(ArrayList dataLinkTblKeyNameList) {
        this.dataLinkTblKeyNameList = dataLinkTblKeyNameList;
    }


    /**
     * @param dataLinkTblNameList
     */
    public void setDataLinkTblNameList(ArrayList dataLinkTblNameList) {
        this.dataLinkTblNameList = dataLinkTblNameList;
    }


    /**
     * @param dataLinkToPgmList
     */
    public void setDataLinkToPgmList(ArrayList dataLinkToPgmList) {
        this.dataLinkToPgmList = dataLinkToPgmList;
    }


    /**
     * @param dataMouseOverNumList
     */
    public void setDataMouseOverNumList(ArrayList dataMouseOverNumList) {
        this.dataMouseOverNumList = dataMouseOverNumList;
    }


    /**
     * @param distExecPresnSeqNumList
     */
    public void setDistExecPresnSeqNumList(ArrayList distExecPresnSeqNumList) {
        this.distExecPresnSeqNumList = distExecPresnSeqNumList;
    }


    /**
     * @param divisionList
     */
    public void setDivisionList(String divisionList) {
        this.divisionList = divisionList;
    }


    /**
     * @param divisionName
     */
    public void setDivisionName(String divisionName) {
        this.divisionName = divisionName;
    }


    /**
     * @param divisionName1
     */
    public void setDivisionName1(String divisionName1) {
        this.divisionName1 = divisionName1;
    }


    /**
     * @param divisions
     */
    public void setDivisions(ArrayList divisions) {
        this.divisions = divisions;
    }


    /**
     * @param divisionYes
     */
    public void setDivisionYes(String divisionYes) {
        this.divisionYes = divisionYes;
    }


    /**
     * @param divNameKeyLvl
     */
    public void setDivNameKeyLvl(int divNameKeyLvl) {
        this.divNameKeyLvl = divNameKeyLvl;
    }


    /**
     * @param emailReport
     */
    public void setEmailReport(String emailReport) {
        this.emailReport = emailReport;
    }


    /**
     * @param endDate
     */
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }


    /**
     * @param endSubTotLvl
     */
    public void setEndSubTotLvl(int endSubTotLvl) {
        this.endSubTotLvl = endSubTotLvl;
    }


    /**
     * @param fileSeqNum
     */
    public void setFileSeqNum(int fileSeqNum) {
        this.fileSeqNum = fileSeqNum;
    }


    /**
     * @param fileSeqNumAsString
     */
    public void setFileSeqNumAsString(String fileSeqNumAsString) {
        this.fileSeqNumAsString = fileSeqNumAsString;
    }


    /**
     * @param fileSeqNumInd
     */
    public void setFileSeqNumInd(String fileSeqNumInd) {
        this.fileSeqNumInd = fileSeqNumInd;
    }


    /**
     * @param fromPage
     */
    public void setFromPage(String fromPage) {
        this.fromPage = fromPage;
    }


    /**
     * @param genEndDate
     */
    public void setGenEndDate(String genEndDate) {
        this.genEndDate = genEndDate;
    }


    /**
     * @param genStartDate
     */
    public void setGenStartDate(String genStartDate) {
        this.genStartDate = genStartDate;
    }


    /**
     * @param graphPresnIndList
     */
    public void setGraphPresnIndList(ArrayList graphPresnIndList) {
        this.graphPresnIndList = graphPresnIndList;
    }


    /**
     * @param headerLinkIndList
     */
    public void setHeaderLinkIndList(ArrayList headerLinkIndList) {
        this.headerLinkIndList = headerLinkIndList;
    }


    /**
     * @param headerLinkPresnIdList
     */
    public void setHeaderLinkPresnIdList(ArrayList headerLinkPresnIdList) {
        this.headerLinkPresnIdList = headerLinkPresnIdList;
    }


    /**
     * @param headerLinkToPgmList
     */
    public void setHeaderLinkToPgmList(ArrayList headerLinkToPgmList) {
        this.headerLinkToPgmList = headerLinkToPgmList;
    }


    /**
     * @param headerMouseOverNumList
     */
    public void setHeaderMouseOverNumList(ArrayList headerMouseOverNumList) {
        this.headerMouseOverNumList = headerMouseOverNumList;
    }


    /**
     * @param hideAlertRuleTiming
     */
    public void setHideAlertRuleTiming(boolean hideAlertRuleTiming) {
        this.hideAlertRuleTiming = hideAlertRuleTiming;
    }


    /**
     * @param hideCreate
     */
    public void setHideCreate(boolean hideCreate) {
        this.hideCreate = hideCreate;
    }


    /**
     * @param hideDivCheckBox
     */
    public void setHideDivCheckBox(boolean hideDivCheckBox) {
        this.hideDivCheckBox = hideDivCheckBox;
    }


    /**
     * @param hideDivDropDown
     */
    public void setHideDivDropDown(boolean hideDivDropDown) {
        this.hideDivDropDown = hideDivDropDown;
    }


    /**
     * @param hideEmail
     */
    public void setHideEmail(boolean hideEmail) {
        this.hideEmail = hideEmail;
    }


    /**
     * @param hideFileSeqNum
     */
    public void setHideFileSeqNum(boolean hideFileSeqNum) {
        this.hideFileSeqNum = hideFileSeqNum;
    }


    /**
     * @param hideMonthYear
     */
    public void setHideMonthYear(boolean hideMonthYear) {
        this.hideMonthYear = hideMonthYear;
    }


    /**
     * @param hideNext
     */
    public void setHideNext(boolean hideNext) {
        this.hideNext = hideNext;
    }


    /**
     * @param hidePrev
     */
    public void setHidePrev(boolean hidePrev) {
        this.hidePrev = hidePrev;
    }


    /**
     * @param hideSortKeyList
     */
    public void setHideSortKeyList(boolean hideSortKeyList) {
        this.hideSortKeyList = hideSortKeyList;
    }


    /**
     * @param hideSortKeyList2
     */
    public void setHideSortKeyList2(boolean hideSortKeyList2) {
        this.hideSortKeyList2 = hideSortKeyList2;
    }


    /**
     * @param hideView
     */
    public void setHideView(boolean hideView) {
        this.hideView = hideView;
    }


    /**
     * @param key1
     */
    public void setKey1(String key1) {
        this.key1 = key1;
    }


    /**
     * @param key2
     */
    public void setKey2(String key2) {
        this.key2 = key2;
    }


    /**
     * @param key3
     */
    public void setKey3(String key3) {
        this.key3 = key3;
    }


    /**
     * @param key4
     */
    public void setKey4(String key4) {
        this.key4 = key4;
    }


    /**
     * @param key5
     */
    public void setKey5(String key5) {
        this.key5 = key5;
    }


    /**
     * @param keysRow1AliasList
     */
    public void setKeysRow1AliasList(ArrayList keysRow1AliasList) {
        this.keysRow1AliasList = keysRow1AliasList;
    }


    /**
     * @param keysRow1ColumnsList
     */
    public void setKeysRow1ColumnsList(ArrayList keysRow1ColumnsList) {
        this.keysRow1ColumnsList = keysRow1ColumnsList;
    }


    /**
     * @param labelSortKeyList
     */
    public void setLabelSortKeyList(String labelSortKeyList) {
        this.labelSortKeyList = labelSortKeyList;
    }


    /**
     * @param labelSortKeyList2
     */
    public void setLabelSortKeyList2(String labelSortKeyList2) {
        this.labelSortKeyList2 = labelSortKeyList2;
    }


    /**
     * @param monthSelect
     */
    public void setMonthSelect(int monthSelect) {
        this.monthSelect = monthSelect;
    }


    /**
     * @param monthSelectOptions
     */
    public void setMonthSelectOptions(ArrayList monthSelectOptions) {
        this.monthSelectOptions = monthSelectOptions;
    }


    /**
     * @param newGenUrlString
     */
    public void setNewGenUrlString(String newGenUrlString) {
        this.newGenUrlString = newGenUrlString;
    }


    /**
     * @param newUrl
     */
    public void setNewUrl(String newUrl) {
        this.newUrl = newUrl;
    }


    /**
     * @param noProcDate
     */
    public void setNoProcDate(String noProcDate) {
        this.noProcDate = noProcDate;
    }


    /**
     * @param onlySelected
     */
    public void setOnlySelected(boolean onlySelected) {
        this.onlySelected = onlySelected;
    }


    /**
     * @param partiRefId
     */
    public void setPartiRefId(int partiRefId) {
        this.partiRefId = partiRefId;
    }


    /**
     * @param partiRefIdList
     */
    public void setPartiRefIdList(ArrayList partiRefIdList) {
        this.partiRefIdList = partiRefIdList;
    }


    /**
     * @param presnCalcNumList
     */
    public void setPresnCalcNumList(ArrayList presnCalcNumList) {
        this.presnCalcNumList = presnCalcNumList;
    }


    /**
     * @param presnFormatList
     */
    public void setPresnFormatList(ArrayList presnFormatList) {
        this.presnFormatList = presnFormatList;
    }


    /**
     * @param presnId
     */
    public void setPresnId(int presnId) {
        this.presnId = presnId;
    }


    /**
     * @param presnIdAsString
     */
    public void setPresnIdAsString(String presnIdAsString) {
        this.presnIdAsString = presnIdAsString;
    }


    /**
     * @param presnModel
     */
    public void setPresnModel(int presnModel) {
        this.presnModel = presnModel;
    }


    /**
     * @param presnOrdIndList
     */
    public void setPresnOrdIndList(ArrayList presnOrdIndList) {
        this.presnOrdIndList = presnOrdIndList;
    }


    /**
     * @param presnSumIndList
     */
    public void setPresnSumIndList(ArrayList presnSumIndList) {
        this.presnSumIndList = presnSumIndList;
    }


    /**
     * @param presnSuppressIndList
     */
    public void setPresnSuppressIndList(ArrayList presnSuppressIndList) {
        this.presnSuppressIndList = presnSuppressIndList;
    }


    /**
     * @param presnTblName
     */
    public void setPresnTblName(String presnTblName) {
        this.presnTblName = presnTblName;
    }


    /**
     * @param presnTrendTime
     */
    public void setPresnTrendTime(String presnTrendTime) {
        this.presnTrendTime = presnTrendTime;
    }


    /**
     * @param presnUnitIndList
     */
    public void setPresnUnitIndList(ArrayList presnUnitIndList) {
        this.presnUnitIndList = presnUnitIndList;
    }


    /**
     * @param procDate
     */
    public void setProcDate(String procDate) {
        this.procDate = procDate;
    }


    /**
     * @param procDateInd
     */
    public void setProcDateInd(String procDateInd) {
        this.procDateInd = procDateInd;
    }


    /**
     * @param queryValue
     */
    public void setQueryValue(String queryValue) {
        this.queryValue = queryValue;
    }


    /**
     * @param recCountFlag
     */
    public void setRecCountFlag(boolean recCountFlag) {
        this.recCountFlag = recCountFlag;
    }


    /**
     * @param region
     */
    public void setRegion(String region) {
        this.region = region;
    }


    /**
     * @param row1Columns
     */
    public void setRow1Columns(String row1Columns) {
        this.row1Columns = row1Columns;
    }


    /**
     * @param rptHeader1
     */
    public void setRptHeader1(String rptHeader1) {
        this.rptHeader1 = rptHeader1;
    }


    /**
     * @param rptHeader2
     */
    public void setRptHeader2(String rptHeader2) {
        this.rptHeader2 = rptHeader2;
    }


    /**
     * @param rptHeader3
     */
    public void setRptHeader3(String rptHeader3) {
        this.rptHeader3 = rptHeader3;
    }


    /**
     * @param rptHeaderDateInd
     */
    public void setRptHeaderDateInd(String rptHeaderDateInd) {
        this.rptHeaderDateInd = rptHeaderDateInd;
    }


    /**
     * @param selectedDivs
     */
    public void setSelectedDivs(String[] selectedDivs) {
        this.selectedDivs = selectedDivs;
    }


    /**
     * @param selectUniqRows
     */
    public void setSelectUniqRows(boolean selectUniqRows) {
        this.selectUniqRows = selectUniqRows;
    }


    /**
     * @param sortKeyList
     */
    public void setSortKeyList(String sortKeyList) {
        this.sortKeyList = sortKeyList;
    }


    /**
     * @param sortKeyList2
     */
    public void setSortKeyList2(String sortKeyList2) {
        this.sortKeyList2 = sortKeyList2;
    }


    /**
     * @param startDate
     */
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }


    /**
     * @param styleAlertTimeValue
     */
    public void setStyleAlertTimeValue(String styleAlertTimeValue) {
        this.styleAlertTimeValue = styleAlertTimeValue;
    }


    /**
     * @param styleAlertTimeValueBR
     */
    public void setStyleAlertTimeValueBR(String styleAlertTimeValueBR) {
        this.styleAlertTimeValueBR = styleAlertTimeValueBR;
    }


    /**
     * @param styleAlertTimeValueWD
     */
    public void setStyleAlertTimeValueWD(String styleAlertTimeValueWD) {
        this.styleAlertTimeValueWD = styleAlertTimeValueWD;
    }


    /**
     * @param tableNames
     */
    public void setTableNames(String tableNames) {
        this.tableNames = tableNames;
    }


    /**
     * @param timingFilterCode
     */
    public void setTimingFilterCode(String timingFilterCode) {
        this.timingFilterCode = timingFilterCode;
    }


    /**
     * @param type
     */
    public void setUserSortType(char type) {
        if (" AD".indexOf(type) != -1) {
            userSortType = type;
        }
    }


    /**
     * @param userSortColumn
     */
    public void setUserSortColumn(String userSortColumn) {
        this.userSortColumn = userSortColumn;
    }


    /**
     * @param viewNameList
     */
    public void setViewNameList(ArrayList viewNameList) {
        this.viewNameList = viewNameList;
    }


    /**
     * @param yearSelect
     */
    public void setYearSelect(int yearSelect) {
        this.yearSelect = yearSelect;
    }


    /**
     * @param yearSelectOptions
     */
    public void setYearSelectOptions(ArrayList yearSelectOptions) {
        this.yearSelectOptions = yearSelectOptions;
    }


    public String toString() {
        StringBuffer buf = new StringBuffer(2048);
        buf.append("<br>");
        buf.append("(AdhocRptDataTO Contents: ");
        buf.append(";adhocTest=" + print(adhocTest));
        buf.append(";alertTimeInd=" + print(alertTimeInd));
        buf.append(";alertTimeIndOptions=");
        addListToString(alertTimeIndOptions, buf);
        buf.append(";alertTimeValue=" + print(alertTimeValue));
        buf.append(";alertTimeValueBR=" + print(alertTimeValueBR));
        buf.append(";alertTimeValueOptions=");
        addListToString(alertTimeValueOptions, buf);
        buf.append(";alertTimeValueOptionsBR=");
        addListToString(alertTimeValueOptionsBR, buf);
        buf.append(";alertTimeValueOptionsWD=");
        addListToString(alertTimeValueOptionsWD, buf);
        buf.append(";alertTimeValueWD=" + print(alertTimeValueWD));
        buf.append(";aliasNames=" + print(aliasNames));
        buf.append(";begSubTotLvl=" + print(begSubTotLvl));
        buf.append(";billRnd=" + print(billRnd));
        buf.append(";billRndOptions=");
        addListToString(billRndOptions, buf);
        buf.append(";clickLvl=" + print(clickLvl));
        buf.append(";columnsAsOracleList=");
        addListToString(columnsAsOracleList, buf);
        buf.append(";columnsHeadersList=");
        addListToString(columnsHeadersList, buf);
        buf.append(";columnsTablesList=");
        addListToString(columnsTablesList, buf);
        buf.append(";columnsToExtractList=");
        addListToString(columnsToExtractList, buf);
        buf.append(";dataDescIndList=");
        addListToString(dataDescIndList, buf);
        buf.append(";dataLinkIndList=");
        addListToString(dataLinkIndList, buf);
        buf.append(";dataLinkPresnIdList=");
        addListToString(dataLinkPresnIdList, buf);
        buf.append(";dataLinkTblKeyDataList=");
        addListToString(dataLinkTblKeyDataList, buf);
        buf.append(";dataLinkTblKeyNameList=");
        addListToString(dataLinkTblKeyNameList, buf);
        buf.append(";dataLinkTblNameList=");
        addListToString(dataLinkTblNameList, buf);
        buf.append(";dataLinkToPgmList=");
        addListToString(dataLinkToPgmList, buf);
        buf.append(";dataMouseOverNumList=");
        addListToString(dataMouseOverNumList, buf);
        buf.append(";databaseNode=" + print(databaseNode));
        buf.append(";distExecPresnSeqNumList=");
        addListToString(distExecPresnSeqNumList, buf);
        buf.append(";divNameKeyLvl=" + print(divNameKeyLvl));
        buf.append(";divisionList=" + print(divisionList));
        buf.append(";divisionName =" + print(divisionName));
        buf.append(";divisionName1 =" + print(divisionName1));
        buf.append(";divisionYes=" + print(divisionYes));
        buf.append(";divisions=");
        addListToString(divisions, buf);
        buf.append(";emailReport=" + print(emailReport));
        buf.append(";endDate=" + print(endDate));
        buf.append(";endSubTotLvl=" + print(endSubTotLvl));
        buf.append(";fileSeqNum=" + print(fileSeqNum));
        buf.append(";fileSeqNumAsString=" + print(fileSeqNumAsString));
        buf.append(";fileSeqNumInd=" + print(fileSeqNumInd));
        buf.append(";fromPage=" + print(fromPage));
        buf.append(";genEndDate=" + print(genEndDate));
        buf.append(";genStartDate=" + print(genStartDate));
        buf.append(";graphPresnIndList=");
        addListToString(graphPresnIndList, buf);
        buf.append(";headerLinkIndList=");
        addListToString(headerLinkIndList, buf);
        buf.append(";headerLinkPresnIdList=");
        addListToString(headerLinkPresnIdList, buf);
        buf.append(";headerLinkToPgmList=");
        addListToString(headerLinkToPgmList, buf);
        buf.append(";headerMouseOverNumList=");
        addListToString(headerMouseOverNumList, buf);
        buf.append(";hideAlertRuleTiming=" + print(hideAlertRuleTiming));
        buf.append(";hideCreate=" + print(hideCreate));
        buf.append(";hideDivCheckBox=" + print(hideDivCheckBox));
        buf.append(";hideDivDropDown=" + print(hideDivDropDown));
        buf.append(";hideEmail=" + print(hideEmail));
        buf.append(";hideFileSeqNum=" + print(hideFileSeqNum));
        buf.append(";hideMonthYear=" + print(hideMonthYear));
        buf.append(";hideNext=" + print(hideNext));
        buf.append(";hidePrev=" + print(hidePrev));
        buf.append(";hideSortKeyList=" + print(hideSortKeyList));
        buf.append(";hideSortKeyList2=" + print(hideSortKeyList2));
        buf.append(";hideView=" + print(hideView));
        buf.append(";key1=" + print(key1));
        buf.append(";key2=" + print(key2));
        buf.append(";key3=" + print(key3));
        buf.append(";key4=" + print(key4));
        buf.append(";key5=" + print(key5));
        buf.append(";keysRow1AliasList=");
        addListToString(keysRow1AliasList, buf);
        buf.append(";keysRow1ColumnsList=");
        addListToString(keysRow1ColumnsList, buf);
        buf.append(";labelSortKeyList=" + print(labelSortKeyList));
        buf.append(";labelSortKeyList2=" + print(labelSortKeyList2));
        buf.append(";monthSelect=" + print(monthSelect));
        buf.append(";monthSelectOptions=");
        addListToString(monthSelectOptions, buf);
        buf.append(";newGenUrlString=" + print(newGenUrlString));
        buf.append(";newUrl=" + print(newUrl));
        buf.append(";noProcDate=" + print(noProcDate));
        buf.append(";onlySelected=" + print(onlySelected));
        buf.append(";partiRefId=" + print(partiRefId));
        buf.append(";partiRefIdList=");
        addListToString(partiRefIdList, buf);
        buf.append(";presnCalcNumList=");
        addListToString(presnCalcNumList, buf);
        buf.append(";presnFormatList=");
        addListToString(presnFormatList, buf);
        buf.append(";presnId=" + print(presnId));
        buf.append(";presnIdAsString=" + print(presnIdAsString));
        buf.append(";presnModel=" + print(presnModel));
        buf.append(";presnOrdIndList=");
        addListToString(presnOrdIndList, buf);
        buf.append(";presnSumIndList=");
        addListToString(presnSumIndList, buf);
        buf.append(";presnSuppressIndList=");
        addListToString(presnSuppressIndList, buf);
        buf.append(";presnTblName=" + print(presnTblName));
        buf.append(";presnTrendTime=" + print(presnTrendTime));
        buf.append(";presnUnitIndList=");
        addListToString(presnUnitIndList, buf);
        buf.append(";previous=");
        addListToString(previous, buf);
        buf.append(";difference=");
        addListToString(difference, buf);    
        buf.append(";procDate=" + print(procDate));
        buf.append(";queryValue=" + print(queryValue));
        buf.append(";recCountFlag=" + print(recCountFlag));
        buf.append(";region=" + print(region));
        buf.append(";rocDateInd=" + print(procDateInd));
        buf.append(";row1Columns=" + print(row1Columns));
        buf.append(";rptHeader1=" + print(rptHeader1));
        buf.append(";rptHeader2=" + print(rptHeader2));
        buf.append(";rptHeader3=" + print(rptHeader3));
        buf.append(";rptHeaderDateInd=" + print(rptHeaderDateInd));
        buf.append(";selectUniqRows=" + print(selectUniqRows));
        buf.append(";selectedDivs=");
        addListToString(selectedDivs, buf);
        buf.append(";sortKeyList=" + print(sortKeyList));
        buf.append(";sortKeyList2=" + print(sortKeyList2));
        buf.append(";startDate=" + print(startDate));
        buf.append(";styleAlertTimeValue=" + print(styleAlertTimeValue));
        buf.append(";styleAlertTimeValueBR=" + print(styleAlertTimeValueBR));
        buf.append(";styleAlertTimeValueWD=" + print(styleAlertTimeValueWD));
        buf.append(";tableNames=" + print(tableNames));
        buf.append(";timingFilterCode=" + print(timingFilterCode));
        buf.append(";viewNameList=");
        addListToString(viewNameList, buf);
        buf.append(";webId=" + print(webId));
        buf.append(";yearSelect=" + print(yearSelect));
        buf.append(";yearSelectOptions=");
        addListToString(yearSelectOptions, buf);
        buf.append("<br>");
        buf.append(";SQL=");
        addListToString(generatedSQL, buf);
        buf.append(";rowData=");
        addListToString(rowData,buf);
        buf.append(";rowDataCnt=" + print(rowDataCnt));
        buf.append(")");

        // // because of a change in the css I need to apply my own breaking.
        // for (int i=BREAK_LENGTH; i<buf.length(); i+=BREAK_LENGTH) {
        // buf.insert(i, "<br>");
        // }

        return buf.toString();
    }


    /**
     * @param list
     * @param buf
     */
    private void addListToString(List list, StringBuffer buf) {
        buf.append("[");
        if (list == null) {
            buf.append("null");
        } else {
            Iterator i = list.iterator();
            while (i.hasNext()) {
                buf.append(print(i.next()));
                if (i.hasNext()) {
                    buf.append(',');
                }
            }
        }
        buf.append("]");
    }


    /**
     * @param list
     * @param buf
     */
    private void addListToString(String[] list, StringBuffer buf) {
        if (list == null) {
            buf.append("[null]");
            return;
        }
        addListToString(Arrays.asList(list), buf);
    }


    /**
     * @param obj
     * @return
     */
    private String print(boolean obj) {
        return "" + obj;
    }


    /**
     * @param obj
     * @return
     */
    private String print(int obj) {
        return "" + obj;
    }


    /**
     * @param obj
     * @return
     */
    private String print(Object obj) {
        if (obj == null) {
            return "null";
        }
        return obj.toString();
    }


    /**
     * Should proc date be used for sorting or should a year/month field be used.
     * 
     * MikeB(14:22:11): select alert_proc_tbl,tbl_proc_date_ddl_name, tbl_bill_rnd_ddl_mon, tbl_bill_rnd_ddl_year from
     * rabc_data_tbl_ddl<br>
     * MikeB(14:24:07): If you run this query you will see that there are a number of tables where the proc_date field
     * and the mon/year fields are both populated. This is part of the problem. The code is (at different places)
     * determining proc_date vs. mon/year based on either the proc_date field being empty or the mon/year fields being
     * empty. So when they are both empty the code is confused.<br>
     * MikeB(14:24:42): Is the table valid? If it is, how should I determine which to use? I think you said always
     * proc_date if its there? <br>
     * KC(14:55:47): actual tble has both field populated. If you feel more comfortable to remove the MM/YY from
     * RABC_DATA_TBL_DDL. I can do that<br>
     * MikeB(14:56:36): That doesn't matter. I just need to understand what the rule should be. Should I always use
     * proc_date if available (regardless of report type)?<br>
     * KC(14:57:42): Yes. if PROC_DATE is available use PROC_DATE else check the MM./YY<br>
     * 
     * @param tblCount
     * @return
     */
    public boolean isProcDateUsed(int tblCount) {
        return !(getNoProcDate().equals("Y"));

        // String table = (String) getColumnsTablesList().get(tblCount);
        // ArrayList list = StaticDataLoader.getDataTblDdlByAlertProcTbl(table, getRegion());
        // if (list.isEmpty()) {
        // return true;
        // }
        //
        // if ((getPresnTrendTime().equalsIgnoreCase("B") && getProcDateInd().equalsIgnoreCase("P")) ||
        // (getNoProcDate().equalsIgnoreCase("Y") && getPresnTrendTime().equalsIgnoreCase("M"))) {
        // return false;
        // } else if (getNoProcDate().equalsIgnoreCase("Y") && !getPresnTrendTime().equalsIgnoreCase("Y")) {
        // return false;
        // } else {
        // return true;
        // }
    }


    /**
     * Return proc year field
     * 
     * @param tblCount
     * @return
     */
    public String getProcYearField(int tblCount) {
        String table = (String) getColumnsTablesList().get(tblCount);
        ArrayList list = StaticDataLoader.getDataTblDdlByAlertProcTbl(table, getRegion());
        if (list.isEmpty()) {
            return "";
        }
        DataTblDdlBean bean = (DataTblDdlBean) list.get(0);
        return bean.getTblBillRndDdlYear();
    }


    /**
     * Return proc month field
     * 
     * @param tblCount
     * @return
     */
    public String getProcMonthField(int tblCount) {
        String table = (String) getColumnsTablesList().get(tblCount);
        ArrayList list = StaticDataLoader.getDataTblDdlByAlertProcTbl(table, getRegion());
        if (list.isEmpty()) {
            return "";
        }
        DataTblDdlBean bean = (DataTblDdlBean) list.get(0);
        return bean.getTblBillRndDdlMon();
    }

	/**
	 * @return the procDateFormat
	 */
	public String getProcDateFormat() {
		return procDateFormat;
	}


	/**
	 * @param procDateFormat the procDateFormat to set
	 */
	public void setProcDateFormat(String procDateFormat) {
		this.procDateFormat = procDateFormat;
	}

	/**
	 * @return the billRoundCheck
	 */
	public String getBillRoundCheck() {
		return billRoundCheck;
	}

	/**
	 * @param billRoundCheck the billRoundCheck to set
	 */
	public void setBillRoundCheck(String billRoundCheck) {
		this.billRoundCheck = billRoundCheck;
	}

	/**
	 * @return the hideBillRoundCheck
	 */
	public boolean isHideBillRoundCheck() {
		return hideBillRoundCheck;
	}

	/**
	 * @param hideBillRoundCheck the hideBillRoundCheck to set
	 */
	public void setHideBillRoundCheck(boolean hideBillRoundCheck) {
		this.hideBillRoundCheck = hideBillRoundCheck;
	}


	/**
	 * @return the dataKeyLvl
	 */
	public int getDataKeyLvl() {
		return dataKeyLvl;
	}

	/**
	 * @param dataKeyLvl the dataKeyLvl to set
	 */
	public void setDataKeyLvl(int dataKeyLvl) {
		this.dataKeyLvl = dataKeyLvl;
	}

	/**
	 * @return the pagedHtml
	 */
	public String getPagedHtml() {
		return pagedHtml;
	}

	/**
	 * @param pagedHtml the pagedHtml to set
	 */
	public void setPagedHtml(String pagedHtml) {
		this.pagedHtml = pagedHtml;
	}


	

/*
 * Added code for previous logic for PMT #M169, issue # M5
 * */
	

	public int getRowDataCnt() {
		return rowDataCnt;
	}


	public void setRowDataCnt(int rowDataCnt) {
		this.rowDataCnt = rowDataCnt;
	}	
	
	public Object clone() {
	    //shallow copy
	    try {
	      return super.clone();
	    } catch (CloneNotSupportedException e) {
	      return null;
	    }
	  }


	public List<RowElement> getRowData() {
		return rowData;
	}


	public void setRowData(List<RowElement> rowData) {
		this.rowData = rowData;
	}
// code ended for previous logic
}
