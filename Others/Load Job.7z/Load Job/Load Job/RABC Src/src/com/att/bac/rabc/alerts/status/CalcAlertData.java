/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.alerts.status;

import com.att.bac.rabc.MyDate;

/**
 * This is a Data Object for RABC_ALERT_CALC_DATA table or 
 * CalcAlertData is java representation for RABC_CALC_ALERT_DATA table.
 * 
 * @author Shailesh Hemdev - SH8512
 */
public class CalcAlertData {
	private double alertData;
	private MyDate procDate;
	private int fileSeqNum = -1;
	private int partiRefId;
	private String alertItem;
	private String alertKey1;
	private String alertKey2;
	private String alertKey3;
	private String alertKey4;
	private String alertKey5;
	private String alertTrendTime;
	private double alertVariancePct;
	private double alertVariance;
	private double alertActualData;
	private String procMonth;
	
	/**
	 * @return Returns the alert_item.
	 */
	public String getAlertItem() {
		return alertItem;
	}
	/**
	 * @param alert_item The alert_item to set.
	 */
	public void setAlertItem(String alertItem) {
		this.alertItem = alertItem;
	}
	/**
	 * @return Returns the alertActualData.
	 */
	public double getAlertActualData() {
		return alertActualData;
	}
	/**
	 * @param alertActualData The alertActualData to set.
	 */
	public void setAlertActualData(double alertActualData) {
		this.alertActualData = alertActualData;
	}
	/**
	 * @return Returns the alertData.
	 */
	public double getAlertData() {
		return alertData;
	}
	/**
	 * @param alertData The alertData to set.
	 */
	public void setAlertData(double alertData) {
		this.alertData = alertData;
	}
	/**
	 * @return Returns the alertKey1.
	 */
	public String getAlertKey1() {
		return alertKey1;
	}
	/**
	 * @param alertKey1 The alertKey1 to set.
	 */
	public void setAlertKey1(String alertKey1) {
		this.alertKey1 = alertKey1;
	}
	/**
	 * @return Returns the alertKey2.
	 */
	public String getAlertKey2() {
		return alertKey2;
	}
	/**
	 * @param alertKey2 The alertKey2 to set.
	 */
	public void setAlertKey2(String alertKey2) {
		this.alertKey2 = alertKey2;
	}
	/**
	 * @return Returns the alertKey3.
	 */
	public String getAlertKey3() {
		return alertKey3;
	}
	/**
	 * @param alertKey3 The alertKey3 to set.
	 */
	public void setAlertKey3(String alertKey3) {
		this.alertKey3 = alertKey3;
	}
	/**
	 * @return Returns the alertKey4.
	 */
	public String getAlertKey4() {
		return alertKey4;
	}
	/**
	 * @param alertKey4 The alertKey4 to set.
	 */
	public void setAlertKey4(String alertKey4) {
		this.alertKey4 = alertKey4;
	}
	/**
	 * @return Returns the alertKey5.
	 */
	public String getAlertKey5() {
		return alertKey5;
	}
	/**
	 * @param alertKey5 The alertKey5 to set.
	 */
	public void setAlertKey5(String alertKey5) {
		this.alertKey5 = alertKey5;
	}
	/**
	 * @return Returns the alertTrendTime.
	 */
	public String getAlertTrendTime() {
		return alertTrendTime;
	}
	/**
	 * @param alertTrendTime The alertTrendTime to set.
	 */
	public void setAlertTrendTime(String alertTrendTime) {
		this.alertTrendTime = alertTrendTime;
	}
	/**
	 * @return Returns the alertVariance.
	 */
	public double getAlertVariance() {
		return alertVariance;
	}
	/**
	 * @param alertVariance The alertVariance to set.
	 */
	public void setAlertVariance(double alertVariance) {
		this.alertVariance = alertVariance;
	}
	/**
	 * @return Returns the alertVariancePct.
	 */
	public double getAlertVariancePct() {
		return alertVariancePct;
	}
	/**
	 * @param alertVariancePct The alertVariancePct to set.
	 */
	public void setAlertVariancePct(double alertVariancePct) {
		this.alertVariancePct = alertVariancePct;
	}
	/**
	 * @return Returns the fileSeqNum.
	 */
	public int getFileSeqNum() {
		return fileSeqNum;
	}
	/**
	 * @param fileSeqNum The fileSeqNum to set.
	 */
	public void setFileSeqNum(int fileSeqNum) {
		this.fileSeqNum = fileSeqNum;
	}
	/**
	 * @return Returns the partiRefId.
	 */
	public int getPartiRefId() {
		return partiRefId;
	}
	/**
	 * @param partiRefId The partiRefId to set.
	 */
	public void setPartiRefId(int partiRefId) {
		this.partiRefId = partiRefId;
	}
	/**
	 * @return Returns the procDate.
	 */
	public MyDate getProcDate() {
		return procDate;
	}
	/**
	 * @param procDate The procDate to set.
	 */
	public void setProcDate(MyDate procDate) {
		this.procDate = procDate;
	}
	
	/**
	 * @return Returns the procMonth.
	 */
	public String getProcMonth() {
		return procMonth;
	}
	/**
	 * @param procMonth The procMonth to set.
	 */
	public void setProcMonth(String procMonth) {
		this.procMonth = procMonth;
	}
}
