/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc;

/**
 * This is a Data Object to represent RABC_WEB_DATA_LINK table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class WebDataLink {
	private int presnId;
	private String webid;
	private int execPresnSeqNum;
	private int linkNum;
	private String linkDdlName;
	private String linkToPgm;
	private int linkPresnId;
	private int linkNumParm;
	private String linkParm1;
	private String linkParm2;
	private String linkParm3;
	private String linkParm4;
	private String linkParm5;
	private String linkParm6;
	private String linkParm7;
	private String linkParm8;
	private String linkParm9;
	private String linkParm10;
	private String linkParm11;
	private String linkParm12;

	/**
	 * @return Returns the PresnId.
	 */
	public int getPresnId() {
		return presnId;
	}
	/**
	 * @return Returns the Webid.
	 */
	public String getWebid() {
		return webid;
	}
	/**
	 * @return Returns the ExecPresnSeqNum.
	 */
	public int getExecPresnSeqNum() {
		return execPresnSeqNum;
	}
	/**
	 * @return Returns the LinkNum.
	 */
	public int getLinkNum() {
		return linkNum;
	}
	/**
	 * @return Returns the LinkDdlName.
	 */
	public String getLinkDdlName() {
		return linkDdlName;
	}
	/**
	 * @return Returns the LinkToPgm.
	 */
	public String getLinkToPgm() {
		return linkToPgm;
	}
	/**
	 * @return Returns the LinkPresnId.
	 */
	public int getLinkPresnId() {
		return linkPresnId;
	}
	/**
	 * @return Returns the LinkNumParm.
	 */
	public int getLinkNumParm() {
		return linkNumParm;
	}
	/**
	 * @return Returns the LinkParm1.
	 */
	public String getLinkParm1() {
		return linkParm1;
	}
	/**
	 * @return Returns the LinkParm2.
	 */
	public String getLinkParm2() {
		return linkParm2;
	}
	/**
	 * @return Returns the LinkParm3.
	 */
	public String getLinkParm3() {
		return linkParm3;
	}
	/**
	 * @return Returns the LinkParm4.
	 */
	public String getLinkParm4() {
		return linkParm4;
	}
	/**
	 * @return Returns the LinkParm5.
	 */
	public String getLinkParm5() {
		return linkParm5;
	}
	/**
	 * @return Returns the LinkParm6.
	 */
	public String getLinkParm6() {
		return linkParm6;
	}
	/**
	 * @return Returns the LinkParm7.
	 */
	public String getLinkParm7() {
		return linkParm7;
	}
	/**
	 * @return Returns the LinkParm8.
	 */
	public String getLinkParm8() {
		return linkParm8;
	}
	/**
	 * @return Returns the LinkParm9.
	 */
	public String getLinkParm9() {
		return linkParm9;
	}
	/**
	 * @return Returns the LinkParm10.
	 */
	public String getLinkParm10() {
		return linkParm10;
	}
	/**
	 * @return Returns the LinkParm11.
	 */
	public String getLinkParm11() {
		return linkParm11;
	}
	/**
	 * @return Returns the LinkParm12.
	 */
	public String getLinkParm12() {
		return linkParm12;
	}

	/**
	 * @param PresnId The presnId to set.
	 */
	public void setPresnId(int presnId) {
		this.presnId = presnId;
	}
	/**
	 * @param Webid The webid to set.
	 */
	public void setWebid(String webid) {
		this.webid = webid;
	}
	/**
	 * @param ExecPresnSeqNum The execPresnSeqNum to set.
	 */
	public void setExecPresnSeqNum(int execPresnSeqNum) {
		this.execPresnSeqNum = execPresnSeqNum;
	}
	/**
	 * @param LinkNum The linkNum to set.
	 */
	public void setLinkNum(int linkNum) {
		this.linkNum = linkNum;
	}
	/**
	 * @param LinkDdlName The linkDdlName to set.
	 */
	public void setLinkDdlName(String linkDdlName) {
		this.linkDdlName = linkDdlName;
	}
	/**
	 * @param LinkToPgm The linkToPgm to set.
	 */
	public void setLinkToPgm(String linkToPgm) {
		this.linkToPgm = linkToPgm;
	}
	/**
	 * @param LinkPresnId The linkPresnId to set.
	 */
	public void setLinkPresnId(int linkPresnId) {
		this.linkPresnId = linkPresnId;
	}
	/**
	 * @param LinkNumParm The linkNumParm to set.
	 */
	public void setLinkNumParm(int linkNumParm) {
		this.linkNumParm = linkNumParm;
	}
	/**
	 * @param LinkParm1 The linkParm1 to set.
	 */
	public void setLinkParm1(String linkParm1) {
		this.linkParm1 = linkParm1;
	}
	/**
	 * @param LinkParm2 The linkParm2 to set.
	 */
	public void setLinkParm2(String linkParm2) {
		this.linkParm2 = linkParm2;
	}
	/**
	 * @param LinkParm3 The linkParm3 to set.
	 */
	public void setLinkParm3(String linkParm3) {
		this.linkParm3 = linkParm3;
	}
	/**
	 * @param LinkParm4 The linkParm4 to set.
	 */
	public void setLinkParm4(String linkParm4) {
		this.linkParm4 = linkParm4;
	}
	/**
	 * @param LinkParm5 The linkParm5 to set.
	 */
	public void setLinkParm5(String linkParm5) {
		this.linkParm5 = linkParm5;
	}
	/**
	 * @param LinkParm6 The linkParm6 to set.
	 */
	public void setLinkParm6(String linkParm6) {
		this.linkParm6 = linkParm6;
	}
	/**
	 * @param LinkParm7 The linkParm7 to set.
	 */
	public void setLinkParm7(String linkParm7) {
		this.linkParm7 = linkParm7;
	}
	/**
	 * @param LinkParm8 The linkParm8 to set.
	 */
	public void setLinkParm8(String linkParm8) {
		this.linkParm8 = linkParm8;
	}
	/**
	 * @param LinkParm9 The linkParm9 to set.
	 */
	public void setLinkParm9(String linkParm9) {
		this.linkParm9 = linkParm9;
	}
	/**
	 * @param LinkParm10 The linkParm10 to set.
	 */
	public void setLinkParm10(String linkParm10) {
		this.linkParm10 = linkParm10;
	}
	/**
	 * @param LinkParm11 The linkParm11 to set.
	 */
	public void setLinkParm11(String linkParm11) {
		this.linkParm11 = linkParm11;
	}
	/**
	 * @param LinkParm12 The linkParm12 to set.
	 */
	public void setLinkParm12(String linkParm12) {
		this.linkParm12 = linkParm12;
	}
}
