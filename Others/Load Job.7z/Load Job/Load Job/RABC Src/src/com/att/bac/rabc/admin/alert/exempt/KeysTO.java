/* Component Name: RABCPPG01235
 * Module Name: KeysTO.java
 * Created on August 4, 2006
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.admin.alert.exempt;

import java.io.Serializable;

/**This is a transfer object class for the Alert Exempt process.  The purpose of this class is to 
 * contain keys row data extracted from the AdminAlertExemptDAO.java class that is sent back to the 
 * AdminAlertExemptForm.java class via the AdminAlertExemptService.java class.
 * 
 * @author js3175
 */
public class KeysTO implements Serializable {
	private static final long serialVersionUID = 0L;
	
	private String alertItem = "";
	private String divisionValue = "";
	private String divisionDesc = "";
	private String [] keys = new String[0];
	private String userId = "";
	private String endEffectiveDate = "";
	private String timestamp = "";
	
	/**Constructor for creating a KeysTO object where the alert rule has only one
	 * key - division.
	 */
	public KeysTO (String alertItem, String divisionValue, String divisionDesc, String userId, String effDate, String timestamp) {
		this.alertItem = alertItem;
		this.divisionValue = divisionValue;
		this.divisionDesc = divisionDesc;
		this.userId = userId;
		this.endEffectiveDate = effDate;
		this.timestamp = timestamp;
	}
	
	/**Constructor for creating a KeysTO object where the alert rule has from two
	 * to five keys.
	 */
	public KeysTO (String alertItem, String divisionValue, String divisionDesc, String [] keys, String userId, String effDate, String timestamp) {
		this.alertItem = alertItem;
		this.divisionValue = divisionValue;
		this.divisionDesc = divisionDesc;
		this.keys = keys;
		this.userId = userId;
		this.endEffectiveDate = effDate;
		this.timestamp = timestamp;
	}
	
	/**
	 * @return Returns the dataItem.
	 */
	public String getAlertItem() {
		return alertItem;
	}
	/**
	 * @param dataItem The dataItem to set.
	 */
	public void setAlertItem(String alertItem) {
		this.alertItem = alertItem;
	}
	/**
	 * @return Returns the divisionDesc.
	 */
	public String getDivisionDesc() {
		return divisionDesc;
	}
	/**
	 * @param divisionDesc The divisionDesc to set.
	 */
	public void setDivisionDesc(String divisionDesc) {
		this.divisionDesc = divisionDesc;
	}
	/**
	 * @return Returns the divisionValue.
	 */
	public String getDivisionValue() {
		return divisionValue;
	}
	/**
	 * @param divisionValue The divisionValue to set.
	 */
	public void setDivisionValue(String divisionValue) {
		this.divisionValue = divisionValue;
	}
	/**
	 * @return Returns the keys.
	 */
	public String [] getKeys() {
		return keys;
	}
	/**
	 * @return Returns the keys one at a time.
	 */
	public String getKey(int i) {
		if (keys[i] == null)
			return " ";
		else
			return keys[i];
	}
	/**
	 * @param key1 The key1 to set.
	 */
	public void setKeys(String [] keys) {
		this.keys = keys;
	}

	/**
	 * @return Returns the effectiveDate.
	 */
	public String getEndEffectiveDate() {
		return endEffectiveDate;
	}

	/**
	 * @param effectiveDate The effectiveDate to set.
	 */
	public void setEndEffectiveDate(String endEffectiveDate) {
		this.endEffectiveDate = endEffectiveDate;
	}

	/**
	 * @return Returns the timestamp.
	 */
	public String getTimestamp() {
		return timestamp;
	}

	/**
	 * @param timestamp The timestamp to set.
	 */
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	/**
	 * @return Returns the userId.
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId The userId to set.
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
}
