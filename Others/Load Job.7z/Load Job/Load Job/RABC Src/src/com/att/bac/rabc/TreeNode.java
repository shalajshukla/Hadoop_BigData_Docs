/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc;

import java.util.ArrayList;
import java.util.List;

/**
 * This is a Tree node class. 
 * Here the concept is that tree consists of nodes [nodeElementList]. 
 * Each node can further contain list of other nodes 
 * & so & so forth to the last level which is in this case a column object.
 * 
 * @author Vijay Dubey - VD3159
 */
public class TreeNode {
	private String nodeName;
	private String nodeValue;
	private String nodeType; // Can contain values from Root , Table sub systems,Tables & Views
	private List nodeElementList = new ArrayList();

	/**
	 * Default constructor
	 */
	public TreeNode(){
		super();
	}
	
	/**
	 * Constructor to set the node name and node type.
	 * @param nodeName
	 * @param nodeType
	 */
	public TreeNode(String nodeName, String nodeType){
		this.nodeName = nodeName;
		this.nodeType = nodeType;
		this.nodeElementList = new ArrayList();
	}
	
	/**
	 * @return Returns the nodeValue.
	 */
	public String getNodeValue() {
		return nodeValue;
	}
	/**
	 * @param nodeValue The nodeValue to set.
	 */
	public void setNodeValue(String nodeValue) {
		this.nodeValue = nodeValue;
	}
	
	/**
	 * @return Returns the nodeElementList.
	 */
	public List getNodeElementList() {
		return nodeElementList;
	}
	/**
	 * @param nodeElementList The nodeElement to add.
	 */
	public void addNodeElement(Object object) {
		this.nodeElementList.add(object);
	}
	/**
	 * @return Returns the nodeName.
	 */
	public String getNodeName() {
		return nodeName;
	}
	/**
	 * @param nodeName The nodeName to set.
	 */
	public void setNodeName(String nodeName) {
		this.nodeName = nodeName;
	}
	/**
	 * @return Returns the nodeType.
	 */
	public String getNodeType() {
		return nodeType;
	}
	/**
	 * @param nodeType The nodeType to set.
	 */
	public void setNodeType(String nodeType) {
		this.nodeType = nodeType;
	}
}
