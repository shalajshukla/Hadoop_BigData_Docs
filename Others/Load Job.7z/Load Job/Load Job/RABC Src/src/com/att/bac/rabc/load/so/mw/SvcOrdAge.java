/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.load.so.mw;

import java.util.Date;

import com.sbc.bac.rabc.load.HashCodeUtil;

/**
 * This is a data object representing entries in RABC_SVC_ORD_AGE table.
 * 
 * @author Shailesh Hemdev - SH8512
 */
public class SvcOrdAge {
	private Date runDate;
	private String division;
	private String busType;
	private long age3DayCt;
	private long age7DayCt;
	private long age14DayCt;
	private long ageGt14DayCt;	
	
	/**
	 * @return Returns the age14DayCt.
	 */
	public long getAge14DayCt() {
		return age14DayCt;
	}
	/**
	 * @param age14DayCt The age14DayCt to set.
	 */
	public void setAge14DayCt(long age14DayCt) {
		this.age14DayCt = age14DayCt;
	}
	/**
	 * @return Returns the age3DayCt.
	 */
	public long getAge3DayCt() {
		return age3DayCt;
	}
	/**
	 * @param age3DayCt The age3DayCt to set.
	 */
	public void setAge3DayCt(long age3DayCt) {
		this.age3DayCt = age3DayCt;
	}
	/**
	 * @return Returns the age7DayCt.
	 */
	public long getAge7DayCt() {
		return age7DayCt;
	}
	/**
	 * @param age7DayCt The age7DayCt to set.
	 */
	public void setAge7DayCt(long age7DayCt) {
		this.age7DayCt = age7DayCt;
	}
	/**
	 * @return Returns the ageGt14DayCt.
	 */
	public long getAgeGt14DayCt() {
		return ageGt14DayCt;
	}
	/**
	 * @param ageGt14DayCt The ageGt14DayCt to set.
	 */
	public void setAgeGt14DayCt(long ageGt14DayCt) {
		this.ageGt14DayCt = ageGt14DayCt;
	}

	/**
	 * @return Returns the division.
	 */
	public String getDivision() {
		return division;
	}
	/**
	 * @param division The division to set.
	 */
	public void setDivision(String division) {
		this.division = division;
	}
	/**
	 * @return Returns the runDate.
	 */
	public Date getRunDate() {
		return runDate;
	}
	/**
	 * @param runDate The runDate to set.
	 */
	public void setRunDate(Date runDate) {
		this.runDate = runDate;
	}
	
	/**
	 * @return Returns the busType.
	 */
	public String getBusType() {
		return busType;
	}
	/**
	 * @param busType The busType to set.
	 */
	public void setBusType(String busType) {
		this.busType = busType;
	}
	/**
	 * Equals method overridden for this object so that it can be stored in a hash map where the key 
	 * would be combination of the following 3 attributes:
	 * Run date
	 * Division
	 * Business type
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object o) {
		// Do a quick check for an identical object reference
	    if (this == o) {
	      return true;
	    }
	    if (!(o instanceof SvcOrdAge)) {
	    	return false;
	    } else {
			if (((SvcOrdAge)o).getRunDate().getTime() == this.getRunDate().getTime()
				&& ((SvcOrdAge)o).getDivision().equalsIgnoreCase(this.getDivision())
				&& ((SvcOrdAge)o).getBusType().equalsIgnoreCase(this.getBusType())	
				) {
				return true;
			} else {
				return false;
			}
	    }
	}
	
	/**
	 * Hash code method overridden for this object to categorize this object in sets 
	 * so that the hash collections can search this object efficiently.
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		int hashCode = HashCodeUtil.SEED;
		hashCode = HashCodeUtil.hash( hashCode, this.getBusType());
	    return hashCode;
	}
}
