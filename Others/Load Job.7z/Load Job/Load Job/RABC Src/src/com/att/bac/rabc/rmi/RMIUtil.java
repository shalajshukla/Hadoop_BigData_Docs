/*
 * Copyright  2002-2005 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.rmi;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;


//import com.att.carat.ldreva.Application;


/**
 * Utility methods for RMI
 * 
 * <p>
 * <hr>
 * <h3>Release History</h3>
 * <p>
 * <ul>
 * 
 */
public final class RMIUtil {

    /**
     * Find the remote object based on the name provided. If the object cannot be found then null is returned.
     * 
     * @param rmiName
     * @return
     * @throws MalformedURLException
     * @throws RemoteException
     * @throws NotBoundException
     */
    public static Object findObject(String rmiName,String host, String port) throws MalformedURLException, RemoteException, NotBoundException {
        String url = findObjectURL(rmiName, host, port);
        if (url == null) {
            return null;
        }
        return Naming.lookup(url);

    }


    /**
     * Find the URL based on the rmiName provided. If the URL can't be found null is returned.
     * 
     * @param rmiName
     * @return URL or null if not found
     */
    public static String findObjectURL(String rmiName, String host, String port) {
//        Properties properties = Application.getProperties();
//        
//        String host = properties.getProperty("server.remote.ip","localhost");
//        int port = Integer.parseInt(properties.getProperty("server.port", "14000"));
//        
//        
        return "rmi://"+host+":" + port + "/" + rmiName;
    }
}
