/* Component Name: RABCPPG00502
 * Module Name: AdminAlertGroupAction.java
 * Created on Jan 19, 2006
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.admin.alert.grp;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.StaticDataLoader;

/**This is the struts Action class for the Alert Group process.  The purpose of this class
 * is mainly to interact between the AdminAlertGroupForm.java class and the struts framework.
 * All business logic is handled in the facade class AdminAlertGroupService.java.
 * 
 * @author js3175
 */
public class AdminAlertGroupAction extends DispatchAction {
	private static final Logger logger = Logger.getLogger(AdminAlertGroupAction.class);
	
	/**This is the struts framework default method entered when entering the admin.alert.grp
	 * process without a dispatch.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of AdminAlertExemptForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward unspecified(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) 
			throws RABCException {
		logger.debug("dispatch = unspecified");
		ActionForward forward = adminAlertGroup(mapping, form, request, response);
		return forward;
	}
	
	/**This is the struts framework method called to set up and present the entry page into
	 * the admin.alert.grp process.  This method is also responsible for catching and logging
	 * all exceptions thrown.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of AdminAlertExemptForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward adminAlertGroup(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = adminAlertGroup");
		ActionForward forward = null;
		try {
			AdminAlertGroupForm adminAlertGroupForm = (AdminAlertGroupForm)form;
			adminAlertGroupForm.setRegion((String)request.getSession().getAttribute("region"));
			adminAlertGroupForm.setUserId((String)request.getSession().getAttribute("bacUserID"));
			adminAlertGroupForm = AdminAlertGroupService.adminAlertGroup(adminAlertGroupForm);
			//Update calendar attributes
			adminAlertGroupForm.setBillRounds(StaticDataLoader.getBillRounds((String)request.getSession().getAttribute("region")));
			adminAlertGroupForm.setProcDates(StaticDataLoader.getProcDates((String)request.getSession().getAttribute("region")));
			adminAlertGroupForm.setHolidayIndicators(StaticDataLoader.getHolidayIndicators((String)request.getSession().getAttribute("region")));
			adminAlertGroupForm.setLoadedDataDates(StaticDataLoader.getLoadedDataDatesByRegion((String)request.getSession().getAttribute("region")));
			log(adminAlertGroupForm);
			forward = mapping.findForward("adminAlertGroup");
		} catch (RABCException e) {
			return this.processError(mapping, request, e);
		}
		return forward;
	}
	
	/**This is the struts framework method called to set up and present the detail page for
	 * the admin.alert.grp process.  On this page, information is entered to create a new
	 * alert group.  This includes entering the name, description, users that are part of the 
	 * new alert group, and chosing the alert rules and application functions the alert group has
	 * access to.  This method is also responsible for catching and logging all exceptions thrown.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of AdminAlertExemptForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward adminAlertGroupDetailCreate(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = adminAlertGroupDetailCreate");
		ActionForward forward = null;
		try {
			AdminAlertGroupForm adminAlertGroupForm = (AdminAlertGroupForm)form;
			adminAlertGroupForm.clear();
			adminAlertGroupForm.setRegion((String)request.getSession().getAttribute("region"));
			adminAlertGroupForm.setUserId((String)request.getSession().getAttribute("bacUserID"));
			adminAlertGroupForm = AdminAlertGroupService.adminAlertGroupDetailCreate(adminAlertGroupForm);
			log(adminAlertGroupForm);
			forward = mapping.findForward("adminAlertGroupDetail");
		} catch (RABCException e) {
			return this.processError(mapping, request, e);
		}
		return forward;
	}
	
	/**This is the struts framework method called to set up and present the detail page for
	 * the admin.alert.grp process.  On this page, information is updated for an existing
	 * alert group.  This includes changing the name, description, users that are part of the 
	 * new alert group, and the alert rules and application functions the alert group has
	 * access to.  This method is also responsible for catching and logging all exceptions thrown.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of AdminAlertExemptForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward adminAlertGroupDetailMaintain(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = adminAlertGroupDetailMaintain");
		ActionForward forward = null;
		try {
			AdminAlertGroupForm adminAlertGroupForm = (AdminAlertGroupForm)form;
			adminAlertGroupForm.setRegion((String)request.getSession().getAttribute("region"));
			adminAlertGroupForm.setUserId((String)request.getSession().getAttribute("bacUserID"));
			adminAlertGroupForm = AdminAlertGroupService.adminAlertGroupDetailMaintain(adminAlertGroupForm);
			log(adminAlertGroupForm);
			forward = mapping.findForward("adminAlertGroupDetail");
		} catch (RABCException e) {
			return this.processError(mapping, request, e);
		}
		return forward;
	}
	
	/**This is the struts framework method called to set up and present the confirm page for
	 * the admin.alert.grp process.  On this page, the values entered on the detail page are displayed
	 * for the user to verify everything is correct.  This method is also responsible for catching and
	 * logging all exceptions thrown.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of AdminAlertExemptForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward adminAlertGroupCreateConfirm(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = adminAlertGroupCreateConfirm");
		ActionForward forward = null;
		try {
			AdminAlertGroupForm adminAlertGroupForm = (AdminAlertGroupForm)form;
			adminAlertGroupForm.setRegion((String)request.getSession().getAttribute("region"));
			adminAlertGroupForm.setUserId((String)request.getSession().getAttribute("bacUserID"));
			adminAlertGroupForm =  AdminAlertGroupService.adminAlertGroupCreateConfirm(adminAlertGroupForm);
			log(adminAlertGroupForm);
			forward = mapping.findForward("adminAlertGroupConfirm");
		} catch (RABCException e) {
			return this.processError(mapping, request, e);
		}
		return forward;
	}
	
	/**This is the struts framework method called to set up and present the confirm page for
	 * the admin.alert.grp process.  On this page, the changes made on the detail page are displayed
	 * for the user to verify everything is correct.  In addition, if an alert rule is removed from the
	 * alert group but the alert rule is only associated with that alert group, this page will inform the user
	 * of this.  This method is also responsible for catching and logging all exceptions thrown.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of AdminAlertExemptForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward adminAlertGroupMaintainConfirm(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = adminAlertGroupMaintainConfirm");
		ActionForward forward = null;
		try {
			AdminAlertGroupForm adminAlertGroupForm = (AdminAlertGroupForm)form;
			adminAlertGroupForm.setRegion((String)request.getSession().getAttribute("region"));
			adminAlertGroupForm.setUserId((String)request.getSession().getAttribute("bacUserID"));
			adminAlertGroupForm = AdminAlertGroupService.adminAlertGroupMaintainConfirm(adminAlertGroupForm);
			log(adminAlertGroupForm);
			forward = mapping.findForward("adminAlertGroupConfirm");
		} catch (RABCException e) {
			return this.processError(mapping, request, e);
		}
		return forward;
	}
	
	/**This is the struts framework method called to set up and present the confirm page for
	 * the admin.alert.grp process.  On this page, all the attributes of the alert group are displayed - the 
	 * name, description, users associated with the alert group, and the application functions, alert rules, and
	 * ad hoc reports associated with the alert group.  In addition, if there are any alert rules or ad hoc 
	 * reports that are associated only with this alert group, this page will inform the user of this.  This
	 * method is also responsible for catching and logging all exceptions thrown.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of AdminAlertExemptForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward adminAlertGroupDeleteConfirm(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = adminAlertGroupDeleteConfirm");
		ActionForward forward = null;
		try {
			AdminAlertGroupForm adminAlertGroupForm = (AdminAlertGroupForm)form;
			adminAlertGroupForm.setRegion((String)request.getSession().getAttribute("region"));
			adminAlertGroupForm.setUserId((String)request.getSession().getAttribute("bacUserID"));
			adminAlertGroupForm = AdminAlertGroupService.adminAlertGroupDeleteConfirm(adminAlertGroupForm);
			log(adminAlertGroupForm);
			forward = mapping.findForward("adminAlertGroupConfirm");
		} catch (RABCException e) {
			return this.processError(mapping, request, e);
		}
		return forward;
	}
	
	/**This is the method called to access the Service class to delete the alert group from the RABC_ALERT_GRP,
	 * RABC_ALERT_GRP_USER, RABC_UPDATE_GRP, RABC_ALERT_GRP_FUNCT, & RABC_PROC_RESPONSIBLE tables.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of AdminAlertExemptForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward deleteAlertGroup(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = deleteAlertGroup");
		ActionForward forward = null;
		try {
			AdminAlertGroupForm adminAlertGroupForm = (AdminAlertGroupForm)form;
			adminAlertGroupForm.setRegion((String)request.getSession().getAttribute("region"));
			adminAlertGroupForm.setUserId((String)request.getSession().getAttribute("bacUserID"));
			adminAlertGroupForm = AdminAlertGroupService.deleteAlertGroup(adminAlertGroupForm);
			log(adminAlertGroupForm);
			forward = mapping.findForward("adminAlertGroup");
			//request.getSession().removeAttribute("AdminAlertGroupForm");
		} catch (RABCException e) {
			return this.processError(mapping, request, e);
		}
		return forward;
	}
	
	/**This is the method called to access the Service class to add the alert group to the RABC_ALERT_GRP,
	 * RABC_ALERT_GRP_USER, RABC_UPDATE_GRP, RABC_ALERT_GRP_FUNCT, & RABC_PROC_RESPONSIBLE tables.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of AdminAlertExemptForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward insertAlertGroup(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = insertAlertGroup");
		ActionForward forward = null;
		try {
			AdminAlertGroupForm adminAlertGroupForm = (AdminAlertGroupForm)form;
			adminAlertGroupForm.setRegion((String)request.getSession().getAttribute("region"));
			adminAlertGroupForm.setUserId((String)request.getSession().getAttribute("bacUserID"));
			adminAlertGroupForm = AdminAlertGroupService.insertAlertGroup(adminAlertGroupForm);
			log(adminAlertGroupForm);
			forward = mapping.findForward("adminAlertGroup");
			//request.getSession().removeAttribute("AdminAlertGroupForm");
		} catch (RABCException e) {
			return this.processError(mapping, request, e);
		}
		return forward;
	}
	
	/**This is the method called to access the Service class to update the alert group in the RABC_ALERT_GRP,
	 * RABC_ALERT_GRP_USER, RABC_UPDATE_GRP, RABC_ALERT_GRP_FUNCT, & RABC_PROC_RESPONSIBLE tables.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of AdminAlertExemptForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward updateAlertGroup(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = updateAlertGroup");
		ActionForward forward = null;
		try {
			AdminAlertGroupForm adminAlertGroupForm = (AdminAlertGroupForm)form;
			adminAlertGroupForm.setRegion((String)request.getSession().getAttribute("region"));
			adminAlertGroupForm.setUserId((String)request.getSession().getAttribute("bacUserID"));
			adminAlertGroupForm = AdminAlertGroupService.updateAlertGroup(adminAlertGroupForm);
			log(adminAlertGroupForm);
			forward = mapping.findForward("adminAlertGroup");
			//request.getSession().removeAttribute("AdminAlertGroupForm");
		} catch (RABCException e) {
			return this.processError(mapping, request, e);
		}
		return forward;
	}
	
	/**This is the struts framework method called to show what alert groups are associated with a particular
	 * user.  The alert rules and application functions for those alert groups are also shown.  This method
	 * is also responsible for catching and logging all exceptions thrown.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of AdminAlertExemptForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward adminUserAccess(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = adminUserAccess");
		ActionForward forward = null;
		try {
			AdminAlertGroupForm adminAlertGroupForm = (AdminAlertGroupForm)form;
			adminAlertGroupForm.setRegion((String)request.getSession().getAttribute("region"));
			adminAlertGroupForm.setUserId((String)request.getSession().getAttribute("bacUserID"));
			adminAlertGroupForm = AdminAlertGroupService.adminUserAccess(adminAlertGroupForm);
			log(adminAlertGroupForm);
			forward = mapping.findForward("adminUserAccess");
		} catch (RABCException e) {
			return this.processError(mapping, request, e);
		}
		return forward;
	}
	
	/**This method sends all error messages to the browser and kills the process.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param request  the HttpServletRequest from the browser
	 * @param e  the error that caused the application to fail.
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	private ActionForward processError(ActionMapping mapping, HttpServletRequest request, Exception e){
		request.setAttribute("javax.servlet.error.exception", e);
		logger.error(e.getMessage(), e);
		return  mapping.findForward("error");
	}
	
	/**This method only shows values in the form to the console when in debug mode.
	 * 
	 * @param adminAlertGroupForm  the ActionForm for this process - AdminAlertGroupForm
	 */
	private void log(AdminAlertGroupForm adminAlertGroupForm) {
		logger.debug("user logged on = " + adminAlertGroupForm.getUserId());
		logger.debug("region = " + adminAlertGroupForm.getRegion());
		logger.debug("alert group name = " + adminAlertGroupForm.getAlertGroupInfo().getAlertGroup());
		logger.debug("alert group description = " + adminAlertGroupForm.getAlertGroupInfo().getAlertGroupDescription());
		logger.debug("*************************************************************************");
	}
}
