/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc;

import org.apache.struts.action.ActionForm;

/**
 * This is a super class for all forms which have paging functionality.
 * 
 * @author Nalina Pandiyan - NP5434
 */
public class PagedForm extends ActionForm {
    private int page;
    private int pages;
    private String dispatch; 
    
	/**
	 * @return Returns the page.
	 */
	public int getPage() {
		return page;
	}
	/**
	 * @param page The page to set.
	 */
	public void setPage(int page) {
		this.page = page;
	}
	/**
	 * @return Returns the pages.
	 */
	public int getPages() {
		return pages;
	}
	/**
	 * @param pages The pages to set.
	 */
	public void setPages(int pages) {
		this.pages = pages;
	}
	/**
	 * @return Returns the dispatch.
	 */
	public String getDispatch() {
		return dispatch;
	}
	/**
	 * @param dispatch The dispatch to set.
	 */
	public void setDispatch(String dispatch) {
		this.dispatch = dispatch;
	}
}
