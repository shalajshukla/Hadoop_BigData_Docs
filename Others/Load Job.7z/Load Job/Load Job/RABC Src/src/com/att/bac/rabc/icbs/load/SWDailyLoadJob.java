/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.icbs.load;

import java.io.File;
import java.net.UnknownHostException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import com.att.bac.rabc.util.EmcisEventLogger;
import com.att.carat.util.NetUtil;
import com.sbc.bac.rabc.load.FilePatternLoadJob;
import com.sbc.bac.rabc.load.PrepareTableForRerun;
import com.sbc.bac.rabc.load.RabcLoadJobTrig;
import com.sbc.bac.rabc.load.RetrieveStaticInfo;
import com.sbc.bac.rabc.load.StaticErrorMsgKeys;
import com.sbc.bac.rabc.load.StaticFieldKeys;

/**
 * This is a Load job which loads ICBS load file for SW region into the following tables:
 * RABC_ICBS_INVOICE_READY
 * RABC_ICBS_MSG_READY
 * RABC_ICBS_INVOICE_DERIVED
 * RABC_ICBS_RETURN
 * 
 * @author Shailesh Hemdev - SH8512
 */
public class SWDailyLoadJob extends FilePatternLoadJob {
	private static final SimpleDateFormat MMDDYY_FORMAT = new SimpleDateFormat("MM-dd-yy");
	private static final SimpleDateFormat MMDDYYYY_FORMAT = new SimpleDateFormat("MMddyyyy");
	
	private static final String RABC_ICBS_INVOICE_READY = "RABC_ICBS_INVOICE_READY";
	private static final String RABC_ICBS_MSG_READY = "RABC_ICBS_MSG_READY";
	private static final String RABC_ICBS_INVOICE_DERIVED = "RABC_ICBS_INVOICE_DERIVED";
	private static final String RABC_ICBS_RETURN = "RABC_ICBS_RETURN";
	private static final String RABC_TRIG = "RABC_TRIG";
	
	private static final String INVOICE_READY_FILE_ID = "SWICBSIB";
	private static final String MSG_READY_FILE_ID = "SWICBSMR";
	private static final String INVOICE_DERIVED_FILE_ID = "SWICBSIR";
	private static final String RETURN_FILE_ID = "SWICBSRT";
	
	private static final String fieldSeperator = StaticFieldKeys.SEMICOLON;
	
	/*
	 * Prepared statements for 4 tables.
	 */
	private PreparedStatement insertInvoiceReady;
	private PreparedStatement insertMsgReady;
	private PreparedStatement insertInvoiceDerived;
	private PreparedStatement insertReturn;
	
	private String runDate;
	private java.sql.Date sqlRunDate;
	private java.util.Date utilRunDate;
	private String division;
	private String backoutRecovery = null;
	private File currentFile;
	private String billRnd;
	
	private int recordCount;
	private int invoiceReadyBatchCounter;
	private int msgReadyBatchCounter;
	private int invoiceDerivedBatchCounter;
	private int returnBatchCounter;
	
	private String fileName, fileToken, region;
	/*
	 * HashMap variables to contain the groups for various tables.
	 */
	private HashMap icbsReturnMap;
	private HashMap icbsDataMap;
	/*
	 * boolean variables indicating whether trigger to be inserted for that file id.
	 */
	boolean isInvoiceReady;
	boolean isMsgReady;
	boolean isInvoiceDerived;
	boolean isReturn;
	
	/*
	 * boolean variables indicating whether the file to be processed or not.
	 */
	boolean isHeaderExists;
	boolean isTrailerExists;
	boolean isDateRecordExists;
	boolean isRecordCountMatches;
	
	/**
	 * Overriding preprocess() method. 
	 * It is executed prior to processing the load job.
	 * Forms the actual prepared statements which need to be fired on to the database.
	 * 
	 * @see com.sbc.bac.load.LoadJob#preprocess()
	 */
	public boolean preprocess() {
		boolean success = super.preprocess();

		if (success) {
			try {
//				insertInvoiceReady 		= connection.prepareStatement("INSERT INTO RABC_ICBS_INVOICE_READY (RUN_DATE, DIVISION,ENTITY_CD, TRN_TYPE, DAILY_INPUT_MSG_CT, DAILY_INPUT_AMT, EMS_ERR_MSG_CT, EMS_ERR_AMT, RTN_MSG_CT, RTN_MSG_AMT, BLG_MSG_CT, BLG_MSG_AMT, CRUDE_OUT_MSG_CT, CRUDE_OUT_MSG_AMT, TOT_MSG_INPUT_CT, TOT_MSG_PROC_CT, TOT_MSG_INPUT_AMT, TOT_MSG_PROC_AMT, BILL_RND) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ) ");
				insertInvoiceReady 		= connection.prepareStatement("INSERT INTO RABC_ICBS_INVOICE_READY (RUN_DATE, DIVISION,ENTITY_CD, TRN_TYPE, DAILY_INPUT_MSG_CT, DAILY_INPUT_AMT, EMS_ERR_MSG_CT, EMS_ERR_AMT, RTN_MSG_CT, RTN_MSG_AMT, BLG_MSG_CT, BLG_MSG_AMT, TOT_MSG_INPUT_CT, TOT_MSG_PROC_CT, TOT_MSG_INPUT_AMT, TOT_MSG_PROC_AMT, BILL_RND,MASTER_MSG_CT, MASTER_REV_AMT, REENTERED_MSG_CT, REENTERED_REV_AMT, BEGIN_MSG_CT, BEGIN_REV_AMT, EMS_IN_MSG_CT, EMS_IN_REV_AMT) " +
																		"  VALUES(?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ) ");
				
				insertMsgReady			= connection.prepareStatement("INSERT INTO RABC_ICBS_MSG_READY (RUN_DATE, DIVISION,ENTITY_CD, TRN_TYPE, DAILY_INPUT_MSG_CT, DAILY_INPUT_AMT, EMS_ERR_MSG_CT, EMS_ERR_AMT, RTN_MSG_CT, RTN_MSG_AMT, BLG_MSG_CT, BLG_MSG_AMT, CRUDE_OUT_MSG_CT, CRUDE_OUT_MSG_AMT, TOT_MSG_INPUT_CT, TOT_MSG_PROC_CT, TOT_MSG_INPUT_AMT, TOT_MSG_PROC_AMT, BILL_RND) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ) ");
				insertInvoiceDerived 	= connection.prepareStatement("INSERT INTO RABC_ICBS_INVOICE_DERIVED (RUN_DATE, DIVISION,ENTITY_CD, TRN_TYPE, DAILY_INPUT_MSG_CT, DAILY_INPUT_AMT, RTN_MSG_CT, RTN_MSG_AMT, BLG_MSG_CT, BLG_MSG_AMT, CRUDE_OUT_MSG_CT, CRUDE_OUT_MSG_AMT, TOT_MSG_INPUT_CT, TOT_MSG_PROC_CT, TOT_MSG_INPUT_AMT, TOT_MSG_PROC_AMT, BILL_RND) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ) ");
				insertReturn 			= connection.prepareStatement("INSERT INTO RABC_ICBS_RETURN (RUN_DATE, DIVISION,ENTITY_CD, DATA_FILE, RTN_CD, TOT_RTN_CT_DB, TOT_RTN_AMT_DB,TOT_RTN_CT_CR, TOT_RTN_AMT_CR) VALUES(?, ?, ?, ?, ?, ?, ?, ? ,? ) ");
				
			} catch (SQLException e) {
				severe(StaticErrorMsgKeys.PREPROCESS_ERROR + e.getMessage(), e);
				success = false;
			}
		}
		
		return success;
	}
	
	/**
	 * Overriding preprocessFile(file) method.
	 * It is executed prior to processing the file to be loaded.
	 * It includes the following steps:
	 * 	1) Marks the backoutRecovery flag to "Y" if this file has already been processed earlier.
	 * 	2) Initializes the global variables with default values.
	 * 
	 * @see com.sbc.bac.load.FileDBLoadJob#preprocessFile(java.io.File)
	 */	
	public boolean preprocessFile(File file) {
		boolean success = super.preprocessFile(file);
		fileToken = "RA120F01";
		fileName = file.getName();
		region   =	file.getName().substring(0,2);
		if (success) {
			try {
				/*
				 * Check whether this file has been processed before and if yes,
				 * mark the backoutRecovery flag to "Y".
				 */
				if (RabcLoadJobTrig.IsOriginalFileLoaded(connection, file, file.getName().length())) {
					backoutRecovery = "Y";
				}
			} catch (Exception e) {
				severe(StaticErrorMsgKeys.PREPROCESSFILE_ERROR + e.getMessage(), e);
				success = false;
			}
		}
		
		/*
		 * Initialize the global variables with default values.
		 */
		currentFile = file;
		recordCount = 0;
		isHeaderExists = false;
		isTrailerExists = false;
		isDateRecordExists=false;
		isRecordCountMatches = false;
		invoiceReadyBatchCounter = 0;
		invoiceDerivedBatchCounter = 0;
		msgReadyBatchCounter = 0;
		returnBatchCounter = 0;
		icbsDataMap = new HashMap();
		icbsReturnMap = new HashMap();
		isInvoiceReady = false;
		isMsgReady = false;
		isInvoiceDerived = false;
		isReturn = false;
		
		return success;
	}
	
	/**
	 * Overriding parseLine(line) method.
	 * It accepts a single line and checks whether it is header, trailer, date or detail record.
	 * Depending upon the record type, it calls the respective internal private methods to process the line.
	 * 
	 * @see com.sbc.bac.load.FileDBLoadJob#parseLine(java.lang.String)
	 */
	protected int parseLine(String line) throws Exception {
		boolean status = true;
		String recordIndicator = getRecordType(line);
		
		if ("HEADER".equalsIgnoreCase(recordIndicator)) {
			isHeaderExists = true;
			status = processHeader(line);
		} else if ("DATE".equalsIgnoreCase(recordIndicator)) {
			if (!isHeaderExists) {
				throw new Exception("Either header record is not present in the file or it is not the first record.");
			} else {
				isDateRecordExists = true;
				recordCount++;
				status = processCycleRecord(line);
			}
		} else if ("TRAILER".equalsIgnoreCase(recordIndicator)) {
			if (!isHeaderExists) {
				throw new Exception("Either header record is not present in the file or it is not the first record.");
			}else if (!isDateRecordExists){
				throw new Exception("Either date record is not present in the file or it is not the second record.");
			}else {
				isTrailerExists = true;
				status = processTrailer(line);
			}
		}  else if ("DAILY".equalsIgnoreCase(recordIndicator)) {
			if (!isHeaderExists) {
				throw new Exception("Either header record is not present in the file or it is not the first record.");
			} else if (!isDateRecordExists) {
				throw new Exception("Either date record is not present in the file or it is not the second record.");
			} else if (isTrailerExists) {
				throw new Exception("Trailer record is not the last record.");
			} else {
				recordCount++;
				status = processDaily(line);
			}
		} else if ("RETURN".equalsIgnoreCase(recordIndicator)) {
			if (!isHeaderExists) {
				throw new Exception("Either header record is not present in the file or it is not the first record.");
			} else if (!isDateRecordExists) {
				throw new Exception("Either date record is not present in the file or it is not the second record.");
			} else if (isTrailerExists) {
				throw new Exception("Trailer record is not the last record.");
			} else {
				recordCount++;
				status = processReturn(line);
			}
		} else {
			recordCount++;
			status = false;
		}
		
		if (status) {
			return SUCCESS;
		} else {
			return ERROR;
		}
	}
	
	/**
	 * Private method to return the record type of the line to be processed.
	 * 
	 * @param line
	 * @return String
	 * @throws Exception
	 */
	private String getRecordType(String line) throws Exception {
		String recordType = null;
		
		String [] lineFields = line.split(fieldSeperator);
		
		if (lineFields.length > 1) {
			String firstField			= lineFields[0].trim();
			String secondField			= lineFields[1].trim();
			
			if ("HEADER".equals(firstField)) {
				recordType = "HEADER";
			} else if ("TRAILER".equals(firstField)) {
				recordType = "TRAILER";
			} else {
				if ("RA12ICBS".equals(firstField)) {
					if ("01".equals(secondField)) {
						recordType = "DATE";
					} else {
						recordType = "DAILY";
					}
				} else if ("RA12ERCD".equals(firstField)) {
					recordType = "RETURN";
				}
			}
		}
		
		return recordType;
	}
	
	/**
	 * Private method to process the header record.
	 * 
	 * @param line
	 * @return boolean
	 * @throws Exception
	 */
	private boolean processHeader(String line) throws Exception {
		boolean success = false;
		
		String [] lineFields = line.split(fieldSeperator);
		
		/*
		 * Populate the instance variable for division.
		 */
		if (lineFields.length > 2) {
			division = lineFields[2].trim();
			success = true;
		}
		
		return success;
	}
	
	/**
	 * Private method to process the trailer record.
	 * It checks that whether the total number of records (excluding header and trailer records)
	 * in the file is eqaul to the count in the trailer record or not.
	 *  
	 * @param line
	 * @return boolean
	 * @throws Exception
	 */
	private boolean processTrailer(String line) throws Exception {
		boolean success = false;
		int trailerCount = 0;
		
		String [] lineFields = line.split(fieldSeperator);
		
		if (lineFields.length > 5) {
			trailerCount = Integer.parseInt(lineFields[5].trim());
			success = true;
		}
		
		if (success) {
			if (trailerCount == recordCount) {
				isRecordCountMatches = true;
			}
		}
		
		return success;
	}
	
	/**
	 * Private method to process the date record. It does the following steps:
	 * 	1) Retrieves the cycle date from the date record.
	 * 	2) Deletes the records matching with the date and division retrieved form the file from the tables 
	 * 	   RABC_ICBS_INVOICE_READY, RABC_ICBS_MSG_READY, RABC_ICBS_INVOICE_DERIVED, RABC_ICBS_RETURN
	 * 	   if the backoutRecovery flag is "Y", i.e. this file has already been processed earlier.
	 * 	3) Get the biil rnd from RABC_CYCLE_CALENDAR table.
	 * 
	 * @param line
	 * @return boolean
	 * @throws Exception
	 */
	private boolean processCycleRecord(String line) throws Exception {
		boolean success = false;
		
		String [] lineFields = line.split(fieldSeperator);
		
		/*
		 * Populate the instance variable for runDate.
		 */
		if (lineFields.length > 2) {
			runDate = lineFields[2].trim();
			success = true;
		}
		
		if (success) {
			sqlRunDate = new java.sql.Date(MMDDYY_FORMAT.parse(runDate).getTime());
			utilRunDate = new java.util.Date(MMDDYY_FORMAT.parse(runDate).getTime());
			
			String runDatequery = "SELECT PROC_DT FROM RABC_CYCLE_CALENDAR WHERE PROC_DT = to_date('" + runDate + "','MM-dd-yy')";
			boolean isRunDateExists	= RetrieveStaticInfo.isProcDateExists(connection, runDatequery);
			
			if (!isRunDateExists) {
				throw new Exception("The cycle date " + runDate + " does not exist in RABC_CYCLE_CALENDAR table.");
			}
			
			String query = "SELECT to_char(BILL_RND,'00') FROM RABC_CYCLE_CALENDAR WHERE PROC_DT = to_date('" + runDate + "','MM-dd-yy')";
			billRnd	= RetrieveStaticInfo.getBillRnd(connection, query);
			if ("0".equals(billRnd) || "00".equals(billRnd) || "".equals(billRnd.trim())) {
				billRnd = "0";
			}
			
			if ("Y".equals(backoutRecovery)) {
				if (!PrepareTableForRerun.deleteTableData(connection, RABC_ICBS_INVOICE_READY, division, sqlRunDate)) {
					throw new Exception("Error occurred attempting to backup and recover for rerun for table: " + RABC_ICBS_INVOICE_READY);
				}
				if (!PrepareTableForRerun.deleteTableData(connection, RABC_ICBS_INVOICE_DERIVED, division, sqlRunDate)) {
					throw new Exception("Error occurred attempting to backup and recover for rerun for table: " + RABC_ICBS_INVOICE_DERIVED);
				}
				if (!PrepareTableForRerun.deleteTableData(connection, RABC_ICBS_MSG_READY, division, sqlRunDate)) {
					throw new Exception("Error occurred attempting to backup and recover for rerun for table: " + RABC_ICBS_MSG_READY);
				}
				if (!PrepareTableForRerun.deleteTableData(connection, RABC_ICBS_RETURN, division, sqlRunDate)) {
					throw new Exception("Error occurred attempting to backup and recover for rerun for table: " + RABC_ICBS_RETURN);
				}
			}
		}

		return success;
	}
	
	/**
	 * Private method to process the records for the rule 'RA12ICBS'.
	 * It does the following steps:
	 * 	1) Retrieves the fields from the line.
	 * 	2) Does conversion of data from String to appropriate data types as well as interpretation for amount.
	 * 	3) Substitutes the prepared insert statements and add them to a batch. 
	 * 	4) Executes batch after every 1000 records.
	 * 
	 * @param line
	 * @return boolean
	 * @throws Exception
	 */
	private boolean processDaily(String line) throws Exception {
		boolean success = false;
		
		String [] lineFields = line.split(fieldSeperator);
		
//		if (lineFields.length >= 16) {
		if (lineFields.length >= 8) {
			String rule		 		= lineFields[0].trim();
			String ruleNo			= lineFields[1].trim();
			String trnType			= lineFields[2].trim();
			String entityCode		= getEntityCode(lineFields[3].trim());
			//sb8798 start
			String beginMsgCount	= null;
			String masterMsgCount	= null;
			String beginMsgAmount	= null;
			String masterMsgAmount	= null;
			//sb8798 end
			String rawInputCount	= null;
			String erredCount		= null;
			String rawInputAmount	= null;
			String erredAmount		= null;
			String errDroppedCount	= null; 	//sb8798
			String returnedCount	= null;
			String errDroppedAmount	= null;		//sb8798
			String returnedAmount	= null;
			String reEnteredCount	= null;		//sb8798
			String billingCount		= null;
			String reEnteredAmount	= null;		//sb8798
			String billingAmount	= null;
			String crudeCount		= null;
			String crudeAmount		= null;
			String inputCount		= null;
			String processedCount	= null;
			String inputAmount		= null;
			String processedAmount	= null;
			
			if (!"".equals(entityCode) && (("ADJUSTMENTS".equalsIgnoreCase(trnType) || "ADJUSTMENT".equalsIgnoreCase(trnType) || "TOLL REVENUE".equalsIgnoreCase(trnType)))) {				
				if ("19".equals(ruleNo)) {		
					rawInputCount	= lineFields[4].trim();
					crudeCount		= lineFields[5].trim();
					rawInputAmount	= lineFields[6].trim();
					crudeAmount		= lineFields[7].trim();
					returnedCount	= lineFields[8].trim();
					returnedAmount	= lineFields[9].trim();
					billingCount	= lineFields[10].trim();
					billingAmount	= lineFields[11].trim();
					inputCount		= lineFields[14].trim();
					processedCount	= lineFields[15].trim();
					inputAmount		= lineFields[16].trim();
					processedAmount	= lineFields[17].trim();
					
//					rawInputCount	= lineFields[4].trim();
//					rawInputAmount	= lineFields[5].trim();
//					returnedCount	= lineFields[6].trim();
//					returnedAmount	= lineFields[7].trim();
//					billingCount	= lineFields[8].trim();
//					billingAmount	= lineFields[9].trim();
//					crudeCount		= lineFields[10].trim();
//					crudeAmount		= lineFields[11].trim();
//					inputCount		= lineFields[12].trim();
//					processedCount	= lineFields[13].trim();
//					inputAmount		= lineFields[14].trim();
//					processedAmount	= lineFields[15].trim();
				}else if ("10".equals(ruleNo)) {		
					rawInputCount	= lineFields[4].trim();
					erredCount		= lineFields[5].trim();
					rawInputAmount	= lineFields[6].trim();
					erredAmount		= lineFields[7].trim();
					returnedCount	= lineFields[8].trim();
					returnedAmount	= lineFields[9].trim();
					billingCount	= lineFields[10].trim();
					billingAmount	= lineFields[11].trim();
					crudeCount		= lineFields[12].trim();
					crudeAmount		= lineFields[13].trim();
					inputCount		= lineFields[14].trim();
					processedCount	= lineFields[15].trim();
					inputAmount		= lineFields[16].trim();
					processedAmount	= lineFields[17].trim();
				} else if("02".equals(ruleNo)){
					beginMsgCount	 = lineFields[4].trim();
					masterMsgCount	 = lineFields[5].trim();
					beginMsgAmount	 = lineFields[6].trim();
					masterMsgAmount	 = lineFields[7].trim();
					rawInputCount	 = lineFields[8].trim();
					erredCount		 = lineFields[9].trim();
					rawInputAmount	 = lineFields[10].trim();
					erredAmount		 = lineFields[11].trim();
					errDroppedCount	 = lineFields[12].trim();
					returnedCount	 = lineFields[13].trim();
					errDroppedAmount = lineFields[14].trim();
					returnedAmount	 = lineFields[15].trim();
					reEnteredCount	 = lineFields[16].trim();
					billingCount	 = lineFields[17].trim();
					reEnteredAmount	 = lineFields[18].trim();
					billingAmount	 = lineFields[19].trim();
					inputCount		 = lineFields[20].trim();					
				} else if("55".equals(ruleNo)) {
					inputCount		= lineFields[4].trim();
					processedCount	= lineFields[5].trim();
					inputAmount		= lineFields[6].trim();
					processedAmount	= lineFields[7].trim();					
				}
				
				/*
				 * Process the values obtained from the file. 
				 * In case of count convert to appropriate primitive using wrapper whereas in
				 * case of amounts strip off the dollar sign as well as check whether 
				 * the amount is +ve (debit) or -ve (credit)
				 */
				long beginMessageCnt = 0;
				double beginMsgAmt = 0.0;
				long masterMsgCnt = 0;
				double masterMsgAmt = 0.0;
				long emsInMsgCnt = 0;
				double emsInMsgAmt = 0.0;
				long reenteredCnt = 0;
				double reenterMsgAmt = 0.0;
				
				long dailyInputMsgCnt = 0;
				double dailyInputMsgAmt = 0.0;
				long emsErrorMsgCnt = 0;
				double emsErrorMsgAmt = 0.0;
				long returnedMsgCnt = 0;
				double returnedMsgAmt = 0.0;
				long billedMsgCnt = 0;
				double billedMsgAmt = 0.0;
				long crudeOutMsgCnt = 0;
				double crudeOutMsgAmt = 0.0;
				long inputMsgCnt = 0;
				double inputMsgAmt = 0.0;
				long processedMsgCnt = 0;
				double processedMsgAmt = 0.0;
				
				if ("02".equals(ruleNo)) {
					// BEGINING MESSAGES
					if (beginMsgCount != null && beginMsgAmount != null) {
						beginMessageCnt		= Long.parseLong(beginMsgCount);	
						beginMsgAmt = convertValue(beginMsgAmount);
					}

					// MASTER MESSAGES
					if (masterMsgCount != null && masterMsgAmount != null) {
						masterMsgCnt		= Long.parseLong(masterMsgCount);	
						masterMsgAmt = convertValue(masterMsgAmount);
					}
	
					// EMS IN REVENUE - count of erred/dropped Charges
					if (errDroppedCount != null && errDroppedAmount != null) {
						emsInMsgCnt			= Long.parseLong(errDroppedCount);	
						emsInMsgAmt = convertValue(errDroppedAmount);
					}
	
					// REENTERED REVENUE
					if (reEnteredCount != null && reEnteredAmount != null) {
						reenteredCnt			= Long.parseLong(reEnteredCount);	
						reenterMsgAmt = convertValue(reEnteredAmount);
					}
				}
				// DAILY INPUT MESSAGES
				if (!"55".equals(ruleNo)) {
					if (rawInputCount != null && rawInputAmount != null) {
						dailyInputMsgCnt		= Long.parseLong(rawInputCount);
						dailyInputMsgAmt = convertValue(rawInputAmount);
					}
				}
/*				if (rawInputCount != null && rawInputAmount != null) {
					dailyInputMsgCnt		= Long.parseLong(rawInputCount);
					String tempDailyInputMsgAmt	= rawInputAmount.substring(1,rawInputAmount.length()).replaceAll(",","");
					if (tempDailyInputMsgAmt.indexOf("CR")==-1 && tempDailyInputMsgAmt.indexOf("cr")==-1){
						dailyInputMsgAmt = Double.parseDouble(tempDailyInputMsgAmt);
					}else {
						dailyInputMsgAmt = -(Double.parseDouble(tempDailyInputMsgAmt.substring(0,tempDailyInputMsgAmt.length()-2)));
					}
				}
*/				
				// EMS ERROR CHARGES
				if ((!"19".equals(ruleNo)) && (!"55".equals(ruleNo))) {
					if (erredCount != null && erredAmount != null) {
						emsErrorMsgCnt			= Long.parseLong(erredCount);	
						emsErrorMsgAmt = convertValue(erredAmount);
					}
				}

				// EMS ERROR CHARGES
/*				if (!"19".equals(ruleNo)) {
					if (erredCount != null && erredAmount != null) {
						emsErrorMsgCnt			= Long.parseLong(erredCount);	
						String tempEMSErrorMsgAmt	= erredAmount.substring(1,erredAmount.length()).replaceAll(",","");
						if (tempEMSErrorMsgAmt.indexOf("CR")==-1 && tempEMSErrorMsgAmt.indexOf("cr")==-1){
							emsErrorMsgAmt = Double.parseDouble(tempEMSErrorMsgAmt);
						}else {
							emsErrorMsgAmt = -(Double.parseDouble(tempEMSErrorMsgAmt.substring(0,tempEMSErrorMsgAmt.length()-2)));
						}
					}
				}
*/
				// RETURNED MESSAGES
				if (!"55".equals(ruleNo)) {
					if (returnedCount != null && returnedAmount != null) {
						returnedMsgCnt			= Long.parseLong(returnedCount);
						returnedMsgAmt = convertValue(returnedAmount);
					}
				}
/*				if (returnedCount != null && returnedAmount != null) {
					returnedMsgCnt			= Long.parseLong(returnedCount);
					String tempReturnedMsgAmt	= returnedAmount.substring(1,returnedAmount.length()).replaceAll(",","");
					if (tempReturnedMsgAmt.indexOf("CR")==-1 && tempReturnedMsgAmt.indexOf("cr")==-1){
						returnedMsgAmt = Double.parseDouble(tempReturnedMsgAmt);
					} else {
						returnedMsgAmt = -(Double.parseDouble(tempReturnedMsgAmt.substring(0,tempReturnedMsgAmt.length()-2)));
					}
				}
*/				
				// BILLED MESSAGES
				if (!"55".equals(ruleNo)) {
					if (billingCount != null && billingAmount != null) {
						billedMsgCnt			= Long.parseLong(billingCount);
						billedMsgAmt = convertValue(billingAmount);
					}
				}
				
/*				if (billingCount != null && billingAmount != null) {
					billedMsgCnt			= Long.parseLong(billingCount);
					String tempBilledMsgAmt	= billingAmount.substring(1,billingAmount.length()).replaceAll(",","");
					if (tempBilledMsgAmt.indexOf("CR")==-1 && tempBilledMsgAmt.indexOf("cr")==-1){
						billedMsgAmt = Double.parseDouble(tempBilledMsgAmt);
					} else {
						billedMsgAmt = -(Double.parseDouble(tempBilledMsgAmt.substring(0,tempBilledMsgAmt.length()-2)));
					}
				}
*/				
				// CRUDE OUT MESSAGES
				if ((!"02".equals(ruleNo)) && (!"55".equals(ruleNo))) {
					if (crudeCount != null && crudeAmount != null) {
						crudeOutMsgCnt			= Long.parseLong(crudeCount);
						crudeOutMsgAmt = convertValue(crudeAmount);
					}
				}
/*				if (crudeCount != null && crudeAmount != null) {
					crudeOutMsgCnt			= Long.parseLong(crudeCount);
					String tempCrudeOutMsgAmt	= crudeAmount.substring(1,crudeAmount.length()).replaceAll(",","");
					if (tempCrudeOutMsgAmt.indexOf("CR")==-1 && tempCrudeOutMsgAmt.indexOf("cr")==-1){
						crudeOutMsgAmt = Double.parseDouble(tempCrudeOutMsgAmt);
					} else {
						crudeOutMsgAmt = -(Double.parseDouble(tempCrudeOutMsgAmt.substring(0,tempCrudeOutMsgAmt.length()-2)));
					}
				}
*/				
				// INPUT MESSAGES
				if ("02".equals(ruleNo)) {
					if (inputCount != null) {
						inputMsgCnt			= Long.parseLong(inputCount);
					}
				} else {
					if (inputCount != null && inputAmount != null) {
						inputMsgCnt			= Long.parseLong(inputCount);
						inputMsgAmt = convertValue(inputAmount);
					}	
				}
					
				/*if (inputCount != null && inputAmount != null) {
					inputMsgCnt			= Long.parseLong(inputCount);
					String tempInputMsgAmt	= inputAmount.substring(1,inputAmount.length()).replaceAll(",","");
					if (tempInputMsgAmt.indexOf("CR")==-1 && tempInputMsgAmt.indexOf("cr")==-1){
						inputMsgAmt = Double.parseDouble(tempInputMsgAmt);
					} else {
						inputMsgAmt = -(Double.parseDouble(tempInputMsgAmt.substring(0,tempInputMsgAmt.length()-2)));
					}
				}*/
				
				// PROCESSED MESSAGES
				if (!"02".equals(ruleNo)) {
					if (processedCount != null && processedAmount != null) {
						processedMsgCnt		= Long.parseLong(processedCount);
						processedMsgAmt = convertValue(processedAmount);
					}
				}
/*				if (processedCount != null && processedAmount != null) {
					processedMsgCnt		= Long.parseLong(processedCount);
					String tempProcessedMsgAmt	= processedAmount.substring(1,processedAmount.length()).replaceAll(",","");
					if (tempProcessedMsgAmt.indexOf("CR")==-1 && tempProcessedMsgAmt.indexOf("cr")==-1){
						processedMsgAmt = Double.parseDouble(tempProcessedMsgAmt);
					} else {
						processedMsgAmt = -(Double.parseDouble(tempProcessedMsgAmt.substring(0,tempProcessedMsgAmt.length()-2)));
					}
				}
*/				
				if (inputMsgCnt != 0) {
					success = true;
					
					if ("02".equals(ruleNo) || "55".equals(ruleNo) ) {						//Insert to RABC_ICBS_INVOICE_READY table
						ICBSData icbsData	= new ICBSData();
						icbsData.setRunDate(MMDDYYYY_FORMAT.parse(runDate));
						icbsData.setDivision(division);
						icbsData.setEntityCd(entityCode);
						if ("ADJUSTMENTS".equalsIgnoreCase(trnType) || "ADJUSTMENT".equalsIgnoreCase(trnType)) {
							icbsData.setTrnType("ADJ");
						} else if ("TOLL REVENUE".equalsIgnoreCase(trnType)) {
							icbsData.setTrnType("TOLL");
						}  
					
						//Check whether the above object is present in the hash map
						 
						ICBSData objRef = null;
						objRef = (ICBSData)icbsDataMap.get(icbsData);
						
						if (objRef != null){
							//update the remaining fields.
							if ("02".equals(ruleNo)) {
								objRef.setDailyInputMsgCt(dailyInputMsgCnt);
								objRef.setDailyInputMsgAmt(dailyInputMsgAmt);
								objRef.setEmsErrMsgCt(emsErrorMsgCnt);
								objRef.setEmsErrMsgAmt(emsErrorMsgAmt);
								objRef.setRtnMsgCt(returnedMsgCnt);
								objRef.setRtnMsgAmt(returnedMsgAmt);
								objRef.setBlgMsgCt(billedMsgCnt);
								objRef.setBlgMsgAmt(billedMsgAmt);
//								objRef.setCrudeOutMsgCt(crudeOutMsgCnt);
//								objRef.setCrudeOutMsgAmt(crudeOutMsgAmt);
								objRef.setBegMsgCt(beginMessageCnt);
								objRef.setBegMsgAmt(beginMsgAmt);
								objRef.setMasMsgCt(masterMsgCnt);
								objRef.setMasMsgAmt(masterMsgAmt);
								objRef.setEmsMsgCt(emsInMsgCnt);
								objRef.setEmsMsgAmt(emsInMsgAmt);
								objRef.setReentMsgCt(reenteredCnt);
								objRef.setReentMsgAmt(reenterMsgAmt);								
							} else if ("55".equals(ruleNo)){ // if ruleNo = 11
								objRef.setTotalInputMsgCt(inputMsgCnt);
								objRef.setTotalInputMsgAmt(inputMsgAmt);
								objRef.setTotalPostedMsgCt(processedMsgCnt);
								objRef.setTotalPostedMsgAmt(processedMsgAmt);								
							}
							icbsDataMap.put(objRef,objRef);
						} else {
							if ("02".equals(ruleNo)) {
							// check 2 or 11 and set the corresponding fields in ICBSDAta
								icbsData.setDailyInputMsgCt(dailyInputMsgCnt);
								icbsData.setDailyInputMsgAmt(dailyInputMsgAmt);
								icbsData.setEmsErrMsgCt(emsErrorMsgCnt);
								icbsData.setEmsErrMsgAmt(emsErrorMsgAmt);
								icbsData.setRtnMsgCt(returnedMsgCnt);
								icbsData.setRtnMsgAmt(returnedMsgAmt);
								icbsData.setBlgMsgCt(billedMsgCnt);
								icbsData.setBlgMsgAmt(billedMsgAmt);
	//							icbsData.setCrudeOutMsgCt(crudeOutMsgCnt);
	//							icbsData.setCrudeOutMsgAmt(crudeOutMsgAmt);
								icbsData.setBegMsgCt(beginMessageCnt);
								icbsData.setBegMsgAmt(beginMsgAmt);
								icbsData.setMasMsgCt(masterMsgCnt);
								icbsData.setMasMsgAmt(masterMsgAmt);
								icbsData.setEmsMsgCt(emsInMsgCnt);
								icbsData.setEmsMsgAmt(emsInMsgAmt);
								icbsData.setReentMsgCt(reenteredCnt);
								icbsData.setReentMsgAmt(reenterMsgAmt);
							} else if ("55".equals(ruleNo)) {
								icbsData.setTotalInputMsgCt(inputMsgCnt);
								icbsData.setTotalInputMsgAmt(inputMsgAmt);
								icbsData.setTotalPostedMsgCt(processedMsgCnt);
								icbsData.setTotalPostedMsgAmt(processedMsgAmt);
							}
							icbsDataMap.put(icbsData,icbsData);
							
						}
											
					} else if ("10".equals(ruleNo)) {				//Insert to RABC_ICBS_MSG_READY table
						insertMsgReady.setDate(1, sqlRunDate);
						insertMsgReady.setString(2, division);	
						insertMsgReady.setString(3, entityCode);
						if ("ADJUSTMENTS".equalsIgnoreCase(trnType) || "ADJUSTMENT".equalsIgnoreCase(trnType)) {
							insertMsgReady.setString(4, "ADJ");
						} else if ("TOLL REVENUE".equalsIgnoreCase(trnType)) {
							insertMsgReady.setString(4, "TOLL");
						}
						insertMsgReady.setLong(5, dailyInputMsgCnt);
						insertMsgReady.setDouble(6, dailyInputMsgAmt);
						insertMsgReady.setLong(7, emsErrorMsgCnt);
						insertMsgReady.setDouble(8, emsErrorMsgAmt);
						insertMsgReady.setLong(9, returnedMsgCnt);
						insertMsgReady.setDouble(10, returnedMsgAmt);
						insertMsgReady.setLong(11, billedMsgCnt);
						insertMsgReady.setDouble(12, billedMsgAmt);
						insertMsgReady.setLong(13, crudeOutMsgCnt);
						insertMsgReady.setDouble(14, crudeOutMsgAmt);
						insertMsgReady.setLong(15, inputMsgCnt);
						insertMsgReady.setDouble(17, inputMsgAmt);
						insertMsgReady.setLong(16, processedMsgCnt);
						insertMsgReady.setDouble(18, processedMsgAmt);
						insertMsgReady.setInt(19,Integer.parseInt(billRnd));
						
						insertMsgReady.addBatch();
						msgReadyBatchCounter++;
						
						if (msgReadyBatchCounter % 1000 == 0) {
							insertMsgReady.executeBatch();
						}
						isMsgReady = true;
						
					} else if ("19".equals(ruleNo)) {				//Insert to RABC_ICBS_INVOICE_DERIVED table
						insertInvoiceDerived.setDate(1, sqlRunDate);
						insertInvoiceDerived.setString(2, division);	
						insertInvoiceDerived.setString(3, entityCode);
						if ("ADJUSTMENTS".equalsIgnoreCase(trnType) || "ADJUSTMENT".equalsIgnoreCase(trnType)) {
							insertInvoiceDerived.setString(4, "ADJ");
						} else if ("TOLL REVENUE".equalsIgnoreCase(trnType)) {
							insertInvoiceDerived.setString(4, "TOLL");
						}
						insertInvoiceDerived.setLong(5, dailyInputMsgCnt);
						insertInvoiceDerived.setDouble(6, dailyInputMsgAmt);
						insertInvoiceDerived.setLong(7, returnedMsgCnt);
						insertInvoiceDerived.setDouble(8, returnedMsgAmt);
						insertInvoiceDerived.setLong(9, billedMsgCnt);
						insertInvoiceDerived.setDouble(10, billedMsgAmt);
						insertInvoiceDerived.setLong(11, crudeOutMsgCnt);
						insertInvoiceDerived.setDouble(12, crudeOutMsgAmt);
						insertInvoiceDerived.setLong(13, inputMsgCnt);
						insertInvoiceDerived.setLong(14, processedMsgCnt);
						insertInvoiceDerived.setDouble(15, inputMsgAmt);
						insertInvoiceDerived.setDouble(16, processedMsgAmt);
						insertInvoiceDerived.setInt(17,Integer.parseInt(billRnd));
						
						insertInvoiceDerived.addBatch();
						invoiceDerivedBatchCounter++;
						
						if (invoiceDerivedBatchCounter % 1000 == 0) {
							insertInvoiceDerived.executeBatch();
						}
						isInvoiceDerived = true;
					}
				}
			}
		}
		
		return success;
	}
		
	/**
	 * Private method to process the records for the rule 'RA12ERCD'.
	 * It does the following steps:
	 * 	1) Retrieves the fields from the line.
	 * 	2) Does conversion of data from String to appropriate data types as well as interpretation for amount.
	 * 	3) Creates the objects of ICBSReturn type.
	 * 	4) Populates the hash map with those objects.
	 * 
	 * @param line
	 * @return boolean
	 * @throws Exception
	 */
	private boolean processReturn(String line) throws Exception {
		boolean success = false;
		
		String [] lineFields = line.split(fieldSeperator);
		
		if (lineFields.length == 7) {
			String recordType		= lineFields[0].trim();
			String seqNumber		= lineFields[1].trim();
			String entityCode		= getEntityCode(lineFields[2].trim());
			String recordId			= lineFields[3].trim();
			String returnCode		= lineFields[4].trim();
			String totalMsgCnt		= lineFields[5].trim();
			String totalMsgAmt		= lineFields[6].trim();
			
			if (!"".equals(entityCode)) {
				success = true;
				
				/*
				 * Format the count & amount values
				 */
				long totalCount				= Long.parseLong(totalMsgCnt.substring(0,totalMsgCnt.length()-6));
				String amountUnitPart		= totalMsgAmt.substring(0,totalMsgAmt.length()-8);
				String amountDecimalPart 	= totalMsgAmt.substring(amountUnitPart.length(),totalMsgAmt.length());
				String actualAmount			= amountUnitPart + "." + amountDecimalPart;
				double totalAmount			= Double.parseDouble(actualAmount);
				
				/*
				 * Get the Return Code
				 */
				String rtnCd = null;
				if (returnCode.length() > 4) {
					rtnCd = returnCode.substring(0,4);
				} else {
					rtnCd = returnCode;
				}
				
				/*
				 * Get the Data File
				 */
				String dataFile	= null;
				if ("RA12ERCD".equals(recordType)){
					if ("02".equals(seqNumber) || "03".equals(seqNumber)) {
						dataFile = "IBIXC";
					} else if ("04".equals(seqNumber) || "05".equals(seqNumber)) {
						dataFile = "IBADJ";
					}
				} else if (recordType.indexOf("RA12IC")!= -1) {
					dataFile = "ICIXC";
				} else if (recordType.indexOf("RA12IR")!= -1) {
					dataFile = "IRIXC";
					rtnCd 	 = "ATT";
				}
								
				/*
				 * Create an object of ICBSReturn type
				 */
				ICBSReturn icbsReturn = new ICBSReturn();
				icbsReturn.setRunDate(utilRunDate);
				icbsReturn.setDivision(division);
				icbsReturn.setEntityCd(entityCode);
				icbsReturn.setDataFile(dataFile);
				icbsReturn.setRtnCd(rtnCd);
		
				/*
				 * Check whether the above object is present in the hash map
				 */
				ICBSReturn icbsObjRef = null;
				icbsObjRef = (ICBSReturn) icbsReturnMap.get(icbsReturn);
				
				if (icbsObjRef != null){
					long newRtnCnt;		
					double newRtnAmt;	
					
					if (totalAmount < 0){
						newRtnCnt = icbsObjRef.getTotRtnCntCr() + totalCount;
						newRtnAmt = icbsObjRef.getTotRtnAmtCr() + totalAmount;
						icbsObjRef.setTotRtnCntCr(newRtnCnt);
						icbsObjRef.setTotRtnAmtCr(newRtnAmt);
					} else {
						newRtnCnt = icbsObjRef.getTotRtnCntDb() + totalCount;
						newRtnAmt = icbsObjRef.getTotRtnAmtDb() + totalAmount;
						icbsObjRef.setTotRtnCntDb(newRtnCnt);
						icbsObjRef.setTotRtnAmtDb(newRtnAmt);
					}
					icbsReturnMap.put(icbsObjRef,icbsObjRef);
				} else {
					if (totalAmount < 0){
						icbsReturn.setTotRtnCntCr(totalCount);
						icbsReturn.setTotRtnAmtCr(totalAmount);
					} else {
						icbsReturn.setTotRtnCntDb(totalCount);
						icbsReturn.setTotRtnAmtDb(totalAmount);
					}
					icbsReturnMap.put(icbsReturn,icbsReturn);
				}
			}
		}
		
		return success;
	}
	
	/**
	 * Private method to return the entity code  to be inserted into the table.
	 * 
	 * @param entityCd
	 * @return String
	 */
	private String getEntityCode(String entityCd) {
		String entityCode = entityCd;
		
		if (entityCd.length() > 5) {
			entityCode = entityCd.substring(3, entityCd.length()-3);
			if (entityCode.length() > 8) {
				entityCode = entityCode.substring(0, 8);
			}
		}
		
		return entityCode;
	}
		
	/**
	 * Overriding postProcessFile(file, success) method.
	 * It is executed post to processing the file to be loaded.
	 * It includes the following steps:
	 * 	1) It checks whether the header and trailer records exists and 
	 * 	   whether the total number of records (excluding header and trailer records)
	 * 	   in the file is eqaul to the count in the trailer record.
	 * 	   If it is then prcoceeds to next step else return false.
	 * 	2) Executes the last batches of the prepared statements 
	 * 	   insertInvoiceReady, insertMsgReady and insertInvoiceDerived.
	 * 	3) Loop through the map icbsReturnMap and insert entries into RABC_ICBS_RETURN table.
	 * 	4) Makes the entries into RABC_TRIG table.
	 * 
	 * @see com.sbc.bac.load.FileDBLoadJob#postprocessFile(java.io.File, boolean)
	 */
	public boolean postprocessFile(File file, boolean success) {
		
		try{
			//Log the file information to EMCIS_EVENT_LOG and EMCIS_EVENT_LOG_DETAIL
			EmcisEventLogger emcisLogger = new EmcisEventLogger();
			String event_id = "RABC_"+fileToken+"_"+region;
            String host = NetUtil.getLocalHostName();
            String hostIP = NetUtil.getLocalIpAddress();
			int sequence = emcisLogger.getEMCISSequence(connection);
			emcisLogger.insertEventLog(connection, sequence, event_id, sqlRunDate, host, hostIP);
			emcisLogger.insertEventLogDetail(connection, sequence, "FileName", fileName);
		}catch (UnknownHostException e) {
            severe("Error getting EMCIS host information ", e);
        }	
		if (success) {
			if (!isTrailerExists) {
				severe("Trailer record is not present in the file.");
				success = false;
			} else if (!isRecordCountMatches) {
				severe("Total number of records in the file is not eqaul to the count in the trailer record.");
				success = false;
			} else {
				try {
					//insertInvoiceReady.executeBatch();
					insertMsgReady.executeBatch();
					insertInvoiceDerived.executeBatch();
					
					/*
					 * Iterate through the entire hash map and insert entries into the RABC_ICBS_INVOICE_READY table
					 */
					Iterator icbsDataIterator = icbsDataMap.keySet().iterator();
					
					while (icbsDataIterator.hasNext()){
						invoiceReadyBatchCounter++;
						
						ICBSData icbsData = (ICBSData)icbsDataIterator.next();
						insertInvoiceReady.setDate(1,sqlRunDate);
						insertInvoiceReady.setString(2,division);	
						insertInvoiceReady.setString(3,icbsData.getEntityCd());
						insertInvoiceReady.setString(4,icbsData.getTrnType());
						insertInvoiceReady.setLong(5,icbsData.getDailyInputMsgCt());
						insertInvoiceReady.setDouble(6,icbsData.getDailyInputMsgAmt());
						insertInvoiceReady.setLong(7,icbsData.getEmsErrMsgCt());
						insertInvoiceReady.setDouble(8,icbsData.getEmsErrMsgAmt());
						insertInvoiceReady.setLong(9,icbsData.getRtnMsgCt());
						insertInvoiceReady.setDouble(10,icbsData.getRtnMsgAmt());
						insertInvoiceReady.setLong(11,icbsData.getBlgMsgCt());
						insertInvoiceReady.setDouble(12,icbsData.getBlgMsgAmt());
//						insertInvoiceReady.setLong(13,icbsData.getCrudeOutMsgCt());
//						insertInvoiceReady.setDouble(14,icbsData.getCrudeOutMsgAmt());
//						insertInvoiceReady.setLong(15,icbsData.getTotalInputMsgCt());
//						insertInvoiceReady.setDouble(17,icbsData.getTotalInputMsgAmt());
//						insertInvoiceReady.setLong(16,icbsData.getTotalPostedMsgCt());
//						insertInvoiceReady.setDouble(18,icbsData.getTotalPostedMsgAmt());
//						insertInvoiceReady.setInt(19,Integer.parseInt(billRnd));
						insertInvoiceReady.setLong(13,icbsData.getTotalInputMsgCt());
						insertInvoiceReady.setLong(14,icbsData.getTotalPostedMsgCt());						
						insertInvoiceReady.setDouble(15,icbsData.getTotalInputMsgAmt());
						insertInvoiceReady.setDouble(16,icbsData.getTotalPostedMsgAmt());
						insertInvoiceReady.setInt(17,Integer.parseInt(billRnd));
						
						insertInvoiceReady.setLong(18,icbsData.getMasMsgCt());
						insertInvoiceReady.setDouble(19,icbsData.getMasMsgAmt());
						insertInvoiceReady.setLong(20,icbsData.getReentMsgCt());
						insertInvoiceReady.setDouble(21,icbsData.getReentMsgAmt());						
						insertInvoiceReady.setLong(22,icbsData.getBegMsgCt());
						insertInvoiceReady.setDouble(23,icbsData.getBegMsgAmt());
						insertInvoiceReady.setLong(24,icbsData.getEmsMsgCt());
						insertInvoiceReady.setDouble(25,icbsData.getEmsMsgAmt());
						insertInvoiceReady.addBatch();
						
						if (invoiceReadyBatchCounter % 1000 == 0){
							insertInvoiceReady.executeBatch();
						}
						isInvoiceReady = true;
					}
					
					/*
					 * Execute the last batch
					 */
					insertInvoiceReady.executeBatch();
				
					
					/*
					 * Iterate through the entire hash map and insert entries into the RABC_ICBS_RETURN table
					 */
					Set icbsReturnSet			= icbsReturnMap.keySet();
					Iterator icbsReturnIterator = icbsReturnSet.iterator();
					
					while (icbsReturnIterator.hasNext()){
						returnBatchCounter++;
						
						ICBSReturn icbsReturn = (ICBSReturn)icbsReturnIterator.next();
						insertReturn.setDate(1, sqlRunDate);
						insertReturn.setString(2, division);
						insertReturn.setString(3, icbsReturn.getEntityCd());
						insertReturn.setString(4, icbsReturn.getDataFile());
						insertReturn.setString(5, icbsReturn.getRtnCd());
						insertReturn.setLong(6, icbsReturn.getTotRtnCntDb());
						insertReturn.setDouble(7, icbsReturn.getTotRtnAmtDb());
						insertReturn.setLong(8, icbsReturn.getTotRtnCntCr());
						insertReturn.setDouble(9, icbsReturn.getTotRtnAmtCr());
						insertReturn.addBatch();
						if (returnBatchCounter % 1000 == 0){
							insertReturn.executeBatch();
						}
						isReturn = true;
					}
					
					/*
					 * Execute the last batch of insertReturn
					 */
					insertReturn.executeBatch();
					
					/*
					 * Call the private method to make the entries into RABC_TRIG table
					 */
					if (!insertTrigger()) {
						success = false;
					}	
					
					
					
				} catch (SQLException sqle){
					severe(StaticErrorMsgKeys.INSERT_ERROR + sqle.getMessage(), sqle);
					success = false;
				}
			}
		}
		
		return super.postprocessFile(file, success);
	}
	
	/**
	 * Private method to insert entry into RABC_TRIG table.
	 * 
	 * @return boolean
	 */
	private boolean insertTrigger() {
		try {
			String cycleDate = MMDDYYYY_FORMAT.format(MMDDYY_FORMAT.parse(runDate));
			
			/*
			 * Check whether there were any invoice ready records inserted, if yes then insert into trigger
			 */
			if (isInvoiceReady) {
				if(!RabcLoadJobTrig.insertTrigger(connection, currentFile.getName().substring(5,currentFile.getName().length()), currentFile.getName(), INVOICE_READY_FILE_ID, division, cycleDate , backoutRecovery, billRnd, RABC_TRIG)){
					return false;	
				}
			}
			
			/*
			 * Check whether there were any message ready records inserted, if yes then insert into trigger
			 */
			if (isMsgReady) {
				if(!RabcLoadJobTrig.insertTrigger(connection, currentFile.getName().substring(5,currentFile.getName().length()), currentFile.getName(), MSG_READY_FILE_ID, division, cycleDate , backoutRecovery, billRnd, RABC_TRIG)){
					return false;	
				}
			}
			
			/*
			 * Check whether there were any invoice derived records inserted, if yes then insert into trigger
			 */
			if (isInvoiceDerived) {
				if(!RabcLoadJobTrig.insertTrigger(connection, currentFile.getName().substring(5,currentFile.getName().length()), currentFile.getName(), INVOICE_DERIVED_FILE_ID, division, cycleDate , backoutRecovery, billRnd, RABC_TRIG)){
					return false;	
				}
			}
			
			/*
			 * Check whether there were any return records inserted, if yes then insert into trigger
			 */
			if (isReturn) {
				if(!RabcLoadJobTrig.insertTrigger(connection, currentFile.getName().substring(5,currentFile.getName().length()), currentFile.getName(), RETURN_FILE_ID, division, cycleDate , backoutRecovery, billRnd, RABC_TRIG)) {
					return false;	
				}
			}
		} catch (Exception e) {
			severe(StaticErrorMsgKeys.POSTPROCESSFILE_ERROR + StaticErrorMsgKeys.TIGGER_TABLE_INSERT_ERROR + e.getMessage(), e);
			return false;
		}
		
		return true;
	}

	/**
	 * Overriding postProcess(success) method.
	 * It is executed post to processing the load job.
	 * It includes the following steps:
	 * 	1) Closes statements that were opened for this load job.
	 * 
	 * @see com.sbc.bac.load.LoadJob#postprocess(boolean)
	 */
	public boolean postprocess(boolean success) {
		try {
			insertInvoiceReady.close();
			insertMsgReady.close();
			insertMsgReady.close();
			insertReturn.close();
		} catch (SQLException e) {
			severe(StaticErrorMsgKeys.POSTPROCESS_ERROR + StaticErrorMsgKeys.SQL_CLOSE_ERROR + e.getMessage(), e);
			success = false;
		}

		return super.postprocess(success);
	}
	
	public double convertValue(String input){
		String tempInput = input.substring(1,input.length()).replaceAll(",","");
		
		if (tempInput.indexOf("CR")==-1 && tempInput.indexOf("cr")==-1){
			return Double.parseDouble(tempInput);
		} else {
			return -(Double.parseDouble(tempInput.substring(0,tempInput.length()-2)));
		}
	}		
}
