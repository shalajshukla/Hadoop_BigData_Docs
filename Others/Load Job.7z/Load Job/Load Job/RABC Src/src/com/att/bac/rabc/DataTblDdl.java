/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc;

/**
 * This is a Data Object to represent RABC_DATA_TBL_DDL table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class DataTblDdl {
	private String alertProcTbl;
	private String tblProcDateDdlName;
	private String tblBillRndDdlName;
	private int tblDdlKeyLvl;
	private String tblDdlKey1Name;
	private String tblDdlKey2Name;
	private String tblDdlKey3Name;
	private String tblDdlKey4Name;
	private String tblDdlKey5Name;
	private String tblDdlName;
	private String tblBillRndDdlMon;
	private String tblBillRndDdlYear;
	private String tblDdlDataType;
	private String tblSubsysId;
	private String tblFileSeqNumDdlName;
	private String tblDdlPrescsnFormatType;
	private String tblDdlNameDesc;

	/**
	 * @return Returns the AlertProcTbl.
	 */
	public String getAlertProcTbl() {
		return alertProcTbl;
	}
	/**
	 * @return Returns the TblProcDateDdlName.
	 */
	public String getTblProcDateDdlName() {
		return tblProcDateDdlName;
	}
	/**
	 * @return Returns the TblBillRndDdlName.
	 */
	public String getTblBillRndDdlName() {
		return tblBillRndDdlName;
	}
	/**
	 * @return Returns the TblDdlKeyLvl.
	 */
	public int getTblDdlKeyLvl() {
		return tblDdlKeyLvl;
	}
	/**
	 * @return Returns the TblDdlKey1Name.
	 */
	public String getTblDdlKey1Name() {
		return tblDdlKey1Name;
	}
	/**
	 * @return Returns the TblDdlKey2Name.
	 */
	public String getTblDdlKey2Name() {
		return tblDdlKey2Name;
	}
	/**
	 * @return Returns the TblDdlKey3Name.
	 */
	public String getTblDdlKey3Name() {
		return tblDdlKey3Name;
	}
	/**
	 * @return Returns the TblDdlKey4Name.
	 */
	public String getTblDdlKey4Name() {
		return tblDdlKey4Name;
	}
	/**
	 * @return Returns the TblDdlKey5Name.
	 */
	public String getTblDdlKey5Name() {
		return tblDdlKey5Name;
	}
	/**
	 * @return Returns the TblDdlName.
	 */
	public String getTblDdlName() {
		return tblDdlName;
	}
	/**
	 * @return Returns the TblBillRndDdlMon.
	 */
	public String getTblBillRndDdlMon() {
		return tblBillRndDdlMon;
	}
	/**
	 * @return Returns the TblBillRndDdlYear.
	 */
	public String getTblBillRndDdlYear() {
		return tblBillRndDdlYear;
	}
	/**
	 * @return Returns the TblDdlDataType.
	 */
	public String getTblDdlDataType() {
		return tblDdlDataType;
	}
	/**
	 * @return Returns the TblSubsysId.
	 */
	public String getTblSubsysId() {
		return tblSubsysId;
	}
	/**
	 * @return Returns the TblFileSeqNumDdlName.
	 */
	public String getTblFileSeqNumDdlName() {
		return tblFileSeqNumDdlName;
	}
	/**
	 * @return Returns the TblDdlPrescsnFormatType.
	 */
	public String getTblDdlPrescsnFormatType() {
		return tblDdlPrescsnFormatType;
	}

	/**
	 * @param AlertProcTbl The alertProcTbl to set.
	 */
	public void setAlertProcTbl(String alertProcTbl) {
		this.alertProcTbl = alertProcTbl;
	}
	/**
	 * @param TblProcDateDdlName The tblProcDateDdlName to set.
	 */
	public void setTblProcDateDdlName(String tblProcDateDdlName) {
		this.tblProcDateDdlName = tblProcDateDdlName;
	}
	/**
	 * @param TblBillRndDdlName The tblBillRndDdlName to set.
	 */
	public void setTblBillRndDdlName(String tblBillRndDdlName) {
		this.tblBillRndDdlName = tblBillRndDdlName;
	}
	/**
	 * @param TblDdlKeyLvl The tblDdlKeyLvl to set.
	 */
	public void setTblDdlKeyLvl(int tblDdlKeyLvl) {
		this.tblDdlKeyLvl = tblDdlKeyLvl;
	}
	/**
	 * @param TblDdlKey1Name The tblDdlKey1Name to set.
	 */
	public void setTblDdlKey1Name(String tblDdlKey1Name) {
		this.tblDdlKey1Name = tblDdlKey1Name;
	}
	/**
	 * @param TblDdlKey2Name The tblDdlKey2Name to set.
	 */
	public void setTblDdlKey2Name(String tblDdlKey2Name) {
		this.tblDdlKey2Name = tblDdlKey2Name;
	}
	/**
	 * @param TblDdlKey3Name The tblDdlKey3Name to set.
	 */
	public void setTblDdlKey3Name(String tblDdlKey3Name) {
		this.tblDdlKey3Name = tblDdlKey3Name;
	}
	/**
	 * @param TblDdlKey4Name The tblDdlKey4Name to set.
	 */
	public void setTblDdlKey4Name(String tblDdlKey4Name) {
		this.tblDdlKey4Name = tblDdlKey4Name;
	}
	/**
	 * @param TblDdlKey5Name The tblDdlKey5Name to set.
	 */
	public void setTblDdlKey5Name(String tblDdlKey5Name) {
		this.tblDdlKey5Name = tblDdlKey5Name;
	}
	/**
	 * @param TblDdlName The tblDdlName to set.
	 */
	public void setTblDdlName(String tblDdlName) {
		this.tblDdlName = tblDdlName;
	}
	/**
	 * @param TblBillRndDdlMon The tblBillRndDdlMon to set.
	 */
	public void setTblBillRndDdlMon(String tblBillRndDdlMon) {
		this.tblBillRndDdlMon = tblBillRndDdlMon;
	}
	/**
	 * @param TblBillRndDdlYear The tblBillRndDdlYear to set.
	 */
	public void setTblBillRndDdlYear(String tblBillRndDdlYear) {
		this.tblBillRndDdlYear = tblBillRndDdlYear;
	}
	/**
	 * @param TblDdlDataType The tblDdlDataType to set.
	 */
	public void setTblDdlDataType(String tblDdlDataType) {
		this.tblDdlDataType = tblDdlDataType;
	}
	/**
	 * @param TblSubsysId The tblSubsysId to set.
	 */
	public void setTblSubsysId(String tblSubsysId) {
		this.tblSubsysId = tblSubsysId;
	}
	/**
	 * @param TblFileSeqNumDdlName The tblFileSeqNumDdlName to set.
	 */
	public void setTblFileSeqNumDdlName(String tblFileSeqNumDdlName) {
		this.tblFileSeqNumDdlName = tblFileSeqNumDdlName;
	}
	/**
	 * @param TblDdlPrescsnFormatType The tblDdlPrescsnFormatType to set.
	 */
	public void setTblDdlPrescsnFormatType(String tblDdlPrescsnFormatType) {
		this.tblDdlPrescsnFormatType = tblDdlPrescsnFormatType;
	}
	/**
	 * @return Returns the tblDdlNameDesc.
	 */
	public String getTblDdlNameDesc() {
		return tblDdlNameDesc;
	}
	/**
	 * @param tblDdlNameDesc The tblDdlNameDesc to set.
	 */
	public void setTblDdlNameDesc(String tblDdlNameDesc) {
		this.tblDdlNameDesc = tblDdlNameDesc;
	}
}
