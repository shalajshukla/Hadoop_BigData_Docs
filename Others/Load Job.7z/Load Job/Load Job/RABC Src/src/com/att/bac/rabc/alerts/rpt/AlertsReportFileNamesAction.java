/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.rpt;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.att.bac.rabc.ConnectionManager;
import com.att.bac.rabc.ExcelReport;
import com.att.bac.rabc.ProgressBar;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;
import com.att.carat.util.email.EmailFactory;

/**
 * This is an action class that handles the
 * various action requested for page 15 (alert report request).
 * 
 * @author Nalina Pandiyan - NP5434
 */
public class AlertsReportFileNamesAction extends DispatchAction{
	
	private static final Logger logger = Logger.getLogger(AlertsReportFileNamesAction.class);
	
	/**
	 * This is a default dispatch action method to handel the request for the AlertReportFileNamesAction.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @see org.apache.struts.actions.DispatchAction#unspecified(org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public ActionForward unspecified(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		List failures = new ArrayList();
		Connection connection = null;
		String page = "error";
		String userId = (String)((HttpSession)request.getSession()).getAttribute("bacUserID");
		
		try{
			AlertsReportFileNamesForm alertsReportFileNamesForm = (AlertsReportFileNamesForm) form;
			connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
			progressBar.setProgressPercent(10);
			if(request.getMethod().equals("GET")){
				if(request.getParameter("partiRefId")!=null){
					alertsReportFileNamesForm.setPartiRefId(new Integer(request.getParameter("partiRefId")));
				}
				if(request.getParameter("fileSeqNum")!=null){
					alertsReportFileNamesForm.setFileSeqNum(new Integer(request.getParameter("fileSeqNum")));
				}
				if(request.getParameter("procDate")!=null){
					alertsReportFileNamesForm.setProcDate(request.getParameter("procDate"));
				}
				if(request.getParameter("divisionName")!=null){
					alertsReportFileNamesForm.setDivisionName(request.getParameter("divisionName"));
				}
				if(request.getParameter("fileDIV")!=null){
					alertsReportFileNamesForm.setFileDIV(request.getParameter("fileDIV"));
				}else{
					alertsReportFileNamesForm.setFileDIV(request.getParameter("divisionName"));
				}
			}
			progressBar.setProgressPercent(20);
			List fileNamesList = processRequest(connection, failures, alertsReportFileNamesForm, progressBar);
			
			if (failures.isEmpty()) {
				int defaultLineCount = AlertsReportService.getAlertsReportService().getDefaultLineCount(connection, failures, userId);
				progressBar.setProgressPercent(80);
				processViewSize(fileNamesList, alertsReportFileNamesForm, 1, defaultLineCount);
				progressBar.setProgressPercent(90);
				page = "AlertsRptFileNames";
			}
		}catch(SQLException sx){
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failures.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failures, logger);
		}
		progressBar.setProgressPercent(100);
		
		if (!failures.isEmpty()) {
			request.setAttribute("failures", failures);
		}
		
		return mapping.findForward(page);
	}
	
	/**
	 * This is an action method to handel the request for generating the excel report of AlertReportFileNamesAction. 
	 * It executes click on Create Report button.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward createReport(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		List failures = new ArrayList();
		Connection connection = null;
		String page = "error";
		
		try{
			AlertsReportFileNamesForm alertsReportFileNamesForm = (AlertsReportFileNamesForm) form;
			connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
			progressBar.setProgressPercent(10);
			AlertsReportFileNamesService alertsReportFileNamesService = new AlertsReportFileNamesService();
			
			/*Prepare arguments List from form*/
			List args = new ArrayList();
			args.add(alertsReportFileNamesForm.getPartiRefId());
			args.add(alertsReportFileNamesForm.getFileSeqNum());
			args.add(alertsReportFileNamesForm.getProcDate());
			args.add(alertsReportFileNamesForm.getDivisionName());
			args.add(alertsReportFileNamesForm.getFileDIV());
			progressBar.setProgressPercent(20);
			
			String reportName = (String)request.getSession().getAttribute("bacUserID")+"page_15.xls" ;
			File file[]  = new File[1];
			file[0] = new File(reportName);
			OutputStream fos = new FileOutputStream(file[0]);
			ExcelReport report = new  ExcelReport(fos);
			progressBar.setProgressPercent(30);

			List fileNamesList = alertsReportFileNamesService.processCreateReportRequest(connection,failures,args, report, progressBar);
			if (!failures.isEmpty()){
				request.setAttribute("failures", failures);
				progressBar.setProgressPercent(100);
				return mapping.findForward("error");
			}			
			fos.close();
			InputStream fis = new FileInputStream(reportName);

			ServletOutputStream out = response.getOutputStream();
			response.setContentType("application/msexcel");
			response.setHeader("Content-Disposition","attachment; filename=ExcelReport.xls");
			progressBar.setProgressPercent(90);

			byte[] buf = new byte[1024];
			int len;
			while ((len = fis.read(buf)) > 0) {
				out.write(buf, 0, len);
			}
			fis.close();
			file[0].delete();
			page = "AlertsRptFileNames";
		}catch(SQLException sx){
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		}catch(IOException ioe) {
			logger.error(RABCMessages.getMessage("ERR_IO_EXEC", new String[] {"IO Exception while e mailing Page 15 report. "}) + " Exception details: " + ioe.getMessage(), ioe);
            failures.add(new RABCException(RABCMessages.getMessage("ERR_IO_EXEC", new String[] {"IO Exception while e mailing Page 15 report."}), ioe));
		}catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failures.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failures, logger);
		}
		progressBar.setProgressPercent(100);
		
		if (!failures.isEmpty()) {
			request.setAttribute("failures", failures);
		}
		
		return mapping.findForward(page);
	}

	/**
	 * Method to execute click on Email Report button.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward emailReport(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		List failures = new ArrayList();
		Connection connection = null;
		String page = "error";
		
		try{
			AlertsReportFileNamesForm alertsReportFileNamesForm = (AlertsReportFileNamesForm) form;
			connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
			progressBar.setProgressPercent(10);
			AlertsReportFileNamesService alertsReportFileNamesService = new AlertsReportFileNamesService();
			
			/*Prepare arguments List from form*/
			List args = new ArrayList();
			args.add(alertsReportFileNamesForm.getPartiRefId());
			args.add(alertsReportFileNamesForm.getFileSeqNum());
			args.add(alertsReportFileNamesForm.getProcDate());
			args.add(alertsReportFileNamesForm.getDivisionName());
			args.add(alertsReportFileNamesForm.getFileDIV());
			progressBar.setProgressPercent(20);
			
			String reportName = (String)request.getSession().getAttribute("bacUserID")+"page_15.xls" ;
			File file[]  = new File[1];
			file[0] = new File(reportName);
			FileOutputStream fos = new FileOutputStream(file[0]);
			ExcelReport report = new  ExcelReport(fos);
			progressBar.setProgressPercent(30);

			List fileNamesList = alertsReportFileNamesService.processCreateReportRequest(connection,failures,args, report, progressBar);
			if (!failures.isEmpty()){
				request.setAttribute("failures", failures);
				progressBar.setProgressPercent(100);
				return mapping.findForward("error");
			}			
			String emailRecipients = alertsReportFileNamesForm.getEmailRecipients();
			String [] emailRecipientsArray = emailRecipients.split(",");
			int totalEmailRecipients = emailRecipientsArray.length;
			int counter = 0;
			//String toAddress = alertsReportFileNamesForm.getEmailRecipients().replace(',',';');
			// pb3879 added to create correct subject line.  Added to second arguement for email.
            Context initContext = new InitialContext();
            String spServer = initContext.lookup("java:/comp/env/saved_report_server").toString();
            String fromEnvironment = initContext.lookup("java:/comp/env/application_env").toString();
			
            for(counter = 0; counter < totalEmailRecipients; counter++  ) {
            	boolean s =	EmailFactory.sendEmail(emailRecipientsArray[counter]+"@att.com", "RABC (" + fromEnvironment + " - " + spServer + ") - List of filenames based on sequence number", "Please Refer to file attached for details.", false, file);
			}
			//boolean s = EmailFactory.sendEmail( toAddress, "RABC (" + fromEnvironment + " - " + spServer + ") - List of filenames based on sequence number", "Please Refer to file attached for details.", false, file);
			//boolean s = Email.sendEmail( toAddress,"RABC - List of filenames based on sequence number", "Please Refer to file attached for details.", false, file);
			
			progressBar.setProgressPercent(90);
			
			file[0].delete();

			int size= fileNamesList.size();
			
			for(int i=0;i<size;i++){
				FileNames fileNames = (FileNames) fileNamesList.get(i);
				String rowClr="white";
				if (i%2 == 0) {
					rowClr="#cee6fd";
				}else{
					rowClr="#ffffff";
				}
				fileNames.setRowClr(rowClr);
				alertsReportFileNamesForm.addFileNamesList(fileNames);
			}
			
			page = "AlertsRptFileNames";
		} catch(SQLException sx){
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch(IOException ioe) {
			logger.error(RABCMessages.getMessage("ERR_IO_EXEC", new String[] {"IO Exception while creating Page 15 report. "}) + " Exception details: " + ioe.getMessage(), ioe);
            failures.add(new RABCException(RABCMessages.getMessage("ERR_IO_EXEC", new String[] {"IO Exception while creating Page 15 report."}), ioe));
		} catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failures.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failures, logger);
		}
		progressBar.setProgressPercent(100);
		
		if (!failures.isEmpty()) {
			request.setAttribute("failures", failures);
		}
		
		return mapping.findForward(page);
	}
	
	/**
	 * This is an action method to handel the request for first page of AlertReportFileNamesAction.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward first(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		List failures = new ArrayList();
		Connection connection = null;
		String page = "error";
		String userId = (String)((HttpSession)request.getSession()).getAttribute("bacUserID");
		try{
			AlertsReportFileNamesForm alertsReportFileNamesForm = (AlertsReportFileNamesForm) form;
			connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
			progressBar.setProgressPercent(20);
			List fileNamesList = processRequest(connection, failures, alertsReportFileNamesForm, progressBar);
			
			if (failures.isEmpty()) {
				int defaultLineCount = AlertsReportService.getAlertsReportService().getDefaultLineCount(connection, failures, userId);
				progressBar.setProgressPercent(80);
				processViewSize(fileNamesList, alertsReportFileNamesForm, 1, defaultLineCount);
				progressBar.setProgressPercent(90);
				page = "AlertsRptFileNames";
			}
		}catch(SQLException sx){
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		}catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failures.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failures, logger);
		}
		progressBar.setProgressPercent(100);
		
		if (!failures.isEmpty()) {
			request.setAttribute("failures", failures);
		}
		
		return mapping.findForward(page);
	}

	/**
	 * This is an action method to handel the request for previous page of AlertReportFileNamesAction.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward previous(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		List failures = new ArrayList();
		Connection connection = null;
		String page = "error";
		String userId = (String)((HttpSession)request.getSession()).getAttribute("bacUserID");
		try{
			AlertsReportFileNamesForm alertsReportFileNamesForm = (AlertsReportFileNamesForm) form;
			connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
			progressBar.setProgressPercent(20);
			List fileNamesList = processRequest(connection, failures, alertsReportFileNamesForm, progressBar);
			
			if (failures.isEmpty()) {
				int defaultLineCount = AlertsReportService.getAlertsReportService().getDefaultLineCount(connection, failures, userId);
				progressBar.setProgressPercent(80);
				processViewSize(fileNamesList, alertsReportFileNamesForm, alertsReportFileNamesForm.getPage() - 1, defaultLineCount);
				progressBar.setProgressPercent(90);
				page = "AlertsRptFileNames";
			}
		}catch(SQLException sx){
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		}catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failures.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failures, logger);
		}
		progressBar.setProgressPercent(100);
		
		if (!failures.isEmpty()) {
			request.setAttribute("failures", failures);
		}
		
		return mapping.findForward(page);
	}

	/**
	 * This is an action method to handel the request for next page of AlertReportFileNamesAction.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward next(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		List failures = new ArrayList();
		Connection connection = null;
		String page = "error";
		String userId = (String)((HttpSession)request.getSession()).getAttribute("bacUserID");
		try{
			AlertsReportFileNamesForm alertsReportFileNamesForm = (AlertsReportFileNamesForm) form;
			connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
			progressBar.setProgressPercent(20);
			List fileNamesList = processRequest(connection, failures, alertsReportFileNamesForm, progressBar);
			
			if (failures.isEmpty()) {
				int defaultLineCount = AlertsReportService.getAlertsReportService().getDefaultLineCount(connection, failures, userId);
				progressBar.setProgressPercent(80);
				processViewSize(fileNamesList, alertsReportFileNamesForm, alertsReportFileNamesForm.getPage() + 1, defaultLineCount);
				progressBar.setProgressPercent(90);
				page = "AlertsRptFileNames";
			}
		}catch(SQLException sx){
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		}catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failures.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failures, logger);
		}
		progressBar.setProgressPercent(100);
		
		if (!failures.isEmpty()) {
			request.setAttribute("failures", failures);
		}
		
		return mapping.findForward(page);
	}

	/**
	 * This is an action method to handel the request for last page of AlertReportFileNamesAction.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward last(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		List failures = new ArrayList();
		Connection connection = null;
		String page = "error";
		String userId = (String)((HttpSession)request.getSession()).getAttribute("bacUserID");
		try{
			AlertsReportFileNamesForm alertsReportFileNamesForm = (AlertsReportFileNamesForm) form;
			connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
			progressBar.setProgressPercent(20);
			List fileNamesList = processRequest(connection, failures, alertsReportFileNamesForm, progressBar);
			
			if (failures.isEmpty()) {
				int defaultLineCount = AlertsReportService.getAlertsReportService().getDefaultLineCount(connection, failures, userId);
				progressBar.setProgressPercent(80);
				processViewSize(fileNamesList, alertsReportFileNamesForm, alertsReportFileNamesForm.getPages(), defaultLineCount);
				progressBar.setProgressPercent(90);
				page = "AlertsRptFileNames";
			}
		}catch(SQLException sx){
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		}catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failures.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failures, logger);
		}
		progressBar.setProgressPercent(100);
		
		if (!failures.isEmpty()) {
			request.setAttribute("failures", failures);
		}
		
		return mapping.findForward(page);
	}

	/**
	 * This is an action method to handel the request for specific page of AlertReportFileNamesAction.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward pagelist(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		List failures = new ArrayList();
		Connection connection = null;
		String page = "error";
		String userId = (String)((HttpSession)request.getSession()).getAttribute("bacUserID");
		try{
			AlertsReportFileNamesForm alertsReportFileNamesForm = (AlertsReportFileNamesForm) form;
			connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
			progressBar.setProgressPercent(20);
			List fileNamesList = processRequest(connection, failures, alertsReportFileNamesForm, progressBar);
			
			if (failures.isEmpty()) {
				int defaultLineCount = AlertsReportService.getAlertsReportService().getDefaultLineCount(connection, failures, userId);
				progressBar.setProgressPercent(80);
				processViewSize(fileNamesList, alertsReportFileNamesForm, alertsReportFileNamesForm.getPageshow(), defaultLineCount);
				progressBar.setProgressPercent(90);
				page = "AlertsRptFileNames";
			}
		}catch(SQLException sx){
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failures.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failures, logger);
		}
		progressBar.setProgressPercent(100);
		
		if (!failures.isEmpty()) {
			request.setAttribute("failures", failures);
		}
		
		return mapping.findForward(page);
	}

	/**
	 * This is an action method to process the request.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertsReportFileNamesForm
	 * @param progressBar
	 * @return List
	 */
	private List processRequest(Connection connection, List failures, AlertsReportFileNamesForm alertsReportFileNamesForm, ProgressBar progressBar) {
		List headers = new ArrayList();
		List args = new ArrayList();
		try {
			AlertsReportFileNamesService alertsReportFileNamesService = new AlertsReportFileNamesService();
			
			/*Prepare arguments List from form*/
			args.add(alertsReportFileNamesForm.getPartiRefId());
			args.add(alertsReportFileNamesForm.getFileSeqNum());
			args.add(alertsReportFileNamesForm.getProcDate());
			args.add(alertsReportFileNamesForm.getDivisionName());
			args.add(alertsReportFileNamesForm.getFileDIV());
			
			progressBar.setProgressPercent(30);
				
			List fileNamesList = alertsReportFileNamesService.processViewRequest(connection,failures,args, headers);
			progressBar.setProgressPercent(60);
			alertsReportFileNamesForm.setHeader1((String)headers.get(0));
			alertsReportFileNamesForm.setHeader2((String)headers.get(1));
			progressBar.setProgressPercent(70);
			return fileNamesList;
		} catch (Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GET_FILENAMES", null) + " Exception details: " + e.getMessage(), e);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_GET_FILENAMES", null) + " Exception details: " + e.getMessage(), e));
			return null;
		}
	}

	/**
	 * This is a method to process rows as per page size.
	 * 
	 * @param fileNamesList
	 * @param alertsReportFileNamesForm
	 * @param page
	 * @param pageSize
	 */
	private void processViewSize(List fileNamesList, AlertsReportFileNamesForm alertsReportFileNamesForm, int page, int pageSize) {
		int nbrOfRows = fileNamesList.size();
		int pages = 0;
		int startIndex = 0;
		int endIndex = 0;
		int j = 0;
		int i = 0;
		FileNames fileNames = null;
		String rowClr;
		alertsReportFileNamesForm.setDataPresent("N");
		if (nbrOfRows > 0) {
			alertsReportFileNamesForm.setDataPresent("Y");
		}
		AlertData alertData = null;
		List alertDataList = null;
		List rows = null;
		
		if ((nbrOfRows <= pageSize) || (pageSize == 0)) {
			alertsReportFileNamesForm.setPages(0); // don't show page related buttons
			for(i=0;i<nbrOfRows;i++){
				fileNames = (FileNames) fileNamesList.get(i);
				rowClr="white";
				if (i%2 == 0) {
					rowClr="#cee6fd";
				}else{
					rowClr="#ffffff";
				}
				fileNames.setRowClr(rowClr);
				alertsReportFileNamesForm.addFileNamesList(fileNames);
			}
			return;
		}

		logger.debug("Processing rows as per page size = "+pageSize);
		pages = nbrOfRows / pageSize;
		if ((nbrOfRows % pageSize) != 0) {
			pages++;
		}
		alertsReportFileNamesForm.setPage(page);
		alertsReportFileNamesForm.setPages(pages);
		alertsReportFileNamesForm.setPageshow(page);
		startIndex = ((page - 1) * pageSize) + 1;
		endIndex = ((page - 1) * pageSize) + 1 + pageSize;

		logger.debug("Retaining rows with startIndex = " + startIndex + " endIndex = " + endIndex);
		j = 1;
		for(i = 1; i <= nbrOfRows; i++) {
			if ((i >= startIndex) && (i < endIndex)) {
				fileNames = (FileNames) fileNamesList.get(i-1);
				if (j%2 == 0) {
					rowClr="#cee6fd";
				}else{
					rowClr="#ffffff";
				}
				j++;
				fileNames.setRowClr(rowClr);
				alertsReportFileNamesForm.addFileNamesList(fileNames);
			}
		}
	}

}
