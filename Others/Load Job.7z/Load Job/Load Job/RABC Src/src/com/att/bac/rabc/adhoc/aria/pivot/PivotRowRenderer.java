/*
 * Copyright  2002-2007 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.adhoc.aria.pivot;

import com.sbc.bac.aria.ARIAReportProcessor;

public interface PivotRowRenderer {
	String renderBeginKeyRow(ARIAReportProcessor processor);
	 
	String renderEndKeyRow(ARIAReportProcessor processor);
	
	String renderBeginAttributeRow(ARIAReportProcessor processor);
	 
	String renderEndAttributeRow(ARIAReportProcessor processor);
	 
    String renderBeginDataRow(ARIAReportProcessor processor);

    String renderEndDataRow(ARIAReportProcessor processor);
}
