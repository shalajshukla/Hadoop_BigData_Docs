/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/

package com.att.bac.rabc.alerts.rpt;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import com.att.bac.rabc.MyDate;

/**
 * This class holds information required for creating alert report  
 * page 11, 12, 14, & 15.
 * 
 * @author Nalina Pandiyan - NP5434
 */
public class AlertReportParameters {
	private String cntrlPtCd = null;
	private MyDate startDate = null;
	private MyDate endDate = null;
	private MyDate procDate = null;
	private MyDate opnrStartDate = null;
	private MyDate opnrEndDate = null;
	private MyDate maxDate = null;
	private MyDate minDate = null;

	private String alertRule = null;
	private String divisionName = null;   
	private String[] keys = null; 
	private String alertGrp = null;
	private String prevSortOrder = null;
	private String prevSortBy = null;	
	private String sortOrder = null;
	private String sortBy = null;
	private String relatedAlertInd; // (String Value - "Y" or "N")
	private String currentDataLink;

	private Integer fileSeqNum = null;
	private Integer partiRefId = null;
	private Integer presnId;
	private Integer sourceCodeIndKeyLvl;
	private Integer severeLvl = null;
	private Integer alertKeyLvl;
	private Integer divisionNameKeyLvl; // should be greater > 0

	// Attributes used while processing request
	private String dataPresent;
	private int totCnt;
	private int calcCnt;
	private int seqCnt;
	private int nbrOfKeys;
	private Integer nbrOfColumns;
	private boolean hideNext;
	private boolean hidePrev;

	// The following attributes controls display filter on the JSP page 
	private String divisionNameLabel = null;
	private List divisionList = null;
	private String key1Label = null;
	private String key2Label = null;
	
	private String header1;
	private String header2;
	private String header3;

	private List uniqueTables = null;
	private String timeStampInd = null;
	private String sumyPresnName = null;
	private String webPageId;
	private String totInd;

	private String partiRefIds = null; // distinct partiRefIDs  
	private String key1s = null; // distinct divisions
	private String alertRules = null; // distinct alert rules
	private String presnIds = null; // for qryMouseOverLink query
	private String execPresnSeqNums = null; // for qryMouseOverLink query
	private String asocPresnIDs = null;
	private String sumyPresnNames = null;
	private String divisions = null;
	private int key1NameCount;
	
	private int selectedButton;
	private String alertTimeInd = null;
	private ArrayList alertTimeIndOptions = new ArrayList();
	private String alertTimeValue = null;
	private String alertTimeValueWD;
	private String alertTimeValueBR;
	private ArrayList alertTimeValueOptions = new ArrayList();
	private ArrayList alertTimeValueOptionsWD = new ArrayList();
	private ArrayList alertTimeValueOptionsBR = new ArrayList();
	
	private String allInfoIndicator = null;
	private String divisionNameList = null;
	private Integer nbrStdColumns;
	private int page;
	private int pages;
	private int pageshow;
	
	private boolean popup; // to check page is in popup or not
	
	private String region = null;
	private String dispatch = null;
	private String statusColumnHeaderBgColor = "#0059B3";
	
	private String alertItem;
	private List alertItemOptions = new ArrayList();
	
	/*
	 * Phase II changes
	 */
	private String key3Label = null;	//to filter the page 11 and 14 on key3 (phase II change)
	private int pageSize;
	private String sessionId;
	private String cycles="";
	
	private String  alertRuleTimingIndicator = "";

	/**
	 * Parameterised constructor which sets the following attribute.
	 * 
	 * @param webPageId
	 */
	public AlertReportParameters(String webPageId) {
		this.webPageId = webPageId;		
		this.relatedAlertInd = "N";
		this.currentDataLink = "N";
		this.header1 = "";
		this.header2 = "";
		this.header3 = "";
		this.totInd = "";
		this.key1NameCount = -1;
		this.severeLvl = new Integer(-1);
		this.keys = new String[] {"","","","",""};
		this.selectedButton = -1;
		this.page = 1;
		this.cntrlPtCd = "";
	}
	
	
	/**
	 * @return String cycles
	 */
	public String getCycles() {
		return cycles;
	}


	/**
	 * @param cycles
	 */
	public void setCycles(String cycles) {
		this.cycles = cycles;
	}



	/**
	 * @return Returns the divisionList.
	 */
	public List getDivisionList() {
		return divisionList;
	}
	/**
	 * @param divisionList The divisionList to set.
	 */
	public void setDivisionList(List divisionList) {
		this.divisionList = divisionList;
	}
	
	/**
	 * @return Returns the calcCnt.
	 */
	public int getCalcCnt() {
		return calcCnt;
	}
	/**
	 * @return Returns the seqCnt.
	 */
	public int getSeqCnt() {
		return seqCnt;
	}
	/**
	 * @return Returns the totCnt.
	 */
	public int getTotCnt() {
		return totCnt;
	}
	/**
	 * @return Returns the alertKeyLvl.
	 */
	public Integer getAlertKeyLvl() {
		return alertKeyLvl;
	}
	/**
	 * @param alertKeyLvl The alertKeyLvl to set.
	 */
	public void setAlertKeyLvl(Integer alertKeyLvl) {
		this.alertKeyLvl = alertKeyLvl;
	}
	/**
	 * @return Returns the presnId.
	 */
	public Integer getPresnId() {
		return presnId;
	}
	/**
	 * @param presnId The presnId to set.
	 */
	public void setPresnId(Integer presnId) {
		this.presnId = presnId;
	}
	
	/**
	 * @return Returns the alertRule.
	 */
	public String getAlertRule() {
		if (this.alertRule == null) return "";
		return alertRule;
	}
	/**
	 * @param alertRule The alertRule to set.
	 */
	public void setAlertRule(String alertRule) {
		this.alertRule = alertRule;
	}
	/**
	 * @return Returns the divisionName.
	 */
	public String getDivisionName() {
		return divisionName;
	}
	/**
	 * @param divisionName The divisionName to set.
	 */
	public void setDivisionName(String divisionName) {
		this.divisionName = divisionName;
	}
	/**
	 * @return Returns the divisionNameLabel
	 */
	public String getDivisionNameLabel() {
		return divisionNameLabel;
	}
	/**
	 * @param divisionNameLabel The divisionNameLabel to set.
	 */
	public void setDivisionNameLabel(String divisionNameLabel) {
		this.divisionNameLabel = divisionNameLabel;
	}
	/**
	 * @return Returns the endDate.
	 */
	public MyDate getEndDate() {
		return endDate;
	}
	/**
	 * @param endDate The endDate to set.
	 */
	public void setEndDate(MyDate endDate) {
		this.endDate = endDate;
	}
	/**
	 * @return Returns the fileSeqNum.
	 */
	public Integer getFileSeqNum() {
		return fileSeqNum;
	}
	/**
	 * @param fileSeqNum The fileSeqNum to set.
	 */
	public void setFileSeqNum(Integer fileSeqNum) {
		this.fileSeqNum = fileSeqNum;
	}
	/**
	 * @return Returns the header1.
	 */
	public String getHeader1() {
		return header1;
	}
	/**
	 * @param header1 The header1 to set.
	 */
	public void setHeader1(String header1) {
		this.header1 = header1;
	}
	/**
	 * @return Returns the header2.
	 */
	public String getHeader2() {
		return header2;
	}
	/**
	 * @param header2 The header2 to set.
	 */
	public void setHeader2(String header2) {
		this.header2 = header2;
	}
	/**
	 * @return Returns the header3.
	 */
	public String getHeader3() {
		return header3;
	}
	/**
	 * @param header3 The header3 to set.
	 */
	public void setHeader3(String header3) {
		this.header3 = header3;
	}
	/**
	 * @return Returns the key1Label.
	 */
	public String getKey1Label() {
		if (this.key1Label == null) return "";
		return key1Label;
	}
	/**
	 * @param key1Label The key1Label to set.
	 */
	public void setKey1Label(String key1Label) {
		this.key1Label = key1Label;
	}
	/**
	 * @return Returns the key2.
	 */
	public String getKeysAt(int i) {
		return this.keys[i];
	}
	/**
	 * @param key2 The key2 to set.
	 */
	public void setKeysAt(int i, String key) {
		if (key == null) {
			this.keys[i] = "";
			return;
		}
		this.keys[i] = key;
	}
	/**
	 * @return Returns the key2Label.
	 */
	public String getKey2Label() {
		if (this.key2Label == null) return "";
		return key2Label;
	}
	/**
	 * @param key2Label The key2Label to set.
	 */
	public void setKey2Label(String key2Label) {
		this.key2Label = key2Label;
	}
	/**
	 * @return Returns the relatedAlertInd.
	 */
	public String getRelatedAlertInd() {
		return relatedAlertInd;
	}
	/**
	 * @param relatedAlertInd The relatedAlertInd to set.
	 */
	public void setRelatedAlertInd(String relatedAlertInd) {
		this.relatedAlertInd = relatedAlertInd;
	}
	/**
	 * @return Returns the startDate.
	 */
	public MyDate getStartDate() {
		return startDate;
	}
	/**
	 * @param startDate The startDate to set.
	 */
	public void setStartDate(MyDate startDate) {
		this.startDate = startDate;
	}
	/**
	 * @return Returns the sumyPresnName.
	 */
	public String getSumyPresnName() {
		return sumyPresnName;
	}
	/**
	 * @param sumyPresnName The sumyPresnName to set.
	 */
	public void setSumyPresnName(String sumyPresnName) {
		this.sumyPresnName = sumyPresnName;
	}
	/**
	 * @return Returns the webPageId.
	 */
	public String getWebPageId() {
		return webPageId;
	}
	/**
	 * @param webPageId The webPageId to set.
	 */
	public void setWebPageId(String webPageId) {
		this.webPageId = webPageId;
	}
	/**
	 * @return Returns the divisionNameKeyLvl.
	 */
	public Integer getDivisionNameKeyLvl() {
		return divisionNameKeyLvl;
	}
	/**
	 * @param divisionNameKeyLvl The divisionNameKeyLvl to set.
	 */
	public void setDivisionNameKeyLvl(Integer divisionNameKeyLvl) {
		this.divisionNameKeyLvl = divisionNameKeyLvl;
	}
	/**
	 * @param i
	 */
	public void setTotCnt(int i) {
		this.totCnt = i;
	}
	/**
	 * @param i
	 */
	public void setCalcCnt(int i) {
		this.calcCnt = i;
	}
	/**
	 * @param i
	 */
	public void setSeqCnt(int i) {
		this.seqCnt = i;
	}
	/**
	 * @param b
	 */
	public void setHideNext(boolean b) {
		this.hideNext = b;
	}
	/**
	 * @param b
	 */
	public void setHidePrev(boolean b) {
		this.hidePrev = b;
	}

	/**
	 * @return Returns the opnrEndDate.
	 */
	public MyDate getOpnrEndDate() {
		return opnrEndDate;
	}

	/**
	 * @param opnrEndDate The opnrEndDate to set.
	 */
	public void setOpnrEndDate(MyDate opnrEndDate) {
		this.opnrEndDate = opnrEndDate;
	}

	/**
	 * @return Returns the opnrStartDate.
	 */
	public MyDate getOpnrStartDate() {
		return opnrStartDate;
	}

	/**
	 * @param opnrStartDate The opnrStartDate to set.
	 */
	public void setOpnrStartDate(MyDate opnrStartDate) {
		this.opnrStartDate = opnrStartDate;
	}

	/**
	 * @return Returns the alertGrp.
	 */
	public String getAlertGrp() {
		return alertGrp;
	}

	/**
	 * @param alertGrp The alertGrp to set.
	 */
	public void setAlertGrp(String alertGrp) {
		this.alertGrp = alertGrp;
	}

	/**
	 * @return Returns the prevSortBy.
	 */
	public String getPrevSortBy() {
		return prevSortBy;
	}

	/**
	 * @param prevSortBy The prevSortBy to set.
	 */
	public void setPrevSortBy(String prevSortBy) {
		this.prevSortBy = prevSortBy;
	}

	/**
	 * @return Returns the prevSortOrder.
	 */
	public String getPrevSortOrder() {
		return prevSortOrder;
	}

	/**
	 * @param prevSortOrder The prevSortOrder to set.
	 */
	public void setPrevSortOrder(String prevSortOrder) {
		this.prevSortOrder = prevSortOrder;
	}

	/**
	 * @return Returns the sortBy.
	 */
	public String getSortBy() {
		return sortBy;
	}

	/**
	 * @param sortBy The sortBy to set.
	 */
	public void setSortBy(String sortBy) {
		this.sortBy = sortBy;
	}

	/**
	 * @return Returns the sortOrder.
	 */
	public String getSortOrder() {
		return sortOrder;
	}

	/**
	 * @param sortOrder The sortOrder to set.
	 */
	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}

	/**
	 * @return Returns the timeStampInd.
	 */
	public String getTimeStampInd() {
		return timeStampInd;
	}

	/**
	 * @param timeStampInd The timeStampInd to set.
	 */
	public void setTimeStampInd(String timeStampInd) {
		this.timeStampInd = timeStampInd;
	}

	/**
	 * @return Returns the severeLvl.
	 */
	public Integer getSevereLvl() {
		if (this.severeLvl == null) {
			this.severeLvl = new Integer(-1);
		}
		return severeLvl;
	}

	/**
	 * @param severeLvl The severeLvl to set.
	 */
	public void setSevereLvl(Integer severeLvl) {
		this.severeLvl = severeLvl;
	}
	/**
	 * @return Returns the nbrOfColumns.
	 */
	public Integer getNbrOfColumns() {
		return nbrOfColumns;
	}

	/**
	 * @param nbrOfColumns The nbrOfColumns to set.
	 */
	public void setNbrOfColumns(Integer nbrOfColumns) {
		this.nbrOfColumns = nbrOfColumns;
	}

	/**
	 * @return Returns the noData.
	 */
	public String getDataPresent() {
		return this.dataPresent;
	}

	/**
	 * @param noData The noData to set.
	 */
	public void setDataPresent(String dataPresent) {
		this.dataPresent = dataPresent;
	}

	/**
	 * @return Returns the hideNext.
	 */
	public boolean isHideNext() {
		return hideNext;
	}

	/**
	 * @return Returns the hidePrev.
	 */
	public boolean isHidePrev() {
		return hidePrev;
	}

	public String toString() {
		String tmpStr = "";
		if (divisionName != null) tmpStr = tmpStr + "divisionName = " + divisionName;
		if (alertRule != null) tmpStr = tmpStr + " alertRule = "+alertRule;
		if (startDate != null) tmpStr = tmpStr + " startDate = " + startDate.toString();
		if (endDate != null) tmpStr = tmpStr + " endDate = " + endDate.toString();
		if (divisionName != null) tmpStr = tmpStr + " divisionName = " + divisionName;
		tmpStr = tmpStr + " relatedAlertInd = " + relatedAlertInd;
		if (procDate != null) tmpStr = tmpStr + " procDate = " + procDate.toString();
		if (partiRefId != null) tmpStr = tmpStr + " partiRefId = " + partiRefId;
		if (opnrStartDate != null) tmpStr = tmpStr + " opnrStartDate = " + opnrStartDate.toString();
		if (opnrEndDate != null) tmpStr = tmpStr + " opnrEndDate = " + opnrEndDate.toString();
		if (prevSortOrder != null) tmpStr = tmpStr + " prevSortOrder = " + prevSortOrder;
		if (prevSortBy != null) tmpStr = tmpStr + " prevSortBy = " + prevSortBy;
		if (sortBy != null) tmpStr = tmpStr + " sortBy = " + sortBy;
		if (timeStampInd != null) tmpStr = tmpStr + " timeStampInd = " + timeStampInd;
		if (severeLvl != null) tmpStr = tmpStr + " severeLvl = " + severeLvl;
		if (webPageId != null) tmpStr = tmpStr + " webPageId = " + webPageId;
		return  tmpStr;
	}
	/**
	 * @return Returns the partiRefId.
	 */
	public Integer getPartiRefId() {
		//if (this.partiRefId == null) return new Integer(-1);
		return partiRefId;
	}
	/**
	 * @param partiRefId The partiRefId to set.
	 */
	public void setPartiRefId(Integer partiRefId) {
		this.partiRefId = partiRefId;
	}
	/**
	 * @return Returns the maxDate.
	 */
	public MyDate getMaxDate() {
		return maxDate;
	}

	/**
	 * @param maxDate The maxDate to set.
	 */
	public void setMaxDate(MyDate maxDate) {
		this.maxDate = maxDate;
	}

	/**
	 * @return Returns the minDate.
	 */
	public MyDate getMinDate() {
		return minDate;
	}

	/**
	 * @param minDate The minDate to set.
	 */
	public void setMinDate(MyDate minDate) {
		this.minDate = minDate;
	}

	/**
	 * @return Returns the totInd.
	 */
	public String getTotInd() {
		return totInd;
	}

	/**
	 * @param totInd The totInd to set.
	 */
	public void setTotInd(String totInd) {
		this.totInd = totInd;
	}

	/**
	 * @return Returns the selectedButton.
	 */
	public int getSelectedButton() {
		return selectedButton;
	}
	/**
	 * @param selectedButton The selectedButton to set.
	 */
	public void setSelectedButton(int selectedButton) {
		this.selectedButton = selectedButton;
	}
	/**
	 * @return Returns the procDate.
	 */
	public MyDate getProcDate() {
		return procDate;
	}

	/**
	 * @param procDate The procDate to set.
	 */
	public void setProcDate(MyDate procDate) {
		this.procDate = procDate;
	}

	/**
	 * @return Returns the alertTimeInd.
	 */
	public String getAlertTimeInd() {
		if (this.alertTimeInd == null) return "";
		return alertTimeInd;
	}

	/**
	 * @param alertTimeInd The alertTimeInd to set.
	 */
	public void setAlertTimeInd(String alertTimeInd) {
		this.alertTimeInd = alertTimeInd;
	}

	/**
	 * @return Returns the alertTimeValue.
	 */
	public String getAlertTimeValue() {
		if (this.alertTimeValue == null) return "";
		return alertTimeValue;
	}

	/**
	 * @param alertTimeValue The alertTimeValue to set.
	 */
	public void setAlertTimeValue(String alertTimeValue) {
		this.alertTimeValue = alertTimeValue;
	}

	/**
	 * @return Returns the allInfoIndicator.
	 */
	public String getAllInfoIndicator() {
		return allInfoIndicator;
	}

	/**
	 * @param allInfoIndicator The allInfoIndicator to set.
	 */
	public void setAllInfoIndicator(String allInfoIndicator) {
		this.allInfoIndicator = allInfoIndicator;
	}


	/**
	 * @return Returns the currentDataLink.
	 */
	public String getCurrentDataLink() {
		if (this.currentDataLink == null) return "";
		return currentDataLink;
	}

	/**
	 * @param currentDataLink The currentDataLink to set.
	 */
	public void setCurrentDataLink(String currentDataLink) {
		this.currentDataLink = currentDataLink;
	}

	/**
	 * @return Returns the divisionNameList.
	 */
	public String getDivisionNameList() {
		return divisionNameList;
	}

	/**
	 * @param divisionNameList The divisionNameList to set.
	 */
	public void setDivisionNameList(String divisionNameList) {
		this.divisionNameList = divisionNameList;
	}

	/**
	 * @return Returns the nbrOfKeys.
	 */
	public int getNbrOfKeys() {
		return nbrOfKeys;
	}

	/**
	 * @param nbrOfKeys The nbrOfKeys to set.
	 */
	public void setNbrOfKeys(int nbrOfKeys) {
		this.nbrOfKeys = nbrOfKeys;
	}

	/**
	 * @return Returns the sourceCodeIndKeyLvl.
	 */
	public Integer getSourceCodeIndKeyLvl() {
		return sourceCodeIndKeyLvl;
	}

	/**
	 * @param sourceCodeIndKeyLvl The sourceCodeIndKeyLvl to set.
	 */
	public void setSourceCodeIndKeyLvl(Integer sourceCodeIndKeyLvl) {
		this.sourceCodeIndKeyLvl = sourceCodeIndKeyLvl;
	}

	/**
	 * @return Returns the uniqueTables.
	 */
	public List getUniqueTables() {
		return uniqueTables;
	}

	/**
	 * @param uniqueTables The uniqueTables to set.
	 */
	public void setUniqueTables(List uniqueTables) {
		this.uniqueTables = uniqueTables;
	}

	/**
	 * @return Returns the nbrStdColumns.
	 */
	public Integer getNbrStdColumns() {
		return nbrStdColumns;
	}

	/**
	 * @param nbrStdColumns The nbrStdColumns to set.
	 */
	public void setNbrStdColumns(Integer nbrStdColumns) {
		this.nbrStdColumns = nbrStdColumns;
	}


	/**
	 * @return Returns the alertRules.
	 */
	public String getAlertRules() {
		if (this.alertRules == null) return "";
		if (alertRules.startsWith(",")) {
			return alertRules.substring(1);
		}else{
			return alertRules;
		}
	}

	/**
	 * @return Returns the asocPresnIDs.
	 */
	public String getAsocPresnIDs() {
		if (this.asocPresnIDs == null) return "";
		if (asocPresnIDs.startsWith(",")) {
			return asocPresnIDs.substring(1);
		}else{
			return asocPresnIDs;
		}
	}

	/**
	 * @return Returns the execPresnSeqNums.
	 */
	public String getExecPresnSeqNums() {
		if (this.execPresnSeqNums == null) return "";
		if (execPresnSeqNums.startsWith(",")) {
			return execPresnSeqNums.substring(1);
		}else{
			return execPresnSeqNums;
		}
	}

	/**
	 * @return Returns the partiRefIds.
	 */
	public String getPartiRefIds() {
		if (this.partiRefIds == null) return "";
		if (partiRefIds.startsWith(",")) {
			return partiRefIds.substring(1);
		}else{
			return partiRefIds;
		}
	}

	/**
	 * @return Returns the presnIds.
	 */
	public String getPresnIds() {
		if (this.presnIds == null) return "";
		if (presnIds.startsWith(",")) {
			return presnIds.substring(1);
		}else{
			return presnIds;
		}
	}

	/**
	 * @return Returns the key1s.
	 */
	public String getKey1s() {
		if (this.key1s== null) return "";
		if (key1s.startsWith(",")) {
			return key1s.substring(1);
		}else{
			return key1s;
		}
	}

	/**
	 * @return Returns the divisions.
	 */
	public String getDivisions() {
		if (this.divisions == null) return "";
		if (this.divisions.startsWith(",")) {
			return this.divisions.substring(1);
		}else{
			return divisions;
		}
	}

	public void addPartiRefId(Integer partiRefId) {
		String tmpId = "," + partiRefId.toString();
		if (this.partiRefIds == null) {
			this.partiRefIds = tmpId;
		}else{
			int index= this.partiRefIds.indexOf(tmpId);
			if (index>-1) {
				if (this.partiRefIds.length() != index + tmpId.length()) {
					index = this.partiRefIds.indexOf(tmpId+",");
					if (index == -1) {
						this.partiRefIds += tmpId;
					}
				}
			} else {
				this.partiRefIds += tmpId;
			}
		}
	}
	
	public void addKey1s(String key) {
		String tmpKey = ",'" + key + "'";
		if (this.key1s == null) {
			this.key1s = tmpKey;
		} else {
			int index= this.key1s.indexOf(tmpKey);
			if (index == -1) {
				this.key1s += tmpKey;
			}
		}	
	}
	
	public void addAlertRule(String alertRule) {
		if (alertRule == null) return;
		
		String tmpAlertRule = ",'" + alertRule + "'";
		if (this.alertRules == null) {
			this.alertRules = tmpAlertRule;
		} else {
			int index= this.alertRules.indexOf(tmpAlertRule);
			if (index == -1) {
				this.alertRules += tmpAlertRule;
			}
		}
	}
	
	/**
	 * @return Returns the sumyPresnNames.
	 */
	public String getSumyPresnNames() {

		if (this.sumyPresnNames == null) return "";
		if (sumyPresnNames.startsWith(",")) {
			return sumyPresnNames.substring(1);
		} else {
			return sumyPresnNames;
		}
	}

	public void setSumyPresnNames(String value) {
		this.sumyPresnNames = value;
	}

	public void addSumyPresnNames(String sumyPresnName) {
		if (sumyPresnName == null) return;
		
		String tmpSumyPresnName = ",'" + sumyPresnName + "'";
		if (this.sumyPresnNames == null) {
			this.sumyPresnNames = tmpSumyPresnName;
		} else {
			int index= this.sumyPresnNames.indexOf(tmpSumyPresnName);
			if (index == -1) {
				this.sumyPresnNames += tmpSumyPresnName;
			}
		}
	}

	public void addPresnId(Integer id) {
		if (id == null) return;

		String tmpId = ","+id.toString();
		if (this.presnIds == null) {
			this.presnIds = tmpId;
		} else {
			int index = this.presnIds.indexOf(tmpId);
			if (index > -1) {
				if (this.presnIds.length() != index + tmpId.length()) {
					index = this.presnIds.indexOf(tmpId+",");
					if (index == -1) {
						this.presnIds += tmpId;
					}
				}
			} else {
				this.presnIds += tmpId;
			}
		}
	}
	public void addExecPresnSeqNum(String s) {
		String tmpId = ","+s.toString();
		if (this.execPresnSeqNums == null) {
			this.execPresnSeqNums = tmpId;
		} else {
			int index = this.execPresnSeqNums.indexOf(tmpId);
			if( index>-1 ){
				index = this.execPresnSeqNums.indexOf(tmpId+",");
				if (index == -1) {
					this.execPresnSeqNums += tmpId;
				}
			} else {
				this.execPresnSeqNums += tmpId;
			}
		}
	}
	public void addAsocPresnID(Integer id) {
		String tmpId = "," + id.toString();
		if (this.asocPresnIDs == null) {
			this.asocPresnIDs = tmpId;
		} else {
			int index= this.asocPresnIDs.indexOf(tmpId);
			if (index > -1) {
				index = this.asocPresnIDs.indexOf(tmpId+",");
				if (index == -1) {
					this.asocPresnIDs += tmpId;
				}
			} else {
				this.asocPresnIDs += tmpId;
			}
		}
	}
	
	public void addDivision(String s) {
		if (s == null) return;
		
		/*String tmpDivision = "," + s;
		if (this.divisions == null) {
			this.divisions = tmpDivision;
		} else {
			int index = this.divisions.indexOf(tmpDivision);
			if( index > -1 ){
				index = this.divisions.indexOf(tmpDivision + ",");
				if (index == -1) {
					this.divisions += tmpDivision;
				}
			} else {
				this.divisions += tmpDivision;
			}
		}*/
		int counter=0;
		if(this.divisions!=null){
			StringTokenizer stn = new StringTokenizer(this.divisions,",");
			while(stn.hasMoreTokens()){
				String temp=stn.nextToken();
				if(temp.equals(s)){
					counter++;
				}
			}		
			if(counter==0){
				this.divisions = this.divisions+","+s;
			}
		}else{
			this.divisions = s;			
		}
	}
	
	public boolean getPopup() {
		return popup;
	}
	
	public void setPopup(boolean popup) {
		this.popup = popup;
	}
	/**
	 * @return Returns the cntrlPtCd.
	 */
	public String getCntrlPtCd() {
		return cntrlPtCd;
	}

	/**
	 * @param cntrlPtCd The cntrlPtCd to set.
	 */
	public void setCntrlPtCd(String cntrlPtCd) {
		this.cntrlPtCd = cntrlPtCd;
	}

	/**
	 * @return Returns the divisionList.
	 */
	public int getKey1NameCount() {
		return this.key1NameCount;
	}
	/**
	 * @param divisionList The divisionList to set.
	 */
	public void setKey1NameCount(int key1NameCount) {
		this.key1NameCount = key1NameCount;
	}
	/**
	 * @return Returns the page.
	 */
	public int getPage() {
		return page;
	}

	/**
	 * @param page The page to set.
	 */
	public void setPage(int page) {
		this.page = page;
	}

	/**
	 * @return Returns the pages.
	 */
	public int getPages() {
		return pages;
	}

	/**
	 * @param pages The pages to set.
	 */
	public void setPages(int pages) {
		this.pages = pages;
	}

	/**
	 * @return Returns the pageshow.
	 */
	public int getPageshow() {
		return pageshow;
	}

	/**
	 * @param pageshow The pageshow to set.
	 */
	public void setPageshow(int pageshow) {
		this.pageshow = pageshow;
	}

	/**
	 * @param alertRules The alertRules to set.
	 */
	public void setAlertRules(String alertRules) {
		this.alertRules = alertRules;
	}

	/**
	 * @param presnIds The presnIds to set.
	 */
	public void setPresnIds(String presnIds) {
		this.presnIds = presnIds;
	}
	
	
	/**
	 * @return Returns the alertTimeValueBR.
	 */
	public String getAlertTimeValueBR() {
		return alertTimeValueBR;
	}
	/**
	 * @param alertTimeValueBR The alertTimeValueBR to set.
	 */
	public void setAlertTimeValueBR(String alertTimeValueBR) {
		this.alertTimeValueBR = alertTimeValueBR;
	}
	/**
	 * @return Returns the alertTimeValueOptions.
	 */
	public ArrayList getAlertTimeValueOptions() {
		return alertTimeValueOptions;
	}
	/**
	 * @param alertTimeValueOptions The alertTimeValueOptions to set.
	 */
	public void setAlertTimeValueOptions(ArrayList alertTimeValueOptions) {
		this.alertTimeValueOptions = alertTimeValueOptions;
	}
	/**
	 * @return Returns the alertTimeValueOptionsBR.
	 */
	public ArrayList getAlertTimeValueOptionsBR() {
		return alertTimeValueOptionsBR;
	}
	/**
	 * @param alertTimeValueOptionsBR The alertTimeValueOptionsBR to set.
	 */
	public void setAlertTimeValueOptionsBR(ArrayList alertTimeValueOptionsBR) {
		this.alertTimeValueOptionsBR = alertTimeValueOptionsBR;
	}
	/**
	 * @return Returns the alertTimeValueOptionsWD.
	 */
	public ArrayList getAlertTimeValueOptionsWD() {
		return alertTimeValueOptionsWD;
	}
	/**
	 * @param alertTimeValueOptionsWD The alertTimeValueOptionsWD to set.
	 */
	public void setAlertTimeValueOptionsWD(ArrayList alertTimeValueOptionsWD) {
		this.alertTimeValueOptionsWD = alertTimeValueOptionsWD;
	}
	/**
	 * @return Returns the alertTimeValueWD.
	 */
	public String getAlertTimeValueWD() {
		return alertTimeValueWD;
	}
	/**
	 * @param alertTimeValueWD The alertTimeValueWD to set.
	 */
	public void setAlertTimeValueWD(String alertTimeValueWD) {
		this.alertTimeValueWD = alertTimeValueWD;
	}
	
	
	/**
	 * @return Returns the alertTimeIndOptions.
	 */
	public ArrayList getAlertTimeIndOptions() {
		return alertTimeIndOptions;
	}
	/**
	 * @param alertTimeIndOptions The alertTimeIndOptions to set.
	 */
	public void setAlertTimeIndOptions(ArrayList alertTimeIndOptions) {
		this.alertTimeIndOptions = alertTimeIndOptions;
	}
	
	/**
	 * @return Returns the region.
	 */
	public String getRegion() {
		return region;
	}
	/**
	 * @param region The region to set.
	 */
	public void setRegion(String region) {
		this.region = region;
	}
	
	/**
	 * @return Returns the dispatch.
	 */
	public String getDispatch() {
		return dispatch;
	}
	/**
	 * @param dispatch The dispatch to set.
	 */
	public void setDispatch(String dispatch) {
		this.dispatch = dispatch;
	}
	
	/**
	 * @return Returns the statusColumnHeaderBgColor.
	 */
	public String getStatusColumnHeaderBgColor() {
		return statusColumnHeaderBgColor;
	}
	/**
	 * @param statusColumnHeaderBgColor The statusColumnHeaderBgColor to set.
	 */
	public void setStatusColumnHeaderBgColor(String statusColumnHeaderBgColor) {
		this.statusColumnHeaderBgColor = statusColumnHeaderBgColor;
	}
	
	/**
	 * @return Returns the alertItem.
	 */
	public String getAlertItem() {
		return alertItem;
	}
	/**
	 * @param alertItem The alertItem to set.
	 */
	public void setAlertItem(String alertItem) {
		this.alertItem = alertItem;
	}
	/**
	 * @return Returns the alertItemOptions.
	 */
	public List getAlertItemOptions() {
		return alertItemOptions;
	}
	/**
	 * @param alertItemOptions The alertItemOptions to set.
	 */
	public void setAlertItemOptions(List alertItemOptions) {
		this.alertItemOptions = alertItemOptions;
	}
	/**
	 * @return Returns the key3Label.
	 */
	public String getKey3Label() {
		return key3Label;
	}
	/**
	 * @param key3Label The key3Label to set.
	 */
	public void setKey3Label(String key3Label) {
		this.key3Label = key3Label;
	}
	
	/**
	 * @return Returns the pageSize.
	 */
	public int getPageSize() {
		return pageSize;
	}
	/**
	 * @param pageSize The pageSize to set.
	 */
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	
	/**
	 * @return Returns the sessionId.
	 */
	public String getSessionId() {
		return sessionId;
	}
	/**
	 * @param sessionId The sessionId to set.
	 */
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	/**
	 * @return the alertRuleTimingIndicator
	 */
	public String getAlertRuleTimingIndicator() {
		return alertRuleTimingIndicator;
	}

	/**
	 * @param alertRuleTimingIndicator the alertRuleTimingIndicator to set
	 */
	public void setAlertRuleTimingIndicator(String alertRuleTimingIndicator) {
		this.alertRuleTimingIndicator = alertRuleTimingIndicator;
	}
}
