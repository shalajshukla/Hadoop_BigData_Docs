/*
 * Created on Feb 9, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.att.bac.rabc.load.paj;

import java.io.File;
import java.net.UnknownHostException;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.att.bac.rabc.util.EmcisEventLogger;
import com.att.carat.util.NetUtil;
import com.sbc.bac.rabc.load.FilePatternLoadJob;
import com.sbc.bac.rabc.load.PrepareTableForRerun;
import com.sbc.bac.rabc.load.RabcLoadJobTrig;
import com.sbc.bac.rabc.load.RetrieveStaticInfo;
import com.sbc.bac.rabc.load.StaticErrorMsgKeys;
import com.sbc.bac.rabc.load.StaticFieldKeys;

/**
 * @author pt6471
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class PaymentAdjustments extends FilePatternLoadJob {

	// private static final String FILEPATTERN = "WE.[CI].C[0-9][0-9]*.CN28100F.*";
	
	private DateFormat df = new SimpleDateFormat("MMddyyyy");
	private DateFormat df1 = new SimpleDateFormat("yyMMdd");
	
	private PreparedStatement xt28f_deposit, xt28f_occ_over, xt28f_master_payment, xt28f_master_adj;
	private PreparedStatement xt28f_input_paymeny, xt28f_input_adj, xt28f_balance_transfer, xt28f_non_payment, xt28f_summary;
	private String division, bill_rnd, run_date, fileToken, fileName;
	
	private String backoutRecovery = null;
	
	private File currentFile;
	
	private int lineCount;
	
	private java.sql.Date sqlrun_date;
	
	private HashMap acctTypeMap;
	
	private boolean nevadaBellData;
	 
	public boolean preprocess() {
		super.preprocess();

		try {
			
			xt28f_deposit = connection.prepareStatement(" insert into RABC_DEPOSIT_OVER_TRSLD(DIVISION, RUN_DATE, BTN, BUS_TYPE, DEP_AMT) VALUES(?, ?, ?, ?, ?) ");
			
			xt28f_occ_over = connection.prepareStatement(" insert into RABC_OCC_OVER_TRSLD(DIVISION, RUN_DATE, BTN, OCC_AMT, CUR_BLG_AMT) VALUES(?, ?, ?, ?, ?) ");
			
			xt28f_master_payment = connection.prepareStatement(" insert into RABC_AIMS_PAYMENT_OVER_TRSLD(DIVISION, RUN_DATE, BTN, MSTR_PAYMENT_AMT, CUR_BLG_AMT) VALUES(?, ?, ?, ?, ?) ");
			
			xt28f_master_adj = connection.prepareStatement(" insert into RABC_AIMS_ADJ_OVER_TRSLD(DIVISION, RUN_DATE, BTN, MSTR_ADJ_AMT, CUR_BLG_AMT) VALUES(?, ?, ?, ?, ?) ");
			
			xt28f_input_paymeny = connection.prepareStatement(" insert into RABC_INPUT_PAYMENT_OVER_TRSLD(DIVISION, RUN_DATE, BTN, INPT_PAYMENT_AMT, CUR_BLG_AMT) VALUES(?, ?, ?, ?, ?) ");
			
			xt28f_input_adj = connection.prepareStatement(" insert into RABC_INPUT_ADJ_OVER_TRSLD(DIVISION, RUN_DATE, BTN, INPT_ADJ_AMT, CUR_BLG_AMT) VALUES(?, ?, ?, ?, ?) ");
			
			xt28f_balance_transfer = connection.prepareStatement(" insert into RABC_BALANCE_TRANSFER(DIVISION, RUN_DATE, BTN, BUS_TYPE, BAL_DUE_TRN_AMT, PREV_BAL_AMT) VALUES(?, ?, ?, ?, ?, ?) ");
			
			xt28f_non_payment = connection.prepareStatement(" insert into RABC_NON_PAYMENT(DIVISION, RUN_DATE, BTN, BUS_TYPE, CUR_BLG_AMT, LAST_PYMT_DATE) VALUES(?, ?, ?, ?, ?, ?) ");
			
			xt28f_summary = connection.prepareStatement(" insert into RABC_AIMS_ACTIVITY_STATS(RUN_DATE, DIVISION, TRNSCTN_TYPE, ACCT_CT) VALUES(?, ?, ?, ?) ");	
			
		} catch (SQLException e) {
			severe(StaticErrorMsgKeys.PREPROCESS_ERROR + e.getMessage());
			return false;
		}
		return true;
	}

	public boolean preprocessFile(File file) {
		boolean success = super.preprocessFile(file);
		fileName = file.getName();
		fileToken = file.getName().substring(file.getName().indexOf("CN28100F"),file.getName().indexOf("CN28100F")+ 8);
		nevadaBellData = false;
		
		acctTypeMap = new HashMap();
		
		if (success) {
			try {
				
				if 	(file.getName().charAt(0) == StaticFieldKeys.C)	
				  division = StaticFieldKeys.PACBELLNORTH;
				else if (file.getName().charAt(0) == StaticFieldKeys.I)	
				  division = StaticFieldKeys.PACBELLSOUTH;
				else 
					return false;
				
				int cycle = Integer.parseInt(file.getName().substring(3, 7));
				
				run_date = RetrieveStaticInfo.getProc_dtByCycle(connection, cycle);
				if (run_date.equals(StaticFieldKeys.ZERO)){
					severe(StaticErrorMsgKeys.NORECORD_RABC_CYCLE_CALENDAR + cycle);
					throw new Exception();	
				}
				
				sqlrun_date = new java.sql.Date(df.parse(run_date).getTime());

				lineCount = 0;
				
				backoutRecovery = null;

				if (RabcLoadJobTrig.IsFileLoaded(connection, file, file.getName().length())) {
					backoutRecovery = "Y";
					
					String tableNm = "RABC_DEPOSIT_OVER_TRSLD";
					success = PrepareTableForRerun.deleteTableData(connection,tableNm,division,sqlrun_date);
					//	Both divisions NB (NEVADABELL) and PN (PACBELLNORTH) come from same file!!
					if (division == StaticFieldKeys.PACBELLNORTH)
					 	success = PrepareTableForRerun.deleteTableData(connection,tableNm,StaticFieldKeys.NEVADABELL,sqlrun_date);

					tableNm = "RABC_OCC_OVER_TRSLD";
					success = PrepareTableForRerun.deleteTableData(connection,tableNm,division,sqlrun_date);
					if (division == StaticFieldKeys.PACBELLNORTH)
					 	success = PrepareTableForRerun.deleteTableData(connection,tableNm,StaticFieldKeys.NEVADABELL,sqlrun_date);


					tableNm = "RABC_AIMS_PAYMENT_OVER_TRSLD";
					success = PrepareTableForRerun.deleteTableData(connection,tableNm,division,sqlrun_date);
					if (division == StaticFieldKeys.PACBELLNORTH)
					 	success = PrepareTableForRerun.deleteTableData(connection,tableNm,StaticFieldKeys.NEVADABELL,sqlrun_date);


					tableNm = "RABC_AIMS_ADJ_OVER_TRSLD";
					success = PrepareTableForRerun.deleteTableData(connection,tableNm,division,sqlrun_date);
					if (division == StaticFieldKeys.PACBELLNORTH)
					 	success = PrepareTableForRerun.deleteTableData(connection,tableNm,StaticFieldKeys.NEVADABELL,sqlrun_date);


					tableNm = "RABC_INPUT_PAYMENT_OVER_TRSLD";
					success = PrepareTableForRerun.deleteTableData(connection,tableNm,division,sqlrun_date);
					if (division == StaticFieldKeys.PACBELLNORTH)
					 	success = PrepareTableForRerun.deleteTableData(connection,tableNm,StaticFieldKeys.NEVADABELL,sqlrun_date);


					tableNm = "RABC_INPUT_ADJ_OVER_TRSLD";
					success = PrepareTableForRerun.deleteTableData(connection,tableNm,division,sqlrun_date);
					if (division == StaticFieldKeys.PACBELLNORTH)
					 	success = PrepareTableForRerun.deleteTableData(connection,tableNm,StaticFieldKeys.NEVADABELL,sqlrun_date);


					tableNm = "RABC_BALANCE_TRANSFER";
					success = PrepareTableForRerun.deleteTableData(connection,tableNm,division,sqlrun_date);
					if (division == StaticFieldKeys.PACBELLNORTH)
					 	success = PrepareTableForRerun.deleteTableData(connection,tableNm,StaticFieldKeys.NEVADABELL,sqlrun_date);


					tableNm = "RABC_NON_PAYMENT";
					success = PrepareTableForRerun.deleteTableData(connection,tableNm,division,sqlrun_date);
					if (division == StaticFieldKeys.PACBELLNORTH)
					 	success = PrepareTableForRerun.deleteTableData(connection,tableNm,StaticFieldKeys.NEVADABELL,sqlrun_date);

					tableNm = "RABC_AIMS_ACTIVITY_STATS";
					success = PrepareTableForRerun.deleteTableData(connection,tableNm,division,sqlrun_date);
					if (division == StaticFieldKeys.PACBELLNORTH)
					 	success = PrepareTableForRerun.deleteTableData(connection,tableNm,StaticFieldKeys.NEVADABELL,sqlrun_date);


				}

				
				bill_rnd = RetrieveStaticInfo.getBillRndByCycle(connection, cycle);
				/*
				if (bill_rnd.equals(StaticFieldKeys.ZERO) || bill_rnd.equals(StaticFieldKeys.ZERO2)){
				 severe(StaticErrorMsgKeys.PREPROCESSFILE_ERROR+":No Bill Round");
				 return false;
				}
				*/
				
			} catch (SQLException e) {
				success = false;
				severe(StaticErrorMsgKeys.PREPROCESSFILE_ERROR + e.getMessage());
			} catch (Exception e) {
				severe(
					StaticErrorMsgKeys.PREPROCESSFILE_ERROR
						+ StaticErrorMsgKeys.FILE_NAME_PARSING_ERROR
						+ e);
				return false;
			}
		}



		currentFile = file;
		return success;
	}

	
	
	public int parseLine(String line) throws Exception {
		boolean status;
		
		lineCount++;
		
		int actTypeCnt = 1;
		
		//StringTokenizer DataLine = new StringTokenizer(line, StaticFieldKeys.SEMICOLON);
	//	String[] tokens = new String[DataLine.countTokens()];
		
		String[] data = line.split(";");
		PaymentData paymentData = new PaymentData();
		
		paymentData.setCompanyId(data[0].trim());
		if (data[0].trim().equals("NB")) nevadaBellData = true;
		
		paymentData.setCycle(Integer.parseInt(data[1].trim()));
		paymentData.setBtn(Long.parseLong(data[3].trim()));

		String mapKey = data[2].trim();
		if (acctTypeMap.containsKey(mapKey)){
			actTypeCnt = ((Integer)(acctTypeMap.get(mapKey))).intValue();
			actTypeCnt++;
			acctTypeMap.put(mapKey,new Integer(actTypeCnt));
		}else 
			acctTypeMap.put(mapKey,new Integer(actTypeCnt));
		
		
		if (mapKey.equals("DEP")) {
			paymentData.setBusinessType(data[4].trim());
			paymentData.setBillPayAmount1(Double.parseDouble(data[5].trim()));
			prcessDepositOverThreshold(paymentData);
		}
		else if (mapKey.equals("OCCBPA")) {
			paymentData.setBillPayAmount1(Double.parseDouble(data[4].trim()));
			paymentData.setBillPayAmount2(Double.parseDouble(data[5].trim()));
			prcessOCCOverThreshold(paymentData);
		}
		else if (mapKey.equals("PYMTM")){
			paymentData.setBillPayAmount1(Double.parseDouble(data[4].trim()));
			paymentData.setBillPayAmount2(Double.parseDouble(data[5].trim()));
			prcessMasterPaymentOverThreshold(paymentData);
		}
		else if (mapKey.equals("ADJM")){
			paymentData.setBillPayAmount1(Double.parseDouble(data[4].trim()));
			paymentData.setBillPayAmount2(Double.parseDouble(data[5].trim()));
			prcessMasterAdjustmentOverThreshold(paymentData);
		}
		else if (mapKey.equals("PYMTI")){
			paymentData.setBillPayAmount1(Double.parseDouble(data[4].trim()));
			paymentData.setBillPayAmount2(Double.parseDouble(data[5].trim()));
			prcessInputPaymentOverThreshold(paymentData);
		}
		else if (mapKey.equals("ADJI")){
			paymentData.setBillPayAmount1(Double.parseDouble(data[4].trim()));
			paymentData.setBillPayAmount2(Double.parseDouble(data[5].trim()));
			prcessInputAdjustmentOverThreshold(paymentData);
		}
		else if (mapKey.equals("BAL")){
			paymentData.setBusinessType(data[4].trim());
			paymentData.setBillPayAmount1(Double.parseDouble(data[5].trim()));
			paymentData.setBillPayAmount2(Double.parseDouble(data[6].trim()));
			prcessBalanceTransfer(paymentData);
		}
		else if (mapKey.equals("NPYMT")){
			paymentData.setBusinessType(data[4].trim());
			paymentData.setBillPayAmount1(Double.parseDouble(data[5].trim()));
			paymentData.setLastPaymentDate(new Date(df1.parse(data[6].trim()).getTime()));
			prcessNonPayment(paymentData);
		}
		else 
			return SKIPPED;

			return SUCCESS;
	}
	private void prcessDepositOverThreshold(PaymentData pData) throws SQLException, Exception {
		try {
			
			xt28f_deposit.setString(1, pData.getCompanyId());
			xt28f_deposit.setDate(2,sqlrun_date);
			xt28f_deposit.setLong(3,pData.getBtn());
			xt28f_deposit.setString(4,pData.getBusinessType());
			xt28f_deposit.setDouble(5,pData.getBillPayAmount1());
			xt28f_deposit.addBatch();
			
		if (lineCount % 1000 == 0){
			xt28f_deposit.executeBatch();
		}
			
		}catch (SQLException sqle){
			severe(StaticErrorMsgKeys.INSERT_ERROR + sqle.getMessage());
			 throw new Exception("Exception is from method process16XTSODE");
		}
		

	}
	
	private void prcessOCCOverThreshold(PaymentData pData) throws SQLException, Exception {
		try {
			
			xt28f_occ_over.setString(1,pData.getCompanyId());
			xt28f_occ_over.setDate(2,sqlrun_date);
			xt28f_occ_over.setLong(3,pData.getBtn());
			xt28f_occ_over.setDouble(4,pData.getBillPayAmount1());
			xt28f_occ_over.setDouble(5,pData.getBillPayAmount2());
			xt28f_occ_over.addBatch();
			
		if (lineCount % 1000 == 0){
			xt28f_occ_over.executeBatch();
		}
			
		}catch (SQLException sqle){
			severe(StaticErrorMsgKeys.INSERT_ERROR + sqle.getMessage());
			 throw new Exception("Exception is from method process16XTSODE");
		}
		

	}
	
	private void prcessMasterPaymentOverThreshold(PaymentData pData) throws SQLException, Exception {
		try {
			
			xt28f_master_payment.setString(1,pData.getCompanyId());
			xt28f_master_payment.setDate(2,sqlrun_date);
			xt28f_master_payment.setLong(3,pData.getBtn());
			xt28f_master_payment.setDouble(4,pData.getBillPayAmount1());
			xt28f_master_payment.setDouble(5,pData.getBillPayAmount2());
			xt28f_master_payment.addBatch();
			
		if (lineCount % 1000 == 0){
			xt28f_master_payment.executeBatch();
		}
			
		}catch (SQLException sqle){
			severe(StaticErrorMsgKeys.INSERT_ERROR + sqle.getMessage());
			 throw new Exception("Exception is from method process16XTSODE");
		}
		

	}
	
	
	private void prcessMasterAdjustmentOverThreshold(PaymentData pData) throws SQLException, Exception {
		try {
			
			xt28f_master_adj.setString(1,pData.getCompanyId());
			xt28f_master_adj.setDate(2,sqlrun_date);
			xt28f_master_adj.setLong(3,pData.getBtn());
			xt28f_master_adj.setDouble(4,pData.getBillPayAmount1());
			xt28f_master_adj.setDouble(5,pData.getBillPayAmount2());
			xt28f_master_adj.addBatch();
			
		if (lineCount % 1000 == 0){
			xt28f_master_adj.executeBatch();
		}
			
		}catch (SQLException sqle){
			severe(StaticErrorMsgKeys.INSERT_ERROR + sqle.getMessage());
			 throw new Exception("Exception is from method process16XTSODE");
		}
		

	}
	
	private void prcessInputPaymentOverThreshold(PaymentData pData) throws SQLException, Exception {
		try {
			
			xt28f_input_paymeny.setString(1,pData.getCompanyId());
			xt28f_input_paymeny.setDate(2,sqlrun_date);
			xt28f_input_paymeny.setLong(3,pData.getBtn());
			xt28f_input_paymeny.setDouble(4,pData.getBillPayAmount1());
			xt28f_input_paymeny.setDouble(5,pData.getBillPayAmount2());
			xt28f_input_paymeny.addBatch();
			
		if (lineCount % 1000 == 0){
			xt28f_input_paymeny.executeBatch();
		}
			
		}catch (SQLException sqle){
			severe(StaticErrorMsgKeys.INSERT_ERROR + sqle.getMessage());
			 throw new Exception("Exception is from method process16XTSODE");
		}
		

	}
	
	private void prcessInputAdjustmentOverThreshold(PaymentData pData) throws SQLException, Exception {
		try {
			
			xt28f_input_adj.setString(1,pData.getCompanyId());
			xt28f_input_adj.setDate(2,sqlrun_date);
			xt28f_input_adj.setLong(3,pData.getBtn());
			xt28f_input_adj.setDouble(4,pData.getBillPayAmount1());
			xt28f_input_adj.setDouble(5,pData.getBillPayAmount2());
			xt28f_input_adj.addBatch();
			
		if (lineCount % 1000 == 0){
			xt28f_input_adj.executeBatch();
		}
			
		}catch (SQLException sqle){
			severe(StaticErrorMsgKeys.INSERT_ERROR + sqle.getMessage());
			 throw new Exception("Exception is from method process16XTSODE");
		}
		

	}
	
	private void prcessBalanceTransfer(PaymentData pData) throws SQLException, Exception {
		try {
			
			xt28f_balance_transfer.setString(1,pData.getCompanyId());
			xt28f_balance_transfer.setDate(2,sqlrun_date);
			xt28f_balance_transfer.setLong(3,pData.getBtn());
			xt28f_balance_transfer.setString(4,pData.getBusinessType());
			xt28f_balance_transfer.setDouble(5,pData.getBillPayAmount1());
			xt28f_balance_transfer.setDouble(6,pData.getBillPayAmount2());
			xt28f_balance_transfer.addBatch();
			
		if (lineCount % 1000 == 0){
			xt28f_balance_transfer.executeBatch();
		}
			
		}catch (SQLException sqle){
			severe(StaticErrorMsgKeys.INSERT_ERROR + sqle.getMessage());
			 throw new Exception("Exception is from method process16XTSODE");
		}
		

	}
	
	private void prcessNonPayment(PaymentData pData) throws SQLException, Exception {
		try {
			
			xt28f_non_payment.setString(1,pData.getCompanyId());
			xt28f_non_payment.setDate(2,sqlrun_date);
			xt28f_non_payment.setLong(3,pData.getBtn());
			xt28f_non_payment.setString(4,pData.getBusinessType());
			xt28f_non_payment.setDouble(5,pData.getBillPayAmount1());
			xt28f_non_payment.setDate(6,pData.getLastPaymentDate());
			xt28f_non_payment.addBatch();
			
		if (lineCount % 1000 == 0){
			xt28f_non_payment.executeBatch();
		}
			
		}catch (SQLException sqle){
			severe(StaticErrorMsgKeys.INSERT_ERROR + sqle.getMessage());
			 throw new Exception("Exception is from method process16XTSODE");
		}
		

	}
	
	
	public boolean postprocessFile(File file, boolean success) {
		try{
			//Log the file information to EMCIS_EVENT_LOG and EMCIS_EVENT_LOG_DETAIL
			EmcisEventLogger emcisLogger = new EmcisEventLogger();
			String event_id = "RABC_"+fileToken+"_WE";
            String host = NetUtil.getLocalHostName();
            String hostIP = NetUtil.getLocalIpAddress();
			int sequence = emcisLogger.getEMCISSequence(connection);
			emcisLogger.insertEventLog(connection, sequence, event_id, sqlrun_date, host, hostIP);
			emcisLogger.insertEventLogDetail(connection, sequence, "FileName", fileName);
			
		}catch (UnknownHostException e) {
            severe("Error getting EMCIS host information ", e);
        }
		if (success) {
			
			try {
				xt28f_deposit.executeBatch();
				xt28f_occ_over.executeBatch();
				xt28f_master_payment.executeBatch();
				xt28f_master_adj.executeBatch();
				xt28f_input_paymeny.executeBatch();
				xt28f_input_adj.executeBatch();
				xt28f_balance_transfer.executeBatch();
				xt28f_non_payment.executeBatch();
				
				Set tableData = acctTypeMap.entrySet();
				for (Iterator i = tableData.iterator(); i.hasNext();) {
					Map.Entry me = (Map.Entry)i.next();
			        String acctType = me.getKey().toString();
			        int actTypeCnt = Integer.parseInt(me.getValue().toString());
			        
			        xt28f_summary.setDate(1,sqlrun_date);
			        xt28f_summary.setString(2,division);
			        xt28f_summary.setString(3,acctType);
			        xt28f_summary.setInt(4,actTypeCnt);
			        xt28f_summary.execute();
				}
				
				if (!insertTrigger()) {
					severe(
						StaticErrorMsgKeys.POSTPROCESSFILE_ERROR
							+ StaticErrorMsgKeys.TIGGER_TABLE_INSERT_ERROR);
					success = false;
				}
				
			}catch (SQLException sqle){
				severe(StaticErrorMsgKeys.INSERT_ERROR + sqle.getMessage());
				success = false;
			}
			
			}
		return success;
	}

	
	public boolean postprocess(boolean success) {

		try {
			
			xt28f_deposit.close();
			xt28f_occ_over.close();
			xt28f_master_payment.close();
			xt28f_master_adj.close();
			xt28f_input_paymeny.close();
			xt28f_input_adj.close();
			xt28f_balance_transfer.close();
			xt28f_non_payment.close();


		} catch (SQLException e) {
			severe(
				StaticErrorMsgKeys.POSTPROCESS_ERROR
					+ StaticErrorMsgKeys.SQL_CLOSE_ERROR
					+ e);
			success = false;
		}

		return super.postprocess(success);
	}

	private boolean insertTrigger() {

		 if(!RabcLoadJobTrig.insertTrigger(connection,currentFile.getName(),"CN28100F",division,run_date,backoutRecovery,bill_rnd))
			return false;
		 
		 if (nevadaBellData)
		 	if(!RabcLoadJobTrig.insertTrigger(connection,currentFile.getName(),"CN28100F","NB",run_date,backoutRecovery,bill_rnd))
				return false;
		 
		return true;
		
	}
}
