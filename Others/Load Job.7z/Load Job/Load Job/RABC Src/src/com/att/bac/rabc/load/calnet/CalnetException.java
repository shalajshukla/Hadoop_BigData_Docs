/* Created by Peter Foo (pf7941) on Dec 1, 2006.
Copyright 2006-2008 AT&T Knowledge Ventures. All rights reserved. */

package com.att.bac.rabc.load.calnet;

public class CalnetException extends Exception {

	public CalnetException() {

		super();
		// TODO Auto-generated constructor stub
	}

	public CalnetException(String arg0) {

		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public CalnetException(Throwable arg0) {

		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public CalnetException(String arg0, Throwable arg1) {

		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

}
