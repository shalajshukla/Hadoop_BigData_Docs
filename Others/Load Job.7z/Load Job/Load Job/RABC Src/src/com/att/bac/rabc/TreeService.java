/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.att.bac.rabc.admin.PresnCalcElem;
import com.att.bac.rabc.admin.PresnCalcElemDAO;

/**
 * This is a service class which cater the business logic to populate the tree object
 * to be shown on the pages.
 * 
 * @author Vijay Dubey - VD3159
 */
public class TreeService {
	private static final Logger logger = Logger.getLogger(TreeService.class);
	
	protected static final String getViewsMap = "select distinct a.alert_proc_tbl, b.view_name, a.tbl_subsys_id " 
											+ "from rabc_data_tbl_ddl a, rabc_view b, rabc_table c " 
											+ "where a.alert_proc_tbl = b.table_name "
											+ "AND UPPER(A.TBL_SUBSYS_ID) IN (SELECT DISTINCT DB_NODE_ID from rabc_db_node) "
											+ "AND UPPER(C.TBL_NODE) IN (SELECT DISTINCT DB_NODE_ID from rabc_db_node) "
											+ "order by a.alert_proc_tbl";
	
	protected static final String GetCalc = "SELECT PRESN_CALC_NAME, PRESN_CALC_NUM, CALC_ELEM_FORMULA,CALC_ELEM_USER_VIEW, "
										+ "CALC_DIV_IND, CALC_ELEM_DISPLAY, CALC_DISPLAY_ELEM, PRESN_FORMAT_CODE,CALC_TBL,CALC_ELEM_SQL_FORMULA "
										+ "FROM RABC_PRESN_CALC_ELEM";
	
	/**
	 * Method to generate the Tree object & pass it to the caller. 
	 * This method builds the tree object containing list of tables as well as calculation objects. 
	 * It is upto the respective JSP to render the elements that it requires. 
	 * Following is the algorithm followed
	 * 	1) Get the list of objects corresponding to the RABC_DATA_TBL_DDL table such that 
	 * 	   the system id is a DB_NODE in RABC_DB_NODE using corresponding DAO.
	 * 	2) Form a hash map of views with key as table name [DDL name]--> Custom method here.
	 * 	3) Form a hash map of table description with key as table name [DDL name]--> Custom method here.
	 * 	4) Get list of calculation objects from RABC_CALC_ELEM table using corresponding DAO.
	 * 	5) Call getNodeList() method which takes results of above 4 steps as input & generates 
	 * 	   a Tree with list of nodes.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param region
	 * @return Tree
	 */
	public Tree generateTree(Connection connection, List failureList, List args, String region){
		/*
		 * Call the getViews() method to return list of views such that their table is included in the 
		 * RABC_data_tbl_ddl table & table node is present in RABC_DB_NODE. Returned map will contain views 
		 * within a table
		 */ 
		HashMap viewsMap = getViews(connection,failureList);
		
		/*
		 * Get the table description
		 */
		HashMap tableMap = getTableName(connection,failureList,region);
		
		/*
		 * Get the table-calculations map.
		 */
		HashMap calculationsMap = getCalculations(connection,failureList);

		/*
		 * Form the nodes
		 */
		List treeNodeList = getTreeNodeList(viewsMap, calculationsMap, tableMap, connection, failureList, region);
		Tree tree = new Tree();
		for (int i=0;i< treeNodeList.size();i++){
			tree.addNode((TreeNode)treeNodeList.get(i));
		}
		
		return tree;
	}
	
	/**
	 * Method to return the list of calculations.
	 * 
	 * @param connection
	 * @param failureList
	 * @return List
	 */
	private List getCalculationList(Connection connection, List failureList){
		List args = new ArrayList();
		
		PresnCalcElemDAO presnCalcElemDAO = new PresnCalcElemDAO();
		List calculationsList = presnCalcElemDAO.get(connection, failureList, args,TreeService.GetCalc);
		
		return calculationsList;
	}
	
	/**
	 * Method to return a map of views per table.
	 * 
	 * @param connection
	 * @param failureList
	 * @return HashMap
	 */
	private HashMap getViews(Connection connection, List failureList) {
		HashMap viewMap = null;
		String currentTableName = null;
		String previousTableName = null;
		String currentViewName = null;
		List viewNameList = new ArrayList();
		boolean addFlag = false;
		String sqlStmt = null;
		
		Statement statement = null;
		ResultSet rs = null;
		try {
			viewMap = new HashMap();
			sqlStmt = TreeService.getViewsMap;
			statement = connection.createStatement();
			rs = statement.executeQuery(sqlStmt);
			
			while(rs.next()){
				addFlag = false;
				currentTableName = rs.getString("ALERT_PROC_TBL");

				if (previousTableName==null){
					previousTableName = currentTableName ;
				}
								
				if (!previousTableName.equals(currentTableName)){
					viewMap.put(previousTableName,viewNameList);
					previousTableName = currentTableName ;
					viewNameList = new ArrayList();
					addFlag = true;
				}
				
				viewNameList.add(rs.getString("VIEW_NAME"));
			}
			if (previousTableName!=null){
				viewMap.put(previousTableName,viewNameList);
			}
		} catch(SQLException sqle){
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sqle.getMessage(), sqle);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sqle));
		} finally{
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(statement, failureList, logger);
		}
		
		return viewMap;
	}
	
	/**
	 * Method to return a map of table objects such that 
	 * the key is the table & value is the table description.
	 * 
	 * @param connection
	 * @param failureList
	 * @param region
	 * @return HashMap
	 */
	private HashMap getTableName(Connection connection, List failureList, String region){
		HashMap tableMap = new HashMap();
		List rabcTableList = StaticDataLoader.getRabcTableList(region);
		
		int size = rabcTableList.size();
		
		for (int i=0;i<size;i++){
			PickList rabcTable = (PickList)rabcTableList.get(i);
			String tableName = rabcTable.getKey();
			String tableDesc = rabcTable.getValue1();
			tableMap.put(tableName,tableDesc);
		}

		return tableMap;
	}
	
	/**
	 * Private method to return the list of distinct database nodes.
	 * 
	 * @param region
	 * @return List
	 */
	private List getDistinctDbNodeList(String region){
		List dbNodeList = StaticDataLoader.getDBNodeList(region);
		List distinctDbNodeList = new ArrayList();
		
		int dbNodeListSize = dbNodeList.size();
		
		for (int i=0;i<dbNodeListSize;i++){
			PickList dbNode = (PickList)dbNodeList.get(i);
			boolean addFlag = true;
			
			int distinctDbNodeListSize = 0;
			if (!distinctDbNodeList.isEmpty()){
				distinctDbNodeListSize = distinctDbNodeList.size();
			}
			
			for (int j=0;j<distinctDbNodeListSize;j++){
				PickList existingDbNode = (PickList)distinctDbNodeList.get(j);
				
				if (dbNode.getKey().equals(existingDbNode.getKey())){
					addFlag = false;
				}
			}
			
			if (addFlag==true){
				distinctDbNodeList.add(dbNode);
			}
		}
		
		return distinctDbNodeList;
	}
	
	/**
	 * Method to return nodes for calculations.
	 * 
	 * @param connection
	 * @param failureList
	 * @return TreeNode
	 */
	public TreeNode getCalculationNode(Connection connection, List failureList){
		List calculationsList = getCalculationList(connection,failureList);
		TreeNode calculationNode = new TreeNode();
		calculationNode.setNodeName("Calculations");
		calculationNode.setNodeValue("Calculations");
		calculationNode.setNodeType("CALCULATIONNODE");
		for (int i=0; i < calculationsList.size();i++){
			calculationNode.addNodeElement((PresnCalcElem)calculationsList.get(i));
		}
		
		return calculationNode;
	}
	
	/**
	 * Method to return the list of DataTblDdlBean.
	 * @param dbNodeId
	 * @param region
	 * @return List
	 */
	public List getDataTblDdlList(String dbNodeId, String region){
		return StaticDataLoader.getDataTblDdlByTblSubsysId(dbNodeId, region);
	}
	
	/**
	 * 1) Create a node for "Create View"
	 * 2) Create a node for all calculations
	 * 3) Create a node for "Tables"
	 * 		a) Under "Tables" form nodes for unique TBL_SUBSYS_ID
	 * 		b) Under each TBL_SUBSYS_ID for nodes for unique ALERT_PROC_TBL
	 * 		c) Under each ALERT_PROC_TBL form nodes for unique Views & columns [TBL_DDL_NAME]
	 * 4) Add all 3 nodes to nodeelementList of Tree ALERT_PROC_TBL
	 * 5) Return tree
	 */
	
	/**
	 * Method to return the list of nodes to be shown.
	 * 
	 * @param viewsMap
	 * @param calculationsMap
	 * @param tableMap
	 * @param connection
	 * @param failureList
	 * @param region
	 * @return List
	 */
	private List getTreeNodeList(HashMap viewsMap, HashMap calculationsMap, HashMap tableMap, Connection connection, List failureList, String region){
		List treeNodeList = new ArrayList(); // List of nodes under the tree
		String currentSysID = null; // TBL_SUBSYS_ID for current column
		String previousSysID = null; // variable to store TBL_SUBSYS_ID when it changes
		String currentTableName = null; // ALERT_PROC_TBL for current column
		String previousTableName = null; // Variable to store ALERT_PROC_TBL when it changes
		String currentColumnName = null; // TBL_DDL_NAME for current column
		String previousColumnName = null; // Variable to store TBL_DDL_NAME when it changes
		String currentColumnDataType = null; // TBL_DDL_DATA_TYPE for current column
		String previousColumnDataType = null; // Variable to store TBL_DDL_DATA_TYPE when it changes
		List sysIdList = new ArrayList(); // List to store nodes corresponding to unique TBL_SUBSYS_ID
		List tableList = new ArrayList();// List to store nodes corresponding to unique ALERT_PROC_TBL
		List columnList = new ArrayList();// List to store nodes corresponding to unique TBL_DDL_NAME
		List viewList = new ArrayList(); // List to store nodes corresponding to views
		List nodeElementList = new ArrayList(); // Final List to store nodes under the tree
		List tablesList = new ArrayList(); // Node corresponding to the "Tables" node
		List calculationList = new ArrayList(); // List to store nodes corresponding to calculations
		
		/*
		 * Node for Create View functionality
		 */
		TreeNode createViewNode = new TreeNode();
		createViewNode.setNodeName("Create View");
		createViewNode.setNodeValue("Create View");
		createViewNode.setNodeType("CREATEVIEWNODE");
		nodeElementList.add(createViewNode);
		
		/*
		 * Node for Create Calculation functionality
		 */
		TreeNode createCalculationNode = new TreeNode();
		createCalculationNode.setNodeName("Create Calculation");
		createCalculationNode.setNodeValue("Create Calculation");
		createCalculationNode.setNodeType("CREATECALCULATIONNODE");
		nodeElementList.add(createCalculationNode);
		
		/*
		 * Node for Calculation. Loop through the list of calculation element objects & create a node for each with 
		 * type as CALCULATIONNODE
		 */
		/*
		 * Call method getCalculationList()to get list of calculation objects
		 */
		TreeNode calculationNode = getCalculationNode(connection,failureList);
		if (calculationNode!=null){
			nodeElementList.add(calculationNode);
		}

		/*
		 * Node for Tables Node functionality. 
		 * 1) Tables will contain nodes for System IDs. 
		 * 2) Under each sys id, we will have nodes for tables [with table description]
		 * 3) Under each table there will be a list of views & list of columns
		 * 4) Under each view there will be list of columns
		 */
		TreeNode tablesNode = new TreeNode();
		tablesNode.setNodeName("Tables");
		tablesNode.setNodeValue("Tables");
		tablesNode.setNodeType("TABLENODE");
		
		List dbNodeList = getDistinctDbNodeList(region);
		int dbNodeListSize = dbNodeList.size();
		
		for (int i=0;i<dbNodeListSize;i++){
			PickList dbNode = (PickList)dbNodeList.get(i);
			String dbNodeId = dbNode.getKey();
			
			/*
			 * Code to arrange table nodes in alphabatical order by their name description.
			 */
			List dataTblDdlList = new ArrayList();
			List unsortedDataTblDdlList = getDataTblDdlList(dbNodeId, region);
			int unsortedDataTblDdlListSize = unsortedDataTblDdlList.size();
			List rabcTableList = StaticDataLoader.getRabcTableList(region);
			int rabcTableListSize =rabcTableList.size();
			for (int x=0;x<rabcTableListSize;x++){
				PickList tableObj = (PickList)rabcTableList.get(x);
				for (int y=0;y<unsortedDataTblDdlListSize;y++){
					DataTblDdlBean dataTblDdl = (DataTblDdlBean) unsortedDataTblDdlList.get(y);
					if (dataTblDdl.getAlertProcTbl().equalsIgnoreCase(tableObj.getKey())){
						dataTblDdlList.add(dataTblDdl);
					}
				}
			}
			
			int dataTblDdlListSize = dataTblDdlList.size();
			
			for (int j=0;j<dataTblDdlListSize;j++){
				DataTblDdlBean dataTblDdl = (DataTblDdlBean)dataTblDdlList.get(j);
				
				currentSysID = dataTblDdl.getTblSubsysId();
				currentTableName = dataTblDdl.getAlertProcTbl();
				currentColumnName = dataTblDdl.getTblDdlName();
				currentColumnDataType = dataTblDdl.getTblDdlDataType();
				boolean hasTableChanged = false;
				
				if (previousSysID==null){
					previousSysID = currentSysID ;
				}
				if (previousTableName == null){
					previousTableName = currentTableName;
				}
				if (previousColumnDataType==null){
					previousColumnDataType=currentColumnDataType;
				}
				
				hasTableChanged = false;
				
				/*
				 * Form a node of table when the table DDL name changes. This is possible since the SQL query for 
				 * columns has an order by clause sorting the columns by table name
				 */
				if (!previousTableName.equals(currentTableName)){
					if (tableMap.get(previousTableName) != null) {
						TreeNode tableNode = new TreeNode();
						tableNode.setNodeName((String) tableMap.get(previousTableName));
						tableNode.setNodeValue(previousTableName);
						tableNode.setNodeType("TABLE");
						
						/*
						 * Get the list of views for this table from the respective HashMap using the table DDL name 
						 * as key
						 */
						viewList = (ArrayList) viewsMap.get(previousTableName);
	
						/*
						 * Check whether viewList is empty if not then loop through the same & create corresponding nodes,
						 * one for each view & within each view 1 for each column
						 */
						if (viewList!=null){
							if (!viewList.isEmpty()){
								for (int k=0;k<viewList.size();k++){
									TreeNode viewNode = new TreeNode();
									viewNode.setNodeName((String) viewList.get(k));
									viewNode.setNodeValue((String) viewList.get(k));
									viewNode.setNodeType("VIEW");
									String sourceTable = null;
									/*
									 * Use the column list obtained so far to create the nodes. The columns for the view
									 * are same as those for the parent table
									 */
									for (int columnCount=0;columnCount<columnList.size();columnCount++){
										Column refColumn = (Column)columnList.get(columnCount);
										Column viewColumn = new Column();
										viewColumn.setColumnAlertProcTBL(refColumn.getColumnAlertProcTBL());
										sourceTable = refColumn.getColumnAlertProcTBL();
										viewColumn.setColumnTBLDDLName(refColumn.getColumnTBLDDLName());
										viewColumn.setColumnTBLDataType(refColumn.getColumnTBLDataType());
										viewColumn.setColumnTBLDDLPRESCSNFormatType(refColumn.getColumnTBLDDLPRESCSNFormatType());
										viewColumn.setColumnViewName(viewNode.getNodeValue());
										viewNode.addNodeElement(viewColumn);
									}
									
									/*
									 * Get the list of calculations for this view from the respective HashMap using the view name 
									 * as key
									 */
									calculationList = (ArrayList) calculationsMap.get(viewNode.getNodeValue());
	
									/*
									 * Check whether calculationList is empty if not then loop through the same & create corresponding nodes,
									 * one for each calculation
									 */
									if (calculationList!=null) {
										if (!calculationList.isEmpty()) {
											TreeNode calcNode = new TreeNode();
											calcNode.setNodeName("Calculations");
											calcNode.setNodeValue("Calculations");
											calcNode.setNodeType("CALCULATIONNODE");
											
											for (int l=0;l<calculationList.size();l++) {
												PresnCalcElem presnCalcElem = (PresnCalcElem) calculationList.get(l);
												Column calculationColumn = new Column();
												calculationColumn.setColumnAlertProcTBL(sourceTable);
												calculationColumn.setColumnTBLDDLName(presnCalcElem.getPresnCalcName());
												calculationColumn.setColumnTBLDataType("CAL");
												calculationColumn.setColumnTBLDDLPRESCSNFormatType(presnCalcElem.getPresnFormatCode());
												calculationColumn.setColumnDescription(presnCalcElem.getCalcElemFormula());
												calculationColumn.setColumnViewName(viewNode.getNodeValue());
												calcNode.addNodeElement(calculationColumn);
											}
											viewNode.addNodeElement(calcNode);
										}	
										calculationList.clear();
									}
									
									tableNode.addNodeElement(viewNode);
								}
								
								viewList.clear();
							}
						}
						
						/*
						 * Get the list of calculations for this table from the respective HashMap using the table DDL name 
						 * as key
						 */
						calculationList = (ArrayList) calculationsMap.get(previousTableName);
	
						/*
						 * Check whether calculationList is empty if not then loop through the same & create corresponding nodes,
						 * one for each calculation
						 */
						if (calculationList!=null) {
							if (!calculationList.isEmpty()) {
								TreeNode calcNode = new TreeNode();
								calcNode.setNodeName("Calculations");
								calcNode.setNodeValue("Calculations");
								calcNode.setNodeType("CALCULATIONNODE");
								
								for (int k=0;k<calculationList.size();k++) {
									PresnCalcElem presnCalcElem = (PresnCalcElem) calculationList.get(k);
									Column calculationColumn = new Column();
									calculationColumn.setColumnAlertProcTBL(previousTableName);
									calculationColumn.setColumnTBLDDLName(presnCalcElem.getPresnCalcName());
									calculationColumn.setColumnTBLDataType("CAL");
									calculationColumn.setColumnTBLDDLPRESCSNFormatType(presnCalcElem.getPresnFormatCode());
									calculationColumn.setColumnDescription(presnCalcElem.getCalcElemFormula());
									calcNode.addNodeElement(calculationColumn);
								}
								tableNode.addNodeElement(calcNode);
							}	
							calculationList.clear();
						}
						
						/*
						 * Columns under the respective tables, use the column list obtained above & create a new column list 
						 * for the previous table
						 */
						for (int columnCount=0;columnCount<columnList.size();columnCount++){
							Column column1 = (Column)columnList.get(columnCount);
							tableNode.addNodeElement((Column)columnList.get(columnCount));
						}
						tableList.add(tableNode);
					}
					
					previousTableName = currentTableName ;
					hasTableChanged = true;
					columnList = new ArrayList();
				}
				
				/*
				 * Preparing the list of columns & adding it to a list
				 */
				if (previousColumnName == null){
					Column column = new Column(dataTblDdl);
					columnList.add(column);
					previousColumnName = currentColumnName;
				}else if (!previousColumnName.equals(currentColumnName)){
					Column column = new Column(dataTblDdl);
					columnList.add(column);
					previousColumnName = currentColumnName;
					previousColumnDataType = currentColumnDataType;
				}else if (previousColumnName.equals(currentColumnName) && hasTableChanged){
					Column column = new Column(dataTblDdl);
					columnList.add(column);
					previousColumnName = currentColumnName;
					previousColumnDataType = currentColumnDataType;
				}else {
					if (!previousColumnDataType.equals(currentColumnDataType)){
						Column column = new Column(dataTblDdl);
						columnList.add(column);
						previousColumnName = currentColumnName;
						previousColumnDataType = currentColumnDataType;
					}
				}
				
				if (!previousSysID.equals(currentSysID)){
					TreeNode sysIdNode = new TreeNode();
					sysIdNode.setNodeName(previousSysID);
					sysIdNode.setNodeType("SYSTEMNODE");

					for (int tableCount=0;tableCount<tableList.size();tableCount++){
						TreeNode str = (TreeNode)tableList.get(tableCount);
						sysIdNode.addNodeElement((TreeNode)tableList.get(tableCount));
					}
					
					tablesNode.addNodeElement(sysIdNode);
					previousSysID = currentSysID;
					tableList = new ArrayList();
				}
				
			}
			
			/*
			 * Add columns for the last table within the System node
			 */
			if (previousTableName!=null){
				if (tableMap.get(previousTableName) != null) {
					TreeNode tableNode = new TreeNode();
					tableNode.setNodeName((String) tableMap.get(previousTableName));
					tableNode.setNodeValue(previousTableName);
					tableNode.setNodeType("TABLE");
					
					/*
					 * Get the list of views for this table from the respective HashMap using the table DDL name 
					 * as key
					 */
					viewList = (ArrayList) viewsMap.get(previousTableName);
	
					/*
					 * Check whether viewList is empty if not then loop through the same & create corresponding nodes,
					 * one for each view & within each view 1 for each column
					 */
					if (viewList!=null){
						if (!viewList.isEmpty()){
							for (int k=0;k<viewList.size();k++){
								TreeNode viewNode = new TreeNode();
								viewNode.setNodeName((String) viewList.get(k));
								viewNode.setNodeValue((String) viewList.get(k));
								viewNode.setNodeType("VIEW");
								String sourceTable = null;
								
								/*
								 * Use the column list obtained so far to create the nodes. The columns for the view
								 * are same as those for the parent table
								 */
								for (int columnCount=0;columnCount<columnList.size();columnCount++){
									Column refColumn = (Column)columnList.get(columnCount);
									Column viewColumn = new Column();
									viewColumn.setColumnAlertProcTBL(refColumn.getColumnAlertProcTBL());
									sourceTable = refColumn.getColumnAlertProcTBL();
									viewColumn.setColumnTBLDDLName(refColumn.getColumnTBLDDLName());
									viewColumn.setColumnTBLDataType(refColumn.getColumnTBLDataType());
									viewColumn.setColumnTBLDDLPRESCSNFormatType(refColumn.getColumnTBLDDLPRESCSNFormatType());
									viewColumn.setColumnViewName(viewNode.getNodeValue());
									viewNode.addNodeElement(viewColumn);
								}
								
								/*
								 * Get the list of calculations for this view from the respective HashMap using the view name 
								 * as key
								 */
								calculationList = (ArrayList) calculationsMap.get(viewNode.getNodeValue());
	
								/*
								 * Check whether calculationList is empty if not then loop through the same & create corresponding nodes,
								 * one for each calculation
								 */
								if (calculationList!=null) {
									if (!calculationList.isEmpty()) {
										TreeNode calcNode = new TreeNode();
										calcNode.setNodeName("Calculations");
										calcNode.setNodeValue("Calculations");
										calcNode.setNodeType("CALCULATIONNODE");
										
										for (int l=0;l<calculationList.size();l++) {
											PresnCalcElem presnCalcElem = (PresnCalcElem) calculationList.get(l);
											Column calculationColumn = new Column();
											calculationColumn.setColumnAlertProcTBL(sourceTable);
											calculationColumn.setColumnTBLDDLName(presnCalcElem.getPresnCalcName());
											calculationColumn.setColumnTBLDataType("CAL");
											calculationColumn.setColumnTBLDDLPRESCSNFormatType(presnCalcElem.getPresnFormatCode());
											calculationColumn.setColumnDescription(presnCalcElem.getCalcElemFormula());
											calculationColumn.setColumnViewName(viewNode.getNodeValue());
											calcNode.addNodeElement(calculationColumn);
										}
										viewNode.addNodeElement(calcNode);
									}	
									calculationList.clear();
								}
								
								tableNode.addNodeElement(viewNode);
							}
							
							viewList.clear();
						}
					}
					
					/*
					 * Get the list of calculations for this table from the respective HashMap using the table DDL name 
					 * as key
					 */
					calculationList = (ArrayList) calculationsMap.get(previousTableName);
	
					/*
					 * Check whether calculationList is empty if not then loop through the same & create corresponding nodes,
					 * one for each calculation
					 */
					if (calculationList!=null) {
						if (!calculationList.isEmpty()) {
							TreeNode calcNode = new TreeNode();
							calcNode.setNodeName("Calculations");
							calcNode.setNodeValue("Calculations");
							calcNode.setNodeType("CALCULATIONNODE");
							
							for (int k=0;k<calculationList.size();k++) {
								PresnCalcElem presnCalcElem = (PresnCalcElem) calculationList.get(k);
								Column calculationColumn = new Column();
								calculationColumn.setColumnAlertProcTBL(previousTableName);
								calculationColumn.setColumnTBLDDLName(presnCalcElem.getPresnCalcName());
								calculationColumn.setColumnTBLDataType("CAL");
								calculationColumn.setColumnTBLDDLPRESCSNFormatType(presnCalcElem.getPresnFormatCode());
								calculationColumn.setColumnDescription(presnCalcElem.getCalcElemFormula());
								calcNode.addNodeElement(calculationColumn);
							}
							tableNode.addNodeElement(calcNode);
						}	
						calculationList.clear();
					}
					
					for (int columnCount=0;columnCount<columnList.size();columnCount++){
						tableNode.addNodeElement((Column)columnList.get(columnCount));
					}
					tableList.add(tableNode);
				}
			}

			/*
			 * Add tables for last Sys Id
			 */
			TreeNode sysIdNode = new TreeNode();
			sysIdNode.setNodeName(previousSysID);
			sysIdNode.setNodeType("SYSTEMNODE");
			
			if (!tableList.isEmpty()){
				for (int tableCount=0;tableCount<tableList.size();tableCount++){
					sysIdNode.addNodeElement((TreeNode)tableList.get(tableCount));
				}
			}
			
			tablesNode.addNodeElement(sysIdNode);	
		}
		
		nodeElementList.add(tablesNode);
		return nodeElementList;
	}
	
	/**
	 * A method to return a map of calculations per table.
	 * 
	 * @param connection
	 * @param failureList
	 * @return HashMap
	 */
	public HashMap getCalculations(Connection connection, List failureList) {
		return new HashMap();
	}
	
}
