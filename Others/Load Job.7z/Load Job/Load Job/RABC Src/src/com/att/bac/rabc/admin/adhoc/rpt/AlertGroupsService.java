/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.admin.adhoc.rpt;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;

import com.att.bac.rabc.PickList;
import com.att.bac.rabc.admin.AlertGroup;
import com.att.bac.rabc.admin.AlertGroupDAO;
import com.att.bac.rabc.admin.AlertGroupUser;
import com.att.bac.rabc.admin.AlertGroupUserDAO;

import java.sql.Connection;

/**
 * Module description: 
 * 
 * This is the alert group popup service.
 *
 * @author Anup Thomas - AT1862
 */
public class AlertGroupsService {
	private static final Logger logger = Logger.getLogger(AlertGroupsService.class);
	private static AlertGroupsService alertGroupsService;
	
	/*
	 * Variables to represent the sql statements.
	 */
	public static final String  qAlertGrp = "SELECT DISTINCT alert_grp,alert_grp_desc ,funct_cd,pnt_alert_grp_ind "
										+   " FROM 	rabc_alert_grp ORDER BY	UPPER(alert_grp)";
	
	public static final String qAlertUsers = "SELECT	DISTINCT TRIM(UPPER(user_id)) AS  user_id,alert_grp " 
											+ "FROM rabc_alert_grp_user ORDER BY UPPER(alert_grp)";
	
	/**
	 * Synchronized method to ensure that there is a single instance of this class created & used for all instances
	 * of action. It is ensured that there are no data members in the class
	 * 
	 * @return AlertGroupsService
	 */
	public static synchronized AlertGroupsService getAlertGroupsService(){
		if (alertGroupsService == null){
			alertGroupsService = new AlertGroupsService();
		}	
		return alertGroupsService;
	}
	
	/**
	 * This method is used to get the list of alert groups
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return List
	 */
	public List getAlertGroupList(Connection connection,List failureList,List args){
		List alertGroupList = new ArrayList();
		List alertGroupPickList = new ArrayList();
		AlertGroupDAO alertGroupDAO = new AlertGroupDAO();
	
		/*
		 * instead of querying database frequently , store the data from the table rabc_alert_grp_user into 
		 * a 2D array . 
		 */
		String [][] alertGroupUserArray;
		alertGroupUserArray = getAlertGroupUserArray(connection,failureList,args,qAlertUsers);
	
		alertGroupList = alertGroupDAO.get(connection,failureList,args,qAlertGrp);
		
		int alertGroupListSize = alertGroupList.size();
		for (int i=0;i<alertGroupListSize;i++){
			AlertGroup alertGroup = (AlertGroup)alertGroupList.get(i);
			String userList = getAlertGroupUsers(alertGroupUserArray,alertGroup.getAlertGrp());
			
			if (userList!=null){ 
				userList = userList.substring(1) ; 
				alertGroupPickList.add(new PickList(alertGroup.getAlertGrpDesc(),userList));
			}
		}
		
		return (alertGroupPickList);
	}
	
	/**
	 * Private method returning the list of alert groups as 2 dimensional array
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param qAlertUsers
	 * @return String[][]
	 */
	private String[][] getAlertGroupUserArray(Connection connection,List failureList,List args,String qAlertUsers){
		AlertGroupUserDAO alertGroupUserDAO = new AlertGroupUserDAO();
		
		List alertGroupUserList = new ArrayList();
		alertGroupUserList = alertGroupUserDAO.get(connection,failureList,args,qAlertUsers);
		int alertGroupUserListSize = alertGroupUserList.size();
		String [][] alertGroupUserArray= new String [alertGroupUserListSize][2];
		
		for (int i=0;i<alertGroupUserListSize;i++){
			AlertGroupUser alertGroupUser = (AlertGroupUser) alertGroupUserList.get(i);
			alertGroupUserArray[i][0] = alertGroupUser.getAlertGrp();
			alertGroupUserArray[i][1] = alertGroupUser.getUserId();
		}
		return alertGroupUserArray;
	}
	
	/**
	 * Private method returning the string for alert group users
	 * @param alertGroupUserArray
	 * @param key
	 * @return String
	 */
	private String getAlertGroupUsers(String [][] alertGroupUserArray,String key ){
		StringBuffer alertGroupUsers=new StringBuffer();
		
		int alertGroupUserArraySize= alertGroupUserArray.length;
		for (int i=0;i<alertGroupUserArraySize;i++){
			if (key.equals(alertGroupUserArray[i][0])){
				if ("".equals(alertGroupUsers)){
					alertGroupUsers.append(alertGroupUserArray[i][1]);
				}else{
					alertGroupUsers.append(",");
					alertGroupUsers.append(alertGroupUserArray[i][1]);
				}	
			}
		}
		
		if (alertGroupUsers.length()<=0){
			return null;
		}else {
			return alertGroupUsers.toString();
		}
	}
}
