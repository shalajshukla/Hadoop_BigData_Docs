/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.adhoc.rpt;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;

import javax.naming.NamingException;

import org.apache.log4j.Logger;

import com.att.bac.rabc.ConnectionManager;
import com.att.bac.rabc.DataTblDdlBean;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.StaticDataLoader;
import com.att.bac.rabc.adhoc.aria.ARIAReportRABC;
import com.att.bac.rabc.adhoc.rpt.generator.AbstractAdhocGenerator;
import com.att.bac.rabc.adhoc.rpt.generator.AdhocGeneratorFactory;
import com.att.bac.rabc.adhoc.rpt.generator.Calculation;
import com.att.carat.util.JDBCUtil;


/**
 * Implementation of the AdhocRptDAO interface
 * 
 * <p>
 * <hr>
 * <h3>Release History</h3>
 * <p>
 * <ul>
 * <li>PD2951 20051216 Initial version for EAP 556010
 * <li>jb6494 Aug 11, 2006 Created class. *
 * <li>jb6494 Mar 13, 2007 ML18 Calculations on views
 * <li>jb6494 Mar 13, 2007 AL11 Calculations on views - view replace loop was wrong
 * </ul>
 * <p>
 * 
 */
public class AdhocRptDAO {
    private static final String QRY_GET_TBL_FROM_VIEW = "SELECT DISTINCT TABLE_NAME FROM RABC_VIEW WHERE view_name = ? or upper(view_name)=?";

    private static final String DATEFORMAT = "MM/dd/yyyy";

    private static final String EMPTY = "";

    private static final Logger logger = Logger.getLogger(AdhocRptDAO.class);

    private static final String NO_VALUE = "N";

    private static final String NON_RABC_DB_NODE = "SYSTEM";

    private static final String QRY_GET_EXEC_PRESN_SEQ_NUM_ACTIVE = "SELECT DISTINCT EXEC_PRESN_SEQ_NUM " + "FROM RABC_PRESN_ID " + "WHERE PRESN_ID = ? " + "AND UPPER(ADHOC_RPT_STATUS) = 'ACTIVE' " + "ORDER BY EXEC_PRESN_SEQ_NUM";

    private static final String QRY_GET_EXEC_PRESN_SEQ_NUM_NOT_DELETE = "SELECT DISTINCT EXEC_PRESN_SEQ_NUM " + "FROM RABC_PRESN_ID " + "WHERE PRESN_ID = ? " + "AND UPPER(ADHOC_RPT_STATUS) != 'DELETE' " + "ORDER BY EXEC_PRESN_SEQ_NUM";

    private static final String QRY_GET_FILE_SEQ_NUM_IND = "SELECT FILE_SEQ_NUM_IND " + "FROM RABC_ALERT_RULE_PRESN_RULE " + "WHERE PRESN_ID = ? " + "AND WEBID = ? " + "AND EXEC_PRESN_SEQ_NUM = 1 " + "AND ROWNUM = 1";

    private static final String QRY_GET_MAX_PROC_DATE = "SELECT TO_CHAR(MAX(TIME_STAMP),''MM/DD/YYYY'') MAXPROCDATE " + "FROM RABC_TRIG " + "WHERE FILE_SEQ_NUM = {0} " + "AND DIVISION IN ({1})";

    private static final String QRY_GET_MOUSE_OVER = "SELECT LINK_TBL_KEY_NAME " + ",LINK_TBL_KEY_DATA " + ",LINK_TBL_NAME " + "FROM RABC_MOUSE_OVER_LINK " + "WHERE PRESN_ID = ? " + "AND WEBID = ? " + "AND EXEC_PRESN_SEQ_NUM = ? " + "AND MOUSE_OVER_NUM  = ? ";

    private static final String QRY_GET_PARTI_REF_ID = "SELECT PARTI_REF_ID " + "FROM RABC_ALERT_RULE " + "WHERE PRESN_ID = ?";

    private static final String QRY_GET_PRESN_ELEM = "SELECT * FROM RABC_PRESN_ELEM_VIEW " + "WHERE PRESN_ID = ? " + "AND WEBID = ? " + "AND EXEC_PRESN_SEQ_NUM = ? ";

    private static final String QRY_GET_PRESN_RULE = "SELECT * FROM RABC_PRESN_RULE_VIEW " + "WHERE PRESN_ID = ? " + "AND WEBID = ? " + "AND EXEC_PRESN_SEQ_NUM = ? order by view_name desc ";

    private static final String QRY_GET_PRESN_TABLE_ACTIVE = "SELECT DISTINCT PRESN_TBL_NAME " + ",PROC_DATE_DDL_NAME " + ",NVL(DIVISION_NAME_KEY_LVL,0) DIVISION_NAME_KEY_LVL " + ",BEG_SUB_TOT_LVL " + ",END_SUB_TOT_LVL " + ",PRESN_MODEL " + ",ADHOC_RPT_IND " + ",ADHOC_RPT_STATUS " + ",DB_NODE_ID " + ",EFF_DT " + ",PRESN_TREND_TIME " + ",TIMING_FILTER_CODE " + ",PRESN_DUR_TIME " + "FROM RABC_PRESN_ID " + "WHERE PRESN_ID = ? " + "AND EXEC_PRESN_SEQ_NUM = ? " + "AND UPPER(ADHOC_RPT_STATUS) = 'ACTIVE' ";

    private static final String QRY_GET_PRESN_TABLE_NOT_DELETE = "SELECT DISTINCT PRESN_TBL_NAME " + ",PROC_DATE_DDL_NAME " + ",NVL(DIVISION_NAME_KEY_LVL,0) DIVISION_NAME_KEY_LVL " + ",BEG_SUB_TOT_LVL " + ",END_SUB_TOT_LVL " + ",PRESN_MODEL " + ",ADHOC_RPT_IND " + ",ADHOC_RPT_STATUS " + ",DB_NODE_ID " + ",EFF_DT " + ",PRESN_TREND_TIME " + ",TIMING_FILTER_CODE " + ",PRESN_DUR_TIME " + "FROM RABC_PRESN_ID " + "WHERE PRESN_ID = ? " + "AND EXEC_PRESN_SEQ_NUM = ? " + "AND UPPER(ADHOC_RPT_STATUS) != 'DELETE' ";

    private static final String QRY_GET_TARGET_REPORT_K1_AND_K2 = "SELECT key1_header, key2_header, key3_header " + "FROM rabc_alert_rule_presn_rule " + "WHERE presn_id = ?";

    private static final String QRY_GET_TOP_HEADER_LINKS = "SELECT * " + "FROM RABC_WEB_HEADER_LINK " + "WHERE PRESN_ID = ? " + "AND WEBID = ? " + "AND LINK_PRESN_NAME = ? " + "ORDER BY SEQ_NUM";

    private static final String QRY_GET_HEADER_TEXT = "SELECT HEADER1 " + ",HEADER2 " + ",HEADER3 " + ",PRESN_DATE_IND " + "FROM RABC_PRESN_HEADER " + "WHERE PRESN_ID = ? " + "AND WEBID = ? ";

    private static final String QRY_GET_ALERT_KEY_LVL = "SELECT DATA_KEY_LVL " + "FROM RABC_ALERT_RULE_PRESN_RULE " + "WHERE PRESN_ID = ?";

    private static final String QRY_GET_CALC_ELEM = "SELECT PRESN_ID, WEBID, EXEC_PRESN_SEQ_NUM, PRESN_CALC_NAME, PRESN_CALC_NUM, CALC_ELEM_FORMULA, CALC_ELEM_USER_VIEW, CALC_DIV_IND, CALC_ELEM_DISPLAY, PRESN_FORMAT_CODE," +
    		"(SELECT CALC_ELEM_SQL_FORMULA FROM RABC_PRESN_CALC_ELEM " +
    		" WHERE PRESN_ID = ? AND WEBID = ? AND PRESN_CALC_NUM = ? AND EXEC_PRESN_SEQ_NUM = ? " +
    		") CALC_ELEM_SQL_FORMULA " +
    		" FROM RABC_PRESN_CALC_ELEM_RPT " +
    		" WHERE PRESN_ID = ? AND WEBID = ? AND PRESN_CALC_NUM = ? AND EXEC_PRESN_SEQ_NUM = ? ";
    
    private static final String QRY_PREV_FILE_DATE = "SELECT MAX(PROC_DT) FROM RABC_CYCLE_CALENDAR WHERE PROC_DT < TO_DATE(''{0}'',''mm/dd/yyyy'')";
    
    private static final String QRY_PREV_FILE_DATE_BILL_RND = "SELECT PREV_PROC_DT FROM RABC_BLG_CALENDAR_PREV WHERE PROC_DT = TO_DATE(''{0}'',''MM/DD/YYYY'')";
    
    private static final String QRY_GET_MONTHLY_OPTION_BILLDAY_DATERANGE = "SELECT START_PROC_DT, END_PROC_DT FROM RABC_CYCLE_CALEN_MTH WHERE PROC_MTH = ? ";
    
    private static final String QRY_GET_MONTHLY_OPTION_BILLDAY_PREVDATERANGE = "SELECT PREV_START_PROC_DT, PREV_END_PROC_DT FROM RABC_CYCLE_CALEN_MTH WHERE PROC_MTH = ''{0}'' ";
    
    private static final String QRY_GET_PRESN_TREND_TIME = "SELECT DISTINCT PRESN_TREND_TIME FROM RABC_PRESN_ID WHERE PRESN_ID = ? " ;
    
    private static final String QRY_GET_MONTHS_FOR_SUBTOTALLING = "SELECT PROC_MTH, TO_CHAR(END_PROC_DT, ''MM/DD/YYYY'') END_PROC_DT_CHAR, END_PROC_DT FROM RABC_CYCLE_CALEN_MTH WHERE END_PROC_DT >= TO_DATE(''{0}'',''MM/DD/YYYY'') AND START_PROC_DT <= TO_DATE(''{1}'',''MM/DD/YYYY'') ORDER BY END_PROC_DT";

    private static final String YES_VALUE = "Y";

    private ArrayList databaseNodeList = new ArrayList(); // <CFSET A_DATABASE_NODE = ARRAYNEW(1)>

    private ArrayList dataLinkNumList = new ArrayList(); // <CFSET A_DATA_LINK_NUM = ARRAYNEW(1)>

    private ArrayList elemPrevIndList = new ArrayList(); // <CFSET A_ELEM_PREV_IND= ARRAYNEW(1)>

    private ArrayList elemTableNameList = new ArrayList(); // <CFSET A_ELEM_TABLE_NAME= ARRAYNEW(1)>

    private ArrayList elemViewNameList = new ArrayList(); // <CFSET A_ELEM_VIEW_NAME= ARRAYNEW(1)>

    private ArrayList execPresnSeqNumList = new ArrayList(); // <CFSET A_EXEC_PRESN_SEQ_NUM = ArrayNew(1)>

    private String genUrlString = null;

    private ArrayList hdParmIndList = new ArrayList(); // <CFSET A_HD_PARM_IND = ARRAYNEW(1)>

    private ArrayList headerDescIndList = new ArrayList(); // <CFSET A_HEADER_DESC_IND = ARRAYNEW(1)>

    private ArrayList headerLinkNumList = new ArrayList(); // <CFSET A_HEADER_LINK_NUM = ARRAYNEW(1)>

    private ArrayList headerLinkTblKeyDataList = new ArrayList(); // <CFSET A_HEADER_LINK_TBL_KEY_DATA = ARRAYNEW(1)>

    private ArrayList headerLinkTblKeyNameList = new ArrayList(); // <CFSET A_HEADER_LINK_TBL_KEY_NAME = ARRAYNEW(1)>

    private ArrayList headerLinkTblNameList = new ArrayList(); // <CFSET A_HEADER_LINK_TBL_NAME = ARRAYNEW(1)>

    private ArrayList key1DdlNameList = new ArrayList(); // <CFSET A_KEY1_DDL_NAME = ARRAYNEW(1)>

    private ArrayList key2DdlNameList = new ArrayList(); // <CFSET A_KEY2_DDL_NAME = ARRAYNEW(1)>

    private ArrayList key3DdlNameList = new ArrayList(); // <CFSET A_KEY3_DDL_NAME = ARRAYNEW(1)>

    private ArrayList key4DdlNameList = new ArrayList(); // <CFSET A_KEY4_DDL_NAME = ARRAYNEW(1)>

    private ArrayList key5DdlNameList = new ArrayList(); // <CFSET A_KEY5_DDL_NAME = ARRAYNEW(1)>

    private ArrayList keysRow1TablesList = new ArrayList(); // <CFSET KEYSROW1TABLES = ARRAYNEW(1)>

    private ArrayList keysRow2ColumnsList = new ArrayList(); // <CFSET KEYSROW2COLUMNS = ARRAYNEW(1)>

    private ArrayList keysRow2TablesList = new ArrayList(); // <CFSET KEYSROW2TABLES = ARRAYNEW(1)>

    private ArrayList keysWhereClauseList = new ArrayList(); // <CFSET A_KEYS_WHERECLAUSE = ARRAYNEW(1)>

    private ArrayList parmIndList = new ArrayList(); // <CFSET A_PARM_IND = ARRAYNEW(1)>

    private ArrayList prevDataIndList = new ArrayList(); // <CFSET A_PREV_DATA_IND = ARRAYNEW(1)>
    
    private ArrayList diffDataIndList = new ArrayList(); 

    private String procDateDdlName = null;


    public void createUrls(AdhocRptDataTO adhocRptDataTO) {
        // Case for the URL parameters have been changed as per Java conventions
        StringBuffer buffer = new StringBuffer();
        buffer.append("&presnId=");
        buffer.append(adhocRptDataTO.getPresnId());
        buffer.append("&procDate=");
        buffer.append(adhocRptDataTO.getProcDate());
        buffer.append("&clickLvl=");
        buffer.append(adhocRptDataTO.getClickLvl());
        buffer.append("&fileSeqNum=");
        buffer.append(adhocRptDataTO.getFileSeqNum());
        buffer.append("&alertTimeValue=");
        buffer.append(adhocRptDataTO.getAlertTimeValue());
        buffer.append("&alertTimeInd=");
        buffer.append(adhocRptDataTO.getAlertTimeInd());
        buffer.append("&monthSelect=");
        buffer.append(adhocRptDataTO.getMonthSelect());
        buffer.append("&yearSelect=");
        buffer.append(adhocRptDataTO.getYearSelect());
        buffer.append("&selectUniqRows=");
        buffer.append(adhocRptDataTO.isSelectUniqRows());
        buffer.append("&onlySelected=");
        buffer.append(adhocRptDataTO.isOnlySelected());
        buffer.append("&adhocTest=");
        buffer.append(adhocRptDataTO.getAdhocTest());
        buffer.append("&divisionName=");
        buffer.append(adhocRptDataTO.getDivisionName());
        buffer.append("&sortKeyList=");
        buffer.append(adhocRptDataTO.getSortKeyList());
        buffer.append("&sortKeyList2=");
        buffer.append(adhocRptDataTO.getSortKeyList2());
        this.genUrlString = buffer.toString();

        buffer.delete(0, buffer.length());
        buffer.append("clickLvl=");
        buffer.append(adhocRptDataTO.getClickLvl());
        buffer.append("&fileSeqNum=");
        buffer.append(adhocRptDataTO.getFileSeqNum());
        buffer.append("&alertTimeValue=");
        buffer.append(adhocRptDataTO.getAlertTimeValue());
        buffer.append("&alertTimeInd=");
        buffer.append(adhocRptDataTO.getAlertTimeInd());
        buffer.append("&monthSelect=");
        buffer.append(adhocRptDataTO.getMonthSelect());
        buffer.append("&yearSelect=");
        buffer.append(adhocRptDataTO.getYearSelect());
        buffer.append("&divisionName=");
        buffer.append(adhocRptDataTO.getDivisionName());
        buffer.append("&sortKeyList=");
        buffer.append(adhocRptDataTO.getSortKeyList());
        buffer.append("&sortKeyList2=");
        buffer.append(adhocRptDataTO.getSortKeyList2());
        adhocRptDataTO.setNewUrl(buffer.toString());

        buffer.delete(0, buffer.length());
        buffer.append("&presnId=");
        buffer.append(adhocRptDataTO.getPresnId());
        buffer.append("&procDate=");
        buffer.append(adhocRptDataTO.getProcDate());
        buffer.append("&clickLvl=");
        buffer.append(adhocRptDataTO.getClickLvl());
        buffer.append("&adhocTest=");
        buffer.append(adhocRptDataTO.getAdhocTest());
        buffer.append("&divisionName=");
        buffer.append(adhocRptDataTO.getDivisionName());
        buffer.append("&sortKeyList=");
        buffer.append(adhocRptDataTO.getSortKeyList());
        buffer.append("&sortKeyList2=");
        buffer.append(adhocRptDataTO.getSortKeyList2());
        adhocRptDataTO.setNewGenUrlString(buffer.toString());
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.att.bac.rabc.adhoc.rpt.AdhocRptDAO#getDateRange(com.att.bac.rabc.adhoc.rpt.AdhocRptDataTO, boolean)
     */
    public String getDateRangeWithFilters(AdhocRptDataTO adhocRptDataTO, boolean next,int sectionId) throws RABCException {
        Connection conn = null;
        PreparedStatement ps1 = null;
        Statement stmt = null;
        ResultSet rs1 = null, rs2 = null,rs3 = null ;
        boolean isRABCTbl = false;

        String qStartDate = null;
        String tempStartDate  = "";

        try {
            conn = ConnectionManager.getConnection(adhocRptDataTO.getRegion());
            
            // check for RABC table,
            // if not a RABC table, date will be stored with timestamp
            // in ODR table, and ODR date will need to be truncated
            
            isRABCTbl = isRABCTable(adhocRptDataTO) ; 

            // if we are in a RABC table
            // and a Presn_ID is passed in, then it is a Presn_ID for an Alert_Rule,
            // find the Parti_Ref_ID associated with the Presn_ID
            if (isRABCTbl && !Integer.toString(adhocRptDataTO.getPresnId()).trim().equals(AdhocRptDAO.EMPTY) && adhocRptDataTO.getPartiRefId() == -1) {
            	ps1 = conn.prepareStatement(AdhocRptDAO.QRY_GET_PARTI_REF_ID);
            	ps1.setInt(1, adhocRptDataTO.getPresnId());
            	rs1 = ps1.executeQuery();
                while (rs1.next()) {
                    adhocRptDataTO.setPartiRefId(rs1.getInt(1));
                }
            }

            // build and execute the query to get next process date if either Next or Previous button was clicked
            stmt = conn.createStatement();
            String nextDateQuery =  this.getNextDateQueryWithFilters(adhocRptDataTO, isRABCTbl, next) ;
            String whereClause = getWhereClauseFilters(adhocRptDataTO,isRABCTbl) ;
            if (whereClause.length() > 0) {
            	nextDateQuery = nextDateQuery + " AND " + whereClause ;
            }
            rs2 = stmt.executeQuery(nextDateQuery);
            while (rs2.next()) {
                qStartDate = rs2.getString(1) == null ? AdhocRptDAO.EMPTY : rs2.getString(1).trim();
            }

            // logic to hide or show Next and Previous buttons
            if (!qStartDate.equals(AdhocRptDAO.EMPTY)) {
                adhocRptDataTO.setStartDate(qStartDate);
                adhocRptDataTO.setEndDate(qStartDate);
                // and reexecute same query with new dates
                nextDateQuery = "" ;
                nextDateQuery = this.getNextDateQueryWithFilters(adhocRptDataTO, isRABCTbl, next) ;
                
                if (whereClause.length() > 0) {
                	nextDateQuery = nextDateQuery + " AND " + whereClause ;
                }
                rs3 = stmt.executeQuery(nextDateQuery);
                while (rs3.next()) {
                    tempStartDate = rs3.getString(1) == null ? AdhocRptDAO.EMPTY : rs3.getString(1).trim();
                }
                if (tempStartDate.equals(AdhocRptDAO.EMPTY)) {
                    if (next) {
                        adhocRptDataTO.setHideNext(true);
                    } else {
                        adhocRptDataTO.setHidePrev(true);
                    }
                }
            } else {
                if (next) {
                    adhocRptDataTO.setHideNext(true);
                } else {
                    adhocRptDataTO.setHidePrev(true);
                }
            }

        } catch (SQLException sqle) {
            throw new RABCException("Error in retrieving previous / next data with given filter conditions.", sqle);
        } catch (NamingException ne) {
            throw new RABCException("NamingException ", ne);
        } finally {
            JDBCUtil.closeResultSet(rs1);
            JDBCUtil.closeResultSet(rs2);
            JDBCUtil.closeResultSet(rs3);
            JDBCUtil.closePreparedStatement(ps1);

            JDBCUtil.closeConnection(conn);
        }
        return qStartDate ;
    }
    
    public boolean isRABCTable (AdhocRptDataTO adhocRptDataTO) {
    	boolean isRABCTable = false ; 
    	isRABCTable = (StaticDataLoader.getDataTblDdlByAlertProcTbl(AdhocRptDAO.NON_RABC_DB_NODE, adhocRptDataTO.getPresnTblName(), adhocRptDataTO.getRegion()).size() > 0 ? true : false);
    	return isRABCTable ; 
    }
    /*
     * (non-Javadoc)
     * 
     * @see com.att.bac.rabc.adhoc.rpt.AdhocRptDAO#getDates(com.att.bac.rabc.adhoc.rpt.AdhocRptDataTO)
     */
    public void getDates(AdhocRptDataTO adhocRptDataTO) throws RABCException {
        // if startDate is empty, set startDate to procDate (which will always have value)
        if (adhocRptDataTO.getStartDate() == null || adhocRptDataTO.getStartDate().trim().equals(AdhocRptDAO.EMPTY)) {
            adhocRptDataTO.setStartDate(adhocRptDataTO.getProcDate());
        }

        // if endDate is empty, set endDate to startDate
        if (adhocRptDataTO.getEndDate() == null || adhocRptDataTO.getEndDate().trim().equals(AdhocRptDAO.EMPTY)) {
            adhocRptDataTO.setEndDate(adhocRptDataTO.getStartDate());
        }

        // if startDate has value, set procDate to startDate
        if (adhocRptDataTO.getStartDate() != null && !adhocRptDataTO.getStartDate().trim().equals(AdhocRptDAO.EMPTY)) {
            adhocRptDataTO.setProcDate(adhocRptDataTO.getStartDate());
        }

        // if getGenStartDate has value, set procDate and startDate to getGenStartDate
        if (adhocRptDataTO.getGenStartDate() != null && !adhocRptDataTO.getGenStartDate().trim().equals(AdhocRptDAO.EMPTY)) {
            adhocRptDataTO.setProcDate(adhocRptDataTO.getGenStartDate());
            adhocRptDataTO.setStartDate(adhocRptDataTO.getGenStartDate());
        }

        // if getGenEndDate has value, set endDate to getGenEndDate
        if (adhocRptDataTO.getGenEndDate() != null && !adhocRptDataTO.getGenEndDate().trim().equals(AdhocRptDAO.EMPTY)) {
            adhocRptDataTO.setEndDate(adhocRptDataTO.getGenEndDate());
        }

        // if procDate is absent and file sequence number is entered,
        // get procDate from RABC_TRIG table and set startDate and endDate to the same
        if ((adhocRptDataTO.getProcDate() == null || adhocRptDataTO.getProcDate().trim().equals(AdhocRptDAO.EMPTY)) && !(Integer.toString(adhocRptDataTO.getFileSeqNum()).trim().equals(AdhocRptDAO.EMPTY))) {
            adhocRptDataTO.setProcDate(getProcDate(adhocRptDataTO.getFileSeqNumAsString(), adhocRptDataTO.getDivisionName1(), adhocRptDataTO.getRegion()));
            adhocRptDataTO.setStartDate(adhocRptDataTO.getProcDate());
            adhocRptDataTO.setEndDate(adhocRptDataTO.getProcDate());
        }

        // perform date formatting based on type of report requested
        if (adhocRptDataTO.getStartDate() == null || adhocRptDataTO.getStartDate().trim().equals(AdhocRptDAO.EMPTY)) {
            if (adhocRptDataTO.getProcDate() != null && !adhocRptDataTO.getProcDate().trim().equals(AdhocRptDAO.EMPTY)) {
                int procDateLength = adhocRptDataTO.getProcDate().length();
                try {
                    switch (procDateLength) {
                        case 4: // yearly report
                            adhocRptDataTO.setStartDate("01/01/" + adhocRptDataTO.getProcDate());
                            break;
                        case 6: // bill day and format is M/YYYY
                            adhocRptDataTO.setStartDate("0" + adhocRptDataTO.getProcDate().substring(0, 1) + "/01" + adhocRptDataTO.getProcDate().substring(1, 6));
                            adhocRptDataTO.setEndDate("0" + adhocRptDataTO.getProcDate().substring(0, 1) + "/" + AdhocRptUtil.getDaysInMonth(adhocRptDataTO.getStartDate(), AdhocRptDAO.DATEFORMAT) + adhocRptDataTO.getProcDate().substring(1, 6));
                            break;
                        case 7: // monthly report and format is MM/YYYY
                            adhocRptDataTO.setStartDate(adhocRptDataTO.getProcDate().substring(0, 2) + "/01" + adhocRptDataTO.getProcDate().substring(2, 7));
                            adhocRptDataTO.setEndDate(adhocRptDataTO.getProcDate().substring(0, 2) + "/" + AdhocRptUtil.getDaysInMonth(adhocRptDataTO.getStartDate(), AdhocRptDAO.DATEFORMAT) + adhocRptDataTO.getProcDate().substring(2, 7));
                            break;
                        default:
                            adhocRptDataTO.setStartDate(adhocRptDataTO.getProcDate());
                    }
                } catch (ParseException pe) {
                    throw new RABCException("Error in parsing date", pe);
                }
            }
        }

        if (adhocRptDataTO.getEndDate() == null || adhocRptDataTO.getEndDate().trim().equals(AdhocRptDAO.EMPTY)) {
            if (adhocRptDataTO.getProcDate() != null && !adhocRptDataTO.getProcDate().trim().equals(AdhocRptDAO.EMPTY)) {
                int procDateLength = adhocRptDataTO.getProcDate().length();
                switch (procDateLength) {
                    case 4: // yearly report
                        adhocRptDataTO.setEndDate("01/01/" + adhocRptDataTO.getProcDate());
                        break;
                    case 6: // bill day and format is M/YYYY
                        adhocRptDataTO.setEndDate("0" + adhocRptDataTO.getProcDate().substring(0, 1) + "/01" + adhocRptDataTO.getProcDate().substring(1, 6));
                        break;
                    case 7: // monthly report and format is MM/YYYY
                        adhocRptDataTO.setEndDate(adhocRptDataTO.getProcDate().substring(0, 2) + "/01" + adhocRptDataTO.getProcDate().substring(2, 7));
                        break;
                    default:
                        adhocRptDataTO.setEndDate(adhocRptDataTO.getProcDate());
                }
            }
        }

        Calendar cal = new GregorianCalendar();
        int currMonth = cal.get(Calendar.MONTH) + 1; // 0=Jan, 1=Feb, ...
        int currYear = cal.get(Calendar.YEAR); // 2002
        int currDay = cal.get(Calendar.DAY_OF_MONTH);

        if (adhocRptDataTO.getMonthSelect() != 0 || adhocRptDataTO.getYearSelect() != 0) {
            // if month and year are current, end day should be the current day of the month,
            // else, it should be the last day of the month

            if (adhocRptDataTO.getMonthSelect() == 0) {
                adhocRptDataTO.setMonthSelect(currMonth);
            }

            String selectedMonthAsString = null;
            if (adhocRptDataTO.getMonthSelect() < 10) {
                selectedMonthAsString = "0" + adhocRptDataTO.getMonthSelect();
            } else {
                selectedMonthAsString = Integer.toString(adhocRptDataTO.getMonthSelect());
            }

            if (adhocRptDataTO.getYearSelect() == 0) {
                adhocRptDataTO.setYearSelect(currYear);
            }

            String selectedYearAsString = Integer.toString(adhocRptDataTO.getYearSelect());
            
            /*
             * First call the method to set the Trend time
             */
            setPresnTrendTime(adhocRptDataTO);
            
            if ("B".equals(adhocRptDataTO.getPresnTrendTime())){
            	Connection conn = null;
                PreparedStatement ps = null;
                ResultSet rs = null;
                
                try {
                    conn = ConnectionManager.getConnection(adhocRptDataTO.getRegion());
                    ps = conn.prepareStatement(AdhocRptDAO.QRY_GET_MONTHLY_OPTION_BILLDAY_DATERANGE);
                    ps.setString(1, selectedMonthAsString + "-" + selectedYearAsString);
                    rs = ps.executeQuery();
                    
                    Date startDt = null;
                    Date endDt = null;
                    
                    while (rs.next()){
                    	startDt = rs.getDate("START_PROC_DT");
                    	endDt = rs.getDate("END_PROC_DT");
                    }
                    
                    if (startDt!=null & endDt!=null){
                    	SimpleDateFormat sd = new SimpleDateFormat(DATEFORMAT);
                    	String newStartDate = sd.format(startDt);
                    	String newEndDate = sd.format(endDt);
                    	
                    	 // Assign the start date and end date
                        adhocRptDataTO.setStartDate(newStartDate);
                        adhocRptDataTO.setEndDate(newEndDate);
                    }
                } catch (SQLException sqle) {
                    throw new RABCException("Error in retrieving date range", sqle);
                } catch (NamingException ne) {
                    throw new RABCException("NamingException ", ne);
                } finally {
                    JDBCUtil.closeResultSet(rs);
                    JDBCUtil.closePreparedStatement(ps);
                    JDBCUtil.closeConnection(conn);
                }
            } else {
            	int endDay = 0;
                if (adhocRptDataTO.getMonthSelect() == currMonth && adhocRptDataTO.getYearSelect() == currYear) {
                    endDay = currDay;
                } else {
                    // corresponding CF code is: <CFSET endDay = DAYSINMONTH(STARTDATE)>, does not look correct
                    // end day should be of the selected month
                    try {
                        endDay = AdhocRptUtil.getDaysInMonth(selectedMonthAsString + "/01/" + adhocRptDataTO.getYearSelect(), AdhocRptDAO.DATEFORMAT);
                    } catch (ParseException pe) {
                        throw new RABCException("Error in parsing date", pe);
                    }
                }

                String endDayAsString = null;
                if (endDay > 0 && endDay < 10) {
                    endDayAsString = "0" + endDay;
                } else if (endDay >= 10) {
                    endDayAsString = Integer.toString(endDay);
                }

                // then assign the start date and end date
                adhocRptDataTO.setStartDate(selectedMonthAsString + "/01/" + adhocRptDataTO.getYearSelect());
                adhocRptDataTO.setEndDate(selectedMonthAsString + "/" + endDayAsString + "/" + adhocRptDataTO.getYearSelect());
            }
        }

        if (adhocRptDataTO.getProcDate().length() == 7 && adhocRptDataTO.getStartDate().length() == 7 && adhocRptDataTO.getEndDate().length() == 7) {
            adhocRptDataTO.setStartDate(adhocRptDataTO.getStartDate().substring(0, 2) + "/01/" + adhocRptDataTO.getStartDate().substring(3, 7));
            int endDay = 0;
            if (Integer.parseInt(adhocRptDataTO.getEndDate().substring(0, 2)) == currMonth && Integer.parseInt(adhocRptDataTO.getEndDate().substring(3, 7)) == currYear) {
                endDay = currDay;
            } else {
                try {
                    endDay = AdhocRptUtil.getDaysInMonth(adhocRptDataTO.getEndDate().substring(0, 2) + "/01/" + adhocRptDataTO.getEndDate().substring(3, 7), AdhocRptDAO.DATEFORMAT);
                } catch (ParseException pe) {
                    throw new RABCException("Error in parsing date", pe);
                }
            }
            String endDayAsString = null;
            if (endDay > 0 && endDay < 10) {
                endDayAsString = "0" + endDay;
            } else if (endDay >= 10) {
                endDayAsString = Integer.toString(endDay);
            }
            adhocRptDataTO.setEndDate(adhocRptDataTO.getEndDate().substring(0, 2) + "/" + endDayAsString + "/" + adhocRptDataTO.getEndDate().substring(3, 7));
        }

    }


    /*
     * (non-Javadoc)
     * 
     * @see com.att.bac.rabc.adhoc.rpt.AdhocRptDAO#getDivision(com.att.bac.rabc.adhoc.rpt.AdhocRptDataTO)
     */
    public void getDivision(AdhocRptDataTO adhocRptDataTO) {
        // store all division code and desc for a region in divisions
        adhocRptDataTO.setDivisions(StaticDataLoader.getDivisionsByRegion(adhocRptDataTO.getRegion()));

        // set divisionName from input divisionList
        if ((adhocRptDataTO.getDivisionList() != null && !adhocRptDataTO.getDivisionList().trim().equals(AdhocRptDAO.EMPTY)) && (adhocRptDataTO.getDivisionName() != null && adhocRptDataTO.getDivisionName().trim().equals("ALL"))) {
            adhocRptDataTO.setDivisionName(adhocRptDataTO.getDivisionList());
        }

        // when divisions are selected, store a comma separated list of selected division codes in divisionName
        if (adhocRptDataTO.getSelectedDivs().length > 0) {
            StringBuffer temp = new StringBuffer();
            for (int i = 0; i < adhocRptDataTO.getSelectedDivs().length; i++) {
                if (adhocRptDataTO.getSelectedDivs().length - i == 1) {
                    temp.append(adhocRptDataTO.getSelectedDivs()[i]);
                } else {
                    temp.append(adhocRptDataTO.getSelectedDivs()[i] + ",");
                }
            }
            adhocRptDataTO.setDivisionName(temp.toString());
            temp = null;
        }

        // if divisionName is empty, set it from divisionList if it has value
        if (adhocRptDataTO.getDivisionName() == null && adhocRptDataTO.getDivisionList() != null) {
            adhocRptDataTO.setDivisionName(adhocRptDataTO.getDivisionList());
        }

        // in divisionName1, store the same list as above except that the division codes are enclosed by "'"
        if (adhocRptDataTO.getDivisionName() != null && !adhocRptDataTO.getDivisionName().equals(AdhocRptDAO.EMPTY)) {
            adhocRptDataTO.setDivisionName1("'" + adhocRptDataTO.getDivisionName().replaceAll(",", "','") + "'");
        }
    }


    /*
     * (non-Javadoc)
     * 
     * @see com.att.bac.rabc.adhoc.rpt.AdhocRptDAO#getPresnSeqNumArray(com.att.bac.rabc.adhoc.rpt.AdhocRptDataTO)
     */
    public void getPresnSeqNumArray(AdhocRptDataTO adhocRptDataTO) throws RABCException {
        boolean recFound = false;
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = ConnectionManager.getConnection(adhocRptDataTO.getRegion());
            if (adhocRptDataTO.getAdhocTest().trim().equalsIgnoreCase("N")) {
                ps = conn.prepareStatement(AdhocRptDAO.QRY_GET_EXEC_PRESN_SEQ_NUM_ACTIVE);
            } else {
                ps = conn.prepareStatement(AdhocRptDAO.QRY_GET_EXEC_PRESN_SEQ_NUM_NOT_DELETE);
            }
            ps.setInt(1, adhocRptDataTO.getPresnId());
            rs = ps.executeQuery();
            while (rs.next()) {
                recFound = true;
                adhocRptDataTO.getDistExecPresnSeqNumList().add(new Integer(rs.getInt(1)));
            }
            if (!recFound) {
                adhocRptDataTO.getDistExecPresnSeqNumList().add(new Integer(1));
            }
        } catch (SQLException sqle) {
            throw new RABCException("Error in retrieving distinct presn sequence number", sqle);
        } catch (NamingException ne) {
            throw new RABCException("NamingException ", ne);
        } finally {
            JDBCUtil.closeResultSet(rs);
            JDBCUtil.closePreparedStatement(ps);
            JDBCUtil.closeConnection(conn);
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.att.bac.rabc.adhoc.rpt.AdhocRptDAO#addPrevNextButtons(com.att.bac.rabc.adhoc.rpt.AdhocRptDataTO)
     */
    public void addPrevNextButtons(AdhocRptDataTO adhocRptDataTO) throws RABCException {
        String minDate = null ; 
        String maxDate = null ;
        String tempStartDate = null ; 
        String tempEndDate = null ;
        
        tempStartDate = adhocRptDataTO.getStartDate() ; 
        tempEndDate = adhocRptDataTO.getEndDate() ; 
        minDate = getMinDate(adhocRptDataTO) ; 
        maxDate = getMaxDate(adhocRptDataTO) ;
        
        if (minDate == null || "".equals(minDate)) {
        	adhocRptDataTO.setHidePrev(true) ;
        }
        
        if (maxDate == null || "".equals(maxDate)) {
        	adhocRptDataTO.setHideNext(true) ;
        }
        
       	adhocRptDataTO.setStartDate(tempStartDate) ; 
        adhocRptDataTO.setEndDate(tempEndDate) ;

    }

    
    /*
     * (non-Javadoc)
     * 
     * @see com.att.bac.rabc.adhoc.rpt.AdhocRptDAO#getMinDate(com.att.bac.rabc.adhoc.rpt.AdhocRptDataTO)
     */
    public String  getMinDate(AdhocRptDataTO adhocRptDataTO) throws RABCException {
    	Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String minDate = null ; 
   	
    	try {
            conn = ConnectionManager.getConnection(adhocRptDataTO.getRegion());
            boolean isRABCTbl = isRABCTable(adhocRptDataTO) ; 
            
            String nextDateQuery =  this.getNextDateQueryWithFilters(adhocRptDataTO, isRABCTbl, false) ;
            String whereClause = getWhereClauseFilters(adhocRptDataTO,isRABCTbl) ;
            
            if (whereClause.length() > 0) {
            	nextDateQuery = nextDateQuery + " AND " + whereClause ;
            }
            
            ps = conn.prepareStatement(nextDateQuery);
            
            rs = ps.executeQuery();
            while (rs.next()) {
            	minDate = rs.getString(1) == null ? AdhocRptDAO.EMPTY : rs.getString(1).trim();
            }
            
            if (minDate != null && !"".equals(minDate)) {
            	adhocRptDataTO.setStartDate(minDate) ;
            	adhocRptDataTO.setEndDate(minDate) ;
            	
            }
            
        } catch (SQLException sqle) {
            throw new RABCException("Error in retrieving min date", sqle);
        } catch (NamingException ne) {
            throw new RABCException("NamingException ", ne);
        } finally {
            JDBCUtil.closeResultSet(rs);
            JDBCUtil.closePreparedStatement(ps);
            JDBCUtil.closeConnection(conn);
        }
        
    	return minDate ; 	
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see com.att.bac.rabc.adhoc.rpt.AdhocRptDAO#getMaxDate(com.att.bac.rabc.adhoc.rpt.AdhocRptDataTO)
     */
    public String  getMaxDate(AdhocRptDataTO adhocRptDataTO) throws RABCException {
    	Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String maxDate = null ; 
   	
    	try {
            conn = ConnectionManager.getConnection(adhocRptDataTO.getRegion());
            boolean isRABCTbl = isRABCTable(adhocRptDataTO) ; 
            
            String nextDateQuery =  this.getNextDateQueryWithFilters(adhocRptDataTO, isRABCTbl, true) ;
            String whereClause = getWhereClauseFilters(adhocRptDataTO,isRABCTbl) ;
            
            if (whereClause.length() > 0) {
            	nextDateQuery = nextDateQuery + " AND " + whereClause ;
            }
            
            ps = conn.prepareStatement(nextDateQuery);
            
            rs = ps.executeQuery();
            while (rs.next()) {
            	maxDate = rs.getString(1) == null ? AdhocRptDAO.EMPTY : rs.getString(1).trim();
            }
            
        } catch (SQLException sqle) {
            throw new RABCException("Error in retrieving min date", sqle);
        } catch (NamingException ne) {
            throw new RABCException("NamingException ", ne);
        } finally {
            JDBCUtil.closeResultSet(rs);
            JDBCUtil.closePreparedStatement(ps);
            JDBCUtil.closeConnection(conn);
        }
        
    	return maxDate ; 	
    }
    /**
     * Get the key1 & 2 headers for the target linked report.
     * 
     * @param c
     * @param targetID
     * @return
     * @throws SQLException
     */
    public List getTargetKeyHeaders(Connection c, int targetID) throws SQLException {
        PreparedStatement ps = null;
        List results = new ArrayList();
        try {
            ps = c.prepareStatement(QRY_GET_TARGET_REPORT_K1_AND_K2);
            ps.setInt(1, targetID);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                results.add(rs.getString("KEY1_HEADER"));
                results.add(rs.getString("KEY2_HEADER"));
                results.add(rs.getString("KEY3_HEADER"));
            }

            return results;
        } catch (SQLException e) {
            logger.error("AdhocRptDAO::getTargetKeyHeaders [" + targetID + "] error", e);
            throw e;
        } finally {
            JDBCUtil.closePreparedStatement(ps);
        }
    }


    /*
     * (non-Javadoc)
     * 
     * @see com.att.bac.rabc.adhoc.rpt.AdhocRptDAO#processPresnSeqNumArray(com.att.bac.rabc.adhoc.rpt.AdhocRptDataTO,
     *      com.att.bac.rabc.adhoc.rpt.AbstractAdhocAriaLayout)
     */
    public ARIAReportRABC[] processPresnSeqNumArray(AdhocRptDataTO adhocRptDataTO, int btnValue) throws RABCException {
        logger.debug("Main loop started.....");

        ARIAReportRABC[] reports = new ARIAReportRABC[adhocRptDataTO.getDistExecPresnSeqNumList().size()];
        String tempSortColumn = null;
        String actualSort = null;
        List dtoList = new ArrayList();
        List startDateList = new ArrayList();
        for (int i = 0; i < adhocRptDataTO.getDistExecPresnSeqNumList().size(); i++) {
            initAdhocRptDataTO(adhocRptDataTO);

            // populate DTO
            getPresnTable(adhocRptDataTO, i);
            if (!"B".equals(adhocRptDataTO.getPresnTrendTime())){
            	adhocRptDataTO.setBillRoundCheck(null);
            }
            getProcDateDdlName(adhocRptDataTO);
            getPresnRule(adhocRptDataTO, i);
            getPresnElem(adhocRptDataTO, i);
            getWhereClause();
            
            adhocRptDataTO.setRow1Columns(AdhocRptUtil.arrayListToString(adhocRptDataTO.getKeysRow1ColumnsList()));
            // code added to show / hide previous - next buttons This is for Daily reports only.
            if ("D".equals(adhocRptDataTO.getPresnTrendTime()) || "".equals(adhocRptDataTO.getPresnTrendTime())) {
            	if (i == 0 ) {
            		addPrevNextButtons(adhocRptDataTO) ;
            	}
            	 
                if (btnValue != -1 ) {
                	boolean next = false ; 
                	if (btnValue == 1) {
                		next = true ; 
                	} 
                	String startDate = this.getDateRangeWithFilters(adhocRptDataTO, next, Integer.parseInt(adhocRptDataTO.getDistExecPresnSeqNumList().get(i).toString()));
                	if (startDate != null && !"".equals(startDate)) {
                		startDateList.add (startDate) ;
                	}
                }
            }

            // Code added for layouts 2 and 4
            if (adhocRptDataTO.getPresnModel()==2 || adhocRptDataTO.getPresnModel()==4) {
            	if (i==0){
                	tempSortColumn = adhocRptDataTO.getUserSortColumn();
                }
            	String sortCol = tempSortColumn;
            	if (sortCol!=null && sortCol.indexOf("~")!=-1){
            		String [] sectionSortInfo = sortCol.split("~");   
                	int sortSection = Integer.parseInt(sectionSortInfo[1]);
                	// Store the actual sort
                	if (i==0){
                		actualSort = sectionSortInfo[0];
                	}
                	if (sortSection==i){
                		adhocRptDataTO.setUserSortColumn(sectionSortInfo[0]);
                	} else {
                		adhocRptDataTO.setUserSortColumn(null);
                	}
            	}
            }
            dtoList.add(adhocRptDataTO.duplicate());
        }
        
        //  Set the actual sort back in the dto associated with the form
        if (adhocRptDataTO.getPresnModel()==2 || adhocRptDataTO.getPresnModel()==4) {
        	adhocRptDataTO.setUserSortColumn(actualSort); 
        }
        
        // Find out the minimum & max proc date from those derived for each section - set these as start & end dates
        if (!startDateList.isEmpty()){
        	adhocRptDataTO.setStartDate((String)startDateList.get(0)) ;
        	adhocRptDataTO.setEndDate((String)startDateList.get(0)) ;
        } 
        
        // Form the report query here
        for (int i = 0; i < adhocRptDataTO.getDistExecPresnSeqNumList().size(); i++) {
        	AdhocRptDataTO curradhocRptDataTO = (AdhocRptDataTO) dtoList.get(i);
        	//Find out the minimum & max proc date from those derived for each section - set these as start & end dates
            if (!startDateList.isEmpty()){
            	curradhocRptDataTO.setStartDate((String)startDateList.get(0)) ;
            	curradhocRptDataTO.setEndDate((String)startDateList.get(0)) ;
            } 
            
        	AbstractAdhocGenerator generator = AdhocGeneratorFactory.createGenerator(curradhocRptDataTO);
            reports[i] = generator.generateQuery(curradhocRptDataTO, i);
            reports[i].setDto(curradhocRptDataTO);
        }

        logger.debug("Main loop completed.....");
        return reports;
    }


    /*
     * (non-Javadoc)
     * 
     * @see com.att.bac.rabc.adhoc.rpt.AdhocRptDAO#setCurrentDate(com.att.bac.rabc.adhoc.rpt.AdhocRptDataTO)
     */
    public void setCurrentDate(AdhocRptDataTO adhocRptDataTO) {
        SimpleDateFormat simple = new SimpleDateFormat(AdhocRptDAO.DATEFORMAT);
        adhocRptDataTO.setStartDate(simple.format(new Date()));
        adhocRptDataTO.setEndDate(adhocRptDataTO.getStartDate());
    }


    /*
     * (non-Javadoc)
     * 
     * @see com.att.bac.rabc.adhoc.rpt.AdhocRptDAO#updateUrl(com.att.bac.rabc.adhoc.rpt.AdhocRptDataTO)
     */
    public void updateUrl(AdhocRptDataTO adhocRptDataTO) {
        String incDivisionName = AdhocRptDAO.EMPTY;

        if (adhocRptDataTO.getDivisionName() != null && !adhocRptDataTO.getDivisionName().trim().equals(AdhocRptDAO.EMPTY)) {
            incDivisionName = adhocRptDataTO.getDivisionName();
        }

        // in genUrlString, replace the value of divisionName with whatever is there in variable incDivisionName
        int indexOffset = this.genUrlString.indexOf("&divisionName");
        if (indexOffset == -1) {
            int indexStart = this.genUrlString.indexOf("=", indexOffset) + 1;
            int indexEnd = this.genUrlString.indexOf("&", indexOffset + 1);
            this.genUrlString = (this.genUrlString.substring(0, indexStart) + incDivisionName + this.genUrlString.substring(indexEnd, this.genUrlString.length())).trim();
        }
    }


    /*
     * (non-Javadoc)
     * 
     * @see com.att.bac.rabc.adhoc.rpt.AdhocRptDAO#validatePresnId(com.att.bac.rabc.adhoc.rpt.AdhocRptDataTO)
     */
    public void validatePresnId(AdhocRptDataTO adhocRptDataTO) throws RABCException {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        boolean recFound = false;
        try {
            conn = ConnectionManager.getConnection(adhocRptDataTO.getRegion());
            ps = conn.prepareStatement(AdhocRptDAO.QRY_GET_FILE_SEQ_NUM_IND);
            ps.setInt(1, adhocRptDataTO.getPresnId());
            ps.setString(2, adhocRptDataTO.getWebId());
            rs = ps.executeQuery();
            while (rs.next()) {
                adhocRptDataTO.setFileSeqNumInd(rs.getString(1) == null ? AdhocRptDAO.EMPTY : rs.getString(1).trim()); // store
                recFound = true;
            }
        } catch (SQLException sqle) {
            throw new RABCException("Error in retrieving file sequence number indicator", sqle);
        } catch (NamingException ne) {
            throw new RABCException("NamingException ", ne);
        } finally {
            JDBCUtil.closeResultSet(rs);
            JDBCUtil.closePreparedStatement(ps);
            JDBCUtil.closeConnection(conn);
        }
        if (!recFound) {
            throw new RABCException("The following presnid is invalid: " + adhocRptDataTO.getPresnId());
        }
    }


    /**
     * @param adhocRptDataTO
     * @param loopCount
     * @param mouseOverNum
     * @param nextArrayValue
     * @throws RABCException
     */
    private void getMouseOver(AdhocRptDataTO adhocRptDataTO, int loopCount, String mouseOverNum, int nextArrayValue) throws RABCException {
        if (mouseOverNum != null && !mouseOverNum.trim().equals(AdhocRptDAO.EMPTY)) {
            Connection conn = null;
            PreparedStatement ps = null;
            ResultSet rs = null;
            boolean recFound = false;
            try {
                conn = ConnectionManager.getConnection(adhocRptDataTO.getRegion());
                ps = conn.prepareStatement(AdhocRptDAO.QRY_GET_MOUSE_OVER);
                ps.setInt(1, adhocRptDataTO.getPresnId());
                ps.setString(2, adhocRptDataTO.getWebId());
                ps.setInt(3, ((Integer) (adhocRptDataTO.getDistExecPresnSeqNumList().get(loopCount))).intValue());
                ps.setInt(4, Integer.parseInt(mouseOverNum));
                rs = ps.executeQuery();
                while (rs.next()) {
                    adhocRptDataTO.getDataLinkTblKeyDataList().add(nextArrayValue, rs.getString("LINK_TBL_KEY_DATA") == null ? AdhocRptDAO.EMPTY : rs.getString("LINK_TBL_KEY_DATA").trim());
                    adhocRptDataTO.getDataLinkTblNameList().add(nextArrayValue, rs.getString("LINK_TBL_NAME") == null ? AdhocRptDAO.EMPTY : rs.getString("LINK_TBL_NAME").trim());
                    adhocRptDataTO.getDataLinkTblKeyNameList().add(nextArrayValue, rs.getString("LINK_TBL_KEY_NAME") == null ? AdhocRptDAO.EMPTY : rs.getString("LINK_TBL_KEY_NAME").trim());
                    recFound = true;
                }
            } catch (SQLException sqle) {
                throw new RABCException("Error in retrieving mouse over details", sqle);
            } catch (NamingException ne) {
                throw new RABCException("NamingException ", ne);
            } finally {
                JDBCUtil.closeResultSet(rs);
                JDBCUtil.closePreparedStatement(ps);
                JDBCUtil.closeConnection(conn);
            }
            if (!recFound) {
                adhocRptDataTO.getDataLinkTblKeyDataList().add(nextArrayValue, AdhocRptDAO.EMPTY);
                adhocRptDataTO.getDataLinkTblNameList().add(nextArrayValue, AdhocRptDAO.EMPTY);
                adhocRptDataTO.getDataLinkTblKeyNameList().add(nextArrayValue, AdhocRptDAO.EMPTY);
            }
        } else {
            adhocRptDataTO.getDataLinkTblKeyDataList().add(nextArrayValue, AdhocRptDAO.EMPTY);
            adhocRptDataTO.getDataLinkTblNameList().add(nextArrayValue, AdhocRptDAO.EMPTY);
            adhocRptDataTO.getDataLinkTblKeyNameList().add(nextArrayValue, AdhocRptDAO.EMPTY);
        }
    }

    /**
     * @param adhocRptDataTO
     * @param isRABCTbl
     * @param next
     * @return
     */
    private String getNextDateQueryWithFilters(AdhocRptDataTO adhocRptDataTO, boolean isRABCTbl, boolean next) {
        StringBuffer getNextDateQueryWithFilters = new StringBuffer();
        if (next) {
        	getNextDateQueryWithFilters.append("SELECT TO_CHAR(MIN(" + this.procDateDdlName + "),'MM/DD/YYYY') AS QSTARTDATE FROM " + adhocRptDataTO.getPresnTblName() + " ");
            if (isRABCTbl) {
            	getNextDateQueryWithFilters.append("WHERE " + this.procDateDdlName + " > TO_DATE('" + adhocRptDataTO.getEndDate() + "','" + AdhocRptDAO.DATEFORMAT + "') ");
            } else {
            	getNextDateQueryWithFilters.append("WHERE TRUNC(" + this.procDateDdlName + ") > TO_DATE('" + adhocRptDataTO.getEndDate() + "','" + AdhocRptDAO.DATEFORMAT + "') ");
            }
        } else {
        	getNextDateQueryWithFilters.append("SELECT TO_CHAR(MAX(" + this.procDateDdlName + "),'MM/DD/YYYY') AS QSTARTDATE FROM " + adhocRptDataTO.getPresnTblName() + " ");
            if (isRABCTbl) {
            	getNextDateQueryWithFilters.append("WHERE " + this.procDateDdlName + " < TO_DATE('" + adhocRptDataTO.getStartDate() + "','" + AdhocRptDAO.DATEFORMAT + "') ");
            } else {
            	getNextDateQueryWithFilters.append("WHERE TRUNC(" + this.procDateDdlName + ") < TO_DATE('" + adhocRptDataTO.getStartDate() + "','" + AdhocRptDAO.DATEFORMAT + "') ");
            }
        }
        if (isRABCTbl && !Integer.toString(adhocRptDataTO.getPartiRefId()).trim().equals(AdhocRptDAO.EMPTY) && adhocRptDataTO.getPartiRefId() > 0) {
        	getNextDateQueryWithFilters.append("AND " + adhocRptDataTO.getPresnTblName() + ".PARTI_REF_ID = " + adhocRptDataTO.getPartiRefId() + " ");
        }
        
        return getNextDateQueryWithFilters.toString();
    }
    /**
     * @param adhocRptDataTO
     * @param loopCount
     * @throws RABCException
     */
    private void getPresnElem(AdhocRptDataTO adhocRptDataTO, int loopCount) throws RABCException {
        if (adhocRptDataTO.getTableNames() == null) {
            adhocRptDataTO.setTableNames(AdhocRptDAO.EMPTY);
        }
        adhocRptDataTO.setAliasNames(adhocRptDataTO.getTableNames());
        

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int currentRow = 0;
        try {
            conn = ConnectionManager.getConnection(adhocRptDataTO.getRegion());
            ps = conn.prepareStatement(AdhocRptDAO.QRY_GET_PRESN_ELEM);
            ps.setInt(1, adhocRptDataTO.getPresnId());
            ps.setString(2, adhocRptDataTO.getWebId());
            ps.setInt(3, ((Integer) (adhocRptDataTO.getDistExecPresnSeqNumList().get(loopCount))).intValue());
            rs = ps.executeQuery();
            while (rs.next()) {
                currentRow++;
                if (rs.getString("DATABASE_NODE") != null && !rs.getString("DATABASE_NODE").trim().equals(AdhocRptDAO.EMPTY)) {
                    adhocRptDataTO.setDatabaseNode(rs.getString("DATABASE_NODE").trim());
                }

                if (rs.getString("DATA_TBL") != null && !rs.getString("DATA_TBL").trim().equals(AdhocRptDAO.EMPTY)) {
                    String dataTbl = rs.getString("DATA_TBL").trim();
                    String viewName = rs.getString("VIEW_NAME") == null ? AdhocRptDAO.EMPTY : rs.getString("VIEW_NAME").trim();
                    if (adhocRptDataTO.getTableNames().toUpperCase().indexOf(dataTbl.toUpperCase()) == -1) {
                        if (adhocRptDataTO.getTableNames().trim().equals(AdhocRptDAO.EMPTY)) {
                            adhocRptDataTO.setTableNames(dataTbl);
                            adhocRptDataTO.setAliasNames(viewName);
                        } else {
                            adhocRptDataTO.setTableNames(adhocRptDataTO.getTableNames() + "," + dataTbl);
                            adhocRptDataTO.setAliasNames(adhocRptDataTO.getAliasNames() + "," + viewName);
                        }
                    } else if (viewName != null && adhocRptDataTO.getAliasNames().toUpperCase().indexOf(viewName.toUpperCase()) == -1) {
                        if (adhocRptDataTO.getTableNames().trim().equals(AdhocRptDAO.EMPTY)) {
                            adhocRptDataTO.setTableNames(dataTbl);
                            adhocRptDataTO.setAliasNames(viewName);
                        } else {
                            adhocRptDataTO.setTableNames(adhocRptDataTO.getTableNames() + "," + dataTbl);
                            adhocRptDataTO.setAliasNames(adhocRptDataTO.getAliasNames() + "," + viewName);
                        }
                    }
                }

                if (rs.getString("DATA_DDL_NAME") != null && !rs.getString("DATA_DDL_NAME").trim().equals(AdhocRptDAO.EMPTY)) {
                    int theValue = adhocRptDataTO.getColumnsToExtractList().size();
                    int theValueSuffix = theValue + 1;
                    String dataTbl = rs.getString("DATA_TBL").trim();
                    String dataType = "K";
                    
                    adhocRptDataTO.getColumnsToExtractList().add(theValue, rs.getString("DATA_DDL_NAME").trim());
                    adhocRptDataTO.getColumnsHeadersList().add(theValue, rs.getString("PRESN_NAME") == null ? AdhocRptDAO.EMPTY : rs.getString("PRESN_NAME").trim());
                    if (rs.getInt("PRESN_CALC_NUM") > 0) { // note that getInt on a null column also returns 0
                        adhocRptDataTO.getColumnsAsOracleList().add(theValue, rs.getString("DATA_DDL_NAME").trim() + "C" + theValueSuffix);
                        adhocRptDataTO.getColumnsDataTypeList().add(theValue,"C");
                    } else if (rs.getString("PREV_DATA_IND") != null && rs.getString("PREV_DATA_IND").trim().equals(AdhocRptDAO.YES_VALUE)) {
                        adhocRptDataTO.getColumnsAsOracleList().add(theValue, rs.getString("DATA_DDL_NAME").trim());// +
                        List dataTblDdlList = (ArrayList) StaticDataLoader.getDataTblDdlByTblDdlName(dataTbl, rs.getString("DATA_DDL_NAME").trim(), adhocRptDataTO.getRegion());
                        if (!dataTblDdlList.isEmpty()){
                        	 DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblDdlList.get(0);
                        	 if ("1".equals(dataTblDdlBean.getTblDdlDataType())){
                        		 dataType = "C";
                        	 }
                        }
                        adhocRptDataTO.getColumnsDataTypeList().add(theValue,dataType);
                        // "P"
                        // +
                        // theValueSuffix);
                    } else if (rs.getString("DATA_TBL") != null && rs.getString("VIEW_NAME") != null && !rs.getString("DATA_TBL").trim().equalsIgnoreCase(rs.getString("VIEW_NAME").trim()) && (rs.getString("PREV_DATA_IND") == null || rs.getString("PREV_DATA_IND").trim().equals(AdhocRptDAO.EMPTY))) {
                        if (adhocRptDataTO.getColumnsAsOracleList().size() == 1) {
                            adhocRptDataTO.getColumnsAsOracleList().add(theValue, rs.getString("DATA_DDL_NAME").trim()); // +
                            List dataTblDdlList = (ArrayList) StaticDataLoader.getDataTblDdlByTblDdlName(dataTbl, rs.getString("DATA_DDL_NAME").trim(), adhocRptDataTO.getRegion());
                            if (!dataTblDdlList.isEmpty()){
                            	 DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblDdlList.get(0);
                            	 if ("1".equals(dataTblDdlBean.getTblDdlDataType())){
                            		 dataType = "C";
                            	 }
                            }
                            adhocRptDataTO.getColumnsDataTypeList().add(theValue,dataType);
                            // "Q"
                            // +
                            // theValueSuffix);
                        } else {
                            String arrayColumnList = AdhocRptUtil.arrayListToString(adhocRptDataTO.getColumnsAsOracleList());
                            if (AdhocRptUtil.listFindNoCase(arrayColumnList, rs.getString("DATA_DDL_NAME").trim(), ",") == -1) {
                                adhocRptDataTO.getColumnsAsOracleList().add(theValue, rs.getString("DATA_DDL_NAME").trim());// +
                                List dataTblDdlList = (ArrayList) StaticDataLoader.getDataTblDdlByTblDdlName(dataTbl, rs.getString("DATA_DDL_NAME").trim(), adhocRptDataTO.getRegion());
                                if (!dataTblDdlList.isEmpty()){
                                	 DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblDdlList.get(0);
                                	 if ("1".equals(dataTblDdlBean.getTblDdlDataType())){
                                		 dataType = "C";
                                	 }
                                }
                                adhocRptDataTO.getColumnsDataTypeList().add(theValue,dataType);
                                // "Q"
                                // +
                                // theValueSuffix);
                            } else {
                                adhocRptDataTO.getColumnsAsOracleList().add(theValue, rs.getString("DATA_DDL_NAME").trim());
                                List dataTblDdlList = (ArrayList) StaticDataLoader.getDataTblDdlByTblDdlName(dataTbl, rs.getString("DATA_DDL_NAME").trim(), adhocRptDataTO.getRegion());
                                if (!dataTblDdlList.isEmpty()){
                                	 DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblDdlList.get(0);
                                	 if ("1".equals(dataTblDdlBean.getTblDdlDataType())){
                                		 dataType = "C";
                                	 }
                                }
                                adhocRptDataTO.getColumnsDataTypeList().add(theValue,dataType);
                            }
                        }
                    } else {
                        String arrayColumnList = AdhocRptUtil.arrayListToString(adhocRptDataTO.getColumnsAsOracleList());
                        if (adhocRptDataTO.getColumnsAsOracleList().size() == 1 && AdhocRptUtil.listFindNoCase(arrayColumnList, rs.getString("DATA_DDL_NAME").trim(), ",") == -1) {
                            adhocRptDataTO.getColumnsAsOracleList().add(theValue, rs.getString("DATA_DDL_NAME").trim());
                            List dataTblDdlList = (ArrayList) StaticDataLoader.getDataTblDdlByTblDdlName(dataTbl, rs.getString("DATA_DDL_NAME").trim(), adhocRptDataTO.getRegion());
                            if (!dataTblDdlList.isEmpty()){
                            	 DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblDdlList.get(0);
                            	 if ("1".equals(dataTblDdlBean.getTblDdlDataType())){
                            		 dataType = "C";
                            	 }
                            }
                            adhocRptDataTO.getColumnsDataTypeList().add(theValue,dataType);
                        } else {
                            adhocRptDataTO.getColumnsAsOracleList().add(theValue, rs.getString("DATA_DDL_NAME").trim());
                            List dataTblDdlList = (ArrayList) StaticDataLoader.getDataTblDdlByTblDdlName(dataTbl, rs.getString("DATA_DDL_NAME").trim(), adhocRptDataTO.getRegion());
                            if (!dataTblDdlList.isEmpty()){
                            	 DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblDdlList.get(0);
                            	 if ("1".equals(dataTblDdlBean.getTblDdlDataType())){
                            		 dataType = "C";
                            	 }
                            }
                            adhocRptDataTO.getColumnsDataTypeList().add(theValue,dataType);
                        }
                    }

                    adhocRptDataTO.getColumnsTablesList().add(theValue, rs.getString("DATA_TBL") == null ? AdhocRptDAO.EMPTY : rs.getString("DATA_TBL").trim());
                    this.execPresnSeqNumList.add(theValue, rs.getString("EXEC_PRESN_SEQ_NUM") == null ? AdhocRptDAO.EMPTY : rs.getString("EXEC_PRESN_SEQ_NUM").trim()); // <CFSET
                    // A_EXEC_PRESN_SEQ_NUM
                    // =
                    // Trim(QRY_PRESNELEM.EXEC_PRESN_SEQ_NUM)>
                    adhocRptDataTO.getHeaderLinkIndList().add(theValue, rs.getString("HEADER_LINK_IND") == null ? AdhocRptDAO.EMPTY : rs.getString("HEADER_LINK_IND").trim());
                    this.headerLinkNumList.add(theValue, rs.getString("HEADER_LINK_NUM") == null ? AdhocRptDAO.EMPTY : rs.getString("HEADER_LINK_NUM").trim());
                    this.headerDescIndList.add(theValue, rs.getString("HEADER_DESC_IND") == null ? AdhocRptDAO.EMPTY : rs.getString("HEADER_DESC_IND").trim());
                    adhocRptDataTO.getHeaderMouseOverNumList().add(theValue, rs.getString("HEADER_MOUSE_OVER_NUM") == null ? AdhocRptDAO.EMPTY : rs.getString("HEADER_MOUSE_OVER_NUM").trim());
                    adhocRptDataTO.getDataLinkIndList().add(theValue, rs.getString("DATA_LINK_IND") == null ? AdhocRptDAO.EMPTY : rs.getString("DATA_LINK_IND").trim());
                    this.dataLinkNumList.add(theValue, rs.getString("DATA_LINK_NUM") == null ? AdhocRptDAO.EMPTY : rs.getString("DATA_LINK_NUM").trim());
                    adhocRptDataTO.getDataDescIndList().add(theValue, rs.getString("DATA_DESC_IND") == null ? AdhocRptDAO.EMPTY : rs.getString("DATA_DESC_IND").trim());
                    adhocRptDataTO.getDataMouseOverNumList().add(theValue, rs.getString("DATA_MOUSE_OVER_NUM") == null ? AdhocRptDAO.EMPTY : rs.getString("DATA_MOUSE_OVER_NUM").trim());
                    adhocRptDataTO.getHeaderLinkToPgmList().add(theValue, rs.getString("HEADER_LINK_TO_PGM") == null ? AdhocRptDAO.EMPTY : rs.getString("HEADER_LINK_TO_PGM").trim());
                    adhocRptDataTO.getHeaderLinkPresnIdList().add(theValue, rs.getString("HEADER_LINK_PRESN_ID") == null ? AdhocRptDAO.EMPTY : rs.getString("HEADER_LINK_PRESN_ID"));
                    this.headerLinkTblKeyDataList.add(theValue, rs.getString("HEADER_LINK_TBL_KEY_DATA") == null ? AdhocRptDAO.EMPTY : rs.getString("HEADER_LINK_TBL_KEY_DATA").trim());
                    this.headerLinkTblNameList.add(theValue, rs.getString("HEADER_LINK_TBL_NAME") == null ? AdhocRptDAO.EMPTY : rs.getString("HEADER_LINK_TBL_NAME").trim());
                    this.headerLinkTblKeyNameList.add(theValue, rs.getString("HEADER_LINK_TBL_KEY_NAME") == null ? AdhocRptDAO.EMPTY : rs.getString("HEADER_LINK_TBL_KEY_NAME").trim());
                    adhocRptDataTO.getDataLinkToPgmList().add(theValue, rs.getString("DATA_LINK_TO_PGM") == null ? AdhocRptDAO.EMPTY : rs.getString("DATA_LINK_TO_PGM").trim());
                    adhocRptDataTO.getDataLinkPresnIdList().add(theValue, rs.getString("DATA_LINK_PRESN_ID") == null ? AdhocRptDAO.EMPTY : rs.getString("DATA_LINK_PRESN_ID"));
                    adhocRptDataTO.getDataLinkTblKeyDataList().add(theValue, rs.getString("DATA_LINK_TBL_KEY_DATA") == null ? AdhocRptDAO.EMPTY : rs.getString("DATA_LINK_TBL_KEY_DATA").trim());
                    adhocRptDataTO.getDataLinkTblNameList().add(theValue, rs.getString("DATA_LINK_TBL_NAME") == null ? AdhocRptDAO.EMPTY : rs.getString("DATA_LINK_TBL_NAME").trim());
                    adhocRptDataTO.getDataLinkTblKeyNameList().add(theValue, rs.getString("DATA_LINK_TBL_KEY_NAME") == null ? AdhocRptDAO.EMPTY : rs.getString("DATA_LINK_TBL_KEY_NAME").trim());
                    adhocRptDataTO.getGraphPresnIndList().add(theValue, rs.getString("GRAPH_PRESN_IND") == null ? AdhocRptDAO.EMPTY : rs.getString("GRAPH_PRESN_IND").trim());
                    adhocRptDataTO.getPresnUnitIndList().add(theValue, rs.getString("PRESN_UNIT_IND") == null ? AdhocRptDAO.EMPTY : rs.getString("PRESN_UNIT_IND").trim());
                    adhocRptDataTO.getPresnSumIndList().add(theValue, rs.getString("PRESN_SUM_IND") == null ? AdhocRptDAO.EMPTY : rs.getString("PRESN_SUM_IND").trim());
                    this.databaseNodeList.add(theValue, AdhocRptDAO.EMPTY);
                    adhocRptDataTO.getPresnCalcNumList().add(theValue, rs.getString("PRESN_CALC_NUM") == null ? AdhocRptDAO.EMPTY : rs.getString("PRESN_CALC_NUM").trim());
                    adhocRptDataTO.getPresnSuppressIndList().add(theValue, rs.getString("PRESN_SUPPRESS_IND") == null ? AdhocRptDAO.EMPTY : rs.getString("PRESN_SUPPRESS_IND").trim());
                    this.prevDataIndList.add(theValue, AdhocRptDAO.EMPTY);
                    adhocRptDataTO.getViewNameList().add(theValue, rs.getString("VIEW_NAME") == null ? AdhocRptDAO.EMPTY : rs.getString("VIEW_NAME").trim());
                    adhocRptDataTO.getPresnOrdIndList().add(theValue, rs.getString("PRESN_ORD_IND") == null ? AdhocRptDAO.EMPTY : rs.getString("PRESN_ORD_IND").trim());
                    adhocRptDataTO.getPresnFormatList().add(theValue, rs.getString("PRESN_FORMAT_CODE") == null ? AdhocRptDAO.EMPTY : rs.getString("PRESN_FORMAT_CODE").trim());
                    adhocRptDataTO.getPrevDataIndList().add(rs.getString("PREV_DATA_IND"));
                    adhocRptDataTO.getDiffDataIndList().add(theValue, rs.getString("DIFF_DATA_IND") == null ? AdhocRptDAO.EMPTY : rs.getString("DIFF_DATA_IND").trim());
                    this.hdParmIndList.add(theValue, AdhocRptDAO.EMPTY);
                    this.parmIndList.add(theValue, AdhocRptDAO.EMPTY);
                    adhocRptDataTO.getPartiRefIdList().add(theValue, rs.getString("PARTI_REF_ID") == null ? AdhocRptDAO.EMPTY : rs.getString("PARTI_REF_ID").trim());

                    this.getMouseOver(adhocRptDataTO, loopCount, rs.getString("DATA_MOUSE_OVER_NUM") == null ? AdhocRptDAO.EMPTY : rs.getString("DATA_MOUSE_OVER_NUM").trim(), theValue);
                    
                    this.elemTableNameList.add(rs.getString("DATA_TBL") == null ? AdhocRptDAO.EMPTY : rs.getString("DATA_TBL").trim());
                    this.elemViewNameList.add(rs.getString("VIEW_NAME") == null ? AdhocRptDAO.EMPTY : rs.getString("VIEW_NAME").trim());
                    this.elemPrevIndList.add(rs.getString("PREV_DATA_IND") == null ? AdhocRptDAO.EMPTY : rs.getString("PREV_DATA_IND").trim());
                }
            }
        } catch (SQLException sqle) {
            throw new RABCException("Error in retrieving presn elem details", sqle);
        } catch (NamingException ne) {
            throw new RABCException("NamingException ", ne);
        } finally {
            JDBCUtil.closeResultSet(rs);
            JDBCUtil.closePreparedStatement(ps);
            JDBCUtil.closeConnection(conn);
        }
        if (currentRow == 0) {
            throw new RABCException("Error : No Data Found in table rabc_alert_rule_presn_elem");
        }
    }


    /**
     * @param adhocRptDataTO
     * @param loopCount
     * @throws RABCException
     */
    private void getPresnRule(AdhocRptDataTO adhocRptDataTO, int loopCount) throws RABCException {
        String colName = null;
        String colHeader = null;
        String eHdLinkInd = null;
        String eHdLinkNum = null;
        String eHdParmInd = null;
        String eDataLinkInd = null;
        String eDataLinkNum = null;
        String eParmInd = null;
        String eDescInd = null;
        String eMouseOverNum = null;
        String eHeaderLinkToPgm = null;
        String eHeaderLinkPresnId = null;
        String eHeaderLinkTblKeyName = null;
        String eHeaderLinkTblKeyData = null;
        String eHeaderLinkTblName = null;
        String eDataLinkToPgm = null;
        String eDataLinkPresnId = null;

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        boolean recFound = false;
        try {
            conn = ConnectionManager.getConnection(adhocRptDataTO.getRegion());
            ps = conn.prepareStatement(AdhocRptDAO.QRY_GET_PRESN_RULE);
            ps.setInt(1, adhocRptDataTO.getPresnId());
            ps.setString(2, adhocRptDataTO.getWebId());
            ps.setInt(3, ((Integer) (adhocRptDataTO.getDistExecPresnSeqNumList().get(loopCount))).intValue());
            rs = ps.executeQuery();
            int count = 1;
            while (rs.next()) {
                recFound = true;
                // concatenate only the first row columns for extraction
                if (count == 1) {
                    for (int x = 1; x <= 5; x++) { // loop for 5 keys
                        colName = rs.getString("KEY" + x + "_DDL_NAME") == null ? AdhocRptDAO.EMPTY : rs.getString("KEY" + x + "_DDL_NAME").trim();
                        if (colName != null && !colName.trim().equals(AdhocRptDAO.EMPTY)) {
                            colHeader = rs.getString("KEY" + x + "_HEADER") == null ? AdhocRptDAO.EMPTY : rs.getString("KEY" + x + "_HEADER").trim();
                            eHdLinkInd = rs.getString("KEY" + x + "_HD_LINK_IND") == null ? AdhocRptDAO.EMPTY : rs.getString("KEY" + x + "_HD_LINK_IND").trim();
                            eHdLinkNum = rs.getString("KEY" + x + "_HD_LINK_NUM") == null ? AdhocRptDAO.EMPTY : rs.getString("KEY" + x + "_HD_LINK_NUM").trim();
                            eHdParmInd = rs.getString("KEY" + x + "_HD_PARM_IND") == null ? AdhocRptDAO.EMPTY : rs.getString("KEY" + x + "_HD_PARM_IND").trim();
                            eDataLinkInd = rs.getString("KEY" + x + "_DATA_LINK_IND") == null ? AdhocRptDAO.EMPTY : rs.getString("KEY" + x + "_DATA_LINK_IND").trim();
                            eDataLinkNum = rs.getString("KEY" + x + "_DATA_LINK_NUM") == null ? AdhocRptDAO.EMPTY : rs.getString("KEY" + x + "_DATA_LINK_NUM").trim();
                            eParmInd = rs.getString("KEY" + x + "_PARM_IND") == null ? AdhocRptDAO.EMPTY : rs.getString("KEY" + x + "_PARM_IND").trim();
                            eDescInd = rs.getString("KEY" + x + "_DESC_IND") == null ? AdhocRptDAO.EMPTY : rs.getString("KEY" + x + "_DESC_IND").trim();
                            eMouseOverNum = rs.getString("KEY" + x + "_MOUSE_OVER_NUM") == null ? AdhocRptDAO.EMPTY : rs.getString("KEY" + x + "_MOUSE_OVER_NUM").trim();
                            eHeaderLinkToPgm = rs.getString("KEY" + x + "_HEADER_LINK_TO_PGM") == null ? AdhocRptDAO.EMPTY : rs.getString("KEY" + x + "_HEADER_LINK_TO_PGM").trim();
                            eHeaderLinkPresnId = rs.getString("KEY" + x + "_HEADER_LINK_PRESN_ID") == null ? AdhocRptDAO.EMPTY : rs.getString("KEY" + x + "_HEADER_LINK_PRESN_ID").trim();
                            eHeaderLinkTblKeyName = rs.getString("KEY" + x + "_HEADER_LINK_TBL_KEY_NAME") == null ? AdhocRptDAO.EMPTY : rs.getString("KEY" + x + "_HEADER_LINK_TBL_KEY_NAME").trim();
                            eHeaderLinkTblKeyData = rs.getString("KEY" + x + "_HEADER_LINK_TBL_KEY_DATA") == null ? AdhocRptDAO.EMPTY : rs.getString("KEY" + x + "_HEADER_LINK_TBL_KEY_DATA").trim();
                            eHeaderLinkTblName = rs.getString("KEY" + x + "_HEADER_LINK_TBL_NAME") == null ? AdhocRptDAO.EMPTY : rs.getString("KEY" + x + "_HEADER_LINK_TBL_NAME").trim();
                            eDataLinkToPgm = rs.getString("KEY" + x + "_DATA_LINK_TO_PGM") == null ? AdhocRptDAO.EMPTY : rs.getString("KEY" + x + "_DATA_LINK_TO_PGM").trim();
                            eDataLinkPresnId = rs.getString("KEY" + x + "_DATA_LINK_PRESN_ID") == null ? AdhocRptDAO.EMPTY : rs.getString("KEY" + x + "_DATA_LINK_PRESN_ID").trim();

                            int nextArrayValue = adhocRptDataTO.getColumnsToExtractList().size(); // <CFSET

                            adhocRptDataTO.getColumnsToExtractList().add(nextArrayValue, colName);
                            adhocRptDataTO.getColumnsDataTypeList().add(nextArrayValue,"K");
                            adhocRptDataTO.getColumnsHeadersList().add(nextArrayValue, colHeader);
                            adhocRptDataTO.getColumnsAsOracleList().add(nextArrayValue, "K" + x + colName); // append
                            adhocRptDataTO.getColumnsTablesList().add(nextArrayValue, rs.getString("VIEW_NAME") == null ? AdhocRptDAO.EMPTY : rs.getString("VIEW_NAME").trim());
                            adhocRptDataTO.getKeysRow1ColumnsList().add(nextArrayValue, colName);
                            adhocRptDataTO.getKeysRow1AliasList().add(nextArrayValue, "K" + x + colName);
                            this.keysRow1TablesList.add(nextArrayValue, rs.getString("VIEW_NAME") == null ? AdhocRptDAO.EMPTY : rs.getString("VIEW_NAME").trim());
                            this.execPresnSeqNumList.add(nextArrayValue, rs.getString("EXEC_PRESN_SEQ_NUM") == null ? rs.getString("EXEC_PRESN_SEQ_NUM") : rs.getString("EXEC_PRESN_SEQ_NUM").trim()); // <CFSET
                            adhocRptDataTO.getHeaderLinkIndList().add(nextArrayValue, eHdLinkInd);
                            this.headerLinkNumList.add(nextArrayValue, eHdLinkNum);
                            this.headerDescIndList.add(nextArrayValue, eDescInd);
                            adhocRptDataTO.getHeaderMouseOverNumList().add(nextArrayValue, eMouseOverNum);
                            adhocRptDataTO.getDataLinkIndList().add(nextArrayValue, eDataLinkInd);
                            this.dataLinkNumList.add(nextArrayValue, eDataLinkNum);
                            adhocRptDataTO.getDataDescIndList().add(nextArrayValue, eDescInd);
                            adhocRptDataTO.getDataMouseOverNumList().add(nextArrayValue, eMouseOverNum);
                            adhocRptDataTO.getHeaderLinkToPgmList().add(nextArrayValue, eHeaderLinkToPgm);
                            adhocRptDataTO.getHeaderLinkPresnIdList().add(nextArrayValue, eHeaderLinkPresnId);
                            this.headerLinkTblKeyDataList.add(nextArrayValue, eHeaderLinkTblKeyData);
                            this.headerLinkTblNameList.add(nextArrayValue, eHeaderLinkTblName);
                            this.headerLinkTblKeyNameList.add(nextArrayValue, eHeaderLinkTblKeyName);
                            adhocRptDataTO.getDataLinkToPgmList().add(nextArrayValue, eDataLinkToPgm);
                            adhocRptDataTO.getDataLinkPresnIdList().add(nextArrayValue, eDataLinkPresnId);

                            this.getMouseOver(adhocRptDataTO, loopCount, eMouseOverNum, nextArrayValue);

                            adhocRptDataTO.getGraphPresnIndList().add(nextArrayValue, AdhocRptDAO.EMPTY);
                            adhocRptDataTO.getPresnUnitIndList().add(nextArrayValue, AdhocRptDAO.EMPTY);
                            adhocRptDataTO.getPresnSumIndList().add(nextArrayValue, AdhocRptDAO.NO_VALUE);
                            this.databaseNodeList.add(nextArrayValue, AdhocRptDAO.EMPTY);
                            adhocRptDataTO.getPresnCalcNumList().add(nextArrayValue, AdhocRptDAO.EMPTY);
                            adhocRptDataTO.getPresnSuppressIndList().add(nextArrayValue, AdhocRptDAO.NO_VALUE);
                            this.prevDataIndList.add(nextArrayValue, AdhocRptDAO.EMPTY);
                            this.diffDataIndList.add(nextArrayValue, AdhocRptDAO.EMPTY);
                            adhocRptDataTO.getViewNameList().add(nextArrayValue, rs.getString("VIEW_NAME") == null ? AdhocRptDAO.EMPTY : rs.getString("VIEW_NAME").trim());
                            adhocRptDataTO.getPresnOrdIndList().add(nextArrayValue, AdhocRptDAO.EMPTY);
                            adhocRptDataTO.getPresnFormatList().add(nextArrayValue, AdhocRptDAO.EMPTY);
                            adhocRptDataTO.getPrevDataIndList().add(nextArrayValue, EMPTY);
                            adhocRptDataTO.getDiffDataIndList().add(nextArrayValue, EMPTY);
                            this.hdParmIndList.add(nextArrayValue, eHdParmInd);
                            this.parmIndList.add(nextArrayValue, eParmInd);
                            adhocRptDataTO.getPartiRefIdList().add(nextArrayValue, AdhocRptDAO.EMPTY);
                            this.elemPrevIndList.add(nextArrayValue, AdhocRptDAO.EMPTY);
                        }// if (colName != null && !colName.trim().equals(AdhocRptDAO.EMPTY))
                    }// for (int x=1; x<=5; x++)
                } else if (count == 2) {// if (count == 1)
                    adhocRptDataTO.setRecCountFlag(true);
                    for (int x = 1; x <= 5; x++) {
                        colName = rs.getString("KEY" + x + "_DDL_NAME") == null ? AdhocRptDAO.EMPTY : rs.getString("KEY" + x + "_DDL_NAME").trim();
                        colHeader = rs.getString("KEY" + x + "_HEADER") == null ? AdhocRptDAO.EMPTY : rs.getString("KEY" + x + "_HEADER").trim();
                        if (colName != null && !colName.trim().equals(AdhocRptDAO.EMPTY)) {
                            int nextArrayValue = this.keysRow2ColumnsList.size();
                            this.keysRow2ColumnsList.add(nextArrayValue, colName);
                            this.keysRow2TablesList.add(nextArrayValue, rs.getString("VIEW_NAME") == null ? AdhocRptDAO.EMPTY : rs.getString("VIEW_NAME").trim());
                        }
                    }
                }
                for (int x = 1; x <= 5; x++) {
                    colName = rs.getString("KEY" + x + "_DDL_NAME") == null ? AdhocRptDAO.EMPTY : rs.getString("KEY" + x + "_DDL_NAME").trim();
                    colHeader = rs.getString("KEY" + x + "_HEADER") == null ? AdhocRptDAO.EMPTY : rs.getString("KEY" + x + "_HEADER").trim();
                    if ((colName != null && !colName.trim().equals(AdhocRptDAO.EMPTY)) && (rs.getString("VIEW_NAME") != null && !rs.getString("VIEW_NAME").trim().equals(AdhocRptDAO.EMPTY))) {
                        String temp = rs.getString("VIEW_NAME").trim() + "." + colName;
                        switch (x) {
                            case 1:
                                this.key1DdlNameList.add(temp);
                                break;
                            case 2:
                                this.key2DdlNameList.add(temp);
                                break;
                            case 3:
                                this.key3DdlNameList.add(temp);
                                break;
                            case 4:
                                this.key4DdlNameList.add(temp);
                                break;
                            case 5:
                                this.key5DdlNameList.add(temp);
                        }
                    }
                }
                count++;
            }
        } catch (SQLException sqle) {
            throw new RABCException("Error in retrieving presn rule details", sqle);
        } catch (NamingException ne) {
            throw new RABCException("NamingException ", ne);
        } finally {
            JDBCUtil.closeResultSet(rs);
            JDBCUtil.closePreparedStatement(ps);
            JDBCUtil.closeConnection(conn);
        }
        if (!recFound) {
            throw new RABCException("Error : No Data Found in table rabc_alert_rule_presn_rule");
        }
    }


    /**
     * @param adhocRptDataTO
     * @param loopCount
     * @throws RABCException
     */
    private void getPresnTable(AdhocRptDataTO adhocRptDataTO, int loopCount) throws RABCException {
        // get the presentation date column name and the division name key level
        // to determine which key header(key1,key2) to use
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        boolean recFound = false;
        int dataKeyLvl = 0 ; 
        try {
            conn = ConnectionManager.getConnection(adhocRptDataTO.getRegion());
            if (adhocRptDataTO.getAdhocTest().trim().equalsIgnoreCase("N")) {
                ps = conn.prepareStatement(AdhocRptDAO.QRY_GET_PRESN_TABLE_ACTIVE);
            } else {
                ps = conn.prepareStatement(AdhocRptDAO.QRY_GET_PRESN_TABLE_NOT_DELETE);
            }
            ps.setInt(1, adhocRptDataTO.getPresnId());
            ps.setInt(2, ((Integer) (adhocRptDataTO.getDistExecPresnSeqNumList().get(loopCount))).intValue());
            rs = ps.executeQuery();
            while (rs.next()) {
                adhocRptDataTO.setPresnTblName(rs.getString(1) == null ? AdhocRptDAO.EMPTY : rs.getString(1).trim());
                adhocRptDataTO.setDivNameKeyLvl(rs.getInt(3));
                adhocRptDataTO.setBegSubTotLvl(rs.getInt(4));
                adhocRptDataTO.setEndSubTotLvl(rs.getInt(5));
                if (rs.getInt(6) > 0) {
                    adhocRptDataTO.setPresnModel(rs.getInt(6));
                }
                adhocRptDataTO.setPresnTrendTime(rs.getString(11) == null ? AdhocRptDAO.EMPTY : rs.getString(11).trim());
                adhocRptDataTO.setTimingFilterCode(rs.getString(12) == null ? AdhocRptDAO.EMPTY : rs.getString(12).trim());
                
                if ("M".equals(adhocRptDataTO.getPresnTrendTime()) && adhocRptDataTO.getPresnModel() == 3) {
                	adhocRptDataTO.setBegSubTotLvl(1);
                	dataKeyLvl = getDataKeyLvl(adhocRptDataTO) ;
                	adhocRptDataTO.setDataKeyLvl(dataKeyLvl);
                	adhocRptDataTO.setEndSubTotLvl(dataKeyLvl == 0 ? 1 : dataKeyLvl);
                } else {
                	dataKeyLvl = getDataKeyLvl(adhocRptDataTO) ;
                	adhocRptDataTO.setDataKeyLvl(dataKeyLvl);
                }
                
                recFound = true;
            }
        } catch (SQLException sqle) {
            throw new RABCException("Error in quering rabc_presn_id table", sqle);
        } catch (NamingException ne) {
            throw new RABCException("NamingException ", ne);
        } finally {
            JDBCUtil.closeResultSet(rs);
            JDBCUtil.closePreparedStatement(ps);
            JDBCUtil.closeConnection(conn);
        }
        if (!recFound) {
            throw new RABCException("The following presnid is invalid: " + adhocRptDataTO.getPresnId());
        }
        if (adhocRptDataTO.getKey1() != null && adhocRptDataTO.getDivNameKeyLvl() != 1) {
            adhocRptDataTO.setSortKeyList(adhocRptDataTO.getKey1());
        }
        if (adhocRptDataTO.getKey2() != null && adhocRptDataTO.getDivNameKeyLvl() != 2) {
            adhocRptDataTO.setSortKeyList2(adhocRptDataTO.getKey2());
        }
        if (adhocRptDataTO.getDivNameKeyLvl() > 0) {
            switch (adhocRptDataTO.getDivNameKeyLvl()) {
                case 1:
                    if (adhocRptDataTO.getKey1() != null && !adhocRptDataTO.getKey1().trim().equals(AdhocRptDAO.EMPTY)) {
                        adhocRptDataTO.setDivisionName(adhocRptDataTO.getKey1());
                    }
                    break;
                case 2:
                    if (adhocRptDataTO.getKey2() != null && !adhocRptDataTO.getKey2().trim().equals(AdhocRptDAO.EMPTY)) {
                        adhocRptDataTO.setDivisionName(adhocRptDataTO.getKey2());
                    }
                    break;
                case 3:
                    if (adhocRptDataTO.getKey3() != null && !adhocRptDataTO.getKey3().trim().equals(AdhocRptDAO.EMPTY)) {
                        adhocRptDataTO.setDivisionName(adhocRptDataTO.getKey3());
                    }
                    break;
                case 4:
                    if (adhocRptDataTO.getKey4() != null && !adhocRptDataTO.getKey4().trim().equals(AdhocRptDAO.EMPTY)) {
                        adhocRptDataTO.setDivisionName(adhocRptDataTO.getKey4());
                    }
                    break;
                case 5:
                    if (adhocRptDataTO.getKey5() != null && !adhocRptDataTO.getKey5().trim().equals(AdhocRptDAO.EMPTY)) {
                        adhocRptDataTO.setDivisionName(adhocRptDataTO.getKey5());
                    }
            }
            adhocRptDataTO.setDivisionYes(AdhocRptDAO.YES_VALUE);
        }
        if (adhocRptDataTO.getDivisionName() != null && adhocRptDataTO.getDivisionName().indexOf("'") == -1) {
            adhocRptDataTO.setDivisionName1("'" + adhocRptDataTO.getDivisionName().replaceAll(",", "','") + "'");
        } else {
            adhocRptDataTO.setDivisionName1(adhocRptDataTO.getDivisionName());
        }
    }


    /**
     * @param fileSeqNumAsString
     * @param divisions
     * @param region
     * @return
     * @throws RABCException
     */
    private String getProcDate(String fileSeqNumAsString, String divisions, String region) throws RABCException {
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        String maxProcDate = null;
        String[] parms = { fileSeqNumAsString, divisions };
        String modifiedSql = MessageFormat.format(AdhocRptDAO.QRY_GET_MAX_PROC_DATE, parms);
        try {
            conn = ConnectionManager.getConnection(region);
            stmt = conn.createStatement();
            rs = stmt.executeQuery(modifiedSql);
            while (rs.next()) {
                maxProcDate = rs.getString(1) == null ? AdhocRptDAO.EMPTY : rs.getString(1).trim();
            }
        } catch (SQLException sqle) {
            throw new RABCException("Error in retrieving proc date", sqle);
        } catch (NamingException ne) {
            throw new RABCException("NamingException ", ne);
        } finally {
            JDBCUtil.closeResultSet(rs);
            JDBCUtil.closeStatement(stmt);
            JDBCUtil.closeConnection(conn);
        }
        if (maxProcDate == null || maxProcDate.trim().equals(AdhocRptDAO.EMPTY)) {
            SimpleDateFormat simple = new SimpleDateFormat(AdhocRptDAO.DATEFORMAT);
            maxProcDate = simple.format(new Date());
        }
        return maxProcDate;
    }


    /**
     * @param adhocRptDataTO
     */
    private void getProcDateDdlName(AdhocRptDataTO adhocRptDataTO) {
        this.procDateDdlName = ((DataTblDdlBean) (StaticDataLoader.getDataTblDdlByAlertProcTbl(adhocRptDataTO.getPresnTblName(), adhocRptDataTO.getRegion()).get(0))).getTblProcDateDdlName();
        if (this.procDateDdlName == null || this.procDateDdlName.trim().equals(AdhocRptDAO.EMPTY)) {
            adhocRptDataTO.setNoProcDate(AdhocRptDAO.YES_VALUE);
        } else {
            adhocRptDataTO.setNoProcDate(AdhocRptDAO.NO_VALUE);
        }
    }


    /**
     */
    private void getWhereClause() {
        String prevWhere = AdhocRptDAO.EMPTY;
        // for key1
        if (this.key1DdlNameList.size() > 1) {
            for (int keysIndexValue = 0; keysIndexValue < this.key1DdlNameList.size(); keysIndexValue++) {
                if (keysIndexValue > 0) {
                    this.keysWhereClauseList.add(prevWhere + "=" + this.key1DdlNameList.get(keysIndexValue));
                }
                prevWhere = (String) this.key1DdlNameList.get(keysIndexValue);
            }
        }
        // for key2
        if (this.key2DdlNameList.size() > 1) {
            for (int keysIndexValue = 0; keysIndexValue < this.key2DdlNameList.size(); keysIndexValue++) {
                if (keysIndexValue > 0) {
                    this.keysWhereClauseList.add(prevWhere + "=" + this.key2DdlNameList.get(keysIndexValue));
                }
                prevWhere = (String) this.key2DdlNameList.get(keysIndexValue);
            }
        }
        // for key3
        if (this.key3DdlNameList.size() > 1) {
            for (int keysIndexValue = 0; keysIndexValue < this.key3DdlNameList.size(); keysIndexValue++) {
                if (keysIndexValue > 0) {
                    this.keysWhereClauseList.add(prevWhere + "=" + this.key3DdlNameList.get(keysIndexValue));
                }
                prevWhere = (String) this.key3DdlNameList.get(keysIndexValue);
            }
        }
        // for key4
        if (this.key4DdlNameList.size() > 1) {
            for (int keysIndexValue = 0; keysIndexValue < this.key4DdlNameList.size(); keysIndexValue++) {
                if (keysIndexValue > 0) {
                    this.keysWhereClauseList.add(prevWhere + "=" + this.key4DdlNameList.get(keysIndexValue));
                }
                prevWhere = (String) this.key4DdlNameList.get(keysIndexValue);
            }
        }
        // for key5
        if (this.key5DdlNameList.size() > 1) {
            for (int keysIndexValue = 0; keysIndexValue < this.key5DdlNameList.size(); keysIndexValue++) {
                if (keysIndexValue > 0) {
                    this.keysWhereClauseList.add(prevWhere + "=" + this.key5DdlNameList.get(keysIndexValue));
                }
                prevWhere = (String) this.key5DdlNameList.get(keysIndexValue);
            }
        }
    }

    /**
     * Method to build where clause filters while fetching date ranges for previous and next buttons.
     * @param AdhocRptDataTO
     * @param isRABCTbl
     * @return String whereClause 
    */
    private String getWhereClauseFilters(AdhocRptDataTO dto,boolean isRABCTbl) {
        StringBuffer prevWhere = new StringBuffer();
        List getDataTblDdlByDataTypeList = new ArrayList() ; 
        boolean isDateColumn = false ; 
        // for key1
        String keyColumn = null;
        boolean isDate = false;
        for (int i=0;i<dto.getDataKeyLvl();i++) {
        	keyColumn = (String)dto.getColumnsTablesList().get(i) + "." + (String)dto.getColumnsToExtractList().get(i);
        	/* Added an if condition in case for daily reports when it is created on a view and filter is selected.
        	This enables query to be created on table instead of view which actually does not exist*/
        	if (keyColumn.startsWith("VW_")){
        		//keyColumn=null;
        		int index = keyColumn.indexOf("VW_");
                int length = keyColumn.substring(index).indexOf('.');
                int end =keyColumn.length();
                String viewName=keyColumn.substring(0,length);
                String filter=keyColumn.substring(length,end);
                Connection conn = null;
                PreparedStatement ps = null;
                ResultSet rs = null;
                String tableName=null;
                try {
                	conn = ConnectionManager.getConnection(dto.getRegion());
                	String select="Select table_name from rabc_view where view_name=?";
        		    ps = conn.prepareStatement(select);
                    ps.setString(1, viewName);
                    rs = ps.executeQuery();
                    while (rs.next()) {
                        tableName = rs.getString(1);
                    }
                    keyColumn=tableName.concat(filter);
                } catch (SQLException sqle) {
                   logger.debug("Could not get a table name for user defined view" + sqle);
                } catch (NamingException ne) {
                   logger.debug("Could not get a table name for user defined view" + ne);
                } finally {
                    JDBCUtil.closeResultSet(rs);
                    JDBCUtil.closeStatement(ps);
                    JDBCUtil.closeConnection(conn);
                }
        	}
        	
        	int keyNum = i + 1;
        	if (keyColumn != null && !"".equals(keyColumn)) {
	        	switch (keyNum){
	        		case 1:
	        			 // Check for DIVISION KEY LEVEL -- Add IN clause  
	        			if (dto.getDivNameKeyLvl() == 1 && dto.getDivisionName1() != null && !dto.getDivisionName1().trim().equals(AdhocRptDAO.EMPTY) && !dto.getDivisionName1().trim().equals("''")) {
	        				prevWhere.append(keyColumn);
	        				prevWhere.append(" IN (");
	        				prevWhere.append(dto.getDivisionName1()) ; 
	        				prevWhere.append(" )");
	        			 } else if (dto.getSortKeyList()!=null && !"".equals(dto.getSortKeyList())){
	        				 // Check for key contains DATE field then convert it to To_DATE   
							try {
								Integer.parseInt(dto.getSortKeyList().substring(6, 10));
								getDataTblDdlByDataTypeList = StaticDataLoader.getDataTblDdlByDataType((String)dto.getColumnsTablesList().get(i), "D", true, dto.getRegion()) ;
								
								if (!getDataTblDdlByDataTypeList.isEmpty()) {
									 for (int j=0;j<getDataTblDdlByDataTypeList.size();j++) {
										 DataTblDdlBean bean = (DataTblDdlBean) (getDataTblDdlByDataTypeList.get(j)); 
										 if (((String)dto.getColumnsToExtractList().get(i)).equals(bean.getTblDdlName())){
											 isDateColumn = true ; 
											 break ; 
										 } 
									 }
									
								}
								if (isDateColumn && dto.getSortKeyList().substring(2, 3).equals("/") && dto.getSortKeyList().substring(5, 6).equals("/")) {
									isDateColumn = false ; 
									isDate = true;
								}
							} catch (NumberFormatException nmfe) {
								isDate = false;
								isDateColumn = false ; 
							} catch (StringIndexOutOfBoundsException iobe) {
								isDate = false;
								isDateColumn = false ; 
							}
							if (isDate) {
								prevWhere.append(keyColumn + "=" + "TO_DATE('" + dto.getSortKeyList() + "','MM/DD/YYYY')");
							} else {
								prevWhere.append("Trim(UPPER" + "(" + keyColumn + "))" + "=" + "'" + dto.getSortKeyList().toUpperCase() + "'");
							}
							isDate = false;
						}
						break;
	        		case 2:
	        			 // Check for DIVISION KEY LEVEL -- Add IN clause  
						if (dto.getDivNameKeyLvl() == 2 && dto.getDivisionName1() != null && !dto.getDivisionName1().trim().equals(AdhocRptDAO.EMPTY) && !dto.getDivisionName1().trim().equals("''")) {
							if (prevWhere.length() > 0) {
								prevWhere.append(" AND ");
							}
							prevWhere.append(keyColumn);
							prevWhere.append(" IN (");
							prevWhere.append(dto.getDivisionName1()) ; 
							prevWhere.append(" )");
						} else if (dto.getSortKeyList2()!=null && !"".equals(dto.getSortKeyList2())){
							// Check for key contains DATE field then convert it to To_DATE   
							try {
								Integer.parseInt(dto.getSortKeyList2().substring(6, 10));
								getDataTblDdlByDataTypeList = StaticDataLoader.getDataTblDdlByDataType((String)dto.getColumnsTablesList().get(i), "D", true, dto.getRegion()) ;
								if (!getDataTblDdlByDataTypeList.isEmpty()) {
									 for (int k=0;k<getDataTblDdlByDataTypeList.size();k++) {
										 DataTblDdlBean bean1 = (DataTblDdlBean) (getDataTblDdlByDataTypeList.get(k)); 
										 if (((String)dto.getColumnsToExtractList().get(i)).equals(bean1.getTblDdlName())){
										 
											 isDateColumn = true ; 
											 break ; 
										 } 
									 }
									
								}
								if (isDateColumn && dto.getSortKeyList2().substring(2, 3).equals("/") && dto.getSortKeyList2().substring(5, 6).equals("/")) {
									isDateColumn = false ; 
									isDate = true;
								}
							} catch (NumberFormatException nmfe) {
								isDate = false;
								isDateColumn = false ; 
							} catch (StringIndexOutOfBoundsException iobe) {
								isDateColumn = false ; 
								isDate = false;
							}
							if (isDate) {
								if (prevWhere.length() > 0) {
									prevWhere.append(" AND ");
								}
								prevWhere.append(keyColumn + "=" + "TO_DATE('" + dto.getSortKeyList2() + "','MM/DD/YYYY')");
							} else {
								if (prevWhere.length() > 0) {
									prevWhere.append(" AND ");
								}
								prevWhere.append("Trim(UPPER" + "(" + keyColumn + "))" + "=" + "'" + dto.getSortKeyList2().toUpperCase() + "'");
							}
						}
						break;
	        	}
	        }
        }
        
        // Add for file seq num
        // Find out here is source table contains file_seq_num_ind (RABC_DATA_TBL_DDL ) and then append where clause
        if  (!"N".equals(dto.getFileSeqNumInd())) {
        	if (isRABCTbl) {
                if (dto.getFileSeqNum() != -1) {
                	if (prevWhere.length() > 0) {
                		prevWhere.append(" AND ") ;
                	}
               	 prevWhere.append(dto.getPresnTblName() + ".file_seq_num = " + dto.getFileSeqNum()) ;
                 }
            } else {
                if (!(Integer.toString(dto.getFileSeqNum()).trim().equals(""))) {
                	if (prevWhere.length() > 0) {
                		prevWhere.append(" AND ") ;
                	}
               	 prevWhere.append(dto.getPresnTblName() + ".seq_num = " + dto.getFileSeqNum());
                 }
            }
        }
       
        // Add for alert time
         if (!Integer.toString(dto.getAlertTimeValue()).trim().equals("") && !dto.getAlertTimeInd().trim().equals("") && dto.getAlertTimeValue() > 0) {
             if (isRABCTbl) {
            	 if (prevWhere.length() > 0) {
             		prevWhere.append(" AND ") ;
             	}
            	 prevWhere.append(dto.getPresnTblName() + ".alert_trend_time = '" + dto.getAlertTimeValue() + "'");
             } else if (!dto.getAlertTimeInd().trim().equalsIgnoreCase("B")) {
        		 String procDateName = ((DataTblDdlBean) (StaticDataLoader.getDataTblDdlByAlertProcTbl(dto.getPresnTblName(), dto.getRegion()).get(0))).getTblProcDateDdlName();
        		 if (procDateName != null && !"".equals(procDateName)) {
        			 if (prevWhere.length() > 0) {
                 		prevWhere.append(" AND ") ;
                 	 }
        			 prevWhere.append("to_char(" + dto.getPresnTblName() + "." + procDateName + ",'D') = " + dto.getAlertTimeValue());
        		 }
            }
         }
        
        return prevWhere.toString() ; 
   	}

    
    /**
     * initialize DTO objects as necessary before start of each section
     * 
     * @param adhocRptDataTO
     */
    private void initAdhocRptDataTO(AdhocRptDataTO adhocRptDataTO) {
        adhocRptDataTO.getHeaderLinkIndList().clear();
        adhocRptDataTO.getHeaderMouseOverNumList().clear();
        adhocRptDataTO.getDataLinkIndList().clear();
        adhocRptDataTO.getDataDescIndList().clear();
        adhocRptDataTO.getDataMouseOverNumList().clear();
        adhocRptDataTO.getHeaderLinkToPgmList().clear();
        adhocRptDataTO.getHeaderLinkPresnIdList().clear();
        adhocRptDataTO.getDataLinkToPgmList().clear();
        adhocRptDataTO.getDataLinkPresnIdList().clear();
        adhocRptDataTO.getDataLinkTblKeyDataList().clear();
        adhocRptDataTO.getDataLinkTblNameList().clear();
        adhocRptDataTO.getDataLinkTblKeyNameList().clear();
        adhocRptDataTO.getGraphPresnIndList().clear();
        adhocRptDataTO.getPresnUnitIndList().clear();
        adhocRptDataTO.getPresnSumIndList().clear();
        adhocRptDataTO.getPresnCalcNumList().clear();
        adhocRptDataTO.getPresnSuppressIndList().clear();
        adhocRptDataTO.getViewNameList().clear();
        adhocRptDataTO.getPresnOrdIndList().clear();
        adhocRptDataTO.getPresnFormatList().clear();
        adhocRptDataTO.getPrevDataIndList().clear();
        adhocRptDataTO.getDiffDataIndList().clear();
        adhocRptDataTO.getPartiRefIdList().clear();
        adhocRptDataTO.getColumnsHeadersList().clear();
        adhocRptDataTO.getColumnsToExtractList().clear();
        adhocRptDataTO.getColumnsAsOracleList().clear();
        adhocRptDataTO.getColumnsTablesList().clear();
        adhocRptDataTO.getKeysRow1ColumnsList().clear();
        adhocRptDataTO.getKeysRow1AliasList().clear();
        adhocRptDataTO.getColumnsDataTypeList().clear();
    }


    /*
     * (non-Javadoc)
     * 
     * @see com.att.bac.rabc.adhoc.rpt.AdhocRptDAO#isButtonHidden(int, java.lang.String, java.lang.String)
     */
    public boolean isButtonHidden(int presnId, String webId, String button, String region) throws RABCException {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        boolean result = true;
        try {
            conn = ConnectionManager.getConnection(region);
            ps = conn.prepareStatement(QRY_GET_TOP_HEADER_LINKS);
            ps.setInt(1, presnId);
            ps.setString(2, webId);
            ps.setString(3, button);
            rs = ps.executeQuery();
            while (rs.next()) {
                result = false;
            }
        } catch (SQLException sqle) {
            throw new RABCException("Error in retrieving top header links", sqle);
        } catch (NamingException ne) {
            throw new RABCException("NamingException ", ne);
        } finally {
            JDBCUtil.closeResultSet(rs);
            JDBCUtil.closePreparedStatement(ps);
            JDBCUtil.closeConnection(conn);
        }
        return result;
    }


    /*
     * (non-Javadoc)
     * 
     * @see com.att.bac.rabc.adhoc.rpt.AdhocRptDAO#updateReportHeaders(com.att.bac.rabc.adhoc.rpt.AdhocRptDataTO)
     */
    public AdhocRptDataTO updateReportHeaders(AdhocRptDataTO dto) throws RABCException {
        Connection conn = null;
        PreparedStatement ps1 = null;
        ResultSet rs1 = null;

        try {
            conn = ConnectionManager.getConnection(dto.getRegion());
            ps1 = conn.prepareStatement(QRY_GET_HEADER_TEXT);
            ps1.setInt(1, dto.getPresnId());
            ps1.setString(2, dto.getWebId());
            rs1 = ps1.executeQuery();
            while (rs1.next()) {
                dto.setRptHeader1(rs1.getString(1) == null ? EMPTY : rs1.getString(1).trim());
                dto.setRptHeader2(rs1.getString(2) == null ? EMPTY : rs1.getString(2).trim());
                dto.setRptHeader3(rs1.getString(3) == null ? EMPTY : rs1.getString(3).trim());
                dto.setRptHeaderDateInd(rs1.getString(4) == null ? EMPTY : rs1.getString(4).trim());
            }
            
            return dto;
        } catch (SQLException sqle) {
            throw new RABCException("Error in retrieving report headers", sqle);
        } catch (NamingException ne) {
            throw new RABCException("NamingException ", ne);
        } finally {
            JDBCUtil.closeResultSet(rs1);
            JDBCUtil.closePreparedStatement(ps1);
            JDBCUtil.closeConnection(conn);
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.att.bac.rabc.adhoc.rpt.AdhocRptDAO#updateReportHeaders(com.att.bac.rabc.adhoc.rpt.AdhocRptDataTO)
     */
    public int getDataKeyLvl(AdhocRptDataTO dto) throws RABCException {
        Connection conn = null;
        PreparedStatement ps2 = null;
        ResultSet rs2 = null;
        int dataKeyLvl = 0;
        try {
        	conn = ConnectionManager.getConnection(dto.getRegion());
            ps2 = conn.prepareStatement(QRY_GET_ALERT_KEY_LVL);
            ps2.setInt(1, dto.getPresnId());
            rs2 = ps2.executeQuery();
            while (rs2.next()) {
                dataKeyLvl = rs2.getInt(1);
            }
            return dataKeyLvl;
        } catch (SQLException sqle) {
            throw new RABCException("Error in retrieving report headers", sqle);
        } catch (NamingException ne) {
            throw new RABCException("NamingException ", ne);
        } finally {
            JDBCUtil.closeResultSet(rs2);
            JDBCUtil.closePreparedStatement(ps2);
            JDBCUtil.closeConnection(conn);
        }
    }

    /**
     * Return the appropriate calulation object
     * 
     * @param dto
     * @param columnsPresnCalcNum
     * @param loopCount
     * @throws RABCException
     * @throws RABCException
     */
    public Calculation getCalcElem(AdhocRptDataTO dto, String columnsPresnCalcNum, int loopCount) throws RABCException {
        Calculation calc = new Calculation();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = ConnectionManager.getConnection(dto.getRegion());
            ps = conn.prepareStatement(QRY_GET_CALC_ELEM);
            ps.setInt(1, dto.getPresnId());
            ps.setString(2, dto.getWebId());
            ps.setInt(3, Integer.parseInt(columnsPresnCalcNum));
            ps.setInt(4, ((Integer) (dto.getDistExecPresnSeqNumList().get(loopCount))).intValue());
            ps.setInt(5, dto.getPresnId());
            ps.setString(6, dto.getWebId());
            ps.setInt(7, Integer.parseInt(columnsPresnCalcNum));
            ps.setInt(8, ((Integer) (dto.getDistExecPresnSeqNumList().get(loopCount))).intValue());
            rs = ps.executeQuery();
            while (rs.next()) {
            	calc.setPresnCalcName(rs.getString("PRESN_CALC_NAME"));
            	calc.setAlgebraicFormula(rs.getString("CALC_ELEM_USER_VIEW"));
                calc.setDivisionUsed(rs.getString("CALC_DIV_IND"));
                calc.setFormula(rs.getString("CALC_ELEM_FORMULA"));
                calc.setDisplayFormula(rs.getString("CALC_ELEM_DISPLAY"));
                calc.setPrecision(rs.getString("PRESN_FORMAT_CODE"));
                calc.setCalcElemSQLFormula(rs.getString("CALC_ELEM_SQL_FORMULA")) ;
            }
            
            int index = calc.getFormula().indexOf("VW_");
            while (index != -1) {
                String formula = calc.getFormula();
                int dot = formula.substring(index).indexOf('.')+index;
                String real = getTableNameFromView(dto, formula.substring(index, dot));
                formula = formula.substring(0, index) + real + formula.substring(dot);
                calc.setFormula(formula);
                index = calc.getFormula().indexOf("VW_");
            }
            
            
        } catch (SQLException sqle) {
            throw new RABCException("Error in retrieving calculation elements", sqle);
        } catch (NamingException ne) {
            throw new RABCException("NamingException ", ne);
        } catch (Exception e) {
            throw new RABCException("Exception ", e);
        } finally {
            JDBCUtil.closeResultSet(rs);
            JDBCUtil.closePreparedStatement(ps);
            JDBCUtil.closeConnection(conn);
            return calc;
        }
    }


    /**
     * 
     * @param dto
     * @param columnsPresnCalcNum
     * @param loopCount
     * @return
     * @throws RABCException
     */
    public Calculation getCalcElem(AdhocRptDataTO dto, int columnsPresnCalcNum, int loopCount) throws RABCException {
        return getCalcElem(dto, "" + columnsPresnCalcNum, loopCount);
    }


    /**
     * @param adhocRptDataTO
     * @param tblViewIndex
     * @throws RABCException
     */
    public String getTableNameFromView(AdhocRptDataTO dto, String view) throws RABCException {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = ConnectionManager.getConnection(dto.getRegion());
            ps = conn.prepareStatement(QRY_GET_TBL_FROM_VIEW);
            ps.setString(1, view);
            ps.setString(2, view);
            rs = ps.executeQuery();
            if (rs.next()) {
                String result = rs.getString(1);
                if (result != null) {
                    return rs.getString(1).trim();
                }
            }
            return "";
        } catch (SQLException sqle) {
            throw new RABCException("Error in retrieving table from view", sqle);
        } catch (NamingException ne) {
            throw new RABCException("NamingException ", ne);
        } finally {
            JDBCUtil.closeResultSet(rs);
            JDBCUtil.closePreparedStatement(ps);
            JDBCUtil.closeConnection(conn);
        }
    }
    
    /**
     * Method will get the previous valid proc Date
     * @param currentDate
     * @param dto
     * @return
     */
    public static Date getPreviousDate(String currentDate, AdhocRptDataTO dto){
    	Date previousFileDate = null;
    	Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        
        String sqlStmt = null;
        List args = new ArrayList();
        args.add(currentDate);
        
        try {
        	conn = ConnectionManager.getConnection(dto.getRegion());
        	MessageFormat mf = new MessageFormat(QRY_PREV_FILE_DATE);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			
			while (rs.next()){
				previousFileDate = rs.getDate(1);
			}
        } catch (SQLException sqle) {
           logger.debug("Could not get the previous date" + sqle);
        } catch (NamingException ne) {
           logger.debug("Could not get the previous date" + ne);
        } finally {
            JDBCUtil.closeResultSet(rs);
            JDBCUtil.closeStatement(stmt);
            JDBCUtil.closeConnection(conn);
        }
        
    	return previousFileDate;
    }

    /**
     * Method will get the previous valid proc Date
     * @param currentDate
     * @param dto
     * @return
     */
    public static Date getPreviousDateForBillRnd(String currentFileDate, AdhocRptDataTO dto){
    	Date previousFileDate = null;
    	Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        
        String sqlStmt = null;
        List args = new ArrayList();
        args.add(currentFileDate);
        
        try {
        	conn = ConnectionManager.getConnection(dto.getRegion());
        	MessageFormat mf = new MessageFormat(QRY_PREV_FILE_DATE_BILL_RND);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			
			while (rs.next()){
				previousFileDate = rs.getDate(1);
			}
        } catch (SQLException sqle) {
           logger.debug("Could not get the previous date for given bill round" + sqle);
        } catch (NamingException ne) {
           logger.debug("Could not get the previous date for given bill round" + ne);
        } finally {
            JDBCUtil.closeResultSet(rs);
            JDBCUtil.closeStatement(stmt);
            JDBCUtil.closeConnection(conn);
        }
        
    	return previousFileDate;
    }

    /**
     * Private method called to set the trend time
     * @param adhocRptDataTO
     * @throws RABCException
     */
    private void setPresnTrendTime(AdhocRptDataTO adhocRptDataTO) throws RABCException {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = ConnectionManager.getConnection(adhocRptDataTO.getRegion());
            ps = conn.prepareStatement(AdhocRptDAO.QRY_GET_PRESN_TREND_TIME);
            ps.setInt(1, adhocRptDataTO.getPresnId());
            rs = ps.executeQuery();
            while (rs.next()) {
                adhocRptDataTO.setPresnTrendTime(rs.getString(1) == null ? AdhocRptDAO.EMPTY : rs.getString(1).trim());
            }
        } catch (SQLException sqle) {
            throw new RABCException("Error in retrieving PRESN_TREND_TIME", sqle);
        } catch (NamingException ne) {
            throw new RABCException("NamingException ", ne);
        } finally {
            JDBCUtil.closeResultSet(rs);
            JDBCUtil.closePreparedStatement(ps);
            JDBCUtil.closeConnection(conn);
        }
    }
    
    /**
     * Method will get the previous set of proc dates
     * @param currentDate
     * @param dto
     * @return
     */
    public static List getBillRndPrevDates(AdhocRptDataTO dto){
    	Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        String sqlStmt = null;
        String mthString = null;
        if (dto.getMonthSelect()<10){
        	mthString = "0" + dto.getMonthSelect() + "-" + dto.getYearSelect();
        }else {
        	mthString = dto.getMonthSelect() + "-" + dto.getYearSelect();
        }
        List args = new ArrayList();
        args.add(mthString);
        
        List prevProcDates = new ArrayList();
        
        try {
        	conn = ConnectionManager.getConnection(dto.getRegion());
        	MessageFormat mf = new MessageFormat(QRY_GET_MONTHLY_OPTION_BILLDAY_PREVDATERANGE);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			
			while (rs.next()){
				if (prevProcDates.isEmpty()){
					prevProcDates.add(rs.getDate("PREV_START_PROC_DT"));
					prevProcDates.add(rs.getDate("PREV_END_PROC_DT"));
				}
			}
        } catch (SQLException sqle) {
           logger.debug("Could not get the previous dates" + sqle);
        } catch (NamingException ne) {
           logger.debug("Could not get the previous dates" + ne);
        } finally {
            JDBCUtil.closeResultSet(rs);
            JDBCUtil.closeStatement(stmt);
            JDBCUtil.closeConnection(conn);
        }
        
    	return prevProcDates;
    }
    
    /**
     * Method will return a map for list of valid months between the given date range
     * @param dto
     * @return
     */
    public static HashMap getBillDaySubTotalMonths(AdhocRptDataTO dto){
    	Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        String sqlStmt = null;
       
        List args = new ArrayList();
        args.add(dto.getStartDate());
        args.add(dto.getEndDate());
        
        HashMap billDayMonthMap = new HashMap();
        
        try {
        	conn = ConnectionManager.getConnection(dto.getRegion());
        	MessageFormat mf = new MessageFormat(QRY_GET_MONTHS_FOR_SUBTOTALLING);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			
			while (rs.next()){
				String mthString = rs.getString("PROC_MTH");
				String [] mthArr = mthString.split("-");
				mthString = mthArr[0] + "/" + mthArr[1];
				String endProcDt = rs.getString("END_PROC_DT_CHAR");
				billDayMonthMap.put(endProcDt, mthString);
			}
        } catch (SQLException sqle) {
           logger.debug("Could not get the previous dates" + sqle);
        } catch (NamingException ne) {
           logger.debug("Could not get the previous dates" + ne);
        } finally {
            JDBCUtil.closeResultSet(rs);
            JDBCUtil.closeStatement(stmt);
            JDBCUtil.closeConnection(conn);
        }
        
    	return billDayMonthMap;
    }
}
