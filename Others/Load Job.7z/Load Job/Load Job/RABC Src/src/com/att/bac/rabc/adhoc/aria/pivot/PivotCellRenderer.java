/*
 * Copyright  2002-2007 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.adhoc.aria.pivot;

import com.sbc.bac.aria.ARIAReportProcessor;

public interface PivotCellRenderer {
	String renderDataLabelCell(ARIAReportProcessor processor, String value, boolean escape);
	
	String renderDataValueCell(ARIAReportProcessor processor, int index, String headerName, String value, boolean escape);
	
	String renderKeyCell(ARIAReportProcessor processor, String label, String value, boolean escape,int index);
}
