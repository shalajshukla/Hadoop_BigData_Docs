/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * This is a custom Date class used to convert from String representation of date to Date form.
 * 
 * @author Vijay Dubey - VD3159
 */
public class MyDate extends Date {
	
	/**
	 * Default constructor. It calls the its default super method.
	 */
	public MyDate() {
		super();
	}
	
	/**
	 * Constructor which accepts Date object.
	 * It calls the super method with date.
	 * 
	 * @param date
	 */
	public MyDate(Date date){
		super.setTime(date.getTime());
	}
	
	/**
	 * Constructor which accepts String representation of date.
	 * It calls the super method with date.
	 * 
	 * @param dateString
	 * @throws ParseException
	 */
	public MyDate(String dateString) throws ParseException {
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date d2 = dateFormat.parse(dateString);
		if (d2 == null) throw new ParseException(dateString, 0);
		super.setTime(d2.getTime());
	}

	/**
	 * Constructor which accepts String representation of date and format.
	 * It calls the super method with date.
	 * 
	 * @param dateString
	 * @param format
	 * @throws ParseException
	 */
	public MyDate(String dateString, String format) throws ParseException {
		SimpleDateFormat tmpDateFormat = new SimpleDateFormat(format);
		Date d2 = tmpDateFormat.parse(dateString);
		if (d2 == null) throw new ParseException(dateString, 0);
		super.setTime(d2.getTime());
	}
	
	/**
	 * Overriding toString() method to return the String representation of this object.
	 * 
	 * @return String
	 * @throws ParseException
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		return dateFormat.format(this);
	}
	
	/**
	 * Method to return the String representation of this object in "HH:MM:SS" format.
	 * 
	 * @return String
	 */
	public String getHHMMSS() {
		SimpleDateFormat timeFormat = new SimpleDateFormat("HH:MM:SS");
		return timeFormat.format(this);
	}
	
	/**
	 * Overriding compareTo(Date) method to compare this object with passed object.
	 * 
	 * @param d1
	 * @return int
	 * @see java.util.Date#compareTo(java.util.Date)
	 */
	public int compareTo(Date d1) {
		// Compares only MM, DD and YYYY
		// returns 0 if this = arg
		// returns -1 if this < arg
		// returns 1 if this > arg
		int thisYear = 0, thisMonth = 0, thisDay = 0;
		int argYear = 0, argMonth = 0, argDay = 0;
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		String thisString = dateFormat.format(this);
		String argString = dateFormat.format(d1);
		thisYear = new Integer(thisString.substring(6)).intValue();
		thisMonth = new Integer(thisString.substring(0 , 2)).intValue();
		thisDay = new Integer(thisString.substring(3 , 5)).intValue();
		
		argYear = new Integer(argString.substring(6)).intValue();
		argMonth = new Integer(argString.substring(0 , 2)).intValue();
		argDay = new Integer(argString.substring(3 , 5)).intValue();
		if (thisYear == argYear) {
			if (thisMonth == argMonth) {
				if (thisDay == argDay) {
					// both dates are same
					return 0;
				} else {
					if (thisDay < argDay) {
						// this date is before Argument date
						return -1;
					} else {
						//	this date is before Argument date
						return 1;
					}
				}				
			} else {
				if (thisMonth < argMonth) {
					// this date is before Argument date
					return -1;
				} else {
					//	this date is before Argument date
					return 1;					
				}
			}
		} else {
			if (thisYear < argYear) {
				// this date is before Argument date
				return -1;
			} else {
				//	this date is before Argument date
				return 1;					
			}
		}
	}
	
	/**
	 * Method to add days to this date. Will be used as an adjust() function to return date corresponding to 
	 * +/- no of days from this date.
	 * 
	 * @param days
	 */
	public void doAdd(int days) {
		Calendar now = Calendar.getInstance();
		Calendar working = null;;

		working = (Calendar) now.clone();
		working.setTime(this);		
		working.add(Calendar.DAY_OF_YEAR, days);
		super.setTime(working.getTimeInMillis());
	}
}
