/*
 * Copyright  2002-2006 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.adhoc.aria.pivot;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;


public class ReportMatrix implements Comparator {
    private Set cells = new HashSet();

    private DataCell[][] matrix;


    /**
     * Add a data cell
     * 
     * @param row
     * @param column
     * @param value
     * @param key
     */
    public DataCell addCell(int row, int column, Object value, DatedCompositeKey key) {
        DataCell cell = new DataCell();
        cell.setRow(row);
        cell.setColumn(column);
        cell.setValue(value);
        cell.setDatedCompositeKey(key);
        cells.add(cell);
        return cell;
    }


    /**
     * Add a data cell
     * 
     * @param row
     * @param column
     * @param value
     * @param key
     * @return
     */
    public DataCell addPreviousCell(int row, int column, Object value, DatedCompositeKey key) {
        DataCell cell = addCell(row, column, value, key);
        cell.setPreviousData(true);
        return cell;
    }


    /**
     * Pivot the report. If this is called a second time it will revert the report to it's previous state.
     */
    public void pivot() {
        DataCell[] cellArray = getCells();
        for (int i = 0; i < cellArray.length; i++) {
            int tempRow = cellArray[i].getRow();
            cellArray[i].setRow(cellArray[i].getColumn());
            cellArray[i].setColumn(tempRow);
        }
        resetCellMatrix();
    }


    /**
     * Get the cells as an array.
     * 
     * @return
     */
    public DataCell[] getCells() {
        List temp = new ArrayList(cells);
        Collections.sort(temp, this);
        return (DataCell[]) temp.toArray(new DataCell[cells.size()]);
    }


    /**
     * Resets the cells as a matrix; a two-dimensional array [row][column] order
     * 
     * @return
     */
    public void resetCellMatrix() {
        matrix = new DataCell[getMaxRow()][getMaxColumns()];
        DataCell[] cc = getCells();
        for (int i = 0; i < cc.length; i++) {
            matrix[cc[i].getRow()][cc[i].getColumn()] = cc[i];
        }
    }


    /**
     * Get the maximum number of rows in the report.
     * 
     * @return
     */
    public int getMaxRow() {
        if (matrix != null) {
            return matrix.length;
        }
        int max = 0;
        Iterator i = cells.iterator();
        while (i.hasNext()) {
            DataCell element = (DataCell) i.next();
            if (element.getRow() > max) {
                max = element.getRow();
            }
        }
        return max + 1;
    }


    /**
     * Get the maximum number of columns in the report.
     * 
     * @return
     */
    public int getMaxColumns() {
        if (matrix != null) {
            return matrix[0].length;
        }
        int max = 0;
        Iterator i = cells.iterator();
        while (i.hasNext()) {
            DataCell element = (DataCell) i.next();
            if (element.getColumn() > max) {
                max = element.getColumn();
            }
        }
        return max + 1;
    }


    /**
     * Convenience method to filter to a single row from an array of cells.
     * 
     * @param row
     * @return
     */
    public DataCell[] getRow(int row) {
        DataCell[] cells = getCells();
        List list = new ArrayList();
        for (int i = 0; i < cells.length; i++) {
            if (cells[i].getRow() == row) {
                list.add(cells[i]);
            }
        }
        return (DataCell[]) list.toArray(new DataCell[list.size()]);
    }


    /*
     * (non-Javadoc)
     * 
     * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
     */
    public int compare(Object o1, Object o2) {
        DataCell c1 = (DataCell) o1;
        DataCell c2 = (DataCell) o2;
        int x = c1.getRow() - c2.getRow();
        if (x != 0) {
            return x;
        }
        return c1.getColumn() - c2.getColumn();
    }


    /**
     * @param row
     * @param column
     * @return
     */
    public DataCell getCellAt(int row, int column) {
        if ((row >= matrix.length) || (column >= matrix[0].length)) {
            return null;
        }
        return matrix[row][column];
    }

}
