/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.alerts.status;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.att.bac.rabc.MyDate;

/**
 * This class represents the data object that contains the attributes to be 
 * shown on the Alert Report Detail page.
 * 
 * @author Abhilash - AC6952
 */
public class AlertReportDetail {
	private boolean alertSelectIndicator = false;
	private boolean alertSelectIndicator1 = false;
	private int updateAccess;
	private String alertRule;
	private int msgNo;
	private Integer fileSeqNum;
	private int alertKeyLevel;
	private String alertKey1;
	private String alertKey2;
	private String alertKey3;
	private String alertKey4;
	private String alertKey5;
	private String alertData1;
	private String alertData2;
	private String alertData3;
	private String alertData4;
	private String alertData5;
	private MyDate procDate;
	private String alertItem;
	private Double alertPct;
	private Double alertActual;
	private String alertStatus;
	private String alertSeverityLevelInd;
	private String graphUrl;
	private int alertSysErrCd;
	private String alertSysErrDesc;
	private String alertSuppInd;
	private List alertSuppInfoList = new ArrayList();
	private Double alertRevenue;
	private Double alertLostRevenue;
	private List alertRootCatgyList = new ArrayList();
	private String alertRootCause;
	private List alertGroupList = new ArrayList();
	private MyDate timeStamp;
	private MyDate alertRuleRunDate;
	private int keyRow = 0;
	private String alertTimeValue;
	private String alertTimeInd;
	private String alertMsg;
	private String alertType;
	private int presnId;
	private String divisionDesc;
	
	private String alertMouseOver1 = "";
	private String alertMouseOver2 = "";
	private String alertMouseOver3 = "";
	private String alertMouseOver4 = "";
	private String alertMouseOver5 = "";
	
	private Map alertKeyAbbrevationMap = new HashMap();
	
	/**
	 * @return Returns the alertSelectIndicator.
	 */
	public boolean isAlertSelectIndicator() {
		return alertSelectIndicator;
	}
	/**
	 * @param alertSelectIndicator The alertSelectIndicator to set.
	 */
	public void setAlertSelectIndicator(boolean alertSelectIndicator) {
		this.alertSelectIndicator = alertSelectIndicator;
	}
	/**
	 * @return Returns the alertActual.
	 */
	public Double getAlertActual() {
		return alertActual;
	}
	/**
	 * @param alertActual The alertActual to set.
	 */
	public void setAlertActual(Double alertActual) {
		this.alertActual = alertActual;
	}
	/**
	 * @return Returns the alertData1.
	 */
	public String getAlertData1() {
		return alertData1;
	}
	/**
	 * @param alertData1 The alertData1 to set.
	 */
	public void setAlertData1(String alertData1) {
		this.alertData1 = alertData1;
	}
	/**
	 * @return Returns the alertData2.
	 */
	public String getAlertData2() {
		return alertData2;
	}
	/**
	 * @param alertData2 The alertData2 to set.
	 */
	public void setAlertData2(String alertData2) {
		this.alertData2 = alertData2;
	}
	/**
	 * @return Returns the alertData3.
	 */
	public String getAlertData3() {
		return alertData3;
	}
	/**
	 * @param alertData3 The alertData3 to set.
	 */
	public void setAlertData3(String alertData3) {
		this.alertData3 = alertData3;
	}
	/**
	 * @return Returns the alertData4.
	 */
	public String getAlertData4() {
		return alertData4;
	}
	/**
	 * @param alertData4 The alertData4 to set.
	 */
	public void setAlertData4(String alertData4) {
		this.alertData4 = alertData4;
	}
	/**
	 * @return Returns the alertData5.
	 */
	public String getAlertData5() {
		return alertData5;
	}
	/**
	 * @param alertData5 The alertData5 to set.
	 */
	public void setAlertData5(String alertData5) {
		this.alertData5 = alertData5;
	}
	/**
	 * @return Returns the alertGroupList.
	 */
	public List getAlertGroupList() {
		return alertGroupList;
	}
	/**
	 * @param alertGroupList The alertGroupList to add.
	 */
	public void addAlertGroup(String alertGroup) {
		this.alertGroupList.add(alertGroup);
	}
	
	/**
	 * @return Returns the alertItem.
	 */
	public String getAlertItem() {
		return alertItem;
	}
	/**
	 * @param alertItem The alertItem to set.
	 */
	public void setAlertItem(String alertItem) {
		this.alertItem = alertItem;
	}
	/**
	 * @return Returns the alertKey1.
	 */
	public String getAlertKey1() {
		if(alertKey1 == null) { 
			return alertKey1;
		}
		else {
			return alertKey1.substring(0,1) + alertKey1.substring(1).toLowerCase().replace('_', ' ').replace('-', ' ');
		}	
	}
	/**
	 * @param alertKey1 The alertKey1 to set.
	 */
	public void setAlertKey1(String alertKey1) {
		this.alertKey1 = alertKey1;
	}
	/**
	 * @return Returns the alertKey2.
	 */
	public String getAlertKey2() {
		if(alertKey2 == null) { 
			return alertKey2;
		}
		else {
			return alertKey2.substring(0,1) + alertKey2.substring(1).toLowerCase().replace('_', ' ').replace('-', ' ');
		}
	}
	/**
	 * @param alertKey2 The alertKey2 to set.
	 */
	public void setAlertKey2(String alertKey2) {
		this.alertKey2 = alertKey2;
	}
	/**
	 * @return Returns the alertKey3.
	 */
	public String getAlertKey3() {
		if(alertKey3 == null) { 
			return alertKey3;
		}
		else {
			return alertKey3.substring(0,1) + alertKey3.substring(1).toLowerCase().replace('_', ' ').replace('-', ' ');
		}	
	}
	/**
	 * @param alertKey3 The alertKey3 to set.
	 */
	public void setAlertKey3(String alertKey3) {
		this.alertKey3 = alertKey3;
	}
	/**
	 * @return Returns the alertKey4.
	 */
	public String getAlertKey4() {
		if(alertKey4 == null) { 
			return alertKey4;
		}
		else {
			return alertKey4.substring(0,1) + alertKey4.substring(1).toLowerCase().replace('_', ' ').replace('-', ' ');
		}	
	}
	/**
	 * @param alertKey4 The alertKey4 to set.
	 */
	public void setAlertKey4(String alertKey4) {
		this.alertKey4 = alertKey4;
	}
	/**
	 * @return Returns the alertKey5.
	 */
	public String getAlertKey5() {
		if(alertKey5 == null) { 
			return alertKey5;
		}
		else {
			return alertKey5.substring(0,1) + alertKey5.substring(1).toLowerCase().replace('_', ' ').replace('-', ' ');
		}	
	}
	/**
	 * @param alertKey5 The alertKey5 to set.
	 */
	public void setAlertKey5(String alertKey5) {
		this.alertKey5 = alertKey5;
	}
	
	/**
	 * @return Returns the alertKeyLevel.
	 */
	public int getAlertKeyLevel() {
		return alertKeyLevel;
	}
	/**
	 * @param alertKeyLevel The alertKeyLevel to set.
	 */
	public void setAlertKeyLevel(int alertKeyLevel) {
		this.alertKeyLevel = alertKeyLevel;
	}
	/**
	 * @return Returns the alertMsg.
	 */
	public String getAlertMsg() {
		return alertMsg;
	}
	/**
	 * @param alertMsg The alertMsg to set.
	 */
	public void setAlertMsg(String alertMsg) {
		this.alertMsg = alertMsg;
	}
	/**
	 * @return Returns the alertPct.
	 */
	public Double getAlertPct() {
		return alertPct;
	}
	/**
	 * @param alertPct The alertPct to set.
	 */
	public void setAlertPct(Double alertPct) {
		this.alertPct = alertPct;
	}
	/**
	 * @return Returns the alertRevenue.
	 */
	public Double getAlertRevenue() {
		return alertRevenue;
	}
	/**
	 * @param alertRevenue The alertRevenue to set.
	 */
	public void setAlertRevenue(Double alertRevenue) {
		this.alertRevenue = alertRevenue;
	}
	
	/**
	 * @return Returns the alertRootCatgyList.
	 */
	public List getAlertRootCatgyList() {
		return alertRootCatgyList;
	}
	/**
	 * @param alertRootCatgy The alertRootCatgy to add.
	 */
	public void addAlertRootCatgy(String alertRootCatgy) {
		this.alertRootCatgyList.add(alertRootCatgy);
	}
	/**
	 * @return Returns the alertRule.
	 */
	public String getAlertRule() {
		return alertRule;
	}
	/**
	 * @param alertRule The alertRule to set.
	 */
	public void setAlertRule(String alertRule) {
		this.alertRule = alertRule;
	}
	/**
	 * @return Returns the alertRuleRunDate.
	 */
	public MyDate getAlertRuleRunDate() {
		return alertRuleRunDate;
	}
	/**
	 * @param alertRuleRunDate The alertRuleRunDate to set.
	 */
	public void setAlertRuleRunDate(MyDate alertRuleRunDate) {
		this.alertRuleRunDate = alertRuleRunDate;
	}
	/**
	 * @return Returns the alertSeverityLevelInd.
	 */
	public String getAlertSeverityLevelInd() {
		return alertSeverityLevelInd;
	}
	/**
	 * @param alertSeverityLevelInd The alertSeverityLevelInd to set.
	 */
	public void setAlertSeverityLevelInd(String alertSeverityLevelInd) {
		this.alertSeverityLevelInd = alertSeverityLevelInd;
	}
	/**
	 * @return Returns the alertStatus.
	 */
	public String getAlertStatus() {
		return alertStatus;
	}
	/**
	 * @param alertStatus The alertStatus to set.
	 */
	public void setAlertStatus(String alertStatus) {
		this.alertStatus = alertStatus;
	}
	/**
	 * @return Returns the alertSuppInd.
	 */
	public String getAlertSuppInd() {
		return alertSuppInd;
	}
	/**
	 * @param alertSuppInd The alertSuppInd to set.
	 */
	public void setAlertSuppInd(String alertSuppInd) {
		this.alertSuppInd = alertSuppInd;
	}
	/**
	 * @return Returns the alertSysErrCd.
	 */
	public int getAlertSysErrCd() {
		return alertSysErrCd;
	}
	/**
	 * @param alertSysErrCd The alertSysErrCd to set.
	 */
	public void setAlertSysErrCd(int alertSysErrCd) {
		this.alertSysErrCd = alertSysErrCd;
	}
	/**
	 * @return Returns the alertSysErrDesc.
	 */
	public String getAlertSysErrDesc() {
		return alertSysErrDesc;
	}
	/**
	 * @param alertSysErrDesc The alertSysErrDesc to set.
	 */
	public void setAlertSysErrDesc(String alertSysErrDesc) {
		this.alertSysErrDesc = alertSysErrDesc;
	}
	/**
	 * @return Returns the alertTimeInd.
	 */
	public String getAlertTimeInd() {
		return alertTimeInd;
	}
	/**
	 * @param alertTimeInd The alertTimeInd to set.
	 */
	public void setAlertTimeInd(String alertTimeInd) {
		this.alertTimeInd = alertTimeInd;
	}
	/**
	 * @return Returns the alertTimeValue.
	 */
	public String getAlertTimeValue() {
		return alertTimeValue;
	}
	/**
	 * @param alertTimeValue The alertTimeValue to set.
	 */
	public void setAlertTimeValue(String alertTimeValue) {
		this.alertTimeValue = alertTimeValue;
	}
	/**
	 * @return Returns the alertType.
	 */
	public String getAlertType() {
		return alertType;
	}
	/**
	 * @param alertType The alertType to set.
	 */
	public void setAlertType(String alertType) {
		this.alertType = alertType;
	}
	/**
	 * @return Returns the fileSeqNum.
	 */
	public Integer getFileSeqNum() {
		return fileSeqNum;
	}
	/**
	 * @param fileSeqNum The fileSeqNum to set.
	 */
	public void setFileSeqNum(Integer fileSeqNum) {
		this.fileSeqNum = fileSeqNum;
	}
	/**
	 * @return Returns the msgNo.
	 */
	public int getMsgNo() {
		return msgNo;
	}
	/**
	 * @param msgNo The msgNo to set.
	 */
	public void setMsgNo(int msgNo) {
		this.msgNo = msgNo;
	}
	/**
	 * @return Returns the presnId.
	 */
	public int getPresnId() {
		return presnId;
	}
	/**
	 * @param presnId The presnId to set.
	 */
	public void setPresnId(int presnId) {
		this.presnId = presnId;
	}
	/**
	 * @return Returns the procDate.
	 */
	public MyDate getProcDate() {
		return procDate;
	}
	/**
	 * @param procDate The procDate to set.
	 */
	public void setProcDate(MyDate procDate) {
		this.procDate = procDate;
	}
	/**
	 * @return Returns the timeStamp.
	 */
	public MyDate getTimeStamp() {
		return timeStamp;
	}
	/**
	 * @param timeStamp The timeStamp to set.
	 */
	public void setTimeStamp(MyDate timeStamp) {
		this.timeStamp = timeStamp;
	}
	/**
	 * @return Returns the updateAccess.
	 */
	public int getUpdateAccess() {
		return updateAccess;
	}
	/**
	 * @param updateAccess The updateAccess to set.
	 */
	public void setUpdateAccess(int updateAccess) {
		this.updateAccess = updateAccess;
	}
	/**
	 * @return Returns the alertRootCause.
	 */
	public String getAlertRootCause() {
		return alertRootCause;
	}
	/**
	 * @param alertRootCause The alertRootCause to set.
	 */
	public void setAlertRootCause(String alertRootCause) {
		this.alertRootCause = alertRootCause;
	}
	/**
	 * @return Returns the alertSelectIndicator1.
	 */
	public boolean isAlertSelectIndicator1() {
		return alertSelectIndicator1;
	}
	/**
	 * @param alertSelectIndicator1 The alertSelectIndicator1 to set.
	 */
	public void setAlertSelectIndicator1(boolean alertSelectIndicator1) {
		this.alertSelectIndicator1 = alertSelectIndicator1;
	}
	/**
	 * @return Returns the keyRow.
	 */
	public int getKeyRow() {
		return keyRow;
	}
	/**
	 * @param keyRow The keyRow to set.
	 */
	public void setKeyRow(int keyRow) {
		this.keyRow = keyRow;
	}
	/**
	 * @return Returns the graphUrl.
	 */
	public String getGraphUrl() {
		return graphUrl;
	}
	/**
	 * @param graphUrl The graphUrl to set.
	 */
	public void setGraphUrl(String graphUrl) {
		this.graphUrl = graphUrl;
	}
	/**
	 * @return Returns the alertLostRevenue.
	 */
	public Double getAlertLostRevenue() {
		return alertLostRevenue;
	}
	/**
	 * @param alertLostRevenue The alertLostRevenue to set.
	 */
	public void setAlertLostRevenue(Double alertLostRevenue) {
		this.alertLostRevenue = alertLostRevenue;
	}
	
	/**
	 * @return Returns the alertSuppInfoList.
	 */
	public List getAlertSuppInfoList() {
		return alertSuppInfoList;
	}
	/**
	 * @param alertSuppInfo The alertSuppInfo to add.
	 */
	public void addAlertSuppInfo(AlertSuppInfo alertSuppInfo) {
		this.alertSuppInfoList.add(alertSuppInfo);
	}
	/**
	 * @return Returns the divisionDesc.
	 */
	public String getDivisionDesc() {
		return divisionDesc;
	}
	/**
	 * @param divisionDesc The divisionDesc to set.
	 */
	public void setDivisionDesc(String divisionDesc) {
		this.divisionDesc = divisionDesc;
	}
	/**
	 * @return the alertMouseOver1
	 */
	public String getAlertMouseOver1() {
		return alertMouseOver1;
	}
	/**
	 * @param alertMouseOver1 the alertMouseOver1 to set
	 */
	public void setAlertMouseOver1(String alertMouseOver1) {
		this.alertMouseOver1 = alertMouseOver1;
	}
	/**
	 * @return the alertMouseOver2
	 */
	public String getAlertMouseOver2() {
		return alertMouseOver2;
	}
	/**
	 * @param alertMouseOver2 the alertMouseOver2 to set
	 */
	public void setAlertMouseOver2(String alertMouseOver2) {
		this.alertMouseOver2 = alertMouseOver2;
	}
	/**
	 * @return the alertMouseOver3
	 */
	public String getAlertMouseOver3() {
		return alertMouseOver3;
	}
	/**
	 * @param alertMouseOver3 the alertMouseOver3 to set
	 */
	public void setAlertMouseOver3(String alertMouseOver3) {
		this.alertMouseOver3 = alertMouseOver3;
	}
	/**
	 * @return the alertMouseOver4
	 */
	public String getAlertMouseOver4() {
		return alertMouseOver4;
	}
	/**
	 * @param alertMouseOver4 the alertMouseOver4 to set
	 */
	public void setAlertMouseOver4(String alertMouseOver4) {
		this.alertMouseOver4 = alertMouseOver4;
	}
	/**
	 * @return the alertMouseOver5
	 */
	public String getAlertMouseOver5() {
		return alertMouseOver5;
	}
	/**
	 * @param alertMouseOver5 the alertMouseOver5 to set
	 */
	public void setAlertMouseOver5(String alertMouseOver5) {
		this.alertMouseOver5 = alertMouseOver5;
	}
	/**
	 * @return the alertKeyAbbrevationMap
	 */
	public Map getAlertKeyAbbrevationMap() {
		return alertKeyAbbrevationMap;
	}
	/**
	 * @param alertKeyAbbrevationMap the alertKeyAbbrevationMap to set
	 */
	public void setAlertKeyAbbrevationMap(Map alertKeyAbbrevationMap) {
		this.alertKeyAbbrevationMap = alertKeyAbbrevationMap;
	}
}
