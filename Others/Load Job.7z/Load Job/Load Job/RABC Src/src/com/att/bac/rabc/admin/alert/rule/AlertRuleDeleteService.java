/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.admin.alert.rule;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import com.att.bac.rabc.PickList;
import com.att.bac.rabc.PresnIdDAO;
import com.att.bac.rabc.ProgressBar;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.StaticDataLoader;

import org.apache.log4j.Logger;

/**
 * This is a Service class for Alert Rule Deletion
 * 
 * @author Shailesh Hemdev - SH8512
 */
public class AlertRuleDeleteService {
	private static final Logger logger = Logger.getLogger(AlertRuleDeleteService.class);
	private static AlertRuleDeleteService alertRuleDeleteService; 
	
	protected static final String GetAlRule = "SELECT BAR.ALERT_RULE, BAR.PARTI_REF_ID, BAR.PRESN_ID, " +
	"BAR.FILE_VERIF_IND, BAR.DATA_EXTRCT_IND, BAR.DATA_CALC_IND, BAR.CALC_RULE, BAR.WARNING_IND, BAR.AVG_IND, BAR.ALERT_MSG_IND, " +
	"BAR.ALERT_SEQ_NUM_IND, BAR.ALERT_TIME_IND, BAR.ALERT_DASH_FRESH_IND, BAR.ALERT_DESC, BAR.ALERT_EXEC_DATE, BAR.ALERT_KEY_LVL, " +
	"BAR.ALERT_KEY1_NAME, BAR.ALERT_KEY2_NAME, BAR.ALERT_KEY3_NAME, BAR.ALERT_KEY4_NAME, BAR.ALERT_KEY5_NAME, BAR.ALERT_FILE_CT, " +
	"BAR.ASOC_FILE_ID, BAR.ALERT_RULE_PRESN_IND, BAR.DIVISION_NAME_KEY_LVL, BAR.DB_NODE_ID, BAR.ALERT_RULE_STATUS, BAR.EFF_DATE, " +
	"BAR.STD_TYPE, BAR.ALERT_EXEMPT_IND, BAR.USER_ID, BAR.TIME_STAMP, BAR.ALERT_DATA_KEEP, BAR.ALERT_RULE_TYPE, BAR.ALERT_MNTH_EXEC_DAY, BAR.ALERT_MNTH_EXEC_BILL_RND " +
	"FROM RABC_ALERT_RULE BAR, RABC_PRESN_ID BPI WHERE ALERT_RULE = ''{0}'' AND BPI.Presn_ID = BAR.Presn_ID";
	
	protected static final String GetAlGrp = "";
	protected static final String GETCNTRLPT = "";
	
	protected static final String GETPRESNID = "Select Distinct Presn_id from RABC_ALERT_RULE where alert_rule = ''{0}''";
	
	protected static final String delRABC_ARULE = "Update RABC_ALERT_RULE SET ALERT_RULE_STATUS = ''DELETED'' where alert_rule=''{0}''";
	
	protected static final String delRABC_PRESN_ID = "Update RABC_PRESN_ID SET ADHOC_RPT_STATUS = ''DELETED'' where PRESN_ID=''{0}''";
	
	protected static final String GETSysALRA = "Select * from RABC_ALERT_RULE Where alert_rule=''{0}''";
	
	protected static final String GETSysALRD = "Select * from RABC_ALERT_RULE Where alert_rule=''{0}''";
	
	protected static final String GETSysALRI = "Select * from RABC_ALERT_RULE Where alert_rule=''{0}''";
	
	protected static final String GETPRESNID_SYSA = "Select Distinct Presn_id from RABC_ALERT_RULE where alert_rule = ''{0}'";
	
	protected static final String delRABC_ARULE_SYSA = "Update RABC_ALERT_RULE SET ALERT_RULE_STATUS = ''DELETED'' where alert_rule=''{0}''";
	
	protected static final String delRABC_PRESN_ID_SYSA = "Update RABC_PRESN_ID SET ADHOC_RPT_STATUS = ''DELETED'' where PRESN_ID=''{0}''";
	
	protected static final String GETPRESNID_SYSD = "Select Distinct Presn_id from RABC_ALERT_RULE where alert_rule = ''{0}''";
	
	protected static final String delRABC_ARULE_SYSD = "Update RABC_ALERT_RULE SET ALERT_RULE_STATUS = ''DELETED'' where alert_rule=''{0}''";
	
	protected static final String delRABC_PRESN_ID_SYSD = "Update RABC_PRESN_ID SET ADHOC_RPT_STATUS = ''DELETED'' where PRESN_ID=''{0}''";
	
	protected static final String GETPRESNID_SYSI = "Select Distinct Presn_id from RABC_ALERT_RULE where alert_rule = ''{0}''";
	
	protected static final String delRABC_ARULE_SYSI = "Update RABC_ALERT_RULE SET ALERT_RULE_STATUS = ''DELETED'' where alert_rule=''{0}''";
	
	protected static final String delRABC_PRESN_ID_SYSI = "Update RABC_PRESN_ID SET ADHOC_RPT_STATUS = ''DELETED'' where PRESN_ID=''{0}''";

	/**
	 * Synchronized method to return the instance of AlertRuleDeleteService object.
	 * It checks the existance of the instance of AlertRuleDeleteService and if it does not exists
	 * then creates one instance of AlertRuleDeleteService and returns otherwise it returns the
	 * existing instance of AlertRuleDeleteService.
	 * 
	 * @return AlertRuleDeleteService
	 */
	public static synchronized AlertRuleDeleteService getAlertRuleDeleteService(){
		
		if (alertRuleDeleteService == null){
			alertRuleDeleteService = new AlertRuleDeleteService();
		}
		return alertRuleDeleteService;
	}
	
	/**
	 * Returns Alert Rule details for the alert rule to be deleted. 
	 * 
	 * @param connection
	 * @param failures
	 * @param args
	 * @param alertRuleDefinition
	 * @param progressBar
	 * @param region
	 * @return AlertRuleDefinition
	 */
	protected AlertRuleDefinition getAlertRuleDefinition(Connection connection, List failures, List args, AlertRuleDefinition alertRuleDefinition, ProgressBar progressBar, String region){		
		List alertRuleNameList = new ArrayList();
		alertRuleNameList.add(args.get(0));
		String alertRuleName = (String)args.get(0);
	
		AlertRule alertRule = AlertRuleDefinitionService.getAlertRuleDefinitionService().getAlertRule(connection,failures,alertRuleNameList,GetAlRule);
		AlertRuleDefinitionService.getAlertRuleDefinitionService().updateFromAlertRule(alertRuleDefinition,alertRule,region);
		progressBar.setProgressPercent(20);
		/*
		 * Get the control point tagged to this alert rule
		 */
		AlertRuleDefinitionService.getAlertRuleDefinitionService().setControlPoint(connection, failures, alertRuleNameList, alertRuleDefinition);
		progressBar.setProgressPercent(40);
		/*
		 * Get the alert groups tagged to this alert rule
		 */
		List userId = new ArrayList();
		userId.add(args.get(1));
		AlertRuleDefinitionService.getAlertRuleDefinitionService().setAlertGroupsList(connection,failures,userId,alertRuleDefinition);
		progressBar.setProgressPercent(60);
		
		/*
		 * Get the db node description 
		 */
		List dbNodeDetailsList = StaticDataLoader.getDBNodeByID(alertRule.getDbNodeId(), region);
		if (!dbNodeDetailsList.isEmpty()){
			PickList dbNodeDetails = (PickList)dbNodeDetailsList.get(0);
			alertRuleDefinition.setDataSource((String)dbNodeDetails.getValue1());
		}
		alertRuleDefinition.setAlertRule(alertRule.getAlertRule());
		
		AlertRuleDefinitionService.getAlertRuleDefinitionService().setAvgRecDaysTypeAndTiming(connection,failures,alertRuleNameList,alertRuleDefinition);
		progressBar.setProgressPercent(80);
		
		List presnIdArgs = new ArrayList();
		presnIdArgs.add(new Integer(alertRule.getPresnId()).toString());
		AlertRuleDefinitionService.getAlertRuleDefinitionService().setFileSeqIndicator(connection,failures,presnIdArgs,alertRuleDefinition);
		progressBar.setProgressPercent(90);
		
		AlertRuleDefinitionService.getAlertRuleDefinitionService().setSelectedAlertGroups(connection,failures,alertRuleDefinition,alertRule);
		return alertRuleDefinition;
	}
	
	/**
	 * Method called on confirm delete.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertRuleDefinition
	 * @param progressBar
	 * @return boolean
	 */
	public boolean deleteAlertRuleDefinition(Connection connection, List failures, AlertRuleDefinition alertRuleDefinition, ProgressBar progressBar){
		List args1 = new ArrayList();
		args1.add(alertRuleDefinition.getAlertRule());
		int presnId = getPresnId(connection,failures,args1,GETPRESNID );
		
		if (presnId==0){
			return false;
		}
		
		List args2 = new ArrayList();
		args2.add(alertRuleDefinition.getAlertRule());
		if (!updateAlertRule(connection,failures,args2,delRABC_ARULE)){
			return false;
		}
		progressBar.setProgressPercent(20);

		List args3 = new ArrayList();
		args3.add(Integer.toString(presnId));
		if (!updatePresnId(connection,failures,args3,delRABC_PRESN_ID)){
			return false;
		}
		progressBar.setProgressPercent(30);
		
		List args4 = new ArrayList();
		args4.add(alertRuleDefinition.getAlertRule() + "-ACCT");
		AlertRule alertRuleAcct = getAlertRule(connection,failures,args4,GETSysALRA);
		progressBar.setProgressPercent(40);
		
		List args5 = new ArrayList();
		args5.add(alertRuleDefinition.getAlertRule() + "-DAILY");
		AlertRule alertRuleDaily = getAlertRule(connection,failures,args5,GETSysALRA);
		progressBar.setProgressPercent(50);
		
		List args6 = new ArrayList();
		args6.add(alertRuleDefinition.getAlertRule() + "-INST");
		AlertRule alertRuleInst = getAlertRule(connection,failures,args6,GETSysALRA);
		progressBar.setProgressPercent(60);
		
		if (alertRuleAcct!=null){	
			List args41 = new ArrayList();
			args41.add(alertRuleDefinition.getAlertRule()+ "-ACCT");
			int acctPresnId = getPresnId(connection,failures,args41,GETPRESNID_SYSA);
			
			List args42 = new ArrayList();
			args42.add(alertRuleDefinition.getAlertRule()+ "-ACCT");
			if (!updateAlertRule(connection,failures,args42,delRABC_ARULE_SYSA)){
				return false;
			}

			List args43 = new ArrayList();
			args43.add(Integer.toString(acctPresnId));
			if (!updatePresnId(connection,failures,args43,delRABC_PRESN_ID_SYSA)){
				return false;
			}
		}
		progressBar.setProgressPercent(70);
		
		if (alertRuleDaily!=null){
			List args51 = new ArrayList();
			args51.add(alertRuleDefinition.getAlertRule()+ "-DAILY");
			int dailyPresnId = getPresnId(connection,failures,args51,GETPRESNID_SYSD);
			
			List args52 = new ArrayList();
			args52.add(alertRuleDefinition.getAlertRule()+ "-DAILY");
			if (!updateAlertRule(connection,failures,args52,delRABC_ARULE_SYSD)){
				return false;
			}

			List args53 = new ArrayList();
			args53.add(Integer.toString(dailyPresnId));
			if (!updatePresnId(connection,failures,args53,delRABC_PRESN_ID_SYSD)){
				return false;
			}
		}
		progressBar.setProgressPercent(80);
		
		if (alertRuleInst!=null){
			List args61 = new ArrayList();
			args61.add(alertRuleDefinition.getAlertRule()+ "-INST");
			int instPresnId = getPresnId(connection,failures,args61,GETPRESNID_SYSI);
			
			List args62 = new ArrayList();
			args62.add(alertRuleDefinition.getAlertRule()+ "-INST");
			if (!updateAlertRule(connection,failures,args62,delRABC_ARULE_SYSI)){
				return false;
			}

			List args63 = new ArrayList();
			args63.add(Integer.toString(instPresnId));
			if (!updatePresnId(connection,failures,args63,delRABC_PRESN_ID_SYSI)){
				return false;
			}
		}
		progressBar.setProgressPercent(90);
		
		return true;	
	}
	
	/**
	 * Common method to run the update.
	 * 
	 * @param connection
	 * @param failures
	 * @param args
	 * @param sql
	 * @return boolean
	 */
	protected boolean updateAlertRule(Connection connection, List failures, List args,String sql){
		boolean success = true;
		
		AlertRuleDAO alertRuleDAO = new AlertRuleDAO();
		alertRuleDAO.executeUpdate(connection,failures,args,sql);
		
		if (!failures.isEmpty()){
			success = false;
		}
		
		return success;
	}
	
	/**
	 * Common method to run the update.
	 * 
	 * @param connection
	 * @param failures
	 * @param args
	 * @param sql
	 * @return boolean
	 */
	protected boolean updatePresnId(Connection connection, List failures, List args,String sql){
		boolean success = true;
		
		PresnIdDAO presnIdDAO = new PresnIdDAO();
		presnIdDAO.executeUpdate(connection,failures,args,sql);
		
		if (!failures.isEmpty()){
			success = false;
		}
		
		return success;
	}
	/**
	 * Method to get the distinct presn id.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param baseSQL
	 * @return int
	 */
	private int getPresnId(Connection connection, List failureList, List args, String baseSQL){
		int presnId = 0;
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		try
		{
			logger.debug("Processing SELECT from RABC_ALERT_RULE table....");
			MessageFormat mf = new MessageFormat(baseSQL);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("getPresnId - Executing SQL statement: "+ prepareStatement);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			
			while(rs.next()){
				presnId = rs.getInt("Presn_id");
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
			return 1;
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		
		return presnId;
	}
	
	/**
	 * Method to get the alert rule details.
	 * 
	 * @param connection
	 * @param failures
	 * @param args
	 * @param selectSQL
	 * @return AlertRule
	 */
	private AlertRule getAlertRule(Connection connection, List failures, List args, String selectSQL){
		AlertRuleDAO alertRuleDAO = new AlertRuleDAO();
		List alertRuleList = alertRuleDAO.get(connection,failures,args,selectSQL);
		
		if (alertRuleList.isEmpty()){
			return null;
		}else {
			AlertRule alertRule = (AlertRule) alertRuleList.get(0);
			return alertRule;
		}		
	}
}
