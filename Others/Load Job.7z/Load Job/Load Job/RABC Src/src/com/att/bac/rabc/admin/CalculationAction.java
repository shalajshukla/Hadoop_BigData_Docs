/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.admin;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.att.bac.rabc.ConnectionManager;
import com.att.bac.rabc.ProgressBar;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.Tree;
import com.att.bac.rabc.TreeService;

/**
 * Module description: 
 * 
 * This is an Calculation Page Action class for the calculation definition Component. 
 *
 * @author Vijay Dubey- VD3159
 */
public class CalculationAction extends DispatchAction {
	private static final Logger logger = Logger.getLogger(ViewAction.class);
	private CalculationService calculationService = CalculationService.getViewCalculationService();

	/**
	 * Default dispatch action method which will collect URL parameters & set it as request attributes
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @see org.apache.struts.actions.DispatchAction#unspecified(org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public ActionForward unspecified(ActionMapping mapping, ActionForm form, 
			HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		return load(mapping, form, request, response);
	}
	
	/**
	 * Action method to populate the calculation setup page.
	 * 1) Check whether this is create / update action based on URL parameters
	 * 2) If its update then get the calculation details from the service class.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward load(ActionMapping mapping, ActionForm form, 
			HttpServletRequest request, HttpServletResponse response){
		CalculationForm calculationForm = (CalculationForm) form;
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		Connection connection = null;
		List failureList = new ArrayList();
		List args = new ArrayList();
		PresnCalcElem presnCalcElem = null;
		TreeService treeService = null;
		Tree tree = null;
		String calculationNum = request.getParameter("calculationNum");
		String fromPage = request.getParameter("fromPage");
		List calculationNameList = new ArrayList();
		int maxCalcNum = 0;
		progressBar.setProgressPercent(10);
		
		try {
			// Get the connection from the available connection pool
			connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
			progressBar.setProgressPercent(30);
			treeService = new CalculationTreeService();
			tree = treeService.generateTree(connection, failureList, args, (String)request.getSession().getAttribute("region"));
			calculationForm.setTableTree(tree);
			progressBar.setProgressPercent(40);
			
			calculationForm.setFromPage(fromPage);
			
			if (calculationForm.isDuplicate()) {
				
				presnCalcElem = (PresnCalcElem)request.getAttribute("presnCalcElem") ;
				progressBar.setProgressPercent(60);
				
				if (presnCalcElem != null ) {
				
				calculationForm.setPresnCalcElem(presnCalcElem);
				
				calculationForm.setActionType("insert");
				progressBar.setProgressPercent(90);
				}
				
			}else if (calculationNum != null && !(calculationNum.equals("0")) ) {
				args.add(calculationNum);
				if (!calculationForm.isDuplicate()) {
					calculationForm.setActionType("update");
				}
				progressBar.setProgressPercent(60);
				
				presnCalcElem = calculationService.getCalculation(connection, failureList, args);
				progressBar.setProgressPercent(80);
				calculationForm.setPresnCalcElem(presnCalcElem);
				calculationForm.setCalcTableName(presnCalcElem.getCalcTbl()) ;
				calculationForm.setCalcElemSqlFormula(presnCalcElem.getCalcElemSqlFormula()) ;
				progressBar.setProgressPercent(90);
			} else {
				presnCalcElem = new PresnCalcElem();
				progressBar.setProgressPercent(60);
				maxCalcNum = calculationService.getMaxCalcNum(connection, failureList, args);
				progressBar.setProgressPercent(80);
				presnCalcElem.setPresnCalcNum(maxCalcNum + 1);
				presnCalcElem.setPresnFormatCode("0") ;
				calculationForm.setPresnCalcElem(presnCalcElem);
				calculationForm.setActionType("insert");
				progressBar.setProgressPercent(90);
			}
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		progressBar.setProgressPercent(100);
		
		if (!failureList.isEmpty()){
			request.setAttribute("failures", failureList);
			return mapping.findForward("error");
		}
		else {
			if (calculationForm.getFromPage().equals("sidemenu")) {
				return mapping.findForward("CalculationPageDefault");
			} else {
				return mapping.findForward("CalculationPage");
			}
		}
	}
	
	/**
	 * Action method to update the existing calculation.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward update(ActionMapping mapping, ActionForm form, 
			HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		CalculationForm calculationForm = (CalculationForm) form;
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		Connection connection = null;
		List failureList = new ArrayList();
		List args = new ArrayList();
		PresnCalcElem presnCalcElem = null;
		
		progressBar.setProgressPercent(10);
		
		String fromPage = request.getParameter("fromPage");
		calculationForm.setFromPage(fromPage) ;
		
		try {
			// Get the connection from the available connection pool
			connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
			progressBar.setProgressPercent(30);
			presnCalcElem = calculationForm.getPresnCalcElem();
			presnCalcElem.setCalcElemSqlFormula(calculationForm.getCalcElemSqlFormula()) ;
			presnCalcElem.setCalcTbl(calculationForm.getCalcTableName()) ;
			progressBar.setProgressPercent(50);
			args.add(presnCalcElem);
			calculationService.updateCalculation(connection, failureList, args);
			progressBar.setProgressPercent(80);
			if (!failureList.isEmpty()) {
				connection.rollback();
			} else {
				connection.commit();
			}
			progressBar.setProgressPercent(90);
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		progressBar.setProgressPercent(100);
		if (!failureList.isEmpty()){
			request.setAttribute("failures", failureList);
			return mapping.findForward("error");
		}
		else {
			request.setAttribute("calculationNum",Integer.toString(presnCalcElem.getPresnCalcNum()));
        	request.setAttribute("presnCalcElem",presnCalcElem);
			
        	if (calculationForm.getFromPage().equals("sidemenu")) {
				return mapping.findForward("CalculationMainPage");
			} else {
				return mapping.findForward("CalculationUpdateSuccess");
			}
        	
		}
	}
	
	/**
	 * Action method to create a new calculation.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward insert(ActionMapping mapping, ActionForm form, 
			HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		CalculationForm calculationForm = (CalculationForm) form;
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		Connection connection = null;
		List failureList = new ArrayList();
		List args = new ArrayList();
		List duplicateArgList = new ArrayList();
		PresnCalcElem presnCalcElem = null;
		
		progressBar.setProgressPercent(10);
		
		String fromPage = request.getParameter("fromPage");
		calculationForm.setFromPage(fromPage) ;
		
		boolean isDuplicate= false ; 
		try {
			
			//	Get the connection from the available connection pool
			connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
			progressBar.setProgressPercent(30);
			presnCalcElem = calculationForm.getPresnCalcElem();
			
			presnCalcElem.setCalcElemSqlFormula(calculationForm.getCalcElemSqlFormula()) ;
			presnCalcElem.setCalcTbl(calculationForm.getCalcTableName()) ;
			duplicateArgList.add(presnCalcElem.getPresnCalcName());
			progressBar.setProgressPercent(40);
			
			isDuplicate = calculationService.checkCalculationNameExists(connection , failureList , duplicateArgList) ;
			calculationForm.setDuplicate(isDuplicate) ;
			progressBar.setProgressPercent(70);
        	
			if (!isDuplicate) { 
        		
    			args.add(presnCalcElem) ;
    			calculationService.insertCalculation(connection, failureList, args);
    			progressBar.setProgressPercent(80);
    			if (!failureList.isEmpty()) {
    				connection.rollback();
    			} else {
    				connection.commit();
    			}
        	}
			progressBar.setProgressPercent(90);
			
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		progressBar.setProgressPercent(100);
		if (!failureList.isEmpty()){
			request.setAttribute("failures", failureList);
			return mapping.findForward("error");
		}
		else {
			request.setAttribute("calculationNum",Integer.toString(presnCalcElem.getPresnCalcNum()));
        	request.setAttribute("presnCalcElem",presnCalcElem);
			if (isDuplicate) {
        		return load(mapping, form, request, response);
        	}
        	else {	
        		if (calculationForm.getFromPage().equals("sidemenu")) {
    				return mapping.findForward("CalculationMainPage");
    			} else {
    				return mapping.findForward("CalculationUpdateSuccess");
    			}	
        	}
		}
	}
	
	/**
	 * Method executes if insert or updated calculation successfully 
	 * and takes user to calculation page to show currently saved calculation
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward updateSuccess(ActionMapping mapping,ActionForm form,HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		
		CalculationForm calculationForm = (CalculationForm) form;
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		Connection connection = null;
		ActionForward forward = null ;
		List failureList = new ArrayList();
		List args = new ArrayList();
		PresnCalcElem presnCalcElem = null;
		String calculationNum = request.getParameter("calculationNum");
		
		progressBar.setProgressPercent(10);
		
		if (calculationNum != null) {
			try {
				// Get the connection from the available pool
				connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
				progressBar.setProgressPercent(30);
				args.add(calculationNum);
				/*
				 * Get the PresnCalcElem object.
				 */
				presnCalcElem = calculationService.getCalculation(connection, failureList, args);
				progressBar.setProgressPercent(70);
				calculationForm.setPresnCalcElem(presnCalcElem);
				progressBar.setProgressPercent(90);
			} catch(SQLException sx) {
				logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
				failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
			} catch(NamingException ne) {
				logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
				failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
			} catch(Exception e) {
				logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
	            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
			} finally {
				SQLHelper.closeConnection(connection, failureList, logger);
			}
		}
		if (!failureList.isEmpty()){
			request.setAttribute("failures", failureList);
			forward =  mapping.findForward("error");
		}
		else {
			forward =  mapping.findForward("CalculationPage");
		}
		progressBar.setProgressPercent(100);

		return forward ;
	}

	/**
	 * This method is called when the user makes any changes to the views
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward reloadCalcTable(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		CalculationForm calculationForm = (CalculationForm) form;
		
		Connection connection = null;
		HttpSession session = null;
		
		/*
		 * Initialize lists of arguments as well as failures
		 */
		List failureList = new ArrayList();
		List args = new ArrayList();
		TreeService treeService = null;
		Tree tree = null;
		session = request.getSession(true);
		try{
			connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
			treeService = new CalculationTreeService();
			tree = treeService.generateTree(connection, failureList, args, (String)request.getSession().getAttribute("region"));
			calculationForm.setTableTree(tree);
			String calculationNum = request.getParameter("calculationNum");
			if (calculationNum != null && !(calculationNum.equals("0"))) {
				calculationForm.setActionType("update") ;
			} else {
				calculationForm.setActionType("insert") ;
			}
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}) + " Exception details: " + e.getMessage(), e);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		if (!failureList.isEmpty()){
			request.setAttribute("failures", failureList);
			return mapping.findForward("error");
		} else {
			if (calculationForm.getFromPage().equals("sidemenu")) {
				return mapping.findForward("CalculationPageDefault");
			} else {
				return mapping.findForward("CalculationPage");
			}
		}
	}
}	
