package com.att.bac.rabc.load.calnet.telcoacus;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.att.carat.util.JDBCUtil;
/**
 * 
 * @author sb8798
 * This is the DAO for the Archive Load Job
 *
 */
public class ArchiveLoadJobDAO{
	
	Logger logger = Logger.getLogger(ArchiveLoadJobDAO.class);
	private int  BATCH_SIZE = 100000;
	
	
	/**
	 * constructor
	 *
	 */
	
	public ArchiveLoadJobDAO() {
		super();
	}
	
	/**
	 * 
	 * @param connection
	 * @param maxDays
	 * @return true if the method is successful
	 * This method deletes all the records from the Archive table where the DATA_EXTRACT_DT 
	 * is greater than 12 months (365 days - specified in the config file). 
	 */
	public boolean deleteOldDataFromAchiveTable(Connection connection, int maxDays) throws CrisAcusException
	{
		PreparedStatement deleteStatement = null;
		
		String sql = "DELETE FROM RABC_CRIS_ACUS_DSCRPNCY_ARCH " +
					 " where trunc(sysdate) - DATA_EXTRACT_DT > ? ";

		try {

			deleteStatement = connection.prepareStatement(sql);
			deleteStatement.setInt(1, maxDays);
			int i = deleteStatement.executeUpdate();
			if (i>0)
			{
				connection.commit();
			}
			logger.info(i + " records have Data > " + maxDays + " and have been deleted from the RABC_CRIS_ACUS_DSCRPNCY_ARCH table");			

		} catch (SQLException sqle) {
			//logger.error("SQL Exception in deleteCurrentDataFromAchiveTable", sqle);
			throw new CrisAcusException("Error in deleteCurrentDataFromAchiveTable", sqle);
		} catch (Exception e) {
			//logger.error("Exception in deleteCurrentDataFromAchiveTable", e);
			throw new CrisAcusException("Error in deleteCurrentDataFromAchiveTable", e);
		}		
		finally
		{
			JDBCUtil.closeStatement(deleteStatement);
		}
		return true;
	}
	
	/**
	 * 
	 * @param connection
	 * @param minDays
	 * @return true if the method is successful 
	 * This method selects records with DATA_EXTRACT_DT > 4 months (120days - specified in the config file).
	 * and passes the result set to another method to copy it over to the ARCH table. 
	 */
	public boolean selectAndInsertDataToBeArchivedFromDscrpncy(Connection connection, int minDays) throws CrisAcusException
	{
		PreparedStatement selectStatement=null;
		ResultSet rs=null;
		StringBuffer sbQuery1 = new StringBuffer();
		
		sbQuery1.append(" SELECT * FROM RABC_CRIS_ACUS_DSCRPNCY ");
		sbQuery1.append(" where trunc(sysdate) - DATA_EXTRACT_DT >= ?");
//		sbQuery1.append(" and trunc(sysdate) - DATA_EXTRACT_DT <= ?");
		
		try {

			selectStatement = connection.prepareStatement(sbQuery1.toString());
			selectStatement.setInt(1, minDays);
	//		selectStatement.setInt(2, maxDays);
			rs = selectStatement.executeQuery();

			insertIntoArchivedFromDscrpncy(connection, rs);
			

		} catch (SQLException sqle) {
//			logger.error("SQLException in selectAndDeleteDataToBeArchivedFromDscrpncy", sqle);
			throw new CrisAcusException("Error in selectAndDeleteDataToBeArchivedFromDscrpncy", sqle); 
		} catch (Exception e) {
//			logger.error("Exception in selectAndDeleteDataToBeArchivedFromDscrpncy", e);
			throw new CrisAcusException("Error in selectAndDeleteDataToBeArchivedFromDscrpncy", e); 
		} 
		 finally {
			 JDBCUtil.closeResultSet(rs);
			 JDBCUtil.closeStatement(selectStatement);
		 }
		 return true;
	}
	
	/**
	 * 
	 * @param connection
	 * @param rs
	 * @return true if the method is successful
	 * The records lder than 120 days are copied from the RABC_CRIS_ACUS_DSCRPNCY table to the RABC_CRIS_ACUS_DSCRPNCY_ARCH table.
	 * 
	 */
	   public boolean insertIntoArchivedFromDscrpncy( Connection connection, ResultSet rs) throws CrisAcusException
	   {
	        PreparedStatement pstatement = null;
	    	StringBuffer sbQuery = new StringBuffer();
	    	int recordCount = 0;

			sbQuery.append(" INSERT INTO RABC_CRIS_ACUS_DSCRPNCY_ARCH ");
			sbQuery.append(" values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )");
			
			try
			{
				pstatement = connection.prepareStatement(sbQuery.toString());
				
				while (rs.next())
				{
					pstatement.setString(1, rs.getString("CRIS_BTN"));
					pstatement.setString(2, rs.getString("CRIS_CURR_MNTH_CHRG_AMT"));
					pstatement.setString(3, rs.getString("CRIS_BILL_RND"));
					pstatement.setString(4, rs.getString("CRIS_BILL_MM"));
					pstatement.setString(5, rs.getString("CRIS_YEAR"));
					pstatement.setString(6, rs.getString("ACUS_BTN"));
					pstatement.setString(7, rs.getString("ACUS_PROV_RECEIVED_AMT"));
					pstatement.setString(8, rs.getString("ACUS_PROV_BILL_RND"));
					pstatement.setString(9, rs.getString("ACUS_PROV_INV_MM"));
					pstatement.setString(10, rs.getString("ACUS_PROV_INV_YEAR"));
					pstatement.setDate(11, rs.getDate("DATA_EXTRACT_DT"));
					
					pstatement.addBatch();
					recordCount++;
					if (((recordCount) % BATCH_SIZE) == 0) {
						pstatement.executeBatch();
						connection.commit();
						logger.info(recordCount + " records have been inserted into the archive table - RABC_CRIS_ACUS_DSCRPNCY_ARCH ");
					}					
				}
				pstatement.executeBatch();
				connection.commit();
				logger.info(recordCount + " records have been inserted into the archive table - RABC_CRIS_ACUS_DSCRPNCY_ARCH ");

			} catch (SQLException e)
			{
				//logger.error("Error in insertIntoArchivedFromDscrpncy", e);
				throw new CrisAcusException("Error in insertIntoArchivedFromDscrpncy", e);
			}
			finally
			{
				JDBCUtil.closeResultSet(rs);
				JDBCUtil.closePreparedStatement(pstatement);
			}
			return true;
	   }

	   /**
	    * 
	    * @param connection
	    * @param minDays
	    * @return true if the method is successful
	    * This method deletes all the records from RABC_CRIS_ACUS_DSCRPNCY table where the DATA_EXTRACT_DT is greater than
	    * 120 days (specified in config file).
	    */
		public boolean deleteDataFromDscrpncy(Connection connection, int minDays) throws CrisAcusException
		{
			
			PreparedStatement deleteStatement = null;
			StringBuffer sbQuery = new StringBuffer();
			sbQuery.append(" DELETE FROM RABC_CRIS_ACUS_DSCRPNCY ");
			sbQuery.append(" where trunc(sysdate) - DATA_EXTRACT_DT >= ?");
			//sbQuery.append(" and trunc(sysdate) - DATA_EXTRACT_DT <= ?");

			try {
				deleteStatement = connection.prepareStatement(sbQuery.toString());
				deleteStatement.setInt(1, minDays);
				//deleteStatement.setInt(2, maxDays);
				int i = deleteStatement.executeUpdate();
				
				if (i>0)
				{
					connection.commit();
				}
				logger.info(i + " records with Data >= " + minDays + " have been deleted from the RABC_CRIS_ACUS_DSCRPNCY table");
				

			} catch (SQLException sqle) {
				//logger.error("SQL Exception in deleteDateFromDscrpncy", sqle);
				throw new CrisAcusException("Error in deleteDateFromDscrpncy", sqle);
			} catch (Exception e) {
				//logger.error("Exception in deleteDateFromDscrpncy", e);
				throw new CrisAcusException("Error in deleteDateFromDscrpncy", e);
			}		
			finally
			{
				JDBCUtil.closeStatement(deleteStatement);
			}
			
			return true;
		}


}
