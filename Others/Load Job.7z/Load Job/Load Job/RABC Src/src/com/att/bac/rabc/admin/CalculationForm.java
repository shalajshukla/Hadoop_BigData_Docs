/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.admin;

import java.util.ArrayList;
import java.util.List;

import org.apache.struts.action.ActionForm;

import com.att.bac.rabc.PickList;
import com.att.bac.rabc.Tree;

/**
 * Module Description : 
 * Form bean for view definition component
 * 
 * @author Vijay Dubey- VD3159
 *
 */
public class CalculationForm extends ActionForm {
	private String dispatch;
	private PresnCalcElem presnCalcElem = new PresnCalcElem();
	private Tree tableTree = null;
	private String variables;
	private List variablesList = new ArrayList();
	private String addValue;
	private String actionType;
	private String hdFormat; 
	private boolean isDuplicate ; 
	private String fromPage = "";
	// If calculation is based on only one table name then store the value in CALC_TBL column (calcTableName form variable). 
	private String calcTableName ; 
	private String calcElemSqlFormula ; 
	
	/**
	 * @return Returns the calcElemSqlFormula.
	 */
	public String getCalcElemSqlFormula() {
		return calcElemSqlFormula;
	}
	/**
	 * @param calcElemSqlFormula The calcElemSqlFormula to set.
	 */
	public void setCalcElemSqlFormula(String calcElemSqlFormula) {
		this.calcElemSqlFormula = calcElemSqlFormula;
	}
	/**
	 * @return Returns the actionType.
	 */
	public String getActionType() {
		return actionType;
	}
	/**
	 * @param actionType The actionType to set.
	 */
	public void setActionType(String actionType) {
		this.actionType = actionType;
	}
	/**
	 * @return Returns the addValue.
	 */
	public String getAddValue() {
		return addValue;
	}
	/**
	 * @param addValue The addValue to set.
	 */
	public void setAddValue(String addValue) {
		this.addValue = addValue;
	}
	/**
	 * @return Returns the dispatch.
	 */
	public String getDispatch() {
		return dispatch;
	}
	/**
	 * @param dispatch The dispatch to set.
	 */
	public void setDispatch(String dispatch) {
		this.dispatch = dispatch;
	}
	/**
	 * @return Returns the presnCalcElem.
	 */
	public PresnCalcElem getPresnCalcElem() {
		return presnCalcElem;
	}
	/**
	 * @param presnCalcElem The presnCalcElem to set.
	 */
	public void setPresnCalcElem(PresnCalcElem presnCalcElem) {
		this.presnCalcElem = presnCalcElem;
	}
	/**
	 * @return Returns the tableTree.
	 */
	public Tree getTableTree() {
		return tableTree;
	}
	/**
	 * @param tableTree The tableTree to set.
	 */
	public void setTableTree(Tree tableTree) {
		this.tableTree = tableTree;
	}
	/**
	 * @return Returns the variables.
	 */
	public String getVariables() {
		return variables;
	}
	/**
	 * @param variables The variables to set.
	 */
	public void setVariables(String variables) {
		this.variables = variables;
	}
	/**
	 * @return Returns the variablesList.
	 */
	public List getVariablesList() {
		return variablesList;
	}
	/**
	 * @param variables The variablesto add.
	 */
	public void addVariables(PickList variables) {
		this.variablesList.add(variables);
	}
	/**
	 * @return Returns the hdFormat.
	 */
	public String getHdFormat() {
		return hdFormat;
	}
	/**
	 * @param hdFormat The hdFormat to set.
	 */
	public void setHdFormat(String hdFormat) {
		this.hdFormat = hdFormat;
	}
	
	/**
	 * @return Returns the isDuplicate.
	 */
	public boolean isDuplicate() {
		return isDuplicate;
	}
	/**
	 * @param isDuplicate The isDuplicate to set.
	 */
	public void setDuplicate(boolean isDuplicate) {
		this.isDuplicate = isDuplicate;
	}
	
	/**
	 * @return Returns the fromPage.
	 */
	public String getFromPage() {
		return fromPage;
	}
	/**
	 * @param fromPage The fromPage to set.
	 */
	public void setFromPage(String fromPage) {
		this.fromPage = fromPage;
	}
	/**
	 * @return Returns the calcTableName.
	 */
	public String getCalcTableName() {
		return calcTableName;
	}
	/**
	 * @param calcTableName The calcTableName to set.
	 */
	public void setCalcTableName(String calcTableName) {
		this.calcTableName = calcTableName;
	}
}
