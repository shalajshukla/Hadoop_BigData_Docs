/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.admin.alert.rule;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.ArrayList;
import java.text.MessageFormat;

import org.apache.log4j.Logger;

import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.RABCException;

/**
 * This is a DAO that performs SELECT, INSERT and UPDATE on RABC_ALERT_RULE table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class AlertRuleDAO {
	private static final Logger logger = Logger.getLogger(AlertRuleDAO.class);

	/**
	 * Returns the list of AlertRule objects.
	 * 
	 * @param conn 
	 * @param failures
	 * @param args
	 * @param baseSQL
	 * @return List
	 */
	public List get(Connection conn, List failures, List args, String baseSQL) {
		List alertRuleList = null;
		AlertRule alertRule = null;
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		
		try
		{
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("AlertRuleDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			alertRuleList = new ArrayList();
			while (rs.next()) {
				alertRuleList.add(buildAlertRule(rs));
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return null;
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
		
		return alertRuleList;
	}

	/**
	 * Private method to build AlertRule object and return it to caller.
	 * 
	 * @param rs
	 * @return AlertRule
	 * @throws SQLException
	 */
	private AlertRule buildAlertRule(ResultSet rs) throws SQLException {
		AlertRule alertRule = new AlertRule();
		
		alertRule.setDbNodeId(rs.getString("DB_NODE_ID"));
		alertRule.setAlertRuleStatus(rs.getString("ALERT_RULE_STATUS"));
		alertRule.setEffDate(rs.getDate("EFF_DATE"));
		alertRule.setStdType(rs.getString("STD_TYPE"));
		alertRule.setAlertExemptInd(rs.getString("ALERT_EXEMPT_IND"));
		alertRule.setUserId(rs.getString("USER_ID"));
		alertRule.setTimeStamp(rs.getDate("TIME_STAMP"));
		alertRule.setAlertRule(rs.getString("ALERT_RULE"));
		alertRule.setPartiRefId(rs.getInt("PARTI_REF_ID"));
		alertRule.setPresnId(rs.getInt("PRESN_ID"));
		alertRule.setFileVerifInd(rs.getString("FILE_VERIF_IND"));
		alertRule.setDataExtrctInd(rs.getString("DATA_EXTRCT_IND"));
		alertRule.setDataCalcInd(rs.getString("DATA_CALC_IND"));
		alertRule.setCalcRule(rs.getString("CALC_RULE"));
		alertRule.setWarningInd(rs.getString("WARNING_IND"));
		alertRule.setAvgInd(rs.getString("AVG_IND"));
		alertRule.setAlertMsgInd(rs.getString("ALERT_MSG_IND"));
		alertRule.setAlertSeqNumInd(rs.getString("ALERT_SEQ_NUM_IND"));
		alertRule.setAlertTimeInd(rs.getString("ALERT_TIME_IND"));
		alertRule.setAlertDashFreshInd(rs.getString("ALERT_DASH_FRESH_IND"));
		alertRule.setAlertDesc(rs.getString("ALERT_DESC"));
		
		if (rs.getString("ALERT_EXEC_DATE")==null || "".equals(rs.getString("ALERT_EXEC_DATE"))){
			alertRule.setAlertExecDate(-1);
		}else {
			alertRule.setAlertExecDate(rs.getInt("ALERT_EXEC_DATE"));
		}
		
		alertRule.setAlertKeyLvl(rs.getInt("ALERT_KEY_LVL"));
		alertRule.setAlertKey1Name(rs.getString("ALERT_KEY1_NAME"));
		alertRule.setAlertKey2Name(rs.getString("ALERT_KEY2_NAME"));
		alertRule.setAlertKey3Name(rs.getString("ALERT_KEY3_NAME"));
		alertRule.setAlertKey4Name(rs.getString("ALERT_KEY4_NAME"));
		alertRule.setAlertKey5Name(rs.getString("ALERT_KEY5_NAME"));
		alertRule.setAlertFileCt(rs.getInt("ALERT_FILE_CT"));
		alertRule.setAsocFileId(rs.getString("ASOC_FILE_ID"));
		alertRule.setAlertRulePresnInd(rs.getString("ALERT_RULE_PRESN_IND"));
		alertRule.setDivisionNameKeyLvl(rs.getInt("DIVISION_NAME_KEY_LVL"));
		
		if (rs.getString("ALERT_DATA_KEEP")==null){
			alertRule.setAlertDataKeep(-1);
		}else {
			alertRule.setAlertDataKeep(rs.getInt("ALERT_DATA_KEEP"));
		}
		alertRule.setAlertRuleType(rs.getString("ALERT_RULE_TYPE"));
		alertRule.setAlertMnthExecDt(rs.getInt("ALERT_MNTH_EXEC_DAY"));
		alertRule.setAlertMnthExecBillRnd(rs.getInt("ALERT_MNTH_EXEC_BILL_RND"));
		
		return alertRule;
	}

	/**
	 * Execute the insert or update statement on RABC_ALERT_RULE table.
	 * 
	 * @param conn
	 * @param failures
	 * @param args
	 * @param baseSQL
	 */
	public void executeUpdate(Connection conn, List failures, List args, String baseSQL) {
		int rowsUpdated = 0;
		Statement stmt = null;
		String sqlStmt = null;
		
		try
		{
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("AlertRuleDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rowsUpdated = stmt.executeUpdate(sqlStmt);
			logger.debug("SQL - Execution complete."+ String.valueOf(rowsUpdated) + "  rows updated");
			
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return;
		} finally {
			SQLHelper.closeStatement(stmt, failures, logger);
		}
	}
	
}
