/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.load.sw;

import java.io.File;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
//changes for M168 by as635b
//import com.sbc.bac.load.FileDBLoadJob;
import com.att.carat.load.FileDBLoadJob;
import com.sbc.bac.rabc.load.StaticErrorMsgKeys;

/**
 * This is a Load job which loads calendar data for SW region in RABC_CYCLE_CALENDAR table.
 * 
 * @author Shailesh Hemdev - SH8512
 */
public class SWCycleCalLoadJob extends FileDBLoadJob {
	/*
	 * Varables to represent the date formats
	 */
	private static final SimpleDateFormat YYYY_DDD_FORMAT = new SimpleDateFormat("yyyyddd");
	private static final SimpleDateFormat MM_DD_YYYY_FORMAT = new SimpleDateFormat("MM/dd/yyyy");
	
	/*
	 * DB Index based constants
	 */
	private static final int PROCEDURE_DATE_INDEX = 1;
	private static final int PROC_DT_IND_INDEX = 2;
	private static final int BILL_ROUND_INDEX = 3;
	private static final int BILL_ROUND_DATE_INDEX = 4;

	/*
	 *  Prepared statements
	 */
	private PreparedStatement insertLCC;
	private PreparedStatement deleteLCC;
	
	/*
	 * boolean to indicate whether the earlier records need to be deleted or not as per specified logic
	 */
	private boolean isFirstRecord;
	
	private int lineCount;
	private String fieldSeperator = ",";
	
	/**
	 * Overriding accept(file) method.
	 * It checks the file name pattern and retuns the boolean value.
	 * 
	 * @see java.io.FileFilter#accept(java.io.File)
	 */
	public boolean accept(File file) {
		return (file.getPath().toUpperCase().indexOf("SW.CRIS.CALENDAR") > 0);
	}
	
	/**
	 * Overriding preprocess() method. 
	 * It is executed prior to processing the load job.
	 * Forms the actual prepared statements which need to be fired on to the database.
	 * 
	 * @see com.sbc.bac.load.LoadJob#preprocess()
	 */
	protected boolean preprocess() {
		boolean success = super.preprocess();

		if (success) {
			try {
				deleteLCC = connection.prepareStatement("DELETE FROM RABC_CYCLE_CALENDAR WHERE PROC_DT >= ?");
				insertLCC = connection.prepareStatement("INSERT INTO RABC_CYCLE_CALENDAR (PROC_DT, PROC_DT_IND, BILL_RND, BILL_RND_DT, CYCLE) VALUES (?, ?, ?, ?, NULL)");	
			} catch (SQLException e) {
				severe(StaticErrorMsgKeys.PREPROCESS_ERROR + e.getMessage(), e);
				success = false;
			}
		}
		
		/*
		 * Intialize the boolean variable to decide whether this is a first record or not. It is used to delete 
		 * the records based on a specific logic.
		 */
		isFirstRecord = true;
		
		return success;
	}
	
	
	/**
	 * Overriding parseLine(line) method.
	 * It accepts a single line and loads data in the table.
	 * It first deletes all the records of the year (year of the proc dates of the records in the file)
	 * from RABC_CYCLE_CALENDAR table.
	 * And then insert the records in the table.
	 * 
	 * @see com.sbc.bac.load.FileDBLoadJob#parseLine(java.lang.String)
	 */
	protected int parseLine(String line) throws Exception {
		int lineReadEndLimit = line.length();

		if (lineReadEndLimit >= 18) {
			if (line.substring(7, 9).equals("  ")) {
				String procedureDateString = line.substring(0, 7);
				String billRound = line.substring(16, 18);
				
				if (!procedureDateString.equals("0000000")) {
					lineCount++;
					
					try {
						Date procedureDate = new Date(YYYY_DDD_FORMAT.parse(procedureDateString).getTime());
						
						/*
						 * Substitution for the prepared statements
						 */
						insertLCC.setDate(PROCEDURE_DATE_INDEX, procedureDate);
						if ("".equals(billRound.trim())) {
							insertLCC.setString(PROC_DT_IND_INDEX, null);
							insertLCC.setString(BILL_ROUND_INDEX, null);
							insertLCC.setTimestamp(BILL_ROUND_DATE_INDEX, null);
						} else if ("00".equals(billRound.trim()) || "0".equals(billRound.trim())) {
							insertLCC.setString(PROC_DT_IND_INDEX, null);
							insertLCC.setString(BILL_ROUND_INDEX, Integer.toString(Integer.parseInt(billRound)));
							insertLCC.setTimestamp(BILL_ROUND_DATE_INDEX, null);
						} else {
							insertLCC.setString(PROC_DT_IND_INDEX, null);
							insertLCC.setString(BILL_ROUND_INDEX, Integer.toString(Integer.parseInt(billRound)));
							insertLCC.setTimestamp(BILL_ROUND_DATE_INDEX, getTimestamp(procedureDate, billRound, MM_DD_YYYY_FORMAT));
						}
						
						/*
						 * If it is first record, then delete all the records where PROC_DT >= 1st January of year 
						 * for which the cycle is.
						 */ 
						if (isFirstRecord) {
							isFirstRecord = false;
	
							Calendar cal = Calendar.getInstance();
							cal.setTime(procedureDate);
							cal.set(Calendar.MONTH,Calendar.JANUARY);
							cal.set(Calendar.DAY_OF_MONTH,1);
								
							/*
							 * Set the date parameter in the Delete statements
							 */
							deleteLCC.setDate(1, new java.sql.Date(cal.getTime().getTime()));
							
							/*
							 * Delete the records
							 */
							deleteLCC.execute();
						}
						
						/*
						 * Add the insert prepared statement to a batch
						 */
						insertLCC.addBatch();
						
						if (lineCount % 1000 == 0){
							insertLCC.executeBatch();
						}
					} catch (ParseException pe) {
						//warning("SW Calendar Load Job has some junk characters in the file");
					}
				}
			}
		}
			
		return SUCCESS;
	}
	
	/**
	 * Private method to return the BILL_RND_DT. Bill round is used
	 * to determine the BILL_RND_DT using the month & year of the procedure date.
	 * 
	 * @param date
	 * @param billRound
	 * @param dateFormat
	 * @return Timestamp
	 * @throws ParseException
	 */
	private Timestamp getTimestamp(Date date, String billRound, SimpleDateFormat dateFormat) 
			throws ParseException {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		String month = "";
		String day = "";
		String year = "";
		String dateString = dateFormat.format(date);
		int br = 0;
		int dy = 0;
		int mo = 0;
		int yr = 0;
		if (!billRound.trim().equals("0") && !billRound.trim().equals("00")) {
		   br = Integer.parseInt(billRound);
		   mo = calendar.get(Calendar.MONTH)+ 1;
		   dy = calendar.get(Calendar.DAY_OF_MONTH);
		   yr = calendar.get(Calendar.YEAR);
		   if (br < dy) {
		   		dy = br;
		   } else if (mo == 1) {
		   		yr = yr - 1;
		   		mo = 12;
		   		dy = br;
		   } else {
		   		mo = mo - 1;
		   		dy = br;
		   }
		   if (mo < 10) {
		   		month = "0" + Integer.toString(mo);
		   } else {
		   		month = Integer.toString(mo);
		   }
		   if (dy < 10) {
	   			day = "0" + Integer.toString(dy);
		   } else {
	   			day = Integer.toString(dy);
		   }
		   year = Integer.toString(yr);
		   dateString = month + "/" + day + "/" + year;
		}
		return new Timestamp(dateFormat.parse(dateString).getTime());
	}
	
	/**
	 * Overriding postProcessFile(file, success) method.
	 * It is executed post to processing the file to be loaded.
	 * It includes the following steps:
	 * 	1) Executes the last batch of prepared statement.
	 * 
	 * @see com.sbc.bac.load.FileDBLoadJob#postprocessFile(java.io.File, boolean)
	 */
	public boolean postprocessFile(File file, boolean success) {
		if (success) {
			try {
				insertLCC.executeBatch();
			} catch (SQLException e){
				severe(StaticErrorMsgKeys.POSTPROCESSFILE_ERROR + StaticErrorMsgKeys.INSERT_ERROR + e.getMessage(), e);
				success = false;
			}
		}
		return super.postprocessFile(file, success);
	}
	
	/**
	 * Overriding postProcess(success) method.
	 * It is executed post to processing the load job.
	 * It includes the following steps:
	 * 	1) Closes statements that were opened for this load job.
	 * 
	 * @see com.sbc.bac.load.LoadJob#postprocess(boolean)
	 */
	protected boolean postprocess(boolean success) {
		try {
			deleteLCC.close();
			insertLCC.close();	
		} catch (SQLException e) {
			severe(StaticErrorMsgKeys.POSTPROCESS_ERROR + StaticErrorMsgKeys.SQL_CLOSE_ERROR + e.getMessage(), e);
			success = false;
		}
		return super.postprocess(success);
	}
}
