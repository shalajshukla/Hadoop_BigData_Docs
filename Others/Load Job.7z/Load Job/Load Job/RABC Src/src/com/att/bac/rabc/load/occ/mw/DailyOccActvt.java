/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.load.occ.mw;

import java.util.Date;

import com.sbc.bac.rabc.load.HashCodeUtil;

/**
 * This is a data object representing entries in RABC_DAILY_OCC_ACTVT table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class DailyOccActvt {
	private Date runDate;
	private String division;
	private String fileId;
	private String sourceInd;
	private String busType;
	private String occType;
	private long occCtDb;
	private double occAmtDb;
	private long occCtCr;
	private double occAmtCr;
	
	/**
	 * @return Returns the busType.
	 */
	public String getBusType() {
		return busType;
	}
	/**
	 * @param busType The busType to set.
	 */
	public void setBusType(String busType) {
		this.busType = busType;
	}
	/**
	 * @return Returns the division.
	 */
	public String getDivision() {
		return division;
	}
	/**
	 * @param division The division to set.
	 */
	public void setDivision(String division) {
		this.division = division;
	}
	/**
	 * @return Returns the fileId.
	 */
	public String getFileId() {
		return fileId;
	}
	/**
	 * @param fileId The fileId to set.
	 */
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	/**
	 * @return Returns the occAmtCr.
	 */
	public double getOccAmtCr() {
		return occAmtCr;
	}
	/**
	 * @param occAmtCr The occAmtCr to set.
	 */
	public void setOccAmtCr(double occAmtCr) {
		this.occAmtCr = occAmtCr;
	}
	/**
	 * @return Returns the occAmtDb.
	 */
	public double getOccAmtDb() {
		return occAmtDb;
	}
	/**
	 * @param occAmtDb The occAmtDb to set.
	 */
	public void setOccAmtDb(double occAmtDb) {
		this.occAmtDb = occAmtDb;
	}
	/**
	 * @return Returns the occCtCr.
	 */
	public long getOccCtCr() {
		return occCtCr;
	}
	/**
	 * @param occCtCr The occCtCr to set.
	 */
	public void setOccCtCr(long occCtCr) {
		this.occCtCr = occCtCr;
	}
	/**
	 * @return Returns the occCtDb.
	 */
	public long getOccCtDb() {
		return occCtDb;
	}
	/**
	 * @param occCtDb The occCtDb to set.
	 */
	public void setOccCtDb(long occCtDb) {
		this.occCtDb = occCtDb;
	}
	/**
	 * @return Returns the occType.
	 */
	public String getOccType() {
		return occType;
	}
	/**
	 * @param occType The occType to set.
	 */
	public void setOccType(String occType) {
		this.occType = occType;
	}
	/**
	 * @return Returns the runDate.
	 */
	public Date getRunDate() {
		return runDate;
	}
	/**
	 * @param runDate The runDate to set.
	 */
	public void setRunDate(Date runDate) {
		this.runDate = runDate;
	}
	/**
	 * @return Returns the sourceInd.
	 */
	public String getSourceInd() {
		return sourceInd;
	}
	/**
	 * @param sourceInd The sourceInd to set.
	 */
	public void setSourceInd(String sourceInd) {
		this.sourceInd = sourceInd;
	}
	
	/**
	 * Equals method overridden for this object so that it can be stored in a hash map where the key 
	 * would be combination of the following 6 attributes:
	 * Run date
	 * Division
	 * File Id
	 * Source Indicator
	 * Business type
	 * OCC Type
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object o) {
		// Do a quick check for an identical object reference
	    if (this == o) {
	      return true;
	    }
	    if (!(o instanceof DailyOccActvt)) {
	    	return false;
	    } else {
			if (((DailyOccActvt)o).getRunDate().getTime() == this.getRunDate().getTime()
				&& ((DailyOccActvt)o).getDivision().equalsIgnoreCase(this.getDivision())
				&& ((DailyOccActvt)o).getFileId().equalsIgnoreCase(this.getFileId())
				&& ((DailyOccActvt)o).getSourceInd().equalsIgnoreCase(this.getSourceInd())
				&& ((DailyOccActvt)o).getBusType().equalsIgnoreCase(this.getBusType())
				&& ((DailyOccActvt)o).getOccType().equalsIgnoreCase(this.getOccType())
				) {
				return true;
			} else {
				return false;
			}
	    }
	}
	
	/**
	 * Hash code method overridden for this object to categorize this object in sets 
	 * so that the hash collections can search this object efficiently.
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		int hashCode = HashCodeUtil.SEED;
		hashCode = HashCodeUtil.hash( hashCode, this.getSourceInd());
		hashCode = HashCodeUtil.hash( hashCode, this.getBusType());
		hashCode = HashCodeUtil.hash( hashCode, this.getOccType());
	    return hashCode;
	}
}
