/* Component Name: RABCPPG00516
 * Module Name: AdminAlertThresholdAction.java
 * Created on Jan 19, 2006
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.admin.alert.thrshld;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.StaticDataLoader;

/**This is the struts Action class for the Alert Threshold process.  The purpose of this class
 * is mainly to interact between the AdminAlertThresholdForm.java class and the struts framework.
 * All business logic is handled in the facade class AdminAlertThresholdService.java.
 * 
 * @author js3175
 */
public class AdminAlertThresholdAction extends DispatchAction {
	private static final Logger logger = Logger.getLogger(AdminAlertThresholdAction.class);
	
	/**This is the struts framework default method entered when entering the admin.alert.thrshld
	 * process without a dispatch.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of AdminAlertThresholdForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward unspecified(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) 
			throws RABCException {
		logger.debug("dispatch = unspecified");
		ActionForward forward = adminAlertThreshold(mapping, form, request, response);
		return forward;
	}
	
	/**This is the struts framework method called to set up and present the entry page into
	 * the admin.alert.thrshld process.  This method is also responsible for catching and logging
	 * all exceptions thrown.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of AdminAlertThresholdForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward adminAlertThreshold(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = adminAlertThreshold");
		ActionForward forward = null;
		try {
			AdminAlertThresholdForm adminAlertThresholdForm = (AdminAlertThresholdForm)form;
			adminAlertThresholdForm.setRegion((String)request.getSession().getAttribute("region"));
			adminAlertThresholdForm.setUserId((String)request.getSession().getAttribute("bacUserID"));
			adminAlertThresholdForm = AdminAlertThresholdService.adminAlertThreshold(adminAlertThresholdForm);
			adminAlertThresholdForm.setBillRounds(StaticDataLoader.getBillRounds((String)request.getSession().getAttribute("region")));
			adminAlertThresholdForm.setProcDates(StaticDataLoader.getProcDates((String)request.getSession().getAttribute("region")));
			adminAlertThresholdForm.setHolidayIndicators(StaticDataLoader.getHolidayIndicators((String)request.getSession().getAttribute("region")));
			adminAlertThresholdForm.setLoadedDataDates(StaticDataLoader.getLoadedDataDatesByRegion((String)request.getSession().getAttribute("region")));
			log(adminAlertThresholdForm);
			forward = mapping.findForward("adminAlertThreshold");
		} catch (RABCException e) {
			return this.processError(request, mapping, e);
		}
		return forward;
	}
	
	/**This is the struts framework method called to set up and present the keys for the key level thresholds
	 * for a particular alert and to set new key level thresholds for a particular alert.  A key level threshold
	 * consists of all the keys of an alert plus the alert item.  This method is also responsible for catching 
	 * and logging all exceptions thrown.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of AdminAlertThresholdForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward adminAlertThresholdKey(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = adminAlertThresholdKey");
		ActionForward forward = null;
		try {
			AdminAlertThresholdForm adminAlertThresholdForm = (AdminAlertThresholdForm)form;
			adminAlertThresholdForm.setRegion((String)request.getSession().getAttribute("region"));
			adminAlertThresholdForm.setUserId((String)request.getSession().getAttribute("bacUserID"));
			adminAlertThresholdForm.setBillRounds(StaticDataLoader.getBillRounds((String)request.getSession().getAttribute("region")));
			adminAlertThresholdForm.setProcDates(StaticDataLoader.getProcDates((String)request.getSession().getAttribute("region")));
			adminAlertThresholdForm.setHolidayIndicators(StaticDataLoader.getHolidayIndicators((String)request.getSession().getAttribute("region")));
			adminAlertThresholdForm.setLoadedDataDates(StaticDataLoader.getLoadedDataDatesByRegion((String)request.getSession().getAttribute("region")));
			adminAlertThresholdForm = AdminAlertThresholdService.adminAlertThresholdKey(adminAlertThresholdForm);
			log(adminAlertThresholdForm);
			forward = mapping.findForward("adminAlertThresholdKey");
		} catch (RABCException e) {
			return this.processError(request, mapping, e);
		}
		return forward;
	}
	
	/**This is the struts framework method called to set up and present the threshold detail page - including
	 * showing the values from the key level page.  This method populates data for the key level thresholds
	 * when creating new thresholds for an alert rule.  This method is also responsible for catching and 
	 * logging all exceptions thrown.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of AdminAlertThresholdForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward adminAlertThresholdDetailCreate(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = adminAlertThresholdDetailCreate");
		ActionForward forward = null;
		try {
			AdminAlertThresholdForm adminAlertThresholdForm = (AdminAlertThresholdForm)form;
			adminAlertThresholdForm.setRegion((String)request.getSession().getAttribute("region"));
			adminAlertThresholdForm.setUserId((String)request.getSession().getAttribute("bacUserID"));
			adminAlertThresholdForm = AdminAlertThresholdService.adminAlertThresholdDetailCreate(adminAlertThresholdForm);
			log(adminAlertThresholdForm);
			forward = mapping.findForward("adminAlertThresholdDetail");
		} catch (RABCException e) {
			return this.processError(request, mapping, e);
		}
		return forward;
	}
	
	/**This is the struts framework method called to set up and present the threshold detail page - including
	 * showing the values from the key level page.  This method only presents either existing key level 
	 * thresholds or the rule default threshold for an alert rule.  This method is also  responsible for catching 
	 * and logging all exceptions thrown.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of AdminAlertThresholdForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward adminAlertThresholdDetailView(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = adminAlertThresholdDetailView");
		ActionForward forward = null;
		try {
			AdminAlertThresholdForm adminAlertThresholdForm = (AdminAlertThresholdForm)form;
			adminAlertThresholdForm.setRegion((String)request.getSession().getAttribute("region"));
			adminAlertThresholdForm.setUserId((String)request.getSession().getAttribute("bacUserID"));
			adminAlertThresholdForm = AdminAlertThresholdService.adminAlertThresholdDetailView(adminAlertThresholdForm);
			log(adminAlertThresholdForm);
			forward = mapping.findForward("adminAlertThresholdDetail");
		} catch (RABCException e) {
			return this.processError(request, mapping, e);
		}
		return forward;
	}
	
	/**This is the struts framework method called to set up and present the threshold detail page in pop-up form.  
	 * This method is called from the alert item column on page 11 and only presents either existing key level 
	 * thresholds or the rule default threshold for an alert rule in pop-up format depending upon what alert item,
	 * trend time, keys, and end effective date correspond between the row on page 11 and what thresholds are stored
	 * in the RABC_ALERT_THRSHLD table.  This method is also responsible for catching and logging all exceptions
	 * thrown.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of AdminAlertThresholdForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward adminAlertThresholdDetailPopup(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = adminAlertThresholdDetailPopup");
		ActionForward forward = null;
		try {
			AdminAlertThresholdForm adminAlertThresholdForm = (AdminAlertThresholdForm)form;
			adminAlertThresholdForm.setRegion((String)request.getSession().getAttribute("region"));
			adminAlertThresholdForm.setUserId((String)request.getSession().getAttribute("bacUserID"));
			adminAlertThresholdForm = AdminAlertThresholdService.adminAlertThresholdDetailPopup(adminAlertThresholdForm);
			log(adminAlertThresholdForm);
			forward = mapping.findForward("adminAlertThresholdDetailPopup");
		} catch (RABCException e) {
			return this.processError(request, mapping, e);
		}
		return forward;
	}
	
	/**This is the struts framework method called to end date a key level threshold.  The end dated threshold will 
	 * then eventually show up in the history table below the current table.  This method is also  responsible for
	 * catching and logging all exceptions thrown.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of AdminAlertThresholdForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward adminAlertThresholdDetailDelete(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = adminAlertThresholdDetailDelete");
		ActionForward forward = null;
		try {
			AdminAlertThresholdForm adminAlertThresholdForm = (AdminAlertThresholdForm)form;
			adminAlertThresholdForm.setRegion((String)request.getSession().getAttribute("region"));
			adminAlertThresholdForm.setUserId((String)request.getSession().getAttribute("bacUserID"));
			adminAlertThresholdForm = AdminAlertThresholdService.adminAlertThresholdDetailDelete(adminAlertThresholdForm);
			log(adminAlertThresholdForm);
			forward = mapping.findForward("adminAlertThresholdDelete");
		} catch (RABCException e) {
			return this.processError(request, mapping, e);
		}
		return forward;
	}
	
	/**This is the struts framework method called to set up and present the threshold detail page for rule default
	 * thresholds.  This method updates the rule default threshold for an alert rule.  This method is also 
	 * responsible for catching and logging all exceptions thrown.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of AdminAlertThresholdForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward adminAlertThresholdDetailDefault(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = adminAlertThresholdDetailDefault");
		ActionForward forward = null;
		try {
			AdminAlertThresholdForm adminAlertThresholdForm = (AdminAlertThresholdForm)form;
			adminAlertThresholdForm.setRegion((String)request.getSession().getAttribute("region"));
			adminAlertThresholdForm.setUserId((String)request.getSession().getAttribute("bacUserID"));
			adminAlertThresholdForm = AdminAlertThresholdService.adminAlertThresholdDetailDefault(adminAlertThresholdForm);
			log(adminAlertThresholdForm);
			forward = mapping.findForward("adminAlertThresholdDetail");
		} catch (RABCException e) {
			return this.processError(request, mapping, e);
		}
		return forward;
	}
	
	/**This is the struts framework method called to insert a new threshold into the RABC_ALERT_THRSHLD table.
	 * This method is also  responsible for catching and logging all exceptions thrown.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of AdminAlertThresholdForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward adminAlertThresholdInsert(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = adminAlertThresholdInsert");
		ActionForward forward = null;
		try {
			AdminAlertThresholdForm adminAlertThresholdForm = (AdminAlertThresholdForm)form;
			adminAlertThresholdForm.setRegion((String)request.getSession().getAttribute("region"));
			adminAlertThresholdForm.setUserId((String)request.getSession().getAttribute("bacUserID"));
			adminAlertThresholdForm = AdminAlertThresholdService.adminAlertThresholdInsert(adminAlertThresholdForm);
			log(adminAlertThresholdForm);
			forward = mapping.findForward("adminAlertThreshold");
		} catch (RABCException e) {
			return this.processError(request, mapping, e);
		}
			return forward;
	}
	
	/**This is the struts framework method called to update the rule default threshold in the RABC_ALERT_THRSHLD
	 * table.  This method is also  responsible for catching and logging all exceptions thrown.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of AdminAlertThresholdForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward adminAlertThresholdUpdate(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = adminAlertThresholdUpdate");
		ActionForward forward = null;
		try {
			AdminAlertThresholdForm adminAlertThresholdForm = (AdminAlertThresholdForm)form;
			adminAlertThresholdForm.setRegion((String)request.getSession().getAttribute("region"));
			adminAlertThresholdForm.setUserId((String)request.getSession().getAttribute("bacUserID"));
			if (request.getAttribute("alertRule")!=null){
				adminAlertThresholdForm.setSelectedAlertRule((String)request.getAttribute("alertRule"));
			}
			adminAlertThresholdForm = AdminAlertThresholdService.adminAlertThresholdUpdate(adminAlertThresholdForm);
			log(adminAlertThresholdForm);
			forward = mapping.findForward("adminAlertThreshold");
		} catch (RABCException e) {
			return this.processError(request, mapping, e);
		}
		return forward;
	}
	
	/**This is the struts framework method called to end date a key level threshold in the RABC_ALERT_THRSHLD
	 * table.  This method is also  responsible for catching and logging all exceptions thrown.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of AdminAlertThresholdForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward adminAlertThresholdDelete(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = adminAlertThresholdDelete");
		ActionForward forward = null;
		try {
			AdminAlertThresholdForm adminAlertThresholdForm = (AdminAlertThresholdForm)form;
			adminAlertThresholdForm.setRegion((String)request.getSession().getAttribute("region"));
			adminAlertThresholdForm.setUserId((String)request.getSession().getAttribute("bacUserID"));
			adminAlertThresholdForm = AdminAlertThresholdService.adminAlertThresholdDelete(adminAlertThresholdForm);
			log(adminAlertThresholdForm);
			forward = mapping.findForward("adminAlertThreshold");
		} catch (RABCException e) {
			return this.processError(request, mapping, e);
		}
		return forward;
	}
	
	/**This method sends all error messages to the browser and kills the process.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param request  the HttpServletRequest from the browser
	 * @param e  the error that caused the application to fail.
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	private ActionForward processError(HttpServletRequest request, ActionMapping mapping, RABCException e){
		request.setAttribute("javax.servlet.error.exception", e);
		logger.error(e.getMessage(), e);
		return  mapping.findForward("error");
	}
	
	/**This method only shows values in the form to the console when in debug mode.
	 * 
	 * @param adminAlertThresholdForm  the ActionForm for this process - AdminAlertThresholdForm
	 */
	private void log(AdminAlertThresholdForm adminAlertThresholdForm){
		logger.debug("region = " + adminAlertThresholdForm.getRegion());
		logger.debug("userId = " + adminAlertThresholdForm.getUserId());
		logger.debug("alertRule = " + adminAlertThresholdForm.getSelectedAlertRule());
		logger.debug("*************************************************************************");
	}
}
