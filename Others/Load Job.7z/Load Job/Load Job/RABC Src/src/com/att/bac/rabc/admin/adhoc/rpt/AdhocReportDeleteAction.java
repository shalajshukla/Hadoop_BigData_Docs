/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.admin.adhoc.rpt;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.att.bac.rabc.ConnectionManager;
import com.att.bac.rabc.PickList;
import com.att.bac.rabc.ProgressBar;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;

/**
 * Module description:
 * This is a Action class for Adhoc Report Deletion Page.
 * @author AT1862 - anup Thomas
 */
public class AdhocReportDeleteAction extends DispatchAction {
	public static Logger  logger = Logger.getLogger(AdhocReportDeleteAction.class);
	AdhocReportDeleteService  adhocReportDeleteService = AdhocReportDeleteService.getAdhocReportDeleteService();
	
	/**
	 * Default dispatch action method to handle the request for Adhoc Report deletion.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward AdhocReportDelete(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response){
		AdhocReportDeleteForm  adhocReportDeleteForm = (AdhocReportDeleteForm) form;
		HttpSession session = request.getSession();
		ProgressBar progressBar = new ProgressBar(session);
		Connection connection = null;
		List failureList = new ArrayList();
		List args = new ArrayList();
		args.add((String)request.getSession().getAttribute("bacUserID")) ;
		String presnId = null;
		presnId = (String)request.getAttribute("presnId");
		
		progressBar.setProgressPercent(10);
		
		args.add(presnId);
		
		try {
			connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
			progressBar.setProgressPercent(20);
			
			//adhocReportDeleteService.getDeleteForm(connection, failureList, args,adhocReportDeleteForm);
			AdhocReportDefinition adhocReportDefinition = adhocReportDeleteService.getAdhocReportDefinition(connection, failureList, args);
			progressBar.setProgressPercent(40);
			AdhocReportDefinitionService adhocReportDefinitionService = new AdhocReportDefinitionService();
			adhocReportDeleteForm.setPresnId(presnId);
			adhocReportDeleteForm.setAdhocReportDefinition(adhocReportDefinition);
			List permissionArgs = new ArrayList();
			permissionArgs.add((String)request.getSession().getAttribute("bacUserID")) ;
			permissionArgs.add("UR") ;
			progressBar.setProgressPercent(50);
			String hasPermission  = adhocReportDefinitionService.getPermissionAdhocReport(connection,permissionArgs,failureList);
			adhocReportDeleteForm.setHasDeletePermission(hasPermission);
			progressBar.setProgressPercent(70);
			//some processing is required . for example alert group should be displayed as comma separated 
			getDeleteForm(connection,failureList, args,adhocReportDeleteForm, progressBar, (String)request.getSession().getAttribute("region"));
		}catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		}catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch (Exception e){
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}) + " Exception details: " + e.getMessage(), e);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		progressBar.setProgressPercent(100);
		
		return mapping.findForward("AdhocReportDelete");
		
	}
	/**
	 * Dispatch Action method called when the user clicks on Delete after confirmation
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward ConfirmDelete(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response){
		AdhocReportDeleteForm  adhocReportDeleteForm = (AdhocReportDeleteForm) form;
		HttpSession session = request.getSession();
		ProgressBar progressBar = new ProgressBar(session);

		String  presnId = adhocReportDeleteForm.getPresnId();
		
		Connection connection = null;
		List failureList = new ArrayList();
		
		progressBar.setProgressPercent(10);
		
		try {
			connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
			connection.setAutoCommit(false);
			progressBar.setProgressPercent(40);
			
			adhocReportDeleteService.confirmDelete(connection, failureList, presnId);
			progressBar.setProgressPercent(80);
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch (Exception e){
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}) + " Exception details: " + e.getMessage(), e);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			if (!failureList.isEmpty()){
				try {
					connection.rollback();
				}catch(SQLException sx) {
				   logger.error(RABCMessages.getMessage("ERR_SQL_ROLLBACK_EXEC") + " Exception details: " + sx.getMessage(), sx);
				   failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_ROLLBACK_EXEC"), sx));
				} 
			}else {
				try {
					connection.commit();
				}catch(SQLException sx) {
				   logger.error(RABCMessages.getMessage("ERR_SQL_COMMIT_EXEC") + " Exception details: " + sx.getMessage(), sx);
				   failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_COMMIT_EXEC"), sx));
				} 
			}
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		progressBar.setProgressPercent(100);
		
		return mapping.findForward("ConfirmDelete");
	}	
	
	
	/**
	 * Private method to get the form relayed fields for selected adhoc report
	 * @param connection
	 * @param failures
	 * @param args
	 * @param adhocReportDeleteForm
	 * @param progressBar
	 * @param region
	 */
	private void getDeleteForm(Connection connection, List failures, List args,AdhocReportDeleteForm adhocReportDeleteForm,ProgressBar progressBar,String region){						
		AdhocReportDefinitionService   adhocReportDefinitionService = new AdhocReportDefinitionService();
					
		String[] alertGrpArr=null;	
		String alertGrp="";	
		String dataSource="";
		String reportType="";
		List reportTypeList = new ArrayList();
		AdhocReportDefinition adhocReportDefinition =  adhocReportDeleteForm.getAdhocReportDefinition();
		
		if ("D".equals(adhocReportDefinition.getRptType())){
			reportType="Daily";
		}else if ("M".equals(adhocReportDefinition.getRptType())){
			reportType="Monthly";
		}else if ("B".equals(adhocReportDefinition.getRptType())){
			if ("MW".equals(region)){
				reportType="Process Group";
			}else {
				reportType="Bill Day";
			}
		}else if ("Y".equals(adhocReportDefinition.getRptType())){
			reportType="Yearly";
		}
		reportTypeList = adhocReportDefinitionService.getReportTypeList(region);
		int reportTypeListSize = reportTypeList.size();
		for (int i=0;i<reportTypeListSize;i++){
			PickList reportTypeItem = (PickList)reportTypeList.get(i);
			
			if (reportTypeItem.getValue1().equals(adhocReportDefinition.getRptType())){
				reportType = reportTypeItem.getKey();
				break;
			}
		}
	
		List dataSourceList = adhocReportDefinitionService.getDataSourceList(region);
		int dataSourceListSize = dataSourceList.size();
		for (int i=0;i<dataSourceListSize;i++){
			PickList dataSourceItem = (PickList)dataSourceList.get(i);
			
			if (dataSourceItem!=null){
				if (dataSourceItem.getKey().equals(adhocReportDefinition.getDataNode())){
					dataSource = dataSourceItem.getValue2();
					break;
				}
			}
		}
		
		alertGrpArr = adhocReportDefinitionService.getAlertGroupSelected(connection,failures,args);
		progressBar.setProgressPercent(80);
		int alertGrpArrSize = alertGrpArr.length;
		for (int i=0;i<alertGrpArrSize;i++){
			if (i==0){
				alertGrp = alertGrpArr[i];
			}else{
				alertGrp = alertGrp+","+alertGrpArr[i];
			}
		}
		
		adhocReportDeleteForm.setRptType(reportType);
		adhocReportDeleteForm.setAlertGrp(alertGrp);
		adhocReportDeleteForm.setDataNode(dataSource);
		List presnHeaderList =  adhocReportDefinitionService.getRABCPresnHeaderList(connection,failures,args) ;
		progressBar.setProgressPercent(90);
	}
}
