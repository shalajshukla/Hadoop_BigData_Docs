/* Component Name: RABCPPG00594
 * Module Name: CntrlPtCertDAO.java
 * Created on Mar 20, 2006
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.cntrlptcert;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.att.bac.rabc.PickList;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.StaticDataLoader;
import com.att.carat.util.JDBCUtil;

/**This is a DAO that will connect to the RABC_CNTRL_PT_CERT table for SELECT, INSERT, UPDATE and DELETE queries.
 * 
 * @author ml2195
 */
public class CntrlPtCertDAO {
	private static final Logger logger = Logger.getLogger(CntrlPtCertDAO.class);
	
	/**This certifies the selected processes by updating the value of the CERT_IND column in the RABC_CNTRL_PROCESS_CERT 
	 * to "Y".
	 * 
	 * @param conn  Connection passed from the Service class
	 * @param cntrlPtCertForm  Form created in the action class and passed down
	 * @param startDate  start date from web page
	 * @param endDate  end date from web page
	 * @param stateDesc  state name
	 * @param process  process name
	 * @param certInd  certification indicator - 'Y' is certified, 'N' is not certified
	 * @param issueInd  issue indicator
	 * @throws RABCException
	 */
	protected static void certifyProcess(Connection conn, CntrlPtCertForm cntrlPtCertForm, String startDate, String endDate, String stateDesc, String process, String certInd, String issueInd) throws RABCException {
		Statement stmt = null;
		String sqlStmt = "";
		String state = "";
		String whereClause = "";	
		ArrayList whereClauseList = new ArrayList();
		String certifyProcess = "UPDATE RABC_CNTRL_PROCESS_CERT " +
								"SET CERT_IND = ''Y'' " +
								"WHERE {0}";
		try {
			//convert state description to state acronym
			if (stateDesc.equals("All"))
				state = stateDesc;
			else
				state = getStateAcronym(conn, stateDesc);
			if (startDate.equals(endDate))
				whereClause += " RUN_DATE = to_date('"+startDate+"','mm/dd/yyyy')";	
			else {
				whereClause +=" RUN_DATE >= to_date('"+startDate+"', 'mm/dd/yyyy')";
				whereClause +=" AND RUN_DATE <= to_date('"+endDate+"', 'mm/dd/yyyy')";
			}
			if (state.equals("All"))
				whereClause += " ";
			else
				whereClause += " AND STATE = '" + state + "'";
			if (process.equals("All"))
				whereClause += " ";
			else
				whereClause += " AND PROCESS = '" + process + "'";
			if (issueInd.equals("A"))
				whereClause += " ";
			else
				whereClause += " AND ISSUE_IND = '" + issueInd + "'";
			if (whereClause != null )
				whereClauseList.add(whereClause);
			else
				whereClauseList.add(" ");
			stmt = conn.createStatement();		
			MessageFormat mf = new MessageFormat(certifyProcess);
			sqlStmt = mf.format((String[])whereClauseList.toArray(new String[whereClauseList.size()]));
			logger.debug("Starting row update...");
			int rowsUpdated = stmt.executeUpdate(sqlStmt);	
			if (rowsUpdated > 0)
				cntrlPtCertForm.setJSAlertMsg("cert");
			else
				cntrlPtCertForm.setJSAlertMsg("nocert");
			logger.debug("Finished row update.");
		} catch (SQLException sqle) {
			JDBCUtil.rollback(conn);
			throw new RABCException("Error in updating a process's certification using certifyProcess query: ", sqle);
		} finally {
			JDBCUtil.closeStatement(stmt);
		}
	}
	
	/**
	 * Method will certify all
	 * @param conn
	 * @param cntrlPtCertForm
	 * @param startDate
	 * @param endDate
	 * @param stateDesc
	 * @param process
	 * @param certInd
	 * @param issueInd
	 * @throws RABCException
	 */
	protected static void certifyProcessAll(Connection conn, List cntrlPtCertViewList, CntrlPtCertForm cntrlPtCertForm) throws RABCException {
		PreparedStatement sqlStmt = null;
		
		try {
			sqlStmt = conn.prepareStatement("UPDATE RABC_CNTRL_PROCESS_CERT SET CERT_IND = ? WHERE STATE = ? AND " +
			"RUN_DATE = to_date(? ,'mm/dd/yyyy') AND PROCESS = ? AND ISSUE_IND = ?");
			
			if (cntrlPtCertViewList !=null & !cntrlPtCertViewList.isEmpty()){
				int cntrlPtCertViewListSize = cntrlPtCertViewList.size();
				for (int i=0;i<cntrlPtCertViewListSize;i++){
					CntrlPtCertView cntrlPtCertView = (CntrlPtCertView) cntrlPtCertViewList.get(i);
					
					sqlStmt.setString(1, "Y");
					sqlStmt.setString(2, getStateAcronym(conn, cntrlPtCertView.getStateDesc()));
					sqlStmt.setString(3, cntrlPtCertView.getRunDate());
					sqlStmt.setString(4,cntrlPtCertView.getProcess());
					sqlStmt.setString(5,cntrlPtCertView.getIssueInd());
					sqlStmt.addBatch();
				}
			}
			
			int [] rowsUpdated = sqlStmt.executeBatch();
			if (rowsUpdated.length > 0)
				cntrlPtCertForm.setJSAlertMsg("cert");
			else
				cntrlPtCertForm.setJSAlertMsg("nocert");
			
			conn.commit();
			logger.debug("Finished row update.");
		} catch (SQLException sqle) {
			JDBCUtil.rollback(conn);
			throw new RABCException("Error in updating a process's certification using certifyProcess query: ", sqle);
		} finally {
			JDBCUtil.closeStatement(sqlStmt);
		}
	}

	/**This updates data in the RABC_CNTRL_PROCESS_CERT table and adds comments to the RABC_CNTRL_PROC_CERT_COMMENT 
	 * as needed.
	 * 
	 * @param conn  Connection passed from the Service class
	 * @param cntrlPtCertForm  Form created in the action class and passed down
	 * @throws RABCException
	 */
	protected static void updateProcess(Connection conn, CntrlPtCertForm cntrlPtCertForm) throws RABCException {
		Statement stmt = null;
		String sqlStmt = "";
		String updtCntrlPtCert = "UPDATE RABC_CNTRL_PROCESS_CERT " +
								 "SET CERT_IND = {0}, " +
								 "    ISSUE_IND = {1}, " +
								 "    USER_ID = {2}, " +
								 "    ISSUE_REVENUE_DB = {3}, " +
								 "    ISSUE_REVENUE_CR = {4}, " +
								 "    ISSUE_LOST_REVENUE = {5}, " +
								 "	  TIME_STAMP = sysdate " +
								 "WHERE RUN_DATE = {6} " +
								 "  AND STATE = {7} " +
								 "  AND PROCESS = {8}";
		ArrayList argsList = new ArrayList();
		String sDebitRev = String.valueOf(cntrlPtCertForm.getDebitRevImpact());
		String sCreditRev = String.valueOf(cntrlPtCertForm.getCreditRevImpact());
		String sLostRev = String.valueOf(cntrlPtCertForm.getLostRevImpact());
		cntrlPtCertForm.addCertNum(cntrlPtCertForm.getCertNum());
		
		try {
			logger.debug("Setting up arguments...");
			//Insert values to RABC_CNTRL_PROCESS_CERT
			argsList.add("'"+cntrlPtCertForm.getCertInd()+"'");
			argsList.add("'"+cntrlPtCertForm.getIssueInd()+"'");
			argsList.add("'"+cntrlPtCertForm.getLoginUserID()+"'");
			argsList.add(sDebitRev);
			argsList.add(sCreditRev);
			argsList.add(sLostRev);
			argsList.add("to_date('"+cntrlPtCertForm.getRunDate()+"','mm/dd/yyyy')");
			//convert state description to state acronym
			String state = getStateAcronym(conn, cntrlPtCertForm.getStateDesc());
			argsList.add("'"+state+"'");
			argsList.add("'"+cntrlPtCertForm.getProcess()+"'");
			logger.debug("Arguments set up.");
			stmt = conn.createStatement();
			MessageFormat mf = new MessageFormat(updtCntrlPtCert);
			sqlStmt = mf.format((String[])argsList.toArray(new String[argsList.size()]));
			logger.debug("Executing SQL...");
			stmt.executeUpdate(sqlStmt);
			logger.debug("SQL finished.");
			cntrlPtCertForm.setJSAlertMsg("updt");
		} catch (SQLException sqle) {
			JDBCUtil.rollback(conn);
			throw new RABCException("Error in updating a control process's certification using updtCntrlPtCert query: ", sqle);
		} finally {
			JDBCUtil.closeStatement(stmt);
		}
	}
	
	/**This inserts new processes for certification, including comments, in the RABC_CNTRL_PROCESS_CERT table.
	 * 
	 * @param conn  Connection passed from the Service class
	 * @param cntrlPtCertForm  Form created in the action class and passed down
	 * @throws RABCException
	 */
	protected static void insertProcess(Connection conn, CntrlPtCertForm cntrlPtCertForm) throws RABCException {
		Statement stmt = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sqlStmt = "";
		String getNextCertNum = "SELECT EWSSEQ_CERT_NO.NEXTVAL FROM DUAL";
		try {
			if ("All".equals(cntrlPtCertForm.getStateDesc()) || "All".equals(cntrlPtCertForm.getProcess())) {
				List stateList = new ArrayList();
				List processList = new ArrayList();
				
				/*
				 * Form the list of states
				 */
				if ("All".equals(cntrlPtCertForm.getStateDesc())){
					String region = cntrlPtCertForm.getRegion();
					if ("EN".equals(cntrlPtCertForm.getRegion())){
						region = cntrlPtCertForm.getSelectedRegion();
					}
					List list = StaticDataLoader.getStatesByRegion(region);
					int listSize = list.size();
					for (int i=0;i<listSize;i++){
						stateList.add((String)list.get(i));
					}
				} else {
					stateList.add(getStateAcronym(conn, cntrlPtCertForm.getStateDesc()));
				}
				
				/*
				 * Form the list of processes
				 */
				if ("All".equals(cntrlPtCertForm.getProcess())){
					String region = cntrlPtCertForm.getRegion();
					if ("EN".equals(cntrlPtCertForm.getRegion())){
						region = cntrlPtCertForm.getSelectedRegion();
					}
					List list = StaticDataLoader.getDistinctProcesses(region);
					int listSize = list.size();
					for (int i=0;i<listSize;i++){
						processList.add((String)list.get(i));
					}
				} else {
					processList.add(cntrlPtCertForm.getProcess());
				}
				
				/*
				 * Outer loop of states & inner loop of processes
				 */
				int stateListSize = stateList.size();
				int processListSize = processList.size();
				for (int i=0;i<stateListSize;i++){
					String state = (String)stateList.get(i);
					for (int j=0;j<processListSize;j++){
						String process = (String) processList.get(j);
						
						stmt = conn.createStatement();
						rs = stmt.executeQuery(getNextCertNum);
						if (rs.next()) {
							cntrlPtCertForm.setCertNum(rs.getInt(1));
							cntrlPtCertForm.addCertNum(cntrlPtCertForm.getCertNum());
						}
						
						//	Insert values to RABC_CNTRL_PROCESS_CERT
						String insertCntrlPtCert = "INSERT INTO RABC_CNTRL_PROCESS_CERT (CERT_NUM, RUN_DATE, STATE, PROCESS, CERT_IND, ISSUE_IND, USER_ID, ISSUE_REVENUE_CR, ISSUE_REVENUE_DB, ISSUE_LOST_REVENUE, TIME_STAMP)" +
												   "{0}";			
						String value1 = "VALUES (" + cntrlPtCertForm.getCertNum() + ", " + 
					                    "to_date('"+cntrlPtCertForm.getRunDate()+"','mm/dd/yyyy'), " +
									    "'" + state + "', " +
										"'" + process + "', " +
										"'" + cntrlPtCertForm.getCertInd() + "', " +
										"'" + cntrlPtCertForm.getIssueInd() + "', " +
										"'" + cntrlPtCertForm.getLoginUserID() + "', " +
										cntrlPtCertForm.getCreditRevImpact() + ", " +
										cntrlPtCertForm.getDebitRevImpact() + ", " +
										cntrlPtCertForm.getLostRevImpact() + ", " +
										"sysdate" + ")";
						
						ArrayList value1List = new ArrayList();
						value1List.add(value1);
						stmt = conn.createStatement();
						MessageFormat mf = new MessageFormat(insertCntrlPtCert);
						sqlStmt = mf.format((String[])value1List.toArray(new String[value1List.size()]));
						logger.debug("Insert new control process certification...");
						stmt.executeUpdate(sqlStmt);
					}
				}
			} else {
				logger.debug("Get sequence number...");
				//Get the next value for the certification number.
				ps = conn.prepareStatement(getNextCertNum);
				rs = ps.executeQuery();
				if (rs.next()) {
					cntrlPtCertForm.setCertNum(rs.getInt(1));
					cntrlPtCertForm.addCertNum(cntrlPtCertForm.getCertNum());
				}
				logger.debug("Get state acronym.");
				//convert state description to state acronym
				String state = getStateAcronym(conn, cntrlPtCertForm.getStateDesc());
				//Insert values to RABC_CNTRL_PROCESS_CERT
				String insertCntrlPtCert = "INSERT INTO RABC_CNTRL_PROCESS_CERT (CERT_NUM, RUN_DATE, STATE, PROCESS, CERT_IND, ISSUE_IND, USER_ID, ISSUE_REVENUE_CR, ISSUE_REVENUE_DB, ISSUE_LOST_REVENUE, TIME_STAMP)" +
										   "{0}";			
				String value1 = "VALUES (" + cntrlPtCertForm.getCertNum() + ", " + 
			                    "to_date('"+cntrlPtCertForm.getRunDate()+"','mm/dd/yyyy'), " +
							    "'" + state + "', " +
								"'" + cntrlPtCertForm.getProcess() + "', " +
								"'" + cntrlPtCertForm.getCertInd() + "', " +
								"'" + cntrlPtCertForm.getIssueInd() + "', " +
								"'" + cntrlPtCertForm.getLoginUserID() + "', " +
								cntrlPtCertForm.getCreditRevImpact() + ", " +
								cntrlPtCertForm.getDebitRevImpact() + ", " +
								cntrlPtCertForm.getLostRevImpact() + ", " +
								"sysdate" + ")";
				ArrayList value1List = new ArrayList();
				value1List.add(value1);
				stmt = conn.createStatement();
				MessageFormat mf = new MessageFormat(insertCntrlPtCert);
				sqlStmt = mf.format((String[])value1List.toArray(new String[value1List.size()]));
				logger.debug("Insert new control process certification...");
				stmt.executeUpdate(sqlStmt);
			}
			
			logger.debug("Finished insert.");
			cntrlPtCertForm.setJSAlertMsg("new");
		} catch (SQLException sqle) {
			JDBCUtil.rollback(conn);
			throw new RABCException("Error in inserting a new control process using insertCntrlPtCert query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
			JDBCUtil.closeStatement(stmt);
		}
	} 
	
	/**This inserts comments into the RABC_CNTRL_PROC_CERT_COMMENT table.
	 * 
	 * @param conn  Connection passed from the Service class
	 * @param cntrlPtCertForm  Form created in the action class and passed down
	 * @throws RABCException
	 */
	protected static void insertComments (Connection conn, CntrlPtCertForm cntrlPtCertForm) throws RABCException {
		Statement stmt = null;
		String sqlStmt = "";
		try {
			String insertCntrlPtCertComment = "INSERT INTO RABC_CNTRL_PROC_CERT_COMMENT " +
			  "(CERT_NUM, USER_ID, CERT_IND, TIME_STAMP, SUBJECT, CERT_COMMENT) " +
			  "{0}";		
			
			List certNumList = cntrlPtCertForm.getCertNumList();
			if (!certNumList.isEmpty()){
				int certNumListSize = certNumList.size();
				for (int i=0;i<certNumListSize;i++){
					int certNum = ((Integer)certNumList.get(i)).intValue();
					String value2 = "VALUES ("  + certNum + ", " + 
					"'" + cntrlPtCertForm.getLoginUserID() + "', " +
					"'" + cntrlPtCertForm.getCertInd() + "', " +
					"sysdate, " + 
					"'" + cntrlPtCertForm.getCommentSubject() + "', " +
					"'" + cntrlPtCertForm.getCommentDetail() + "')";
					
					ArrayList value2List = new ArrayList();
					value2List.add(value2);
					stmt = conn.createStatement();			
					MessageFormat mf = new MessageFormat(insertCntrlPtCertComment);
					sqlStmt = mf.format((String[])value2List.toArray(new String[value2List.size()]));
					logger.debug("Insert comments...");
					stmt.executeUpdate(sqlStmt);
					logger.debug("Comments inserted.");
				}
			}
		} catch (SQLException sqle) {
			JDBCUtil.rollback(conn);
			throw new RABCException("Error in inserting a comment using insertCntrlPtCertComment query: ", sqle);
		} finally {
			JDBCUtil.closeStatement(stmt);
		}
	}
	
	/**Verify that the data to be inserted does not exist in the database. This method returns 0 when there is
	 * no duplicate. A return code of 1 means that data is in the database.
	 * 
	 * @param conn  Connection passed from the Service class
	 * @param cntrlPtCertForm  Form created in the action class and passed down
	 * @return dupExists  1 indicates a duplicate, 0 indicates no duplicates
	 * @throws RABCException
	 */
	protected static int checkForDup(Connection conn, CntrlPtCertForm cntrlPtCertForm) throws RABCException {
		Statement stmt = null;
		ResultSet rs = null;
		String sqlStmt = "";
		cntrlPtCertForm.setJSAlertMsg(" ");
		String verifyNoDupInsert = "SELECT CERT_NUM, RUN_DATE, STATE, PROCESS, CERT_IND, ISSUE_IND, ISSUE_REVENUE_CR, ISSUE_REVENUE_DB, ISSUE_LOST_REVENUE " +
								   "FROM RABC_CNTRL_PROCESS_CERT " +
								   "WHERE {0}" ;
		String whereClause = "";
		ArrayList whereClauseList = new ArrayList();
		int dupExists = 0;
		try {
			if (cntrlPtCertForm.getRunDate() == "")
				whereClause += " RUN_DATE = to_date('"+cntrlPtCertForm.getStartDate()+"','mm/dd/yyyy')";
			else
				whereClause += " RUN_DATE = to_date('"+cntrlPtCertForm.getRunDate()+"','mm/dd/yyyy')";
			
			//convert state description to state acronym
			if (!"All".equals(cntrlPtCertForm.getStateDesc())){
				String state = getStateAcronym(conn, cntrlPtCertForm.getStateDesc());
				whereClause += " AND STATE = '"+state+"' ";
			}
			if (!"All".equals(cntrlPtCertForm.getProcess())){
				whereClause += " AND PROCESS = '"+cntrlPtCertForm.getProcess()+"' ";	
			}
			whereClauseList.add(whereClause);
			
			stmt = conn.createStatement();		
			MessageFormat mf = new MessageFormat(verifyNoDupInsert);
			sqlStmt = mf.format((String[])whereClauseList.toArray(new String[whereClauseList.size()]));		
			rs = stmt.executeQuery(sqlStmt);	
			if (rs.next()) {	
				dupExists = 1;
				String tempDate = rs.getDate("RUN_DATE").toString();
				cntrlPtCertForm.setRunDate(tempDate.substring(5,7) + "/" + tempDate.substring(8,10) + "/" + tempDate.substring(0,4));			
				cntrlPtCertForm.setCertNum(rs.getInt("CERT_NUM"));			
				cntrlPtCertForm.setState(rs.getString("STATE"));
				cntrlPtCertForm.setStateDesc(getStateDesc(conn, rs.getString("STATE")));
				cntrlPtCertForm.setProcess(rs.getString("PROCESS"));
				cntrlPtCertForm.setCertInd(rs.getString("CERT_IND"));
				cntrlPtCertForm.setIssueInd(rs.getString("ISSUE_IND"));
				cntrlPtCertForm.setCreditRevImpact(rs.getDouble("ISSUE_REVENUE_CR"));
				cntrlPtCertForm.setDebitRevImpact(rs.getDouble("ISSUE_REVENUE_DB"));
				cntrlPtCertForm.setLostRevImpact(rs.getDouble("ISSUE_LOST_REVENUE"));
			} else {
				dupExists = 0;
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in duplicate control process check using verifyNoDupInsert query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closeStatement(stmt);
		}
		return dupExists;
	}
	
	/**This selects all the states from the RABC_CRO_CD_DIVISION table and moves them to the CntrlPtCertForm bean. 
	 * The states will be used in the State pull-down input box.
	 * 
	 * @param conn  Connection passed from the Service class
	 * @param cntrlPtCertForm  Form created in the action class and passed down
	 * @throws RABCException
	 */
	protected static void getStateList(Connection conn, CntrlPtCertForm cntrlPtCertForm) throws RABCException {
		Statement stmt = null;
		ResultSet rs = null;
		String getStates = "SELECT DISTINCT STATE_DESC FROM RABC_DIVISION ORDER BY STATE_DESC";
		try {			
			stmt = conn.createStatement();	
			rs = stmt.executeQuery(getStates);
			while (rs.next())
				cntrlPtCertForm.setStateList(rs.getString(1)); 
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving user's access level using getUsrAccess query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closeStatement(stmt);
		}	
	}
	
	/**This selects all the processes from the RABC_PROCESS table and moves them to the CntrlPtCertForm bean.
	 * The processes will be used in the Process pull-down input box.
	 * 
	 * @param conn  Connection passed from the Service class
	 * @param cntrlPtCertForm  Form created in the action class and passed down
	 * @throws RABCException
	 */
	protected static void getProcessList(Connection conn, CntrlPtCertForm cntrlPtCertForm) throws RABCException {
		Statement stmt = null;
		ResultSet rs = null;
		String getProcesses = "SELECT DISTINCT PROCESS FROM RABC_PROCESS ORDER BY PROCESS";
		try {
			stmt = conn.createStatement();	
			rs = stmt.executeQuery(getProcesses);
			while (rs.next())
				cntrlPtCertForm.setProcessList(rs.getString(1));
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving process names using getProcesses query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closeStatement(stmt);
		}
	}
	
	/**This selects all the run date, state, process, certification ind and issue ind from the RABC_CNTRL_PROCESS_CERT table
	 * based on the selection criteria provided.
	 * 
	 * @param conn  Connection passed from the Service class
	 * @param cntrlPtCertForm  Form created in the action class and passed down
	 * @param startDate  start date from web page
	 * @param endDate  end date from web page
	 * @param stateDesc  state name
	 * @param process  process name
	 * @param certInd  certification indicator - 'Y' is certified, 'N' is not certified
	 * @param issueInd  issue indicator
	 * @throws RABCException
	 */
	protected static void getCntrlPtCertViewList(Connection conn, CntrlPtCertForm cntrlPtCertForm, String startDate, String endDate, String stateDesc, String process, String certInd, String issueInd) throws RABCException {
		Statement stmt = null;
		ResultSet rs = null;
		String sqlStmt = "";
		String getCntrlPtCertViewData = "SELECT RUN_DATE, STATE, PROCESS, CERT_IND, ISSUE_IND, CERT_NUM, USER_ID " +
										"FROM RABC_CNTRL_PROCESS_CERT " +
										"WHERE {0} " +
										"ORDER BY RUN_DATE, STATE, PROCESS";
		String whereClause = "";
		ArrayList whereClauseList = new ArrayList();
		//convert state description to state acronym
		String state = "";
		try {
			if (stateDesc.equals("All"))
				state = stateDesc;
			else
				state = getStateAcronym(conn, stateDesc);
			//build WHERE clause
			if (startDate.equals(endDate))
				whereClause += " RUN_DATE = to_date('"+startDate+"','mm/dd/yyyy')";
			else {
				whereClause +=" RUN_DATE >= to_date('"+startDate+"', 'mm/dd/yyyy')";
				whereClause +=" AND RUN_DATE <= to_date('"+endDate+"', 'mm/dd/yyyy')";
			}
			if (state.equals("All"))
				whereClause += " ";
			else
				whereClause += " AND STATE = '" + state + "'";
			if (process.equals("All"))
				whereClause += " ";
			else
				whereClause += " AND PROCESS = '" + process + "'";
			if (certInd.equals("A"))
				whereClause += " ";
			else
				whereClause += " AND CERT_IND = '" + certInd + "'";
			if (issueInd.equals("A"))
				whereClause += " ";
			else
				whereClause += " AND ISSUE_IND = '" + issueInd + "'";
			if (whereClause != null )
				whereClauseList.add(whereClause);
			else
				whereClauseList.add(" ");
			//execute SQL statement
			stmt = conn.createStatement();
			MessageFormat mf = new MessageFormat(getCntrlPtCertViewData);
			sqlStmt = mf.format((String[])whereClauseList.toArray(new String[whereClauseList.size()]));
			rs = stmt.executeQuery(sqlStmt);
			while (rs.next())
				cntrlPtCertForm.getCntrlPtCertViewList().add(buildCntrlPtCertView(conn, rs, cntrlPtCertForm.getSelectedRegion()));
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving view data using getCntrlPtCertViewData query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closeStatement(stmt);
		}
	}
	
	/**This builds the CntrlPtCertView form. This form will contain data that will be displayed in the main page's 
	 * table.
	 * 
	 * @param conn  Connection passed from the Service class
	 * @param rs  The result set passed from getCntrlPtCertViewList()
	 * @param region  The region the user is in
	 * @return cntrlPtCertView  The transfer object that contains view information
	 * @throws RABCException
	 */
	private static CntrlPtCertView buildCntrlPtCertView(Connection conn, ResultSet rs, String selectedRegion) throws RABCException {
		CntrlPtCertView cntrlPtCertView = new CntrlPtCertView();
		try {
			String tempDate = rs.getDate("RUN_DATE").toString();
			cntrlPtCertView.setRunDate(tempDate.substring(5,7) + "/" + tempDate.substring(8,10) + "/" + tempDate.substring(0,4));
			cntrlPtCertView.setStateDesc(getStateDesc(conn, rs.getString("STATE")));
			cntrlPtCertView.setProcess(rs.getString("PROCESS"));	
			cntrlPtCertView.setCertInd(rs.getString("CERT_IND"));   
			cntrlPtCertView.setIssueInd(rs.getString("ISSUE_IND"));
			cntrlPtCertView.setCertNum(rs.getInt("CERT_NUM"));
			cntrlPtCertView.setSavedUserID(rs.getString("USER_ID"));
			cntrlPtCertView.setSelectedRegion(selectedRegion);
		} catch (SQLException sqle) {
			throw new RABCException("Error in setting up cntrlPtCertView object: ", sqle);
		}
		return cntrlPtCertView;	
	}
	
	/**This extracts comments from the RABC_CNTRL_PROC_CERT_COMMENT and RABC_ALERT_COMMENT for a process.
	 * 
	 * @param conn  Connection passed from the Service class
	 * @param cntrlPtCertForm  Form created in the action class and passed down
	 * @throws RABCException
	 */
	protected static void getCntrlPtCertCommentList(Connection conn, CntrlPtCertForm cntrlPtCertForm) throws RABCException {
		Statement stmt = null;
		ResultSet rs = null;
		String sqlStmt = "";
		//get all control points for the given process
		String controlPoints = getControlPoints(conn, cntrlPtCertForm);
		//get comments 
		String getComments = "SELECT TIME_STAMP as time_stamp, " +
							 "'' ''       as alert_rule, " +
							 "0           as alert_key_lvl, " +
							 "'' ''       as alert_key1, " +
							 "'' ''       as alert_key2, " +
							 "'' ''       as alert_key3, " +
							 "'' ''       as alert_key4, " +
							 "'' ''       as alert_key5, " +
							 "'' ''       as alert_item, " +
							 "USER_ID           as user_id, " +
							 "CERT_IND          as cert_ind, " +
							 "'' ''     as alert_status, " +
							 "9                 as alert_revenue, " +
							 "CERT_NUM          as cert_num, " +
							 "CERT_COMMENT      as comments, " +
							 "SUBJECT           as subject " +
							 "FROM RABC_CNTRL_PROC_CERT_COMMENT " +
							 "WHERE CERT_NUM = {0} " +
							 "UNION " +
							 "SELECT B.TIME_STAMP as time_stamp, " +
							 "C.ALERT_RULE        as alert_rule, " +
							 "C.ALERT_KEY_LVL     as alert_key_lvl, " +
							 "C.ALERT_KEY1        as alert_key1, " +
							 "C.ALERT_KEY2        as alert_key2, " +
							 "C.ALERT_KEY3        as alert_key3, " +
							 "C.ALERT_KEY4        as alert_key4, " +
							 "C.ALERT_KEY5        as alert_key5, " +
							 "C.ALERT_ITEM        as alert_item, " +
							 "B.COMMENT_USER_ID   as user_id, " +
							 "'' ''                 as cert_ind, " +
							 "C.ALERT_STATUS      as alert_status, " +
							 "C.ALERT_REVENUE     as alert_revenue, " +
							 "0                   as cert_num, " +
							 "B.MSG_COMMENT       as comments, " +
							 "'' ''           as subject " +
							 "FROM RABC_ALERT_COMMENT B, RABC_ALERT_MSG C, RABC_CNTRL_PT_ALERT D " +
							 "WHERE D.CNTRL_PT_CD IN {1} " +
							 "  AND C.PROC_DATE = {2} " +
							 "  AND B.MSG_NUM = C.MSG_NUM " +
							 "  AND C.ALERT_RULE = D.ALERT_RULE";
		String sCertNum = String.valueOf(cntrlPtCertForm.getCertNum());
		String procDate = " to_date('"+cntrlPtCertForm.getRunDate()+"','mm/dd/yyyy')";
		ArrayList argsList = new ArrayList(0);
		argsList.add(sCertNum);

		if (!"()".equals(controlPoints)) {
			argsList.add(controlPoints);
		}else {
			argsList.add(" (' ') ");
		}
		
		argsList.add(procDate);
		int rowCount = 1;
		try {			
			stmt = conn.createStatement();		
			MessageFormat mf = new MessageFormat(getComments);
			sqlStmt = mf.format((String[])argsList.toArray(new String[argsList.size()]));				
			rs = stmt.executeQuery(sqlStmt);
			while (rs.next()) {			
				cntrlPtCertForm.getCntrlPtCertCommentList().add(buildCntrlPtCertComment(rs, rowCount));
				rowCount++;				
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving comments using getComments query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closeStatement(stmt);
		}
	}
	
	/**This builds the comment list to be displayed as Comment History in the Detail page. 
	 * 
	 * @param rs  Result set passed from the getCntrlPtCertCommentList() method
	 * @param rowCount  Number of rows to be processed
	 * @return cntrlPtCertComment  The transfer object containing comment information
	 * @throws RABCException
	 */
	private static CntrlPtCertComment buildCntrlPtCertComment(ResultSet rs, int rowCount) throws RABCException {
		CntrlPtCertComment cntrlPtCertComment = new CntrlPtCertComment();
		try {
			cntrlPtCertComment.setTimeStamp(rs.getDate("time_stamp"));
			cntrlPtCertComment.setAlertRule(rs.getString("alert_rule"));
			for (int i = 0; i < rs.getInt("alert_key_lvl"); i++) {
				int j = i + 1;
				cntrlPtCertComment.setAlertKeys(rs.getString("alert_key" + j));
			}
			cntrlPtCertComment.setAlertItem(rs.getString("alert_item"));
			cntrlPtCertComment.setSavedUserID(rs.getString("user_id"));
			cntrlPtCertComment.setCertInd(rs.getString("cert_ind"));
			cntrlPtCertComment.setAlertStatus(rs.getString("alert_status"));
			cntrlPtCertComment.setAlertRevenue(rs.getDouble("alert_revenue"));
			cntrlPtCertComment.setCertNum(rs.getInt("cert_num"));
			cntrlPtCertComment.setSubject(rs.getString("subject"));   
			cntrlPtCertComment.setComment(rs.getString("comments"));
			int colorIndex = rowCount%2;
			if (colorIndex == 1)
				cntrlPtCertComment.setBgColor("white");
			else
				cntrlPtCertComment.setBgColor("skyblue");
		} catch (SQLException sqle) {
			throw new RABCException("Error in setting up cntrlPtCertComment object: ", sqle);
		}
		return cntrlPtCertComment;	
	}
	
	/**This gets the revenue amounts from the RABC_CNTRL_PROC_CERT table.
	 * 
	 * @param conn  Connection passed from the Service class
	 * @param cntrlPtCertForm  Form created in the action class and passed down
	 * @throws RABCException
	 */
	protected static void getRevenueAmts(Connection conn, CntrlPtCertForm cntrlPtCertForm) throws RABCException {	
		Statement stmt = null;
		ResultSet rs = null;
		String sqlStmt = "";
		//get control process cert revenue impacts
		String getRevenues = "SELECT  ISSUE_REVENUE_DB, ISSUE_REVENUE_CR, ISSUE_LOST_REVENUE " +
							 "FROM RABC_CNTRL_PROCESS_CERT " +
							 "WHERE CERT_NUM = {0}";	
		String sCertNum = String.valueOf(cntrlPtCertForm.getCertNum());
		ArrayList argsList = new ArrayList(0);
		argsList.add(sCertNum);
		try {		
			stmt = conn.createStatement();		
			MessageFormat mf = new MessageFormat(getRevenues);
			sqlStmt = mf.format((String[])argsList.toArray(new String[argsList.size()]));				
			rs = stmt.executeQuery(sqlStmt);	
			while (rs.next()) {
				cntrlPtCertForm.setDebitRevImpact(rs.getDouble("ISSUE_REVENUE_DB"));
				cntrlPtCertForm.setCreditRevImpact(rs.getDouble("ISSUE_REVENUE_CR"));
				cntrlPtCertForm.setLostRevImpact(rs.getDouble("ISSUE_LOST_REVENUE"));
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving revenue amounts using getRevenues query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closeStatement(stmt);
		} 	
		//get alert msg revenue impact
		getAlertMsgRevenueAmts(conn, cntrlPtCertForm);
	}
	
	/**This gets the alert message revenue aounts from the RABC_ALERT_MSG table.
	 * 
	 * @param conn  Connection passed from the Service class
	 * @param cntrlPtCertForm  Form created in the action class and passed down
	 * @throws RABCException
	 */
	protected static void getAlertMsgRevenueAmts(Connection conn, CntrlPtCertForm cntrlPtCertForm) throws RABCException {
		Statement stmt = null;
		ResultSet rs = null;
		String sqlStmt = "";
		String controlPoints = getControlPoints(conn, cntrlPtCertForm);
		String runDate = cntrlPtCertForm.getRunDate();		
		String  divisions = "";		
		
		/*
		 * Form the divisions
		 */
		if ("All".equals(cntrlPtCertForm.getStateDesc())){
			String region = cntrlPtCertForm.getRegion();
			divisions = "(";	
			if ("EN".equals(cntrlPtCertForm.getRegion())){
				region = cntrlPtCertForm.getSelectedRegion();
			}
			List list = StaticDataLoader.getDivisionsByRegion(region);
			int listSize = list.size();
			for (int i=0;i<listSize;i++){
				PickList pickList = (PickList)list.get(i);	
				if(divisions.equalsIgnoreCase("(")){
					divisions += "'"+pickList.getKey()+"'";
				}else{
					divisions += ",'"+pickList.getKey()+"'";
				}
			}
			divisions += ")";
		} else {				
			divisions  =  getDivisionsByStateDesc(conn, cntrlPtCertForm.getStateDesc());
		}
		
		
		String getAlertRevenue = "SELECT SUM(A.ALERT_REVENUE), SUM(A.ALERT_LOST_REVENUE) " +
								 "FROM RABC_ALERT_MSG A, RABC_CNTRL_PT_ALERT B " +
								 "WHERE A.ALERT_RULE(+) = B.ALERT_RULE {0}";
		String whereClause = ""; 
		
		if (!"()".equals(controlPoints)) {
			whereClause += " AND B.CNTRL_PT_CD IN ";
			whereClause += controlPoints;
		}
		
		if (!"()".equals(divisions)) {
			whereClause += " AND A.ALERT_DATA1 IN ";
			whereClause += divisions;
		}
	
		whereClause += " AND PROC_DATE = to_date('"+runDate+"','mm/dd/yyyy')";
		ArrayList whereClauseList = new ArrayList();
		whereClauseList.add(whereClause);
		try {
			stmt = conn.createStatement();		
			MessageFormat mf = new MessageFormat(getAlertRevenue);
			sqlStmt = mf.format((String[])whereClauseList.toArray(new String[whereClauseList.size()]));
			rs = stmt.executeQuery(sqlStmt);		
			while (rs.next()) {
				cntrlPtCertForm.setAlertMsgRevImpact(rs.getDouble(1));
				cntrlPtCertForm.setAlertMsgLostRevImpact(rs.getDouble(2));
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving alert message revenue amounts using getAlertRevenue query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closeStatement(stmt);
		}  
	}
	
	/**This gets all the control points of a process.
	 * 
	 * @param conn  Connection passed from the Service class
	 * @param cntrlPtCertForm  Form created in the action class and passed down
	 * @return controlPoints  The control points to be used on the main page
	 * @throws RABCException
	 */
	protected static String getControlPoints(Connection conn, CntrlPtCertForm cntrlPtCertForm) throws RABCException {
		Statement stmt = null;
		ResultSet rs = null;
		String sqlStmt = "";
		String getControlPoints = "SELECT CNTRL_PT_CD FROM RABC_PROCESS WHERE PROCESS = {0}";
		String getControlPoints1 = "SELECT DISTINCT CNTRL_PT_CD FROM RABC_PROCESS ";
		ArrayList argsList = new ArrayList(0);
		
		if ("All".equals(cntrlPtCertForm.getProcess())){
			argsList.add("");
		}else {
			argsList.add("'"+cntrlPtCertForm.getProcess()+"'");
		}
		
		String controlPoints = "(";
		try {	
			stmt = conn.createStatement();		
			if ("All".equals(cntrlPtCertForm.getProcess())){
				sqlStmt = getControlPoints1;
			}else {
				MessageFormat mf = new MessageFormat(getControlPoints);
				sqlStmt = mf.format((String[])argsList.toArray(new String[argsList.size()]));			
			}	
			rs = stmt.executeQuery(sqlStmt);		
			while (rs.next()){
				if(controlPoints.equalsIgnoreCase("(")){
					controlPoints += "'"+rs.getString("CNTRL_PT_CD")+"'";
				}else{
					controlPoints += ",'"+rs.getString("CNTRL_PT_CD")+"'";					
				}				
			}				
			controlPoints += ")";
		} catch (SQLException sqle) {
			throw new RABCException("Error in setting up WHERE clause using getControlPoints query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closeStatement(stmt);
		}
		return controlPoints;
	}
	
	/**This retrieves a state's acronym.
	 * 
	 * @param conn  Connection passed from the Service class
	 * @param stateDesc  The state name
	 * @param region  The region being accessed
	 * @return stateAcr  The 2 letter state abbreviation
	 * @throws RABCException
	 */
	protected static String getStateAcronym(Connection conn, String stateDesc) throws RABCException {
		Statement stmt = null;
		ResultSet rs = null;
		String sqlStmt = "";
		String getStateAcronym = "SELECT STATE FROM RABC_DIVISION WHERE STATE_DESC = {0}";
		ArrayList argsList = new ArrayList(0);
		argsList.add("'" + stateDesc + "'");
		String stateAcr = "";
		try {	
			stmt = conn.createStatement();		
			MessageFormat mf = new MessageFormat(getStateAcronym);
			sqlStmt = mf.format((String[])argsList.toArray(new String[argsList.size()]));				
			rs = stmt.executeQuery(sqlStmt);		
			if (rs.next())
				stateAcr = rs.getString(1);
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving state abbreviation using getStateAcronym query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closeStatement(stmt);
		} 
		return stateAcr;
	}
	
	/**This retrieves a state's description.
	 * 
	 * @param conn  Connection passed from the Service class
	 * @param stateAcr  The 2 letter state abbreviation
	 * @param region  The region being accessed
	 * @return stateDesc  The state name
	 * @throws RABCException
	 */
	protected static String getStateDesc(Connection conn, String stateAcr) throws RABCException {
		Statement stmt = null;
		ResultSet rs = null;
		String sqlStmt = "";
		String getStateDesc = "SELECT STATE_DESC FROM RABC_DIVISION WHERE STATE = {0}";
		ArrayList argsList = new ArrayList(0);
		argsList.add("'" + stateAcr + "'");
		String stateDesc = "";
		try {	
			stmt = conn.createStatement();		
			MessageFormat mf = new MessageFormat(getStateDesc);
			sqlStmt = mf.format((String[])argsList.toArray(new String[argsList.size()]));				
			rs = stmt.executeQuery(sqlStmt);		
			if (rs.next())
				stateDesc = rs.getString(1);
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving state description using getStateDesc query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closeStatement(stmt);
		} 
		return stateDesc;
	}
	
	/**This determines if the user has read-only or update access to the Control Process Certification page.
	 * 
	 * @param conn  Connection passed from the Service class
	 * @param cntrlPtCertForm  Form created in the action class and passed down
	 * @throws RABCException
	 */
	protected static void getUserAccess(Connection conn, CntrlPtCertForm cntrlPtCertForm) throws RABCException {
		Statement stmt = null;
		ResultSet rs = null;
		String sqlStmt = "";
		String getUsrAccess = "SELECT A.USER_ID, B.FUNCT_CD " +
							  "FROM RABC_ALERT_GRP_USER A, RABC_ALERT_GRP_FUNCT B " +
							  "WHERE UPPER(USER_ID) = {0} " +
							  "  AND B.FUNCT_CD = ''US'' " +
							  "  AND A.ALERT_GRP = B.ALERT_GRP";
		String userID = "'" + cntrlPtCertForm.getLoginUserID().toUpperCase() + "'";
		ArrayList userIDList = new ArrayList();
		userIDList.add(userID);
		try {	
			stmt = conn.createStatement();		
			MessageFormat mf = new MessageFormat(getUsrAccess);
			sqlStmt = mf.format((String[])userIDList.toArray(new String[userIDList.size()]));				
			rs = stmt.executeQuery(sqlStmt);		
			if (rs.next()) 
				cntrlPtCertForm.setUserAccess("U");
			else
				cntrlPtCertForm.setUserAccess("R");				
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving user's access level using getUsrAccess query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closeStatement(stmt);
		} 
	}
	
	
	/**This gets all the divisions of a stateDesc.
	 * 
	 * @param conn  Connection passed from the Service class
	 * @param stateDesc  stateDesc
	 * @return divisions  The division corrosponding to given stateDesc
	 * @throws RABCException
	 */
	private static String getDivisionsByStateDesc(Connection conn, String stateDesc) throws RABCException {
		Statement stmt = null;
		ResultSet rs = null;		
		String sqlStmt = "SELECT DISTINCT DIVISION FROM RABC_DIVISION WHERE STATE_DESC = " + "'" + stateDesc + "'";
		String divisions = "(";
		try {	
			stmt = conn.createStatement();		
			rs = stmt.executeQuery(sqlStmt);		
			while (rs.next()){
				if(divisions.equalsIgnoreCase("(")){
					divisions += "'"+rs.getString("DIVISION")+"'";
				}else{
					divisions += ",'"+rs.getString("DIVISION")+"'";					
				}				
			}				
			divisions += ")";
			
		} catch (SQLException sqle) {
			throw new RABCException("Error in setting up WHERE clause using getControlPoints query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closeStatement(stmt);
		}
		return divisions;
	}
}
