package com.att.bac.rabc.load.acus.calnet;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import com.att.carat.util.JDBCUtil;

public class RabcFileStatusDAO {
/**
 * RABC File Statuses:
 * 0 - Success
 * 1 - Error
 * 2 - Duplicate
 */
	
	protected static final int SUCCESS = 0;
	protected static final String[] errorMessage = {"The file was successfully inserted into the table.",
												"No file insert done. There was an ERROR in the file received."};
	protected static final int ERROR = 1;

	
	/**
	 * constructor
	 *
	 */
	public RabcFileStatusDAO() {
		super();
	}

	/**
	 * 
	 * @param acusInvDate
	 * @param fileId
	 * @return the status
	 * @throws ACUSFileDBLoadJobException
	 * This method checks if the ACUS_INV_DATE has already been processed for a particular 
	 * file Id (eitherACUS_INFO or ACUS_BILLPAYER) 
	 */
	public int acusInvDatePresent (Connection connection,
			Date acusInvDate,
			String fileId)  throws ACUSFileDBLoadJobException
	{
		PreparedStatement selectStatement=null;
		ResultSet rs=null;
		int noOfFileSeqRecords=0;
		int status = -1;
		StringBuffer sbQuery1 = new StringBuffer();

		sbQuery1.append(" SELECT * FROM RABC_FILE_STATUS");
		sbQuery1.append(" where ACUS_INV_DATE = ? and FILE_ID = ? ");

		try {

			selectStatement = connection.prepareStatement(sbQuery1.toString());

			selectStatement.setDate(1, acusInvDate);
			selectStatement.setString(2, fileId);
			
			

			rs = selectStatement.executeQuery();
            while (rs.next()) {
            	noOfFileSeqRecords++;
            	status = rs.getInt("STATUS");
            }
            
            if (noOfFileSeqRecords>1)
            {
            	throw new ACUSFileDBLoadJobException("There cannot be more than one record for a given ACUS_INV_DATE in the table.");
            }

		} catch (SQLException sqle) {
			//e.printStackTrace();
			throw new ACUSFileDBLoadJobException("SQLException in the acusInvDatePresent method of the RabcFileStatusDAO", sqle);
		} catch (Exception e) {
			throw new ACUSFileDBLoadJobException("Exception in the acusInvDatePresent method - RabcFileStatusDAO", e);
		} finally {
			 JDBCUtil.closeResultSet(rs);
			 JDBCUtil.closeStatement(selectStatement);
		 }
		return status;
	}
	
	/**
	 * 
	 * @param acusInvDate
	 * @param fileId
	 * @return the number of records prior to the current ACUS_INV_DATE
	 * @throws ACUSFileDBLoadJobException
	 * This method checks the number of runs prior to the given ACUS_INV_DATE. 
	 */
	public boolean checkifTableHasAnyPriorRuns(Connection connection,
			Date acusInvDate,
			String fileId	) throws ACUSFileDBLoadJobException
	{
		PreparedStatement selectStatement=null;
		ResultSet rs=null;
		boolean priorRun= false;
		StringBuffer sbQuery1 = new StringBuffer();

//		sbQuery1.append(" SELECT COUNT(ROWID) as noOfRecords FROM ").append(tableNm);
//		sbQuery1.append(" where FILE_ID = ? ");
		
		sbQuery1.append(" SELECT ACUS_INV_DATE FROM RABC_FILE_STATUS ");
		sbQuery1.append(" where FILE_ID = ?  and ACUS_INV_DATE < ?");

		try {

			selectStatement = connection.prepareStatement(sbQuery1.toString());

			selectStatement.setString(1, fileId);
			selectStatement.setDate(2, acusInvDate);
			rs = selectStatement.executeQuery();
            if (rs.next()) {
            	priorRun = true;
            }

		} catch (SQLException sqle) {
		//	e.printStackTrace();
			throw new ACUSFileDBLoadJobException("SQL Exception in the checkifTableHasAnyPriorRuns method - RabcFileStatusDAO", sqle);
		} catch (Exception e) {
			throw new ACUSFileDBLoadJobException("Exception in the checkifTableHasAnyPriorRuns method - RabcFileStatusDAO", e);
		} 
		 finally {
			 JDBCUtil.closeResultSet(rs);
			 JDBCUtil.closeStatement(selectStatement);
		 }
		return priorRun;
	}		

	/**
	 * 
	 * @param procDate
	 * @return the bill round associated to the header date 
	 * @throws ACUSFileDBLoadJobException
	 * This method retrieves the Bill Round that is associated to the passed headerDate from the 
	 * RABC_CYCLE_CALENDAR view to be used to populate the Cycle_Day in the RABC_TRIG table 
	 */
	public int getBillRound(Connection connection,
			String procDate ) throws ACUSFileDBLoadJobException
	{
		PreparedStatement selectStatement=null;
		ResultSet rs=null;
		int billRound = 0;
		StringBuffer sbQuery1 = new StringBuffer();
		
		sbQuery1.append(" SELECT BILL_RND FROM RABC_CYCLE_CALENDAR ");
		sbQuery1.append(" where PROC_DT = TO_DATE(?, 'MM-DD-YYYY') ");

		try {

			selectStatement = connection.prepareStatement(sbQuery1.toString());

			selectStatement.setString(1, procDate);
			rs = selectStatement.executeQuery();
            while (rs.next()) {
            	billRound = rs.getInt(1);
            }

		} catch (SQLException sqle) {
		//	e.printStackTrace();
			throw new ACUSFileDBLoadJobException("SQL Exception in the getBillRound method - RabcFileStatusDAO", sqle);
		} catch (Exception e) {
			throw new ACUSFileDBLoadJobException("Exception in the getBillRound method - RabcFileStatusDAO", e);
		} 
		 finally {
			 JDBCUtil.closeResultSet(rs);
			 JDBCUtil.closeStatement(selectStatement);
		 }
		return billRound;
	}		

/**
 * 
 * @param fileId
 * @param fileSeq
 * @param status
 * @param recCnt
 * @param fileName
 * @param acusInvDate
 * @return success or failure
 * @throws ACUSFileDBLoadJobException
 *  This method inserts a record into the RABC_FILE_STATUS table irrespective of whether it was successful or not.
 *  If it was successful the status column would have a value of 0, if not, it would have a value of 1.
 */
	   public int insertIntoFileStatus( Connection connection,
			   							String fileId,
			   							int fileSeq,
			   							int status,
			   							int recCnt,
			   							String fileName,
			   							Date acusInvDate
			   							) throws ACUSFileDBLoadJobException
	  {
	        PreparedStatement pstatement = null;
	    	StringBuffer sbQuery1 = new StringBuffer();
	    	sbQuery1.append(" INSERT INTO RABC_FILE_STATUS");
			sbQuery1.append(" values(?, ?, ?, ?, ?, ?, ? )");
			
	        int count = 0;
	        try {
	        	pstatement = connection.prepareStatement(sbQuery1.toString());
				//get the current sql Date
        		// new Date(util.Date.getTime());
				DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
				String runDate = dateFormat.format(new java.util.Date());
				java.sql.Date sqlRunDate = new java.sql.Date(dateFormat.parse(runDate).getTime());
				pstatement.setDate(1, sqlRunDate);
	            
	        	pstatement.setString(2, fileId);

	        	pstatement.setInt(3, fileSeq);
	            
	            pstatement.setInt(4, recCnt);
	            
	            pstatement.setInt(5, status);
	            
	            pstatement.setString(6, errorMessage[status] + " " + fileName);
	            
	            pstatement.setDate(7, acusInvDate);
	            count = pstatement.executeUpdate();
	        }
	        catch(ParseException pe) {
	        	throw new ACUSFileDBLoadJobException("Parse Exception in insertIntoFileStatus. RabcFileStatusDAO. ", pe);
	        }
	        catch (SQLException sqle) {
	        	throw new ACUSFileDBLoadJobException("Exception in insertIntoFileStatus. RabcFileStatusDAO.", sqle);
	        } finally {
	        	JDBCUtil.closeStatement(pstatement);
	        }	
	        return count;
       }
	   
	   
		public void deleteErroredAcusInvDate(	Connection connection,
											Date acusInvDate,
											String fileId
															) throws ACUSFileDBLoadJobException

		{
			PreparedStatement deleteStatement;

			StringBuffer sbQuery1 = new StringBuffer();

			sbQuery1.append(" DELETE FROM RABC_FILE_STATUS");
			sbQuery1.append(" where FILE_ID = ? and ACUS_INV_DATE = ? ");

			try {

				deleteStatement = connection.prepareStatement(sbQuery1.toString());

				deleteStatement.setString(1, fileId);
				deleteStatement.setDate(2, acusInvDate);

				deleteStatement.execute();

				deleteStatement.close();

			} catch (SQLException sqle) {
				throw new ACUSFileDBLoadJobException("SQL Exception in deleteErroredAcusInvDate. RabcFileStatusDAO. ", sqle);
			} catch (Exception e) {
				throw new ACUSFileDBLoadJobException("Exception in deleteErroredAcusInvDate. RabcFileStatusDAO. ", e);
			}
		}
		
	
}
