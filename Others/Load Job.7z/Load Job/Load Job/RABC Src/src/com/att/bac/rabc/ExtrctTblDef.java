/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc;

/**
 * This is a Data Object to represent RABC_EXTRCT_TBL_DEF table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class ExtrctTblDef {
	private int partiRefId;
	private int extrctKeyLvl;
	private String key1Name;
	private String key2Name;
	private String key3Name;
	private String key4Name;
	private String key5Name;
	private String extrctItemName;
	private int extrctDataCt;
	private int extrctDataLeftCt;
	private int extrctDataRightCt;
	private String extrctData1Name;
	private String extrctData2Name;
	private String extrctData3Name;
	private String extrctData4Name;
	private String extrctData5Name;
	private String extrctData6Name;
	private String extrctData7Name;
	private String extrctData8Name;
	private String extrctData9Name;
	private String extrctData10Name;
	private String extrctData11Name;
	private String extrctData12Name;
	private String extrctData13Name;
	private String extrctData14Name;
	private String extrctData15Name;

	/**
	 * @return Returns the PartiRefId.
	 */
	public int getPartiRefId() {
		return partiRefId;
	}
	/**
	 * @return Returns the ExtrctKeyLvl.
	 */
	public int getExtrctKeyLvl() {
		return extrctKeyLvl;
	}
	/**
	 * @return Returns the Key1Name.
	 */
	public String getKey1Name() {
		return key1Name;
	}
	/**
	 * @return Returns the Key2Name.
	 */
	public String getKey2Name() {
		return key2Name;
	}
	/**
	 * @return Returns the Key3Name.
	 */
	public String getKey3Name() {
		return key3Name;
	}
	/**
	 * @return Returns the Key4Name.
	 */
	public String getKey4Name() {
		return key4Name;
	}
	/**
	 * @return Returns the Key5Name.
	 */
	public String getKey5Name() {
		return key5Name;
	}
	/**
	 * @return Returns the ExtrctItemName.
	 */
	public String getExtrctItemName() {
		return extrctItemName;
	}
	/**
	 * @return Returns the ExtrctDataCt.
	 */
	public int getExtrctDataCt() {
		return extrctDataCt;
	}
	/**
	 * @return Returns the ExtrctDataLeftCt.
	 */
	public int getExtrctDataLeftCt() {
		return extrctDataLeftCt;
	}
	/**
	 * @return Returns the ExtrctDataRightCt.
	 */
	public int getExtrctDataRightCt() {
		return extrctDataRightCt;
	}
	/**
	 * @return Returns the ExtrctData1Name.
	 */
	public String getExtrctData1Name() {
		return extrctData1Name;
	}
	/**
	 * @return Returns the ExtrctData2Name.
	 */
	public String getExtrctData2Name() {
		return extrctData2Name;
	}
	/**
	 * @return Returns the ExtrctData3Name.
	 */
	public String getExtrctData3Name() {
		return extrctData3Name;
	}
	/**
	 * @return Returns the ExtrctData4Name.
	 */
	public String getExtrctData4Name() {
		return extrctData4Name;
	}
	/**
	 * @return Returns the ExtrctData5Name.
	 */
	public String getExtrctData5Name() {
		return extrctData5Name;
	}
	/**
	 * @return Returns the ExtrctData6Name.
	 */
	public String getExtrctData6Name() {
		return extrctData6Name;
	}
	/**
	 * @return Returns the ExtrctData7Name.
	 */
	public String getExtrctData7Name() {
		return extrctData7Name;
	}
	/**
	 * @return Returns the ExtrctData8Name.
	 */
	public String getExtrctData8Name() {
		return extrctData8Name;
	}
	/**
	 * @return Returns the ExtrctData9Name.
	 */
	public String getExtrctData9Name() {
		return extrctData9Name;
	}
	/**
	 * @return Returns the ExtrctData10Name.
	 */
	public String getExtrctData10Name() {
		return extrctData10Name;
	}
	/**
	 * @return Returns the ExtrctData11Name.
	 */
	public String getExtrctData11Name() {
		return extrctData11Name;
	}
	/**
	 * @return Returns the ExtrctData12Name.
	 */
	public String getExtrctData12Name() {
		return extrctData12Name;
	}
	/**
	 * @return Returns the ExtrctData13Name.
	 */
	public String getExtrctData13Name() {
		return extrctData13Name;
	}
	/**
	 * @return Returns the ExtrctData14Name.
	 */
	public String getExtrctData14Name() {
		return extrctData14Name;
	}
	/**
	 * @return Returns the ExtrctData15Name.
	 */
	public String getExtrctData15Name() {
		return extrctData15Name;
	}

	/**
	 * @param PartiRefId The partiRefId to set.
	 */
	public void setPartiRefId(int partiRefId) {
		this.partiRefId = partiRefId;
	}
	/**
	 * @param ExtrctKeyLvl The extrctKeyLvl to set.
	 */
	public void setExtrctKeyLvl(int extrctKeyLvl) {
		this.extrctKeyLvl = extrctKeyLvl;
	}
	/**
	 * @param Key1Name The key1Name to set.
	 */
	public void setKey1Name(String key1Name) {
		this.key1Name = key1Name;
	}
	/**
	 * @param Key2Name The key2Name to set.
	 */
	public void setKey2Name(String key2Name) {
		this.key2Name = key2Name;
	}
	/**
	 * @param Key3Name The key3Name to set.
	 */
	public void setKey3Name(String key3Name) {
		this.key3Name = key3Name;
	}
	/**
	 * @param Key4Name The key4Name to set.
	 */
	public void setKey4Name(String key4Name) {
		this.key4Name = key4Name;
	}
	/**
	 * @param Key5Name The key5Name to set.
	 */
	public void setKey5Name(String key5Name) {
		this.key5Name = key5Name;
	}
	/**
	 * @param ExtrctItemName The extrctItemName to set.
	 */
	public void setExtrctItemName(String extrctItemName) {
		this.extrctItemName = extrctItemName;
	}
	/**
	 * @param ExtrctDataCt The extrctDataCt to set.
	 */
	public void setExtrctDataCt(int extrctDataCt) {
		this.extrctDataCt = extrctDataCt;
	}
	/**
	 * @param ExtrctDataLeftCt The extrctDataLeftCt to set.
	 */
	public void setExtrctDataLeftCt(int extrctDataLeftCt) {
		this.extrctDataLeftCt = extrctDataLeftCt;
	}
	/**
	 * @param ExtrctDataRightCt The extrctDataRightCt to set.
	 */
	public void setExtrctDataRightCt(int extrctDataRightCt) {
		this.extrctDataRightCt = extrctDataRightCt;
	}
	/**
	 * @param ExtrctData1Name The extrctData1Name to set.
	 */
	public void setExtrctData1Name(String extrctData1Name) {
		this.extrctData1Name = extrctData1Name;
	}
	/**
	 * @param ExtrctData2Name The extrctData2Name to set.
	 */
	public void setExtrctData2Name(String extrctData2Name) {
		this.extrctData2Name = extrctData2Name;
	}
	/**
	 * @param ExtrctData3Name The extrctData3Name to set.
	 */
	public void setExtrctData3Name(String extrctData3Name) {
		this.extrctData3Name = extrctData3Name;
	}
	/**
	 * @param ExtrctData4Name The extrctData4Name to set.
	 */
	public void setExtrctData4Name(String extrctData4Name) {
		this.extrctData4Name = extrctData4Name;
	}
	/**
	 * @param ExtrctData5Name The extrctData5Name to set.
	 */
	public void setExtrctData5Name(String extrctData5Name) {
		this.extrctData5Name = extrctData5Name;
	}
	/**
	 * @param ExtrctData6Name The extrctData6Name to set.
	 */
	public void setExtrctData6Name(String extrctData6Name) {
		this.extrctData6Name = extrctData6Name;
	}
	/**
	 * @param ExtrctData7Name The extrctData7Name to set.
	 */
	public void setExtrctData7Name(String extrctData7Name) {
		this.extrctData7Name = extrctData7Name;
	}
	/**
	 * @param ExtrctData8Name The extrctData8Name to set.
	 */
	public void setExtrctData8Name(String extrctData8Name) {
		this.extrctData8Name = extrctData8Name;
	}
	/**
	 * @param ExtrctData9Name The extrctData9Name to set.
	 */
	public void setExtrctData9Name(String extrctData9Name) {
		this.extrctData9Name = extrctData9Name;
	}
	/**
	 * @param ExtrctData10Name The extrctData10Name to set.
	 */
	public void setExtrctData10Name(String extrctData10Name) {
		this.extrctData10Name = extrctData10Name;
	}
	/**
	 * @param ExtrctData11Name The extrctData11Name to set.
	 */
	public void setExtrctData11Name(String extrctData11Name) {
		this.extrctData11Name = extrctData11Name;
	}
	/**
	 * @param ExtrctData12Name The extrctData12Name to set.
	 */
	public void setExtrctData12Name(String extrctData12Name) {
		this.extrctData12Name = extrctData12Name;
	}
	/**
	 * @param ExtrctData13Name The extrctData13Name to set.
	 */
	public void setExtrctData13Name(String extrctData13Name) {
		this.extrctData13Name = extrctData13Name;
	}
	/**
	 * @param ExtrctData14Name The extrctData14Name to set.
	 */
	public void setExtrctData14Name(String extrctData14Name) {
		this.extrctData14Name = extrctData14Name;
	}
	/**
	 * @param ExtrctData15Name The extrctData15Name to set.
	 */
	public void setExtrctData15Name(String extrctData15Name) {
		this.extrctData15Name = extrctData15Name;
	}
}
