/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.load.occ.mw;

import java.util.Date;

import com.sbc.bac.rabc.load.HashCodeUtil;

/**
 * This is a data object representing entries in RABC_BILLDAY_OCC_BTN_MW.
 * 
 * @author Sonali Uttarwar - SU3643
 */
public class BillDayOccBTN implements Comparable {
	private Date runDate;
	private String division;
	private String billRnd;
	private String btn;
	private String custType;
	private String mktInd;
	private String occPhraseCd;
	private long occCt;
	private double occAmt;
	
	/**
	 * @return Returns the occPhraseCd.
	 */
	public String getOccPhraseCd() {
		return occPhraseCd;
	}
	/**
	 * @param occPhraseCd The occPhraseCd to set.
	 */
	public void setOccPhraseCd(String occPhraseCd) {
		this.occPhraseCd = occPhraseCd;
	}
	/**
	 * @return Returns the btn.
	 */
	public String getBtn() {
		return btn;
	}
	/**
	 * @param btn The btn to set.
	 */
	public void setBtn(String btn) {
		this.btn = btn;
	}
	/**
	 * @return Returns the mktInd.
	 */
	public String getMktInd() {
		return mktInd;
	}
	/**
	 * @param mktInd The mktInd to set.
	 */
	public void setMktInd(String mktInd) {
		this.mktInd = mktInd;
	}
	/**
	 * @return Returns the division.
	 */
	public String getDivision() {
		return division;
	}
	/**
	 * @param division The division to set.
	 */
	public void setDivision(String division) {
		this.division = division;
	}
	/**
	 * @return Returns the billRnd.
	 */
	public String getBillRnd() {
		return billRnd;
	}
	/**
	 * @param billRnd The billRnd to set.
	 */
	public void setBillRnd(String billRnd) {
		this.billRnd = billRnd;
	}
	/**
	 * @return Returns the custType.
	 */
	public String getCustType() {
		return custType;
	}
	/**
	 * @param custType The custType to set.
	 */
	public void setCustType(String custType) {
		this.custType = custType;
	}
	/**
	 * @return Returns the runDate.
	 */
	public Date getRunDate() {
		return runDate;
	}
	/**
	 * @param runDate The runDate to set.
	 */
	public void setRunDate(Date runDate) {
		this.runDate = runDate;
	}
	/**
	 * @return Returns the occAmt.
	 */
	public double getOccAmt() {
		return occAmt;
	}
	/**
	 * @param occAmt The occAmt to set.
	 */
	public void setOccAmt(double occAmt) {
		this.occAmt = occAmt;
	}
	/**
	 * @return Returns the occCt.
	 */
	public long getOccCt() {
		return occCt;
	}
	/**
	 * @param occCt The occCt to set.
	 */
	public void setOccCt(long occCt) {
		this.occCt = occCt;
	}
	
	/**
	 * Equals method overridden for this object so that it can be stored in a hash map where the key 
	 * would be combination of the following 7 attributes:
	 * Run date
	 * Division
	 * Bill round
	 * Business telephone no.
	 * Custome type
	 * Market indicator
	 * OCC phrase code
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object o) {
		// Do a quick check for an identical object reference
	    if (this == o) {
	      return true;
	    }
	    if (!(o instanceof BillDayOccBTN)) {
	    	return false;
	    } else {
			if (((BillDayOccBTN)o).getRunDate().getTime() == this.getRunDate().getTime()
				&& ((BillDayOccBTN)o).getDivision().equalsIgnoreCase(this.getDivision())
				&& ((BillDayOccBTN)o).getBillRnd().equalsIgnoreCase(this.getBillRnd())	
				&& ((BillDayOccBTN)o).getBtn().equalsIgnoreCase(this.getBtn())
				&& ((BillDayOccBTN)o).getCustType().equalsIgnoreCase(this.getCustType())
				&& ((BillDayOccBTN)o).getMktInd().equalsIgnoreCase(this.getMktInd())
				&& ((BillDayOccBTN)o).getOccPhraseCd().equalsIgnoreCase(this.getOccPhraseCd())
				) {
				return true;
			} else {
				return false;
			}
	    }
	}
	
	/**
	 * Hash code method overridden for this object to categorize this object in sets 
	 * so that the hash collections can search this object efficiently.
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		int hashCode = HashCodeUtil.SEED;
		hashCode = HashCodeUtil.hash( hashCode, this.getCustType());
		hashCode = HashCodeUtil.hash( hashCode, this.getMktInd());
		hashCode = HashCodeUtil.hash( hashCode, this.getOccPhraseCd());
	    return hashCode;
	}
	
	/**
	 * compareTo method implementation of Comparable interface to 
	 * make the objects stored in sorted collections sorted.
	 * 
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	public int compareTo(Object o) {
		if ((o instanceof BillDayOccBTN)) {
			if (this.getOccPhraseCd().compareTo(((BillDayOccBTN)o).getOccPhraseCd()) < 0) {
				return -1;
			} else if (this.getOccPhraseCd().compareTo(((BillDayOccBTN)o).getOccPhraseCd()) == 0) {
				if (Math.abs(this.getOccAmt()) < Math.abs(((BillDayOccBTN)o).getOccAmt())) {
					return 1;
				} else if (Math.abs(this.getOccAmt()) == Math.abs(((BillDayOccBTN)o).getOccAmt())) {
					if (this.getBtn().compareTo(((BillDayOccBTN)o).getBtn()) < 0) {
						return -1;
					} else if (this.getBtn().compareTo(((BillDayOccBTN)o).getBtn()) == 0) {
						return 0;
					} else {
						return 1;
					}
				} else {
					return -1;
				}
			} else {
				return 1;
			}
		} else {
			return 0;
		}
	}
}
