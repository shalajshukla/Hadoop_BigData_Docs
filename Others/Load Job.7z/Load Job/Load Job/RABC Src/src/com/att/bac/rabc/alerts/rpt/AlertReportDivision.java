/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.rpt;

/**
 * This class represents the Division which contains division name and selected 
 * to be shown on the Alert Report (Control Alert Detail) page for filter.
 * 
 * @author Nalina Pandiyan - NP5434
 */
public class AlertReportDivision {
	private String divisionName;
	private String divisionDesc;
	private Boolean selected;
	/**
	 * Parameterised constructor which sets the following attribute.
	 * 
	 * @param divisionName
	 */
	public AlertReportDivision(String divisionName) {
		this.divisionName = divisionName;
		this.selected = new Boolean(false);
	}
	
	/**
	 * Parameterised constructor which sets the following attributes.
	 * 
	 * @param divisionName
	 * @param divisionDesc
	 */
	public AlertReportDivision(String divisionName, String divisionDesc) {
		this.divisionName = divisionName;
		this.divisionDesc = divisionDesc;
		this.selected = new Boolean(false);
	}
	
	/**
	 * Parameterised constructor which sets the following attributes.
	 * 
	 * @param divisionName
	 * @param divisionDesc
	 * @param selected
	 */
	public AlertReportDivision(String divisionName, String divisionDesc, boolean selected) {
		this.divisionName = divisionName;
		this.divisionDesc = divisionDesc;
		this.selected = new Boolean(selected);
	}

	/**
	 * @return Returns the divisionName.
	 */
	public String getDivisionName() {
		return divisionName;
	}
	/**
	 * @param divisionName The divisionName to set.
	 */
	public void setDivisionName(String divisionName) {
		this.divisionName = divisionName;
	}
	/**
	 * @return Returns the divisionDesc.
	 */
	public String getDivisionDesc() {
		return divisionDesc;
	}
	/**
	 * @param divisionDesc The divisionDesc to set.
	 */
	public void setDivisionDesc(String divisionDesc) {
		this.divisionDesc = divisionDesc;
	}
	/**
	 * @return Returns the selected.
	 */
	public Boolean getSelected() {
		return selected;
	}
	/**
	 * @param selected The selected to set.
	 */
	public void setSelected(Boolean selected) {
		this.selected = selected;
	}
}
