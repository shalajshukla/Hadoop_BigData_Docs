/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.alerts.status;


import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.ConnectionManager;
import com.att.bac.rabc.ExcelReport;
import com.att.bac.rabc.PickList;
import com.att.bac.rabc.ProgressBar;
import com.att.bac.rabc.RABCConstantsLists;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.StaticDataLoader;
import com.att.bac.rabc.admin.AlertGroup;
import com.att.bac.rabc.admin.alert.rule.AlertRule;
import com.att.bac.rabc.alerts.dashboard.CycleCalendar;
import com.att.bac.rabc.alerts.dashboard.SystemMessagesParameters;
import com.att.carat.util.email.EmailFactory;
import com.att.carat.util.io.FileIO;

/**
 * This is an action class that controls the actions required to populate 
 * the Alert Report Selection Criteria page and Alert Report Detail page.
 * 
 * @author Abhilash - AC6952
 */
public class AlertReportDetailAction extends DispatchAction {
	public static Logger logger = Logger.getLogger(AlertReportDetailAction.class);
	private AlertReportDetailService alertReportDetailService = AlertReportDetailService.getAlertReportDetailService();
	
	/**
	 * Default dispatch action method to handel the request for Alert Report Selection Criteria page.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @see org.apache.struts.actions.DispatchAction#unspecified(org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public ActionForward unspecified(ActionMapping mapping, ActionForm form,HttpServletRequest request, HttpServletResponse response)  {	
		return criteria(mapping, form, request, response);
	}
	
	/**
	 * Dispatch action method to handel the request for Alert Report Selection Criteria page.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward criteria(ActionMapping mapping, ActionForm form,HttpServletRequest request, HttpServletResponse response) {
		AlertReportDetailForm alertReportDetailForm = (AlertReportDetailForm) form;
		Connection connection = null;
		List failureList = new ArrayList();
		HttpSession session = request.getSession(true);
		String region = (String) session.getAttribute("region");
		
		/*
		 * Update calendar attributes
		 */
		alertReportDetailForm.setBillRounds(StaticDataLoader.getBillRounds(region));
		alertReportDetailForm.setProcDates(StaticDataLoader.getProcDates(region));
		alertReportDetailForm.setHolidayIndicators(StaticDataLoader.getHolidayIndicators(region));
		alertReportDetailForm.setLoadedDataDates(StaticDataLoader.getLoadedDataDatesByRegion(region));
		
		try {
			connection = ConnectionManager.getConnection(region);
			
			/*
			 * Code to get the default division. 
			 */
			String userId = (String) session.getAttribute("bacUserID");
			String defaultDivision = alertReportDetailService.getDefaultDivision(connection, failureList, userId);
			alertReportDetailForm.setDivision(defaultDivision);
			
			/*
			 * Call the internal method populateOptions(alertReportDetailForm, connection, failureList, region)
			 * to populate the drop down boxes.
			 */ 
	        populateOptions(alertReportDetailForm, connection, failureList, region);
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		}catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		if (!failureList.isEmpty()) {
        	request.setAttribute("failures",failureList);
			return mapping.findForward("error");
		} else {
			return mapping.findForward("AlertReportSelectPage");
		}
	}
	
	/**
	 * Dispatch action method to handel the request for Alert Report Detail page.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward viewAlerts(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		AlertReportDetailForm alertReportDetailForm = (AlertReportDetailForm) form;
		Connection connection = null;
		List failureList = new ArrayList();
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		String userId = (String) session.getAttribute("bacUserID");
		String region = (String) session.getAttribute("region");
		int counter = 0;
		String dispatch = alertReportDetailForm.getDispatch();
		int defaultLineCount = 0;
		
		/*
		 * Code to set the form parameters when request comes from the dashboard.
		 */
		String requestMethod = request.getMethod();
		if ("GET".equals(requestMethod)) {
			if (!"returnView".equals(dispatch)) {
				setFormParameters(request, alertReportDetailForm);
			}
		}
		
		alertReportDetailForm.setControlPointHidden(RABCConstantsLists.getRABCConstantsLists().getText(alertReportDetailForm.getControlPointHidden(), true));
		alertReportDetailForm.setDivisionHidden(RABCConstantsLists.getRABCConstantsLists().getText(alertReportDetailForm.getDivisionHidden(), true));
		
		/*
		 * Call the private method setDefaultFileDates(alertReportDetailForm) to set the default dates.
		 */
		setDefaultFileDates(alertReportDetailForm);
		
		try {
			connection = ConnectionManager.getConnection(region);
			
			/*
			 * Code to get the default line count. 
			 */
			defaultLineCount = alertReportDetailService.getDefaultLineCount(connection, failureList, userId);
			progressBar.setProgressPercent(progressBar.getPercent() + 10);
			
			/*
			 * Call private method listArguments(alertReportDetailForm, userId) to add the form parameters
			 * in an array list.
			 */
			List args = listArguments(alertReportDetailForm, userId, defaultLineCount, region);
			
			/*
			 * Code for paging.
			 * Call the private method setPaging(alertReportDetailForm, connection, failureList, args) to set the 
			 * paging parameters in the form.
			 */
			setPaging(alertReportDetailForm, connection, failureList, args);
			progressBar.setProgressPercent(progressBar.getPercent() + 10);
			
			/*
			 * Reset the args list with current page and total no. of pages.
			 */
			args.add(27, new Integer(alertReportDetailForm.getPage()));
	    	args.add(28, new Integer(alertReportDetailForm.getPages()));
	    	
	    	/*
			 * Put the criterias selected into session.
			 * This will be used when after updating the status of alert, user returns to the same page.
			 */
			Hashtable options = getCriteria(alertReportDetailForm);
			session.setAttribute("options", options);
	    	
	    	/*
			 * Call the private method getCycle(connection, failureList, args) to get the cycle.
			 */
			String cycle = getCycle(connection, failureList, args);
			alertReportDetailForm.setCycle(cycle);
			progressBar.setProgressPercent(progressBar.getPercent() + 10);
			
			/*
			 * Code to create the list of alert report detail objects.
			 * This calls the service class to get the list of alert report detail objects.
			 */
			List alertReportDetailList = alertReportDetailService.getAlertReportDetailList(connection, failureList, args, progressBar);
			alertReportDetailForm.getAlertReportDetailList().clear();
			if (alertReportDetailList != null) {
				int alertReportDetailListSize = alertReportDetailList.size();
				AlertReportDetail alertReportDetail = null;
				for(counter = 0; counter < alertReportDetailListSize; counter++) {
					alertReportDetail = (AlertReportDetail)alertReportDetailList.get(counter);
					alertReportDetailForm.addAlertReportDetail(alertReportDetail);
					/*
					 * Code to set the form parameter key2Column which indiactes that whether the column key2
					 * of Alert Report Detail page is to be displayed or not.
					 */
					if (alertReportDetailForm.getKey2Column() == 0) {
						if ((alertReportDetail.getAlertData2() != null) && (!alertReportDetail.getAlertData2().equals(""))) {
							alertReportDetailForm.setKey2Column(1);
						}
					}
					/*
					 * Code to set the form parameter seqColumn which indiactes that whether the column Seq#
					 * of Alert Report Detail page is to be displayed or not.
					 */
					if (alertReportDetailForm.getSeqColumn() == 0) {
						if ((alertReportDetail.getFileSeqNum() != null) && (!alertReportDetail.getFileSeqNum().equals(""))) {
							alertReportDetailForm.setSeqColumn(1);
						}
					}
					/*
					 * Code to set the form parameter updateAccessAll which indiactes that whether the checkbox
					 * to selcet all alerts on Alert Report Detail page is enabled or not.
					 */
					if (alertReportDetailForm.getUpdateAccessAll() == 0) {
						if (alertReportDetail.getUpdateAccess() == 1) {
							alertReportDetailForm.setUpdateAccessAll(1);
						}
					}
					/*
					 * Code to set the form parameter statusColor which indiactes the color of the status title.
					 */
					/*if (alertReportDetailForm.getStatusColor() == null) {
						if (alertReportDetail.getAlertStatus() != null 
								&& alertReportDetail.getAlertStatus().equals("Warning")) {
							alertReportDetailForm.setStatusColor("Red");
						} else if (!"Closed".equals(alertReportDetail.getAlertStatus())) {
							if (alertReportDetail.getAlertSeverityLevelInd() != null
									&& alertReportDetail.getAlertSeverityLevelInd().equals("1")) {
								alertReportDetailForm.setStatusColor("Red");
							}
						}
					}*/
					if ("Warning".equals(alertReportDetail.getAlertStatus())) {
						alertReportDetailForm.setStatusColor("Red");
					} else if ("Closed".equalsIgnoreCase(alertReportDetail.getAlertStatus())) {
						if (!"Red".equals(alertReportDetailForm.getStatusColor()) && !"#ff9900".equals(alertReportDetailForm.getStatusColor()) && !"#ffff00".equals(alertReportDetailForm.getStatusColor())) {
							alertReportDetailForm.setStatusColor("#0059B3");
						}
					} else {
						if ("1".equals(alertReportDetail.getAlertSeverityLevelInd())) {
							alertReportDetailForm.setStatusColor("Red");
						} else if ("2".equals(alertReportDetail.getAlertSeverityLevelInd())) {
							if (!"Red".equals(alertReportDetailForm.getStatusColor())) {
								alertReportDetailForm.setStatusColor("#ff9900");
							}
						} else if ("3".equals(alertReportDetail.getAlertSeverityLevelInd())) {
							if (!"Red".equals(alertReportDetailForm.getStatusColor()) && !"#ff9900".equals(alertReportDetailForm.getStatusColor())) {
								alertReportDetailForm.setStatusColor("#ffff00");
							}
						}
					}
				}
			}
			
			/*
			 * Set the lsit of alert report detail objects into session.
			 */
			session.setAttribute("alertReportDetailList", alertReportDetailList);
			
			/*
			 * Remove the lsit of selected alert report detail objects from session.
			 */
			if (!("first".equals(dispatch) || "previous".equals(dispatch) || "next".equals(dispatch) 
					|| "last".equals(dispatch)  || "pagelist".equals(dispatch))) {
				session.removeAttribute("selectedAlertReportDetailList");
			}
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		}finally {
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		progressBar.setProgressPercent(100);
		/*
		 * Code to forward the request to Alert Report Detail page in case of no failure
		 * or to Error page in another case.
		 */
		if (!failureList.isEmpty()) {
			request.setAttribute("failures",failureList);
			return mapping.findForward("error");
		} else {
			return mapping.findForward("AlertReportDetail");
		}
	}
	
	/**
	 * Dispatch action method to handel the request for first page of Alert Report.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward first(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)  {
		AlertReportDetailForm alertReportDetailForm = (AlertReportDetailForm) form;
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		int counter = 0;
		int counter1 = 0;
		int totalAlertsSelected = 0;
		List selectedAlertReportDetailListTemp = null;
		
		/*
		 * Get the lsit of alert report detail objects and selected alerts from session.
		 */
		List alertReportDetailList = (List) session.getAttribute("alertReportDetailList");
		List selectedAlertReportDetailList = (List) session.getAttribute("selectedAlertReportDetailList");
		
		/*
		 * Code to get the list of selected alert report detail objects and then set into the session.
		 */
		String selectedAlerts = alertReportDetailForm.getSelectedAlerts();
		String[] selectedAlertsArray = selectedAlerts.split("~");
		int totalSelectedAlerts = selectedAlertsArray.length;
		if (alertReportDetailList != null) {
			int totalAlerts = alertReportDetailList.size();
			if (selectedAlertReportDetailList == null) {
				selectedAlertReportDetailList = new ArrayList();
				for(counter=0; counter<totalAlerts; counter++) {
					for(counter1=0; counter1<totalSelectedAlerts; counter1++) {
						if ((Integer.toString(((AlertReportDetail)alertReportDetailList.get(counter)).getMsgNo())).equals(selectedAlertsArray[counter1])) {
							selectedAlertReportDetailList.add(alertReportDetailList.get(counter));
						}
					}
				}
				session.setAttribute("selectedAlertReportDetailList", selectedAlertReportDetailList);
			} else {
				totalAlertsSelected = selectedAlertReportDetailList.size();
				selectedAlertReportDetailListTemp = new ArrayList();
				for(counter=0; counter<totalAlerts; counter++) {
					for(counter1=0; counter1<totalAlertsSelected; counter1++) {
						if ((Integer.toString(((AlertReportDetail)alertReportDetailList.get(counter)).getMsgNo())).equals((Integer.toString(((AlertReportDetail)selectedAlertReportDetailList.get(counter1)).getMsgNo())))) {
							selectedAlertReportDetailListTemp.add(selectedAlertReportDetailList.get(counter1));
						}
					}
				}
				selectedAlertReportDetailList.removeAll(selectedAlertReportDetailListTemp);
				for(counter=0; counter<totalAlerts; counter++) {
					for(counter1=0; counter1<totalSelectedAlerts; counter1++) {
						if ((Integer.toString(((AlertReportDetail)alertReportDetailList.get(counter)).getMsgNo())).equals(selectedAlertsArray[counter1])) {
							selectedAlertReportDetailList.add(alertReportDetailList.get(counter));
						}
					}
				}
			}
		}
		return viewAlerts(mapping, form, request, response);
    }
	
	/**
	 * Dispatch action method to handel the request for previous page of Alert Report.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward previous(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		AlertReportDetailForm alertReportDetailForm = (AlertReportDetailForm) form;
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		int counter = 0;
		int counter1 = 0;
		int totalAlertsSelected = 0;
		List selectedAlertReportDetailListTemp = null;
		
		/*
		 * Get the lsit of alert report detail objects and selected alerts from session.
		 */
		List alertReportDetailList = (List) session.getAttribute("alertReportDetailList");
		List selectedAlertReportDetailList = (List) session.getAttribute("selectedAlertReportDetailList");
		
		/*
		 * Code to get the list of selected alert report detail objects and then set into the session.
		 */
		String selectedAlerts = alertReportDetailForm.getSelectedAlerts();
		String[] selectedAlertsArray = selectedAlerts.split("~");
		int totalSelectedAlerts = selectedAlertsArray.length;
		if (alertReportDetailList != null) {
			int totalAlerts = alertReportDetailList.size();
			if (selectedAlertReportDetailList == null) {
				selectedAlertReportDetailList = new ArrayList();
				for(counter=0; counter<totalAlerts; counter++) {
					for(counter1=0; counter1<totalSelectedAlerts; counter1++) {
						if ((Integer.toString(((AlertReportDetail)alertReportDetailList.get(counter)).getMsgNo())).equals(selectedAlertsArray[counter1])) {
							selectedAlertReportDetailList.add(alertReportDetailList.get(counter));
						}
					}
				}
				session.setAttribute("selectedAlertReportDetailList", selectedAlertReportDetailList);
			} else {
				totalAlertsSelected = selectedAlertReportDetailList.size();
				selectedAlertReportDetailListTemp = new ArrayList();
				for(counter=0; counter<totalAlerts; counter++) {
					for(counter1=0; counter1<totalAlertsSelected; counter1++) {
						if ((Integer.toString(((AlertReportDetail)alertReportDetailList.get(counter)).getMsgNo())).equals((Integer.toString(((AlertReportDetail)selectedAlertReportDetailList.get(counter1)).getMsgNo())))) {
							selectedAlertReportDetailListTemp.add(selectedAlertReportDetailList.get(counter1));
						}
					}
				}
				selectedAlertReportDetailList.removeAll(selectedAlertReportDetailListTemp);
				for(counter=0; counter<totalAlerts; counter++) {
					for(counter1=0; counter1<totalSelectedAlerts; counter1++) {
						if ((Integer.toString(((AlertReportDetail)alertReportDetailList.get(counter)).getMsgNo())).equals(selectedAlertsArray[counter1])) {
							selectedAlertReportDetailList.add(alertReportDetailList.get(counter));
						}
					}
				}
			}
		}
		return viewAlerts(mapping, form, request, response);
    }
	
	/**
	 * Dispatch action method to handel the request for next page of Alert Report.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward next(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		AlertReportDetailForm alertReportDetailForm = (AlertReportDetailForm) form;
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		int counter = 0;
		int counter1 = 0;
		int totalAlertsSelected = 0;
		List selectedAlertReportDetailListTemp = null;
		
		/*
		 * Get the lsit of alert report detail objects and selected alerts from session.
		 */
		List alertReportDetailList = (List) session.getAttribute("alertReportDetailList");
		List selectedAlertReportDetailList = (List) session.getAttribute("selectedAlertReportDetailList");
		
		/*
		 * Code to get the list of selected alert report detail objects and then set into the session.
		 */
		String selectedAlerts = alertReportDetailForm.getSelectedAlerts();
		String[] selectedAlertsArray = selectedAlerts.split("~");
		int totalSelectedAlerts = selectedAlertsArray.length;
		if (alertReportDetailList != null) {
			int totalAlerts = alertReportDetailList.size();
			if (selectedAlertReportDetailList == null) {
				selectedAlertReportDetailList = new ArrayList();
				for(counter=0; counter<totalAlerts; counter++) {
					for(counter1=0; counter1<totalSelectedAlerts; counter1++) {
						if ((Integer.toString(((AlertReportDetail)alertReportDetailList.get(counter)).getMsgNo())).equals(selectedAlertsArray[counter1])) {
							selectedAlertReportDetailList.add(alertReportDetailList.get(counter));
						}
					}
				}
				session.setAttribute("selectedAlertReportDetailList", selectedAlertReportDetailList);
			} else {
				totalAlertsSelected = selectedAlertReportDetailList.size();
				selectedAlertReportDetailListTemp = new ArrayList();
				for(counter=0; counter<totalAlerts; counter++) {
					for(counter1=0; counter1<totalAlertsSelected; counter1++) {
						if ((Integer.toString(((AlertReportDetail)alertReportDetailList.get(counter)).getMsgNo())).equals((Integer.toString(((AlertReportDetail)selectedAlertReportDetailList.get(counter1)).getMsgNo())))) {
							selectedAlertReportDetailListTemp.add(selectedAlertReportDetailList.get(counter1));
						}
					}
				}
				selectedAlertReportDetailList.removeAll(selectedAlertReportDetailListTemp);
				for(counter=0; counter<totalAlerts; counter++) {
					for(counter1=0; counter1<totalSelectedAlerts; counter1++) {
						if ((Integer.toString(((AlertReportDetail)alertReportDetailList.get(counter)).getMsgNo())).equals(selectedAlertsArray[counter1])) {
							selectedAlertReportDetailList.add(alertReportDetailList.get(counter));
						}
					}
				}
			}
		}
		return viewAlerts(mapping, form, request, response);
    }
	
	/**
	 * Dispatch action method to handel the request for last page of Alert Report.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward last(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		AlertReportDetailForm alertReportDetailForm = (AlertReportDetailForm) form;
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		int counter = 0;
		int counter1 = 0;
		int totalAlertsSelected = 0;
		List selectedAlertReportDetailListTemp = null;
		
		/*
		 * Get the lsit of alert report detail objects and selected alerts from session.
		 */
		List alertReportDetailList = (List) session.getAttribute("alertReportDetailList");
		List selectedAlertReportDetailList = (List) session.getAttribute("selectedAlertReportDetailList");
		
		/*
		 * Code to get the list of selected alert report detail objects and then set into the session.
		 */
		String selectedAlerts = alertReportDetailForm.getSelectedAlerts();
		String[] selectedAlertsArray = selectedAlerts.split("~");
		int totalSelectedAlerts = selectedAlertsArray.length;
		if (alertReportDetailList != null) {
			int totalAlerts = alertReportDetailList.size();
			if (selectedAlertReportDetailList == null) {
				selectedAlertReportDetailList = new ArrayList();
				for(counter=0; counter<totalAlerts; counter++) {
					for(counter1=0; counter1<totalSelectedAlerts; counter1++) {
						if ((Integer.toString(((AlertReportDetail)alertReportDetailList.get(counter)).getMsgNo())).equals(selectedAlertsArray[counter1])) {
							selectedAlertReportDetailList.add(alertReportDetailList.get(counter));
						}
					}
				}
				session.setAttribute("selectedAlertReportDetailList", selectedAlertReportDetailList);
			} else {
				totalAlertsSelected = selectedAlertReportDetailList.size();
				selectedAlertReportDetailListTemp = new ArrayList();
				for(counter=0; counter<totalAlerts; counter++) {
					for(counter1=0; counter1<totalAlertsSelected; counter1++) {
						if ((Integer.toString(((AlertReportDetail)alertReportDetailList.get(counter)).getMsgNo())).equals((Integer.toString(((AlertReportDetail)selectedAlertReportDetailList.get(counter1)).getMsgNo())))) {
							selectedAlertReportDetailListTemp.add(selectedAlertReportDetailList.get(counter1));
						}
					}
				}
				selectedAlertReportDetailList.removeAll(selectedAlertReportDetailListTemp);
				for(counter=0; counter<totalAlerts; counter++) {
					for(counter1=0; counter1<totalSelectedAlerts; counter1++) {
						if ((Integer.toString(((AlertReportDetail)alertReportDetailList.get(counter)).getMsgNo())).equals(selectedAlertsArray[counter1])) {
							selectedAlertReportDetailList.add(alertReportDetailList.get(counter));
						}
					}
				}
			}
		}
    	return viewAlerts(mapping, form, request, response);
    }
    
	/**
	 * Dispatch action method to handel the request for specific page of Alert Report.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward pagelist(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		AlertReportDetailForm alertReportDetailForm = (AlertReportDetailForm) form;
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		int counter = 0;
		int counter1 = 0;
		int totalAlertsSelected = 0;
		List selectedAlertReportDetailListTemp = null;
		
		/*
		 * Get the lsit of alert report detail objects and selected alerts from session.
		 */
		List alertReportDetailList = (List) session.getAttribute("alertReportDetailList");
		List selectedAlertReportDetailList = (List) session.getAttribute("selectedAlertReportDetailList");
		
		/*
		 * Code to get the list of selected alert report detail objects and then set into the session.
		 */
		String selectedAlerts = alertReportDetailForm.getSelectedAlerts();
		String[] selectedAlertsArray = selectedAlerts.split("~");
		int totalSelectedAlerts = selectedAlertsArray.length;
		if (alertReportDetailList != null) {
			int totalAlerts = alertReportDetailList.size();
			if (selectedAlertReportDetailList == null) {
				selectedAlertReportDetailList = new ArrayList();
				for(counter=0; counter<totalAlerts; counter++) {
					for(counter1=0; counter1<totalSelectedAlerts; counter1++) {
						if ((Integer.toString(((AlertReportDetail)alertReportDetailList.get(counter)).getMsgNo())).equals(selectedAlertsArray[counter1])) {
							selectedAlertReportDetailList.add(alertReportDetailList.get(counter));
						}
					}
				}
				session.setAttribute("selectedAlertReportDetailList", selectedAlertReportDetailList);
			} else {
				totalAlertsSelected = selectedAlertReportDetailList.size();
				selectedAlertReportDetailListTemp = new ArrayList();
				for(counter=0; counter<totalAlerts; counter++) {
					for(counter1=0; counter1<totalAlertsSelected; counter1++) {
						if ((Integer.toString(((AlertReportDetail)alertReportDetailList.get(counter)).getMsgNo())).equals((Integer.toString(((AlertReportDetail)selectedAlertReportDetailList.get(counter1)).getMsgNo())))) {
							selectedAlertReportDetailListTemp.add(selectedAlertReportDetailList.get(counter1));
						}
					}
				}
				selectedAlertReportDetailList.removeAll(selectedAlertReportDetailListTemp);
				for(counter=0; counter<totalAlerts; counter++) {
					for(counter1=0; counter1<totalSelectedAlerts; counter1++) {
						if ((Integer.toString(((AlertReportDetail)alertReportDetailList.get(counter)).getMsgNo())).equals(selectedAlertsArray[counter1])) {
							selectedAlertReportDetailList.add(alertReportDetailList.get(counter));
						}
					}
				}
			}
		}
    	return viewAlerts(mapping, form, request, response);
    }
    
	/**
	 * Dispatch action method to handel the request for sorting the current page of Alert Report 
	 * depending upon sort criteria.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward sort(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
    	return viewAlerts(mapping, form, request, response);
    }
	
	/**
	 * Dispatch action method to handel the request for generating the excel report of Alert Report. 
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward createReport(ActionMapping mapping, ActionForm form,HttpServletRequest request, HttpServletResponse response){
		AlertReportDetailForm alertReportDetailForm = (AlertReportDetailForm) form;
		Connection connection = null;
		List failureList = new ArrayList();
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		String userId = (String) session.getAttribute("bacUserID");
		String region = (String) session.getAttribute("region");
		String reportName = "Alert_Details_" + userId + ".xls";
		
		/*
		 * Call the private method setDefaultFileDates(alertReportDetailForm) to set the default dates.
		 */
		setDefaultFileDates(alertReportDetailForm);
		
		/*
		 * Call private method listArguments(alertReportDetailForm, userId) to add the form parameters
		 * in an array list.
		 */
		List args = listArguments(alertReportDetailForm, userId, 0, region);
		
		/*
		 * Call private method listHiddenArguments(alertReportDetailForm) to add the hidden form parameters
		 * in an array list.
		 */
		List hiddenArgs = listHiddenArguments(alertReportDetailForm);
		
		try {
			connection = ConnectionManager.getConnection(region);
			
			/*
			 * Set response content type and headers.
			 */
	        response.setContentType("application/msexcel");
	        response.setHeader("Content-Disposition","attachment; filename="+reportName);
	        
	        /*
	         * Create an instance of ExcelReport.
	         */
	        ExcelReport report = new ExcelReport(response.getOutputStream());
	        progressBar.setProgressPercent(progressBar.getPercent() + 10);
	        
	        /*
	         * Call the service class to create the excel report of Alert Report.
	         */
			alertReportDetailService.getExcelReport(connection, failureList, args, hiddenArgs, report, progressBar);
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		}catch(IOException ioe) {
			logger.error(RABCMessages.getMessage("ERR_IO_EXEC", new String[] {"IO Exception while creating Page 4 report. "}) + " Exception details: " + ioe.getMessage(), ioe);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_IO_EXEC", new String[] {"IO Exception while creating Page 4 report."}), ioe));
		}catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		progressBar.setProgressPercent(100);
		/*
		 * Code to forward the request to null in case of no failure
		 * or to Error page in another case.
		 */
		if (!failureList.isEmpty()) {
			request.setAttribute("failures",failureList);
			return mapping.findForward("error");
		} else {
			return null;
		}
	}
	
	/**
	 * Dispatch action method to handel the request for sending the email with attached 
	 * excel report of Alert Report to the list of selected users. 
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward emailReport(ActionMapping mapping, ActionForm form,HttpServletRequest request, HttpServletResponse response){
		AlertReportDetailForm alertReportDetailForm = (AlertReportDetailForm) form;
		List failureList = new ArrayList();
		Connection connection = null;
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		String userId = (String) session.getAttribute("bacUserID");
		String region = (String) session.getAttribute("region");
		String reportName = "Alert_Details";
		String reportPath = "Alert_Details_" + userId + ".xls";
		
        /*
		 * Call the private method setDefaultFileDates(alertReportDetailForm) to set the default dates.
		 */
		setDefaultFileDates(alertReportDetailForm);
		
		/*
		 * Call private method listArguments(alertReportDetailForm) to add the form parameters
		 * in an array list.
		 */
		List args = listArguments(alertReportDetailForm, userId, 0, region);
		
		/*
		 * Call private method listHiddenArguments(alertReportDetailForm) to add the hidden form parameters
		 * in an array list.
		 */
		List hiddenArgs = listHiddenArguments(alertReportDetailForm);
		
        try {
        	connection = ConnectionManager.getConnection(region);

        	/*
			 * Code to get the list of email recipients and send mail to them with attached report.  
			 */
			String emailRecipients = alertReportDetailForm.getEmailRecipients();
			String [] emailRecipientsArray = emailRecipients.split(",");
			int totalEmailRecipients = emailRecipientsArray.length;
			int counter = 0;
  // pb3879 added to create correct subject line.  Added to second arguement for email.
		    Context initContext = new InitialContext();
            String spServer = initContext.lookup("java:/comp/env/saved_report_server").toString();
            String fromEnvironment = initContext.lookup("java:/comp/env/application_env").toString();
            String rootFolder = initContext.lookup("java:/comp/env/saved_report_folder").toString();
            String spUser = initContext.lookup("java:/comp/env/saved_report_user").toString();
            String spPasswd = initContext.lookup("java:/comp/env/saved_report_passwd").toString();
            String smbUrl = "smb://" + spUser + ":" + spPasswd + "@" + spServer + "/" + rootFolder ;// + reportPath;
            /*
	         * Create an instance of FileIO.
	         */
            FileIO fio = new FileIO(smbUrl,reportPath);
            /*
	         * Create an instance of ExcelReport.
	         */
	        ExcelReport report = new ExcelReport(fio.createOutputStream());
	        progressBar.setProgressPercent(progressBar.getPercent() + 10);
	        
	        /*
	         * Call the service class to create the excel report of Alert Report.
	         */
			alertReportDetailService.getExcelReport(connection, failureList, args, hiddenArgs, report, progressBar);
			
			for(counter = 0; counter < totalEmailRecipients; counter++  ) {
				EmailFactory.sendEmail(emailRecipientsArray[counter]+"@att.com", "RABC (" + fromEnvironment + " - " + spServer + ") " + reportName, "Please find the enclosed RABC Report - " + reportPath, false, fio);
			}
			//for(counter = 0; counter < totalEmailRecipients; counter++  ) {
			//	Email.sendEmail(emailRecipientsArray[counter]+"@att.com", reportName, "Please find the enclosed RABC Report - " + reportPath, false, file);
		//	}			
			
        } catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch(IOException ioe) {
			logger.error(RABCMessages.getMessage("ERR_IO_EXEC", new String[] {"IO Exception while e mailing Page 4 report. "}) + " Exception details: " + ioe.getMessage(), ioe);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_IO_EXEC", new String[] {"IO Exception while e mailing Page 4 report."}), ioe));
		} catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		progressBar.setProgressPercent(100);
		/*
		 * Code to forward the request to null in case of no failure
		 * or to Error page in another case.
		 */
		if (!failureList.isEmpty()) {
			request.setAttribute("failures",failureList);
			return mapping.findForward("error");
		} else {
			return viewAlerts(mapping, form, request, response);
		}
	}
	
	/**
	 * Dispatch action method to handel the request for Alert Report Detail Confirm page. 
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward select(ActionMapping mapping, ActionForm form,HttpServletRequest request, HttpServletResponse response) {
		AlertReportDetailForm alertReportDetailForm = (AlertReportDetailForm) form;
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		int counter = 0;
		int counter1 = 0;
		int totalAlertsSelected = 0;
		List selectedAlertReportDetailListTemp = null;
		
		/*
		 * Get the lsit of alert report detail objects and selected alerts from session.
		 */
		List alertReportDetailList = (List) session.getAttribute("alertReportDetailList");
		List selectedAlertReportDetailList = (List) session.getAttribute("selectedAlertReportDetailList");
		
		/*
		 * Code to get the list of selected alert report detail objects and then set into the session.
		 */
		String selectedAlerts = alertReportDetailForm.getSelectedAlerts();
		String[] selectedAlertsArray = selectedAlerts.split("~");
		int totalSelectedAlerts = selectedAlertsArray.length;
		if (alertReportDetailList != null) {
			int totalAlerts = alertReportDetailList.size();
			if (selectedAlertReportDetailList == null) {
				selectedAlertReportDetailList = new ArrayList();
				for(counter=0; counter<totalAlerts; counter++) {
					for(counter1=0; counter1<totalSelectedAlerts; counter1++) {
						if ((Integer.toString(((AlertReportDetail)alertReportDetailList.get(counter)).getMsgNo())).equals(selectedAlertsArray[counter1])) {
							selectedAlertReportDetailList.add(alertReportDetailList.get(counter));
						}
					}
				}
				session.setAttribute("selectedAlertReportDetailList", selectedAlertReportDetailList);
			} else {
				totalAlertsSelected = selectedAlertReportDetailList.size();
				selectedAlertReportDetailListTemp = new ArrayList();
				for(counter=0; counter<totalAlerts; counter++) {
					for(counter1=0; counter1<totalAlertsSelected; counter1++) {
						if ((Integer.toString(((AlertReportDetail)alertReportDetailList.get(counter)).getMsgNo())).equals((Integer.toString(((AlertReportDetail)selectedAlertReportDetailList.get(counter1)).getMsgNo())))) {
							selectedAlertReportDetailListTemp.add(selectedAlertReportDetailList.get(counter1));
						}
					}
				}
				selectedAlertReportDetailList.removeAll(selectedAlertReportDetailListTemp);
				for(counter=0; counter<totalAlerts; counter++) {
					for(counter1=0; counter1<totalSelectedAlerts; counter1++) {
						if ((Integer.toString(((AlertReportDetail)alertReportDetailList.get(counter)).getMsgNo())).equals(selectedAlertsArray[counter1])) {
							selectedAlertReportDetailList.add(alertReportDetailList.get(counter));
						}
					}
				}
			}
		}
		
		if (selectedAlertReportDetailList != null) {
			totalAlertsSelected = selectedAlertReportDetailList.size();
			for(counter=0; counter<totalAlertsSelected; counter++) {
				alertReportDetailForm.addAlertReportDetail((AlertReportDetail)selectedAlertReportDetailList.get(counter));
			}
			alertReportDetailForm.setTotalAlerts(totalAlertsSelected);
		}
		progressBar.setProgressPercent(100);
		return mapping.findForward("AlertReportDetailConfirm");
	}
	
	/**
	 * Dispatch action method to handel the request for Alert Status Update. 
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward alertStautus(ActionMapping mapping, ActionForm form,HttpServletRequest request, HttpServletResponse response) {
		AlertReportDetailForm alertReportDetailForm = (AlertReportDetailForm) form;
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		
		/*
		 * Code to get the selected list of alert report detail objects and then set as a request attribute. 
		 */
		if ("GET".equals(request.getMethod())) {	
			List alertReportDetailList = (List) session.getAttribute("alertReportDetailList");
			if (alertReportDetailList != null) {
				List selectedAlertReportDetailList = new ArrayList();
				int index = Integer.valueOf(request.getParameter("index")).intValue();
				selectedAlertReportDetailList.add(alertReportDetailList.get(index));
				request.setAttribute("selectedAlertReportDetailList", selectedAlertReportDetailList);
			}
		} else {
			List selectedAlertReportDetailList = (List) session.getAttribute("selectedAlertReportDetailList");
			if (selectedAlertReportDetailList != null) {
				request.setAttribute("selectedAlertReportDetailList", selectedAlertReportDetailList);
				/*
				 * Remove the selcted list of alert report detail objects from session.
				 */
				session.removeAttribute("selectedAlertReportDetailList");
			}
		}
		
		/*
		 * Forward the request to Alert Status Update page.
		 */
		return mapping.findForward("AlertStatus");
	}
	
	/**
	 * Dispatch action method to handel the request to return to Alert Report Detail page 
	 * after upadating the status of alert. 
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward returnView(ActionMapping mapping, ActionForm form,HttpServletRequest request, HttpServletResponse response){
		AlertReportDetailForm alertReportDetailForm = (AlertReportDetailForm) form;
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		
		/*
		 * Get the criterias selected form session.
		 */
		Hashtable options = (Hashtable) session.getAttribute("options");
		alertReportDetailForm.setWebPageId((String) options.get("webPageId"));
		alertReportDetailForm.setDateType((String) options.get("dateTpye"));
		alertReportDetailForm.setReportData(((Integer) options.get("reportData")).intValue());
		alertReportDetailForm.setFileStartDate((String) options.get("fileStartDate"));
		alertReportDetailForm.setFileEndDate((String) options.get("fileEndDate"));
		alertReportDetailForm.setProcessPoint((String) options.get("processPoint"));
		alertReportDetailForm.setControlPoint((String) options.get("controlPoint"));
		alertReportDetailForm.setAlertRule((String) options.get("alertRule"));
		alertReportDetailForm.setDivision((String) options.get("division"));
		alertReportDetailForm.setAlertRuleTiming((String) options.get("alertRuleTiming"));
		alertReportDetailForm.setAlertRuleTimingIndicator((String) options.get("alertRuleTimingIndicator"));
		alertReportDetailForm.setAlertStatus((String) options.get("alertStatus"));
		alertReportDetailForm.setAlertSeverity((String) options.get("alertSeverity"));
		alertReportDetailForm.setGroupAlerted((String) options.get("groupAlerted"));
		alertReportDetailForm.setRevenueImpactValue((String) options.get("revenueImpactValue"));
		alertReportDetailForm.setRevenueImpactIndicator(((Integer) options.get("revenueImpactIndicator")).intValue());
		alertReportDetailForm.setRootCauseCategory((String) options.get("rootCauseCategory"));
		alertReportDetailForm.setLastUpdateStartDate((String) options.get("lastUpdateStartDate"));
		alertReportDetailForm.setLastUpdateEndDate((String) options.get("lastUpdateStartDate"));
		alertReportDetailForm.setSortItem((String) options.get("sortItem"));
		alertReportDetailForm.setSortOrder((String) options.get("sortOrder"));
		alertReportDetailForm.setPage(((Integer) options.get("page")).intValue());
		alertReportDetailForm.setFromPage((String) options.get("fromPage"));
		alertReportDetailForm.setTimeStampInd((String) options.get("timeStampInd"));
		alertReportDetailForm.setControlPointHidden((String) options.get("controlPointHidden"));
		alertReportDetailForm.setDivisionHidden((String) options.get("divisionHidden"));
		alertReportDetailForm.setAlertRuleTimingIndicatorHidden((String) options.get("alertRuleTimingIndicatorHidden"));
		alertReportDetailForm.setRootCauseCategoryHidden((String) options.get("rootCauseCategoryHidden"));
		alertReportDetailForm.setRevenueImpactValueHidden(((Double) options.get("revenueImpactValueHidden")).doubleValue());
		
		return viewAlerts(mapping, alertReportDetailForm, request, response);
	}
	
	/**
	 * Dispatch action method to handel the request for System Messages page. 
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward systemMessages(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		AlertReportDetailForm alertReportDetailForm = (AlertReportDetailForm) form;
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		SystemMessagesParameters systemMessagesParameters = new SystemMessagesParameters();
		
		/*
		 * Set relevant attributes from form to systemMessagesParameters object.
		 * Then set that object as a request atribute.
		 */ 
		systemMessagesParameters.setWebPageId(alertReportDetailForm.getWebPageId());
		systemMessagesParameters.setDateType(alertReportDetailForm.getDateType());
		systemMessagesParameters.setStartDate(alertReportDetailForm.getFileStartDate());
		systemMessagesParameters.setEndDate(alertReportDetailForm.getFileEndDate());
		systemMessagesParameters.setUpStartDate(alertReportDetailForm.getLastUpdateStartDate());
		systemMessagesParameters.setUpEndDate(alertReportDetailForm.getLastUpdateEndDate());
		systemMessagesParameters.setControlPoint(alertReportDetailForm.getControlPoint());
		systemMessagesParameters.setAlertRule(alertReportDetailForm.getAlertRule());
		systemMessagesParameters.setDivision(alertReportDetailForm.getDivision());
		systemMessagesParameters.setAlertRuleTiming(alertReportDetailForm.getAlertRuleTiming());
		systemMessagesParameters.setAlertRuleTimingIndicator(alertReportDetailForm.getAlertRuleTimingIndicator());

		systemMessagesParameters.setRevenueImpactValue(alertReportDetailForm.getRevenueImpactValue());
		if ((alertReportDetailForm.getRevenueImpactValue() != null)
				&& (!alertReportDetailForm.getRevenueImpactValue().trim().equals(""))) {
			systemMessagesParameters.setRevenueImpactValueHidden((new Double(alertReportDetailForm.getRevenueImpactValue())).doubleValue());
		}
		if (alertReportDetailForm.getRevenueImpactIndicator() == 1) {
			systemMessagesParameters.setRevenueImpactIndicator("Greater than");
		} else if (alertReportDetailForm.getRevenueImpactIndicator() == 2) {
			systemMessagesParameters.setRevenueImpactIndicator("Equal to");
		} else if (alertReportDetailForm.getRevenueImpactIndicator() == 3) {
			systemMessagesParameters.setRevenueImpactIndicator("Less than");
		}
		systemMessagesParameters.setAlertStatus(alertReportDetailForm.getAlertStatus());
		systemMessagesParameters.setRootCatgyCd(alertReportDetailForm.getRootCauseCategory());
		systemMessagesParameters.setSystemErrorType(alertReportDetailForm.getSystemErrorTypeHidden());
		systemMessagesParameters.setDivisionHidden(alertReportDetailForm.getDivisionHidden());
		systemMessagesParameters.setControlPointHidden(alertReportDetailForm.getControlPointHidden());
		
		request.setAttribute("systemMessagesParameters",systemMessagesParameters);
		
		/*
		 * Return to the System Messages action.
		 */
		return mapping.findForward("SystemMessages");
	}
	
	/**
	 * Private method to pouplate the list objects of the form. These list objects are used to populate
	 * the drop down boxes on the Alert Report Selection Criteria page.
	 * 
	 * @param alertReportDetailForm
	 * @param connection
	 * @param failureList
	 * @param region
	 */
	private void populateOptions(AlertReportDetailForm alertReportDetailForm, Connection connection, 
			List failureList, String region) {
    	List tempList;
    	int temListSize = 0;
    	int counter = 0;
    	
    	/*
		 * Call methods from service class to populate the drop-down boxes on alertReportDetailForm.
		 */
    	if ( alertReportDetailForm.getProcessPointList() == null || alertReportDetailForm.getProcessPointList().size() == 0) {
    		tempList = alertReportDetailService.getProcessPointList(region);
    		if (tempList != null) {
    			temListSize = tempList.size();
	    		for(counter = 0; counter < temListSize; counter++) {
					alertReportDetailForm.addProcessPoint((PickList)tempList.get(counter));
				}
    		}
    	}
    	if ( alertReportDetailForm.getControlPointList() == null || alertReportDetailForm.getControlPointList().size() == 0) {
    		tempList = alertReportDetailService.getControlPointList(region);
    		if (tempList != null) {
    			temListSize = tempList.size();
	    		for(counter = 0; counter < temListSize; counter++) {
					alertReportDetailForm.addControlPoint((PickList)tempList.get(counter));
				}
    		}
    	}
    	if ( alertReportDetailForm.getAlertRuleList() == null || alertReportDetailForm.getAlertRuleList().size() == 0) {
    		tempList = alertReportDetailService.getAlertRuleList(connection, failureList);
    		if (tempList != null) {
    			temListSize = tempList.size();
	    		for(counter = 0; counter < temListSize; counter++) {
					alertReportDetailForm.addAlertRule((AlertRule)tempList.get(counter));
				}
    		}
    	}
    	if ( alertReportDetailForm.getDivisionList() == null || alertReportDetailForm.getDivisionList().size() == 0) {
    		tempList = alertReportDetailService.getDivisions(region);
    		if (tempList != null) {
    			temListSize = tempList.size();
	    		for(counter = 0; counter < temListSize; counter++) {
					alertReportDetailForm.addDivision((PickList)tempList.get(counter));
				}
    		}
    	}
    	if ( alertReportDetailForm.getAlertRuleTimingList() == null || alertReportDetailForm.getAlertRuleTimingList().size() == 0) {
    		tempList = alertReportDetailService.getAlertRuleTimingList(region);
    		if (tempList != null) {
    			temListSize = tempList.size();
	    		for(counter = 0; counter < temListSize; counter++) {
					alertReportDetailForm.addAlertRuleTiming((PickList)tempList.get(counter));
				}
    		}
    	}
    	if ( alertReportDetailForm.getAlertStatusList() == null || alertReportDetailForm.getAlertStatusList().size() == 0) {
    		tempList = alertReportDetailService.getAlertStatusList();
    		if (tempList != null) {
    			temListSize = tempList.size();
	    		for(counter = 0; counter < temListSize; counter++) {
					alertReportDetailForm.addAlertStatus((PickList)tempList.get(counter));
				}
    		}
    	}
    	if ( alertReportDetailForm.getAlertSeverityList() == null || alertReportDetailForm.getAlertSeverityList().size() == 0) {
    		tempList = alertReportDetailService.getAlertSeverityList();
    		if (tempList != null) {
    			temListSize = tempList.size();
	    		for(counter = 0; counter < temListSize; counter++) {
					alertReportDetailForm.addAlertSeverity((PickList)tempList.get(counter));
				}
    		}
    	}
    	if ( alertReportDetailForm.getGroupAlertedList() == null || alertReportDetailForm.getGroupAlertedList().size() == 0) {
    		tempList = alertReportDetailService.getGroupAlertedList(connection, failureList);
    		if (tempList != null) {
    			temListSize = tempList.size();
	    		for(counter = 0; counter < temListSize; counter++) {
					alertReportDetailForm.addGroupAlerted((AlertGroup)tempList.get(counter));
				}
    		}
    	}
    	if ( alertReportDetailForm.getSystemErrorTypeList() == null || alertReportDetailForm.getSystemErrorTypeList().size() == 0) {
    		tempList = alertReportDetailService.getSystemErrorTypeList(connection, failureList);
    		if (tempList != null) {
    			temListSize = tempList.size();
	    		for(counter = 0; counter < temListSize; counter++) {
					alertReportDetailForm.addSystemErrorType((SysErr)tempList.get(counter));
				}
    		}
    	}
    	if ( alertReportDetailForm.getRootCauseCategoryList() == null || alertReportDetailForm.getRootCauseCategoryList().size() == 0) {
    		tempList = alertReportDetailService.getRootCauseCategoryList(connection, failureList);
    		if (tempList != null) {
    			temListSize = tempList.size();
	    		for(counter = 0; counter < temListSize; counter++) {
					alertReportDetailForm.addRootCauseCategory((RootCategory)tempList.get(counter));
	    		}
    		}
    	}
    	
    	List billRoundList = StaticDataLoader.getBillRndByRegion(region);
    	StringBuffer sb = new StringBuffer("");
    	if (!billRoundList.isEmpty()){
    		int billRoundListSize = billRoundList.size();
    		for (int i=0;i<billRoundListSize;i++){
    			if ("".equals(sb)){
    				sb.append((String)billRoundList.get(i));
    			}else {
    				sb.append(":");
    				sb.append((String)billRoundList.get(i));
    			}
    		}
    	}
    	alertReportDetailForm.setBillRoundList(sb.toString());
    }
    
	/**
	 * Private method to set the form parameters when request comes throgh the GET method.
	 * 
	 * @param request
	 * @param alertReportDetailForm
	 */
	private void setFormParameters(HttpServletRequest request, AlertReportDetailForm alertReportDetailForm) {
    	alertReportDetailForm.setFromPage(request.getParameter("webId"));
		alertReportDetailForm.setDateType(request.getParameter("dateType"));
		if ((request.getParameter("startDate") != null) && (!"".equals(request.getParameter("startDate")))) {
			alertReportDetailForm.setFileStartDate(request.getParameter("startDate"));
			if ((request.getParameter("endDate") != null) && (!"".equals(request.getParameter("endDate")))) {
				alertReportDetailForm.setFileEndDate(request.getParameter("endDate"));
			} else {
				alertReportDetailForm.setFileEndDate(request.getParameter("startDate"));
			}
		} else if ((request.getParameter("endDate") != null) && (!"".equals(request.getParameter("endDate")))) {
			alertReportDetailForm.setFileEndDate(request.getParameter("endDate"));
			if ((request.getParameter("startDate") != null) && (!"".equals(request.getParameter("startDate")))) {
				alertReportDetailForm.setFileStartDate(request.getParameter("startDate"));
			} else {
				alertReportDetailForm.setFileStartDate(request.getParameter("endDate"));
			}
		}
		if ((request.getParameter("processPoint") != null) && (!"".equals(request.getParameter("processPoint")))) {
			alertReportDetailForm.setProcessPoint(request.getParameter("processPoint"));
		}
		if ((request.getParameter("cntrlPtCd") != null) && (!"".equals(request.getParameter("cntrlPtCd")))) {
			alertReportDetailForm.setControlPoint(request.getParameter("cntrlPtCd"));
		}
		if ((request.getParameter("cntrlPtDesc") != null) && (!"".equals(request.getParameter("cntrlPtDesc")))) {
			alertReportDetailForm.setControlPointHidden(request.getParameter("cntrlPtDesc"));
		}
		if ((request.getParameter("alertRule") != null) && (!"".equals(request.getParameter("alertRule")))) {
			alertReportDetailForm.setAlertRule(request.getParameter("alertRule"));
		}
		if ((request.getParameter("divisionName") != null) && (!"".equals(request.getParameter("divisionName")))) {
			alertReportDetailForm.setDivision(request.getParameter("divisionName"));
		}
		if ((request.getParameter("divisionDesc") != null) && (!"".equals(request.getParameter("divisionDesc")))) {
			alertReportDetailForm.setDivisionHidden(request.getParameter("divisionDesc"));
		}
		if ((request.getParameter("status") != null) && (!"".equals(request.getParameter("status")))) {
			alertReportDetailForm.setAlertStatus(request.getParameter("status"));
		}
		if ((request.getParameter("severeLvl") != null) && (!"".equals(request.getParameter("severeLvl")))) {
			alertReportDetailForm.setAlertSeverity(request.getParameter("severeLvl"));
		}
		if ((request.getParameter("timestampInd") != null) && (!"".equals(request.getParameter("timestampInd")))) {
			alertReportDetailForm.setTimeStampInd(request.getParameter("timestampInd"));
		}
    }	
	
	/**
	 * Private method to return a hashtable that contains the criterias selected to generate the Alert Report.
	 * 
	 * @param alertReportDetailForm
	 * @return Hashtable
	 */
	private Hashtable getCriteria(AlertReportDetailForm alertReportDetailForm) {
		Hashtable options = new Hashtable();
		if (alertReportDetailForm.getWebPageId() != null) {
			options.put("webPageId", alertReportDetailForm.getWebPageId());
		}
		if (alertReportDetailForm.getDateType() != null) {
			options.put("dateTpye", alertReportDetailForm.getDateType());
		}
		options.put("reportData", new Integer(alertReportDetailForm.getReportData()));
		if (alertReportDetailForm.getFileStartDate() != null) {
			options.put("fileStartDate", alertReportDetailForm.getFileStartDate());
		}
		if (alertReportDetailForm.getFileEndDate() != null) {
			options.put("fileEndDate", alertReportDetailForm.getFileEndDate());
		}
		if (alertReportDetailForm.getProcessPoint() != null) {
			options.put("processPoint", alertReportDetailForm.getProcessPoint());
		}
		if (alertReportDetailForm.getControlPoint() != null) {
			options.put("controlPoint", alertReportDetailForm.getControlPoint());
		}
		if (alertReportDetailForm.getAlertRule() != null) {
			options.put("alertRule", alertReportDetailForm.getAlertRule());
		}
		if (alertReportDetailForm.getDivision() != null) {
			options.put("division", alertReportDetailForm.getDivision());
		}
		if (alertReportDetailForm.getAlertRuleTiming() != null) {
			options.put("alertRuleTiming", alertReportDetailForm.getAlertRuleTiming());
		}
		if (alertReportDetailForm.getAlertRuleTimingIndicator() != null) {
			options.put("alertRuleTimingIndicator", alertReportDetailForm.getAlertRuleTimingIndicator());
		}
		if (alertReportDetailForm.getAlertStatus() != null) {
			options.put("alertStatus", alertReportDetailForm.getAlertStatus());
		}
		if (alertReportDetailForm.getAlertSeverity() != null) {
			options.put("alertSeverity", alertReportDetailForm.getAlertSeverity());
		}
		if (alertReportDetailForm.getGroupAlerted() != null) {
			options.put("groupAlerted", alertReportDetailForm.getGroupAlerted());
		}		
		if (alertReportDetailForm.getRevenueImpactValue() != null) {
			options.put("revenueImpactValue", alertReportDetailForm.getRevenueImpactValue());
		}
		options.put("revenueImpactIndicator", new Integer(alertReportDetailForm.getRevenueImpactIndicator()));
		if (alertReportDetailForm.getRootCauseCategory() != null) {
			options.put("rootCauseCategory", alertReportDetailForm.getRootCauseCategory());
		}
		if (alertReportDetailForm.getLastUpdateStartDate() != null) {
			options.put("lastUpdateStartDate", alertReportDetailForm.getLastUpdateStartDate());
		}
		if (alertReportDetailForm.getLastUpdateEndDate() != null) {
			options.put("lastUpdateEndDate", alertReportDetailForm.getLastUpdateEndDate());
		}
		if (alertReportDetailForm.getSortItem() != null) {
			options.put("sortItem", alertReportDetailForm.getSortItem());
		}
		if (alertReportDetailForm.getSortOrder() != null) {
			options.put("sortOrder", alertReportDetailForm.getSortOrder());
		}
		options.put("page", new Integer(alertReportDetailForm.getPage()));
		if (alertReportDetailForm.getFromPage() != null) {
			options.put("fromPage", alertReportDetailForm.getFromPage());
		}
		if (alertReportDetailForm.getTimeStampInd() != null) {
			options.put("timeStampInd", alertReportDetailForm.getTimeStampInd());
		}
		if (alertReportDetailForm.getControlPointHidden() != null) {
			options.put("controlPointHidden", alertReportDetailForm.getControlPointHidden());
		}
		if (alertReportDetailForm.getDivisionHidden() != null) {
			options.put("divisionHidden", alertReportDetailForm.getDivisionHidden());
		}
		if (alertReportDetailForm.getAlertRuleTimingIndicatorHidden() != null) {
			options.put("alertRuleTimingIndicatorHidden", alertReportDetailForm.getAlertRuleTimingIndicatorHidden());
		}
		if (alertReportDetailForm.getRootCauseCategoryHidden() != null) {
			options.put("rootCauseCategoryHidden", alertReportDetailForm.getRootCauseCategoryHidden());
		}
		options.put("revenueImpactValueHidden", new Double(alertReportDetailForm.getRevenueImpactValueHidden()));

		return options;
	}    
	
	/**
	 * Private method to set the default file dates if start file date and end file dates are blank.
	 * Default end date = today date.
	 * Default start date = 90 days prior to today date.
	 * 
	 * @param alertReportDetailForm
	 */
	private void setDefaultFileDates(AlertReportDetailForm alertReportDetailForm) {
    	SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
    	Date tempDate = null;
    	Calendar calendar = Calendar.getInstance();
		String fileStartDate = alertReportDetailForm.getFileStartDate();
		String fileEndDate = alertReportDetailForm.getFileEndDate();
		if ( ((fileStartDate == null) || (fileStartDate.equals(""))) && ((fileEndDate == null) || (fileEndDate.equals(""))) ) {
    		tempDate = new Date(System.currentTimeMillis());
    		alertReportDetailForm.setFileEndDateHidden(dateFormat.format(tempDate));
    		calendar.setTime(tempDate);
    		calendar.add(Calendar.DAY_OF_YEAR, -90);
    		tempDate = new Date(calendar.getTimeInMillis());
    		alertReportDetailForm.setFileStartDateHidden(dateFormat.format(tempDate));
    	} else {
    		alertReportDetailForm.setFileStartDateHidden(alertReportDetailForm.getFileStartDate());
    		alertReportDetailForm.setFileEndDateHidden(alertReportDetailForm.getFileEndDate());
    	}
		
		/*
         * Code added to fix issue EM#09 wherein the selectAll button was checked.
         */
        alertReportDetailForm.setAlertSelectIndicatorAll(false);
        alertReportDetailForm.setAlertSelectIndicatorAll1(false);
    }
	
	/**
	 * Private method to return a list of arguments which are passed to service class to 
	 * get the list of AlertReportDetail objects.
	 * 
	 * @param alertReportDetailForm
	 * @param userId
	 * @param defaultLineCount
	 * @param region
	 * @return List
	 */
	private List listArguments(AlertReportDetailForm alertReportDetailForm, String userId,
    		int defaultLineCount, String region) {
    	List args = new ArrayList();
    	args.add(0, userId);
    	args.add(1, alertReportDetailForm.getFileStartDateHidden());
    	args.add(2, alertReportDetailForm.getFileEndDateHidden());
    	args.add(3, alertReportDetailForm.getControlPoint());
    	args.add(4, alertReportDetailForm.getAlertRule());
    	args.add(5, alertReportDetailForm.getDivision());
    	args.add(6, alertReportDetailForm.getAlertRuleTiming());
    	args.add(7, alertReportDetailForm.getAlertRuleTimingIndicator());
    	args.add(8, alertReportDetailForm.getAlertStatus());
    	args.add(9, alertReportDetailForm.getAlertSeverity());
    	args.add(10, alertReportDetailForm.getGroupAlerted());
    	args.add(11, alertReportDetailForm.getRevenueImpactValue());
    	args.add(12, new Integer(alertReportDetailForm.getRevenueImpactIndicator()));
    	args.add(13, alertReportDetailForm.getSystemErrorType());
    	args.add(14, alertReportDetailForm.getRootCauseCategory());
    	args.add(15, alertReportDetailForm.getLastUpdateStartDate());
    	args.add(16, alertReportDetailForm.getLastUpdateEndDate());
    	args.add(17, alertReportDetailForm.getWebPageId());
    	args.add(18, alertReportDetailForm.getDateType());
    	args.add(19, alertReportDetailForm.getProcessPoint());
    	args.add(20, alertReportDetailForm.getSortItem());
    	args.add(21, alertReportDetailForm.getSortOrder());
    	args.add(22, alertReportDetailForm.getDispatch());
    	args.add(23, alertReportDetailForm.getFromPage());
    	args.add(24, alertReportDetailForm.getTimeStampInd());
    	args.add(25, new Integer(defaultLineCount));
    	args.add(26, region);
    	args.add(27, new Integer(alertReportDetailForm.getPage()));
    	args.add(28, new Integer(alertReportDetailForm.getPages()));

    	return args;
    }
	
	/**
	 * Private method to return a list of hidden arguments.
	 * 
	 * @param alertReportDetailForm
	 * @return List
	 */
	private List listHiddenArguments(AlertReportDetailForm alertReportDetailForm) {
    	List args = new ArrayList();
    	args.add(0, alertReportDetailForm.getControlPointHidden());
    	args.add(1, alertReportDetailForm.getDivisionHidden());
    	args.add(2, alertReportDetailForm.getAlertRuleTimingIndicatorHidden());
    	args.add(3, alertReportDetailForm.getRootCauseCategoryHidden());
    	args.add(4, alertReportDetailForm.getSystemErrorTypeHidden());

    	return args;
    }
	
	/**
	 * Private method to set the total number of pages and current page of the report to the form.
	 * 
	 * @param alertReportDetailForm
	 * @param connection
	 * @param failureList
	 * @param args
	 */
	private void setPaging(AlertReportDetailForm alertReportDetailForm, Connection connection,
			List failureList, List args) {
		/*
		 * Call the service class to get the total count of alerts.
		 */
		int totalAlerts = alertReportDetailService.getTotalAlerts(connection, failureList, args);
		
		int pageSize = ((Integer) args.get(25)).intValue();
		
		int pages = totalAlerts / pageSize;
		int temp = totalAlerts % pageSize;
		if ( temp > 0)
			pages++;
		
		/*
		 * Set the total no. of pages of the report.
		 */
		alertReportDetailForm.setPages(pages);
		
		/*
		 * Set the total count of alerts.
		 */
		alertReportDetailForm.setTotalAlerts(totalAlerts);
		
		/*
		 * Code to set the current page of the report.
		 */
		String dispatch = alertReportDetailForm.getDispatch();
		if ("first".equals(dispatch)) {
			alertReportDetailForm.setPage(1);
		} else if ("last".equals(dispatch)) {
			alertReportDetailForm.setPage(alertReportDetailForm.getPages());
		} else if ("previous".equals(dispatch)) {
        	if (alertReportDetailForm.getPage() != 1) {
        		alertReportDetailForm.setPage(alertReportDetailForm.getPage() - 1);
        	}
        } else if ("next".equals(dispatch)) {
        	if (alertReportDetailForm.getPage() != alertReportDetailForm.getPages()) {
        		alertReportDetailForm.setPage(alertReportDetailForm.getPage() + 1);
        	}
        } else if ("pagelist".equals(dispatch)) {
        	if (alertReportDetailForm.getPageshow() != 0) {
        		alertReportDetailForm.setPage(alertReportDetailForm.getPageshow());
        	} else {
        		alertReportDetailForm.setPage(1);
        	}
        } else if ("sort".equals(dispatch)) {
        	alertReportDetailForm.setPage(alertReportDetailForm.getPage());
        } else if ("returnView".equals(dispatch)) {
        	alertReportDetailForm.setPage(alertReportDetailForm.getPage());
        } else {
        	alertReportDetailForm.setPage(1);
        }
	}
	
	/**
	 * Private method to return a string that contains the first cycle and the last cycle.
	 * This calls the service class to get the list of cycles for the entered file start date and file end date.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return String
	 */
	private String getCycle(Connection connection, List failureList, List args) {
		String cycle = "";
		String region = (String) args.get(26);
		
		if ("WE".equalsIgnoreCase(region) || "C2".equalsIgnoreCase(region)) {
			/*
			 * Call the service class to get the list of cycles.
			 */
			List cycleList = alertReportDetailService.getCycleCalendarList(connection, failureList, args);
			if (cycleList != null) {
				int cycleListSize = cycleList.size();
				if (cycleListSize > 0) {
					if (cycleListSize == 1) {
						cycle = (new Integer(((CycleCalendar) cycleList.get(0)).getCycle())).toString();
					} else {
						cycle = ((new StringBuffer())
								.append((new Integer(((CycleCalendar) cycleList.get(0)).getCycle())).toString())
								.append(" - ")
								.append((new Integer(((CycleCalendar) cycleList.get(cycleListSize-1)).getCycle())).toString()))
								.toString();
					}
				} else {
					cycle = "";
				}
			} else {
				cycle = "";
			}
		}
		return cycle;
	}
}
