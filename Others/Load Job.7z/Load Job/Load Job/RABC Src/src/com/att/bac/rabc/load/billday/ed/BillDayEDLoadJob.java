/**
 * 
 */
package com.att.bac.rabc.load.billday.ed;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.UnknownHostException;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Properties;

import com.att.bac.rabc.util.EmcisEventLogger;
import com.att.carat.util.NetUtil;
import com.att.carat.util.JDBCUtil;
//changes done for M168 by as635b
//import com.sbc.bac.load.Application;
import com.att.carat.load.Application;
import com.sbc.bac.rabc.load.FilePatternLoadJob;
import com.sbc.bac.rabc.load.PrepareTableForRerun;
import com.sbc.bac.rabc.load.RabcLoadJobTrig;
import com.sbc.bac.rabc.load.StaticErrorMsgKeys;

/**
 * The load job loads data from a file with semicolon separated values into the RABC tables.
 * If the USOC level must is 1 the data is loaded to the RABC_ED_SUMY_DATA table.
 * If the USOC level is or 2,3,4,5 the data is loaded to the RABC_COMP_SUMY_DATA table.
 * 
 * @author vp4821
 *
 */
public class BillDayEDLoadJob extends FilePatternLoadJob {
	
	private PreparedStatement loadToED;
	private PreparedStatement loadCOMP;
	private PreparedStatement fetchStatement;
	private static int BATCH_SIZE = 1000;

	private static String loadToEdSumyQry = "insert into RABC_ED_SUMY_DATA " +
			"(REGION, DIVISION, BILL_PERIOD, BILL_PERIOD_DT, ED_PCKG_USOC, BUS_RES_TYPE, " +
			"ED_PCKG_CT, ED_PCKG_BLD_AMT, PROC_DT, USOC_LVL_IND) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	
	private static String sqlForCOMP_W = "insert into RABC_COMP_SUMY_DATA " +
			"(REGION, DIVISION, BILL_RND, BILL_RND_DATE, ED_PCKG_USOC, SUB_PACK_USOC_1, " +
			"SUB_PACK_USOC_2, SUB_PACK_USOC_3, COMP_USOC, BUS_RES_TYPE, USOC_LVL_IND, USOC_RATE, " +
			"TOT_USOC_CNT, TOT_USOC_AMNT, PROC_DATE) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	
	private static String sqlForCOMP_SW_MW = "insert into RABC_COMP_SUMY_DATA " +
			"(REGION, DIVISION, BILL_PERIOD, BILL_PERIOD_DT, ED_PCKG_USOC, SUB_PACK_USOC_1, " +
			"SUB_PACK_USOC_2, SUB_PACK_USOC_3, COMP_USOC, BUS_RES_TYPE, USOC_LVL_IND, USOC_RATE, " +
			"TOT_USOC_CNT, TOT_USOC_AMNT, PROC_DATE) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	
	private static String fetchBillRndAndBillRndDate = "SELECT BILL_RND , BILL_RND_DT FROM RABC_CYCLE_CALENDAR WHERE PROC_DT = ?";

	private String fileId = "RA24COMP"; 		//matches FILE_ID field in rabc_file_mash table for table names from above queries 
	private String fileId_ED = "RA24ED"; 
	
	private RegionEnum region = null;
	private String division = null;
	private HashSet<String> divisionHS;
	private boolean hasTrailerBeenProcessed;
	private boolean isFirstLine;
	private boolean isSecondLine;
	private Date headerDate;
	private Date processDate;
	//private Date billPeriodDate;
	private Date cycleDate;
	private Date recordCycleDate;
	private Calendar recordCycleCal;
	private Date billRndDate;
	private int billRnd = 0;
	private int lineCountED;
	private int lineCountCOMP;
	private int indexUSOCLevel = 0;
	private int westDecr = 0;
	private DateFormat yyMMdd = new SimpleDateFormat("yyMMdd");
	private DateFormat MMddyyyy = new SimpleDateFormat("MMddyyyy");
	private File currentFile;								
	private static final String RABC_COMP_SUMY_DATA ="RABC_COMP_SUMY_DATA";
	private static final String RABC_ED_SUMY_DATA 	="RABC_ED_SUMY_DATA";
	private static final String PN 	="PN";
	private static final String NB 	="NB";
	private static final String PS 	="PS";
	
	private String backoutRecovery;
	private String fileToken, fileName;

	protected boolean configure(Application application, Properties configuration) {
		boolean result = super.configure(application, configuration);
		if( result ){
			if(configuration.getProperty("region") == null || configuration.getProperty("region").equals("")){
				severe("'region' configuration property missing. Please specify 'region' in load job configuration file.");
				result = false;
			} else{
				region = RegionEnum.valueOf( configuration.getProperty("region") );
			}
			
			if( region == RegionEnum.W ){
				westDecr = 0;
			} else if( region == RegionEnum.MW || region == RegionEnum.SW ){
				westDecr = 0; 
			} else {
				result = false;
			}
		}
		return result;
	}
	   
	protected boolean preprocessFile(File file) {
		if( !super.preprocess() )
			return false;
		BufferedReader in = null;
		//configuration.getProperty("create_day");
		fileName = file.getName();

		try {
			loadToED = this.connection.prepareStatement( loadToEdSumyQry );
			if( region == RegionEnum.W ){
				loadCOMP = this.connection.prepareStatement( sqlForCOMP_W );
				fileToken = file.getName().substring(file.getName().indexOf("XT24EDBF"),file.getName().indexOf("XT24EDBF")+ 8);
			}else{
				loadCOMP = this.connection.prepareStatement( sqlForCOMP_SW_MW );
				fileToken = file.getName().substring(5,13);
			}
			fetchStatement = this.connection.prepareStatement(fetchBillRndAndBillRndDate);
			
			lineCountED = 0;
			lineCountCOMP = 0;
			billRnd = 0;
			hasTrailerBeenProcessed = false;
			divisionHS = new HashSet<String>();
			recordCycleCal = Calendar.getInstance();
			isFirstLine = true;	
			isSecondLine = false;
			headerDate = null;
			processDate = null;
			//billPeriodDate = null;
			cycleDate = null;
			billRndDate = null;
			boolean success = true;
			currentFile = file;
			backoutRecovery = null;
			
			String temp = currentFile.getName().substring(0,currentFile.getName().lastIndexOf('.'));
			String fileNameWithoutTimeStamp = temp.substring(0,temp.lastIndexOf('.'));
			
			//If the file is already loaded then delete previously loaded data
			if (RabcLoadJobTrig.IsOriginalFileLoaded(connection, file, fileNameWithoutTimeStamp.length())) {
				warning(file.getName() + " has already been loaded.");
				
				//Marks the backoutRecovery flag to "Y" if this file has already been processed earlier.
				backoutRecovery = "Y";
				in = new BufferedReader(new FileReader(file));
				parseHeader(in.readLine().split("[ ]*;[ ]*"));
				parseProcessAndBillPeriodDate(in.readLine().split("[ ]*;[ ]*"));
				
				if(region== RegionEnum.W ){
					// For West region delete the records from RABC_COMP_SUMY_DATA and RABC_ED_SUMY_DATA for PN and NB regions
					if( division.contentEquals( PS ) ){
						info("Deleting records from RABC_COMP_SUMY_DATA and RABC_ED_SUMY_DATA tables for division:"+PS +" and PROC DATE:"+processDate);
						success = PrepareTableForRerun.deletePreviouslyLoadedData(connection, RABC_COMP_SUMY_DATA, PS, processDate)
						&&PrepareTableForRerun.deletePreviouslyLoadedData(connection, RABC_ED_SUMY_DATA, PS, processDate);
					} else {
						info("Deleting records from RABC_COMP_SUMY_DATA and RABC_ED_SUMY_DATA tables for division:"+PN+", "+NB+"and PROC DATE:"+processDate);
						success = PrepareTableForRerun.deletePreviouslyLoadedData(connection,RABC_COMP_SUMY_DATA , PN, processDate)
						&&PrepareTableForRerun.deletePreviouslyLoadedData(connection,RABC_ED_SUMY_DATA , PN, processDate)
						&&PrepareTableForRerun.deletePreviouslyLoadedData(connection,RABC_COMP_SUMY_DATA , NB, processDate)
						&&PrepareTableForRerun.deletePreviouslyLoadedData(connection,RABC_ED_SUMY_DATA , NB, processDate);
					}
				}else{
					info("Deleting records from RABC_COMP_SUMY_DATA and RABC_ED_SUMY_DATA tables for division:"+division +" and PROC DATE:"+processDate);
					success = PrepareTableForRerun.deletePreviouslyLoadedData(connection,RABC_COMP_SUMY_DATA , division, processDate)
					&&PrepareTableForRerun.deletePreviouslyLoadedData(connection,RABC_ED_SUMY_DATA , division, processDate);
				}
				return success;					
			}

		} catch (SQLException e) {
			severe("Could not instantiate prepared statements.", e);
			return false;
		} catch (IOException e) {
			severe("Could not read file.", e);
			return false;
		} catch (ParseException e) {
			severe("Could not parse file.", e);
			return false;
		} catch(Exception e){
			severe("General Exception occured.", e);
			return false;
		} finally {
			try {
				if (in != null) in.close();
			} catch (IOException e) {
				severe("error closing file - " + e.toString());
			}
			in = null;
		}
		
		return true;
	}
	
	protected int parseLine(String line) throws Exception {
		String[] fields = line.split("[ ]*;[ ]*");
		
		if( hasTrailerBeenProcessed ) {							// trailer must be last record in file
			throw new Exception("TRAILER was not the last record on currently processing file: " + currentFile.getName());
		}														
		
		if (isFirstLine) {										// header must be first record on file
			isFirstLine = false;
			isSecondLine = true;
			//If header is not already parsed then parse the header
			if(headerDate==null){
				return parseHeader(fields);
			}else{
				//header is already processed
				return SUCCESS;
			}
		} else if(isSecondLine){
			isSecondLine = false;
			//if(processDate == null || billPeriodDate == null){
			if(processDate == null || billRndDate == null){
				return parseProcessAndBillPeriodDate(fields);
			} else{
				return SUCCESS;
			}
		} else if ("TRAILER".equalsIgnoreCase(fields[0])) {
			hasTrailerBeenProcessed = true;
			int totalRecords = Integer.parseInt(fields[5]) - 1;	
			if (totalRecords == (lineCountED + lineCountCOMP)) {
				return SUCCESS;
			}
			else{
				throw new Exception("Record count mismatch: trailer record shows " + totalRecords + ", but " 
						+ (lineCountED + lineCountCOMP) + " records exist on file " 
						+ currentFile.getName());
				
			}
		}										
				
		indexUSOCLevel = Integer.parseInt( fields[10 - westDecr] );		//if in west region westDecr == 0
		
		if( indexUSOCLevel == 1){
			if( region == RegionEnum.W ){
			//	recordCycleDate = new Date( yyMMdd.parse( fields[4] ).getTime() );
			//	recordCycleCal.setTime( recordCycleDate );
				division = fields[3];
				
				loadToED.setString(1, region.name());									//REGION
				loadToED.setString(2, division);										//DIVISION
				
				/*loadToED.setInt(3, recordCycleCal.get( Calendar.DAY_OF_MONTH ) );		//BILL_PERIOD 
				loadToED.setDate(4, recordCycleDate);*/									//BILL_PERIOD_DT
				
				loadToED.setInt(3, billRnd);												//BILL_PERIOD 
				loadToED.setDate(4, billRndDate);										//BILL_PERIOD_DT
				loadToED.setString(5, fields[5]); 										//ED_PCKG_USOC
				loadToED.setString(6, fields[11]); 										//BUS_RES_TYPE
				loadToED.setDouble(7, parseAmount(fields[14])); 						//ED_PCKG_CT
				loadToED.setDouble(8, parseAmount( fields[15] ));						//ED_PCKG_BLD_AMT
				loadToED.setDate(9, processDate);										//PROC_DT
				loadToED.setString(10, fields[10]);										//USOC_LVL_IND		
			}
			else {
				recordCycleDate = new Date( yyMMdd.parse( fields[4] ).getTime() );
				recordCycleCal.setTime( recordCycleDate );
				division = fields[3];
				
				loadToED.setString(1, region.name());									//REGION
				loadToED.setString(2, division);										//DIVISION
				
				/*loadToED.setInt(3, recordCycleCal.get( Calendar.DAY_OF_MONTH ));		//BILL_PERIOD 
				loadToED.setDate(4, recordCycleDate);*/									//BILL_PERIOD_DT 
				
				loadToED.setInt(3, billRnd);												//BILL_PERIOD 
				loadToED.setDate(4, billRndDate);										//BILL_PERIOD_DT 
				loadToED.setString(5, fields[5]); 										//ED_PCKG_USOC
				loadToED.setString(6, fields[11]); 										//BUS_RES_TYPE
				loadToED.setDouble(7, parseAmount(fields[13])); 						//ED_PCKG_CT
				loadToED.setDouble(8, parseAmount( fields[14] ));						//ED_PCKG_BLD_AMT
				loadToED.setDate(9, processDate);										//PROC_DT	
				loadToED.setString(10, fields[10]);										//USOC_LVL_IND		
			}
			lineCountED++;								// header and trailer records are not counted	

			// cycle date must be the most recent bill round date in file
			if( cycleDate == null ){
				cycleDate = recordCycleDate;
			} else {
				if( cycleDate.before(recordCycleDate) )
					cycleDate = recordCycleDate;
			}
			
			// you can have PN and NB divisions in a file, add both to trig table		
			divisionHS.add( division );	
			
			loadToED.addBatch();			
			if((lineCountED % BATCH_SIZE) == 0){
				loadToED.executeBatch();
			}
		} else if( (1 < indexUSOCLevel) && (indexUSOCLevel < 6) ){			// USOC level must be 1 or 2,3,4,5
			if( region == RegionEnum.W ){
				recordCycleDate = new Date( yyMMdd.parse( fields[4] ).getTime() );
				recordCycleCal.setTime( recordCycleDate );
				division = fields[3];
				
				loadCOMP.setString(1, region.name());									//REGION
				loadCOMP.setString(2, division);										//DIVISION
				
				/*loadCOMP.setString(3, fields[4].substring(4));						//BILL_RND 
				loadCOMP.setDate(4, recordCycleDate);*/									//BILL_RND_DATE 
				
				loadCOMP.setInt(3, billRnd);												//BILL_RND 
				loadCOMP.setDate(4, billRndDate);										//BILL_RND_DATE
				loadCOMP.setString(5, fields[5]); 										//ED_PCKG_USOC		
				loadCOMP.setString(6, fields[6]);										//SUB_PACK_USOC_1
				loadCOMP.setString(7, fields[7]);										//SUB_PACK_USOC_2
				loadCOMP.setString(8, fields[8]);										//SUB_PACK_USOC_3
				loadCOMP.setString(9, fields[9]);										//COMP_USOC
				loadCOMP.setString(10, fields[11]);										//BUS_RES_TYPE
				loadCOMP.setString(11, fields[10]);										//USOC_LVL_IND
				loadCOMP.setDouble(12, parseAmount( fields[13] ));						//USOC_RATE
				loadCOMP.setDouble(13, parseAmount( fields[14] ));						//TOT_USOC_CNT
				loadCOMP.setDouble(14, parseAmount( fields[15] ));						//TOT_USOC_AMNT
				loadCOMP.setDate(15, processDate);										//PROC_DATE
			}
			else{
				recordCycleDate = new Date( yyMMdd.parse( fields[4] ).getTime() );
				recordCycleCal.setTime( recordCycleDate );
				division = fields[3];
				
				loadCOMP.setString(1, region.name());									//REGION
				loadCOMP.setString(2, division);										//DIVISION
				
				/*loadCOMP.setString(3, fields[4].substring(4));						//BILL_PERIOD 
				loadCOMP.setDate(4, recordCycleDate);	*/								//BILL_PERIOD_DT 
				
				loadCOMP.setInt(3, billRnd);												//BILL_RND 
				loadCOMP.setDate(4, billRndDate);										//BILL_RND_DATE
				loadCOMP.setString(5, fields[5]); 										//ED_PCKG_USOC		
				loadCOMP.setString(6, fields[6]);										//SUB_PACK_USOC_1
				loadCOMP.setString(7, fields[7]);										//SUB_PACK_USOC_2
				loadCOMP.setString(8, fields[8]);										//SUB_PACK_USOC_3
				loadCOMP.setString(9, fields[9]);										//COMP_USOC
				loadCOMP.setString(10, fields[11]);										//BUS_RES_TYPE
				loadCOMP.setString(11, fields[10]);										//USOC_LVL_IND
				loadCOMP.setDouble(12, parseAmount( fields[12] ));						//USOC_RATE
				loadCOMP.setDouble(13, parseAmount( fields[13] ));						//TOT_USOC_CNT
				loadCOMP.setDouble(14, parseAmount( fields[14] ));						//TOT_USOC_AMNT
				loadCOMP.setDate(15, processDate);										//PROC_DATE
			}
			lineCountCOMP++;							// header and trailer records are not counted	
				
			// cycle date must be the most recent bill round date in file
			if( cycleDate == null ){
				cycleDate = recordCycleDate;
			} else {
				if( cycleDate.before(recordCycleDate) )
					cycleDate = recordCycleDate;
			}
			
			// you can have PN and NB divisions in a file, add both to trig table		
			divisionHS.add( division );	

			loadCOMP.addBatch();			
			if((lineCountCOMP % BATCH_SIZE) == 0){
				loadCOMP.executeBatch();
			}
		} 				
		
		return SUCCESS;
	}
	
	public boolean postprocessFile(File file, boolean success) {
		try{
			//Log the file information to EMCIS_EVENT_LOG and EMCIS_EVENT_LOG_DETAIL
			EmcisEventLogger emcisLogger = new EmcisEventLogger();
			String event_id = "RABC_"+fileToken+"_"+region;
            String host = NetUtil.getLocalHostName();
            String hostIP = NetUtil.getLocalIpAddress();
			int sequence = emcisLogger.getEMCISSequence(connection);
			emcisLogger.insertEventLog(connection, sequence, event_id, processDate, host, hostIP);
			emcisLogger.insertEventLogDetail(connection, sequence, "FileName", fileName);
			
		}catch (UnknownHostException e) {
            severe("Error getting EMCIS host information ", e);
        }
		if (success) {
			try {
				loadCOMP.executeBatch();			
				loadToED.executeBatch();				
				
				if(!insertTrigger()) {		// lookup will be done in rabc_cycle_calendar to find cycle_run_day
					severe(
						StaticErrorMsgKeys.POSTPROCESSFILE_ERROR
							+ StaticErrorMsgKeys.TIGGER_TABLE_INSERT_ERROR);
					success = false;
				}
			} catch (SQLException sqle) {
				severe(StaticErrorMsgKeys.INSERT_ERROR + " from method postprocessFile(File file, boolean success)" + sqle.getMessage(), sqle);
				success = false;
			}
		}
		return super.postprocessFile(file, success);
	}
	
	protected boolean postprocess(boolean success) {

		JDBCUtil.closePreparedStatement( loadCOMP );
		JDBCUtil.closePreparedStatement( loadToED );
		
		return super.postprocess(success);
	}

	private boolean insertTrigger() {	
		for( String division1 : divisionHS ){
			if( !RabcLoadJobTrig.insertTrigger(
					connection, 
					currentFile.getName(), 
					currentFile.getName(), 
					fileId, 
					division1, 
					headerDate,
					processDate,
					backoutRecovery) )	// insert backup recovery indicator when file is has already been loaded
			{
				severe("BillDayEDLoadJob could not insert into RABC_TRIG table for RA24COMP. It is possible that the CYCLE_CALENDAR table is missing dates.");
				return false;
			}
			
			if( !RabcLoadJobTrig.insertTrigger(
					connection, 
					currentFile.getName(), 
					currentFile.getName(), 
					fileId_ED, 
					division1, 
					headerDate,
					processDate,
					backoutRecovery) )	// insert backup recovery indicator when file is has already been loaded
			{
				severe("BillDayEDLoadJob could not insert into RABC_TRIG table for RA24ED . It is possible that the CYCLE_CALENDAR table is missing dates.");
				return false;
			}
		}
		return true;
	}
	/** 
	 * Parses a string based on the assumption that the last 6 characters of the string <br>
	 * represent the decimal portion of the number. <br>
	 * Ex: <br>
	 * -0000999500000 will be parsed to: -999.5<br>
	 * 999500000 will be parsed to: 999.5<br>
	 * -000000500000 will be parsed to: -0.50
	 * @param usocAmount
	 * @return usoc amount as double
	 */
	private double parseAmount(String usocAmount){
		double dec = Double.parseDouble( usocAmount.substring(usocAmount.length() - 6, usocAmount.length()) );
		int integ = Integer.parseInt( usocAmount.substring(0, usocAmount.length() - 6 ) );
		int sign = 1;
		if( usocAmount.charAt(0) == '-' )
			sign = -1;		
		return ( dec/1000000 + Math.abs( integ )) * sign;
	}
	
	/**
	 * Used to read the headerDate and division from the header.
	 * @param fields - first line in file
	 * @return
	 * @throws Exception
	 */
	private int parseHeader(String[] fields) throws Exception{
		if ("HEADER".equalsIgnoreCase(fields[0])) {
			headerDate = new Date( MMddyyyy.parse( fields[3] ).getTime() );
			division = fields[2];
			return SUCCESS;
		} else {
			throw new Exception("HEADER could not be parsed in file: " + currentFile.getName());
		}
	}
	
	/**
	 * Used to read the process Date and BillPeriodDate from the 2nd row of the file.
	 * @param fields - second line in file
	 * @return
	 * @throws Exception
	 */
	private int parseProcessAndBillPeriodDate(String[] fields) throws Exception{
		if("RA24DATE".equalsIgnoreCase(fields[0]) || "XT24DATE".equalsIgnoreCase(fields[0])){
			if(fields.length > 2 && !(fields[2].equalsIgnoreCase("000000")) && fields[2] != null && !(fields[2].equalsIgnoreCase(""))){
				processDate = new Date( yyMMdd.parse( fields[2] ).getTime() );
				//billPeriodDate = new Date( yyMMdd.parse( fields[3] ).getTime() );
				
				// fetching BillRnd and BillRndDt from RabcCycleCalendar
				fetchStatement.setDate(1, new java.sql.Date(processDate.getTime()));
				
				ResultSet rs = fetchStatement.executeQuery();
				if( rs.next() ){
					billRnd = rs.getInt("BILL_RND");            //Bill_Rnd
					billRndDate = rs.getDate("BILL_RND_DT");    //Bill_Rnd_Dt
				}else{
					throw new Exception("BillDayEDLoadJob could not fetch BillRnd and BillRndDate from Rabc_Cycle_Calendar. It is possible that the Rabc_Cycle_Calendar table is missing dates.");
				}
				return SUCCESS;
			}else{
				throw new Exception("Process Date not defined in the second row of currently processing file: " + currentFile.getName());
			}
		}else{
			throw new Exception("RA24DATE or XT24DATE row missing in currently processing file: " + currentFile.getName());
		}
		
	}
	
}
