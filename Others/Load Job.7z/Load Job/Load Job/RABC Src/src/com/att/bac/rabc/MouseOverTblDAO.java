/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

/**
 * This is a DAO that performs SELECT, INSERT and UPDATE on RABC_MOUSE_OVER_TBL table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class MouseOverTblDAO {
	private static final Logger logger = Logger.getLogger(MouseOverTblDAO.class);

	/**
	 * Returns the list of MouseOverTbl objects.
	 * 
	 * @param conn 
	 * @param failures
	 * @param args
	 * @param baseSQL
	 * @return List
	 */
	public List get(Connection conn, List failures, List args, String baseSQL) {
		List mouseOverTblList = null;
		MouseOverTbl mouseOverTbl = null;
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		
		try
		{
			logger.debug("Processing SELECT from RABC_MOUSE_OVER_TBL table....");
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("MouseOverTblDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			logger.debug("SQL - Execution complete.");
			mouseOverTblList = new ArrayList();
			while (rs.next()) {
				mouseOverTblList.add(buildMouseOverTbl(rs));
			}
			
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return null;
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
		
		return mouseOverTblList;
	}

	/**
	 * Private method to build MouseOverTbl object and return it to caller.
	 * 
	 * @param rs
	 * @return MouseOverTbl
	 * @throws SQLException
	 */
	private MouseOverTbl buildMouseOverTbl(ResultSet rs) throws SQLException {
		MouseOverTbl mouseOverTbl = new MouseOverTbl();
		
		mouseOverTbl.setTableName(rs.getString("TABLE_NAME"));
		mouseOverTbl.setTableDesc(rs.getString("TABLE_DESC"));
		mouseOverTbl.setTableKeyData(rs.getString("TABLE_KEY_DATA"));
		mouseOverTbl.setTableKeyName(rs.getString("TABLE_KEY_NAME"));
		return mouseOverTbl;
	}

	/**
	 * Execute the insert or update statement on RABC_MOUSE_OVER_TBL table.
	 * 
	 * @param conn
	 * @param failures
	 * @param args
	 * @param baseSQL
	 */
	public void executeUpdate(Connection conn, List failures, List args, String baseSQL) {
		int rowsUpdated = 0;
		Statement stmt = null;
		String sqlStmt = null;
		
		try
		{
			logger.debug("Processing executeUpdate on RABC_MOUSE_OVER_TBL table....");
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("MouseOverTblDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rowsUpdated = stmt.executeUpdate(sqlStmt);
			logger.debug("SQL - Execution complete."+ String.valueOf(rowsUpdated) + "  rows updated");
			
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return;
		} finally {
			SQLHelper.closeStatement(stmt, failures, logger);
		}
	}

}
