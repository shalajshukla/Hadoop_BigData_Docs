package com.att.bac.rabc.adhoc.rpt;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jcifs.smb.SmbFileInputStream;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.att.bac.rabc.ConnectionManager;
import com.att.bac.rabc.PickList;
import com.att.bac.rabc.ProgressBar;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;

public class AdhocBackgroundReportAction extends DispatchAction{
	 public static Logger logger = Logger.getLogger(AdhocBackgroundReportAction.class);
	 private static final int BUFFER_SIZE = 512;
	 
	    protected ActionForward unspecified(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
	    	return view(mapping, form, request, response);				
	    }    

		public ActionForward view(ActionMapping mapping, ActionForm form,HttpServletRequest request, HttpServletResponse res) {
			AdhocBackgroundReportForm adhocBackgroundReportForm = (AdhocBackgroundReportForm)form;
	        HttpSession session = request.getSession(true);
			String region = (String) session.getAttribute("region");
			String tableNode = (String) session.getAttribute("tableNode"); 
			String userId = (String) session.getAttribute("bacUserID");
			//String presnId = (String) request.getParameter("presnIdAsString");
			String dispatch =(String) request.getParameter("dispatch");
			
			String presnId = null;
			if(adhocBackgroundReportForm != null   ){
				if( (adhocBackgroundReportForm.getReportName() != null) &&  !(adhocBackgroundReportForm.getReportName().equals(""))) {
			presnId = adhocBackgroundReportForm.getReportName();
			}
		}
			int id=0;
			if(presnId!=null){
			//int end = presnId.indexOf("dispatch");
			//presnId= presnId.substring(0, end);
			id = Integer.valueOf(presnId);
		
			}
			AdhocBackgroundReportDAO adhocBkgDao = new AdhocBackgroundReportDAO();
			Connection connection = null;
	        List failureList = new ArrayList();		
	        
	        try {
	            ProgressBar progressBar = new ProgressBar(session);
	            connection = ConnectionManager.getConnection(region);
	            progressBar.setProgressPercent(progressBar.getPercent() + 10);
	            
	           // adhocBkgDao.validatePresnId(connection, tableNode, id);
	            
	            populateOptions(adhocBackgroundReportForm, connection, failureList, tableNode);
	            adhocBackgroundReportForm.setReportName(adhocBkgDao.getReportName(connection, failureList, tableNode, id));
	            
	            progressBar.setProgressPercent(progressBar.getPercent() + 10);
	            
	            progressBar.setProgressPercent(progressBar.getPercent() + 10);
	            
	            //set Paging
	           setPaging(adhocBackgroundReportForm, connection, failureList, tableNode, userId, id);

	            
	            adhocBackgroundReportForm.getAdhocBackgroundReportList().clear();	            
	            List<AdhocBackgroundReport> adhocBackgroundReportsList =  adhocBkgDao.getAdhocBackgroundReportsList(connection, failureList, adhocBackgroundReportForm, tableNode,id);
	            progressBar.setProgressPercent(progressBar.getPercent() + 10);
	            
//	            session.setAttribute("adhocBackgroundReportsList", adhocBackgroundReportsList);
//	            session.setAttribute("totalBackgrounReports", totalBackgroundReports);
	            progressBar.setProgressPercent(progressBar.getPercent() + 10);
	            
	            progressBar.setProgressPercent(100);
			} catch(Exception e) {
				logger.error(RABCMessages.getMessage("ERROR_IN_BKG_RPT", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
	            failureList.add(new RABCException(RABCMessages.getMessage("ERROR_IN_BKG_RPT", new String[] {"General Exception"}), e));
			} finally {
				SQLHelper.closeConnection(connection, failureList, logger);
			}	
	        
			 if (!failureList.isEmpty()){
					request.setAttribute("failures", failureList);
					return mapping.findForward("error");
				} else {
					return mapping.findForward("success");
				}
		}
		
		
		/**
		 * Private method to set the total number of pages and current page of the report to the form.
		 * 
		 * @param adhocBackgroundReportForm
		 * @param connection
		 * @param failureList
		 * @param args
		 */
		private void setPaging(AdhocBackgroundReportForm adhocBackgroundReportForm, Connection connection,
				List failureList, String tableNode, String userId, int id) {

			//	List failureList, String tableNode, String userId) {
			/*
			 * Call the service class to get the total count of alerts.
			 */
			AdhocBackgroundReportDAO adhocBkgDao = new AdhocBackgroundReportDAO();
			int pageSize = adhocBkgDao.getDefaultLineCount(connection, failureList, tableNode, userId);
			
			adhocBackgroundReportForm.setPageSize(pageSize);
            int totalBackgroundReports = adhocBkgDao.getTotalAdhocBackgroundReports(connection, failureList, adhocBackgroundReportForm, tableNode, id);

           //int totalBackgroundReports = adhocBkgDao.getTotalAdhocBackgroundReports(connection, failureList, adhocBackgroundReportForm, tableNode);
            adhocBackgroundReportForm.setTotalBackgroundReports(totalBackgroundReports);
    		
    		int pages = totalBackgroundReports / pageSize;
    		int temp = totalBackgroundReports % pageSize;
    		if ( temp > 0)
    			pages++;
    		
    		/*
    		 * Set the total no. of pages of the report.
    		 */
    		adhocBackgroundReportForm.setPages(pages);
    		
    		String dispatch = adhocBackgroundReportForm.getDispatch();
    		if ("first".equals(dispatch)) {
    			adhocBackgroundReportForm.setPage(1);
    		} else if ("last".equals(dispatch)) {
    			adhocBackgroundReportForm.setPage(adhocBackgroundReportForm.getPages());
    		} else if ("previous".equals(dispatch)) {
            	if (adhocBackgroundReportForm.getPage() != 1) {
            		adhocBackgroundReportForm.setPage(adhocBackgroundReportForm.getPage() - 1);
            	}
            } else if ("next".equals(dispatch)) {
            	if (adhocBackgroundReportForm.getPage() != adhocBackgroundReportForm.getPages()) {
            		adhocBackgroundReportForm.setPage(adhocBackgroundReportForm.getPage() + 1);
            	}
            } else if ("pagelist".equals(dispatch)) {
            	if (adhocBackgroundReportForm.getPageshow() != 0) {
            		adhocBackgroundReportForm.setPage(adhocBackgroundReportForm.getPageshow());
            	} else {
            		adhocBackgroundReportForm.setPage(1);
            	}
            } else if ("sort".equals(dispatch)) {
            	adhocBackgroundReportForm.setPage(adhocBackgroundReportForm.getPage());
            } else if ("returnView".equals(dispatch)) {
            	adhocBackgroundReportForm.setPage(adhocBackgroundReportForm.getPage());
            } else {
            	adhocBackgroundReportForm.setPage(1);
            }
    		
		}
		
	    private void populateOptions(AdhocBackgroundReportForm adhocBackgroundReportForm, Connection connection, 
				List failureList, String tableNode)throws RABCException {

	    	List tempList;
	    	int temListSize = 0;
	    	int counter = 0;
	    		    	
	    	AdhocBackgroundReportDAO adhocBkgDao = new AdhocBackgroundReportDAO();

	    	/*
			 * Call methods from service class to populate the drop-down boxes on adhocBackgroundReportForm.
			 */
	    	
	    	if ( adhocBackgroundReportForm.getReportNameList() == null || adhocBackgroundReportForm.getReportNameList().size() == 0) {
	    		tempList =adhocBkgDao.getReportName_List(connection, failureList, tableNode);
	    		if (tempList != null) {
	    			temListSize = tempList.size();
		    		for(counter = 0; counter < temListSize; counter++) {
		    			adhocBackgroundReportForm.addReportName((PickList)tempList.get(counter));
					}
	    		}	
	    	}	    	
	    	
	       	if ( adhocBackgroundReportForm.getUserNameList() == null || adhocBackgroundReportForm.getUserNameList().size() == 0) {
	    		tempList = adhocBkgDao.getUsers_list(connection, failureList, tableNode);
	    		if (tempList != null) {
	    			temListSize = tempList.size();
		    		for(counter = 0; counter < temListSize; counter++) {
		    			adhocBackgroundReportForm.addUserName((PickList)tempList.get(counter));
					}
	    		}
	    	}
	       	
	       	if ( adhocBackgroundReportForm.getStatusesList() == null || adhocBackgroundReportForm.getStatusesList().size() == 0) {
	    		tempList = adhocBkgDao.getStatuses_list(connection, failureList, tableNode);
	    		if (tempList != null) {
	    			temListSize = tempList.size();
		    		for(counter = 0; counter < temListSize; counter++) {
		    			adhocBackgroundReportForm.addStatuses((PickList)tempList.get(counter));
					}
	    		}
	    	}	       	
	    }
	    
	    public ActionForward delete(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response){
			AdhocBackgroundReportForm adhocBackgroundReportForm = (AdhocBackgroundReportForm)form;
	        Connection connection = null;
			List failureList = new ArrayList();		
			
	        try {
		        HttpSession session = request.getSession(true);
				String region = (String) session.getAttribute("region");
				String tableNode = (String) session.getAttribute("tableNode"); 
				String reportNumbers = adhocBackgroundReportForm.getCheckedReports();
//				// if single report delete, then  bckGrndRptNum !=null, else bckGrndRptNum will be null
				if ((reportNumbers==null)&&request.getParameter("bckGrndRptNum")!=null) {
					reportNumbers = (String)request.getParameter("bckGrndRptNum");	
				}	
	            
	            connection = ConnectionManager.getConnection(region);
	            AdhocBackgroundReportDAO dao = new AdhocBackgroundReportDAO();
	            int numberDeleted = dao.deleteBkGrndReport(connection, failureList, tableNode, reportNumbers);
	            if (numberDeleted > 0) {
	            	adhocBackgroundReportForm.setMessage(numberDeleted + " report(s) deleted.");
	            }	            
	        } catch(Exception e) {
				logger.error(RABCMessages.getMessage("ERROR_IN_BKG_RPT", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
	            failureList.add(new RABCException(RABCMessages.getMessage("ERROR_IN_BKG_RPT", new String[] {"General Exception"}), e));
			} finally {
				SQLHelper.closeConnection(connection, failureList, logger);
			}	
		
			return view(mapping, adhocBackgroundReportForm, request, response);
	    }	 
	    
	    public ActionForward download(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
	        Connection connection = null;
			List failureList = new ArrayList();	
			String smbUrl	= null;
	        try {
	        	HttpSession session = request.getSession(true);
				String region = (String) session.getAttribute("region");
				String tableNode = (String) session.getAttribute("tableNode"); 
	            int reportNum = Integer.parseInt(request.getParameter("bckGrndRptNum"));
	            connection = ConnectionManager.getConnection(region);
	            AdhocBackgroundReportDAO dao = new AdhocBackgroundReportDAO();
	            PrintWriter pw = response.getWriter();
	            String fileName = dao.getReportFile(connection, failureList, tableNode, reportNum);
	            
	            Context initContext = new InitialContext();

	            // Get the adhoc report path
	            String spServer = initContext.lookup("java:/comp/env/saved_report_server").toString();
	            String rootFolder = initContext.lookup("java:/comp/env/saved_report_folder").toString();
	            String spUser = initContext.lookup("java:/comp/env/saved_report_user").toString();
	            String spPasswd = initContext.lookup("java:/comp/env/saved_report_passwd").toString();
	            smbUrl = "smb://" + spUser + ":" + spPasswd + "@" + spServer + "/" + rootFolder + "/" + fileName;
		        response.setContentType("application/msexcel");
		        response.setHeader("Content-Disposition", "attachment; filename=" + fileName);

	            InputStream is = new SmbFileInputStream(smbUrl);

	            InputStreamReader bs = new InputStreamReader(is);
	            char[] buffer = new char[512];
	            int read = 0;
	            while ((read = bs.read(buffer)) != -1) {
	                pw.write(buffer, 0, read);
	                buffer = new char[BUFFER_SIZE];
	            }
	            bs.close();
	            is.close();
	        } catch(Exception e) {
				logger.error(RABCMessages.getMessage("ERROR_IN_DOWLOAD", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
	            failureList.add(new RABCException(RABCMessages.getMessage("ERROR_IN_BKG_RPT", new String[] {"General Exception"}), e));
			} finally {
				SQLHelper.closeConnection(connection, failureList, logger);
			}
			 return null;
	    }	
   
	    
		/**
		 * This is an action method to handel the request for first page of SystemMessages.
		 * 
		 * @param mapping
		 * @param form
		 * @param request
		 * @param response
		 * @return ActionForward
		 */
		public ActionForward first(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
			return view(mapping, form, request, response);
	    }
		
		/**
		 * This is an action method to handel the request for previous page of SystemMessages.
		 * 
		 * @param mapping
		 * @param form
		 * @param request
		 * @param response
		 * @return ActionForward
		 */
		public ActionForward previous(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response){
			return view(mapping, form, request, response);
	    }
		
		/**
		 * This is an action method to handel the request for next page of SystemMessages.
		 * 
		 * @param mapping
		 * @param form
		 * @param request
		 * @param response
		 * @return ActionForward
		 */
		public ActionForward next(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
			return view(mapping, form, request, response);
	    }
		
		/**
		 * This is an action method to handel the request for last page of SystemMessages.
		 * 
		 * @param mapping
		 * @param form
		 * @param request
		 * @param response
		 * @return ActionForward
		 */
		public ActionForward last(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response){
	    	return view(mapping, form, request, response);
	    }
	    
		/**
		 * This is an action method to handel the request for specific page of SystemMessages.
		 * 
		 * @param mapping
		 * @param form
		 * @param request
		 * @param response
		 * @return ActionForward
		 */
		public ActionForward pagelist(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response){
	    	return view(mapping, form, request, response);
	    }
	    	
//		public ActionForward view2(ActionMapping mapping, ActionForm form,HttpServletRequest request, HttpServletResponse res) {
//			AdhocBackgroundReportForm adhocBackgroundReportForm = (AdhocBackgroundReportForm)form;
//	        HttpSession session = request.getSession(true);
//			String region = (String) session.getAttribute("region");
//			String tableNode = (String) session.getAttribute("tableNode"); 
//			String userId = (String) session.getAttribute("bacUserID");
//			String presnId = (String) session.getAttribute("presndIsAsString");
//			AdhocBackgroundReportDAO adhocBkgDao = new AdhocBackgroundReportDAO();
//			Connection connection = null;
//	        List failureList = new ArrayList();		
	        
//	        try {
//	            ProgressBar progressBar = new ProgressBar(session);
//	            connection = ConnectionManager.getConnection(region);
//	            progressBar.setProgressPercent(progressBar.getPercent() + 10);
	            
	       //     populateOptions(adhocBackgroundReportForm, connection, failureList, tableNode);
//	            progressBar.setProgressPercent(progressBar.getPercent() + 10);
	            
//	            progressBar.setProgressPercent(progressBar.getPercent() + 10);
	            
	            //set Paging
//	            setPaging(adhocBackgroundReportForm, connection, failureList, tableNode, userId);
	            
//	            adhocBackgroundReportForm.getAdhocBackgroundReportList().clear();	            
//	            List<AdhocBackgroundReport> adhocBackgroundReportsList =  adhocBkgDao.getAdhocBackgroundReportsList(connection, failureList, adhocBackgroundReportForm, tableNode);
//	            progressBar.setProgressPercent(progressBar.getPercent() + 10);
	            
//	            session.setAttribute("adhocBackgroundReportsList", adhocBackgroundReportsList);
//	            session.setAttribute("totalBackgrounReports", totalBackgroundReports);
//	            progressBar.setProgressPercent(progressBar.getPercent() + 10);
	            
//	            progressBar.setProgressPercent(100);
//			} catch(Exception e) {
//				logger.error(RABCMessages.getMessage("ERROR_IN_BKG_RPT", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
//	            failureList.add(new RABCException(RABCMessages.getMessage("ERROR_IN_BKG_RPT", new String[] {"General Exception"}), e));
//			} finally {
//				SQLHelper.closeConnection(connection, failureList, logger);
//			}	
	        
//			 if (!failureList.isEmpty()){
//					request.setAttribute("failures", failureList);
//					return mapping.findForward("error");
//				} else {
//					return mapping.findForward("success");
//				}
//		}
}
