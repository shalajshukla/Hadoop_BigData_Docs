/*
 * � 2002-2009 AT&T Intellectual Property. All rights reserved.
 */
package com.att.bac.rabc.rmi;

import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

import com.att.carat.server.rmi.ITask;


/**
 * RMI Remote interface for issuing a remote run command for standard reports.
 * 
 * @author jb6494
 * 
 */
public interface IRMIRunReport extends Runnable {

    /**
     * Run the report in a thread
     */
    public void runAsThread();


    /**
     * Find the associated {@link ITask}
     * 
     * @return
     * @throws MalformedURLException
     * @throws RemoteException
     * @throws NotBoundException
     */
    public ITask getTask() throws MalformedURLException, RemoteException, NotBoundException;

}
