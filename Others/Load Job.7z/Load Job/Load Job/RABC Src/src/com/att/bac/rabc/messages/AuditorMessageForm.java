/* Created on Feb 23, 2006 by Peter Foo (pf7941)
 * Copyright 2006 AT&T Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.messages;

import org.apache.struts.action.ActionForm;

public class AuditorMessageForm extends ActionForm {
    private static final long serialVersionUID = 1L;
    
    boolean endSession = false;
    
    public boolean isEndSession() {
        return endSession;
    }
    public void setEndSession(boolean endSession) {
        this.endSession = endSession;
    }
}