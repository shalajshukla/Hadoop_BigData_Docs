/* Component Name: RABCPPG00506
 * Module Name: SelectListTO.java
 * Created on Mar 1, 2006
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.admin.alert.grp;

import java.io.Serializable;

/**This is a transfer object class for the Alert Group process.  The purpose of this class is to 
 * contain data associated with the application functions and alert rules of an alert group.  This data
 * is extracted from the AdminAlertGroupDAO.java class and is sent back to the AdminAlertGroupForm.java
 * class via the AdminAlertGroupService.java class.
 * 
 * @author js3175
 */
public class SelectRowTO implements Serializable {
	private static final long serialVersionUID = 0L;
	
	private String rowID = "";
	private String rowName = "";
	private int isSelected = 0;
	private int canDelete = 0;
	private int systemMessage = 0;
	private int applicationMessage = 0;
	
	public SelectRowTO () {}
	
	public SelectRowTO (String rowId, String rowName, int isSelected) {
		this.rowID = rowId;
		this.rowName = rowName;
		this.isSelected = isSelected;
	}
	
	/**
	 * @return Returns the functCode.
	 */
	public String getRowID() {
		return rowID;
	}
	/**
	 * @param functCode The functCode to set.
	 */
	public void setRowID(String functCode) {
		this.rowID = functCode;
	}
	/**
	 * @return Returns the rowName.
	 */
	public String getRowName() {
		return rowName;
	}
	/**
	 * @param rowName The rowName to set.
	 */
	public void setRowName(String rowName) {
		this.rowName = rowName;
	}
	/**
	 * @return Returns the isSelected.
	 */
	public int getIsSelected() {
		return isSelected;
	}
	/**
	 * @param isSelected The isSelected to set.
	 */
	public void setIsSelected(int isSelected) {
		this.isSelected = isSelected;
	}
	/**
	 * @return Returns the canDelete.
	 */
	public int getCanDelete() {
		return canDelete;
	}
	/**
	 * @param canDelete The canDelete to set.
	 */
	public void setCanDelete(int canDelete) {
		this.canDelete = canDelete;
	}
	/**
	 * @return Returns the applicationMessage.
	 */
	public int getApplicationMessage() {
		return applicationMessage;
	}
	/**
	 * @param applicationMessage The applicationMessage to set.
	 */
	public void setApplicationMessage(int applicationMessage) {
		this.applicationMessage = applicationMessage;
	}
	/**
	 * @return Returns the systemMessage.
	 */
	public int getSystemMessage() {
		return systemMessage;
	}
	/**
	 * @param systemMessage The systemMessage to set.
	 */
	public void setSystemMessage(int systemMessage) {
		this.systemMessage = systemMessage;
	}
}
