/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.admin.alert.rule;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.ArrayList;
import java.text.MessageFormat;

import org.apache.log4j.Logger;

import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.RABCException;

/**
 * This is a DAO that performs SELECT, INSERT and UPDATE on RABC_AVG_CALC table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class AvgCalcDAO {
	private static final Logger logger = Logger.getLogger(AvgCalcDAO.class);

	/**
	 * Returns the list of AvgCalc objects.
	 * 
	 * @param conn 
	 * @param failures
	 * @param args
	 * @param baseSQL
	 * @return List
	 */
	public List get(Connection conn, List failures, List args, String baseSQL) {
		List avgCalcList = null;
		AvgCalc avgCalc = null;
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		
		try
		{
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("AvgCalcDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			avgCalcList = new ArrayList();
			while (rs.next()) {
				avgCalcList.add(buildAvgCalc(rs));
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return null;
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
		
		return avgCalcList;
	}

	/**
	 * Private method to build AvgCalc object and return it to caller.
	 * 
	 * @param rs
	 * @return AvgCalc
	 * @throws SQLException
	 */
	private AvgCalc buildAvgCalc(ResultSet rs) throws SQLException {
		AvgCalc avgCalc = new AvgCalc();
		
		avgCalc.setAlertRule(rs.getString("ALERT_RULE"));
		avgCalc.setPartiRefId(rs.getInt("PARTI_REF_ID"));
		avgCalc.setAvgNumDate(rs.getInt("AVG_NUM_DATE"));
		avgCalc.setAvgNumRec(rs.getInt("AVG_NUM_REC"));
		avgCalc.setAvgTrendTimeInd(rs.getString("AVG_TREND_TIME_IND"));
		avgCalc.setAvgTblName(rs.getString("AVG_TBL_NAME"));
		avgCalc.setAvgType(rs.getString("AVG_TYPE"));
		return avgCalc;
	}

	/**
	 * Execute the insert or update statement on RABC_AVG_CALC table.
	 * 
	 * @param conn
	 * @param failures
	 * @param args
	 * @param baseSQL
	 */
	public void executeUpdate(Connection conn, List failures, List args, String baseSQL) {
		int rowsUpdated = 0;
		Statement stmt = null;
		String sqlStmt = null;
		
		try
		{
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("AvgCalcDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rowsUpdated = stmt.executeUpdate(sqlStmt);
			logger.debug("SQL - Execution complete."+ String.valueOf(rowsUpdated) + "  rows updated");
			
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return;
		} finally {
			SQLHelper.closeStatement(stmt, failures, logger);
		}
	}

}
