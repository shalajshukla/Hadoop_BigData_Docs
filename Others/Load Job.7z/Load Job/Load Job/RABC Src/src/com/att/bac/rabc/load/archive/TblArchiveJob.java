package com.att.bac.rabc.load.archive;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.att.carat.util.JDBCUtil;
//changes for M168 by as635b
import com.att.carat.load.TimedLoadJob;
//import com.sbc.bac.load.TimedLoadJob;

public class TblArchiveJob extends TimedLoadJob {
	
	/**
	 * This job "DELETED"s data from tables listed in column TABLE_NAME for older than ARCHIVE_DAYS column in table RABC_ARCHIVE_INFO.  
	 * This job runs once everyday in after hours and cleans up any matching data.     
	 */
	
	private PreparedStatement selectDDLdata;
	private PreparedStatement getTblList;
	private PreparedStatement delArchiveData;
	private static final String DLLSql = "select ALERT_PROC_TBL, TBL_PROC_DATE_DDL_NAME, TBL_BILL_RND_DDL_MON, TBL_BILL_RND_DDL_YEAR from   RABC_DATA_TBL_DDL where ALERT_PROC_TBL = ? and rownum < 2";
	
	// process records from RABC_ARCHIVE_INFO & RABC_DATA_TBL_DDL to determine what data need to be deleted from source tables -- 
	// listed ..
	
	protected boolean action() {
		
		boolean status = true;
		ResultSet tblList = null;
		
		try {
			
			getTblList = connection.prepareStatement(" select DIVISION, TABLE_NAME, ARCHIVE_DAYS from RABC_ARCHIVE_INFO ");
			tblList = getTblList.executeQuery();
			
			while(tblList.next()){
				String division = tblList.getString("DIVISION");
				String sourceTbl = tblList.getString("TABLE_NAME");
				int days = tblList.getInt("ARCHIVE_DAYS");
				
				processDataDeletion(division, sourceTbl, days); 
			}
			
		}catch (SQLException e) {
			severe(" Archive processing Exception"+e, e);
			status = false;
		} catch (Exception e){
			severe(" Archive processing Exception"+e, e);
			status = false;
		}finally {
			JDBCUtil.closeResultSet(tblList);			
		}
		
		return status;
	}

	private void processDataDeletion(String division, String sourceTbl, int days) throws SQLException {

		ResultSet DDLList = null;
		selectDDLdata = connection.prepareStatement(DLLSql);
		selectDDLdata.setString(1,sourceTbl);
		DDLList = selectDDLdata.executeQuery();
		
		if (!DDLList.next())
			return;
			
		//TBL_PROC_DATE_DDL_NAME
		String procDateDDLName = DDLList.getString("TBL_PROC_DATE_DDL_NAME");

		StringBuffer delSQL = new StringBuffer(" DELETE from ").append(sourceTbl);
		delSQL.append(" where ");
		if (division != null && !division.equals(""))
			delSQL.append(" DIVISION = ? AND ");
		delSQL.append(procDateDDLName).append(" < (SYSDATE - ?)");
		
		delArchiveData = connection.prepareStatement(delSQL.toString());
		if (division != null && !division.equals("")){
			delArchiveData.setString(1,division);
			delArchiveData.setInt(2,days);
		}else 
			delArchiveData.setInt(1,days);
		
		int deletedCnt = delArchiveData.executeUpdate();
		
		info ("For table " + sourceTbl + " Archived rows " + deletedCnt);
		System.out.println(" for " + sourceTbl + "rows deleted >> " + deletedCnt);
		
	}
	
	protected boolean postprocess(boolean success) {
	
			JDBCUtil.closePreparedStatement(getTblList);
			JDBCUtil.closePreparedStatement(selectDDLdata);
			JDBCUtil.closePreparedStatement(delArchiveData);
		
		success = super.postprocess(success);
		
		return success;
	}
	

}
