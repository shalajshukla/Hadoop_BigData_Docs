/*
 * Copyright  2002-2006 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.load.keymatch;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

import com.att.carat.util.JDBCUtil;
// changes for M168 by as635b
import com.att.carat.load.TimedLoadJob;
//import com.sbc.bac.load.TimedLoadJob;


/**
 * This program matches the keys from a selected run against a number of previous runs. The program will be schedule to
 * run once a day. The program uses "Log table" to determine if current input data is ready to run. If the entry is not
 * found in the Log table, the job should execute right away with current run.
 * 
 * <pre>
 *                                                                             
 *                                                                             Process logic:
 *                                                                             1. read RABC_KEY_MATCH_ALERT table in sequence. 
 *                                                                             
 *                                                                             2. For each ALERT_MATCHKEY record determine if it is time to execute.  
 *                                                                             (Include BILL_RND_DDL_NAME if its value is not null)
 *                                                                             
 *                                                                             A. SQL:
 *                                                                             select   Key1_DDL_NAME, 
 *                                                                             max(value of  PROC_DATE_DDL_NAME), 
 *                                                                             value of Bill_RND_DDL_NAME
 *                                                                             from   value of ALERT_PROC_TBL
 *                                                                             group by  value of Key1_DDL_NAME
 *                                                                             
 *                                                                             B. for each record:
 *                                                                             I.  Based on the next_run_date_ind convert the run_date  
 *                                                                             Weekly = -7 days, 
 *                                                                             month  = -1 month 
 *                                                                             
 *                                                                             II.  Select  true                   (is time to run?-jb6494)
 *                                                                             from  rabc_match_key_log
 *                                                                             where  key1_data = value of key1 from 2.A
 *                                                                             and run_date  &gt;=  convert run_date B.I
 *                                                                             and alert_matchkey = alert_matchkey in process
 *                                                                             
 *                                                                             3. If not true from 2.B.II execute the match key process
 *                                                                             
 *                                                                             For each missing data found:
 *                                                                             insert to the RABC_ALERT_MSG table as a system msg using max run date as the alert msg date. 
 *                                                                             Number of keys depends on LVL_OF_KEY field.
 *                                                                             
 *                                                                             select   key1_data, 
 *                                                                             key2_data... 
 *                                                                             from   ALERT_PROC_TBL (old data)
 *                                                                             where   PROC_DATE_DDL_NAME &lt; then max run date 
 *                                                                             and PROC_DATE_DDL_NAME &gt; current date + ALERT DAY
 *                                                                             and bill_rnd = value of bill_rnd return (if apply)
 *                                                                             group by  key_data...........
 *                                                                             
 *                                                                             not exist
 *                                                                             
 *                                                                             ((select  key1_data, 
 *                                                                             key2_data.., 
 *                                                                             from   ALERT_PROC_TBL (current data)
 *                                                                             where  PRC_DATE_DDL_NAME = MAX Run date)
 *                                                                             
 *                                                                             union
 *                                                                             
 *                                                                             (select  key1_date, 
 *                                                                             key2_data.. 
 *                                                                             from   RABC_KEY_MATCH_EXMPT (exemption)
 *                                                                             where  ALERT_MATCHKEY = current process ALERT_MATCHKEY))
 *                                                                             
 *                                                                             4. Insert to the RABC_MATCH_KEY_LOG table for each DDL_KEY1_NAME
 * </pre>
 * 
 * 
 * <p>
 * <hr>
 * <h3>Release History</h3>
 * <p>
 * <ul>
 * 
 * <li>jb6494 Oct 23, 2006 Created class.
 * 
 * </ul>
 * <p>
 * 
 */
public class KeyMatchLoadJob extends TimedLoadJob {    
    private static final SimpleDateFormat SDF = new SimpleDateFormat("yyyy-MM-dd");

    private Date maxRunDate;

    private Date previousRunDate;;

    /**
     * @param alert
     */
    private void computePreviousRunDate(KeyMatchAlert alert) {
        Calendar g = (GregorianCalendar) GregorianCalendar.getInstance();
        g.setTimeInMillis(System.currentTimeMillis());					// Previous run date calculations based off of current system time

        if (alert.getNextRunDayIndicator() == null) {					// NEXT_RUN_DAY_IND is unpopulated
        	if (alert.getAlertDay() == 0) {
                g.add(GregorianCalendar.DAY_OF_MONTH, -90);
        	} else {
                g.add(GregorianCalendar.DAY_OF_MONTH, -alert.getAlertDay());
        	}
        } else {
            if ("W".equals(alert.getNextRunDayIndicator())) {			// 'W' stands for weekly
                g.add(GregorianCalendar.DAY_OF_MONTH, -7);
            } else {													// only other valid value is 'M' for monthly
                g.add(GregorianCalendar.MONTH, -1);
            }
        }
        
        previousRunDate = new Date(g.getTimeInMillis());
        return;
    }


    /**
     * @return
     * @throws SQLException
     */
    private int createMsgNum() throws SQLException {
        PreparedStatement ps = connection.prepareStatement("select EWSSEQ_MSG_NO.nextval from dual");
        ResultSet rs = ps.executeQuery();
        rs.next();
        int result = rs.getInt(1);
        JDBCUtil.closeResultSet(rs);
        JDBCUtil.closePreparedStatement(ps);
        return result;
    }


    /**
     * @param alert
     * @param billRnd
     * @throws SQLException
     */
    private void doKeyMatchProcess(KeyMatchAlert alert, String keyOneData, String billRnd) throws SQLException {
        /*
         * select key1_data, key2_data... from ALERT_PROC_TBL (old data) where PROC_DATE_DDL_NAME &lt; then max run date
         * and PROC_DATE_DDL_NAME &gt; current date + ALERT DAY and bill_rnd = value of bill_rnd return (if apply) group
         * by key_data...........
         */
        StringBuffer buf = new StringBuffer(100);
        buf.append("SELECT * FROM ((SELECT ");

        for (int i = 0; i < alert.getLevelOfKey(); i++) {
            buf.append(alert.getDdlKeyName().get(i));
            if (i + 1 < alert.getLevelOfKey()) {
                buf.append(", ");
            }
        }
        buf.append(" FROM ");
        buf.append(alert.getAlertProcTable());
        buf.append(" WHERE ");
        buf.append(alert.getProcDateDDLName());
        buf.append(" < ");
        buf.append(toDate(maxRunDate));
        buf.append(" AND ");
        buf.append(alert.getProcDateDDLName());
        buf.append(" >= ");
        buf.append(toDate(previousRunDate));
        buf.append(" AND ");
        buf.append(alert.getDdlKeyName().get(0));
        buf.append(" = '" + keyOneData + "'");
        

        if (billRnd != null) {
            buf.append(" AND bill_rnd = ");
            buf.append(billRnd);
        }

        /*
         * not exist
         */
        buf.append(") minus ((SELECT ");

        /*
         * ((select key1_data, key2_data.., from ALERT_PROC_TBL (current data) where PRC_DATE_DDL_NAME = MAX Run date)
         * 
         * union
         * 
         * (select key1_date, key2_data.. from RABC_KEY_MATCH_EXMPT (exemption) where ALERT_MATCHKEY = current process
         * ALERT_MATCHKEY))
         */
        for (int i = 0; i < alert.getLevelOfKey(); i++) {
            buf.append(alert.getDdlKeyName().get(i));
            if (i + 1 < alert.getLevelOfKey()) {
                buf.append(", ");
            }
        }
        buf.append(" FROM ");
        buf.append(alert.getAlertProcTable());
        buf.append(" WHERE ");
        buf.append(alert.getProcDateDDLName());
        buf.append(" = ");
        buf.append(toDate(maxRunDate));
        buf.append(" UNION (SELECT ");
        for (int i = 0; i < alert.getLevelOfKey(); i++) {
            buf.append(" key");
            buf.append(i + 1);
            buf.append("_data ");
            if (i + 1 < alert.getLevelOfKey()) {
                buf.append(",");
            }
        }
        buf.append("FROM rabc_key_match_exmpt WHERE alert_MATCHKEY = ");
        buf.append(alert.getAlertMatchKey());
        buf.append("))))");

        PreparedStatement ps = connection.prepareStatement(buf.toString());
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            /*
             * For each missing data found: insert to the RABC_ALERT_MSG table as a system msg using max run date as the
             * alert msg date. Number of keys depends on LVL_OF_KEY field.
             */
            String[] keys = {"", "", "", "", ""};
            for (int i = 0; i < alert.getLevelOfKey(); i++) {
                keys[i] = rs.getString(i + 1);
            }
            sendAlertMessage(alert, keys);
        }
        JDBCUtil.closeResultSet(rs);
        JDBCUtil.closePreparedStatement(ps);
    }


    /**
     * 4. Insert to the RABC_MATCH_KEY_LOG table for each DDL_KEY1_NAME
     * 
     */
    private void insertToLog(KeyMatchAlert alert, Date maxRunDate, String keyOneData) throws SQLException {
        String sql = "INSERT INTO rabc_match_key_log (alert_matchkey, run_date, key1_data, timestamp) VALUES(?,?,?,?)";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setInt(1, alert.getAlertMatchKey());
        ps.setDate(2, maxRunDate);											// RUN_DATE 
        ps.setString(3, keyOneData);										// KEY1_DATA
        ps.setDate(4, new Date(Calendar.getInstance().getTimeInMillis()));	// TIME_STAMP
        ps.executeUpdate();
        JDBCUtil.closePreparedStatement(ps);
    }


    /**
     * II. Select true (is time to run?-jb6494) from rabc_match_key_log where key1_data = value of key1 from 2.A and
     * run_date &gt;= convert run_date B.I and alert_matchkey = alert_matchkey in process 3. If not true from 2.B.II
     * execute the match key process
     */
    private boolean isRecordReadyToProcess(KeyMatchAlert alert, String k1Data) throws SQLException {
        String sql = "SELECT alert_matchkey FROM rabc_match_key_log WHERE key1_data = ? AND run_date = ? AND alert_matchkey = ?";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, k1Data);
        ps.setDate(2, maxRunDate);
        ps.setInt(3, alert.getAlertMatchKey());
        ResultSet rs = ps.executeQuery();
        boolean ready = !rs.next();
        JDBCUtil.closeResultSet(rs);
        JDBCUtil.closePreparedStatement(ps);
        return ready;
    }


    /**
     * @param rs
     * @return
     * @throws SQLException
     */
    private KeyMatchAlert populateAlertRecord(ResultSet rs) throws SQLException {
        KeyMatchAlert alert = new KeyMatchAlert();
        alert.setAlertDay(rs.getInt("ALERT_DAY"));
        alert.setAlertMatchKey(rs.getInt("ALERT_MATCHKEY"));
        alert.setAlertProcTable(rs.getString("ALERT_PROC_TBL"));
        alert.setAlertRule(rs.getString("ALERT_RULE"));
        alert.setBillRoundDDLName(rs.getString("BILL_RND_DDL_NAME"));
        alert.setFileID(rs.getString("FILE_ID"));
        alert.setLevelOfKey(rs.getInt("LVL_OF_KEY"));
        alert.setNextRunDayIndicator(rs.getString("NEXT_RUN_DAY_IND"));
        alert.setProcDateDDLName(rs.getString("PROC_DATE_DDL_NAME"));
        alert.getDdlKeyName().add(rs.getString("DDL_KEY1_NAME"));
        alert.getDdlKeyName().add(rs.getString("DDL_KEY2_NAME"));
        alert.getDdlKeyName().add(rs.getString("DDL_KEY3_NAME"));
        alert.getDdlKeyName().add(rs.getString("DDL_KEY4_NAME"));
        alert.getDdlKeyName().add(rs.getString("DDL_KEY5_NAME"));
        return alert;
    }


    /**
     * 
     * For each missing data found: insert to the RABC_ALERT_MSG table as a system msg using max run date as the alert
     * msg date. Number of keys depends on LVL_OF_KEY field.
     * 
     * Details to populate RABC_ALERT_MSG <br>
     * 1. ALERT_SEVERE_LVL_IND = 'S' <br>
     * 2. PROC_DATE = max run date from the alert rule in the RABC_CNTRL_RUN table. I do that just in case the
     * ALERT_RULE execution has been delay before the Matching Key program. <br>
     * 3. beside the file id, concatenate all the key involved in the Alert msg column example:File_id:file_id,
     * 'alert_key1':alert_data1, 'Alert_key2': alert_data2.
     * 
     * @param alert
     */
    private void sendAlertMessage(KeyMatchAlert alert, String[] data) throws SQLException {
        String sql = "INSERT INTO rabc_alert_msg (msg_num, proc_date, file_seq_num, alert_rule, alert_key_lvl, alert_key1, alert_key2, alert_key3, alert_key4, alert_key5, alert_data1, alert_data2, alert_data3, alert_data4, alert_data5,alert_status, alert_msg, alert_sys_err_cd, time_stamp, alert_severe_lvl_ind, alert_rule_run_dt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,'Warning', ?, ?, SYSDATE, 'S', SYSDATE)";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setInt(1, createMsgNum());
        ps.setDate(2, maxRunDate); // TODO get from some other table
        ps.setNull(3, Types.INTEGER);// file_seq_num,
        ps.setString(4, alert.getAlertRule());
        ps.setInt(5, alert.getLevelOfKey());

        for (int i = 0; i < 5; i++) {
            if (i < alert.getLevelOfKey()) {
                ps.setString(i + 6, (String) alert.getDdlKeyName().get(i));
            } else {
                ps.setNull(i + 6, Types.VARCHAR);
            }
        }

        for (int i = 0; i < 5; i++) {
            if (i < alert.getLevelOfKey()) {
                ps.setString(i + 11, data[i]);
            } else {
                ps.setNull(i + 11, Types.VARCHAR);
            }
        }

        StringBuffer buf = new StringBuffer(100);
        buf.append("File_id:");
        buf.append(alert.getFileID());
        buf.append(", ");
        for (int i = 0; i < 5; i++) {
            buf.append(alert.getDdlKeyName().get(i));
            buf.append(":");
            buf.append(data[i]);
            if (i < 4) {
                buf.append(", ");
            }
        }
        ps.setString(16, buf.toString());
        ps.setInt(17, 7);

        ps.execute();
        JDBCUtil.closePreparedStatement(ps);
    }


    private String toDate(Date date) {
        return "to_Date('" + SDF.format(date) + "', 'YYYY-MM-DD')";
    }


    /*
     * (non-Javadoc)
     * 
     * @see com.sbc.bac.load.LoadJob#action()
     */
    protected boolean action() {
        PreparedStatement ps = null;
        ResultSet rs = null;
        PreparedStatement ps2 = null;
        ResultSet rs2 = null;

        boolean result = true;

        try {
            ps = connection.prepareStatement("SELECT * FROM rabc_key_match_alert");
            rs = ps.executeQuery();
            while (rs.next()) {
                KeyMatchAlert alert = populateAlertRecord(rs);

                StringBuffer buf = new StringBuffer(100);

                if (alert.getBillRoundDDLName() != null) {		// expand to include bill rnd information
                	buf.append("SELECT DISTINCT ");								// ensure no duplicates
                    buf.append("B." + alert.getDdlKeyName().get(0) + ", ");		// key info from subset B
                    buf.append("B.RUN_DATE, ");									// run date from subset B
                    buf.append("A." + alert.getBillRoundDDLName() + " ");		// bill rnd from target table A
                    buf.append("FROM " + alert.getAlertProcTable() + " A, ");	// name target table A
                    buf.append("(");											// enclose subset B
                }
                
                /*
                 * select Key1_DDL_NAME, max(value of PROC_DATE_DDL_NAME) from value of
                 * ALERT_PROC_TBL group by value of Key1_DDL_NAME
                 */
                buf.append("SELECT ");
                buf.append(alert.getDdlKeyName().get(0));
                buf.append(", max(");
                buf.append(alert.getProcDateDDLName());
                buf.append(")");

                if (alert.getBillRoundDDLName() != null) {		// expand to include bill rnd information
                	buf.append(" RUN_DATE ");									// name this column RUN_DATE for subset B
                }
                
                buf.append(" from ");
                buf.append(alert.getAlertProcTable());
                buf.append(" group by ");
                buf.append(alert.getDdlKeyName().get(0));
                
                if (alert.getBillRoundDDLName() != null) {		// expand to include bill rnd information
                	buf.append(") B ");											// enclose subset B, and name it B
                    buf.append("WHERE ");		
                    buf.append("B.RUN_DATE = A." + alert.getProcDateDDLName() + " ");	// run dates are equal
                    buf.append("AND B." + alert.getDdlKeyName().get(0) + " = A." + alert.getDdlKeyName().get(0));	// key values are the same
                }
                
                ps2 = connection.prepareStatement(buf.toString());
                rs2 = ps2.executeQuery();
                while (rs2.next()) {
                    String k1Data = rs2.getString(1);
                    maxRunDate = rs2.getDate(2);
                    String billRnd = null;
                    if (alert.getBillRoundDDLName() != null) {
                        billRnd = rs2.getString(3);
                    }

                    computePreviousRunDate(alert);

                    /*
                     * 3. If not true from 2.B.II execute the match key process
                     */
                    if (isRecordReadyToProcess(alert, k1Data)) {
                        doKeyMatchProcess(alert, k1Data, billRnd);
                        insertToLog(alert, maxRunDate, k1Data);
                    }
                }
            }
        } catch (Exception e) {
            result = false;
            severe("Unhandled exception caught in action(), message follows: "  + e.getMessage(), e);
        } finally {
            JDBCUtil.closeResultSet(rs2);
            JDBCUtil.closePreparedStatement(ps2);
            JDBCUtil.closeResultSet(rs);
            JDBCUtil.closePreparedStatement(ps);
        }
        return result;
    }
}
