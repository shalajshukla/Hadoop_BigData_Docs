/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.admin.alert.rule;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.att.bac.rabc.ConnectionManager;
import com.att.bac.rabc.ProgressBar;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;

/**
 * This is a Action class for Alert Rule Deletion Page.
 * 
 * @author Shailesh Hemdev - SH8512
 */
public class AlertRuleDeleteAction extends DispatchAction {
	public static Logger  logger = Logger.getLogger(AlertRuleDeleteAction.class);
	AlertRuleDeleteService  alertRuleDeleteService = AlertRuleDeleteService.getAlertRuleDeleteService();
	
	/**
	 * Delete Action.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward delete(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response){
		AlertRuleDeleteForm  alertRuleDeleteForm = (AlertRuleDeleteForm) form;
		alertRuleDeleteForm.setAlertRuleDefinition(new AlertRuleDefinition((String)request.getSession().getAttribute("region")));
		Connection connection = null;
		List failureList = new ArrayList();
		List args = new ArrayList();
		HttpSession session = null;
		ProgressBar progressBar = null;
		
		alertRuleDeleteForm.setActionType("DELETE");
		//Collect the parameters such as data source & alert rule [key] from the request if the		 
		session = request.getSession(true);
		progressBar = new ProgressBar(session);
		
		AlertRuleDefinition alertRuleDefinition = new AlertRuleDefinition((String)request.getSession().getAttribute("region"));
		
		if (request.getAttribute("dataSource")!=null){
			alertRuleDefinition.setDataSource((String)request.getAttribute("dataSource"));
		}

		if (request.getAttribute("alertRule")!=null){
			alertRuleDefinition.setAlertRule((String)request.getAttribute("alertRule"));
			
			args.add((String)request.getAttribute("alertRule"));
			args.add((String)session.getAttribute("bacUserID"));
			
			try {
				connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
				progressBar.setProgressPercent(10);
				
				alertRuleDefinition = alertRuleDeleteService.getAlertRuleDefinition(connection, failureList, args, alertRuleDefinition, progressBar, (String)request.getSession().getAttribute("region"));
			} catch(SQLException sx) {
				logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
				failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
			} catch(NamingException ne) {
				logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
				failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
			} catch(Exception e){
				logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}) + " Exception details: " + e.getMessage(), e);
				failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
			} finally {
				SQLHelper.closeConnection(connection, failureList, logger);
			}
			
			alertRuleDeleteForm.setAlertRuleDefinition(alertRuleDefinition);
			alertRuleDeleteForm.setAlertRule(alertRuleDefinition.getAlertRule());
			progressBar.setProgressPercent(100);
		}
		
		if (!failureList.isEmpty()){
			request.setAttribute("failures", failureList);
			return mapping.findForward("error");
		} else {
			return mapping.findForward("Delete");
		}
	}

	/**
	 * Action method called when the user clicks on Delete.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward confirm(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response){
		AlertRuleDeleteForm alertRuleDeleteForm = (AlertRuleDeleteForm) form;
		ActionForward forward;
		Connection connection = null;
		List failureList = new ArrayList();
		List args = new ArrayList();
		HttpSession session = request.getSession();
		ProgressBar progressBar = new ProgressBar(session);
		AlertRuleDefinition alertRuleDefinition = new AlertRuleDefinition((String)request.getSession().getAttribute("region"));
		
		try {
			// Get the connection
			connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
			connection.setAutoCommit(false);
			progressBar.setProgressPercent(10);
			
			// First get the alert rule definition details
			
			args.add(alertRuleDeleteForm.getAlertRule());
			if (session.getAttribute("bacUserID")!=null){
				args.add((String)session.getAttribute("bacUserID"));
			}else {
				throw new IllegalStateException("Unable to get user ID from session");
			}

			alertRuleDefinition = AlertRuleDefinitionService.getAlertRuleDefinitionService().getAlertRuleDefinition(connection,failureList, args, progressBar, (String)request.getSession().getAttribute("region"));
			alertRuleDeleteForm.setAlertRuleDefinition(alertRuleDefinition);

			// Marks the transaction
			if (!alertRuleDeleteService.deleteAlertRuleDefinition(connection, failureList, alertRuleDefinition, progressBar)){
				request.setAttribute("statusMessage","Delete operation could not complete successfully");
			}else {
				request.setAttribute("statusMessage","Delete operation completed successfully");
			}
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			// If update did not occur properly then failure list would not be empty; rollback the transaction
			if (!failureList.isEmpty()){
				try {
					connection.rollback();
				}catch(SQLException sx) {
				   logger.error(RABCMessages.getMessage("ERR_SQL_ROLLBACK_EXEC") + " Exception details: " + sx.getMessage());
				   failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_ROLLBACK_EXEC"), sx));
				} 
			}else {
				// No errors; commit the transaction
				try {
					request.setAttribute("successMessage","Alert rule:" + alertRuleDefinition.getAlertRule() + " deleted successfully");
					connection.commit();
				}catch(SQLException sx) {
				   logger.error(RABCMessages.getMessage("ERR_SQL_COMMIT_EXEC") + " Exception details: " + sx.getMessage());
				   failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_COMMIT_EXEC"), sx));
				} 
			}
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		progressBar.setProgressPercent(100);
		
		/*
		 * Decide to which page you want to take the user to
		 */		
		if (!failureList.isEmpty()){
			forward = mapping.findForward("error");
		}else{
			forward = mapping.findForward("ConfirmDelete");
		}
		
		return forward;
	}
}
