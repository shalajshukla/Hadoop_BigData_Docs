/* Created by Gaurav Bhargava (GB0741) on Dec 11, 2006.
Copyright 2006-2008 AT&T Knowledge Ventures. All rights reserved. */

package com.att.bac.rabc.load.billday.calnet;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.att.bac.rabc.load.calnet.CalnetDAO;
import com.att.bac.rabc.load.calnet.CalnetDTO;
import com.att.bac.rabc.load.calnet.CalnetException;

/**
 * Data Access Object class for RABC_TOP_ADJ_BLG_AGY table.
 * It is used to perform database operation on this table.
 * @author GB0741
 */
public class RabcTopAdjBlgAgyDAO extends CalnetDAO{

	private static final String INSERT_SQL = "INSERT INTO RABC_TOP_ADJ_BLG_AGY" +
			"(RUN_DATE,DIVISION,CYCLE,AGENCY_ID,ADJ_AMT,PREV_BLG_AMT," +
			"CURR_MNTH_CHRG_AMT,CURR_BAL_DUE_AMT,BILL_RND,BILL_MM,BILL_YEAR) " +
			"VALUES(?,?,?,?,?,?,?,?,?,?,?)";

	/**
	 * Returns the insert statement used to insert a record into RABC_TOP_ADJ_BLG_AGY
	 * table.
	 * @return Returns the insert statement
	 */
	protected String getInsertSql(){
		return INSERT_SQL;
	}

	/**
	 * Reads the field values from passed DTO object and sets as corresponding
	 * parameters of the PreparedStatement
	 * @param pstmt - PreparedStatement object for setting the parameters.
	 * @param dataTransferObject - CalnetDTO for reading the field values.
	 * @throws CalnetException Throws exception when there is an error in setting
	 * the parameter.
	 */
	protected void setValues(PreparedStatement pstmt, CalnetDTO dataTransferObject)
				throws CalnetException{
		RabcTopAdjBlgAgy adjBlgAgy = (RabcTopAdjBlgAgy)dataTransferObject;
		try{
			pstmt.setDate(1, new Date(adjBlgAgy.getRunDate().getTime()));
			pstmt.setString(2, adjBlgAgy.getDivision());
			pstmt.setInt(3,adjBlgAgy.getCycle());
			pstmt.setString(4, adjBlgAgy.getAgencyID());
			pstmt.setDouble(5, adjBlgAgy.getAdjAmt());
			pstmt.setDouble(6, adjBlgAgy.getPrevBlgAmt());
			pstmt.setDouble(7, adjBlgAgy.getCurrMnthChrgAmt());
			pstmt.setDouble(8, adjBlgAgy.getCurrBalDueAmt());
			pstmt.setString(9, adjBlgAgy.getBillRnd());
			pstmt.setString(10, adjBlgAgy.getBillMm());
			pstmt.setString(11, adjBlgAgy.getBillYear());
		}catch(SQLException ex){
			throw new CalnetException("Error setting values in prepared statement: Agency ID "
								+ adjBlgAgy.getAgencyID() + ex.getMessage(), ex);
		}
	}
}
