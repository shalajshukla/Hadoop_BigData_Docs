/*
  * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

/**
 * This is a DAO that performs SELECT, INSERT and UPDATE on RABC_EXTRCT_TBL_DEF table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class ExtrctTblDefDAO {
	private static final Logger logger = Logger.getLogger(ExtrctTblDefDAO.class);

	/**
	 * Returns the list of ExtrctTblDef objects.
	 * 
	 * @param conn 
	 * @param failures
	 * @param args
	 * @param baseSQL
	 * @return List
	 */
	public List get(Connection conn, List failures, List args, String baseSQL) {
		List extrctTblDefList = null;
		ExtrctTblDef extrctTblDef = null;
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		
		try
		{
			logger.debug("Processing SELECT from RABC_EXTRCT_TBL_DEF table....");
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("ExtrctTblDefDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			logger.debug("SQL - Execution complete.");
			extrctTblDefList = new ArrayList();
			while (rs.next()) {
				extrctTblDefList.add(buildExtrctTblDef(rs));
			}
			
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return null;
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
		
		return extrctTblDefList;
	}

	/**
	 * Execute SELECT statement on RABC_EXTRCT_TBL_DEF table and returns record count
	 * @param conn
	 * @param failures
	 * @param args
	 * @param baseSQL
	 * @return
	 */
	public Long getCount(Connection conn, List failures, List args, String baseSQL) {
		Long count = null;
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		
		try
		{
			logger.debug("Processing SELECT from RABC_EXTRCT_TBL_DEF table....");
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("ExtrctTblDefDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			logger.debug("SQL - Execution complete.");
			if (rs != null && rs.next()) {
				count = new Long(rs.getLong("RECORD_COUNT"));
			} else {
				count = new Long(0);
			}
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return null;
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
		
		return count;
	}
	
	/**
	 * Private method to build ExtrctTblDef object and return it to caller.
	 * 
	 * @param rs
	 * @return ExtrctTblDef
	 * @throws SQLException
	 */
	private ExtrctTblDef buildExtrctTblDef(ResultSet rs) throws SQLException {
		ExtrctTblDef extrctTblDef = new ExtrctTblDef();
		
		extrctTblDef.setPartiRefId(rs.getInt("PARTI_REF_ID"));
		extrctTblDef.setExtrctKeyLvl(rs.getInt("EXTRCT_KEY_LVL"));
		extrctTblDef.setKey1Name(rs.getString("KEY1_NAME"));
		extrctTblDef.setKey2Name(rs.getString("KEY2_NAME"));
		extrctTblDef.setKey3Name(rs.getString("KEY3_NAME"));
		extrctTblDef.setKey4Name(rs.getString("KEY4_NAME"));
		extrctTblDef.setKey5Name(rs.getString("KEY5_NAME"));
		extrctTblDef.setExtrctItemName(rs.getString("EXTRCT_ITEM_NAME"));
		extrctTblDef.setExtrctDataCt(rs.getInt("EXTRCT_DATA_CT"));
		extrctTblDef.setExtrctDataLeftCt(rs.getInt("EXTRCT_DATA_LEFT_CT"));
		extrctTblDef.setExtrctDataRightCt(rs.getInt("EXTRCT_DATA_RIGHT_CT"));
		extrctTblDef.setExtrctData1Name(rs.getString("EXTRCT_DATA1_NAME"));
		extrctTblDef.setExtrctData2Name(rs.getString("EXTRCT_DATA2_NAME"));
		extrctTblDef.setExtrctData3Name(rs.getString("EXTRCT_DATA3_NAME"));
		extrctTblDef.setExtrctData4Name(rs.getString("EXTRCT_DATA4_NAME"));
		extrctTblDef.setExtrctData5Name(rs.getString("EXTRCT_DATA5_NAME"));
		extrctTblDef.setExtrctData6Name(rs.getString("EXTRCT_DATA6_NAME"));
		extrctTblDef.setExtrctData7Name(rs.getString("EXTRCT_DATA7_NAME"));
		extrctTblDef.setExtrctData8Name(rs.getString("EXTRCT_DATA8_NAME"));
		extrctTblDef.setExtrctData9Name(rs.getString("EXTRCT_DATA9_NAME"));
		extrctTblDef.setExtrctData10Name(rs.getString("EXTRCT_DATA10_NAME"));
		extrctTblDef.setExtrctData11Name(rs.getString("EXTRCT_DATA11_NAME"));
		extrctTblDef.setExtrctData12Name(rs.getString("EXTRCT_DATA12_NAME"));
		extrctTblDef.setExtrctData13Name(rs.getString("EXTRCT_DATA13_NAME"));
		extrctTblDef.setExtrctData14Name(rs.getString("EXTRCT_DATA14_NAME"));
		extrctTblDef.setExtrctData15Name(rs.getString("EXTRCT_DATA15_NAME"));
		return extrctTblDef;
	}

	/**
	 * Execute the insert or update statement on RABC_EXTRCT_TBL_DEF table.
	 * 
	 * @param conn
	 * @param failures
	 * @param args
	 * @param baseSQL
	 */
	public void executeUpdate(Connection conn, List failures, List args, String baseSQL) {
		int rowsUpdated = 0;
		Statement stmt = null;
		String sqlStmt = null;
		
		try
		{
			logger.debug("Processing executeUpdate on RABC_EXTRCT_TBL_DEF table....");
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("ExtrctTblDefDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rowsUpdated = stmt.executeUpdate(sqlStmt);
			logger.debug("SQL - Execution complete."+ String.valueOf(rowsUpdated) + "  rows updated");
			
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage());
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return;
		} finally {
			SQLHelper.closeStatement(stmt, failures, logger);
		}
	}

	
}
