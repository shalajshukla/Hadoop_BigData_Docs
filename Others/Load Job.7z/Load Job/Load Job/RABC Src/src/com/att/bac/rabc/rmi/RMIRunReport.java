/*
 * � 2002-2009 AT&T Intellectual Property. All rights reserved.
 */
package com.att.bac.rabc.rmi;
import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

import org.apache.log4j.Logger;

import com.att.carat.server.rmi.ITask;

/**
 * Run a RMI Report
 * 
 * @author IL3693
 * 
 */
public class RMIRunReport implements IRMIRunReport {
    public static Logger logger = Logger.getLogger(RMIRunReport.class);

    String rmiName;

    String host;

    String port;


    /**
     * @param rmiName
     * @param host
     * @param port
     */
    public RMIRunReport(String rmiName, String host, String port) {
        this.rmiName = rmiName;
        this.host = host;
        this.port = port;
    }


    /**
     * Lookup the request and execute it
     */
    public void run() {
        try {
            ITask ro = getTask();
            if (ro != null) {
                ro.execute();
            }
            logger.info(RMIUtil.findObjectURL(rmiName, host, port) + " remotely called.");
        } catch (Exception e) {
            logger.error(toString(), e);
        }
    }


    /**
     * Poke the RMI Job to start processing reports
     */
    public void runAsThread() {
        new Thread(this).start();
    }


    /**
     * Find the associated {@link ITask}
     * 
     * @return
     * @throws MalformedURLException
     * @throws RemoteException
     * @throws NotBoundException
     */
    public ITask getTask() throws MalformedURLException, RemoteException, NotBoundException {
        ITask ro = (ITask) RMIUtil.findObject(rmiName, host, port);
        return ro;
    }


    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return RMIUtil.findObjectURL(rmiName, host, port);
    }
}
