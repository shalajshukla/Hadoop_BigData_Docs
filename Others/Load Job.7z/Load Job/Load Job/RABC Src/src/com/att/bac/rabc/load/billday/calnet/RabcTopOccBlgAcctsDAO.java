/* Created by Prachi Chhabra (PC2774) on Dec 8, 2006.
Copyright 2006-2008 AT&T Knowledge Ventures. All rights reserved.

*/package com.att.bac.rabc.load.billday.calnet;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.att.bac.rabc.load.calnet.CalnetDAO;
import com.att.bac.rabc.load.calnet.CalnetDTO;
import com.att.bac.rabc.load.calnet.CalnetException;

/**
 * Data Access Object class for RABC_TOP_ADJ_BLG_ACCTS table.
 * It is used to perform database operation on this table.
 * @author PC2774
 */
public class RabcTopOccBlgAcctsDAO extends CalnetDAO {

	private static final String INSERT_SQL = "INSERT INTO RABC_TOP_OCC_BLG_ACCTS(RUN_DATE,DIVISION," +
			"CYCLE,BTN,AGENCY_ID,OCC_AMT,PREV_BLG_AMT,CURR_MNTH_CHRG_AMT,CURR_BAL_DUE_AMT,BILL_RND," +
			"BILL_MM,BILL_YEAR) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";

	/**
	 *@return Returns the insert statement used to insert a record into RABC_TOP_OCC_BLG_ACCTS table.
	 */
	protected String getInsertSql(){
		return INSERT_SQL;
	}

	/**
	 * Reads the field values from passed DTO object and sets as corresponding parameters of the PreparedStatement
	 * @param pstmt - PreparedStatement object for setting the parameters.
	 * @param dataTransferObject - CalnetDTO for reading the field values.
	 * @throws CalnetException Throws exception when there is an error in setting the parameter.
	 */
	protected void setValues(PreparedStatement pstmt, CalnetDTO dataTransferObject)
		throws CalnetException{
		RabcTopOccBlgAcct acct = (RabcTopOccBlgAcct)dataTransferObject;
		try{
			pstmt.setDate(1, new Date(acct.getRunDate().getTime()));
			pstmt.setString(2, acct.getDivision());
			pstmt.setInt(3,acct.getCycle());
			pstmt.setString(4, acct.getBtn());
			pstmt.setString(5,acct.getAgencyId());
			pstmt.setDouble(6, acct.getOccAmt());
			pstmt.setDouble(7, acct.getPrevBlgAmt());
			pstmt.setDouble(8, acct.getCurrMnthChrgAmt());
			pstmt.setDouble(9, acct.getCurrBalDueAmt());
			pstmt.setString(10, acct.getBillRnd());
			pstmt.setString(11, acct.getBillMm());
			pstmt.setString(12, acct.getBillYear());

		}catch(SQLException ex){
			throw new CalnetException("Error setting values in prepared statement: BTN "
											+ acct.getBtn() + ex.getMessage(), ex);
		}
	}
}
