/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.admin.adhoc.rpt;

import java.util.ArrayList;
import java.util.List;
/**
 * Module description: 
 * 
 * This is an adhoc report step 3 object used to hold the fields on step3.
 *
 * @author Umesh Deole- UD7153
 */
public class AdhocReportStep3 {
	
	private int alertKeyLevel; // 1-5
	private String level1ColumnHeaderName;
	private String level1MouseOverDescription;
	private String level1ReportLink;
	
	private String level2ColumnHeaderName;
	private String level2MouseOverDescription; 
	private String level2ReportLink;
	
	private String level3ColumnHeaderName;
	private String level3MouseOverDescription;
	private String level3ReportLink;
	
	private String level4ColumnHeaderName;
	private String level4MouseOverDescription;
	private String level4ReportLink;
	
	private String level5ColumnHeaderName;
	private String level5MouseOverDescription;
	private String level5ReportLink;
	
	private int subTotalKeyLevelFrom ; // Subtotal key level from 
	private int subTotalKeyLevelTo ; // Subtotal key level to  
	private String key1HeaderDesc ;// Header Description for Key 1 
	private String fileSequenceIndicator="N";
	private String isFileSequenceIndicatorDisabled="N";
	private String isLayout1Disabled="N";
	private String isLayout2Disabled="N";
	private String isLayout3Disabled="N";
	private String isLayout4Disabled="N";
	private String isReportDurationDisabled="N";
	
	private int selectedLayout=1;
	private String reportDurationTime;

	private List alertKeyLevelList = new ArrayList();	
	private List tableList = new ArrayList();	
	private List mouseOverList = new ArrayList();	
	private List reportDurationList = new ArrayList();	
	private List reportLinkList = new ArrayList();
	
	
	//adhockeyList contains key1,key2,key3,key4,key5 in the 3rd step of adhoc report definition
	private List adhockeyList = new ArrayList();   // 

	/**
	 * @return Returns the reportLinkList.
	 */
	public List getReportLinkList() {
		return reportLinkList;
	}
	/**
	 * @param reportLinkList The reportLinkList to set.
	 */
	public void setReportLinkList(List reportLinkList) {
		this.reportLinkList = reportLinkList;
	}
	/**
	 * @return Returns the level1ReportLink.
	 */
	public String getLevel1ReportLink() {
		return level1ReportLink;
	}
	/**
	 * @param level1ReportLink The level1ReportLink to set.
	 */
	public void setLevel1ReportLink(String level1ReportLink) {
		this.level1ReportLink = level1ReportLink;
	}
	/**
	 * @return Returns the level2ReportLink.
	 */
	public String getLevel2ReportLink() {
		return level2ReportLink;
	}
	/**
	 * @param level2ReportLink The level2ReportLink to set.
	 */
	public void setLevel2ReportLink(String level2ReportLink) {
		this.level2ReportLink = level2ReportLink;
	}
	/**
	 * @return Returns the level3ReportLink.
	 */
	public String getLevel3ReportLink() {
		return level3ReportLink;
	}
	/**
	 * @param level3ReportLink The level3ReportLink to set.
	 */
	public void setLevel3ReportLink(String level3ReportLink) {
		this.level3ReportLink = level3ReportLink;
	}
	/**
	 * @return Returns the level4ReportLink.
	 */
	public String getLevel4ReportLink() {
		return level4ReportLink;
	}
	/**
	 * @param level4ReportLink The level4ReportLink to set.
	 */
	public void setLevel4ReportLink(String level4ReportLink) {
		this.level4ReportLink = level4ReportLink;
	}
	/**
	 * @return Returns the level5ReportLink.
	 */
	public String getLevel5ReportLink() {
		return level5ReportLink;
	}
	/**
	 * @param level5ReportLink The level5ReportLink to set.
	 */
	public void setLevel5ReportLink(String level5ReportLink) {
		this.level5ReportLink = level5ReportLink;
	}
	/**
	 * @return Returns the isLayout1Disabled.
	 */
	public String getIsLayout1Disabled() {
		return isLayout1Disabled;
	}
	/**
	 * @param isLayout1Disabled The isLayout1Disabled to set.
	 */
	public void setIsLayout1Disabled(String isLayout1Disabled) {
		this.isLayout1Disabled = isLayout1Disabled;
	}
	/**
	 * @return Returns the isLayout2Disabled.
	 */
	public String getIsLayout2Disabled() {
		return isLayout2Disabled;
	}
	/**
	 * @param isLayout2Disabled The isLayout2Disabled to set.
	 */
	public void setIsLayout2Disabled(String isLayout2Disabled) {
		this.isLayout2Disabled = isLayout2Disabled;
	}
	/**
	 * @return Returns the isLayout4Disabled.
	 */
	public String getIsLayout4Disabled() {
		return isLayout4Disabled;
	}
	/**
	 * @param isLayout4Disabled The isLayout4Disabled to set.
	 */
	public void setIsLayout4Disabled(String isLayout4Disabled) {
		this.isLayout4Disabled = isLayout4Disabled;
	}
	/**
	 * @return Returns the isReportDurationDisabled.
	 */
	public String getIsReportDurationDisabled() {
		return isReportDurationDisabled;
	}
	/**
	 * @param isReportDurationDisabled The isReportDurationDisabled to set.
	 */
	public void setIsReportDurationDisabled(String isReportDurationDisabled) {
		this.isReportDurationDisabled = isReportDurationDisabled;
	}
	/**
	 * @return Returns the isLayout3Disabled.
	 */
	public String getIsLayout3Disabled() {
		return isLayout3Disabled;
	}
	/**
	 * @param isLayout3Disabled The isLayout3Disabled to set.
	 */
	public void setIsLayout3Disabled(String isLayout3Disabled) {
		this.isLayout3Disabled = isLayout3Disabled;
	}
	/**
	 * @return Returns the isFileSequenceIndicatorDisabled.
	 */
	public String getIsFileSequenceIndicatorDisabled() {
		return isFileSequenceIndicatorDisabled;
	}
	/**
	 * @param isFileSequenceIndicatorDisabled The isFileSequenceIndicatorDisabled to set.
	 */
	public void setIsFileSequenceIndicatorDisabled(
			String isFileSequenceIndicatorDisabled) {
		this.isFileSequenceIndicatorDisabled = isFileSequenceIndicatorDisabled;
	}
	/**
	 * @return Returns the fileSequenceIndicator.
	 */
	public String getFileSequenceIndicator() {
		return fileSequenceIndicator;
	}
	/**
	 * @param fileSequenceIndicator The fileSequenceIndicator to set.
	 */
	public void setFileSequenceIndicator(String fileSequenceIndicator) {
		this.fileSequenceIndicator = fileSequenceIndicator;
	}
	
	/**
	 * @return Returns the adhockeyList.
	 */
	public AdhocKey retrieveAdhockeyList(int i) {
		return ((AdhocKey)adhockeyList.get(i));
	}
	/**
	 * @param adhockeyList The adhockeyList to set.
	 */
	public void addAdhockeyList(AdhocKey keyVal) {
		this.adhockeyList.add(keyVal);
	}
	
	/**
	 * @return Returns the reportDurationList.
	 */
	public List getReportDurationList() {
		return reportDurationList;
	}
	/**
	 * @param reportDurationList The reportDurationList to set.
	 */
	public void setReportDurationList(List reportDurationList) {
		this.reportDurationList = reportDurationList;
	}
	/**
	 * @return Returns the mouseOverList.
	 */
	public List getMouseOverList() {
		return mouseOverList;
	}
	/**
	 * @param mouseOverList The mouseOverList to set.
	 */
	public void setMouseOverList(List mouseOverList) {
		this.mouseOverList = mouseOverList;
	}
	/**
	 * @return Returns the alertKeyLevelList.
	 */
	public List getAlertKeyLevelList() {
		return alertKeyLevelList;
	}
	/**
	 * @param alertKeyLevelList The alertKeyLevelList to set.
	 */
	public void setAlertKeyLevelList(List alertKeyLevelList) {
		this.alertKeyLevelList = alertKeyLevelList;
	}
	/**
	 * @return Returns the tableList.
	 */
	public List getTableList() {
		return tableList;
	}
	/**
	 * @param tableList The tableList to set.
	 */
	public void setTableList(List tableList) {
		this.tableList = tableList;
	}
	/**
	 * @return Returns the alertKeyLevel.
	 */
	public int getAlertKeyLevel() {
		return alertKeyLevel;
	}
	/**
	 * @param alertKeyLevel The alertKeyLevel to set.
	 */
	public void setAlertKeyLevel(int alertKeyLevel) {
		this.alertKeyLevel = alertKeyLevel;
	}
	
	/**
	 * @return Returns the key1HeaderDesc.
	 */
	public String getKey1HeaderDesc() {
		return key1HeaderDesc;
	}
	/**
	 * @param key1HeaderDesc The key1HeaderDesc to set.
	 */
	public void setKey1HeaderDesc(String key1HeaderDesc) {
		this.key1HeaderDesc = key1HeaderDesc;
	}
	/**
	 * @return Returns the reportDurationTime.
	 */
	public String getReportDurationTime() {
		return reportDurationTime;
	}
	/**
	 * @param reportDurationTime The reportDurationTime to set.
	 */
	public void setReportDurationTime(String reportDurationTime) {
		this.reportDurationTime = reportDurationTime;
	}
	/**
	 * @return Returns the selectedLayout.
	 */
	public int getSelectedLayout() {
		return selectedLayout;
	}
	/**
	 * @param selectedLayout The selectedLayout to set.
	 */
	public void setSelectedLayout(int selectedLayout) {
		this.selectedLayout = selectedLayout;
	}
	/**
	 * @return Returns the subTotalKeyLevelFrom.
	 */
	public int getSubTotalKeyLevelFrom() {
		return subTotalKeyLevelFrom;
	}
	/**
	 * @param subTotalKeyLevelFrom The subTotalKeyLevelFrom to set.
	 */
	public void setSubTotalKeyLevelFrom(int subTotalKeyLevelFrom) {
		this.subTotalKeyLevelFrom = subTotalKeyLevelFrom;
	}
	/**
	 * @return Returns the subTotalKeyLevelTo.
	 */
	public int getSubTotalKeyLevelTo() {
		return subTotalKeyLevelTo;
	}
	/**
	 * @param subTotalKeyLevelTo The subTotalKeyLevelTo to set.
	 */
	public void setSubTotalKeyLevelTo(int subTotalKeyLevelTo) {
		this.subTotalKeyLevelTo = subTotalKeyLevelTo;
	}
	
	
	
	
	
	/**
	 * @return Returns the level1ColumnHeaderName.
	 */
	public String getLevel1ColumnHeaderName() {
		return level1ColumnHeaderName;
	}
	/**
	 * @param level1ColumnHeaderName The level1ColumnHeaderName to set.
	 */
	public void setLevel1ColumnHeaderName(String level1ColumnHeaderName) {
		this.level1ColumnHeaderName = level1ColumnHeaderName;
	}
	/**
	 * @return Returns the level1MouseOverDescription.
	 */
	public String getLevel1MouseOverDescription() {
		return level1MouseOverDescription;
	}
	/**
	 * @param level1MouseOverDescription The level1MouseOverDescription to set.
	 */
	public void setLevel1MouseOverDescription(String level1MouseOverDescription) {
		this.level1MouseOverDescription = level1MouseOverDescription;
	}
	/**
	 * @return Returns the level2ColumnHeaderName.
	 */
	public String getLevel2ColumnHeaderName() {
		return level2ColumnHeaderName;
	}
	/**
	 * @param level2ColumnHeaderName The level2ColumnHeaderName to set.
	 */
	public void setLevel2ColumnHeaderName(String level2ColumnHeaderName) {
		this.level2ColumnHeaderName = level2ColumnHeaderName;
	}
	/**
	 * @return Returns the level2MouseOverDescription.
	 */
	public String getLevel2MouseOverDescription() {
		return level2MouseOverDescription;
	}
	/**
	 * @param level2MouseOverDescription The level2MouseOverDescription to set.
	 */
	public void setLevel2MouseOverDescription(String level2MouseOverDescription) {
		this.level2MouseOverDescription = level2MouseOverDescription;
	}
	/**
	 * @return Returns the level3ColumnHeaderName.
	 */
	public String getLevel3ColumnHeaderName() {
		return level3ColumnHeaderName;
	}
	/**
	 * @param level3ColumnHeaderName The level3ColumnHeaderName to set.
	 */
	public void setLevel3ColumnHeaderName(String level3ColumnHeaderName) {
		this.level3ColumnHeaderName = level3ColumnHeaderName;
	}
	/**
	 * @return Returns the level3MouseOverDescription.
	 */
	public String getLevel3MouseOverDescription() {
		return level3MouseOverDescription;
	}
	/**
	 * @param level3MouseOverDescription The level3MouseOverDescription to set.
	 */
	public void setLevel3MouseOverDescription(String level3MouseOverDescription) {
		this.level3MouseOverDescription = level3MouseOverDescription;
	}
	/**
	 * @return Returns the level4ColumnHeaderName.
	 */
	public String getLevel4ColumnHeaderName() {
		return level4ColumnHeaderName;
	}
	/**
	 * @param level4ColumnHeaderName The level4ColumnHeaderName to set.
	 */
	public void setLevel4ColumnHeaderName(String level4ColumnHeaderName) {
		this.level4ColumnHeaderName = level4ColumnHeaderName;
	}
	/**
	 * @return Returns the level4MouseOverDescription.
	 */
	public String getLevel4MouseOverDescription() {
		return level4MouseOverDescription;
	}
	/**
	 * @param level4MouseOverDescription The level4MouseOverDescription to set.
	 */
	public void setLevel4MouseOverDescription(String level4MouseOverDescription) {
		this.level4MouseOverDescription = level4MouseOverDescription;
	}
	/**
	 * @return Returns the level5ColumnHeaderName.
	 */
	public String getLevel5ColumnHeaderName() {
		return level5ColumnHeaderName;
	}
	/**
	 * @param level5ColumnHeaderName The level5ColumnHeaderName to set.
	 */
	public void setLevel5ColumnHeaderName(String level5ColumnHeaderName) {
		this.level5ColumnHeaderName = level5ColumnHeaderName;
	}
	/**
	 * @return Returns the level5MouseOverDescription.
	 */
	public String getLevel5MouseOverDescription() {
		return level5MouseOverDescription;
	}
	/**
	 * @param level5MouseOverDescription The level5MouseOverDescription to set.
	 */
	public void setLevel5MouseOverDescription(String level5MouseOverDescription) {
		this.level5MouseOverDescription = level5MouseOverDescription;
	}
	/**
	 * @return Returns the adhockeyList.
	 */
	public List getAdhockeyList() {
		return adhockeyList;
	}
	/**
	 * @param adhockeyList The adhockeyList to set.
	 */
	public void setAdhockeyList(List adhockeyList) {
		this.adhockeyList = adhockeyList;
	}
}
