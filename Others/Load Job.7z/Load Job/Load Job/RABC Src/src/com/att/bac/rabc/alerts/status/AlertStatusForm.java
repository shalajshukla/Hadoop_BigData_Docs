/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.alerts.status;

import java.util.ArrayList;
import java.util.List;

import com.att.bac.rabc.PickList;
import com.att.bac.rabc.SortedForm;

/**
 * This is an action form to represent the Alert Status Update page and Alert Comments History page.
 * This is actualy a sub class of SortedForm which extends the PagedForm which in turn extends the ActionForm.
 * 
 * @author Abhilash - AC6952
 */
public class AlertStatusForm extends SortedForm {
	private String popupPage = "N";
	private String alertStatus;
	private List alertStatusList = new ArrayList();
	private String revenueImpactValue;
	private String lostRevenueImpactValue;
	private String[] rootCauseCategories;
	private List rootCauseCategoryList = new ArrayList();
	private String rootCause;
	private String comments;	
	private String fromPage;
	private List alertReportDetailList = new ArrayList();
	private int totalAlerts;
	private String updateAccess;
	private String statusColor = "#0059B3";
	
	private List alertCommentList = new ArrayList();
	private int totalComments;
	
	/**
	 * Default constructor which sets the default sort item, sort order and previous sort item.
	 */
	public AlertStatusForm() {
		this.setPreviousSortItem("time_stamp");
		this.setSortItem("time_stamp");
		this.setSortOrder("DESC");
	}
	
	/**
	 * @return Returns the popupPage.
	 */
	public String getPopupPage() {
		return popupPage;
	}
	/**
	 * @param popupPage The popupPage to set.
	 */
	public void setPopupPage(String popupPage) {
		this.popupPage = popupPage;
	}
	/**
	 * @return Returns the alertReportDetailList.
	 */
	public List getAlertReportDetailList() {
		return alertReportDetailList;
	}
	/**
	 * @param alertReportDetail The alertReportDetail to add.
	 */
	public void addAlertReportDetail(AlertReportDetail alertReportDetail) {
		this.alertReportDetailList.add(alertReportDetail);
	}
	/**
	 * @return Returns the totalAlerts.
	 */
	public int getTotalAlerts() {
		return totalAlerts;
	}
	/**
	 * @param totalAlerts The totalAlerts to set.
	 */
	public void setTotalAlerts(int totalAlerts) {
		this.totalAlerts = totalAlerts;
	}
	/**
	 * @return Returns the alertStatus.
	 */
	public String getAlertStatus() {
		return alertStatus;
	}
	/**
	 * @param alertStatus The alertStatus to set.
	 */
	public void setAlertStatus(String alertStatus) {
		this.alertStatus = alertStatus;
	}
	/**
	 * @return Returns the alertStatusList.
	 */
	public List getAlertStatusList() {
		return alertStatusList;
	}
	/**
	 * @param alertStatusList The alertStatusList to add.
	 */
	public void addAlertStatus(PickList alertStatus) {
		this.alertStatusList.add(alertStatus);
	}
	/**
	 * @return Returns the comments.
	 */
	public String getComments() {
		return comments;
	}
	/**
	 * @param comments The comments to set.
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}
	/**
	 * @return Returns the revenueImpactValue.
	 */
	public String getRevenueImpactValue() {
		return revenueImpactValue;
	}
	/**
	 * @param revenueImpactValue The revenueImpactValue to set.
	 */
	public void setRevenueImpactValue(String revenueImpactValue) {
		this.revenueImpactValue = revenueImpactValue;
	}
	/**
	 * @return Returns the rootCause.
	 */
	public String getRootCause() {
		return rootCause;
	}
	/**
	 * @param rootCause The rootCause to set.
	 */
	public void setRootCause(String rootCause) {
		this.rootCause = rootCause;
	}
	/**
	 * @return Returns the rootCauseCategories.
	 */
	public String[] getRootCauseCategories() {
		return rootCauseCategories;
	}
	/**
	 * @param rootCauseCategory The rootCauseCategories to set.
	 */
	public void setRootCauseCategories(String[] rootCauseCategories) {
		this.rootCauseCategories = rootCauseCategories;
	}
	/**
	 * @return Returns the rootCauseCategoryList.
	 */
	public List getRootCauseCategoryList() {
		return rootCauseCategoryList;
	}
	/**
	 * @param rootCauseCategoryList The rootCauseCategoryList to add.
	 */
	public void addRootCauseCategory(RootCategory rootCauseCategory) {
		this.rootCauseCategoryList.add(rootCauseCategory);
	}
	/**
	 * @return Returns the alertCommentList.
	 */
	public List getAlertCommentList() {
		return alertCommentList;
	}
	/**
	 * @param alertComment The alertCommentt to add.
	 */
	public void addAlertComment(AlertComment alertComment) {
		this.alertCommentList.add(alertComment);
	}
	/**
	 * @return Returns the totalComments.
	 */
	public int getTotalComments() {
		return totalComments;
	}
	/**
	 * @param totalComments The totalComments to set.
	 */
	public void setTotalComments(int totalComments) {
		this.totalComments = totalComments;
	}
	/**
	 * @return Returns the updateAccess.
	 */
	public String getUpdateAccess() {
		return updateAccess;
	}
	/**
	 * @param updateAccess The updateAccess to set.
	 */
	public void setUpdateAccess(String updateAccess) {
		this.updateAccess = updateAccess;
	}
	/**
	 * @return Returns the fromPage.
	 */
	public String getFromPage() {
		return fromPage;
	}
	/**
	 * @param fromPage The fromPage to set.
	 */
	public void setFromPage(String fromPage) {
		this.fromPage = fromPage;
	}
	/**
	 * @return Returns the lostRevenueImpactValue.
	 */
	public String getLostRevenueImpactValue() {
		return lostRevenueImpactValue;
	}
	/**
	 * @param lostRevenueImpactValue The lostRevenueImpactValue to set.
	 */
	public void setLostRevenueImpactValue(String lostRevenueImpactValue) {
		this.lostRevenueImpactValue = lostRevenueImpactValue;
	}
	/**
	 * @return Returns the statusColor.
	 */
	public String getStatusColor() {
		return statusColor;
	}
	/**
	 * @param statusColor The statusColor to set.
	 */
	public void setStatusColor(String statusColor) {
		this.statusColor = statusColor;
	}
}
