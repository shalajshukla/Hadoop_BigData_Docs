/*
 * Created on Feb 22, 2006
 *
 * Copyright 2006-2008 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.messages;



/**
 * @author pf7941
 */
public class AuditorMessage {

//    public static final int MSG_ID = 0;
//    public static final int TIME_STAMP = 1;
//    public static final int AUDITOR = 2;
    
    private int presnId;
    private String message;
  //  private Date timeStamp;
//    private boolean read;
    private String tblName;
    private String status;

    public AuditorMessage() {
    }

    public AuditorMessage(String tblName, String message, String status) {
        this.tblName = tblName;
        this.message = message;
        this.status = status;
//        this.read = read;
//        this.timeStamp = timeStamp;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String string) {
        message = string;
    }

	public String getTblName() {
		return tblName;
	}

	public void setTblName(String tblName) {
		this.tblName = tblName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

//    public int getMessageId() {
//        return messageId;
//    }
//
//    public void setMessageId(int i) {
//        messageId = i;
//    }
//
//    public String getAuditor() {
//        return id;
//    }
//
//    public void setAuditor(String string) {
//        id = string;
//    }
//
//    public boolean isRead() {
//        return read;
//    }
//
//    public void setRead(boolean read) {
//        this.read = read;
//    }
//
//    public Date getTimeStamp() {
//        return timeStamp;
//    }
//
//    public void setTimeStamp(Date date) {
//        timeStamp = date;
//    }

}
