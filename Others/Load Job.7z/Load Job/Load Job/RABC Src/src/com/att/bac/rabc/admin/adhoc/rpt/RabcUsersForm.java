/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.admin.adhoc.rpt;

import java.util.ArrayList;
import java.util.List;

import org.apache.struts.action.ActionForm;

/**
* Module description: 
* Struts Form for the RABC users popup 
* @author Anup Thomas - AT1862
*/
public class RabcUsersForm extends ActionForm{

	List rabcUsersList = new ArrayList();
	
	/**
	 * @return Returns the rabcUsersList.
	 */
	public List getRabcUsersList() {
		return rabcUsersList;
	}
	/**
	 * @param rabcUsersList The rabcUsersList to set.
	 */
	public void setRabcUsersList(List rabcUsersList) {
		this.rabcUsersList = rabcUsersList;
	}
}
