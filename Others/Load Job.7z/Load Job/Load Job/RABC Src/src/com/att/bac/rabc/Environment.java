/* Component Name: RABCPPG000xx
 * Module Name: Environment.java
 * Created on Feb 1, 2006
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.log4j.Logger;

/**
 * @author js3175
 *
 * This is the java class for pulling in the environment variables.
 */
public class Environment {
    private static Logger logger = Logger.getLogger(Environment.class);
    private static Environment instance = new Environment();
    
    private Context env = null;
    
    private Environment() {
        try {
            env = (Context)new InitialContext().lookup("java:/comp/env");
        } catch(NamingException ne){
            logger.warn("Unable to create initial context: "+ne.getMessage(),ne);
        }
    }
    
    public static synchronized Environment getInstance() {
        if(instance==null){
            instance = new Environment();
        }
        return instance;
    }
    
    public Object lookup(String var){
        Object result = null;
        if(env!=null){
            try {
                synchronized(env){
                    result = env.lookup(var);
                }
            } catch(NamingException ne){
                logger.warn("Unable to look up "+var+": "+ne.getMessage(),ne);
                result = null;
            }
        }
        return result;
    }
}
