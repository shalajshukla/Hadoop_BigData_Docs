/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.admin.alert.rule;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.ArrayList;
import java.text.MessageFormat;

import org.apache.log4j.Logger;

import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.RABCException;

/**
 * This is a DAO that performs SELECT, INSERT and UPDATE on RABC_EXTRCT_BUILD_RULE table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class ExtractBuildRuleDAO {
	private static final Logger logger = Logger.getLogger(ExtractBuildRuleDAO .class);

	/**
	 * Returns the list of ExtractBuildRule objects.
	 * 
	 * @param conn 
	 * @param failures
	 * @param args
	 * @param baseSQL
	 * @return List
	 */
	public List get(Connection conn, List failures, List args, String baseSQL) {
		List extractBuildRuleList = null;
		ExtractBuildRule extractBuildRule = null;
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		
		try
		{
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("ExtractBuildRuleDAO  - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			extractBuildRuleList = new ArrayList();
			while (rs.next()) {
				extractBuildRuleList.add(buildExtractBuildRule(rs));
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return null;
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
		
		return extractBuildRuleList;
	}

	/**
	 * Private method to build ExtractBuildRule object and return it to caller.
	 * 
	 * @param rs
	 * @return ExtractBuildRule
	 * @throws SQLException
	 */
	private ExtractBuildRule buildExtractBuildRule(ResultSet rs) throws SQLException {
		ExtractBuildRule extractBuildRule = new ExtractBuildRule();
		
		extractBuildRule.setPartiRefId(rs.getInt("PARTI_REF_ID"));
		extractBuildRule.setExtrctType(rs.getString("EXTRCT_TYPE"));
		extractBuildRule.setExtrctRndupInd(rs.getString("EXTRCT_RNDUP_IND"));
		extractBuildRule.setExtrctItemName(rs.getString("EXTRCT_ITEM_NAME"));
		extractBuildRule.setExtrctToTbl(rs.getString("EXTRCT_TO_TBL"));
		extractBuildRule.setFileItem1Name(rs.getString("FILE_ITEM1_NAME"));
		extractBuildRule.setExtrctItem1Name(rs.getString("EXTRCT_ITEM1_NAME"));
		extractBuildRule.setFileItem2Name(rs.getString("FILE_ITEM2_NAME"));
		extractBuildRule.setExtrctItem2Name(rs.getString("EXTRCT_ITEM2_NAME"));
		extractBuildRule.setFileItem3Name(rs.getString("FILE_ITEM3_NAME"));
		extractBuildRule.setExtrctItem3Name(rs.getString("EXTRCT_ITEM3_NAME"));
		extractBuildRule.setFileItem4Name(rs.getString("FILE_ITEM4_NAME"));
		extractBuildRule.setExtrctItem4Name(rs.getString("EXTRCT_ITEM4_NAME"));
		extractBuildRule.setFileItem5Name(rs.getString("FILE_ITEM5_NAME"));
		extractBuildRule.setExtrctItem5Name(rs.getString("EXTRCT_ITEM5_NAME"));
		extractBuildRule.setFileItem6Name(rs.getString("FILE_ITEM6_NAME"));
		extractBuildRule.setExtrctItem6Name(rs.getString("EXTRCT_ITEM6_NAME"));
		extractBuildRule.setFileItem7Name(rs.getString("FILE_ITEM7_NAME"));
		extractBuildRule.setExtrctItem7Name(rs.getString("EXTRCT_ITEM7_NAME"));
		extractBuildRule.setFileItem8Name(rs.getString("FILE_ITEM8_NAME"));
		extractBuildRule.setExtrctItem8Name(rs.getString("EXTRCT_ITEM8_NAME"));
		extractBuildRule.setFileItem9Name(rs.getString("FILE_ITEM9_NAME"));
		extractBuildRule.setExtrctItem9Name(rs.getString("EXTRCT_ITEM9_NAME"));
		extractBuildRule.setExtrctItem1CalcInd(rs.getString("EXTRCT_ITEM1_CALC_IND"));
		extractBuildRule.setExtrctItem2CalcInd(rs.getString("EXTRCT_ITEM2_CALC_IND"));
		extractBuildRule.setExtrctItem3CalcInd(rs.getString("EXTRCT_ITEM3_CALC_IND"));
		extractBuildRule.setExtrctItem4CalcInd(rs.getString("EXTRCT_ITEM4_CALC_IND"));
		extractBuildRule.setExtrctItem5CalcInd(rs.getString("EXTRCT_ITEM5_CALC_IND"));
		extractBuildRule.setExtrctItem6CalcInd(rs.getString("EXTRCT_ITEM6_CALC_IND"));
		extractBuildRule.setExtrctItem7CalcInd(rs.getString("EXTRCT_ITEM7_CALC_IND"));
		extractBuildRule.setExtrctItem8CalcInd(rs.getString("EXTRCT_ITEM8_CALC_IND"));
		extractBuildRule.setExtrctItem9CalcInd(rs.getString("EXTRCT_ITEM9_CALC_IND"));
		return extractBuildRule;
	}

	/**
	 * Execute the insert or update statement on RABC_EXTRCT_BUILD_RULE table.
	 * 
	 * @param conn
	 * @param failures
	 * @param args
	 * @param baseSQL
	 */
	public void executeUpdate(Connection conn, List failures, List args, String baseSQL) {
		int rowsUpdated = 0;
		Statement stmt = null;
		String sqlStmt = null;
		
		try
		{
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("ExtractBuildRuleDAO  - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rowsUpdated = stmt.executeUpdate(sqlStmt);
			logger.debug("SQL - Execution complete."+ String.valueOf(rowsUpdated) + "  rows updated");
			
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return;
		} finally {
			SQLHelper.closeStatement(stmt, failures, logger);
		}
	}

}
