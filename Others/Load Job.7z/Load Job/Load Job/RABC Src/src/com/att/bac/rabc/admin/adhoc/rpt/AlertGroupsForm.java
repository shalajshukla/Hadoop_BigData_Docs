/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/

package com.att.bac.rabc.admin.adhoc.rpt;

import java.util.ArrayList;
import java.util.List;

import org.apache.struts.action.ActionForm;

import com.att.bac.rabc.PickList;

/**
 * Module description: 
 * Struts Form for the Alert Groups action
 * @author Anup Thomas - AT1862
 */
public class AlertGroupsForm extends ActionForm  {
	List alertGroupList = new ArrayList();

	/**
	 * @return Returns the alertGroupList.
	 */
	public List getAlertGroupList() {
		return alertGroupList;
	}
	/**
	 * @param alertGroupList The alertGroupList to set.
	 */
	public void addAlertGroup(PickList alertGroup) {
		this.alertGroupList.add(alertGroup);
	}
}
