package com.att.bac.rabc.adhoc.rpt;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;

public class AdhocBackgroundReportDetailsDAO {
	private static final Logger logger = Logger.getLogger(AdhocBackgroundReportDetailsDAO.class);
	
	
	public void getAdhocBackgroundReportDetails(Connection connection, List failureList, AdhocBackgroundReportDetailsForm detailsForm, String tableNode, int reportNum) {
		

		String sql = "select PRESN_ID, SUB_RPT_TM, START_DATE, END_DATE, DIVISION_CD, KEY_LVL_NBR, RPT_TIME_IND, RPT_MONTH, " +
					 " RPT_YEAR, CYCLE_BILLED, USER_ID, STATUS_CD, NOTES_TXT, ROWS_RETURNED_NBR, PROCESS_START_TM, PROCESS_END_TM, PROCESSING_TM " +
					 " FROM RABC_BKGRND_RPT WHERE BKGRND_RPT_NBR = ?";

		
		PreparedStatement ps = null;
		ResultSet rs	= null;
		ArrayList<String> columnNamesList = new ArrayList<String>();
		ArrayList<String> columnValuesList = new ArrayList<String>();
		//get all the keys info
		ResultSet keysRs = null;   
		keysRs = getAdhocBackgroundReportDetailsKeys(connection, failureList, tableNode, reportNum);
		
		String sValue="";
		 try {
			ps = connection.prepareStatement(sql);
		    ps.setInt(1,reportNum);
			rs = ps.executeQuery();
			if(rs.next()){
				if ((detailsForm.getReportName()!=null)&&(!detailsForm.getReportName().equals(""))) {
					columnNamesList.add("Report Name:");
					columnValuesList.add(detailsForm.getReportName());
				}
				
				sValue = rs.getString("NOTES_TXT");
				if (sValue==null){
					sValue ="";
				}
				detailsForm.setNotes(sValue);
				
				DateFormat date_formatter = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
				Date date = rs.getTimestamp("SUB_RPT_TM");
				if (date!=null) {
					columnNamesList.add("Time Submitted:");
					columnValuesList.add(date_formatter.format(date));
				}
				
				sValue = rs.getString("START_DATE");
				if (sValue!=null && !sValue.equals("")) {
					columnNamesList.add("Start Date:");
					if (sValue.length()>10) {
						sValue =  sValue.substring(5, 7) + "/" + sValue.substring(8, 10) + "/" + sValue.substring(0,4);
						columnValuesList.add(sValue);
					}
				}
				
				sValue = rs.getString("END_DATE");
				if (sValue!=null && !sValue.equals("")) {
					columnNamesList.add("End Date:");
					if (sValue.length()>10) {
						sValue =  sValue.substring(5, 7) + "/" + sValue.substring(8, 10) + "/" + sValue.substring(0,4);
						columnValuesList.add(sValue);
					}
				}
				
				//store all the keys info
				int presnId = rs.getInt("PRESN_ID");
				int divisionKeyLvl = getDivisionKeyLvl(connection, presnId, failureList, tableNode);
				getKeyInfoInArrayList(connection, keysRs, columnNamesList, columnValuesList, divisionKeyLvl, failureList, tableNode);
				
				sValue = rs.getString("RPT_MONTH");
				if (sValue!=null && !sValue.equals("") & !sValue.equals("0")) {
					columnNamesList.add("Report Month:");
					columnValuesList.add(sValue);
				}
				
				sValue = rs.getString("RPT_YEAR");
				if (sValue!=null && !sValue.equals("") & !sValue.equals("0")) {
					columnNamesList.add("Report Year:");
					columnValuesList.add(sValue);
				}
				
				sValue = rs.getString("CYCLE_BILLED");
				if (sValue!=null && !sValue.equals("")) {
					columnNamesList.add("Cycle Billed:");
					columnValuesList.add(sValue);
				}
				
				sValue = rs.getString("USER_ID");
				if (sValue!=null && !sValue.equals("")) {
					columnNamesList.add("User Id:");
					columnValuesList.add(sValue);
				}
				
				sValue = rs.getString("STATUS_CD");
				if (sValue!=null && !sValue.equals("")) {
					columnNamesList.add("Status:");
					columnValuesList.add(sValue);
				}
				
				sValue = rs.getString("ROWS_RETURNED_NBR");
				if (sValue!=null && !sValue.equals("")) {
					columnNamesList.add("Rows Returned:");
					columnValuesList.add(sValue);
				}
				
				date = rs.getTimestamp("PROCESS_START_TM");
				if (date!=null) {
					columnNamesList.add("Processing Start:");
					columnValuesList.add(date_formatter.format(date));
				}				

				date = rs.getTimestamp("PROCESS_END_TM");
				if (date!=null) {
					columnNamesList.add("Processing End:");
					columnValuesList.add(date_formatter.format(date));
				}				

				
				sValue = rs.getString("PROCESSING_TM");
				int secs=0;
				int hours, remainder, minutes, seconds;
				if (sValue!=null && sValue.length()>0) {
					secs = Math.round(Float.parseFloat(sValue) / 1000);
					hours = secs / 3600; 
					remainder = secs % 3600;
					minutes = remainder / 60;
					seconds = remainder % 60; 
					sValue = "";
					if (hours>0) {
						sValue =  hours + " Hrs ";
					}
					if (minutes > 0) {
						sValue = sValue + minutes + " Min ";
					}
					if (seconds > 0) {
						sValue = sValue + seconds + " Secs ";
					}
				}
				
				if (sValue!=null && !sValue.equals("")) {
					columnNamesList.add("Processing Time:");
					columnValuesList.add(sValue);
				}				
				
			}
			
			if (columnNamesList.size()>0&&(columnNamesList.size() == columnValuesList.size())) {
				detailsForm.setColumnNamesList(columnNamesList);
				detailsForm.setColumnValuesList(columnValuesList);
			} else {
				logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sql}) + " The size of the columns keys should be equal to the column Values");
				failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {"The size of the columns keys should be equal to the column Values"})));
				
			}
		 } catch (SQLException sx) {
				logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sql}) + " Exception details: " + sx.getMessage(), sx);
				failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sql}), sx));
		} finally{
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(ps, failureList, logger);
		}
	}
	
	public ResultSet getAdhocBackgroundReportDetailsKeys(Connection connection, List failureList, String tableNode, int reportNum) {
		
		String sql = " select KEY_NBR, KEY_HEADER_TXT, KEY_TXT " +
					 " FROM RABC_BKGRND_RPT_KEYS WHERE BKGRND_RPT_NBR = ? ORDER BY KEY_NBR";


		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1,reportNum);
			rs = ps.executeQuery();
		 } catch (SQLException sx) {
				logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sql}) + " Exception details in getAdhocBackgroundReportDetailsKeys: " + sx.getMessage(), sx);
				failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sql}), sx));
				SQLHelper.closeStatement(ps, failureList, logger);
		}
		return rs;
	}
	
	public int getDivisionKeyLvl(Connection connection, int presnId, List failureList, String tableNode) {
		
		String sql = " select DIVISION_NAME_KEY_LVL " +
					 " FROM RABC_PRESN_ID WHERE PRESN_ID = ?";

		int divLevel=0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1,presnId);
			rs = ps.executeQuery();
			
			if (rs.next()) {
				divLevel = rs.getInt("DIVISION_NAME_KEY_LVL");
			}
		 } catch (SQLException sx) {
				logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sql}) + " Exception details in getAdhocBackgroundReportDetailsKeys: " + sx.getMessage(), sx);
				failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sql}), sx));
		} finally{
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(ps, failureList, logger);
		}
		return divLevel;
	}
	
	public void getKeyInfoInArrayList(Connection conn, ResultSet keysRs, ArrayList<String>columnNamesList, ArrayList<String>columnValuesList, int divisionKeyLvl, List failureList, String tableNode) {

		try {
			int keyNbr=0;
			if (keysRs!=null) {
				while (keysRs.next()) {
					keyNbr = keysRs.getInt("KEY_NBR");
					if (keyNbr > 0) {
						columnNamesList.add(keysRs.getString("KEY_HEADER_TXT")+":");
						if (divisionKeyLvl == keyNbr) {
							String divNames[] = keysRs.getString("KEY_TXT").split(",");
							String divisionName="";
							for (int j=0; j<divNames.length; j++) {
								divisionName = divisionName + getDivisionName(conn, divNames[j], failureList, tableNode)+", ";
							}
							if (divisionName.length()>0) {
								divisionName = divisionName.substring(0, divisionName.length()-2);
							}
							columnValuesList.add(divisionName);
						} else {
							columnValuesList.add(keysRs.getString("KEY_TXT"));
						}
					}
				}
			}	
		 } catch (SQLException sx) {
				logger.error(RABCMessages.getMessage("ERR_SQL_EXEC") + " Exception details in getKeyInfoInArrayList: " + sx.getMessage(), sx);
				failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC"), sx));
		} finally{
			SQLHelper.closeResultSet(keysRs, failureList, logger);
		}
		
	}
	
	public String getDivisionName(Connection connection, String divName, List failureList, String tableNode) {
		
		String sql = " select DIVISION_DESC " +
					 " FROM RABC_DIVISION WHERE DIVISION = ?";

		String divisionName="";
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = connection.prepareStatement(sql);
			ps.setString(1, divName);
			rs = ps.executeQuery();
			
			if (rs.next()) {
				divisionName = rs.getString("DIVISION_DESC");
			}
		 } catch (SQLException sx) {
				logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sql}) + " Exception details in getAdhocBackgroundReportDetailsKeys: " + sx.getMessage(), sx);
				failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sql}), sx));
		} finally{
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(ps, failureList, logger);
		}
		return divisionName;
	}	
	
}
