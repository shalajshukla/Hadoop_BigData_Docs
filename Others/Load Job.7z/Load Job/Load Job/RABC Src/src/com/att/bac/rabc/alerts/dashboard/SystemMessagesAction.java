/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.dashboard;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;

import javax.naming.NamingException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jcifs.smb.SmbFileInputStream;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.att.bac.rabc.ConnectionManager;
import com.att.bac.rabc.ExcelReport;
import com.att.bac.rabc.ProgressBar;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.StaticDataLoader;
import com.att.carat.util.email.EmailFactory;
import com.att.carat.util.io.FileIO;

/**
 * This class represents an Action that generates the System Messages Detail page.
 * 
 * @author Abhilash - AC6957
 */
public class SystemMessagesAction extends DispatchAction {
	public static Logger  logger = Logger.getLogger(SystemMessagesAction.class);
	private SystemMessagesService systemMessagesService = SystemMessagesService.getSystemMessagesService();
	
	/**
	 * This is default action method.
	 * This method will check the dispatch parameter obtained from the form based on value of respective dispatch call method 
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @see org.apache.struts.actions.DispatchAction#unspecified(org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public ActionForward unspecified(ActionMapping mapping, ActionForm form, 
			HttpServletRequest request, HttpServletResponse response)   {
		return systemMessages(mapping,form,request, response);
	}


	/**
	 * This is an action method to handel the request for System Messages page. 
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward systemMessages(ActionMapping mapping, ActionForm form,HttpServletRequest request, HttpServletResponse response)   {
		/*
		 * Standard list maintained to collect the exceptions as & when they are encountered.
		 */
		List failureList = new ArrayList();
		Connection connection = null;
		int defaultLineCount = 0;
		
		SystemMessagesForm systemMessagesForm = (SystemMessagesForm) form;
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		String userId = (String) session.getAttribute("bacUserID");
		String region = (String) session.getAttribute("region");
		
		/*
		 * Update calendar attributes
		 */
		systemMessagesForm.setBillRounds(StaticDataLoader.getBillRounds(region));
		systemMessagesForm.setProcDates(StaticDataLoader.getProcDates(region));
		systemMessagesForm.setHolidayIndicators(StaticDataLoader.getHolidayIndicators(region));
		systemMessagesForm.setLoadedDataDates(StaticDataLoader.getLoadedDataDatesByRegion(region));
		
		try {
			connection = ConnectionManager.getConnection(region);
			
			SystemMessagesParameters systemMessagesParameters = (SystemMessagesParameters) request.getAttribute("systemMessagesParameters");
			
			if (systemMessagesParameters == null) {
				systemMessagesParameters = systemMessagesForm.getSystemMessagesParameters();
				systemMessagesParameters.setStartDate(systemMessagesForm.getStartDate());
				systemMessagesParameters.setEndDate(systemMessagesForm.getEndDate());
			} else {
				systemMessagesForm.setSystemMessagesParameters(systemMessagesParameters);
				systemMessagesForm.setStartDate(systemMessagesParameters.getStartDate());
				systemMessagesForm.setEndDate(systemMessagesParameters.getEndDate());
			}

			/*
			 * Code to get the default line count. 
			 */
			defaultLineCount = systemMessagesService.getDefaultLineCount(connection, failureList, userId);
			progressBar.setProgressPercent(progressBar.getPercent() + 10);
			
			/*
			 * Call private method listArguments(systemMessagesForm) to add the form parameters
			 * in an array list.
			 */
			List args = listArguments(systemMessagesForm, defaultLineCount, region);
			
			/*
			 * Code for paging.
			 * Call the private method setPaging(systemMessagesForm, connection, failureList, args) to set the 
			 * paging parameters in the form.
			 */
			setPaging(systemMessagesForm, connection, failureList, args);
			
			/*
			 * Reset the args list with current page and total no. of pages.
			 */
			args.add(4, new Integer(systemMessagesForm.getPage()));
	    	args.add(5, new Integer(systemMessagesForm.getPages()));
	    	
	    	Hashtable options = getCriteria(systemMessagesParameters, args);
			session.setAttribute("options", options);
			
			/*
			 * Call the private method getCycle(connection, failureList, args) to get the cycle.
			 */
			String cycle = getCycle(connection, failureList, region, systemMessagesParameters);
			systemMessagesForm.setCycle(cycle);
			progressBar.setProgressPercent(progressBar.getPercent() + 10);
			
			// Call the getSystemMessagesList method of service passing the SystemMessagesParameters object as 1 of the arguments
			List systemMessagesList = systemMessagesService.getSystemMessagesList(connection,failureList,systemMessagesParameters,args,progressBar);
			systemMessagesForm.getSystemMessagesList().clear();
			if (systemMessagesList != null) {
				SystemMessages systemMessages = null;
				for(int i = 0; i < systemMessagesList.size(); i++) {
					systemMessages = (SystemMessages)systemMessagesList.get(i);
					systemMessagesForm.addSystemMessages(systemMessages);
					if (systemMessagesForm.getStatusColor() == null) {
						if (systemMessages.getStatus() != null 
								&& systemMessages.getStatus().equals("Warning")) {
							systemMessagesForm.setStatusColor("Red");
						} else {
							systemMessagesForm.setStatusColor("NoColor");
						}
					}
				}
			}
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		}catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		}  finally {
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		
		progressBar.setProgressPercent(100);
		
		if (!failureList.isEmpty()) {
			request.setAttribute("failures",failureList);
			return mapping.findForward("error");
		} else {
			return mapping.findForward("SystemMessages");
		}
		
	}

	/**
	 * This is an action method to handel the request for first page of SystemMessages.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward first(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		return systemMessages(mapping, form, request, response);
    }
	
	/**
	 * This is an action method to handel the request for previous page of SystemMessages.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward previous(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response){
		return systemMessages(mapping, form, request, response);
    }
	
	/**
	 * This is an action method to handel the request for next page of SystemMessages.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward next(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		return systemMessages(mapping, form, request, response);
    }
	
	/**
	 * This is an action method to handel the request for last page of SystemMessages.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward last(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response){
    	return systemMessages(mapping, form, request, response);
    }
    
	/**
	 * This is an action method to handel the request for specific page of SystemMessages.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward pagelist(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response){
    	return systemMessages(mapping, form, request, response);
    }
    
	/**
	 * This is an action method to handel the request for sorting the current page of SystemMessages
	 * depending upon sort criteria.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward sort(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response){
    	return systemMessages(mapping, form, request, response);
    }
	
	/**
	 * This is an action method to handel the request for sending the email with attached 
	 * excel report of SystemMessages to the list of selected users. 
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward emailReport(ActionMapping mapping, ActionForm form,HttpServletRequest request, HttpServletResponse response)   {
		SystemMessagesForm systemMessagesForm = (SystemMessagesForm) form;
		List failureList = new ArrayList();
		String toAddress = systemMessagesForm.getEmailRecipients();
		boolean htmlYN = false;
		Connection connection = null;
		//File file[]  = new File[1];
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		String region = (String) session.getAttribute("region");
		
        String reportPath = "Outstanding_System_Messages_" ;
        
        try {
			connection = ConnectionManager.getConnection(region);
			SystemMessagesParameters systemMessagesParameters  = systemMessagesForm.getSystemMessagesParameters();
			systemMessagesParameters.setStartDate(systemMessagesForm.getStartDate());
			systemMessagesParameters.setEndDate(systemMessagesForm.getEndDate());
			List args = listArguments(systemMessagesForm, 0, region);
						
			// Call the getSystemMessagesList method of service passing the SystemMessagesParameters object as 1 of the arguments
			List systemMessagesList = systemMessagesService.getSystemMessagesList(connection,failureList,systemMessagesParameters,args,progressBar);
			systemMessagesForm.getSystemMessagesList().clear();
			if (systemMessagesList != null) {
				for(int i = 0; i < systemMessagesList.size(); i++) {
					systemMessagesForm.addSystemMessages((SystemMessages)systemMessagesList.get(i));
				}
				systemMessagesForm.setQryResultCt(systemMessagesList.size());
			}
			progressBar.setProgressPercent(progressBar.getPercent() + 10);
			reportPath += (String)request.getSession().getAttribute("bacUserID")+".xls" ;
			
			 // pb3879 added to create correct subject line. Added to second arguement for email.
            Context initContext = new InitialContext();
            String spServer = initContext.lookup("java:/comp/env/saved_report_server").toString();
            String fromEnvironment = initContext.lookup("java:/comp/env/application_env").toString();
            String rootFolder = initContext.lookup("java:/comp/env/saved_report_folder").toString();
            String spUser = initContext.lookup("java:/comp/env/saved_report_user").toString();
            String spPasswd = initContext.lookup("java:/comp/env/saved_report_passwd").toString();
            String smbUrl = "smb://" + spUser + ":" + spPasswd + "@" + spServer + "/" + rootFolder;// + reportPath;

            FileIO fio = new FileIO(smbUrl, reportPath);
			
			//Call to Methood for Generating Report
			ExcelReport report = new  ExcelReport(fio.createOutputStream());
			systemMessagesService.getExcelReport(failureList,systemMessagesParameters,systemMessagesList,report);
			progressBar.setProgressPercent(progressBar.getPercent() + 10);
			String [] emailRecipients = toAddress.split(",");
			for (int count = 0; count < emailRecipients.length; count++) {
                EmailFactory.sendEmail(emailRecipients[count] + "@att.com", "RABC (" + fromEnvironment + " - " + spServer + ") - Outstanding System Messages ",
                                   "Please find the enclosed RABC Report - " + reportPath, false, fio);
            }
			
	        } catch(SQLException sx) {
				logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
				failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
			} catch(NamingException ne) {
				logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
				failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
			} catch(IOException ioe) {
				logger.error(RABCMessages.getMessage("ERR_IO_EXEC", new String[] {"IO Exception while e mailing system messages report. "}) + " Exception details: " + ioe.getMessage(), ioe);
	            failureList.add(new RABCException(RABCMessages.getMessage("ERR_IO_EXEC", new String[] {"IO Exception while e mailing system messages report."}), ioe));
			}catch(Exception e) {
				logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
	            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
			} finally {
				SQLHelper.closeConnection(connection, failureList, logger);
			}
			progressBar.setProgressPercent(100);
			if (!failureList.isEmpty()) {
				request.setAttribute("failures",failureList);
				return mapping.findForward("error");
			} else {
				return systemMessages(mapping, form, request, response);
			}
	}
	
	/**
	 * This is an action method to handel the request for generating the excel report of SystemMessages. 
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward createReport(ActionMapping mapping, ActionForm form,HttpServletRequest request, HttpServletResponse response)   {
		List failureList = new ArrayList();
		Connection connection = null;
		String reportName = "";
		
		ServletOutputStream out = null;
		
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		String region = (String) session.getAttribute("region");
		
		try {
			
			connection = ConnectionManager.getConnection(region);
			SystemMessagesForm systemMessagesForm = (SystemMessagesForm) form;
			SystemMessagesParameters systemMessagesParameters = systemMessagesForm.getSystemMessagesParameters();
			systemMessagesParameters.setStartDate(systemMessagesForm.getStartDate());
			systemMessagesParameters.setEndDate(systemMessagesForm.getEndDate());
			List args = listArguments(systemMessagesForm, 0, region);
			
			String fileName = "Outstanding_System_Messages_" + (String)request.getSession().getAttribute("bacUserID") +".xls";
			reportName += fileName ;

			
			// Call the getSystemMessagesList method of service passing the SystemMessagesParameters object as 1 of the arguments
			List systemMessagesList = systemMessagesService.getSystemMessagesList(connection, failureList, systemMessagesParameters, args,progressBar);
			systemMessagesForm.getSystemMessagesList().clear();
			
			if (systemMessagesList != null) {
				for(int i = 0; i < systemMessagesList.size(); i++) {
					systemMessagesForm.addSystemMessages((SystemMessages)systemMessagesList.get(i));
				}
				systemMessagesForm.setQryResultCt(systemMessagesList.size());
			}
			progressBar.setProgressPercent(progressBar.getPercent() + 10);
			//Set response headers
	        response.setContentType("application/msexcel");
	        response.setHeader("Content-Disposition","attachment; filename="+fileName);
	        
	        Context initContext = new InitialContext();
            String spServer = initContext.lookup("java:/comp/env/saved_report_server").toString();
            String rootFolder = initContext.lookup("java:/comp/env/saved_report_folder").toString();
            String spUser = initContext.lookup("java:/comp/env/saved_report_user").toString();
            String spPasswd = initContext.lookup("java:/comp/env/saved_report_passwd").toString();
            String smbUrl = "smb://" + spUser + ":" + spPasswd + "@" + spServer + "/" + rootFolder ;
		
			// Code for Generating Report
		
            FileIO fio= new FileIO(smbUrl,reportName);
			ExcelReport report = new  ExcelReport(fio.createOutputStream());
			systemMessagesService.getExcelReport(failureList, systemMessagesParameters, systemMessagesList,report);
			progressBar.setProgressPercent(progressBar.getPercent() + 10);
		
				
		     InputStream fis = new BufferedInputStream(new SmbFileInputStream(fio.getQualifiedFilename()));
		      out = response.getOutputStream();
		     int readBytes = 0;
		     while((readBytes = fis.read()) != -1){
		    	 out.write(readBytes);
		     }	
		   
		
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch(IOException ioe) {
			logger.error(RABCMessages.getMessage("ERR_IO_EXEC", new String[] {"IO Exception while creating system messages report. "}) + " Exception details: " + ioe.getMessage(), ioe);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_IO_EXEC", new String[] {"IO Exception while creating system messages report."}), ioe));
		}catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failureList, logger);
			try {
				
				if (out != null){
					out.close();
				}
				
			} catch(Exception e) {
				logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
	            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
			}
		}
		progressBar.setProgressPercent(100);
		return null;
	}
	
	/**
	 * This is an action method to handel the request for dashboard page.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward alertDashboard(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		SystemMessagesForm systemMessagesForm = (SystemMessagesForm) form;
		HttpSession session = request.getSession(false);
		
		Hashtable options = new Hashtable();
    	
		if (systemMessagesForm.getStartDate() != null) {
			options.put("startDate", systemMessagesForm.getStartDate());
		}
		if (systemMessagesForm.getEndDate() != null) {
			options.put("endDate", systemMessagesForm.getEndDate());
		}
		if (systemMessagesForm.getSystemMessagesParameters().getDateType() != null) {
			options.put("dateOption", systemMessagesForm.getSystemMessagesParameters().getDateType());
		}
		
		options.put("dashboardType", "2");
		
		options.put("displayHead", "range");
		
		options.put("sortItem", "severe_lvl_high_ct");

		options.put("sortOrder", "ASC");
		
		options.put("page", new Integer(1));
		
		session.setAttribute("dashboardOptions", options);
		
		return mapping.findForward("AlertDashboard");
    }
	
	/**
	 * A method to return the selected options which accepts the SystemMessagesParameters as an input.
	 * 
	 * @param systemMessagesParameters
	 * @param args
	 * @return Hashtable
	 */
	private Hashtable getCriteria(SystemMessagesParameters systemMessagesParameters, List args ) {
		String sortItem = (String) args.get(0);
		String sortOrder = (String) args.get(1);
		Integer page = (Integer) args.get(4);
		
		Hashtable options = new Hashtable();
		if (systemMessagesParameters.getWebPageId() != null) {
			options.put("webPageId", systemMessagesParameters.getWebPageId());
		}
		if (systemMessagesParameters.getDateType() != null) {
			options.put("dateTpye", systemMessagesParameters.getDateType());
		}
		if (systemMessagesParameters.getStartDate() != null) {
			options.put("startDate", systemMessagesParameters.getStartDate());
		}
		if (systemMessagesParameters.getEndDate() != null) {
			options.put("endDate", systemMessagesParameters.getEndDate());
		}
		if (systemMessagesParameters.getUpStartDate() != null) {
			options.put("upStartDate", systemMessagesParameters.getUpStartDate());
		}
		if (systemMessagesParameters.getUpEndDate() != null) {
			options.put("upEndDate", systemMessagesParameters.getUpEndDate());
		}
		if (systemMessagesParameters.getControlPoint() != null) {
			options.put("controlPoint", systemMessagesParameters.getControlPoint());
		}
		if (systemMessagesParameters.getAlertRule() != null) {
			options.put("alertRule", systemMessagesParameters.getAlertRule());
		}
		if (systemMessagesParameters.getDivision() != null) {
			options.put("division", systemMessagesParameters.getDivision());
		}
		if (systemMessagesParameters.getAlertInstant() != null) {
			options.put("alertInstant", systemMessagesParameters.getAlertInstant());
		}
		if (systemMessagesParameters.getAlertRuleTiming() != null) {
			options.put("alertRuleTiming", systemMessagesParameters.getAlertRuleTiming());
		}
		if (systemMessagesParameters.getAlertRuleTimingIndicator() != null) {
			options.put("alertRuleTimingIndicator", systemMessagesParameters.getAlertRuleTimingIndicator());
		}
		if (systemMessagesParameters.getRevenueImpactValue() != null) {
			options.put("revenueImpactValue", systemMessagesParameters.getRevenueImpactValue());
		}
		if (systemMessagesParameters.getRevenueImpactValue() != null && !systemMessagesParameters.getRevenueImpactValue().trim().equals("")) {
			options.put("revenueImpactValueHidden", new Double(systemMessagesParameters.getRevenueImpactValueHidden()));
		}
		if (systemMessagesParameters.getRevenueImpactIndicator() != null) {
			options.put("revenueImpactIndicator", systemMessagesParameters.getRevenueImpactIndicator());
		}
		if (systemMessagesParameters.getAlertStatus() != null) {
			options.put("alertStatus", systemMessagesParameters.getAlertStatus());
		}
		if (systemMessagesParameters.getRootCatgyCd() != null) {
			options.put("rootCatgyCd", systemMessagesParameters.getRootCatgyCd());
		}
		if (systemMessagesParameters.getAlertGroup() != null) {
			options.put("alertGroup", systemMessagesParameters.getAlertGroup());
		}
		if (systemMessagesParameters.getSystemErrorType() != null) {
			options.put("systemErrorType", systemMessagesParameters.getSystemErrorType());
		}
		if (sortItem != null) {
			options.put("sortItem", sortItem);
		}
		if (sortOrder != null) {
			options.put("sortOrder", sortOrder);
		}
		options.put("page", page);
		
		return options;
	}
		
	/**
	 * This is an action method to handel the request to return to SystemMessages page 
	 * after upadating the status. 
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward returnView(ActionMapping mapping, ActionForm form,HttpServletRequest request, HttpServletResponse response){
		SystemMessagesForm systemMessagesForm = (SystemMessagesForm) form;
		SystemMessagesParameters systemMessagesParameters = new SystemMessagesParameters();
		HttpSession session = request.getSession(true);
		Hashtable options = (Hashtable) session.getAttribute("options");
		systemMessagesParameters.setWebPageId((String) options.get("webPageId"));
		systemMessagesParameters.setDateType((String) options.get("dateTpye"));
		systemMessagesParameters.setStartDate((String) options.get("startDate"));
		systemMessagesParameters.setEndDate((String) options.get("endDate"));
		systemMessagesParameters.setUpStartDate((String) options.get("upStartDate"));
		systemMessagesParameters.setUpEndDate((String) options.get("upEndDate"));
		systemMessagesParameters.setControlPoint((String) options.get("controlPoint"));
		systemMessagesParameters.setAlertRule((String) options.get("alertRule"));
		systemMessagesParameters.setDivision((String) options.get("division"));
		systemMessagesParameters.setAlertInstant((String) options.get("alertInstant"));
		systemMessagesParameters.setAlertRuleTiming((String) options.get("alertRuleTiming"));
		systemMessagesParameters.setAlertRuleTimingIndicator((String) options.get("alertRuleTimingIndicator"));
		String revenueImpactValue = (String) options.get("revenueImpactValue");
		systemMessagesParameters.setRevenueImpactValue(revenueImpactValue);
		if (revenueImpactValue != null && !revenueImpactValue.trim().equals("")) {
			systemMessagesParameters.setRevenueImpactValueHidden(((Double) options.get("revenueImpactValueHidden")).doubleValue());
		}
		systemMessagesParameters.setRevenueImpactIndicator((String) options.get("revenueImpactIndicator"));
		systemMessagesParameters.setAlertStatus((String) options.get("alertStatus"));
		systemMessagesParameters.setRootCatgyCd((String) options.get("rootCatgyCd"));
		systemMessagesParameters.setAlertGroup((String) options.get("alertGroup"));
		systemMessagesParameters.setSystemErrorType((String) options.get("systemErrorType"));
				
		systemMessagesForm.setSystemMessagesParameters(systemMessagesParameters);
		systemMessagesForm.setStartDate(systemMessagesParameters.getStartDate());
		systemMessagesForm.setEndDate(systemMessagesParameters.getEndDate());
		systemMessagesForm.setSortItem((String) options.get("sortItem"));
		systemMessagesForm.setSortOrder((String) options.get("sortOrder"));
		systemMessagesForm.setPage(((Integer) options.get("page")).intValue());
		
		return systemMessages(mapping, systemMessagesForm, request, response);
	}
		
	/**
	 * This is a private method to set the current page and total no. of pages of the report
	 * to the form bean.
	 * 
	 * @param systemMessagesForm
	 * @param connection
	 * @param failureList
	 * @param args
	 */
	private void setPaging(SystemMessagesForm systemMessagesForm, Connection connection,	List failureList , List args) {
		SystemMessagesParameters systemMessagesParameters = systemMessagesForm.getSystemMessagesParameters();
		
		/*
		 * Call the service class to get the total count of systemMessages.
		 */
		int totalMessageCount = systemMessagesService.getTotalMessages(systemMessagesParameters, connection, failureList, args);
		
		int pageSize = ((Integer) args.get(3)).intValue();
		
		int pages = totalMessageCount / pageSize;
		int temp = totalMessageCount % pageSize;
		if ( temp > 0)
			pages++;
		
		/*
		 * Set the total no. of pages of the report.
		 */
		systemMessagesForm.setPages(pages);
		
		/*
		 * Set the total count of systemMessages.
		 */
		systemMessagesForm.setQryResultCt(totalMessageCount);
		
		/*
		 * Code to set the current page of the report.
		 */
		String dispatch = systemMessagesForm.getDispatch();
		if ("first".equals(dispatch)) {
			systemMessagesForm.setPage(1);
		} else if ("last".equals(dispatch)) {
			systemMessagesForm.setPage(systemMessagesForm.getPages());
		} else if ("previous".equals(dispatch)) {
        	if (systemMessagesForm.getPage() != 1) {
        		systemMessagesForm.setPage(systemMessagesForm.getPage() - 1);
        	}
        } else if ("next".equals(dispatch)) {
        	if (systemMessagesForm.getPage() != systemMessagesForm.getPages()) {
        		systemMessagesForm.setPage(systemMessagesForm.getPage() + 1);
        	}
        } else if ("pagelist".equals(dispatch)) {
        	if (systemMessagesForm.getPageshow() != 0) {
        		systemMessagesForm.setPage(systemMessagesForm.getPageshow());
        	} else {
        		systemMessagesForm.setPage(1);
        	}
        } else if ("sort".equals(dispatch)) {
        	systemMessagesForm.setPage(systemMessagesForm.getPage());
        } else if ("returnView".equals(dispatch)) {
        	systemMessagesForm.setPage(systemMessagesForm.getPage());
        } else {
        	systemMessagesForm.setPage(1);
        }
	}
	
	/**
	 * Private internal method to return the arguments list.
	 * 
	 * @param systemMessagesForm
	 * @param defaultLineCount
	 * @return List
	 */
	private List listArguments(SystemMessagesForm systemMessagesForm, int defaultLineCount, String region) {
    	List args = new ArrayList();
		String sortItem = systemMessagesForm.getSortItem();
		String sortOrder = systemMessagesForm.getSortOrder();   	
		args.add(0,sortItem);
		args.add(1,sortOrder);
		args.add(2, systemMessagesForm.getDispatch());
		args.add(3, new Integer(defaultLineCount));
		args.add(4, new Integer(systemMessagesForm.getPage()));
    	args.add(5, new Integer(systemMessagesForm.getPages()));
    	args.add(6, region);
    	
    	return args;
    }
	
	/**
	 * Private method to return a string that contains the first cycle and the last cycle.
	 * This calls the service class to get the list of cycles for the entered file start date and file end date.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return String
	 */
	private String getCycle(Connection connection, List failureList, String region, SystemMessagesParameters systemMessagesParameters) {
		String cycle = "";
		
		if ("WE".equalsIgnoreCase(region)) {
			/*
			 * Call the service class to get the list of cycles.
			 */
			List cycleList = systemMessagesService.getCycleCalendarList(connection, failureList, systemMessagesParameters);
			if (cycleList != null) {
				int cycleListSize = cycleList.size();
				if (cycleListSize > 0) {
					if (cycleListSize == 1) {
						cycle = (new Integer(((CycleCalendar) cycleList.get(0)).getCycle())).toString();
					} else {
						cycle = ((new StringBuffer())
								.append((new Integer(((CycleCalendar) cycleList.get(0)).getCycle())).toString())
								.append(" - ")
								.append((new Integer(((CycleCalendar) cycleList.get(cycleListSize-1)).getCycle())).toString()))
								.toString();
					}
				} else {
					cycle = "";
				}
			} else {
				cycle = "";
			}
		}
		return cycle;
	}
}

