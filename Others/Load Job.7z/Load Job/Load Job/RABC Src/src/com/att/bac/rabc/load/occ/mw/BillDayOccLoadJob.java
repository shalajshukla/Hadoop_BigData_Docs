/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.load.occ.mw;

import java.io.File;
import java.net.UnknownHostException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeMap;

import com.att.bac.rabc.util.EmcisEventLogger;
import com.att.carat.util.NetUtil;
import com.sbc.bac.rabc.load.FilePatternLoadJob;
import com.sbc.bac.rabc.load.PrepareTableForRerun;
import com.sbc.bac.rabc.load.RabcLoadJobTrig;
import com.sbc.bac.rabc.load.RetrieveStaticInfo;
import com.sbc.bac.rabc.load.StaticErrorMsgKeys;
import com.sbc.bac.rabc.load.StaticFieldKeys;

/**
 * This is a Load job which loads OCC load file for MW region into the following tables:
 * RABC_BILLDAY_OCC_ACTVT
 * RABC_BILLDAY_OCC_BTN
 * 
 * @author Sonali Uttarwar - SU3643
 */
public class BillDayOccLoadJob extends FilePatternLoadJob {
	/*
	 * Varables to represent the date formats
	 */
	private static final SimpleDateFormat YYMMDD_FORMAT = new SimpleDateFormat("yyMMdd");
	private static final SimpleDateFormat MMDDYYYY_FORMAT = new SimpleDateFormat("MMddyyyy");
	
	/*
	 * Variables to represent the table names.
	 */
	private static final String RABC_BILLDAY_OCC_ACTVT = "RABC_BILLDAY_OCC_ACTVT";
	private static final String RABC_BILLDAY_OCC_BTN = "RABC_BILLDAY_OCC_BTN";
	private static final String RABC_TRIG = "RABC_TRIG";
	
	/*
	 * Variables to represent the file ids to be inserted in RABC_TRIG table.
	 */
	private static final String BILLDAY_OCC_ACTVT_FILE_ID = "MWOCCBD";
	
	/*
	 * Variables to represent the prepared statements
	 */
	private PreparedStatement insertActvt;
	private PreparedStatement insertBtn;
	
	/*
	 * Global variables
	 */
	private String runDate;
	private java.sql.Date sqlRunDate;
	private String division;
	private int recordCount;
	private int actvtBatchCounter;
	private int btnBatchCounter;
	private String backoutRecovery = null;
	private File currentFile;
	private String fieldSeperator = StaticFieldKeys.SEMICOLON;
	private String fileName, fileToken, region;
	/*
	 * HashMap variables to contain the groups for various tables.
	 */
	private HashMap occActvtMap;
	private TreeMap occBTNMap;
	
	/*
	 * boolean variables indicating whether trigger to be inserted for that file id.
	 */
	boolean isBillDayOccActvt;
	boolean isBillDayOccBtn;
	
	/*
	 * boolean variables indicating whether the file to be processed or not.
	 */
	boolean isHeaderExists;
	boolean isTrailerExists;
	boolean isRecordCountMatches;
	
	/**
	 * Overriding preprocess() method. 
	 * It is executed prior to processing the load job.
	 * Forms the actual prepared statements which need to be fired on to the database.
	 * 
	 * @see com.sbc.bac.load.LoadJob#preprocess()
	 */
	public boolean preprocess() {
		boolean success = super.preprocess();

		if (success) {
			try {
				insertActvt = connection.prepareStatement("INSERT INTO RABC_BILLDAY_OCC_ACTVT (RUN_DATE, DIVISION, BILL_RND, BUS_TYPE, OCC_PHRASE_CD, OCC_CT, OCC_AMT) VALUES(?, ?, ?, ?, ?, ?, ? ) ");
				insertBtn   = connection.prepareStatement("INSERT INTO RABC_BILLDAY_OCC_BTN (RUN_DATE, DIVISION, BILL_RND, BTN, CUST_TYPE, MKT_IND, OCC_PHRASE_CD, OCC_CT, OCC_AMT) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ? ) ");
	
			} catch (SQLException e) {
				severe(StaticErrorMsgKeys.PREPROCESS_ERROR + e.getMessage(), e);
				success = false;
			}
		}
		
		return success;
	}
	
	/**
	 * Overriding preprocessFile(file) method.
	 * It is executed prior to processing the file to be loaded.
	 * It includes the following steps:
	 * 	1) Marks the backoutRecovery flag to "Y" if this file has already been processed earlier.
	 * 	2) Initializes the global variables with default values.
	 * 
	 * @see com.sbc.bac.load.FileDBLoadJob#preprocessFile(java.io.File)
	 */	
	public boolean preprocessFile(File file) {
		boolean success = super.preprocessFile(file);
		fileName = file.getName();
		fileToken = file.getName().substring(file.getName().indexOf("RA110F01"),file.getName().indexOf("RA110F01")+ 8);
		region = file.getName().substring(0,2);
		if (success) {
			try {
				/*
				 * Check whether this file has been processed before and if yes,
				 * mark the backoutRecovery flag to "Y".
				 */
				if (RabcLoadJobTrig.IsOriginalFileLoaded(connection, file, file.getName().length())) {
					backoutRecovery = "Y";
				}
			} catch (Exception e) {
				severe(StaticErrorMsgKeys.PREPROCESSFILE_ERROR + e.getMessage(), e);
				success = false;
			}
		}
		
		/*
		 * Initialize the global variables with default values.
		 */
		currentFile = file;
		recordCount = 0;
		isHeaderExists = false;
		isTrailerExists = false;
		isRecordCountMatches = false;
		occActvtMap = new HashMap();
		occBTNMap = new TreeMap();
		isBillDayOccActvt = false;
		isBillDayOccBtn = false;
		actvtBatchCounter = 0;
		btnBatchCounter = 0;
		
		return success;
	}
	
	/**
	 * Overriding parseLine(line) method.
	 * It accepts a single line and checks whether it is header, trailer, date or detail record.
	 * Depending upon the record type, it calls the respective internal private methods to process the line.
	 * 
	 * @see com.sbc.bac.load.FileDBLoadJob#parseLine(java.lang.String)
	 */
	protected int parseLine(String line) throws Exception {
		boolean status = true;
		String recordIndicator = getRecordType(line);
		
		if ("HEADER".equalsIgnoreCase(recordIndicator)) {
			isHeaderExists = true;
			status = processHeader(line);
		} else if ("TRAILER".equalsIgnoreCase(recordIndicator)) {
			isTrailerExists = true;
			status = processTrailer(line);
		} else if ("DATE".equalsIgnoreCase(recordIndicator)) {
			recordCount++;
			status = processCycleRecord(line);
		} else if ("DETAIL".equalsIgnoreCase(recordIndicator)) {
			recordCount++;
			status = processDetail(line);
		} else {
			status = false;
		}
		
		if (status) {
			return SUCCESS;
		} else {
			return ERROR;
		}
	}
	
	/**
	 * Private method to return the record type of the line to be processed.
	 * 
	 * @param line
	 * @return String
	 * @throws Exception
	 */
	private String getRecordType(String line) throws Exception {
		String recordType = null;
		
		String [] lineFields 	= line.split(fieldSeperator);
		String firstField		= lineFields[0].trim();
		
		if ("HEADER".equals(firstField)) {
			recordType = "HEADER";
		} else if ("TRAILER".equals(firstField)) {
			recordType = "TRAILER";
		} else if ("RA11DATE".equals(firstField)) {
			recordType = "DATE";
		} else if ("RA11OCCS".equals(firstField)) {
			recordType = "DETAIL";
		}
		
		return recordType;
	}
	
	/**
	 * Private method to process the header record.
	 * 
	 * @param line
	 * @return boolean
	 * @throws Exception
	 */
	private boolean processHeader(String line) throws Exception {
		boolean success = false;
		
		String [] lineFields = line.split(fieldSeperator);
		
		/*
		 * Populate the instance variable for division.
		 */
		if (lineFields.length > 2) {
			division = lineFields[2].trim();
			success = true;
		}
		
		return success;
	}
	
	/**
	 * Private method to process the trailer record.
	 * It checks that whether the total number of records (excluding header and trailer records)
	 * in the file is eqaul to the count in the trailer record or not.
	 *  
	 * @param line
	 * @return boolean
	 * @throws Exception
	 */
	private boolean processTrailer(String line) throws Exception {
		boolean success = false;
		int trailerCount = 0;
		
		String [] lineFields = line.split(fieldSeperator);
		
		if (lineFields.length > 5) {
			trailerCount = Integer.parseInt(lineFields[5].trim());
			success = true;
		}
		
		if (success) {
			if (trailerCount == recordCount) {
				isRecordCountMatches = true;
			}
		}
		
		return success;
	}
	
	/**
	 * Private method to process the date record. It does the following steps:
	 * 	1) Retrieves the cycle date from the date record.
	 * 	2) Deletes the records matching with the date and division retrieved form the file from the tables 
	 * 	   RABC_BILLDAY_OCC_ACTVT and RABC_BILLDAY_OCC_BTN if the backoutRecovery flag is "Y", 
	 * 	   i.e. this file has already been processed earlier.
	 * 
	 * @param line
	 * @return boolean
	 * @throws Exception
	 */
	private boolean processCycleRecord(String line) throws Exception {
		boolean success = false;
		
		String [] lineFields = line.split(fieldSeperator);
		
		/*
		 * Populate the instance variable for runDate.
		 */
		if (lineFields.length > 2) {
			runDate = lineFields[2].trim();
			success = true;
		}
		
		if (success) {
			sqlRunDate = new java.sql.Date(YYMMDD_FORMAT.parse(runDate).getTime());
			runDate = MMDDYYYY_FORMAT.format(YYMMDD_FORMAT.parse(runDate));
			
			if ("Y".equals(backoutRecovery)){
				success = PrepareTableForRerun.deleteTableData(connection, RABC_BILLDAY_OCC_ACTVT, division, sqlRunDate);
				if (success) {
					success = PrepareTableForRerun.deleteTableData(connection, RABC_BILLDAY_OCC_BTN, division, sqlRunDate);
				}
			}
		}
		
		return success;
	}
	
	/**
	 * Private method to process the records for the rule 'RA11OCCS'.
	 * It does the following steps:
	 * 	1) Retrieves the fields from the line.
	 * 	2) Does conversion of data from String to appropriate data types as well as interpretation for amount.
	 * 	3) Creates the objects of BillDayOccActvt and BillDayOccBTN type.
	 * 	4) Populates the hash map with those objects.
	 * 
	 * @param line
	 * @return boolean
	 * @throws Exception
	 */
	private boolean processDetail(String line) throws Exception {
		boolean success = true;
		
		String [] lineFields = line.split(fieldSeperator);
		
		String ruleName		= lineFields[0].trim();
		String seqNumber	= lineFields[1].trim();
		String btn			= lineFields[2].trim();
		String billRnd		= lineFields[3].trim();
		String custType		= lineFields[4].trim();
		String mktInd		= lineFields[5].trim();
		String occPhraseCd	= lineFields[6].trim();
		String totalCnt		= lineFields[7].trim();
		String totalAmt		= lineFields[8].trim();
		String busType = null;
		if ("D".equals(custType) || "K".equals(custType) || "R".equals(custType)) {
			busType = "RES";
		} else {
			busType = "BUS";
		}
		if (!"".equals(mktInd)) {
			busType = "R" + busType;
		}
		
		/*
		 * Format the count & amount values
		 */
		long totalCount				= Long.parseLong(totalCnt.substring(0, totalCnt.length()-6));
		String amountUnitPart		= totalAmt.substring(0, totalAmt.length()-6);
		String amountDecimalPart 	= totalAmt.substring(totalAmt.length()-6);
		String actualAmount			= amountUnitPart + "." + amountDecimalPart;
		double totalAmount			= Double.parseDouble(actualAmount);
		
		/*
		 * Create an object of BillDayOccActvt type
		 */
		BillDayOccActvt occActvt = new BillDayOccActvt();
		occActvt.setRunDate(MMDDYYYY_FORMAT.parse(runDate));
		occActvt.setDivision(division);
		occActvt.setBillRnd(billRnd);
		occActvt.setBusType(busType);
		occActvt.setOccPhraseCd(occPhraseCd);
		
		/*
		 * Check whether the object of BillDayOccActvt type is present in the hash map
		 */
		BillDayOccActvt actvtObjRef = null;
		actvtObjRef = (BillDayOccActvt) occActvtMap.get(occActvt);
		
		if (actvtObjRef != null) {
			long newOccCt		= actvtObjRef.getOccCt() + totalCount;
			double newOccAmt	= actvtObjRef.getOccAmt() + totalAmount;
			actvtObjRef.setOccCt(newOccCt);
			actvtObjRef.setOccAmt(newOccAmt);
			occActvtMap.put(actvtObjRef, actvtObjRef);
		} else {
			occActvt.setOccCt(totalCount);
			occActvt.setOccAmt(totalAmount);
			occActvtMap.put(occActvt, occActvt);
		}
		
		/*
		 * Create an object of BillDayOccBtn type
		 */
		BillDayOccBTN occBTN = new BillDayOccBTN();
		occBTN.setRunDate(MMDDYYYY_FORMAT.parse(runDate));
		occBTN.setDivision(division);
		occBTN.setBillRnd(billRnd);
		occBTN.setBtn(btn);
		occBTN.setCustType(custType);
		occBTN.setMktInd(mktInd);
		occBTN.setOccPhraseCd(occPhraseCd);

		/*
		 * Check whether the object of BillDayOccBtn type is present in the tree map
		 */
		BillDayOccBTN btnObjRef = null;
		btnObjRef = (BillDayOccBTN) occBTNMap.get(occBTN);
		
		if (btnObjRef != null) {
			long newOccCt		= btnObjRef.getOccCt() + totalCount;
			double newOccAmt	= btnObjRef.getOccAmt() + totalAmount;
			btnObjRef.setOccCt(newOccCt);
			btnObjRef.setOccAmt(newOccAmt);
			occBTNMap.put(btnObjRef, btnObjRef);
		} else {
			occBTN.setOccCt(totalCount);
			occBTN.setOccAmt(totalAmount);
			occBTNMap.put(occBTN, occBTN);
		}
			
		return success;
	}
	
	/**
	 * Overriding postProcessFile(file, success) method.
	 * It is executed post to processing the file to be loaded.
	 * It includes the following steps:
	 * 	1) It checks whether the header and trailer records exists and 
	 * 	   whether the total number of records (excluding header and trailer records)
	 * 	   in the file is eqaul to the count in the trailer record.
	 * 	   If it is then prcoceeds to next step else return false.
	 * 	2) Loops through the maps and insert entries into RABC_BILLDAY_OCC_ACTVT and RABC_BILLDAY_OCC_BTN tables.
	 * 	3) Makes the entries into RABC_TRIG table.
	 * 
	 * @see com.sbc.bac.load.FileDBLoadJob#postprocessFile(java.io.File, boolean)
	 */
	public boolean postprocessFile(File file, boolean success) {
		try{
			//Log the file information to EMCIS_EVENT_LOG and EMCIS_EVENT_LOG_DETAIL
			EmcisEventLogger emcisLogger = new EmcisEventLogger();
			String event_id = "RABC_"+fileToken+"_"+region;
            String host = NetUtil.getLocalHostName();
            String hostIP = NetUtil.getLocalIpAddress();
			int sequence = emcisLogger.getEMCISSequence(connection);
			emcisLogger.insertEventLog(connection, sequence, event_id, sqlRunDate, host, hostIP);
			emcisLogger.insertEventLogDetail(connection, sequence, "FileName", fileName);
	
		}catch (UnknownHostException e) {
	        severe("Error getting EMCIS host information ", e);
	    }
		if (success) {
			if (!isHeaderExists) {
				severe("Header record is not present in the file.");
				success = false;
			} else if (!isTrailerExists) {
				severe("Trailer record is not present in the file.");
				success = false;
			} else if (!isRecordCountMatches) {
				severe("Total number of records in the file is not eqaul to the count in the trailer record.");
				success = false;
			} else {
				try {
					/*
					 * Iterate through the entire map occActvtMap and insert entries into the RABC_BILLDAY_OCC_ACTVT table
					 */
					Set occActvtSet			= occActvtMap.keySet();
					Iterator occActvtIterator = occActvtSet.iterator();
					
					while (occActvtIterator.hasNext()) {
						BillDayOccActvt occActvt = (BillDayOccActvt) occActvtIterator.next();
						insertActvt.setDate(1, sqlRunDate);
						insertActvt.setString(2, division);
						insertActvt.setString(3, occActvt.getBillRnd());
						insertActvt.setString(4, occActvt.getBusType());
						insertActvt.setString(5, occActvt.getOccPhraseCd());
						insertActvt.setLong(6, occActvt.getOccCt());
						insertActvt.setDouble(7, occActvt.getOccAmt());
						
						insertActvt.addBatch();
						actvtBatchCounter++;
						
						if (actvtBatchCounter % 1000 == 0) {
							insertActvt.executeBatch();
						}
						isBillDayOccActvt = true;
					}
					
					/*
					 * Execute the batch after all entries in map are processed
					 */
					insertActvt.executeBatch();
					
					/*
					 * Iterate through the entire map occBTNMap and insert entries into the RABC_BILLDAY_OCC_BTN table.
					 * Maximum 30 records will be inserted in the table for one occ phrase code (ordered in absolute
					 * value of occ amount).
					 */
					Set occBtnSet			= occBTNMap.keySet();
					Iterator occBtnIterator = occBtnSet.iterator();
					int btnCounter = 1;
					String currentPhraseCode = "";
					String previousPhraseCode = "";
					
					while (occBtnIterator.hasNext()) {
						BillDayOccBTN occBTN = (BillDayOccBTN) occBtnIterator.next();
						currentPhraseCode = occBTN.getOccPhraseCd();
						if (previousPhraseCode.equals(currentPhraseCode)) {
							btnCounter++;
						} else {
							btnCounter = 1;
						}
						if (btnCounter <= 30) {
							insertBtn.setDate(1, sqlRunDate);
							insertBtn.setString(2, division);
							insertBtn.setString(3, occBTN.getBillRnd());
							insertBtn.setString(4, occBTN.getBtn());
							insertBtn.setString(5, occBTN.getCustType());
							insertBtn.setString(6, occBTN.getMktInd());
							insertBtn.setString(7, currentPhraseCode);
							insertBtn.setLong(8, occBTN.getOccCt());
							insertBtn.setDouble(9, occBTN.getOccAmt());
							insertBtn.addBatch();
							btnBatchCounter++;
							previousPhraseCode = currentPhraseCode;
						}
						
						if (btnBatchCounter % 1000 == 0) {
							insertBtn.executeBatch();
						}
						isBillDayOccBtn = true;
					}
					
					/*
					 * Execute the batch after all entries in map are processed
					 */
					insertBtn.executeBatch();
					
					/*
					 * Call the private method to make the entries into RABC_TRIG table
					 */
					if (!insertTrigger()) {
						success = false;
					}	
				} catch (SQLException sqle){
					severe(StaticErrorMsgKeys.INSERT_ERROR + sqle.getMessage(), sqle);
					success = false;
				}
			}
		}
		
			return super.postprocessFile(file, success);
		}
	
	/**
	 * This is a method to insert entry into RABC_TRIG table
	 * 
	 * @return boolean
	 */
	private boolean insertTrigger() {
		try {
			String query 	= "SELECT to_char(BILL_RND,'00') FROM RABC_CYCLE_CALENDAR WHERE BILL_RND_DT = to_date('" + runDate + "','MMddyyyy')";
			String billRnd	= RetrieveStaticInfo.getBillRnd(connection, query);
			if ("0".equals(billRnd) || "00".equals(billRnd) || "".equals(billRnd.trim())){
				billRnd = "0";
			}
			
			/*
			 * Check whether there were any activity record inserted, if yes then insert into trigger
			 */
			if (isBillDayOccActvt) {
				if(!RabcLoadJobTrig.insertTrigger(connection, currentFile.getName().substring(5, currentFile.getName().length()), currentFile.getName(), BILLDAY_OCC_ACTVT_FILE_ID, division, runDate , backoutRecovery, billRnd, RABC_TRIG)) {
					return false;	
				}
			}
		} catch (Exception e) {
			severe(StaticErrorMsgKeys.POSTPROCESSFILE_ERROR + StaticErrorMsgKeys.TIGGER_TABLE_INSERT_ERROR + e.getMessage(), e);
			return false;
		}
		
		return true;
	}
	
	/**
	 * Overriding postProcess(success) method.
	 * It is executed post to processing the load job.
	 * It includes the following steps:
	 * 	1) Closes statements that were opened for this load job.
	 * 
	 * @see com.sbc.bac.load.LoadJob#postprocess(boolean)
	 */
	public boolean postprocess(boolean success) {
		try {
			insertActvt.close();
			insertBtn.close();
		} catch (SQLException e) {
			severe(StaticErrorMsgKeys.POSTPROCESS_ERROR + StaticErrorMsgKeys.SQL_CLOSE_ERROR + e.getMessage(), e);
			success = false;
		}
		
		return super.postprocess(success);
	}
}
