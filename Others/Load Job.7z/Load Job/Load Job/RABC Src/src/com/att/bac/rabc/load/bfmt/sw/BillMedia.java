/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.load.bfmt.sw;

import java.util.Date;

import com.sbc.bac.rabc.load.HashCodeUtil;


/**
 * This is a class representing entries in RABC_BILL_PRT_SUMY table.
 * 
 * @author Shailesh Hemdev - SH8512
 */
public class BillMedia {
	private Date runDate;
	private String division;
	private String custClsCd;
	private String docCd;
	private long docCopyCt;
	private int billRound;
			
	/**
	 * @return Returns the billRound.
	 */
	public int getBillRound() {
		return billRound;
	}
	/**
	 * @param billRound The billRound to set.
	 */
	public void setBillRound(int billRound) {
		this.billRound = billRound;
	}

	/**
	 * @return Returns the custClsCd.
	 */
	public String getCustClsCd() {
		return custClsCd;
	}
	/**
	 * @param custClsCd The custClsCd to set.
	 */
	public void setCustClsCd(String custClsCd) {
		this.custClsCd = custClsCd;
	}
	/**
	 * @return Returns the division.
	 */
	public String getDivision() {
		return division;
	}
	/**
	 * @param division The division to set.
	 */
	public void setDivision(String division) {
		this.division = division;
	}
	/**
	 * @return Returns the docCd.
	 */
	public String getDocCd() {
		return docCd;
	}
	/**
	 * @param docCd The docCd to set.
	 */
	public void setDocCd(String docCd) {
		this.docCd = docCd;
	}
	/**
	 * @return Returns the docCopyCt.
	 */
	public long getDocCopyCt() {
		return docCopyCt;
	}
	/**
	 * @param docCopyCt The docCopyCt to set.
	 */
	public void setDocCopyCt(long docCopyCt) {
		this.docCopyCt = docCopyCt;
	}
	/**
	 * @return Returns the runDate.
	 */
	public Date getRunDate() {
		return runDate;
	}
	/**
	 * @param runDate The runDate to set.
	 */
	public void setRunDate(Date runDate) {
		this.runDate = runDate;
	}
	
	/**
	 * Equals method overridden for this object so that it can be stored in a hash map where the key 
	 * would be combination of the following 5 attributes:
	 * Run date
	 * Division
	 * Doc Code
	 * Business type
	 * Bill Round
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object o) {
		// Do a quick check for an identical object reference
	    if (this == o) {
	      return true;
	    }
	    if (!(o instanceof BillMedia)) {
	    	return false;
	    } else {
			if (((BillMedia)o).getRunDate().getTime() == this.getRunDate().getTime()
				&& ((BillMedia)o).getDivision().equalsIgnoreCase(this.getDivision())
				&& ((BillMedia)o).getDocCd().equalsIgnoreCase(this.getDocCd())	
				&& ((BillMedia)o).getCustClsCd().equalsIgnoreCase(this.getCustClsCd())
				&& ((BillMedia)o).getBillRound()== this.getBillRound()
				) {
				return true;
			} else {
				return false;
			}
	    }
	}
	
	/**
	 * Hash code method overridden for this object to categorize this object in sets 
	 * so that the hash collections can search this object efficiently.
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		int hashCode = HashCodeUtil.SEED;
		hashCode = HashCodeUtil.hash( hashCode, this.getCustClsCd());
		hashCode = HashCodeUtil.hash( hashCode, this.getDocCd());
	    return hashCode;
	}
}
