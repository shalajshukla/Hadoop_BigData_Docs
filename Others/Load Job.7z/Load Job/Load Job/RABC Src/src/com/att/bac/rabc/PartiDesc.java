/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc;

/**
 * This is a Data Object to represent RABC_PARTI_DESC table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class PartiDesc {
	private int partiRefId;
	private String partiDesc;
	private String procTbl;
	private int extrctDataCt;

	/**
	 * @return Returns the PartiRefId.
	 */
	public int getPartiRefId() {
		return partiRefId;
	}
	/**
	 * @return Returns the PartiDesc.
	 */
	public String getPartiDesc() {
		return partiDesc;
	}
	/**
	 * @return Returns the ProcTbl.
	 */
	public String getProcTbl() {
		return procTbl;
	}
	/**
	 * @return Returns the ExtrctDataCt.
	 */
	public int getExtrctDataCt() {
		return extrctDataCt;
	}

	/**
	 * @param PartiRefId The partiRefId to set.
	 */
	public void setPartiRefId(int partiRefId) {
		this.partiRefId = partiRefId;
	}
	/**
	 * @param PartiDesc The partiDesc to set.
	 */
	public void setPartiDesc(String partiDesc) {
		this.partiDesc = partiDesc;
	}
	/**
	 * @param ProcTbl The procTbl to set.
	 */
	public void setProcTbl(String procTbl) {
		this.procTbl = procTbl;
	}
	/**
	 * @param ExtrctDataCt The extrctDataCt to set.
	 */
	public void setExtrctDataCt(int extrctDataCt) {
		this.extrctDataCt = extrctDataCt;
	}
}
