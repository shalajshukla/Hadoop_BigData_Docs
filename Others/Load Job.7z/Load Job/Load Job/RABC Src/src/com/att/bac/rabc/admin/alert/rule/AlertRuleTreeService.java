/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.admin.alert.rule;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.att.bac.rabc.DataTblDdlBean;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.StaticDataLoader;
import com.att.bac.rabc.TreeNode;
import com.att.bac.rabc.TreeService;
import com.att.bac.rabc.admin.PresnCalcElem;

/**
 * This is a Alert Rule Tree service class which extends Tree Service class.
 * 
 * @author Vijay Dubey - VD3159
 */
public class AlertRuleTreeService extends TreeService {
	private static final Logger logger = Logger.getLogger(AlertRuleTreeService.class);
	
	protected static final String getCalculationsMap = "select distinct calc_tbl, presn_calc_name, presn_format_code, calc_elem_formula " 
		+ "from rabc_presn_calc_elem " 
		+ "where calc_tbl is not null and presn_calc_name not like '%_PREV'"
		+ "order by calc_tbl";

	/**
	 * Returns the list of dataTblDdl.
	 * 
	 * @param dbNodeId
	 * @param region
	 * @return List
	 */
	public List getDataTblDdlList(String dbNodeId, String region){
		List dataTblDdlList = StaticDataLoader.getDataTblDdlByTblSubsysId(dbNodeId, region);
		List filteredDataTblDdlList = new ArrayList();
		
		int dataTblDdlListSize = dataTblDdlList.size();
		
		for (int i=0;i<dataTblDdlListSize;i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblDdlList.get(i);
			
			String tblName = dataTblDdlBean.getAlertProcTbl();
			List fileIdList = StaticDataLoader.getFileMashByTableName(tblName, region);
			int sizeOfFileIdList = fileIdList.size();
			
			if(sizeOfFileIdList > 0){
				if (dataTblDdlBean.getTblProcDateDdlName()!=null || dataTblDdlBean.getTblBillRndDdlMon()!=null || dataTblDdlBean.getTblBillRndDdlYear()!=null){
					if (dataTblDdlBean.getTblDdlDataType()!=null){
						if ("1".equals(dataTblDdlBean.getTblDdlDataType().trim())){
							filteredDataTblDdlList.add(dataTblDdlBean);
						}
					}
				}
			}
		}
		
		return filteredDataTblDdlList;
	}

	/**
	 * Override the method to get the calculationNode & return null as we don't need to build the list of 
	 * calculations for alert rule definition.
	 * 
	 * @param connection
	 * @param failureList
	 * @return TreeNode
	 */
	public TreeNode getCalculationNode(Connection connection, List failureList){
		return null;
	}

	/**
	 * Override the method to return a map of calculations per table.
	 * 
	 * @param connection
	 * @param failureList
	 * @return HashMap
	 */
	public HashMap getCalculations(Connection connection, List failureList) {
		HashMap calculationMap = null;
		String currentTableName = null;
		String previousTableName = null;
		PresnCalcElem presnCalcElem = null;
		String presnCalcName = null;
		String presnFormatCode = null;
		String calcElemFormula = null;
		List calculationNameList = new ArrayList();
		boolean addFlag = false;
		String sqlStmt =null;
		
		Statement statement = null;
		ResultSet rs = null;
		try {
			calculationMap = new HashMap();
			sqlStmt = AlertRuleTreeService.getCalculationsMap;
			statement = connection.createStatement();
			rs = statement.executeQuery(sqlStmt);
			
			while(rs.next()) {
				addFlag = false;
				currentTableName = rs.getString("CALC_TBL");

				if (previousTableName==null){
					previousTableName = currentTableName ;
				}
								
				if (!previousTableName.equals(currentTableName)){
					calculationMap.put(previousTableName,calculationNameList);
					previousTableName = currentTableName ;
					calculationNameList = new ArrayList();
					addFlag = true;
				}
				
				presnCalcElem = new PresnCalcElem();
				presnCalcName = rs.getString("PRESN_CALC_NAME");
				presnFormatCode = rs.getString("PRESN_FORMAT_CODE");
				calcElemFormula = rs.getString("CALC_ELEM_FORMULA");
				presnCalcElem.setPresnCalcName(presnCalcName);
				presnCalcElem.setPresnFormatCode(presnFormatCode);
				presnCalcElem.setCalcElemFormula(calcElemFormula);
				calculationNameList.add(presnCalcElem);
			}
			if (previousTableName!=null){
				calculationMap.put(previousTableName,calculationNameList);
			}
		}catch(SQLException sqle){
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sqle.getMessage(), sqle);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sqle));
		} finally{
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(statement, failureList, logger);
		}
		
		return calculationMap;
	}
}
