/* Created by Gaurav Bhargava (GB0741) on Dec 11, 2006.
Copyright 2006-2008 AT&T Knowledge Ventures. All rights reserved. */

package com.att.bac.rabc.load.billday.calnet;

import java.io.File;
import java.net.UnknownHostException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import com.att.bac.rabc.load.calnet.CalnetException;
import com.att.bac.rabc.load.calnet.CalnetLoadJob;
import com.att.bac.rabc.util.EmcisEventLogger;
import com.att.carat.util.NetUtil;
import com.sbc.bac.rabc.load.PrepareTableForRerun;
import com.sbc.bac.rabc.load.RabcLoadJobTrig;
import com.sbc.bac.rabc.load.StaticErrorMsgKeys;

/**
 * This class reads the data from files whose name fits the pattern:
 * WE.[CI].C[0-9]{4}.XT31SUMM.* . It gets the files from input folder name specified
 * in BillDayChrgSumm.cfg file. It parses the file line by line and inserts the
 * records into the RABC_TOT_BLG_SUMY, RABC_TOP_ADJ_BLG_AGY and RABC_TOP_OCC_BLG_AGY
 * tables. It also populates RABC_TOT_BLG_SUMY_AVG table from data of
 * RABC_TOT_BLG_SUMY table.
 * @author GB0741
 */
public class TotBlgSumyLoadJob extends CalnetLoadJob {

	List rabcTotBlgSumy = null;
	List rabcTopAdjBlgAgy = null;
	List rabcTopOccBlgAgy = null;
	TreeMap topAdjBlgAgyMap = null;
	TreeMap topOccBlgAgyMap = null;
	private static final int MAX_RECORDS = 30;
	private static final int DENOMINATOR = 1000000;
	private String fileName, region;

	/**
	 * @return ID of the file being processed
	 */
	public String getFileId() {
		return "XT31SUMM";
	}

	/**
	 * @return Table Name for inserting the records.
	 */
	public String getTable() {
		return "RABC_TOT_BLG_SUMY";
	}

//	/**
//	 * @return Table Name for inserting the records.
//	 */
//	public String getBlgSumyAvgTable() {
//		return "RABC_TOT_BLG_SUMY_AVG";
//	}

	/**
	 * @return Table Name for inserting the records.
	 */
	public String getAdjBlgAgyTable() {
		return "RABC_TOP_ADJ_BLG_AGY";
	}

	/**
	 * @return Table Name for inserting the records.
	 */
	public String getOccBlgAgyTable() {
		return "RABC_TOP_OCC_BLG_AGY";
	}

	/**
	 * Initiailizes the list to hold data transfer objects. It parses the filename to
	 * set the values for region, division, cycle, run date, bill round date and
	 * bill round.
	 * @param file object representing the file to be processed
	 */
	public boolean preprocessFile(File file){
		fileName = file.getName();
		region = file.getName().substring(0,2);
		rabcTotBlgSumy = new ArrayList();
		rabcTopAdjBlgAgy = new ArrayList();
		rabcTopOccBlgAgy = new ArrayList();
		topAdjBlgAgyMap = new TreeMap(Collections.reverseOrder());
		topOccBlgAgyMap = new TreeMap(Collections.reverseOrder());
		return super.preprocessFile(file);
	}

	/**
	 * Processes a single record from the load file. A line contains fields that are
	 * semicolon delimited in the format: <FileId>;<AgencyId>;<AcctCt>;<blank>;<PrevBlgAmount>;
	 * <AdjAmount>;<CurrMnthChrgAmount>;<CurrBalDueAmount>;<TollAmount>;<OccAmount>;<BocAmount>;
	 * <AttAmount>;<IecAmount>;<CpucSurchargeAmount>;<FedTaxAmount>;<StateTaxAmount>;
	 * <CityTaxAmount>;<SrvUsffAmount>;<EuclChrgAmount>;<BlgSurchargeAmount>;<ChcfaSurchargeAmount>;
	 * <ChcfbSurchargeAmount>;<LflnSurchargeAmount>;<HcapSurchargeAmount>;<CtfSurchargeAmount>
	 *
	 * @param line record from load file
	 * @return int indicating the return status as Success or Error
	 * @throws Exception Throws exception if there is an error in parsing the fields.
	 */
	protected int processRecord(String line) throws Exception {
		int success;
		if (line.length() < 10)
			return SKIPPED;
		RabcTotBlgSumy blgSmy = new RabcTotBlgSumy();
		RabcTopAdjBlgAgy adjBlgAgy = new RabcTopAdjBlgAgy();
		RabcTopOccBlgAgy occBlgAgy = new RabcTopOccBlgAgy();

		try {
			String[] tokens = line.split(";");
			double adjAmount = 0.0;
			double occAmount = 0.0;

			//RABC_TOT_BLG_SUMY Table
			blgSmy.setRunDate(sqlRunDate);
			blgSmy.setDivision(division);
			blgSmy.setCycle(cycle);
			blgSmy.setAgencyID(tokens[1]);
			blgSmy.setAcctCt(Integer.parseInt(tokens[2]));
			blgSmy.setCurrMnthChrgAmt(Double.parseDouble(tokens[6].trim())/DENOMINATOR);
			blgSmy.setCurrBalDueAmt(Double.parseDouble(tokens[7].trim())/DENOMINATOR);
			blgSmy.setTollAmt(Double.parseDouble(tokens[8].trim())/DENOMINATOR);
			blgSmy.setOccAmt(Double.parseDouble(tokens[9].trim())/DENOMINATOR);
			blgSmy.setBocAmt(Double.parseDouble(tokens[10].trim())/DENOMINATOR);
			blgSmy.setAttAmt(Double.parseDouble(tokens[11].trim())/DENOMINATOR);
			blgSmy.setIecAmt(Double.parseDouble(tokens[12].trim())/DENOMINATOR);
			blgSmy.setCpucSrcgAmt(Double.parseDouble(tokens[13].trim())/DENOMINATOR);
			blgSmy.setFedTaxAmt(Double.parseDouble(tokens[14].trim())/DENOMINATOR);
			blgSmy.setStateTaxAmt(Double.parseDouble(tokens[15].trim())/DENOMINATOR);
			blgSmy.setCityTaxAmt(Double.parseDouble(tokens[16].trim())/DENOMINATOR);
			blgSmy.setSrvUsffAmt(Double.parseDouble(tokens[17].trim())/DENOMINATOR);
			blgSmy.setEuclChrgAmt(Double.parseDouble(tokens[18].trim())/DENOMINATOR);
			blgSmy.setBlgSrcgAmt(Double.parseDouble(tokens[19].trim())/DENOMINATOR);
			blgSmy.setChcfaSrcgAmt(Double.parseDouble(tokens[20].trim())/DENOMINATOR);
			blgSmy.setChcfbSrcgAmt(Double.parseDouble(tokens[21].trim())/DENOMINATOR);
			blgSmy.setLflnSrcgAmt(Double.parseDouble(tokens[22].trim())/DENOMINATOR);
			blgSmy.setHcapSrcgAmt(Double.parseDouble(tokens[23].trim())/DENOMINATOR);
			blgSmy.setCtfSrcgAmt(Double.parseDouble(tokens[24].trim())/DENOMINATOR);
			blgSmy.setSdUndergrdSrcgAmt(Double.parseDouble(tokens[25].trim())/DENOMINATOR);
			blgSmy.setBillRnd(billRnd);
			blgSmy.setBillMm(billRndDate.substring(0,2));
			blgSmy.setBillYear(billRndDate.substring(4,8));

			//RABC_TOP_ADJ_BLG_AGY Table
			adjAmount = Double.parseDouble(tokens[5].trim()) / DENOMINATOR;
			adjBlgAgy.setRunDate(sqlRunDate);
			adjBlgAgy.setDivision(division);
			adjBlgAgy.setCycle(cycle);
			adjBlgAgy.setAgencyID(tokens[1]);
			adjBlgAgy.setAdjAmt(adjAmount);
			adjBlgAgy.setPrevBlgAmt(Double.parseDouble(tokens[4].trim()) / DENOMINATOR);
			adjBlgAgy.setCurrMnthChrgAmt(Double.parseDouble(tokens[6].trim()) / DENOMINATOR);
			adjBlgAgy.setCurrBalDueAmt(Double.parseDouble(tokens[7].trim()) / DENOMINATOR);
			adjBlgAgy.setBillRnd(billRnd);
			adjBlgAgy.setBillMm(billRndDate.substring(0,2));
			adjBlgAgy.setBillYear(billRndDate.substring(4,8));

			//RABC_TOP_OCC_BLG_AGY Table
			occAmount = Double.parseDouble(tokens[9].trim()) / DENOMINATOR;
			occBlgAgy.setRunDate(sqlRunDate);
			occBlgAgy.setDivision(division);
			occBlgAgy.setCycle(cycle);
			occBlgAgy.setAgencyID(tokens[1].trim());
			occBlgAgy.setOccAmt(occAmount);
			occBlgAgy.setPrevBlgAmt(Double.parseDouble(tokens[4].trim()) / DENOMINATOR);
			occBlgAgy.setCurrMnthChrgAmt(Double.parseDouble(tokens[6].trim()) / DENOMINATOR);
			occBlgAgy.setCurrBalDueAmt(Double.parseDouble(tokens[7].trim()) / DENOMINATOR);
			occBlgAgy.setBillRnd(billRnd);
			occBlgAgy.setBillMm(billRndDate.substring(0,2));
			occBlgAgy.setBillYear(billRndDate.substring(4,8));

			rabcTotBlgSumy.add(blgSmy);

			//Add adjBlgAgy to a list in TreeMap to have multiple values against an adjustment value
			Double adjAmt = new Double(Math.abs(adjAmount));
			if(!topAdjBlgAgyMap.containsKey(adjAmt)){
				topAdjBlgAgyMap.put(adjAmt, new ArrayList());
			}
			((ArrayList)topAdjBlgAgyMap.get(adjAmt)).add(adjBlgAgy);


			//Add occBlgAgy to a list in TreeMap to have multiple values against a OCC value
			Double occAmt = new Double(Math.abs(occAmount));
			if(!topOccBlgAgyMap.containsKey(occAmt)){
				topOccBlgAgyMap.put(occAmt, new ArrayList());
			}
			((ArrayList)topOccBlgAgyMap.get(occAmt)).add(occBlgAgy);

			lineCount++;
			success = SUCCESS;
		}
		catch (Exception ex) {
			severe(StaticErrorMsgKeys.PARSELINE_ERROR + " Agency ID " + blgSmy.getAgencyID() + ex.getMessage(), ex);
			success = ERROR;
		}
		return success;
	}

	/**
	 * Inserts the processed data into RABC_TOT_BLG_SUMY, RABC_TOT_BLG_SUMY_AVG,
	 * RABC_TOP_ADJ_BLG_AGY and RABC_TOP_OCC_BLG_AGY tables.
	 * Calls postprocessFile method of base class in the end.
	 * @param file object representing load file
	 * @param success boolean indicating success or failure of previous action
	 * @return boolean indicating success or failure
	 */
	public boolean postprocessFile(File file, boolean success) {
		try{
			//Log the file information to EMCIS_EVENT_LOG and EMCIS_EVENT_LOG_DETAIL
			EmcisEventLogger emcisLogger = new EmcisEventLogger();
			String event_id = "RABC_"+getFileId()+"_"+region;
            String host = NetUtil.getLocalHostName();
            String hostIP = NetUtil.getLocalIpAddress();
			int sequence = emcisLogger.getEMCISSequence(connection);
			emcisLogger.insertEventLog(connection, sequence, event_id, sqlRunDate, host, hostIP);
			emcisLogger.insertEventLogDetail(connection, sequence, "FileName", fileName);

		}catch (UnknownHostException e) {
            severe("Error getting EMCIS host information ", e);
        }
		if(success){
			populateLists();

			RabcTotBlgSumyDAO daoTotBlgSumy = new RabcTotBlgSumyDAO();
//			RabcTotBlgSumyAvgDAO daoTotBlgSumyAvg = new RabcTotBlgSumyAvgDAO();
			RabcTopAdjBlgAgyDAO daoTopAdjBlgAgy = new RabcTopAdjBlgAgyDAO();
			RabcTopOccBlgAgyDAO daoTopOccBlgAgy = new RabcTopOccBlgAgyDAO();

			try{
				success = daoTotBlgSumy.insertBatchOfRecords(connection, rabcTotBlgSumy, 1000);
//				if (success)
//					success = daoTotBlgSumyAvg.insertRecords(connection, sqlRunDate, division);
				if (success)
					success = daoTopAdjBlgAgy.insertBatchOfRecords(connection, rabcTopAdjBlgAgy, 1000);
				if (success)
					success = daoTopOccBlgAgy.insertBatchOfRecords(connection, rabcTopOccBlgAgy, 1000);
			}catch(CalnetException ex){
				severe(ex.getMessage(), ex);
				success = false;
			}
			catch(Exception ex){
				severe(ex.getMessage(), ex);
				success = false;
			}
		}
		rabcTotBlgSumy = null;
		rabcTopAdjBlgAgy = null;
		rabcTopOccBlgAgy = null;

		return super.postprocessFile(file, success);
	}

	/**
	 * If the data for file being processed has already been loaded then this mehod is
	 * called to delete the records from tables affected by the Job based on division
	 * and run date.
	 * @return success boolean indicating success or failure of previous action
	 */
	protected boolean deleteTable() {
		boolean success;
		backoutRecovery = "Y";
		success = PrepareTableForRerun.deleteTableData(connection, getTable(), division, sqlRunDate);
//		if(success)
//			success = PrepareTableForRerun.deleteTableData(connection, getBlgSumyAvgTable(), division, sqlRunDate);
		if(success)
			success = PrepareTableForRerun.deleteTableData(connection, getAdjBlgAgyTable(), division, sqlRunDate);
		if(success)
			success = PrepareTableForRerun.deleteTableData(connection, getOccBlgAgyTable(), division, sqlRunDate);

		return success;
	}

	/**
	 * Populates Adjustment and Occ amount Lists for top 30 values.
	 */
	private void populateLists() {
		int adjListCount = 0;
		int occListCount = 0;

		Set adjEntries = topAdjBlgAgyMap.entrySet();
		Iterator adjAmtIter = adjEntries.iterator();
    	while (adjAmtIter.hasNext()) {
    		Map.Entry e = (Map.Entry)adjAmtIter.next();
    		Double amount = (Double)e.getKey();
    		ArrayList arr = (ArrayList)topAdjBlgAgyMap.get(amount);
    		for(Iterator itrList=arr.iterator(); itrList.hasNext();) {
    			rabcTopAdjBlgAgy.add(itrList.next());
    			adjListCount++;
    			if (adjListCount==MAX_RECORDS) break;
    		}
    		if (adjListCount==MAX_RECORDS) break;
    	}

	    Set occEntries = topOccBlgAgyMap.entrySet();
		Iterator occAmtIter = occEntries.iterator();
    	while (occAmtIter.hasNext()) {
    		Map.Entry e = (Map.Entry)occAmtIter.next();
    		Double amount = (Double)e.getKey();
    		ArrayList arr = (ArrayList)topOccBlgAgyMap.get(amount);
    		for(Iterator itrList=arr.iterator(); itrList.hasNext();) {
    			rabcTopOccBlgAgy.add(itrList.next());
    			occListCount++;
    			if (occListCount==MAX_RECORDS) break;
    		}
    		if (occListCount==MAX_RECORDS) break;
    	}
	}
	
	/**
	 * Inserts a record into RABC_TRIG table indicating that file has been processed for a given run
	 * date
	 *
	 * @return boolean indicating success or failure
	 */
	protected boolean insertTrigger() {
		if (!RabcLoadJobTrig.insertTrigger(connection, currentFile.getName(), "XT31SUMM", division, runDate,
				backoutRecovery, billRnd) ||
				!RabcLoadJobTrig.insertTrigger(connection, currentFile.getName(), "XT31AADJ", division, runDate,
						backoutRecovery, billRnd) ||
				!RabcLoadJobTrig.insertTrigger(connection, currentFile.getName(), "XT31AOCC", division, runDate,
								backoutRecovery, billRnd)) {
			return false;
		}
		return true;

	}	
}
