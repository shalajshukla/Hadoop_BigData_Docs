/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.admin.alert.rule;

import java.util.ArrayList;
import java.util.List;

import com.att.bac.rabc.Column;
import com.att.bac.rabc.PickList;

/**
 * This is a Data Object for Alert Keys.
 * 
 * @author Shashank Weginwar - SW3562
 */
public class AlertKey {
	private String tableName;
	private String viewName;
	private int keyLevel;
	private String fileId;
	private List fileIdList;
	private String key1 = "DIVISION";
	private String key2;
	private String key3;
	private String key4;
	private String key5;
	private List columnList;
	private String allowUpdate;
	

	/**
	 * Constructor to initialise all List variables & allowUpdate variable.
	 */
	public AlertKey(){
		this.fileIdList = new ArrayList();
		this.columnList = new ArrayList();
		this.allowUpdate = "N";
	}
	
	/**
	 * @return Returns the columnList.
	 */
	public List getColumnList() {
		return columnList;
	}
	/**
	 * @param columnList The columnList to add.
	 */
	public void addColumn(Column column) {
		this.columnList.add(column);
	}
	/**
	 * @return Returns the fileIdList.
	 */
	public List getFileIdList() {
		return fileIdList;
	}
	/**
	 * @param fileIdList The fileIdList to add.
	 */
	public void addFileId(PickList fileId) {
		this.fileIdList.add(fileId);
	}
	/**
	 * @return Returns the keyLevel.
	 */
	public int getKeyLevel() {
		return keyLevel;
	}
	/**
	 * @param keyLevel The keyLevel to set.
	 */
	public void setKeyLevel(int keyLevel) {
		this.keyLevel = keyLevel;
	}
	/**
	 * @return Returns the fileId.
	 */
	public String getFileId() {
		return fileId;
	}
	/**
	 * @param fileId The fileId to set.
	 */
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	/**
	 * @return Returns the key1.
	 */
	public String getKey1() {
		return key1;
	}
	/**
	 * @param key1 The key1 to set.
	 */
	public void setKey1(String key1) {
		this.key1 = key1;
	}
	/**
	 * @return Returns the key2.
	 */
	public String getKey2() {
		return key2;
	}
	/**
	 * @param key2 The key2 to set.
	 */
	public void setKey2(String key2) {
		this.key2 = key2;
	}
	/**
	 * @return Returns the key3.
	 */
	public String getKey3() {
		return key3;
	}
	/**
	 * @param key3 The key3 to set.
	 */
	public void setKey3(String key3) {
		this.key3 = key3;
	}
	/**
	 * @return Returns the key4.
	 */
	public String getKey4() {
		return key4;
	}
	/**
	 * @param key4 The key4 to set.
	 */
	public void setKey4(String key4) {
		this.key4 = key4;
	}
	/**
	 * @return Returns the key5.
	 */
	public String getKey5() {
		return key5;
	}
	/**
	 * @param key5 The key5 to set.
	 */
	public void setKey5(String key5) {
		this.key5 = key5;
	}
	/**
	 * @return Returns the tableName.
	 */
	public String getTableName() {
		return tableName;
	}
	/**
	 * @param tableName The tableName to set.
	 */
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	/**
	 * @return Returns the viewName.
	 */
	public String getViewName() {
		return viewName;
	}
	/**
	 * @param viewName The viewName to set.
	 */
	public void setViewName(String viewName) {
		this.viewName = viewName;
	}
	/**
	 * @return Returns the allowUpdate.
	 */
	public String getAllowUpdate() {
		return allowUpdate;
	}
	/**
	 * @param allowUpdate The allowUpdate to set.
	 */
	public void setAllowUpdate(String allowUpdate) {
		this.allowUpdate = allowUpdate;
	}
}
