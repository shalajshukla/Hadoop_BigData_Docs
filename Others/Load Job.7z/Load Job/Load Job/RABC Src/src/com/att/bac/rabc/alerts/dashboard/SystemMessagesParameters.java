/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/

package com.att.bac.rabc.alerts.dashboard;

/**
 * This class represents the System Message parameters.
 * 
 * @author Abhilash - AC6957
 */
public class SystemMessagesParameters {
	private String webPageId = "RABCPSF00006";
	private String dateType = "run";
	private String startDate;
	private String endDate;
	private String upStartDate;
	private String upEndDate;
	private String controlPoint;
	private String alertRule;
	private String division="";
	private String alertInstant;
	private String alertRuleTiming; // Record,Billing,CallDay of Week
	private String alertRuleTimingIndicator;
	private String revenueImpactValue;
	private double revenueImpactValueHidden;
	private String revenueImpactIndicator = "Greater than";
	private String alertStatus;
	private String rootCatgyCd;
	private String alertGroup;
	private String msgNo;
	private String systemErrorType;
	private String fileSeqNum;
	//These parameters have to discussed.
	private String webId;
	private String needPage;
	private String head1 = "testing";
	private String pageId;
	private String fromPage;
	private String severelvl;
	private String controlPointHidden;
	private String divisionHidden;
	private String systemErrorDesc; // New attribute added to address issue LC#14
	
	/**
	 * @return Returns the alertGroup.
	 */
	public String getAlertGroup() {
		return alertGroup;
	}
	/**
	 * @param alertGroup The alertGroup to set.
	 */
	public void setAlertGroup(String alertGroup) {
		this.alertGroup = alertGroup;
	}
	/**
	 * @return Returns the alertInstant.
	 */
	public String getAlertInstant() {
		return alertInstant;
	}
	/**
	 * @param alertInstant The alertInstant to set.
	 */
	public void setAlertInstant(String alertInstant) {
		this.alertInstant = alertInstant;
	}
	/**
	 * @return Returns the alertRule.
	 */
	public String getAlertRule() {
		return alertRule;
	}
	/**
	 * @param alertRule The alertRule to set.
	 */
	public void setAlertRule(String alertRule) {
		this.alertRule = alertRule;
	}
	/**
	 * @return Returns the alertRuleTiming.
	 */
	public String getAlertRuleTiming() {
		return alertRuleTiming;
	}
	/**
	 * @param alertRuleTiming The alertRuleTiming to set.
	 */
	public void setAlertRuleTiming(String alertRuleTiming) {
		this.alertRuleTiming = alertRuleTiming;
	}
	/**
	 * @return Returns the alertRuleTimingIndicator.
	 */
	public String getAlertRuleTimingIndicator() {
		return alertRuleTimingIndicator;
	}
	/**
	 * @param alertRuleTimingIndicator The alertRuleTimingIndicator to set.
	 */
	public void setAlertRuleTimingIndicator(String alertRuleTimingIndicator) {
		this.alertRuleTimingIndicator = alertRuleTimingIndicator;
	}
	/**
	 * @return Returns the alertStatus.
	 */
	public String getAlertStatus() {
		return alertStatus;
	}
	/**
	 * @param alertStatus The alertStatus to set.
	 */
	public void setAlertStatus(String alertStatus) {
		this.alertStatus = alertStatus;
	}
	/**
	 * @return Returns the controlPoint.
	 */
	public String getControlPoint() {
		return controlPoint;
	}
	/**
	 * @param controlPoint The controlPoint to set.
	 */
	public void setControlPoint(String controlPoint) {
		this.controlPoint = controlPoint;
	}
	/**
	 * @return Returns the dateType.
	 */
	public String getDateType() {
		return dateType;
	}
	/**
	 * @param dateType The dateType to set.
	 */
	public void setDateType(String dateType) {
		this.dateType = dateType;
	}
	/**
	 * @return Returns the division.
	 */
	public String getDivision() {
		return division;
	}
	/**
	 * @param division The division to set.
	 */
	public void setDivision(String division) {
		this.division = division;
	}
	/**
	 * @return Returns the endDate.
	 */
	public String getEndDate() {
		return endDate;
	}
	/**
	 * @param endDate The endDate to set.
	 */
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	/**
	 * @return Returns the msgNo.
	 */
	public String getMsgNo() {
		return msgNo;
	}
	/**
	 * @param msgNo The msgNo to set.
	 */
	public void setMsgNo(String msgNo) {
		this.msgNo = msgNo;
	}
	/**
	 * @return Returns the revenueImpactIndicator.
	 */
	public String getRevenueImpactIndicator() {
		return revenueImpactIndicator;
	}
	/**
	 * @param revenueImpactIndicator The revenueImpactIndicator to set.
	 */
	public void setRevenueImpactIndicator(String revenueImpactIndicator) {
		this.revenueImpactIndicator = revenueImpactIndicator;
	}
	/**
	 * @return Returns the revenueImpactValue.
	 */
	public String getRevenueImpactValue() {
		return revenueImpactValue;
	}
	/**
	 * @param revenueImpactValue The revenueImpactValue to set.
	 */
	public void setRevenueImpactValue(String revenueImpactValue) {
		this.revenueImpactValue = revenueImpactValue;
	}
	/**
	 * @return Returns the rootCatgyCd.
	 */
	public String getRootCatgyCd() {
		return rootCatgyCd;
	}
	/**
	 * @param rootCatgyCd The rootCatgyCd to set.
	 */
	public void setRootCatgyCd(String rootCatgyCd) {
		this.rootCatgyCd = rootCatgyCd;
	}
	/**
	 * @return Returns the startDate.
	 */
	public String getStartDate() {
		return startDate;
	}
	/**
	 * @param startDate The startDate to set.
	 */
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	/**
	 * @return Returns the systemErrorType.
	 */
	public String getSystemErrorType() {
		return systemErrorType;
	}
	/**
	 * @param systemErrorType The systemErrorType to set.
	 */
	public void setSystemErrorType(String systemErrorType) {
		this.systemErrorType = systemErrorType;
	}
	/**
	 * @return Returns the upEndDate.
	 */
	public String getUpEndDate() {
		return upEndDate;
	}
	/**
	 * @param upEndDate The upEndDate to set.
	 */
	public void setUpEndDate(String upEndDate) {
		this.upEndDate = upEndDate;
	}
	/**
	 * @return Returns the upStartDate.
	 */
	public String getUpStartDate() {
		return upStartDate;
	}
	/**
	 * @param upStartDate The upStartDate to set.
	 */
	public void setUpStartDate(String upStartDate) {
		this.upStartDate = upStartDate;
	}
	/**
	 * @return Returns the webPageId.
	 */
	public String getWebPageId() {
		return webPageId;
	}
	/**
	 * @param webPageId The webPageId to set.
	 */
	public void setWebPageId(String webPageId) {
		this.webPageId = webPageId;
	}
	
	
	/**
	 * @return Returns the fileSeqNum.
	 */
	public String getFileSeqNum() {
		return fileSeqNum;
	}
	/**
	 * @param fileSeqNum The fileSeqNum to set.
	 */
	public void setFileSeqNum(String fileSeqNum) {
		this.fileSeqNum = fileSeqNum;
	}
	
	/**
	 * @return Returns the head1.
	 */
	public String getHead1() {
		return head1;
	}
	/**
	 * @param head1 The head1 to set.
	 */
	public void setHead1(String head1) {
		this.head1 = head1;
	}
	
	
	/**
	 * @return Returns the severelvl.
	 */
	public String getSeverelvl() {
		return severelvl;
	}
	/**
	 * @param severelvl The severelvl to set.
	 */
	public void setSeverelvl(String severelvl) {
		this.severelvl = severelvl;
	}
	
	/**
	 * @return Returns the fromPage.
	 */
	public String getFromPage() {
		return fromPage;
	}
	/**
	 * @param fromPage The fromPage to set.
	 */
	public void setFromPage(String fromPage) {
		this.fromPage = fromPage;
	}
	/**
	 * @return Returns the needPage.
	 */
	public String getNeedPage() {
		return needPage;
	}
	/**
	 * @param needPage The needPage to set.
	 */
	public void setNeedPage(String needPage) {
		this.needPage = needPage;
	}
	/**
	 * @return Returns the pageId.
	 */
	public String getPageId() {
		return pageId;
	}
	/**
	 * @param pageId The pageId to set.
	 */
	public void setPageId(String pageId) {
		this.pageId = pageId;
	}
	/**
	 * @return Returns the webId.
	 */
	public String getWebId() {
		return webId;
	}
	/**
	 * @param webId The webId to set.
	 */
	public void setWebId(String webId) {
		this.webId = webId;
	}
	
	
	/**
	 * @return Returns the controlPointHidden.
	 */
	public String getControlPointHidden() {
		return controlPointHidden;
	}
	/**
	 * @param controlPointHidden The controlPointHidden to set.
	 */
	public void setControlPointHidden(String controlPointHidden) {
		this.controlPointHidden = controlPointHidden;
	}
	/**
	 * @return Returns the divisionHidden.
	 */
	public String getDivisionHidden() {
		return divisionHidden;
	}
	/**
	 * @param divisionHidden The divisionHidden to set.
	 */
	public void setDivisionHidden(String divisionHidden) {
		this.divisionHidden = divisionHidden;
	}
	/**
	 * @return Returns the revenueImpactValueHidden.
	 */
	public double getRevenueImpactValueHidden() {
		return revenueImpactValueHidden;
	}
	/**
	 * @param revenueImpactValueHidden The revenueImpactValueHidden to set.
	 */
	public void setRevenueImpactValueHidden(double revenueImpactValueHidden) {
		this.revenueImpactValueHidden = revenueImpactValueHidden;
	}
	
	/**
	 * @return Returns the systemErrorDesc.
	 */
	public String getSystemErrorDesc() {
		return systemErrorDesc;
	}
	/**
	 * @param systemErrorDesc The systemErrorDesc to set.
	 */
	public void setSystemErrorDesc(String systemErrorDesc) {
		this.systemErrorDesc = systemErrorDesc;
	}
}
