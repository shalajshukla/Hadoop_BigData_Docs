/*
 * Copyright  2002-2006 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.adhoc.rpt.generator;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;

import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.adhoc.AdhocConstants;
import com.att.bac.rabc.adhoc.aria.ARIACalculationColumnRABC;
import com.att.bac.rabc.adhoc.aria.ARIADecodeColumnRABC;
import com.att.bac.rabc.adhoc.aria.ARIAReportRABC;
import com.att.bac.rabc.adhoc.aria.ARIASimpleColumnRABC;
import com.att.bac.rabc.adhoc.rpt.AdhocRptDAO;
import com.att.bac.rabc.adhoc.rpt.AdhocRptDataTO;
import com.sbc.bac.aria.ARIAColumn;
import com.sbc.bac.aria.ARIADataPoint;
import com.sbc.bac.aria.ARIAJoin;
import com.sbc.bac.aria.ARIAReport;
import com.sbc.bac.aria.ARIAReportException;
import com.sbc.bac.aria.ARIASort;
import com.sbc.bac.aria.ARIASource;


/**
 * Base class for adhoc query generation.
 * 
 * <p>
 * <hr>
 * <h3>Release History</h3>
 * <p>
 * <ul>
 * 
 * <li>jb6494 Aug 29, 2006 Created class.
 * <li>jb6494 Mar 03, 2007 Updated sorting for ST ML#08
 * <li>jb6494 Mar 13, 2007 ML18 Calculations on views
 * <li>jb6494 Mar 15, 2007 Kin - Key causes background error
 * 
 * </ul>
 * <p>
 * 
 */
public abstract class AbstractAdhocGenerator implements AdhocConstants {
    public static Logger logger = Logger.getLogger(AbstractAdhocGenerator.class);

    protected static final String BASE_DATE = "01/01/2005";

    protected static final String BILL_ROUND = "B";

    protected static final String DATEFORMAT = "MM/dd/yyyy";

    protected static final String EMPTY_STRING = "";

    protected static final String MONTHLY = "M";

    protected static final String NO = "N";

    protected static final String SIX_MONTHS_FIELD = "SIX_MONTHS";

    protected static final String YES = "Y";

    private int expandedCount;

    private AdhocGeneratorLegacy legacy;

    private HashMap nameToDataPointMap = new HashMap();

    protected ARIAReportRABC report;


    /**
     * Create a table.column result
     * 
     * @param table
     * @param column
     * @return
     */
    protected static String dot(String table, String column) {
        return table.trim() + "." + column.trim();
    }


    /**
     * Isolate all the stupid if !null && = bs.
     * 
     * @param haystack
     * @param needle
     * @return
     */
    protected static boolean isNotNullEQ(String haystack, String needle) {
        if (haystack == null) {
            return false;
        }
        return haystack.trim().equalsIgnoreCase(needle);
    }


    /**
     * Create the query for the report
     * 
     * @param dto
     * @param sectionIndex
     * @return
     * @throws RABCException
     */
    public abstract ARIAReportRABC generateQuery(AdhocRptDataTO dto, int sectionIndex) throws RABCException;


    /**
     * @param table
     * @param limit
     * @return
     */
    private String convertViewToTable(String table, String limit) {
        while (limit.indexOf("VW_") >= 0) {
            int index = limit.indexOf("VW_");
            int length = limit.substring(index).indexOf('.');
            limit = limit.replaceAll(limit.substring(index,index+length), table);
//            limit = limit.substring(0, index) + table + limit.substring(length);
        }
        return limit;
    }


    /**
     * Check for duplicate data column names.
     * 
     * @param dto
     * @param name
     * @return
     */
    private int getDuplicateColumnCount(AdhocRptDataTO dto, String name) {
        int count = 0;
        Iterator i = dto.getColumnsHeadersList().iterator();
        while (i.hasNext()) {
            String element = (String) i.next();
            if (name.equals(element)) {
                count++;
            }
        }
        return count;
    }


    /**
     * Add ARIAColumns objects to the report object.
     * 
     * @param dto
     * @param loopCount
     * @throws RABCException
     */
    protected abstract void addARIAColumns(AdhocRptDataTO dto, int loopCount) throws RABCException;


    /**
     * Add AriaSort objects to the report object.
     * 
     * @param dto
     * @param loopCount
     */
    protected abstract void addARIAOrderBy(AdhocRptDataTO dto, int loopCount);


    /**
     * Add the name (key) and data point (value) the the nameToDataPointMap
     * 
     * @param name
     * @param dp
     */
    protected void addDataPointReference(String name, ARIADataPoint dp) {
        nameToDataPointMap.put(name.toUpperCase(), dp);
    }


    /**
     * Join all the sources keys to the first source.
     * 
     * @param report
     * @param keyCount
     */
    protected void addJoins(ARIAReport report, int keyCount) {
        if (report.getSources().size() <= 1) {
            return;
        }

        ARIASource base = ((ARIASource) report.getSources().get(0));

        List temp = new ArrayList(report.getSources());
        temp.remove(0);
        ARIASource[] theRest = (ARIASource[]) temp.toArray(new ARIASource[temp.size()]);

        ARIADataPoint[] baseKeys = (ARIADataPoint[]) base.getKeys().toArray(new ARIADataPoint[base.getKeys().size()]);
        for (int i = 0; i < keyCount; i++) {
            for (int j = 0; j < theRest.length; j++) {
                ARIADataPoint dp = (ARIADataPoint) new ArrayList(theRest[j].getKeys()).get(i);
                report.addJoin(new ARIAJoin(dp, baseKeys[i]));
            }
        }

        addHardWiredJoins(report);
    }


    /**
     * Create and add AriaSource objects to the report object.
     * 
     * @param dto
     * @param index
     */
    protected abstract void buildAriaSource(AdhocRptDataTO dto);


    /**
     * Create an ARIASource with the following limits
     * <p>
     * Please change the Adhoc report. For any adhoc report which 'PRESN_TREND_TIME' defined as 'B' (bill rnd report).
     * Add (bill_rnd != 0 or bill_rnd is not null) as additional data selection criteria. do not hard code the
     * 'bill_rnd', as usual the actuall name of 'Bill_rnd' come from RABC_DATA_TBL_DDL. I believe your program should
     * already use it in the SQL. For people want to see the Bill rnd 0 data. you can create 'no bill' call view then
     * create 'daily' Adhoc report using the 'no bill call' view' to see the 'no bill' call data. Since the Adhoc Report
     * defined as Daily, the Bill rnd will not be used.
     * 
     * @return
     */
    protected ARIASource createAriaSource(AdhocRptDataTO dto) {
        String tableName = getLegacy().viewTbl;
        String whereClause = convertViewToTable(tableName, getLegacy().getWhereClause());
        whereClause += addHardwiredConditions(tableName);
        ARIASource source = null;
        source = report.createSource(tableName, whereClause);
        if (dto.getPresnTrendTime().equals("B")) {
            String billRoundName = getLegacy().getBillRoundName();
            if (billRoundName != null) {
                String limit = source.getLimit();
                if ("on".equals(dto.getBillRoundCheck())){
                	limit += " AND (" + dot(tableName, billRoundName) + " <> 0 AND " + dot(tableName, billRoundName) + " IS NOT NULL)";
                }
                source.setLimit(limit);
            }
        }
        
        int index = Integer.parseInt(source.getId().substring(5));
        if (!dto.isProcDateUsed(index)) {
            String year = dto.getProcYearField(index);
            String month = dto.getProcMonthField(index);
            
            ARIADataPoint dp = source.createData(year);
            addDataPointReference(dot(getLegacy().viewTbl, year), dp);
            
            dp = source.createData(month);
            addDataPointReference(dot(getLegacy().viewTbl, month), dp);
        }
        return source;
    }


    /**
     * Create a calc column
     * 
     * @param dto
     * @param columnIndex
     * @param loopCount
     * @param index
     * @return
     * @throws RABCException
     */
    protected ARIAColumn createCalculationColumn(AdhocRptDataTO dto, int columnIndex, int loopCount, int index) throws RABCException {
        String columnHeader = getColumnHeader(dto, index);
        Calculation calc = new AdhocRptDAO().getCalcElem(dto, columnIndex, loopCount);
        ARIACalculationColumnRABC col = new ARIACalculationColumnRABC(columnHeader, calc, report, index);
        return col;
    }

    
    /**
     * Create a "previous data" column using the ORACLE lag function
     * 
     * @param dp
     * @param columnHeader
     * @param outputPattern
     * @param columnIndex
     * @param loopCount
     * @return
     */
    protected ARIAColumn createPreviousDataColumn(AdhocRptDataTO dto, ARIADataPoint dp, String columnHeader, String outputPattern, int columnIndex, int loopCount) {

        //
        // Create the over code. It is ordered by all the keys.
        //
        final StringBuffer orderBuf = new StringBuffer(100);
        orderBuf.append(" OVER(ORDER BY ");
        orderBuf.append(getDP(dto, 0, "PROC_DATE").toString());
        orderBuf.append(',');
        Iterator i = dto.getKeysRow1AliasList().iterator();
        while (i.hasNext()) {
            String key = (String) i.next();
            if (key != null) {
                orderBuf.append(getDP(dto, loopCount, key).toString());
                orderBuf.append(',');
            }
        }
        orderBuf.replace(orderBuf.lastIndexOf(","), orderBuf.lastIndexOf(",") + 1, ") ");

        //
        // Create the column
        //
        ARIAColumn c = new ARIASimpleColumnRABC(dp, columnHeader, null, outputPattern, columnIndex) {
            public String toSQL() {
                StringBuffer buf = new StringBuffer(50);
                buf.append("LAG(");
                if (getDataPoint().getFunction() != null) {
                    buf.append(getDataPoint().getFunction().toSQL(getDataPoint().toString()));
                } else {
                    buf.append(getDataPoint().toString());
                }
                buf.append(") ");
                buf.append(orderBuf);
                buf.append(" \"");
                buf.append(getName());
                return buf.toString();
            }
        };

        return c;
    }


    /**
     * Create a subtotal decode column. This exact returned value is based on the layout
     * 
     * @param dto
     * @param loopCount
     * @return
     */
    protected ARIADecodeColumnRABC createSubTotalColumn(AdhocRptDataTO dto, int loopCount) {
        ARIADecodeColumnRABC col = null;

        switch (dto.getPresnModel()) {
            case 1:
                col = new ARIADecodeColumnRABC("File Date", null, "mm/dd/yyyy", -2);
                col.addGroupingDataPoint(getDP(dto, 0, "PROC_DATE"));
                col.addValue(1, TOTAL);
                col.addValue(2, GRAND_TOTAL);
                break;
            case 2:
                col = new ARIADecodeColumnRABC("File Date", null, "mm/dd/yyyy", -2);
                col.addGroupingDataPoint(getDP(dto, 0, "PROC_DATE"));
                col.addValue(1, TOTAL);
                col.addValue(2, GRAND_TOTAL);
                break;
            case 3:
                col = new ARIADecodeColumnRABC("File Date", null, "mm/dd/yyyy", -2);
                col.addGroupingDataPoint(getDP(dto, 0, "PROC_DATE"));
                col.addValue(1, TOTAL);
                col.addValue(2, TOTAL);
                break;
            case 4:
                col = new ARIADecodeColumnRABC("File Date", null, "mm/dd/yyyy", -2);
                col.addGroupingDataPoint(getDP(dto, 0, "PROC_DATE"));
                col.addValue(1, TOTAL);
                col.addValue(2, GRAND_TOTAL);
                break;
            default:
        }

        col.setDefaultValue(getDP(dto, 0, "PROC_DATE"));
        return col;
    }


    /**
     * for testing
     */
    protected void debugARIAReport() {
        try {
            logger.info("\nARIAReport SQL:\n" + report.toSQL() + "\n");
        } catch (ARIAReportException e) {
            e.printStackTrace();
        }
    }


    /**
     * Get the column header. Special conditions exist if the header is "RTOTAL" or "LTOTAL"
     * 
     * @param adhocRptDataTO
     * @param index
     * @return
     */
    protected String getColumnHeader(AdhocRptDataTO dto, int index) {
        String header = dto.getColumnsHeadersList().get(index).toString();
        if (header.indexOf(".") != -1) {
            header = header.replace('.', ' ');
        } else if (header.equalsIgnoreCase("RTOTAL")) {
            header = "Right Side Total";
        } else if (dto.getColumnsHeadersList().get(index).toString().equalsIgnoreCase("LTOTAL")) {
            header = "Left Side Total";
        }

        // Make sure we don't have mismatched sizes in this silly array
        int missing = dto.getColumnsHeadersList().size() - dto.getColumnsHeadersListExpanded().size();
        if (missing > 0) {
            for (int i = 0; i < missing; i++) {
                dto.getColumnsHeadersListExpanded().add("");
            }
        }

        if ((header.length() > 30) || (getDuplicateColumnCount(dto, (String) dto.getColumnsHeadersList().get(index)) > 1)) {
            dto.getColumnsHeadersListExpanded().set(index, dto.getColumnsHeadersList().get(index));
            dto.getColumnsHeadersList().set(index, "___E" + expandedCount++);
            header = dto.getColumnsHeadersList().get(index).toString();
        }

        return header;
    }


    /**
     * Get the data point matching the name
     * 
     * @param name
     * @return
     */
    protected ARIADataPoint getDataPoint(String name) {
        if (name == null) {
            logger.warn("getDataPoint", "name is null");
            return null;
        }
        return (ARIADataPoint) nameToDataPointMap.get(name.toUpperCase().trim());
    }


    /**
     * Lookup DP from the mapped data points
     * 
     * @param dto
     * @param index
     * @param name
     * 
     * @return
     */
    protected ARIADataPoint getDP(AdhocRptDataTO dto, int index, String name) {
        if (name == null) {
            logger.warn("getDP was passed a null for name");
            return null;
        }
        if ((!("PROC_DATE".equals(name))) && (!("file_seq_num".equals(name)))){
        	if (index<dto.getPresnCalcNumList().size() && !EMPTY_STRING.equals(dto.getPresnCalcNumList().get(index).toString())) {
            	ARIADataPoint dp = getDataPoint(name);
            	if (dp == null) {
                    logger.warn("getDP could not find the ARIADataPoint for '" + name + "'");
                }
                return dp;
            } 
        }
        
        
        if (name.indexOf('.') == -1) {
            if (index >= dto.getColumnsTablesList().size()) {
                name = dot(dto.getColumnsTablesList().get(0).toString(), name).toUpperCase();
            } else {
                name = dot(dto.getColumnsTablesList().get(index).toString(), name).toUpperCase();
            }
        }

		if (name.startsWith("VW_")) {
        	name = getLegacy().viewTbl + name.substring(name.indexOf("."));
        }
        
        ARIADataPoint dp = getDataPoint(name);
        if (dp == null) {
            logger.warn("getDP could not find the ARIADataPoint for '" + name + "'");
        }
        return dp;
    }


    /**
     * Count what the legacy says are the keys (i.e. oracle fields starting with k1-k9)
     * 
     * @param dto
     * @return
     */
    protected int getKeyCount(AdhocRptDataTO dto) {
        int count = 2;
        Iterator i = dto.getColumnsAsOracleList().iterator();
        while (i.hasNext()) {
            String element = (String) i.next();
            if (element.startsWith("K") && ("12345".indexOf(element.substring(1, 2)) >= 0)) {
                count++;
            }
        }
        return count;
    }


    /**
     * Get the legacy code.
     * 
     * @return
     */
    protected AdhocGeneratorLegacy getLegacy() {
        if (legacy == null) {
            legacy = new AdhocGeneratorLegacy();
        }
        return legacy;
    }


    /**
     * Lookup previous DP from the mapped data points
     * 
     * @param dto
     * @param index
     * @param name
     * 
     * @return
     */
    protected ARIADataPoint getPreviousDP(AdhocRptDataTO dto, int index, String name) {
        if (name == null) {
            logger.warn("getDP was passed a null for name");
            return null;
        }

        if (name.indexOf('.') == -1) {
            name = dot(dto.getColumnsTablesList().get(index).toString(), name).toUpperCase();
        }

        if (name.startsWith("VW_")) {
            name = getLegacy().viewTbl + name.substring(name.indexOf("."));
        }

        name = "p" + name;

        ARIADataPoint dp = getDataPoint(name);
        return dp;
    }


    /**
     * Check to see if there is previous data in the dto
     * 
     * @param dto
     * @return
     */
    protected boolean hasPreviousData(AdhocRptDataTO dto) {
        Iterator i = dto.getPrevDataIndList().iterator();
        while (i.hasNext()) {
            Object element = i.next();
            if (element != null) {
                if (element.toString().equals(YES)) {
                    return true;
                }
            }
        }
        return false;
    }


    /**
     * There are (sadly) hardcoded items that must be added to inner where clauses
     * 
     * @param tableName
     * @return
     */
    private String addHardwiredConditions(String tableName) {
        if (tableName.equals("RABC_EXTRCT_SUMY_DATA")) {
            return " AND RABC_EXTRCT_SUMY_DATA.PRESN_CD IN ('A', 'B')";
        }
        return "";
    }


    /**
     * Strange hard wiring.
     * 
     * @param report
     */
    private void addHardWiredJoins(ARIAReport report) {
        List sources = report.getSources();

        if (sources.size() < 2) {
            return;
        }

        ARIASource s0 = (ARIASource) sources.get(0);
        ARIASource s1 = (ARIASource) sources.get(1);

        if (s0.getTable().equals("RABC_EXTRCT_SUMY_DATA") && (s1.getTable().equals("RABC_CALC_ALERT_DATA"))) {
            report.addJoin(new ARIAJoin(findDataPoint(s0, "EXTRCT_ITEM"), findDataPoint(s1, "ALERT_ITEM")));
            Iterator i = sources.iterator();
            while (i.hasNext()) {
                ARIASource element = (ARIASource) i.next();
                if (element.getTable().equals("RABC_EXTRCT_SUMY_DATA")) {
                    report.addJoin(new ARIAJoin(findDataPoint(element, "EXTRCT_ITEM"), findDataPoint(s1, "ALERT_ITEM")));
                }
            }
        } else if (s0.getTable().equals("RABC_CALC_ALERT_DATA") && (s1.getTable().equals("RABC_EXTRCT_SUMY_DATA"))) {
            report.addJoin(new ARIAJoin(findDataPoint(s0, "ALERT_ITEM"), findDataPoint(s1, "EXTRCT_ITEM")));
            Iterator i = sources.iterator();
            while (i.hasNext()) {
                ARIASource element = (ARIASource) i.next();
                if (element.getTable().equals("RABC_EXTRCT_SUMY_DATA")) {
                    report.addJoin(new ARIAJoin(findDataPoint(s0, "ALERT_ITEM"), findDataPoint(element, "EXTRCT_ITEM")));
                }
            }
        }
    }


    /**
     * If the user has selected a sort, add it to the report
     * <p>
     * <b>NOTE: This should be called before other sorts are added to the report.</b>
     * 
     * @param dto
     */
    protected void addUserSort(AdhocRptDataTO dto) {
        String userSort = dto.getUserSortColumn();
        if ((userSort != null) && (userSort.length() > 0)) {
            ARIADataPoint dp = findDataPoint(userSort);
            if (dp != null) {
                ARIASort order = null;
                switch (dto.getUserSortType()) {
                    case 'A':
                        order = ARIASort.ASC;
                        break;
                    case 'D':
                        order = ARIASort.DESC;
                        break;
                }
                if (order != null) {
                    report.addSort(dp, order);
                }
            } else {
                logger.error("addUserSort: " + userSort + " not found in DataPoint map");
            }
        }
    }


    /**
     * Find a data point given a string of "tablex.pointy" where x & y are numbers;
     * 
     * @param qualifiedDataPointName
     * @return
     */
    private ARIADataPoint findDataPoint(String qualifiedDataPointName) {
        String table = qualifiedDataPointName.substring(0, qualifiedDataPointName.indexOf('.'));
        String field = qualifiedDataPointName.substring(qualifiedDataPointName.indexOf('.') + 1);

        Iterator i = report.getSources().iterator();
        while (i.hasNext()) {
            ARIASource source = (ARIASource) i.next();
            if (source.getId().equals(table)) {
                Collection c = source.getKeys();
                c.addAll(source.getData());
                Iterator j = c.iterator();
                while (j.hasNext()) {
                    ARIADataPoint dp = (ARIADataPoint) j.next();
                    if (dp.getId().equals(field)) {
                        return dp;
                    }
                }
            }
        }

        return null;
    }


    /**
     * Add subtotaling. Note: KeyPosition is zeroBased.
     * 
     * @param dto
     * @param dp
     * @param keyPosition
     */
    protected void setDataPointSubTotal(AdhocRptDataTO dto, ARIADataPoint dp, int keyPosition) {
        if (dto.getUserSortColumn() == null || isNotNullEQ(dto.getUserSortColumn(), "")) {
            if ((dto.getBegSubTotLvl() <= keyPosition + 1) && (dto.getEndSubTotLvl() >= keyPosition + 1)) {
                dp.setSubTotalOrder(keyPosition + 2);
            }
        }
    }


    /**
     * Find a datapoint within a source
     * 
     * @param s
     * @param columnName
     * @return
     */
    private static ARIADataPoint findDataPoint(ARIASource s, String columnName) {
        Iterator i = s.getKeys().iterator();
        String qualifiedName = dot(s.getTable(), columnName);
        while (i.hasNext()) {
            ARIADataPoint element = (ARIADataPoint) i.next();
            if (element.getColumn().equalsIgnoreCase(qualifiedName)) {
                return element;
            }
        }

        i = s.getData().iterator();
        while (i.hasNext()) {
            ARIADataPoint element = (ARIADataPoint) i.next();
            if (element.getColumn().equalsIgnoreCase(qualifiedName)) {
                return element;
            }
        }

        return null;
    }
}
