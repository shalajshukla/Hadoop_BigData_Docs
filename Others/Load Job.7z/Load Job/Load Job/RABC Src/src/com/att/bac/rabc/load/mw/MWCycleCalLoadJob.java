/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.load.mw;

import java.io.File;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

//changes for M168 by as635b
//import com.sbc.bac.load.FileDBLoadJob;
import com.att.carat.load.FileDBLoadJob;
import com.sbc.bac.rabc.load.StaticErrorMsgKeys;

/**
 * This is a Load job which loads calendar data for MW region in RABC_CYCLE_CALENDAR table.
 * 
 * @author Shailesh Hemdev - SH8512
 */
public class MWCycleCalLoadJob extends FileDBLoadJob {
	/*
	 * Varables to represent the date formats
	 */
	private static final SimpleDateFormat MM_DD_YYYY_FORMAT = new SimpleDateFormat("MM/dd/yyyy");
	
	/*
	 * DB Index based constants
	 */
	private static final int PROCEDURE_DATE_INDEX = 1;
	private static final int PROC_DT_IND_INDEX = 2;
	private static final int BILL_ROUND_INDEX = 3;
	private static final int BILL_ROUND_DATE_INDEX = 4;
	
	/*
	 *  Prepared statements
	 */
	private PreparedStatement insertLCC;
	private PreparedStatement deleteLCC;
	
	/*
	 * boolean to indicate whether the earlier records need to be deleted or not as per specified logic
	 */
	private boolean isFirstRecord;
	
	private int lineCount;
	private String previousBillRound;
	private String fieldSeperator = ",";
	
	/**
	 * Overriding accept(file) method.
	 * It checks the file name pattern and retuns the boolean value.
	 * 
	 * @see java.io.FileFilter#accept(java.io.File)
	 */
	public boolean accept(File file) {
		return (file.getPath().toUpperCase().indexOf("MW.ACIS.CALENDAR") > 0);
	}
	
	/**
	 * Overriding preprocess() method. 
	 * It is executed prior to processing the load job.
	 * Forms the actual prepared statements which need to be fired on to the database.
	 * 
	 * @see com.sbc.bac.load.LoadJob#preprocess()
	 */
	public boolean preprocess() {
		boolean success = super.preprocess();

		if (success) {
			try {
				deleteLCC = connection.prepareStatement("DELETE FROM RABC_CYCLE_CALENDAR WHERE PROC_DT >= ?");
				insertLCC = connection.prepareStatement("INSERT INTO RABC_CYCLE_CALENDAR (PROC_DT, PROC_DT_IND, BILL_RND, BILL_RND_DT, CYCLE) VALUES (?, ?, ?, ?, NULL)");	
			} catch (SQLException e) {
				severe(StaticErrorMsgKeys.PREPROCESS_ERROR + e.getMessage(), e);
				success = false;
			}
		}
		
		/*
		 * Intialize the boolean variable to decide whether this is a first record or not. It is used to delete 
		 * the records based on a specific logic.
		 */
		isFirstRecord = true;
		
		return success;
	}
	
	/**
	 * Overriding parseLine(line) method.
	 * It accepts a single line and loads data in the table.
	 * It first deletes all the records of the year (year of the proc dates of the records in the file)
	 * from RABC_CYCLE_CALENDAR table.
	 * And then insert the records in the table.
	 * 
	 * @see com.sbc.bac.load.FileDBLoadJob#parseLine(java.lang.String)
	 */
	protected int parseLine(String line) throws Exception {
		String [] lineFields 		= line.split(fieldSeperator);

		if (lineFields.length >= 6) {
			String procedureDateString 	= lineFields[0].trim();
			String applicationCode 		= lineFields[1].trim();
			String stateId 				= lineFields[2].trim();
			String processGroup 		= lineFields[3].trim();
			String timeStamp 			= lineFields[4].trim();
			String billRound 			= "";
			
			Date procedureDate 			= new Date(MM_DD_YYYY_FORMAT.parse(procedureDateString).getTime());
						
			/*
			 * Process further only if the application code is 'ACIS'
			 */
			if ("ACIS".equalsIgnoreCase(applicationCode)) {
				lineCount++;
				
				if(!"".equals(processGroup) && processGroup.indexOf("PG")!=-1){
					billRound=processGroup.substring(processGroup.indexOf("PG")+2,processGroup.length()).trim();
				}
				
				/*
				 * Code added to ensure that if the bill round is consecutively repeated then 
				 * for all entries after the first for that bill round insert null.
				 * [Assumption is that entries are sorted on month].
				 * Now if the current bill round is same as previous bill round,
				 * make the billRound variable as "" so that later in the 
				 * code insert NULL for both BILL_RND and BILL_RND_DT.
				 */
				if (billRound.equals(previousBillRound)) {
					previousBillRound = billRound;
					billRound = "";
				} else {
					if (!"".equals(billRound.trim())){
						previousBillRound = billRound;
					}
				}
				
				/*
				 * Substitution for the prepared statements. Also note the following:
				 * 	1) BILL_RND_DT and BILL_RND are NULL when bill round is blank.
				 * 	2) PROC_DT_IND is 'H' when cycle type is NOCYC, i.e., no cycle.
				 */
				insertLCC.setDate(PROCEDURE_DATE_INDEX, procedureDate);
				if ("NOCYC".equalsIgnoreCase(processGroup)) {
					insertLCC.setString(PROC_DT_IND_INDEX, "H");
				} else {
					insertLCC.setString(PROC_DT_IND_INDEX, null);
				}
				if ("".equals(billRound.trim())) {
					insertLCC.setString(BILL_ROUND_INDEX, null);
					insertLCC.setTimestamp(BILL_ROUND_DATE_INDEX, null);
				} else if ("00".equals(billRound.trim()) || "0".equals(billRound.trim())) {
					insertLCC.setString(BILL_ROUND_INDEX, Integer.toString(Integer.parseInt(billRound)));
					insertLCC.setTimestamp(BILL_ROUND_DATE_INDEX, null);
				} else {
					insertLCC.setString(BILL_ROUND_INDEX, Integer.toString(Integer.parseInt(billRound)));
					insertLCC.setTimestamp(BILL_ROUND_DATE_INDEX, getTimestamp(procedureDate, billRound, MM_DD_YYYY_FORMAT));
				}
				
				/*
				 * If it is first record, then delete all the records where PROC_DT >= 1st January of year 
				 * for which the cycle is.
				 */	 
				if (isFirstRecord) {
					isFirstRecord = false;
	
					Calendar cal = Calendar.getInstance();
					cal.setTime(procedureDate);
					cal.set(Calendar.MONTH, Calendar.JANUARY);
					cal.set(Calendar.DAY_OF_MONTH, 1);
						
					/*
					 * Set the date parameter in the Delete statements
					 */
					deleteLCC.setDate(1, new java.sql.Date(cal.getTime().getTime()));
					
					/*
					 * Delete the records
					 */
					deleteLCC.execute();
				}
				
				/*
				 * Add the insert prepared statement to a batch
				 */
				insertLCC.addBatch();
				
				if (lineCount % 1000 == 0) {
					insertLCC.executeBatch();
				}
			}
			return SUCCESS;
		} else {
			return SKIPPED;
		}
	}
	
	/**
	 * Private method to return the BILL_RND_DT. Bill round is used
	 * to determine the BILL_RND_DT using the month & year of the procedure date.
	 * 
	 * @param date
	 * @param billRound
	 * @param dateFormat
	 * @return Timestamp
	 * @throws ParseException
	 */
	private Timestamp getTimestamp(Date date, String billRound, SimpleDateFormat dateFormat) 
			throws ParseException {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		String month = "";
		String day = "";
		String year = "";
		String dateString = dateFormat.format(date);
		int br = 0;
		int dy = 0;
		int mo = 0;
		int yr = 0;
		if (!billRound.trim().equals("0") && !billRound.trim().equals("00")) {
		   br = Integer.parseInt(billRound);
		   mo = calendar.get(Calendar.MONTH)+ 1;
		   dy = calendar.get(Calendar.DAY_OF_MONTH);
		   yr = calendar.get(Calendar.YEAR);
		   if (br < dy) {
		   		dy = br;
		   } else if (mo == 1) {
		   		yr = yr - 1;
		   		mo = 12;
		   		dy = br;
		   } else {
		   		mo = mo - 1;
		   		dy = br;
		   }
		   if (mo < 10) {
		   		month = "0" + Integer.toString(mo);
		   } else {
		   		month = Integer.toString(mo);
		   }
		   if (dy < 10) {
	   			day = "0" + Integer.toString(dy);
		   } else {
	   			day = Integer.toString(dy);
		   }
		   year = Integer.toString(yr);
		   dateString = month + "/" + day + "/" + year;
		}
		return new Timestamp(dateFormat.parse(dateString).getTime());
	}
	
	/**
	 * After the file has been processed (as in all records have been read), execute the last batch
	 */
	/**
	 * Overriding postProcessFile(file, success) method.
	 * It is executed post to processing the file to be loaded.
	 * It includes the following steps:
	 * 	1) Executes the last batch of prepared statement.
	 * 
	 * @see com.sbc.bac.load.FileDBLoadJob#postprocessFile(java.io.File, boolean)
	 */
	public boolean postprocessFile(File file, boolean success) {
		if (success) {
			try {
				insertLCC.executeBatch();
			} catch (SQLException e){
				severe(StaticErrorMsgKeys.POSTPROCESSFILE_ERROR + StaticErrorMsgKeys.INSERT_ERROR + e.getMessage(), e);
				success = false;
			}
		}
		return super.postprocessFile(file, success);
	}
	
	/**
	 * Overriding postProcess(success) method.
	 * It is executed post to processing the load job.
	 * It includes the following steps:
	 * 	1) Closes statements that were opened for this load job.
	 * 
	 * @see com.sbc.bac.load.LoadJob#postprocess(boolean)
	 */
	protected boolean postprocess(boolean success) {
		try {
			deleteLCC.close();
			insertLCC.close();	
		} catch (SQLException e) {
			severe(StaticErrorMsgKeys.POSTPROCESS_ERROR + StaticErrorMsgKeys.SQL_CLOSE_ERROR + e.getMessage(), e);
			success = false;
		}
		return super.postprocess(success);
	}
}
