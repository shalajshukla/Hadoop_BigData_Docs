/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.admin.alert.rule;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.ArrayList;
import java.text.MessageFormat;

import org.apache.log4j.Logger;

import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.RABCException;

/**
 * This is a DAO that performs SELECT, INSERT and UPDATE on RABC_AVG_TBL_DEF table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class AvgTblDefDAO {
	private static final Logger logger = Logger.getLogger(AvgTblDefDAO.class);

	/**
	 * Returns the list of AvgTblDef objects.
	 * 
	 * @param conn 
	 * @param failures
	 * @param args
	 * @param baseSQL
	 * @return List
	 */
	public List get(Connection conn, List failures, List args, String baseSQL) {
		List avgTblDefList = null;
		AvgTblDef avgTblDef = null;
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		
		try
		{
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("AvgTblDefDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			avgTblDefList = new ArrayList();
			while (rs.next()) {
				avgTblDefList.add(buildAvgTblDef(rs));
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return null;
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
		
		return avgTblDefList;
	}

	/**
	 * Private method to build AvgTblDef object and return it to caller.
	 * 
	 * @param rs
	 * @return AvgTblDef
	 * @throws SQLException
	 */
	private AvgTblDef buildAvgTblDef(ResultSet rs) throws SQLException {
		AvgTblDef avgTblDef = new AvgTblDef();
		
		avgTblDef.setPartiRefId(rs.getInt("PARTI_REF_ID"));
		avgTblDef.setAvgKeyLvl(rs.getInt("AVG_KEY_LVL"));
		avgTblDef.setKey1Name(rs.getString("KEY1_NAME"));
		avgTblDef.setKey2Name(rs.getString("KEY2_NAME"));
		avgTblDef.setKey3Name(rs.getString("KEY3_NAME"));
		avgTblDef.setKey4Name(rs.getString("KEY4_NAME"));
		avgTblDef.setKey5Name(rs.getString("KEY5_NAME"));
		avgTblDef.setAvgItemName(rs.getString("AVG_ITEM_NAME"));
		avgTblDef.setAvgDataCt(rs.getInt("AVG_DATA_CT"));
		avgTblDef.setAvgData1Name(rs.getString("AVG_DATA1_NAME"));
		avgTblDef.setAvgData2Name(rs.getString("AVG_DATA2_NAME"));
		avgTblDef.setAvgData3Name(rs.getString("AVG_DATA3_NAME"));
		avgTblDef.setAvgData4Name(rs.getString("AVG_DATA4_NAME"));
		avgTblDef.setAvgData5Name(rs.getString("AVG_DATA5_NAME"));
		avgTblDef.setAvgData6Name(rs.getString("AVG_DATA6_NAME"));
		avgTblDef.setAvgData7Name(rs.getString("AVG_DATA7_NAME"));
		avgTblDef.setAvgData8Name(rs.getString("AVG_DATA8_NAME"));
		avgTblDef.setAvgData9Name(rs.getString("AVG_DATA9_NAME"));
		avgTblDef.setAvgData10Name(rs.getString("AVG_DATA10_NAME"));
		avgTblDef.setAvgData11Name(rs.getString("AVG_DATA11_NAME"));
		avgTblDef.setAvgData12Name(rs.getString("AVG_DATA12_NAME"));
		avgTblDef.setAvgData13Name(rs.getString("AVG_DATA13_NAME"));
		avgTblDef.setAvgData14Name(rs.getString("AVG_DATA14_NAME"));
		avgTblDef.setAvgData15Name(rs.getString("AVG_DATA15_NAME"));
		return avgTblDef;
	}

	/**
	 * Execute the insert or update statement on RABC_AVG_TBL_DEF  table.
	 * 
	 * @param conn
	 * @param failures
	 * @param args
	 * @param baseSQL
	 */
	public void executeUpdate(Connection conn, List failures, List args, String baseSQL) {
		int rowsUpdated = 0;
		Statement stmt = null;
		String sqlStmt = null;
		
		try
		{
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("AvgTblDefDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rowsUpdated = stmt.executeUpdate(sqlStmt);
			logger.debug("SQL - Execution complete."+ String.valueOf(rowsUpdated) + "  rows updated");
			
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return;
		} finally {
			SQLHelper.closeStatement(stmt, failures, logger);
		}
	}

}
