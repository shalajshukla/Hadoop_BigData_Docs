/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.admin.alert.rule;

/**
 * This is a Data Object to represent RABC_TRACK_FILE_DTL table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class TrackFileDtl {
	private String alertItem7DdlName;
	private int alertItem7SumInd;
	private String alertItem8DdlName;
	private int alertItem8SumInd;
	private String alertItem9DdlName;
	private int alertItem9SumInd;
	private String alertItem10DdlName;
	private int alertItem10SumInd;
	private String alertItem11DdlName;
	private int alertItem11SumInd;
	private String alertItem12DdlName;
	private int alertItem12SumInd;
	private String alertItem13DdlName;
	private int alertItem13SumInd;
	private String alertItem14DdlName;
	private int alertItem14SumInd;
	private String alertItem15DdlName;
	private int alertItem15SumInd;
	private String viewName;
	private int alertItemOrd;
	private String alertRule;
	private String fileId;
	private String alertItemName;
	private String alertItemInd;
	private String alertDateInd;
	private String alertItemExtrctTbl;
	private int partiRefId;
	private int alertItemKeyLvl;
	private String alertItemKey1Name;
	private String alertItemKey2Name;
	private String alertItemKey3Name;
	private String alertItemKey4Name;
	private String alertItemKey5Name;
	private int alertItemDataCt;
	private String alertItem1DdlName;
	private int alertItem1SumInd;
	private String alertItem2DdlName;
	private int alertItem2SumInd;
	private String alertItem3DdlName;
	private int alertItem3SumInd;
	private String alertItem4DdlName;
	private int alertItem4SumInd;
	private String alertItem5DdlName;
	private int alertItem5SumInd;
	private String alertItem6DdlName;
	private int alertItem6SumInd;
	/*
	 * Impact of new columns added for ALERT_ITEM*_DDL_NAME_IND - 15 new variables added with corresponding getter and setter methods
	 */
	private String alertItem1DdlNameInd;
	private String alertItem2DdlNameInd;
	private String alertItem3DdlNameInd;
	private String alertItem4DdlNameInd;
	private String alertItem5DdlNameInd;
	private String alertItem6DdlNameInd;
	private String alertItem7DdlNameInd;
	private String alertItem8DdlNameInd;
	private String alertItem9DdlNameInd;
	private String alertItem10DdlNameInd;
	private String alertItem11DdlNameInd;
	private String alertItem12DdlNameInd;
	private String alertItem13DdlNameInd;
	private String alertItem14DdlNameInd;
	private String alertItem15DdlNameInd;

	/**
	 * @return Returns the AlertItem7DdlName.
	 */
	public String getAlertItem7DdlName() {
		return alertItem7DdlName;
	}
	/**
	 * @return Returns the AlertItem7SumInd.
	 */
	public int getAlertItem7SumInd() {
		return alertItem7SumInd;
	}
	/**
	 * @return Returns the AlertItem8DdlName.
	 */
	public String getAlertItem8DdlName() {
		return alertItem8DdlName;
	}
	/**
	 * @return Returns the AlertItem8SumInd.
	 */
	public int getAlertItem8SumInd() {
		return alertItem8SumInd;
	}
	/**
	 * @return Returns the AlertItem9DdlName.
	 */
	public String getAlertItem9DdlName() {
		return alertItem9DdlName;
	}
	/**
	 * @return Returns the AlertItem9SumInd.
	 */
	public int getAlertItem9SumInd() {
		return alertItem9SumInd;
	}
	/**
	 * @return Returns the AlertItem10DdlName.
	 */
	public String getAlertItem10DdlName() {
		return alertItem10DdlName;
	}
	/**
	 * @return Returns the AlertItem10SumInd.
	 */
	public int getAlertItem10SumInd() {
		return alertItem10SumInd;
	}
	/**
	 * @return Returns the AlertItem11DdlName.
	 */
	public String getAlertItem11DdlName() {
		return alertItem11DdlName;
	}
	/**
	 * @return Returns the AlertItem11SumInd.
	 */
	public int getAlertItem11SumInd() {
		return alertItem11SumInd;
	}
	/**
	 * @return Returns the AlertItem12DdlName.
	 */
	public String getAlertItem12DdlName() {
		return alertItem12DdlName;
	}
	/**
	 * @return Returns the AlertItem12SumInd.
	 */
	public int getAlertItem12SumInd() {
		return alertItem12SumInd;
	}
	/**
	 * @return Returns the AlertItem13DdlName.
	 */
	public String getAlertItem13DdlName() {
		return alertItem13DdlName;
	}
	/**
	 * @return Returns the AlertItem13SumInd.
	 */
	public int getAlertItem13SumInd() {
		return alertItem13SumInd;
	}
	/**
	 * @return Returns the AlertItem14DdlName.
	 */
	public String getAlertItem14DdlName() {
		return alertItem14DdlName;
	}
	/**
	 * @return Returns the AlertItem14SumInd.
	 */
	public int getAlertItem14SumInd() {
		return alertItem14SumInd;
	}
	/**
	 * @return Returns the AlertItem15DdlName.
	 */
	public String getAlertItem15DdlName() {
		return alertItem15DdlName;
	}
	/**
	 * @return Returns the AlertItem15SumInd.
	 */
	public int getAlertItem15SumInd() {
		return alertItem15SumInd;
	}
	/**
	 * @return Returns the ViewName.
	 */
	public String getViewName() {
		return viewName;
	}
	/**
	 * @return Returns the AlertItemOrd.
	 */
	public int getAlertItemOrd() {
		return alertItemOrd;
	}
	/**
	 * @return Returns the AlertRule.
	 */
	public String getAlertRule() {
		return alertRule;
	}
	/**
	 * @return Returns the FileId.
	 */
	public String getFileId() {
		return fileId;
	}
	/**
	 * @return Returns the AlertItemName.
	 */
	public String getAlertItemName() {
		return alertItemName;
	}
	/**
	 * @return Returns the AlertItemInd.
	 */
	public String getAlertItemInd() {
		return alertItemInd;
	}
	/**
	 * @return Returns the AlertDateInd.
	 */
	public String getAlertDateInd() {
		return alertDateInd;
	}
	/**
	 * @return Returns the AlertItemExtrctTbl.
	 */
	public String getAlertItemExtrctTbl() {
		return alertItemExtrctTbl;
	}
	/**
	 * @return Returns the PartiRefId.
	 */
	public int getPartiRefId() {
		return partiRefId;
	}
	/**
	 * @return Returns the AlertItemKeyLvl.
	 */
	public int getAlertItemKeyLvl() {
		return alertItemKeyLvl;
	}
	/**
	 * @return Returns the AlertItemKey1Name.
	 */
	public String getAlertItemKey1Name() {
		return alertItemKey1Name;
	}
	/**
	 * @return Returns the AlertItemKey2Name.
	 */
	public String getAlertItemKey2Name() {
		return alertItemKey2Name;
	}
	/**
	 * @return Returns the AlertItemKey3Name.
	 */
	public String getAlertItemKey3Name() {
		return alertItemKey3Name;
	}
	/**
	 * @return Returns the AlertItemKey4Name.
	 */
	public String getAlertItemKey4Name() {
		return alertItemKey4Name;
	}
	/**
	 * @return Returns the AlertItemKey5Name.
	 */
	public String getAlertItemKey5Name() {
		return alertItemKey5Name;
	}
	/**
	 * @return Returns the AlertItemDataCt.
	 */
	public int getAlertItemDataCt() {
		return alertItemDataCt;
	}
	/**
	 * @return Returns the AlertItem1DdlName.
	 */
	public String getAlertItem1DdlName() {
		return alertItem1DdlName;
	}
	/**
	 * @return Returns the AlertItem1SumInd.
	 */
	public int getAlertItem1SumInd() {
		return alertItem1SumInd;
	}
	/**
	 * @return Returns the AlertItem2DdlName.
	 */
	public String getAlertItem2DdlName() {
		return alertItem2DdlName;
	}
	/**
	 * @return Returns the AlertItem2SumInd.
	 */
	public int getAlertItem2SumInd() {
		return alertItem2SumInd;
	}
	/**
	 * @return Returns the AlertItem3DdlName.
	 */
	public String getAlertItem3DdlName() {
		return alertItem3DdlName;
	}
	/**
	 * @return Returns the AlertItem3SumInd.
	 */
	public int getAlertItem3SumInd() {
		return alertItem3SumInd;
	}
	/**
	 * @return Returns the AlertItem4DdlName.
	 */
	public String getAlertItem4DdlName() {
		return alertItem4DdlName;
	}
	/**
	 * @return Returns the AlertItem4SumInd.
	 */
	public int getAlertItem4SumInd() {
		return alertItem4SumInd;
	}
	/**
	 * @return Returns the AlertItem5DdlName.
	 */
	public String getAlertItem5DdlName() {
		return alertItem5DdlName;
	}
	/**
	 * @return Returns the AlertItem5SumInd.
	 */
	public int getAlertItem5SumInd() {
		return alertItem5SumInd;
	}
	/**
	 * @return Returns the AlertItem6DdlName.
	 */
	public String getAlertItem6DdlName() {
		return alertItem6DdlName;
	}
	/**
	 * @return Returns the AlertItem6SumInd.
	 */
	public int getAlertItem6SumInd() {
		return alertItem6SumInd;
	}

	/**
	 * @param AlertItem7DdlName The alertItem7DdlName to set.
	 */
	public void setAlertItem7DdlName(String alertItem7DdlName) {
		this.alertItem7DdlName = alertItem7DdlName;
	}
	/**
	 * @param AlertItem7SumInd The alertItem7SumInd to set.
	 */
	public void setAlertItem7SumInd(int alertItem7SumInd) {
		this.alertItem7SumInd = alertItem7SumInd;
	}
	/**
	 * @param AlertItem8DdlName The alertItem8DdlName to set.
	 */
	public void setAlertItem8DdlName(String alertItem8DdlName) {
		this.alertItem8DdlName = alertItem8DdlName;
	}
	/**
	 * @param AlertItem8SumInd The alertItem8SumInd to set.
	 */
	public void setAlertItem8SumInd(int alertItem8SumInd) {
		this.alertItem8SumInd = alertItem8SumInd;
	}
	/**
	 * @param AlertItem9DdlName The alertItem9DdlName to set.
	 */
	public void setAlertItem9DdlName(String alertItem9DdlName) {
		this.alertItem9DdlName = alertItem9DdlName;
	}
	/**
	 * @param AlertItem9SumInd The alertItem9SumInd to set.
	 */
	public void setAlertItem9SumInd(int alertItem9SumInd) {
		this.alertItem9SumInd = alertItem9SumInd;
	}
	/**
	 * @param AlertItem10DdlName The alertItem10DdlName to set.
	 */
	public void setAlertItem10DdlName(String alertItem10DdlName) {
		this.alertItem10DdlName = alertItem10DdlName;
	}
	/**
	 * @param AlertItem10SumInd The alertItem10SumInd to set.
	 */
	public void setAlertItem10SumInd(int alertItem10SumInd) {
		this.alertItem10SumInd = alertItem10SumInd;
	}
	/**
	 * @param AlertItem11DdlName The alertItem11DdlName to set.
	 */
	public void setAlertItem11DdlName(String alertItem11DdlName) {
		this.alertItem11DdlName = alertItem11DdlName;
	}
	/**
	 * @param AlertItem11SumInd The alertItem11SumInd to set.
	 */
	public void setAlertItem11SumInd(int alertItem11SumInd) {
		this.alertItem11SumInd = alertItem11SumInd;
	}
	/**
	 * @param AlertItem12DdlName The alertItem12DdlName to set.
	 */
	public void setAlertItem12DdlName(String alertItem12DdlName) {
		this.alertItem12DdlName = alertItem12DdlName;
	}
	/**
	 * @param AlertItem12SumInd The alertItem12SumInd to set.
	 */
	public void setAlertItem12SumInd(int alertItem12SumInd) {
		this.alertItem12SumInd = alertItem12SumInd;
	}
	/**
	 * @param AlertItem13DdlName The alertItem13DdlName to set.
	 */
	public void setAlertItem13DdlName(String alertItem13DdlName) {
		this.alertItem13DdlName = alertItem13DdlName;
	}
	/**
	 * @param AlertItem13SumInd The alertItem13SumInd to set.
	 */
	public void setAlertItem13SumInd(int alertItem13SumInd) {
		this.alertItem13SumInd = alertItem13SumInd;
	}
	/**
	 * @param AlertItem14DdlName The alertItem14DdlName to set.
	 */
	public void setAlertItem14DdlName(String alertItem14DdlName) {
		this.alertItem14DdlName = alertItem14DdlName;
	}
	/**
	 * @param AlertItem14SumInd The alertItem14SumInd to set.
	 */
	public void setAlertItem14SumInd(int alertItem14SumInd) {
		this.alertItem14SumInd = alertItem14SumInd;
	}
	/**
	 * @param AlertItem15DdlName The alertItem15DdlName to set.
	 */
	public void setAlertItem15DdlName(String alertItem15DdlName) {
		this.alertItem15DdlName = alertItem15DdlName;
	}
	/**
	 * @param AlertItem15SumInd The alertItem15SumInd to set.
	 */
	public void setAlertItem15SumInd(int alertItem15SumInd) {
		this.alertItem15SumInd = alertItem15SumInd;
	}
	/**
	 * @param ViewName The viewName to set.
	 */
	public void setViewName(String viewName) {
		this.viewName = viewName;
	}
	/**
	 * @param AlertItemOrd The alertItemOrd to set.
	 */
	public void setAlertItemOrd(int alertItemOrd) {
		this.alertItemOrd = alertItemOrd;
	}
	/**
	 * @param AlertRule The alertRule to set.
	 */
	public void setAlertRule(String alertRule) {
		this.alertRule = alertRule;
	}
	/**
	 * @param FileId The fileId to set.
	 */
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	/**
	 * @param AlertItemName The alertItemName to set.
	 */
	public void setAlertItemName(String alertItemName) {
		this.alertItemName = alertItemName;
	}
	/**
	 * @param AlertItemInd The alertItemInd to set.
	 */
	public void setAlertItemInd(String alertItemInd) {
		this.alertItemInd = alertItemInd;
	}
	/**
	 * @param AlertDateInd The alertDateInd to set.
	 */
	public void setAlertDateInd(String alertDateInd) {
		this.alertDateInd = alertDateInd;
	}
	/**
	 * @param AlertItemExtrctTbl The alertItemExtrctTbl to set.
	 */
	public void setAlertItemExtrctTbl(String alertItemExtrctTbl) {
		this.alertItemExtrctTbl = alertItemExtrctTbl;
	}
	/**
	 * @param PartiRefId The partiRefId to set.
	 */
	public void setPartiRefId(int partiRefId) {
		this.partiRefId = partiRefId;
	}
	/**
	 * @param AlertItemKeyLvl The alertItemKeyLvl to set.
	 */
	public void setAlertItemKeyLvl(int alertItemKeyLvl) {
		this.alertItemKeyLvl = alertItemKeyLvl;
	}
	/**
	 * @param AlertItemKey1Name The alertItemKey1Name to set.
	 */
	public void setAlertItemKey1Name(String alertItemKey1Name) {
		this.alertItemKey1Name = alertItemKey1Name;
	}
	/**
	 * @param AlertItemKey2Name The alertItemKey2Name to set.
	 */
	public void setAlertItemKey2Name(String alertItemKey2Name) {
		this.alertItemKey2Name = alertItemKey2Name;
	}
	/**
	 * @param AlertItemKey3Name The alertItemKey3Name to set.
	 */
	public void setAlertItemKey3Name(String alertItemKey3Name) {
		this.alertItemKey3Name = alertItemKey3Name;
	}
	/**
	 * @param AlertItemKey4Name The alertItemKey4Name to set.
	 */
	public void setAlertItemKey4Name(String alertItemKey4Name) {
		this.alertItemKey4Name = alertItemKey4Name;
	}
	/**
	 * @param AlertItemKey5Name The alertItemKey5Name to set.
	 */
	public void setAlertItemKey5Name(String alertItemKey5Name) {
		this.alertItemKey5Name = alertItemKey5Name;
	}
	/**
	 * @param AlertItemDataCt The alertItemDataCt to set.
	 */
	public void setAlertItemDataCt(int alertItemDataCt) {
		this.alertItemDataCt = alertItemDataCt;
	}
	/**
	 * @param AlertItem1DdlName The alertItem1DdlName to set.
	 */
	public void setAlertItem1DdlName(String alertItem1DdlName) {
		this.alertItem1DdlName = alertItem1DdlName;
	}
	/**
	 * @param AlertItem1SumInd The alertItem1SumInd to set.
	 */
	public void setAlertItem1SumInd(int alertItem1SumInd) {
		this.alertItem1SumInd = alertItem1SumInd;
	}
	/**
	 * @param AlertItem2DdlName The alertItem2DdlName to set.
	 */
	public void setAlertItem2DdlName(String alertItem2DdlName) {
		this.alertItem2DdlName = alertItem2DdlName;
	}
	/**
	 * @param AlertItem2SumInd The alertItem2SumInd to set.
	 */
	public void setAlertItem2SumInd(int alertItem2SumInd) {
		this.alertItem2SumInd = alertItem2SumInd;
	}
	/**
	 * @param AlertItem3DdlName The alertItem3DdlName to set.
	 */
	public void setAlertItem3DdlName(String alertItem3DdlName) {
		this.alertItem3DdlName = alertItem3DdlName;
	}
	/**
	 * @param AlertItem3SumInd The alertItem3SumInd to set.
	 */
	public void setAlertItem3SumInd(int alertItem3SumInd) {
		this.alertItem3SumInd = alertItem3SumInd;
	}
	/**
	 * @param AlertItem4DdlName The alertItem4DdlName to set.
	 */
	public void setAlertItem4DdlName(String alertItem4DdlName) {
		this.alertItem4DdlName = alertItem4DdlName;
	}
	/**
	 * @param AlertItem4SumInd The alertItem4SumInd to set.
	 */
	public void setAlertItem4SumInd(int alertItem4SumInd) {
		this.alertItem4SumInd = alertItem4SumInd;
	}
	/**
	 * @param AlertItem5DdlName The alertItem5DdlName to set.
	 */
	public void setAlertItem5DdlName(String alertItem5DdlName) {
		this.alertItem5DdlName = alertItem5DdlName;
	}
	/**
	 * @param AlertItem5SumInd The alertItem5SumInd to set.
	 */
	public void setAlertItem5SumInd(int alertItem5SumInd) {
		this.alertItem5SumInd = alertItem5SumInd;
	}
	/**
	 * @param AlertItem6DdlName The alertItem6DdlName to set.
	 */
	public void setAlertItem6DdlName(String alertItem6DdlName) {
		this.alertItem6DdlName = alertItem6DdlName;
	}
	/**
	 * @param AlertItem6SumInd The alertItem6SumInd to set.
	 */
	public void setAlertItem6SumInd(int alertItem6SumInd) {
		this.alertItem6SumInd = alertItem6SumInd;
	}
	
	
	/**
	 * @return Returns the alertItem10DdlNameInd.
	 */
	public String getAlertItem10DdlNameInd() {
		return alertItem10DdlNameInd;
	}
	/**
	 * @param alertItem10DdlNameInd The alertItem10DdlNameInd to set.
	 */
	public void setAlertItem10DdlNameInd(String alertItem10DdlNameInd) {
		this.alertItem10DdlNameInd = alertItem10DdlNameInd;
	}
	/**
	 * @return Returns the alertItem11DdlNameInd.
	 */
	public String getAlertItem11DdlNameInd() {
		return alertItem11DdlNameInd;
	}
	/**
	 * @param alertItem11DdlNameInd The alertItem11DdlNameInd to set.
	 */
	public void setAlertItem11DdlNameInd(String alertItem11DdlNameInd) {
		this.alertItem11DdlNameInd = alertItem11DdlNameInd;
	}
	/**
	 * @return Returns the alertItem12DdlNameInd.
	 */
	public String getAlertItem12DdlNameInd() {
		return alertItem12DdlNameInd;
	}
	/**
	 * @param alertItem12DdlNameInd The alertItem12DdlNameInd to set.
	 */
	public void setAlertItem12DdlNameInd(String alertItem12DdlNameInd) {
		this.alertItem12DdlNameInd = alertItem12DdlNameInd;
	}
	/**
	 * @return Returns the alertItem13DdlNameInd.
	 */
	public String getAlertItem13DdlNameInd() {
		return alertItem13DdlNameInd;
	}
	/**
	 * @param alertItem13DdlNameInd The alertItem13DdlNameInd to set.
	 */
	public void setAlertItem13DdlNameInd(String alertItem13DdlNameInd) {
		this.alertItem13DdlNameInd = alertItem13DdlNameInd;
	}
	/**
	 * @return Returns the alertItem14DdlNameInd.
	 */
	public String getAlertItem14DdlNameInd() {
		return alertItem14DdlNameInd;
	}
	/**
	 * @param alertItem14DdlNameInd The alertItem14DdlNameInd to set.
	 */
	public void setAlertItem14DdlNameInd(String alertItem14DdlNameInd) {
		this.alertItem14DdlNameInd = alertItem14DdlNameInd;
	}
	/**
	 * @return Returns the alertItem15DdlNameInd.
	 */
	public String getAlertItem15DdlNameInd() {
		return alertItem15DdlNameInd;
	}
	/**
	 * @param alertItem15DdlNameInd The alertItem15DdlNameInd to set.
	 */
	public void setAlertItem15DdlNameInd(String alertItem15DdlNameInd) {
		this.alertItem15DdlNameInd = alertItem15DdlNameInd;
	}
	/**
	 * @return Returns the alertItem1DdlNameInd.
	 */
	public String getAlertItem1DdlNameInd() {
		return alertItem1DdlNameInd;
	}
	/**
	 * @param alertItem1DdlNameInd The alertItem1DdlNameInd to set.
	 */
	public void setAlertItem1DdlNameInd(String alertItem1DdlNameInd) {
		this.alertItem1DdlNameInd = alertItem1DdlNameInd;
	}
	/**
	 * @return Returns the alertItem2DdlNameInd.
	 */
	public String getAlertItem2DdlNameInd() {
		return alertItem2DdlNameInd;
	}
	/**
	 * @param alertItem2DdlNameInd The alertItem2DdlNameInd to set.
	 */
	public void setAlertItem2DdlNameInd(String alertItem2DdlNameInd) {
		this.alertItem2DdlNameInd = alertItem2DdlNameInd;
	}
	/**
	 * @return Returns the alertItem3DdlNameInd.
	 */
	public String getAlertItem3DdlNameInd() {
		return alertItem3DdlNameInd;
	}
	/**
	 * @param alertItem3DdlNameInd The alertItem3DdlNameInd to set.
	 */
	public void setAlertItem3DdlNameInd(String alertItem3DdlNameInd) {
		this.alertItem3DdlNameInd = alertItem3DdlNameInd;
	}
	/**
	 * @return Returns the alertItem4DdlNameInd.
	 */
	public String getAlertItem4DdlNameInd() {
		return alertItem4DdlNameInd;
	}
	/**
	 * @param alertItem4DdlNameInd The alertItem4DdlNameInd to set.
	 */
	public void setAlertItem4DdlNameInd(String alertItem4DdlNameInd) {
		this.alertItem4DdlNameInd = alertItem4DdlNameInd;
	}
	/**
	 * @return Returns the alertItem5DdlNameInd.
	 */
	public String getAlertItem5DdlNameInd() {
		return alertItem5DdlNameInd;
	}
	/**
	 * @param alertItem5DdlNameInd The alertItem5DdlNameInd to set.
	 */
	public void setAlertItem5DdlNameInd(String alertItem5DdlNameInd) {
		this.alertItem5DdlNameInd = alertItem5DdlNameInd;
	}
	/**
	 * @return Returns the alertItem6DdlNameInd.
	 */
	public String getAlertItem6DdlNameInd() {
		return alertItem6DdlNameInd;
	}
	/**
	 * @param alertItem6DdlNameInd The alertItem6DdlNameInd to set.
	 */
	public void setAlertItem6DdlNameInd(String alertItem6DdlNameInd) {
		this.alertItem6DdlNameInd = alertItem6DdlNameInd;
	}
	/**
	 * @return Returns the alertItem7DdlNameInd.
	 */
	public String getAlertItem7DdlNameInd() {
		return alertItem7DdlNameInd;
	}
	/**
	 * @param alertItem7DdlNameInd The alertItem7DdlNameInd to set.
	 */
	public void setAlertItem7DdlNameInd(String alertItem7DdlNameInd) {
		this.alertItem7DdlNameInd = alertItem7DdlNameInd;
	}
	/**
	 * @return Returns the alertItem8DdlNameInd.
	 */
	public String getAlertItem8DdlNameInd() {
		return alertItem8DdlNameInd;
	}
	/**
	 * @param alertItem8DdlNameInd The alertItem8DdlNameInd to set.
	 */
	public void setAlertItem8DdlNameInd(String alertItem8DdlNameInd) {
		this.alertItem8DdlNameInd = alertItem8DdlNameInd;
	}
	/**
	 * @return Returns the alertItem9DdlNameInd.
	 */
	public String getAlertItem9DdlNameInd() {
		return alertItem9DdlNameInd;
	}
	/**
	 * @param alertItem9DdlNameInd The alertItem9DdlNameInd to set.
	 */
	public void setAlertItem9DdlNameInd(String alertItem9DdlNameInd) {
		this.alertItem9DdlNameInd = alertItem9DdlNameInd;
	}
}
