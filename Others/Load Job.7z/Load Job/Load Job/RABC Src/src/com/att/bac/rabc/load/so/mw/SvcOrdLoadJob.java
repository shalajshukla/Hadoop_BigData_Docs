/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.load.so.mw;

import java.io.File;
import java.net.UnknownHostException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import com.att.bac.rabc.util.EmcisEventLogger;
import com.att.carat.util.NetUtil;
import com.sbc.bac.rabc.load.FilePatternLoadJob;
import com.sbc.bac.rabc.load.PrepareTableForRerun;
import com.sbc.bac.rabc.load.RabcLoadJobTrig;
import com.sbc.bac.rabc.load.RetrieveStaticInfo;
import com.sbc.bac.rabc.load.StaticErrorMsgKeys;
import com.sbc.bac.rabc.load.StaticFieldKeys;

/**
 * This is a Load job which loads SO and USOC load file for MW region into the following tables:
 * RABC_SVC_ORD_TRN
 * RABC_SVC_ORD_ERR
 * RABC_SVC_ORD_INFO
 * RABC_SVC_ORD_AGE
 * RABC_DAILY_CIR_USOC_ACTVT
 * RABC_DAILY_NONCIR_USOC_ACTVT
 * 
 * @author Vijay Dubey - VD3159
 */
public class SvcOrdLoadJob extends FilePatternLoadJob {
	/*
	 * Varables to represent the date formats
	 */
	private static final SimpleDateFormat YYMMDD_FORMAT = new SimpleDateFormat("yyMMdd");
	private static final SimpleDateFormat MMDDYYYY_FORMAT = new SimpleDateFormat("MMddyyyy");
	
	/*
	 * Variables to represent the table names.
	 */
	private static final String RABC_SVC_ORD_TRN = "RABC_SVC_ORD_TRN";
	private static final String RABC_SVC_ORD_ERR = "RABC_SVC_ORD_ERR";
	private static final String RABC_SVC_ORD_INFO = "RABC_SVC_ORD_INFO";
	private static final String RABC_SVC_ORD_AGE = "RABC_SVC_ORD_AGE";
	private static final String RABC_DAILY_CIR_USOC_ACTVT = "RABC_DAILY_CIR_USOC_ACTVT";
	private static final String RABC_DAILY_NONCIR_USOC_ACTVT = "RABC_DAILY_NONCIR_USOC_ACTVT";
	private static final String RABC_USOC_EXCH_DTL = "RABC_USOC_EXCH_DTL";
	private static final String RABC_TRIG = "RABC_TRIG";
	
	/*
	 * Variables to represent the file ids to be inserted in RABC_TRIG table.
	 */
	private static final String SVC_ORD_TRN_FILE_ID = "MWSVCTN";
	private static final String SVC_ORD_ERR_FILE_ID = "MWSVCER";
	private static final String DAILY_CIR_USOC_ACTVT_FILE_ID = "MWUSOCNC";
	private static final String DAILY_NONCIR_USOC_ACTVT_FILE_ID = "MWUSOCCI";
	private static final String DAILY_USOC_EXCH_DTL_ACTVT_FILE_ID =	"MWEXCHDTL";
	
	/*
	 * Variables to represent the prepared statements
	 */
	private PreparedStatement insertTrn;
	private PreparedStatement insertErr;
	private PreparedStatement insertInfo;
	private PreparedStatement insertAge;
	private PreparedStatement insertUsocCir;
	private PreparedStatement insertUsocNonCir;
	private PreparedStatement insertUsocExchgDtl;
	
	/*
	 * Global variables
	 */
	private String runDate;
	private java.sql.Date sqlRunDate;
	private String division;
	private String billRound;
	private int recordCount;
	private int trnBatchCounter;
	private int errBatchCounter;
	private int infoBatchCounter;
	private int ageBatchCounter;
	private int usocUSOCExchDtlBatchCounter;
	private String backoutRecovery = null;
	private File currentFile;
	private String fieldSeperator = StaticFieldKeys.SEMICOLON;
	private String fileName, fileToken, region;
	
	/*
	 * HashMap variables to contain the groups for various tables.
	 */
	private HashMap svcOrdTrnMap;
	private HashMap svcOrdAgeMap;
	private HashMap svcOrdErrMap;
	private HashMap svcOrdInfoMap;
	private ArrayList USOCExchgDTLList;
	
	/*
	 * boolean variables indicating whether trigger to be inserted for that file id.
	 */
	boolean isTrn;
	boolean isErr;
	boolean isUsocCir;
	boolean isUsocNonCir;
	boolean isUsocExchDtl;
	
	/*
	 * boolean variables indicating whether the file to be processed or not.
	 */
	boolean isHeaderExists;
	boolean isTrailerExists;
	boolean isDateRecordExists;
	boolean isRecordCountMatches;
	
	/* 
	 * boolean variable to indicate whether the current date is last day of month.
	 */
	boolean isLastDayOfMonth;

	/* 
	 * Queries to insert records into RABC_DAILY_CIR_USOC_ACTVT & RABC_DAILY_NONCIR_USOC_ACTVT tables.
	 */
//	private String	insertUsocCirQry	= "  INSERT INTO RABC_DAILY_CIR_USOC_ACTVT (run_date, division, bus_type, usoc, usoc_ct, usoc_amt)(SELECT run_date,division,bus_type,usoc,SUM (usoc_ct),SUM (usoc_amt) FROM rabc_usoc_exch_dtl WHERE rule_num = '10' AND RUN_DATE = SYSDATE GROUP BY run_date, division, bus_type, usoc)"; 
//	private String	insertUsocNonCirQry	= "  INSERT INTO RABC_DAILY_NONCIR_USOC_ACTVT (run_date, division, bus_type, usoc, usoc_ct, usoc_amt)(SELECT run_date,division,bus_type,usoc,SUM (usoc_ct),SUM (usoc_amt) FROM rabc_usoc_exch_dtl WHERE rule_num = '11' AND RUN_DATE = SYSDATE GROUP BY run_date, division, bus_type, usoc)";

	
	/**
	 * Overriding preprocess() method. 
	 * It is executed prior to processing the load job.
	 * Forms the actual prepared statements which need to be fired on to the database.
	 * 
	 * @see com.sbc.bac.load.LoadJob#preprocess()
	 */
	public boolean preprocess() {
		boolean success = super.preprocess();

		if (success) {
			try {
				insertTrn 			= connection.prepareStatement("  INSERT INTO RABC_SVC_ORD_TRN (RUN_DATE, DIVISION, BUS_TYPE, SVC_ORD_TYPE,	SVC_ORD_INPUT_CT, SVC_ORD_CMPL_CT, SVC_ORD_ERR_CT, SVC_ORD_INTERIM_CT, SVC_ORD_DEL_CT) VALUES(?, ?, ?, ?, ?, ?, ?, ?,? ) ");
				insertErr 			= connection.prepareStatement("  INSERT INTO RABC_SVC_ORD_ERR (RUN_DATE, DIVISION, BUS_TYPE, SVC_ORD_TYPE,	ERR_CD, SVC_ORD_ERR_CT ) VALUES(?, ?, ?, ?, ?, ? ) ");
				insertInfo 			= connection.prepareStatement("  INSERT INTO RABC_SVC_ORD_INFO (RUN_DATE, DIVISION, BUS_TYPE, SVC_ORD_NUM,	SVC_ORD_AGE_DAY) VALUES(?, ?, ?, ?, ? ) ");
				insertAge 			= connection.prepareStatement("  INSERT INTO RABC_SVC_ORD_AGE (RUN_DATE, DIVISION, BUS_TYPE, AGE_3_DAY_CT,	AGE_7_DAY_CT, AGE_14_DAY_CT, AGE_GT_14_DAY_CT ) VALUES(?, ?, ?, ?, ?, ?, ? ) ");
//				insertUsocCir		= connection.prepareStatement("  INSERT INTO RABC_DAILY_CIR_USOC_ACTVT	(RUN_DATE, DIVISION, BUS_TYPE, USOC,USOC_CT, USOC_AMT ) VALUES(?, ?, ?, ?, ?, ? ) ");
				// treat rule_num=11 as cir data
				insertUsocCir		= connection.prepareStatement("  INSERT INTO RABC_DAILY_CIR_USOC_ACTVT (run_date, division, bus_type, usoc, usoc_ct, usoc_amt)(SELECT run_date,division,bus_type,usoc,SUM (usoc_ct),SUM (usoc_amt) FROM rabc_usoc_exch_dtl WHERE rule_num = '11' AND RUN_DATE = ? and division=? GROUP BY run_date, division, bus_type, usoc)"); 
//				insertUsocNonCir 	= connection.prepareStatement("  INSERT INTO RABC_DAILY_NONCIR_USOC_ACTVT (RUN_DATE, DIVISION, BUS_TYPE, USOC,	USOC_CT, USOC_AMT ) VALUES(?, ?, ?, ?, ?, ? ) ");
				// treat rule_num=10 as non -cir data
				insertUsocNonCir 	= connection.prepareStatement("  INSERT INTO RABC_DAILY_NONCIR_USOC_ACTVT (run_date, division, bus_type, usoc, usoc_ct, usoc_amt)(SELECT run_date,division,bus_type,usoc,SUM (usoc_ct),SUM (usoc_amt) FROM rabc_usoc_exch_dtl WHERE rule_num = '10' AND RUN_DATE = ? and division=?  GROUP BY run_date, division, bus_type, usoc)");
				insertUsocExchgDtl 	= connection.prepareStatement(" /* Formatted on 2010/04/28 13:17 (Formatter Plus v4.8.8) */ " 
				                   	                           + " INSERT INTO rabc_usoc_exch_dtl "
				                   	                        + "             (run_date, division, rule_num, so_type, bus_type, usoc, exch_cd, usoc_ct, "
				                   	                        + "              usoc_amt "
				                   	                        + "             ) "
				                   	                        + "      VALUES (?, ?, ?, ?, ?, ?, ?, ?, "
				                   	                        + "              ? "
				                   	                        + "             ) "
);
			} catch (SQLException e) {
				severe(StaticErrorMsgKeys.PREPROCESS_ERROR + e.getMessage(), e);
				success = false;
			}
		}
		
		return success;
	}
	
	/**
	 * Overriding preprocessFile(file) method.
	 * It is executed prior to processing the file to be loaded.
	 * It includes the following steps:
	 * 	1) Marks the backoutRecovery flag to "Y" if this file has already been processed earlier.
	 * 	2) Initializes the global variables with default values.
	 * 
	 * @see com.sbc.bac.load.FileDBLoadJob#preprocessFile(java.io.File)
	 */
	public boolean preprocessFile(File file) {
		boolean success = super.preprocessFile(file);

		fileName = file.getName();
		fileToken = file.getName().substring(file.getName().indexOf("RA100F01"),file.getName().indexOf("RA100F01")+ 8);
		
		if (success) {
			try {
				region   =	file.getName().substring(0,2);
				/*
				 * Check whether this file has been processed before and if yes,
				 * mark the backoutRecovery flag to "Y".
				 */
				if (RabcLoadJobTrig.IsOriginalFileLoaded(connection, file, file.getName().length())) {
					backoutRecovery = "Y";
				}
				
				isLastDayOfMonth = isLastDayOfMonth();
			} catch (Exception e) {
				severe(StaticErrorMsgKeys.PREPROCESSFILE_ERROR + e.getMessage(), e);
				success = false;
			}
		}
		
		/*
		 * Initialize the global variables with default values.
		 */
		currentFile = file;
		recordCount = 0;
		isHeaderExists = false;
		isTrailerExists = false;
		isDateRecordExists=false;
		isRecordCountMatches = false;
		svcOrdTrnMap = new HashMap();
		svcOrdAgeMap = new HashMap();
		svcOrdErrMap = new HashMap();
		svcOrdInfoMap = new HashMap();
		USOCExchgDTLList=new ArrayList() ;
		
		trnBatchCounter = 0;
		errBatchCounter = 0;
		infoBatchCounter = 0;
		ageBatchCounter = 0;
		usocUSOCExchDtlBatchCounter = 0;
		
		isTrn = false;
		isErr = false;
		isUsocCir = false;
		isUsocNonCir = false;
		isUsocExchDtl = false;
		
		return success;
	}

	/**
	 * Overriding parseLine(line) method.
	 * It accepts a single line and checks whether it is header, trailer, date or detail record.
	 * Depending upon the record type, it calls the respective internal private methods to process the line.
	 * 
	 * @see com.sbc.bac.load.FileDBLoadJob#parseLine(java.lang.String)
	 */
	protected int parseLine(String line) throws Exception {
		boolean status = true;
		String recordIndicator = getRecordType(line);
		
		if ("HEADER".equalsIgnoreCase(recordIndicator)) {
			isHeaderExists = true;
			status = processHeader(line);
		} else if ("DATE".equalsIgnoreCase(recordIndicator)) {
			if (!isHeaderExists) {
				throw new Exception("Either header record is not present in the file or it is not the first record.");
			} else {
				isDateRecordExists = true;
				recordCount++;
				status = processCycleRecord(line);
			}
		} else if ("TRAILER".equalsIgnoreCase(recordIndicator)) {
			if (!isHeaderExists) {
				throw new Exception("Either header record is not present in the file or it is not the first record.");
			}else if (!isDateRecordExists){
				throw new Exception("Either date record is not present in the file or it is not the second record.");
			}else {
				isTrailerExists = true;
				status = processTrailer(line);
			}
		} else if ("Rule01".equalsIgnoreCase(recordIndicator)) {
			if (!isHeaderExists) {
				throw new Exception("Either header record is not present in the file or it is not the first record.");
			} else if (!isDateRecordExists) {
				throw new Exception("Either date record is not present in the file or it is not the second record.");
			} else if (isTrailerExists) {
				throw new Exception("Trailer record is not the last record.");
			} else {
				recordCount++;
				status = processRule01(line);
			}
		} else if ("Rule02".equalsIgnoreCase(recordIndicator)) {
			if (!isHeaderExists) {
				throw new Exception("Either header record is not present in the file or it is not the first record.");
			} else if (!isDateRecordExists) {
				throw new Exception("Either date record is not present in the file or it is not the second record.");
			} else if (isTrailerExists) {
				throw new Exception("Trailer record is not the last record.");
			} else {
				recordCount++;
				status = processRule02(line);
			}
		} else if ("Rule03".equalsIgnoreCase(recordIndicator)) {
			if (!isHeaderExists) {
				throw new Exception("Either header record is not present in the file or it is not the first record.");
			} else if (!isDateRecordExists) {
				throw new Exception("Either date record is not present in the file or it is not the second record.");
			} else if (isTrailerExists) {
				throw new Exception("Trailer record is not the last record.");
			} else {
				recordCount++;
				status = processRule03(line);
			}
		} else if ("Rule04".equalsIgnoreCase(recordIndicator)) {
			if (!isHeaderExists) {
				throw new Exception("Either header record is not present in the file or it is not the first record.");
			} else if (!isDateRecordExists) {
				throw new Exception("Either date record is not present in the file or it is not the second record.");
			} else if (isTrailerExists) {
				throw new Exception("Trailer record is not the last record.");
			} else {
				recordCount++;
				status = processRule04(line);
			}
		} else if ("Rule05".equalsIgnoreCase(recordIndicator)) {
			if (!isHeaderExists) {
				throw new Exception("Either header record is not present in the file or it is not the first record.");
			} else if (!isDateRecordExists) {
				throw new Exception("Either date record is not present in the file or it is not the second record.");
			} else if (isTrailerExists) {
				throw new Exception("Trailer record is not the last record.");
			} else {
				recordCount++;
				status = processRule05(line);
			}
		} else if ("Rule10".equalsIgnoreCase(recordIndicator)) {
			if (!isHeaderExists) {
				throw new Exception("Either header record is not present in the file or it is not the first record.");
			} else if (!isDateRecordExists) {
				throw new Exception("Either date record is not present in the file or it is not the second record.");
			} else if (isTrailerExists) {
				throw new Exception("Trailer record is not the last record.");
			} else {
				recordCount++;
				status = processUSOCExchDtls(line,"10");
			}
		} else if ("Rule11".equalsIgnoreCase(recordIndicator)) {
			if (!isHeaderExists) {
				throw new Exception("Either header record is not present in the file or it is not the first record.");
			} else if (!isDateRecordExists) {
				throw new Exception("Either date record is not present in the file or it is not the second record.");
			} else if (isTrailerExists) {
				throw new Exception("Trailer record is not the last record.");
			} else {
				recordCount++;
				status = processUSOCExchDtls(line,"11");
			}
		} else {
			recordCount++;
			status = false;
		}
		
		if (status) {
			return SUCCESS;
		} else {
			return ERROR;
		}
	}
	
	/**
	 * Private method to return the record type of the line to be processed.
	 * 
	 * @param line
	 * @return String
	 * @throws Exception
	 */
	private String getRecordType(String line) throws Exception {
		String recordType = null;
		
		String [] lineFields 	= line.split(fieldSeperator);
		
		if (lineFields.length > 1) {
			String firstField		= lineFields[0].trim();
			String secondField		= lineFields[1].trim();
			
			if ("HEADER".equals(firstField)) {
				recordType = "HEADER";
			} else if ("TRAILER".equals(firstField)) {
				recordType = "TRAILER";
			} else if ("RA10DATE".equals(firstField)) {
				recordType = "DATE";
			} else if ("RA10SORD".equals(firstField)) {
				if ("01".equals(secondField)) {
					recordType = "Rule01";
				} else if ("02".equals(secondField)) {
					recordType = "Rule02";
				} else if ("03".equals(secondField)) {
					recordType = "Rule03";
				} else if ("04".equals(secondField)) {
					recordType = "Rule04";
				} else if ("05".equals(secondField)) {
					recordType = "Rule05";
				} else if ("10".equals(secondField)) {
					recordType = "Rule10";
				} else if ("11".equals(secondField)) {
					recordType = "Rule11";
				}
			}
		}
		
		return recordType;
	}
	
	/**
	 * Private method to process the header record.
	 * 
	 * @param line
	 * @return boolean
	 * @throws Exception
	 */
	private boolean processHeader(String line) throws Exception {
		boolean success = false;
		
		String [] lineFields = line.split(fieldSeperator);
		
		/*
		 * Populate the instance variable for division.
		 */
		if (lineFields.length > 2) {
			division = lineFields[2].trim();
			success = true;
		}
		
		return success;
	}
	
	/**
	 * Private method to process the trailer record.
	 * It checks that whether the total number of records (excluding header and trailer records)
	 * in the file is eqaul to the count in the trailer record or not.
	 *  
	 * @param line
	 * @return boolean
	 * @throws Exception
	 */
	private boolean processTrailer(String line) throws Exception {
		boolean success = false;
		int trailerCount = 0;
		
		String [] lineFields = line.split(fieldSeperator);
		
		if (lineFields.length > 5) {
			trailerCount = Integer.parseInt(lineFields[5].trim());
			success = true;
		}
		
		if (success) {
			if (trailerCount == recordCount) {
				isRecordCountMatches = true;
			}
		}
		
		return success;
	}
	
	/**
	 * Private method to process the date record. It does the following steps:
	 * 	1) Retrieves the cycle date from the date record.
	 * 	2) Deletes the records matching with the date and division retrieved form the file from the tables 
	 * 	   RABC_SVC_ORD_TRN, RABC_SVC_ORD_ERR, RABC_SVC_ORD_INFO, RABC_SVC_ORD_AGE, RABC_DAILY_CIR_USOC_ACTVT 
	 * 	   and RABC_DAILY_NONCIR_USOC_ACTVT if the backoutRecovery flag is "Y", 
	 * 	   i.e. this file has already been processed earlier.
	 * 
	 * @param line
	 * @return boolean
	 * @throws Exception
	 */
	private boolean processCycleRecord(String line) throws Exception {
		boolean success = false;
		
		String [] lineFields = line.split(fieldSeperator);
		
		/*
		 * Populate the instance variable for runDate.
		 */
		if (lineFields.length > 3) {
			runDate = lineFields[2].trim();
			billRound = lineFields[3].trim();
			if ("00".equals(billRound) || "".equals(billRound.trim())) {
				billRound = "0";
			}
			success = true;
		}
		
		if (success) {
			sqlRunDate = new java.sql.Date(YYMMDD_FORMAT.parse(runDate).getTime());
			runDate = MMDDYYYY_FORMAT.format(YYMMDD_FORMAT.parse(runDate));
			
			String runDatequery = "SELECT PROC_DT FROM RABC_CYCLE_CALENDAR WHERE PROC_DT = to_date('" + runDate + "','MMddyyyy')";
			boolean isRunDateExists	= RetrieveStaticInfo.isProcDateExists(connection, runDatequery);
			
			if (!isRunDateExists) {
				throw new Exception("The cycle date " + runDate + " does not exist in RABC_CYCLE_CALENDAR table.");
			}
			
			if ("Y".equals(backoutRecovery)){
				if (!PrepareTableForRerun.deleteTableData(connection, RABC_SVC_ORD_TRN, division, sqlRunDate)) {
					throw new Exception("Error occurred attempting to backup and recover for rerun for table: " + RABC_SVC_ORD_TRN);
				}
				if (!PrepareTableForRerun.deleteTableData(connection, RABC_SVC_ORD_ERR, division, sqlRunDate)) {
					throw new Exception("Error occurred attempting to backup and recover for rerun for table: " + RABC_SVC_ORD_ERR);
				}
				if (!PrepareTableForRerun.deleteTableData(connection, RABC_SVC_ORD_INFO, division, sqlRunDate)) {
					throw new Exception("Error occurred attempting to backup and recover for rerun for table: " + RABC_SVC_ORD_INFO);
				}
				if (!PrepareTableForRerun.deleteTableData(connection, RABC_SVC_ORD_AGE, division, sqlRunDate)) {
					throw new Exception("Error occurred attempting to backup and recover for rerun for table: " + RABC_SVC_ORD_AGE);
				}
				if (!PrepareTableForRerun.deleteTableData(connection, RABC_DAILY_CIR_USOC_ACTVT, division, sqlRunDate)) {
					throw new Exception("Error occurred attempting to backup and recover for rerun for table: " + RABC_DAILY_CIR_USOC_ACTVT);
				}
				if (!PrepareTableForRerun.deleteTableData(connection, RABC_DAILY_NONCIR_USOC_ACTVT, division, sqlRunDate)) {
					throw new Exception("Error occurred attempting to backup and recover for rerun for table: " + RABC_DAILY_NONCIR_USOC_ACTVT);
				}
				if (!PrepareTableForRerun.deleteTableData(connection, RABC_USOC_EXCH_DTL, division, sqlRunDate)) {
					throw new Exception("Error occurred attempting to backup and recover for rerun for table: " + RABC_USOC_EXCH_DTL);
				}

			}
		}
		
		return success;
	}
	
	/**
	 * Private method to process the records for the rule number '01' of 'RA10SORD'.
	 * It does the following steps:
	 * 	1) Retrieves the fields from the line.
	 * 	2) Does conversion of data from String to appropriate data types as well as interpretation for amount.
	 * 	3) Creates the objects of SvcOrdTrn type.
	 * 	4) Populates the hash map with those objects.
	 * 
	 * @param line
	 * @return boolean
	 * @throws Exception
	 */
	private boolean processRule01(String line) throws Exception {
		boolean success = false;
		
		String [] lineFields = line.split(fieldSeperator);
		String busType = null;
		
		if (lineFields.length == 5) {
			success = true;
			
			String ruleName				= lineFields[0].trim();
			String seqNumber			= lineFields[1].trim();
			String srvOrdType 			= lineFields[2].trim();
			String custType				= lineFields[3].trim();
			String totCtSvcOrd			= lineFields[4].trim();
			
			// Calculate the business type 
			busType =getBusType(custType);
			
			long totSvcInpCount			= Long.parseLong(totCtSvcOrd.substring(0, totCtSvcOrd.length()-6));	
			
			/*
			 * Create an object of SvcOrdTrn type
			 */
			SvcOrdTrn objSvcOrdTrn = new SvcOrdTrn();
			objSvcOrdTrn.setRunDate(MMDDYYYY_FORMAT.parse(runDate));
			objSvcOrdTrn.setDivision(division);
			objSvcOrdTrn.setBusType(busType);
			objSvcOrdTrn.setSvcOrdType(srvOrdType);
			
			/*
			 * Check whether the object of SvcOrdTrn type is present in the hash map
			 */
			SvcOrdTrn objRef = (SvcOrdTrn) svcOrdTrnMap.get(objSvcOrdTrn);
			if (objRef != null) {
				totSvcInpCount += objRef.getSvcOrdInputCt();
				objRef.setSvcOrdInputCt(totSvcInpCount);
				svcOrdTrnMap.put(objRef, objRef);
			} else {
				objSvcOrdTrn.setSvcOrdInputCt(totSvcInpCount);
				svcOrdTrnMap.put(objSvcOrdTrn, objSvcOrdTrn);
			}
		}
			
		return success;
	}
	
	/**
	 * Private method to process the records for the rule number '02' of 'RA10SORD'.
	 * It does the following steps:
	 * 	1) Retrieves the fields from the line.
	 * 	2) Does conversion of data from String to appropriate data types as well as interpretation for amount.
	 * 	3) Creates the objects of SvcOrdTrn and SvcOrdAge type.
	 * 	4) Populates the hash map with those objects.
	 * 	5) Substitutes the prepared insert statements and add them to a batch. 
	 * 	6) Executes batch after every 1000 records.
	 * 
	 * @param line
	 * @return boolean
	 * @throws Exception
	 */
	private boolean processRule02(String line) throws Exception {
		boolean success = false;
				
		String [] lineFields = line.split(fieldSeperator);
		String busType = null;
		
		if (lineFields.length == 8) {
			success = true;
			
			String ruleName				= lineFields[0].trim();
			String seqNumber			= lineFields[1].trim();
			String srvOrdType 			= lineFields[2].trim();
			String custType				= lineFields[3].trim();
			String srvOrdNumber			= lineFields[4].trim();
			String errCodeInd			= lineFields[5].trim();
			String cycAgingCnt			= lineFields[6].trim();
			String errCode				= lineFields[7].trim();
			
			// Calculate the business type 
			busType =getBusType(custType);
			
			int totalErrors = Integer.parseInt(errCodeInd);
			int cycAgingCounter = Integer.parseInt(cycAgingCnt);
			
			/*
			 * Logic for forming the map to be used to populate RABC_SVC_ORD_TRN table. 
			 * Brief algorithm is as follows:
			 * 	a) Consider records for which Cycle Aging Counter has a value of 1.
			 * 	b) For every record prepare the key which is the combination of Run date, division, customer type 
			 * 	   and service order type.
			 * 	c) Check for the presence of an object using this key in the map, if match found 
			 * 	   then increment service Order Error Count by errCodeInd else set it to errCodeInd.
			 * 	d) Put object in the map, where key will be used to ensure uniqueness.
			 */
			if (cycAgingCounter == 1) {
				SvcOrdTrn objSvcOrdTrn = new SvcOrdTrn();
				objSvcOrdTrn.setRunDate(MMDDYYYY_FORMAT.parse(runDate));
				objSvcOrdTrn.setDivision(division);
				objSvcOrdTrn.setBusType(busType);
				objSvcOrdTrn.setSvcOrdType(srvOrdType);
										
				long totOrdErrCount = Long.parseLong(errCodeInd);
				
				SvcOrdTrn objRef = (SvcOrdTrn) svcOrdTrnMap.get(objSvcOrdTrn);
				if (objRef != null) {
					totOrdErrCount += objRef.getSvcOrdErrCt();
					objRef.setSvcOrdErrCt(totOrdErrCount);
					svcOrdTrnMap.put(objRef, objRef);
				} else {
					objSvcOrdTrn.setSvcOrdErrCt(totOrdErrCount);
					svcOrdTrnMap.put(objSvcOrdTrn, objSvcOrdTrn);
				}		
			}
			
			/*
			 * Logic to populate RABC_SVC_ORD_ERR table. 
			 * Brief algorithm is as follows:
			 * 	a) Consider records for which Cycle Aging Counter has a value of 1.
			 * 	b) Use total errors field to loop through the Error Cd field in sets of 5 characters each
			 * 	   and find out the error codes. 
			 * 	c) For every errorCode, substitute the values in the prepare staement and then add 
			 * 	   that statement into batch.
			 * 	d) Execute the batch if the batch counter is the modulo of 1000.
			 */
			int subStrFrom = 0;
			int subStrTo = 0;
			String subErrCode;
			if (cycAgingCounter == 1) {
				for (int counterErrCode=0; counterErrCode<totalErrors; counterErrCode++){
					long totErrCount=1;
					subStrFrom = counterErrCode * 5;
					subStrTo = subStrFrom + 5;
					if (subStrTo <= errCode.length()) {
						subErrCode = errCode.substring(subStrFrom, subStrTo);
					} else {
						subErrCode = errCode.substring(subStrFrom);
					}
					
					SvcOrdErr svcOrdErr	= new SvcOrdErr();
					svcOrdErr.setRunDate(MMDDYYYY_FORMAT.parse(runDate));
					svcOrdErr.setBusType(busType);
					svcOrdErr.setDivision(division);
					svcOrdErr.setSvcOrdType(srvOrdType);
					svcOrdErr.setErrCd(subErrCode);

					SvcOrdErr objRef=(SvcOrdErr)svcOrdErrMap.get(svcOrdErr);
					if (objRef != null) {
						totErrCount += objRef.getSvcOrdErrCt();
						objRef.setSvcOrdErrCt(totErrCount);
						svcOrdErrMap.put(objRef, objRef);
					}else {
						svcOrdErr.setSvcOrdErrCt(totErrCount);
						svcOrdErrMap.put(svcOrdErr,svcOrdErr);
					}
				}		
			}
			
			/*
			 * Logic RABC_SVC_ORD_INFO table. 
			 * Brief algorithm is as follows:
			 * 	a) Consider records for which Cycle Aging Counter has a value of 1.
			 * 	b) For every record representing one service order number, substitute the values 
			 * 	   in the prepare staement and then add that statement into batch.
			 * 	c) Execute the batch if the batch counter is the modulo of 1000.
			 */	
			if (cycAgingCounter == 1) {
				long totOrdAgeDay 		= cycAgingCounter;	
				SvcOrdInfo objSvcOrdInfo=new SvcOrdInfo();
				objSvcOrdInfo.setRunDate(MMDDYYYY_FORMAT.parse(runDate));
				objSvcOrdInfo.setDivision(division);
				objSvcOrdInfo.setBusType(busType);
				objSvcOrdInfo.setSvcOrdNum(srvOrdNumber);
				
				SvcOrdInfo objRef=(SvcOrdInfo)svcOrdInfoMap.get(objSvcOrdInfo);
				if (objRef != null) {
					totOrdAgeDay += objRef.getSvcOrdAgeDay();
					objRef.setSvcOrdAgeDay(totOrdAgeDay);
					svcOrdInfoMap.put(objRef, objRef);
				}else {
					objSvcOrdInfo.setSvcOrdAgeDay(totOrdAgeDay);
					svcOrdInfoMap.put(objSvcOrdInfo, objSvcOrdInfo);
				}
			}
			
			/*
			 * Call private method to first check whether the current date is the last day of the month. 
			 * If yes then proceed else do not perform the aging code. 
			 * Brief algorithm for forming the map to be used to populate RABC_SVC_ORD_AGE table is as follows:
			 * 	a) Consider all records.
			 * 	b) For every record prepare the key which is the combination of Run date, division, customer type 
			 * 	   and service order type. 
			 * 	c) Check whether the value of Cycle Aging Counter lies between 0 - 3, 4- 7, 8 - 14 or above 14.
			 * 	   Based on this, increment appropriate bucket value by 1.
			 * 	d) Put object in the map, where key will be used to ensure uniqueness.
			*/
			if (isLastDayOfMonth) {
				SvcOrdAge objSvcOrdAge = new SvcOrdAge();
				objSvcOrdAge.setRunDate(MMDDYYYY_FORMAT.parse(runDate));
				objSvcOrdAge.setDivision(division);
				objSvcOrdAge.setBusType(busType);
				
				long agingCounter = 1;
				
				SvcOrdAge objRef = (SvcOrdAge) svcOrdAgeMap.get(objSvcOrdAge);
				if (objRef != null) {
					if (cycAgingCounter <= 3) {
						agingCounter += objRef.getAge3DayCt();
						objRef.setAge3DayCt(agingCounter);
					} else if((cycAgingCounter > 3) && (cycAgingCounter <= 7)) {
						agingCounter += objRef.getAge7DayCt();
						objRef.setAge7DayCt(agingCounter);
					} else if((cycAgingCounter > 7) && (cycAgingCounter <= 14)) {
						agingCounter += objRef.getAge14DayCt();
						objRef.setAge14DayCt(agingCounter);
					} else if(cycAgingCounter > 14) {
						agingCounter += objRef.getAgeGt14DayCt();
						objRef.setAgeGt14DayCt(agingCounter);
					}
					svcOrdAgeMap.put(objRef, objRef);
				} else {
					if (cycAgingCounter <= 3){
						objSvcOrdAge.setAge3DayCt(agingCounter);
					} else if((cycAgingCounter > 3) && (cycAgingCounter <= 7)) {
						objSvcOrdAge.setAge7DayCt(agingCounter);
					} else if((cycAgingCounter > 7) && (cycAgingCounter <= 14)) {
						objSvcOrdAge.setAge14DayCt(agingCounter);
					} else if(cycAgingCounter > 14) {
						objSvcOrdAge.setAgeGt14DayCt(agingCounter);
					}
					svcOrdAgeMap.put(objSvcOrdAge, objSvcOrdAge);
				}
			}
		}
		
		return success;
	}
	
	/**
	 * Private method to check whether the current system date is the maximum bill rnd date for the current month.
	 * 
	 * @param con
	 * @return boolean
	 * @throws Exception
	 */
	private boolean isLastDayOfMonth() throws Exception {
		boolean isLastDayOfMonth = false;
		
		PreparedStatement lastDayStatement = null;
		ResultSet lastDayRs = null;
		Date currentDate	= new Date(System.currentTimeMillis());
		String currDate = MMDDYYYY_FORMAT.format(currentDate);
		String currentMonth = currDate.substring(0, 2);
		String maxBillRndDt;
		
		try {
			String query = "SELECT TO_CHAR(MAX(BILL_RND_DT),'MMddyyyy') FROM RABC_CYCLE_CALENDAR WHERE TO_CHAR(PROC_DT,'MM') = '" + currentMonth + "' AND PROC_DT_IND IS NULL ";

			lastDayStatement = connection.prepareStatement(query);
			lastDayRs = lastDayStatement.executeQuery();

			if (lastDayRs.next()) {
				maxBillRndDt = lastDayRs.getString(1);
				if (currDate.equals(maxBillRndDt)){
					isLastDayOfMonth = true;
				}
			}
		} catch (SQLException sqe) {
			severe("SO MW Load: Error retrieving the last day of the month from RABC_CYCLE_CALENDAR: "  + sqe.getMessage(), sqe);
			isLastDayOfMonth = false; 
		} finally {
			try {
				lastDayRs.close();
				lastDayStatement.close();
			} catch (SQLException e) {
				severe("SO MW Load: isLastDayOfMonth() - " + StaticErrorMsgKeys.SQL_CLOSE_ERROR + e.getMessage(), e);
				isLastDayOfMonth = false; 
			}	
		}
		
		return isLastDayOfMonth;
	}
	
	/**
	 * Private method to process the records for the rule number '03' of 'RA10SORD'.
	 * It does the following steps:
	 * 	1) Retrieves the fields from the line.
	 * 	2) Does conversion of data from String to appropriate data types as well as interpretation for amount.
	 * 	3) Creates the objects of SvcOrdTrn type.
	 * 	4) Populates the hash map with those objects.
	 * 
	 * @param line
	 * @return boolean
	 * @throws Exception
	 */
	private boolean processRule03(String line) throws Exception {
		boolean success = false;
		
		String [] lineFields = line.split(fieldSeperator);
		String busType = null;
		
		if (lineFields.length == 5) {
			success = true;
			
			String ruleName				= lineFields[0].trim();
			String seqNumber			= lineFields[1].trim();
			String srvOrdType 			= lineFields[2].trim();
			String custType				= lineFields[3].trim();
			String totCtPostedOrd		= lineFields[4].trim();
			
			// Calculate the business type 
			busType =getBusType(custType);
			
			long totPostedCt			= Long.parseLong(totCtPostedOrd.substring(0, totCtPostedOrd.length()-6));
		
			/*
			 * Create an object of SvcOrdTrn type
			 */
			SvcOrdTrn objSvcOrdTrn = new SvcOrdTrn();
			objSvcOrdTrn.setRunDate(MMDDYYYY_FORMAT.parse(runDate));
			objSvcOrdTrn.setDivision(division);
			objSvcOrdTrn.setBusType(busType);
			objSvcOrdTrn.setSvcOrdType(srvOrdType);
			
			/*
			 * Check whether the object of SvcOrdTrn type is present in the hash map
			 */
			SvcOrdTrn objRef = (SvcOrdTrn) svcOrdTrnMap.get(objSvcOrdTrn);
			if (objRef != null) {
				totPostedCt += objRef.getSvcOrdCmplCt();
				objRef.setSvcOrdCmplCt(totPostedCt);
				svcOrdTrnMap.put(objRef, objRef);
			} else {
				objSvcOrdTrn.setSvcOrdCmplCt(totPostedCt);
				svcOrdTrnMap.put(objSvcOrdTrn, objSvcOrdTrn);
			}
		}
			
		return success;
	}

	/**
	 * Private method to process the records for the rule number '04' of 'RA10SORD'.
	 * It does the following steps:
	 * 	1) Retrieves the fields from the line.
	 * 	2) Does conversion of data from String to appropriate data types as well as interpretation for amount.
	 * 	3) Creates the objects of SvcOrdTrn type.
	 * 	4) Populates the hash map with those objects.
	 * 
	 * @param line
	 * @return boolean
	 * @throws Exception
	 */
	private boolean processRule04(String line) throws Exception {
		boolean success = false;
		
		String [] lineFields = line.split(fieldSeperator);
		String busType = null;
		
		if (lineFields.length == 5) {
			success = true;
		
			String ruleName				= lineFields[0].trim();
			String seqNumber			= lineFields[1].trim();
			String srvOrdType 			= lineFields[2].trim();
			String custType				= lineFields[3].trim();
			String totCtIntSo			= lineFields[4].trim();
			
			// Calculate the business type 
			busType =getBusType(custType);
			
			long totInterimCt			= Long.parseLong(totCtIntSo.substring(0, totCtIntSo.length()-6));
			
			/*
			 * Create an object of SvcOrdTrn type
			 */
			SvcOrdTrn objSvcOrdTrn = new SvcOrdTrn();
			objSvcOrdTrn.setRunDate(MMDDYYYY_FORMAT.parse(runDate));
			objSvcOrdTrn.setDivision(division);
			objSvcOrdTrn.setBusType(busType);
			objSvcOrdTrn.setSvcOrdType(srvOrdType);
	
			/*
			 * Check whether the object of SvcOrdTrn type is present in the hash map
			 */
			SvcOrdTrn objRef = (SvcOrdTrn) svcOrdTrnMap.get(objSvcOrdTrn);
			if (objRef != null) {
				totInterimCt += objRef.getSvcOrdInterimCt();
				objRef.setSvcOrdInterimCt(totInterimCt);
				svcOrdTrnMap.put(objRef, objRef);
			} else {
				objSvcOrdTrn.setSvcOrdInterimCt(totInterimCt);
				svcOrdTrnMap.put(objSvcOrdTrn, objSvcOrdTrn);
			}
		}
			
		return success;
	}
	
	/**
	 * Private method to process the records for the rule number '05' of 'RA10SORD'.
	 * It does the following steps:
	 * 	1) Retrieves the fields from the line.
	 * 	2) Does conversion of data from String to appropriate data types as well as interpretation for amount.
	 * 	3) Creates the objects of SvcOrdTrn type.
	 * 	4) Populates the hash map with those objects.
	 * 
	 * @param line
	 * @return boolean
	 * @throws Exception
	 */
	private boolean processRule05(String line) throws Exception {
		boolean success = false;
		 
		String [] lineFields = line.split(fieldSeperator);
		String busType = null;
		
		if (lineFields.length == 5) {
			success = true;
			
			String ruleName				= lineFields[0].trim();
			String seqNumber			= lineFields[1].trim();
			String srvOrdType 			= lineFields[2].trim();
			String custType				= lineFields[3].trim();
			String totCtDeleted			= lineFields[4].trim();
			
			// Calculate the business type 
			busType =getBusType(custType);
			
			long totDeletedCt			= Long.parseLong(totCtDeleted.substring(0, totCtDeleted.length()-6));
			
			/*
			 * Create an object of SvcOrdTrn type
			 */
			SvcOrdTrn objSvcOrdTrn = new SvcOrdTrn();
			objSvcOrdTrn.setRunDate(MMDDYYYY_FORMAT.parse(runDate));
			objSvcOrdTrn.setDivision(division);
			objSvcOrdTrn.setBusType(busType);
			objSvcOrdTrn.setSvcOrdType(srvOrdType);
	
			/*
			 * Check whether the object of SvcOrdTrn type is present in the hash map
			 */
			SvcOrdTrn objRef = (SvcOrdTrn) svcOrdTrnMap.get(objSvcOrdTrn);
			if (objRef != null) {
				totDeletedCt += objRef.getSvcOrdDelCt();
				objRef.setSvcOrdDelCt(totDeletedCt);
				svcOrdTrnMap.put(objRef, objRef);
			} else {
				objSvcOrdTrn.setSvcOrdDelCt(totDeletedCt);
				svcOrdTrnMap.put(objSvcOrdTrn, objSvcOrdTrn);
			}
		}
			
		return success;
	}
	
	/**
	 * Private method to process the records for the rule number '10' & '11' of 'RA10SORD'.
	 * It does the following steps:
	 * 	1) Retrieves the fields from the line.
	 * 	2) Does conversion of data from String to appropriate data types as well as interpretation for amount.
	 * 	3) Substitutes the prepared insert statements and add them to a batch. 
	 * 	4) Executes batch after every 1000 records.
	 * 
	 * @param line
	 * @return boolean
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
    private boolean processUSOCExchDtls(String line,String ruleNumber) throws Exception {
		boolean success = false;
		
		String [] lineFields = line.split(fieldSeperator);
		String busType = null;
		
		int fieldCount = lineFields.length;
        if ((fieldCount == 8)||(fieldCount == 9)) {
			success = true;
			
			String ruleName				= lineFields[0].trim();
			String seqNumber			= lineFields[1].trim();
			String srvOrdType 			= lineFields[2].trim();
			String custType				= lineFields[3].trim();
			String wrIndicator			= lineFields[4].trim();
			String exchCD               = "";
			if (fieldCount == 9) {
			exchCD				           = lineFields[5].trim();
			}
			String usoc					= lineFields[fieldCount-3].trim();
			String usocCt				= lineFields[fieldCount-2].trim();
			String usocAmt				= lineFields[fieldCount-1].trim();
			
			
			// Get the business type
			busType =getBusType(custType, wrIndicator);
			
			long usocCount			= Long.parseLong(usocCt.substring(0, usocCt.length()-6));
			
			String amtUnitPart			= usocAmt.substring(0, usocAmt.length()-6);
			String amtDecimalPart		= usocAmt.substring(usocAmt.length()-6);
			String amtUsoc				= amtUnitPart + "." + amtDecimalPart;
			double usocNonAmt 		= Double.parseDouble(amtUsoc);
			
			USOCActvt objUsoc=new USOCActvt();
			objUsoc.setBusType(busType);
			objUsoc.setDivision(division);
			objUsoc.setRuleNumber(ruleNumber);
			objUsoc.setSoType(srvOrdType);
			objUsoc.setRunDate(MMDDYYYY_FORMAT.parse(runDate));
			objUsoc.setExchCD(exchCD);
			objUsoc.setUsoc(usoc);
			objUsoc.setUsocCt(usocCount);
			objUsoc.setUsocAmt(usocNonAmt);
			USOCExchgDTLList.add(objUsoc);
		}
		
		return success;
	}

	/**
	 * Private method to return the business type based on only the customer type
	 * @param custType
	 * @return
	 */
	private String getBusType(String custType){
		if ("D".equals(custType)|| "K".equals(custType) || "R".equals(custType)){
			return "RES";
		}else {
			return "BUS";
		}
	}
	
	/**
	 * Private method to return the business type based on the customer type and WR indicator
	 * 
	 * @param custType
	 * @param mktInd
	 * @return
	 */
	private String getBusType(String custType, String mktInd){
		String busType = null;
		if ("D".equals(custType)|| "K".equals(custType) || "R".equals(custType)){
			busType = "RES";
		}else {
			busType = "BUS";
		}
		
		if ("B".equals(mktInd)||"U".equals(mktInd) || "R".equals(mktInd)){
			busType = "R" + busType;
		}
		
		return busType;
	}
	
	/**
	 * Overriding postProcessFile(file, success) method.
	 * It is executed post to processing the file to be loaded.
	 * It includes the following steps:
	 * 	1) It checks whether the header and trailer records exists and 
	 * 	   whether the total number of records (excluding header and trailer records)
	 * 	   in the file is eqaul to the count in the trailer record.
	 * 	   If it is then prcoceeds to next step else return false.
	 * 	2) Executes the last batches.
	 * 	3) Loops through the maps and insert entries into respective tables.
	 * 	4) Makes the entries into RABC_TRIG table.
	 * 
	 * @see com.sbc.bac.load.FileDBLoadJob#postprocessFile(java.io.File, boolean)
	 */
	public boolean postprocessFile(File file, boolean success) {
		try{
			//Log the file information to EMCIS_EVENT_LOG and EMCIS_EVENT_LOG_DETAIL
			EmcisEventLogger emcisLogger = new EmcisEventLogger();
			String event_id = "RABC_"+fileToken+"_"+region;
            String host = NetUtil.getLocalHostName();
            String hostIP = NetUtil.getLocalIpAddress();
			int sequence = emcisLogger.getEMCISSequence(connection);
			emcisLogger.insertEventLog(connection, sequence, event_id, sqlRunDate, host, hostIP);
			emcisLogger.insertEventLogDetail(connection, sequence, "FileName", fileName);

		}catch (UnknownHostException e) {
            severe("Error getting EMCIS host information ", e);
        }
		if (success) {
			if (!isTrailerExists) {
				severe("Trailer record is not present in the file.");
				success = false;
			} else if (!isRecordCountMatches) {
				severe("Total number of records in the file is not eqaul to the count in the trailer record.");
				success = false;
			} else {
				try {
					/*
					 * Iterate through the entire map svcOrdTrnMap and insert entries into the RABC_SVC_ORD_TRN table
					 */
					Set svcOrdTrnSet 		= svcOrdTrnMap.keySet();
					Iterator svcTrnIterator = svcOrdTrnSet.iterator();
					
					while (svcTrnIterator.hasNext()) {
						SvcOrdTrn objSvcOrdTrn = (SvcOrdTrn) svcTrnIterator.next();
						insertTrn.setDate(1, sqlRunDate);		
						insertTrn.setString(2, objSvcOrdTrn.getDivision());
						insertTrn.setString(3, objSvcOrdTrn.getBusType());
						insertTrn.setString(4, objSvcOrdTrn.getSvcOrdType());
						insertTrn.setLong(5, objSvcOrdTrn.getSvcOrdInputCt() );
						insertTrn.setLong(6, objSvcOrdTrn.getSvcOrdCmplCt());
						insertTrn.setLong(7, objSvcOrdTrn.getSvcOrdErrCt());
						insertTrn.setLong(8, objSvcOrdTrn.getSvcOrdInterimCt());
						insertTrn.setLong(9, objSvcOrdTrn.getSvcOrdDelCt());	
						
						insertTrn.addBatch();
						trnBatchCounter++;
						
						if (trnBatchCounter % 1000 == 0){
							insertTrn.executeBatch();
						}
						isTrn = true;
					}
					
					/*
					 * Execute the batch after all entries in svcOrdTrnMap are processed
					 */
					insertTrn.executeBatch();
					
					Set svcOrdErrSet 			= svcOrdErrMap.keySet();
					Iterator svcErrIterator 	= svcOrdErrSet.iterator();
					
					while (svcErrIterator.hasNext()){
						errBatchCounter++;
						SvcOrdErr objSvcOrdErr = (SvcOrdErr)svcErrIterator.next();		
						java.sql.Date sqlRunDate = new java.sql.Date(objSvcOrdErr.getRunDate().getTime());
						insertErr.setDate(1,sqlRunDate);
						insertErr.setString(2,objSvcOrdErr.getDivision());
						insertErr.setString(3,objSvcOrdErr.getBusType());
						insertErr.setString(4,objSvcOrdErr.getSvcOrdType());
						insertErr.setString(5,objSvcOrdErr.getErrCd() );
						insertErr.setLong(6,objSvcOrdErr.getSvcOrdErrCt());
						insertErr.addBatch();
						
						if (errBatchCounter % 1000 == 0) {
							insertErr.executeBatch();
						}
						isErr = true;
					}
					
					// Execute the last batch
					insertErr.executeBatch();
					
					Set svcOrdInfoSet 			= svcOrdInfoMap.keySet();
					Iterator svcInfoIterator 	= svcOrdInfoSet.iterator();
					
					while (svcInfoIterator.hasNext()){
						infoBatchCounter++;
										
						SvcOrdInfo objSvcOrdInfo = (SvcOrdInfo)svcInfoIterator.next();
						java.sql.Date sqlRunDate = new java.sql.Date(objSvcOrdInfo.getRunDate().getTime());
						insertInfo.setDate(1,sqlRunDate);
						insertInfo.setString(2,objSvcOrdInfo.getDivision());
						insertInfo.setString(3,objSvcOrdInfo.getBusType());
						insertInfo.setString(4,objSvcOrdInfo.getSvcOrdNum());
						insertInfo.setLong(5,objSvcOrdInfo.getSvcOrdAgeDay());
						insertInfo.addBatch();
										
						if (infoBatchCounter % 1000 == 0) {
							insertInfo.executeBatch();
						}
					}
					
					// Execute the last batch
					insertInfo.executeBatch();
					
					/*
					 * Iterate through the entire map svcOrdAgeMap and insert entries into the RABC_SVC_ORD_AGE table
					 */
					Set svcOrdAgeSet 		= svcOrdAgeMap.keySet();
					Iterator svcAgeIterator = svcOrdAgeSet.iterator();
					
					while (svcAgeIterator.hasNext()) {
						SvcOrdAge objSvcOrdAge = (SvcOrdAge) svcAgeIterator.next();		
						insertAge.setDate(1, sqlRunDate);
						insertAge.setString(2, objSvcOrdAge.getDivision());
						insertAge.setString(3, objSvcOrdAge.getBusType());
						insertAge.setLong(4, objSvcOrdAge.getAge3DayCt());
						insertAge.setLong(5, objSvcOrdAge.getAge7DayCt());
						insertAge.setLong(6, objSvcOrdAge.getAge14DayCt());
						insertAge.setLong(7, objSvcOrdAge.getAgeGt14DayCt());
						insertAge.addBatch();
						
						insertAge.addBatch();
						ageBatchCounter++;
						
						if (ageBatchCounter % 1000 == 0){
							insertAge.executeBatch();
						}
					}
					
					/*
					 * Execute the batch after all entries in svcOrdAgeMap are processed
					 */
					insertAge.executeBatch();
					
					
					/*
					* Iterate through the entire CIRC hash map and insert entries into the RABC_DAILY_CIR_USOC_ACTVT table
					*/	
					Iterator usocIterator	= USOCExchgDTLList.iterator();	
					
					while (usocIterator.hasNext()){
						usocUSOCExchDtlBatchCounter++;		
						USOCActvt objUsocExchDtl= (USOCActvt)usocIterator.next();

						java.sql.Date sqlRunDate = new java.sql.Date(objUsocExchDtl.getRunDate().getTime());
						insertUsocExchgDtl.setDate(1,sqlRunDate);
						insertUsocExchgDtl.setString(2,objUsocExchDtl.getDivision());
						insertUsocExchgDtl.setString(3,objUsocExchDtl.getRuleNumber());
						insertUsocExchgDtl.setString(4,objUsocExchDtl.getSoType());
						insertUsocExchgDtl.setString(5,objUsocExchDtl.getBusType());
						insertUsocExchgDtl.setString(6,objUsocExchDtl.getUsoc());
					
						insertUsocExchgDtl.setString(7,objUsocExchDtl.getExchCD());
						insertUsocExchgDtl.setLong(8,objUsocExchDtl.getUsocCt());
						insertUsocExchgDtl.setDouble(9,objUsocExchDtl.getUsocAmt());
						insertUsocExchgDtl.addBatch();
														
						if (usocUSOCExchDtlBatchCounter % 1000 == 0) {
							insertUsocExchgDtl.executeBatch();
						}
						isUsocExchDtl = true;
					}
					
					// Execute the last batch
					insertUsocExchgDtl.executeBatch();	
					/**
					 * Insert summarized records into RABC_DAILY_CIR_USOC_ACTVT table.
					 */
					insertUsocCir.setDate(1,sqlRunDate);
					insertUsocCir.setString(2, division);
					int rowsUpdated = insertUsocCir.executeUpdate();

					if(rowsUpdated > 0)
						isUsocCir = true;
					/**
					 * Insert summarized records into RABC_DAILY_NONCIR_USOC_ACTVT table.
					 */
					insertUsocNonCir.setDate(1,sqlRunDate);
					insertUsocNonCir.setString(2, division);
					rowsUpdated = insertUsocNonCir.executeUpdate();
					
					if(rowsUpdated > 0)
						isUsocNonCir = true;

					/*
					 * Call the private method to make the entries into RABC_TRIG table
					 */
					if (!insertTrigger()) {
						success = false;
					}	
				} catch (SQLException sqle){
					severe(StaticErrorMsgKeys.INSERT_ERROR + sqle.getMessage(), sqle);
					success = false;
				}
			}
		}
		
		return super.postprocessFile(file, success);
	}
	
	/**
	 * This is a method to insert entry into RABC_TRIG table
	 * 
	 * @return boolean
	 */
	private boolean insertTrigger() {
		/*
		 * Check whether there were any trn record inserted, if yes then insert into trigger
		 */
		if (isTrn) {
			if(!RabcLoadJobTrig.insertTrigger(connection, currentFile.getName().substring(5, currentFile.getName().length()), currentFile.getName(), SVC_ORD_TRN_FILE_ID, division, runDate , backoutRecovery, billRound, RABC_TRIG)) {
				return false;	
			}
		}
		
		/*
		 * Check whether there were any err record inserted, if yes then insert into trigger
		 */
		if (isErr) {
			if(!RabcLoadJobTrig.insertTrigger(connection, currentFile.getName().substring(5, currentFile.getName().length()), currentFile.getName(), SVC_ORD_ERR_FILE_ID, division, runDate , backoutRecovery, billRound, RABC_TRIG)) {
				return false;	
			}
		}
		
		/*
		 * Check whether there were any non circuit usoc record inserted, if yes then insert into trigger
		 */
		if (isUsocNonCir) {
			if(!RabcLoadJobTrig.insertTrigger(connection, currentFile.getName().substring(5, currentFile.getName().length()), currentFile.getName(), DAILY_NONCIR_USOC_ACTVT_FILE_ID, division, runDate , backoutRecovery, billRound, RABC_TRIG)) {
				return false;	
			}
		}
		
		/*
		 * Check whether there were any circuit usoc record inserted, if yes then insert into trigger
		 */
		if (isUsocCir) {
			if(!RabcLoadJobTrig.insertTrigger(connection, currentFile.getName().substring(5, currentFile.getName().length()), currentFile.getName(), DAILY_CIR_USOC_ACTVT_FILE_ID, division, runDate , backoutRecovery, billRound, RABC_TRIG)) {
				return false;	
			}
		}
		/*
		 * Check whether there were any usoc exchange record inserted, if yes then insert into trigger
		 */
		if (isUsocExchDtl) {
			if(!RabcLoadJobTrig.insertTrigger(connection, currentFile.getName().substring(5, currentFile.getName().length()), currentFile.getName(), DAILY_USOC_EXCH_DTL_ACTVT_FILE_ID, division, runDate , backoutRecovery, billRound, RABC_TRIG)) {
				return false;	
			}
		}
		
		return true;
	}
	
	/**
	 * Overriding postProcess(success) method.
	 * It is executed post to processing the load job.
	 * It includes the following steps:
	 * 	1) Closes statements that were opened for this load job.
	 * 
	 * @see com.sbc.bac.load.LoadJob#postprocess(boolean)
	 */
	public boolean postprocess(boolean success) {
		try {
			insertTrn.close();
			insertErr.close();
			insertInfo.close();
			insertAge.close();
			insertUsocCir.close();
			insertUsocNonCir.close();
		} catch (SQLException e) {
			severe(StaticErrorMsgKeys.POSTPROCESS_ERROR + StaticErrorMsgKeys.SQL_CLOSE_ERROR + e.getMessage(), e);
			success = false;
		}
		
		return super.postprocess(success);
	}
}
