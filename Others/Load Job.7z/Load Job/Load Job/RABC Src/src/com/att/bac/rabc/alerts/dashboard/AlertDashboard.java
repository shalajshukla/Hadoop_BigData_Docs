/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/

package com.att.bac.rabc.alerts.dashboard;

import java.util.ArrayList;
import java.util.List;

/**
 * This class represents the data object that holds the attributes required
 * to represent alert dashboard. 
 * 
 * @author Sandhya Chinala - SC3837
 */
public class AlertDashboard {
	private String type;	
	private boolean showLink = false;
	private String processPointCode;
	private String processPoint;
	private String controlPointCode;
	private String cntrlPtDesc;
	private String mouseOver;
	private List levelWiseWarningList = new ArrayList();
	
	/**
	 * @return Returns the cntrlPtDesc.
	 */
	public String getCntrlPtDesc() {
		return cntrlPtDesc.replace('_', ' ');
	}
	/**
	 * @param cntrlPtDesc The cntrlPtDesc to set.
	 */
	public void setCntrlPtDesc(String cntrlPtDesc) {
		this.cntrlPtDesc = cntrlPtDesc;
	}
	/**
	 * @return Returns the controlPointCode.
	 */
	public String getControlPointCode() {
		return controlPointCode;
	}
	/**
	 * @param controlPointCode The controlPointCode to set.
	 */
	public void setControlPointCode(String controlPointCode) {
		this.controlPointCode = controlPointCode;
	}
	/**
	 * @return Returns the type.
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type The type to set.
	 */
	public void setType(String type) {
		this.type = type;
	}
	
	/**
	 * @return Returns the levelWiseWarningList.
	 */
	public List getLevelWiseWarningList() {
		return levelWiseWarningList;
	}
	/**
	 * @param levelWiseWarnings The levelWiseWarnings add.
	 */
	public void addLevelWiseWarning(LevelWiseWarnings levelWiseWarnings) {
		this.levelWiseWarningList.add(levelWiseWarnings);
	}
	/**
	 * @return Returns the showLink.
	 */
	public boolean isShowLink() {
		return showLink;
	}
	/**
	 * @param showLink The showLink to set.
	 */
	public void setShowLink(boolean showLink) {
		this.showLink = showLink;
	}
	/**
	 * @return Returns the processPoint.
	 */
	public String getProcessPoint() {
		return processPoint;
	}
	/**
	 * @param processPoint The processPoint to set.
	 */
	public void setProcessPoint(String processPoint) {
		this.processPoint = processPoint;
	}
	/**
	 * @return Returns the mouseOver.
	 */
	public String getMouseOver() {
		return mouseOver;
	}
	/**
	 * @param mouseOver The mouseOver to set.
	 */
	public void setMouseOver(String mouseOver) {
		this.mouseOver = mouseOver;
	}
	/**
	 * @return Returns the processPointCode.
	 */
	public String getProcessPointCode() {
		return processPointCode;
	}
	/**
	 * @param processPointCode The processPointCode to set.
	 */
	public void setProcessPointCode(String processPointCode) {
		this.processPointCode = processPointCode;
	}
}
