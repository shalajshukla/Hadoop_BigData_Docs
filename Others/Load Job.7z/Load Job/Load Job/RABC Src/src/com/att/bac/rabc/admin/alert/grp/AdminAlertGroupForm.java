/* Component Name: RABCPPG00504
 * Module Name: AdminAlertGroupForm.java
 * Created on Jan 18, 2006
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.admin.alert.grp;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.apache.struts.Globals;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import org.apache.struts.util.MessageResources;

import com.att.bac.rabc.User;

/**This is the struts Form class for the admin alert group process.  The purpose of this bean class
 * is to hold data to be presented in the web pages AdminAlertGroup.jsp, AdminAlertGroupConfirm.jsp,
 * AdminAlertGroupDetail.jsp.
 * 
 * @author js3175
 */
public class AdminAlertGroupForm extends ActionForm {
	private static final Logger logger = Logger.getLogger(AdminAlertGroupForm.class);
	private static final long serialVersionUID = 0L;
	
	private String dispatch = "";
	private String region = "";
	private String userId = "";
	
	//Alert Group Maintenance Page
	private ArrayList alertGroups = new ArrayList();
	private String selectedAlertGroup = "";
	private int disabled = 0;
	private int superAdmin = 0;
	
	//Alert Group Detail Page
	private AlertGroupTO alertGroupInfo = new AlertGroupTO();
	private String previousAlertGroupName = "";
	private User [] users = new User[0];
	private User [] currentUsers = new User[0];
	private SelectRowTO [] applicationFuncts = new SelectRowTO[0];
	private SelectRowTO [] alertRules = new SelectRowTO[0];
	private SelectRowTO [] previousAlertRules = new SelectRowTO[0];
	private SelectRowTO [] adhocReports = new SelectRowTO[0];
	private String [] selectedUsers = new String[0];
	private String [] selectedCurrentUsers = new String[0];
	private String [] selectedApplicationFuncts = new String[0];
	private String [] selectedAlertRules = new String[0];
	private String [] sendSystemWarning = new String[0];
	private String [] sendApplicationWarning = new String[0];
	private boolean applFuncAll = false;
	private boolean applFuncSkipAll = false;
	private boolean alertRuleAll = false;
	private boolean alertRuleSkipAll = false;
	private boolean systMssgAll = false;
	private boolean systMssgSkipAll = false;
	private boolean applMssgAll = false;
	private boolean applMssgSkipAll = false;
	private int updatePermission = 0;
	private int maintMode = 0;
	private int noApplicationFuncts = 0;
	private int noAlertRules = 0;
	
	//Alert Group Confirm Page
	private int duplicateAlertGroup = 0;
	private String [] insertCurrentUsers = new String[0];
	private String [] insertApplicationFuncts = new String[0];
	private String [] insertAlertRules = new String[0];
	
	//User Access Page
	private String viewUserID = "";
	private UserAccessTO [] userAccessList = new UserAccessTO[0];
	private char areGroups = ' ';
	
	/*
	 * Variables added for calendar page
	 */
	private String procDates;
	private String billRounds;
	private String holidayIndicators;
	private String loadedDataDates;
	

	//This method is called by the container.	
	public ActionErrors validate(ActionMapping mapping, HttpServletRequest req) {
		ActionErrors errors = new ActionErrors();
		MessageResources resources = (MessageResources)req.getAttribute(Globals.MESSAGES_KEY);
		
		//Check for alert group name, description, and users associated
		//with the alert group. If they doen't exists goback to previous page.
		if (this.alertGroupInfo.getAlertGroup() == null || this.alertGroupInfo.getAlertGroup().trim().equals("")){
			ActionMessage error = new ActionMessage("error.admin.alert.group.requiredfield", resources.getMessage("label.admin.alert.group.alertgroupname"));
			errors.add(ActionMessages.GLOBAL_MESSAGE, error);
		}
		if (this.alertGroupInfo.getAlertGroupDescription() == null || this.alertGroupInfo.getAlertGroupDescription().trim().equals("")){
			ActionMessage error = new ActionMessage("error.admin.alert.group.requiredfield", resources.getMessage("label.admin.alert.group.alertgroupdesc"));
			errors.add(ActionMessages.GLOBAL_MESSAGE, error);
		}
		if (this.currentUsers == null || this.currentUsers.length == 0){
			ActionMessage error = new ActionMessage("error.admin.alert.group.requiredfield", resources.getMessage("label.admin.alert.group.curruserlist"));
			errors.add(ActionMessages.GLOBAL_MESSAGE, error);
		}
		logger.debug("Finished AdminAlertGroupForm.validate");
		return errors;
	}
	
	//This method is called by the container.
	public void reset(ActionMapping mapping, HttpServletRequest request) {
		logger.debug("Finished AdminAlertGroupForm.reset");
	}
	
	public void clear() {
		//Alert Group Maintenance Page
		alertGroups.clear();
		selectedAlertGroup = "";
		
		//Alert Group Detail Page
		alertGroupInfo = new AlertGroupTO();
		previousAlertGroupName = "";
		users = new User[0];
		currentUsers = new User[0];
		applicationFuncts = new SelectRowTO[0];
		alertRules = new SelectRowTO[0];
		previousAlertRules = new SelectRowTO[0];
		adhocReports = new SelectRowTO[0];
		selectedUsers = new String[0];
		selectedCurrentUsers = new String[0];
		selectedApplicationFuncts = new String[0];
		selectedAlertRules = new String[0];
		sendSystemWarning = new String[0];
		sendApplicationWarning = new String[0];
		applFuncAll = false;
		applFuncSkipAll = false;
		alertRuleAll = false;
		alertRuleSkipAll = false;
		systMssgAll = false;
		systMssgSkipAll = false;
		applMssgAll = false;
		applMssgSkipAll = false;
		updatePermission = 0;
		maintMode = 0;
		noApplicationFuncts = 0;
		noAlertRules = 0;
		
		//Alert Group Confirm Page
		duplicateAlertGroup = 0;
		insertCurrentUsers = new String[0];
		insertApplicationFuncts = new String[0];
		insertAlertRules = new String[0];
		
		//User Access Page
		viewUserID = "";
		userAccessList = new UserAccessTO[0];
		areGroups = ' ';
		logger.debug("Finished AdminAlertGroupForm.clear");
	}
	
	//Accessor methods...
	/**
	 * @return billRounds
	 */
	public String getBillRounds() {
		return billRounds;
	}
	
	/**
	 * @param billRounds
	 */
	public void setBillRounds(String billRounds) {
		this.billRounds = billRounds;
	}
	
	/**
	 * @return holidayIndicators
	 */
	public String getHolidayIndicators() {
		return holidayIndicators;
	}
	
	/**
	 * @param holidayIndicators
	 */
	public void setHolidayIndicators(String holidayIndicators) {
		this.holidayIndicators = holidayIndicators;
	}
	
	/**
	 * @return loadedDataDates
	 */
	public String getLoadedDataDates() {
		return loadedDataDates;
	}
	
	/**
	 * 
	 * @param loadedDataDates
	 */
	public void setLoadedDataDates(String loadedDataDates) {
		this.loadedDataDates = loadedDataDates;
	}
	
	/**
	 * 
	 * @return procDates
	 */
	public String getProcDates() {
		return procDates;
	}

	/**
	 * @param procDates
	 */
	public void setProcDates(String procDates) {
		this.procDates = procDates;
	}

	/**
	 * @return Returns the dispatch.
	 */
	public String getDispatch() {
		return dispatch;
	}
	/**
	 * @param dispatch The dispatch to set.
	 */
	public void setDispatch(String dispatch) {
		this.dispatch = dispatch;
	}
	/**
	 * @return Returns the region.
	 */
	public String getRegion() {
		return region;
	}
	/**
	 * @param region The region to set.
	 */
	public void setRegion(String region) {
		this.region = region;
	}
	/**
	 * @return Returns the userId.
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @param userId The userId to set.
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	/**
	 * @return Returns the alertRules.
	 */
	public SelectRowTO[] getAlertRules() {
		return this.alertRules;
	}
	/**
	 * @return Returns a single row of the alertRules array.
	 */
	public SelectRowTO getAlertRule(int i) {
		return this.alertRules[i];
	}
	/**
	 * @param alertRules The alertRules to set.
	 */
	public void setAlertRules(SelectRowTO[] alertRules) {
		this.alertRules = alertRules;
	}
	/**
	 * @return Returns the applicationFuncts.
	 */
	public SelectRowTO[] getApplicationFuncts() {
		return this.applicationFuncts;
	}
	/**
	 * @return Returns the applicationFuncts.
	 */
	public SelectRowTO getApplicationFuncts(int i) {
		return this.applicationFuncts[i];
	}
	/**
	 * @param applicationFuncts The applicationFuncts to set.
	 */
	public void setApplicationFuncts(SelectRowTO[] applicationFuncts) {
		this.applicationFuncts = applicationFuncts;
	}
	/**
	 * @param applicationFuncts The applicationFuncts to set when the array has a length of 0.
	 */
	public void setApplicationFuncts(SelectRowTO applicationFunct) {
		SelectRowTO [] none = new SelectRowTO[1];
		none[0] = applicationFunct;
		this.applicationFuncts = none;
	}
	/**
	 * @return Returns the adhocReports.
	 */
	public SelectRowTO[] getAdhocReports() {
		return this.adhocReports;
	}
	/**
	 * @return Returns the adhocReports one row at a time.
	 */
	public SelectRowTO getAdhocReport(int i) {
		return this.adhocReports[i];
	}
	/**
	 * @param adhocReports The adhocReports to set.
	 */
	public void setAdhocReports(SelectRowTO[] adhocReports) {
		this.adhocReports = adhocReports;
	}
	/**
	 * @param adhocReports The adhocReports to set when the array has a length of 0.
	 */
	public void setAdhocReports(SelectRowTO adhocReport) {
		SelectRowTO [] none = new SelectRowTO[1];
		none[0] = adhocReport;
		this.adhocReports = none;
	}
	/**
	 * @return Returns the users.
	 */
	public User[] getUsers() {
		return users;
	}
	/**
	 * @return Returns the users one row at a time.
	 */
	public User getUsers(int i) {
		return users[i];
	}
	/**
	 * @param users The users to set.
	 */
	public void setUsers(User[] users) {
		this.users = users;
	}
	/**
	 * @return Returns the currentUsers.
	 */
	public User[] getCurrentUsers() {
		return this.currentUsers;
	}
	/**
	 * @param currentUsers The currentUsers to set.
	 */
	public void setCurrentUsers(User[] currUsers) {
		if (currUsers != null || currUsers.length != 0) {
			this.currentUsers = currUsers;
		}
	}
	/**
	 * @return Returns the alertGroups.
	 */
	public String [] getAlertGroups() {
		if (this.alertGroups.isEmpty()) {
			String [] none = new String[1];
			none[0] = "no alert groups found";
			disabled = 1;
			return none;
		} else {
			return (String[]) alertGroups.toArray(new String[0]);
		}
	}
	/**
	 * @param alertGroups The alertGroups to set.
	 */
	public void setAlertGroups(ArrayList alertGroups) {
		this.alertGroups = alertGroups;
	}
	/**
	 * @return Returns the selectedAlertGroup.
	 */
	public String getSelectedAlertGroup() {
		return selectedAlertGroup;
	}
	/**
	 * @param selectedAlertGroup The selectedAlertGroup to set.
	 */
	public void setSelectedAlertGroup(String selectedAlertGroup) {
		this.selectedAlertGroup = selectedAlertGroup;
	}
	/**
	 * @return Returns the previousAlertGroupName.
	 */
	public String getPreviousAlertGroupName() {
		return previousAlertGroupName;
	}
	/**
	 * @param previousAlertGroupName The previousAlertGroupName to set.
	 */
	public void setPreviousAlertGroupName(String previousAlertGroupName) {
		this.previousAlertGroupName = previousAlertGroupName;
	}
	/**
	 * @return Returns the selectedCurrentUsers.
	 */
	public String[] getSelectedCurrentUsers() {
		return selectedCurrentUsers;
	}
	/**
	 * @param selectedCurrentUsers The selectedCurrentUsers to set.
	 */
	public void setSelectedCurrentUsers(String[] selectedCurrentUsers) {
		this.selectedCurrentUsers = selectedCurrentUsers;
	}
	/**
	 * @return Returns the selectedUsers.
	 */
	public String[] getSelectedUsers() {
		return selectedUsers;
	}
	/**
	 * @param selectedUsers The selectedUsers to set.
	 */
	public void setSelectedUsers(String[] selectedUsers) {
		this.selectedUsers = selectedUsers;
	}
	/**
	 * @return Returns the alertGroupInfo.
	 */
	public AlertGroupTO getAlertGroupInfo() {
		return alertGroupInfo;
	}
	/**
	 * @param alertGroupInfo The alertGroupInfo to set.
	 */
	public void setAlertGroupInfo(AlertGroupTO alertGroupInfo) {
		this.alertGroupInfo = alertGroupInfo;
	}
	/**
	 * @return Returns the selectedAlertRules.
	 */
	public String[] getSelectedAlertRules() {
		return selectedAlertRules;
	}
	/**
	 * @return Returns the selectedAlertRules one at a time.
	 */
	public String getSelectedAlertRules(int i) {
		return selectedAlertRules[i];
	}
	/**
	 * @param selectedAlertRules The selectedAlertRules to set.
	 */
	public void setSelectedAlertRules(String[] selectedAlertRules) {
		this.selectedAlertRules = selectedAlertRules;
	}
	/**
	 * @param selectedAlertRules The selectedAlertRules to set when the array has a length of 0.
	 */
	public void setSelectedAlertRules(String selectedAlertRule) {
		String [] none = new String[1];
		none[0] = selectedAlertRule;
		this.selectedAlertRules = none;
	}
	/**
	 * @return Returns the previousAlertRules.
	 */
	public SelectRowTO[] getPreviousAlertRules() {
		return previousAlertRules;
	}
	/**
	 * @return Returns the previousAlertRules one at a time.
	 */
	public SelectRowTO getPreviousAlertRule(int i) {
		return previousAlertRules[i];
	}
	/**
	 * @param previousAlertRules The previousAlertRules to set.
	 */
	public void setPreviousAlertRules(SelectRowTO[] previousAlertRules) {
		this.previousAlertRules = previousAlertRules;
	}
	/**
	 * @return Returns the selectedApplicationFuncts.
	 */
	public String[] getSelectedApplicationFuncts() {
		return selectedApplicationFuncts;
	}
	/**
	 * @param selectedApplicationFuncts The selectedApplicationFuncts to set.
	 */
	public void setSelectedApplicationFuncts(String[] selectedApplicationFuncts) {
		this.selectedApplicationFuncts = selectedApplicationFuncts;
	}
	/**
	 * @param selectedApplicationFuncts The selectedApplicationFuncts to set one at a time.
	 */
	public void setSelectedApplicationFuncts(int i, String selectedApplicationFunct) {
		this.selectedApplicationFuncts[0] = selectedApplicationFunct;
	}
	/**
	 * @return Returns the appFunctAll.
	 */
	public boolean getApplFuncAll() {
		return applFuncAll;
	}
	/**
	 * @param appFunctAll The appFunctAll to set.
	 */
	public void setApplFuncAll(boolean applFuncAll) {
		this.applFuncAll = applFuncAll;
	}
	/**
	 * @return Returns the appFunctSkipAll.
	 */
	public boolean getApplFuncSkipAll() {
		return applFuncSkipAll;
	}
	/**
	 * @param appFunctSkipAll The appFunctSkipAll to set.
	 */
	public void setApplFuncSkipAll(boolean applFuncSkipAll) {
		this.applFuncSkipAll = applFuncSkipAll;
	}
	/**
	 * @return Returns the alrtRuleAll.
	 */
	public boolean getAlertRuleAll() {
		return alertRuleAll;
	}
	/**
	 * @param alrtRuleAll The alrtRuleAll to set.
	 */
	public void setAlertRuleAll(boolean alertRuleAll) {
		this.alertRuleAll = alertRuleAll;
	}
	/**
	 * @return Returns the alrtRuleSkipAll.
	 */
	public boolean getAlertRuleSkipAll() {
		return alertRuleSkipAll;
	}
	/**
	 * @param alrtRuleSkipAll The alrtRuleSkipAll to set.
	 */
	public void setAlertRuleSkipAll(boolean alertRuleSkipAll) {
		this.alertRuleSkipAll = alertRuleSkipAll;
	}
	/**
	 * @return Returns the applMssgAll.
	 */
	public boolean getApplMssgAll() {
		return applMssgAll;
	}
	/**
	 * @param applMssgAll The applMssgAll to set.
	 */
	public void setApplMssgAll(boolean applMssgAll) {
		this.applMssgAll = applMssgAll;
	}
	/**
	 * @return Returns the applMssgSkipAll.
	 */
	public boolean getApplMssgSkipAll() {
		return applMssgSkipAll;
	}
	/**
	 * @param applMssgSkipAll The applMssgSkipAll to set.
	 */
	public void setApplMssgSkipAll(boolean applMssgSkipAll) {
		this.applMssgSkipAll = applMssgSkipAll;
	}
	/**
	 * @return Returns the systMssgAll.
	 */
	public boolean getSystMssgAll() {
		return systMssgAll;
	}
	/**
	 * @param systMssgAll The systMssgAll to set.
	 */
	public void setSystMssgAll(boolean systMssgAll) {
		this.systMssgAll = systMssgAll;
	}
	/**
	 * @return Returns the systMssgSkipAll.
	 */
	public boolean getSystMssgSkipAll() {
		return systMssgSkipAll;
	}
	/**
	 * @param systMssgSkipAll The systMssgSkipAll to set.
	 */
	public void setSystMssgSkipAll(boolean systMssgSkipAll) {
		this.systMssgSkipAll = systMssgSkipAll;
	}
	/**
	 * @return Returns the viewUserID.
	 */
	public String getViewUserID() {
		return viewUserID;
	}
	/**
	 * @param viewUserID The viewUserID to set.
	 */
	public void setViewUserID(String userID) {
		this.viewUserID = userID;
	}
	/**
	 * @return Returns the userAccessList.
	 */
	public UserAccessTO[] getUserAccessList() {
		return userAccessList;
	}
	/**
	 * @param userAccessList The userAccessList to set.
	 */
	public void setUserAccessList(UserAccessTO[] userAccessList) {
		this.userAccessList = userAccessList;
	}
	/**
	 * @return Returns the areGroups.
	 */
	public char getAreGroups() {
		return areGroups;
	}
	/**
	 * @param areGroups The areGroups to set.
	 */
	public void setAreGroups(char areGroups) {
		this.areGroups = areGroups;
	}
	/**
	 * @return Returns the maintMode.
	 */
	public int getMaintMode() {
		return maintMode;
	}
	/**
	 * @param maintMode The maintMode to set.
	 */
	public void setMaintMode(int maintMode) {
		this.maintMode = maintMode;
	}
	/**
	 * @return Returns the duplicateAlertGroup.
	 */
	public int getDuplicateAlertGroup() {
		return duplicateAlertGroup;
	}
	/**
	 * @param duplicateAlertGroup The duplicateAlertGroup to set.
	 */
	public void setDuplicateAlertGroup(int duplicateAlertGroup) {
		this.duplicateAlertGroup = duplicateAlertGroup;
	}
	/**
	 * @return Returns the insertAlertRules.
	 */
	public String[] getInsertAlertRules() {
		return insertAlertRules;
	}
	/**
	 * @return Returns the insertAlertRules one row at a time.
	 */
	public String getInsertAlertRules(int i) {
		return insertAlertRules[i];
	}
	/**
	 * @param insertAlertRules The insertAlertRules to set.
	 */
	public void setInsertAlertRules(String[] insertAlertRules) {
		this.insertAlertRules = insertAlertRules;
	}
	/**
	 * @return Returns the insertApplicationFuncts.
	 */
	public String[] getInsertApplicationFuncts() {
		return insertApplicationFuncts;
	}
	/**
	 * @return Returns the insertApplicationFuncts one row at a time.
	 */
	public String getInsertApplicationFuncts(int i) {
		return insertApplicationFuncts[i];
	}
	/**
	 * @param insertApplicationFuncts The insertApplicationFuncts to set.
	 */
	public void setInsertApplicationFuncts(String[] insertApplicationFuncts) {
		this.insertApplicationFuncts = insertApplicationFuncts;
	}
	/**
	 * @return Returns the insertCurrentUsers.
	 */
	public String[] getInsertCurrentUsers() {
		return insertCurrentUsers;
	}
	/**
	 * @return Returns the insertCurrentUsers one row at a time.
	 */
	public String getInsertCurrentUsers(int i) {
		return insertCurrentUsers[i];
	}
	/**
	 * @param insertCurrentUsers The insertCurrentUsers to set.
	 */
	public void setInsertCurrentUsers(String[] insertCurrentUsers) {
		this.insertCurrentUsers = insertCurrentUsers;
	}
	/**
	 * @return Returns the disabled.
	 */
	public int getDisabled() {
		return disabled;
	}
	/**
	 * @param disabled The disabled to set.
	 */
	public void setDisabled(int disabled) {
		this.disabled = disabled;
	}
	/**
	 * @return Returns the noAlertRules.
	 */
	public int getNoAlertRules() {
		return noAlertRules;
	}
	/**
	 * @param noAlertRules The noAlertRules to set.
	 */
	public void setNoAlertRules(int noAlertRules) {
		this.noAlertRules = noAlertRules;
	}
	/**
	 * @return Returns the noApplicationFuncts.
	 */
	public int getNoApplicationFuncts() {
		return noApplicationFuncts;
	}
	/**
	 * @param noApplicationFuncts The noApplicationFuncts to set.
	 */
	public void setNoApplicationFuncts(int noApplicationFuncts) {
		this.noApplicationFuncts = noApplicationFuncts;
	}
	/**
	 * @return Returns the updatePermission.
	 */
	public int getUpdatePermission() {
		return updatePermission;
	}
	/**
	 * @param updatePermission The updatePermission to set.
	 */
	public void setUpdatePermission(int updatePermission) {
		this.updatePermission = updatePermission;
	}
	/**
	 * @return Returns the superAdmin.
	 */
	public int getSuperAdmin() {
		return superAdmin;
	}
	/**
	 * @param superAdmin The superAdmin to set.
	 */
	public void setSuperAdmin(int superAdmin) {
		this.superAdmin = superAdmin;
	}
	/**
	 * @return Returns the sendApplicationWarning.
	 */
	public String[] getSendApplicationWarning() {
		return sendApplicationWarning;
	}
	/**
	 * @param sendApplicationWarning The sendApplicationWarning to set.
	 */
	public void setSendApplicationWarning(String[] sendApplicationWarning) {
		this.sendApplicationWarning = sendApplicationWarning;
	}
	/**
	 * @return Returns the sendSystemWarning.
	 */
	public String[] getSendSystemWarning() {
		return sendSystemWarning;
	}
	/**
	 * @param sendSystemWarning The sendSystemWarning to set.
	 */
	public void setSendSystemWarning(String[] sendSystemWarning) {
		this.sendSystemWarning = sendSystemWarning;
	}
}
