/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.alerts.status;

import java.util.Map;
import org.jfree.chart.JFreeChart;
import de.laures.cewolf.ChartPostProcessor;

/**
 * This is a utility class used for processing prior to rendering a bar graph.
 * 
 * @author Shailesh Hemdev - SH8512
 */
public class BarGraphPostProcessor implements ChartPostProcessor {
	/**
	 * Method to process prior to rendering a bar graph.
	 * 
	 * @param chart
	 * @param map
	 * @see de.laures.cewolf.ChartPostProcessor#processChart(java.lang.Object, java.util.Map)
	 */
	public void processChart(Object chart, Map map){
		JFreeChart jChart = (JFreeChart) chart;
		jChart.getCategoryPlot().getDomainAxis().setTickLabelsVisible(false);
		jChart.getCategoryPlot().setRangeGridlinesVisible(true);
		jChart.getCategoryPlot().setDomainGridlinesVisible(true);
	}
}
