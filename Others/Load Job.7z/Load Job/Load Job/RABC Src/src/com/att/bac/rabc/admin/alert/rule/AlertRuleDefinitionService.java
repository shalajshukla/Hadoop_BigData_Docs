/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.admin.alert.rule;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;

import com.att.bac.rabc.CntrlPtTrans;
import com.att.bac.rabc.CntrlPtTransDAO;
import com.att.bac.rabc.Column;
import com.att.bac.rabc.MouseOverTbl;
import com.att.bac.rabc.MouseOverTblDAO;
import com.att.bac.rabc.MyDate;
import com.att.bac.rabc.DataTblDdlBean;
import com.att.bac.rabc.PickList;
import com.att.bac.rabc.PresnId;
import com.att.bac.rabc.ProgressBar;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.StaticDataLoader;
import com.att.bac.rabc.WebDataLink;
import com.att.bac.rabc.WebDataLinkDAO;
import com.att.bac.rabc.admin.AlertGroupUser;
import com.att.bac.rabc.admin.AlertGroupUserDAO;
import com.att.bac.rabc.admin.adhoc.rpt.AdhocMainPageService;
import com.att.bac.rabc.MouseOverLinkDAO;
import com.att.bac.rabc.MouseOverLink;

/**
 * This is a Service class for Alert Rule Definition (All 3 steps).
 * 
 * @author Shashank Weginwar - SW3562
 */
public class AlertRuleDefinitionService {
	private static final Logger logger = Logger.getLogger(AlertRuleDefinitionService.class);
	private static AlertRuleDefinitionService alertRuleDefinitionService; 
	private static final String trend = "Trend";
	private static final String track = "Track";
	
	protected static final String getAllDesc = "SELECT ALERT_RULE, PARTI_REF_ID, PRESN_ID, " +
	"FILE_VERIF_IND, DATA_EXTRCT_IND, DATA_CALC_IND, CALC_RULE, WARNING_IND, AVG_IND, ALERT_MSG_IND, " +
	"ALERT_SEQ_NUM_IND, ALERT_TIME_IND, ALERT_DASH_FRESH_IND, ALERT_DESC, ALERT_EXEC_DATE, ALERT_KEY_LVL, " +
	"ALERT_KEY1_NAME, ALERT_KEY2_NAME, ALERT_KEY3_NAME, ALERT_KEY4_NAME, ALERT_KEY5_NAME, ALERT_FILE_CT, " +
	"ASOC_FILE_ID, ALERT_RULE_PRESN_IND, DIVISION_NAME_KEY_LVL, DB_NODE_ID, ALERT_RULE_STATUS, EFF_DATE, " +
	"STD_TYPE, ALERT_EXEMPT_IND, USER_ID, TIME_STAMP, ALERT_RULE_CREATE_IND, ALERT_DATA_KEEP, ALERT_RULE_TYPE, " +
	"ALERT_MNTH_EXEC_DAY, ALERT_MNTH_EXEC_BILL_RND FROM RABC_ALERT_RULE WHERE ALERT_RULE = ''{0}''";
	
	protected static final String getAlertGrps = "SELECT DISTINCT ALERT_GRP, UPPER(USER_ID) USER_ID FROM RABC_ALERT_GRP_USER WHERE " +
	"UPPER(USER_ID) = UPPER(''{0}'') ORDER BY UPPER(ALERT_GRP)";
	
	protected static final String getFSQ = "SELECT DISTINCT FILE_SEQ_NUM_IND FROM RABC_ALERT_RULE_PRESN_RULE WHERE PRESN_ID = {0}";
	
	protected static final String getAvgDaysRcdsAndTiming = "SELECT DISTINCT AVG_NUM_DATE, AVG_TREND_TIME_IND, AVG_NUM_REC, AVG_TYPE FROM " +
	"RABC_AVG_CALC WHERE ALERT_RULE = ''{0}''";

	protected static final String getCntrlPoint = "SELECT CNTRL_PT_CD, ALERT_RULE, PRESN_SEQ_NUM FROM RABC_CNTRL_PT_ALERT WHERE ALERT_RULE = ''{0}''";
	
	protected static final String getCntrlPointDesc = "SELECT CNTRL_PT_CODE, CNTRL_PT_DESC, PRESN_SEQ_NUM FROM RABC_CNTRL_PT_TRANS WHERE CNTRL_PT_CODE = ''{0}''";
	
	private static final String currGrps = "SELECT ALERT_GRP FROM RABC_UPDATE_GRP WHERE ALERT_RULE = ''{0}'' ORDER BY UPPER(ALERT_GRP)";
	
	//SQL Queries added to implement enhancements pertaining to mouse over & report link.
	protected static final String qryMouseOver	= "SELECT TABLE_NAME,TABLE_DESC,TABLE_KEY_DATA,TABLE_KEY_NAME"
												+ " FROM RABC_MOUSE_OVER_TBL ORDER BY TABLE_DESC"; 
	
	protected static final String qryReportLinks1 = "SELECT DISTINCT BAR.ALERT_RULE ALERT_RULE,BPI.PRESN_ID PRESN_ID FROM RABC_ALERT_RULE BAR, RABC_PRESN_ID BPI " +
	"WHERE (ALERT_RULE_STATUS IS NULL OR ALERT_RULE_STATUS <> ''DELETED'') AND ALERT_RULE_PRESN_IND = ''Y'' " +
	"AND BAR.PRESN_ID = BPI.PRESN_ID AND (BAR.ALERT_RULE_CREATE_IND IS NULL OR BAR.ALERT_RULE_CREATE_IND <> ''S'') " +
	"ORDER BY UPPER(ALERT_RULE)";
	
	protected static final String qryReportLinks = " SELECT DISTINCT PRESN_ID,PRESN_ID_DESC FROM RABC_PRESN_ID "
	+ " WHERE UPPER(ADHOC_RPT_STATUS) = ''ACTIVE'' AND PRESN_ID_DESC IS NOT NULL "
	+ "AND UPPER(ADHOC_RPT_IND) = ''Y'' ORDER BY UPPER(PRESN_ID_DESC) ASC " ;
	
	protected static final String qryAlertRuleKeyFlags =  "SELECT KEY1_DATA_LINK_IND, KEY1_DATA_LINK_NUM,KEY1_MOUSE_OVER_NUM,"
													 	+ " KEY2_DATA_LINK_IND, KEY2_DATA_LINK_NUM,KEY2_MOUSE_OVER_NUM, "
														+ " KEY3_DATA_LINK_IND, KEY3_DATA_LINK_NUM,KEY3_MOUSE_OVER_NUM, "
														+ " KEY4_DATA_LINK_IND, KEY4_DATA_LINK_NUM,KEY4_MOUSE_OVER_NUM,"
														+ " KEY5_DATA_LINK_IND, KEY5_DATA_LINK_NUM,KEY5_MOUSE_OVER_NUM "
														+ " FROM RABC_ALERT_RULE_PRESN_RULE WHERE PRESN_ID = {0} AND WEBID = ''RABCPSF00013''";
	
	protected static final String qryReportLink = "SELECT PRESN_ID, WEBID, EXEC_PRESN_SEQ_NUM, LINK_NUM, LINK_DDL_NAME, LINK_TO_PGM, LINK_PRESN_ID, "
												+ "LINK_NUM_PARM,LINK_PARM1,LINK_PARM2,LINK_PARM3,LINK_PARM4,LINK_PARM5,LINK_PARM6,LINK_PARM7,"
												+ "LINK_PARM8,LINK_PARM9,LINK_PARM10,LINK_PARM11,LINK_PARM12 FROM RABC_WEB_DATA_LINK "
												+ "WHERE PRESN_ID = {0} AND WEBID = ''RABCPSF00013'' AND LINK_NUM = {1} ";
	
	protected static final String qryMouseOverLink =  "SELECT PRESN_ID, WEBID, EXEC_PRESN_SEQ_NUM, MOUSE_OVER_NUM, LINK_TBL_KEY_NAME, LINK_TBL_KEY_DATA, LINK_TBL_NAME "
													+ " FROM RABC_MOUSE_OVER_LINK WHERE PRESN_ID = {0} AND WEBID= ''RABCPSF00013'' AND MOUSE_OVER_NUM = {1} ";
	
	protected static final String qryAllowMonthlyTimingUpdate =  "SELECT COUNT(PROC_DATE) FROM RABC_EXTRCT_SUMY_DATA WHERE PARTI_REF_ID = {0} ";
	
	protected static final String qryGetStdNumDate =  "SELECT ALERT_RULE, PARTI_REF_ID, STD_NUM_DATE, STD_NUM_REC, STD_TREND_TIME_IND, STD_TYPE, STD_TBL_NAME FROM RABC_STD_CALC WHERE PARTI_REF_ID = {0} ";

	/**
	 * Synchronized method to return the instance of AlertRuleDefinitionService object.
	 * It checks the existance of the instance of AlertRuleDefinitionService and if it does not exists
	 * then creates one instance of AlertRuleDefinitionService and returns otherwise it returns the
	 * existing instance of AlertRuleDefinitionService.
	 * 
	 * @return AlertRuleDefinitionService
	 */
	public static synchronized AlertRuleDefinitionService getAlertRuleDefinitionService(){
		if (alertRuleDefinitionService == null){
			alertRuleDefinitionService = new AlertRuleDefinitionService();
		}
		return alertRuleDefinitionService;
	}
	
	/**
	 * Returns the AlertRuleDefinition object for the given UserId and AlertRule.
	 * 
	 * @param connection
	 * @param failures
	 * @param args
	 * @param progressBar
	 * @param region
	 * @return AlertRuleDefinition
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	protected AlertRuleDefinition getAlertRuleDefinition(Connection connection, List failures, List args, ProgressBar progressBar, String region) throws SQLException, ClassNotFoundException{
		AlertRuleDefinition alertRuleDefinition = new AlertRuleDefinition(region);
		
		List alertRuleNameList = new ArrayList();
		alertRuleNameList.add(args.get(0));

		AlertRule alertRule = getAlertRule(connection,failures,alertRuleNameList,getAllDesc);
		updateFromAlertRule(alertRuleDefinition,alertRule,region);
		
		/*
		 * Get the std deviation
		 */
		List stdArgs = new ArrayList();
		stdArgs.add(Integer.toString(alertRule.getPartiRefId()));
		setStdNumDate(connection,failures,stdArgs,alertRuleDefinition);
		
		progressBar.setProgressPercent(20);
		
		/*
		 * Check whether user can update bill round & date for Monthly
		 */
		List monthlyUpdateCheckArgs = new ArrayList();
		monthlyUpdateCheckArgs.add(Integer.toString(alertRule.getPartiRefId()));
		if (checkMonthlyTimingUpdateAllowed(connection,failures,monthlyUpdateCheckArgs)){
			alertRuleDefinition.setAllowMonthlyTimingUpdate("true");
		}
		
		/*
		 * Change the variable name to userIdArgumentList; also all lists to be suffixed by list key word
		 */
		List userId = new ArrayList();
		userId.add(args.get(1));
		
		setSelectedAlertGroups(connection, failures, alertRuleDefinition, alertRule);
		setSelectedRelatedAlertRules(connection, failures, alertRuleDefinition, alertRule);
		setAvgRecDaysTypeAndTiming(connection,failures,alertRuleNameList,alertRuleDefinition);
		setAlertGroupsList(connection,failures,userId,alertRuleDefinition);
		progressBar.setProgressPercent(30);

		List presnIdArgs = new ArrayList();
		presnIdArgs.add(new Integer(alertRule.getPresnId()).toString());
		setFileSeqIndicator(connection,failures,presnIdArgs,alertRuleDefinition);
		
		//alertRuleDefinition.setControlPoint("Bill Day");
		setControlPoint(connection, failures, alertRuleNameList, alertRuleDefinition);  
		
		List partiRefIdList = new ArrayList();
		int partiRefId = alertRule.getPartiRefId();
		partiRefIdList.add((new Integer (partiRefId)).toString());
		
		List alertProcList = new ArrayList();
		alertProcList = AlertItemService.getAlertItemService().getAlertProcList(connection,failures,alertRuleNameList);
		
		List trackFileDtlList = new ArrayList();
		trackFileDtlList = AlertItemService.getAlertItemService().getTrackFileDtlList(connection,failures,alertRuleNameList);
				
		List extrctBuildRuleList = new ArrayList();
		extrctBuildRuleList = AlertItemService.getAlertItemService().getExtrctBuildRuleList(connection,failures,partiRefIdList);
		
		alertRuleDefinition = AlertItemService.getAlertItemService().updateTableList(connection, failures,trackFileDtlList,alertRuleDefinition, alertRule);
		
		List alertItemList = AlertItemService.getAlertItemService().getAlertItemList(connection,failures, alertProcList,trackFileDtlList,extrctBuildRuleList, alertRule);
		for (int i=0;i<alertItemList.size();i++){
			AlertItem alertItem = (AlertItem) alertItemList.get(i);
			for (int j=0;j<alertItem.getColumnList().size();j++){
				Column column = (Column)alertItem.getColumnList().get(j);
			}
			alertRuleDefinition.addAlertItem(alertItem);
		}
		progressBar.setProgressPercent(40);
		
		/* 
		 * All 3 lists are used to set alertKey, relatedAlertRules 
		 * and selectedRelatedAlertRules of AlertRuleDefinition object.
		 */
		List alertKeyList = AlertItemService.getAlertItemService().getalertKeyList(trackFileDtlList, alertRule,connection,failures);  //Returns Alert Key Object.
		
		/*
		 * Set the current key level & alertKey List in AlertRuleDefinition Object.
		 */
		alertRuleDefinition.setAlertKeyLevel(alertRule.getAlertKeyLvl());
		for (int i=0;i<alertKeyList.size();i++){
			alertRuleDefinition.addAlertKey((AlertKey)alertKeyList.get(i));
		}
		
		/*
		 * Build the mouse over options as well as the report link options.
		 */
		buildMouseOverOptions(connection,failures,alertRuleDefinition);
		buildReportLinkOptions(connection,failures,alertRuleDefinition);
		getKeyRelatedAttributes(connection,failures,alertRule,alertRuleDefinition);
		progressBar.setProgressPercent(50);
		
		return alertRuleDefinition;
	}
	
	/**
	 * Sets the AlertRuleDefinition Object of getAlertRuleDefinition method.
	 * 
	 * @param alertRuleDefinition
	 * @param alertRule
	 * @param region
	 */
	protected void updateFromAlertRule(AlertRuleDefinition alertRuleDefinition, AlertRule alertRule, String region){
		String alertRuleType = null;
		
		alertRuleDefinition.setAlertRule(alertRule.getAlertRule());
		alertRuleDefinition.setAlertRuleDescription(alertRule.getAlertDesc());
		alertRuleDefinition.setDelayExecutionTime(alertRule.getAlertExecDate());
		alertRuleDefinition.setAlertDataKeep(alertRule.getAlertDataKeep());
		alertRuleDefinition.setUserId(alertRule.getUserId());
		alertRuleDefinition.setTimeStamp(new MyDate(alertRule.getTimeStamp()));
		
		MyDate effectiveDate = new MyDate(alertRule.getEffDate());
		alertRuleDefinition.setEffectiveDate(effectiveDate.toString());
		
		if ("Y".equals(alertRule.getAlertExemptInd().trim())){
			alertRuleDefinition.setThresholdExemptionCheck("on");
		}else {
			alertRuleDefinition.setThresholdExemptionCheck(null);
		}
		
		alertRuleType = alertRule.getAlertRuleType();
		
		if (alertRuleType.equals("TRACK")){
			alertRuleDefinition.setAlertRuleType(track);	
		} else {
			alertRuleDefinition.setAlertRuleType(trend);
		}
		
		String dbNodeId = alertRule.getDbNodeId();
		List dbNodeList = StaticDataLoader.getDBNodeByID(dbNodeId, region);
		if (!dbNodeList.isEmpty()){
			PickList dbNode = (PickList)dbNodeList.get(0);
			alertRuleDefinition.setDbNodeId(dbNodeId);
			alertRuleDefinition.setDataSource(dbNode.getValue1()); //put description here
		}
		
		/*
		 * PMT 284847 Code Change
		 */
		if (alertRule.getAlertMnthExecBillRnd() == 0){
			alertRuleDefinition.setAlertRuleMonthlyTimingType("D");
			alertRuleDefinition.setMnthExecDt(Integer.toString(alertRule.getAlertMnthExecDt()));
			alertRuleDefinition.setMnthExecBillRnd("");
		}else {
			alertRuleDefinition.setAlertRuleMonthlyTimingType("B");
			alertRuleDefinition.setMnthExecDt("");
			alertRuleDefinition.setMnthExecBillRnd(Integer.toString(alertRule.getAlertMnthExecBillRnd()));
		}
	}
	
	/**
	 * Sets all Related Alert Rules of the requested alert rule.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertRuleDefinition
	 * @param alertRule
	 */
	protected void setSelectedRelatedAlertRules(Connection connection, List failures, AlertRuleDefinition alertRuleDefinition, AlertRule alertRule){
		List selectedRelatedAlertRules = new ArrayList();
		selectedRelatedAlertRules = AlertItemService.getAlertItemService().getSelectedRelatedAlerts(connection,failures,alertRuleDefinition);
		int sizeOfSelectedRelatedAlertRules = selectedRelatedAlertRules.size();
		String [] selectedAlertRules = new String [sizeOfSelectedRelatedAlertRules];
		for (int i=0;i<sizeOfSelectedRelatedAlertRules;i++){
			selectedAlertRules[i] = selectedRelatedAlertRules.get(i).toString();
		}
		alertRuleDefinition.setSelectedRelatedAlertRules(selectedAlertRules);
	}
	
	/**
	 * Sets the alertGroups [] variable in the AlertRuleDefinition object.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertRuleDefinition
	 * @param alertRule
	 */
	protected void setSelectedAlertGroups(Connection connection, List failures, AlertRuleDefinition alertRuleDefinition, AlertRule alertRule){
		String selectSQL = currGrps;
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		List args = new ArrayList();
		args.add(alertRule.getAlertRule());
		List result = new ArrayList();
		
		try {
			MessageFormat mf = new MessageFormat(selectSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("AlertRuleDefinitionService.setSelectedAlertGroups() - Executing SQL statement: "+ sqlStmt);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			
			while (rs.next()) {
				result.add(rs.getString("ALERT_GRP"));
			}
			int size = result.size();
			String [] selectedAltGrp = new String [size];
			for(int i = 0; i < size; i++){
				selectedAltGrp[i] = (result.get(i)).toString();
			}
			alertRuleDefinition.setAlertGroups(selectedAltGrp);
			
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
	}
	
	/**
	 * Sets the following fields 
	 * 1) Average Days
	 * 2) Average Records
	 * 3) Average Type
	 * 4) Alert Rule Timing in AlertRuleDefinition object.
	 * 
	 * @param connection
	 * @param failures
	 * @param args
	 * @param alertRuleDefinition
	 */
	protected void setAvgRecDaysTypeAndTiming(Connection connection, List failures, List args, AlertRuleDefinition alertRuleDefinition){
		String selectSQL = getAvgDaysRcdsAndTiming;
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		
		try {
			MessageFormat mf = new MessageFormat(selectSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("AlertRuleDefinitionService.getAvgRecDaysType() - Executing SQL statement: "+ sqlStmt);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			
			while (rs.next()) {
				alertRuleDefinition.setAverageDays(rs.getString("AVG_NUM_DATE"));
				alertRuleDefinition.setAverageRecords(rs.getString("AVG_NUM_REC"));
				alertRuleDefinition.setAverageType(rs.getString("AVG_TYPE"));
				alertRuleDefinition.setAlertRuleTiming(rs.getString("AVG_TREND_TIME_IND"));
				break;
			}
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
	}	

	/**
	 * Sets control point in AlertRuleDefinition Object.
	 * 
	 * @param connection
	 * @param failures
	 * @param args
	 * @param alertRuleDefinition
	 */
	protected void setControlPoint (Connection connection, List failures, List args, AlertRuleDefinition alertRuleDefinition){
		CntrlPtAlertDAO cntrlPtAlertDAO = new CntrlPtAlertDAO();
		String selectSQL = getCntrlPoint;
		List cntrlPtAlertList = cntrlPtAlertDAO.get(connection,failures,args,selectSQL);
		
		if (!cntrlPtAlertList.isEmpty()){
			String cntlrPt = ((CntrlPtAlert)cntrlPtAlertList.get(0)).getCntrlPtCd();
			alertRuleDefinition.setControlPoint(cntlrPt);
			CntrlPtTransDAO cntrlPtTransDAO =new CntrlPtTransDAO();
			List newArgList = new ArrayList();
			newArgList.add(cntlrPt);
			List cntrlPtTransList=cntrlPtTransDAO.get(connection,failures,newArgList,getCntrlPointDesc);
			
			if (!cntrlPtTransList.isEmpty()){
				String cntlrPtDesc = ((CntrlPtTrans) cntrlPtTransList.get(0)).getCntrlPtDesc();
				alertRuleDefinition.setControlPointDesc(cntlrPtDesc);
			}
		}	
	}
	
	/**
	 * Sets the list of Alert Groups for a perticular user in AlertRuleDefinition Object.
	 * 
	 * @param connection
	 * @param failures
	 * @param args
	 * @param alertRuleDefinition
	 */
	protected void setAlertGroupsList(Connection connection, List failures, List args,AlertRuleDefinition alertRuleDefinition){
		List alertGroupsList = new ArrayList();
		AlertGroupUserDAO alertGroupUserDAO = new AlertGroupUserDAO();
		String selectSQL = getAlertGrps;
		alertGroupsList = alertGroupUserDAO.get(connection,failures,args,selectSQL);
		if (alertGroupsList != null) {
			for(int i = 0; i < alertGroupsList.size(); i++){
				alertRuleDefinition.addAlertGroup(((AlertGroupUser)alertGroupsList.get(i)));
			}
		}
	}
	
	/**
	 * Sets File Sequence Indicator in AlertRuleDefinition object.
	 * 
	 * @param connection
	 * @param failures
	 * @param args
	 * @param alertRuleDefinition
	 */
	protected void setFileSeqIndicator(Connection connection, List failures, List args, AlertRuleDefinition alertRuleDefinition){
		String selectSQL = getFSQ;
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		String fileSequenceIndicator= null;

		try {
			MessageFormat mf = new MessageFormat(selectSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("AlertRuleDefinitionService.GetFSQ() - Executing SQL statement: "+ sqlStmt);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			
			while (rs.next()) {
				fileSequenceIndicator = rs.getString("FILE_SEQ_NUM_IND");
				break;
			}
			
			if ("Y".equals(fileSequenceIndicator)){
				alertRuleDefinition.setFileSequenceIndicator("on");
			}else{
				alertRuleDefinition.setFileSequenceIndicator(null);
			}
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
		
	}	
	
	/**
	 * Get attributes from RABC_ALERT_RULE & update alertRuleDefinition object.
	 * 
	 * @param connection
	 * @param failures
	 * @param args
	 * @param selectSQL
	 * @return AlertRule
	 */
	protected AlertRule getAlertRule(Connection connection, List failures, List args, String selectSQL){
		AlertRuleDAO alertRuleDAO = new AlertRuleDAO();
		List alertRuleList = alertRuleDAO.get(connection,failures,args,selectSQL);
		AlertRule alertRule = (AlertRule) alertRuleList.get(0);
		return alertRule;
	}

	/**
	 * Used when new Alert Rule is to be created.
	 * 
	 * @param connection
	 * @param failures
	 * @param args
	 * @param alertRuleDefinition
	 * @param progressBar
	 * @return AlertRuleDefinition
	 */
	protected AlertRuleDefinition buildNew(Connection connection, List failures, List args, AlertRuleDefinition alertRuleDefinition, ProgressBar progressBar){
		setAlertGroupsList(connection,failures,args,alertRuleDefinition);
		progressBar.setProgressPercent(20);
		MyDate effectiveDate = new MyDate(new Date(System.currentTimeMillis()));
		alertRuleDefinition.setEffectiveDate(effectiveDate.toString());
		alertRuleDefinition.setAlertKeyLevel(1);
		
		/*
		 * Build the mouse over options as well as the report link options
		 */
		buildMouseOverOptions(connection,failures,alertRuleDefinition);
		buildReportLinkOptions(connection,failures,alertRuleDefinition);
		progressBar.setProgressPercent(30);
		
		return alertRuleDefinition;
	}
	
	/**
	 * Assuming that from the form you have obtained the data attribute that will 
	 * be the 1st argument passed to this method.
	 * 
	 * @param connection
	 * @param alertRuleDefinition
	 * @param failureList
	 * @param args
	 * @param region
	 * @return AlertRuleDefinition
	 */
	protected AlertRuleDefinition updateAlertRuleDefinition(Connection connection, AlertRuleDefinition alertRuleDefinition,List failureList,List args, String region){
		String data = (String)args.get(0);
		//Perform string operations to get the details required for creating LHS & RHS list
		String tableName = null;
		String viewName = null;
		String columnName = null;
		String presnFormat = null;
		StringTokenizer st1;
		StringTokenizer st2;
		List tableList = new ArrayList();
		List columnAttributesList = new ArrayList();
		List selectedTableList = new ArrayList();
		
		// Remove all columns from the LHSCOlumn & RHSColumnList
		if (!alertRuleDefinition.getLHSColumnsList().isEmpty()){
			alertRuleDefinition.getLHSColumnsList().clear();
		}
		if (!alertRuleDefinition.getRHSColumnsList().isEmpty()){
			alertRuleDefinition.getRHSColumnsList().clear();
		}

		//Form the List of columns
		st1 = new StringTokenizer(data,";");
		while (st1.hasMoreTokens()) {
			tableList.add(st1.nextToken());
        }
		
		int tableListSize = tableList.size();
		String [] alertType = new String [tableListSize];
		String [] warningIndicator = new String [tableListSize];
		String [] reportLink = new String [tableListSize];
		String [] alertUnit = new String [tableListSize];
			
		for(int j = 0; j < tableList.size(); j++){
			String columnAttributes = tableList.get(j).toString();
			st2 = new StringTokenizer(columnAttributes,":");
			columnAttributesList = new ArrayList();
			
			while (st2.hasMoreTokens()) {
				columnAttributesList.add(st2.nextToken());
	        }
			
			Column column = new Column();
			column.setColumnAlertProcTBL((String)columnAttributesList.get(3));
			column.setColumnTBLDDLName((String)columnAttributesList.get(2));
			
			String viewNm = (String)columnAttributesList.get(1);
			if (viewNm.indexOf("VW_")!=-1){
				column.setColumnViewName(viewNm);
			}
			
			String columnDataType = (String)columnAttributesList.get(4);
			if ("CAL".equals(columnDataType)) {
				column.setColumnTBLDataType(columnDataType);
			}
			
			column.setColumnTBLDDLPRESCSNFormatType((String)columnAttributesList.get(7));
			
			String LHSOrRHSFlag = (String)columnAttributesList.get(0);
			
			if ("L".equals(LHSOrRHSFlag)){
				alertRuleDefinition.addLHSColumn(column);
			}else {
				alertRuleDefinition.addRHSColumn(column);
			}
			selectedTableList.add(column);
			if("Trend".equals(alertRuleDefinition.getAlertRuleType()) || "2".equals(alertRuleDefinition.getAlertRuleType())){
				warningIndicator[j] = (String)columnAttributesList.get(9);
				alertType[j] = (String)columnAttributesList.get(8);
				reportLink[j] = (String)columnAttributesList.get(10);
				alertUnit[j] = (String)columnAttributesList.get(11);
			}
		}
		
		// Call the method to update the Alert Item List
		if("Track".equals(alertRuleDefinition.getAlertRuleType()) || "1".equals(alertRuleDefinition.getAlertRuleType())){
			alertRuleDefinition = AlertItemService.getAlertItemService().updateAlertItemListForTrack(connection, alertRuleDefinition, failureList, selectedTableList, region);
		} else {
			alertRuleDefinition = AlertItemService.getAlertItemService().updateAlertItemListForTrend(connection,alertRuleDefinition,failureList,selectedTableList,warningIndicator,alertType,reportLink, alertUnit);
		}
		
		// Call method to update the key list
		alertRuleDefinition = AlertItemService.getAlertItemService().updateAlertKeyList(connection, alertRuleDefinition, failureList, selectedTableList, region);
		return alertRuleDefinition;
	}
	
	/**
	 * Returns the string to populate left and right column boxes for tracking rule.
	 * And for trending rule returns the string to populate column box.
	 * 
	 * @param alertRuleDefinition
	 * @return String
	 */
	protected String getData(AlertRuleDefinition alertRuleDefinition){
		Column column;
		String data = null;
		
		for (int i = 0; i < alertRuleDefinition.getLHSColumnsList().size(); i++){
			column = (Column) alertRuleDefinition.getLHSColumnsList().get(i);
			
			if (data==null){
				data = "";
			}else {
				data = data + ";";
			}
			
			data = data + "L"+":";
			
			if (column.getColumnViewName()==null){
				data = data + column.getColumnAlertProcTBL()+":";
			}else {
				data = data + column.getColumnViewName()+":";
			}
			
			data = data + column.getColumnTBLDDLName()+":";
			data = data + column.getColumnAlertProcTBL()+":";
			
			if (column.getColumnTBLDataType()==null){
				data = data + "" +":";
			}else {
				data = data + column.getColumnTBLDataType()+":";
			}
			
			data = data + column.getColumnAlertProcTBL()+"."+column.getColumnTBLDDLName()+":";
			data = data + column.getColumnTBLDDLName() + ":";
			data = data + column.getColumnTBLDDLPRESCSNFormatType();
		}
		for (int i = 0; i < alertRuleDefinition.getRHSColumnsList().size(); i++){
			column = (Column) alertRuleDefinition.getRHSColumnsList().get(i);
			
			if (data==null){
				data = "";
			}else {
				data = data + ";";
			}
			data = data + "R"+":";
			
			if (column.getColumnViewName()==null){
				data = data + column.getColumnAlertProcTBL()+":";
			}else {
				data = data + column.getColumnViewName()+":";
			}
			
			data = data + column.getColumnTBLDDLName()+":";
			data = data + column.getColumnAlertProcTBL()+":";
			
			if (column.getColumnTBLDataType()==null){
				data = data + "" +":";
			}else {
				data = data + column.getColumnTBLDataType()+":";
			}
			data = data + column.getColumnAlertProcTBL()+"."+column.getColumnTBLDDLName()+":";
			data = data + column.getColumnTBLDDLName() + ":";
			data = data + column.getColumnTBLDDLPRESCSNFormatType();
		}
		return data;
	}
	
	/**
	 * Overloaded method for getting the data value in case of trending rule.
	 * 
	 * @param alertItemList
	 * @return String
	 */
	protected String getData(List alertItemList){
		String data = null;
		//String alertType = null;
		
		for (int i = 0; i < alertItemList.size(); i++){
			Column column = new Column();
			AlertItem alertItem = new AlertItem();
			
			alertItem = (AlertItem) alertItemList.get(i);
			column = (Column)alertItem.getColumnList().get(0);
			
			if (data==null){
				data = "";
			}else {
				data = data + ";";
			}
			
			data = data + "L"+":";
			
			if (column.getColumnViewName()==null){
				data = data + column.getColumnAlertProcTBL()+":";
				
			}else {
				data = data + column.getColumnViewName()+":";
			}
			
			data = data + column.getColumnTBLDDLName()+":";
			data = data + column.getColumnAlertProcTBL()+":";
			
			if (column.getColumnTBLDataType()==null){
				data = data + " " +":";
			}else {
				data = data + column.getColumnTBLDataType()+":";
			}
			
			data = data + column.getColumnAlertProcTBL()+"."+column.getColumnTBLDDLName()+":";
			data = data + column.getColumnTBLDDLName() + ":";
			data = data + column.getColumnTBLDDLPRESCSNFormatType() + ":";
			data = data + alertItem.getAlertType() + ":";
			
			if ("Y".equals(alertItem.getWarningIndicator())){
				data = data + "Y" + ":";
			}else {
				data = data + "N" + ":";
			}
			
			if (alertItem.getReportLinkData()!=null){
				data = data + alertItem.getReportLinkData() + ":";
			}else {
				data = data + "---Select---" + ":";
			}
			if (alertItem.getAlertUnit()!=null && !"none".equals(alertItem.getAlertUnit())){
				data = data + alertItem.getAlertUnit();
			}else {
				data = data + "none";
			}
		}
		return data;
	}
	
	/**
	 * 	Method will check whether the fields TBL_BILL_RND_DDL_MON & TBL_BILL_RND_DDL_YEAR OR TBL_PROC_DATE_DDL_NAME 
	 * 	are null for any tables
	 */
	
	/**
	 * Method will check whether the fields TBL_BILL_RND_DDL_MON & TBL_BILL_RND_DDL_YEAR OR TBL_PROC_DATE_DDL_NAME 
	 * are null for any tables.
	 * 
	 * @param tableList
	 * @param selTiming
	 * @param region
	 * @return boolean
	 */
	protected boolean checkTime(List tableList, String selTiming, String region){
		boolean checkTime = false;
		
		if (!tableList.isEmpty()){
			int tableListSize = tableList.size();
			for (int i=0;i<tableListSize;i++){
				Column column = (Column)tableList.get(i);
				
				List checkTimingDataTblDdlList = StaticDataLoader.getDataTblDdlBySelTiming(column.getColumnAlertProcTBL(), selTiming, region);
				List checkTimingList = new ArrayList();
				
				if (!checkTimingDataTblDdlList.isEmpty()){
					int checkTimingDataTblDdlListSize = checkTimingDataTblDdlList.size();
					for (int j=0;j<checkTimingDataTblDdlListSize;j++){
						DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)checkTimingDataTblDdlList.get(j);
						
						if ("B".equals(selTiming)){
							if (dataTblDdlBean.getTblBillRndDdlMon()!=null && dataTblDdlBean.getTblBillRndDdlYear()!=null){
								checkTimingList.add(dataTblDdlBean);
							}
						}else {
							if (dataTblDdlBean.getTblProcDateDdlName()!=null){
								checkTimingList.add(dataTblDdlBean);
							}
						}
					}
					
					if (checkTimingList.isEmpty()){
						checkTime = true;
					}
				}
			}
		}

		return checkTime;
	}
	
	/**
	 * Method will check whether the file sequence indicator for any of the columns is set to some value which is 
	 * required if user has checked the file sequence indicator in the 1st page.
	 * 
	 * @param tableList
	 * @param region
	 * @return boolean
	 */
	protected boolean checkFsq(List tableList, String region){
		boolean checkFsq = false;
		
		if (!tableList.isEmpty()){
			int tableListSize = tableList.size();
			for (int i=0;i<tableListSize;i++){
				Column column = (Column)tableList.get(i);
				
				List checkFsqDataTblDdlList = StaticDataLoader.getDataTblDdlBySeqNumDdlName(column.getColumnAlertProcTBL(), null, region);
				
				if (!checkFsqDataTblDdlList.isEmpty()){
					checkFsq = true;
				}
			}
		}

		return checkFsq;
	}
	
	/**
	 * Method to get list of alert rules concatenated in string.
	 * 
	 * @param connection
	 * @param failureList
	 * @return String
	 */

	protected String getAlertRules(Connection connection, List failureList){
		String alertRules = "";
		
		AlertRuleMainService alertRuleMainService = new AlertRuleMainService();
		List args = new ArrayList();
		List alertRulesList = alertRuleMainService.getalertRulesList(connection,failureList,args);
		
		int i;
		int alertRulesListSize = alertRulesList.size();
		for (i=0;i<alertRulesListSize;i++){
			alertRules = alertRules + "," + (String)alertRulesList.get(i);
		}
		
		return alertRules;
	}
	
	/**
	 * Method to build the list of mouse over options.
	 * 
	 * @param connection
	 * @param failureList
	 * @param alertRuleDefinition
	 */
	protected void buildMouseOverOptions(Connection connection, List failureList, AlertRuleDefinition alertRuleDefinition){
		List args = new ArrayList();
		List mouseOverList = new ArrayList();
		MouseOverTblDAO mouseOverTblDAO = new MouseOverTblDAO();
		mouseOverList = mouseOverTblDAO.get(connection,failureList,args,qryMouseOver);
		
		/*
		 * From the list of objects obtained build the mouseOverOptionsList 
		 */
		int mouseOverListSize= mouseOverList.size();
		for (int i=0;i<mouseOverListSize;i++){
			MouseOverTbl mouseOverTbl = (MouseOverTbl) mouseOverList.get(i);
			alertRuleDefinition.addMouseOverTableOption(new PickList(mouseOverTbl.getTableDesc(),mouseOverTbl.getTableName()+ "~" + mouseOverTbl.getTableKeyName() + "~" + mouseOverTbl.getTableKeyData()));

		}
	}
	
	/**
	 * Method to build the list of report link options.
	 * 
	 * @param connection
	 * @param failureList
	 * @param alertRuleDefinition
	 */
	protected void buildReportLinkOptions(Connection connection, List failureList, AlertRuleDefinition alertRuleDefinition){
		AdhocMainPageService adhocMainPageService = new AdhocMainPageService();
		List reportNameList = adhocMainPageService.getReportNameList(connection, failureList, new ArrayList());
		if (!reportNameList.isEmpty()){
			int reportNameListSize = reportNameList.size();
			for (int i=0;i<reportNameListSize;i++){
				PresnId presnId = (PresnId)reportNameList.get(i);
				PickList report = new PickList(Integer.toString(presnId.getPresnId()) + "~" + presnId.getPresnIdDesc(),presnId.getPresnIdDesc(),Integer.toString(presnId.getPresnId()));
				alertRuleDefinition.addReportLinkOption(report);
			}
		}
		
	}
	
	
	/**
	 * Method that will bring the report link for keys as well as mouse overs.
	 * 
	 * @param connection
	 * @param failureList
	 * @param alertRule
	 * @param alertRuleDefinition
	 * @return AlertRuleDefinition
	 */
	private AlertRuleDefinition getKeyRelatedAttributes(Connection connection, List failureList, AlertRule alertRule, AlertRuleDefinition alertRuleDefinition){
		List args = new ArrayList();
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		
		/*
		 * Build the arguments
		 */
		args.add(Integer.toString(alertRule.getPresnId()));
		
		/*
		 * Create temporary variables
		 */
		String key1DataLinkInd = null;
		String key1DataLinkNum = null;
		int key1MouseOverNum = 0;
		String key2DataLinkInd = null;
		String key2DataLinkNum = null;
		int key2MouseOverNum = 0;
		String key3DataLinkInd = null;
		String key3DataLinkNum = null;
		int key3MouseOverNum = 0;
		String key4DataLinkInd = null;
		String key4DataLinkNum = null;
		int key4MouseOverNum = 0;
		String key5DataLinkInd = null;
		String key5DataLinkNum = null;
		int key5MouseOverNum = 0;
		
		try {
			MessageFormat mf = new MessageFormat(qryAlertRuleKeyFlags);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("AlertRuleDefinitionService.getKeyRelatedAttributes() - Executing SQL statement: " + sqlStmt);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			
			if (rs.next()) {
				key1DataLinkInd = rs.getString("KEY1_DATA_LINK_IND");
				key1DataLinkNum = rs.getString("KEY1_DATA_LINK_NUM");
				key1MouseOverNum = rs.getInt("KEY1_MOUSE_OVER_NUM");
				key2DataLinkInd = rs.getString("KEY2_DATA_LINK_IND");
				key2DataLinkNum = rs.getString("KEY2_DATA_LINK_NUM");
				key2MouseOverNum = rs.getInt("KEY2_MOUSE_OVER_NUM");
				key3DataLinkInd = rs.getString("KEY3_DATA_LINK_IND");
				key3DataLinkNum = rs.getString("KEY3_DATA_LINK_NUM");
				key3MouseOverNum = rs.getInt("KEY3_MOUSE_OVER_NUM");
				key4DataLinkInd = rs.getString("KEY4_DATA_LINK_IND");
				key4DataLinkNum = rs.getString("KEY4_DATA_LINK_NUM");
				key4MouseOverNum = rs.getInt("KEY4_MOUSE_OVER_NUM");
				key5DataLinkInd = rs.getString("KEY5_DATA_LINK_IND");
				key5DataLinkNum = rs.getString("KEY5_DATA_LINK_NUM");
				key5MouseOverNum = rs.getInt("KEY5_MOUSE_OVER_NUM");
			}
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		
		/*
		 * Get the report links
		 */
		if ("Y".equals(key1DataLinkInd)&& key1DataLinkNum!=null && !"".equals(key1DataLinkNum)){
			List webDataLinkList = new ArrayList();
			List args1 = new ArrayList();
			
			args1.add(Integer.toString(alertRule.getPresnId()));
			args1.add(key1DataLinkNum);
			
			WebDataLinkDAO webDataLinkDAO = new WebDataLinkDAO();
			webDataLinkList = webDataLinkDAO.get(connection,failureList,args1,qryReportLink);
			
			if (!webDataLinkList.isEmpty()){
				WebDataLink webDataLink = (WebDataLink)webDataLinkList.get(0);
				alertRuleDefinition.setReportLinkKey1(webDataLink.getLinkPresnId() + "~" + webDataLink.getLinkDdlName());
			}
		}
		
		if ("Y".equals(key2DataLinkInd)&& key2DataLinkNum!=null && !"".equals(key2DataLinkNum)){
			List webDataLinkList = new ArrayList();
			List args1 = new ArrayList();
			
			args1.add(Integer.toString(alertRule.getPresnId()));
			args1.add(key2DataLinkNum);
			
			WebDataLinkDAO webDataLinkDAO = new WebDataLinkDAO();
			webDataLinkList = webDataLinkDAO.get(connection,failureList,args1,qryReportLink);
			
			if (!webDataLinkList.isEmpty()){
				WebDataLink webDataLink = (WebDataLink)webDataLinkList.get(0);
				alertRuleDefinition.setReportLinkKey2(webDataLink.getLinkPresnId() + "~" + webDataLink.getLinkDdlName());
			}
		}
		
		if ("Y".equals(key3DataLinkInd)&& key3DataLinkNum!=null && !"".equals(key3DataLinkNum)){
			List webDataLinkList = new ArrayList();
			List args1 = new ArrayList();
			
			args1.add(Integer.toString(alertRule.getPresnId()));
			args1.add(key3DataLinkNum);
			
			WebDataLinkDAO webDataLinkDAO = new WebDataLinkDAO();
			webDataLinkList = webDataLinkDAO.get(connection,failureList,args1,qryReportLink);
			
			if (!webDataLinkList.isEmpty()){
				WebDataLink webDataLink = (WebDataLink)webDataLinkList.get(0);
				alertRuleDefinition.setReportLinkKey3(webDataLink.getLinkPresnId() + "~" + webDataLink.getLinkDdlName());
			}
		}
		
		if ("Y".equals(key4DataLinkInd)&& key4DataLinkNum!=null && !"".equals(key4DataLinkNum)){
			List webDataLinkList = new ArrayList();
			List args1 = new ArrayList();
			
			args1.add(Integer.toString(alertRule.getPresnId()));
			args1.add(key4DataLinkNum);
			
			WebDataLinkDAO webDataLinkDAO = new WebDataLinkDAO();
			webDataLinkList = webDataLinkDAO.get(connection,failureList,args1,qryReportLink);
			
			if (!webDataLinkList.isEmpty()){
				WebDataLink webDataLink = (WebDataLink)webDataLinkList.get(0);
				alertRuleDefinition.setReportLinkKey4(webDataLink.getLinkPresnId() + "~" + webDataLink.getLinkDdlName());
			}
		}
		
		if ("Y".equals(key5DataLinkInd)&& key5DataLinkNum!=null && !"".equals(key5DataLinkNum)){
			List webDataLinkList = new ArrayList();
			List args1 = new ArrayList();
			
			args1.add(Integer.toString(alertRule.getPresnId()));
			args1.add(key5DataLinkNum);
			
			WebDataLinkDAO webDataLinkDAO = new WebDataLinkDAO();
			webDataLinkList = webDataLinkDAO.get(connection,failureList,args1,qryReportLink);
			
			if (!webDataLinkList.isEmpty()){
				WebDataLink webDataLink = (WebDataLink)webDataLinkList.get(0);
				alertRuleDefinition.setReportLinkKey5(webDataLink.getLinkPresnId() + "~" + webDataLink.getLinkDdlName());
			}
		}
		
		/*
		 * Get the mouse overs
		 */
		if (key1MouseOverNum>0){
			List mouseOverLinkList = new ArrayList();
			List args1 = new ArrayList();
			
			args1.add(Integer.toString(alertRule.getPresnId()));
			args1.add(Integer.toString(key1MouseOverNum));
			
			MouseOverLinkDAO mouseOverLinkDAO = new MouseOverLinkDAO();
			mouseOverLinkList = mouseOverLinkDAO.get(connection,failureList,args1,qryMouseOverLink);
			
			if (!mouseOverLinkList.isEmpty()){
				MouseOverLink mouseOverLink = (MouseOverLink)mouseOverLinkList.get(0);
				alertRuleDefinition.setMouseOverTableKey1(mouseOverLink.getLinkTblName()+ "~" + mouseOverLink.getLinkTblKeyName() + "~" + mouseOverLink.getLinkTblKeyData());
			}
		}
		
		if (key2MouseOverNum>0){
			List mouseOverLinkList = new ArrayList();
			List args1 = new ArrayList();
			
			args1.add(Integer.toString(alertRule.getPresnId()));
			args1.add(Integer.toString(key2MouseOverNum));
			
			MouseOverLinkDAO mouseOverLinkDAO = new MouseOverLinkDAO();
			mouseOverLinkList = mouseOverLinkDAO.get(connection,failureList,args1,qryMouseOverLink);
			
			if (!mouseOverLinkList.isEmpty()){
				MouseOverLink mouseOverLink = (MouseOverLink)mouseOverLinkList.get(0);
				alertRuleDefinition.setMouseOverTableKey2(mouseOverLink.getLinkTblName()+ "~" + mouseOverLink.getLinkTblKeyName() + "~" + mouseOverLink.getLinkTblKeyData());
			}
		}
		
		if (key3MouseOverNum>0){
			List mouseOverLinkList = new ArrayList();
			List args1 = new ArrayList();
			
			args1.add(Integer.toString(alertRule.getPresnId()));
			args1.add(Integer.toString(key3MouseOverNum));
			
			MouseOverLinkDAO mouseOverLinkDAO = new MouseOverLinkDAO();
			mouseOverLinkList = mouseOverLinkDAO.get(connection,failureList,args1,qryMouseOverLink);
			
			if (!mouseOverLinkList.isEmpty()){
				MouseOverLink mouseOverLink = (MouseOverLink)mouseOverLinkList.get(0);
				alertRuleDefinition.setMouseOverTableKey3(mouseOverLink.getLinkTblName()+ "~" + mouseOverLink.getLinkTblKeyName() + "~" + mouseOverLink.getLinkTblKeyData());
			}
		}
		
		if (key4MouseOverNum>0){
			List mouseOverLinkList = new ArrayList();
			List args1 = new ArrayList();
			
			args1.add(Integer.toString(alertRule.getPresnId()));
			args1.add(Integer.toString(key4MouseOverNum));
			
			MouseOverLinkDAO mouseOverLinkDAO = new MouseOverLinkDAO();
			mouseOverLinkList = mouseOverLinkDAO.get(connection,failureList,args1,qryMouseOverLink);
			
			if (!mouseOverLinkList.isEmpty()){
				MouseOverLink mouseOverLink = (MouseOverLink)mouseOverLinkList.get(0);
				alertRuleDefinition.setMouseOverTableKey4(mouseOverLink.getLinkTblName()+ "~" + mouseOverLink.getLinkTblKeyName() + "~" + mouseOverLink.getLinkTblKeyData());
			}
		}
		
		if (key5MouseOverNum>0){
			List mouseOverLinkList = new ArrayList();
			List args1 = new ArrayList();
			
			args1.add(Integer.toString(alertRule.getPresnId()));
			args1.add(Integer.toString(key5MouseOverNum));
			
			MouseOverLinkDAO mouseOverLinkDAO = new MouseOverLinkDAO();
			mouseOverLinkList = mouseOverLinkDAO.get(connection,failureList,args1,qryMouseOverLink);
			
			if (!mouseOverLinkList.isEmpty()){
				MouseOverLink mouseOverLink = (MouseOverLink)mouseOverLinkList.get(0);
				alertRuleDefinition.setMouseOverTableKey5(mouseOverLink.getLinkTblName()+ "~" + mouseOverLink.getLinkTblKeyName() + "~" + mouseOverLink.getLinkTblKeyData());
			}
		}
		
		return alertRuleDefinition;
	}
	
	/**
	 * Method to update the alert items from the values selected in drop downs on step2 of tracking rule.
	 * 
	 * @param alertRuleDefinition
	 * @return AlertRuleDefinition
	 */
	public AlertRuleDefinition updateAlertItems(AlertRuleDefinition alertRuleDefinition) {
	 	List newAlertItemList = new ArrayList();
	 	List newColumnList = null;
	 	int newAlertItemListSize = 0;
	 	int newColumnListSize = 0;
	 	
	 	List alertItemList = null;
	 	List columnList = null;
	 	int alertItemListSize = 0;
	 	int columnListSize = 0;
	 	
	 	String dropdownValue = null;
		int calIndex = 0;
	 	
	 	alertItemList = alertRuleDefinition.getAlertItemList();
	 	if (alertItemList != null) {
		 	alertItemListSize = alertItemList.size();
		 	for (int i=0; i<alertItemListSize; i++) {
		 		AlertItem alertItem = (AlertItem) alertItemList.get(i);
		 		newColumnList = new ArrayList();
		 		columnList = alertItem.getColumnList();
		 		if (columnList != null) {
			 		columnListSize = columnList.size();
			 		for (int j=0; j<columnListSize; j++) {
			 			Column column = (Column) columnList.get(j);
			 			dropdownValue = column.getDropdownValue();
			 			if (dropdownValue != null) {
			 				calIndex = dropdownValue.indexOf("~CAL");
			 				if (calIndex != -1) {
			 					column.setColumnTBLDDLName(dropdownValue.substring(0, calIndex));
			 					column.setColumnTBLDataType("CAL");
			 				} else {
			 					column.setColumnTBLDDLName(dropdownValue);
			 				}
			 			}
			 			newColumnList.add(column);
			 		}
			 		alertItem.getColumnList().clear();
			 		newColumnListSize = newColumnList.size();
			 		for (int j=0; j<newColumnListSize; j++) {
			 			Column column = (Column) newColumnList.get(j);
			 			alertItem.addColumn(column);
			 		}
			 		newAlertItemList.add(alertItem);
		 		}
		 	}
		 	
		 	alertRuleDefinition.getAlertItemList().clear();
		 	newAlertItemListSize = newAlertItemList.size();
		 	for (int i=0; i<newAlertItemListSize; i++) {
		 		AlertItem alertItem = (AlertItem) newAlertItemList.get(i);
		 		alertRuleDefinition.addAlertItem(alertItem);
		 	}
	 	}
	 	return alertRuleDefinition;
	 }
	
	/**
	 * Method checks whether there is any data in RABC_EXTRCT_SUMY_DATA for the given alert rule
	 * @param connection
	 * @param failures
	 * @param args
	 * @return
	 */
	private boolean checkMonthlyTimingUpdateAllowed(Connection connection, List failures, List args){
		String selectSQL = qryAllowMonthlyTimingUpdate;
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		long count = 0;

		try {
			MessageFormat mf = new MessageFormat(selectSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("AlertRuleDefinitionService.checkMonthlyTimingUpdateAllowed() - Executing SQL statement: "+ sqlStmt);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			
			if (rs.next()) {
				count = rs.getLong(1);
			}
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);	
		}
		
		if (count > 0){
			return true;
		}else {
			return false;
		}
	}	
	
	/**
	 * Method to set the std num date
	 * @param connection
	 * @param failures
	 * @param args
	 * @param alertRuleDefinition
	 */
	protected void setStdNumDate(Connection connection, List failures, List args, AlertRuleDefinition alertRuleDefinition){
		StdCalDAO stdCalDAO = new StdCalDAO();
		String selectSQL = qryGetStdNumDate;
		List stdCalcList = stdCalDAO.get(connection,failures,args,selectSQL);
		
		if (!stdCalcList.isEmpty()){
			int stdNumDate = ((StdCal)stdCalcList.get(0)).getStdNumDate();
			alertRuleDefinition.setStdNumDate(Integer.toString(stdNumDate));
		}	
	}
}
