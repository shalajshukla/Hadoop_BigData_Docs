/* Component Name: RABCPPG01236
 * Module Name: TrendTimeTO.java
 * Created on August 4, 2006
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.admin.alert.exempt;

import java.io.Serializable;

/**This is a transfer object class for the Alert Exempt process.  The purpose of this class is to 
 * contain trend time row data extracted from the AdminAlertExemptDAO.java class that is sent back 
 * to the AdminAlertExemptForm.java class via the AdminAlertExemptService.java class.
 * 
 * @author js3175
 */
public class TrendTimeTO implements Serializable {
	private static final long serialVersionUID = 0L;
	
	private String alertTrendTime = "";
	private String alertTrendTimeDesc = "";
	private String endEffectiveDate = "";
	private String userId = "";
	private String timeStamp = "";
	
	/**
	 * @return Returns the selectedAlertTrendTimes.
	 */
	public String getAlertTrendTime() {
		return alertTrendTime;
	}

	/**
	 * @param selectedAlertTrendTimes The selectedAlertTrendTimes to set.
	 */
	public void setAlertTrendTime(String alertTrendTime) {
		this.alertTrendTime = alertTrendTime;
	}
	
	/**
	 * @return Returns the alertTrendTimeDesc.
	 */
	public String getAlertTrendTimeDesc() {
		return alertTrendTimeDesc;
	}

	/**
	 * @param alertTrendTimeDesc The alertTrendTimeDesc to set.
	 */
	public void setAlertTrendTimeDesc(String alertTrendTimeDesc) {
		this.alertTrendTimeDesc = alertTrendTimeDesc;
	}

	/**
	 * @return Returns the endEffectiveDate.
	 */
	public String getEndEffectiveDate() {
		return endEffectiveDate;
	}

	/**
	 * @param endEffectiveDate The endEffectiveDate to set.
	 */
	public void setEndEffectiveDate(String effectiveDate) {
		this.endEffectiveDate = effectiveDate;
	}

	/**
	 * @return Returns the timeStamp.
	 */
	public String getTimeStamp() {
		return timeStamp;
	}

	/**
	 * @param timeStamp The timeStamp to set.
	 */
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

	/**
	 * @return Returns the userId.
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId The userId to set.
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
}
