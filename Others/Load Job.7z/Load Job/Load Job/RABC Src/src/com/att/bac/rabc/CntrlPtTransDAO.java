/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

/**
 * This is a DAO that performs SELECT, INSERT and UPDATE on RABC_CNTRL_PT_TRANS table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class CntrlPtTransDAO {
	private static final Logger logger = Logger.getLogger(CntrlPtTransDAO.class);

	/**
	 * Returns the list of CntrlPtTrans objects.
	 * 
	 * @param conn 
	 * @param failures
	 * @param args
	 * @param baseSQL
	 * @return List
	 */
	public List get(Connection conn, List failures, List args, String baseSQL) {
		List cntrlPtTransList = null;
		CntrlPtTrans cntrlPtTrans = null;
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		
		try
		{
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("CntrlPtTransDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			cntrlPtTransList = new ArrayList();
			while (rs.next()) {
				cntrlPtTransList.add(buildCntrlPtTrans(rs));
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return null;
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
		
		return cntrlPtTransList;
	}

	/**
	 * Private method to build CntrlPtTrans object and return it to caller.
	 * 
	 * @param rs
	 * @return CntrlPtTrans
	 * @throws SQLException
	 */
	private CntrlPtTrans buildCntrlPtTrans(ResultSet rs) throws SQLException {
		CntrlPtTrans cntrlPtTrans = new CntrlPtTrans();
		
		cntrlPtTrans.setCntrlPtCode(rs.getString("CNTRL_PT_CODE"));
		cntrlPtTrans.setCntrlPtDesc(rs.getString("CNTRL_PT_DESC"));
		cntrlPtTrans.setPresnSeqNum(rs.getInt("PRESN_SEQ_NUM"));
		return cntrlPtTrans;
	}

	/**
	 * Execute the insert or update statement on RABC_CNTRL_PT_TRANS table.
	 * 
	 * @param conn
	 * @param failures
	 * @param args
	 * @param baseSQL
	 */
	public void executeUpdate(Connection conn, List failures, List args, String baseSQL) {
		int rowsUpdated = 0;
		Statement stmt = null;
		String sqlStmt = null;
		
		try
		{
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("CntrlPtTransDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rowsUpdated = stmt.executeUpdate(sqlStmt);
			logger.debug("SQL - Execution complete."+ String.valueOf(rowsUpdated) + "  rows updated");
			
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return;
		} finally {
			SQLHelper.closeStatement(stmt, failures, logger);
		}
	}
}
