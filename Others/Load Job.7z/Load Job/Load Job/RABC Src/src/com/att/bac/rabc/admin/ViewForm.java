/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.admin;

import java.util.ArrayList;
import java.util.List;

import org.apache.struts.action.ActionForm;

import com.att.bac.rabc.Tree;
import com.att.bac.rabc.View;

/**
 * Module Description : 
 * Form bean for view definition component
 * 
 * * @author Umesh Deole - UD7153
 *
 */
public class ViewForm extends ActionForm{
	private String dispatch;
	private String selDataNode;
	private List dataSourceList;
	private String chkPrevious ; 
	private Tree tableTree = null;
	private String viewData ;
	private List viewList = null ; 
	private String actionType;
	private View view; 
	private String fromPage ;
	private boolean isDuplicate ;
	private boolean isDuplicatePreviousView ; 
	private boolean previousViewInsertSucc ; 
	private String columnNames;
	private String columnDataTypes;
	
	public ViewForm() {
		this.view = new View();
		this.dataSourceList = new ArrayList();
		this.viewList = new ArrayList();
		columnNames = "";
		columnDataTypes = "";
	}
	
	/**
	 * @return Returns the dispatch.
	 */
	public String getDispatch() {
		return dispatch;
	}
	/**
	 * @param dispatch The dispatch to set.
	 */
	public void setDispatch(String dispatch) {
		this.dispatch = dispatch;
	}
	/**
	 * @return Returns the tableTree.
	 */
	public Tree getTableTree() {
		return tableTree;
	}
	/**
	 * @param tableTree The tableTree to set.
	 */
	public void setTableTree(Tree tableTree) {
		this.tableTree = tableTree;
	}
	
	/**
	 * @return Returns the view.
	 */
	public View getView() {
		return view;
	}
	/**
	 * @param view The view to set.
	 */
	public void setView(View view) {
		this.view = view;
	}
	/**
	 * @return Returns the previousData.
	 */
	public String getChkPrevious() {
		return chkPrevious;
	}
	/**
	 * @param previousData The previousData to set.
	 */
	public void setChkPrevious(String chkPrevious) {
		this.chkPrevious = chkPrevious;
	}
	
	
	/**
	 * @return Returns the viewData.
	 */
	public String getViewData() {
		return viewData;
	}
	/**
	 * @param viewData The viewData to set.
	 */
	public void setViewData(String viewData) {
		this.viewData = viewData;
	}
	
	
	/**
	 * @return Returns the viewList.
	 */
	public List getViewList() {
		return viewList;
	}
	/**
	 * @param viewData to add.
	 */
	public void addViewData(String viewData) {
		this.viewList.add(viewData);
	}
	
	
	/**
	 * @return Returns the dataSourceList.
	 */
	public List getDataSourceList() {
		return dataSourceList;
	}
	/**
	 * @param dataSourceList The dataSourceList to set.
	 */
	public void setDataSourceList(List dataSourceList) {
		this.dataSourceList = dataSourceList;
	}
	/**
	 * @return Returns the selDataNode.
	 */
	public String getSelDataNode() {
		return selDataNode;
	}
	/**
	 * @param selDataNode The selDataNode to set.
	 */
	public void setSelDataNode(String selDataNode) {
		this.selDataNode = selDataNode;
	}
	
	
	/**
	 * @return Returns the actionType.
	 */
	public String getActionType() {
		return actionType;
	}
	/**
	 * @param actionType The actionType to set.
	 */
	public void setActionType(String actionType) {
		this.actionType = actionType;
	}
	/**
	 * @return Returns the fromPage.
	 */
	public String getFromPage() {
		return fromPage;
	}
	/**
	 * @param fromPage The fromPage to set.
	 */
	public void setFromPage(String fromPage) {
		this.fromPage = fromPage;
	}
	
	/**
	 * @return Returns the isDuplicate.
	 */
	public boolean isDuplicate() {
		return isDuplicate;
	}
	/**
	 * @param isDuplicate The isDuplicate to set.
	 */
	public void setDuplicate(boolean isDuplicate) {
		this.isDuplicate = isDuplicate;
	}
	/**
	 * @return Returns the isDuplicatePreviousView.
	 */
	public boolean isDuplicatePreviousView() {
		return isDuplicatePreviousView;
	}
	/**
	 * @param isDuplicatePreviousView The isDuplicatePreviousView to set.
	 */
	public void setDuplicatePreviousView(boolean isDuplicatePreviousView) {
		this.isDuplicatePreviousView = isDuplicatePreviousView;
	}
	/**
	 * @return Returns the previousViewInsertSucc.
	 */
	public boolean isPreviousViewInsertSucc() {
		return previousViewInsertSucc;
	}
	/**
	 * @param previousViewInsertSucc The previousViewInsertSucc to set.
	 */
	public void setPreviousViewInsertSucc(boolean previousViewInsertSucc) {
		this.previousViewInsertSucc = previousViewInsertSucc;
	}
	/**
	 * @return Returns the columnDataTypes.
	 */
	public String getColumnDataTypes() {
		return columnDataTypes;
	}
	/**
	 * @param columnDataTypes The columnDataTypes to set.
	 */
	public void setColumnDataTypes(String columnDataTypes) {
		this.columnDataTypes = columnDataTypes;
	}
	/**
	 * @return Returns the columnNames.
	 */
	public String getColumnNames() {
		return columnNames;
	}
	/**
	 * @param columnNames The columnNames to set.
	 */
	public void setColumnNames(String columnNames) {
		this.columnNames = columnNames;
	}
}
