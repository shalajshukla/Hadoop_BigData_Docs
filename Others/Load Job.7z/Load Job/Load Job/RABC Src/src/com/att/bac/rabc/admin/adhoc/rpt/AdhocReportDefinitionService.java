/* 
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.admin.adhoc.rpt;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;

import com.att.bac.rabc.DataTblDdlBean;
import com.att.bac.rabc.MouseOverLink;
import com.att.bac.rabc.MouseOverLinkDAO;
import com.att.bac.rabc.MouseOverTbl;
import com.att.bac.rabc.MouseOverTblDAO;
import com.att.bac.rabc.PickList;
import com.att.bac.rabc.PresnId;
import com.att.bac.rabc.PresnIdDAO;
import com.att.bac.rabc.ProgressBar;
import com.att.bac.rabc.RABCConstantsLists;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.StaticDataLoader;
import com.att.bac.rabc.View;
import com.att.bac.rabc.ViewDAO;
import com.att.bac.rabc.WebDataLink;
import com.att.bac.rabc.WebDataLinkDAO;
import com.att.bac.rabc.WebHeaderLinkDAO;
import com.att.bac.rabc.admin.AlertGroupFunctDAO;
import com.att.bac.rabc.admin.AlertGroupUser;
import com.att.bac.rabc.admin.AlertGroupUserDAO;
import com.att.bac.rabc.admin.MenuIndex;
import com.att.bac.rabc.admin.MenuIndexDAO;
import com.att.bac.rabc.admin.PresnCalcElem;
import com.att.bac.rabc.admin.PresnCalcElemDAO;
import com.att.bac.rabc.admin.PresnCalcElemRpt;
import com.att.bac.rabc.admin.PresnCalcElemRptDAO;
import com.att.bac.rabc.admin.PresnHeader;
import com.att.bac.rabc.admin.PresnHeaderDAO;
import com.att.bac.rabc.admin.PresnKey1Header;
import com.att.bac.rabc.admin.PresnKey1HeaderDAO;
import com.att.bac.rabc.admin.PresnKey2Header;
import com.att.bac.rabc.admin.PresnKey2HeaderDAO;
import com.att.bac.rabc.admin.UpdateGrp;
import com.att.bac.rabc.admin.UpdateGrpDAO;
import com.att.bac.rabc.alerts.AlertRulePresnElem;
import com.att.bac.rabc.alerts.AlertRulePresnElemDAO;
import com.att.bac.rabc.alerts.rpt.AlertRulePresenRule;
import com.att.bac.rabc.alerts.rpt.AlertRulePresenRuleDAO;

/**
 * Module Description : 
 * This is a service class to provide the business logic.
 * The methods in this class are called by the action class. 
 * They internaly calls the DAO classes to do the required manipulation and returns the result to the action class. 
 * This service class serves the business logic to populate the
 * adhoc report definition objects for step1, step2 and step3.
 * 
 * @author Umesh Deole - UD7153
 */
public class AdhocReportDefinitionService {
	private static final Logger logger = Logger.getLogger(AdhocMainPageService.class);
	private static AdhocReportDefinitionService AdhocReportDefinitionService;
	
	/*
	 * Variables to represent the sql statements.
	 */
	
	// for new report 
	protected static final String ALERT_GROUP_SELECT_1 = "SELECT DISTINCT (ALERT_GRP), UPPER(USER_ID) USER_ID " 
				+" FROM RABC_ALERT_GRP_USER "
				+" WHERE UPPER(USER_ID) = UPPER(''{0}'') ORDER BY UPPER(ALERT_GRP) ";
	
	// Get Presentation details for Step 1 
	protected static final String getRABCPresnId = "SELECT DISTINCT PRESN_ID,PRESN_ID_DESC,ASOC_FILE_ID,PRESN_TBL_NAME," 
				+"PROC_DATE_DDL_NAME,DIVISION_NAME_KEY_LVL,PRESN_ID_PRESN_IND,EXEC_PRESN_SEQ_NUM,BEG_SUB_TOT_LVL," 
				+"END_SUB_TOT_LVL,PRESN_MODEL,ADHOC_RPT_IND,ADHOC_RPT_STATUS,DB_NODE_ID,EFF_DT,PRESN_TREND_TIME," 
				+"PRESN_DUR_TIME,TIMING_FILTER_CODE"
				+" FROM RABC_PRESN_ID WHERE RABC_PRESN_ID.PRESN_ID = {1} and upper(ADHOC_RPT_STATUS) = ''ACTIVE'' ORDER BY EXEC_PRESN_SEQ_NUM ";
	
	protected static final String getAlertGroupList = "SELECT ALERT_GRP,ALERT_GRP_DESC,FUNCT_CD,PNT_ALERT_GRP_IND " 
				+"FROM RABC_ALERT_GRP WHERE PNT_ALERT_GRP_IND <> '1' ORDER BY UPPER(ALERT_GRP) " ; 
	
	protected static final String getAlertGrpSelected = "SELECT ALERT_RULE,ALERT_GRP,PRESN_ID FROM RABC_UPDATE_GRP " 
				+"WHERE PRESN_ID = {1} " ;
	
	// Get header1,header2,header3 for Step 1    
	protected static final String getRABCPresnHeader = "SELECT PRESN_ID,WEBID,HEADER1, HEADER2, HEADER3,PRESN_DATE_IND " 
				+"FROM RABC_PRESN_HEADER WHERE RABC_PRESN_HEADER.PRESN_ID = {1} AND WEBID = ''RABCPSF00013'' " ;
	
	/*
	 * CAN WE INSTEAD OF QUERYING USE THE SIZE OF THE LIST RETURNED BY getRABCPresnId QUERY ??
	 */
	protected static final String nbrRptSections = "SELECT COUNT(EXEC_PRESN_SEQ_NUM) NumberofReportSections " 
				+"FROM RABC_PRESN_ID where RABC_PRESN_ID.PRESN_ID = {1} AND ADHOC_RPT_STATUS = ''Active'' " 
				+"AND EXEC_PRESN_SEQ_NUM IS NOT NULL" ;

	//query to get the data for adhoc report definition step 2 
	protected static final String getColumnVars = "SELECT PRESN_ID,WEBID,EXEC_PRESN_SEQ_NUM,PRESN_SEQ_NUM,PRESN_NAME"
				+",DATA_TBL,PARTI_REF_ID,DATA_DDL_NAME,HEADER_LINK_IND,HEADER_LINK_NUM"
				+",HEADER_DESC_IND,HEADER_MOUSE_OVER_NUM,DATA_LINK_IND,DATA_LINK_NUM"
				+",DATA_DESC_IND,DATA_MOUSE_OVER_NUM,GRAPH_PRESN_IND,PRESN_ELEM_TOT_IND"
				+",PRESN_UNIT_IND,PRESN_SUM_IND,DATABASE_NODE,PRESN_CALC_NUM,PRESN_SUPPRESS_IND"
				+",PREV_DATA_IND,VIEW_NAME,PRESN_ORD_IND,PRESN_FORMAT_CODE,DIFF_DATA_IND"
				+" FROM rabc_alert_rule_presn_elem where presn_id= {1} "
				+ " AND WEBID = ''RABCPSF00013'' AND EXEC_PRESN_SEQ_NUM = {2} "
				+ " ORDER BY PRESN_SEQ_NUM ";

	protected static final String getCalc = "SELECT PRESN_CALC_NAME,PRESN_CALC_NUM,CALC_ELEM_FORMULA,CALC_ELEM_USER_VIEW"
				+",CALC_DIV_IND,CALC_ELEM_DISPLAY,CALC_DISPLAY_ELEM,PRESN_FORMAT_CODE,CALC_TBL,CALC_ELEM_SQL_FORMULA FROM RABC_PRESN_CALC_ELEM "
				+" WHERE PRESN_CALC_NUM=''{0}''";
	
	protected static final String qryCalcName = "SELECT  PRESN_ID,WEBID,EXEC_PRESN_SEQ_NUM,PRESN_CALC_NAME"
				+",PRESN_CALC_NUM,CALC_ELEM_FORMULA,CALC_ELEM_USER_VIEW"
				+",CALC_DIV_IND,CALC_ELEM_DISPLAY,PRESN_FORMAT_CODE "
				+" FROM    rabc_presn_calc_elem_rpt "
				+ " WHERE   presn_id = {1} AND    webid = ''RABCPSF00013'' "
				+ " AND exec_presn_seq_num = {2} AND  presn_calc_num = ''{3}'' ";
	
	protected static final String MOUSE_OVER_LINK = "SELECT PRESN_ID,WEBID,EXEC_PRESN_SEQ_NUM,MOUSE_OVER_NUM"
				+",LINK_TBL_KEY_NAME,LINK_TBL_KEY_DATA,LINK_TBL_NAME FROM RABC_MOUSE_OVER_LINK " 
				+ " WHERE PRESN_ID = {1} AND WEBID = ''RABCPSF00013'' "
				+ " AND EXEC_PRESN_SEQ_NUM = {2} "	;
	
	protected static final String GetWebDataLink = "SELECT PRESN_ID,WEBID,EXEC_PRESN_SEQ_NUM,LINK_NUM"
				+",LINK_DDL_NAME,LINK_TO_PGM,LINK_PRESN_ID"
				+",LINK_NUM_PARM,LINK_PARM1,LINK_PARM2"
				+",LINK_PARM3,LINK_PARM4,LINK_PARM5,LINK_PARM6"
				+",LINK_PARM7,LINK_PARM8,LINK_PARM9"
				+",LINK_PARM10,LINK_PARM11,LINK_PARM12 FROM RABC_WEB_DATA_LINK "
				+" WHERE  PRESN_ID = {1}"
				+" AND WEBID = ''RABCPSF00013''"
				+" AND EXEC_PRESN_SEQ_NUM = {2} "; 

	protected static final String qryMouseOver="SELECT TABLE_NAME,TABLE_DESC,TABLE_KEY_DATA,TABLE_KEY_NAME"
				+" FROM   rabc_mouse_over_tbl ORDER BY table_desc"; 
	
	protected static final String getKeyVars="SELECT ALERT_DATA_LINK_IND,ALERT_DATA_LINK_NUM,ALERT_PARM_IND,ALERT_DESC_IND"
				+",ALERT_MOUSE_OVER_NUM,PRESN_ID,WEBID,EXEC_PRESN_SEQ_NUM,FILE_SEQ_NUM_IND"
				+",PRESN_DATA_TBL,DATA_KEY_LVL,KEY1_DDL_NAME,MAIN_KEY1_IND,KEY1_HEADER,KEY1_HD_LINK_IND"
				+",KEY1_HD_LINK_NUM,KEY1_HD_PARM_IND,KEY1_DATA_LINK_IND,KEY1_DATA_LINK_NUM,KEY1_PARM_IND"
				+",KEY1_DESC_IND,KEY1_MOUSE_OVER_NUM,KEY2_DDL_NAME,KEY2_HEADER,KEY2_HD_LINK_IND"
				+",KEY2_HD_LINK_NUM,KEY2_HD_PARM_IND,KEY2_DATA_LINK_IND,KEY2_DATA_LINK_NUM"
				+",KEY2_PARM_IND,KEY2_DESC_IND,KEY2_MOUSE_OVER_NUM,KEY3_DDL_NAME,KEY3_HEADER"
				+",KEY3_HD_LINK_IND,KEY3_HD_LINK_NUM,KEY3_HD_PARM_IND,KEY3_DATA_LINK_IND,KEY3_DATA_LINK_NUM"
				+",KEY3_PARM_IND,KEY3_DESC_IND,KEY3_MOUSE_OVER_NUM,KEY4_DDL_NAME,KEY4_HEADER,KEY4_HD_LINK_IND"
				+",KEY4_HD_LINK_NUM,KEY4_HD_PARM_IND,KEY4_DATA_LINK_IND,KEY4_DATA_LINK_NUM,KEY4_PARM_IND"
				+",KEY4_DESC_IND,KEY4_MOUSE_OVER_NUM,KEY5_DDL_NAME,KEY5_HEADER,KEY5_HD_LINK_IND"
				+",KEY5_HD_LINK_NUM,KEY5_HD_PARM_IND,KEY5_DATA_LINK_IND,KEY5_DATA_LINK_NUM,KEY5_PARM_IND"
				+",KEY5_DESC_IND,KEY5_MOUSE_OVER_NUM,ALERT_DATA_NAME,ALERT_HD_NAME,ALERT_HD_LINK_IND"
				+",ALERT_HD_LINK_NUM,ALERT_HD_PARM_IND FROM rabc_alert_rule_presn_rule "
				+" WHERE  presn_id = {1}"
				+" AND WEBID = ''RABCPSF00013''"
				+" AND EXEC_PRESN_SEQ_NUM = {2}";
	
	protected static final String getRabcPresnKey1Header = "SELECT PRESN_ID,WEBID,EXEC_PRESN_SEQ_NUM,KEY1_VALUE,MAIN_KEY1_LINE_HEADER"
				+" FROM rabc_presn_key1_header "
				+"	WHERE PRESN_ID = {1} " 
				+" AND EXEC_PRESN_SEQ_NUM = {2} "
				+"	AND WEBID = ''RABCPSF00013''";
	
	protected static final String getRabcPresnKey2Header = "SELECT PRESN_ID,WEBID,EXEC_PRESN_SEQ_NUM,KEY2_VALUE,MAIN_KEY2_LINE_HEADER"
				+" FROM rabc_presn_key2_header "
				+"	WHERE PRESN_ID = {1} " 
				+" AND EXEC_PRESN_SEQ_NUM = {2} "
				+"	AND WEBID = ''RABCPSF00013''";

	protected static final String getRabcPresnIdKeyvars = "SELECT  PRESN_ID,PRESN_ID_DESC,ASOC_FILE_ID,PRESN_TBL_NAME"
				+",PROC_DATE_DDL_NAME,DIVISION_NAME_KEY_LVL,PRESN_ID_PRESN_IND"
				+",EXEC_PRESN_SEQ_NUM,BEG_SUB_TOT_LVL,END_SUB_TOT_LVL,PRESN_MODEL"
				+",ADHOC_RPT_IND,ADHOC_RPT_STATUS,DB_NODE_ID,EFF_DT,PRESN_TREND_TIME"
				+",PRESN_DUR_TIME,TIMING_FILTER_CODE FROM RABC_PRESN_ID "
				+" WHERE 	PRESN_ID = {1}" 
				+" AND EXEC_PRESN_SEQ_NUM ={2}";
	
	private static final String getPresenId = "SELECT DISTINCT(PRESN_ID) FROM RABC_PRESN_ID	ORDER BY PRESN_ID ASC";  
	
	private static final String delHeader = "DELETE FROM  RABC_PRESN_HEADER"
				+" WHERE  presn_id = {0}"
				+" AND    webid = ''RABCPSF00013''";
	
	private static final String insHeader = "INSERT INTO RABC_PRESN_HEADER(PRESN_ID,WEBID,HEADER1,HEADER2,HEADER3) "
				+ " VALUES(''{0}'',''RABCPSF00013'',''{1}'',''{2}'',''{3}'')";
	
	private static final String delWebHeaderLink="DELETE FROM RABC_WEB_HEADER_LINK "
				+" WHERE   presn_id ={0} " 
				+" AND    webid = ''RABCPSF00013''";
	
	private static final String insWebHeaderLink1 = "INSERT INTO RABC_WEB_HEADER_LINK " 
				+" (PRESN_ID,WEBID,SEQ_NUM,LINK_PRESN_NAME,LINK_TO_PGM,LINK_PRESN_ID) "
				+" VALUES({0},''RABCPSF00013'',1,''View Report'',''AdhocRpt.do'',{0}) ";
	
	private static final String insWebHeaderLink2="INSERT INTO RABC_WEB_HEADER_LINK "
				+" (PRESN_ID,WEBID,SEQ_NUM,LINK_PRESN_NAME,LINK_TO_PGM,LINK_PRESN_ID)"
				+"	VALUES({0},''RABCPSF00013'',2,''Previous Data'',''AdhocRpt.do'',{0})";

	private static final String insWebHeaderLink3="INSERT INTO RABC_WEB_HEADER_LINK"
				+"(PRESN_ID,WEBID,SEQ_NUM,LINK_PRESN_NAME,LINK_TO_PGM,LINK_PRESN_ID)"
				+" VALUES({0},''RABCPSF00013'',3,''Next Data'',''AdhocRpt.do'',{0})";
	
	private static final String insWebHeaderLink4 = "INSERT INTO RABC_WEB_HEADER_LINK"
				+"(PRESN_ID,WEBID,SEQ_NUM,LINK_PRESN_NAME,LINK_TO_PGM,LINK_PRESN_ID)"
				+"VALUES({0},''RABCPSF00013'',{1},''Create Report'',''AdhocRpt.do'',{0})";
	
	private static final String insWebHeaderLink5 = "INSERT INTO RABC_WEB_HEADER_LINK " 
				+" (PRESN_ID,WEBID,SEQ_NUM,LINK_PRESN_NAME,LINK_TO_PGM,LINK_PRESN_ID)"
				+" VALUES({0},''RABCPSF00013'',{1},''Email Report'',''AdhocRpt.do'',{0})";
	
	private static final String delMenuIndexID = "DELETE FROM RABC_MENU_INDEX"
				+" WHERE PRESN_ID = {0}"; 
	
	//Changed following query to have SUB_ASSOC_PARENT_ID passed as an attribute now.
	private static final String insMenu="INSERT INTO RABC_MENU_INDEX"
				+"(PRESN_TYPE,PRESN_NAME,PRESN_LVL,PRESN_SEQ_NUM,ASSOC_PARENT_ID,SUB_ASSOC_PARENT_ID,PRESN_ID)"
				+"VALUES(''P'',''{1}'',3,0,{2},{3},{0})";
	
	// for new directory creation 
	private static final String insMenuUserDirectory="INSERT INTO RABC_MENU_INDEX"
		+"(PRESN_TYPE,PRESN_NAME,PRESN_LVL,PRESN_SEQ_NUM,ASSOC_PARENT_ID,SUB_ASSOC_PARENT_ID)"
		+"VALUES(''P'',''{0}'',2,{1},4,0)";
	
	// to check which user directories are empty , if yes then delete these directories from RABC_MENU_INDEX
	private static final String selEmptyUserDir = "SELECT PRESN_SEQ_NUM " +
			" FROM rabc_menu_index WHERE presn_lvl = 2 AND presn_seq_num > 2 " +
			" AND assoc_parent_id = 4 AND presn_id IS NULL AND alert_rule IS NULL " +
			" AND presn_seq_num NOT IN ( SELECT DISTINCT sub_assoc_parent_id FROM rabc_menu_index WHERE sub_assoc_parent_id " +
			" IN (SELECT presn_seq_num FROM rabc_menu_index WHERE presn_lvl = 2 AND presn_seq_num > 2 AND assoc_parent_id = 4 AND presn_id IS NULL AND alert_rule IS NULL )" +
			" AND presn_id IN (SELECT presn_id FROM rabc_presn_id WHERE UPPER (adhoc_rpt_status) = ''ACTIVE'')) " ; 	
	
	private static final String delMenuIndexDIR = "DELETE FROM RABC_MENU_INDEX "
		+" WHERE presn_lvl = 2 and PRESN_SEQ_NUM in ( {0} ) and assoc_parent_id = 4 and presn_id is null and alert_rule is null " 
		+" and presn_seq_num NOT IN ( SELECT DISTINCT sub_assoc_parent_id FROM rabc_menu_index WHERE sub_assoc_parent_id " 
		+" IN (SELECT presn_seq_num FROM rabc_menu_index WHERE presn_lvl = 2 AND presn_seq_num > 2 AND assoc_parent_id = 4 AND presn_id IS NULL AND alert_rule IS NULL )" 
		+" AND presn_id IN (SELECT presn_id FROM rabc_presn_id WHERE UPPER (adhoc_rpt_status) = ''ACTIVE'')) " ;  
	
	private static final String delAlertGrps="DELETE FROM RABC_UPDATE_GRP"
				+" WHERE PRESN_ID = {0}";
	
	private static final String insUpdgrp = "INSERT INTO RABC_Update_GRP"
				+" (ALERT_GRP,PRESN_ID)"
				+"VALUES(''{1}'',{0})"; 
	
	private static final String delKey1Header="DELETE FROM  RABC_PRESN_KEY1_HEADER "
				+" WHERE presn_id ={0} "
				+"	AND webid = ''RABCPSF00013''"
				+" AND exec_presn_seq_num ={1}";
	
	private static final String insKey1Header="INSERT INTO RABC_PRESN_KEY1_HEADER"
				+"(PRESN_ID,WEBID,EXEC_PRESN_SEQ_NUM,KEY1_VALUE,MAIN_KEY1_LINE_HEADER)"
				+"VALUES ({0},''RABCPSF00013'',{1},NULL,''{2}'')";
	
	private static final String delKey2Header="DELETE FROM  RABC_PRESN_KEY2_HEADER "
				+" WHERE presn_id ={0} "
				+"	AND webid = ''RABCPSF00013''"
				+" AND exec_presn_seq_num ={1}";

	private static final String insKey2Header="INSERT INTO RABC_PRESN_KEY2_HEADER"
				+"(PRESN_ID,WEBID,EXEC_PRESN_SEQ_NUM,KEY2_VALUE,MAIN_KEY2_LINE_HEADER)"
				+"VALUES ({0},''RABCPSF00013'',{1},NULL,''{2}'')";
	
	private static final String delAdhocReportPresnId = "DELETE FROM RABC_PRESN_ID WHERE Presn_id={0} AND exec_PRESN_SEQ_NUM={1}";
	
	private static final String insAdhocReportPresnId="INSERT INTO  RABC_PRESN_ID(Presn_id,exec_PRESN_SEQ_NUM,Presn_id_desc,ADHOC_RPT_STATUS"
				+",EFF_Dt,PRESN_TREND_TIME,DB_NODE_ID,BEG_SUB_TOT_LVL,END_SUB_TOT_LVL,ADHOC_RPT_IND,PRESN_DUR_TIME,PRESN_MODEL,TIMING_FILTER_CODE,PRESN_TBL_NAME,PROC_DATE_DDL_NAME,DIVISION_NAME_KEY_LVL)"
				+"VALUES({0},''{1}'',''{2}'',''Pending''"
				+",sysdate,''{3}'',''{4}'',{5},{6},''Y'',''{7}'',''{8}'',''{9}'',''{10}'',''{11}'',''{12}'')";
	
	private static final String saveAdhocReport = "UPDATE RABC_PRESN_ID SET ADHOC_RPT_STATUS=''Active''"
				+" WHERE  Presn_id=''{0}'' and upper(ADHOC_RPT_STATUS) = ''PENDING'' ";
	
	private static final String delAlertRulePresnElem = "DELETE FROM rabc_alert_rule_presn_elem WHERE Presn_id={0} AND exec_PRESN_SEQ_NUM={1}";
	
	private static final String insAlertRulePresnElem ="INSERT INTO RABC_ALERT_RULE_PRESN_ELEM "					
				+"(Presn_id,WEBID,EXEC_PRESN_SEQ_NUM,PRESN_SEQ_NUM,VIEW_NAME,DATA_TBL,DATA_DDL_NAME,PRESN_NAME"
				+",PRESN_CALC_NUM,GRAPH_PRESN_IND,PRESN_ORD_IND,PRESN_SUPPRESS_IND,PREV_DATA_IND,DATA_DESC_IND,DATA_MOUSE_OVER_NUM,DATA_LINK_IND"
				+",DATA_LINK_NUM,PRESN_UNIT_IND,PRESN_FORMAT_CODE,PRESN_SUM_IND,PARTI_REF_ID,DIFF_DATA_IND) "
				+" VALUES({0},''RABCPSF00013'',''{1}'',''{2}'',''{3}'',''{4}'',''{5}'',''{6}''"
				+",''{7}'',''{8}'',''{9}'',''{10}'',''{11}'',''{12}'',''{13}''"
				+",''{14}'',''{15}'',''{16}'',''{17}'',''{18}'',''{19}'',''{20}'')";
	
	private static final String delAlertRulePresnRule = "DELETE RABC_ALERT_RULE_PRESN_RULE WHERE Presn_ID = {0} AND EXEC_PRESN_SEQ_NUM = {1} "
				+" AND 	WEBID=''RABCPSF00013''";
	
	private static final String  insAlertRulePresnRule = "INSERT INTO RABC_Alert_Rule_PRESN_RULE " 
				+"(Presn_ID,WEBID,EXEC_PRESN_SEQ_NUM,file_seq_num_ind"
				+",presn_data_tbl,data_key_lvl,key1_DDL_Name,key1_header"
				+",Key1_desc_IND,Key1_Mouse_Over_num,Key2_DDL_NAME,Key2_Header" 
				+",Key2_DESC_IND,Key2_Mouse_Over_num,Key3_DDL_NAME,Key3_Header,Key3_DESC_IND"
				+",Key3_Mouse_Over_num,Key4_DDL_NAME,Key4_Header,Key4_DESC_IND,Key4_Mouse_Over_num"
				+",Key5_DDL_NAME,Key5_Header,Key5_DESC_IND,Key5_Mouse_Over_num"
				+",key1_data_link_ind,key1_data_link_num,key2_data_link_ind,key2_data_link_num"
				+",key3_data_link_ind,key3_data_link_num,key4_data_link_ind,key4_data_link_num"
				+",key5_data_link_ind,key5_data_link_num)"
				+"VALUES({0},''RABCPSF00013'',{1},''{2}''" 
				+",''{3}'',{4},''{5}'',''{6}''"
				+",''{7}'',''{8}'',''{9}'',''{10}''"
				+",''{11}'',''{12}'',''{13}'',''{14}'',''{15}''" 
				+",''{16}'',''{17}'',''{18}'',''{19}'',''{20}''"
				+",''{21}'',''{22}'',''{23}'',''{24}''"
				+",''{25}'',''{26}'',''{27}'',''{28}''"
				+",''{29}'',''{30}'',''{31}'',''{32}''"
				+",''{33}'',''{34}'')";
	
	private static String delMoLink = "DELETE FROM  RABC_MOUSE_OVER_LINK	WHERE   presn_id = {0}"
				+"	AND webid = ''RABCPSF00013'' "						
				+" AND exec_presn_seq_num = {1}";
	
	private static String insMouseOver = "INSERT INTO  RABC_Mouse_Over_Link(PRESN_ID,WEBID,EXEC_PRESN_SEQ_NUM,MOUSE_OVER_NUM,Link_TBL_KEY_NAME,Link_TBL_KEY_DATA,Link_TBL_NAME)"
				+"VALUES({0},''RABCPSF00013'',{1},{2},''{3}'',''{4}'',''{5}'')";
	
	//get max mouse over num
	private static String selMaxMon="SELECT MAX(mouse_over_num) MON	FROM RABC_Mouse_Over_Link" 
				+" WHERE Presn_ID = {0}	AND EXEC_PRESN_SEQ_NUM = {1} AND WEBID=''RABCPSF00013''";
	
	private static String delDataLinkNum = "DELETE	FROM rabc_web_data_link"
				+" WHERE presn_id = {0}	AND   webid = ''RABCPSF00013''	AND   exec_presn_seq_num = {1}";
	
	private static String selMaxwebDataLink="SELECT MAX(link_num) link_num	FROM RABC_WEB_DATA_LINK" 
		+" WHERE Presn_ID = {0}	AND EXEC_PRESN_SEQ_NUM = {1} AND WEBID=''RABCPSF00013''";
	
	private static String insWebDataLink="INSERT INTO RABC_WEB_Data_Link " 
				+"(Presn_id,WEBID,exec_PRESN_SEQ_NUM,Link_Num" 
				+",Link_DDL_Name,Link_to_PGM,Link_Presn_Id)"
				+" VALUES({0},''RABCPSF00013'',{1},{2}"
				+",''{3}'',''AdhocRpt.do'',{4})"; 

	private static String chkViewName="SELECT * FROM rabc_view	WHERE view_name = ''{0}''";
	
	private static String delCalculation = "DELETE FROM  rabc_presn_calc_elem_rpt"
				+" WHERE  presn_id = {0}"
				+"	AND webid = ''RABCPSF00013''"
				+" AND  exec_presn_seq_num ={1}";

	private static String insCalulation = "INSERT INTO  rabc_presn_calc_elem_rpt"
						+"(presn_id,webid,exec_presn_seq_num,presn_calc_name"
						+",presn_calc_num,calc_elem_formula,calc_elem_user_view" 
						+",calc_div_ind,calc_elem_display,presn_format_code)"
						+" VALUES " 
						+"({0},''RABCPSF00013'',''{1}'',''{2}''" 
						+",''{3}'',''{4}'',''{5}''"
						+",''{6}'',''{7}'',''{8}'')";
	
	protected static final String delReport = "UPDATE RABC_PRESN_ID SET Adhoc_RPT_STATUS = ''Delete''"
		+" WHERE Presn_ID = {0} AND  exec_presn_seq_num = {1}";
	
	private static final String alertGrpUser="SELECT ALERT_GRP,USER_ID FROM 	RABC_ALERT_GRP_USER WHERE UPPER(USER_ID)=UPPER(''{0}'')";
	
	private static final String alertGrpFunct = "SELECT	ALERT_GRP,FUNCT_CD FROM	RABC_ALERT_GRP_FUNCT WHERE FUNCT_CD=''{1}'' AND UPPER(ALERT_GRP)=UPPER(''{2}'')";
	
	private static final String updateAdhocReport = "UPDATE RABC_PRESN_ID SET PRESN_MODEL=''{1}'' "
													+ "WHERE PRESN_ID=''{0}'' ";
	
	/*
	 * To get the current section number 
	 */
	protected static final String getActiveSectionNumbers = "SELECT EXEC_PRESN_SEQ_NUM " 
		+"FROM RABC_PRESN_ID where RABC_PRESN_ID.PRESN_ID = {1} AND ADHOC_RPT_STATUS = ''Active'' " 
		+"AND EXEC_PRESN_SEQ_NUM IS NOT NULL ORDER BY EXEC_PRESN_SEQ_NUM " ;

	//to populate user directory list 
	protected static final String getUserDirectory = "SELECT PRESN_TYPE,PRESN_NAME,PRESN_LVL,PRESN_SEQ_NUM,ASSOC_PARENT_ID,SUB_ASSOC_PARENT_ID,PRESN_ID,ALERT_RULE FROM RABC_MENU_INDEX " 
				+" WHERE PRESN_SEQ_NUM > 2 AND presn_lvl = 2 AND alert_rule IS NULL AND assoc_Parent_id = 4 " 
				+" AND sub_assoc_parent_id = 0 order by presn_name " ;
	
	//to get selected user directory name  
	protected static final String getUserDirectorySelected = " SELECT PRESN_TYPE,PRESN_NAME,PRESN_LVL,PRESN_SEQ_NUM,ASSOC_PARENT_ID,SUB_ASSOC_PARENT_ID,PRESN_ID,ALERT_RULE FROM rabc_menu_index WHERE presn_type = ''P'' AND presn_lvl = 2 AND " 
		+ " presn_seq_num = (SELECT sub_assoc_parent_id FROM rabc_menu_index WHERE presn_type = ''P''" 
		+ " AND presn_lvl = 3 AND presn_id = {1} AND assoc_parent_id = 4 AND alert_rule IS NULL) " 
		+ " AND assoc_parent_id = 4 AND sub_assoc_parent_id = 0 AND presn_seq_num > 2 AND alert_rule IS NULL " ;   

	// to get maximum presn seq number + 1 , used for new directory creation  
	protected static final String getPresnSeqNumber	= " SELECT MAX (presn_seq_num) + 1 FROM RABC_MENU_INDEX " 
	+" WHERE presn_lvl = 2 AND alert_rule IS NULL AND assoc_Parent_id = 4 AND sub_assoc_parent_id = 0 " ;
	
	// to get current presn seq number, used when user creates new directory and that report will be saved under same direcory i.e. newly created 
	protected static final String getCurrentPresnSeqNumber	= " SELECT presn_seq_num FROM RABC_MENU_INDEX " 
		+" WHERE presn_lvl = 2 AND alert_rule IS NULL AND assoc_Parent_id = 4 AND sub_assoc_parent_id = 0 and presn_name = ''{0}''" ;
	

	/**
	 * Synchronized method to return the instance of AdhocReportDefinitionService object.
	 * It checks the existance of the instance of AdhocReportDefinitionService and if it does not exists
	 * then creates one instance of AdhocReportDefinitionService and returns otherwise it returns the
	 * existing instance of AdhocReportDefinitionService.
	 * 
	 * @return AdhocReportDefinitionService
	 */
	public static synchronized AdhocReportDefinitionService getAdhocReportDefinitionService(){
		if (AdhocReportDefinitionService == null){
			AdhocReportDefinitionService = new AdhocReportDefinitionService();
		}	
		return AdhocReportDefinitionService;
	}
	
	/**
	 * This method is used to get the details of adhoc report for step1
	 * @param connection
	 * @param failures
	 * @param args
	 * @return List
	 */
	public List getPresenDetails(Connection connection, List failures, List args) {
		List presnIdList ;
		PresnIdDAO presnIdDAO = new PresnIdDAO();
		presnIdList = presnIdDAO.get(connection,failures,args,getRABCPresnId);
        return presnIdList;
    }
	
	/**
	 * This method is used to get the report type list on step1 - daily , monthly,bill day, yearly
	 * @return ArrayList
	 */
	public ArrayList getReportTypeList(String region) {
	 	ArrayList list = new ArrayList();
	 	list=RABCConstantsLists.getRABCConstantsLists().getAdhocReportTimingList(region);
        return list;
    }
	
	/** 
	 * This method is used to get the heading1,heading2,heading3 for step1
	 * @param connection
	 * @param failures
	 * @param args
	 * @return List
	 */
	public List getRABCPresnHeaderList (Connection connection, List failures, List args) {
		PresnHeaderDAO presnHeaderDAO = new PresnHeaderDAO();
		String selectSQL = getRABCPresnHeader;
		List presnHeaderList ;
		presnHeaderList = presnHeaderDAO.get(connection,failures,args,selectSQL);
        return presnHeaderList;
		
	}

	/**
	 * This method is used to get the list of columns for the table in adhoc Report definition step3 
	 * @param connection
	 * @param failureList
	 * @param tableName
	 * @param region
	 * @return
	 */
	public List getColumnList (Connection connection, List failureList, String tableName, String region) {
		ArrayList list = new ArrayList();
		List args = new ArrayList();
		//check if it is a view , get the corresponding table name
		List viewList = returnViewList(connection, failureList, tableName);
		if (viewList.size()>0){
			View view = (View) viewList.get(0);
			tableName = view.getTableName();
		}
		args.add(tableName);
		List dataTblDdlBeanList = StaticDataLoader.getDataTblDdlByAlertProcTbl(tableName, region);
		int dataTblDdlBeanListSize =dataTblDdlBeanList.size(); 
		for (int j=0;j<dataTblDdlBeanListSize;j++)
		{
			DataTblDdlBean dataTblDdlBean  =(DataTblDdlBean) dataTblDdlBeanList.get(j);
			if (!("1".equals(dataTblDdlBean.getTblDdlDataType()))){
				list.add(new PickList(dataTblDdlBean.getTblDdlName(),dataTblDdlBean.getTblDdlName()));
			}	
		}
        return list;
	}

	/**
	 * This method is used to get the list of views corresponding to the tableViewString argument
	 * @param connection
	 * @param failureList
	 * @param tableViewString
	 * @return List
	 */
	private List returnViewList(Connection connection, List failureList, String  tableViewString){
		
		ViewDAO viewDAO = new ViewDAO();
		List arguments = new ArrayList();
		List viewList = new ArrayList();
		arguments.add(tableViewString);
		viewList = viewDAO.get(connection,failureList,arguments,chkViewName);
		return (viewList);
	}
	
	/**
	 * This method is used in step3 for alert key level drop down - values are 1-5
	 * 
	 * @return ArrayList
	 */
	public ArrayList getAlertKeyLevelList() {
	 	ArrayList list = new ArrayList();
	 	list=RABCConstantsLists.getRABCConstantsLists().getKeyLevelList();
        return list;
    }
	
	/**
	 * This method is used in step3 for report duration drop down. 
	 * 
	 * @return ArrayList
	 */
	public ArrayList getReportDurationList() {
	 	ArrayList list = new ArrayList();
	 	list=RABCConstantsLists.getRABCConstantsLists().getAdhocReportDurationTimingList();
        return list;
    }

	/**
	 * This method is used in step3 for layout types. 
	 * 
	 * @return ArrayList
	 */
	public ArrayList getLayoutTypeList() {
	 	ArrayList list = new ArrayList();
	 	list=RABCConstantsLists.getRABCConstantsLists().getLayoutTypeList();
        return list;
    }
	
	/**
	 * This method is used in step1 to get the selecetd alert group. 
	 * @param connection
	 * @param failures
	 * @param args
	 * @return String[]
	 */
	public String[] getAlertGroupSelected(Connection connection, List failures, List args) {
		UpdateGrpDAO updateGrpDAO = new UpdateGrpDAO();
		
		List alertGroupSelected ;
		alertGroupSelected = updateGrpDAO.get(connection,failures,args,getAlertGrpSelected);
		String alertGrp[] = new String[alertGroupSelected.size()];
		for (int i = 0 ; i<alertGrp.length;i++) {
			alertGrp[i] = ((UpdateGrp) alertGroupSelected.get(i)).getAlertGrp() ;
		}
		return alertGrp;
	}
	
	/**
	 * This method is used to get the list of all alert groups for the dropdown in step1 . 
	 * @param connection
	 * @param failures
	 * @param args
	 * @return List
	 */
	public List getAlertGroupList(Connection connection, List failures, List args) {
        
        AlertGroupUserDAO alertGroupUserDAO = new AlertGroupUserDAO();
		List alertGroup ;
		alertGroup = alertGroupUserDAO.get(connection,failures,args,ALERT_GROUP_SELECT_1);
        return alertGroup;
    }
	
	/**
	 * This method is used to get number of report sections for an adhoc report. 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return int
	 */
	public int getNbrRptSections(Connection connection, List failureList, List args) {
		String selectSQL = nbrRptSections ;
		int nbrOfRptSections = 1 ;
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		List presnIdList = new ArrayList();
		PresnId presnId = null ;
		try
		{
			MessageFormat mf = new MessageFormat(selectSQL);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			if (rs != null && rs.next()){
				nbrOfRptSections = rs.getInt(1);
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
			return 1;
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		return nbrOfRptSections ; 
    }
	
	/**
	 * This method is used to get the sort list drop down in step 2 - values are "ASC","DESC". 
	 * 
	 * @return List
	 */
	public List getSortList() {
		ArrayList list = new ArrayList();
	 	list=RABCConstantsLists.getRABCConstantsLists().getAdhocSortList();
        return list;
    }
	
	/**
	 * This method is used to get unit list drop down for step 2 . values are "%","$" etc. 
	 * 
	 * @return List
	 */
	public List getUnitList() {
		ArrayList list = new ArrayList();
	 	list=RABCConstantsLists.getRABCConstantsLists().getAdhocUnitList();
        return list;
    }
	
	/**
	 * This method is used to get mouse over list for step2 as well as step3. 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return List
	 */
	public List getMouseOverList (Connection connection, List failureList, List args) {
		ArrayList list = new ArrayList();
		String selectSQL = qryMouseOver;
		List mouseOverList = new ArrayList();
		MouseOverTblDAO mouseOverTblDAO = new MouseOverTblDAO();
		mouseOverList = mouseOverTblDAO.get(connection,failureList,args,qryMouseOver);
		String tableName=null;
		String tableDesc=null;
		String tableKeyName=null;
		String tableKeyData=null;
		int mouseOverListSize= mouseOverList.size();
		for (int i=0;i<mouseOverListSize;i++)
		{
			MouseOverTbl mouseOverTbl = (MouseOverTbl)mouseOverList.get(i);
			tableName=mouseOverTbl.getTableName();
			tableDesc=mouseOverTbl.getTableDesc();
			tableKeyName = mouseOverTbl.getTableKeyName();
			tableKeyData = mouseOverTbl.getTableKeyData();
			list.add(new PickList(tableDesc,tableName+"~"+tableKeyName+"~"+tableKeyData));
		}
        return list;
	}
	
	/**
	 * This method is used to get distinct datasource list for step 1. 
	 * @param region
	 * @return List
	 */
	public List getDataSourceList(String region) {
		List dbNodeList = StaticDataLoader.getDBNodeList(region);
		List distinctDbNodeList = new ArrayList();
		
		int dbNodeListSize = dbNodeList.size();
		
		for (int i=0;i<dbNodeListSize;i++){
			PickList dbNode = (PickList)dbNodeList.get(i);
			boolean addFlag = true;
			
			int distinctDbNodeListSize = 0;
			if (!distinctDbNodeList.isEmpty()){
				distinctDbNodeListSize = distinctDbNodeList.size();
			}
			for (int j=0;j<distinctDbNodeListSize;j++){
				PickList existingDbNode = (PickList)distinctDbNodeList.get(j);
				
				if (dbNode.getKey().equals(existingDbNode.getKey())){
					addFlag = false;
				}
			}
			if (addFlag==true){
				distinctDbNodeList.add(dbNode);
			}
		}
		return distinctDbNodeList;
    }
	
	/**
	 * This method is used to get the name of user directory for selected adhoc report in step1 . 
	 * @param connection
	 * @param failures
	 * @param args
	 * @return List
	 */
	public List getuserDirectorySelected(Connection connection, List failures, List args) {
		MenuIndexDAO menuIndexDAO = new MenuIndexDAO() ;
		List userDirectorySelectedList ;
		userDirectorySelectedList = menuIndexDAO.get(connection,failures,args,getUserDirectorySelected);
		return userDirectorySelectedList;
    }
	
	/**
	 * This method is used to get the list of all user directories  for the dropdown in step1 . 
	 * @param connection
	 * @param failures
	 * @param args
	 * @return List
	 */
	public List getuserDirectoryList(Connection connection, List failures, List args) {
        
		MenuIndexDAO menuIndexDAO = new MenuIndexDAO() ;
		List userDirectoryList ;
		userDirectoryList = menuIndexDAO.get(connection,failures,args,getUserDirectory);
        return userDirectoryList;
    }
	/**
	 * This method is used to get key1header for step3 . 
	 * @param connection
	 * @param failures
	 * @param args
	 * @return List
	 */
	public List getRabcPresnKey1Header (Connection connection, List failures, List args) {
		PresnKey1HeaderDAO presnKey1HeaderDAO = new PresnKey1HeaderDAO();
		List presnKey1HeaderList ;
		presnKey1HeaderList =  presnKey1HeaderDAO.get(connection, failures, args,getRabcPresnKey1Header);
		return presnKey1HeaderList;
	}
	
	/**
	 * This method is used to get key2header for step3 . 
	 * @param connection
	 * @param failures
	 * @param args
	 * @return List
	 */
	public List getRabcPresnKey2Header (Connection connection, List failures, List args) {
		PresnKey2HeaderDAO presnKey2HeaderDAO = new PresnKey2HeaderDAO();
		List presnKey2HeaderList ;
		presnKey2HeaderList =  presnKey2HeaderDAO.get(connection, failures, args, getRabcPresnKey2Header);
		return presnKey2HeaderList;
	}
	
	/**
	 * This method is used to get adhocReport definition with all the dropdown and default values 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param progressBar
	 * @param region
	 * @return AdhocReportDefinition
	 */
	public AdhocReportDefinition getAdhocReportDefinition(Connection connection, List failureList, List args, ProgressBar progressBar, String region){
		AdhocReportDefinition adhocReportDefinition = new AdhocReportDefinition();
		createAdhocReportDefinitionObject(adhocReportDefinition,connection,failureList,args,progressBar,region) ;
		return adhocReportDefinition;
	}

	/** 
	 * Private method to construct adHocReportDefination object in step 1 
	 * @param adhocReportDefinition
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param progressBar
	 * @param region
	 */
	private void createAdhocReportDefinitionObject(AdhocReportDefinition adhocReportDefinition,Connection connection, List failureList, List args, ProgressBar progressBar, String region)
	{
		
		int presnSeqNum ; // to get presn_seq_number for selected user directory
		String userDirectoryName = "" ; // to get user directory name stored in DB
		
		/*
		 * Using the DAO(s) to get the Presentation ID & header related details
		 */
		List presnIdList =  getPresenDetails(connection,failureList,args) ;
		progressBar.setProgressPercent(40);
		PresnId presnId = (PresnId)presnIdList.get(0);
		adhocReportDefinition.setPresnId(presnId.getPresnId());
		adhocReportDefinition.setPresnDesc(presnId.getPresnIdDesc());
		
		if (presnId.getPresnTrendTime() == null ) { // If presnTrendTime is null , it means report type is record 
			adhocReportDefinition.setRptType("S") ;
		} else {
			adhocReportDefinition.setRptType(presnId.getPresnTrendTime()) ;
		}

		adhocReportDefinition.setDataNode(presnId.getDbNodeId()) ;
		adhocReportDefinition.setDataSourceList(getDataSourceList(region));
		
		
		List userDirectorySelectedList = getuserDirectorySelected(connection, failureList, args) ;
		if ((!userDirectorySelectedList.isEmpty())  && userDirectorySelectedList.size() > 0 ) {
			MenuIndex menuIndex = (MenuIndex)userDirectorySelectedList.get(0);
			presnSeqNum = menuIndex.getPresnSeqNum();
			adhocReportDefinition.setUserDirectorySelected(Integer.toString(presnSeqNum));
			adhocReportDefinition.setUserDirRadioOption("useExisting") ;
			userDirectoryName = menuIndex.getPresnName() ; 
		} else {
			if ("".equals(adhocReportDefinition.getUserDirNameText())) {
				adhocReportDefinition.setUserDirRadioOption("useNew") ;
			}else {
				adhocReportDefinition.setUserDirRadioOption("useDefault") ;
			}
			
		}
		
		if (!"".equals(userDirectoryName)){
			adhocReportDefinition.setUserDirectoryHidden(userDirectoryName) ;
		}
		
		List userDirectoryList = getuserDirectoryList(connection, failureList, args) ;
		adhocReportDefinition.setUserDirectoryList(userDirectoryList);
				
		adhocReportDefinition.setReportTypeList(getReportTypeList(region));
		adhocReportDefinition.setSortList(getSortList());
		adhocReportDefinition.setUnitList(getUnitList());
		AdhocMainPageService adhocService = new AdhocMainPageService();
		// Get the existing adhoc reports and store them in arraylist
		List result = adhocService.getReportNameList(connection,failureList,args) ;
		adhocReportDefinition.setReportLinkList(result);
		adhocReportDefinition.setMouseOverList(getMouseOverList(connection,failureList,args));
		progressBar.setProgressPercent(50);
		
		// for selected group return type string array
		adhocReportDefinition.setAlertGroup(getAlertGroupSelected(connection,failureList,args)) ;
		// for all alert group return type list 
		adhocReportDefinition.setAlertGroupList(getAlertGroupList(connection,failureList,args)) ;
		adhocReportDefinition.setNbrRptSections(getNbrRptSections(connection,failureList,args)) ;
		progressBar.setProgressPercent(60);
		
		/*
		 * Use the RABC_PRESN_HEADER table to get the header related values for the adhoc report definition
		 */
		List presnHeaderList =  getRABCPresnHeaderList(connection,failureList,args) ;
		adhocReportDefinition.setHeader1(((PresnHeader)presnHeaderList.get(0)).getHeader1()) ;
		adhocReportDefinition.setHeader2(((PresnHeader)presnHeaderList.get(0)).getHeader2()) ;
		adhocReportDefinition.setHeader3(((PresnHeader)presnHeaderList.get(0)).getHeader3()) ;
		
		int nbrRptSections = adhocReportDefinition.getNbrRptSections();
		
		String activeSectionStr = getActiveSectionStr(connection,adhocReportDefinition,failureList,args);
		adhocReportDefinition.setActiveSectionStr(activeSectionStr);
		progressBar.setProgressPercent(70);
		
		String tempSectionStr="";
		String[] sectionArr ; 
		List sectionList = new ArrayList() ;
		for (int i=0;i<nbrRptSections;i++){
			// Create Step 2 & 3 objects
			AdhocReportStep2 adhocReportStep2 = new AdhocReportStep2();
			AdhocReportStep3 adhocReportStep3 = new AdhocReportStep3();
			args.remove(2); // index of current section in the args is 2
			if (activeSectionStr.equals("")){				
				args.add(2,Integer.toString(i+1));
				tempSectionStr = tempSectionStr+Integer.toString(i+1)+"~";
			}else{
				 sectionArr = activeSectionStr.split("~");
				adhocReportDefinition.setCurrentSection(i+1);
				args.add(2,sectionArr[i]);	
			}
			sectionList.add(new PickList(Integer.toString(i+1),Integer.toString(i+1))) ;
			// Build the step 2 and step3 objects 
			buildAdhocStep2(adhocReportDefinition,connection,failureList,args);
			buildAdhocStep3(adhocReportDefinition,connection,failureList,args,region);
		}
		progressBar.setProgressPercent(80);
		adhocReportDefinition.setSectionList(sectionList) ;
		if (adhocReportDefinition.getActiveSectionStr().equals("")){
			adhocReportDefinition.setActiveSectionStr(tempSectionStr);
		}
		//set the current section back to 1 so that the section starts from 1
		adhocReportDefinition.setCurrentSection(1);
		progressBar.setProgressPercent(90);
	}
	
	/** This method is used to create the adhoc report step 2 details and add to adhocReportDefintion object 
	 * @param adhocReportDefinition
	 * @param connection
	 * @param failureList
	 * @param args
	 */
	public void buildAdhocStep2(AdhocReportDefinition adhocReportDefinition,Connection connection, List failureList, List args ){
		
		AdhocReportStep2 adhocReportStep2 = new AdhocReportStep2();
		adhocReportStep2= getAdhocReportStep2(adhocReportDefinition,connection,failureList,args );
		
		if (failureList.isEmpty()){
			adhocReportDefinition.addAdhocReportStep2List(adhocReportStep2);
		}	
	}

	/**
	 * This method is used to create the column value string for step2 .
	 * @param adhocReportDefinition
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return AdhocReportStep2
	 */
	public AdhocReportStep2 getAdhocReportStep2(AdhocReportDefinition adhocReportDefinition, Connection connection, List failureList, List args){
		AdhocReportStep2 adhocReportStep2 = new AdhocReportStep2();
		try{
			List arguments = new ArrayList();
			List alertRulePresnElemList;
	
			String columnString = null;
			String tempColumnString = null;
			
			alertRulePresnElemList=getAlertRulePresnElemList(connection,failureList,args);
	
			HashMap mouseOverLinkMap = getMouseOverLinkMap(connection, failureList, args);
			MouseOverLink mouseOverLink = new MouseOverLink();
			
			HashMap webDataLinkMap = getWebDataLinkMap(connection, failureList, args);
			
			WebDataLink webDataLink = new WebDataLink();
			
			int alertRulePresnElemListSize = alertRulePresnElemList.size();
			
			//Start looping
			for (int i=0;i<alertRulePresnElemListSize;i++)	{
				AlertRulePresnElem alertRulePresnElem = (AlertRulePresnElem)alertRulePresnElemList.get(i);
				String tName =null;
				String dcn = null;
				String dataTbl=null;
				String dataDdlName=null;
				String tableText=null;
				String tableValue=null;
				String presnName=null;
				String calc = null;
				int calcId;
				String graph=null;
				String presnOrdInd=null;
				String supress=null;
				String dataDesc=null;
				int mouseOverNum;
				String mouseOver=null;
				String  dataLinkInd=null;
				String dataLinkNum;
				String presnUnitInd=null;
				String presnSumInd=null;
				String presnFormatCode=null;
				String delete=null;
				String previousData=null;
				String differenceData=null;
			
				tName = alertRulePresnElem.getViewName();
				dataTbl = alertRulePresnElem.getDataTbl();
				dataDdlName = alertRulePresnElem.getDataDdlName();
				dcn = alertRulePresnElem.getDataDdlName();
				tableText = tName+"."+dcn;
				tableValue = dataTbl+"."+dataDdlName;
				presnName = alertRulePresnElem.getPresnName();
				calcId = alertRulePresnElem.getPresnCalcNum();
				
				if (calcId>0){
					List calcFormulaArgs = new ArrayList();
					calcFormulaArgs.add(Integer.toString(calcId));
					calc = getCalcFormula(connection,calcFormulaArgs,calcFormulaArgs);
					List presnCalcNameArgs = new ArrayList(args);
					System.out.println(presnCalcNameArgs);
					//List presnCalcNameArgs = new ArrayList();
					//presnCalcNameArgs = args;
					presnCalcNameArgs.add(Integer.toString(calcId));
					//args.add(Integer.toString(calcId));
					String presnCalcName = getPresnCalcElemRpt(connection,failureList,presnCalcNameArgs);
					tableText = presnCalcName;
					tableValue = presnCalcName;
				} else {
					calc = "false";
				}
				
				if (!("false".equals(calc))){
					tName ="null";
					dataTbl = "null";
					dcn = "null";
					dataDdlName = "null";
				}
				
				if (alertRulePresnElem.getGraphPresnInd()==null){
					graph="false";
				}else if ("Y".equals(alertRulePresnElem.getGraphPresnInd().trim())){ 
					graph = "true";
				}	
				else{
					graph="false";
				}
				
				presnOrdInd = alertRulePresnElem.getPresnOrdInd();
				if (presnOrdInd==null){
					presnOrdInd="";
				}
				
				if (alertRulePresnElem.getPresnSuppressInd()==null){
					supress = "false";	
					delete="true";
				}else if ("Y".equals(alertRulePresnElem.getPresnSuppressInd().trim())) {
					supress = "true";
					delete="false";
				}
				else {
					supress = "false";	
					delete="true";
				}
				
				dataDesc = alertRulePresnElem.getDataDescInd();
				if (dataDesc==null){
					dataDesc="";
				}
				
				mouseOverNum = alertRulePresnElem.getDataMouseOverNum();
				mouseOverLink = (MouseOverLink) mouseOverLinkMap.get(new Integer(mouseOverNum));
				if (mouseOverLink==null){
					mouseOver ="null";
				}else{
					mouseOver =mouseOverLink.getLinkTblName()+"~"+mouseOverLink.getLinkTblKeyName()+"~"+mouseOverLink.getLinkTblKeyData();
				}
				
				if (alertRulePresnElem.getDataLinkInd()==null){
					
				}else if ("Y".equals(alertRulePresnElem.getDataLinkInd().trim())){ 
					dataLinkInd = "true";
				}	
				else{
					dataLinkInd="false";
				}			
			
				if (webDataLinkMap.size()>0){
					webDataLink = (WebDataLink) webDataLinkMap.get(Integer.toString(alertRulePresnElem.getDataLinkNum()));
					if (webDataLink!=null){
						dataLinkNum =Integer.toString(webDataLink.getLinkPresnId());
					}else{
						dataLinkNum ="null";
					}
				}else{
					dataLinkNum ="null";
				}
				presnUnitInd = alertRulePresnElem.getPresnUnitInd();
				
				presnSumInd = alertRulePresnElem.getPresnSumInd();
				
				presnFormatCode = alertRulePresnElem.getPresnFormatCode();
				
				if (alertRulePresnElem.getPrevDataInd()==null){
					previousData="false";
				}else if ("Y".equals(alertRulePresnElem.getPrevDataInd().trim())){ 
					previousData="true";
				}	
				else{
					previousData="false";
				}

				if (alertRulePresnElem.getDiffDataInd()==null){
					differenceData="false";
				}else if ("Y".equalsIgnoreCase(alertRulePresnElem.getDiffDataInd().trim())){ 
					differenceData="true";
				}	
				else{
					differenceData="false";
				}
			
				tempColumnString = tName+":"+dataTbl+":"+dcn+":"+dataDdlName+":"+tableText+":"
							+tableValue+":"+presnName+":"+calc+":"+calcId+":"+graph+":"+presnOrdInd+":"+supress+":"
							+previousData+":"+dataDesc+":"+mouseOver+":"+dataLinkInd+":"+dataLinkNum+":"+presnUnitInd+":"
							+presnSumInd+":"+presnFormatCode+":"+delete+":"+differenceData;
					
				if (columnString == null) {
					columnString=tempColumnString;
				}
				else {
					columnString = columnString+";"+tempColumnString;
				}
				
			}//End loop
			
			// Strucsture of column string will be as follows 
			//columnString="RABC_ACCT_BLG_DTL:RABC_ACCT_BLG_DTL:ACCT_900_CALL_CHRG:ACCT_900_CALL_CHRG:RABC_ACCT_BLG_DTL.ACCT_900_CALL_CHRG:RABC_ACCT_BLG_DTL.ACCT_900_CALL_CHRG:ACCT_900_CALL_CHRG:false: :false:null:false:null:null:null:null:null:null:2:true";
			
			adhocReportStep2.setData(columnString);
		} catch(Exception e){
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		}
		return adhocReportStep2;
	}
	
	/** 
	 * This method is used to get the calculation name 
	 * @param connection
	 * @param failures
	 * @param args
	 * @return String
	 */
	public String getPresnCalcElemRpt(Connection connection, List failures, List args) {
		PresnCalcElemRptDAO presnCalcElemRptDAO = new PresnCalcElemRptDAO();
		List presnCalcElemRptList = presnCalcElemRptDAO.get(connection,failures,args,qryCalcName);
		String calcName="";
		int  presnCalcElemRptListSize = presnCalcElemRptList.size();
		
		for (int i=0;i<presnCalcElemRptListSize;i++){
			
			PresnCalcElemRpt presnCalcElemRpt = (PresnCalcElemRpt) presnCalcElemRptList.get(i);
			calcName = presnCalcElemRpt.getPresnCalcName();
		}
		return (calcName);
    }

	/**
	 * This method is used to create adhoc report step3 objects and assign to the adhocReportDefinition object
	 * @param adhocReportDefinition
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param region
	 */
	public void buildAdhocStep3(AdhocReportDefinition adhocReportDefinition,Connection connection, List failureList, List args, String region){
		AdhocReportStep3 adhocReportStep3;
		adhocReportStep3= getAdhocReportStep3(adhocReportDefinition,connection,failureList,args,region);
		if (failureList.isEmpty()){
			adhocReportDefinition.addAdhocReportStep3List(adhocReportStep3);
		}
	}
	
	/**
	 * This method is used to build the adhoc report step 3 object. 
	 * @param adhocReportDefinition
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param region
	 * @return AdhocReportStep3
	 */
	public AdhocReportStep3 getAdhocReportStep3(AdhocReportDefinition adhocReportDefinition, Connection connection, List failureList, List args, String region){
		AdhocReportStep3 adhocReportStep3 = new AdhocReportStep3();
		
		AlertRulePresenRuleDAO alertRulePresenRuleDAO = new AlertRulePresenRuleDAO();
		List alertRulePresenRuleList = alertRulePresenRuleDAO.get(connection, failureList, args,getKeyVars);
		
		PresnIdDAO  presnIdDAO = new PresnIdDAO();
		List presnIdList = presnIdDAO.get(connection, failureList, args,getRabcPresnIdKeyvars);
		
		adhocReportStep3.setAlertKeyLevelList(getAlertKeyLevelList());
		adhocReportStep3.setMouseOverList(getMouseOverList(connection, failureList, args));
		adhocReportStep3.setReportDurationList(getReportDurationList());
		AdhocMainPageService adhocMainPageService = new AdhocMainPageService(); 
		List result = adhocMainPageService.getReportNameList(connection,failureList,args) ;
		adhocReportStep3.setReportLinkList(result);
	
		if (alertRulePresenRuleList.size()>0)
		{
			AlertRulePresenRule alertRulePresenRule = (AlertRulePresenRule)alertRulePresenRuleList.get(0);
			adhocReportStep3.setLevel1ColumnHeaderName(alertRulePresenRule.getKeyHeaderAt(0));
			adhocReportStep3.setLevel2ColumnHeaderName(alertRulePresenRule.getKeyHeaderAt(1));
			adhocReportStep3.setLevel3ColumnHeaderName(alertRulePresenRule.getKeyHeaderAt(2));
			adhocReportStep3.setLevel4ColumnHeaderName(alertRulePresenRule.getKeyHeaderAt(3));
			adhocReportStep3.setLevel5ColumnHeaderName(alertRulePresenRule.getKeyHeaderAt(4));
			
			adhocReportStep3.setAlertKeyLevel(alertRulePresenRule.getDataKeyLvl());
			
			HashMap mouseOverLinkMap = getMouseOverLinkMap(connection, failureList, args);
			
			MouseOverLink mouseOverLink = new MouseOverLink();
			
			if (alertRulePresenRule.getKeyMouseOverNumAt(0) != 0 ){
				mouseOverLink = (MouseOverLink) mouseOverLinkMap.get(new Integer(alertRulePresenRule.getKeyMouseOverNumAt(0)));
				adhocReportStep3.setLevel1MouseOverDescription(mouseOverLink.getLinkTblName()+"~"+mouseOverLink.getLinkTblKeyName()+"~"+mouseOverLink.getLinkTblKeyData());
			}else {
				adhocReportStep3.setLevel1MouseOverDescription("");
			}
			
			if (alertRulePresenRule.getKeyMouseOverNumAt(1) != 0 ){
				mouseOverLink = (MouseOverLink) mouseOverLinkMap.get(new Integer(alertRulePresenRule.getKeyMouseOverNumAt(1)));
				adhocReportStep3.setLevel2MouseOverDescription(mouseOverLink.getLinkTblName()+"~"+mouseOverLink.getLinkTblKeyName()+"~"+mouseOverLink.getLinkTblKeyData());
			}else {
				adhocReportStep3.setLevel2MouseOverDescription("");
			}
			
			if (alertRulePresenRule.getKeyMouseOverNumAt(2) != 0 ){
				mouseOverLink = (MouseOverLink) mouseOverLinkMap.get(new Integer(alertRulePresenRule.getKeyMouseOverNumAt(2)));
				adhocReportStep3.setLevel3MouseOverDescription(mouseOverLink.getLinkTblName()+"~"+mouseOverLink.getLinkTblKeyName()+"~"+mouseOverLink.getLinkTblKeyData());
			}else {
				adhocReportStep3.setLevel3MouseOverDescription("");
			}
			
			if (alertRulePresenRule.getKeyMouseOverNumAt(3) != 0 ){
				mouseOverLink = (MouseOverLink) mouseOverLinkMap.get(new Integer(alertRulePresenRule.getKeyMouseOverNumAt(3)));
				adhocReportStep3.setLevel4MouseOverDescription(mouseOverLink.getLinkTblName()+"~"+mouseOverLink.getLinkTblKeyName()+"~"+mouseOverLink.getLinkTblKeyData());
			}else {
				adhocReportStep3.setLevel4MouseOverDescription("");
			}
			
			if (alertRulePresenRule.getKeyMouseOverNumAt(4) != 0 ){
				mouseOverLink = (MouseOverLink) mouseOverLinkMap.get(new Integer(alertRulePresenRule.getKeyMouseOverNumAt(4)));
				adhocReportStep3.setLevel5MouseOverDescription(mouseOverLink.getLinkTblName()+"~"+mouseOverLink.getLinkTblKeyName()+"~"+mouseOverLink.getLinkTblKeyData());
			}else {
				adhocReportStep3.setLevel5MouseOverDescription("");
			}
			
			List webDataLinkMapArgs = new ArrayList();
			//add a blank argument , because , the query arguments start with {1}
			webDataLinkMapArgs.add("");
			webDataLinkMapArgs.add(Integer.toString(adhocReportDefinition.getPresnId()));
			webDataLinkMapArgs.add(Integer.toString(adhocReportDefinition.getCurrentSection()));
			
			HashMap webDataLinkMapReportLink = getWebDataLinkMap(connection, failureList, webDataLinkMapArgs);
			
			WebDataLink webDataLink = new WebDataLink();
			
			if (alertRulePresenRule.getKeyDataLinkNumAt(0)!=0){
				webDataLink = (WebDataLink) webDataLinkMapReportLink.get(Integer.toString(alertRulePresenRule.getKeyDataLinkNumAt(0)));
				adhocReportStep3.setLevel1ReportLink(Integer.toString(webDataLink.getLinkPresnId()));
			}else {
				adhocReportStep3.setLevel1ReportLink("");
			}
			
			if (alertRulePresenRule.getKeyDataLinkNumAt(1)!=0){
				webDataLink = (WebDataLink) webDataLinkMapReportLink.get(Integer.toString(alertRulePresenRule.getKeyDataLinkNumAt(1)));
				adhocReportStep3.setLevel2ReportLink(Integer.toString(webDataLink.getLinkPresnId()));
			}else {
				adhocReportStep3.setLevel2ReportLink("");
			}
			
			if (alertRulePresenRule.getKeyDataLinkNumAt(2)!=0){
				webDataLink = (WebDataLink) webDataLinkMapReportLink.get(Integer.toString(alertRulePresenRule.getKeyDataLinkNumAt(2)));
				adhocReportStep3.setLevel3ReportLink(Integer.toString(webDataLink.getLinkPresnId()));
			}else {
				adhocReportStep3.setLevel3ReportLink("");
			}
			
			if (alertRulePresenRule.getKeyDataLinkNumAt(3)!=0){
				webDataLink = (WebDataLink) webDataLinkMapReportLink.get(Integer.toString(alertRulePresenRule.getKeyDataLinkNumAt(3)));
				adhocReportStep3.setLevel4ReportLink(Integer.toString(webDataLink.getLinkPresnId()));
			}else {
				adhocReportStep3.setLevel4ReportLink("");
			}
			
			if (alertRulePresenRule.getKeyDataLinkNumAt(4)!=0){
				webDataLink = (WebDataLink) webDataLinkMapReportLink.get(Integer.toString(alertRulePresenRule.getKeyDataLinkNumAt(4)));
				adhocReportStep3.setLevel5ReportLink(Integer.toString(webDataLink.getLinkPresnId()));
			}else {
				adhocReportStep3.setLevel5ReportLink("");
			}
			
			if ("Y".equals(alertRulePresenRule.getFileSeqNumInd())){
				adhocReportStep3.setFileSequenceIndicator("Y");
			}else{
				adhocReportStep3.setFileSequenceIndicator("N");
			}
		}
		
		int alertKeyLevel = adhocReportStep3.getAlertKeyLevel();
		
		if (alertKeyLevel > 1) {
			List presnKey2HeaderList = getRabcPresnKey2Header(connection, failureList, args);
			
			PresnKey2Header presnKey2Header = new PresnKey2Header() ; 
			if (presnKey2HeaderList.size() > 0) {
				presnKey2Header = (PresnKey2Header) presnKey2HeaderList.get(0);
				adhocReportStep3.setKey1HeaderDesc(presnKey2Header.getMainKey2LineHeader());
			} else {
				adhocReportStep3.setKey1HeaderDesc("");
			}
		} else {
			List presnKey1HeaderList = getRabcPresnKey1Header(connection, failureList, args);
			
			PresnKey1Header presnKey1Header = new PresnKey1Header() ; 
			if (presnKey1HeaderList.size() > 0) {
				presnKey1Header = (PresnKey1Header) presnKey1HeaderList.get(0);
				adhocReportStep3.setKey1HeaderDesc(presnKey1Header.getMainKey1LineHeader());
			} else {
				adhocReportStep3.setKey1HeaderDesc("");
			}
		}
		
		if (presnIdList.size()>0)
		{
			PresnId presnId = (PresnId)presnIdList.get(0);
			adhocReportStep3.setReportDurationTime(presnId.getPresnDurTime());
			adhocReportStep3.setSubTotalKeyLevelFrom(presnId.getBegSubTotLvl());
			adhocReportStep3.setSubTotalKeyLevelTo(presnId.getEndSubTotLvl());
			adhocReportStep3.setReportDurationTime(presnId.getPresnDurTime());
			adhocReportStep3.setSelectedLayout(presnId.getPresnModel());
		}
		else {
			adhocReportStep3.setReportDurationTime("");
			adhocReportStep3.setSubTotalKeyLevelFrom(0);
			adhocReportStep3.setSubTotalKeyLevelTo(0);
			adhocReportStep3.setReportDurationTime("");
		}
		
		String colString = ((AdhocReportStep2)adhocReportDefinition.getAdhocReportStep2List().get(adhocReportDefinition.getSectionIndex())).getData();
		List tableList = extractTableNames(connection,failureList,colString);
		adhocReportStep3.setTableList(tableList);			
		List adhocKeyList = new ArrayList(); 
		adhocKeyList = getAdhocKeyList(alertRulePresenRuleList,connection,failureList,region);
		int timeFilterCode;
		
		//if ((adhocReportDefinition.getRptType().equals("D")) &&   (tableList.size()==getNbrOfBillRndTables(tableList,adhocReportDefinition.getDataNode(),region))){
		if (adhocReportDefinition.getRptType().equals("D")){
			timeFilterCode=1;
		}
		
		adhocReportStep3.setAdhockeyList(adhocKeyList);
		return adhocReportStep3;
	}
	
    /**
     * This method is used across the action class to populate default values for the various parameters for step 3 
     * @param adhocReportDefinition
     * @param connection
     * @param failureList
     * @param args
     */
    public void populateOptionValuesStep3(AdhocReportDefinition adhocReportDefinition,Connection connection, List failureList,List args) {
			AdhocReportStep3 adhocReportStep3 = (AdhocReportStep3)adhocReportDefinition.getAdhocReportStep3List().get(adhocReportDefinition.getSectionIndex());
	    	
	    	adhocReportStep3.setAlertKeyLevel(1);
	    	adhocReportStep3.setAlertKeyLevelList(getAlertKeyLevelList());			
	    	adhocReportStep3.setMouseOverList(getMouseOverList(connection, failureList, args));			
	    	adhocReportStep3.setReportDurationList(getReportDurationList());
	    	
	    	AdhocMainPageService adhocService = new AdhocMainPageService();
			// Get the existing adhoc reports and store them in arraylist
			List result = adhocService.getReportNameList(connection,failureList,args) ;
			adhocReportStep3.setReportLinkList(result);
			
			adhocReportStep3.setLevel1ColumnHeaderName("");
	    	adhocReportStep3.setLevel2ColumnHeaderName("");
	    	adhocReportStep3.setLevel3ColumnHeaderName("");
	    	adhocReportStep3.setLevel4ColumnHeaderName("");
	    	adhocReportStep3.setLevel5ColumnHeaderName("");
	    	
	    	adhocReportStep3.setLevel1MouseOverDescription("");
	    	adhocReportStep3.setLevel2MouseOverDescription("");
	    	adhocReportStep3.setLevel3MouseOverDescription("");
	    	adhocReportStep3.setLevel4MouseOverDescription("");
	    	adhocReportStep3.setLevel5MouseOverDescription("");
	    	
	    	adhocReportStep3.setKey1HeaderDesc("");
	    	
	    	adhocReportStep3.setReportDurationTime("");
			adhocReportStep3.setSubTotalKeyLevelFrom(0);
			adhocReportStep3.setSubTotalKeyLevelTo(0);
			List tableList = new ArrayList();
			
			adhocReportStep3.setTableList(tableList);
			adhocReportStep3.setFileSequenceIndicator("N");
    }
    
	/**
	 * This method is used to access AlertRulePresnElemDAO and fetch the records from RABC_ALERT_RULE_PRESN_ELEM 
	 * @param connection
	 * @param failures
	 * @param args
	 * @return List
	 */
	private List getAlertRulePresnElemList(Connection connection, List failures, List args)
	{
		List alertRulePresnElemList;
		AlertRulePresnElemDAO alertRulePresnElem = new AlertRulePresnElemDAO();
		alertRulePresnElemList = alertRulePresnElem.get(connection,failures,args,getColumnVars);
		return (alertRulePresnElemList);
	}

	/**
	 * This method is used to create the hashmap for step2 and step3 mouseover links.
	 * @param connection
	 * @param failures
	 * @param args
	 * @return HashMap
	 */
	public HashMap getMouseOverLinkMap(Connection connection, List failures, List args) {
		MouseOverLinkDAO mouseOverLinkDAO = new MouseOverLinkDAO();
		List mouseOverLinkList = mouseOverLinkDAO.get(connection,failures,args,MOUSE_OVER_LINK);
		HashMap mouseOverLinkMap = new HashMap();
		MouseOverLink mouseOverLink = new MouseOverLink() ; 
		int mouseOverLinkListSize = mouseOverLinkList.size();
		
		for (int i=0;i<mouseOverLinkListSize;i++){
			mouseOverLink = (MouseOverLink) mouseOverLinkList.get(i);
			mouseOverLinkMap.put(new Integer(mouseOverLink.getMouseOverNum()), mouseOverLink);
		}
        return mouseOverLinkMap;
    }
	
	/**
	 * This method is used to create the hashmap for step2 and step3 web data links. 
	 * @param connection
	 * @param failures
	 * @param args
	 * @return HashMap
	 */
	public HashMap getWebDataLinkMap(Connection connection, List failures, List args) {
		WebDataLinkDAO webDataLinkDAO = new WebDataLinkDAO(); 
		List webDataLinkList = webDataLinkDAO.get(connection,failures,args,GetWebDataLink);
		HashMap webDataLinkMap = new HashMap();
		for (int i=0;i<webDataLinkList.size();i++){
			WebDataLink webDataLink = (WebDataLink) webDataLinkList.get(i); 
			webDataLinkMap.put(Integer.toString(webDataLink.getLinkNum()), webDataLink);
		}
        return webDataLinkMap;
    }
	
	/**
	 * This method is used to extract table names for step 3 .
	 * @param connection
	 * @param failureList
	 * @param colString
	 * @return List
	 */
	public List extractTableNames(Connection connection , List failureList, String colString)
	{
		String[] tableList  ;
		List tableNameList = new ArrayList();
		tableList = colString.split(";");
		for (int i=0;i<tableList.length;i++)
		{
			String tableColumnString = tableList[i];
			String tableName=tableColumnString.substring(0,tableColumnString.indexOf(":"));
			List viewList = returnViewList(connection, failureList, tableName);
			if (viewList.size()>0){
				View view = (View) viewList.get(0);
				tableName = view.getTableName();
			}
			if (!(tableNameList.contains(tableName)) && !("null".equals(tableName))) {
				tableNameList.add(tableName);
			}	
		}
		return (tableNameList);
	}
	
	/**
	 * This method is used to get the time_filter_code 
	 * @param adhocReportDefinition
	 * @param failureList
	 * @param region
	 * @return int
	 */
	public int getTimeFilterCode(AdhocReportDefinition adhocReportDefinition,List failureList,String region)
	{
		int timeFilterCode=1;
		
		if ("D".equals(adhocReportDefinition.getRptType().trim())){// if Report type is Daily then set value to 1 .
			timeFilterCode=1;
		}else if ("B".equals(adhocReportDefinition.getRptType().trim())){ // if Report type is Bill Day then set value to 2 .
			timeFilterCode=2;
		} else if ("M".equals(adhocReportDefinition.getRptType().trim())){ // if Report type is Monthly then set value to 3 .
			timeFilterCode=3;
		}else if ("Y".equals(adhocReportDefinition.getRptType().trim())){ // if Report type is Yearly then set value to 4 .
			timeFilterCode=4;
		}else if ("S".equals(adhocReportDefinition.getRptType().trim())){// if Report type is Record then set value to 5 . 
			timeFilterCode=5;
		}
		
		/*
		AdhocReportStep3 adhocReportStep3= ((AdhocReportStep3)adhocReportDefinition.getAdhocReportStep3List().get(adhocReportDefinition.getSectionIndex()));
		List tableList = adhocReportStep3.getTableList(); 
		int nbrOfBillRnd=0;
		int nbrOfProcDate=0;
		nbrOfBillRnd = getNbrOfBillRndTables(tableList,adhocReportDefinition.getDataNode(),region);
		nbrOfProcDate = getNbrOfProcDateTables(tableList,adhocReportDefinition.getDataNode(),region);
		
		int timeFilterCode=1;
		int tableListSize = tableList.size();
		if ((tableListSize==nbrOfBillRnd) && (adhocReportDefinition.getRptType().trim().equals("D"))){
			timeFilterCode=1;
		}else if ((tableListSize==nbrOfProcDate) && (adhocReportDefinition.getRptType().trim().equals("B"))){
			timeFilterCode=2;
		}else if ((adhocReportDefinition.getRptType().trim().equals("Y"))||(adhocReportDefinition.getRptType().trim().equals("M"))){
			//if table selected has both DATE and BILL CYCLE column, set value to 3
			if (adhocReportDefinition.getSectionIndex()>0) {
				timeFilterCode=0;
			} else if (nbrOfProcDate==tableListSize){
				if (nbrOfBillRnd==tableListSize){
					timeFilterCode=3;
				}else if(nbrOfBillRnd<tableListSize){
					timeFilterCode=1;
				}
			}else if(nbrOfBillRnd==tableListSize){
				if (nbrOfProcDate==tableListSize){
					timeFilterCode=3;
				}else if(nbrOfProcDate<tableListSize){
					timeFilterCode=2;
				}
			}
		} else if (adhocReportDefinition.getRptType().trim().equals("S")) { // if Report type is Record then set value to 0 . 
			timeFilterCode=0;
		}
		*/
		return (timeFilterCode);		
	}

	/**
	 * This method is used to build keys and columns for step3
	 * @param adhocReportDefinition
	 * @param connection
	 * @param failureList
	 * @param region
	 */
	public void buildAdhocKey(AdhocReportDefinition adhocReportDefinition, Connection connection, List failureList, String region)
	{
		int numberOfTables = 0;
		List tempAdhocKey = new ArrayList();
				
		AdhocReportStep3 adhocReportStep3= ((AdhocReportStep3)adhocReportDefinition.getAdhocReportStep3List().get(adhocReportDefinition.getSectionIndex()));
		numberOfTables = adhocReportStep3.getTableList().size(); 
		for (int i=0;i<numberOfTables;i++)
		{
			String tableName = adhocReportStep3.getTableList().get(i).toString();
			//check if the object for tableName is already created . If created already
			//no need to do anything , otherwise add object .
			if (!(isTableNameInList(adhocReportStep3.getAdhockeyList(),tableName)))
			{
				AdhocKey adhocKey = new AdhocKey();
				adhocKey.setTableName(tableName);
				adhocKey.setKey1(StaticDataLoader.getDefaultDataTblDdlKey(tableName, region, 1));
				adhocKey.setKey2(StaticDataLoader.getDefaultDataTblDdlKey(tableName, region, 2));
				adhocKey.setKey3(StaticDataLoader.getDefaultDataTblDdlKey(tableName, region, 3));
				adhocKey.setKey4(StaticDataLoader.getDefaultDataTblDdlKey(tableName, region, 4));
				adhocKey.setKey5(StaticDataLoader.getDefaultDataTblDdlKey(tableName, region, 5));
				
				adhocKey.setColumnList(getColumnList(connection,failureList,tableName,region));
				adhocReportStep3.addAdhockeyList(adhocKey);
			}
		}
		//check in the opposite direction also , so that the table names and the
		//adhockey have 1-1 mapping
		int numberOfAdhocKeyList = adhocReportStep3.getAdhockeyList().size();
		
		for (int j=0;j<numberOfAdhocKeyList;j++)
		{
			String tableName = ((AdhocKey)adhocReportStep3.getAdhockeyList().get(j)).getTableName();
			if (adhocReportStep3.getTableList().contains(tableName)){
				tempAdhocKey.add((AdhocKey)adhocReportStep3.getAdhockeyList().get(j));
			}
		}
		adhocReportStep3.setAdhockeyList(tempAdhocKey);
	}
	
	/**
	 * Private method to check whether a tablename is already added to the list or not 
	 * @param adhocKeyList
	 * @param tableName
	 * @return true/false
	 */
	private boolean isTableNameInList(List  adhocKeyList,String tableName){
		
		boolean found=false;
		int i=0;
		while (!found && (i<adhocKeyList.size())){
			AdhocKey adhocKey =  (AdhocKey)adhocKeyList.get(i);
			if (adhocKey.getTableName().equals((String)tableName)){
				found=true;
			}
			i=i+1;
		}
		return found;
	}

	/**
	 * Private method to get the adhoc key list for step3
	 * @param alertRulePresenRuleList
	 * @param connection
	 * @param failureList
	 * @param region
	 * @return List
	 */
	private List getAdhocKeyList(List alertRulePresenRuleList,Connection connection,List failureList,String region)
	{
		List adhocKeyList = new ArrayList();
		for (int i=0;i<alertRulePresenRuleList.size();i++)
		{
			AlertRulePresenRule alertRulePresenRule = (AlertRulePresenRule)alertRulePresenRuleList.get(i);
			AdhocKey adhocKey = new AdhocKey();
			adhocKey.setKey1(alertRulePresenRule.getKeyDdlNameAt(0));
			adhocKey.setKey2(alertRulePresenRule.getKeyDdlNameAt(1));
			adhocKey.setKey3(alertRulePresenRule.getKeyDdlNameAt(2));
			adhocKey.setKey4(alertRulePresenRule.getKeyDdlNameAt(3));
			adhocKey.setKey5(alertRulePresenRule.getKeyDdlNameAt(4));
			adhocKey.setTableName(alertRulePresenRule.getPresnDataTbl());
			
			adhocKey.setColumnList(getColumnList(connection,failureList,alertRulePresenRule.getPresnDataTbl(),region));
			adhocKeyList.add(adhocKey);
		}
		return adhocKeyList;
	}
	
	/**
	 * Private method to get new PresnSeqNumber .
	 * It looks for the max of PresnSeqNumber in RABC_MENU_INDEX table where presn_lvl is 2 AND alert_rule IS NULL AND assoc_Parent_id is 4 AND sub_assoc_parent_id = 0.
	 * @param connection
	 * @param failureList
	 * @return PresnSeqNumber
	 */
	private int getPresnSeqNumber(Connection connection,List failureList,AdhocReportDefinition adhocReportDefinition) {
		
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		List args = new ArrayList();
		int presnSeqNumber=3;
		
		try	{
			MessageFormat mf = new MessageFormat(getPresnSeqNumber);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			
			while(rs.next()){
				presnSeqNumber = rs.getInt(1);
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
			return 1;
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		return (presnSeqNumber);
	}

	/**
	 * Private method to get new PresnSeqNumber .
	 * It looks for direcory name entered on page is exists, if it exists , will return presn seq number else -1 .
	 * Purposefully used integer value because same method can be used to set presn_se number attribute. 
	 * @param connection
	 * @param failureList
	 * @return PresnSeqNumber
	 */
	private int checkDirectoryExists(Connection connection,List failureList,AdhocReportDefinition adhocReportDefinition) {
		
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		List args = new ArrayList();
		int presnSeqNumber= -1 ;
		
		args.add(adhocReportDefinition.getUserDirectoryHidden()) ;
		try	{
			MessageFormat mf = new MessageFormat(getCurrentPresnSeqNumber);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			
			while(rs.next()){
				presnSeqNumber = rs.getInt(1);
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
			return 1;
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		return (presnSeqNumber);
	}

	
	/**
	 * Private method to get the list of user directories against which no adhoc report defined .
	 * It looks for direcory name entered on page is exists, if it exists , will return presn seq number else -1 .
	 * Purposefully used integer value because same method can be used to set presn_se number attribute. 
	 * @param connection
	 * @param failureList
	 * @param adhocReportDefinition
	 * @return List
	 */
	private List getEmptyUserDirList(Connection connection,List failureList,AdhocReportDefinition adhocReportDefinition) {
		
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		List args = new ArrayList();
		List selEmptyUserDirList = new ArrayList();
		//args.add(adhocReportDefinition.getUserDirectoryHidden()) ;
		try	{
			MessageFormat mf = new MessageFormat(selEmptyUserDir);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			
			while(rs.next()){
				selEmptyUserDirList.add(new Integer (rs.getInt(1))) ; 
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		return (selEmptyUserDirList);
	}
	
	/**
	 * This method is called when the user clicks on "save" or "test & Save" button
	 * @param connection
	 * @param failureList
	 * @param adhocReportDefinition
	 */
	public void save(Connection connection, List failureList, AdhocReportDefinition adhocReportDefinition){
		int presnId = adhocReportDefinition.getPresnId();
		List saveArgs = new ArrayList();
		saveArgs.add(Integer.toString(presnId));
		PresnIdDAO presnIdDAO= new PresnIdDAO();
		presnIdDAO.executeUpdate(connection,failureList,saveArgs,saveAdhocReport);
	}
	
	/**
	 * Private method to carry out insert operation into RABC_PRESN_ID table
	 * @param connection
	 * @param failureList
	 * @param adhocReportDefinition
	 * @param region
	 */
	private void insertPresnId(Connection connection, List failureList, AdhocReportDefinition adhocReportDefinition, String region){
		PresnIdDAO presnIdDAO= new PresnIdDAO();
		
		// Add all the arguments from object to list & pass the list to the 
		List insArgs = new ArrayList();
		List delArgs = new ArrayList();
		
		delArgs.add(Integer.toString(adhocReportDefinition.getPresnId())); // Get the presn_id
		delArgs.add(Integer.toString(adhocReportDefinition.getCurrentSection()));
		
		insArgs.add(Integer.toString(adhocReportDefinition.getPresnId())); // Get the presn_id
		insArgs.add(Integer.toString(adhocReportDefinition.getCurrentSection()));
		insArgs.add(adhocReportDefinition.getPresnDesc());
		
		if ("S".equals(adhocReportDefinition.getRptType())) { // If reprot type is Record then insert null 
			insArgs.add("");
		} else {
			insArgs.add(adhocReportDefinition.getRptType());
		}
	
		insArgs.add(adhocReportDefinition.getDataNode());
		AdhocReportStep3 adhocReportStep3 = ((AdhocReportStep3)adhocReportDefinition.getAdhocReportStep3List().get(adhocReportDefinition.getSectionIndex()));
		
		if (adhocReportStep3.getAlertKeyLevel() > 0 ) {
			insArgs.add(Integer.toString(adhocReportStep3.getSubTotalKeyLevelFrom()));
			insArgs.add(Integer.toString(adhocReportStep3.getSubTotalKeyLevelTo()));
		}else {
			insArgs.add("0");
			insArgs.add("0");
		}
		
		if (adhocReportStep3.getReportDurationTime()!=null){
			insArgs.add(adhocReportStep3.getReportDurationTime());
		}else{
			insArgs.add("");
		}
		insArgs.add(Integer.toString(adhocReportStep3.getSelectedLayout()));
		int timeFilterCode = getTimeFilterCode(adhocReportDefinition,failureList,region);
		insArgs.add(Integer.toString(timeFilterCode));
		
		String presnTblName="";
		String procDateDdlName="";
		List tableList = adhocReportStep3.getTableList();
		if (tableList!=null){
			presnTblName = (String)tableList.get(0);
		}
		procDateDdlName = getProcDateDdlName(presnTblName,region);
		insArgs.add(presnTblName);
		insArgs.add(procDateDdlName);
		// argument 12 - Division_name_key_lvl
		String divisionNameKeyLevel="0";
		int adhocKeySize = adhocReportStep3.getAdhockeyList().size();
		if (adhocReportStep3.getAlertKeyLevel() > 0 ) {
			for (int i=0;i<adhocKeySize;i++){
				if (((AdhocKey)adhocReportStep3.getAdhockeyList().get(i)).getKey1().equalsIgnoreCase("DIVISION")){
					divisionNameKeyLevel="1";
				}else if (((AdhocKey)adhocReportStep3.getAdhockeyList().get(i)).getKey2().equalsIgnoreCase("DIVISION")){
					divisionNameKeyLevel="2";
				}else if (((AdhocKey)adhocReportStep3.getAdhockeyList().get(i)).getKey3().equalsIgnoreCase("DIVISION")){
					divisionNameKeyLevel="3";
				}else if (((AdhocKey)adhocReportStep3.getAdhockeyList().get(i)).getKey4().equalsIgnoreCase("DIVISION")){
					divisionNameKeyLevel="4";
				}else if (((AdhocKey)adhocReportStep3.getAdhockeyList().get(i)).getKey5().equalsIgnoreCase("DIVISION")){
					divisionNameKeyLevel="5";
				}
			}
		}
		insArgs.add(divisionNameKeyLevel);
		presnIdDAO.executeUpdate(connection,failureList,delArgs,delAdhocReportPresnId);
		presnIdDAO.executeUpdate(connection,failureList,insArgs,insAdhocReportPresnId);
	}
	
	/**
	 * Private method to carry out insert operation into RABC_PRESN_HEADER table
	 * @param connection
	 * @param failureList
	 * @param adhocReportDefinition
	 */
	private void insertPresnHeader(Connection connection, List failureList,AdhocReportDefinition adhocReportDefinition){
		PresnHeaderDAO presnHeaderDAO = new PresnHeaderDAO();
		
		// Add all the arguments from object to list & pass the list to the 
		List insArgs = new ArrayList();
		List delArgs = new ArrayList();
		
		delArgs.add(Integer.toString(adhocReportDefinition.getPresnId())); // Get the presn_id
		
		insArgs.add(Integer.toString(adhocReportDefinition.getPresnId())); // Get the presn_id
		insArgs.add(adhocReportDefinition.getHeader1());
		insArgs.add(adhocReportDefinition.getHeader2());
		insArgs.add(adhocReportDefinition.getHeader3());
		
		presnHeaderDAO.executeUpdate(connection,failureList,delArgs,delHeader);
		presnHeaderDAO.executeUpdate(connection,failureList,insArgs,insHeader);
	}
	
	/**
	 * Private method to carry out insert operation into Web_Header_Link table
	 * @param connection
	 * @param failureList
	 * @param adhocReportDefinition
	 */
	private void insertWebHeader(Connection connection, List failureList,AdhocReportDefinition adhocReportDefinition){
		WebHeaderLinkDAO webHeaderLinkDAO = new WebHeaderLinkDAO();
		String rptType = adhocReportDefinition.getRptType(); 
		// Add all the arguments from object to list & pass the list to the 
		
		List delArgs = new ArrayList();
		List insWebHeaderLink1Args = new ArrayList();
		List insWebHeaderLink2Args = new ArrayList();
		List insWebHeaderLink3Args = new ArrayList();
		List insWebHeaderLink4Args = new ArrayList();
		List insWebHeaderLink5Args = new ArrayList();
		
		delArgs.add(Integer.toString(adhocReportDefinition.getPresnId())); // Get the presn_id
		insWebHeaderLink1Args.add(Integer.toString(adhocReportDefinition.getPresnId()));
		insWebHeaderLink2Args.add(Integer.toString(adhocReportDefinition.getPresnId()));
		insWebHeaderLink3Args.add(Integer.toString(adhocReportDefinition.getPresnId()));
		insWebHeaderLink4Args.add(Integer.toString(adhocReportDefinition.getPresnId()));
		insWebHeaderLink5Args.add(Integer.toString(adhocReportDefinition.getPresnId()));
		
		webHeaderLinkDAO.executeUpdate(connection,failureList,delArgs,delWebHeaderLink);
		
		webHeaderLinkDAO.executeUpdate(connection,failureList,insWebHeaderLink1Args,insWebHeaderLink1);
		if (rptType.equals("D")){
			webHeaderLinkDAO.executeUpdate(connection,failureList,insWebHeaderLink2Args,insWebHeaderLink2);
			webHeaderLinkDAO.executeUpdate(connection,failureList,insWebHeaderLink3Args,insWebHeaderLink3);
			insWebHeaderLink4Args.add("4");
			insWebHeaderLink5Args.add("5");
		}else{
			insWebHeaderLink4Args.add("2");
			insWebHeaderLink5Args.add("3");
		}
		
		webHeaderLinkDAO.executeUpdate(connection,failureList,insWebHeaderLink4Args,insWebHeaderLink4);
		webHeaderLinkDAO.executeUpdate(connection,failureList,insWebHeaderLink5Args,insWebHeaderLink5);
	}
	
	/**
	 * Private method to carry out insert operation into RABC_MENU_INDEX table
	 * @param connection
	 * @param failureList
	 * @param adhocReportDefinition
	 */
	private void insertMenuIndex(Connection connection, List failureList,AdhocReportDefinition adhocReportDefinition){
		MenuIndexDAO menuIndexDAO = new MenuIndexDAO();
		
		// Add all the arguments from object to list & pass the list to the 
		List insArgs = new ArrayList();
		List delArgs = new ArrayList();
				
		delArgs.add(Integer.toString(adhocReportDefinition.getPresnId())); // Get the presn_id
		insArgs.add(Integer.toString(adhocReportDefinition.getPresnId())); // Get the presn_id
		insArgs.add(adhocReportDefinition.getPresnDesc());
		String assocParentId=null;
		int subAssocParentId = 2 ; //Default is 2 -- Adhoc Report Directory if no user direcory selected
		
		if ((!("".equals(adhocReportDefinition.getUserDirectoryHidden()))) && (!("null").equals(adhocReportDefinition.getUserDirectoryHidden()))){
			assocParentId= "4" ;
			subAssocParentId = adhocReportDefinition.getPresnSeqNumber() ;
		}else {
			if (adhocReportDefinition.getRptType().equals("D")){
				assocParentId="1";
			}else if (adhocReportDefinition.getRptType().equals("S")){ // If report type is record then Other Directory --> Adhoc reports 
				assocParentId="4";
			}else if (adhocReportDefinition.getRptType().equals("M")){
				assocParentId="3";
			}else if (adhocReportDefinition.getRptType().equals("Y")){
				assocParentId="4";
			}else if (adhocReportDefinition.getRptType().equals("B")){
				assocParentId="2";
			}
		}
		insArgs.add(assocParentId);
		insArgs.add(Integer.toString(subAssocParentId)) ; // sub_assoc_parent_id    
		
		menuIndexDAO.executeUpdate(connection,failureList,delArgs,delMenuIndexID);
		menuIndexDAO.executeUpdate(connection,failureList,insArgs,insMenu);
	}
	
	/**
	 * Private method to carry out insert operation into RABC_MENU_INDEX table
	 * @param connection
	 * @param failureList
	 * @param adhocReportDefinition
	 */
	private void insertMenuIndexUserDirectory(Connection connection, List failureList,AdhocReportDefinition adhocReportDefinition){
		MenuIndexDAO menuIndexDAO = new MenuIndexDAO();
		
		// Add all the arguments from object to list & pass the list to the 
		List insArgs = new ArrayList();
		int presnSeqNumber ; 
		//insArgs.add(Integer.toString(adhocReportDefinition.getPresnId())); // Get the presn_id
		
		insArgs.add(adhocReportDefinition.getUserDirectoryHidden());
		presnSeqNumber = getPresnSeqNumber(connection,failureList,adhocReportDefinition) ;
		insArgs.add(Integer.toString(presnSeqNumber));
		adhocReportDefinition.setPresnSeqNumber(presnSeqNumber) ;
		menuIndexDAO.executeUpdate(connection,failureList,insArgs,insMenuUserDirectory);
	}
	
	/**
	 * Private method to carry out delete operation from RABC_MENU_INDEX table for those user directories which does not 
	 * conatin any adhoc report  
	 * @param connection
	 * @param failureList
	 * @param adhocReportDefinition
	 */
	private void deleteMenuIndexUserDirectory(Connection connection, List failureList,AdhocReportDefinition adhocReportDefinition){
		MenuIndexDAO menuIndexDAO = new MenuIndexDAO();
		List selEmptyDirList = new ArrayList(); 
		List delDirArgs = new ArrayList();
		int presnSeqNumber ; 
		int selEmptyDirListSize ;
		String presnSeqNumStr = "" ;
		
		// Check here which user directories are empty , if yes delete them from RABC_MENU_INDEX 
		// Before deleting check that current report is going under empty directory or not . 
		//IF it is going under empty directory then don't delete that directory. 
		
		presnSeqNumber = adhocReportDefinition.getPresnSeqNumber() ;
		
		// Get list of empty directories 
		selEmptyDirList = getEmptyUserDirList (connection,failureList,adhocReportDefinition) ;
		
		selEmptyDirListSize = selEmptyDirList.size() ;
		
		if (selEmptyDirListSize > 0 ) {
			for (int i = 0 ; i < selEmptyDirListSize ; i++ ){
				if (presnSeqNumber != ((Integer) selEmptyDirList.get(i)).intValue()) {
					if (i == (selEmptyDirListSize-1) ) {
						presnSeqNumStr += selEmptyDirList.get(i) ;	
					}else {
						presnSeqNumStr += selEmptyDirList.get(i) + "," ;
					} 
				} 
			}
		}
		if (!("").equals(presnSeqNumStr)) {
			delDirArgs.add(presnSeqNumStr) ;
			if (delDirArgs.size()  > 0 ) {
				menuIndexDAO.executeUpdate(connection,failureList,delDirArgs,delMenuIndexDIR);
			}
		}
	}
	
	/**
	 * Private method to carry out insert operation into RABC_UPDATE_GRP table
	 * @param connection
	 * @param failureList
	 * @param adhocReportDefinition
	 */
	private void insertUpdateGroup(Connection connection, List failureList,AdhocReportDefinition adhocReportDefinition){
		UpdateGrpDAO updateGrpDAO = new UpdateGrpDAO();
		
		// Add all the arguments from object to list & pass the list to the 
		List insArgs = new ArrayList();
		List delArgs = new ArrayList();
		String[] alertGroup ;  
		delArgs.add(Integer.toString(adhocReportDefinition.getPresnId())); // Get the presn_id
		insArgs.add(Integer.toString(adhocReportDefinition.getPresnId())); // Get the presn_id
		
		updateGrpDAO.executeUpdate(connection,failureList,delArgs,delAlertGrps);
		
		alertGroup = adhocReportDefinition.getAlertGroup();
		int alertGroupLen = alertGroup.length;
		for (int i=0;i<alertGroupLen;i++){
			insArgs.add(1,alertGroup[i]);
			updateGrpDAO.executeUpdate(connection,failureList,insArgs,insUpdgrp);
			//remove from the list so that the next iteration will insert to the 1st position 
			//itself 
			insArgs.remove(1);
		}
	}
	
	/**
	 * Private method to carry out insert operation into RABC_PRESN_KEY1_HEADER or RABC_PRESN_KEY2_HEADER table
	 * @param connection
	 * @param failureList
	 * @param adhocReportDefinition
	 */
	private void insertKey1Header(Connection connection, List failureList,AdhocReportDefinition adhocReportDefinition){
		// Add all the arguments from object to list & pass the list to the 
		List insArgs = new ArrayList();
		List delArgs = new ArrayList();
		  
		delArgs.add(Integer.toString(adhocReportDefinition.getPresnId())); // Get the presn_id
		insArgs.add(Integer.toString(adhocReportDefinition.getPresnId())); // Get the presn_id
		delArgs.add(Integer.toString(adhocReportDefinition.getCurrentSection()));
		insArgs.add(Integer.toString(adhocReportDefinition.getCurrentSection()));
		String presnKey1HeaderDesc = ((AdhocReportStep3)adhocReportDefinition.getAdhocReportStep3List().get(adhocReportDefinition.getSectionIndex())).getKey1HeaderDesc();
		
		insArgs.add(presnKey1HeaderDesc);
		
		int alertKeyLevel = ((AdhocReportStep3)adhocReportDefinition.getAdhocReportStep3List().get(adhocReportDefinition.getSectionIndex())).getAlertKeyLevel();
		
		if (alertKeyLevel > 1) {
			PresnKey2HeaderDAO presnKey2HeaderDAO = new PresnKey2HeaderDAO();
			presnKey2HeaderDAO.executeUpdate(connection,failureList,delArgs,delKey2Header);
			presnKey2HeaderDAO.executeUpdate(connection,failureList,insArgs,insKey2Header);
		} else {
			PresnKey1HeaderDAO presnKey1HeaderDAO = new PresnKey1HeaderDAO();
			presnKey1HeaderDAO.executeUpdate(connection,failureList,delArgs,delKey1Header);
			presnKey1HeaderDAO.executeUpdate(connection,failureList,insArgs,insKey1Header);
		}
	}	

	/**
	 * Private method to get new presn_id .
	 * It looks for the missing PRESN_ID in the table. If a PRESN_ID is missing in the 
	 * series, then the new record should be created with the missing PRESEN_ID's
	 * @param connection
	 * @param failureList
	 * @return
	 */
	private int getNewPresnId(Connection connection,List failureList) {
		
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		List args = new ArrayList();
		int presnId=1;
		try	{
			MessageFormat mf = new MessageFormat(getPresenId);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			
			while(rs.next()){
				if (rs.getInt(1)!=presnId){
					return (presnId);
				}
				else{
					presnId=presnId+1;
				}	
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
			return 1;
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		return (presnId);
	}

	/**
	 * Private method to carry out insert operation into rabc_alert_rule_presn_elem table
	 * @param connection
	 * @param failureList
	 * @param adhocReportDefinition
	 * @param region
	 */
	private void insertAlertRulePresnElem(Connection connection, List failureList,AdhocReportDefinition adhocReportDefinition,String region){
		AlertRulePresnElemDAO alertRulePresnElemDAO= new AlertRulePresnElemDAO();
		MouseOverLinkDAO mouseOverLinkDAO = new MouseOverLinkDAO(); 
		WebDataLinkDAO webDataLinkDAO = new WebDataLinkDAO();
		PresnCalcElemRptDAO presnCalcElemRptDAO = new PresnCalcElemRptDAO();
		// Add all the arguments from object to list & pass the list to the 
		List insArgs = new ArrayList();
		List delArgs = new ArrayList();
		
		List mouseOverLinkDelArgs = new ArrayList();
		List mouseOverLinkInsArgs = new ArrayList();
		
		List webDataLinkDelArgs = new ArrayList();
		List webDataLinkInsArgs = new ArrayList();
		
		mouseOverLinkInsArgs.add(Integer.toString(adhocReportDefinition.getPresnId()));
		mouseOverLinkInsArgs.add(Integer.toString(adhocReportDefinition.getCurrentSection()));
		
		webDataLinkInsArgs.add(Integer.toString(adhocReportDefinition.getPresnId()));
		webDataLinkInsArgs.add(Integer.toString(adhocReportDefinition.getCurrentSection()));
		
		mouseOverLinkDelArgs.add(Integer.toString(adhocReportDefinition.getPresnId()));
		mouseOverLinkDelArgs.add(Integer.toString(adhocReportDefinition.getCurrentSection()));
		
		webDataLinkDelArgs.add(Integer.toString(adhocReportDefinition.getPresnId()));
		webDataLinkDelArgs.add(Integer.toString(adhocReportDefinition.getCurrentSection()));
		
		//delete existing mouse over link data
		mouseOverLinkDAO.executeUpdate(connection,failureList,mouseOverLinkDelArgs,delMoLink);
		
		//delete existing web data link 
		
		webDataLinkDAO.executeUpdate(connection,failureList,webDataLinkDelArgs,delDataLinkNum);
		
		int webDataLinkNum = 1;
		delArgs.add(Integer.toString(adhocReportDefinition.getPresnId())); // Get the presn_id
		delArgs.add(Integer.toString(adhocReportDefinition.getCurrentSection()));
		
		alertRulePresnElemDAO.executeUpdate(connection,failureList,delArgs,delAlertRulePresnElem);
		//0
		insArgs.add(Integer.toString(adhocReportDefinition.getPresnId())); // Get the presn_id
		//1
		insArgs.add(Integer.toString(adhocReportDefinition.getCurrentSection()));
		
		//Delete the selected calculation and section from RABC_PRESN_CALC_ELEM_RPT table.
		List presnCalcElemRptDelListArgs = new ArrayList();
		presnCalcElemRptDelListArgs.add(Integer.toString(adhocReportDefinition.getPresnId()));
		presnCalcElemRptDelListArgs.add(Integer.toString(adhocReportDefinition.getCurrentSection()));
		presnCalcElemRptDAO.executeUpdate(connection,failureList,presnCalcElemRptDelListArgs,delCalculation);
		
		String colString = ((AdhocReportStep2)adhocReportDefinition.getAdhocReportStep2List().get(adhocReportDefinition.getSectionIndex())).getData();
		
		String[] colStringArray;
		colStringArray = colString.split(";");
		String sumInd = "" ;
		int mouseOverNum=1;
		int i=0 ;
		for ( i=0;i<colStringArray.length;i++)
		{
			//2
			insArgs.add(Integer.toString(i+1));
			String[] singleColStringArray;
			singleColStringArray = colStringArray[i].split(":");
			
			String tblName="";
			String ddlName="";
			String viewName="";

			String[] calcDataArray;
			//if it is a calculation
			if ("null".equals(singleColStringArray[0])){
				//add the code here , if it is a calculation  . get the data from  singleColStringArray[7] 
				//the  singleColStringArray[7] is like "Sum(RABC_ACCT_BLG_DTL.ACCT_900_CALL_CHRG)+200"
				//extract "RABC_ACCT_BLG_DTL.ACCT_900_CALL_CHRG" from it and then extract "RABC_ACCT_BLG_DTL" and "ACCT_900_CALL_CHRG" separately 
				//put "RABC_ACCT_BLG_DTL" in tblName and "ACCT_900_CALL_CHRG" in  ddlName and "RABC_ACCT_BLG_DTL" in viewName
				
				List getTokenArray = new ArrayList();
				getTokenArray = getToken(singleColStringArray[7]) ; 

				//for ( i = 0 ; i<getTokenArray.size(); i++ ) {
					if (!isNumeric(getTokenArray.get(0).toString()))
						tblName= (getTokenArray.get(0).toString()).substring(0,getTokenArray.get(0).toString().indexOf(".")) ;
						ddlName= (getTokenArray.get(0).toString()).substring(getTokenArray.get(0).toString().indexOf(".")+1,getTokenArray.get(0).toString().length()) ;
						//break;
				//}
				
				// If calculation is based on view then get base table from view . 
				if ("VW_".equals(tblName.substring(0,3))) {
					List viewList = returnViewList(connection, failureList, tblName);
					if (viewList.size()>0){
						View view = (View) viewList.get(0);
						tblName = view.getTableName();
						viewName = view.getViewName() ;
					}
				} else {
					viewName=tblName;
				}

				
			}else{
				tblName = singleColStringArray[1];
				ddlName=singleColStringArray[2];
				viewName=singleColStringArray[0];
			}
				
			//3
			//VIEW_NAME
			insArgs.add(viewName);
			//4
			//DATA_TBL
			
			insArgs.add(tblName);
			//5
			//DATA_DDL_NAME
			insArgs.add(ddlName);
			//6
			//Column Header Name - PRESN_NAME
			insArgs.add(singleColStringArray[6]);
			//7
			// calc id - PRESN_CALC_NUM	
			if (!("null".equals(singleColStringArray[8].toString().trim()))){
				if ("0".equals(singleColStringArray[8].toString().trim())){
					insArgs.add("");
				}else{
					insArgs.add(singleColStringArray[8]);
				}
				
			}else{
				insArgs.add("");
				
			}
			
			//8
			//GRAPH - PRESN_GRAPH_IND
			if ("true".equals(singleColStringArray[9].toString().trim())){
				insArgs.add("Y");
			}
			else{
				//insArgs.add("N");
				insArgs.add("");
			}
			
			//9
			//SORT  - PRESN_ORD_IND
			if (!("null".equals(singleColStringArray[10].toString().trim()))){
				insArgs.add(singleColStringArray[10]);
			}else{
				insArgs.add("");
				
			}
			
			//10
			//SUPRESS - PRESN_SUPRESS_IND
			if ("true".equals(singleColStringArray[11].toString().trim())){
				insArgs.add("Y");
			}else{
				//insArgs.add("N");
				insArgs.add("");
			}
			
			//11
			//PREVIOUS DATA - PREV_DATA_IND
			if ("true".equals(singleColStringArray[12].toString().trim())){
				insArgs.add("Y");
			}else{
				insArgs.add("");
			}
			
			//12
			//DATA_DESC_IND
			if (!("".equals(singleColStringArray[14].trim())) && !("null".equals(singleColStringArray[14].trim()))){
				insArgs.add("Y");
				//13
				//
				//mouse over description - DATA_MOUSE_OVER_NUM
				insArgs.add(Integer.toString(mouseOverNum));
				//mouseOverNum = mouseOverNum+1; Removed for defect fix while inserting value in MOUSE_OVER_lINK table 
			}else{
				insArgs.add("");
				insArgs.add("0");
			}
			
			//DATA_LINK_IND
			if (!("null".equals(singleColStringArray[16].toString().trim()))){
				if ("0".equals(singleColStringArray[16].toString().trim())){
					insArgs.add("");
					insArgs.add("0");
				}else{
					insArgs.add("Y");
					insArgs.add(Integer.toString(webDataLinkNum));
					webDataLinkNum = webDataLinkNum+1;
				}
				//15
				//DATA_LINK_NUM
				
			}else{
				insArgs.add("");
				insArgs.add("0");
			}
			
			//16
			//UNIT - PRESN_UNIT_IND
			if (!("null".equals(singleColStringArray[17].toString().trim()))){
				insArgs.add(singleColStringArray[17]);
			}else{
				insArgs.add("");
			}
			
			//17
			//PRESN_FORMAT_CODE
			if (!("null".equals(singleColStringArray[19].toString()))){
				insArgs.add(singleColStringArray[19]);
			}else{
				insArgs.add("");
			}
			//18
			//PRESN_SUM_IND
			if ("null".equals(singleColStringArray[0])) {
				sumInd = "N" ;
			}	
			else {	
				sumInd = getSumInd(adhocReportDefinition.getDataNode(),singleColStringArray[1],singleColStringArray[2],region);
			}			
			insArgs.add(sumInd);
			
			//19
			//PARTI_REF_ID
			/*
			if ("null".equals(singleColStringArray[0])){
				insArgs.add(singleColStringArray[8]);
			}else{
				insArgs.add("");
			}
			*/
			
			//19
			//PARTI_REF_ID
			insArgs.add("");
		
			//21 DIFFERENCE DATA - DIFF_DATA_IND
			if ("true".equalsIgnoreCase(singleColStringArray[21].toString().trim())){
				insArgs.add("Y");
			}else{
				insArgs.add("");
			}			
			
			
			alertRulePresnElemDAO.executeUpdate(connection,failureList,insArgs,insAlertRulePresnElem);
			

			

			
			//remove the arguments so that it will not conflict in the next iteration .
			
			while (insArgs.size()>2){
				insArgs.remove(insArgs.size()-1);
			}
			
			//INSERT INTO RABC_PRESN_CALC_ELEM_RPT TABLE IF IT IS A CALC			
			if (("null".equals(singleColStringArray[0].toString().trim()))){
				
				List presnCalcElemRptInsListArgs = new ArrayList();
				List presnCalcElemArgs = new ArrayList();
				
				presnCalcElemRptInsListArgs.add(Integer.toString(adhocReportDefinition.getPresnId()));
				presnCalcElemRptInsListArgs.add(Integer.toString(adhocReportDefinition.getCurrentSection()));
				
				presnCalcElemArgs.add(singleColStringArray[8]);
				
				PresnCalcElemDAO presnCalcElemDAO = new PresnCalcElemDAO();
				List presnCalcElemList = presnCalcElemDAO.get(connection,failureList,presnCalcElemArgs,getCalc);
				int  presnCalcElemListSize = presnCalcElemList.size();
				
				for (int j=0;j<presnCalcElemListSize;j++){
					PresnCalcElem presnCalcElem = (PresnCalcElem) presnCalcElemList.get(j);
					if (presnCalcElem!=null){
						if (presnCalcElem.getPresnCalcName()!=null){
							presnCalcElemRptInsListArgs.add(presnCalcElem.getPresnCalcName());
						}else{
							presnCalcElemRptInsListArgs.add("");
						}
						
						presnCalcElemRptInsListArgs.add(Integer.toString(presnCalcElem.getPresnCalcNum()));
						if (presnCalcElem.getCalcElemFormula()!=null){						
							presnCalcElemRptInsListArgs.add(presnCalcElem.getCalcElemFormula());
						}else{
							presnCalcElemRptInsListArgs.add("");
						}
						if(presnCalcElem.getCalcElemUserView()!=null){
							presnCalcElemRptInsListArgs.add(presnCalcElem.getCalcElemUserView());
						}else{
							presnCalcElemRptInsListArgs.add("");
						}
						if (presnCalcElem.getCalcDivInd()!=null){
							presnCalcElemRptInsListArgs.add(presnCalcElem.getCalcDivInd());
						}	
						else{
							presnCalcElemRptInsListArgs.add("");
						}
						if (presnCalcElem.getCalcElemDisplay()!=null){
							presnCalcElemRptInsListArgs.add(presnCalcElem.getCalcElemDisplay());
						}else{
							presnCalcElemRptInsListArgs.add("");
						}
						if (presnCalcElem.getPresnFormatCode()!=null){
							presnCalcElemRptInsListArgs.add(presnCalcElem.getPresnFormatCode());
						}else{
							presnCalcElemRptInsListArgs.add("");
						}
					}
				}
				presnCalcElemRptDAO.executeUpdate(connection,failureList,presnCalcElemRptInsListArgs,insCalulation);
			}
			
			//END	INSERT INTO RABC_PRESN_CALC_ELEM_RPT TABLE IF IT IS A CALC 
			if ("null".equals(singleColStringArray[14])){
				singleColStringArray[14]="";
			}
			
			//insert into rabc_mouse_over_link table 
			if (!("".equals(singleColStringArray[14]))){
				String description = singleColStringArray[14];
				String tableName = description.substring(0, description.indexOf("~"));
				String tableKeyName = description.substring(description.indexOf("~")+1, description.lastIndexOf("~"));
				String tableKeyData = description.substring(description.lastIndexOf("~")+1);
				
				// 2
				//mouseOverLinkInsArgs.add(Integer.toString(i+1));
				mouseOverLinkInsArgs.add(Integer.toString(mouseOverNum));
				mouseOverNum = mouseOverNum+1;

				//3
				mouseOverLinkInsArgs.add(tableKeyName);
				//4
				mouseOverLinkInsArgs.add(tableKeyData);
				//5
				mouseOverLinkInsArgs.add(tableName);
				
				mouseOverLinkDAO.executeUpdate(connection,failureList,mouseOverLinkInsArgs,insMouseOver);
				
				while (mouseOverLinkInsArgs.size()>2){
					mouseOverLinkInsArgs.remove(mouseOverLinkInsArgs.size()-1);
				}
			}	
			//insert into rabc_web_data_link table 
				
			if (!(singleColStringArray[16].toString().equals("null")) && !"0".equals(singleColStringArray[16].toString())){
				//2
				webDataLinkInsArgs.add(Integer.toString(webDataLinkNum-1));
				//3 
				List PresnIdargs = new ArrayList();
				PresnIdargs.add("");
				PresnIdargs.add(singleColStringArray[16].toString());
				List presnIdList =  getPresenDetails(connection,failureList,PresnIdargs) ;
				if (presnIdList!=null){
					PresnId presnId = (PresnId)presnIdList.get(0);
				
					webDataLinkInsArgs.add(presnId.getPresnIdDesc());
				}else{
					webDataLinkInsArgs.add("");
				}
				//4
				webDataLinkInsArgs.add(singleColStringArray[16].toString());
				
				webDataLinkDAO.executeUpdate(connection,failureList,webDataLinkInsArgs,insWebDataLink);
				
				while (webDataLinkInsArgs.size()>2){
					webDataLinkInsArgs.remove(webDataLinkInsArgs.size()-1);
				}
			}
		}	
	}

	/**
	 * Private method to carry out insert operation into RABC_Alert_Rule_Presn_Rule table
	 * @param connection
	 * @param failureList
	 * @param adhocReportDefinition
	 * @param region
	 */
	private void insertAlertRulePresnRule(Connection connection, List failureList, AdhocReportDefinition adhocReportDefinition, String region){
		PresnKey1HeaderDAO presnKey1HeaderDAO = new PresnKey1HeaderDAO();
		MouseOverLinkDAO mouseOverLinkDAO = new MouseOverLinkDAO(); 
		
		AdhocReportStep3 adhocReportStep3 =  (AdhocReportStep3) adhocReportDefinition.getAdhocReportStep3List().get(adhocReportDefinition.getSectionIndex());
		String  reportLinkNum="";
		// Add all the arguments from object to list & pass the list to the 
		
		List insArgs = new ArrayList();
		List delArgs = new ArrayList();
	
		List mouseOverLinkInsArgs = new ArrayList();
		List webDataLinkInsArgs = new ArrayList();
		  
		delArgs.add(Integer.toString(adhocReportDefinition.getPresnId())); // Get the presn_id
		//0
		insArgs.add(Integer.toString(adhocReportDefinition.getPresnId())); // Get the presn_id
		delArgs.add(Integer.toString(adhocReportDefinition.getCurrentSection()));
		//1
		insArgs.add(Integer.toString(adhocReportDefinition.getCurrentSection()));
		
		presnKey1HeaderDAO.executeUpdate(connection,failureList,delArgs,delAlertRulePresnRule);
		
		//2
		if ("Y".equals(adhocReportStep3.getFileSequenceIndicator())){
			insArgs.add("Y");
		}else{
			insArgs.add("N");
		}
		
		List adhocKeyList = adhocReportStep3.getAdhockeyList();
		
		/*
		 * insert into RABC_WEB_DATA_LINK . code added by AT1862 to implement report link in step3 
		 */
		
		int linkNum1= 0;
		int linkNum2= 0;
		int linkNum3= 0;
		int linkNum4= 0;
		int linkNum5= 0;
		
		WebDataLinkDAO webDataLinkDAO = new WebDataLinkDAO();
		webDataLinkInsArgs.add(Integer.toString(adhocReportDefinition.getPresnId()));
		webDataLinkInsArgs.add(Integer.toString(adhocReportDefinition.getCurrentSection()));
		int maxWebDataLinkNum = getMaxWebDataLinkNum(connection,failureList,adhocReportDefinition);
		maxWebDataLinkNum = maxWebDataLinkNum+1;
		if ((adhocReportStep3.getAlertKeyLevel()>=1) && (!("".equals(adhocReportStep3.getLevel1ReportLink())))){
			webDataLinkInsArgs.add(Integer.toString(maxWebDataLinkNum));
			webDataLinkInsArgs.add(getReportName(adhocReportStep3.getLevel1ReportLink(),connection,failureList));
			webDataLinkInsArgs.add(adhocReportStep3.getLevel1ReportLink());
			linkNum1= maxWebDataLinkNum;
			maxWebDataLinkNum = maxWebDataLinkNum+1;
			webDataLinkDAO.executeUpdate(connection,failureList,webDataLinkInsArgs,insWebDataLink);
			
			while (webDataLinkInsArgs.size()>2){
				webDataLinkInsArgs.remove(webDataLinkInsArgs.size()-1);
			}
		}
		
		if ((adhocReportStep3.getAlertKeyLevel()>=2) && (!("".equals(adhocReportStep3.getLevel2ReportLink())))){
			webDataLinkInsArgs.add(Integer.toString(maxWebDataLinkNum));
			webDataLinkInsArgs.add(getReportName(adhocReportStep3.getLevel2ReportLink(),connection,failureList));
			webDataLinkInsArgs.add(adhocReportStep3.getLevel2ReportLink());
			linkNum2= maxWebDataLinkNum;
			maxWebDataLinkNum = maxWebDataLinkNum+1;
			webDataLinkDAO.executeUpdate(connection,failureList,webDataLinkInsArgs,insWebDataLink);
			
			while (webDataLinkInsArgs.size()>2){
				webDataLinkInsArgs.remove(webDataLinkInsArgs.size()-1);
			}
		}
		
		if ((adhocReportStep3.getAlertKeyLevel()>=3) && (!("".equals(adhocReportStep3.getLevel3ReportLink())))){
			webDataLinkInsArgs.add(Integer.toString(maxWebDataLinkNum));
			webDataLinkInsArgs.add(getReportName(adhocReportStep3.getLevel3ReportLink(),connection,failureList));
			webDataLinkInsArgs.add(adhocReportStep3.getLevel3ReportLink());
			linkNum3= maxWebDataLinkNum;
			maxWebDataLinkNum = maxWebDataLinkNum+1;
			webDataLinkDAO.executeUpdate(connection,failureList,webDataLinkInsArgs,insWebDataLink);
			
			while (webDataLinkInsArgs.size()>2){
				webDataLinkInsArgs.remove(webDataLinkInsArgs.size()-1);
			}
		}
		
		if ((adhocReportStep3.getAlertKeyLevel()>=4) && (!("".equals(adhocReportStep3.getLevel4ReportLink())))){
			webDataLinkInsArgs.add(Integer.toString(maxWebDataLinkNum));
			webDataLinkInsArgs.add(getReportName(adhocReportStep3.getLevel4ReportLink(),connection,failureList));
			webDataLinkInsArgs.add(adhocReportStep3.getLevel4ReportLink());
			linkNum4= maxWebDataLinkNum;
			maxWebDataLinkNum = maxWebDataLinkNum+1;
			webDataLinkDAO.executeUpdate(connection,failureList,webDataLinkInsArgs,insWebDataLink);
			
			while (webDataLinkInsArgs.size()>2){
				webDataLinkInsArgs.remove(webDataLinkInsArgs.size()-1);
			}
		}
		
		if ((adhocReportStep3.getAlertKeyLevel()>=5) && (!("".equals(adhocReportStep3.getLevel5ReportLink())))){
			webDataLinkInsArgs.add(Integer.toString(maxWebDataLinkNum));
			webDataLinkInsArgs.add(getReportName(adhocReportStep3.getLevel5ReportLink(),connection,failureList));
			webDataLinkInsArgs.add(adhocReportStep3.getLevel5ReportLink());
			linkNum5= maxWebDataLinkNum;
			webDataLinkDAO.executeUpdate(connection,failureList,webDataLinkInsArgs,insWebDataLink);
			
		}
		
		int maxMouseOverNum = getMaxMouseOverNum(connection,failureList,adhocReportDefinition);
		maxMouseOverNum = maxMouseOverNum+1;
		
		int mouseOverNumPresnRule = maxMouseOverNum;
		//below variable is to reset the variable in the keys loop 
		int mouseOverNumPresnRuleTemp = mouseOverNumPresnRule;
		//INSERT MOUSE OVER LINKS
		mouseOverLinkInsArgs.add(Integer.toString(adhocReportDefinition.getPresnId()));
		mouseOverLinkInsArgs.add(Integer.toString(adhocReportDefinition.getCurrentSection()));
		
		if (!("".equals(adhocReportStep3.getLevel1MouseOverDescription()))){
			String description = adhocReportStep3.getLevel1MouseOverDescription();
			String tableName = description.substring(0, description.indexOf("~"));
			String tableKeyName = description.substring(description.indexOf("~")+1, description.lastIndexOf("~"));
			String tableKeyData = description.substring(description.lastIndexOf("~")+1);
			
			//2
			mouseOverLinkInsArgs.add(Integer.toString(maxMouseOverNum));
			maxMouseOverNum = maxMouseOverNum+1;
			//3
			mouseOverLinkInsArgs.add(tableKeyName);
			//4
			mouseOverLinkInsArgs.add(tableKeyData);
			//5
			mouseOverLinkInsArgs.add(tableName);
			
			mouseOverLinkDAO.executeUpdate(connection,failureList,mouseOverLinkInsArgs,insMouseOver);
			
			//remove the arguments so that it will not conflict in the next IF .
		
			while (mouseOverLinkInsArgs.size()>2){
				mouseOverLinkInsArgs.remove(mouseOverLinkInsArgs.size()-1);
			}
		}
		
		if (!("".equals(adhocReportStep3.getLevel2MouseOverDescription()))){
			String description = adhocReportStep3.getLevel2MouseOverDescription();
			String tableName = description.substring(0, description.indexOf("~"));
			String tableKeyName = description.substring(description.indexOf("~")+1, description.lastIndexOf("~"));
			String tableKeyData = description.substring(description.lastIndexOf("~")+1);
			
			//2
			mouseOverLinkInsArgs.add(Integer.toString(maxMouseOverNum));
			maxMouseOverNum = maxMouseOverNum+1;
			//3
			mouseOverLinkInsArgs.add(tableKeyName);
			//4
			mouseOverLinkInsArgs.add(tableKeyData);
			//5
			mouseOverLinkInsArgs.add(tableName);
			
			mouseOverLinkDAO.executeUpdate(connection,failureList,mouseOverLinkInsArgs,insMouseOver);
			
			//remove the arguments so that it will not conflict in the next if .
		
			while (mouseOverLinkInsArgs.size()>2){
				mouseOverLinkInsArgs.remove(mouseOverLinkInsArgs.size()-1);
			}
		}
		
		if (!("".equals(adhocReportStep3.getLevel3MouseOverDescription()))){
			String description = adhocReportStep3.getLevel3MouseOverDescription();
			String tableName = description.substring(0, description.indexOf("~"));
			String tableKeyName = description.substring(description.indexOf("~")+1, description.lastIndexOf("~"));
			String tableKeyData = description.substring(description.lastIndexOf("~")+1);
			
			//2
			mouseOverLinkInsArgs.add(Integer.toString(maxMouseOverNum));
			maxMouseOverNum = maxMouseOverNum+1;
			//3
			mouseOverLinkInsArgs.add(tableKeyName);
			//4
			mouseOverLinkInsArgs.add(tableKeyData);
			//5
			mouseOverLinkInsArgs.add(tableName);
			
			mouseOverLinkDAO.executeUpdate(connection,failureList,mouseOverLinkInsArgs,insMouseOver);
			
			//remove the arguments so that it will not conflict in the next IF .
		
			while (mouseOverLinkInsArgs.size()>2){
				mouseOverLinkInsArgs.remove(mouseOverLinkInsArgs.size()-1);
			}
		}
		
		if (!("".equals(adhocReportStep3.getLevel4MouseOverDescription()))){
			String description = adhocReportStep3.getLevel4MouseOverDescription();
			String tableName = description.substring(0, description.indexOf("~"));
			String tableKeyName = description.substring(description.indexOf("~")+1, description.lastIndexOf("~"));
			String tableKeyData = description.substring(description.lastIndexOf("~")+1);
			
			//2
			mouseOverLinkInsArgs.add(Integer.toString(maxMouseOverNum));
			maxMouseOverNum = maxMouseOverNum+1;
			//3
			mouseOverLinkInsArgs.add(tableKeyName);
			//4
			mouseOverLinkInsArgs.add(tableKeyData);
			//5
			mouseOverLinkInsArgs.add(tableName);
			
			mouseOverLinkDAO.executeUpdate(connection,failureList,mouseOverLinkInsArgs,insMouseOver);
			
			//remove the arguments so that it will not conflict in the next IF .
		
			while (mouseOverLinkInsArgs.size()>2){
				mouseOverLinkInsArgs.remove(mouseOverLinkInsArgs.size()-1);
			}
		}
		
		if (!("".equals(adhocReportStep3.getLevel5MouseOverDescription()))){
			String description = adhocReportStep3.getLevel5MouseOverDescription();
			String tableName = description.substring(0, description.indexOf("~"));
			String tableKeyName = description.substring(description.indexOf("~")+1, description.lastIndexOf("~"));
			String tableKeyData = description.substring(description.lastIndexOf("~")+1);
			
			//2
			mouseOverLinkInsArgs.add(Integer.toString(maxMouseOverNum));
			maxMouseOverNum = maxMouseOverNum+1;
			//3
			mouseOverLinkInsArgs.add(tableKeyName);
			//4
			mouseOverLinkInsArgs.add(tableKeyData);
			//5
			mouseOverLinkInsArgs.add(tableName);
			
			mouseOverLinkDAO.executeUpdate(connection,failureList,mouseOverLinkInsArgs,insMouseOver);
			
			//remove the arguments so that it will not conflict in the next IF .
		
			while (mouseOverLinkInsArgs.size()>2){
				insArgs.remove(mouseOverLinkInsArgs.size()-1);
			}
		}
		//END INSERT MOUSE OVER LINK
		
		int  adhocKeyListSize = adhocKeyList.size();
		
		for (int i=0;i<adhocKeyListSize;i++){
			mouseOverNumPresnRule = mouseOverNumPresnRuleTemp;
			AdhocKey adhocKey = (AdhocKey)adhocKeyList.get(i);
			//3
			insArgs.add(adhocKey.getTableName());
			//4
			insArgs.add(Integer.toString(adhocReportStep3.getAlertKeyLevel()));

			if (adhocReportStep3.getAlertKeyLevel()>=1){
				//5
				insArgs.add(adhocKey.getKey1());
				//6 
				insArgs.add(adhocReportStep3.getLevel1ColumnHeaderName());
				
				if ("".equals(adhocReportStep3.getLevel1MouseOverDescription())){
					//7
					insArgs.add("");
					//8
					insArgs.add("0");
				}else{
					//7
					insArgs.add("Y");
					insArgs.add(Integer.toString(mouseOverNumPresnRule));
					mouseOverNumPresnRule = mouseOverNumPresnRule+1;
				}
			}else{
				insArgs.add("");
				insArgs.add("");
				insArgs.add("");
				insArgs.add("0");
			}
		
			if (adhocReportStep3.getAlertKeyLevel()>=2){
				//9
				insArgs.add(adhocKey.getKey2());
				//10 
				insArgs.add(adhocReportStep3.getLevel2ColumnHeaderName());
				
				//12
				if ("".equals(adhocReportStep3.getLevel2MouseOverDescription())){
					//11
					insArgs.add("");
					insArgs.add("0");
				}else{
					//11	
					insArgs.add("Y");
					insArgs.add(Integer.toString(mouseOverNumPresnRule));
					mouseOverNumPresnRule = mouseOverNumPresnRule+1;
				}
			}else{
				insArgs.add("");
				insArgs.add("");
				insArgs.add("");
				insArgs.add("0");
			}
			
			if (adhocReportStep3.getAlertKeyLevel()>=3){
				//13
				insArgs.add(adhocKey.getKey3());
				//14 
				insArgs.add(adhocReportStep3.getLevel3ColumnHeaderName());
				
				if ("".equals(adhocReportStep3.getLevel3MouseOverDescription())){
					//15	
					insArgs.add("");
					//16
					insArgs.add("0");
				}else{
					//15
					insArgs.add("Y");
					insArgs.add(Integer.toString(mouseOverNumPresnRule));
					mouseOverNumPresnRule = mouseOverNumPresnRule+1;
				}
			}else{
				insArgs.add("");
				insArgs.add("");
				insArgs.add("");
				insArgs.add("0");
			}
			if (adhocReportStep3.getAlertKeyLevel()>=4){
				//17
				insArgs.add(adhocKey.getKey4());
				//18 
				insArgs.add(adhocReportStep3.getLevel4ColumnHeaderName());
				
				if ("".equals(adhocReportStep3.getLevel4MouseOverDescription())){
					//19
					insArgs.add("");
					//20
					insArgs.add("0");
				}else{
					insArgs.add("Y");
					insArgs.add(Integer.toString(mouseOverNumPresnRule));
					mouseOverNumPresnRule = mouseOverNumPresnRule+1;
				}
			}else{
				insArgs.add("");
				insArgs.add("");
				insArgs.add("");
				insArgs.add("0");
			}
			
			if (adhocReportStep3.getAlertKeyLevel()>=5){
				//21
				insArgs.add(adhocKey.getKey5());
				//22 
				insArgs.add(adhocReportStep3.getLevel5ColumnHeaderName());
				
				//24
				if ("".equals(adhocReportStep3.getLevel5MouseOverDescription())){
					insArgs.add("");
					insArgs.add("0");
				}else{
					insArgs.add("Y");
					insArgs.add(Integer.toString(mouseOverNumPresnRule));
					mouseOverNumPresnRule = mouseOverNumPresnRule+1;
				}
			}else{
				insArgs.add("");
				insArgs.add("");
				insArgs.add("");
				insArgs.add("0");
			}
			
			/*
			 * code added by AT1862 on 8th june 2006 for report link  in step3 
			 */
	
			//25 & 26
			if ((adhocReportStep3.getAlertKeyLevel()>=1) && (!("".equals(adhocReportStep3.getLevel1ReportLink())))){
				insArgs.add("Y");
				insArgs.add(Integer.toString(linkNum1));
				
			}else{
				insArgs.add("");
				insArgs.add("0");
			}
			
			//27 & 28
			if ((adhocReportStep3.getAlertKeyLevel()>=2) && (!("".equals(adhocReportStep3.getLevel2ReportLink())))){
				insArgs.add("Y");
				insArgs.add(Integer.toString(linkNum2));
			}else{
				insArgs.add("");
				insArgs.add("0");
			}
			
			//29 & 30
			if ((adhocReportStep3.getAlertKeyLevel()>=3) && (!("".equals(adhocReportStep3.getLevel3ReportLink())))){
				insArgs.add("Y");
				insArgs.add(Integer.toString(linkNum3));
				
			}else{
				insArgs.add("");
				insArgs.add("0");
			}			
			
			//31 & 32
			if ((adhocReportStep3.getAlertKeyLevel()>=4) && (!("".equals(adhocReportStep3.getLevel4ReportLink())))){
				insArgs.add("Y");
				insArgs.add(Integer.toString(linkNum4));
			}else{
				insArgs.add("");
				insArgs.add("0");
			}
			
			//33 & 34
			if ((adhocReportStep3.getAlertKeyLevel()>=5) && (!("".equals(adhocReportStep3.getLevel5ReportLink())))){
				insArgs.add("Y");
				insArgs.add(Integer.toString(linkNum5));
			}else{
				insArgs.add("");
				insArgs.add("0");
			}
			
			presnKey1HeaderDAO.executeUpdate(connection,failureList,insArgs,insAlertRulePresnRule);

			//remove the arguments so that it will not conflict in the next iteration .
			while (insArgs.size()>3){
				insArgs.remove(insArgs.size()-1);
			}
		}		
	}

	/**
	 * Private method to get Number Of BillRound Tables .
	 * @param tableList
	 * @param tblSubsysId
	 * @param region
	 * @return int
	 */
	public int getNbrOfBillRndTables(List tableList,String tblSubsysId,String region){
		
		int tableListSize = tableList.size();
		List uniqueTableList =  new ArrayList();
		for (int i=0;i<tableListSize;i++)
		{
			List dataTblDdlBeanList = StaticDataLoader.getDataTblDdlByAlertProcTbl(tblSubsysId, tableList.get(i).toString(), region);
			int dataTblDdlBeanListSize = dataTblDdlBeanList.size();
			for (int j=0;j<dataTblDdlBeanListSize;j++)
			{
				DataTblDdlBean dataTblDdlBean  =(DataTblDdlBean) dataTblDdlBeanList.get(j);
				if (dataTblDdlBean.getTblBillRndDdlName()!=null){
					if (!(uniqueTableList.contains(dataTblDdlBean.getAlertProcTbl()))){
						uniqueTableList.add(dataTblDdlBean.getAlertProcTbl());
					}
				}
			}
		}
	
		return (uniqueTableList.size());
	}
	
	/**
	 * Private method to get String Of BillRound Tables .
	 * @param region
	 * @return String
	 */
	public String getBillRndTableStr(String region) {
    	String billRndTableStr = "" ; 
    	List billRndTableList = StaticDataLoader.getDataTblDdlForBillRndNotNull(region);
    	List uniqueTableList =  new ArrayList();
    	
    	int billRndTableListSize = billRndTableList.size() ; 
      	
    	for (int i=0;i<billRndTableListSize;i++)
		{
			DataTblDdlBean dataTblDdlBean  =(DataTblDdlBean) billRndTableList.get(i);
			if (dataTblDdlBean.getTblBillRndDdlName()!=null){
				if (!(uniqueTableList.contains(dataTblDdlBean.getAlertProcTbl()))){
					uniqueTableList.add(dataTblDdlBean.getAlertProcTbl());
					if (billRndTableStr.equals("")) {
						billRndTableStr += dataTblDdlBean.getAlertProcTbl() ;
					}else {
						billRndTableStr += "~" + dataTblDdlBean.getAlertProcTbl() ;
					}
				}
			}
		}

    	return billRndTableStr ; 
    }
	
	/**
	 * Private method to get Number Of Number Of ProcDateTables.
	 * @param tableList
	 * @param tblSubsysId
	 * @param region
	 * @return int
	 */
	public int getNbrOfProcDateTables(List tableList,String tblSubsysId,String region){
		
		List uniqueProcDateTables = new ArrayList();
		int tableListSize = tableList.size();
		for (int i=0;i<tableListSize;i++){
			List dataTblDdlBeanList = StaticDataLoader.getDataTblDdlByAlertProcTbl(tblSubsysId, tableList.get(i).toString(), region);
		
			int dataTblDdlBeanListSize = dataTblDdlBeanList.size();
			for (int j=0;j<dataTblDdlBeanListSize;j++){
				DataTblDdlBean dataTblDdlBean  =(DataTblDdlBean) dataTblDdlBeanList.get(j);
				
				if (dataTblDdlBean.getTblProcDateDdlName()!=null){
					if (!(uniqueProcDateTables.contains(dataTblDdlBean.getAlertProcTbl()))){
						uniqueProcDateTables.add(dataTblDdlBean.getAlertProcTbl());
					}
				}
			}			
		}
		return (uniqueProcDateTables.size());
	}
	
	/**
	 * Private method to get the number of file sequence tables
	 * @param tableList
	 * @param tblSubsysId
	 * @param region
	 * @return int
	 */
	private int getNbrOfFileSequenceTables(List tableList,String tblSubsysId,String region) {
		List fileSequenceTables = new ArrayList();
		int tableListSize = tableList.size();
		for (int i=0;i<tableListSize;i++){
			List dataTblDdlBeanList = StaticDataLoader.getDataTblDdlByAlertProcTbl(tblSubsysId, tableList.get(i).toString(), region);
			int dataTblDdlBeanListSize = dataTblDdlBeanList.size();
			for (int j=0;j<dataTblDdlBeanListSize;j++){
				DataTblDdlBean dataTblDdlBean  =(DataTblDdlBean) dataTblDdlBeanList.get(j);
			
				if (dataTblDdlBean.getTblFileSeqNumDdlName()!=null){
					if (!(fileSequenceTables.contains(dataTblDdlBean.getAlertProcTbl()))){
						fileSequenceTables.add(dataTblDdlBean.getAlertProcTbl());
					}
				}
			}			
		}
		return (fileSequenceTables.size());
	}
	
	/**
	 * Private method to get whether a column is summable or not.
	 * @param tblSubsysId
	 * @param tableName
	 * @param columnName
	 * @param region
	 * @return String
	 */
	private String getSumInd(String tblSubsysId,String tableName,String columnName,String region) {
		List dataTblDdlBeanList = StaticDataLoader.getDataTblDdlByAlertProcTbl(tblSubsysId, tableName, region);
		String sumInd="";
		int dataTblDdlBeanListSize =  dataTblDdlBeanList.size();
		for (int j=0;j<dataTblDdlBeanListSize;j++){
			DataTblDdlBean dataTblDdlBean  =(DataTblDdlBean) dataTblDdlBeanList.get(j);
			if (dataTblDdlBean.getTblDdlName().equalsIgnoreCase(columnName)){
				if ((dataTblDdlBean.getTblDdlDataType().equals("4")) || (dataTblDdlBean.getTblDdlDataType().equals("2")) || (dataTblDdlBean.getTblDdlDataType().equals("D"))){
					sumInd="N";
				}
				break;
			}
		}				
		return (sumInd);
	}
	
	/**
	 * Private method to get max mouse over num.
	 * @param connection
	 * @param failureList
	 * @param adhocReportDefinition
	 * @return int
	 */
	private int getMaxMouseOverNum(Connection connection,List failureList,
			AdhocReportDefinition adhocReportDefinition) {	
		
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		List args = new ArrayList();
		args.add(Integer.toString(adhocReportDefinition.getPresnId()));
		args.add(Integer.toString(adhocReportDefinition.getCurrentSection()));
		
		int maxMouseOverNum=0;
		try{
			MessageFormat mf = new MessageFormat(selMaxMon);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			
			while(rs.next()){
				maxMouseOverNum = rs.getInt(1);
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
			
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		return (maxMouseOverNum);
	}
	
	/**
	 * Private method to get max web data link  num.
	 * @param connection
	 * @param failureList
	 * @param adhocReportDefinition
	 * @return int
	 */
	private int getMaxWebDataLinkNum(Connection connection,List failureList,
			AdhocReportDefinition adhocReportDefinition) {
				
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		List args = new ArrayList();
		args.add(Integer.toString(adhocReportDefinition.getPresnId()));
		args.add(Integer.toString(adhocReportDefinition.getCurrentSection()));
		
		int maxWebDataLinkNum=0;
		try {
			MessageFormat mf = new MessageFormat(selMaxwebDataLink);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			
			while(rs.next()){
				maxWebDataLinkNum = rs.getInt(1);
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
			
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		return (maxWebDataLinkNum);
	}
	
	/**
	 * Private method to check whether if the report name entered exist or not - used in step1 .
	 * @param connection
	 * @param args
	 * @param failureList
	 * @param adhocReportDefinition
	 * @return true/false
	 */
	public boolean isDuplicateReportName(Connection connection,List args,List failureList,AdhocReportDefinition adhocReportDefinition){
		
		AdhocMainPageService adhocService = new AdhocMainPageService();
		// Get the existing adhoc reports and store them in arraylist
		List result = adhocService.getReportNameList(connection,failureList,args) ;
		String reportNameFromUser=null;
		reportNameFromUser = adhocReportDefinition.getPresnDesc();
		
		int resultListSize= result.size();
		for (int i=0;i<resultListSize;i++){
			PresnId presnId = (PresnId)result.get(i);
			if (presnId.getPresnId()!=-1 && presnId.getPresnId()!=-2){
				if (reportNameFromUser.toUpperCase().trim().equals(presnId.getPresnIdDesc().toUpperCase().trim())){
					return(true);
				}
			}	
		}
		return (false);
	}
	
	/**
	 * Private method to access PresnCalcElemDAO and to get PRESN_CALC_FORMULA
	 * @param connection
	 * @param failures
	 * @param args
	 * @return String
	 */
	private String getCalcFormula(Connection connection,List failures,List args){
		PresnCalcElemDAO presnCalcElemDAO = new PresnCalcElemDAO();
		List presnCalcElemList = presnCalcElemDAO.get(connection,failures,args,getCalc);
		String calcFormula="";
		int  presnCalcElemListSize = presnCalcElemList.size();
		
		for (int i=0;i<presnCalcElemListSize;i++){
			PresnCalcElem presnCalcElem = (PresnCalcElem) presnCalcElemList.get(i);
			calcFormula = presnCalcElem.getCalcElemFormula();
		}
		return (calcFormula);	
	}
	
	/**
	 * Private method to get proc_date_ddl_name
	 * @param presnTblName
	 * @param region
	 * @return String
	 */
	private String getProcDateDdlName(String presnTblName, String region){
		String procDateDdlName="";
		List dataTblDdlList = new ArrayList();
		dataTblDdlList = StaticDataLoader.getDataTblDdlByAlertProcTbl(presnTblName, region);
		int dataTblDdlListSize = dataTblDdlList.size();
		for (int i=0;i<dataTblDdlListSize;i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblDdlList.get(i);
			if (dataTblDdlBean!=null){
				if (dataTblDdlBean.getTblDdlName()!=null){
					procDateDdlName = dataTblDdlBean.getTblProcDateDdlName();
					break;
				}
			}
		}
		return (procDateDdlName);
	}
	
	/**
	 * This method is called when the user click on "test" or "test & Save" button is clicked
	 * @param connection
	 * @param failureList
	 * @param adhocReportDefinition
	 * @param progressBar
	 * @param region
	 */
	public void test(Connection connection, List failureList, AdhocReportDefinition adhocReportDefinition, ProgressBar progressBar, String region){
		
		/*
		 * Call the respective method to insert into RABC_PRESN_HEADER table
		 */
		
		if (adhocReportDefinition.getPresnId()==0){
			int presnId = getNewPresnId(connection,failureList);
			
			adhocReportDefinition.setPresnId(presnId);
		}else if (adhocReportDefinition.isCopyReport()){
			int presnId = getNewPresnId(connection,failureList);
			adhocReportDefinition.setPresnId(presnId);
		}
		progressBar.setProgressPercent(20);
		
		insertPresnId(connection,failureList,adhocReportDefinition,region);
		progressBar.setProgressPercent(30);
		insertPresnHeader(connection,failureList,adhocReportDefinition);
		progressBar.setProgressPercent(40);
		insertWebHeader(connection,failureList,adhocReportDefinition);
		progressBar.setProgressPercent(50);
		
		if ((!("".equals(adhocReportDefinition.getUserDirectoryHidden()))) && (!("null").equals(adhocReportDefinition.getUserDirectoryHidden()))){
			// Check here the direcory exists in menu_index 
			// if yes set PresnSeqNumber for it else create new direcory and
			
			int presnSeqNumber ; 
			presnSeqNumber = checkDirectoryExists(connection,failureList,adhocReportDefinition) ;
			if (presnSeqNumber == -1 ) {
				insertMenuIndexUserDirectory(connection,failureList,adhocReportDefinition);
			}else {
				//adhocReportDefinition.setPresnSeqNumber(Integer.parseInt(adhocReportDefinition.getUserDirectorySelected())) ;
				adhocReportDefinition.setPresnSeqNumber(presnSeqNumber) ;
			}
		}
		insertMenuIndex(connection,failureList,adhocReportDefinition);
		deleteMenuIndexUserDirectory(connection,failureList,adhocReportDefinition);
		progressBar.setProgressPercent(60);
		insertUpdateGroup(connection,failureList,adhocReportDefinition);
		progressBar.setProgressPercent(70);
		insertKey1Header(connection,failureList,adhocReportDefinition);
		insertAlertRulePresnElem(connection,failureList,adhocReportDefinition,region);
		progressBar.setProgressPercent(80);
		
		insertAlertRulePresnRule(connection,failureList,adhocReportDefinition,region);
		progressBar.setProgressPercent(90);
		//set copy report to false so that it will not copy again if the user click on the 
		//save more than once
		
		adhocReportDefinition.setCopyReport(false);
	}
	
	/**
	 * Thos method is used to delete the report section if the user unchek the checkbox in step2 
	 * @param connection
	 * @param delArgs
	 * @param failureList
	 */
	public void deleteReportSection(Connection connection, List delArgs,List failureList){
		PresnIdDAO presnIdDAO= new PresnIdDAO();
		presnIdDAO.executeUpdate(connection,failureList,delArgs,delReport);
	}
	
	/**
	 * This method is used to enable/disable the step3 elements depending upon the report type
	 * @param adhocReportDefinition
	 * @param failureList
	 * @param region
	 */
	public void  enableDisableStep3FormElements(AdhocReportDefinition adhocReportDefinition,List failureList,String region){
		String isFileSequenceIndicatorDisabled="N";
		String isLayout1Disabled="N";
		String isLayout2Disabled="N";
		String isLayout3Disabled="N";
		String isLayout4Disabled="N";
		String isReportDurationDisabled="N";
		
		AdhocReportStep3 adhocReportStep3 =((AdhocReportStep3)adhocReportDefinition.getAdhocReportStep3List().get(adhocReportDefinition.getSectionIndex()));
	
		List tableList = adhocReportStep3.getTableList(); 
		
		int nbrOfFileSequnceIndicator=0;
		
		if (adhocReportDefinition.getSectionIndex()==0){
			if ("S".equals(adhocReportDefinition.getRptType().trim())){
				isLayout3Disabled="Y";
				isLayout4Disabled="Y";
				isReportDurationDisabled="Y";
			}else if (!("M".equals(adhocReportDefinition.getRptType().trim()))){
				isLayout3Disabled="Y";
				isReportDurationDisabled="Y";
			}
		}else{
			isLayout1Disabled="Y";
			isLayout2Disabled="Y";
			isLayout3Disabled="Y";
			isLayout4Disabled="Y";
			isReportDurationDisabled="Y";
			
			AdhocReportStep3 firstSectionAdhocReportStep3 =((AdhocReportStep3)adhocReportDefinition.getAdhocReportStep3List().get(0));
			int firstSectionSelectedLayout = firstSectionAdhocReportStep3.getSelectedLayout();
			adhocReportStep3.setSelectedLayout(firstSectionSelectedLayout);
		}
		
		nbrOfFileSequnceIndicator = getNbrOfFileSequenceTables(tableList,adhocReportDefinition.getDataNode(),region);
		if (nbrOfFileSequnceIndicator==tableList.size()){
			if ("D".equals(adhocReportDefinition.getRptType().trim())){
				isFileSequenceIndicatorDisabled="N";
			}else{
				isFileSequenceIndicatorDisabled="Y";
			}	
		}else{
			isFileSequenceIndicatorDisabled="Y";
		}
		
		adhocReportStep3.setIsFileSequenceIndicatorDisabled(isFileSequenceIndicatorDisabled);
		adhocReportStep3.setIsLayout1Disabled(isLayout1Disabled);
		adhocReportStep3.setIsLayout2Disabled(isLayout2Disabled);
		adhocReportStep3.setIsLayout3Disabled(isLayout3Disabled);
		adhocReportStep3.setIsLayout4Disabled(isLayout4Disabled);
		adhocReportStep3.setIsReportDurationDisabled(isReportDurationDisabled);
	}
	
	/**
	 * This method is used to find out to which group the user belongs
	 * @param connection
	 * @param args
	 * @param failureList
	 * @return String
	 */
	public String getPermissionAdhocReport(Connection connection, List args,List failureList) {
		String hasPermission="N";
		//args[0] is logged in user id 
		//args[1] is function id , like "UR" for update report  
		//args[2] is alert group   
		//find out  to which group the user belongs 
		
		AlertGroupUserDAO alertGroupUserDAO = new AlertGroupUserDAO();
		List alertGroupUserList = new ArrayList(); 
		alertGroupUserList = alertGroupUserDAO.get(connection,failureList,args,alertGrpUser);
		
		if (alertGroupUserList!=null){
			int alertGroupUserListSize=alertGroupUserList.size();
			if (alertGroupUserListSize>0){
				for (int i=0;i<alertGroupUserListSize;i++){
					AlertGroupUser alertGroupUser = (AlertGroupUser)alertGroupUserList.get(i);
					String userGroup = alertGroupUser.getAlertGrp();
					args.add(userGroup);
				
					//find whether the user has the permission to do the operation 
					AlertGroupFunctDAO alertGroupFunctDAO  = new AlertGroupFunctDAO();  
					List alertGroupFunctList  = alertGroupFunctDAO.get(connection,failureList,args,alertGrpFunct);
					if (alertGroupFunctList!=null){
						int alertGroupFunctListSize = alertGroupFunctList.size();
						if (alertGroupFunctListSize>0){
							hasPermission="Y";
							break;
						}
					}
					//remove the argument from the list , so that it add to the position 2
					//in the next iteration
					args.remove(2);
				}	
			}
		}
		return (hasPermission);
	}
	
	/**
	 * This method is used to get the token i.e. function name from the passed string
	 * @param X
	 * @return List
	 */
	public List getToken(String X) {
		
		X = X.replaceAll("texttonumber", "to_number") ;  
		
		X = X.replaceAll("numbertotext", "to_char") ;
		
		String tempStr = X;
		String token = "";
		String remainStr = "";
		String finalString = "";
		String previousToken ="";
		int currDelimiter = 0;
		String lastDelimeter,nextDelimeter;
		String x1 ;
		String x2 = "" ;
		String x3 ;
		boolean flag = true;
		String previousIsText;
		List tokenArray = new ArrayList();
		int itrcont  = 0 ; 
		int istext = 0 ;
		for (int l= 0 ; l<=X.length()-1 ; l++) {
			
			if (X.charAt(l) == '(' )
				itrcont = itrcont + 1 ; 
			
			if (X.charAt(l) == ')' )
				itrcont = itrcont + 1 ; 
				
			if (X.charAt(l) == '/' )
				itrcont = itrcont + 1 ; 
				
			if (X.charAt(l) == '-' )
				itrcont = itrcont + 1 ; 
			
			if (X.charAt(l) == '+' )
				itrcont = itrcont + 1 ; 
			
			if (X.charAt(l) == '*' )
				itrcont = itrcont + 1 ; 	
			
			if (X.charAt(l) == ',' )
				itrcont = itrcont + 1 ; 
		}	
		if (itrcont > 0 ) {
			for (int j = 1 ; j<=itrcont ; j++ ) {  
				nextDelimeter = getCurrentDelim(tempStr) ;
	
				token = tempStr.substring(currDelimiter,tempStr.indexOf(nextDelimeter)) ;
				
				remainStr = tempStr.substring((tempStr.indexOf(nextDelimeter) + 1), tempStr.length()) ;
				
				x1 =  token;
			  	x2 = "" ;
				x3 = previousToken;
				flag = false;
				if ( (x1.matches("chr")) || (x1.matches("concat")) || (x1.matches("length") ) || (x1.matches("lower") ) || (x1.matches("upper") ) || (x1.matches("substr") ) || (x1.matches("trim") ) || (x1.matches("ltrim") ) || (x1.matches("rtrim") ) || (x1.matches("to_char") ) || (x1.matches("to_number") ) || (x1.matches("avg") ) || (x1.matches("count") ) || (x1.matches("max") ) || (x1.matches("min") ) || (x1.matches("stddev") )) {
					istext = 1 ;
				} else {
					istext = 0 ;
				}
				
				if (!isNumeric(x1) && (!x1.matches("abs") ) && (!x1.matches("acos") ) && (!x1.matches("atan") ) && (!x1.matches("asin") ) && (!x1.matches("exp") ) && (!x1.matches("log") ) && (!x1.matches("mod") ) && (!x1.matches("round") ) && (!x1.matches("sign") ) && (!x1.matches("sqrt") ) && (!x1.matches("trunc") ) && (!x1.matches("avg") ) && (!x1.matches("stddev") ) && (!x1.matches("max") ) && (!x1.matches("min") ) && (!x1.matches("count") ) && (!x1.matches("char") ) && (!x1.matches("concatenate") ) && (!x1.matches("length") ) && (!x1.matches("lower")  ) && (!x1.matches("upper") ) && (!x1.matches("substr") ) && (!x1.matches("trim") ) && (!x1.matches("left") ) && (!x1.matches("Right") ) && (!x1.matches("to_char") ) && (!x1.matches("to_num") ) && (!x1.matches("Sum") ) ) {	
					if (istext!=1) {
						flag = true;
					} 
				}else {
					flag = false;
				}
	
				if (flag ) {
					//X2 = "Sum("+x1+")" ;
					finalString = finalString + token + "$ " ;
				} 
	
				lastDelimeter = nextDelimeter;
				
				 if (!"".equals(token)) {
				 	previousToken = token;
				 }
				 tempStr = remainStr;
			 }// for 	
		}else {
			finalString = "Sum("+tempStr+")$ " ;
		}
		StringTokenizer finalStringTokenizer = new StringTokenizer(finalString,"$ ");
		while (finalStringTokenizer.hasMoreTokens()) {
			tokenArray.add(finalStringTokenizer.nextToken());
		}
		return tokenArray ; 	
	}
	
	/**
	 * This method is used to get the current delimeter character from the passed String. Used for function tree in calculation screen
	 * @param str
	 * @return String
	 */
	public String getCurrentDelim(String str) {
		String currDelimeter = ""; 
		for (int i = 0 ; i<= (str.length())-1 ; i++) {
			if (str.charAt(i) == '(') {
				currDelimeter = "(" ; 
				break ;
			}
			if (str.charAt(i) == ')' ) {
				currDelimeter = ")" ; 
				break ;
			}
			if (str.charAt(i) == '/' ) {
				currDelimeter = "/" ; 
				break ;
			}
			if (str.charAt(i) == '-'  ) {
				currDelimeter = "-" ; 
				break ;
			}
			if (str.charAt(i) == '+' ) {
				currDelimeter = "+" ; 
				break ;
			}
			if (str.charAt(i) == '*' ) {
				currDelimeter = "*" ; 
				break ;
			}
			
			if (str.charAt(i) == ',' ) {
				currDelimeter = "," ; 
				break ;
			}
		}
		return currDelimeter ;
	}
	
	/**
	 * Private method used to get table key data from MOUSE_OVER_TBL
	 * @param tableName
	 * @param region
	 * @return String
	 */
	private String getMouseOverTblTableKeyDataByTblName(String tableName, String region){
		List mouseOverList = StaticDataLoader.getMouseOverList(region);
		String tableKeyData="";
		
		int mouseOverListSize = mouseOverList.size();
		for (int i=0;i<mouseOverListSize;i++){
			PickList mouseOverPickList = (PickList) mouseOverList.get(i);
			if (mouseOverPickList.getKey().equalsIgnoreCase(tableName)){
				tableKeyData = mouseOverPickList.getValue3();
				break;
			}
		}
		return (tableKeyData);
	}
		
	/**
	 * Private method is used to get the table key name from Mouse_Over_Tbl
	 * @param tableName
	 * @param region
	 * @return String
	 */
	private String getMouseOverTblTableKeyNameByTblName(String tableName, String region){
		List mouseOverList = StaticDataLoader.getMouseOverList(region);
		String tableKeyName="";
		int mouseOverListSize = mouseOverList.size();
		for (int i=0;i<mouseOverListSize;i++){
			PickList mouseOverPickList = (PickList) mouseOverList.get(i);
			if (mouseOverPickList.getKey().equalsIgnoreCase(tableName)){
				tableKeyName = mouseOverPickList.getValue2();
				break;
			}
		}
		return (tableKeyName);
	}
	
	 /**
	 * Private method to check the value is numeric or not 
	 * @param tmpQryColVal
	 * @return true/false 
	 */
	private boolean isNumeric(String tmpQryColVal) {
	  
	 	if (tmpQryColVal == null )  {  return false ;}
	 	if ("".equals(tmpQryColVal))  { return true;}
	  try {
	  	Double tmpValue = new Double(tmpQryColVal);
	  	if (tmpValue.doubleValue() != 0) return true;
	  	
	  } catch (NumberFormatException e) {
	  	return false;
	  }
	  	return false;
	 }
	
	 /**
	 * Private method used to get the report name  
	 * @param rptId
	 * @param connection
	 * @param failureList
	 * @return String
	 */
	private String getReportName(String rptId,Connection connection,List failureList){
	 	List PresnIdargs = new ArrayList();
	 	String presnDesc = "";
		PresnIdargs.add("");
		PresnIdargs.add(rptId);
		List presnIdList =  getPresenDetails(connection,failureList,PresnIdargs) ;
		if (presnIdList!=null){
			PresnId presnId = (PresnId)presnIdList.get(0);
			presnDesc = presnId.getPresnIdDesc();
		}
	 	return (presnDesc);
	 }
	 
	 /**
	 * Method to get the currently active section numbers for selected adhoc report.  
	 * @param connection
	 * @param adhocReportDefinition
	 * @param failureList
	 * @param args
	 * @return String
	 */
	public String getActiveSectionStr(Connection connection,AdhocReportDefinition adhocReportDefinition,List failureList,List args) {
	 	String selectSQL = getActiveSectionNumbers ;
		int currSecNbr = 1 ;
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		String activeSectionNbrStr = "" ; 
		try {
			MessageFormat mf = new MessageFormat(selectSQL);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			while(rs.next()){
				currSecNbr = rs.getInt(1) ;
				activeSectionNbrStr = activeSectionNbrStr + currSecNbr + "~" ;
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
	 	return activeSectionNbrStr ; 
	 }
	 
	 /**
	 * Method to get the entered key headers in step 3 - used for key validations.   
	 * @param adhocReportDefinition
	 * @param failureList
	 * @param args
	 * @return String
	 */
	public String getkeyHeaderStr(AdhocReportDefinition adhocReportDefinition,List failureList,List args) {
	 	
	 	String key1Header="null";
	 	String key2Header="null";
	 	String key3Header="null";
	 	String key4Header="null";
	 	String key5Header="null";
	
	 	for (int i=(adhocReportDefinition.getSectionIndex() - 1);i>=0;i--){
	 		String key1HeaderNew  = ((AdhocReportStep3)adhocReportDefinition.getAdhocReportStep3List().get(i)).getLevel1ColumnHeaderName();
	 		String key2HeaderNew  = ((AdhocReportStep3)adhocReportDefinition.getAdhocReportStep3List().get(i)).getLevel2ColumnHeaderName();
	 		String key3HeaderNew  = ((AdhocReportStep3)adhocReportDefinition.getAdhocReportStep3List().get(i)).getLevel3ColumnHeaderName();
	 		String key4HeaderNew  = ((AdhocReportStep3)adhocReportDefinition.getAdhocReportStep3List().get(i)).getLevel4ColumnHeaderName();
	 		String key5HeaderNew  = ((AdhocReportStep3)adhocReportDefinition.getAdhocReportStep3List().get(i)).getLevel5ColumnHeaderName();
	 		
	 		if ((key1HeaderNew!=null)&&(!"".equals(key1HeaderNew))&& (!key1Header.equals(key1HeaderNew))){
	 			key1Header = key1HeaderNew;
	 		}
	 		
	 		if ((key2HeaderNew!=null)&&(!"".equals(key2HeaderNew))&& (!key2Header.equals(key2HeaderNew))){
	 			key2Header = key2HeaderNew;
	 		}
	 		
	 		if ((key3HeaderNew!=null)&&(!"".equals(key3HeaderNew))&& (!key3Header.equals(key3HeaderNew))){
	 			key3Header = key3HeaderNew;
	 		}
	 		if ((key4HeaderNew!=null)&&(!"".equals(key4HeaderNew))&& (!key4Header.equals(key4HeaderNew))){
	 			key4Header = key4HeaderNew;
	 		}
	 		
	 		if ((key5HeaderNew!=null)&&(!"".equals(key5HeaderNew))&& (!key5Header.equals(key5HeaderNew))){
	 			key5Header = key5HeaderNew;
	 		}
	 	}
	 	String keyHeaderStr=key1Header+"~"+key2Header+"~"+key3Header+"~"+key4Header+"~"+key5Header;
	 	return(keyHeaderStr);
	}
	
	/**
	 * This method is called when the user clicks on "save" or "test & Save" button
	 * @param connection
	 * @param failureList
	 * @param adhocReportDefinition
	 */
	public void updatePresnId(Connection connection, List failureList, AdhocReportDefinition adhocReportDefinition){
		int presnId = adhocReportDefinition.getPresnId();
		int selectedLayout = ((AdhocReportStep3)adhocReportDefinition.getAdhocReportStep3List().get(adhocReportDefinition.getSectionIndex())).getSelectedLayout();
		List updateArgs = new ArrayList();
		updateArgs.add(Integer.toString(presnId));
		updateArgs.add(Integer.toString(selectedLayout));
		PresnIdDAO presnIdDAO= new PresnIdDAO();
		presnIdDAO.executeUpdate(connection,failureList, updateArgs, updateAdhocReport);
	}
}
