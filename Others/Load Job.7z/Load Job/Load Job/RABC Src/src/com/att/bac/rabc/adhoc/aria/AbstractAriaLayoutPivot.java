/*
 * Copyright  2002-2006 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.adhoc.aria;

import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;

import javax.naming.NamingException;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;

import com.att.bac.rabc.ConnectionManager;
import com.att.bac.rabc.DateUtil;
import com.att.bac.rabc.PagedForm;
import com.att.bac.rabc.RABCConstantsLists;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.StaticDataLoader;
import com.att.bac.rabc.adhoc.AdhocConstants;
import com.att.bac.rabc.adhoc.aria.pivot.AdhocPivotData;
import com.att.bac.rabc.adhoc.aria.pivot.CompositeKey;
import com.att.bac.rabc.adhoc.aria.pivot.DatedCompositeKey;
import com.att.bac.rabc.adhoc.aria.pivot.Page13PivotHTMLProcessor;
import com.att.bac.rabc.adhoc.aria.pivot.PivotCellRenderer;
import com.att.bac.rabc.adhoc.aria.pivot.PivotHeaderRenderer;
import com.att.bac.rabc.adhoc.aria.pivot.PivotPagingRenderer;
import com.att.bac.rabc.adhoc.aria.pivot.PivotReportRenderer;
import com.att.bac.rabc.adhoc.aria.pivot.PivotRowRenderer;
import com.att.bac.rabc.adhoc.aria.pivot.PivotTableRenderer;
import com.att.bac.rabc.adhoc.aria.pivot.PreviousDataLookup;
import com.att.bac.rabc.adhoc.rpt.AdhocRptDAO;
import com.att.bac.rabc.adhoc.rpt.AdhocRptDataTO;
import com.att.carat.util.JDBCUtil;
import com.sbc.bac.aria.ARIAColumn;
import com.sbc.bac.aria.ARIAPaging;
import com.sbc.bac.aria.ARIAReport;
import com.sbc.bac.aria.ARIAReportException;
import com.sbc.bac.aria.ARIAReportProcessor;

/**
 * Extends the base abstract class to provide a set of methods for "pivot" reports (i.e. a report where the columns
 * appear along the left side as rows, and the rows appear as columns).
 * 
 * 
 * <p>
 * <hr>
 * <h3>Release History</h3>
 * <p>
 * <ul>
 * 
 * <li>jb6494 Nov 16, 2006 Created class.
 * <li>JB6494 Dec 12, 2006 Modified to match new requirements
 * <li>JB6494 Mar 13, 2007 ML17: Daily computation not working, made guess to fix, changed maxint to 99999 to avoid rollover explosion
 * 
 * </ul>
 * <p>
 * 
 */
public abstract class AbstractAriaLayoutPivot implements AdhocConstants,PivotReportRenderer,PivotTableRenderer,PivotHeaderRenderer,PivotRowRenderer,PivotCellRenderer,PivotPagingRenderer {
    private static final String CLASS_NAME = AbstractAriaLayoutPivot.class.getName();
    private static Logger logger = Logger.getLogger(AbstractAriaLayoutPivot.class);
	private static final SimpleDateFormat MMDDYYYY_FORMAT	= new SimpleDateFormat("MM/dd/yyyy");
	private static final SimpleDateFormat YYYYMMDD_FORMAT	= new SimpleDateFormat("yyyyMMdd");

    protected ActionForm form;
    protected OutputStream os;
    protected String userid;
    
    protected AdhocRptDataTO dto;
    private AdhocRptDataTO dtoBase;
    private Connection connection;
    
    private static HashMap weekdayOptions = null;
    private int section;
    protected PreviousDataLookup prevData;
	private int noOfKeyColumns;
	private int noOfDataColumns;
	private int [] validColsIndexArray;
    private TreeMap adhocDataSetMap;
    private List pivotKeyList;
    boolean previousExists = false;
    private int totalDataSets;

    /**
     * Constructor to set basic attributes
     * @param form
     * @param os
     * @param userid
     */
    public AbstractAriaLayoutPivot(ActionForm form, OutputStream os, String userid) {
        super();
        this.form = form;
        this.os = os;
        this.userid = userid;
        this.adhocDataSetMap = new TreeMap();
        this.pivotKeyList = new ArrayList();
    }

    /**
     * Get the base DTO. This is the real one that interacts with the jsp.
     * 
     * @return
     */
    protected AdhocRptDataTO getDtoBase() {
        return dtoBase;
    }
    
    /**
     * Get the current section number
     * 
     * @return
     */
    protected int getSection() {
        return section;
    }

    /**
     * Set the DTO object
     * 
     * @param dto
     */
    protected void setDto(AdhocRptDataTO dto) {
        this.dto = dto;
    }

    /**
     * Set the base DTO.This is the real one that interacts with the jsp.
     * 
     * @param dto
     */
    protected void setDtoBase(AdhocRptDataTO dto) {
        dtoBase = dto;
        if (dto == null) {
            dto = dtoBase;
        }
    }


    /**
     * Set the current section number
     * 
     * @param section
     */
    protected void setSection(int section) {
        this.section = section;
    }
    
	/**
	 * @return the adhocDataSetMap
	 */
	public TreeMap getAdhocDataSetMap() {
		return adhocDataSetMap;
	}


	/**
	 * @param adhocDataSetMap the adhocDataSetMap to set
	 */
	public void setAdhocDataSetMap(TreeMap adhocDataSetMap) {
		this.adhocDataSetMap = adhocDataSetMap;
	}
	
	/**
	 * @return the noOfDataColumns
	 */
	public int getNoOfDataColumns() {
		return noOfDataColumns;
	}

	/**
	 * @param noOfDataColumns the noOfDataColumns to set
	 */
	public void setNoOfDataColumns(int noOfDataColumns) {
		this.noOfDataColumns = noOfDataColumns;
	}

	/**
	 * @return the noOfKeyColumns
	 */
	public int getNoOfKeyColumns() {
		return noOfKeyColumns;
	}

	/**
	 * @param noOfKeyColumns the noOfKeyColumns to set
	 */
	public void setNoOfKeyColumns(int noOfKeyColumns) {
		this.noOfKeyColumns = noOfKeyColumns;
	}

	/**
	 * @return the validColsIndexArray
	 */
	public int[] getValidColsIndexArray() {
		return validColsIndexArray;
	}

	/**
	 * @param validColsIndexArray the validColsIndexArray to set
	 */
	public void setValidColsIndexArray(int[] validColsIndexArray) {
		this.validColsIndexArray = validColsIndexArray;
	}

	/**
	 * @return the totalDataSets
	 */
	public int getTotalDataSets() {
		return totalDataSets;
	}
	
	/**
	 * @param totalDataSets the totalDataSets to set
	 */
	public void setTotalDataSets(int totalDataSets) {
		this.totalDataSets = totalDataSets;
	}

	/**
	 * Since the map of data objects is prepared for each section, clear all values for every section run
	 */
	public void clear(){
		this.noOfKeyColumns = 0;
		this.noOfDataColumns = 0;
		
		ArrayList columnDataTypeList = dto.getColumnsDataTypeList();
		
		if (!columnDataTypeList.isEmpty()){
			int columnDataTypeListSize = columnDataTypeList.size();
			this.validColsIndexArray = new int[columnDataTypeListSize];
			int j=0;
			
			for (int i=0;i<columnDataTypeListSize;i++){
				String columnDataType = (String)columnDataTypeList.get(i);

				this.validColsIndexArray[j] = i;
				if ("C".equals(columnDataType)){
					this.noOfDataColumns++;
				} else {
					this.noOfKeyColumns++;
				}
				j++;
			}
		}
		
		this.adhocDataSetMap.clear();
		this.pivotKeyList.clear();
	}
	
    /**
     * Run the report 
     * 
     * @param reports
     * @param dto
     * @throws Exception
     */
    public abstract void execute(ARIAReportRABC[] reports, AdhocRptDataTO dto) throws Exception;

    /**
     * Get or create a connection. If the connection exists it will use it, otherwise it will create one.
     * 
     * @return
     * @throws SQLException
     * @throws NamingException
     */
    protected Connection getConnection() throws NamingException, SQLException {
        if (connection == null) {
            connection = ConnectionManager.getConnection(dtoBase.getRegion());
            logger.info("ADHOC REPORTS: Creating connection");
        }
        
        return connection;
    }
    
    /**
     * Close the connection
     */
    protected void closeConnection() {
    	JDBCUtil.closeConnection(connection);
    	connection = null;
 	    logger.info("ADHOC REPORTS: Closing connection");
    }

	/**
     * Create an Pivot processor and assign renderers
     * 
     * @param os
     * @return
     */
    protected Page13PivotHTMLProcessor createProcessor(OutputStream os) {
        Page13PivotHTMLProcessor processor = new Page13PivotHTMLProcessor(os);
        processor.setCellFormatter(this);
        processor.setHeaderRenderer(this);
        processor.setReportRenderer(this);
        processor.setRowRenderer(this);
        processor.setTableRenderer(this);
        processor.setPagingRenderer(this);
        processor.setShowPaging(Page13PivotHTMLProcessor.PAGING_AT_TOP);
        
        return processor;
    }
    
    /**
     * Method to create report filters e.g. date, timing, etc. This info is used in the JSP.
     * <p>
     * Legacy
     * 
     * @throws RABCException
     */
    protected void createReportFilters() throws RABCException {
        dtoBase = LayoutHelper.createReportFilters(dtoBase, weekdayOptions);
    }

    /**
	 * 
	 * @param connection
	 * @param report
	 * @throws Exception
	 */
	public void formAdhocDataSets(ARIAReport report,Page13PivotHTMLProcessor processor) throws Exception {
		// Get the connection 
		Connection connection = getConnection();
		
		// Get the SQL 
    	String sql = report.toSQL();

    	// Boolean to decide whether to continue
    	boolean execute = true;
    	
    	if (!isOutputExcel()){
    		// Method to form the unique keys
        	addKeyList(sql, report, processor);
        	
        	// Form the filtered SQl for the current page
        	if (!this.pivotKeyList.isEmpty()){
        		sql = appendWhere(sql);
        	} else {
        		execute = false;
        	}
    	}
    	
    	if (execute){
    		Statement statement = null;
            ResultSet rs = null;

            statement = connection.createStatement();
            rs = statement.executeQuery(sql);

            if (logger != null) {
                logger.debug("AdhocCustomLayout.formAdhocDataSets: ran SQL");
            }
             
            while (rs.next()){
            	AdhocPivotData adhocDataSet = buildAdhocDataSet(rs, report); 
            	AdhocPivotData existingAdhocDataSet = (AdhocPivotData) this.getAdhocDataSetMap().get(adhocDataSet);
            	 
            	if (existingAdhocDataSet != null){
            		for (int i=0;i<adhocDataSet.getDataColumnNames().length;i++){
            			for (int j=0;j<adhocDataSet.getDataColumnHeaderNames().length;j++){
            				if (adhocDataSet.getDataColumnValues()[i][j]!= Double.NEGATIVE_INFINITY && existingAdhocDataSet.getDataColumnValues()[i][j]!=Double.NEGATIVE_INFINITY) {
            					existingAdhocDataSet.getDataColumnValues()[i][j] += adhocDataSet.getDataColumnValues()[i][j];
            				} else if (adhocDataSet.getDataColumnValues()[i][j]!= Double.NEGATIVE_INFINITY && existingAdhocDataSet.getDataColumnValues()[i][j]==Double.NEGATIVE_INFINITY){
            					existingAdhocDataSet.getDataColumnValues()[i][j] = adhocDataSet.getDataColumnValues()[i][j];
            				}
            			}
            		}
            		this.getAdhocDataSetMap().put(existingAdhocDataSet, existingAdhocDataSet);
            	}else {
            		this.getAdhocDataSetMap().put(adhocDataSet, adhocDataSet);
            	}
            }   
            
            if (isOutputExcel()){
            	totalDataSets = this.getAdhocDataSetMap().size();
            }
            
            /*
             * Call the method to insert monthly total columns in case of BILL_DAY, RECORD AND DAILY Reports
             */
    		if (!TREND_TIME_MONTHLY.equals(dto.getPresnTrendTime()) && !TREND_TIME_YEARLY.equals(dto.getPresnTrendTime())){
    			if (dto.getAlertTimeValue()==-1 || (TREND_TIME_DAILY.equals(dto.getPresnTrendTime()) && dto.getAlertTimeValue()==0)){
    				addMonthlyTotals();
    			}
    		}
    	}
    	closeConnection();
	}
	
	/**
	 * 
	 * @param rs
	 * @return
	 * @throws Exception
	 * @throws SQLException
	 */
	private AdhocPivotData buildAdhocDataSet(ResultSet rs, ARIAReport report) throws Exception, SQLException {
		AdhocPivotData adhocDataSet = new AdhocPivotData(this.getNoOfKeyColumns(),this.getNoOfDataColumns());
		
		// Set the sort index and order
		adhocDataSet.setSortKeyIndex(dto.getUserSortColumn()==null || "".equals(dto.getUserSortColumn())? 0:Integer.parseInt(dto.getUserSortColumn()));
		adhocDataSet.setSortOrder('D'==dto.getUserSortType()? 2 : 1);
		
		// Set the column header values which are typically file dates
		adhocDataSet = setFileDates(adhocDataSet, report);
		adhocDataSet.setKeyColumnValues(new String[adhocDataSet.getNoOfKeyColumns()]);
		
		// Set the indexes for key & data columns which can be used later to access their other attributes
		adhocDataSet.setKeyColumnIndexes(new int[adhocDataSet.getNoOfKeyColumns()]);
		adhocDataSet.setDataColumnIndexes(new int[adhocDataSet.getNoOfDataColumns()]);
		
   	 	int cols = rs.getMetaData().getColumnCount();
   	 	ArrayList keyNames = new ArrayList();
   	 	ArrayList columnNames = new ArrayList();
   	 	int dataTypeCounter = 0;
   	 	int keyCounter = 0;
   	 	int dataCounter = 0;
   	 	int j=0;
   	 	
   	 	String fileDate = null;
   	 
	   	if (!dto.getColumnsDataTypeList().isEmpty()){
	   		int colSize = dto.getColumnsDataTypeList().size();
	   		if (cols == (colSize+1)){
	   			for (int i = 0; i < cols; i++) {
	   				String colName = rs.getMetaData().getColumnName(i+1);
	   				
   					if ("File Date".equals(colName)){
	   					fileDate = getFileDate(rs);
	   				} else {
	   					dataTypeCounter = getValidColsIndexArray()[j];
	   					String dataType = (String)dto.getColumnsDataTypeList().get(dataTypeCounter) ;
	   					if ("C".equals(dataType)){
		   					columnNames.add(getColumnHeader((String)dto.getColumnsHeadersList().get(dataTypeCounter), dataTypeCounter));
		   					adhocDataSet.getDataColumnIndexes()[dataCounter] = dataTypeCounter;
		   					setValue(rs,colName,adhocDataSet,dataCounter, fileDate,dataType);
		   					dataCounter++;
		   				} else {
		   					keyNames.add(getColumnHeader((String)dto.getColumnsHeadersList().get(dataTypeCounter), dataTypeCounter));
		   					adhocDataSet.getKeyColumnIndexes()[keyCounter] = dataTypeCounter;
		   					setValue(rs,colName,adhocDataSet,keyCounter, fileDate, dataType);
		   					keyCounter++;
		   				}
	   					j++;
	   				}
	   			}
	       	}
	   	}
	   	
	   	if (!keyNames.isEmpty()){
	   		int keyNamesSize = keyNames.size();
	   		String [] keyNamesArr = new String[keyNamesSize];
	   		for (int k=0;k<keyNamesSize;k++){
	   			keyNamesArr[k]= (String)keyNames.get(k);
	   		}
	   		adhocDataSet.setKeyColumnNames(keyNamesArr);
	   	}
	   	if (!columnNames.isEmpty()){
	   		int columnNamesSize = columnNames.size();
	   		String [] columnNamesArr = new String[columnNamesSize];
	   		for (int k=0;k<columnNamesSize;k++){
	   			columnNamesArr[k]= (String)columnNames.get(k);
	   		}
	   		adhocDataSet.setDataColumnNames(columnNamesArr);
	   	}

	   	return adhocDataSet;
	}
	
	/**
	 * 
	 * @param adhocDataSet
	 * @return
	 */
	private AdhocPivotData setFileDates(AdhocPivotData adhocDataSet,ARIAReport report) throws RABCException, ARIAReportException {
		String [] columnHeaders = null;
		if (TREND_TIME_BILL_ROUND.equals(dto.getPresnTrendTime()) || TREND_TIME_DAILY.equals(dto.getPresnTrendTime())){
			adhocDataSet = getFileDates(adhocDataSet);
			columnHeaders = adhocDataSet.getDataColumnHeaderNames();
		} else {
			columnHeaders = getFileDates(report);
		}
		
		if (columnHeaders == null){
			throw new RABCException("Some issue in getting dates for Pivoted Layouts");
		} else {
			adhocDataSet.setDataColumnHeaderNames(columnHeaders);
			adhocDataSet.setDataColumnValues(new double[adhocDataSet.getNoOfDataColumns()][adhocDataSet.getDataColumnHeaderNames().length]);
			/*
			 * Run a loop to enter a default value in the array
			 */
			for (int i=0;i<adhocDataSet.getNoOfDataColumns();i++){
				for (int j=0;j<adhocDataSet.getDataColumnHeaderNames().length;j++){
					adhocDataSet.getDataColumnValues()[i][j]= Double.NEGATIVE_INFINITY;
				}
			}
		}

		return adhocDataSet;
	}
	
	/**
	 * Get the file dates from RABC_CYCLE_CALENDAR
	 * @return
	 */
	private AdhocPivotData getFileDates(AdhocPivotData adhocDataSet) {
		String procDates = StaticDataLoader.getProcDates(dto.getRegion());
		String billRounds = StaticDataLoader.getBillRounds(dto.getRegion());
		
		String [] procDatesArray = procDates.split("~");
		String [] billRoundsArray = billRounds.split("~");
		
		ArrayList filteredProcDatesList = new ArrayList();
		ArrayList filteredBillRndList = new ArrayList();
		
		String startDate = dto.getStartDate();
		String endDate = dto.getEndDate();
		
		Date startDt = null;
		Date endDt = null;
		
		try {
			startDt = MMDDYYYY_FORMAT.parse(startDate);
			endDt = MMDDYYYY_FORMAT.parse(endDate);
		} catch (ParseException pe){
			logger.debug("Could not format this start or end Date " + startDate + " & " + endDate);
		}
		
		if (startDt!=null && endDt!= null) {
			for (int i=0;i<procDatesArray.length;i++){
				if (!"".equals(procDatesArray[i])){
					try {
						Date procDt = MMDDYYYY_FORMAT.parse(procDatesArray[i]);
						
						if (procDt.compareTo(startDt)>=0 && procDt.compareTo(endDt)<=0){
							if (dto.getAlertTimeValue()== -1){
								if (TREND_TIME_BILL_ROUND.equals(dto.getPresnTrendTime()) && "on".equals(dto.getBillRoundCheck())){
									if (!"0".equals(billRoundsArray[i]) && !"".equals(billRoundsArray[i])){
										filteredProcDatesList.add(procDatesArray[i]);
										filteredBillRndList.add(billRoundsArray[i]);
									}		
								} else {
									filteredProcDatesList.add(procDatesArray[i]);
									filteredBillRndList.add(billRoundsArray[i]);
								}
							}else if (TREND_TIME_BILL_ROUND.equals(dto.getPresnTrendTime())){
								if (Integer.parseInt(billRoundsArray[i])== dto.getAlertTimeValue()){
									filteredProcDatesList.add(procDatesArray[i]);
									filteredBillRndList.add(billRoundsArray[i]);
								}
							} else if (TREND_TIME_DAILY.equals(dto.getPresnTrendTime())){
								if (dto.getAlertTimeValue()== 0){
									filteredProcDatesList.add(procDatesArray[i]);
								} else if (DateUtil.getDayOfWeek(procDt)== dto.getAlertTimeValue()){
									filteredProcDatesList.add(procDatesArray[i]);
								}
							}
						}
					} catch (ParseException pe){
						logger.debug("Could not format this proc Date " + procDatesArray[i]);
					}
				}
			}
		}
		
	   	if (!filteredProcDatesList.isEmpty()){
	   		int filteredProcDatesListSize = filteredProcDatesList.size();
	   		String [] filteredProcDatesArr = new String[filteredProcDatesListSize];
	   		String [] billRoundsArr = new String[filteredProcDatesListSize];
	   		
	   		for (int k=0;k<filteredProcDatesListSize;k++){
	   			filteredProcDatesArr[k]= (String)filteredProcDatesList.get(k);
	   			if ("B".equals(dto.getPresnTrendTime())){
	   				if ("MW".equals(dto.getRegion())){
		   				billRoundsArr[k]= "<BR> PG " + (String)filteredBillRndList.get(k);
		   			} else {
		   				billRoundsArr[k]= "<BR> BR " + (String)filteredBillRndList.get(k);
		   			}
	   			}
	   		}
	   		
	   		adhocDataSet.setDataColumnHeaderNames(filteredProcDatesArr);
	   		adhocDataSet.setBillRndArr(billRoundsArr);
	   	} 
	   	
	   	return adhocDataSet;
	}
	
	/**
     * Gets the file date.
     * <p>
     * Should not be in this class.
     * 
     * @param report
     * @return
     * @throws ARIAReportException
     */
    private String[] getFileDates(ARIAReport report) throws ARIAReportException {
        String originalSQL = report.toSQL();
        String name = "\"" + ((ARIAColumn) report.getColumns().get(0)).getName() + "\"";

        StringBuffer sql = new StringBuffer(100);
        sql.append("SELECT DISTINCT ");
        sql.append(name);
        sql.append(" FROM (");
        sql.append(originalSQL);
        sql.append(") ORDER BY 1");
       
        PreparedStatement ps = null;
        ResultSet rs = null;
        List fileDtList = new ArrayList();
        
        try {
            logger.debug(sql);
            ps = getConnection().prepareStatement(sql.toString());
            rs = ps.executeQuery();
            
            while (rs.next()){
            	fileDtList.add(getFileDate(rs));
            }
        } catch (Exception e) {
            logger.error("GetReportCount", e);
        } finally {
            JDBCUtil.closeResultSet(rs);
            JDBCUtil.closePreparedStatement(ps);
        }
        
        if (!fileDtList.isEmpty()){
        	int fileDtListSize = fileDtList.size();
        	String [] fileDatesArr = new String[fileDtListSize];
        	for (int i=0;i<fileDtListSize;i++){
        		fileDatesArr[i] = (String)fileDtList.get(i);
        	}
        	return fileDatesArr;
        } else {
        	return null;
        }
    }
	
	/**
	 * 
	 * @param rs
	 * @param colName
	 * @param adhocDataSet
	 * @param arrIndex
	 * @throws Exception
	 * @throws SQLException
	 */
	private void setValue(ResultSet rs, String colName, AdhocPivotData adhocDataSet,int arrIndex, String fileDate, String passedDataType) throws Exception, SQLException {
        int dataType = rs.getMetaData().getColumnType(rs.findColumn(colName));

        switch (dataType) {
            case Types.VARCHAR:
            case Types.CHAR:
            case Types.LONGVARCHAR:
            	adhocDataSet.getKeyColumnValues()[arrIndex] = rs.getString(colName);
                break;
            case Types.DATE:
            	adhocDataSet.getKeyColumnValues()[arrIndex] = rs.getString(colName);
                break;
            case Types.DECIMAL:
            case Types.NUMERIC:
            case Types.FLOAT:
            case Types.REAL:
            	if ("C".equals(passedDataType)){
            		double value = rs.getDouble(colName);
                	for (int i=0;i<adhocDataSet.getDataColumnHeaderNames().length;i++){
                		if (fileDate!=null & fileDate.equals(adhocDataSet.getDataColumnHeaderNames()[i])){
                			adhocDataSet.getDataColumnValues()[arrIndex][i] = value;
                		}
                	}
            	} else {
            		adhocDataSet.getKeyColumnValues()[arrIndex] = rs.getString(colName);
            	}
                break;
            case Types.INTEGER:
            case Types.SMALLINT:
                if ("C".equals(passedDataType)){
                	long val = rs.getLong(colName);
            		for (int i=0;i<adhocDataSet.getDataColumnHeaderNames().length;i++){
                		if (fileDate!=null & fileDate.equals(adhocDataSet.getDataColumnHeaderNames()[i])){
                			adhocDataSet.getDataColumnValues()[arrIndex][i] = val;
                		}
                	}
            	} else {
            		adhocDataSet.getKeyColumnValues()[arrIndex] = rs.getString(colName);
            	}
                break;
            case Types.TIMESTAMP:
            case Types.TIME:
            	adhocDataSet.getKeyColumnValues()[arrIndex] = rs.getString(colName);
                break;
            default:
            	adhocDataSet.getKeyColumnValues()[arrIndex] = rs.getString(colName);
                logger.warn("Undefined format found in AdhocCustomLayout::setValue: " + dataType);
        }
    }

	/**
	 * Private method will return the file date based on the format of PROC_DATE
	 * @param fileDate
	 * @return
	 */
	private String getFileDate(ResultSet rs) throws SQLException, ParseException {
		String fileDate = rs.getString("File Date");
		
		if ("MM/DD/YYYY".equals(dto.getProcDateFormat())){
			return fileDate;
		} else if ("MM/YYYY".equals(dto.getProcDateFormat())){
			return fileDate;
		} else if ("YYYY".equals(dto.getProcDateFormat())){
			return fileDate;
		} else if ("YYYYMM".equals(dto.getProcDateFormat())){
			String yr = fileDate.substring(0,4);
			String mth = fileDate.substring(4,fileDate.length());
			fileDate = mth + "/" + yr;
			return fileDate;
		} else if ("YYYYMMDD".equals(dto.getProcDateFormat())){
			Date fileDt = YYYYMMDD_FORMAT.parse(fileDate);
			fileDate = MMDDYYYY_FORMAT.format(fileDt);
			return fileDate;
		} else if ("YYYY/MM".equals(dto.getProcDateFormat())){
			String yr = fileDate.substring(0,4);
			String mth = fileDate.substring(5,fileDate.length());
			fileDate = mth + "/" + yr;
			return fileDate;
		} else if ("DATE".equals(dto.getProcDateFormat())){
			Date fileDt = rs.getDate("File Date");
			fileDate = MMDDYYYY_FORMAT.format(fileDt);
			return fileDate;
		} else {
			return fileDate;
		}
	}
	
	/**
	 * Form the monthly totals 
	 */
	private void addMonthlyTotals(){
		TreeMap adhocDataSetMap = this.getAdhocDataSetMap();
        Set adhocDataSet = adhocDataSetMap.keySet();
        Iterator adhocDataSetIterator = adhocDataSet.iterator();
        
        while (adhocDataSetIterator.hasNext()){
        	AdhocPivotData adhocPivotData = (AdhocPivotData)adhocDataSetIterator.next();
        	int prevMth = 0;
        	String prevLabel = null;
        	List newColumnHeadings = new ArrayList();
        	List newColumnSubHeadings = new ArrayList();
        	
        	/*
        	 * Get the list of months in case of bill day report
        	 */
        	HashMap billDayMonthMap = null;
        	if ("B".equals(dto.getPresnTrendTime())){
        		billDayMonthMap = AdhocRptDAO.getBillDaySubTotalMonths(dto);
        	}
        	
        	/*
        	 * Form the labels for monthly headers
        	 */
        	boolean shouldDisplayTotal = false;
        	String lastProcDate = null;
        	for (int i=0;i<adhocPivotData.getDataColumnHeaderNames().length;i++){
        		String procDate = adhocPivotData.getDataColumnHeaderNames()[i];
        		String billRnd = "";
        		lastProcDate = procDate;
        		
        		/*
        		 * In case of bill day report we will show a sub total if the proc date is the end proc date
        		 */
        		if ("B".equals(dto.getPresnTrendTime())){
        			billRnd = adhocPivotData.getBillRndArr()[i];
            		String checkMthLabel = getMonthlyTotalLabel(billDayMonthMap,prevLabel, procDate);
        			if (checkMthLabel!= null){
    					prevLabel = checkMthLabel;
    					
    					newColumnHeadings.add(prevLabel + " Total");
            			newColumnSubHeadings.add("");
            			
            			newColumnHeadings.add(procDate);
                		newColumnSubHeadings.add(billRnd);	
        				
        				shouldDisplayTotal = true;
        			} else {
        				newColumnHeadings.add(procDate);
                		newColumnSubHeadings.add(billRnd);
        			}
        		} else {
        			int currMth = Integer.parseInt(procDate.substring(0, 2));
            		if (prevMth == 0){
            			prevMth = currMth;
            			prevLabel = procDate.substring(0,2) + "/" + procDate.substring(6,procDate.length()) + " Total";
            		}
            		if (currMth != prevMth){
            			newColumnHeadings.add(prevLabel);
            			newColumnSubHeadings.add("");
            			prevMth = currMth;
            			prevLabel = procDate.substring(0,2) + "/" + procDate.substring(6,procDate.length()) + " Total";
            			shouldDisplayTotal = true;
            		}
            		
            		newColumnHeadings.add(procDate);
            		newColumnSubHeadings.add(billRnd);
        		}
        	}
        	
        	// Add for the last label - additional check for bill day report
        	if ("B".equals(dto.getPresnTrendTime()) && lastProcDate!=null && adhocPivotData.getDataColumnHeaderNames().length>1){
        		prevLabel = lastProcDate.substring(0,2) + "/" + lastProcDate.substring(6,lastProcDate.length()) + " Total";
        	} 
    		if (!newColumnHeadings.isEmpty() && prevLabel!=null){
        		newColumnHeadings.add(prevLabel);
        		newColumnSubHeadings.add("");
        	}
        	
        	/*
        	 * Add the monthly totals if we want to display monthly totals which is only when there is data for more than 1 month
        	 */
        	if (shouldDisplayTotal) {
        		if (!newColumnHeadings.isEmpty()){
            		int newColumnHeadingsSize = newColumnHeadings.size();
            		String [] newColHeaderArr = new String[newColumnHeadingsSize];
            		String [] newColSubHeaderArr = new String[newColumnHeadingsSize];
            		for (int i=0;i<newColumnHeadingsSize;i++){
            			newColHeaderArr[i] = (String)newColumnHeadings.get(i);
            			newColSubHeaderArr[i] = (String)newColumnSubHeadings.get(i);
            		}

                	double [][] newDataColumnValues = new double[adhocPivotData.getDataColumnNames().length][newColHeaderArr.length];
                	for (int i=0;i<adhocPivotData.getDataColumnNames().length;i++){
                		for (int j=0;j<adhocPivotData.getDataColumnHeaderNames().length;j++){            			
                			for (int k=0;k<newColHeaderArr.length;k++){
                				if (newColHeaderArr[k].equals(adhocPivotData.getDataColumnHeaderNames()[j]) ){
                					newDataColumnValues[i][k] = adhocPivotData.getDataColumnValues()[i][j];
                					break;
                				}
                			}
                		}
                	}
                	
                	double monthlyTotal = 0;
                	for (int i=0;i<adhocPivotData.getDataColumnNames().length;i++){
                		for (int k=0;k<newColHeaderArr.length;k++){
                			if (newDataColumnValues[i][k]!= Double.NEGATIVE_INFINITY){
                				monthlyTotal += newDataColumnValues[i][k];
                			}
                			if (newColHeaderArr[k].indexOf("Total")!=-1){
                				newDataColumnValues[i][k] = monthlyTotal;
                				monthlyTotal = 0;
                			}
                    	}
                	}

            		adhocPivotData.setDataColumnHeaderNames(newColHeaderArr);
            		adhocPivotData.setBillRndArr(newColSubHeaderArr);
            		adhocPivotData.setDataColumnValues(newDataColumnValues);
            	}
            	
            	this.getAdhocDataSetMap().put(adhocPivotData, adhocPivotData);
        	}
        }
	}

	/**
	 * Method to return the sub total label if any
	 * @param billDayMonthMap
	 * @param prevLabel
	 * @param currProcDate
	 * @return
	 */
	private String getMonthlyTotalLabel(HashMap billDayMonthMap, String prevLabel, String currProcDate) {
		String totalLabel = null;
		try {
			Date currProcDt = MMDDYYYY_FORMAT.parse(currProcDate);
			Set billDayMonthSet			= billDayMonthMap.keySet();
			Iterator billDayMonthIterator = billDayMonthSet.iterator();
			
			while (billDayMonthIterator.hasNext()){
				String endProcDate = (String)billDayMonthIterator.next();
				Date endProcDt = MMDDYYYY_FORMAT.parse(endProcDate);
				
				/*
				 * Get the month and year parts of current key
				 */
				String mth = (String)billDayMonthMap.get(endProcDate);
				String [] mthArr = mth.split("/");
				int currMth = Integer.parseInt(mthArr[0]);
				int currYear = Integer.parseInt(mthArr[1]);
				
				if (prevLabel == null){
					if (currProcDt.compareTo(endProcDt)>0 ){
						totalLabel = (String)billDayMonthMap.get(endProcDate);
						break;
					}
				} else {
					/*
					 * Get the month and year parts of previous label
					 */
					String [] prevLabelArr = prevLabel.split("/");
					int prevMth = Integer.parseInt(prevLabelArr[0]);
					int prevYear = Integer.parseInt(prevLabelArr[1]);
					if (currProcDt.compareTo(endProcDt)>0 && (currMth>prevMth || currYear>prevYear)){
						totalLabel = mth;
						break;
					}
				}
			}
		} catch (ParseException e) {
			totalLabel = null;
		}
		
		return totalLabel;
	}
	
    /**
     * Expand possible date conversions
     * 
     * @param dateString
     * @return
     */
    protected Date parseDate(String dateString) {
        return LayoutHelper.parseDate(dateString);
    }
    
    protected void createTD(String style, int colIndex, StringBuffer buf) {
        buf = LayoutHelper.createTD(style, colIndex, buf, dto);
    }
    
    /**
     * format the presentation of the cell
     * 
     * @param columnName
     * @param value
     * @param escape
     * @param elementIndex
     * @param buf
     * @throws RABCException
     */
    protected void formatCellData(String columnName, String value, boolean escape, int elementIndex, StringBuffer buf) throws RABCException {
        buf = LayoutHelper.formatCellData(columnName, value, escape, elementIndex, buf, dto, logger, getSection());
    }
    
    /**
     * 
     * @param header
     * @param index
     * @return
     */
    public String getColumnHeader(String header, int index) {
        return LayoutHelper.getColumnHeader(header, index, dto);
    }
    
    /**
     * Inappropriately located method to get mouse over description. This should really be in the DAO.
     * 
     * @param tableIndex
     * @param mouseKey
     * @param value TODO
     * @return
     * @throws RABCException
     */
    protected String getMouseOverDescription(int tableIndex, String mouseKey, String value) {
        return LayoutHelper.getMouseOverDescription(tableIndex, mouseKey, value, dto, dtoBase, connection, logger);
    }
    
    /**
     * Method called to form link data for Data Cells
     * @param columnName
     * @param processor
     * @param value
     * @param escape
     * @param elementIndex
     * @param buf
     * @param adhocPivotData
     * @param procDate
     * @throws ParseException
     * @throws NamingException
     * @throws RABCException
     * @throws SQLException
     * @throws UnsupportedEncodingException
     */
    protected void formatDataCellWithLinks(String columnName, Page13PivotHTMLProcessor processor, String value, boolean escape, int elementIndex, StringBuffer buf, AdhocPivotData adhocPivotData, String procDate) throws ParseException, NamingException, RABCException, SQLException, UnsupportedEncodingException {
    	if (elementIndex < 0) {
            formatCellData(columnName, value, escape, elementIndex, buf);
        } else {
            boolean addLink = isIndicatorIn((String) dto.getDataLinkIndList().get(elementIndex), "Y");
	        if (addLink) {
                buf.append(getUrl(columnName,elementIndex, value,adhocPivotData, null));
            }

            formatCellData(columnName, value, escape, elementIndex, buf);

            if (addLink) {
                buf.append("</a>");
            }

            boolean addGraph = isIndicatorIn((String) dto.getGraphPresnIndList().get(elementIndex), "Y");
            if (addGraph) {
                buf.append("<a href=\"javascript:graphpopup('alertGraph','");
                buf.append(urlEncodedFormat(getGraphUrl(columnName,elementIndex, adhocPivotData, procDate)));
                buf.append("')\"><img src=\"./images/graph.gif\" alt=\"Graph\" height=\"10\" width=\"13\" border=\"0\"/></a>");
            }
        }
    }
    
    /**
     * Method called to form link data for Key Cells
     * @param columnName
     * @param processor
     * @param value
     * @param escape
     * @param elementIndex
     * @param buf
     * @param adhocPivotData
     * @throws ParseException
     * @throws NamingException
     * @throws RABCException
     * @throws SQLException
     * @throws UnsupportedEncodingException
     */
    protected void formatKeyCellWithLinks(String columnName, Page13PivotHTMLProcessor processor, String value, boolean escape, int elementIndex, StringBuffer buf, AdhocPivotData adhocPivotData) throws ParseException, NamingException, RABCException, SQLException, UnsupportedEncodingException {
        if (elementIndex < 0) {
            formatCellData(columnName, value, escape, elementIndex, buf);
        } else {
            boolean addLink = isIndicatorIn((String) dto.getDataLinkIndList().get(elementIndex), "Y");
            	
            if (addLink) {
                buf.append(getUrl(columnName,elementIndex, value,adhocPivotData, null));
            }

            formatCellData(columnName, value, escape, elementIndex, buf);

            if (addLink) {
                buf.append("</a>");
            }

            boolean addGraph = isIndicatorIn((String) dto.getGraphPresnIndList().get(elementIndex), "Y");
            if (addGraph) {
                buf.append("<a href=\"javascript:graphpopup('alertGraph','");
                buf.append(urlEncodedFormat(getGraphUrl(columnName,elementIndex, adhocPivotData, null)));
                buf.append("')\"><img src=\"./images/graph.gif\" alt=\"Graph\" height=\"10\" width=\"13\" border=\"0\"/></a>");
            }
        }
    }
    
    /**
     * Get the link url.
     * 
     * @param columnName
     * @param rowMap
     * @param tableIndex
     * @param value
     * @return
     * @throws ParseException
     * @throws RABCException
     * @throws SQLException
     * @throws UnsupportedEncodingException
     */
    protected String getUrl(String columnName, int tableIndex, String value, AdhocPivotData adhocPivotData, String procDate) throws NamingException,ParseException, RABCException, SQLException, UnsupportedEncodingException {
        return LayoutHelper.getUrl(columnName,tableIndex, value, dto, dtoBase, getConnection(), logger,adhocPivotData,procDate);
    }
    
    /**
     * Create the graph href url
     * 
     * @param columnName
     * @param rowMap
     * @param tableIndex
     * @return
     * @throws ParseException
     * @throws UnsupportedEncodingException
     */
    protected String getGraphUrl(String columnName, int tableIndex, AdhocPivotData adhocPivotData,String procDate) throws ParseException, UnsupportedEncodingException {
        return LayoutHelper.getGraphUrl(columnName,tableIndex, dto, adhocPivotData,procDate );
    }
    
    /**
     * Test the character indicator to see if it contains the value specified. If the indicator is null it will return
     * false.
     * <p>
     * example: isIndicatorIn(myInd, "YN") = true if the indicator is either 'Y' or 'N'
     * 
     * @param ind
     * @param test
     * @return
     */
    protected boolean isIndicatorIn(String ind, String test) {
        return LayoutHelper.isIndicatorIn(ind, test);
    }
    
    /**
     * If previous data exists, setup the table for it.
     * 
     * @param report
     * @throws ARIAReportException
     * @throws NamingException
     * @throws SQLException
     * @throws ARIAReportException
     * @throws NamingException
     * @throws SQLException
     * @throws RABCException
     */
    protected void setupPreviousDataTable(int section) throws SQLException, NamingException, ParseException,ARIAReportException, RABCException {
    	prevData = LayoutHelper.setupPivotPreviousDataTable(section, dto, dtoBase, prevData, getConnection(), logger, isPreviousExists());
    }
    
    /**
     * Construct a composite key with date
     * 
     * @param column
     * @param processor
     * @return
     */
    protected DatedCompositeKey getDatedKey(String procDate) {
       return LayoutHelper.getDatedKey(procDate);
    }

	/**
	 * @return the previousExists
	 */
	public boolean isPreviousExists() {
		boolean previousExists = false;
        for (int j = 0; j < dto.getPrevDataIndList().size(); j++) {
            if (isIndicatorIn((String) dto.getPrevDataIndList().get(j), "Y")) {
                previousExists = true;
                break;
            }
        }
        
        // Additional condition in case of Layout 2 to suppress previous if specific bill round or weekday selected
        if (dto.getAlertTimeValue()!=-1 && ("B".equals(dto.getPresnTrendTime()) || "D".equals(dto.getPresnTrendTime()))){
        	previousExists = false;
        }
        
        return previousExists;
	} 
	
    /**
     * Call the super classes createReportFilters to create the "search criteria" and write it to the report stream
     */
    public String renderBeginReport(ARIAReportProcessor processor) {
        try {
            createReportFilters();
        } catch (RABCException e) {
            logger.error("AdhocAriaLayout1::renderBeginReport", e);
        }     
        return "";
    }
    
    /**
     * Ends the report
     */
    public String renderEndReport(ARIAReportProcessor processor) {
        StringBuffer buf = new StringBuffer(40);

        /*
         * If nothing returned print the no data message
         */
        if (getAdhocDataSetMap().isEmpty()) {
        	buf.append("<table border=1 width=99% cellspacing=0 cellpadding=3>");
        	if (getTotalDataSets()>0){
        		buf.append("<tr><td class='NoData' colspan='100%' align='center'>No data on this page for this section.</td></tr>");
        	} else {
        		buf.append("<tr><td class='NoData' colspan='100%' align='center'>No data found for the criteria entered.</td></tr>");
        	}
            buf.append("</table>");
        }

        return buf.toString();
    }

    /**
     * Begins the table
     */
	public String renderBeginTable(ARIAReportProcessor processor) {
		StringBuffer buf = new StringBuffer(40);
		buf.append("<table border=1 width=99% cellspacing=0 cellpadding=3>");
		return buf.toString();
	}

	/**
	 * Ends the table
	 */
	public String renderEndTable(ARIAReportProcessor processor) {
		StringBuffer buf = new StringBuffer(40);
		buf.append("</table>");
		buf.append("<table border='0'><tr><td></td></tr></table>");
		return buf.toString();
	}


	/**
	 * Begins the key row
	 */
	public String renderBeginKeyRow(ARIAReportProcessor processor) {
		StringBuffer buf = new StringBuffer(100);
		
		Page13PivotHTMLProcessor page13 = (Page13PivotHTMLProcessor) processor;
		AdhocPivotData adhocPivotData = page13.getAdhocDataSet();
		
		String [] dataColumnHeaders = adhocPivotData.getDataColumnHeaderNames();
		String styleClass = "class='KeyRow'";
		if (isOutputExcel()){
			styleClass = "bgColor = 'D8D8D8'";
		}
		
		if (isPreviousExists()){
			buf.append("<tr><td " + styleClass + " colspan = " + ((dataColumnHeaders.length)*2 + 2) + " >");
		} else {
			buf.append("<tr><td " + styleClass + " colspan = " + (dataColumnHeaders.length + 2) + " >");
		}

		try {
			buf.append(LayoutHelper.getSubHeader(dto, getConnection(), getSection(), logger));
		} catch (NamingException e) {
			logger.debug("Could not get the sub header" + e);
		} catch (SQLException e) {
			logger.debug("Could not get the sub header" + e);
		}
		
		return buf.toString();
	}
	
	/**
	 * Starts the attribute row
	 */
	public String renderBeginAttributeRow(ARIAReportProcessor processor) {
		StringBuffer buf = new StringBuffer(100);
		
		Page13PivotHTMLProcessor page13 = (Page13PivotHTMLProcessor) processor;
		AdhocPivotData adhocPivotData = page13.getAdhocDataSet();
		
		String [] dataColumnHeaders = adhocPivotData.getDataColumnHeaderNames();
		String styleClass = "class='AttributeRow'";
		if (isOutputExcel()){
			styleClass = "bgColor = 'D8D8D8'";
		}
		
		if (isPreviousExists()){
			buf.append("<tr><td " + styleClass + " colspan = " + ((dataColumnHeaders.length)*2 + 2) + " >");
		} else {
			buf.append("<tr><td " + styleClass + " colspan = " + (dataColumnHeaders.length + 2) + " >");
		}
		return buf.toString();
	}

	/**
	 * Ends the key row
	 */
	public String renderEndKeyRow(ARIAReportProcessor processor) {
		StringBuffer buf = new StringBuffer(40);
		buf.append("</td></tr>");	
		return buf.toString();
	}
	
	/**
	 * Ends the attribute row
	 */
	public String renderEndAttributeRow(ARIAReportProcessor processor) {
		StringBuffer buf = new StringBuffer(40);
		buf.append("</td></tr>");	
		return buf.toString();
	}

	/**
	 * Starts the data row
	 */
	public String renderBeginDataRow(ARIAReportProcessor processor) {
		StringBuffer buf = new StringBuffer(100);
		buf.append("<tr>");
		return buf.toString();
	}
	
	/**
	 * Ends the data row
	 */
	public String renderEndDataRow(ARIAReportProcessor processor) {
		StringBuffer buf = new StringBuffer(40);
		buf.append("</td></tr>");	
		return buf.toString();
	}


	/**
	 *  Renders the key & attributes cell 
	 */
	public String renderKeyCell(ARIAReportProcessor processor, String label, String value, boolean escape, int elementIndex) {
		try {
			if (!isIndicatorIn((String) dto.getPresnSuppressIndList().get(elementIndex), "Y")) {
				if ("".equals(value) || value.equals("null")) {
		            return "<span class = 'formLabel'> " + label + " </span> :&nbsp;&nbsp;&nbsp;&nbsp;";
		        }
				
		        Page13PivotHTMLProcessor proc = (Page13PivotHTMLProcessor) processor;
				AdhocPivotData adhocPivotData = proc.getAdhocDataSet();
		        
				StringBuffer buf = new StringBuffer(40);
				buf.append("&nbsp;");
		        buf.append("<span class = 'formLabel'> ");
		        buf.append(label);
		        buf.append(":");
		        buf.append("</span>");
		        buf.append("<a ");
		        buf.append(" title='"+ getMouseOverDescription(elementIndex, "", value) + "' ");
		        buf.append(">");

		        // New method to format Key data
		        if (isOutputExcel()){
		        	formatCellData((String) dto.getColumnsToExtractList().get(elementIndex), value, escape, elementIndex, buf);
		        } else {
		        	formatKeyCellWithLinks((String) dto.getColumnsToExtractList().get(elementIndex), proc, value, escape, elementIndex, buf, adhocPivotData);
		        }
		        
		        buf.append("</a> ");
		        if (!isOutputExcel()){
		        	addUserSortLink(buf,elementIndex,adhocPivotData);
		        }
		        buf.append("&nbsp;&nbsp;&nbsp;");
		        
		        return buf.toString();
			} else {
				return "";
			}
		}catch (Exception e) {
            logger.error("renderKeyCell", e);
            return "<span class = 'formLabel'> " + label + " </span> :&nbsp;&nbsp;&nbsp;&nbsp;";
        }           
	}

	/**
	 * Renders the data label
	 */
	public String renderDataLabelCell(ARIAReportProcessor processor, String value, boolean escape) {
		StringBuffer buf = new StringBuffer(40);
		buf.append("<td class=\"formLabel mso\" align='left'>");
		buf.append("&nbsp;&nbsp;");
		buf.append(value);
		buf.append("</td>");
		
		return buf.toString();
	}
	
	/**
	 * Method to add the image to sort
	 * @param buf
	 * @param keyIndex
	 * @param adhocPivotData
	 */
	protected void addUserSortLink(StringBuffer buf, int keyIndex, AdhocPivotData adhocPivotData) {
        boolean isSortColumn = adhocPivotData.getSortKeyIndex()== keyIndex;

        buf.append("&nbsp;");

        String imgASC = "<img src=\"./images/ArrowUp2.gif\" border=0 />";
        String imgDESC = "<img src=\"./images/ArrowDown2.gif\" border=0 />";
        String imgNoSort = "<img src=\"./images/arrowRightW.gif\" border=0 />";

        buf.append("<a href=\"javascript:sortBy('");
        buf.append(keyIndex);
        buf.append("~");
        buf.append(getSection());
        buf.append("','");
        if (isSortColumn) {
            switch (dto.getUserSortType()) {
                case 'A':
                    buf.append('D');
                    break;
                case 'D':
                    buf.append(' ');
                    break;
                default:
                    buf.append('A');
            }
        } else {
            buf.append('A');
        }

        buf.append("');document.AdhocRptForm.submit();\">");

        if (isSortColumn) {
            switch (dto.getUserSortType()) {
                case 'A':
                    buf.append(imgASC);
                    break;
                case 'D':
                    buf.append(imgDESC);
                    break;
                default:
                    buf.append(imgNoSort);
            }
        } else {
            buf.append(imgNoSort);
        }

        buf.append("</a>");

    }

	/**
	 * @return the isOutputExcel
	 */
	public boolean isOutputExcel() {
		return false;
	}
	
	/**
	 * 
	 * @param realSQL
	 * @param report
	 */
	private void addKeyList(String realSQL,ARIAReport report,Page13PivotHTMLProcessor processor){
		String sql = formKeySQL(realSQL);
		
		if (form instanceof PagedForm) {
			ARIAPaging paging = null;
			if (processor.getPaging()==null){
				paging = new ARIAPaging();
			} else {
				paging = processor.getPaging();
			}
            PagedForm pForm = (PagedForm) form;
            paging.setRowsPerPage(RABCConstantsLists.getRABCConstantsLists().getAdhocDataSetSize()); 
            paging.setCurrentPage(pForm.getPage());
            
            totalDataSets = getDistinctKeyCount(sql,report);
            
            int maxPage = (int) (((float) totalDataSets / paging.getRowsPerPage()) + .99);
            int pCount = Math.max(1, maxPage);
            if (pCount > paging.getTotalPages()) {
                paging.setTotalPages(pCount);
                pForm.setPages(paging.getTotalPages());
            }

            processor.setPaging(paging);
            
            String pagedSQL = getPagedSQL(sql,paging);
            PreparedStatement ps = null;
            ResultSet rs = null;
            try {
                logger.debug(pagedSQL);
                ps = getConnection().prepareStatement(pagedSQL.toString());
                rs = ps.executeQuery();
                int cols = rs.getMetaData().getColumnCount();
                while (rs.next()){
                	CompositeKey key = new CompositeKey();
                	key.setNumKeys(cols-1);
                	for (int i=1;i<cols;i++){
                		int dataType = rs.getMetaData().getColumnType(i);
                		if (dataType == Types.TIME || dataType == Types.DATE || dataType == Types.TIMESTAMP){
                			key.addKey(rs.getDate(i));
                		} else {
                			key.addKey(rs.getString(i));
                		}
                	}
                	this.pivotKeyList.add(key);
                }
            } catch (Exception e) {
                logger.error("Formation of pivot keys", e);
            } finally {
                JDBCUtil.closeResultSet(rs);
                JDBCUtil.closePreparedStatement(ps);
            }
		}
	}
	
	/**
	 * 
	 * @param realSQL
	 * @param report
	 * @return
	 */
	private int getDistinctKeyCount(String realSQL,ARIAReport report){
		StringBuffer sql = new StringBuffer(100);
        sql.append("SELECT COUNT(*)");
        sql.append(" FROM (");
        sql.append(realSQL);
        sql.append(")");
        
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            logger.debug(sql);
            ps = getConnection().prepareStatement(sql.toString());
            rs = ps.executeQuery();
            rs.next();
            return rs.getInt(1);
        } catch (Exception e) {
            logger.error("GetReportCount", e);
            return 0;
        } finally {
            JDBCUtil.closeResultSet(rs);
            JDBCUtil.closePreparedStatement(ps);
        }
	}
	
	/**
	 * Form the key SQL
	 * @param realSQL
	 */
	private String formKeySQL(String realSQL){	
		return LayoutHelper.getKeySQL(realSQL, dto);
	}
	

    /**
     * Method will return the paged SQL
     * @param realSQL
     * @param paging
     * @return
     */
    private String getPagedSQL(String realSQL, ARIAPaging paging){
    	StringBuffer buf = new StringBuffer(300);
        buf.append("SELECT * FROM (SELECT non_paging.*,ROWNUM linenum FROM (");
        buf.append(realSQL);
        buf.append(") non_paging) WHERE linenum >=");
        buf.append(paging.getCurrentStartRow());
        buf.append(" AND linenum <=");
        buf.append(paging.getCurrentEndRow());
        return buf.toString();
    }
    
    /**
     * Will return the actual SQL
     * @param sql
     * @return
     */
    private String appendWhere(String sql){
		// Create a new string buffer to store the SQL
		StringBuffer completeSql = new StringBuffer();
		completeSql.append("SELECT * FROM (");
		completeSql.append(sql.toString());
		completeSql.append(")");
		
		// Boolean
		boolean isFirst = true;
		int count = 0;

		// Loop through the list of columns
		for (int i = 0; i < dto.getColumnsAsOracleList().size(); i++) {
            String element = (String) dto.getColumnsAsOracleList().get(i);
            element = element.trim();
            if (!dto.getColumnsDataTypeList().get(i).toString().equalsIgnoreCase("C")) {
            	 String header = dto.getColumnsHeadersList().get(i).toString();
                 if (header.indexOf(".") != -1) {
                     header = header.replace('.', ' ');
                 } else if (header.equalsIgnoreCase("RTOTAL")) {
                     header = "Right Side Total";
                 } else if (dto.getColumnsHeadersList().get(i).toString().equalsIgnoreCase("LTOTAL")) {
                     header = "Left Side Total";
                 }
                 if (!isFirst){
                	 completeSql.append(" AND ");
                 } else {
                	 completeSql.append(" WHERE ");
                 }

                // Form the distinct set of values to put in where clause
                List distinctKeyValuesList = new ArrayList();
				for (int j = 0; j < this.pivotKeyList.size(); j++) {
					CompositeKey key = (CompositeKey) this.pivotKeyList.get(j);
					Object keyVal = key.getKey(count);
					
					if (distinctKeyValuesList.isEmpty()){
						if (keyVal instanceof Date){
							distinctKeyValuesList.add((Date)keyVal);
						} else {
							distinctKeyValuesList.add((String)keyVal);
						}					
					} else if (keyVal instanceof Date){
						if (!distinctKeyValuesList.contains((Date)keyVal)){
							distinctKeyValuesList.add((Date)keyVal);
						}	
					} else {
						if (!distinctKeyValuesList.contains((String)keyVal)){
							distinctKeyValuesList.add((String)keyVal);
						}		
					}	
				}
				
				// Append to sql
				if (!distinctKeyValuesList.isEmpty()){
					completeSql.append("\"");
	                completeSql.append(header);
	                completeSql.append("\"");
	                completeSql.append(" IN (");
	                 
					for (int j = 0; j < distinctKeyValuesList.size(); j++) {
						Object keyVal = distinctKeyValuesList.get(j);
						if (keyVal instanceof Date){
							Date dateVal = (Date)keyVal;
							String fomattedDateVal = MMDDYYYY_FORMAT.format(dateVal);
							completeSql.append("TO_DATE('");
							completeSql.append(fomattedDateVal);
							completeSql.append("','MM/DD/YYYY'");
							completeSql.append(")");
						} else {
							completeSql.append("'");
							completeSql.append((String) keyVal);
							completeSql.append("'");
						}
						
						if (distinctKeyValuesList.size()>1 && j<distinctKeyValuesList.size()-1){
							completeSql.append(",");
						}
					}
					
					completeSql.append(" )");
					isFirst = false;
				}

                count++;
            }
	    }
				
		return completeSql.toString();
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see com.sbc.bac.aria.renderers.ARIAHTMLPagingRenderer#renderPaging(com.sbc.bac.aria.ARIAPaging)
     */
    public String renderPaging(ARIAPaging paging) {
        return LayoutHelper.getPaging(paging);
    }
    
    /**
	 * This method returns the string for urlEncodedFormat.
	 * 
	 * @param s
	 * @return String
	 */
	private String urlEncodedFormat(String s) {
		if (s == null) return null;
		try {
			return URLEncoder.encode(s, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			return null;
		}
	}
}
