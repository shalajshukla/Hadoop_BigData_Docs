/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.admin;

/**
 * This is a Data Object to represent RABC_ALERT_GRP_USER table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class AlertGroupUser {
	private String alertGrp;
	private String userId;

	/**
	 * @return Returns the AlertGrp.
	 */
	public String getAlertGrp() {
		return alertGrp;
	}
	/**
	 * @return Returns the UserId.
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param AlertGrp The alertGrp to set.
	 */
	public void setAlertGrp(String alertGrp) {
		this.alertGrp = alertGrp;
	}
	/**
	 * @param UserId The userId to set.
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
}
