/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.dashboard;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.text.MessageFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.att.bac.rabc.ExcelReport;
import com.att.bac.rabc.ProgressBar;
import com.att.bac.rabc.RABCConstantsLists;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;

/**
 * This class represents the Service that create the AlertRuleRevenue Object. 
 * 
 * @author Sandhya Chinala - SC3837
 */
public class AlertRuleRevenueService {
	private static final Logger logger = Logger.getLogger(AlertDashboardService.class);
	private static AlertRuleRevenueService alertRuleRevenueService;
			
	private final String query_getCycle = "SELECT CYCLE, BILL_RND, PROC_DT, BILL_RND_DT "
		+ "FROM rabc_cycle_calendar {0}";
	
	private final String query_total_rev_investigations = "select sum(issue_revenue_cr) total_rev_cr, " 
		+ "sum(issue_revenue_db) total_rev_db, " 
		+ "sum(issue_lost_revenue) total_rev_lost " 
		+ "from rabc_cntrl_process_cert " 
		+ "where process = ''{0}'' "
		+ "{1}" ;
	
	private final String query_total_rev_impacted_credit = "select sum(alert_revenue) credit " 
		+ "from RABC_DIVISION b, RABC_ALERT_MSG c, RABC_ALERT_COMMENT d " 
		+ "where alert_revenue > 0 " 
		+ "and {0} "
		+ "and {1} " 
		+ "c.alert_data1 = b.division "
		+ "and c.msg_num = d.msg_num ";
			
	private final String query_total_rev_impacted_debit = "select sum(alert_revenue) debit " 
		+ "from	RABC_DIVISION b, RABC_ALERT_MSG c, RABC_ALERT_COMMENT d " 
		+ "where alert_revenue < 0 " 
		+ "and {0} "  
		+ "and {1} "
		+ "c.alert_data1 = b.division "
		+ "and c.msg_num = d.msg_num";
					
	private final String query_total_rev_impacted_lost = "select sum(alert_lost_revenue) lost " 
		+ "from	RABC_DIVISION b, RABC_ALERT_MSG c, RABC_ALERT_COMMENT d " 
		+ "where {0} " 
		+ "and {1} " 
		+ "c.alert_data1 = b.division "
		+ "and c.msg_num = d.msg_num";
	
	private final String query_getCertInfo = "select distinct run_date, state_desc, issue_revenue_cr, " 
		+ "issue_revenue_db, issue_lost_revenue, cert_ind " 
		+ "from rabc_cntrl_process_cert a, rabc_division b " 
		+ "where a.state = b.state " 
		+ "and process = ''{0}'' " 
		+ "{1} " 
		+ "order by run_date, state_desc";
	
	private final String query_getAlertInfo = "select c.alert_rule, c.alert_rule_run_dt, division_desc, " 
		+ "alert_item, alert_revenue, alert_root_catgy_cd, alert_lost_revenue, alert_status, "
		+ "(select msg_comment from rabc_alert_comment d where c.msg_num = d.msg_num "
		+ "and d.msg_num || ''-'' || to_char(d.time_stamp, ''MM/dd/yyyy hh:mi:ss'') in "
		+ "(select msg_num || ''-'' || to_char(time_stamp, ''MM/dd/yyyy hh:mi:ss'') from "
		+ "(select msg_num, max(time_stamp) time_stamp from rabc_alert_comment group by msg_num)) "
		+ ") msg_comment, "
		+ "alert_key2, alert_key3, alert_key4, alert_key5, "
		+ "alert_data2, alert_data3, alert_data4, alert_data5 "
		+ "from RABC_DIVISION b, RABC_ALERT_MSG c " 
		+ "where {0} "  
		+ "and {1} "
		+ "c.alert_data1 = b.division "
		+ "order by	c.alert_rule";
	
	/**
	 * Synchronized method to return the instance of AlertRuleRevenueService object.
	 * It checks the existance of the instance of AlertRuleRevenueService and if it does not exists
	 * then creates one instance of AlertRuleRevenueService and returns otherwise it returns the
	 * existing instance of AlertRuleRevenueService.
	 * 
	 * @return AlertRuleRevenueService
	 */
	protected static synchronized AlertRuleRevenueService getAlertRuleRevenueService() {
		if (alertRuleRevenueService == null) {
			alertRuleRevenueService = new AlertRuleRevenueService();
		}
		return alertRuleRevenueService;
	}
	
	/**
	 * Method to return the list of cycles.
	 * It calls the CycleCalendarDAO to get the list of cycles.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return List
	 */
	protected List getCycleCalendarList(Connection connection, List failureList, List args ){
		List cycleCalendarList = new ArrayList();
		List cycleList = new ArrayList();
		CycleCalendar cycleCalendar= null;
		List cycleArgsList = new ArrayList();
		String startDate = (String) args.get(0);
		String endDate = (String) args.get(1);
		String alertDate = (String) args.get(2);
		
		if ((alertDate != null) && (!"".equals(alertDate))) {
			cycleArgsList.add("where proc_dt = to_date('"+alertDate+"','MM/dd/yyyy')");
		} else if((startDate != null && !"".equals(startDate)) && (endDate == null || "".equals(endDate))) {
			cycleArgsList.add("where proc_dt = to_date('" + startDate + "','MM/dd/yyyy')");
		} else if((startDate != null && !"".equals(startDate))  && (endDate != null && !"".equals(endDate)) && (startDate.equals(endDate))) {
			cycleArgsList.add("where proc_dt  = to_date('" + startDate + "','MM/dd/yyyy')");
		} else if((startDate != null && !"".equals(startDate))  && (endDate != null && !"".equals(endDate)) && (!startDate.equals(endDate))) {
			cycleArgsList.add("where proc_dt  between  to_date('" + startDate + "','MM/dd/yyyy') and to_date('" + endDate + "','MM/dd/yyyy')");
		} else {
			cycleArgsList.add("");
		}
		cycleCalendarList = new CycleCalendarDAO().get(connection, failureList, cycleArgsList, query_getCycle);
		if (!failureList.isEmpty()) {
			return null;
		}
		if (cycleCalendarList != null) {
			int i = 0;
			int cycleCalendarListSize = cycleCalendarList.size();
			for (i=0; i<cycleCalendarListSize; i++) {
				cycleCalendar = (CycleCalendar)cycleCalendarList.get(i);
				cycleList.add(new Integer(cycleCalendar.getCycle()));
			}
		}
		return cycleList;
	}
	
	/**
	 * This is a method to return the list of AlertRuleRevenue objects.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param progressBar
	 * @return List
	 */
	protected List getAlertRuleRevenueList(Connection connection, List failureList, List args, ProgressBar progressBar, String region, String dateOption) {
		List alertRuleRevenueList = new ArrayList();
		String alertRule = (String) args.get(3);
		String processPoint = (String) args.get(4);
		String processPointText = RABCConstantsLists.getRABCConstantsLists().getText(processPoint, false);
		
		/*
		 * Logic Constructs a Certified row in the table 1
		 */
		if (!region.equals("C2")) {
			List certifiedList = queryTotalRevInvestigations(connection, failureList, args);
			if (!failureList.isEmpty()) {
				return null;
			}
			double certifiedCredit = ((Double)certifiedList.get(1)).doubleValue();
			double certifiedDebit = ((Double)certifiedList.get(2)).doubleValue();
			double certifiedUnrecoverableRevenue = ((Double)certifiedList.get(3)).doubleValue();
			AlertRuleRevenue alertRuleRevenueCertified = new AlertRuleRevenue();
			alertRuleRevenueCertified = buidAlertRuleRevenue(certifiedList);
			alertRuleRevenueList.add((AlertRuleRevenue)alertRuleRevenueCertified);
		}
		progressBar.setProgressPercent(progressBar.getPercent() + 10);
		
		/*
		 * Logic Constructs a AlertRule row in the table 1
		 */
		List alertRuleList = new ArrayList();
		double alertRuleCredit = queryTotalRevImpactedCredit(connection, failureList, args, dateOption);
		if (!failureList.isEmpty()) {
			return null;
		}
		double alertRuleDebit = queryTotalRevImpactedDebit(connection, failureList, args, dateOption);
		if (!failureList.isEmpty()) {
			return null;
		}
		progressBar.setProgressPercent(progressBar.getPercent() + 10);
		double alertRuleUnrecoverableRevenue = queryTotalRevImpactedLost(connection, failureList, args, dateOption);
		if (!failureList.isEmpty()) {
			return null;
		}
		if ((alertRule != null) && (!alertRule.equals(""))) {
			alertRuleList.add("Total Alert Rule Amount for " + alertRule);
		} else {
			alertRuleList.add("Alert Rule Amount for " + processPointText);
		}
		alertRuleList.add(new Double(alertRuleCredit));
		alertRuleList.add(new Double(alertRuleDebit));
		alertRuleList.add(new Double(alertRuleUnrecoverableRevenue));
		AlertRuleRevenue alertRuleRevenueAlertRule = new AlertRuleRevenue();
		alertRuleRevenueAlertRule = buidAlertRuleRevenue(alertRuleList);
		alertRuleRevenueList.add((AlertRuleRevenue)alertRuleRevenueAlertRule);
		progressBar.setProgressPercent(progressBar.getPercent() + 10);
					
		return alertRuleRevenueList;
	}
	
	/**
	 * This is a method to return the list of total revenue investigation objects.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return List
	 */
	private List queryTotalRevInvestigations(Connection connection,List failureList,List args){
		List certfiedAlertsList = new ArrayList();
		List alertInfoArgsList = new ArrayList();
		String startDate = (String)args.get(0);
		String endDate = (String)args.get(1);
		String alertDate = (String)args.get(2);
		String processPoint = (String)args.get(4);
		Statement statement = null;
		ResultSet rs = null;
		String prepareStatement = null;
		
		alertInfoArgsList.add(processPoint);
		if ((alertDate != null) && (!"".equals(alertDate))) {
			alertInfoArgsList.add("  and run_date = to_date('"+alertDate+"','MM/dd/yyyy') ");
		} else if((startDate != null && !"".equals(startDate)) && (endDate == null || "".equals(endDate))) {
			alertInfoArgsList.add("  and run_date = to_date('"+startDate+"','MM/dd/yyyy')");
		} else if((startDate != null && !"".equals(startDate)) && (endDate != null && !"".equals(endDate))) {
			alertInfoArgsList.add("  and run_date between to_date('"+startDate+"','MM/dd/yyyy') and to_date('"+endDate+"','MM/dd/yyyy')");
		} else {
			alertInfoArgsList.add("");
		}
		try{
			MessageFormat mf = new MessageFormat(query_total_rev_investigations);
			prepareStatement = mf.format((String[])alertInfoArgsList.toArray(new String[alertInfoArgsList.size()]));
			logger.debug("AlertRuleRevenueService.queryTotalRevInvestigations() - Executing SQL statement: "+ prepareStatement);
			statement = connection.createStatement();
			rs = statement.executeQuery(prepareStatement);
			logger.debug("SQL - Execution complete.");
			if (rs != null && rs.next()) {
				certfiedAlertsList.add("Certified - Process Level");
				certfiedAlertsList.add(new Double(rs.getDouble(1)));
				certfiedAlertsList.add(new Double(rs.getDouble(2)));
				certfiedAlertsList.add(new Double(rs.getDouble(3)));
			}
		} catch(SQLException sqle) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sqle.getMessage(), sqle);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sqle));
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(statement, failureList, logger);
		}
		return certfiedAlertsList;
	}
	
	/**
	 * This is a private method to return the total revenue impacted credit objects.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return double
	 */
	private double queryTotalRevImpactedCredit(Connection connection,List failureList,List args, String dateOption){
		double alertRuleCredit = 0.0;
		List alertInfoArgsList = new ArrayList();
		String startDate = (String)args.get(0);
		String endDate = (String)args.get(1);
		String alertDate = (String)args.get(2);
		String alertRule = (String) args.get(3);
		String processPoint = (String) args.get(4);
		Statement statement = null;
		ResultSet rs = null;
		String prepareStatement = null;
		
		if ((alertRule != null) && (!alertRule.equals(""))) {
			alertInfoArgsList.add("c.alert_rule = '" + alertRule + "'");
		} else {
			alertInfoArgsList.add("c.alert_rule in (select alert_rule from rabc_cntrl_pt_alert where cntrl_pt_cd in (select cntrl_pt_cd from rabc_process where process= '" + processPoint + "'))");
		}
		if ("run".equals(dateOption)){
			if ((alertDate != null) && (!"".equals(alertDate))) {
				alertInfoArgsList.add("  c.alert_rule_run_dt = to_date('"+alertDate+"','MM/dd/yyyy') and  ");
			} else if((startDate != null && !"".equals(startDate)) && (endDate == null || "".equals(endDate))) {
				alertInfoArgsList.add("  c.alert_rule_run_dt = to_date('"+startDate+"','MM/dd/yyyy') and  ");
			} else if((startDate != null && !"".equals(startDate))  && (endDate != null && !"".equals(endDate))) {
				alertInfoArgsList.add("  c.alert_rule_run_dt between to_date('"+startDate+"','MM/dd/yyyy') and to_date('"+endDate+"','MM/dd/yyyy') and " ); 			
			} else {
				alertInfoArgsList.add("");
			}
		} else {
			if ((alertDate != null) && (!"".equals(alertDate))) {
				alertInfoArgsList.add("  c.proc_date = to_date('"+alertDate+"','MM/dd/yyyy') and  ");
			} else if((startDate != null && !"".equals(startDate)) && (endDate == null || "".equals(endDate))) {
				alertInfoArgsList.add("  c.proc_date = to_date('"+startDate+"','MM/dd/yyyy') and  ");
			} else if((startDate != null && !"".equals(startDate))  && (endDate != null && !"".equals(endDate))) {
				alertInfoArgsList.add("  c.proc_date between to_date('"+startDate+"','MM/dd/yyyy') and to_date('"+endDate+"','MM/dd/yyyy') and " ); 			
			} else {
				alertInfoArgsList.add("");
			}
		}
		
		try{
			MessageFormat mf = new MessageFormat(query_total_rev_impacted_credit);
			prepareStatement = mf.format((String[])alertInfoArgsList.toArray(new String[alertInfoArgsList.size()]));
			logger.debug("AlertRuleRevenueService.queryTotalRevImpactedCredit() - Executing SQL statement: "+ prepareStatement);
			statement = connection.createStatement();
			rs = statement.executeQuery(prepareStatement);
			logger.debug("SQL - Execution complete.");
			if (rs != null && rs.next()) {
				alertRuleCredit = rs.getDouble(1);
			}
		} catch(SQLException sqle) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sqle.getMessage(), sqle);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sqle));
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(statement, failureList, logger);
		}
		return alertRuleCredit;
	}
	
	/**
	 * This is a private method to return the total revenue impacted debit objects
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return double
	 */
	private double queryTotalRevImpactedDebit(Connection connection,List failureList,List args, String dateOption){
		double alertRuleDebit = 0.0;
		List alertInfoArgsList = new ArrayList();
		String startDate = (String)args.get(0);
		String endDate = (String)args.get(1);
		String alertDate = (String)args.get(2);
		String alertRule = (String) args.get(3);
		String processPoint = (String) args.get(4);
		Statement statement = null;
		ResultSet rs = null;
		String prepareStatement = null;
		
		if ((alertRule != null) && (!alertRule.equals(""))) {
			alertInfoArgsList.add("c.alert_rule = '" + alertRule + "'");
		} else {
			alertInfoArgsList.add("c.alert_rule in (select alert_rule from rabc_cntrl_pt_alert where cntrl_pt_cd in (select cntrl_pt_cd from rabc_process where process= '" + processPoint + "'))");
		}
		
		if ("run".equals(dateOption)){
			if ((alertDate != null) && (!"".equals(alertDate))) {
				alertInfoArgsList.add("  c.alert_rule_run_dt = to_date('"+alertDate+"','MM/dd/yyyy') and  ");
			} else if((startDate != null && !"".equals(startDate)) && (endDate == null || "".equals(endDate))) {
				alertInfoArgsList.add("  c.alert_rule_run_dt = to_date('"+startDate+"','MM/dd/yyyy') and  ");
			} else if((startDate != null && !"".equals(startDate))  && (endDate != null && !"".equals(endDate))) {
				alertInfoArgsList.add("  c.alert_rule_run_dt between to_date('"+startDate+"','MM/dd/yyyy') and to_date('"+endDate+"','MM/dd/yyyy') and " ); 			
			} else {
				alertInfoArgsList.add("");
			}
		} else {
			if ((alertDate != null) && (!"".equals(alertDate))) {
				alertInfoArgsList.add("  c.proc_date = to_date('"+alertDate+"','MM/dd/yyyy') and  ");
			} else if((startDate != null && !"".equals(startDate)) && (endDate == null || "".equals(endDate))) {
				alertInfoArgsList.add("  c.proc_date = to_date('"+startDate+"','MM/dd/yyyy') and  ");
			} else if((startDate != null && !"".equals(startDate))  && (endDate != null && !"".equals(endDate))) {
				alertInfoArgsList.add("  c.proc_date between to_date('"+startDate+"','MM/dd/yyyy') and to_date('"+endDate+"','MM/dd/yyyy') and " ); 			
			} else {
				alertInfoArgsList.add("");
			}
		}
		
		try{
			MessageFormat mf = new MessageFormat(query_total_rev_impacted_debit);
			prepareStatement = mf.format((String[])alertInfoArgsList.toArray(new String[alertInfoArgsList.size()]));
			logger.debug("AlertRuleRevenueService.queryTotalRevImpactedDebit() - Executing SQL statement: "+ prepareStatement);
			statement = connection.createStatement();
			rs = statement.executeQuery(prepareStatement);
			logger.debug("SQL - Execution complete.");
			if (rs != null && rs.next()) {
				alertRuleDebit = rs.getDouble(1);
			}
		} catch(SQLException sqle) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sqle.getMessage(), sqle);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sqle));
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(statement, failureList, logger);
		}
		return alertRuleDebit;
	}
	
	/**
	 * This is a private method to return the total revenue impacted lost objects
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return double
	 */
	private double queryTotalRevImpactedLost(Connection connection,List failureList,List args,String dateOption){
		double alertRuleUnrecoverableRevenue = 0.0;
		List alertInfoArgsList = new ArrayList();
		String startDate = (String)args.get(0);
		String endDate = (String)args.get(1);
		String alertDate = (String)args.get(2);
		String alertRule = (String) args.get(3);
		String processPoint = (String) args.get(4);
		Statement statement = null;
		ResultSet rs = null;
		String prepareStatement = null;
		
		if ((alertRule != null) && (!alertRule.equals(""))) {
			alertInfoArgsList.add("c.alert_rule = '" + alertRule + "'");
		} else {
			alertInfoArgsList.add("c.alert_rule in (select alert_rule from rabc_cntrl_pt_alert where cntrl_pt_cd in (select cntrl_pt_cd from rabc_process where process= '" + processPoint + "'))");
		}
		
		if ("run".equals(dateOption)){
			if ((alertDate != null) && (!"".equals(alertDate))) {
				alertInfoArgsList.add("  c.alert_rule_run_dt = to_date('"+alertDate+"','MM/dd/yyyy') and  ");
			} else if((startDate != null && !"".equals(startDate)) && (endDate == null || "".equals(endDate))) {
				alertInfoArgsList.add("  c.alert_rule_run_dt = to_date('"+startDate+"','MM/dd/yyyy') and  ");
			} else if((startDate != null && !"".equals(startDate))  && (endDate != null && !"".equals(endDate))) {
				alertInfoArgsList.add("  c.alert_rule_run_dt between to_date('"+startDate+"','MM/dd/yyyy') and to_date('"+endDate+"','MM/dd/yyyy') and " ); 			
			} else {
				alertInfoArgsList.add("");
			}
		} else {
			if ((alertDate != null) && (!"".equals(alertDate))) {
				alertInfoArgsList.add("  c.proc_date = to_date('"+alertDate+"','MM/dd/yyyy') and  ");
			} else if((startDate != null && !"".equals(startDate)) && (endDate == null || "".equals(endDate))) {
				alertInfoArgsList.add("  c.proc_date = to_date('"+startDate+"','MM/dd/yyyy') and  ");
			} else if((startDate != null && !"".equals(startDate))  && (endDate != null && !"".equals(endDate))) {
				alertInfoArgsList.add("  c.proc_date between to_date('"+startDate+"','MM/dd/yyyy') and to_date('"+endDate+"','MM/dd/yyyy') and " ); 			
			} else {
				alertInfoArgsList.add("");
			}
		}

		try{
			MessageFormat mf = new MessageFormat(query_total_rev_impacted_lost);
			prepareStatement = mf.format((String[])alertInfoArgsList.toArray(new String[alertInfoArgsList.size()]));
			logger.debug("AlertRuleRevenueService.queryTotalRevImpactedLost() - Executing SQL statement: "+ prepareStatement);
			statement = connection.createStatement();
			rs = statement.executeQuery(prepareStatement);
			logger.debug("SQL - Execution complete.");
			if (rs != null && rs.next()) {
				alertRuleUnrecoverableRevenue = rs.getDouble(1);
			}
		} catch(SQLException sqle) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sqle.getMessage(), sqle);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sqle));
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(statement, failureList, logger);
		}
		return alertRuleUnrecoverableRevenue;
	}

	/**
	 * This is a private method for constructing the alertRuleRevenue objects
	 * 
	 * @param list
	 * @return AlertRuleRevenue
	 */
	private AlertRuleRevenue buidAlertRuleRevenue(List list) {
		AlertRuleRevenue alertRuleRevenue = new AlertRuleRevenue();	
		alertRuleRevenue.setHead((String)list.get(0));
		alertRuleRevenue.setCredit(((Double)list.get(1)).doubleValue());
		alertRuleRevenue.setDebit(((Double)list.get(2)).doubleValue());
		alertRuleRevenue.setUnrecoverableRevenue(((Double)list.get(3)).doubleValue());
		return alertRuleRevenue;
	}
	
	/**
	 * Method to return the list of AlertRuleInvestigations objects.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param progressBar
	 * @return List
	 */
	protected List getAlertRuleInvestigationsList(Connection connection, List failureList, List args, ProgressBar progressBar) {
		List alertRuleInvestigationsList = new ArrayList();
		AlertRuleInvestigations alertRuleInvestigations = null;
		List alertRuleInvestigationsArgsList = new ArrayList();
		String startDate = (String)args.get(0);
		String endDate = (String)args.get(1);
		String alertDate = (String)args.get(2);
		String processPoint = (String)args.get(4);
		Statement statement = null;
		ResultSet rs = null;
		String prepareStatement = null;
		
		alertRuleInvestigationsArgsList.add(processPoint);
		if ((alertDate != null) && (!"".equals(alertDate))) {
			alertRuleInvestigationsArgsList.add("  and run_date = to_date('"+alertDate+"','MM/dd/yyyy')");
		} else if((startDate != null && !"".equals(startDate)) && (endDate == null || "".equals(endDate))) {
			alertRuleInvestigationsArgsList.add("  and run_date = to_date('"+startDate+"','MM/dd/yyyy')");
		} else if((startDate != null && !"".equals(startDate)) && (endDate != null && !"".equals(endDate))) {
			alertRuleInvestigationsArgsList.add("  and run_date between to_date('"+startDate+"','MM/dd/yyyy') and to_date('"+endDate+"','MM/dd/yyyy')");
		} else {
			alertRuleInvestigationsArgsList.add("");
		}
		progressBar.setProgressPercent(progressBar.getPercent() + 10);
		try{
			MessageFormat mf = new MessageFormat(query_getCertInfo);
			prepareStatement = mf.format((String[])alertRuleInvestigationsArgsList.toArray(new String[alertRuleInvestigationsArgsList.size()]));
			logger.debug("AlertRuleRevenueService.getAlertRuleInvestigationsList() - Executing SQL statement: "+ prepareStatement);
			statement = connection.createStatement();
			rs = statement.executeQuery(prepareStatement);
			logger.debug("SQL - Execution complete.");
			if (rs != null) {
				while(rs.next()){
					alertRuleInvestigations = buidAlertRuleInvestigations(rs);
					alertRuleInvestigationsList.add(alertRuleInvestigations);
				}
			}
		} catch(SQLException sqle) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sqle.getMessage(), sqle);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sqle));
			return null;
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(statement, failureList, logger);
		}
		progressBar.setProgressPercent(progressBar.getPercent() + 10);
		return alertRuleInvestigationsList;
	}
	
	/**
	 * This is a private method for constructing the AlertRuleInvestigations objects
	 * 
	 * @param resultSet
	 * @return AlertRuleInvestigations
	 * @throws SQLException
	 */
	private AlertRuleInvestigations buidAlertRuleInvestigations(ResultSet resultSet) throws SQLException {
		AlertRuleInvestigations alertRuleInvestigations = new AlertRuleInvestigations();
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		alertRuleInvestigations.setCertificationDate(dateFormat.format(resultSet.getDate(1)));
		alertRuleInvestigations.setDivision(resultSet.getString(2));
		alertRuleInvestigations.setCredit(resultSet.getDouble(3));
		alertRuleInvestigations.setDebit(resultSet.getDouble(4));
		alertRuleInvestigations.setUnrecoverableRevenue(resultSet.getDouble(5));
		String certInd = resultSet.getString(6);
		if ("Y".equalsIgnoreCase(certInd)) {
			alertRuleInvestigations.setStatus("Yes");
		} else if ("N".equalsIgnoreCase(certInd)) {
			alertRuleInvestigations.setStatus("No");
		} else {
			alertRuleInvestigations.setStatus(" ");
		}
		return alertRuleInvestigations;
	}
	
	/**
	 * Method to return the list of AlertRuleWarnings objects.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param progressBar
	 * @return List
	 */ 
	protected List getAlertRuleWarningsList(Connection connection, List failureList, List args, ProgressBar progressBar, String dateOption) {
		List alertRuleWarningsList = new ArrayList();
		AlertRuleWarnings alertRuleWarnings = null;
		List alertRuleWarningsArgsList = new ArrayList();
		String startDate = (String)args.get(0);
		String endDate = (String)args.get(1);
		String alertDate = (String)args.get(2);
		String alertRule = (String)args.get(3);
		String processPoint = (String)args.get(4);
		Statement statement = null;
		ResultSet rs = null;
		String prepareStatement = null;
		
		if ((alertRule != null) && (!alertRule.equals(""))) {
			alertRuleWarningsArgsList.add("c.alert_rule = '" + alertRule + "'");
		} else {
			alertRuleWarningsArgsList.add("c.alert_rule in (select alert_rule from rabc_cntrl_pt_alert where cntrl_pt_cd in (select cntrl_pt_cd from rabc_process where process= '" + processPoint + "'))");
		}
		
		if ("run".equals(dateOption)){
			if ((alertDate != null) && (!"".equals(alertDate))) {
				alertRuleWarningsArgsList.add("  c.alert_rule_run_dt = to_date('"+alertDate+"','MM/dd/yyyy') and ");
			} else if((startDate != null && !"".equals(startDate)) && (endDate == null || "".equals(endDate))) {
				alertRuleWarningsArgsList.add("  c.alert_rule_run_dt = to_date('"+startDate+"','MM/dd/yyyy') and ");
			} else if((startDate != null && !"".equals(startDate)) && (endDate != null && !"".equals(endDate))) {
				alertRuleWarningsArgsList.add("  c.alert_rule_run_dt between to_date('"+startDate+"','MM/dd/yyyy') and to_date('"+endDate+"','MM/dd/yyyy') and ");
			} else {
				alertRuleWarningsArgsList.add("");
			}
		} else {
			if ((alertDate != null) && (!"".equals(alertDate))) {
				alertRuleWarningsArgsList.add("  c.proc_date = to_date('"+alertDate+"','MM/dd/yyyy') and ");
			} else if((startDate != null && !"".equals(startDate)) && (endDate == null || "".equals(endDate))) {
				alertRuleWarningsArgsList.add("  c.proc_date = to_date('"+startDate+"','MM/dd/yyyy') and ");
			} else if((startDate != null && !"".equals(startDate)) && (endDate != null && !"".equals(endDate))) {
				alertRuleWarningsArgsList.add("  c.proc_date between to_date('"+startDate+"','MM/dd/yyyy') and to_date('"+endDate+"','MM/dd/yyyy') and ");
			} else {
				alertRuleWarningsArgsList.add("");
			}
		}
		
		progressBar.setProgressPercent(progressBar.getPercent() + 10);
		try{
			MessageFormat mf = new MessageFormat(query_getAlertInfo);
			prepareStatement = mf.format((String[])alertRuleWarningsArgsList.toArray(new String[alertRuleWarningsArgsList.size()]));
			logger.debug("AlertRuleRevenueService.getAlertRuleWarningsList() - Executing SQL statement: "+ prepareStatement);
			statement = connection.createStatement();
			rs = statement.executeQuery(prepareStatement);
			logger.debug("SQL - Execution complete.");
			if (rs != null) {
				while(rs.next()){
					alertRuleWarnings = buidAlertRuleWarnings(rs);
					alertRuleWarningsList.add(alertRuleWarnings);
				}
			}			
		} catch(SQLException sqle) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sqle.getMessage(), sqle);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sqle));
			return null;
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(statement, failureList, logger);
		}
		progressBar.setProgressPercent(progressBar.getPercent() + 10);
		return alertRuleWarningsList;
	}
	
	/**
	 * This is a private method for constructing the AlertRuleWarnings objects
	 * 
	 * @param resultSet
	 * @return AlertRuleWarnings
	 * @throws SQLException
	 */
	private AlertRuleWarnings buidAlertRuleWarnings(ResultSet resultSet) throws SQLException {
		AlertRuleWarnings alertRuleWarnings = new AlertRuleWarnings();	
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		alertRuleWarnings.setAlertRule(resultSet.getString(1));
		alertRuleWarnings.setAlertDate(dateFormat.format(resultSet.getDate(2)));
		alertRuleWarnings.setDivision(resultSet.getString(3));
		alertRuleWarnings.setDataItem(resultSet.getString(4));
		alertRuleWarnings.setRevenueImpact(resultSet.getDouble(5));
		alertRuleWarnings.setRootCauseCategory(resultSet.getString(6));
		alertRuleWarnings.setUnrecoverableRevenue(resultSet.getDouble(7));
		alertRuleWarnings.setStatus(resultSet.getString(8));
		alertRuleWarnings.setComments(resultSet.getString(9));
		alertRuleWarnings.setAlertKey2(resultSet.getString(10));
		alertRuleWarnings.setAlertKey3(resultSet.getString(11));
		alertRuleWarnings.setAlertKey4(resultSet.getString(12));
		alertRuleWarnings.setAlertKey5(resultSet.getString(13));
		String urlKey2 = resultSet.getString(14);
		String urlKey3 = resultSet.getString(15);
		String urlKey4 = resultSet.getString(16);
		String urlKey5 = resultSet.getString(17);
		alertRuleWarnings.setAlertData2(urlKey2);
		alertRuleWarnings.setAlertData3(urlKey3);
		alertRuleWarnings.setAlertData4(urlKey4);
		alertRuleWarnings.setAlertData5(urlKey5);
		if ((urlKey2 == null || urlKey2.equals("")) && (urlKey3 == null || urlKey3.equals("")) && (urlKey4 == null || urlKey4.equals("")) 
				&& (urlKey5 == null || urlKey5.equals(""))) {
			alertRuleWarnings.setKeyRow(0);
		} else {
			alertRuleWarnings.setKeyRow(1);
		}
		return alertRuleWarnings;
	}
	
	/**
	 * This is a method to generate the excel report.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param report
	 * @param progressBar
	 */
	public void getExcelReport(Connection connection, List failureList, List args, ExcelReport report, ProgressBar progressBar,String dateOption) {
		int counter = 0;
		String startDate =(String) args.get(0);
		String endDate = (String) args.get(1);
		String region = (String) args.get(5);
		String cycle = "";
		String rawColor = null;
		int alertRuleRevenueListSize = 0;
		int alertRuleInvestigationsListSize = 0;
		int alertRuleWarningsListSize = 0;
		AlertRuleRevenue alertRuleRevenue = new AlertRuleRevenue();
		AlertRuleInvestigations alertRuleInvestigations = new AlertRuleInvestigations();
		AlertRuleWarnings alertRuleWarnings = new AlertRuleWarnings();
		NumberFormat formatter = new DecimalFormat(",##0.00");
				
		if ("WE".equalsIgnoreCase(region)) {
			/*
			 * Call method getCycleCalendarList(connection, failureList, args) to get the list of cycles.
			 */
			List cycleList = getCycleCalendarList(connection, failureList, args);
			progressBar.setProgressPercent(progressBar.getPercent() + 10);
			if (cycleList != null) {
				int cycleListSize = cycleList.size();
				if (cycleListSize > 0) {
					if (cycleListSize == 1) {
						cycle = ((new StringBuffer())
							.append("Cycle(s): ")
							.append(((Integer)cycleList.get(0)).toString()))
							.toString();
					} else {
						cycle = ((new StringBuffer())
							.append("Cycle(s): ")
							.append(((Integer)cycleList.get(0)).toString())
							.append(" - ")
							.append(((Integer)cycleList.get(cycleListSize-1)).toString()))
							.toString();
					}
				} else {
					cycle = "";
				}
			} else {
				cycle = "";
			}
		}
		
		List alertRuleRevenueList = getAlertRuleRevenueList(connection,failureList,args,progressBar, region, dateOption);
		List alertRuleInvestigationsList = null;
		if (!region.equals("C2")) {
			alertRuleInvestigationsList = getAlertRuleInvestigationsList(connection,failureList,args,progressBar);
		} else {
			progressBar.setProgressPercent(progressBar.getPercent() + 20);
		}
		List alertRuleWarningsList = getAlertRuleWarningsList(connection,failureList,args,progressBar, dateOption);
		
		try {				
			report.beginReport();
				report.beginTable();
					report.beginRow();
						report.addRaw("<td nowrap align=\"center\" colspan=\"8\">");
							report.addRaw("<b>Alert Dashboard</b>");
						report.addRaw("</td>");
					report.endRow();
					
					report.beginRow();
						report.addRaw("<td nowrap align=\"center\" colspan=\"8\">");
							report.addRaw("<b>Revenue Impacted Alert Rule</b>");
						report.addRaw("</td>");
					report.endRow();
					
					report.beginRow();							
						if((startDate != null && !startDate.equals("")) && (endDate != null && !endDate.equals(""))) {
							report.addRaw("<td nowrap align=\"center\" colspan=\"8\">");
							if ("run".equals(dateOption)){
								report.addRaw("<b>From Alert Run Dates:</b> " + startDate + " - " + endDate + "     " + cycle);
							} else {
								report.addRaw("<b>From Alert File Dates:</b> " + startDate + " - " + endDate + "     " + cycle);
							}
							report.endRow();
						} else {
							report.addRaw("<td nowrap align=\"center\" colspan=\"8\">");
							if ("run".equals(dateOption)){
								report.addRaw("<b>For Alert Run Date:</b> " + startDate + "     " + cycle);
							} else {
								report.addRaw("<b>For Alert File Date:</b> " + startDate + "     " + cycle);
							}
							report.addRaw("</td>");
						}
					report.endRow();
					
					report.beginRow();
					report.endRow();
					
					report.beginRow();
					report.endRow();
					
					report.beginRow();
						report.addRaw("<td nowrap align=\"left\" colspan=\"8\">");
							report.addRaw("&nbsp;&nbsp;&nbsp;<b>Total Revenue Impacted</b>");
						report.addRaw("</td>");
					report.endRow();
					
					report.beginRow();
						report.addRaw("<td nowrap align=\"left\" colspan=\"8\">");
							report.addRaw("<table width=100% border=1>");
								report.beginRow();
									report.addHeader("");
									report.addHeader("Credit");
									report.addHeader("Debit");
									report.addHeader("Unrecoverable");
								report.endRow();
								if (alertRuleRevenueList != null) {
									alertRuleRevenueListSize = alertRuleRevenueList.size();
									for(counter=0; counter<alertRuleRevenueListSize; counter++) {
										alertRuleRevenue = (AlertRuleRevenue) alertRuleRevenueList.get(counter);
										report.beginRow();
											report.addColumn(alertRuleRevenue.getHead());
											report.addCurrency(alertRuleRevenue.getCredit());
											report.addCurrency(alertRuleRevenue.getDebit());
											report.addCurrency(alertRuleRevenue.getUnrecoverableRevenue());
										report.endRow();
									}
								}
							report.addRaw("</table>");
						report.addRaw("</td>");
					report.endRow();
					
					report.beginRow();
						report.addRaw("<td>&nbsp;</td>");
					report.endRow();
					
					report.beginRow();
						report.addRaw("<td>&nbsp;</td>");
					report.endRow();
				if (!region.equals("C2")) {	
					report.beginRow();
						report.addRaw("<td nowrap align=\"left\" colspan=\"8\">");
							report.addRaw("&nbsp;&nbsp;&nbsp;<b>Revenue Impacted from other Investigations</b>");
						report.addRaw("</td>");
					report.endRow();
					
					report.beginRow();
						report.addRaw("<td nowrap align=\"left\" colspan=\"8\">");
							report.addRaw("<table width=100% border=1>");
								report.beginRow();
									report.addHeader("Certification Date");
									report.addHeader("State");
									report.addHeader("Revenue Credit");
									report.addHeader("Revenue Debit");
									report.addHeader("Unrecoverable");
									report.addHeader("Certification Status");
								report.endRow();
								if (alertRuleInvestigationsList != null) {
									alertRuleInvestigationsListSize = alertRuleInvestigationsList.size();
									if (alertRuleInvestigationsListSize > 0) {
										for(counter=0; counter<alertRuleInvestigationsListSize; counter++) {
											alertRuleInvestigations= (AlertRuleInvestigations)alertRuleInvestigationsList.get(counter);
											report.beginRow();
												report.addColumn(alertRuleInvestigations.getCertificationDate());
												report.addColumn(alertRuleInvestigations.getDivision());
												report.addCurrency(alertRuleInvestigations.getCredit());
												report.addCurrency(alertRuleInvestigations.getDebit());
												report.addCurrency(alertRuleInvestigations.getUnrecoverableRevenue());
												report.addColumn(alertRuleInvestigations.getStatus());
											report.endRow();
										}
									} else {
										report.addRaw("<td nowrap align=\"center\" colspan=\"6\">");
											report.addRaw("<b>No data available.</b>");
										report.addRaw("</td>");
									}
								}
							report.addRaw("</table>");
						report.addRaw("</td>");
					report.endRow();
				}		
					report.beginRow();
						report.addRaw("<td>&nbsp;</td>");
					report.endRow();
					
					report.beginRow();
						report.addRaw("<td>&nbsp;</td>");
					report.endRow();
					
				
					report.beginRow();
						report.addRaw("<td nowrap align=\"left\" colspan=\"8\">");
							report.addRaw("&nbsp;&nbsp;&nbsp;<b>Revenue Impacted from Alert Rule Warnings</b>");
						report.addRaw("</td>");
					report.endRow();
					
					report.beginRow();
						report.addRaw("<td nowrap align=\"left\" colspan=\"8\">");
							report.addRaw("<table width=100% border=1>");
								report.beginRow();
									report.addRaw("<th>Alert<br>Date</th>");
									report.addHeader("Division");	
									report.addHeader("Alert Rule");
									report.addHeader("Data Item");
									report.addRaw("<th>Revenue<br>Impact</th>");
									report.addHeader("Unrecoverable");
									report.addRaw("<th>Root Cause<br>Category</th>");
									report.addHeader("Status");
								report.endRow();
								if (alertRuleWarningsList != null) {
									alertRuleWarningsListSize = alertRuleWarningsList.size();
									if (alertRuleWarningsListSize > 0) {
										for(counter=0; counter<alertRuleWarningsListSize; counter++) {
											alertRuleWarnings = (AlertRuleWarnings)alertRuleWarningsList.get(counter);
											report.beginRow();
												report.addColumn(alertRuleWarnings.getAlertDate());
												report.addColumn(alertRuleWarnings.getDivision());
												report.addColumn(alertRuleWarnings.getAlertRule());
												report.addColumn(alertRuleWarnings.getDataItem());
												report.addCurrency(alertRuleWarnings.getRevenueImpact());
												report.addCurrency(alertRuleWarnings.getUnrecoverableRevenue());
												report.addColumn(alertRuleWarnings.getRootCauseCategory());
												report.addColumn(alertRuleWarnings.getStatus());
											report.endRow();	
											if (alertRuleWarnings.getKeyRow() == 1) {
												report.beginRow();
													if ((alertRuleWarnings.getAlertData2() != null) && (!alertRuleWarnings.getAlertData2().equals(""))) {
														if ((alertRuleWarnings.getAlertKey2() != null) && (!alertRuleWarnings.getAlertKey2().equals(""))) {
															report.addRaw("<td colspan=\"2\"><b>" + alertRuleWarnings.getAlertKey2() + ":</b> " + alertRuleWarnings.getAlertData2() + "</td>");
														} else {
															report.addRaw("<td colspan=\"2\"><b>Key2:</b> " + alertRuleWarnings.getAlertData2() + "</td>");
														}
													}
													if ((alertRuleWarnings.getAlertData3() != null) && (!alertRuleWarnings.getAlertData3().equals(""))) {
														if ((alertRuleWarnings.getAlertKey3() != null) && (!alertRuleWarnings.getAlertKey3().equals(""))) {
															report.addRaw("<td colspan=\"2\"><b>" + alertRuleWarnings.getAlertKey3() + ":</b> " + alertRuleWarnings.getAlertData3() + "</td>");
														} else {
															report.addRaw("<td colspan=\"2\"><b>Key2:</b> " + alertRuleWarnings.getAlertData3() + "</td>");
														}
													}
													if ((alertRuleWarnings.getAlertData4() != null) && (!alertRuleWarnings.getAlertData4().equals(""))) {
														if ((alertRuleWarnings.getAlertKey4() != null) && (!alertRuleWarnings.getAlertKey4().equals(""))) {
															report.addRaw("<td colspan=\"2\"><b>" + alertRuleWarnings.getAlertKey4() + ":</b> " + alertRuleWarnings.getAlertData4() + "</td>");
														} else {
															report.addRaw("<td colspan=\"2\"><b>Key2:</b> " + alertRuleWarnings.getAlertData4() + "</td>");
														}
													}
													if ((alertRuleWarnings.getAlertData5() != null) && (!alertRuleWarnings.getAlertData5().equals(""))) {
														if ((alertRuleWarnings.getAlertKey5() != null) && (!alertRuleWarnings.getAlertKey5().equals(""))) {
															report.addRaw("<td colspan=\"2\"><b>" + alertRuleWarnings.getAlertKey5() + ":</b> " + alertRuleWarnings.getAlertData5() + "</td>");
														} else {
															report.addRaw("<td colspan=\"2\"><b>Key2:</b> " + alertRuleWarnings.getAlertData5() + "</td>");
														}
													}
												report.endRow();
											}
											report.beginRow();
												report.addRaw("<td colspan=\"2\" align=\"right\"><b>Comments:</b></td>");
												report.addRaw("<td colspan=\"6\" align=\"left\">" + alertRuleWarnings.getComments() + "</td>");
											report.endRow();
										}
									} else {
										report.addRaw("<td nowrap align=\"center\" colspan=\"8\">");
											report.addRaw("<b>No data available.</b>");
										report.addRaw("</td>");
									}
								}
							report.addRaw("</table>");
						report.addRaw("</td>");
					report.endRow();
				report.endTable();
			report.endReport();
		} catch (IOException iox) {
			logger.error("Error in creting the excel report. Exception details: " + iox.getMessage(), iox);
		  	failureList.add(new RABCException("Error in creting the excel report.", iox));
		}
	}
}
