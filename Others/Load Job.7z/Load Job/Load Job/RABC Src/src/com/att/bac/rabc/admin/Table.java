/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/

package com.att.bac.rabc.admin;

import java.util.ArrayList;
import java.util.List;

/**
 * Form bean used for table tree
 * 
 * @author Anup Thomas - AT1862
 *
 */
public class Table {
	private String tableName;
	private List columnList = new ArrayList();
	
	/**
	 * @return Returns the tableName.
	 */
	public String getTableName() {
		return tableName;
	}
	/**
	 * @param tableName The tableName to set.
	 */
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	/**
	 * @return Returns the columnList.
	 */
	public List getColumnList() {
		return columnList;
	}
	/**
	 * @param string 
	 */
	public void addColumn(String columnName) {
		this.columnList.add(columnName); 
	}
}
