/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.alerts.status;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.att.bac.rabc.ConnectionManager;
import com.att.bac.rabc.DateUtil;
import com.att.bac.rabc.MyDate;
import com.att.bac.rabc.PickList;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.admin.alert.rule.AlertRule;

/**
 * Module description: 
 * 
 * This is an action class that controls the actions required to generate the graph page for the report.
 * 
 * @author Shailesh Hemdev - SH8512
 */
public class GraphAction extends DispatchAction {
	private static final Logger logger = Logger.getLogger(GraphAction.class);
	private GraphService graphService = GraphService.getGraphService();
	private PercentGraphService percentGraphService = PercentGraphService.getPercentGraphService();
	private DataGraphService dataGraphService = DataGraphService.getDataGraphService();
	
	/**
	 * Default dispatch action method to handel the request to generate the graph page.
	 * It collects the URL parameters & set them to the corresponding graph parameters.
	 * In last, it calls another action method to build the graph. 
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @see org.apache.struts.actions.DispatchAction#unspecified(org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public ActionForward unspecified(ActionMapping mapping,ActionForm form,HttpServletRequest request, HttpServletResponse response)  {
		Enumeration et = request.getParameterNames();
		GraphForm graphForm = (GraphForm)form;
		GraphParameters graphParameters = graphForm.getGraphParameters();
		List failureList = new ArrayList();
		
		try {
			while (et.hasMoreElements()){
				String paramName = (String)et.nextElement();
				String paramValue = request.getParameter(paramName);
				
				if ("alertrule".equals(paramName.trim())){
					if (!"".equals(paramValue.trim())){
						graphParameters.setAlertrule(URLDecoder.decode(paramValue.trim(),"UTF-8"));
					}
				}
				
				if ("alertItem".equals(paramName.trim())){
					if (!"".equals(paramValue.trim()) && !"null".equals(paramValue.trim())){
						String alertItem = paramValue.trim();
						alertItem = alertItem.replace('+', '~');
						alertItem = URLDecoder.decode(alertItem.trim(),"UTF-8");
						alertItem = alertItem.replace('~', '+');
						graphParameters.setAlertItem(alertItem);
					}
				}
				
				if ("alertTimeInd".equals(paramName.trim())){
					if (!"".equals(paramValue.trim())){
						graphParameters.setAlertTimeInd(paramValue.trim());
					}
				}
				
				if ("alertTimeValue".equals(paramName.trim())){
					if (!"".equals(paramValue.trim()) && !"-1".equals(paramValue.trim())){
						graphParameters.setAlertTimeValue(paramValue.trim());
					}
				}
				
				if ("extractDateName".equals(paramName.trim())){
					if (!"".equals(paramValue.trim())){
						graphParameters.setExtractDateName(paramValue.trim());
					}
				}
				
				if ("fileSeqNum".equals(paramName.trim())){
					if (!"".equals(paramValue.trim())){
						graphParameters.setFileSeqNum(paramValue.trim());
					}
				}
				
				if ("itemDDlName".equals(paramName.trim())){
					if (!"".equals(paramValue.trim())){
						graphParameters.setItemDDlName(paramValue.trim());
					}
				}
				
				if ("key1".equals(paramName.trim())){
					if (!"".equals(paramValue.trim()) && !"''".equals(paramValue.trim()) && !"".equals(paramValue.trim())){
						graphParameters.setKey1(paramValue.trim());
					}
				}
				if ("key2".equals(paramName.trim())){
					if (!"".equals(paramValue.trim()) && !"''".equals(paramValue.trim())&& !"''".equals(paramValue.trim())){
						graphParameters.setKey2(paramValue.trim());
					}
				}
				if ("key3".equals(paramName.trim())){
					if (!"".equals(paramValue.trim()) && !"''".equals(paramValue.trim()) && !"''".equals(paramValue.trim())){
						graphParameters.setKey3(paramValue.trim());
					}
				}
				if ("key4".equals(paramName.trim())){
					if (!"".equals(paramValue.trim()) && !"''".equals(paramValue.trim()) && !"''".equals(paramValue.trim())){
						graphParameters.setKey4(paramValue.trim());
					}
				}
				if ("key5".equals(paramName.trim())){
					if (!"".equals(paramValue.trim()) && !"''".equals(paramValue.trim()) && !"''".equals(paramValue.trim())){
						graphParameters.setKey5(paramValue.trim());
					}
				}
				
				/*
				 * Parameters added to address exception in Page 13. Since page 13 cannot pass the parameter values as 
				 * expected by the graph program, this modification has been done in graph program despite redundancy
				 */
				if ("aKey1".equals(paramName.trim())){
					if (!"".equals(paramValue.trim()) && !"''".equals(paramValue.trim()) && !"".equals(paramValue.trim())){
						graphParameters.setAkey1(paramValue.trim());
					}
				}
				if ("aKey2".equals(paramName.trim())){
					if (!"".equals(paramValue.trim()) && !"''".equals(paramValue.trim())&& !"''".equals(paramValue.trim())){
						graphParameters.setAkey2(paramValue.trim());
					}
				}
				if ("aKey3".equals(paramName.trim())){
					if (!"".equals(paramValue.trim()) && !"''".equals(paramValue.trim()) && !"''".equals(paramValue.trim())){
						graphParameters.setAkey3(paramValue.trim());
					}
				}
				if ("aKey4".equals(paramName.trim())){
					if (!"".equals(paramValue.trim()) && !"''".equals(paramValue.trim()) && !"''".equals(paramValue.trim())){
						graphParameters.setAkey4(paramValue.trim());
					}
				}
				if ("aKey5".equals(paramName.trim())){
					if (!"".equals(paramValue.trim()) && !"''".equals(paramValue.trim()) && !"''".equals(paramValue.trim())){
						graphParameters.setAkey5(paramValue.trim());
					}
				}
				
				if ("PartiRefId".equals(paramName.trim())){
					if (!"".equals(paramValue.trim())){
						graphParameters.setPartiRefId(Integer.parseInt(paramValue.trim()));
					}
				}
				
				if ("ProcDate".equals(paramName.trim())){
					if (!"".equals(paramValue.trim())){
						try {
							MyDate procDate = new MyDate(paramValue.trim(),"MM/dd/yyyy");
							graphParameters.setProcDate(procDate);
						}catch (ParseException e){
							Date d = null;
							try {
								d = DateUtil.parseUnknown(paramValue.trim());
								if (d == null){
									graphParameters.setProcDate(new MyDate(new Date(System.currentTimeMillis())));
								} else {
									graphParameters.setProcDate(new MyDate(d));
								}
							} catch (ParseException e1) {
								graphParameters.setProcDate(new MyDate(new Date(System.currentTimeMillis())));
							}
						}
					}
				}
				
				if ("tableName".equals(paramName.trim())){
					if (!"".equals(paramValue.trim())){
						graphParameters.setTableName(paramValue);
					}
				}
				
				if ("Header".equals(paramName.trim())){
					if (!"".equals(paramValue.trim())){
						graphParameters.setHeader(paramValue);
					}
				}
				
				if ("PresnId".equals(paramName.trim())){
					if (!"".equals(paramValue.trim())){
						graphParameters.setPresnId(Integer.parseInt(paramValue.trim()));
					}
				}
				
				if ("key1colname".equals(paramName.trim())){
					if (!"".equals(paramValue.trim())){
						graphParameters.setKey1colname(paramValue.trim());
					}
				}
				
				if ("graphType".equals(paramName.trim())){
					if (!"".equals(paramValue.trim())){
						graphParameters.setGraphType(paramValue.trim());
					}
				}

				if ("dayspan".equals(paramName.trim())){
					if (!"".equals(paramValue.trim())){
						graphParameters.setDaySpan(Integer.parseInt(paramValue.trim()));
					}
				}
				
				if ("colmnName".equals(paramName.trim())){
					if (!"".equals(paramValue.trim())){
						graphParameters.setColumnName(paramValue.trim());
					}
				}
				
				if ("colmnValue".equals(paramName.trim())){
					if (!"".equals(paramValue.trim())){
						graphParameters.setColumnValue(paramValue.trim());
					}
				}
			}

			graphForm.setGraphParameters(graphParameters);
			
		} catch (UnsupportedEncodingException e){
			logger.error(RABCMessages.getMessage("ERR_ENCODING_EXEC", new String[] {"Unsupported Encoding exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_ENCODING_EXEC", new String[] {"Unsupported Encoding exception for decode operation done on graph parameters"}), e));
		}
		
		if (!failureList.isEmpty()){
			request.setAttribute("failures", failureList);
			return mapping.findForward("error");
		} else {
			return buildGraph(mapping,graphForm,request,response);
		}
	}
	
	/**
	 * Dispatch action method to handel the request to build the graph.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @see org.apache.struts.actions.DispatchAction#unspecified(org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public ActionForward buildGraph(ActionMapping mapping,ActionForm form,HttpServletRequest request, 
			HttpServletResponse response)  {
		GraphForm graphForm = (GraphForm)form;
		Connection connection = null;
		List failureList = new ArrayList();

		defaultChecks(graphForm);
		buildGraphParameters(graphForm, graphService);
		
		try{
			connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));

			preGraphGenerationChecks(connection, failureList,graphForm);
			
			/*
			 * Get the key 1 values for the filters on top of the JSP
			 */
			HttpSession session = request.getSession(false);
			String region = (String)session.getAttribute("region");
			List args1 = new ArrayList();
			
			args1.add(region);
			
			List key1ValuesList = graphService.getKey1ValuesList(connection,failureList,args1, graphForm.getGraphParameters());
			if (!key1ValuesList.isEmpty()){
				int key1ValuesListSize = key1ValuesList.size();
				for (int i=0;i<key1ValuesListSize;i++){
					PickList key1Value = (PickList)key1ValuesList.get(i);
					PickList keyToAdd;
					if (key1Value.getKey().equals(graphForm.getGraphParameters().getKey1())){
						keyToAdd = new PickList(key1Value.getKey(),key1Value.getValue1(),"KeyNameLinkActive");
					}else {
						keyToAdd = new PickList(key1Value.getKey(),key1Value.getValue1(),"KeyNameLink");
					}
					graphForm.addKey1(keyToAdd);
				}
			}

			GraphParameters graphParameters = graphForm.getGraphParameters();
			
			/*
			 * Get the title as well as the selection criteria
			 */
			graphForm.setPercentGraphTitle(percentGraphService.getTitle(graphForm.getGraphParameters()));
			graphForm.setPercentGraphSelectionCriteria(percentGraphService.getSelectionCriteria(graphForm.getGraphParameters(),connection,failureList,region));
			graphForm.setDataGraphTitle(dataGraphService.getTitle(graphForm.getGraphParameters(),graphForm.getPercentGraphFlg(),connection,failureList));
			graphForm.setDataGraphSelectionCriteria(dataGraphService.getSelectionCriteria(graphForm.getGraphParameters(),connection,failureList,region));
			
			/*
			 * Process for percent graph only if it is to be shown
			 */
			if ("Y".equals(graphForm.getPercentGraphFlg())){
				List percentGraphDataList = percentGraphService.buildPercentGraph(graphForm.getGraphParameters(),connection,failureList);

				if (percentGraphDataList!=null){
					if (!percentGraphDataList.isEmpty()){
						PercentGraph percentGraph = new PercentGraph();
						percentGraph.updateList(percentGraphDataList);
						graphForm.setPercentGraph(percentGraph);
						request.setAttribute("percentGraph",percentGraph);
						
						if (graphParameters.getFileSeqNum()!=null){
							graphForm.setPercentGraphXAxisTitle("File Sequence Number");
						}else if ("B".equals(graphParameters.getAlertTimeInd()) || "AB".equals(graphParameters.getAlertTimeInd())){
							if ("MW".equals(region)){
								graphForm.setPercentGraphXAxisTitle("Process Group");
							}else {
								graphForm.setPercentGraphXAxisTitle("Bill Cycle");
							}
						}else if ("M".equals(graphParameters.getAlertTimeInd())){
							graphForm.setPercentGraphXAxisTitle("Month of the Year");
						}else {
							graphForm.setPercentGraphXAxisTitle("Day of the Month");
						}
					}
				}
			}
			
			List dataGraphDataList = dataGraphService.buildDataGraph(graphForm.getGraphParameters(),connection,failureList,(String)request.getSession().getAttribute("region"));
			
			if (dataGraphDataList!=null){
				if (!dataGraphDataList.isEmpty()){
					DataGraph dataGraph = new DataGraph();
					dataGraph.updateList(dataGraphDataList);
					graphForm.setDataGraph(dataGraph);
					request.setAttribute("dataGraph",dataGraph);
					
					if (graphParameters.getFileSeqNum()!=null){
						graphForm.setDataGraphXAxisTitle("File Sequence Number");
					}else if ("B".equals(graphParameters.getAlertTimeInd()) || "AB".equals(graphParameters.getAlertTimeInd())){
						if ("MW".equals(region)){
							graphForm.setPercentGraphXAxisTitle("Process Group");
						}else {
							graphForm.setPercentGraphXAxisTitle("Bill Cycle");
						}
					}else if ("M".equals(graphParameters.getAlertTimeInd())){
						graphForm.setDataGraphXAxisTitle("Month of the Year");
					}else {
						graphForm.setDataGraphXAxisTitle("Day of the Month");
					}
					
					if (graphParameters.getYaxisTitle()!=null){
						graphForm.setDataGraphYAxisTitle(graphParameters.getYaxisTitle());
					}else if (graphParameters.getAlertItem()!=null && graphForm.getDataGraphYAxisTitle()==null){
						graphForm.setDataGraphYAxisTitle(graphParameters.getAlertItem()) ; //+ ":" + graphParameters.getHeader());
					}else if (graphForm.getDataGraphYAxisTitle()==null){
						graphForm.setDataGraphYAxisTitle(graphParameters.getHeader());
					}else if (graphParameters.getAlertItem()!=null && graphForm.getDataGraphYAxisTitle()!=null){
						graphForm.setDataGraphYAxisTitle(graphParameters.getAlertItem()); // + ":" + graphParameters.getHeader());
					}
				}
			}
						
			request.setAttribute("postProcessor", new GraphPostProcessor());
			
			if (graphParameters.getProcDate()!=null){
				graphForm.setProcDate(graphParameters.getProcDate().toString());
			}
			
			if (graphParameters.getDaySpan()==-1){
				graphParameters.setDaySpan(0);
			}
						
			graphForm.setGraphParameters(graphParameters);
		}catch(SQLException e){
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}) + " Exception details: " + e.getMessage(), e);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		
		if (!failureList.isEmpty()){
			request.setAttribute("failures", failureList);
			return mapping.findForward("error");
		} else {
			return mapping.findForward("DisplayGraph");
		}	
	}
	
	/**
	 * Private method to build the graph parameters to generate the graph. 
	 * These parameters are passed through the URL.
	 * 
	 * @param graphForm
	 * @param graphService
	 */
	private void buildGraphParameters(GraphForm graphForm, GraphService graphService){
		GraphParameters graphParameters = graphForm.getGraphParameters();

		/*
		 * Set the proc date. 
		 * 
		 * RE: Conference call with onsite dated 06 July 2006. 
		 * In case of Bill Day & Monthly ad hoc reports, the data on Page 13 is grouped by month i.e. File date appears as MM/YYYY. The 
		 * same value is passed in the procDate parameter to Graph. Graph program originally used to make the procDate as 1st day of the
		 * month which is passed - this led to an error in data not being shown correctly on the graph. As per the discussion in the call
		 * it was decided to make the default date as 1st day of the subsequent month in such cases
		 */
		if (graphForm.getProcDate()!=null){
			String procDate = graphForm.getProcDate();
			
			if (procDate!=null){
				if (procDate.length()==7){
					String procMonth = procDate.substring(0,2);
					String procYear = procDate.substring(3,procDate.length());
					int procMonthNum = Integer.parseInt(procMonth);
					int procYearNum = Integer.parseInt(procYear);
					
					if (procMonthNum == 12){
						procMonthNum = 1;
						procYearNum = procYearNum + 1;
					}else {
						procMonthNum = procMonthNum + 1;
					}
					
					procMonth = Integer.toString(procMonthNum);
					procYear = Integer.toString(procYearNum);
					
					procDate = procMonth + "/01/" + procYear;
				} 
			}
			
			if (graphParameters.getProcDate() == null){
				try {
					graphParameters.setProcDate(new MyDate(procDate,"MM/dd/yyyy"));
				} catch (ParseException e) {
					graphParameters.setProcDate(new MyDate(new Date(System.currentTimeMillis())));
				}
			}
		}
		
		/*
		 * Checks for whether keys passed are dates
		 */
		if (graphParameters.getKey1()!=null){
			if (graphService.isDate(graphParameters.getKey1())){
				graphParameters.setKey1(graphService.getKeyValue(graphParameters.getKey1()));
			}
		}
		if (graphParameters.getKey2()!=null){
			if (graphService.isDate(graphParameters.getKey2())){
				graphParameters.setKey2(graphService.getKeyValue(graphParameters.getKey2()));
			}
		}
		if (graphParameters.getKey3()!=null){
			if (graphService.isDate(graphParameters.getKey3())){
				graphParameters.setKey3(graphService.getKeyValue(graphParameters.getKey3()));
			}
		}
		if (graphParameters.getKey4()!=null){
			if (graphService.isDate(graphParameters.getKey4())){
				graphParameters.setKey4(graphService.getKeyValue(graphParameters.getKey4()));
			}
		}
		if (graphParameters.getKey5()!=null){
			if (graphService.isDate(graphParameters.getKey5())){
				graphParameters.setKey5(graphService.getKeyValue(graphParameters.getKey5()));
			}
		}
		
		/*
		 * Since we now have additional parameters for aKey1 to aKey5 I am going to also check for dates in case of these
		 * parameters
		 */
		if (graphParameters.getAkey1()!=null){
			if (graphService.isDate(graphParameters.getAkey1())){
				graphParameters.setAkey1(graphService.getKeyValue(graphParameters.getAkey1()));
			}
		}
		if (graphParameters.getAkey2()!=null){
			if (graphService.isDate(graphParameters.getAkey2())){
				graphParameters.setAkey2(graphService.getKeyValue(graphParameters.getAkey2()));
			}
		}
		if (graphParameters.getAkey3()!=null){
			if (graphService.isDate(graphParameters.getAkey3())){
				graphParameters.setAkey3(graphService.getKeyValue(graphParameters.getAkey3()));
			}
		}
		if (graphParameters.getAkey4()!=null){
			if (graphService.isDate(graphParameters.getAkey4())){
				graphParameters.setAkey4(graphService.getKeyValue(graphParameters.getAkey4()));
			}
		}
		if (graphParameters.getAkey5()!=null){
			if (graphService.isDate(graphParameters.getAkey5())){
				graphParameters.setAkey5(graphService.getKeyValue(graphParameters.getAkey5()));
			}
		}

		/*
		 * Check whether the key1 value contains the key1columnname + value
		 */
		String key1ColName = null ;
		String key1=null;
		if (graphParameters.getTableName()!=null){
			if (graphParameters.getAlertrule()==null && (graphParameters.getTableName().indexOf("RABC")==-1 || graphParameters.getTableName().indexOf("rabc")==-1)){
				if (graphParameters.getKey1colname()==null){
					if (graphParameters.getKey1()!=null){
						if (graphParameters.getKey1().trim().indexOf("is null")==-1 && graphParameters.getKey1().trim().indexOf("=")!=-1){
							int lenKey1complete = graphParameters.getKey1().trim().length();
							key1ColName = graphParameters.getKey1().trim().substring(2,graphParameters.getKey1().trim().indexOf("="));
							key1 = graphParameters.getKey1().trim().substring((graphParameters.getKey1().trim().indexOf("=")+1),lenKey1complete);
							if (key1.startsWith(" ")){
								key1 = key1.substring(1, key1.length());
							}
							graphParameters.setKey1colname(key1ColName);
							graphParameters.setKey1(key1);
						}else if (graphParameters.getKey1().trim().indexOf("is null")!=-1){
							key1ColName = graphParameters.getKey1().trim().substring(0,graphParameters.getKey1().trim().indexOf(" "));
							graphParameters.setKey1colname(key1ColName);
						}
						
					}
				}
			}
		}
	
		/*
		 * Make the day span -1 if it was 0
		 */
		if (graphParameters.getDaySpan()==0){
			graphParameters.setDaySpan(-1);
		}

		/*
		 * Get the alert time value
		 */
		graphParameters.setAlertTimeValue(graphService.getAlertTimeValue(graphParameters));
		
		/*
		 * Get the value for start date
		 */
		graphParameters.setStartDate(graphService.getStartDate(graphParameters));
		
		graphForm.setGraphParameters(graphParameters);
	}
	
	/**
	 * Private method to perform some checks prior to call the service classes for
	 * generation of percent and data graphs.
	 * 
	 * @param connection
	 * @param failureList
	 * @param graphForm
	 */
	private void preGraphGenerationChecks(Connection connection, List failureList, GraphForm graphForm){
		GraphParameters graphParameters = graphForm.getGraphParameters();
		
		/*
		 * Flags for percent graph generation
		 */
		if (graphParameters.getAlertrule()==null && graphParameters.getTableName()!=null && graphParameters.getItemDDlName()!=null){
			graphForm.setPercentGraphFlg("N");
		}
		
		/*
		 * Check for validity of alert rule using the following queries
		 * 1) chkAlertRule
		 * 2) qryCalcRule
		 */
		GraphSQLService graphSQLService = new GraphSQLService(graphParameters);
		graphService.setGraphSQLService(graphSQLService);
		
		if (graphParameters.getAlertrule()!=null){
			/*
			 * Run the checkAlertRule check
			 */
			List args = new ArrayList();
			args.add(graphParameters.getAlertrule());
			
			AlertRule alertRule = null;
			alertRule = graphService.chkAlertRule(connection, failureList, args);
			
			if (alertRule!=null){
				/*
				 * If parti_ref_id is not passed but we have the alert rule then get the parti ref id for this alert
				 * rule from the database. 
				 */
				graphParameters.setPartiRefId(alertRule.getPartiRefId());
				graphParameters.setAlertRule(alertRule);
				
				/*
				 * Get the calc_ind value
				 */
				if (graphSQLService.isPercentGraphRequired(graphParameters,connection, failureList)) {
					graphForm.setPercentGraphFlg("N");
				}else if ("T".equals(alertRule.getCalcRule())){
					graphForm.setPercentGraphFlg("Y");
				}else {
					graphForm.setPercentGraphFlg("N");
				}
			}else {
				graphParameters.setError("Error : No matching row in table rabc_alert_rule for alert rule: " + graphParameters.getAlertrule());
			}
		}else if (graphParameters.getTableName()==null || graphParameters.getItemDDlName()==null){
			graphParameters.setError("Error : Parameters Table Name or DDL Name is null, No graph can be plotted ! ");
		}
		
		graphService.setGraphButton(graphParameters);
		graphForm.setGraphParameters(graphParameters);
	}
	
	/**
	 * Private method to check whether values passed for certain parameters is ""; if yes then instead put null
	 * in the corresponding graphParameters object attribute.
	 * 
	 * @param graphForm
	 */
	private void defaultChecks(GraphForm graphForm){
		GraphParameters graphParameters = graphForm.getGraphParameters();
		
		if (graphParameters.getKey1()!=null){
			if ("".equals(graphParameters.getKey1().trim())){
				graphParameters.setKey1(null);
			}
		}
		
		if (graphParameters.getKey2()!=null){
			if ("".equals(graphParameters.getKey2().trim())){
				graphParameters.setKey2(null);
			}
		}
		
		if (graphParameters.getKey3()!=null){
			if ("".equals(graphParameters.getKey3().trim())){
				graphParameters.setKey3(null);
			}
		}
		
		if (graphParameters.getKey4()!=null){
			if ("".equals(graphParameters.getKey4().trim())){
				graphParameters.setKey4(null);
			}
		}
		
		if (graphParameters.getKey5()!=null){
			if ("".equals(graphParameters.getKey5().trim())){
				graphParameters.setKey5(null);
			}
		}
		
		if (graphParameters.getAkey1()!=null){
			if ("".equals(graphParameters.getAkey1().trim())){
				graphParameters.setAkey1(null);
			}
		}
		
		if (graphParameters.getAkey2()!=null){
			if ("".equals(graphParameters.getAkey2().trim())){
				graphParameters.setAkey2(null);
			}
		}
		
		if (graphParameters.getAkey3()!=null){
			if ("".equals(graphParameters.getAkey3().trim())){
				graphParameters.setAkey3(null);
			}
		}
		
		if (graphParameters.getAkey4()!=null){
			if ("".equals(graphParameters.getAkey4().trim())){
				graphParameters.setAkey4(null);
			}
		}
		
		if (graphParameters.getAkey5()!=null){
			if ("".equals(graphParameters.getAkey5().trim())){
				graphParameters.setAkey5(null);
			}
		}
		
		if (graphParameters.getAlertItem()!=null){
			if ("".equals(graphParameters.getAlertItem().trim())){
				graphParameters.setAlertItem(null);
			}
		}

		if (graphParameters.getAlertrule()!=null){
			if ("".equals(graphParameters.getAlertrule().trim())){
				graphParameters.setAlertrule(null);
			}
		}
		
		if (graphParameters.getAlertTimeInd()!=null){
			if ("".equals(graphParameters.getAlertTimeInd().trim())){
				graphParameters.setAlertTimeInd(null);
			}
		}
		
		if (graphParameters.getAlertTimeValue()!=null){
			if ("".equals(graphParameters.getAlertTimeValue().trim())){
				graphParameters.setAlertTimeValue(null);
			}
		}
		
		if (graphParameters.getColumnName()!=null){
			if ("".equals(graphParameters.getColumnName().trim())){
				graphParameters.setColumnName(null);
			}
		}
		
		if (graphParameters.getColumnValue()!=null){
			if ("".equals(graphParameters.getColumnValue().trim())){
				graphParameters.setColumnName(null);
			}
		}
		
		if (graphParameters.getExtractDateName()!=null){
			if ("".equals(graphParameters.getExtractDateName().trim())){
				graphParameters.setExtractDateName(null);
			}
		}
		
		if (graphParameters.getExtrctIndItem()!=null){
			if ("".equals(graphParameters.getExtrctIndItem().trim())){
				graphParameters.setExtrctIndItem(null);
			}
		}
		
		if (graphParameters.getFileSeqNum()!=null){
			if ("".equals(graphParameters.getFileSeqNum().trim())){
				graphParameters.setFileSeqNum(null);
			}
		}
		
		if (graphParameters.getHeader()!=null){
			if ("".equals(graphParameters.getHeader().trim())){
				graphParameters.setHeader(null);
			}
		}
		
		if (graphParameters.getItemDDlName()!=null){
			if ("".equals(graphParameters.getItemDDlName().trim())){
				graphParameters.setItemDDlName(null);
			}
		}
		
		if (graphParameters.getTableName()!=null){
			if ("".equals(graphParameters.getTableName().trim())){
				graphParameters.setTableName(null);
			}
		}
		
		if (graphParameters.getTrendTimeInd()!=null){
			if ("".equals(graphParameters.getTrendTimeInd().trim())){
				graphParameters.setTrendTimeInd(null);
			}
		}
		
		if (graphParameters.getColumnName()!=null){
			if ("".equals(graphParameters.getColumnName().trim())){
				graphParameters.setColumnName(null);
			}
		}
		
		if (graphParameters.getColumnValue()!=null){
			if ("".equals(graphParameters.getColumnValue().trim())){
				graphParameters.setColumnValue(null);
			}
		}
		
		graphForm.setGraphParameters(graphParameters);
	}
}
