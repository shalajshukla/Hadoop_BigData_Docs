/* Component Name: RABCPPG00517
 * Module Name: AdminAlertThresholdDAO.java
 * Created on Jan 20, 2006
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.admin.alert.thrshld;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import org.apache.log4j.Logger;

import com.att.bac.rabc.PickList;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.StaticDataLoader;
import com.att.bac.rabc.admin.alert.rule.AlertRule;
import com.att.carat.util.JDBCUtil;

/**This is the Data Access Object class for the admin alert threshold process.  The purpose of this class
 * is to interact with the database to get the active and deactive key level thresholds when the user is 
 * accessing the AdminAlertThresholdKey.jsp page & get the detail threshold values when the user is accessing
 * the AdminAlertThresholdDetail.jsp page.  In both cases, this data is returned to the 
 * AdminAlertThresholdService.java class.  All exceptions are thrown back to the AdminAlertThresholdAction.java
 * class via the AdminAlertThresholdService.java class.
 * 
 * @author js3175
 */
public class AdminAlertThresholdDAO {
	private static final Logger logger = Logger.getLogger(AdminAlertThresholdDAO.class);
	
	static final String ACTIVE = "A";
	static final String DEACTIVE = "D";
	static final String RULE_DEFAULT_THRSHLD = "D";
	
	/**This static method is called by the service class to get the alert rules to be displayed in a
	 * drop down on the main page.
	 * 
	 * @param conn  the connection created in the service class
	 * @return (String[]) list.toArray(new String[list.size()])  a String array of alert rules.
	 */
	protected static String [] getRules(Connection conn) throws RABCException {
		ArrayList list = new ArrayList();
		Statement stmt = null;
		ResultSet rs = null;
		String getRules = "SELECT BAR.ALERT_RULE " +
						  "FROM RABC_ALERT_RULE BAR, RABC_PRESN_ID BPI " +
						  "WHERE (BAR.ALERT_RULE_STATUS IS NULL OR BAR.ALERT_RULE_STATUS <> 'DELETED') " +
						  "AND BAR.ALERT_RULE_PRESN_IND = 'Y' " +
						  "AND BAR.PRESN_ID = BPI.PRESN_ID " +
						  "ORDER BY INITCAP(ALERT_RULE)";
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(getRules);
			logger.debug("Starting rs loop...");
			while (rs.next()) {
				list.add(rs.getString("ALERT_RULE"));
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving alert rules using getRules query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closeStatement(stmt);
		}
		if (list.size() == 0) {
			String [] none = new String[1];
			none[0] = "no alert rules found";
			return none;
		} else {
			return (String[]) list.toArray(new String[list.size()]);
		}
	}
	
	/**This static method is called by the service class to set the variable that gives the level of permissions
	 * the user has on the exempt pages.
	 * 
	 * @param conn  the connection created in the service class
	 * @param sbcuid  the user's AT&T user ID
	 * @param ruleToCheck  the rule whose threshold the user is accessing
	 * @return permission  1 allows end dating and updating as well as viewing the thresholds, 0 is view only.
	 */
	protected static int getPermission(Connection conn, String sbcuid, String ruleToCheck) throws RABCException {
		int permission = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String updateSelectPermissions = "SELECT BAG.ALERT_GRP " +
										 "FROM RABC_ALERT_GRP BAG, RABC_ALERT_GRP_USER BAGU, RABC_ALERT_GRP_FUNCT BAGF, RABC_UPDATE_GRP BUG	" +
										 "WHERE BAGU.USER_ID = ? " +
										 "AND BAGF.FUNCT_CD = 'TH' " +
										 "AND BUG.ALERT_RULE = ?" +
										 "AND BAG.ALERT_GRP = BAGU.ALERT_GRP " +
										 "AND BAG.ALERT_GRP = BAGF.ALERT_GRP " +
										 "AND BAG.ALERT_GRP = BUG.ALERT_GRP";
		try {
			ps = conn.prepareStatement(updateSelectPermissions);
			ps.setString(1, sbcuid);
			ps.setString(2, ruleToCheck);
			rs = ps.executeQuery();
			if (rs.next()){
				permission = 1;
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving alert rules using updateSelectPermissions query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
		return permission;
	}
	
	/**This static method is called by the service class to set the daily trend time values and descriptions to
	 * be displayed in a drop down.
	 * 
	 * @return list  an ArrayList of PickLists containing day of the week information.
	 */
	protected static ArrayList getDailyTrendTime() {
		ArrayList list = new ArrayList();
		String dayOfWeek = "";
		for (int i = 1; i < 8; i++) {
			switch (i) {
				case 1: dayOfWeek = "Sunday";
						break;
				case 2: dayOfWeek = "Monday";
						break;
				case 3: dayOfWeek = "Tuesday";
						break;
				case 4: dayOfWeek = "Wednesday";
						break;
				case 5: dayOfWeek = "Thursday";
						break;
				case 6: dayOfWeek = "Friday";
						break;
				default: dayOfWeek = "Saturday";
			}
			PickList pickList = new PickList(Integer.toString(i), dayOfWeek);
			list.add(pickList);
			dayOfWeek = "";
		}
		return list;
	}
	
	/**This static method is called by the service class to set the daily trend time values and descriptions to
	 * be displayed in a drop down.
	 * 
	 * @param slctdDailyTrendTime  the numeric value of the day of the week.
	 * @return dayOfWeek  the actual day of the week.
	 */
	protected static String getDailyTrendTime(String slctdDailyTrendTime) throws RABCException {
		String dayOfWeek = "";
		try {
			if (slctdDailyTrendTime != null && !slctdDailyTrendTime.trim().equals("")) {
				int j = Integer.parseInt(slctdDailyTrendTime);
				switch (j) {
					case 1: dayOfWeek = "Sunday";
							break;
					case 2: dayOfWeek = "Monday";
							break;
					case 3: dayOfWeek = "Tuesday";
							break;
					case 4: dayOfWeek = "Wednesday";
							break;
					case 5: dayOfWeek = "Thursday";
							break;
					case 6: dayOfWeek = "Friday";
							break;
					default: dayOfWeek = "Saturday";
				}
			}
		} catch (NumberFormatException nfe) {
			throw new RABCException("Error parsing day of week value: ", nfe);
		}
		return dayOfWeek;
	}
	
	/**This static method is called by the service class to get descriptive information on the alert rule
	 * selected.  This information is passed back as an alert rule object.
	 * 
	 * @param conn  the connection created in the service class
	 * @param alertRule  the rule whose active thresholds the user is accessing
	 * @return alertRuleObject  an alert rule object containing descriptive info on the alertRule.
	 */
	protected static AlertRule getRuleDescription(Connection conn, String alertRule) throws RABCException {
		PreparedStatement ps = null;
		ResultSet rs = null;
		AlertRule alertRuleObject = new AlertRule();
		String ruleDescription = "SELECT BAR.ALERT_RULE, BAR.ALERT_DESC, " +
		   						 "       DECODE(BAR.STD_TYPE,NULL,0,BAR.STD_TYPE) STD_TYPE, " +
								 "       DECODE(BAR.ALERT_KEY_LVL,NULL,0,BAR.ALERT_KEY_LVL) ALERT_KEY_LVL, " +
								 "       DECODE(BAR.DIVISION_NAME_KEY_LVL,NULL,0,BAR.DIVISION_NAME_KEY_LVL) DIVISION_NAME_KEY_LVL, " +
								 "       BAR.ALERT_RULE_TYPE ALERT_RULE_TYPE, " +
								 "		 BAR.ALERT_TIME_IND ALERT_TIME_IND " +
								 "FROM RABC_ALERT_RULE BAR, RABC_PRESN_ID BPI " +
								 "WHERE BAR.ALERT_RULE = ? " +
								 "AND BAR.ALERT_RULE_PRESN_IND = 'Y' " +
								 "AND BAR.PRESN_ID = BPI.PRESN_ID";
		try {
			ps = conn.prepareStatement(ruleDescription);
			ps.setString(1, alertRule.trim());
			rs = ps.executeQuery();
			if (rs.next()) {
				alertRuleObject.setAlertRule(rs.getString("ALERT_RULE"));
				alertRuleObject.setAlertDesc(rs.getString("ALERT_DESC"));
				alertRuleObject.setAlertKeyLvl(rs.getInt("ALERT_KEY_LVL"));
				alertRuleObject.setDivisionNameKeyLvl(rs.getInt("DIVISION_NAME_KEY_LVL"));
				alertRuleObject.setAlertRuleType(rs.getString("ALERT_RULE_TYPE"));
				alertRuleObject.setAlertTimeInd(rs.getString("ALERT_TIME_IND"));
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving alert rule description using ruleDescription query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
		return alertRuleObject;
	}
	
	/**This static method is called by the service class to set the objects that are used to make up the active
	 * key level thresholds table.  These key level thresholds can be created, end dated, or the actual threshold
	 * values viewed as a pop-up.
	 * 
	 * @param conn  the connection created in the service class
	 * @param region  the region the user is processing RABC data in.
	 * @param alertRule  the rule whose active thresholds the user is accessing.
	 * @param alertKeyLvl  the number of keys the alert rule has.
	 * @param alertTimeInd  null for record, 'D' for daily, & 'B' for bill period.
	 * @return (KeyData[]) list.toArray(new KeyData[list.size()])  the active key level thresholds that can be end
	 *                                                             dated.
	 */
	protected static KeyData [] getActiveKeyLevelThresholds(Connection conn, String region, String alertRule, int alertKeyLvl, String alertTimeInd) throws RABCException {
		ArrayList list = new ArrayList();
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		PreparedStatement ps = null;
		ResultSet rs = null;
		String actvKeyLvlThrshlds = "SELECT DISTINCT ALERT_RULE, ALERT_KEY1_DATA, ALERT_KEY2_DATA, ALERT_KEY3_DATA, " +
									"ALERT_KEY4_DATA, ALERT_KEY5_DATA, ALERT_ITEM_NAME, ALERT_TREND_TIME, USER_ID, " +
									"END_EFF_DT, TRUNC(TIME_STAMP) TIME_STAMP " +
									"FROM RABC_ALERT_THRSHLD " +
									"WHERE ALERT_RULE = ? " +
									"  AND END_EFF_DT > SYSDATE " +
									"  AND DFLT_IND IS NULL " +
									"  AND STATUS = ?";
		try {
			ps = conn.prepareStatement(actvKeyLvlThrshlds);
			ps.setString(1, alertRule);
			ps.setString(2, AdminAlertThresholdDAO.ACTIVE);
			rs = ps.executeQuery();
			logger.debug("Starting rs loop...");
			while (rs.next()) {
				String desc = StaticDataLoader.getDivisionDesc(region, rs.getString("ALERT_KEY1_DATA"));
				String alertItem = " ";
				String alertTrendTime = " ";
				String endEffDate = " ";
				String userId = " ";
				String timestamp = " ";
				if (rs.getString("ALERT_ITEM_NAME") != null)
					alertItem = rs.getString("ALERT_ITEM_NAME");
				if (rs.getString("ALERT_TREND_TIME") != null)
					alertTrendTime = rs.getString("ALERT_TREND_TIME");
				if (rs.getString("USER_ID") != null)
					userId = rs.getString("USER_ID");
				if (rs.getDate("END_EFF_DT") != null)
					endEffDate = sdf.format(rs.getDate("END_EFF_DT"));
				if (rs.getDate("TIME_STAMP") != null)
					timestamp = sdf.format(rs.getDate("TIME_STAMP"));
				if (alertKeyLvl > 1) {
					String [] keys = new String[alertKeyLvl - 1];
					for (int i = 0; i < alertKeyLvl - 1; i++) {
						keys[i] = " ";
						if (rs.getString(i + 3) != null)
							keys[i] = rs.getString(i + 3);
					}
					KeyData keyData = new KeyData(alertItem, rs.getString("ALERT_KEY1_DATA"), desc, keys, alertTrendTime, userId, endEffDate, timestamp);
					if (alertTimeInd != null && alertTimeInd.trim().equals("D"))
						keyData.setTrendTimeDescription(AdminAlertThresholdDAO.getDailyTrendTime(keyData.getTrendTime()));
					list.add(keyData);
				} else {
					KeyData keyData = new KeyData(alertItem, rs.getString("ALERT_KEY1_DATA"), desc, alertTrendTime, userId, endEffDate, timestamp);
					if (alertTimeInd != null && alertTimeInd.trim().equals("D"))
						keyData.setTrendTimeDescription(AdminAlertThresholdDAO.getDailyTrendTime(keyData.getTrendTime()));
					list.add(keyData);
				}
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving key level data using actvKeyLvlThrshlds query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
		return (KeyData[]) list.toArray(new KeyData[list.size()]);
	}
	
	/**This static method is called by the service class to set the objects that are used to make up the deactive
	 * key level thresholds table.  These key level thresholds cannot be created or updated.
	 * 
	 * @param conn  the connection created in the service class
	 * @param region  the region the user is processing RABC data in.
	 * @param alertRule  the rule whose deactive thresholds the user is accessing.
	 * @param alertKeyLvl  the number of keys the alert rule has.
	 * @param alertTimeInd  null for record, 'D' for daily, & 'B' for bill period.
	 * @return (KeyData[]) list.toArray(new KeyData[list.size()])  the deactive key level thresholds in the history
	 *                                                             table.
	 */
	protected static KeyData [] getDeactiveKeyLevelThresholds(Connection conn, String region, String alertRule, int alertKeyLvl, String alertTimeInd) throws RABCException {
		ArrayList list = new ArrayList();
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		PreparedStatement ps = null;
		ResultSet rs = null;
		String deacKeyLvlThrshlds = "SELECT DISTINCT ALERT_RULE, ALERT_KEY1_DATA, ALERT_KEY2_DATA, ALERT_KEY3_DATA, " +
									"ALERT_KEY4_DATA, ALERT_KEY5_DATA, ALERT_ITEM_NAME, ALERT_TREND_TIME, USER_ID, " +
									"END_EFF_DT, TRUNC(TIME_STAMP) TIME_STAMP " +
									"FROM RABC_ALERT_THRSHLD " +
									"WHERE ALERT_RULE = ? " +
									"  AND DFLT_IND IS NULL " +
									"  AND (END_EFF_DT <= SYSDATE OR STATUS = ?) " +
									"ORDER BY TIME_STAMP DESC, ALERT_KEY1_DATA, ALERT_KEY2_DATA, ALERT_KEY3_DATA, ALERT_KEY4_DATA, ALERT_KEY5_DATA, ALERT_ITEM_NAME, END_EFF_DT, USER_ID";
		try {
			ps = conn.prepareStatement(deacKeyLvlThrshlds);
			ps.setString(1, alertRule);
			ps.setString(2, AdminAlertThresholdDAO.DEACTIVE);
			rs = ps.executeQuery();
			logger.debug("Starting rs loop...");
			while (rs.next()) {
				String desc = StaticDataLoader.getDivisionDesc(region, rs.getString("ALERT_KEY1_DATA"));
				String alertItem = " ";
				String alertTrendTime = " ";
				String endEffDate = " ";
				String userId = " ";
				String timestamp = " ";
				if (rs.getString("ALERT_ITEM_NAME") != null)
					alertItem = rs.getString("ALERT_ITEM_NAME");
				if (rs.getString("ALERT_TREND_TIME") != null)
					alertTrendTime = rs.getString("ALERT_TREND_TIME");
				if (rs.getString("USER_ID") != null)
					userId = rs.getString("USER_ID");
				if (rs.getDate("END_EFF_DT") != null)
					endEffDate = sdf.format(rs.getDate("END_EFF_DT"));
				if (rs.getDate("TIME_STAMP") != null)
					timestamp = sdf.format(rs.getDate("TIME_STAMP"));
				if (alertKeyLvl > 1) {
					String [] keys = new String[alertKeyLvl - 1];
					for (int i = 0; i < alertKeyLvl - 1; i++) {
						keys[i] = " ";
						if (rs.getString(i + 3) != null)
							keys[i] = rs.getString(i + 3);
					}
					KeyData keyData = new KeyData(alertItem, rs.getString("ALERT_KEY1_DATA"), desc, keys, alertTrendTime, userId, endEffDate, timestamp);
					if (alertTimeInd != null && alertTimeInd.trim().equals("D"))
						keyData.setTrendTimeDescription(AdminAlertThresholdDAO.getDailyTrendTime(keyData.getTrendTime()));
					list.add(keyData);
				} else {
					KeyData keyData = new KeyData(alertItem, rs.getString("ALERT_KEY1_DATA"), desc, alertTrendTime, userId, endEffDate, timestamp);
					if (alertTimeInd != null && alertTimeInd.trim().equals("D"))
						keyData.setTrendTimeDescription(AdminAlertThresholdDAO.getDailyTrendTime(keyData.getTrendTime()));
					list.add(keyData);
				}
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving key level data using deacKeyLvlThrshlds query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
		return (KeyData[]) list.toArray(new KeyData[list.size()]);
	}
	
	/**This static method is called by the service class to return the end effective date for a key level threshold.
	 * This method is not needed for rule default thresholds since rule default thresholds should never be deleted.
	 * 
	 * @param conn  the connection created in the service class
	 * @param alertRule  the rule whose active thresholds the user is accessing.
	 * @param alertItem  the alert item that makes up the particular key level threshold - can be null.
	 * @param division  the division value for this key level threshold - it will always be key 1.
	 * @param key2  the key2 value for this key level threshold.
	 * @param key3  the key3 value for this key level threshold.
	 * @param key4  the key4 value for this key level threshold.
	 * @param key5  the key5 value for this key level threshold.
	 * @param trendTime  the trend time value for this key level threshold - null for record, bill period for
	 *                   billday, and day of week for daily.
	 * @return endEffDt  the date the key level threshold becomes deactive.
	 */
	protected static String getEndEffectiveDt(Connection conn, String alertRule, String alertItem, String division, String key2, String key3, String key4, String key5, String trendTime) throws RABCException {
		PreparedStatement ps = null;
		ResultSet rs = null;
		String endEffDt = "";
		String effDateSQL = "SELECT DISTINCT END_EFF_DT " +
							"FROM RABC_ALERT_THRSHLD " +
							"WHERE ALERT_RULE = ? " +
							"  AND DFLT_IND IS NULL " +
							"  AND UPPER(ALERT_ITEM_NAME) = ? " +
							"  AND UPPER(ALERT_KEY1_DATA) = ? " +
							"  AND UPPER(ALERT_KEY2_DATA) = ? " +
							"  AND UPPER(ALERT_KEY3_DATA) = ? " +
							"  AND UPPER(ALERT_KEY4_DATA) = ? " +
							"  AND UPPER(ALERT_KEY5_DATA) = ? " +
							"  AND ALERT_TREND_TIME = ? " +
							"  AND STATUS = ?";
		try {
			ps = conn.prepareStatement(effDateSQL);
			ps.setString(1, alertRule.trim());
			ps.setString(2, alertItem.trim());
			ps.setString(3, division.trim().toUpperCase());
			ps.setString(4, key2.trim().toUpperCase());
			ps.setString(5, key3.trim().toUpperCase());
			ps.setString(6, key4.trim().toUpperCase());
			ps.setString(7, key5.trim().toUpperCase());
			ps.setString(8, trendTime.trim());
			ps.setString(9, AdminAlertThresholdDAO.ACTIVE);
			rs = ps.executeQuery();
			logger.debug("Starting rs loop...");
			if (rs.next()) {
				endEffDt = rs.getString("END_EFF_DT");
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving end effective date using effDateSQL query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
		return endEffDt;
	}
	
	/**This static method is called by the service class to set the column names for the current key level table
	 * and the historical key level table to better describe the columns.
	 * 
	 * @param conn  the connection created in the service class.
	 * @param keyLevel  the number of keys the alert rule has.
	 * @param alertRule  the rule whose active thresholds the user is accessing.
	 * @return keyHeaders  the key level columns for the alert rule.
	 */
	protected static String [] getKeyLevelHeaders(Connection conn, int keyLevel, String alertRule) throws RABCException {
		String [] keyHeaders = new String[keyLevel];
		PreparedStatement ps = null;
		ResultSet rs = null;
		String keyLevelHeaders = "SELECT DISTINCT KEY1_HEADER, KEY2_HEADER, KEY3_HEADER, KEY4_HEADER, KEY5_HEADER " +
								 "FROM RABC_ALERT_RULE_PRESN_RULE " +
								 "WHERE PRESN_ID IN (SELECT PRESN_ID " +
								 "					 FROM RABC_ALERT_RULE " +
								 "					 WHERE ALERT_RULE = ?)";
		try {
			ps = conn.prepareStatement(keyLevelHeaders);
			ps.setString(1, alertRule.trim());
			rs = ps.executeQuery();
			logger.debug("Starting rs loop...");
			if (rs.next()) {
				for (int i = 0; i < keyLevel; i++) {
					if (rs.getString(i + 1) == null) {
						keyHeaders[i] = " ";
					} else {
						keyHeaders[i] = rs.getString(i + 1);
					}
				}
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving key level data using keyLevelHeaders query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
		return keyHeaders;
	}
	
	/**This static method is called by the service class to populate the alert item drop down in the create
	 * key row.
	 * 
	 * @param conn  the connection created in the service class.
	 * @param alertRule  the rule whose thresholds the user is accessing.
	 * @return list  the ArrayList of alert items that is populated in the drop down.
	 */
	protected static ArrayList getAlertItem(Connection conn, String alertRule) throws RABCException {
		PreparedStatement ps = null;
		ResultSet rs = null;
		ArrayList list = new ArrayList();
		String alertItem = "";
		String ruleDataItem = "SELECT DISTINCT ALERT_ITEM_DDL_NAME, ALERT_ITEM_DDL_DATA " +
		 					  "FROM RABC_ALERT_PROC " +
							  "WHERE ALERT_RULE = ? " +
							  "ORDER BY ALERT_ITEM_DDL_NAME";
		try {
			ps = conn.prepareStatement(ruleDataItem);
			ps.setString(1, alertRule.trim());
			rs = ps.executeQuery();
			logger.debug("Starting rs loop...");
			while (rs.next()) {
				if (rs.getString("ALERT_ITEM_DDL_NAME") == null)
					alertItem = " ";
				else
					alertItem = rs.getString("ALERT_ITEM_DDL_NAME");
				list.add(alertItem);
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving data items using ruleDataItem query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
		return list;
	}
	
	/**This static method is called by the service class to return the date the threshold was last updated for rule
	 * default thresholds and when the threshold was end dated for a key level threshold.
	 * 
	 * @param conn  the connection created in the service class
	 * @param threshLvl  indicates whether the threshold is a key level threshold or a rule default threshold.
	 * @param alertRule  the rule whose active thresholds the user is accessing.
	 * @param alertItem  the alert item that makes up the particular key level threshold - can be null.
	 * @param key1  the division value for this key level threshold - it will always be key 1.
	 * @param key2  the key2 value for this key level threshold.
	 * @param key3  the key3 value for this key level threshold.
	 * @param key4  the key4 value for this key level threshold.
	 * @param key5  the key5 value for this key level threshold.
	 * @param trendTime  the trend time value for this key level threshold - null for record, bill period for
	 *                   billday, and day of week for daily.
	 * @return lastUpdt  the date the key level threshold becomes deactive.
	 */
	protected static String getLastUpdate(Connection conn, String threshLvl, String alertRule, String alertItem, String key1, String key2, String key3, String key4, String key5, String trendTime) throws RABCException {
		PreparedStatement ps = null;
		ResultSet rs = null;
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		String lastUpdtDt = "";
		String lastUpdt = "";
		int k = 4;
		StringBuffer sb = new StringBuffer("SELECT MAX(TIME_STAMP) LAST_UPDATED " +
										   "FROM RABC_ALERT_THRSHLD " +
										   "WHERE ALERT_RULE = ?" +
										   "  AND STATUS = ?  " +
										   "  AND END_EFF_DT >= SYSDATE ");
		try {
			if (threshLvl.trim().equals(AdminAlertThresholdForm.KEY_LEVEL)) {
				sb.append("  AND DFLT_IND IS NULL ");
				sb.append("  AND UPPER(ALERT_KEY1_DATA) = ? ");
				if (key2 != null && !key2.trim().equals("")) {
					sb.append("  AND UPPER(ALERT_KEY2_DATA) = ? ");
				} else {
					sb.append("  AND ALERT_KEY2_DATA IS NULL ");
				}
				if (key3 != null && !key3.trim().equals("")) {
					sb.append("  AND UPPER(ALERT_KEY3_DATA) = ? ");
				} else {
					sb.append("  AND ALERT_KEY3_DATA IS NULL ");
				}
				if (key4 != null && !key4.trim().equals("")) {
					sb.append("  AND UPPER(ALERT_KEY4_DATA) = ? ");
				} else {
					sb.append("  AND ALERT_KEY4_DATA IS NULL ");
				}
				if (key5 != null && !key5.trim().equals("")) {
					sb.append("  AND UPPER(ALERT_KEY5_DATA) = ? ");
				} else {
					sb.append("  AND ALERT_KEY5_DATA IS NULL ");
				}
				if (alertItem != null && !alertItem.trim().equals("")) {
					sb.append("  AND UPPER(ALERT_ITEM_NAME) = ? ");
				} else {
					sb.append("  AND ALERT_ITEM_NAME IS NULL ");
				}
				if (trendTime != null && !trendTime.trim().equals("")) {
					sb.append("  AND ALERT_TREND_TIME = ? ");
				} else {
					sb.append("  AND ALERT_TREND_TIME IS NULL ");
				}
				sb.append("GROUP BY ALERT_RULE, DFLT_IND, ALERT_ITEM_NAME, ALERT_KEY1_DATA, ALERT_KEY2_DATA, ALERT_KEY3_DATA, ALERT_KEY4_DATA, ALERT_KEY5_DATA, ALERT_TREND_TIME");
			} else {
				sb.append("  AND DFLT_IND = 'D' ");
				sb.append("GROUP BY ALERT_RULE, DFLT_IND");
			}
			lastUpdt = sb.toString();
			ps = conn.prepareStatement(lastUpdt);
			ps.setString(1, alertRule.trim());
			ps.setString(2, AdminAlertThresholdDAO.ACTIVE);
			if (threshLvl.trim().equals(AdminAlertThresholdForm.KEY_LEVEL)) {
				ps.setString(3, key1.trim().toUpperCase());
				if (key2 != null && !key2.trim().equals("")) {
					ps.setString(k, key2.trim().toUpperCase());
					k++;
				}
				if (key3 != null && !key3.trim().equals("")) {
					ps.setString(k, key3.trim().toUpperCase());
					k++;
				}
				if (key4 != null && !key4.trim().equals("")) {
					ps.setString(k, key4.trim().toUpperCase());
					k++;
				}
				if (key5 != null && !key5.trim().equals("")) {
					ps.setString(k, key5.trim().toUpperCase());
					k++;
				}
				if (alertItem != null && !alertItem.trim().equals("")) {
					ps.setString(k, alertItem.trim().toUpperCase());
					k++;
				}
				if (trendTime != null && !trendTime.trim().equals(""))
					ps.setString(k, trendTime.trim());
			}
			rs = ps.executeQuery();
			if (rs.next()) {
				if (rs.getDate("LAST_UPDATED") != null) {
					logger.debug("Latest update date is: " + rs.getDate(1).toString());
					lastUpdtDt = sdf.format(rs.getDate("LAST_UPDATED"));
				} else {
					Date lastUpdateDate = new Date(Calendar.getInstance().getTimeInMillis());
					logger.debug("Latest update date is: " + lastUpdateDate.toString());
					lastUpdtDt = sdf.format(lastUpdateDate);
				}
			} else {
				Date lastUpdateDate = new Date(Calendar.getInstance().getTimeInMillis());
				logger.debug("Latest update date is: " + lastUpdateDate.toString());
				lastUpdtDt = sdf.format(lastUpdateDate);
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving most recent update date and time using lastUpdated query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
		return lastUpdtDt;
	}
	
	/**This static method is called by the service class to set the alert type for a particular alert rule/alert
	 * item combination.
	 * 
	 * @param conn  the connection created in the service class.
	 * @param alertRule  the rule whose active thresholds the user is accessing.
	 * @param alertItem  the alert item being associated with the alert rule to get the alert type.
	 * @return alertType  the alert type for the alert rule/alert item combo.
	 */
	protected static int getUpdateType(Connection conn, String alertRule, String alertItem) throws RABCException {
		PreparedStatement ps = null;
		ResultSet rs = null;
		int alertType = 0;
		String updateType = "SELECT DISTINCT ALERT_TYPE " +
							"FROM RABC_ALERT_PROC " +
							"WHERE ALERT_RULE = ? " +
							"  AND UPPER(ALERT_ITEM_DDL_NAME) = ?";
		try {
			ps = conn.prepareStatement(updateType);
			ps.setString(1, alertRule.trim());
			ps.setString(2, alertItem.trim().toUpperCase());
			rs = ps.executeQuery();
			if (rs.next()) {
				logger.debug("Update type is: " + rs.getInt("ALERT_TYPE"));
				alertType = rs.getInt("ALERT_TYPE");
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving update type using updateType query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
		return alertType;
	}
	
	/**This static method is called by the service class to return a ThresholdData object containing all the threshold
	 * values for that key level or rule default threshold.  These values are used to populate the threshold table on
	 * the AdminAlertThresholdDetail.jsp page.
	 * 
	 * @param conn  the connection created in the service class
	 * @param thresholdLvl  indicates whether the threshold is a key level threshold or a rule default threshold.
	 * @param alertRule  the rule whose active thresholds the user is accessing.
	 * @param alertItem  the alert item that makes up the particular key level threshold - can be null.
	 * @param trendTime  the trend time value for this key level threshold - null for record, bill period for
	 *                   billday, and day of week for daily.
	 * @param key1  the division value for this key level threshold - it will always be key 1.
	 * @param key2  the key2 value for this key level threshold.
	 * @param key3  the key3 value for this key level threshold.
	 * @param key4  the key4 value for this key level threshold.
	 * @param key5  the key5 value for this key level threshold.
	 * @return threshData  the object containing the threshold values in all three rows to populate the threshold
	 *                     table.
	 */
	protected static ThresholdData getAlertThresholdValues(Connection conn, String thresholdLvl, String alertRule, String alertItem, String trendTime, String key1, String key2, String key3, String key4, String key5) throws RABCException {
		PreparedStatement ps = null;
		ResultSet rs = null;
		ThresholdData threshData = new ThresholdData();
		String alertThresholdValues = "";
		StringBuffer sb = new StringBuffer("SELECT ALERT_RULE, ALERT_TYPE, ALERT_KEY1_DATA, ALERT_KEY2_DATA, ALERT_KEY3_DATA, ALERT_KEY4_DATA, ALERT_KEY5_DATA, " +
										   "ALERT_ITEM_NAME, ALERT_ITEM_DDL_DATA, ALERT_THRSHLD_LVL, ALERT_THRSHLD, ALERT_HIGH, ALERT_LOW, MIN_ALERT_VAL " +
										   "FROM RABC_ALERT_THRSHLD " +
										   "WHERE ALERT_RULE = ? " +
										   "  AND STATUS = ? " +
										   "  AND END_EFF_DT >= SYSDATE ");
		int k = 4;
		try {
			if (thresholdLvl.trim().equals(AdminAlertThresholdForm.KEY_LEVEL)) {
				sb.append("  AND DFLT_IND IS NULL ");
				sb.append("  AND UPPER(ALERT_KEY1_DATA) = ? ");
				if (key2 != null && !key2.trim().equals("")) {
					sb.append("  AND UPPER(ALERT_KEY2_DATA) = ? ");
				} else {
					sb.append("  AND ALERT_KEY2_DATA IS NULL ");
				}
				if (key3 != null && !key3.trim().equals("")) {
					sb.append("  AND UPPER(ALERT_KEY3_DATA) = ? ");
				} else {
					sb.append("  AND ALERT_KEY3_DATA IS NULL ");
				}
				if (key4 != null && !key4.trim().equals("")) {
					sb.append("  AND UPPER(ALERT_KEY4_DATA) = ? ");
				} else {
					sb.append("  AND ALERT_KEY4_DATA IS NULL ");
				}
				if (key5 != null && !key5.trim().equals("")) {
					sb.append("  AND UPPER(ALERT_KEY5_DATA) = ? ");
				} else {
					sb.append("  AND ALERT_KEY5_DATA IS NULL ");
				}
				if (alertItem != null && !alertItem.trim().equals("")) {
					sb.append("  AND UPPER(ALERT_ITEM_NAME) = ? ");
				} else {
					sb.append("  AND ALERT_ITEM_NAME IS NULL ");
				}
				if (trendTime != null && !trendTime.trim().equals("")) {
					sb.append("  AND ALERT_TREND_TIME = ? ");
				} else {
					sb.append("  AND ALERT_TREND_TIME IS NULL ");
				}
			} else {
				sb.append("  AND DFLT_IND = 'D' ");
			}
			alertThresholdValues = sb.toString();
			ps = conn.prepareStatement(alertThresholdValues);
			ps.setString(1, alertRule.trim());
			ps.setString(2, AdminAlertThresholdDAO.ACTIVE);
			if (thresholdLvl.trim().equals(AdminAlertThresholdForm.KEY_LEVEL)) {
				ps.setString(3, key1.trim().toUpperCase());
				if (key2 != null && !key2.trim().equals("")) {
					ps.setString(k, key2.trim().toUpperCase());
					k++;
				}
				if (key3 != null && !key3.trim().equals("")) {
					ps.setString(k, key3.trim().toUpperCase());
					k++;
				}
				if (key4 != null && !key4.trim().equals("")) {
					ps.setString(k, key4.trim().toUpperCase());
					k++;
				}
				if (key5 != null && !key5.trim().equals("")) {
					ps.setString(k, key5.trim().toUpperCase());
					k++;
				}
				if (alertItem != null && !alertItem.trim().equals("")) {
					ps.setString(k, alertItem.trim().toUpperCase());
					k++;
				}
				if (trendTime != null && !trendTime.trim().equals(""))
					ps.setString(k, trendTime.trim());
			}
			rs = ps.executeQuery();
			if (rs.next()) {
				threshData.setEditMode(1);
				logger.debug("Alert Rule is: " + rs.getString("ALERT_RULE"));
				logger.debug("Alert Threshold Level is: " + rs.getInt("ALERT_THRSHLD_LVL"));
				if (rs.getInt("ALERT_THRSHLD_LVL") == 1) {
					if (rs.getString("ALERT_THRSHLD") != null && !rs.getString("ALERT_THRSHLD").trim().equals(""))
						threshData.setStandardHigh(rs.getString("ALERT_THRSHLD"));
					if (rs.getString("ALERT_LOW") != null && !rs.getString("ALERT_LOW").trim().equals(""))
						threshData.setLowRangeHigh(rs.getString("ALERT_LOW"));
					if (rs.getString("ALERT_HIGH") != null && !rs.getString("ALERT_HIGH").trim().equals(""))
						threshData.setHighRangeHigh(rs.getString("ALERT_HIGH"));
					if (rs.getString("MIN_ALERT_VAL") != null && !rs.getString("MIN_ALERT_VAL").trim().equals(""))
						threshData.setAlertMinHigh(rs.getString("MIN_ALERT_VAL"));
				} else if (rs.getInt("ALERT_THRSHLD_LVL") == 2) {
					if (rs.getString("ALERT_THRSHLD") != null && !rs.getString("ALERT_THRSHLD").trim().equals(""))
						threshData.setStandardMedium(rs.getString("ALERT_THRSHLD"));
					if (rs.getString("ALERT_LOW") != null && !rs.getString("ALERT_LOW").trim().equals(""))
						threshData.setLowRangeMedium(rs.getString("ALERT_LOW"));
					if (rs.getString("ALERT_HIGH") != null && !rs.getString("ALERT_HIGH").trim().equals(""))
						threshData.setHighRangeMedium(rs.getString("ALERT_HIGH"));
					if (rs.getString("MIN_ALERT_VAL") != null && !rs.getString("MIN_ALERT_VAL").trim().equals(""))
						threshData.setAlertMinMedium(rs.getString("MIN_ALERT_VAL"));
				} else {
					if (rs.getString("ALERT_THRSHLD") != null && !rs.getString("ALERT_THRSHLD").trim().equals(""))
						threshData.setStandardLow(rs.getString("ALERT_THRSHLD"));
					if (rs.getString("ALERT_LOW") != null && !rs.getString("ALERT_LOW").trim().equals(""))
						threshData.setLowRangeLow(rs.getString("ALERT_LOW"));
					if (rs.getString("ALERT_HIGH") != null && !rs.getString("ALERT_HIGH").trim().equals(""))
						threshData.setHighRangeLow(rs.getString("ALERT_HIGH"));
					if (rs.getString("MIN_ALERT_VAL") != null && !rs.getString("MIN_ALERT_VAL").trim().equals(""))
						threshData.setAlertMinLow(rs.getString("MIN_ALERT_VAL"));
				}
				while (rs.next()) {
					logger.debug("Alert Rule is: " + rs.getString("ALERT_RULE"));
					logger.debug("Alert Threshold Level is: " + rs.getInt("ALERT_THRSHLD_LVL"));
					if (rs.getInt("ALERT_THRSHLD_LVL") == 1) {
						if (rs.getString("ALERT_THRSHLD") != null && !rs.getString("ALERT_THRSHLD").trim().equals(""))
							threshData.setStandardHigh(rs.getString("ALERT_THRSHLD"));
						if (rs.getString("ALERT_LOW") != null && !rs.getString("ALERT_LOW").trim().equals(""))
							threshData.setLowRangeHigh(rs.getString("ALERT_LOW"));
						if (rs.getString("ALERT_HIGH") != null && !rs.getString("ALERT_HIGH").trim().equals(""))
							threshData.setHighRangeHigh(rs.getString("ALERT_HIGH"));
						if (rs.getString("MIN_ALERT_VAL") != null && !rs.getString("MIN_ALERT_VAL").trim().equals(""))
							threshData.setAlertMinHigh(rs.getString("MIN_ALERT_VAL"));
					} else if (rs.getInt("ALERT_THRSHLD_LVL") == 2) {
						if (rs.getString("ALERT_THRSHLD") != null && !rs.getString("ALERT_THRSHLD").trim().equals(""))
							threshData.setStandardMedium(rs.getString("ALERT_THRSHLD"));
						if (rs.getString("ALERT_LOW") != null && !rs.getString("ALERT_LOW").trim().equals(""))
							threshData.setLowRangeMedium(rs.getString("ALERT_LOW"));
						if (rs.getString("ALERT_HIGH") != null && !rs.getString("ALERT_HIGH").trim().equals(""))
							threshData.setHighRangeMedium(rs.getString("ALERT_HIGH"));
						if (rs.getString("MIN_ALERT_VAL") != null && !rs.getString("MIN_ALERT_VAL").trim().equals(""))
							threshData.setAlertMinMedium(rs.getString("MIN_ALERT_VAL"));
					} else {
						if (rs.getString("ALERT_THRSHLD") != null && !rs.getString("ALERT_THRSHLD").trim().equals(""))
							threshData.setStandardLow(rs.getString("ALERT_THRSHLD"));
						if (rs.getString("ALERT_LOW") != null && !rs.getString("ALERT_LOW").trim().equals(""))
							threshData.setLowRangeLow(rs.getString("ALERT_LOW"));
						if (rs.getString("ALERT_HIGH") != null && !rs.getString("ALERT_HIGH").trim().equals(""))
							threshData.setHighRangeLow(rs.getString("ALERT_HIGH"));
						if (rs.getString("MIN_ALERT_VAL") != null && !rs.getString("MIN_ALERT_VAL").trim().equals(""))
							threshData.setAlertMinLow(rs.getString("MIN_ALERT_VAL"));
					}
				}
			}
			if (thresholdLvl.trim().equals(AdminAlertThresholdForm.RULE_DEFAULT)) {
				threshData.setRuleDefaultMode(1);
				threshData.setDefaultIndicator(1);
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving threshold values using alertThresholdValues query: ", sqle);
		} catch (NumberFormatException nfe) {
			throw new RABCException("Error formatting numeric values: ", nfe);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
		return threshData;
	}
	
	/**This static method is called by the service class to return a ThresholdData object containing all the threshold
	 * values for that key level or rule default threshold.  These values are used to populate the threshold table on
	 * the AdminAlertThresholdDetail.jsp page.  This static method is different from getAlertThresholdValues() because
	 * it will search the key level heirarchy to find the key level threshold that is active the data from page 11 will
	 * be run against.  If no key level threshold is found, the rule default thresholds are used.
	 * 
	 * @param conn  the connection created in the service class
	 * @param thresholdLvl  indicates whether the threshold is a key level threshold or a rule default threshold.
	 * @param alertRule  the rule whose active thresholds the user is accessing.
	 * @param alertItem  the alert item that makes up the particular key level threshold - can be null.
	 * @param trendTime  the trend time value for this key level threshold - null for record, bill period for
	 *                   billday, and day of week for daily.
	 * @param key1  the division value for this key level threshold - it will always be key 1.
	 * @param key2  the key2 value for this key level threshold.
	 * @param key3  the key3 value for this key level threshold.
	 * @param key4  the key4 value for this key level threshold.
	 * @param key5  the key5 value for this key level threshold.
	 * @return threshData  the object containing the threshold values in all three rows to populate the threshold
	 *                     table.
	 */
	protected static ThresholdData getPopUpThresholdValues(Connection conn, String thresholdLvl, String alertRule, String alertItem, String trendTime, String key1, String key2, String key3, String key4, String key5, String procDate) throws RABCException {
		String subSql1 = "(SELECT MAX(RC.ALERT_RULE_RUN_DT) " +
						 "FROM RABC_CNTRL_RUN RC " +
						 "WHERE RC.PROC_DATE = to_date(?, 'MM/DD/YYYY') " +
				         "AND RC.ALERT_RULE = ? ";
		String subSql2 = "(SELECT MAX(TRUNC(TIME_STAMP)) " +
						 "FROM RABC_ALERT_THRSHLD " +
						 "WHERE ALERT_RULE = ? ";
		PreparedStatement ps = null;
		ResultSet rs = null;
		StringBuffer sb = new StringBuffer();
		StringBuffer sb2 = new StringBuffer();
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		ThresholdData threshData = new ThresholdData();
		String alertThresholdValues = "";
		boolean alertItemInd = true;
		boolean trendTimeInd = true;
		boolean key1Ind = true;
		boolean key2Ind = true;
		boolean key3Ind = true;
		boolean key4Ind = true;
		boolean key5Ind = true;
		boolean stampInd = false;
		int j = 2;
		try {
			for (int k = 0; k <= 8; k++) {
				sb.setLength(0);
				sb2.setLength(0);
				subSql2 = "(SELECT MAX(TRUNC(TIME_STAMP)) " +
				 		  "FROM RABC_ALERT_THRSHLD " +
				 		  "WHERE ALERT_RULE = ? ";
				j = 2;
				if (thresholdLvl.equals(AdminAlertThresholdForm.KEY_LEVEL)) {
					sb2.append("AND DFLT_IND IS NULL ");
					if (alertItemInd) {
						if (alertItem == null || alertItem.trim().equals("")) {
							sb2.append("AND ALERT_ITEM_NAME IS NULL ");
						} else {
							sb2.append("AND UPPER(ALERT_ITEM_NAME) = ? ");
						}
					} else {
						sb2.append("AND ALERT_ITEM_NAME IS NULL ");
					}
					if (trendTimeInd) {
						if (trendTime == null || trendTime.trim().equals("")) {
							sb2.append("AND ALERT_TREND_TIME IS NULL ");
						} else {
							sb2.append("AND ALERT_TREND_TIME = ? ");
						}
					} else {
						sb2.append("AND ALERT_TREND_TIME IS NULL ");
					}
					if (key1 == null || key1.trim().equals("")) {
						sb2.append("AND ALERT_KEY1_DATA IS NULL ");
					} else {
						sb2.append("AND UPPER(ALERT_KEY1_DATA) = ? ");
					}
					if (key2Ind) {
						if (key2 == null || key2.trim().equals("")) {
							sb2.append("AND ALERT_KEY2_DATA IS NULL ");
						} else {
							sb2.append("AND UPPER(ALERT_KEY2_DATA) = ? ");
						}
					} else {
						sb2.append("AND ALERT_KEY2_DATA IS NULL ");
					}
					if (key3Ind) {
						if (key3 == null || key3.trim().equals("")) {
							sb2.append("AND ALERT_KEY3_DATA IS NULL ");
						} else {
							sb2.append("AND UPPER(ALERT_KEY3_DATA) = ? ");
						}
					} else {
						sb2.append("AND ALERT_KEY3_DATA IS NULL ");
					}
					if (key4Ind) {
						if (key4 == null || key4.trim().equals("")) {
							sb2.append("AND ALERT_KEY4_DATA IS NULL ");
						} else {
							sb2.append("AND UPPER(ALERT_KEY4_DATA) = ? ");
						}
					} else {
						sb2.append("AND ALERT_KEY4_DATA IS NULL ");
					}
					if (key5Ind) {
						if (key5 == null || key5.trim().equals("")) {
							sb2.append("AND ALERT_KEY5_DATA IS NULL ");
						} else {
							sb2.append("AND UPPER(ALERT_KEY5_DATA) = ? ");
						}
					} else {
						sb2.append("AND ALERT_KEY5_DATA IS NULL ");
					}
				} else {
					sb2.append("AND DFLT_IND = ? ");
				}
				sb2.append(") ");
				subSql2 = subSql2 + sb2.toString();
				sb.append("SELECT ALERT_RULE, ALERT_THRSHLD_LVL, ALERT_THRSHLD, ALERT_HIGH, ALERT_LOW, MIN_ALERT_VAL, TIME_STAMP ");
				sb.append("FROM RABC_ALERT_THRSHLD ");
				sb.append("WHERE ALERT_RULE = ? ");
				sb.append("AND TRUNC(TIME_STAMP) <= ");
				sb.append(subSql1);
				if (!key1.equals("") && !key1.equals(null)) {
					sb.append("AND RC.KEY1 = ?) ");
					stampInd = true;
				} else {
					sb.append("AND RC.KEY1 IS NULL) ");
				}
				sb.append("AND TRUNC(TIME_STAMP) = ");
				sb.append(subSql2);
				if (thresholdLvl.equals(AdminAlertThresholdForm.KEY_LEVEL)) {
					sb.append("AND DFLT_IND IS NULL ");
					if (alertItemInd) {
						if (alertItem == null || alertItem.trim().equals("")) {
							sb.append("AND ALERT_ITEM_NAME IS NULL ");
						} else {
							sb.append("AND UPPER(ALERT_ITEM_NAME) = ? ");
						}
					} else {
						sb.append("AND ALERT_ITEM_NAME IS NULL ");
					}
					if (trendTimeInd) {
						if (trendTime == null || trendTime.trim().equals("")) {
							sb.append("AND ALERT_TREND_TIME IS NULL ");
						} else {
							sb.append("AND ALERT_TREND_TIME = ? ");
						}
					} else {
						sb.append("AND ALERT_TREND_TIME IS NULL ");
					}
					if (key1 == null || key1.trim().equals("")) {
						sb.append("AND ALERT_KEY1_DATA IS NULL ");
					} else {
						sb.append("AND UPPER(ALERT_KEY1_DATA) = ? ");
					}
					if (key2Ind) {
						if (key2 == null || key2.trim().equals("")) {
							sb.append("AND ALERT_KEY2_DATA IS NULL ");
						} else {
							sb.append("AND UPPER(ALERT_KEY2_DATA) = ? ");
						}
					} else {
						sb.append("AND ALERT_KEY2_DATA IS NULL ");
					}
					if (key3Ind) {
						if (key3 == null || key3.trim().equals("")) {
							sb.append("AND ALERT_KEY3_DATA IS NULL ");
						} else {
							sb.append("AND UPPER(ALERT_KEY3_DATA) = ? ");
						}
					} else {
						sb.append("AND ALERT_KEY3_DATA IS NULL ");
					}
					if (key4Ind) {
						if (key4 == null || key4.trim().equals("")) {
							sb.append("AND ALERT_KEY4_DATA IS NULL ");
						} else {
							sb.append("AND UPPER(ALERT_KEY4_DATA) = ? ");
						}
					} else {
						sb.append("AND ALERT_KEY4_DATA IS NULL ");
					}
					if (key5Ind) {
						if (key5 == null || key5.trim().equals("")) {
							sb.append("AND ALERT_KEY5_DATA IS NULL ");
						} else {
							sb.append("AND UPPER(ALERT_KEY5_DATA) = ? ");
						}
					} else {
						sb.append("AND ALERT_KEY5_DATA IS NULL ");
					}
				} else {
					sb.append("AND DFLT_IND = ? ");
				}
				alertThresholdValues = sb.toString();
				ps = conn.prepareStatement(alertThresholdValues);
				ps.setString(1, alertRule.trim());	
				ps.setString(2, procDate);
				ps.setString(3, alertRule.trim());
				j = 4;
				if (stampInd) {
					ps.setString(j, key1.trim());
					j++;
				}
				ps.setString(j, alertRule.trim());
				j++;
				if (thresholdLvl.equals(AdminAlertThresholdForm.KEY_LEVEL)) {
					if (alertItemInd && (alertItem != null && !alertItem.trim().equals(""))) {
						ps.setString(j, alertItem.trim().toUpperCase());
						j++;
					}
					if (trendTimeInd && (trendTime != null && !trendTime.trim().equals(""))) {
						ps.setString(j, trendTime.trim());
						j++;
					}
					if (key1Ind && (key1 != null && !key1.trim().equals(""))) {
						ps.setString(j, key1.trim().toUpperCase());
						j++;
					}
					if (key2Ind && (key2 != null && !key2.trim().equals(""))) {
						ps.setString(j, key2.trim().toUpperCase());
						j++;
					}
					if (key3Ind && (key3 != null && !key3.trim().equals(""))) {
						ps.setString(j, key3.trim().toUpperCase());
						j++;
					}
					if (key4Ind && (key4 != null && !key4.trim().equals(""))) {
						ps.setString(j, key4.trim().toUpperCase());
						j++;
					}
					if (key5Ind && (key5 != null && !key5.trim().equals(""))) {
						ps.setString(j, key5.trim().toUpperCase());
						j++;
					}
					if (alertItemInd && (alertItem != null && !alertItem.trim().equals(""))) {
						ps.setString(j, alertItem.trim().toUpperCase());
						j++;
					}
					if (trendTimeInd && (trendTime != null && !trendTime.trim().equals(""))) {
						ps.setString(j, trendTime.trim());
						j++;
					}
					if (key1Ind && (key1 != null && !key1.trim().equals(""))) {
						ps.setString(j, key1.trim().toUpperCase());
						j++;
					}
					if (key2Ind && (key2 != null && !key2.trim().equals(""))) {
						ps.setString(j, key2.trim().toUpperCase());
						j++;
					}
					if (key3Ind && (key3 != null && !key3.trim().equals(""))) {
						ps.setString(j, key3.trim().toUpperCase());
						j++;
					}
					if (key4Ind && (key4 != null && !key4.trim().equals(""))) {
						ps.setString(j, key4.trim().toUpperCase());
						j++;
					}
					if (key5Ind && (key5 != null && !key5.trim().equals(""))) {
						ps.setString(j, key5.trim().toUpperCase());
						j++;
					}
				} else {
					ps.setString(j, AdminAlertThresholdDAO.RULE_DEFAULT_THRSHLD);
					j++;
					ps.setString(j, AdminAlertThresholdDAO.RULE_DEFAULT_THRSHLD);
					j++;
				}
				rs = ps.executeQuery();
				if (rs.next()) {
					threshData.setEditMode(1);
					logger.debug("Alert Rule is: " + rs.getString("ALERT_RULE"));
					logger.debug("Alert Threshold Level is: " + rs.getInt("ALERT_THRSHLD_LVL"));
					threshData.setLastUpdatedDate(sdf.format(rs.getDate("TIME_STAMP")));
					if (rs.getInt("ALERT_THRSHLD_LVL") == 1) {
						if (rs.getString("ALERT_THRSHLD") != null && !rs.getString("ALERT_THRSHLD").trim().equals(""))
							threshData.setStandardHigh(rs.getString("ALERT_THRSHLD"));
						if (rs.getString("ALERT_LOW") != null && !rs.getString("ALERT_LOW").trim().equals(""))
							threshData.setLowRangeHigh(rs.getString("ALERT_LOW"));
						if (rs.getString("ALERT_HIGH") != null && !rs.getString("ALERT_HIGH").trim().equals(""))
							threshData.setHighRangeHigh(rs.getString("ALERT_HIGH"));
						if (rs.getString("MIN_ALERT_VAL") != null && !rs.getString("MIN_ALERT_VAL").trim().equals(""))
							threshData.setAlertMinHigh(rs.getString("MIN_ALERT_VAL"));
					} else if (rs.getInt("ALERT_THRSHLD_LVL") == 2) {
						if (rs.getString("ALERT_THRSHLD") != null && !rs.getString("ALERT_THRSHLD").trim().equals(""))
							threshData.setStandardMedium(rs.getString("ALERT_THRSHLD"));
						if (rs.getString("ALERT_LOW") != null && !rs.getString("ALERT_LOW").trim().equals(""))
							threshData.setLowRangeMedium(rs.getString("ALERT_LOW"));
						if (rs.getString("ALERT_HIGH") != null && !rs.getString("ALERT_HIGH").trim().equals(""))
							threshData.setHighRangeMedium(rs.getString("ALERT_HIGH"));
						if (rs.getString("MIN_ALERT_VAL") != null && !rs.getString("MIN_ALERT_VAL").trim().equals(""))
							threshData.setAlertMinMedium(rs.getString("MIN_ALERT_VAL"));
					} else {
						if (rs.getString("ALERT_THRSHLD") != null && !rs.getString("ALERT_THRSHLD").trim().equals(""))
							threshData.setStandardLow(rs.getString("ALERT_THRSHLD"));
						if (rs.getString("ALERT_LOW") != null && !rs.getString("ALERT_LOW").trim().equals(""))
							threshData.setLowRangeLow(rs.getString("ALERT_LOW"));
						if (rs.getString("ALERT_HIGH") != null && !rs.getString("ALERT_HIGH").trim().equals(""))
							threshData.setHighRangeLow(rs.getString("ALERT_HIGH"));
						if (rs.getString("MIN_ALERT_VAL") != null && !rs.getString("MIN_ALERT_VAL").trim().equals(""))
							threshData.setAlertMinLow(rs.getString("MIN_ALERT_VAL"));
					}
					while (rs.next()) {
						logger.debug("Alert Rule is: " + rs.getString("ALERT_RULE"));
						logger.debug("Alert Threshold Level is: " + rs.getInt("ALERT_THRSHLD_LVL"));
						if (rs.getInt("ALERT_THRSHLD_LVL") == 1) {
							if (rs.getString("ALERT_THRSHLD") != null && !rs.getString("ALERT_THRSHLD").trim().equals(""))
								threshData.setStandardHigh(rs.getString("ALERT_THRSHLD"));
							if (rs.getString("ALERT_LOW") != null && !rs.getString("ALERT_LOW").trim().equals(""))
								threshData.setLowRangeHigh(rs.getString("ALERT_LOW"));
							if (rs.getString("ALERT_HIGH") != null && !rs.getString("ALERT_HIGH").trim().equals(""))
								threshData.setHighRangeHigh(rs.getString("ALERT_HIGH"));
							if (rs.getString("MIN_ALERT_VAL") != null && !rs.getString("MIN_ALERT_VAL").trim().equals(""))
								threshData.setAlertMinHigh(rs.getString("MIN_ALERT_VAL"));
						} else if (rs.getInt("ALERT_THRSHLD_LVL") == 2) {
							if (rs.getString("ALERT_THRSHLD") != null && !rs.getString("ALERT_THRSHLD").trim().equals(""))
								threshData.setStandardMedium(rs.getString("ALERT_THRSHLD"));
							if (rs.getString("ALERT_LOW") != null && !rs.getString("ALERT_LOW").trim().equals(""))
								threshData.setLowRangeMedium(rs.getString("ALERT_LOW"));
							if (rs.getString("ALERT_HIGH") != null && !rs.getString("ALERT_HIGH").trim().equals(""))
								threshData.setHighRangeMedium(rs.getString("ALERT_HIGH"));
							if (rs.getString("MIN_ALERT_VAL") != null && !rs.getString("MIN_ALERT_VAL").trim().equals(""))
								threshData.setAlertMinMedium(rs.getString("MIN_ALERT_VAL"));
						} else {
							if (rs.getString("ALERT_THRSHLD") != null && !rs.getString("ALERT_THRSHLD").trim().equals(""))
								threshData.setStandardLow(rs.getString("ALERT_THRSHLD"));
							if (rs.getString("ALERT_LOW") != null && !rs.getString("ALERT_LOW").trim().equals(""))
								threshData.setLowRangeLow(rs.getString("ALERT_LOW"));
							if (rs.getString("ALERT_HIGH") != null && !rs.getString("ALERT_HIGH").trim().equals(""))
								threshData.setHighRangeLow(rs.getString("ALERT_HIGH"));
							if (rs.getString("MIN_ALERT_VAL") != null && !rs.getString("MIN_ALERT_VAL").trim().equals(""))
								threshData.setAlertMinLow(rs.getString("MIN_ALERT_VAL"));
						}
					}
					break;
				} else {
					if (thresholdLvl.equals(AdminAlertThresholdForm.RULE_DEFAULT)) {
						threshData.setThresholdFound(0);
					}
					switch (k) {
						case 0: alertItemInd = true;
								trendTimeInd = false;
								break;
						case 1: alertItemInd = false;
								trendTimeInd = true;
								break;
						case 2: alertItemInd = false;
								trendTimeInd = false;
								break;
						case 3: key5Ind = false;
								break;
						case 4: key4Ind = false;
								break;
						case 5: key3Ind = false;
								break;
						case 6: key2Ind = false;
								break;
						default: key1Ind = false;
								 thresholdLvl = AdminAlertThresholdForm.RULE_DEFAULT;
								 threshData.setThresholdLevel(AdminAlertThresholdForm.RULE_DEFAULT);
					}
					JDBCUtil.closeResultSet(rs);
					JDBCUtil.closePreparedStatement(ps);
				}
			}
			if (thresholdLvl.equals(AdminAlertThresholdForm.RULE_DEFAULT)) {
				threshData.setRuleDefaultMode(1);
				threshData.setDefaultIndicator(1);
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving pop-up threshold values using alertThresholdValues query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
		return threshData;
	}
	
	/**This static method is called by the service class to insert new key level or rule default thresholds into the
	 * table RABC_ALERT_THRSHLD.
	 * 
	 * @param conn  the connection created in the service class
	 * @param thresholdLevel  indicates whether the threshold is a key level threshold or a rule default threshold.
	 * @param alertType  the alert type for the row being inserted.
	 * @param alertRule  the rule whose active thresholds the user is inserting.
	 * @param alertItem  the alert item that makes up the particular key level threshold - can be null.
	 * @param trendTime  the trend time value for this key level threshold - null for record, bill period for
	 *                   billday, and day of week for daily.
	 * @param key1  the division value for this key level threshold - it will always be key 1.
	 * @param key2  the key2 value for this key level threshold.
	 * @param key3  the key3 value for this key level threshold.
	 * @param key4  the key4 value for this key level threshold.
	 * @param key5  the key5 value for this key level threshold.
	 * @param userId  the AT&T user ID of the user inserting the threshold.
	 * @param endEffDate  the date the threshold values become deactive.
	 * @param standardHigh  number of standard deviations - data falling outside this value trigger tier 3 warnings.
	 * @param standardMedium  number of standard deviations - data falling between this value and the standardHigh
	 *                        trigger tier 2 warnings.
	 * @param standardLow  number of standard deviations - data falling between this value and the standardMedium
	 *                     trigger tier 1 warnings.
	 * @param highRangeHigh  numeric value - data falling above this value trigger tier 3 warnings.
	 * @param highRangeMedium  numeric value - data falling between this value and the highRangeHigh trigger
	 *                         tier 2 warnings.
	 * @param highRangeLow  numeric value - data falling between this value and the highRangeMedium trigger
	 *                      tier 1 warnings.
	 * @param lowRangeHigh  numeric value - data falling below this value trigger tier 3 warnings.
	 * @param lowRangeMedium  numeric value - data falling between this value and the lowRangeHigh trigger
	 *                        tier 2 warnings.
	 * @param lowRangeLow  numeric value - data falling between this value and the lowRangeMedium trigger
	 *                     tier 1 warnings.
	 * @param alertMinHigh  dollar value - minimum dollar value that will be considered to trigger tier 3
	 *                      warnings.
	 * @param alertMinMedium  dollar value - minimum dollar value that will be considered to trigger tier 2
	 *                      warnings.
	 * @param alertMinLow  dollar value - minimum dollar value that will be considered to trigger tier 1
	 *                      warnings.
	 */
	protected static void insertAlertThresholdValues(Connection conn, String thresholdLevel, String alertRule, int alertType, String alertItem, String trendTime, String key1, String key2, String key3, String key4, String key5, String userId, String endEffDate, String standardHigh, String standardMedium, String standardLow, String highRangeHigh, String highRangeMedium, String highRangeLow, String lowRangeHigh, String lowRangeMedium, String lowRangeLow, String alertMinHigh, String alertMinMedium, String alertMinLow) throws RABCException {
		PreparedStatement ps = null;
		String insertRuleDefaultThreshold = "INSERT INTO RABC_ALERT_THRSHLD (ALERT_RULE, ALERT_TYPE, STATUS, USER_ID, END_EFF_DT, DFLT_IND, TIME_STAMP, ALERT_THRSHLD_LVL, ALERT_THRSHLD, ALERT_LOW, ALERT_HIGH, MIN_ALERT_VAL) " +
											"VALUES (?,?,?,?,?,'D',SYSDATE,?,?,?,?,?)";
		String insertKeyLevelThreshold = "INSERT INTO RABC_ALERT_THRSHLD (ALERT_RULE, ALERT_TYPE, STATUS, USER_ID, ALERT_ITEM_NAME, ALERT_KEY1_DATA, ALERT_KEY2_DATA, ALERT_KEY3_DATA, ALERT_KEY4_DATA, ALERT_KEY5_DATA, ALERT_TREND_TIME, END_EFF_DT, DFLT_IND, TIME_STAMP, ALERT_THRSHLD_LVL, ALERT_THRSHLD, ALERT_LOW, ALERT_HIGH, MIN_ALERT_VAL) " +
										 "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,NULL,SYSDATE,?,?,?,?,?)";
		int j = 0;
		try {
			if (thresholdLevel.equals(AdminAlertThresholdForm.KEY_LEVEL)) {
				String month = endEffDate.trim().substring(0, 2);
				String day = endEffDate.trim().substring(3, 5);
				String year = endEffDate.trim().substring(6);
				ps = conn.prepareStatement(insertKeyLevelThreshold);
				ps.setString(1, alertRule.trim());
				ps.setInt(2, alertType);
				ps.setString(3, AdminAlertThresholdDAO.ACTIVE);
				ps.setString(4, userId.trim());
				ps.setString(5, alertItem.trim());
				ps.setString(6, key1.trim());
				ps.setString(7, key2.trim());
				ps.setString(8, key3.trim());
				ps.setString(9, key4.trim());
				ps.setString(10, key5.trim());
				ps.setString(11, trendTime.trim());
				ps.setDate(12, Date.valueOf(year + "-" + month + "-" + day));
				j = 13;
			} else {
				ps = conn.prepareStatement(insertRuleDefaultThreshold);
				ps.setString(1, alertRule.trim());
				ps.setInt(2, alertType);
				ps.setString(3, AdminAlertThresholdDAO.ACTIVE);
				ps.setString(4, userId.trim());
				ps.setDate(5, Date.valueOf("9999-12-31"));
				j = 6;
			}
			for (int i = 1; i < 4; i++) {
				ps.setInt(j, i);
				j++;
				if (i == 1) {
					ps.setString(j, standardHigh);
					j++;
					ps.setString(j, lowRangeHigh);
					j++;
					ps.setString(j, highRangeHigh);
					j++;
					ps.setString(j, alertMinHigh);
				} else if (i == 2) {
					ps.setString(j, standardMedium);
					j++;
					ps.setString(j, lowRangeMedium);
					j++;
					ps.setString(j, highRangeMedium);
					j++;
					ps.setString(j, alertMinMedium);
				} else {
					ps.setString(j, standardLow);
					j++;
					ps.setString(j, lowRangeLow);
					j++;
					ps.setString(j, highRangeLow);
					j++;
					ps.setString(j, alertMinLow);
				}
				ps.execute();
				if (thresholdLevel.equals(AdminAlertThresholdForm.KEY_LEVEL)) {
					j = 13;
				} else {
					j = 6;
				}
			}
		} catch (SQLException sqle) {
			JDBCUtil.rollback(conn);
			throw new RABCException("Error inserting threshold values: ", sqle);
		} catch (NumberFormatException nfe) {
			JDBCUtil.rollback(conn);
			throw new RABCException("Error parsing numeric values: ", nfe);
		} finally {
			JDBCUtil.closePreparedStatement(ps);
		}
	}
	
	/**This static method is called by the service class to set a rule default threshold to deactive in the
	 * table RABC_ALERT_THRSHLD then call AdminAlertThresholdDAO.insertAlertThresholdValues() to set the new
	 * active row.
	 * 
	 * @param conn  the connection created in the service class
	 * @param thresholdLevel  indicates whether the threshold is a key level threshold or a rule default threshold.
	 * @param alertType  the alert type for the row being inserted.
	 * @param alertRule  the rule whose active thresholds the user is inserting.
	 * @param userId  the AT&T user ID of the user inserting the threshold.
	 * @param standardHigh  number of standard deviations - data falling outside this value trigger tier 3 warnings.
	 * @param standardMedium  number of standard deviations - data falling between this value and the standardHigh
	 *                        trigger tier 2 warnings.
	 * @param standardLow  number of standard deviations - data falling between this value and the standardMedium
	 *                     trigger tier 1 warnings.
	 * @param highRangeHigh  numeric value - data falling above this value trigger tier 3 warnings.
	 * @param highRangeMedium  numeric value - data falling between this value and the highRangeHigh trigger
	 *                         tier 2 warnings.
	 * @param highRangeLow  numeric value - data falling between this value and the highRangeMedium trigger
	 *                      tier 1 warnings.
	 * @param lowRangeHigh  numeric value - data falling below this value trigger tier 3 warnings.
	 * @param lowRangeMedium  numeric value - data falling between this value and the lowRangeHigh trigger
	 *                        tier 2 warnings.
	 * @param lowRangeLow  numeric value - data falling between this value and the lowRangeMedium trigger
	 *                     tier 1 warnings.
	 * @param alertMinHigh  dollar value - minimum dollar value that will be considered to trigger tier 3
	 *                      warnings.
	 * @param alertMinMedium  dollar value - minimum dollar value that will be considered to trigger tier 2
	 *                      warnings.
	 * @param alertMinLow  dollar value - minimum dollar value that will be considered to trigger tier 1
	 *                      warnings.
	 */
	protected static void updateAlertThresholdValues(Connection conn, String alertRule, int alertType, String userId, String standardHigh, String standardMedium, String standardLow, String highRangeHigh, String highRangeMedium, String highRangeLow, String lowRangeHigh, String lowRangeMedium, String lowRangeLow, String alertMinHigh, String alertMinMedium, String alertMinLow) throws RABCException {
		PreparedStatement ps = null;
		String updateRuleDefaultThreshold = "UPDATE RABC_ALERT_THRSHLD SET " +
											"STATUS = ? " +
											"WHERE ALERT_RULE = ? " +
											"  AND DFLT_IND = 'D'";
		try {
			ps = conn.prepareStatement(updateRuleDefaultThreshold);
			ps.setString(1, AdminAlertThresholdDAO.DEACTIVE);
			ps.setString(2, alertRule.trim());
			ps.execute();
			AdminAlertThresholdDAO.insertAlertThresholdValues(conn, AdminAlertThresholdForm.RULE_DEFAULT, alertRule, alertType, "", "", "", "", "", "", "", userId, "", standardHigh, standardMedium, standardLow, highRangeHigh, highRangeMedium, highRangeLow, lowRangeHigh, lowRangeMedium, lowRangeLow, alertMinHigh, alertMinMedium, alertMinLow);
		} catch (SQLException sqle) {
			JDBCUtil.rollback(conn);
			throw new RABCException("Error in updating rule default threshold values using updateRuleDefaultThreshold query: ", sqle);
		} catch (NumberFormatException nfe) {
			JDBCUtil.rollback(conn);
			throw new RABCException("Error parsing numeric values: ", nfe);
		} finally {
			JDBCUtil.closePreparedStatement(ps);
		}
	}
	
	/**This static method is called by the service class to set a key level threshold to deactive in the
	 * table RABC_ALERT_THRSHLD then call AdminAlertThresholdDAO.insertAlertThresholdValues() to insert a new 
	 * row with the end effective date specified on the web page.
	 * 
	 * @param conn  the connection created in the service class
	 * @param alertRule  the rule whose active thresholds the user is end dating.
	 * @param alertItem  the alert item that makes up the particular key level threshold - can be null.
	 * @param key1  the division value for this key level threshold - it will always be key 1.
	 * @param key2  the key2 value for this key level threshold.
	 * @param key3  the key3 value for this key level threshold.
	 * @param key4  the key4 value for this key level threshold.
	 * @param key5  the key5 value for this key level threshold.
	 * @param trendTime  the trend time value for this key level threshold - null for record, bill period for
	 *                   billday, and day of week for daily.
	 * @param endEffDate  the date the threshold values become deactive.
	 * @param userId  the AT&T user ID of the user inserting the threshold.
	 */
	protected static void deleteAlertThresholdValues(Connection conn, String alertRule, String alertItem, String key1, String key2, String key3, String key4, String key5, String trendTime, String endEffDate, String userId) throws RABCException {
		PreparedStatement ps = null;
		ThresholdData thresholdData = new ThresholdData();
		String updateKeyLevelStatus = "UPDATE RABC_ALERT_THRSHLD SET " +
									  "STATUS = ? " +
									  "WHERE ALERT_RULE = ? " +
									  "  AND UPPER(ALERT_KEY1_DATA) = ? " +
									  "  AND NVL(UPPER(ALERT_KEY2_DATA), -1) = NVL(?, -1) " +
									  "  AND NVL(UPPER(ALERT_KEY3_DATA), -1) = NVL(?, -1) " +
									  "  AND NVL(UPPER(ALERT_KEY4_DATA), -1) = NVL(?, -1) " +
									  "  AND NVL(UPPER(ALERT_KEY5_DATA), -1) = NVL(?, -1) " +
									  "  AND NVL(UPPER(ALERT_ITEM_NAME), -1) = NVL(?, -1) " +
									  "  AND NVL(ALERT_TREND_TIME, -1) = NVL(?, -1) " +
									  "  AND DFLT_IND IS NULL";
		try {
			thresholdData = AdminAlertThresholdDAO.retrieveAlertThresholdValues(conn, alertRule, alertItem, key1, key2, key3, key4, key5, trendTime);
			ps = conn.prepareStatement(updateKeyLevelStatus);
			ps.setString(1, AdminAlertThresholdDAO.DEACTIVE);
			ps.setString(2, alertRule.trim());
			ps.setString(3, key1.trim().toUpperCase());
			ps.setString(4, key2.trim().toUpperCase());
			ps.setString(5, key3.trim().toUpperCase());
			ps.setString(6, key4.trim().toUpperCase());
			ps.setString(7, key5.trim().toUpperCase());
			ps.setString(8, alertItem.trim().toUpperCase());
			ps.setString(9, trendTime.trim());
			ps.execute();
			AdminAlertThresholdDAO.insertAlertThresholdValues(conn, AdminAlertThresholdForm.KEY_LEVEL, alertRule, thresholdData.getAlertType(), alertItem, trendTime, key1, key2, key3, key4, key5, userId, endEffDate, thresholdData.getStandardHigh(), thresholdData.getStandardMedium(), thresholdData.getStandardLow(), thresholdData.getHighRangeHigh(), thresholdData.getHighRangeMedium(), thresholdData.getHighRangeLow(), thresholdData.getLowRangeHigh(), thresholdData.getLowRangeMedium(), thresholdData.getLowRangeLow(), thresholdData.getAlertMinHigh(), thresholdData.getAlertMinMedium(), thresholdData.getAlertMinLow());
		} catch (SQLException sqle) {
			JDBCUtil.rollback(conn);
			throw new RABCException("Error updating the end date of the key level threshold: ", sqle);
		} catch (NumberFormatException nfe) {
			JDBCUtil.rollback(conn);
			throw new RABCException("Error parsing numeric values: ", nfe);
		} finally {
			JDBCUtil.closePreparedStatement(ps);
		}
	}
	
	/**This static method is called by the service class to get the standard deviation for this threshold.  This is
	 * used to help set the high and low range values if this option is selected.
	 * 
	 * @param conn  the connection created in the service class
	 * @param alertRule  the rule whose active thresholds the user is accessing.
	 * @param alertItem  the alert item that makes up the particular key level threshold - can be null.
	 * @param key1  the division value for this key level threshold - it will always be key 1.
	 * @param key2  the key2 value for this key level threshold.
	 * @param key3  the key3 value for this key level threshold.
	 * @param key4  the key4 value for this key level threshold.
	 * @param key5  the key5 value for this key level threshold.
	 * @param trendTime  the trend time value for this key level threshold - null for record, bill period for
	 *                   billday, and day of week for daily.
	 * @param data  the threshold data the standard deviation value will be added to for display on the 
	 *              AdminAlertThresholdDetail.jsp page.
	 */
	protected static void getStandardDeviation(Connection conn, String alertRule, String alertItem, String key1, String key2, String key3, String key4, String key5, String trendTime, ThresholdData data) throws RABCException {
		PreparedStatement ps = null;
		ResultSet rs = null;
		StringBuffer sb = new StringBuffer();
		String getStdDev = "";
		try {
			String alrtTimeInd = AdminAlertThresholdDAO.checkAlertTimeIndicator(conn, alertRule);
			sb.append("SELECT ROUND(STDDEV(BAH.ALERT_DATA),2) ");
			sb.append("FROM RABC_ALERT_HIST BAH, RABC_STD_CALC BSC ");
			sb.append("WHERE BSC.ALERT_RULE = ? ");
			sb.append("  AND BAH.PROC_DATE >= SYSDATE - (SELECT STD_NUM_DATE FROM RABC_STD_CALC WHERE ALERT_RULE = ?) ");
			sb.append("  AND BAH.PROC_DATE < SYSDATE ");
			if (alertItem != null && !alertItem.trim().equals(""))
				sb.append("  AND BAH.ALERT_ITEM = ? ");
			else
				sb.append("  AND BAH.ALERT_ITEM IS NULL ");
			sb.append("  AND BAH.ALERT_KEY1 = ? ");
			if (key2 != null && !key2.trim().equals(""))
				sb.append("  AND BAH.ALERT_KEY2 = ? ");
			else
				sb.append("  AND BAH.ALERT_KEY2 IS NULL ");
			if (key3 != null && !key3.trim().equals(""))
				sb.append("  AND BAH.ALERT_KEY3 = ? ");
			else
				sb.append("  AND BAH.ALERT_KEY3 IS NULL ");
			if (key4 != null && !key4.trim().equals(""))
				sb.append("  AND BAH.ALERT_KEY4 = ? ");
			else
				sb.append("  AND BAH.ALERT_KEY4 IS NULL ");
			if (key5 != null && !key5.trim().equals(""))
				sb.append("  AND BAH.ALERT_KEY5 = ? ");
			else
				sb.append("  AND BAH.ALERT_KEY5 IS NULL ");
			if (alrtTimeInd != null && !alrtTimeInd.trim().equals(""))
				sb.append("  AND BAH.ALERT_TREND_TIME = ? ");
			sb.append("  AND BAH.PARTI_REF_ID = BSC.PARTI_REF_ID");
			getStdDev = sb.toString();
			ps = conn.prepareStatement(getStdDev);
			int j = 3;
			ps.setString(1, alertRule.trim());
			ps.setString(2, alertRule.trim());
			if (alertItem != null && !alertItem.trim().equals("")) {
				ps.setString(j, alertItem.trim());
				j++;
			}
			ps.setString(j, key1.trim());
			j++;
			if (key2 != null && !key2.trim().equals("")) {
				ps.setString(j, key2.trim());
				j++;
			}
			if (key3 != null && !key3.trim().equals("")){
				ps.setString(j, key3.trim());
				j++;
			}
			if (key4 != null && !key4.trim().equals("")) {
				ps.setString(j, key4.trim());
				j++;
			}
			if (key5 != null && !key5.trim().equals("")) {
				ps.setString(j, key5.trim());
				j++;
			}
			if (alrtTimeInd != null && !alrtTimeInd.trim().equals(""))
				ps.setString(j, trendTime.trim());
			rs = ps.executeQuery();
			if (rs.next()){
				data.setStandardDeviation(rs.getDouble(1));
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving standard deviation using getStdDev query: ", sqle);
		} catch (NumberFormatException nfe) {
			throw new RABCException("Error parsing numeric values: ", nfe);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
	}
	
	/**This static method is called by the service class to get the standard deviation for the row selected on page
	 * 11.  This value should match the standard deviation at the time the row was created.
	 * 
	 * @param conn  the connection created in the service class
	 * @param alertRule  the rule whose active thresholds the user is accessing.
	 * @param alertItem  the alert item that makes up the particular key level threshold - can be null.
	 * @param key1  the division value for this key level threshold - it will always be key 1.
	 * @param key2  the key2 value for this key level threshold.
	 * @param key3  the key3 value for this key level threshold.
	 * @param key4  the key4 value for this key level threshold.
	 * @param key5  the key5 value for this key level threshold.
	 * @param trendTime  the trend time value for this key level threshold - null for record, bill period for
	 *                   billday, and day of week for daily.
	 * @param data  the threshold data the standard deviation value will be added to for display on the 
	 *              AdminAlertThresholdDetail.jsp page.
	 */
	protected static void getPopUpStandardDeviation(Connection conn, String alertRule, String alertItem, String key1, String key2, String key3, String key4, String key5, String trendTime, ThresholdData data, String procDate) throws RABCException {
		PreparedStatement ps = null;
		ResultSet rs = null;
		StringBuffer sb = new StringBuffer();
		String getStdDev = "";
		try {
			String month = procDate.trim().substring(0, 2);
			String day = procDate.trim().substring(3, 5);
			String year = procDate.trim().substring(6);
			String alrtTimeInd = AdminAlertThresholdDAO.checkAlertTimeIndicator(conn, alertRule);
			sb.append("SELECT ROUND(STDDEV(BAH.ALERT_DATA),2) ");
			sb.append("FROM RABC_ALERT_HIST BAH, RABC_STD_CALC BSC ");
			sb.append("WHERE BSC.ALERT_RULE = ? ");
			sb.append("  AND BAH.PROC_DATE >= ? - (SELECT STD_NUM_DATE FROM RABC_STD_CALC WHERE ALERT_RULE = ?) ");
			sb.append("  AND BAH.PROC_DATE < ? ");
			if (alertItem != null && !alertItem.trim().equals(""))
				sb.append("  AND BAH.ALERT_ITEM = ? ");
			else
				sb.append("  AND BAH.ALERT_ITEM IS NULL ");
			sb.append("  AND BAH.ALERT_KEY1 = ? ");
			if (key2 != null && !key2.trim().equals(""))
				sb.append("  AND BAH.ALERT_KEY2 = ? ");
			else
				sb.append("  AND BAH.ALERT_KEY2 IS NULL ");
			if (key3 != null && !key3.trim().equals(""))
				sb.append("  AND BAH.ALERT_KEY3 = ? ");
			else
				sb.append("  AND BAH.ALERT_KEY3 IS NULL ");
			if (key4 != null && !key4.trim().equals(""))
				sb.append("  AND BAH.ALERT_KEY4 = ? ");
			else
				sb.append("  AND BAH.ALERT_KEY4 IS NULL ");
			if (key5 != null && !key5.trim().equals(""))
				sb.append("  AND BAH.ALERT_KEY5 = ? ");
			else
				sb.append("  AND BAH.ALERT_KEY5 IS NULL ");
			if (alrtTimeInd != null && !alrtTimeInd.trim().equals(""))
				sb.append("  AND BAH.ALERT_TREND_TIME = ? ");
			sb.append("  AND BAH.PARTI_REF_ID = BSC.PARTI_REF_ID");
			getStdDev = sb.toString();
			ps = conn.prepareStatement(getStdDev);
			int j = 5;
			ps.setString(1, alertRule.trim());
			ps.setDate(2, Date.valueOf(year + "-" + month + "-" + day));
			ps.setString(3, alertRule.trim());
			ps.setDate(4, Date.valueOf(year + "-" + month + "-" + day));
			if (alertItem != null && !alertItem.trim().equals("")) {
				ps.setString(j, alertItem.trim());
				j++;
			}
			ps.setString(j, key1.trim());
			j++;
			if (key2 != null && !key2.trim().equals("")) {
				ps.setString(j, key2.trim());
				j++;
			}
			if (key3 != null && !key3.trim().equals("")){
				ps.setString(j, key3.trim());
				j++;
			}
			if (key4 != null && !key4.trim().equals("")) {
				ps.setString(j, key4.trim());
				j++;
			}
			if (key5 != null && !key5.trim().equals("")) {
				ps.setString(j, key5.trim());
				j++;
			}
			if (alrtTimeInd != null && !alrtTimeInd.trim().equals(""))
				ps.setString(j, trendTime.trim());
			rs = ps.executeQuery();
			if (rs.next()){
				data.setStandardDeviation(rs.getDouble(1));
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving standard deviation using getStdDev query: ", sqle);
		} catch (NumberFormatException nfe) {
			throw new RABCException("Error parsing numeric values: ", nfe);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
	}
	
	/**This static method is called by AdminAlertThresholdDAO.getStandardDeviation to check the alert time
	 * indicator for a particular alert rule.
	 * 
	 * @param conn  the connection created in the service class
	 * @param alertRule  the rule whose active thresholds the user is accessing.
	 * @return alrtTimeInd  "" for record, "B" for billday, and "D" for daily.
	 */
	private static String checkAlertTimeIndicator(Connection conn, String alertRule) throws RABCException {
		PreparedStatement ps = null;
		ResultSet rs = null;
		String getAlertTimeInd = "SELECT DISTINCT BAR.ALERT_TIME_IND " +
								 "FROM RABC_ALERT_RULE BAR, RABC_AVG_CALC BAC " +
								 "WHERE BAR.ALERT_RULE = ? " +
								 "  AND BAR.PARTI_REF_ID = BAC.PARTI_REF_ID";
		String alrtTimeInd = "";
		try {
			ps = conn.prepareStatement(getAlertTimeInd);
			ps.setString(1, alertRule.trim());
			rs = ps.executeQuery();
			if (rs.next()){
				alrtTimeInd = rs.getString(1);
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving alert time indicator using getAlertTimeInd query: ", sqle);
		} catch (NumberFormatException nfe) {
			throw new RABCException("Error parsing numeric values: ", nfe);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
		return alrtTimeInd;
	}
	
	/**This static method is called by AdminAlertThresholdDAO.deleteAlertThresholdValues() to retrieve the 
	 * threshold values that will be passed into AdminAlertThresholdDAO.insertAlertThresholdValues() when
	 * the updated row is created.
	 * 
	 * @param conn  the connection created in the service class
	 * @param alertRule  the rule whose active thresholds the user is end dating.
	 * @param alertItem  the alert item that makes up the particular key level threshold - can be null.
	 * @param key1  the division value for this key level threshold - it will always be key 1.
	 * @param key2  the key2 value for this key level threshold.
	 * @param key3  the key3 value for this key level threshold.
	 * @param key4  the key4 value for this key level threshold.
	 * @param key5  the key5 value for this key level threshold.
	 * @param trendTime  the trend time value for this key level threshold - null for record, bill period for
	 *                   billday, and day of week for daily.
	 * @return thresholdData  the 
	 */
	private static ThresholdData retrieveAlertThresholdValues(Connection conn, String alertRule, String alertItem, String key1, String key2, String key3, String key4, String key5, String trendTime) throws RABCException {
		PreparedStatement ps = null;
		ResultSet rs = null;
		ThresholdData thresholdData = new ThresholdData();
		String getKeyLevelThresholds = "SELECT DISTINCT ALERT_TYPE, ALERT_THRSHLD_LVL, ALERT_THRSHLD, ALERT_HIGH, ALERT_LOW, MIN_ALERT_VAL " +
									   "FROM RABC_ALERT_THRSHLD " +
									   "WHERE ALERT_RULE = ? " +
									   "  AND STATUS = ? " +
									   "  AND UPPER(ALERT_KEY1_DATA) = ? " +
									   "  AND NVL(UPPER(ALERT_KEY2_DATA), -1) = NVL(?, -1) " +
									   "  AND NVL(UPPER(ALERT_KEY3_DATA), -1) = NVL(?, -1) " +
									   "  AND NVL(UPPER(ALERT_KEY4_DATA), -1) = NVL(?, -1) " +
									   "  AND NVL(UPPER(ALERT_KEY5_DATA), -1) = NVL(?, -1) " +
									   "  AND NVL(UPPER(ALERT_ITEM_NAME), -1) = NVL(?, -1) " +
									   "  AND NVL(ALERT_TREND_TIME, -1) = NVL(?, -1) " +
									   "  AND DFLT_IND IS NULL";
		try {
			ps = conn.prepareStatement(getKeyLevelThresholds);
			ps.setString(1, alertRule.trim());
			ps.setString(2, AdminAlertThresholdDAO.ACTIVE);
			ps.setString(3, key1.trim().toUpperCase());
			ps.setString(4, key2.trim().toUpperCase());
			ps.setString(5, key3.trim().toUpperCase());
			ps.setString(6, key4.trim().toUpperCase());
			ps.setString(7, key5.trim().toUpperCase());
			ps.setString(8, alertItem.trim().toUpperCase());
			ps.setString(9, trendTime.trim());
			rs = ps.executeQuery();
			while (rs.next()) {
				thresholdData.setAlertType(rs.getInt("ALERT_TYPE"));
				if (rs.getInt("ALERT_THRSHLD_LVL") == 1) {
					thresholdData.setStandardHigh(rs.getString("ALERT_THRSHLD"));
					thresholdData.setLowRangeHigh(rs.getString("ALERT_LOW"));
					thresholdData.setHighRangeHigh(rs.getString("ALERT_HIGH"));
					thresholdData.setAlertMinHigh(rs.getString("MIN_ALERT_VAL"));
				} else if (rs.getInt("ALERT_THRSHLD_LVL") == 2) {
					thresholdData.setStandardMedium(rs.getString("ALERT_THRSHLD"));
					thresholdData.setLowRangeMedium(rs.getString("ALERT_LOW"));
					thresholdData.setHighRangeMedium(rs.getString("ALERT_HIGH"));
					thresholdData.setAlertMinMedium(rs.getString("MIN_ALERT_VAL"));
				} else if (rs.getInt("ALERT_THRSHLD_LVL") == 3) {
					thresholdData.setStandardLow(rs.getString("ALERT_THRSHLD"));
					thresholdData.setLowRangeLow(rs.getString("ALERT_LOW"));
					thresholdData.setHighRangeLow(rs.getString("ALERT_HIGH"));
					thresholdData.setAlertMinLow(rs.getString("MIN_ALERT_VAL"));
				} else {
					JDBCUtil.rollback(conn);
					String illegalArgumentException = "Invalid alert threshold level: " + rs.getInt("ALERT_THRSHLD_LVL");
					throw new RABCException(illegalArgumentException);
				}
			}
		} catch (SQLException sqle) {
			JDBCUtil.rollback(conn);
			throw new RABCException("Error retrieving the threshold values using the getKeyLevelThresholds query: ", sqle);
		} catch (NumberFormatException nfe) {
			JDBCUtil.rollback(conn);
			throw new RABCException("Error parsing numeric values: ", nfe);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
		return thresholdData;
	}
}
