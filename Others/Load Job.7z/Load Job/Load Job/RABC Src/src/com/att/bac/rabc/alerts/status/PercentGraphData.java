/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.alerts.status;

import com.att.bac.rabc.MyDate;

/**
 * Data object representing the each value to be plotted on the percent graph.
 * 
 * @author Shailesh Hemdev - SH8512
 */
public class PercentGraphData {
	private int fileSeqNum = -1; // A value of -1 indicates that this is equal to null
	private MyDate procDate;
	private String [] itemNames;
	private double [] percentages;
	private double alertData;
	private String procMonth;
	
	/**
	 * @return Returns the fileSeqNum.
	 */
	public int getFileSeqNum() {
		return fileSeqNum;
	}
	/**
	 * @param fileSeqNum The fileSeqNum to set.
	 */
	public void setFileSeqNum(int fileSeqNum) {
		this.fileSeqNum = fileSeqNum;
	}
	/**
	 * @return Returns the itemNames.
	 */
	public String[] getItemNames() {
		return itemNames;
	}
	/**
	 * @param itemNames The itemNames to set.
	 */
	public void setItemNames(String[] itemNames) {
		this.itemNames = itemNames;
	}
	/**
	 * @return Returns the percentages.
	 */
	public double[] getPercentages() {
		return percentages;
	}
	/**
	 * @param percentages The percentages to set.
	 */
	public void setPercentages(double[] percentages) {
		this.percentages = percentages;
	}
	/**
	 * @return Returns the procDate.
	 */
	public MyDate getProcDate() {
		return procDate;
	}
	/**
	 * @param procDate The procDate to set.
	 */
	public void setProcDate(MyDate procDate) {
		this.procDate = procDate;
	}
	
	/**
	 * @return Returns the alertData.
	 */
	public double getAlertData() {
		return alertData;
	}
	/**
	 * @param alertData The alertData to set.
	 */
	public void setAlertData(double alertData) {
		this.alertData = alertData;
	}
	
	/**
	 * @return Returns the procMonth.
	 */
	public String getProcMonth() {
		return procMonth;
	}
	/**
	 * @param procMonth The procMonth to set.
	 */
	public void setProcMonth(String procMonth) {
		this.procMonth = procMonth;
	}
}
