/*
 * � 2002-2005 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.adhoc.rpt;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import com.att.bac.rabc.DateUtil;
import com.att.bac.rabc.adhoc.AdhocConstants;

/**
 * Module description: This has some utility methods used by adhoc report modules. For now, they are here, may be
 * shifted to a more appropriate location later.
 * 
 * <p>
 * <hr>
 * <h3>Release History</h3>
 * <p>
 * <ul>
 * 
 * <li>PD2951 Jan 1, 2006 Initial version for EAP 556010
 * <li>jb6494 Dec 8, 2006 Added "previous date" calculations
 * 
 * </ul>
 * <p>
 * 
 */
public class AdhocRptUtil implements AdhocConstants {
	private static final SimpleDateFormat MMDDYYYY_FORMAT	= new SimpleDateFormat("MM/dd/yyyy");
	
    /**
     * @param date
     * @param offset
     * @return
     */
    public static String addDate(String date, int offset) {
        Calendar c = Calendar.getInstance();
        int inputMonth = Integer.parseInt(date.substring(0, 2)) - 1;
        int inputDay = Integer.parseInt(date.substring(3, 5));
        int inputYear = Integer.parseInt(date.substring(6, 10));
        c.set(inputYear, inputMonth, inputDay);
        c.add(Calendar.DATE, offset);
        String month = null;
        String day = null;
        if (c.get(Calendar.MONTH) + 1 < 10) {
            month = "0" + Integer.toString(c.get(Calendar.MONTH) + 1);
        } else {
            month = Integer.toString(c.get(Calendar.MONTH) + 1);
        }
        if (c.get(Calendar.DATE) < 10) {
            day = "0" + Integer.toString(c.get(Calendar.DATE));
        } else {
            day = Integer.toString(c.get(Calendar.DATE));
        }
        String year = Integer.toString(c.get(Calendar.YEAR));
        return month + "/" + day + "/" + year;
    }


    /**
     * @param parm
     * @return
     */
    public static String arrayListToString(ArrayList parm) {
        return parm.toString().replaceAll(", ", ",").replace('[', ' ').replace(']', ' ').trim();
    }


    /**
     * @param inputDate
     * @param dateFormat
     * @return
     * @throws ParseException
     */
    public static int getDaysInMonth(String inputDate, String dateFormat) throws ParseException {
        Calendar calendar;
        SimpleDateFormat format = new SimpleDateFormat(dateFormat);
        Date date = format.parse(inputDate);
        calendar = Calendar.getInstance();
        calendar.setTime(date);
        return calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
    }


    /**
     * @param date1
     * @param date2
     * @return
     */
    public static boolean isBefore(String date1, String date2) {
        Calendar c1 = Calendar.getInstance();
        Calendar c2 = Calendar.getInstance();
        int inputMonth1 = Integer.parseInt(date1.substring(0, 2));
        int inputDay1 = Integer.parseInt(date1.substring(3, 5));
        int inputYear1 = Integer.parseInt(date1.substring(6, 10));
        int inputMonth2 = Integer.parseInt(date2.substring(0, 2));
        int inputDay2 = Integer.parseInt(date2.substring(3, 5));
        int inputYear2 = Integer.parseInt(date2.substring(6, 10));
        c1.set(inputYear1, inputMonth1, inputDay1);
        c2.set(inputYear2, inputMonth2, inputDay2);
        return c1.before(c2);
    }


    /**
     * @param strToSearchIn
     * @param strToSearchFor
     * @param delimiter
     * @return
     */
    public static int listContainsNoCase(String strToSearchIn, String strToSearchFor, char delimiter) {
        int result = 0;
        int index = strToSearchIn.toUpperCase().indexOf(strToSearchFor.toUpperCase());
        if (index == 0 || index == -1) {
            return index;
        }
        char[] charArray = strToSearchIn.substring(0, index).toCharArray();
        for (int i = 0; i < charArray.length; i++) {
            if (charArray[i] == delimiter) {
                result++;
            }
        }
        return result;
    }


    /**
     * @param strToSearchIn
     * @param strToSearchFor
     * @param delimiter
     * @return
     */
    public static int listFindNoCase(String strToSearchIn, String strToSearchFor, String delimiter) {
        int result = -1;
        ArrayList list = AdhocRptUtil.stringToArrayList(strToSearchIn, delimiter);
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).toString().equalsIgnoreCase(strToSearchFor)) {
                result = i;
            }
        }
        return result;
    }


    /**
     * @param inputStr
     * @param delimiter
     * @return
     */
    public static ArrayList stringToArrayList(String inputStr, String delimiter) {
        ArrayList parmList = new ArrayList();
        if (inputStr.trim().equals("")) {
            return parmList;
        }
        int index = inputStr.indexOf(delimiter);
        if (index == -1) {
            parmList.add(inputStr);
            return parmList;
        }
        parmList.add(inputStr.substring(0, index));
        int newIndex = 0;
        while (newIndex < inputStr.length()) {
            newIndex = inputStr.indexOf(delimiter, index + 1);
            if (newIndex == -1) {
                parmList.add(inputStr.substring(index + 1, inputStr.length()));
                break;
            }
            parmList.add(inputStr.substring(index + 1, newIndex));
            index = newIndex;
        }
        return parmList;
    }


    /**
     * Given a date and trend time, calculate the previous date.
     * 
     * @param currentDate
     * @param trendTime
     * @return
     */
    public static Date getPreviousDate(Date currentDate, String trendTime, AdhocRptDataTO dto,boolean billRnd) {
    	Calendar cal = Calendar.getInstance();
        cal.setTime(currentDate);

        if (trendTime.equals(TREND_TIME_DAILY)) {
        	if (dto.getPresnModel()==1 && (dto.getMonthSelect()!=0 || dto.getYearSelect()!=0) ){
        		cal.add(Calendar.MONTH, -1);
        	} else {
        		cal.add(Calendar.DATE, -7);
        	}
        }

        if (trendTime.equals(TREND_TIME_MONTHLY)) {
            cal.add(Calendar.MONTH, -1);
        }

        if (trendTime.equals(TREND_TIME_YEARLY)) {
            cal.add(Calendar.YEAR, -1);
        }

        if (trendTime.equals(TREND_TIME_BILL_ROUND)) {
        	if (dto.getPresnModel()==1 && (dto.getMonthSelect()!=0 || dto.getYearSelect()!=0) ){
        		cal.add(Calendar.MONTH, -1);
        	}else if (!billRnd){
        		//  First go back to previous month
                cal.add(Calendar.MONTH, -1);
                
                // Then get the valid proc date in that month
                String tempDate = MMDDYYYY_FORMAT.format(DateUtil.getFirstDayOfMonth(cal.getTime()));
                Date prevDate = AdhocRptDAO.getPreviousDate(tempDate, dto);
                
                // Return this as the date if not null
                if (prevDate != null){
                	// Made changes for PMT #169, issue #12
                	return new Date(prevDate.getTime());
                	//return prevDate;
                }
        	} else {
        		// Then get the valid proc date in that month
        		String currDate = MMDDYYYY_FORMAT.format(cal.getTime());
        		
        		//  Now go back to previous month
                Date prevDate = AdhocRptDAO.getPreviousDateForBillRnd(currDate,  dto);
                prevDate=parseDate(prevDate.toString());
                
                // Return this as the date if not null
                if (prevDate != null){
                	
                	// Made changes for PMT #169, issue #12
                	return new Date(prevDate.getTime());
                	//return prevDate;
                } 
        	}
        }

        // Added for Record
        if (trendTime.equals(TREND_TIME_NONE) || "".equals(trendTime)) {
        	cal.add(Calendar.MONTH, -3);
        }
        
        return cal.getTime();
    }

    /**
     * Method to return previous date
     * @param currentDate
     * @return
     */
    public static Date getPreviousDate(Date currentDate) {
    	Calendar cal = Calendar.getInstance();
        cal.setTime(currentDate);
        cal.add(Calendar.DATE, -1);
        return cal.getTime();
    }
    
    private AdhocRptUtil() {
    }
    public static Date parseDate(String dateString) {
        Date d = null;
        try {
            d = DateUtil.parseUnknown(dateString);
            if (d == null) {
                if (dateString.matches("\\d{6}")) {
                    d = DateUtil.parseDate(dateString, "yyyyMM");
                } else if (dateString.matches("\\d{2}[/]\\d{4}")){
                	d = DateUtil.parseDate(dateString, "MM/yyyy");
                } else if (dateString.matches("\\d{4}")) {
                    d = DateUtil.parseDate(dateString, "yyyy");
                } 
            }
        } catch (ParseException e) {
            throw new IllegalArgumentException(dateString + " is not a know date format.");
        }
        return d;
}
}
