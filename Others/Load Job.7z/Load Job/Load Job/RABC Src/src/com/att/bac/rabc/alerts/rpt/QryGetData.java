/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.rpt;

import java.util.List;
import java.util.ArrayList;
import org.apache.log4j.Logger;

import com.att.bac.rabc.MyDate;

/**
 * This class represents the data object that holds the attributes required
 * for QryGetData query used in Alert Rule Report page 12.
 * 
 * @author Nalina Pandiyan - NP5434
 */
public class QryGetData {
	private static final Logger logger = Logger.getLogger(QryGetData.class);

	private MyDate fileProcessDate;
	private int presnId;
	private String thisTable;
	private int thisPartiRefId;
	private String thisProcDate;
	private int sequenceNumber;
	private String thisPrevTotInd;
	private String thisTotInd;
	private String thisAlertTimeInd;
	private List columnNames;
	private List columnValues;

	/**
	 * Default constructor which sets default columnValues and columnNames attributes.
	 */
	public QryGetData() {
		this.columnValues = new ArrayList();
		this.columnNames = new ArrayList();
	}
	/**
	 * @return Returns the fileProcessDate.
	 */
	public MyDate getFileProcessDate() {
		return fileProcessDate;
	}

	/**
	 * @param fileProcessDate The fileProcessDate to set.
	 */
	public void setFileProcessDate(MyDate fileProcessDate) {
		this.fileProcessDate = fileProcessDate;
	}

	/**
	 * @return Returns the presnId.
	 */
	public int getPresnId() {
		return presnId;
	}

	/**
	 * @param presnId The presnId to set.
	 */
	public void setPresnId(int presnId) {
		this.presnId = presnId;
	}

	/**
	 * @return Returns the sequenceNumber.
	 */
	public int getSequenceNumber() {
		return sequenceNumber;
	}

	/**
	 * @param sequenceNumber The sequenceNumber to set.
	 */
	public void setSequenceNumber(int sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	/**
	 * @return Returns the thisPartiRefId.
	 */
	public int getThisPartiRefId() {
		return thisPartiRefId;
	}

	/**
	 * @param thisPartiRefId The thisPartiRefId to set.
	 */
	public void setThisPartiRefId(int thisPartiRefId) {
		this.thisPartiRefId = thisPartiRefId;
	}

	/**
	 * @return Returns the thisPrevTotInd.
	 */
	public String getThisPrevTotInd() {
		return thisPrevTotInd;
	}

	/**
	 * @param thisPrevTotInd The thisPrevTotInd to set.
	 */
	public void setThisPrevTotInd(String thisPrevTotInd) {
		this.thisPrevTotInd = thisPrevTotInd;
	}

	/**
	 * @return Returns the thisProcDate.
	 */
	public String getThisProcDate() {
		return thisProcDate;
	}

	/**
	 * @param thisProcDate The thisProcDate to set.
	 */
	public void setThisProcDate(String thisProcDate) {
		this.thisProcDate = thisProcDate;
	}

	/**
	 * @return Returns the thisTable.
	 */
	public String getThisTable() {
		return thisTable;
	}

	/**
	 * @param thisTable The thisTable to set.
	 */
	public void setThisTable(String thisTable) {
		this.thisTable = thisTable;
	}

	/**
	 * @return Returns the thisTotInd.
	 */
	public String getThisTotInd() {
		return thisTotInd;
	}

	/**
	 * @param thisTotInd The thisTotInd to set.
	 */
	public void setThisTotInd(String thisTotInd) {
		this.thisTotInd = thisTotInd;
	}
	
	/**
	 * This method is used to get Value For the passed colName.
	 * 
	 * @param colName
	 * @return String
	 */
	public String getValueFor(String colName) {
		if (colName == null) return null;
		int i = 0;
		int size = this.columnNames.size();

		if(colName.equals("File_Process_Date")) return fileProcessDate.toString();
		if(colName.equals("Sequence_Number")){
			if(sequenceNumber!=0){
				return Integer.toString(sequenceNumber);
			}else{
				return null;
			}
		}
		
		for(i = 0; i < size; i++) {
			if (colName.equalsIgnoreCase((String)this.columnNames.get(i))) {
				if(this.columnValues.get(i)!=null){
					return this.columnValues.get(i).toString().trim();
				}else{
					return null;
				}
			}
		}
		logger.warn("Logic - Column Name not found...Needs Verification");
		return null;
	}

	/**
	 * This method returns boolean value depend upon colName is exist or not.
	 * 
	 * @param colName
	 * @return boolean
	 */
	public boolean isExist(String colName) {
		if (colName == null) return false;
		int i = 0;
		int size = this.columnNames.size();
		for(i = 0; i < size; i++) {
			if (colName.equalsIgnoreCase((String)this.columnNames.get(i))) {
				return true; 
			}
		}
		return false;
	}

	/**
	 * @return Returns the thisAlertTimeInd.
	 */
	public String getThisAlertTimeInd() {
		return thisAlertTimeInd;
	}

	/**
	 * @param thisAlertTimeInd The thisAlertTimeInd to set.
	 */
	public void setThisAlertTimeInd(String thisAlertTimeInd) {
		this.thisAlertTimeInd = thisAlertTimeInd;
	}

	/**
	 * @return Returns the columnValue.
	 */
	public List getColumnValues() {
		return columnValues;
	}

	/**
	 * @return Returns the columnNames.
	 */
	public List getColumnNames() {
		return columnNames;
	}

}
