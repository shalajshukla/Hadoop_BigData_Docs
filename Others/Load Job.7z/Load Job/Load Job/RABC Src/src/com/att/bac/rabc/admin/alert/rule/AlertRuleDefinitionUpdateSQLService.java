/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.admin.alert.rule;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.att.bac.rabc.CntrlPtTrans;
import com.att.bac.rabc.CntrlPtTransDAO;
import com.att.bac.rabc.ExtrctTblDefDAO;
import com.att.bac.rabc.MouseOverLinkDAO;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.WebDataLinkDAO;
import com.att.bac.rabc.admin.AlertGroupDAO;
import com.att.bac.rabc.alerts.AlertRulePresnElemDAO;
import com.att.bac.rabc.alerts.AlertSumyPresnDAO;
import com.att.bac.rabc.alerts.rpt.AlertRulePresenRuleDAO;

/**
 * This is a Service class for Updating Trend and Track Alert Rule.
 * 
 * @author Shashank Weginwar - SW3562
 */
public class AlertRuleDefinitionUpdateSQLService {

	private static final Logger logger = Logger.getLogger(AlertRuleDefinitionUpdateSQLService.class);
	private static AlertRuleDefinitionUpdateSQLService alertRuleDefinitionUpdateSQLService;
	 
	protected static final String updARD_1 = "UPDATE RABC_ALERT_RULE SET USER_ID = ''{5}'', TIME_STAMP = SYSDATE, ALERT_DESC = ''{0}'', " +
	"ALERT_EXEC_DATE = ''{1}'', EFF_DATE = TO_DATE(''{2}'',''MM/DD/YYYY''), ALERT_DATA_KEEP = ''{4}'',ALERT_MNTH_EXEC_DAY = ''{6}''" +
	",ALERT_MNTH_EXEC_BILL_RND = ''{7}'',ALERT_EXEMPT_IND = ''{8}'' WHERE ALERT_RULE = ''{3}''";
	
	protected static final String updARD_2 = "UPDATE RABC_ALERT_RULE SET USER_ID = ''{4}'', TIME_STAMP = SYSDATE, ALERT_DESC = ''{0}'', " +
	"ALERT_EXEC_DATE = NULL, EFF_DATE = TO_DATE(''{1}'',''MM/DD/YYYY''), ALERT_DATA_KEEP = ''{3}'' ,ALERT_MNTH_EXEC_DAY = ''{5}''" +
	",ALERT_MNTH_EXEC_BILL_RND = ''{6}'',ALERT_EXEMPT_IND = ''{7}'' WHERE ALERT_RULE = ''{2}''";
	
	protected static final String delAlGroup = "DELETE RABC_UPDATE_GRP WHERE ALERT_RULE = ''{0}''";
	
	protected static final String insAlGrp = "INSERT INTO RABC_UPDATE_GRP(ALERT_RULE, ALERT_GRP) VALUES (''{0}'',''{1}'')";
	
	protected static final String delCntP = "DELETE RABC_CNTRL_PT_ALERT WHERE ALERT_RULE = ''{0}''";
	
	protected static final String getPSN = "SELECT CNTRL_PT_CODE, CNTRL_PT_DESC, PRESN_SEQ_NUM FROM RABC_CNTRL_PT_TRANS " +
	"WHERE CNTRL_PT_CODE = ''{0}''";
	
	protected static final String insRabcCntrlPtAlert = "INSERT INTO RABC_CNTRL_PT_ALERT (CNTRL_PT_CD, ALERT_RULE, " +
	"PRESN_SEQ_NUM) VALUES (''{0}'', ''{1}'',''{2}'')";
	
	protected static final String getMsg = "SELECT ALERT_RULE, PARTI_REF_ID, PRESN_ID, " +
	"FILE_VERIF_IND, DATA_EXTRCT_IND, DATA_CALC_IND, CALC_RULE, WARNING_IND, AVG_IND, ALERT_MSG_IND, " +
	"ALERT_SEQ_NUM_IND, ALERT_TIME_IND, ALERT_DASH_FRESH_IND, ALERT_DESC, ALERT_EXEC_DATE, ALERT_KEY_LVL, " +
	"ALERT_KEY1_NAME, ALERT_KEY2_NAME, ALERT_KEY3_NAME, ALERT_KEY4_NAME, ALERT_KEY5_NAME, ALERT_FILE_CT, " +
	"ASOC_FILE_ID, ALERT_RULE_PRESN_IND, DIVISION_NAME_KEY_LVL, DB_NODE_ID, ALERT_RULE_STATUS, EFF_DATE, " +
	"STD_TYPE, ALERT_EXEMPT_IND, USER_ID, TIME_STAMP, ALERT_DATA_KEEP, ALERT_RULE_TYPE,ALERT_MNTH_EXEC_DAY, ALERT_MNTH_EXEC_BILL_RND " +
	"FROM RABC_ALERT_RULE WHERE ALERT_RULE = ''{0}'' ORDER BY PRESN_ID";
	
	protected static final String delMsg = "DELETE RABC_PROC_RESPONSIBLE WHERE ALERT_RULE = ''{0}''";
	
	protected static final String updRabcProcResponsible = "INSERT INTO RABC_PROC_RESPONSIBLE (ALERT_RULE, ROLE_CD, " +
	"ALERT_GRP) VALUES (''{0}'', ''{1}'', ''{2}'')";
	
	protected static final String updAvgCalc_1 = "UPDATE RABC_AVG_CALC SET AVG_NUM_DATE = ''{0}'', AVG_NUM_REC = ''{1}'', " +
	"AVG_TYPE = ''{2}'' WHERE ALERT_RULE = ''{3}''";
	
	protected static final String updAvgCalc_2 = "UPDATE RABC_AVG_CALC SET AVG_NUM_DATE = NULL, AVG_NUM_REC = ''{1}'', " +
	"AVG_TYPE = ''{2}'' WHERE ALERT_RULE = ''{3}''";
	
	protected static final String updAvgCalc_3 = "UPDATE RABC_AVG_CALC SET AVG_NUM_DATE = ''{0}'', AVG_NUM_REC = NULL, " +
	"AVG_TYPE = ''{2}'' WHERE ALERT_RULE = ''{3}''";
	
	protected static final String updAvgCalc_4 = "UPDATE RABC_AVG_CALC SET AVG_NUM_DATE = NULL, AVG_NUM_REC = NULL, " +
	"AVG_TYPE = ''{2}'' WHERE ALERT_RULE = ''{3}''";
	
	protected static final String delSupp = "DELETE FROM RABC_ALERT_SUPP_RULE WHERE ALERT_RULE = ''{0}'' AND " +
	"ALERT_ITEM_NAME = ''{1}''";
	
	protected static final String insSuppForTrend = "INSERT INTO RABC_ALERT_SUPP_RULE (ALERT_RULE, ALERT_ITEM_NAME, " +
	"ALERT_ITEM_DDL_NAME, SUPP_SEQ_NUM, TBL_NAME, SUPP_ITEM_NAME, SUPP_ITEM_DDL_NAME, SUPP_PRESN_NAME, SUPP_PIC_LINK) " +
	"VALUES (''{0}'', ''{1}'', ''ALERT DATA'', ''{2}'', ''RABC_EXTRCT_SUMY_DATA'', NULL, ''{3}'',''{4}'', ''SQUARE.GIF'')";
	
	protected static final String getAsocPresnId = getMsg;

	protected static final String updRabcAlertProc = "UPDATE RABC_ALERT_PROC SET ALERT_TYPE = ''{0}'', " +
	"ALERT_CREATE_IND = ''{1}'' WHERE ALERT_RULE = ''{2}'' AND ALERT_ITEM_DDL_NAME = ''{3}''";
	
	protected static final String getDdlName = "SELECT SUPP_ITEM_DDL_NAME FROM RABC_ALERT_SUPP_RULE WHERE ALERT_RULE = ''{0}''";
	
	protected static final String insSuppForTrack = "INSERT INTO RABC_ALERT_SUPP_RULE (ALERT_RULE, ALERT_ITEM_NAME, " +
	"ALERT_ITEM_DDL_NAME, SUPP_SEQ_NUM, TBL_NAME, SUPP_ITEM_NAME, SUPP_ITEM_DDL_NAME, SUPP_PRESN_NAME, SUPP_PIC_LINK) " +
	"VALUES (''{0}'', ''{1}'', ''ALERT DATA'', ''{2}'', ''RABC_EXTRCT_SUMY_DATA'', ''{3}'', ''{4}'',''{5}'', ''SQUARE.GIF'')";
	
	protected static final String delFromAlertSumyPresn = "DELETE FROM RABC_ALERT_SUMY_PRESN WHERE ALERT_RULE = ''{0}'' " +
	"AND ASOC_PRESN_ID != ''{1}'' ";
	
	protected static final String insAlertSumyPresn = "INSERT INTO RABC_ALERT_SUMY_PRESN (SUMY_PRESN_NAME, " +
	"ALERT_RULE, WEBID, PRESN_SEQ_NUM, TOT_IND, ASOC_PRESN_ID) VALUES (''{0}'', ''{1}'', ''{2}'', ''{3}'', " +
	"''{4}'', ''{5}'')";
	
	protected static final String delFromAlertRulePresnElemForTrend = "DELETE RABC_ALERT_RULE_PRESN_ELEM WHERE PRESN_ID = ''{0}''";
	
	protected static final String insIntoAlertRulePresnElemForTrend = "INSERT INTO RABC_ALERT_RULE_PRESN_ELEM (PRESN_ID, " +
	"WEBID, EXEC_PRESN_SEQ_NUM, PRESN_SEQ_NUM, PRESN_NAME, DATA_TBL, PARTI_REF_ID, DATA_DDL_NAME, HEADER_LINK_IND, " +
	"HEADER_LINK_NUM, HEADER_DESC_IND, HEADER_MOUSE_OVER_NUM, DATA_LINK_IND, DATA_LINK_NUM, DATA_DESC_IND, " +
	"DATA_MOUSE_OVER_NUM, GRAPH_PRESN_IND, PRESN_ELEM_TOT_IND, PRESN_UNIT_IND, PRESN_SUM_IND, DATABASE_NODE, " +
	"PRESN_CALC_NUM, PRESN_SUPPRESS_IND, PREV_DATA_IND, VIEW_NAME, PRESN_ORD_IND,  PRESN_FORMAT_CODE, DIFF_DATA_IND ) " +
	"VALUES(''{0}'', ''RABCPSF00013'', ''1'', ''{1}'', ''{2}'', ''RABC_EXTRCT_SUMY_DATA'', ''{3}'', ''{4}'', NULL, NULL, " +
	"NULL, NULL, ''{8}'', ''{9}'', NULL, NULL, ''{7}'', NULL, ''{10}'', ''{6}'', NULL, NULL, NULL, NULL, ''RABC_EXTRCT_SUMY_DATA'', " +
	"NULL, ''{5}'',NULL)";
	
	protected static final String delFromAlertProc = "DELETE RABC_ALERT_PROC WHERE ALERT_RULE = ''{0}''";
	
	protected static final String insIntoAlertProcForTrack = "INSERT INTO RABC_ALERT_PROC (ALERT_RULE, ALERT_TYPE," +
	"ALERT_ITEM_DDL_NAME, ALERT_ITEM_DDL_DATA, ALERT_ITEM_AVG_NAME, ALERT_PROC_TBL, ALERT_PROC_AVG_TBL, ALERT_CREATE_IND, " +
	"ALERT_MSG_SUPP_DATA_IND, ALERT_THRSHLD_DFLT_IND, ALERT_CALC_NUM, ALERT_TBL_SEL_NUM, PARTI_REF_ID) VALUES(''{0}'', " +
	"''{1}'', ''{2}'', ''{3}'', ''{4}'', ''{5}'', ''{6}'', ''{7}'', ''{8}'', ''N'', ''{9}'', ''{10}'', ''{11}'')";
	
	protected static final String insIntoAlertProcForTrend = "INSERT INTO RABC_ALERT_PROC (ALERT_RULE, ALERT_TYPE, " +
	"ALERT_ITEM_DDL_NAME, ALERT_ITEM_DDL_DATA, ALERT_ITEM_AVG_NAME, ALERT_PROC_TBL, ALERT_PROC_AVG_TBL, " +
	"ALERT_CREATE_IND, ALERT_MSG_SUPP_DATA_IND, ALERT_THRSHLD_DFLT_IND, ALERT_CALC_NUM, ALERT_TBL_SEL_NUM, " +
	"PARTI_REF_ID) VALUES (''{0}'', ''{1}'', ''{2}'', ''{3}'', ''{4}'', ''{5}'', ''{6}'', ''{7}'', ''N'', ''N'', " +
	"''{8}'', ''{9}'', ''{10}'')";
	
	protected static final String insIntoExtrctTblDefForTrend = "INSERT INTO RABC_EXTRCT_TBL_DEF (PARTI_REF_ID, " +
	"EXTRCT_KEY_LVL, KEY1_NAME, KEY2_NAME, KEY3_NAME, KEY4_NAME, KEY5_NAME, EXTRCT_ITEM_NAME, EXTRCT_DATA_CT, " +
	"EXTRCT_DATA_LEFT_CT, EXTRCT_DATA_RIGHT_CT, EXTRCT_DATA1_NAME, EXTRCT_DATA2_NAME, EXTRCT_DATA3_NAME, EXTRCT_DATA4_NAME, " +
	"EXTRCT_DATA5_NAME, EXTRCT_DATA6_NAME, EXTRCT_DATA7_NAME, EXTRCT_DATA8_NAME, EXTRCT_DATA9_NAME, EXTRCT_DATA10_NAME, " +
	"EXTRCT_DATA11_NAME, EXTRCT_DATA12_NAME, EXTRCT_DATA13_NAME, EXTRCT_DATA14_NAME, EXTRCT_DATA15_NAME) VALUES " +
	"(''{0}'', ''{1}'', ''{2}'', ''{3}'', ''{4}'', ''{5}'', ''{6}'', NULL, ''{7}'', ''0'', ''0'', ''{8}'', ''{9}'', " +
	"''{10}'', ''{11}'', ''{12}'', ''{13}'', ''{14}'', ''{15}'', ''{16}'', ''{17}'', ''{18}'', ''{19}'', ''{20}'', " +
	"''{21}'', ''{22}'')";
	
	protected static final String insIntoExtrctTblDefForTrack = "INSERT INTO RABC_EXTRCT_TBL_DEF(PARTI_REF_ID," +
	"EXTRCT_KEY_LVL, KEY1_NAME, KEY2_NAME, KEY3_NAME, KEY4_NAME, KEY5_NAME, EXTRCT_ITEM_NAME, EXTRCT_DATA_CT, " +
	"EXTRCT_DATA_LEFT_CT, EXTRCT_DATA_RIGHT_CT, EXTRCT_DATA1_NAME, EXTRCT_DATA2_NAME, EXTRCT_DATA3_NAME, " +
	"EXTRCT_DATA4_NAME, EXTRCT_DATA5_NAME, EXTRCT_DATA6_NAME,EXTRCT_DATA7_NAME, EXTRCT_DATA8_NAME, EXTRCT_DATA9_NAME, " +
	"EXTRCT_DATA10_NAME, EXTRCT_DATA11_NAME, EXTRCT_DATA12_NAME, EXTRCT_DATA13_NAME, EXTRCT_DATA14_NAME, " +
	"EXTRCT_DATA15_NAME) VALUES(''{0}'', ''{1}'',''{2}'', ''{3}'', ''{4}'', ''{5}'', ''{6}'', ''{7}'', ''{8}'', " +
	"''{9}'', ''{10}'', ''{11}'', ''{12}'', ''{13}'', ''{14}'', ''{15}'', ''{16}'', ''{17}'', ''{18}'', ''{19}'', " +
	"''{20}'', ''{21}'', ''{22}'', ''{23}'', ''{24}'', ''{25}'')";
	
	protected static final String delFromExtrctTblDef = "DELETE RABC_EXTRCT_TBL_DEF WHERE PARTI_REF_ID = ''{0}''";
	
	protected static final String insTrackFileDtlForTrack = "INSERT INTO RABC_TRACK_FILE_DTL(ALERT_RULE, " +
	"FILE_ID, ALERT_ITEM_NAME, ALERT_ITEM_IND, ALERT_DATE_IND, ALERT_ITEM_EXTRCT_TBL, PARTI_REF_ID, ALERT_ITEM_KEY_LVL, " +
	"ALERT_ITEM_KEY1_NAME, ALERT_ITEM_KEY2_NAME, ALERT_ITEM_KEY3_NAME, ALERT_ITEM_KEY4_NAME, ALERT_ITEM_KEY5_NAME, " +
	"ALERT_ITEM_DATA_CT, ALERT_ITEM1_DDL_NAME, ALERT_ITEM1_SUM_IND, ALERT_ITEM1_DDL_NAME_IND,ALERT_ITEM2_DDL_NAME, " + 
	"ALERT_ITEM2_SUM_IND,ALERT_ITEM2_DDL_NAME_IND,ALERT_ITEM3_DDL_NAME, ALERT_ITEM3_SUM_IND, ALERT_ITEM3_DDL_NAME_IND, " + 
	"ALERT_ITEM4_DDL_NAME, ALERT_ITEM4_SUM_IND, ALERT_ITEM4_DDL_NAME_IND,ALERT_ITEM5_DDL_NAME,ALERT_ITEM5_SUM_IND, " + 
	"ALERT_ITEM5_DDL_NAME_IND,ALERT_ITEM6_DDL_NAME, ALERT_ITEM6_SUM_IND, ALERT_ITEM6_DDL_NAME_IND,ALERT_ITEM7_DDL_NAME, " + 
	"ALERT_ITEM7_SUM_IND, ALERT_ITEM7_DDL_NAME_IND,ALERT_ITEM8_DDL_NAME, ALERT_ITEM8_SUM_IND, ALERT_ITEM8_DDL_NAME_IND," + 
	"ALERT_ITEM9_DDL_NAME, ALERT_ITEM9_SUM_IND, ALERT_ITEM9_DDL_NAME_IND,ALERT_ITEM10_DDL_NAME,ALERT_ITEM10_SUM_IND, " + 
	"ALERT_ITEM10_DDL_NAME_IND,ALERT_ITEM11_DDL_NAME, ALERT_ITEM11_SUM_IND, ALERT_ITEM11_DDL_NAME_IND,ALERT_ITEM12_DDL_NAME, " + 
	"ALERT_ITEM12_SUM_IND,ALERT_ITEM12_DDL_NAME_IND,ALERT_ITEM13_DDL_NAME, ALERT_ITEM13_SUM_IND, ALERT_ITEM13_DDL_NAME_IND, " + 
	"ALERT_ITEM14_DDL_NAME, ALERT_ITEM14_SUM_IND, ALERT_ITEM14_DDL_NAME_IND,ALERT_ITEM15_DDL_NAME, ALERT_ITEM15_SUM_IND, " + 
	"ALERT_ITEM15_DDL_NAME_IND, VIEW_NAME, ALERT_ITEM_ORD) VALUES(''{0}'', ''{1}'', NULL, ''{2}'', ''{3}'', ''{4}'', NULL, " +
	"''{5}'', ''{6}'', ''{7}'', ''{8}'', ''{9}'', ''{10}'', ''{11}'', ''{12}'', ''{13}'', ''{14}'', ''{15}'', ''{16}'', " +
	"''{17}'', ''{18}'', ''{19}'', ''{20}'', ''{21}'', ''{22}'', ''{23}'', ''{24}'', ''{25}'', ''{26}'', ''{27}'', " +
	"''{28}'', ''{29}'', ''{30}'', ''{31}'', ''{32}'', ''{33}'', ''{34}'', ''{35}'', ''{36}'', ''{37}'', ''{38}'', " +
	"''{39}'', ''{40}'', ''{41}'', ''{42}'', ''{43}'',''{44}'',''{45}'',''{46}'',''{47}'',''{48}'',''{49}'',''{50}'',''{51}''," + 
	"''{52}'',''{53}'',''{54}'',''{55}'',''{56}'',''{57}'',''{58}'')";
	
	protected static final String insTrackFileDtlForTrend =  "INSERT INTO RABC_TRACK_FILE_DTL (ALERT_RULE, FILE_ID, " +
	"ALERT_ITEM_NAME, ALERT_DATE_IND, ALERT_ITEM_EXTRCT_TBL, PARTI_REF_ID, ALERT_ITEM_KEY_LVL, ALERT_ITEM_KEY1_NAME, " +
	"ALERT_ITEM_KEY2_NAME, ALERT_ITEM_KEY3_NAME, ALERT_ITEM_KEY4_NAME, ALERT_ITEM_KEY5_NAME, ALERT_ITEM_DATA_CT, " +
	"ALERT_ITEM1_DDL_NAME, ALERT_ITEM1_SUM_IND, ALERT_ITEM1_DDL_NAME_IND, ALERT_ITEM2_DDL_NAME, ALERT_ITEM2_SUM_IND," + 
	"ALERT_ITEM2_DDL_NAME_IND,ALERT_ITEM3_DDL_NAME, ALERT_ITEM3_SUM_IND, ALERT_ITEM3_DDL_NAME_IND,ALERT_ITEM4_DDL_NAME," + 
	"ALERT_ITEM4_SUM_IND, ALERT_ITEM4_DDL_NAME_IND,ALERT_ITEM5_DDL_NAME, ALERT_ITEM5_SUM_IND, ALERT_ITEM5_DDL_NAME_IND," +
	"ALERT_ITEM6_DDL_NAME, ALERT_ITEM6_SUM_IND, ALERT_ITEM6_DDL_NAME_IND,ALERT_ITEM7_DDL_NAME, ALERT_ITEM7_SUM_IND, " + 
	"ALERT_ITEM7_DDL_NAME_IND,ALERT_ITEM8_DDL_NAME,ALERT_ITEM8_SUM_IND, ALERT_ITEM8_DDL_NAME_IND,ALERT_ITEM9_DDL_NAME, " + 
	"ALERT_ITEM9_SUM_IND, ALERT_ITEM9_DDL_NAME_IND,ALERT_ITEM10_DDL_NAME, ALERT_ITEM10_SUM_IND, ALERT_ITEM10_DDL_NAME_IND," +
	"ALERT_ITEM11_DDL_NAME, ALERT_ITEM11_SUM_IND,ALERT_ITEM11_DDL_NAME_IND, ALERT_ITEM12_DDL_NAME, ALERT_ITEM12_SUM_IND," + 
	"ALERT_ITEM12_DDL_NAME_IND,ALERT_ITEM13_DDL_NAME,ALERT_ITEM13_SUM_IND, ALERT_ITEM13_DDL_NAME_IND,ALERT_ITEM14_DDL_NAME," + 
	"ALERT_ITEM14_SUM_IND,ALERT_ITEM14_DDL_NAME_IND, ALERT_ITEM15_DDL_NAME, ALERT_ITEM15_SUM_IND, ALERT_ITEM15_DDL_NAME_IND," +
	"VIEW_NAME, ALERT_ITEM_ORD) VALUES (''{0}'', ''{1}'', NULL, ''Y'', ''{2}'', NULL,	''{3}'', ''{4}'', ''{5}'', " +
	"''{6}'', ''{7}'',''{8}'', ''{9}'', ''{10}'', ''{11}'', ''{12}'', ''{13}'', ''{14}'', ''{15}'', ''{16}'', " +
	"''{17}'', ''{18}'', ''{19}'', ''{20}'', ''{21}'', ''{22}'', ''{23}'', ''{24}'', ''{25}'', ''{26}'', ''{27}'', " +
	"''{28}'', ''{29}'', ''{30}'', ''{31}'', ''{32}'', ''{33}'', ''{34}'', ''{35}'', ''{36}'', ''{37}'', ''{38}'', ''{39}'', " +
	"''{40}'', ''{41}'', ''{42}'', ''{43}'',''{44}'',''{45}'',''{46}'',''{47}'',''{48}'',''{49}'',''{50}'',''{51}''," + 
	"''{52}'',''{53}'',''{54}'',''{55}'',''{56}'')";
	
	protected static final String delTrackFileDtl = "DELETE RABC_TRACK_FILE_DTL WHERE ALERT_RULE = ''{0}''";
	
	protected static final String insExtrctBuildRuleTrack = "INSERT INTO RABC_EXTRCT_BUILD_RULE (PARTI_REF_ID," +
	"EXTRCT_TYPE,EXTRCT_RNDUP_IND,EXTRCT_ITEM_NAME,EXTRCT_TO_TBL,EXTRCT_ITEM1_NAME, EXTRCT_ITEM1_CALC_IND, " +
	"FILE_ITEM1_NAME,EXTRCT_ITEM2_NAME, EXTRCT_ITEM2_CALC_IND, FILE_ITEM2_NAME, EXTRCT_ITEM3_NAME, EXTRCT_ITEM3_CALC_IND, " +
	"FILE_ITEM3_NAME,EXTRCT_ITEM4_NAME, EXTRCT_ITEM4_CALC_IND, FILE_ITEM4_NAME, EXTRCT_ITEM5_NAME, EXTRCT_ITEM5_CALC_IND, " +
	"FILE_ITEM5_NAME, EXTRCT_ITEM6_NAME, EXTRCT_ITEM6_CALC_IND, FILE_ITEM6_NAME, EXTRCT_ITEM7_NAME, EXTRCT_ITEM7_CALC_IND, " +
	"FILE_ITEM7_NAME, EXTRCT_ITEM8_NAME, EXTRCT_ITEM8_CALC_IND, FILE_ITEM8_NAME, EXTRCT_ITEM9_NAME, EXTRCT_ITEM9_CALC_IND, " +
	"FILE_ITEM9_NAME)VALUES (''{0}'', ''{1}'', NULL, ''{2}'', ''RABC_EXTRCT_SUMY_DATA'', ''{3}'', ''{4}'', ''{5}'', ''{6}'', " +
	"''{7}'', ''{8}'', ''{9}'', ''{10}'', ''{11}'', ''{12}'', ''{13}'', ''{14}'', ''{15}'', ''{16}'', ''{17}'', ''{18}'', " +
	"''{19}'', ''{20}'', ''{21}'', ''{22}'', ''{23}'', ''{24}'', ''{25}'', ''{26}'', ''{27}'', ''{28}'', ''{29}'') ";
	
	protected static final String delExtrctBuildRuleTrack = "DELETE RABC_EXTRCT_BUILD_RULE WHERE PARTI_REF_ID = ''{0}''";
	
	protected static final String insAvgTblDefTrack = "INSERT INTO RABC_AVG_TBL_DEF (PARTI_REF_ID, AVG_KEY_LVL, " +
	"KEY1_NAME, KEY2_NAME, KEY3_NAME, KEY4_NAME, KEY5_NAME, AVG_ITEM_NAME, AVG_DATA_CT, AVG_DATA1_NAME, AVG_DATA2_NAME, " +
	"AVG_DATA3_NAME, AVG_DATA4_NAME, AVG_DATA5_NAME, AVG_DATA6_NAME, AVG_DATA7_NAME, AVG_DATA8_NAME, AVG_DATA9_NAME, " +
	"AVG_DATA10_NAME, AVG_DATA11_NAME, AVG_DATA12_NAME, AVG_DATA13_NAME, AVG_DATA14_NAME, AVG_DATA15_NAME)VALUES " +
	"(''{0}'', ''{1}'', ''{2}'', ''{3}'', ''{4}'', ''{5}'', ''{6}'', ''{7}'', ''{8}'', ''{9}'', ''{10}'', ''{11}'', " +
	"''{12}'', ''{13}'', ''{14}'', ''{15}'', ''{16}'', ''{17}'', ''{18}'', ''{19}'', ''{20}'', ''{21}'', ''{22}'', ''{23}'')";
	
	protected static final String delAvgTblDefTrack = "DELETE RABC_AVG_TBL_DEF WHERE PARTI_REF_ID = ''{0}''";
	
	protected static final String delMouseOverLink = "DELETE RABC_MOUSE_OVER_LINK WHERE PRESN_ID = ''{0}''";
	
	protected static final String insMouseOverLink = "INSERT INTO RABC_MOUSE_OVER_LINK (PRESN_ID, WEBID, EXEC_PRESN_SEQ_NUM, " +
	"MOUSE_OVER_NUM, LINK_TBL_NAME, LINK_TBL_KEY_NAME, LINK_TBL_KEY_DATA) VALUES (''{0}'', ''{1}'', ''1'', ''{2}'', " +
	"''{3}'', ''{4}'', ''{5}'')";
	
	protected static final String updAlertRulePresnRule = "UPDATE RABC_ALERT_RULE_PRESN_RULE SET KEY1_MOUSE_OVER_NUM = ''{0}'', " +
	"KEY2_MOUSE_OVER_NUM = ''{2}'', KEY3_MOUSE_OVER_NUM = ''{4}'', KEY4_MOUSE_OVER_NUM = ''{6}'', KEY5_MOUSE_OVER_NUM = ''{8}'', " +
	"KEY1_DESC_IND = ''{1}'', KEY2_DESC_IND = ''{3}'', KEY3_DESC_IND = ''{5}'', KEY4_DESC_IND = ''{7}'',KEY5_DESC_IND = ''{9}'' " +
	"WHERE PRESN_ID = ''{10}''";
	
	protected static final String updAlertRulePresnRuleForReportLinkForPage13 = "UPDATE RABC_ALERT_RULE_PRESN_RULE SET KEY1_DATA_LINK_IND = ''{0}'', " +
	"KEY1_DATA_LINK_NUM = ''{1}'', KEY2_DATA_LINK_IND = ''{2}'', KEY2_DATA_LINK_NUM = ''{3}'', KEY3_DATA_LINK_IND = ''{4}'', " +
	"KEY3_DATA_LINK_NUM = ''{5}'', KEY4_DATA_LINK_IND = ''{6}'', KEY4_DATA_LINK_NUM = ''{7}'', KEY5_DATA_LINK_IND = ''{8}'', " +
	"KEY5_DATA_LINK_NUM = ''{9}'' WHERE PRESN_ID = ''{10}'' AND WEBID = ''RABCPSF00013'' ";
	
	protected static final String delWebDataLinkForPage13 = "DELETE RABC_WEB_DATA_LINK WHERE PRESN_ID = ''{0}'' AND WEBID = ''RABCPSF00013''";
	
	protected static final String insWebDataLinkForPage13 = "INSERT INTO RABC_WEB_DATA_LINK (PRESN_ID, WEBID, " +
	"EXEC_PRESN_SEQ_NUM, LINK_NUM,LINK_DDL_NAME, LINK_TO_PGM, LINK_PRESN_ID)VALUES (''{0}'', ''RABCPSF00013'', ''1'', " +
	"''{1}'', ''{2}'', ''AdhocRpt.do'', ''{3}'')";
	
	protected static final String getCalculationFormatCode = "SELECT DISTINCT PRESN_FORMAT_CODE FROM RABC_PRESN_CALC_ELEM WHERE PRESN_CALC_NAME = ''{0}''";
		
	protected static final String DEL_RABC_TRIG_CONVERT = "DELETE FROM RABC_TRIG_CONVERT WHERE ALERT_RULE = ''{0}''";
	
	protected static final String INS_RABC_TRIG_CONVERT_Track = "INSERT INTO RABC_TRIG_CONVERT (FILE_ID, ALERT_RULE, " +
	"PROC_PGM, RUN_CHK_DAY, RUN_CHK_HR, RUN_FREQ_IND) VALUES (''{0}'', ''{1}'',''RABC_BKG_CNTRL_RULE_DRIVER.JAVA''," +
	"''{3}'', ''0'', ''{2}'')";

	protected static final String INS_RABC_TRIG_CONVERT_Trend = "INSERT INTO RABC_TRIG_CONVERT (FILE_ID, ALERT_RULE, " +
	"PROC_PGM, RUN_CHK_DAY, RUN_CHK_HR, RUN_FREQ_IND) VALUES (''{0}'', ''{1}'', ''RABC_BKG_CNTRL_RULE_DRIVER.JAVA'', " +
	"''{3}'', ''0'', ''{2}'')";
	
	protected static final String updStdDeviation = "UPDATE RABC_STD_CALC SET STD_NUM_DATE = ''{0}'' WHERE ALERT_RULE = ''{1}''";
	
	/**
	 * Synchronized method to return the instance of AlertRuleDefinitionUpdateSQLService object.
	 * It checks the existance of the instance of AlertRuleDefinitionUpdateSQLService and if it does not exists
	 * then creates one instance of AlertRuleDefinitionUpdateSQLService and returns otherwise it returns the
	 * existing instance of AlertRuleDefinitionUpdateSQLService.
	 * 
	 * @return AlertRuleDefinitionUpdateSQLService
	 */
	public static synchronized AlertRuleDefinitionUpdateSQLService getAlertRuleDefinitionUpdateSQLService(){
		if (alertRuleDefinitionUpdateSQLService == null){
			alertRuleDefinitionUpdateSQLService = new AlertRuleDefinitionUpdateSQLService();
		}
		return alertRuleDefinitionUpdateSQLService;
	}
	
	/**
	 * Returns Alert Rule Details.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertRuleDefinition
	 * @return String
	 */
	protected String getAlertRuleDetails (Connection connection, List failures, AlertRuleDefinition alertRuleDefinition){
		String alertRuleDetails = null;
		List alertRuleNameList = new ArrayList();
		alertRuleNameList.add(alertRuleDefinition.getAlertRule());
		AlertRuleDAO alertRuleDAO = new AlertRuleDAO();
		List alertRuleList = alertRuleDAO.get(connection,failures,alertRuleNameList,getMsg);
		if(alertRuleList.size() > 0){
			alertRuleDetails = ((AlertRule)alertRuleList.get(0)).getAlertMsgInd();
		}
		return alertRuleDetails;
	}

	/**
	 * Returns Alert Rule Details.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertRuleDefinition
	 * @return AlertRule
	 */
	protected AlertRule getAlertRule (Connection connection, List failures, AlertRuleDefinition alertRuleDefinition){
		AlertRule alertRule = null;
		List alertRuleNameList = new ArrayList();
		alertRuleNameList.add(alertRuleDefinition.getAlertRule());
		AlertRuleDAO alertRuleDAO = new AlertRuleDAO();
		List alertRuleList = alertRuleDAO.get(connection,failures,alertRuleNameList,getMsg);
		if(alertRuleList.size() > 0){
			alertRule = (AlertRule)alertRuleList.get(0);
		}
		return alertRule;
	}
	
	
	/**
	 * Returns Alert Rule Details.
	 * 
	 * @param connection
	 * @param failures
	 * @param selectedRealtedAlerts
	 * @return String
	 */
	protected String getAlertRuleDetails (Connection connection, List failures, String [] selectedRealtedAlerts){
		String alertRuleDetails = null;
		List alertRuleNameList = new ArrayList();
		alertRuleNameList.add(selectedRealtedAlerts[0]);
		AlertRuleDAO alertRuleDAO = new AlertRuleDAO();
		List alertRuleList = alertRuleDAO.get(connection,failures,alertRuleNameList,getAsocPresnId);
		if(alertRuleList.size() > 0){
			alertRuleDetails = (new Integer (((AlertRule)alertRuleList.get(0)).getPresnId())).toString();
		}
		return alertRuleDetails;
	}
	
	/**
	 * Returns the presence sequence number.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertRuleDefinition
	 * @return int
	 */
	protected int getCntrlPtTrans(Connection connection, List failures, AlertRuleDefinition alertRuleDefinition){
		int GPSN = 0;
		List cntrlPtCodeList = new ArrayList();
		cntrlPtCodeList.add(alertRuleDefinition.getControlPoint());
		CntrlPtTransDAO cntrlPtTransDAO = new CntrlPtTransDAO();
		List cntrlPtTransList = cntrlPtTransDAO.get(connection,failures,cntrlPtCodeList,getPSN);
		if(cntrlPtTransList.size() > 0){
			GPSN = ((CntrlPtTrans)cntrlPtTransList.get(0)).getPresnSeqNum();
		}
		return GPSN;
	}
	
	/**
	 * Returns Item DDL Name.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertRuleDefinition
	 * @return String
	 */
	protected String getDdlName(Connection connection, List failures, AlertRuleDefinition alertRuleDefinition){
		String itemDdlName = null;
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		List arguments = new ArrayList();
		arguments.add(alertRuleDefinition.getAlertRule());
		//arguments.add(itemName);
		try
		{
			MessageFormat mf = new MessageFormat(getDdlName);
			prepareStatement = mf.format((String[])arguments.toArray(new String[arguments.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			
			while(rs.next()){
				itemDdlName = rs.getString("SUPP_ITEM_DDL_NAME");
				break;
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
			return "1";
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
		return itemDdlName;
	}
	
	/**
	 * Updates RABC_ALERT_RULE table.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param alertRuleDefinition
	 * @param pickSql
	 * @return boolean
	 */
	protected boolean alertRuleTransaction(Connection connection,List failureList,List args, AlertRuleDefinition alertRuleDefinition,int pickSql){
		boolean success = true;
		AlertRuleDAO alertRuleDAO = new AlertRuleDAO();
		String selectSQL = updARD_1;
		if (pickSql ==1){
			selectSQL = updARD_1;
		}else {
			selectSQL = updARD_2;
		}

		alertRuleDAO.executeUpdate(connection,failureList,args,selectSQL);
				
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
	
	/**
	 * Performs insert and delete operations on RABC_UPDATE_GRP table.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param pickSQL
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	protected boolean alertGroupTransaction(Connection connection,List failureList,List args, int pickSQL, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		AlertGroupDAO alertGroupDAO = new AlertGroupDAO();
		String selectSQL = null;
		if (pickSQL == 1){
			selectSQL = delAlGroup;
		}else if (pickSQL == 2){
			selectSQL = insAlGrp;
		}
		alertGroupDAO.executeUpdate(connection,failureList,args,selectSQL);
				
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
	
	/**
	 * Performs insert and delete operations on RABC_CNTRL_PT_ALERT table. 
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param pickSQL
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	protected boolean cntrlPtAlertTransaction(Connection connection,List failureList,List args, int pickSQL, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		CntrlPtAlertDAO cntrlPtAlertDAO = new CntrlPtAlertDAO();
		String selectSQL = null;
		if (pickSQL == 1){
			selectSQL = delCntP;
		}else if (pickSQL == 2){
			selectSQL = insRabcCntrlPtAlert;
		}
		cntrlPtAlertDAO.executeUpdate(connection,failureList,args,selectSQL);
				
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
	
	/**
	 * Performs update and delete operations on RABC_PROC_RESPONSIBLE table. 
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param pickSQL
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	protected boolean procResponsibleTransaction(Connection connection,List failureList,List args, int pickSQL, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		ProcResponsibleDAO procResponsibleDAO = new ProcResponsibleDAO();
		String selectSQL = null;
		if (pickSQL == 1){
			selectSQL = delMsg;
		}else if (pickSQL == 2){
			selectSQL = updRabcProcResponsible;
		}
		procResponsibleDAO.executeUpdate(connection,failureList,args,selectSQL);
				
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
	
	/**
	 * Updates RABC_AVG_CALC table.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param pickSQL
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	protected boolean avgCalcTransaction(Connection connection,List failureList,List args, int pickSQL, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		AvgCalcDAO avgCalcDAO = new AvgCalcDAO();
		String selectSQL = null;
		if (pickSQL == 1){
			selectSQL = updAvgCalc_1;
		}else if (pickSQL == 2){
			selectSQL = updAvgCalc_2;
		}else if (pickSQL == 3){
			selectSQL = updAvgCalc_3;
		}else if (pickSQL == 4){
			selectSQL = updAvgCalc_4;
		}
		avgCalcDAO.executeUpdate(connection,failureList,args,selectSQL);
				
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
		
	/**
	 * Performs insert and delete operations on RABC_ALERT_SUPP_RULE table.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param pickSQL
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	protected boolean alertSuppRuleTransaction(Connection connection,List failureList,List args, int pickSQL, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		AlertSuppRuleDAO alertSuppRuleDAO = new AlertSuppRuleDAO();
		String selectSQL = null;
		if (pickSQL == 1){
			selectSQL = delSupp;
		}else if (pickSQL == 2){
			selectSQL = insSuppForTrend;
		}else if (pickSQL == 3){
			selectSQL = insSuppForTrack;
		}
		alertSuppRuleDAO.executeUpdate(connection,failureList,args,selectSQL);
				
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}	
	
	/**
	 * Performs update and delete operations on RABC_ALERT_SUMY_PRESN table.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param pickSQL
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	protected boolean alertSumyPresnTransaction(Connection connection,List failureList,List args, int pickSQL, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		AlertSumyPresnDAO alertSumyPresnDAO = new AlertSumyPresnDAO(); 
		String selectSQL = null;
		if (pickSQL == 1){
			selectSQL = delFromAlertSumyPresn;
		}else if (pickSQL == 2){
			selectSQL = insAlertSumyPresn;
		}
		alertSumyPresnDAO.executeUpdate(connection,failureList,args,selectSQL);
				
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}	
	
	/**
	 * Updates RABC_ALERT_PROC table.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param alertRuleDefinition
	 * @return boolean
	 */ 
	protected boolean alertProcTransaction(Connection connection,List failureList,List args, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		AlertProcDAO alertProcDAO = new AlertProcDAO();
		String selectSQL = updRabcAlertProc;
		alertProcDAO.executeUpdate(connection,failureList,args,selectSQL);
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
	
	/**
	 * Deletes from RABC_ALERT_RULE_PRESN_ELEM table for trending rule.
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return boolean
	 */
	protected boolean deleteAlertRulePresenElemForTrend(Connection connection,List failureList,List args){
		boolean success = true;
		AlertRulePresnElemDAO alertRulePresenElemDAO = new AlertRulePresnElemDAO();
		alertRulePresenElemDAO.executeUpdate(connection,failureList,args,delFromAlertRulePresnElemForTrend);
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
		
	/**
	 * Insert into RABC_ALERT_RULE_PRESN_ELEM table for trending rule.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return boolean
	 */
	protected boolean insertAlertRulePresenElemForTrend(Connection connection,List failureList,List args){
		boolean success = true;
		AlertRulePresnElemDAO alertRulePresenElemDAO = new AlertRulePresnElemDAO();
		alertRulePresenElemDAO.executeUpdate(connection,failureList,args,insIntoAlertRulePresnElemForTrend);
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
	
	/**
	 * Delete from RABC_ALERT_PROC table for track and trend rules.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return boolean
	 */
	protected boolean deleteAlertProc(Connection connection,List failureList,List args){
		boolean success = true;
		AlertProcDAO alertProcDAO = new AlertProcDAO();
		alertProcDAO.executeUpdate(connection,failureList,args,delFromAlertProc);
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
		
	/**
	 * Insert into RABC_ALERT_PROC table for track and trend rules.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	protected boolean insertAlertProc(Connection connection,List failureList,List args, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		AlertProcDAO alertProcDAO = new AlertProcDAO();
		if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
			alertProcDAO.executeUpdate(connection,failureList,args,insIntoAlertProcForTrack);
		} else {
			alertProcDAO.executeUpdate(connection,failureList,args,insIntoAlertProcForTrend);
		}
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
	
	/**
	 * Delete from RABC_EXTRCT_TBL_DEF table.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return boolean
	 */
	protected boolean deleteExtrctTblDef(Connection connection,List failureList,List args){
		boolean success = true;
		ExtrctTblDefDAO extractTblDefDAO = new ExtrctTblDefDAO();
		extractTblDefDAO.executeUpdate(connection,failureList,args,delFromExtrctTblDef);
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
	
	/**
	 * Insert into RABC_EXTRCT_TBL_DEF table.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	protected boolean insertExtrctTblDef(Connection connection,List failureList,List args, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		ExtrctTblDefDAO extractTblDefDAO = new ExtrctTblDefDAO(); 
		if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
			extractTblDefDAO.executeUpdate(connection,failureList,args,insIntoExtrctTblDefForTrack);
		} else {
			extractTblDefDAO.executeUpdate(connection,failureList,args,insIntoExtrctTblDefForTrend);
		}
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;	
	}
	
	/**
	 * Delete from RABC_TRACK_FILE_DTL table for trending and tracking rule.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return boolean
	 */
	protected boolean deleteTrackFileDtl(Connection connection,List failureList,List args){
		boolean success = true;
		TrackFileDtlDAO trackFileDtlDAO = new TrackFileDtlDAO();
		trackFileDtlDAO.executeUpdate(connection,failureList,args,delTrackFileDtl);
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
	
	/**
	 * Insert into RABC_TRACK_FILE_DTL table for trending and tracking rule.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	protected boolean insertTrackFileDtl(Connection connection,List failureList,List args, AlertRuleDefinition alertRuleDefinition) {
		boolean success = true;
		TrackFileDtlDAO trackFileDtlDAO = new TrackFileDtlDAO();
		if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
			trackFileDtlDAO.executeUpdate(connection,failureList,args,insTrackFileDtlForTrack);
		} else {
			trackFileDtlDAO.executeUpdate(connection,failureList,args,insTrackFileDtlForTrend);
		}
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
	
	/**
	 * Delete from RABC_EXTRCT_BUILD_RULE table for tracking rule.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return boolean
	 */
	protected boolean deleteExtrctBuildRuleForTrack(Connection connection,List failureList,List args){
		boolean success = true;
		ExtractBuildRuleDAO extractBuildRuleDAO = new ExtractBuildRuleDAO();
		extractBuildRuleDAO.executeUpdate(connection,failureList,args,delExtrctBuildRuleTrack);
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
	
	/**
	 * Insert into RABC_EXTRCT_BUILD_RULE table for tracking rule.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return boolean
	 */
	protected boolean insertExtrctBuildRuleForTrack(Connection connection,List failureList,List args) {
		boolean success = true;
		ExtractBuildRuleDAO extractBuildRuleDAO = new ExtractBuildRuleDAO();
		extractBuildRuleDAO.executeUpdate(connection,failureList,args,insExtrctBuildRuleTrack);
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
	
	/**
	 * Delete from RABC_AVG_TBL_DEF table for tracking rule.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return boolean
	 */
	protected boolean deleteAvgTblDefForTrack(Connection connection,List failureList,List args){
		boolean success = true;
		AvgTblDefDAO avgTblDefDAO = new AvgTblDefDAO();
		avgTblDefDAO.executeUpdate(connection,failureList,args,delAvgTblDefTrack);
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
	
	/**
	 * Insert into RABC_AVG_TBL_DEF table for tracking rule.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return boolean
	 */
	protected boolean insertAvgTblDefForTrack(Connection connection,List failureList,List args) {
		boolean success = true;
		AvgTblDefDAO avgTblDefDAO = new AvgTblDefDAO();
		avgTblDefDAO.executeUpdate(connection,failureList,args,insAvgTblDefTrack);
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
	
	/**
	 * Delete from RABC_MOUSE_OVER_LINK table for tracking and trending rule.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return boolean
	 */
	protected boolean deleteMouseOverLink(Connection connection,List failureList,List args){
		boolean success = true;
		MouseOverLinkDAO mouseOverLinkDAO = new MouseOverLinkDAO();
		mouseOverLinkDAO.executeUpdate(connection,failureList,args,delMouseOverLink);
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
	
	/**
	 * Insert into RABC_MOUSE_OVER_LINK table for tracking and trending rule.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return boolean
	 */
	protected boolean insertMouseOverLink(Connection connection,List failureList,List args) {
		boolean success = true;
		MouseOverLinkDAO mouseOverLinkDAO = new MouseOverLinkDAO();
		mouseOverLinkDAO.executeUpdate(connection, failureList, args, insMouseOverLink);
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
	
	/**
	 * Update RABC_ALERT_RULE_PRESN_RULE table for tracking and trending rule.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return boolean
	 */
	protected boolean updateAlertRulePresnRule(Connection connection,List failureList,List args) {
		boolean success = true;
		AlertRulePresenRuleDAO alertRulePresnRuleDAO = new AlertRulePresenRuleDAO();
		alertRulePresnRuleDAO.executeUpdate(connection,failureList,args,updAlertRulePresnRule);
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
	
	/**
	 * Update RABC_ALERT_RULE_PRESN_RULE table for report link for tracking and trending rule.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return boolean
	 */
	protected boolean updateAlertRulePresnRuleForReportLink(Connection connection,List failureList,List args) {
		boolean success = true;
		AlertRulePresenRuleDAO alertRulePresnRuleDAO = new AlertRulePresenRuleDAO();
		alertRulePresnRuleDAO.executeUpdate(connection,failureList,args,updAlertRulePresnRuleForReportLinkForPage13);
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
	
	/**
	 * Delete from RABC_WEB_DATA_LINK table for tracking and trending rule.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return boolean
	 */
	protected boolean deleteWebDataLink(Connection connection,List failureList,List args){
		boolean success = true;
		WebDataLinkDAO webDataLinkDAO = new WebDataLinkDAO();
		webDataLinkDAO.executeUpdate(connection,failureList,args,delWebDataLinkForPage13);
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
	
	/**
	 * Insert into RABC_WEB_DATA_LINK table for tracking and trending rule.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	protected boolean insertWebDataLink(Connection connection,List failureList,List args, AlertRuleDefinition alertRuleDefinition) {
		boolean success = true;
		WebDataLinkDAO webDataLinkDAO = new WebDataLinkDAO();
		webDataLinkDAO.executeUpdate(connection,failureList,args,insWebDataLinkForPage13);
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
	
	/**
	 * Method will return the format code for the calculation specified.
	 * 
	 * @param connection
	 * @param failureList
	 * @param calculationName
	 * @return String
	 */
	protected String getFormatCode(Connection connection, List failureList, String calculationName){
		String formatCode = "0";
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		List args = new ArrayList();
		args.add(calculationName);

		try {
			MessageFormat mf = new MessageFormat(getCalculationFormatCode);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			
			while(rs.next()){
				formatCode = rs.getString("PRESN_FORMAT_CODE");
				break;
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
			formatCode = "0";
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		return formatCode;
	}
	
	/**
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param alertRuleDefinition
	 * @return
	 */
	protected boolean deleteTrigConvert(Connection connection,List failureList,List args){
		boolean success = true;
		TrigConvertDAO trigConvertDAO = new TrigConvertDAO();
		
		trigConvertDAO.executeUpdate(connection,failureList,args,DEL_RABC_TRIG_CONVERT);
		
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
	
	/**
	 * Inserts data into RABC_TRIG_CONVERT table.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	protected boolean insertTrigConvert(Connection connection,List failureList,List args, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		TrigConvertDAO trigConvertDAO = new TrigConvertDAO();
		if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
			trigConvertDAO.executeUpdate(connection,failureList,args,INS_RABC_TRIG_CONVERT_Track);
		} else {
			trigConvertDAO.executeUpdate(connection,failureList,args,INS_RABC_TRIG_CONVERT_Trend);
		}
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
	
	/**
	 * Update Std Deviation to RABC_STD_CALC
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param alertRuleDefinition
	 * @return
	 */
	protected boolean updateStdDeviation(Connection connection,List failureList,List args, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		StdCalDAO stdCalDAO = new StdCalDAO();
		String selectSQL = updStdDeviation;
		stdCalDAO.executeUpdate(connection,failureList,args,selectSQL);
				
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
}
