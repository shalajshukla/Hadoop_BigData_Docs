/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.admin.alert.rule;

/**
 * This is a Data Object to represent RABC_ALERT_SUPP_RULE table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class AlertSuppRule {
	private String alertRule;
	private String alertItemName;
	private String alertItemDdlName;
	private int suppSeqNum;
	private String tblName;
	private String suppItemName;
	private String suppItemDdlName;
	private String suppPresnName;
	private String suppPicLink;

	/**
	 * @return Returns the AlertRule.
	 */
	public String getAlertRule() {
		return alertRule;
	}
	/**
	 * @return Returns the AlertItemName.
	 */
	public String getAlertItemName() {
		return alertItemName;
	}
	/**
	 * @return Returns the AlertItemDdlName.
	 */
	public String getAlertItemDdlName() {
		return alertItemDdlName;
	}
	/**
	 * @return Returns the SuppSeqNum.
	 */
	public int getSuppSeqNum() {
		return suppSeqNum;
	}
	/**
	 * @return Returns the TblName.
	 */
	public String getTblName() {
		return tblName;
	}
	/**
	 * @return Returns the SuppItemName.
	 */
	public String getSuppItemName() {
		return suppItemName;
	}
	/**
	 * @return Returns the SuppItemDdlName.
	 */
	public String getSuppItemDdlName() {
		return suppItemDdlName;
	}
	/**
	 * @return Returns the SuppPresnName.
	 */
	public String getSuppPresnName() {
		return suppPresnName;
	}
	/**
	 * @return Returns the SuppPicLink.
	 */
	public String getSuppPicLink() {
		return suppPicLink;
	}

	/**
	 * @param AlertRule The alertRule to set.
	 */
	public void setAlertRule(String alertRule) {
		this.alertRule = alertRule;
	}
	/**
	 * @param AlertItemName The alertItemName to set.
	 */
	public void setAlertItemName(String alertItemName) {
		this.alertItemName = alertItemName;
	}
	/**
	 * @param AlertItemDdlName The alertItemDdlName to set.
	 */
	public void setAlertItemDdlName(String alertItemDdlName) {
		this.alertItemDdlName = alertItemDdlName;
	}
	/**
	 * @param SuppSeqNum The suppSeqNum to set.
	 */
	public void setSuppSeqNum(int suppSeqNum) {
		this.suppSeqNum = suppSeqNum;
	}
	/**
	 * @param TblName The tblName to set.
	 */
	public void setTblName(String tblName) {
		this.tblName = tblName;
	}
	/**
	 * @param SuppItemName The suppItemName to set.
	 */
	public void setSuppItemName(String suppItemName) {
		this.suppItemName = suppItemName;
	}
	/**
	 * @param SuppItemDdlName The suppItemDdlName to set.
	 */
	public void setSuppItemDdlName(String suppItemDdlName) {
		this.suppItemDdlName = suppItemDdlName;
	}
	/**
	 * @param SuppPresnName The suppPresnName to set.
	 */
	public void setSuppPresnName(String suppPresnName) {
		this.suppPresnName = suppPresnName;
	}
	/**
	 * @param SuppPicLink The suppPicLink to set.
	 */
	public void setSuppPicLink(String suppPicLink) {
		this.suppPicLink = suppPicLink;
	}
}
