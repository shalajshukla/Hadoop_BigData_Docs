/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.ArrayList;
import java.text.MessageFormat;

import org.apache.log4j.Logger;

import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.RABCException;

/**
 * This is a DAO that performs SELECT, INSERT and UPDATE on RABC_ALERT_SUMY_PRESN table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class AlertSumyPresnDAO {
	private static final Logger logger = Logger.getLogger(AlertSumyPresnDAO.class);

	/**
	 * Returns the list of AlertSumyPresn objects.
	 * 
	 * @param conn 
	 * @param failures
	 * @param args
	 * @param baseSQL
	 * @return List
	 */
	public List get(Connection conn, List failures, List args, String baseSQL) {
		List alertSumyPresnList = null;
		AlertSumyPresn alertSumyPresn = null;
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;

		try
		{
			if (!args.isEmpty()) {
				MessageFormat mf = new MessageFormat(baseSQL);			
				sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			} else {
				sqlStmt = baseSQL;
			}
			logger.debug("AlertSumyPresnDAO - Executing SQL statement: " + sqlStmt);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			alertSumyPresnList = new ArrayList();
			while (rs.next()) {
				alertSumyPresnList.add(buildAlertSumyPresn(rs));
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return null;
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
		
		return alertSumyPresnList;
	}

	/**
	 * Private method to build AlertSumyPresn object and return it to caller.
	 * 
	 * @param rs
	 * @return AlertSumyPresn
	 * @throws SQLException
	 */
	private AlertSumyPresn buildAlertSumyPresn(ResultSet rs) throws SQLException {
		AlertSumyPresn alertSumyPresn = new AlertSumyPresn();
		
		alertSumyPresn.setSumyPresnName(rs.getString("SUMY_PRESN_NAME"));
		alertSumyPresn.setAlertRule(rs.getString("ALERT_RULE"));
		alertSumyPresn.setWebid(rs.getString("WEBID"));
		alertSumyPresn.setPresnSeqNum(rs.getInt("PRESN_SEQ_NUM"));
		alertSumyPresn.setTotInd(rs.getString("TOT_IND"));
		alertSumyPresn.setAsocPresnId(rs.getInt("ASOC_PRESN_ID"));
		return alertSumyPresn;
	}

	/**
	 * Execute the insert or update statement on RABC_ALERT_SUMY_PRESN table.
	 * 
	 * @param conn
	 * @param failures
	 * @param args
	 * @param baseSQL
	 */
	public void executeUpdate(Connection conn, List failures, List args, String baseSQL) {
		int rowsUpdated = 0;
		Statement stmt = null;
		String sqlStmt = null;
		
		try
		{
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("AlertSumyPresnDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rowsUpdated = stmt.executeUpdate(sqlStmt);
			logger.debug("SQL - Execution complete."+ String.valueOf(rowsUpdated) + "  rows updated");
			
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return;
		} finally {
			SQLHelper.closeStatement(stmt, failures, logger);
		}
	}

}
