/* Component Name: RABCPPG00521
 * Module Name: AdminAlertThresholdService.java
 * Created on October 4, 2006
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.admin.alert.thrshld;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.NamingException;

import org.apache.log4j.Logger;

import com.att.bac.rabc.ConnectionManager;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.StaticDataLoader;
import com.att.bac.rabc.admin.alert.rule.AlertRule;
import com.att.carat.util.JDBCUtil;

/**This is the facade class for the Alert Threshold process.  The purpose of this class is to handle
 * the business logic and populate the AdminAlertThresholdForm.java class with data gathered from the
 * AdminAlertThresholdDAO.java class.
 * 
 * @author js3175
 */
public class AdminAlertThresholdService {
	private static final Logger logger = Logger.getLogger(AdminAlertThresholdService.class);
	
	/**This is the method called to access the DAO for alert rule information.  This information is then 
	 * populated in a drop down menu.
	 * 
	 * @param adminAlertThresholdForm  a blank AdminAlertThresholdForm with userId & region populated
	 * @return adminAlertThresholdForm  an AdminAlertThresholdForm with data populated from the DAO
	 */
	protected static AdminAlertThresholdForm adminAlertThreshold(AdminAlertThresholdForm adminAlertThresholdForm) throws RABCException {
		logger.debug("Starting process AdminAlertThresholdService.adminAlertThreshold.");
		Connection conn = null;
		try {
			conn = ConnectionManager.getConnection(adminAlertThresholdForm.getRegion());
			adminAlertThresholdForm.setAlertRules(AdminAlertThresholdDAO.getRules(conn));
			logger.debug("Finished process AdminAlertThresholdService.adminAlertThreshold.");
		} catch (SQLException sqle) {
			throw new RABCException("SQL exception in creating a connection: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return adminAlertThresholdForm;
	}
	
	/**This is the method that processes the business rules and accesses static methods in the DAO to set up the 
	 * table of active and deactive key level thresholds.
	 * 
	 * @param adminAlertThresholdForm  a blank AdminAlertThresholdForm with userId & region populated
	 * @return adminAlertThresholdForm  an AdminAlertThresholdForm with key level data populated from the DAO
	 */
	protected static AdminAlertThresholdForm adminAlertThresholdKey(AdminAlertThresholdForm adminAlertThresholdForm) throws RABCException {
		logger.debug("Starting process AdminAlertThresholdService.adminAlertThresholdKey.");
		Connection conn = null;
		try {
			conn = ConnectionManager.getConnection(adminAlertThresholdForm.getRegion());
			adminAlertThresholdForm.setUpdatePermission(AdminAlertThresholdDAO.getPermission(conn, adminAlertThresholdForm.getUserId(), adminAlertThresholdForm.getSelectedAlertRule()));
			AlertRule alertRuleObject = AdminAlertThresholdDAO.getRuleDescription(conn, adminAlertThresholdForm.getSelectedAlertRule());
			adminAlertThresholdForm.setSelectedAlertRule(alertRuleObject.getAlertRule());
			adminAlertThresholdForm.setSelectedAlertRuleDesc(alertRuleObject.getAlertDesc());
			adminAlertThresholdForm.setAlertKeyLevel(alertRuleObject.getAlertKeyLvl());
			adminAlertThresholdForm.setDivisionKeyLevel(alertRuleObject.getDivisionNameKeyLvl());
			adminAlertThresholdForm.setSelectedAlertRuleType(alertRuleObject.getAlertRuleType());
			adminAlertThresholdForm.setSelectedAlertTimeInd(alertRuleObject.getAlertTimeInd());
			adminAlertThresholdForm.setActiveKeyData(AdminAlertThresholdDAO.getActiveKeyLevelThresholds(conn, adminAlertThresholdForm.getRegion(), adminAlertThresholdForm.getSelectedAlertRule(), adminAlertThresholdForm.getAlertKeyLevel(), adminAlertThresholdForm.getSelectedAlertTimeInd()));
			adminAlertThresholdForm.setDeactiveKeyData(AdminAlertThresholdDAO.getDeactiveKeyLevelThresholds(conn, adminAlertThresholdForm.getRegion(), adminAlertThresholdForm.getSelectedAlertRule(), adminAlertThresholdForm.getAlertKeyLevel(), adminAlertThresholdForm.getSelectedAlertTimeInd()));
			adminAlertThresholdForm.setKeyHeaders(AdminAlertThresholdDAO.getKeyLevelHeaders(conn, adminAlertThresholdForm.getAlertKeyLevel(), adminAlertThresholdForm.getSelectedAlertRule()));
			adminAlertThresholdForm.setDivisions(StaticDataLoader.getDivisionsByRegion(adminAlertThresholdForm.getRegion()));
			if (alertRuleObject.getAlertTimeInd() != null && !alertRuleObject.getAlertTimeInd().trim().equals("") && !alertRuleObject.getAlertTimeInd().trim().equals("M")) {
				if (alertRuleObject.getAlertTimeInd().trim().equals("B")) {
					adminAlertThresholdForm.setAlertTrendTimes(StaticDataLoader.getBillRndByRegion(adminAlertThresholdForm.getRegion()));
				} else if (alertRuleObject.getAlertTimeInd().trim().equals("D")) {
					adminAlertThresholdForm.setAlertTrendTimes(AdminAlertThresholdDAO.getDailyTrendTime());
				} else {
					String illegalArgumentException = "Invalid alert time indicator: " + alertRuleObject.getAlertTimeInd();
					throw new RABCException(illegalArgumentException);
				}
			}
			adminAlertThresholdForm.setDataItems(AdminAlertThresholdDAO.getAlertItem(conn, adminAlertThresholdForm.getSelectedAlertRule()));
			logger.debug("Finished process AdminAlertThresholdService.adminAlertExemptKey.");
		} catch (SQLException sqle) {
			throw new RABCException("SQL exception in creating a connection: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return adminAlertThresholdForm;
	}
	
	/**This is the method that processes the business rules and accesses static methods in the DAO to present a blank
	 * set of thresholds for a new key level so the user can enter and create them.
	 * 
	 * @param adminAlertThresholdForm  a blank AdminAlertThresholdForm with userId & region populated
	 * @return adminAlertThresholdForm  an AdminAlertThresholdForm with threshold data populated from the DAO.
	 *                                  Page will be set to create mode.
	 */
	protected static AdminAlertThresholdForm adminAlertThresholdDetailCreate(AdminAlertThresholdForm adminAlertThresholdForm) throws RABCException {
		logger.debug("Starting process AdminAlertThresholdService.adminAlertThresholdDetailCreate.");
		Connection conn = null;
		try {
			conn = ConnectionManager.getConnection(adminAlertThresholdForm.getRegion());
			adminAlertThresholdForm.setSelectedDataItem(adminAlertThresholdForm.getSelectedNewDataItem());
			adminAlertThresholdForm.setSelectedDivision(adminAlertThresholdForm.getSelectedNewDivision());
			adminAlertThresholdForm.setSelectedDivisionDesc(StaticDataLoader.getDivisionDesc(adminAlertThresholdForm.getRegion(), adminAlertThresholdForm.getSelectedDivision()));
			adminAlertThresholdForm.setSelectedKey2(adminAlertThresholdForm.getSelectedNewKey2().trim().toUpperCase());
			adminAlertThresholdForm.setSelectedKey3(adminAlertThresholdForm.getSelectedNewKey3().trim().toUpperCase());
			adminAlertThresholdForm.setSelectedKey4(adminAlertThresholdForm.getSelectedNewKey4().trim().toUpperCase());
			adminAlertThresholdForm.setSelectedKey5(adminAlertThresholdForm.getSelectedNewKey5().trim().toUpperCase());
			adminAlertThresholdForm.setSelectedTrendTime(adminAlertThresholdForm.getSelectedNewTrendTime().trim());
			adminAlertThresholdForm.setSelectedEndEffDate(adminAlertThresholdForm.getSelectedNewEndEffDate().trim());
			adminAlertThresholdForm.setKeyHeaders(AdminAlertThresholdDAO.getKeyLevelHeaders(conn, adminAlertThresholdForm.getAlertKeyLevel(), adminAlertThresholdForm.getSelectedAlertRule()));
			adminAlertThresholdForm.setLastUpdated(AdminAlertThresholdDAO.getLastUpdate(conn, adminAlertThresholdForm.getThresholdLevel(), adminAlertThresholdForm.getSelectedAlertRule(), adminAlertThresholdForm.getSelectedDataItem(), adminAlertThresholdForm.getSelectedDivision(), adminAlertThresholdForm.getSelectedKey2(), adminAlertThresholdForm.getSelectedKey3(), adminAlertThresholdForm.getSelectedKey4(), adminAlertThresholdForm.getSelectedKey5(), adminAlertThresholdForm.getSelectedTrendTime()));
			adminAlertThresholdForm.setAlertType(AdminAlertThresholdDAO.getUpdateType(conn, adminAlertThresholdForm.getSelectedAlertRule(), adminAlertThresholdForm.getSelectedDataItem()));
			if (adminAlertThresholdForm.getAlertType() == 1 || adminAlertThresholdForm.getAlertType() == 2 || adminAlertThresholdForm.getAlertType() == 4) {
				adminAlertThresholdForm.setShowHigh(1);
			}
			if (adminAlertThresholdForm.getAlertType() == 1 || adminAlertThresholdForm.getAlertType() == 3) {
				adminAlertThresholdForm.setShowLow(1);
			}
			AlertRule alertRuleObject = AdminAlertThresholdDAO.getRuleDescription(conn, adminAlertThresholdForm.getSelectedAlertRule());
			adminAlertThresholdForm.setSelectedAlertRule(alertRuleObject.getAlertRule());
			adminAlertThresholdForm.setSelectedAlertRuleDesc(alertRuleObject.getAlertDesc());
			adminAlertThresholdForm.setAlertKeyLevel(alertRuleObject.getAlertKeyLvl());
			adminAlertThresholdForm.setDivisionKeyLevel(alertRuleObject.getDivisionNameKeyLvl());
			adminAlertThresholdForm.setThresholdData(AdminAlertThresholdDAO.getAlertThresholdValues(conn, adminAlertThresholdForm.getThresholdLevel(), adminAlertThresholdForm.getSelectedAlertRule(), adminAlertThresholdForm.getSelectedDataItem(), adminAlertThresholdForm.getSelectedTrendTime(), adminAlertThresholdForm.getSelectedDivision(), adminAlertThresholdForm.getSelectedKey2(), adminAlertThresholdForm.getSelectedKey3(), adminAlertThresholdForm.getSelectedKey4(), adminAlertThresholdForm.getSelectedKey5()));
			adminAlertThresholdForm.setEditMode(adminAlertThresholdForm.getThresholdData().getEditMode());
			adminAlertThresholdForm.setRuleDefaultMode(adminAlertThresholdForm.getThresholdData().getRuleDefaultMode());
			AdminAlertThresholdDAO.getStandardDeviation(conn, adminAlertThresholdForm.getSelectedAlertRule(), adminAlertThresholdForm.getSelectedDataItem(), adminAlertThresholdForm.getSelectedDivision(), adminAlertThresholdForm.getSelectedKey2(), adminAlertThresholdForm.getSelectedKey3(), adminAlertThresholdForm.getSelectedKey4(), adminAlertThresholdForm.getSelectedKey4(), adminAlertThresholdForm.getSelectedTrendTime(), adminAlertThresholdForm.getThresholdData());
			if (alertRuleObject.getAlertTimeInd() != null && alertRuleObject.getAlertTimeInd().trim().equals("D")) {
				adminAlertThresholdForm.setSelectedTrendTimeDesc(AdminAlertThresholdDAO.getDailyTrendTime(adminAlertThresholdForm.getSelectedTrendTime()));
			}
			logger.debug("Finished process AdminAlertThresholdService.adminAlertThresholdDetailCreate.");
		} catch (SQLException sqle) {
			throw new RABCException("SQL exception in creating a connection: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return adminAlertThresholdForm;
	}
	
	/**This is the method that processes the business rules and accesses static methods in the DAO to present either
	 * the rule default or key level thresholds for an alert rule.  The user can only view those values.
	 * 
	 * @param adminAlertThresholdForm  a blank AdminAlertThresholdForm with userId & region populated
	 * @return adminAlertThresholdForm  an AdminAlertThresholdForm with threshold data populated from the DAO.
	 *                                  Page will be set to view mode.
	 */
	protected static AdminAlertThresholdForm adminAlertThresholdDetailView(AdminAlertThresholdForm adminAlertThresholdForm) throws RABCException {
		logger.debug("Starting process AdminAlertThresholdService.adminAlertThresholdDetailView.");
		Connection conn = null;
		try {
			conn = ConnectionManager.getConnection(adminAlertThresholdForm.getRegion());
			adminAlertThresholdForm.setSelectedDivisionDesc(StaticDataLoader.getDivisionDesc(adminAlertThresholdForm.getRegion(), adminAlertThresholdForm.getSelectedDivision()));
			adminAlertThresholdForm.setLastUpdated(AdminAlertThresholdDAO.getLastUpdate(conn, adminAlertThresholdForm.getThresholdLevel(), adminAlertThresholdForm.getSelectedAlertRule(), adminAlertThresholdForm.getSelectedDataItem(), adminAlertThresholdForm.getSelectedDivision(), adminAlertThresholdForm.getSelectedKey2(), adminAlertThresholdForm.getSelectedKey3(), adminAlertThresholdForm.getSelectedKey4(), adminAlertThresholdForm.getSelectedKey5(), adminAlertThresholdForm.getSelectedTrendTime()));
			adminAlertThresholdForm.setAlertType(AdminAlertThresholdDAO.getUpdateType(conn, adminAlertThresholdForm.getSelectedAlertRule(), adminAlertThresholdForm.getSelectedDataItem()));
			if (adminAlertThresholdForm.getAlertType() == 1 || adminAlertThresholdForm.getAlertType() == 2 || adminAlertThresholdForm.getAlertType() == 4) {
				adminAlertThresholdForm.setShowHigh(1);
			}
			if (adminAlertThresholdForm.getAlertType() == 1 || adminAlertThresholdForm.getAlertType() == 3) {
				adminAlertThresholdForm.setShowLow(1);
			}
			AlertRule alertRuleObject = AdminAlertThresholdDAO.getRuleDescription(conn, adminAlertThresholdForm.getSelectedAlertRule());
			adminAlertThresholdForm.setSelectedAlertRule(alertRuleObject.getAlertRule());
			adminAlertThresholdForm.setSelectedAlertRuleDesc(alertRuleObject.getAlertDesc());
			adminAlertThresholdForm.setAlertKeyLevel(alertRuleObject.getAlertKeyLvl());
			adminAlertThresholdForm.setDivisionKeyLevel(alertRuleObject.getDivisionNameKeyLvl());
			if (alertRuleObject.getAlertTimeInd() != null && alertRuleObject.getAlertTimeInd().trim().equals("D"))
				adminAlertThresholdForm.setSelectedTrendTimeDesc(AdminAlertThresholdDAO.getDailyTrendTime(adminAlertThresholdForm.getSelectedTrendTime()));
			adminAlertThresholdForm.setKeyHeaders(AdminAlertThresholdDAO.getKeyLevelHeaders(conn, adminAlertThresholdForm.getAlertKeyLevel(), adminAlertThresholdForm.getSelectedAlertRule()));
			adminAlertThresholdForm.setThresholdData(AdminAlertThresholdDAO.getAlertThresholdValues(conn, adminAlertThresholdForm.getThresholdLevel(), adminAlertThresholdForm.getSelectedAlertRule(), adminAlertThresholdForm.getSelectedDataItem(), adminAlertThresholdForm.getSelectedTrendTime(), adminAlertThresholdForm.getSelectedDivision(), adminAlertThresholdForm.getSelectedKey2(), adminAlertThresholdForm.getSelectedKey3(), adminAlertThresholdForm.getSelectedKey4(), adminAlertThresholdForm.getSelectedKey5()));
			adminAlertThresholdForm.setRuleDefaultMode(adminAlertThresholdForm.getThresholdData().getRuleDefaultMode());
			AdminAlertThresholdDAO.getStandardDeviation(conn, adminAlertThresholdForm.getSelectedAlertRule(), adminAlertThresholdForm.getSelectedDataItem(), adminAlertThresholdForm.getSelectedDivision(), adminAlertThresholdForm.getSelectedKey2(), adminAlertThresholdForm.getSelectedKey3(), adminAlertThresholdForm.getSelectedKey4(), adminAlertThresholdForm.getSelectedKey4(), adminAlertThresholdForm.getSelectedTrendTime(), adminAlertThresholdForm.getThresholdData());
			adminAlertThresholdForm.setEditMode(2);
			logger.debug("Finished process AdminAlertThresholdService.adminAlertThresholdDetailView.");
		} catch (SQLException sqle) {
			throw new RABCException("SQL exception in creating a connection: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return adminAlertThresholdForm;
	}
	
	/**This is the method that processes the business rules and accesses static methods in the DAO to present either
	 * the rule default or key level thresholds for an alert rule.  These threshold values will appear in a pop-up
	 * window accessed from page 11.  The user can only view those values.
	 * 
	 * @param adminAlertThresholdForm  a blank AdminAlertThresholdForm with userId & region populated
	 * @return adminAlertThresholdForm  an AdminAlertThresholdForm with threshold data populated from the DAO.
	 *                                  Pop-up page will be set to view mode.
	 */
	protected static AdminAlertThresholdForm adminAlertThresholdDetailPopup(AdminAlertThresholdForm adminAlertThresholdForm) throws RABCException {
		logger.debug("Starting process AdminAlertThresholdService.adminAlertThresholdDetailPopup.");
		Connection conn = null;
		try {
			conn = ConnectionManager.getConnection(adminAlertThresholdForm.getRegion());
			adminAlertThresholdForm.setSelectedDivisionDesc(StaticDataLoader.getDivisionDesc(adminAlertThresholdForm.getRegion(), adminAlertThresholdForm.getSelectedDivision()));
			adminAlertThresholdForm.setAlertType(AdminAlertThresholdDAO.getUpdateType(conn, adminAlertThresholdForm.getSelectedAlertRule(), adminAlertThresholdForm.getSelectedDataItem()));
			if (adminAlertThresholdForm.getAlertType() == 1 || adminAlertThresholdForm.getAlertType() == 2 || adminAlertThresholdForm.getAlertType() == 4) {
				adminAlertThresholdForm.setShowHigh(1);
			}
			if (adminAlertThresholdForm.getAlertType() == 1 || adminAlertThresholdForm.getAlertType() == 3) {
				adminAlertThresholdForm.setShowLow(1);
			}
			AlertRule alertRuleObject = AdminAlertThresholdDAO.getRuleDescription(conn, adminAlertThresholdForm.getSelectedAlertRule());
			adminAlertThresholdForm.setSelectedAlertRule(alertRuleObject.getAlertRule());
			adminAlertThresholdForm.setSelectedAlertRuleDesc(alertRuleObject.getAlertDesc());
			adminAlertThresholdForm.setAlertKeyLevel(alertRuleObject.getAlertKeyLvl());
			adminAlertThresholdForm.setDivisionKeyLevel(alertRuleObject.getDivisionNameKeyLvl());
			adminAlertThresholdForm.setSelectedAlertRuleType(alertRuleObject.getAlertRuleType());
			adminAlertThresholdForm.setSelectedAlertTimeInd(alertRuleObject.getAlertTimeInd());
			adminAlertThresholdForm.setThresholdLevel(AdminAlertThresholdForm.KEY_LEVEL);
			adminAlertThresholdForm.setKeyHeaders(AdminAlertThresholdDAO.getKeyLevelHeaders(conn, adminAlertThresholdForm.getAlertKeyLevel(), adminAlertThresholdForm.getSelectedAlertRule()));
			adminAlertThresholdForm.setThresholdData(AdminAlertThresholdDAO.getPopUpThresholdValues(conn, adminAlertThresholdForm.getThresholdLevel(), adminAlertThresholdForm.getSelectedAlertRule(), adminAlertThresholdForm.getSelectedDataItem(), adminAlertThresholdForm.getSelectedTrendTime(), adminAlertThresholdForm.getSelectedDivision(), adminAlertThresholdForm.getSelectedKey2(), adminAlertThresholdForm.getSelectedKey3(), adminAlertThresholdForm.getSelectedKey4(), adminAlertThresholdForm.getSelectedKey5(), adminAlertThresholdForm.getSelectedProcDate()));
			adminAlertThresholdForm.setLastUpdated(adminAlertThresholdForm.getThresholdData().getLastUpdatedDate());
			adminAlertThresholdForm.setRuleDefaultMode(adminAlertThresholdForm.getThresholdData().getRuleDefaultMode());
			adminAlertThresholdForm.setThresholdLevel(adminAlertThresholdForm.getThresholdData().getThresholdLevel());
			AdminAlertThresholdDAO.getPopUpStandardDeviation(conn, adminAlertThresholdForm.getSelectedAlertRule(), adminAlertThresholdForm.getSelectedDataItem(), adminAlertThresholdForm.getSelectedDivision(), adminAlertThresholdForm.getSelectedKey2(), adminAlertThresholdForm.getSelectedKey3(), adminAlertThresholdForm.getSelectedKey4(), adminAlertThresholdForm.getSelectedKey5(), adminAlertThresholdForm.getSelectedTrendTime(), adminAlertThresholdForm.getThresholdData(), adminAlertThresholdForm.getSelectedProcDate());
			adminAlertThresholdForm.setThresholdFound(adminAlertThresholdForm.getThresholdData().getThresholdFound());
			adminAlertThresholdForm.setEditMode(2);
			logger.debug("Finished process AdminAlertThresholdService.adminAlertThresholdDetailPopup.");
		} catch (SQLException sqle) {
			throw new RABCException("SQL exception in creating a connection: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return adminAlertThresholdForm;
	}
	
	/**This is the method that processes the business rules and accesses static methods in the DAO to present the
	 * key level data for a row from the key level page that is being end dated.  This information goes to a confirm
	 * page.
	 * 
	 * @param adminAlertThresholdForm  a blank AdminAlertThresholdForm with userId & region populated
	 * @return adminAlertThresholdForm  an AdminAlertThresholdForm with key level data populated from the DAO.
	 *                                  Information will be sent to a confirm page.
	 */
	protected static AdminAlertThresholdForm adminAlertThresholdDetailDelete(AdminAlertThresholdForm adminAlertThresholdForm) throws RABCException {
		logger.debug("Starting process AdminAlertThresholdService.adminAlertThresholdDetailDelete.");
		Connection conn = null;
		try {
			conn = ConnectionManager.getConnection(adminAlertThresholdForm.getRegion());
			AlertRule alertRuleObject = AdminAlertThresholdDAO.getRuleDescription(conn, adminAlertThresholdForm.getSelectedAlertRule());
			adminAlertThresholdForm.setSelectedAlertRule(alertRuleObject.getAlertRule());
			adminAlertThresholdForm.setAlertKeyLevel(alertRuleObject.getAlertKeyLvl());
			adminAlertThresholdForm.setDivisionKeyLevel(alertRuleObject.getDivisionNameKeyLvl());
			adminAlertThresholdForm.setSelectedAlertRuleType(alertRuleObject.getAlertRuleType());
			adminAlertThresholdForm.setSelectedAlertTimeInd(alertRuleObject.getAlertTimeInd());
			adminAlertThresholdForm.setSelectedDivisionDesc(StaticDataLoader.getDivisionDesc(adminAlertThresholdForm.getRegion(), adminAlertThresholdForm.getSelectedDivision()));
			adminAlertThresholdForm.setKeyHeaders(AdminAlertThresholdDAO.getKeyLevelHeaders(conn, adminAlertThresholdForm.getAlertKeyLevel(), adminAlertThresholdForm.getSelectedAlertRule()));
			logger.debug("Finished process AdminAlertThresholdService.adminAlertThresholdDetailDelete.");
		} catch (SQLException sqle) {
			throw new RABCException("SQL exception in creating a connection: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return adminAlertThresholdForm;
	}
	
	/**This is the method that processes the business rules and accesses static methods in the DAO to present the
	 * rule default thresholds for an alert rule.  The user can then update those values.
	 * 
	 * @param adminAlertThresholdForm  a blank AdminAlertThresholdForm with userId & region populated
	 * @return adminAlertThresholdForm  an AdminAlertThresholdForm with threshold data populated from the DAO.
	 *                                  Page will be set to update mode.
	 */
	protected static AdminAlertThresholdForm adminAlertThresholdDetailDefault(AdminAlertThresholdForm adminAlertThresholdForm) throws RABCException {
		logger.debug("Starting process AdminAlertThresholdService.adminAlertThresholdDetailDefault.");
		Connection conn = null;
		try {
			conn = ConnectionManager.getConnection(adminAlertThresholdForm.getRegion());
			adminAlertThresholdForm.setUpdatePermission(AdminAlertThresholdDAO.getPermission(conn, adminAlertThresholdForm.getUserId(), adminAlertThresholdForm.getSelectedAlertRule()));
			adminAlertThresholdForm.setSelectedDivisionDesc(StaticDataLoader.getDivisionDesc(adminAlertThresholdForm.getRegion(), adminAlertThresholdForm.getSelectedDivision()));
			adminAlertThresholdForm.setLastUpdated(AdminAlertThresholdDAO.getLastUpdate(conn, adminAlertThresholdForm.getThresholdLevel(), adminAlertThresholdForm.getSelectedAlertRule(), adminAlertThresholdForm.getSelectedDataItem(), adminAlertThresholdForm.getSelectedDivision(), adminAlertThresholdForm.getSelectedKey2(), adminAlertThresholdForm.getSelectedKey3(), adminAlertThresholdForm.getSelectedKey4(), adminAlertThresholdForm.getSelectedKey5(), adminAlertThresholdForm.getSelectedTrendTime()));
			adminAlertThresholdForm.setAlertType(AdminAlertThresholdDAO.getUpdateType(conn, adminAlertThresholdForm.getSelectedAlertRule(), adminAlertThresholdForm.getSelectedDataItem()));
			if (adminAlertThresholdForm.getAlertType() == 1 || adminAlertThresholdForm.getAlertType() == 2 || adminAlertThresholdForm.getAlertType() == 4) {
				adminAlertThresholdForm.setShowHigh(1);
			}
			if (adminAlertThresholdForm.getAlertType() == 1 || adminAlertThresholdForm.getAlertType() == 3) {
				adminAlertThresholdForm.setShowLow(1);
			}
			AlertRule alertRuleObject = AdminAlertThresholdDAO.getRuleDescription(conn, adminAlertThresholdForm.getSelectedAlertRule());
			adminAlertThresholdForm.setSelectedAlertRule(alertRuleObject.getAlertRule());
			adminAlertThresholdForm.setSelectedAlertRuleDesc(alertRuleObject.getAlertDesc());
			adminAlertThresholdForm.setAlertKeyLevel(alertRuleObject.getAlertKeyLvl());
			adminAlertThresholdForm.setSelectedAlertRuleType(alertRuleObject.getAlertRuleType());
			adminAlertThresholdForm.setDivisionKeyLevel(alertRuleObject.getDivisionNameKeyLvl());
			adminAlertThresholdForm.setThresholdData(AdminAlertThresholdDAO.getAlertThresholdValues(conn, adminAlertThresholdForm.getThresholdLevel(), adminAlertThresholdForm.getSelectedAlertRule(), adminAlertThresholdForm.getSelectedDataItem(), adminAlertThresholdForm.getSelectedTrendTime(), adminAlertThresholdForm.getSelectedDivision(), adminAlertThresholdForm.getSelectedKey2(), adminAlertThresholdForm.getSelectedKey3(), adminAlertThresholdForm.getSelectedKey4(), adminAlertThresholdForm.getSelectedKey5()));
			AdminAlertThresholdDAO.getStandardDeviation(conn, adminAlertThresholdForm.getSelectedAlertRule(), adminAlertThresholdForm.getSelectedDataItem(), adminAlertThresholdForm.getSelectedDivision(), adminAlertThresholdForm.getSelectedKey2(), adminAlertThresholdForm.getSelectedKey3(), adminAlertThresholdForm.getSelectedKey4(), adminAlertThresholdForm.getSelectedKey4(), adminAlertThresholdForm.getSelectedTrendTime(), adminAlertThresholdForm.getThresholdData());
			adminAlertThresholdForm.setEditMode(adminAlertThresholdForm.getThresholdData().getEditMode());
			adminAlertThresholdForm.setRuleDefaultMode(adminAlertThresholdForm.getThresholdData().getRuleDefaultMode());
			logger.debug("Finished process AdminAlertThresholdService.adminAlertThresholdDetailDefault.");
		} catch (SQLException sqle) {
			throw new RABCException("SQL exception in creating a connection: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return adminAlertThresholdForm;
	}
	
	/**This is the method called to insert thresholds into RABC_ALERT_THRSHLD via the DAO then access the DAO 
	 * for alert rule information.  This information is then populated in a drop down menu on the main threshold
	 * page.
	 * 
	 * @param adminAlertThresholdForm  a blank AdminAlertThresholdForm with userId & region populated
	 * @return adminAlertThresholdForm  an AdminAlertThresholdForm with data populated from the DAO
	 */
	protected static AdminAlertThresholdForm adminAlertThresholdInsert(AdminAlertThresholdForm adminAlertThresholdForm) throws RABCException {
		logger.debug("Starting process AdminAlertThresholdService.adminAlertThresholdInsert.");
		Connection conn = null;
		try {
			conn = ConnectionManager.getConnection(adminAlertThresholdForm.getRegion());
			AdminAlertThresholdDAO.insertAlertThresholdValues(conn, adminAlertThresholdForm.getThresholdLevel(), adminAlertThresholdForm.getSelectedAlertRule(), adminAlertThresholdForm.getAlertType(), adminAlertThresholdForm.getSelectedDataItem(), adminAlertThresholdForm.getSelectedTrendTime(), adminAlertThresholdForm.getSelectedDivision(), adminAlertThresholdForm.getSelectedKey2(), adminAlertThresholdForm.getSelectedKey3(), adminAlertThresholdForm.getSelectedKey4(), adminAlertThresholdForm.getSelectedKey5(), adminAlertThresholdForm.getUserId(), adminAlertThresholdForm.getSelectedEndEffDate(), adminAlertThresholdForm.getThresholdData().getStandardHigh(), adminAlertThresholdForm.getThresholdData().getStandardMedium(), adminAlertThresholdForm.getThresholdData().getStandardLow(), adminAlertThresholdForm.getThresholdData().getHighRangeHigh(), adminAlertThresholdForm.getThresholdData().getHighRangeMedium(), adminAlertThresholdForm.getThresholdData().getHighRangeLow(), adminAlertThresholdForm.getThresholdData().getLowRangeHigh(), adminAlertThresholdForm.getThresholdData().getLowRangeMedium(), adminAlertThresholdForm.getThresholdData().getLowRangeLow(), adminAlertThresholdForm.getThresholdData().getAlertMinHigh(), adminAlertThresholdForm.getThresholdData().getAlertMinMedium(), adminAlertThresholdForm.getThresholdData().getAlertMinLow());
			conn.commit();
			adminAlertThresholdForm.setAlertRules(AdminAlertThresholdDAO.getRules(conn));
			logger.debug("Finished process AdminAlertThresholdService.adminAlertThresholdInsert.");
		} catch (SQLException sqle) {
			throw new RABCException("SQL exception in creating a connection or committing changes: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return adminAlertThresholdForm;
	}
	
	/**This is the method called to update rule default thresholds only in RABC_ALERT_THRSHLD via the DAO then 
	 * access the DAO for alert rule information.  This information is then populated in a drop down menu on 
	 * the main threshold page.
	 * 
	 * @param adminAlertThresholdForm  a blank AdminAlertThresholdForm with userId & region populated
	 * @return adminAlertThresholdForm  an AdminAlertThresholdForm with data populated from the DAO
	 */
	protected static AdminAlertThresholdForm adminAlertThresholdUpdate(AdminAlertThresholdForm adminAlertThresholdForm) throws RABCException {
		logger.debug("Starting process AdminAlertThresholdService.adminAlertThresholdUpdate.");
		Connection conn = null;
		try {
			conn = ConnectionManager.getConnection(adminAlertThresholdForm.getRegion());
			AdminAlertThresholdDAO.updateAlertThresholdValues(conn, adminAlertThresholdForm.getSelectedAlertRule(), adminAlertThresholdForm.getAlertType(), adminAlertThresholdForm.getUserId(), adminAlertThresholdForm.getThresholdData().getStandardHigh(), adminAlertThresholdForm.getThresholdData().getStandardMedium(), adminAlertThresholdForm.getThresholdData().getStandardLow(), adminAlertThresholdForm.getThresholdData().getHighRangeHigh(), adminAlertThresholdForm.getThresholdData().getHighRangeMedium(), adminAlertThresholdForm.getThresholdData().getHighRangeLow(), adminAlertThresholdForm.getThresholdData().getLowRangeHigh(), adminAlertThresholdForm.getThresholdData().getLowRangeMedium(), adminAlertThresholdForm.getThresholdData().getLowRangeLow(), adminAlertThresholdForm.getThresholdData().getAlertMinHigh(), adminAlertThresholdForm.getThresholdData().getAlertMinMedium(), adminAlertThresholdForm.getThresholdData().getAlertMinLow());
			conn.commit();
			adminAlertThresholdForm.setAlertRules(AdminAlertThresholdDAO.getRules(conn));
			logger.debug("Finished process AdminAlertThresholdService.adminAlertThresholdUpdate.");
		} catch (SQLException sqle) {
			throw new RABCException("SQL exception in creating a connection or committing changes: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return adminAlertThresholdForm;
	}
	
	/**This is the method called to end date key level thresholds only in RABC_ALERT_THRSHLD via the DAO then 
	 * access the DAO for alert rule information.  This information is then populated in a drop down menu on 
	 * the main threshold page.
	 * 
	 * @param adminAlertThresholdForm  a blank AdminAlertThresholdForm with userId & region populated
	 * @return adminAlertThresholdForm  an AdminAlertThresholdForm with data populated from the DAO
	 */
	protected static AdminAlertThresholdForm adminAlertThresholdDelete(AdminAlertThresholdForm adminAlertThresholdForm) throws RABCException {
		logger.debug("Starting process AdminAlertThresholdService.adminAlertThresholdDelete.");
		Connection conn = null;
		try {
			conn = ConnectionManager.getConnection(adminAlertThresholdForm.getRegion());
			AdminAlertThresholdDAO.deleteAlertThresholdValues(conn, adminAlertThresholdForm.getSelectedAlertRule(), adminAlertThresholdForm.getSelectedDataItem(), adminAlertThresholdForm.getSelectedDivision(), adminAlertThresholdForm.getSelectedKey2(), adminAlertThresholdForm.getSelectedKey3(), adminAlertThresholdForm.getSelectedKey4(), adminAlertThresholdForm.getSelectedKey5(), adminAlertThresholdForm.getSelectedTrendTime(), adminAlertThresholdForm.getSelectedEndEffDate(), adminAlertThresholdForm.getUserId());
			conn.commit();
			adminAlertThresholdForm.setAlertRules(AdminAlertThresholdDAO.getRules(conn));
			logger.debug("Finished process AdminAlertThresholdService.adminAlertThresholdDelete.");
		} catch (SQLException sqle) {
			throw new RABCException("SQL exception in creating a connection or committing changes: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return adminAlertThresholdForm;
	}
}
