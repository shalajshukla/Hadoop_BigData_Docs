/* 
 * Created by GB0741 on 05-Nov-07
 * Copyright 2007 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.load.calnet.telcoacus;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Properties;
//changes done for M168 by as635b
//import com.sbc.bac.load.DBLoadJob;
//import com.sbc.bac.load.Application;
import com.att.carat.load.Application;
import com.att.carat.load.DBLoadJob;

/**
 * This component controls the selection and insertion of cris acus discrepancy data. Methods from CrisAcusDAO 
 * are called for this operation.
 */
public class CrisAcusLoadJob extends DBLoadJob {
	
	private String time = null;
	private String acusDays = null;
	private String crisFromDays = null;
	private String crisToDays = null;
	protected Calendar runTime = Calendar.getInstance();

	protected boolean configure(Application application, Properties configuration) {
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
		boolean success = super.configure(application, configuration);

		if (success){
			// get parameters' values from configuration file CrisAcus.cfg
			time		 = configuration.getProperty("runtime");
			acusDays 	 = configuration.getProperty("acus_days");
			crisFromDays = configuration.getProperty("cris_from_days");
			crisToDays 	 = configuration.getProperty("cris_to_days");

			if (time == null){ 
				severe("Please specify runtimein CrisAcus.cfg");
				return false;
			}
			
			if (acusDays == null){ 
				severe("Please specify acus_days in CrisAcus.cfg");
				return false;
			}

			if (crisFromDays == null){ 
				severe("Please specify cris_from_days in CrisAcus.cfg");
				return false;
			}
			
			if (crisToDays == null){ 
				severe("Please specify cris_to_days in CrisAcus.cfg");
				return false;
			}

			// sets current time
			try {
				runTime.setTime(sdf.parse(time));
			} catch (ParseException pe) {
				severe("Runtime entry could not be parsed: ", pe);
				return false;
			}

			Calendar now = Calendar.getInstance();
			
			// sets current date in runtime
			runTime.set(Calendar.DATE, now.get(Calendar.DATE));
			runTime.set(Calendar.YEAR, now.get(Calendar.YEAR));
			runTime.set(Calendar.MONTH, now.get(Calendar.MONTH));

			//increments runtime by one day if it has already elapsed 
			if(now.after(runTime)){
				runTime.add(Calendar.DATE, 1);
			}
			info("CrisAcus Load Job is scheduled to run on "
			        + new java.util.Date(this.runTime.getTimeInMillis()));
		}
		return success;
	}
	
	/* (non-Javadoc)
	 * @see com.sbc.bac.load.LoadJob#check()
	 */
	protected boolean check() {
		return Calendar.getInstance().after(runTime);
	}

	/**
	 * This method calls DAO to insert bill amount and btn discrepancy records in database
	 * table RABC_CRIS_ACUS_DSCRPNCY
	 * 
	 */
	public boolean action() {
		boolean success = false;
		CrisAcusDAO dao = new CrisAcusDAO();
		
			try {
				// Insert the records into the table.
				success = dao.populateBillAmtRecords(connection, acusDays);
				success = dao.populateBtnRecords(connection, acusDays, crisFromDays, crisToDays);
				info("success: " + success);
			}
			catch (Exception exc) {
				severe("Error Inserting records into database" + exc.getMessage(), exc);
				success = false;
			}
		return success;
	}
	
	/**
	 * Schedules the job to run daily
	 * */
	protected boolean postprocess(boolean success) {
		//Update day to run the job daily
		if(success){	
			runTime.add(Calendar.DATE, 1);
			info("CrisAcus Load Job is scheduled to again on "
			        + new java.util.Date(this.runTime.getTimeInMillis()));
		}
		
		return super.postprocess(success);
	}
}
