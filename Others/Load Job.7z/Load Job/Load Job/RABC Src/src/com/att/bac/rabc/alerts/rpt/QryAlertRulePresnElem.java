/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.rpt;

/**
 * This class represents the data object that holds the attributes required
 * for QryAlertRulePresnElem query used in Alert Rule Report page 12.
 * Updated jh9518 8/22/2008 added dataStatNum...
 *  
 * @author Nalina Pandiyan - NP5434
 */
public class QryAlertRulePresnElem {
	private int presnId;
	private int partiRefId;
	private String presnName;
	private int presnSeqNum;
	private int sumyPresnSeqNum;
	private String dataTbl;
	private String dataDdlName;
	private String presnElemTotInd;
	private String presnUnitInd;
	private String presnSumInd;
	private String tblProcDateDdlName;
	private String blinkTblKeyName;
	private String clinkTblKeyName;
	private String dlinkDdlName;
	private String elinkDdlName;
	private int headerLinkNum;
	private int headerMouseOverNum;
	private int dataLinkNum;
	private int dataMouseOverNum;
	private String graphPresnInd;
	private int execPresnSeqNum;
	private int dataKeyLvl;
	private String[] keyDdlName = {"","","","",""};
	private String[] keyHeader = {"","","","",""};
	private String[] keyHdLinkInd = {"","","","",""};
	private int[] keyHdLinkNum = {0,0,0,0,0};
	private String[] keyHdParmInd = {"","","","",""};
	private String[] keyDataLinkInd = {"","","","",""};
	private int[] keyDataLinkNum = {0,0,0,0,0};
	private String[] keyDescInd = {"","","","",""};
	private int[] keyMouseOverNum = {0,0,0,0,0};
	private int seqCnt;
	private String dataLinkToPgm;
	private String presnIdDesc;


	/**
	 * @return Returns the blinkTblKeyName.
	 */
	public String getBlinkTblKeyName() {
		return blinkTblKeyName;
	}

	/**
	 * @param blinkTblKeyName The blinkTblKeyName to set.
	 */
	public void setBlinkTblKeyName(String blinkTblKeyName) {
		this.blinkTblKeyName = blinkTblKeyName;
	}

	/**
	 * @return Returns the clinkTblKeyName.
	 */
	public String getClinkTblKeyName() {
		return clinkTblKeyName;
	}

	/**
	 * @param clinkTblKeyName The clinkTblKeyName to set.
	 */
	public void setClinkTblKeyName(String clinkTblKeyName) {
		this.clinkTblKeyName = clinkTblKeyName;
	}

	/**
	 * @return Returns the dataDdlName.
	 */
	public String getDataDdlName() {
		return dataDdlName;
	}

	/**
	 * @param dataDdlName The dataDdlName to set.
	 */
	public void setDataDdlName(String dataDdlName) {
		this.dataDdlName = dataDdlName;
	}

	/**
	 * @return Returns the dataKeyLvl.
	 */
	public int getDataKeyLvl() {
		return dataKeyLvl;
	}

	/**
	 * @param dataKeyLvl The dataKeyLvl to set.
	 */
	public void setDataKeyLvl(int dataKeyLvl) {
		this.dataKeyLvl = dataKeyLvl;
	}

	/**
	 * @return Returns the dataLinkNum.
	 */
	public int getDataLinkNum() {
		return dataLinkNum;
	}

	/**
	 * @param dataLinkNum The dataLinkNum to set.
	 */
	public void setDataLinkNum(int dataLinkNum) {
		this.dataLinkNum = dataLinkNum;
	}

	/**
	 * @return Returns the dataLinkToPgm.
	 */
	public String getDataLinkToPgm() {
		return dataLinkToPgm;
	}

	/**
	 * @param dataLinkToPgm The dataLinkToPgm to set.
	 */
	public void setDataLinkToPgm(String dataLinkToPgm) {
		this.dataLinkToPgm = dataLinkToPgm;
	}

	/**
	 * @return Returns the dataMouseOverNum.
	 */
	public int getDataMouseOverNum() {
		return dataMouseOverNum;
	}

	/**
	 * @param dataMouseOverNum The dataMouseOverNum to set.
	 */
	public void setDataMouseOverNum(int dataMouseOverNum) {
		this.dataMouseOverNum = dataMouseOverNum;
	}

	/**
	 * @return Returns the dataTbl.
	 */
	public String getDataTbl() {
		return dataTbl;
	}

	/**
	 * @param dataTbl The dataTbl to set.
	 */
	public void setDataTbl(String dataTbl) {
		this.dataTbl = dataTbl;
	}

	/**
	 * @return Returns the dlinkDdlName.
	 */
	public String getDlinkDdlName() {
		return dlinkDdlName;
	}

	/**
	 * @param dlinkDdlName The dlinkDdlName to set.
	 */
	public void setDlinkDdlName(String dlinkDdlName) {
		this.dlinkDdlName = dlinkDdlName;
	}

	/**
	 * @return Returns the elinkDdlName.
	 */
	public String getElinkDdlName() {
		return elinkDdlName;
	}

	/**
	 * @param elinkDdlName The elinkDdlName to set.
	 */
	public void setElinkDdlName(String elinkDdlName) {
		this.elinkDdlName = elinkDdlName;
	}

	/**
	 * @return Returns the execPresnSeqNum.
	 */
	public int getExecPresnSeqNum() {
		return execPresnSeqNum;
	}

	/**
	 * @param execPresnSeqNum The execPresnSeqNum to set.
	 */
	public void setExecPresnSeqNum(int execPresnSeqNum) {
		this.execPresnSeqNum = execPresnSeqNum;
	}

	/**
	 * @return Returns the graphPresnInd.
	 */
	public String getGraphPresnInd() {
		return graphPresnInd;
	}

	/**
	 * @param graphPresnInd The graphPresnInd to set.
	 */
	public void setGraphPresnInd(String graphPresnInd) {
		this.graphPresnInd = graphPresnInd;
	}

	/**
	 * @return Returns the headerLinkNum.
	 */
	public int getHeaderLinkNum() {
		return headerLinkNum;
	}

	/**
	 * @param headerLinkNum The headerLinkNum to set.
	 */
	public void setHeaderLinkNum(int headerLinkNum) {
		this.headerLinkNum = headerLinkNum;
	}

	/**
	 * @return Returns the headerMouseOverNum.
	 */
	public int getHeaderMouseOverNum() {
		return headerMouseOverNum;
	}

	/**
	 * @param headerMouseOverNum The headerMouseOverNum to set.
	 */
	public void setHeaderMouseOverNum(int headerMouseOverNum) {
		this.headerMouseOverNum = headerMouseOverNum;
	}

	/**
	 * @return Returns the partiRefId.
	 */
	public int getPartiRefId() {
		return partiRefId;
	}

	/**
	 * @param partiRefId The partiRefId to set.
	 */
	public void setPartiRefId(int partiRefId) {
		this.partiRefId = partiRefId;
	}

	/**
	 * @return Returns the presn_seqNum.
	 */
	public int getPresnSeqNum() {
		return presnSeqNum;
	}

	/**
	 * @param presn_seqNum The presn_seqNum to set.
	 */
	public void setPresnSeqNum(int presnSeqNum) {
		this.presnSeqNum = presnSeqNum;
	}

	/**
	 * @return Returns the presnElemTotInd.
	 */
	public String getPresnElemTotInd() {
		return presnElemTotInd;
	}

	/**
	 * @param presnElemTotInd The presnElemTotInd to set.
	 */
	public void setPresnElemTotInd(String presnElemTotInd) {
		this.presnElemTotInd = presnElemTotInd;
	}

	/**
	 * @return Returns the presnId.
	 */
	public int getPresnId() {
		return presnId;
	}

	/**
	 * @param presnId The presnId to set.
	 */
	public void setPresnId(int presnId) {
		this.presnId = presnId;
	}

	/**
	 * @return Returns the presnIdDesc.
	 */
	public String getPresnIdDesc() {
		return presnIdDesc;
	}

	/**
	 * @param presnIdDesc The presnIdDesc to set.
	 */
	public void setPresnIdDesc(String presnIdDesc) {
		this.presnIdDesc = presnIdDesc;
	}

	/**
	 * @return Returns the presnName.
	 */
	public String getPresnName() {
		return presnName;
	}

	/**
	 * @param presnName The presnName to set.
	 */
	public void setPresnName(String presnName) {
		this.presnName = presnName;
	}

	/**
	 * @return Returns the presnSumInd.
	 */
	public String getPresnSumInd() {
		return presnSumInd;
	}

	/**
	 * @param presnSumInd The presnSumInd to set.
	 */
	public void setPresnSumInd(String presnSumInd) {
		this.presnSumInd = presnSumInd;
	}

	/**
	 * @return Returns the presnUnitInd.
	 */
	public String getPresnUnitInd() {
		return presnUnitInd;
	}

	/**
	 * @param presnUnitInd The presnUnitInd to set.
	 */
	public void setPresnUnitInd(String presnUnitInd) {
		this.presnUnitInd = presnUnitInd;
	}

	/**
	 * @return Returns the seqCnt.
	 */
	public int getSeqCnt() {
		return seqCnt;
	}

	/**
	 * @param seqCnt The seqCnt to set.
	 */
	public void setSeqCnt(int seqCnt) {
		this.seqCnt = seqCnt;
	}

	/**
	 * @return Returns the sumy_presnSeqNum.
	 */
	public int getSumyPresnSeqNum() {
		return sumyPresnSeqNum;
	}

	/**
	 * @param sumy_presnSeqNum The sumy_presnSeqNum to set.
	 */
	public void setSumyPresnSeqNum(int sumyPresnSeqNum) {
		this.sumyPresnSeqNum = sumyPresnSeqNum;
	}

	/**
	 * @return Returns the tblProcDateDdlName.
	 */
	public String getTblProcDateDdlName() {
		return tblProcDateDdlName;
	}

	/**
	 * @param tblProcDateDdlName The tblProcDateDdlName to set.
	 */
	public void setTblProcDateDdlName(String tblProcDateDdlName) {
		this.tblProcDateDdlName = tblProcDateDdlName;
	}
	
	/**
	 * @return Returns the keyDdlName.
	 */
	public String getKeyDdlNameAt(int i) {
		return this.keyDdlName[i];
	}
	
	/**
	 * @param keyDdlName The keyDdlName to set.
	 */
	public void setKeyDdlNameAt(int i, String s) {
		this.keyDdlName[i] = s;
	}
	
	/**
	 * @return Returns the keyHeader.
	 */
	public String getKeyHeaderAt(int i) {
		return this.keyHeader[i];
	}
	
	/**
	 * @param keyHeader The keyHeader to set.
	 */
	public void setKeyHeaderAt(int i, String s) {
		this.keyHeader[i] = s;
	}
	
	/**
	 * @return Returns the keyHdLinkInd.
	 */
	public String getKeyHdLinkIndAt(int i) {
		return this.keyHdLinkInd[i];
	}
	
	/**
	 * @param keyHdLinkInd The keyHdLinkInd to set.
	 */
	public void setKeyHdLinkIndAt(int i, String s) {
		this.keyHdLinkInd[i] = s;
	}
	
	/**
	 * @return Returns the keyHdParmInd.
	 */
	public String getKeyHdParmIndAt(int i) {
		return this.keyHdParmInd[i];
	}
	
	/**
	 * @param keyHdParmInd The keyHdParmInd to set.
	 */
	public void setKeyHdParmIndAt(int i, String s) {
		this.keyHdParmInd[i] = s;
	}
	
	/**
	 * @return Returns the keyDataLinkInd.
	 */
	public String getKeyDataLinkIndAt(int i) {
		return this.keyDataLinkInd[i];
	}
	
	/**
	 * @param keyDataLinkInd The keyDataLinkInd to set.
	 */
	public void setKeyDataLinkIndAt(int i, String s) {
		this.keyDataLinkInd[i] = s;
	}
	
	/**
	 * @return Returns the keyDescInd.
	 */
	public String getKeyDescIndAt(int i) {
		return this.keyDescInd[i];
	}
	
	/**
	 * @param keyDescInd The keyDescInd to set.
	 */
	public void setKeyDescIndAt(int i, String s) {
		this.keyDescInd[i] = s;
	}
	
	/**
	 * @return Returns the keyHdLinkNum.
	 */
	public int getKeyHdLinkNumAt(int i) {
		return this.keyHdLinkNum[i];
	}
	
	/**
	 * @param keyHdLinkNum The keyHdLinkNum to set.
	 */
	public void setKeyHdLinkNumAt(int i, int v) {
		this.keyHdLinkNum[i] = v;
	}
	
	/**
	 * @return Returns the keyDataLinkNum.
	 */
	public int getKeyDataLinkNumAt(int i) {
		return this.keyDataLinkNum[i];
	}
	
	/**
	 * @param keyDataLinkNum The keyDataLinkNum to set.
	 */
	public void setKeyDataLinkNumAt(int i, int v) {
		this.keyDataLinkNum[i] = v;
	}
	
	/**
	 * @return Returns the keyMouseOverNum.
	 */
	public int getKeyMouseOverNumAt(int i) {
		return this.keyMouseOverNum[i];
	}
	
	/**
	 * @param keyMouseOverNum The keyMouseOverNum to set.
	 */
	public void setKeyMouseOverNumAt(int i, int v) {
		this.keyMouseOverNum[i] = v;
	}
	
	
}
