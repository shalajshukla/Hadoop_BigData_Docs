/*
 * Copyright  2002-2007 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.adhoc.aria.pivot;

import java.io.IOException;
import java.io.OutputStream;

import com.sbc.bac.aria.ARIAHTMLReportProcessor;
import com.sbc.bac.aria.ARIAPaging;
import com.sbc.bac.aria.ARIAReportException;

public class Page13PivotHTMLProcessor extends ARIAHTMLReportProcessor {
	public static final int PAGING_AT_BOTTOM = 2;
    public static final int PAGING_AT_TOP = 1;
    public static final int PAGING_AT_TOP_AND_BOTTOM = 3;
    public static final int PAGING_OFF = 0;
    
	private PivotCellRenderer cellFormatter;
	private PivotHeaderRenderer headerRenderer;
	private PivotReportRenderer reportRenderer;
	private PivotRowRenderer rowRenderer;
	private PivotTableRenderer tableRenderer;
	private AdhocPivotData adhocDataSet;
	private String totalLabel;
	private int sectionNo;
	
	private PivotPagingRenderer pagingRenderer;
	private ARIAPaging paging;
	private int showPaging;
	private String pagedHtml;
	
	public Page13PivotHTMLProcessor(OutputStream out) {
		super(out);
	}
	 
	/*
     * (non-Javadoc)
     * 
     * @see com.sbc.bac.aria.ARIAHTMLReportProcessor#beginReport()
	*/
    public void beginReport() throws ARIAReportException {
        try {
        	// add paging if defined for top
            if ((getShowPaging() == PAGING_AT_TOP) || (getShowPaging() == PAGING_AT_TOP_AND_BOTTOM)) {
                if (getPaging() != null) {
                    setPagedHtml(insertPaging());
                }
            }
            
            if (getReportRenderer() == null) {
                super.beginReport();
            } else {
                out.write(getReportRenderer().renderBeginReport(this));
            }
        } catch (IOException e) {
            throw new ARIAReportException(e);
        }
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see com.sbc.bac.aria.ARIAHTMLReportProcessor#endReport()
     */
    public void endReport() throws ARIAReportException {
        try {
            if (getReportRenderer() == null) {
                super.endReport();
            } else {
                out.write(getReportRenderer().renderEndReport(this));
                out.flush();
            }
            
            // add paging if defined for bottom
            if ((getShowPaging() == PAGING_AT_BOTTOM) || (getShowPaging() == PAGING_AT_TOP_AND_BOTTOM)) {
                if (getPaging() != null) {
                	setPagedHtml(insertPaging());
                }
            }
        } catch (IOException e) {
            throw new ARIAReportException(e);
        }
    }
    
    /**
     * Method will begin a new layout 2 table
     * @throws ARIAReportException
     */
    public void beginTable() throws ARIAReportException {
        try {
            if (getTableRenderer() == null) {
            	out.write("<table>");
            } else {
                out.write(getTableRenderer().renderBeginTable(this));
            }
        } catch (IOException e) {
            throw new ARIAReportException(e);
        }
    }
    
    /**
     * Method will end a table
     * @throws ARIAReportException
     */
    public void endTable() throws ARIAReportException {
        try {
            if (getTableRenderer() == null) {
            	out.write("</table>");
            } else {
                out.write(getTableRenderer().renderEndTable(this));
            }
        } catch (IOException e) {
            throw new ARIAReportException(e);
        }
    }
    /**
     * Method will render the headers
     * @throws ARIAReportException
     */
    public void renderHeaders()throws ARIAReportException {
    	try {
    		if (getHeaderRenderer() != null){
    			out.write(getHeaderRenderer().renderHeader(this));
        	} 
    	} catch (IOException e) {
            throw new ARIAReportException(e);
        }
    }
    
    /**
     * Method will begin the key row for pivot reports
     * @throws ARIAReportException
     */
    public void beginKeyRow() throws ARIAReportException {
        try {
            if (getRowRenderer() == null) {
                out.write("<tr>");
            } else {
                out.write(getRowRenderer().renderBeginKeyRow(this));
            }
        } catch (IOException e) {
            throw new ARIAReportException(e);
        }
    }
    
    /**
     * Method will end the key row for Pivot reports
     * @throws ARIAReportException
     */
    public void endKeyRow() throws ARIAReportException {
    	try {
    		if (getRowRenderer() == null) {
                super.endRow();
            } else {
            	 out.write(getRowRenderer().renderEndKeyRow(this));
            }
    	} catch (IOException e) {
            throw new ARIAReportException(e);
        }  
    }
    
    /**
     * Method will begin the non-calculable columns row for pivot reports
     * @throws ARIAReportException
     */
    public void beginAttributeRow() throws ARIAReportException {
        try {
            if (getRowRenderer() == null) {
                out.write("<tr>");
            } else {
                out.write(getRowRenderer().renderBeginKeyRow(this));
            }
        } catch (IOException e) {
            throw new ARIAReportException(e);
        }
    }
    
    /**
     * Method will end the non-calculable columns row for Pivot reports
     * @throws ARIAReportException
     */
    public void endAttributeRow() throws ARIAReportException {
    	try {
    		if (getRowRenderer() == null) {
                super.endRow();
            } else {
            	 out.write(getRowRenderer().renderEndKeyRow(this));
            }
    	} catch (IOException e) {
            throw new ARIAReportException(e);
        }  
    }
    
    /**
     * Method will begin the Data Row for Pivot Reports
     * @throws ARIAReportException
     */
    public void beginDataRow() throws ARIAReportException {
        try {
            if (getRowRenderer() == null) {
                out.write("<tr>");
            } else {
                out.write(getRowRenderer().renderBeginDataRow(this));
            }
        } catch (IOException e) {
            throw new ARIAReportException(e);
        }
    }
    
    /**
     * Method will end the data row for Pivot reports
     * @throws ARIAReportException
     */
    public void endDataRow() throws ARIAReportException {
    	try {
    		if (getRowRenderer() == null) {
                super.endRow();
            } else {
            	out.write(getRowRenderer().renderEndDataRow(this));
            }
    	}catch (IOException e) {
            throw new ARIAReportException(e);
        }
    }
    
    /**
     * Method will add the key cell
     * @param label
     * @param value
     * @param escape
     * @throws ARIAReportException
     */
    public void addKeyCell(String label,String value, boolean escape,int elementIndex) throws ARIAReportException {
        try {
            if (getCellFormatter() != null) {
                String linkValue = getCellFormatter().renderKeyCell(this, label,value, escape,elementIndex);
                if (linkValue != null) {
                    out.write(linkValue);
                    return;
                }
            }
            out.write("<td> no data </td>");
        } catch (IOException e) {
            throw new ARIAReportException(e);
        }
    }
    
    /**
     * Method will add the data label cell i.e. 1st cell in a new data row
     * @param value
     * @param escape
     * @throws ARIAReportException
     */
    public void addDataLabelCell(String value, boolean escape) throws ARIAReportException {
        try {
            if (getCellFormatter() != null) {
                String linkValue = getCellFormatter().renderDataLabelCell(this, value, escape);
                if (linkValue != null) {
                    out.write(linkValue);
                    return;
                }
            }
            out.write("<td> no data </td>");
        } catch (IOException e) {
            throw new ARIAReportException(e);
        }
    }
    
    /**
     * Method will add the data value cell i.e. cells after 1st cell in a data row
     * @param label
     * @param headerName
     * @param value
     * @param escape
     * @throws ARIAReportException
     */
    public void addDataValueCell(int elementIndex,String headerName, String value, boolean escape) throws ARIAReportException {
        try {
            if (getCellFormatter() != null) {
                String linkValue = getCellFormatter().renderDataValueCell(this, elementIndex,headerName, value, escape);
                if (linkValue != null) {
                    out.write(linkValue);
                    return;
                }
            }
            out.write("<td> no data </td>");
        } catch (IOException e) {
            throw new ARIAReportException(e);
        }
    }
    
    
    /**
     * Get the column formatter or null if none is defined.
     * 
     * @return Returns the column formatter.
     */
    public PivotCellRenderer getCellFormatter() {
        return cellFormatter;
    }

    /**
     * @return Returns the headerRenderer.
     */
    public PivotHeaderRenderer getHeaderRenderer() {
        return headerRenderer;
    }
    
    public PivotReportRenderer getReportRenderer() {
        return reportRenderer;
    }
    
    public PivotRowRenderer getRowRenderer() {
        return rowRenderer;
    }

    /**
     * @param formatter The htmlLink to set.
     */
    public void setCellFormatter(PivotCellRenderer formatter) {
        this.cellFormatter = formatter;
    }

    /**
     * @param headerRenderer The headerRenderer to set.
     */
    public void setHeaderRenderer(PivotHeaderRenderer headerRenderer) {
        this.headerRenderer = headerRenderer;
    }

    public void setReportRenderer(PivotReportRenderer reportRenderer) {
        this.reportRenderer = reportRenderer;
    }


    public void setRowRenderer(PivotRowRenderer rowRenderer) {
        this.rowRenderer = rowRenderer;
    }

    /**
	 * @return the tableRenderer
	 */
	public PivotTableRenderer getTableRenderer() {
		return tableRenderer;
	}

	/**
	 * @param tableRenderer the tableRenderer to set
	 */
	public void setTableRenderer(PivotTableRenderer tableRenderer) {
		this.tableRenderer = tableRenderer;
	}

	/**
	 * @return the adhocDataSet
	 */
	public AdhocPivotData getAdhocDataSet() {
		return adhocDataSet;
	}

	/**
	 * @param adhocDataSet the adhocDataSet to set
	 */
	public void setAdhocDataSet(AdhocPivotData adhocDataSet) {
		this.adhocDataSet = adhocDataSet;
	}

	/**
	 * @return the totalLabel
	 */
	public String getTotalLabel() {
		return totalLabel;
	}

	/**
	 * @param totalLabel the totalLabel to set
	 */
	public void setTotalLabel(String totalLabel) {
		this.totalLabel = totalLabel;
	} 
	
	/**
     * Calculate whether the line is a grand total line or not
     * 
     * @return
     */
    public boolean isTotal() {
        if (getTotalLabel() == null) {
            return false;
        }
        return true;
    }
    
    /**
     * Return the paging object if defined
     * 
     * @return Returns the paging.
     */
    public ARIAPaging getPaging() {
        return paging;
    }

    /**
     * @return Returns the pagingRenderer.
     */
    public PivotPagingRenderer getPagingRenderer() {
        return pagingRenderer;
    }
    
    /**
     * Get the value determining if paging is shown or not
     * 
     * @return Returns the showPaging.
     */
    public int getShowPaging() {
        return showPaging;
    }
    
    /**
     * Set the paging object.
     * 
     * @param paging The paging to set.
     */
    public void setPaging(ARIAPaging paging) {
        this.paging = paging;
    }

    /**
     * @param pagingRenderer The pagingRenderer to set.
     */
    public void setPagingRenderer(PivotPagingRenderer pagingRenderer) {
        this.pagingRenderer = pagingRenderer;
    }
    
    /**
     * Set the desired paging display type. Use constants described in this class to determine valid values
     * 
     * @param showPaging The showPaging to set.
     */
    public void setShowPaging(int showPaging) {
        this.showPaging = showPaging;
    }
    
    /**
     * Insert paging HTML
     * 
     * @return
     */
    private String insertPaging() {
        if (pagingRenderer != null) {
            return pagingRenderer.renderPaging(getPaging());
        } else {
            return "";
        }
    }

	/**
	 * @return the sectionNo
	 */
	public int getSectionNo() {
		return sectionNo;
	}

	/**
	 * @param sectionNo the sectionNo to set
	 */
	public void setSectionNo(int sectionNo) {
		this.sectionNo = sectionNo;
	}

	/**
	 * @return the pagedHtml
	 */
	public String getPagedHtml() {
		return pagedHtml;
	}

	/**
	 * @param pagedHtml the pagedHtml to set
	 */
	public void setPagedHtml(String pagedHtml) {
		this.pagedHtml = pagedHtml;
	}
	
	
}
