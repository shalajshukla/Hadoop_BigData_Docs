/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.att.bac.rabc.admin.AlertGroup;
import com.att.carat.util.email.EmailFactory;

/**
 * This is an action class that controls the actions required to populate 
 * the email user's selection page and send email to selected recipents.
 * 
 * @author Vijay Dubey - VD3159
 */
public class EmailUserAction extends DispatchAction {
	public static Logger logger = Logger.getLogger(EmailUserAction.class);
	public EmailUserService emailUserService = EmailUserService.getEmailUserService();
	
	
	/**
	 * Default dispatch action method to populate the email user's selection page.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @see org.apache.struts.actions.DispatchAction#unspecified(org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public ActionForward unspecified(ActionMapping mapping, ActionForm form,HttpServletRequest request, HttpServletResponse response){
		return get(mapping, form, request, response);
	}
	
	/**
	 * Dispatch action method to populate the email user's selection page.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @see org.apache.struts.actions.DispatchAction#unspecified(org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public ActionForward get(ActionMapping mapping, ActionForm form,HttpServletRequest request, HttpServletResponse response){
		EmailUserForm emailUserForm = (EmailUserForm) form;
		Connection connection = null;
		List failureList = new ArrayList();
		try {
			connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
			String alertGroup = emailUserForm.getAlertGroup();
			
			/*
			 * Call the internal method populateOptions(EmailUserForm) 
			 * to set the option lists.
			 */ 
	        populateOptions(emailUserForm, connection, failureList, alertGroup);
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		if (!failureList.isEmpty()) {
			request.setAttribute("failures",failureList);
			return mapping.findForward("error");
		} else {
			return mapping.findForward("EmailUser");
		}
	}
	
	/**
	 * Dispatch action method to send email to admin person 
	 * if there is any error in sending the email to the selected recipients.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @see org.apache.struts.actions.DispatchAction#unspecified(org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public ActionForward emailErrorDetails(ActionMapping mapping, ActionForm form,HttpServletRequest request, HttpServletResponse response) {
		EmailUserForm emailUserForm = (EmailUserForm) form;
		List failureList = new ArrayList();		
		String techsupport_email = null;
		
		try {
			
			Context context = (Context)new InitialContext().lookup("java:/comp/application_env");
			
			techsupport_email = (String)context.lookup("techsupport_email");
			EmailFactory.sendEmail(techsupport_email, emailUserForm.getSenderEmailAddress(), "Subject : (RABC) Error reported in the application " , emailUserForm.getErrorDetails());
			//Email.sendEmail("js3175@att.com", emailUserForm.getSenderEmailAddress(), "Subject : (RABC) Error reported in the application " , emailUserForm.getErrorDetails());
		} catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} 		
		
		if (!failureList.isEmpty()) {
			request.setAttribute("failures",failureList);
			return mapping.findForward("error");
		} else {
			return mapping.findForward("SendEmail");
		}
	}
	
	/**
	 * Private method to pouplate the list objects of the form. These list objects are used to populate
	 * the drop down boxes on the email user's selection page.
	 * 
	 * @param emailUserForm
	 * @param connection
	 * @param failureList
	 * @param alertGroup
	 */
	private void populateOptions(EmailUserForm emailUserForm, 
    		Connection connection, List failureList, String alertGroup) {
    	List tempList;
    	int counter = 0;
    	/*
		 * Call methods from service class to populate the EmailUserForm.
		 */
    	if ( emailUserForm.getAlertGroupList() == null || emailUserForm.getAlertGroupList().size() == 0) {
    		tempList = emailUserService.getAlertGroupList(connection, failureList);
    		if (tempList != null) {
    			int tempListSize = tempList.size();
	    		for(counter = 0; counter < tempListSize; counter++) {
	    			emailUserForm.addAlertGroup((AlertGroup) tempList.get(counter));
				}
    		}
    	}
    	
    	if ( emailUserForm.getUserList() == null || emailUserForm.getUserList().size() == 0) {
    		tempList = emailUserService.getAlertUserList(connection, failureList, alertGroup);
    		if (tempList != null) {
    			int tempListSize = tempList.size();
	    		for(counter = 0; counter < tempListSize; counter++) {
	    			emailUserForm.addUser((PickList) tempList.get(counter));
				}
    		}
    	}
    }
}
