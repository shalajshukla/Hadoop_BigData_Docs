/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/

package com.att.bac.rabc.alerts.dashboard;

import java.util.ArrayList;
import java.util.List;

/**
 * This class represents the data object that holds the attributes required
 * to represent level wise warnings.  
 * 
 * @author Sandhya Chinala - SC3837
 */
public class LevelWiseWarnings {
	private int count;
	private List divisionWiseAlertSummaryList;
	
	/**
	 * Default constructor for level wise warnings object
	 *
	 */
	public LevelWiseWarnings(){
		this.divisionWiseAlertSummaryList= new ArrayList();
	}
	
	/**
	 * @return Returns the divisionWiseAlertSummaryList.
	 */
	public List getDivisionWiseAlertSummaryList() {
		return divisionWiseAlertSummaryList;
	}
	
	/**
	 * @param divisionWiseAlertSummary The divisionWiseAlertSummary add. 
	 */
	public void addDivisionWiseAlertSummary(DivisionWiseAlertSummary divisionWiseAlertSummary) {
		this.divisionWiseAlertSummaryList.add(divisionWiseAlertSummary);
	}
	/**
	 * @return Returns the count.
	 */
	public int getCount() {
		return count;
	}
	/**
	 * @param count The count to set.
	 */
	public void setCount(int count) {
		this.count = count;
	}
}
