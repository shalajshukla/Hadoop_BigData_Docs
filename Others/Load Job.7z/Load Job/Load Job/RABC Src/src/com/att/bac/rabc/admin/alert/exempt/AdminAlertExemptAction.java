/* Component Name: RABCPPG01232
 * Module Name: AdminAlertExemptAction.java
 * Created on Jul 17, 2006
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.admin.alert.exempt;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.StaticDataLoader;

/**This is the struts Action class for the Alert Exempt process.  The purpose of this class
 * is mainly to interact between the AdminAlertExemptForm.java class and the struts framework.
 * All business logic is handled in the facade class AdminAlertExemptService.java.
 * 
 * @author js3175
 */
public class AdminAlertExemptAction extends DispatchAction {
	private static final Logger logger = Logger.getLogger(AdminAlertExemptAction.class);
	
	/**This is the struts framework default method entered when entering the admin.alert.exempt
	 * process without a dispatch.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of AdminAlertExemptForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward unspecified(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) 
			throws RABCException {
		logger.debug("dispatch = unspecified");
		ActionForward forward = adminAlertExempt(mapping, form, request, response);
		return forward;
	}
	
	/**This is the struts framework method called to set up and present the entry page into
	 * the admin.alert.exempt process.  This method is also responsible for catching and logging
	 * all exceptions thrown.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of AdminAlertExemptForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward adminAlertExempt(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = adminAlertExempt");
		ActionForward forward = null;
		try {
			AdminAlertExemptForm adminAlertExemptForm = (AdminAlertExemptForm)form;
			adminAlertExemptForm.setRegion((String)request.getSession().getAttribute("region"));
			adminAlertExemptForm.setUserId((String)request.getSession().getAttribute("bacUserID"));
			adminAlertExemptForm.setBillRounds(StaticDataLoader.getBillRounds((String)request.getSession().getAttribute("region")));
			adminAlertExemptForm.setProcDates(StaticDataLoader.getProcDates((String)request.getSession().getAttribute("region")));
			adminAlertExemptForm.setHolidayIndicators(StaticDataLoader.getHolidayIndicators((String)request.getSession().getAttribute("region")));
			adminAlertExemptForm.setLoadedDataDates(StaticDataLoader.getLoadedDataDatesByRegion((String)request.getSession().getAttribute("region")));
			adminAlertExemptForm = AdminAlertExemptService.adminAlertExempt(adminAlertExemptForm);
			log(adminAlertExemptForm);
			forward = mapping.findForward("adminAlertExempt");
		} catch (RABCException e) {
			return this.processError(request, mapping, e);
		}
		return forward;
	}
	
	/**This is the struts framework method called to set up and present the trend time exempts present for a
	 * particular alert and to set new trend time exempts for a particular alert.  These values can be either
	 * a bill period or a day of the week depending upon the alert rule.  This method is also responsible for
	 * catching and logging all exceptions thrown.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of AdminAlertExemptForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward adminAlertExemptTime(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = adminAlertExemptTime");
		ActionForward forward = null;
		try {
			AdminAlertExemptForm adminAlertExemptForm = (AdminAlertExemptForm)form;
			adminAlertExemptForm.clear();
			adminAlertExemptForm.setRegion((String)request.getSession().getAttribute("region"));
			adminAlertExemptForm.setUserId((String)request.getSession().getAttribute("bacUserID"));
			adminAlertExemptForm.setBillRounds(StaticDataLoader.getBillRounds((String)request.getSession().getAttribute("region")));
			adminAlertExemptForm.setProcDates(StaticDataLoader.getProcDates((String)request.getSession().getAttribute("region")));
			adminAlertExemptForm.setHolidayIndicators(StaticDataLoader.getHolidayIndicators((String)request.getSession().getAttribute("region")));
			adminAlertExemptForm.setLoadedDataDates(StaticDataLoader.getLoadedDataDatesByRegion((String)request.getSession().getAttribute("region")));
			adminAlertExemptForm = AdminAlertExemptService.adminAlertExemptTime(adminAlertExemptForm);
			log(adminAlertExemptForm);
			forward = mapping.findForward("adminAlertExemptTime");
		} catch (RABCException e) {
			return this.processError(request, mapping, e);
		}
		return forward;
	}
	
	/**This is the struts framework method called to set up and present the keys exempts present for a
	 * particular alert and to set new keys exempts for a particular alert.  A key exempt consists of all
	 * the keys of an alert plus the alert item.  This method is also responsible for catching and logging
	 * all exceptions thrown.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of AdminAlertExemptForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward adminAlertExemptKey(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = adminAlertExemptKey");
		ActionForward forward = null;
		try {
			AdminAlertExemptForm adminAlertExemptForm = (AdminAlertExemptForm)form;
			adminAlertExemptForm.clear();
			adminAlertExemptForm.setRegion((String)request.getSession().getAttribute("region"));
			adminAlertExemptForm.setUserId((String)request.getSession().getAttribute("bacUserID"));
			adminAlertExemptForm.setBillRounds(StaticDataLoader.getBillRounds((String)request.getSession().getAttribute("region")));
			adminAlertExemptForm.setProcDates(StaticDataLoader.getProcDates((String)request.getSession().getAttribute("region")));
			adminAlertExemptForm.setHolidayIndicators(StaticDataLoader.getHolidayIndicators((String)request.getSession().getAttribute("region")));
			adminAlertExemptForm.setLoadedDataDates(StaticDataLoader.getLoadedDataDatesByRegion((String)request.getSession().getAttribute("region")));
			adminAlertExemptForm = AdminAlertExemptService.adminAlertExemptKey(adminAlertExemptForm);
			log(adminAlertExemptForm);
			forward = mapping.findForward("adminAlertExemptKey");
		} catch (RABCException e) {
			return this.processError(request, mapping, e);
		}
		return forward;
	}
	
	/**This is the struts framework method called to set up and present the confirm page for trend times that 
	 * have been either added or end dated.  A trend time can be either a bill period or a day of the week.
	 * This method is also responsible for catching and logging all exceptions thrown.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of AdminAlertExemptForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward adminAlertExemptConfirmTime(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = adminAlertExemptConfirmTime");
		ActionForward forward = null;
		try {
			AdminAlertExemptForm adminAlertExemptForm = (AdminAlertExemptForm)form;
			adminAlertExemptForm.setRegion((String)request.getSession().getAttribute("region"));
			adminAlertExemptForm.setUserId((String)request.getSession().getAttribute("bacUserID"));
			adminAlertExemptForm = AdminAlertExemptService.adminAlertExemptConfirmTime(adminAlertExemptForm);
			log(adminAlertExemptForm);
			forward = mapping.findForward("adminAlertExemptConfirmTime");
		} catch (RABCException e) {
			return this.processError(request, mapping, e);
		}
		return forward;
	}
	
	/**This is the struts framework method called to set up and present the confirm page for trend times that 
	 * have been either added or end dated.  A trend time can be either a bill period or a day of the week.
	 * This method is also responsible for catching and logging all exceptions thrown.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of AdminAlertExemptForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward adminAlertExemptConfirmKey(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = adminAlertExemptConfirmKey");
		ActionForward forward = null;
		try {
			AdminAlertExemptForm adminAlertExemptForm = (AdminAlertExemptForm)form;
			adminAlertExemptForm.setRegion((String)request.getSession().getAttribute("region"));
			adminAlertExemptForm.setUserId((String)request.getSession().getAttribute("bacUserID"));
			adminAlertExemptForm = AdminAlertExemptService.adminAlertExemptConfirmKey(adminAlertExemptForm);
			log(adminAlertExemptForm);
			forward = mapping.findForward("adminAlertExemptConfirmKey");
		} catch (RABCException e) {
			return this.processError(request, mapping, e);
		}
		return forward;
	}
	
	/**This is the struts framework method called to set up and present the confirm page for trend times that 
	 * have been either added or end dated.  A trend time can be either a bill period or a day of the week.
	 * This method is also responsible for catching and logging all exceptions thrown.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of AdminAlertExemptForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward updateTrendTimes(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = updateTrendTimes");
		ActionForward forward = null;
		try {
			AdminAlertExemptForm adminAlertExemptForm = (AdminAlertExemptForm)form;
			adminAlertExemptForm.setRegion((String)request.getSession().getAttribute("region"));
			adminAlertExemptForm.setUserId((String)request.getSession().getAttribute("bacUserID"));
			adminAlertExemptForm = AdminAlertExemptService.updateTrendTimes(adminAlertExemptForm);
			log(adminAlertExemptForm);
			forward = mapping.findForward("adminAlertExempt");
		} catch (RABCException e) {
			return this.processError(request, mapping, e);
		}
		return forward;
	}
	
	/**This is the struts framework method called to set up and present the confirm page for trend times that 
	 * have been either added or end dated.  A trend time can be either a bill period or a day of the week.
	 * This method is also responsible for catching and logging all exceptions thrown.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of AdminAlertExemptForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward adminAlertExemptEndDateKey(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = adminAlertExemptEndDateKey");
		ActionForward forward = null;
		try {
			AdminAlertExemptForm adminAlertExemptForm = (AdminAlertExemptForm)form;
			adminAlertExemptForm.setRegion((String)request.getSession().getAttribute("region"));
			adminAlertExemptForm.setUserId((String)request.getSession().getAttribute("bacUserID"));
			adminAlertExemptForm = AdminAlertExemptService.adminAlertExemptEndDateKey(adminAlertExemptForm);
			log(adminAlertExemptForm);
			forward = mapping.findForward("adminAlertExemptConfirmKey");
		} catch (RABCException e) {
			return this.processError(request, mapping, e);
		}
		return forward;
	}
	
	/**This is the struts framework method called to set up and present the confirm page for trend times that 
	 * have been either added or end dated.  A trend time can be either a bill period or a day of the week.
	 * This method is also responsible for catching and logging all exceptions thrown.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of AdminAlertExemptForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward adminAlertExemptInsert(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = adminAlertExemptInsert");
		ActionForward forward = null;
		try {
			AdminAlertExemptForm adminAlertExemptForm = (AdminAlertExemptForm)form;
			adminAlertExemptForm.setRegion((String)request.getSession().getAttribute("region"));
			adminAlertExemptForm.setUserId((String)request.getSession().getAttribute("bacUserID"));
			adminAlertExemptForm = AdminAlertExemptService.adminAlertExemptInsert(adminAlertExemptForm);
			log(adminAlertExemptForm);
			forward = mapping.findForward("adminAlertExempt");
		} catch (RABCException e) {
			return this.processError(request, mapping, e);
		}
		return forward;
	}
	
	/**This method sends all error messages to the browser and kills the process.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param request  the HttpServletRequest from the browser
	 * @param e  the error that caused the application to fail.
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	private ActionForward processError(HttpServletRequest request, ActionMapping mapping, RABCException e) {
		request.setAttribute("javax.servlet.error.exception", e);
		logger.error(e.getMessage(), e);
		return  mapping.findForward("error");
	}
	
	/**This method only shows values in the form to the console when in debug mode.
	 * 
	 * @param adminAlertExemptForm  the ActionForm for this process - AdminAlertExemptForm
	 */
	private void log(AdminAlertExemptForm adminAlertExemptForm){
		logger.debug("region = " + adminAlertExemptForm.getRegion());
		logger.debug("userId = " + adminAlertExemptForm.getUserId());
		logger.debug("alertRule = " + adminAlertExemptForm.getSelectedAlertRule());
		logger.debug("# trend times = " + adminAlertExemptForm.getActiveTrendTimes().length);
		logger.debug("# key exempts = " + adminAlertExemptForm.getActiveKeyExempts().length);
		logger.debug("*************************************************************************");
	}
}
