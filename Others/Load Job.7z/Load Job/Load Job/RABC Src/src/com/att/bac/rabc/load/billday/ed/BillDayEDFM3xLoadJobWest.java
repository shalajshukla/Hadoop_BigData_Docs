/**
 * 
 */
package com.att.bac.rabc.load.billday.ed;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.UnknownHostException;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashSet;

import com.att.bac.rabc.util.EmcisEventLogger;
import com.att.bac.util.NetUtil;
import com.att.carat.util.JDBCUtil;
import com.sbc.bac.rabc.load.FilePatternLoadJob;
import com.sbc.bac.rabc.load.PrepareTableForRerun;
import com.sbc.bac.rabc.load.RabcLoadJobTrig;
import com.sbc.bac.rabc.load.StaticErrorMsgKeys;

/**
 * The load job loads data from a file with semicolon separated values into the RABC_QUAL_DQ_SUMY table.
 * No calculations or summations are needed. 
 * @author vp4821
 *
 */
public class BillDayEDFM3xLoadJobWest extends FilePatternLoadJob {
	
	private static String sqlForQual = "insert into rabc_qual_dq_sumy t " +
		" (t.REGION, t.DIVISION, t.PKG_USOC, t.QUAL_DQ_IND, t.PROC_DATE, t.TOT_CNT) " +
		" values (?, ?, ?, ?, ?, ?)"; 
	
	private PreparedStatement loadQual;
	private static int BATCH_SIZE = 1000;
	
	private String fileId = "XT25ED02";				//matches FILE_ID field in rabc_file_mash table for TABLE_NAME: rabc_qual_dq_sumy
	private File currentFile;	
	private boolean hasTrailerBeenProcessed;
	private boolean isFirstLine;
	private boolean isSecondLine;
	private int lineCount;
	//private DateFormat yyyyMMdd = new SimpleDateFormat("yyyyMMdd");
	private DateFormat MMddyyyy = new SimpleDateFormat("MMddyyyy");
	private DateFormat yyMMdd = new SimpleDateFormat("yyMMdd");
	
	//private String procDateStr;
	//private String billRndStr;
	private String division, fileName, fileToken, region;
	private HashSet<String> divisionHS = new HashSet<String>();
	private static final String TABLE_NAME = "RABC_QUAL_DQ_SUMY";
	private String backoutRecovery = null;
	private Date procDate;
	//private Date duplFileDeleteDate;
	private Date processDate;
	//private Date billPeriodDate;
	
	public boolean preprocess() {
		boolean success = true;
		super.preprocess();

		try {
			loadQual = connection.prepareStatement( sqlForQual );
		} catch (SQLException e) {
			severe(StaticErrorMsgKeys.PREPROCESS_ERROR + e.getMessage(), e);
			success = false;
		}
		
		return success;
	}

    /**
     * Runs prior to file processing. Initializes application variables.
     * 
     * @return false if an error is encountered during initialization, otherwise true
     */
	public boolean preprocessFile(File file) {
		boolean success = super.preprocessFile(file);
		fileName = file.getName();
		fileToken = file.getName().substring(file.getName().indexOf("XT25EDFM"),file.getName().indexOf("XT25EDFM")+ 8);
		String temp = file.getName().substring(0,file.getName().lastIndexOf('.'));
		String fileNameWithoutTimeStamp = temp.substring(0,temp.lastIndexOf('.'));
		BufferedReader in = null;
		try{
			if( success ){
				currentFile = file;
				lineCount = 0;
				hasTrailerBeenProcessed = false;
				isFirstLine = true;	
				isSecondLine = false;
				procDate = null;
				divisionHS = new HashSet<String>();
				processDate = null;
				//billPeriodDate = null;
				//set backup recovery indicator to null
				backoutRecovery = null;
				region = file.getName().substring(0,2);
				
				if (RabcLoadJobTrig.IsFileLoaded(connection, file, fileNameWithoutTimeStamp.length())) {
					warning(file.getName() + " has already been loaded.");
	
					//Marks the backoutRecovery flag to "Y" if this file has already been processed earlier.
					backoutRecovery = "Y";
					in = new BufferedReader(new FileReader(file));
					parseHeader(in.readLine().split("[ ]*;[ ]*"));
					// parse the process date and the bill period date from the 2nd row of the file 
					parseProcessAndBillPeriodDate(in.readLine().split("[ ]*;[ ]*"));
					
					//get first date from detail record
					//duplFileDeleteDate = new Date( yyyyMMdd.parse( in.readLine().split("[ ]*;[ ]*")[5] ).getTime() ); 
					
					//get first date from detail record for deletions
					if( division.contentEquals( "PS" ) ){
						info("Deleting records from RABC_QUAL_DQ_SUMY for division: PS and PROC DATE:"+processDate);
						success = PrepareTableForRerun.deletePreviouslyLoadedData(connection,TABLE_NAME , "PS", processDate);
					} else {
						info("Deleting records from RABC_QUAL_DQ_SUMY for division: PN and NB and PROC DATE:"+processDate);
						success = PrepareTableForRerun.deletePreviouslyLoadedData(connection,TABLE_NAME , "PN", processDate)
								&&PrepareTableForRerun.deletePreviouslyLoadedData(connection,TABLE_NAME , "NB", processDate);
					}
					return success;			
				}
				return true;
			}
			else 
				return false;
		}catch (SQLException e) {
			severe("Could not instantiate prepared statements.", e);
			return false;
		}catch (IOException e) {
			severe("Could not read file.", e);
			return false;
		} catch (ParseException e) {
			severe("Could not parse file.", e);
			return false;
		} catch(Exception e){
			severe("General Exception occured.", e);
			return false;
		} finally {
			try {
				if (in != null) in.close();
			} catch (IOException e) {
				severe("error closing file - " + e.toString());
			}
			in = null;
		}
	}

	/* (non-Javadoc)
	 * @see com.sbc.bac.load.FileDBLoadJob#parseLine(java.lang.String)
	 */
	@Override
	protected int parseLine(String line) throws Exception {
		String[] fields = line.split("[ ]*;[ ]*");
		
		if( hasTrailerBeenProcessed ) {							// trailer must be last record in file
			severe("TRAILER was not the last record on currently processing file: " + currentFile.getName());
			return ERROR;
		}
			
		if (isFirstLine) {										// header must be first record on file
			isFirstLine = false;
			isSecondLine = true;
			//If header is not already parsed then parse the header
			if(procDate==null){
				return parseHeader(fields);
			}else{
				//header is already processed
				return SUCCESS;
			}

		} else if(isSecondLine){
			isSecondLine = false;
			//if(processDate == null || billPeriodDate == null){
			if(processDate == null){
				return parseProcessAndBillPeriodDate(fields);
			} else{
				return SUCCESS;
			}
		} else if ("TRAILER".equalsIgnoreCase(fields[0])) {
			hasTrailerBeenProcessed = true;
			int totalRecords = Integer.parseInt(fields[5]) - 1;			
			if (totalRecords == lineCount) {
				return SUCCESS;
			}
			else{
				throw new Exception("Record count mismatch, trailer record shows " + totalRecords + ", but " + lineCount + " records exist on file " + currentFile.getName());
			}
		}
		
		lineCount++;										// header and trailer records are not counted	
		loadQual.setString(1, fields[1]);											// REGION
		loadQual.setString(2, fields[2]);											// DIVISION
		loadQual.setString(3, fields[3]);											// PKG_USOC
		loadQual.setString(4, fields[4]);											// QUAL_DQ_IND
		//loadQual.setDate(5, new Date(yyyyMMdd.parse(fields[5]).getTime()));		// PROC_DATE
		loadQual.setDate(5, processDate);                                           // PROC_DATE
		loadQual.setString(6, fields[7].substring(0, fields[7].length()-6));		// TOT_CNT

		loadQual.addBatch();
		if((lineCount % BATCH_SIZE) == 0){
			loadQual.executeBatch();
		}
			
		divisionHS.add( fields[2] );							// identify divisions for insertion into trig table

		return SUCCESS;
	}
	
	public boolean postprocessFile(File file, boolean success) {
		try{
			//Log the file information to EMCIS_EVENT_LOG and EMCIS_EVENT_LOG_DETAIL
			EmcisEventLogger emcisLogger = new EmcisEventLogger();
			String event_id = "RABC_"+fileToken+"_"+region;
            String host = NetUtil.getLocalHostName();
            String hostIP = NetUtil.getLocalIpAddress();
			int sequence = emcisLogger.getEMCISSequence(connection);
			emcisLogger.insertEventLog(connection, sequence, event_id, procDate, host, hostIP);
			emcisLogger.insertEventLogDetail(connection, sequence, "FileName", fileName);

		}catch (UnknownHostException e) {
            severe("Error getting EMCIS host information ", e);
        }
		if (success) {
			try {
				loadQual.executeBatch();
				
				if(!insertTrigger()) {
					severe(
						StaticErrorMsgKeys.POSTPROCESSFILE_ERROR
							+ StaticErrorMsgKeys.TIGGER_TABLE_INSERT_ERROR);
					success = false;
				}
			} catch (SQLException sqle) {
				severe(StaticErrorMsgKeys.INSERT_ERROR + " from method postprocessFile(File file, boolean success)" + sqle.getMessage(), sqle);
				success = false;
			}
		}
		return super.postprocessFile(file, success);
	}
	
	private boolean insertTrigger() {		
		for(String division: divisionHS){
			if( !RabcLoadJobTrig.insertTrigger(							
					connection, currentFile.getName(), fileId, division, processDate, backoutRecovery) ){
				return false;
			}
		}
		return true;
	}

	public boolean postprocess(boolean success) {
		JDBCUtil.closePreparedStatement( loadQual );	
		return true;
	}
	
	/**
	 * Reads the procDate from the header.
	 * @param fields - first line in file
	 * @return
	 * @throws ParseException
	 */
	private int parseHeader(String[] fields) throws java.text.ParseException{
		if ("HEADER".equalsIgnoreCase(fields[0])) {
			//procDateStr = fields[3];						// should be MMddyyyy
			//billRndStr = fields[3].substring(2, 4);			// get the dd
			division = fields[2];
			procDate = new Date( MMddyyyy.parse( fields[3] ).getTime() );
			return SUCCESS;
		} else {
			severe("HEADER could not be parsed in file: " + currentFile.getName());
			return ERROR;
		}
	}
	
	/**
	 * Used to read the process Date and BillPeriodDate from the 2nd row of the file.
	 * @param fields - second line in file
	 * @return
	 * @throws Exception
	 */
	private int parseProcessAndBillPeriodDate(String[] fields) throws Exception{
		if("XT25DATE".equalsIgnoreCase(fields[0])){
			if(fields.length > 2 && !(fields[2].equalsIgnoreCase("000000")) && !(fields[2].equalsIgnoreCase("")) && fields[2] != null){
				processDate = new Date( yyMMdd.parse( fields[2] ).getTime() );
				//billPeriodDate = new Date( yyMMdd.parse( fields[3] ).getTime() );
				return SUCCESS;
			}else{
				throw new Exception("Process Date not defined in the second row of currently processing file: " + currentFile.getName());
			}
		}else{
			throw new Exception("XT25DATE row missing in currently processing file: " + currentFile.getName());
		}
	}
}
