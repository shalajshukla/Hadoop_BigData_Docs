/*
 * Copyright  2002-2006 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.load.keymatch;

import java.util.ArrayList;
import java.util.List;


/**
 * RABC_KEY_MATCH_ALERT bean
 * 
 * <p>
 * <hr>
 * <h3>Release History</h3>
 * <p>
 * <ul>
 * 
 * <li>jb6494 Oct 24, 2006 Created class.
 * 
 * </ul>
 * <p>
 * 
 */
public class KeyMatchAlert {
    private int alertDay;

    private int alertMatchKey;

    private String alertProcTable;

    private String alertRule;

    private String billRoundDDLName;

    private List ddlKeyName;

    private String fileID;

    private int levelOfKey;

    private String nextRunDayIndicator;

    private String procDateDDLName;


    /**
     * @return Returns the alertDay.
     */
    public int getAlertDay() {
        return alertDay;
    }


    /**
     * @return Returns the alertMatchKey.
     */
    public int getAlertMatchKey() {
        return alertMatchKey;
    }


    /**
     * @return Returns the alertProcTable.
     */
    public String getAlertProcTable() {
        return alertProcTable;
    }


    /**
     * @return Returns the alertRule.
     */
    public String getAlertRule() {
        return alertRule;
    }


    /**
     * @return Returns the billRoundDDLName.
     */
    public String getBillRoundDDLName() {
        return billRoundDDLName;
    }


    /**
     * @return Returns the ddlKeyName.
     */
    public List getDdlKeyName() {
        if (ddlKeyName == null) {
            ddlKeyName = new ArrayList();
        }
        return ddlKeyName;
    }


    /**
     * @return Returns the fileID.
     */
    public String getFileID() {
        return fileID;
    }


    /**
     * @return Returns the levelOfKey.
     */
    public int getLevelOfKey() {
        return levelOfKey;
    }


    /**
     * @return Returns the nextRunDayIndicator.
     */
    public String getNextRunDayIndicator() {
        return nextRunDayIndicator;
    }


    /**
     * @return Returns the procDateDDLName.
     */
    public String getProcDateDDLName() {
        return procDateDDLName;
    }


    /**
     * @param alertDay The alertDay to set.
     */
    public void setAlertDay(int alertDay) {
        this.alertDay = alertDay;
    }


    /**
     * @param alertMatchKey The alertMatchKey to set.
     */
    public void setAlertMatchKey(int alertMatchKey) {
        this.alertMatchKey = alertMatchKey;
    }


    /**
     * @param alertProcTable The alertProcTable to set.
     */
    public void setAlertProcTable(String alertProcTable) {
        this.alertProcTable = alertProcTable;
    }


    /**
     * @param alertRule The alertRule to set.
     */
    public void setAlertRule(String alertRule) {
        this.alertRule = alertRule;
    }


    /**
     * @param billRoundDDLName The billRoundDDLName to set.
     */
    public void setBillRoundDDLName(String billRoundDDLName) {
        this.billRoundDDLName = billRoundDDLName;
    }


    /**
     * @param fileID The fileID to set.
     */
    public void setFileID(String fileID) {
        this.fileID = fileID;
    }


    /**
     * @param levelOfKey The levelOfKey to set.
     */
    public void setLevelOfKey(int levelOfKey) {
        this.levelOfKey = levelOfKey;
    }


    /**
     * @param string The nextRunDayIndicator to set.
     */
    public void setNextRunDayIndicator(String nextRunDayIndicator) {
        this.nextRunDayIndicator = nextRunDayIndicator;
    }


    /**
     * @param procDateDDLName The procDateDDLName to set.
     */
    public void setProcDateDDLName(String procDateDDLName) {
        this.procDateDDLName = procDateDDLName;
    }
}
