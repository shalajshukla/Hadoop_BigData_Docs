package com.att.bac.rabc.load.calnet.telcoacus;
import java.sql.Date;
import java.text.SimpleDateFormat;

/**
 * This component contains the getter/ setter methods of the fields used by CrisAcusReportLoadJob
 *
 */
public class CrisAcus {

	private String crisBtn;
	private String crisBillRnd;
	private String crisBillMm;
	private String crisYear;
	private String crisBillAmt;
	private String acusBtn;
	private String acusBillRnd;
	private String acusBillMm;
	private String acusYear;
	private String acusReceivedAmt;
	private Date   dataExtractDt;
	
	public String getAcusBillMm() {
		return acusBillMm;
	}
	
	public void setAcusBillMm(String acusBillMm) {
		this.acusBillMm = acusBillMm;
	}
	
	public String getAcusBillRnd() {
		return acusBillRnd;
	}
	
	public void setAcusBillRnd(String acusBillRnd) {
		this.acusBillRnd = acusBillRnd;
	}
	
	public String getAcusBtn() {
		return acusBtn;
	}
	
	public void setAcusBtn(String acusBtn) {
		this.acusBtn = acusBtn;
	}
	
	public String getAcusReceivedAmt() {
		return acusReceivedAmt;
	}
	
	public void setAcusReceivedAmt(String acusReceivedAmt) {
		this.acusReceivedAmt = acusReceivedAmt;
	}
	
	public String getAcusYear() {
		return acusYear;
	}
	
	public void setAcusYear(String acusYear) {
		this.acusYear = acusYear;
	}
	
	public String getCrisBillAmt() {
		return crisBillAmt;
	}
	
	public void setCrisBillAmt(String crisBillAmt) {
		this.crisBillAmt = crisBillAmt;
	}
	
	public String getCrisBillMm() {
		return crisBillMm;
	}
	
	public void setCrisBillMm(String crisBillMm) {
		this.crisBillMm = crisBillMm;
	}
	
	public String getCrisBillRnd() {
		return crisBillRnd;
	}
	
	public void setCrisBillRnd(String crisBillRnd) {
		this.crisBillRnd = crisBillRnd;
	}
	
	public String getCrisBtn() {
		return crisBtn;
	}
	
	public void setCrisBtn(String crisBtn) {
		this.crisBtn = crisBtn;
	}
	
	public String getCrisYear() {
		return crisYear;
	}
	
	public void setCrisYear(String crisYear) {
		this.crisYear = crisYear;
	}
	
		
	public String getDataExtractDt(){
		if(dataExtractDt==null)
			return "";
		SimpleDateFormat result = new SimpleDateFormat("MM/dd/yyyy");
		return result.format(dataExtractDt);
	}
	
	public void setDataExtractDt(Date dataExtractDt){
		this.dataExtractDt = dataExtractDt;
	}
}
