/*
 * Module description: 
 * Load job for SO control point in case of SW region.
 * 
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 *
 * Modification History:                                     
 * SBCUID		Date			Description                         	    	
 * ------		--------		-----------
 * UD7153		20060817		Initial version for EAP 556013  
 */
package com.att.bac.rabc.load.so.sw;

import java.io.File;
import java.net.UnknownHostException;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.att.bac.rabc.util.EmcisEventLogger;
import com.att.carat.util.NetUtil;
import com.sbc.bac.rabc.load.FilePatternLoadJob;
import com.sbc.bac.rabc.load.PrepareTableForRerun;
import com.sbc.bac.rabc.load.RabcLoadJobTrig;
import com.sbc.bac.rabc.load.RetrieveStaticInfo;
import com.sbc.bac.rabc.load.StaticErrorMsgKeys;
import com.sbc.bac.rabc.load.StaticFieldKeys;

public class SOSWLoadJob extends FilePatternLoadJob {

	/*
	 *  Prepared statements ..
	 */
	private PreparedStatement insertTRNSW;
	private PreparedStatement insertERRSW;
	private PreparedStatement insertInfo;
	private PreparedStatement insertAge;
	private PreparedStatement updateAge;
	private PreparedStatement getProcDt;
	private PreparedStatement insertUSOC;
	
	/*
	 * Common variables
	 */
	private String division, runDate;
	private Date sqlRunDate, procDate, infoDate;
	
	private boolean isInfoLoad;
	private static final int DAY_IN_SEC=86400;
	private DateFormat df = new SimpleDateFormat("yyyyMMdd");
	private DateFormat MMDDYYYY_format = new SimpleDateFormat("MMddyyyy");
	private String backupRecovery = null;
	private ArrayList triggers;
	private File currentFile;
	private int lineCount = 0;
	private USOCData usocData;
	
	private String fileName, fileToken, region;
	/*
	 * HashMap variables to contain the groups for various tables 
	 */
	private HashMap svcOrdAgeMap;
	private HashMap svcOrdTrnMap;
	private HashMap svcOrdErrMap;
	private HashMap svcOrdErrRecMap;
	
	
	private String fieldSeperator = StaticFieldKeys.SEMICOLON;
	List args = new ArrayList() ;
	
	
	/**
	 * Method will run prior processing of the file. Here we will form the actual INSERT statements 
	 * which need to be fired on to the database.
	 */

	public boolean preprocess() {
		 super.preprocess();

		  try {
				insertERRSW = connection.prepareStatement(" insert into  RABC_SVC_ORD_ERR (RUN_DATE, DIVISION, MKT_IND, SVC_ORD_TYPE, ERR_CD, SVC_ORD_ERR_CT) VALUES (?, ?, ?, ?, ?, ?)");
				insertTRNSW = connection.prepareStatement(" insert into RABC_SVC_ORD_TRN (RUN_DATE, DIVISION, MKT_IND, SVC_ORD_TYPE, SVC_ORD_INPUT_CT, SVC_ORD_CMPL_CT, SVC_ORD_ERR_CT, SVC_ORD_INTERIM_CT) VALUES (?, ?, ?, ?, ?, ?, ?, ?) ");				
				insertInfo = connection.prepareStatement(" insert into  RABC_SVC_ORD_INFO (RUN_DATE, DIVISION, MKT_IND, SVC_ORD_NUM, SVC_ORD_CREATE_DT, SVC_ORD_AGE_DAY) VALUES (?, ?, ?, ?, ?, ?) ");
				insertAge = connection.prepareStatement("insert into RABC_SVC_ORD_AGE (RUN_DATE, DIVISION, MKT_IND, AGE_3_DAY_CT, AGE_7_DAY_CT, AGE_14_DAY_CT, AGE_GT_14_DAY_CT) VALUES (?, ?, ?, ?, ?, ?, ?) ");
				updateAge = connection.prepareStatement(" UPDATE RABC_SVC_ORD_AGE SET AGE_3_DAY_CT = ? , AGE_7_DAY_CT = ? , AGE_14_DAY_CT = ? , AGE_GT_14_DAY_CT = ? where RUN_DATE = ? and DIVISION = ? and MKT_IND = ? ");
				insertUSOC = connection.prepareStatement(" insert into RABC_DAILY_USOC_ACTVT (RUN_DATE, DIVISION, USOC, BUS_TYPE, QTY, TOT_AMT) values (?, ?, ?, ?, ?, ?)");

				/*
				 * 
				 getProcDt = connection.prepareStatement(" SELECT MAX (proc_dt) PROC_DT, MIN (proc_dt) INFO_DATE, (MAX (proc_dt) - ?) * 86400 DIFF FROM rabc_cycle_calendar WHERE TO_CHAR (bill_rnd_dt, 'YYYYMM') = " +
						" (SELECT TO_CHAR (MAX (bill_rnd_dt), 'YYYYMM') rnd_dt FROM rabc_cycle_calendar WHERE TO_CHAR (proc_dt, 'YYYYMMDD') = TO_CHAR (?, 'YYYYMMDD'))");
				*/
				
				getProcDt = connection.prepareStatement("SELECT MAX (proc_dt) proc_dt, MIN (proc_dt) info_date, (MAX (proc_dt) - ?) * 86400 diff FROM rabc_cycle_calendar WHERE TO_CHAR (proc_dt, 'YYYYMM') = TO_CHAR (?, 'YYYYMM')");
				
			} catch (SQLException e) {
				severe(StaticErrorMsgKeys.PREPROCESS_ERROR + e.getMessage());
				e.printStackTrace();
				return false;
			}
			return true;
		}
	
	/**
	 * Method will run prior to actual processing of the file.
	 */
	public boolean preprocessFile(File file) {
		boolean success = super.preprocessFile(file);
		isInfoLoad = false;
		triggers = new ArrayList();
		fileToken = file.getName().substring(file.getName().indexOf("RA100F01"),file.getName().indexOf("RA100F01")+ 8);
		fileName = file.getName();
		region   =	file.getName().substring(0,2);
		
		if (success) {
			try {
				/*
				 * Check whether this file has been run before & if yes mark the backoutRecovery flag to "Y"
				 */
				lineCount = 0;

				backupRecovery = null;

				if (RabcLoadJobTrig.IsOriginalFileLoaded(connection, file,file.getName().length())) {
					backupRecovery = "Y";
				}
			} catch (Exception e) {
				severe(StaticErrorMsgKeys.PREPROCESSFILE_ERROR + StaticErrorMsgKeys.FILE_NAME_PARSING_ERROR + e);
				e.printStackTrace();
				return false;
			}
		}
		
		currentFile = file;
		svcOrdAgeMap = new HashMap();
		svcOrdErrMap = new HashMap();
		svcOrdErrRecMap = new HashMap();
		svcOrdTrnMap = new HashMap();
		return success;
	}

	/**
	 * Method will parse the line.
	 */
	protected int parseLine(String line) throws Exception {
		boolean status;
		String recortType = getRecordType(line);
		if ("H".equals(recortType)) {
			status = processHeaderRecord(line);
		} else if ("T".equals(recortType)) {
			status = processTrailerRecord(line);
		} else if ("D".equals(recortType)) {
			status = processDateRecord(line);
		} else{
			status = processDetailRecord(line);
		}
		
		if (status) {
			return SUCCESS;
		} else {
			return ERROR;
		}
	}
	
	private boolean processDetailRecord(String line) throws Exception {
		boolean status = true; 
		lineCount++;
		try{
			String[] lineFields = line.split(fieldSeperator);
			if (lineFields[1].trim().matches("0[1-6]"))			// process Service Order records ..
			{
				if(lineFields[3]!=null && !("".equals(lineFields[3].trim()))){
					if (!triggers.contains("SWSOTRN")) {
						triggers.add("SWSOTRN");
					}
					status = processServiceOrderRec(line);
				}
			}
			else if (lineFields[1].trim().matches("1[0-1]")) 	// process ERROR records
			{
				if(lineFields[5]!=null && !("".equals(lineFields[5].trim()))){
					if (!triggers.contains("SWSOERR")) {
						triggers.add("SWSOERR");
					}
					status = processErrorRec(line);
				}
			}
			else if (lineFields[1].trim().equals("19"))			// process AGE records
			{
					status = processAgeRec(line);
			}
			else 												// process USOC RECORDS
			{
				if (!triggers.contains("SWUSOCRT")) {
					triggers.add("SWUSOCRT");
				}
				status = processUSOCRec(line);
			}
		}catch (Exception e){
			severe(e.getMessage());
			e.printStackTrace();
			throw new Exception("Exception is from method processDetailRecord(line)" + e.getMessage());
		} 
		return status;	  
	}

	
	/**
	 * Method will run post to actual processing of the file.
	 */
	
	private boolean processServiceOrderRec(String line)throws Exception {
		
		String[] lineFields = line.split(fieldSeperator);
		String trnType = getTrnType(lineFields[1].trim());
		String mktInd = lineFields[2].trim();
		if (mktInd.equals("")) mktInd = "02";
		String svcOrdType = lineFields[3].trim();
		long svcOrdCount = Long.parseLong(lineFields[4].toString().trim())/1000000;

		SummaryData objSvcOrdTrn = new SummaryData(); 
		objSvcOrdTrn.setMktInd(mktInd);
		objSvcOrdTrn.setSvcOrdType(svcOrdType);

		/*
		 * Check whether the object is present in the map
		 */
		
		SummaryData objRef=(SummaryData)svcOrdTrnMap.get(objSvcOrdTrn);
	
			if (objRef != null) {
				if ("1".equals(trnType)) {
					objRef.setSVC_ORD_INPUT_CT(objRef.getSVC_ORD_INPUT_CT()+svcOrdCount)  ;	
				} else if ("2".equals(trnType)) {
					objRef.setSVC_ORD_CMPL_CT(objRef.getSVC_ORD_CMPL_CT()+svcOrdCount)  ;
				} else if ("3".equals(trnType)) {
					objRef.setSVC_ORD_INTERIM_CT(objRef.getSVC_ORD_INTERIM_CT()+svcOrdCount)  ;
				}
				
				svcOrdTrnMap.put(objRef, objRef);
			}else {
				if ("1".equals(trnType)) {
					objSvcOrdTrn.setSVC_ORD_INPUT_CT(svcOrdCount);	
				} else if ("2".equals(trnType)) {
					objSvcOrdTrn.setSVC_ORD_CMPL_CT(svcOrdCount);
				} else if ("3".equals(trnType)) {
					objSvcOrdTrn.setSVC_ORD_INTERIM_CT(svcOrdCount);
				}
				svcOrdTrnMap.put(objSvcOrdTrn, objSvcOrdTrn);
			}

		return true;
	}
	
	private boolean processErrorRec(String line)throws Exception {
		
		String[] lineFields = line.split(fieldSeperator);
		
		String mktInd = lineFields[2].trim();
		String svcOrdType = lineFields[3].trim();
		//long svcOrdErrCt = Long.parseLong(lineFields[4].trim()); // changed since data doesn't have count in file
		String errorCode = lineFields[5].trim();

		ErrData errData = new ErrData();
		errData.setMktInd(mktInd);
		errData.setSvcOrdType(svcOrdType);
		
		ErrData objRef=(ErrData)svcOrdErrMap.get(errData);
		
				if (objRef != null) {
					objRef.setSVC_ORD_ERR_CT(objRef.getSVC_ORD_ERR_CT() + 1);
					svcOrdErrMap.put(objRef, objRef);
				}else {
					errData.setSVC_ORD_ERR_CT(1);
					svcOrdErrMap.put(errData, errData);
				}
	
		SvcOrdErrRecData svcErrRecData = new SvcOrdErrRecData();
		svcErrRecData.setMktInd(mktInd);
		svcErrRecData.setSvcOrdType(svcOrdType);
		svcErrRecData.setSvcOrdErrCd(errorCode);
		
		SvcOrdErrRecData objRecRef = (SvcOrdErrRecData)svcOrdErrRecMap.get(svcErrRecData);
		
		if(objRecRef != null) {
			objRecRef.setSVC_ORD_ERR_CT(objRecRef.getSVC_ORD_ERR_CT()+1);
			svcOrdErrRecMap.put(objRecRef, objRecRef);
		}else {
			svcErrRecData.setSVC_ORD_ERR_CT(1);
			svcOrdErrRecMap.put(svcErrRecData, svcErrRecData);
		}
		
		/*
		try {
			//RUN_DATE, DIVISION, MKT_IND, SVC_ORD_TYPE, ERR_CD, SVC_ORD_ERR_CT
			insertERRSW.setDate(1, sqlRunDate);
			insertERRSW.setString(2, division);
			insertERRSW.setString(3, mktInd);
			insertERRSW.setString(4, svcOrdType);
			insertERRSW.setString(5, errorCode);
			insertERRSW.setLong(6, svcOrdErrCt);

			insertERRSW.addBatch();
			if (lineCount % 1000 == 0){
				insertERRSW.executeBatch();
			}
		}catch (SQLException sqle){
			severe(StaticErrorMsgKeys.INSERT_ERROR + sqle.getMessage());
			sqle.printStackTrace();
			throw new Exception("Exception is from method processDetailRecord(line)");
		}
		*/
		
		return true;
	}
	
	private boolean processAgeRec(String line)throws Exception {

		// PROCESS AGE/INFO records only if the runDate ( from date record ) is same as 
		// last working day of the Month !!    
		
		if (!isInfoLoad) 
				return true;
		
		if ("Y".equals(backupRecovery)){
			
			String tableName = "RABC_SVC_ORD_INFO";
			if(! PrepareTableForRerun.deleteTableData(connection, tableName, division, infoDate)){
				throw new Exception("Error occurred attempting to backup and recover for rerun for table: " + tableName);
			}
		}
			
		if (!triggers.contains("SWSOAGE")) 
				triggers.add("SWSOAGE");
		
		String[] lineFields = line.split(fieldSeperator);
		
		String mktInd = lineFields[2].trim(); 
		String svcOrdNum = lineFields[3].trim();
		String applicationDate = lineFields[4].trim();
		
		java.sql.Date svcCreatetDt ;
		DateFormat df = new SimpleDateFormat("yyyyMMdd");
		
		svcCreatetDt = new java.sql.Date(df.parse(applicationDate).getTime());

		// use lastday of the month to check for how old the Order is.
		long svcOrdAgeDay = ((procDate.getTime() - svcCreatetDt.getTime()) / (1000 * DAY_IN_SEC)) ;
		
		AgeData ageData = new AgeData() ;
		ageData.setMktInd(mktInd);
		AgeData objRef=(AgeData)svcOrdAgeMap.get(ageData);
		
		if (objRef != null) {
			if (svcOrdAgeDay >= 0 && svcOrdAgeDay <= 3) {
				objRef.setAGE_3_DAY_CT(objRef.getAGE_3_DAY_CT()+1)  ;	
			} else if (svcOrdAgeDay >= 4 && svcOrdAgeDay <= 7) {
				objRef.setAGE_7_DAY_CT(objRef.getAGE_7_DAY_CT()+1)  ;	
			} else if (svcOrdAgeDay >= 8 && svcOrdAgeDay <= 14)  {
				objRef.setAGE_14_DAY_CT(objRef.getAGE_14_DAY_CT()+1) ;
			}else if (svcOrdAgeDay > 14 ) {
				objRef.setAGE_GT_14_DAY_CT(objRef.getAGE_GT_14_DAY_CT()+1) ;
			}
			svcOrdAgeMap.put(objRef, objRef);
		}else {
			if (svcOrdAgeDay >= 0 && svcOrdAgeDay <= 3) {
				ageData.setAGE_3_DAY_CT(ageData.getAGE_3_DAY_CT()+1)  ;	
			} else if (svcOrdAgeDay >= 4 && svcOrdAgeDay <= 7) {
				ageData.setAGE_7_DAY_CT(ageData.getAGE_7_DAY_CT()+1)  ;	
			} else if (svcOrdAgeDay >= 8 && svcOrdAgeDay <= 14)  {
				ageData.setAGE_14_DAY_CT(ageData.getAGE_14_DAY_CT()+1) ;
			}else if (svcOrdAgeDay > 14 ) {
				ageData.setAGE_GT_14_DAY_CT(ageData.getAGE_GT_14_DAY_CT()+1) ;
			}
			
			svcOrdAgeMap.put(ageData, ageData);
		}
		
		try {
			insertInfo.setDate(1,infoDate);		
			insertInfo.setString(2,division);
			insertInfo.setString(3,mktInd);
			insertInfo.setString(4,svcOrdNum);
			insertInfo.setDate(5,svcCreatetDt);
			insertInfo.setLong(6,svcOrdAgeDay);
			insertInfo.addBatch();
			
			if (lineCount % 1000 == 0){
				insertInfo.executeBatch();
			}
		}catch (SQLException sqle){
			severe(StaticErrorMsgKeys.INSERT_ERROR + sqle.getMessage());
			sqle.printStackTrace();
			 throw new Exception("Exception is from method process16XTSOME"+ sqle);
		}
		
		return true;
	}
	
	private boolean processUSOCRec(String line)throws Exception {
		//table RABC_DAILY_USOC_ACTVT
		//records : RUN_DATE, DIVISION, USOC, BUS_TYPE, QTY, TOT_AMT
		
		String[] lineFields = line.split(fieldSeperator);
		
		//String sordDate = lineFields[1].trim();
		int WRInd = Integer.parseInt(lineFields[3].trim());
		int custType = 2; // default custType to BUSINESS (BUS). custType=1 RESIDENCE (RES) only if you get a 1 in first field.. This is as per MVS IA 
		if (!lineFields[5].trim().equals("") && lineFields[5].trim().substring(0,1).equals("1"))
			custType = 1;
		String USOC = lineFields[6].trim();
		long usocCnt = Long.parseLong(lineFields[8].trim())/1000000;
		double usocAmt = Double.parseDouble(lineFields[9].trim())/1000000;
		
		String busType = null;
		
		/* 
		 * BUS-TYPE conversion
		 * First byte 0f CUST-TYPE = 1 OR not 1
		 * CUST-TYPEFB EQ 1 and WRInd 01/02 (W/R) is '01' BUS-TYPE = 'RBUS'
		 * CUST-TYPEFB EQ 1 and WRInd 01/02 (W/R) is not '01' BUS-TYPE = 'BUS'
		 * CUST-TYPEFB not EQ 1 and WRInd 01/02 (W/R) is '01' BUS-TYPE = 'RRES'
		 * CUST-TYPEFB not EQ 1 and WRInd 01/02 (W/R) is not '01' BUS-TYPE = 'RES'
		*/
		
		if (custType == 1)
			if (WRInd == 1)
				busType = "RRES";
			else 
				busType = "RES";
		else 
			if (WRInd == 1)
				busType = "RBUS";
			else 
				busType = "BUS";
		
		
		if (usocData != null && usocData.getUsoc().equals(USOC) && usocData.getBusType().equals(busType)){
			usocData.setUsocCt(usocCnt);
			usocData.setUsocAmt(usocAmt);
		}else if(usocData == null){
			usocData = new USOCData();
			usocData.setBusType(busType);
			usocData.setUsoc(USOC);
			usocData.setUsocCt(usocCnt);
			usocData.setUsocAmt(usocAmt);

		} else { 
		
			//insertUSOC.setDate(1, new java.sql.Date(df.parse(sordDate).getTime()));
			insertUSOC.setDate(1, sqlRunDate);
			insertUSOC.setString(2,division);
			insertUSOC.setString(3,usocData.getUsoc());
			insertUSOC.setString(4,usocData.getBusType());
			insertUSOC.setLong(5,usocData.getUsocCt());
			insertUSOC.setDouble(6,usocData.getUsocAmt());
			insertUSOC.addBatch();
			
			if (lineCount % 1000 == 0){
				insertUSOC.executeBatch();
			}
			
			usocData = new USOCData();
			usocData.setBusType(busType);
			usocData.setUsoc(USOC);
			usocData.setUsocCt(usocCnt);
			usocData.setUsocAmt(usocAmt);
		}
		
		return true;
	}
	

	public boolean postprocessFile(File file, boolean success) {

		int batchCnt = 0;

		Set svcOrdAgeSet = svcOrdAgeMap.keySet();
		Set svcOrdTrnSet = svcOrdTrnMap.keySet();
		Set svcOrdErrRecSet = svcOrdErrRecMap.keySet();

		Iterator svcAgeIterator = svcOrdAgeSet.iterator();
		Iterator svcTrnIterator = svcOrdTrnSet.iterator();
		Iterator svcErrIterator = svcOrdErrRecSet.iterator();
		try{
			//Log the file information to EMCIS_EVENT_LOG and EMCIS_EVENT_LOG_DETAIL
			EmcisEventLogger emcisLogger = new EmcisEventLogger();
			String event_id = "RABC_"+fileToken+"_"+region;
            String host = NetUtil.getLocalHostName();
            String hostIP = NetUtil.getLocalIpAddress();
			int sequence = emcisLogger.getEMCISSequence(connection);
			emcisLogger.insertEventLog(connection, sequence, event_id, sqlRunDate, host, hostIP);
			emcisLogger.insertEventLogDetail(connection, sequence, "FileName", fileName);

		}catch (UnknownHostException e) {
            severe("Error getting EMCIS host information ", e);
        }
		if (success) {
			try {
				batchCnt = 0;
				while (svcTrnIterator.hasNext()) {
					batchCnt++;
					SummaryData objSvcOrdTrn = (SummaryData) svcTrnIterator.next();
					
					ErrData errData = new ErrData();
					errData.setMktInd(objSvcOrdTrn.getMktInd());
					errData.setSvcOrdType(objSvcOrdTrn.getSvcOrdType());
					
					ErrData objRef=(ErrData)svcOrdErrMap.get(errData);
					if (objRef != null) {
						objSvcOrdTrn.setSVC_ORD_ERR_CT(objRef.getSVC_ORD_ERR_CT());
					}
					
					insertTRNSW.setDate(1, sqlRunDate);
					insertTRNSW.setString(2, division);
					insertTRNSW.setString(3, objSvcOrdTrn.getMktInd());
					insertTRNSW.setString(4, objSvcOrdTrn.getSvcOrdType());
					insertTRNSW.setLong(5, objSvcOrdTrn.getSVC_ORD_INPUT_CT());
 					insertTRNSW.setLong(6, objSvcOrdTrn.getSVC_ORD_CMPL_CT());
					insertTRNSW.setLong(7, objSvcOrdTrn.getSVC_ORD_ERR_CT());
					insertTRNSW.setLong(8, objSvcOrdTrn.getSVC_ORD_INTERIM_CT());
					insertTRNSW.addBatch();

					if (batchCnt % 1000 == 0) {
						insertTRNSW.executeBatch();
					}

				}

				batchCnt = 0;
				while (svcAgeIterator.hasNext()) {
					batchCnt++;
					AgeData objSvcOrdAge = (AgeData) svcAgeIterator.next();

					insertAge.setDate(1, sqlRunDate);
					insertAge.setString(2, division);
					insertAge.setString(3, objSvcOrdAge.getMktInd());
					insertAge.setLong(4, objSvcOrdAge.getAGE_3_DAY_CT());
					insertAge.setLong(5, objSvcOrdAge.getAGE_7_DAY_CT());
					insertAge.setLong(6, objSvcOrdAge.getAGE_14_DAY_CT());
					insertAge.setLong(7, objSvcOrdAge.getAGE_GT_14_DAY_CT());
					insertAge.addBatch();

					if (batchCnt % 1000 == 0) {
						insertAge.executeBatch();
					}
				}
				
				//svcErrIterator
				
				batchCnt = 0;
				while (svcErrIterator.hasNext()) {
					batchCnt++;
					SvcOrdErrRecData objSvcOrdAge = (SvcOrdErrRecData) svcErrIterator.next();

//					RUN_DATE, DIVISION, MKT_IND, SVC_ORD_TYPE, ERR_CD, SVC_ORD_ERR_CT
					insertERRSW.setDate(1, sqlRunDate);
					insertERRSW.setString(2, division);
					insertERRSW.setString(3, objSvcOrdAge.getMktInd());
					insertERRSW.setString(4, objSvcOrdAge.getSvcOrdType());
					insertERRSW.setString(5, objSvcOrdAge.getSvcOrdErrCd());
					insertERRSW.setLong(6, objSvcOrdAge.getSVC_ORD_ERR_CT());

					insertERRSW.addBatch();
					if (lineCount % 1000 == 0){
						insertERRSW.executeBatch();
					}
				}

				/*
				 * Live Defect 57335: Last record was not added to the batch
				 */
				if (usocData != null){
					insertUSOC.setDate(1, sqlRunDate);
					insertUSOC.setString(2,division);
					insertUSOC.setString(3,usocData.getUsoc());
					insertUSOC.setString(4,usocData.getBusType());
					insertUSOC.setLong(5,usocData.getUsocCt());
					insertUSOC.setDouble(6,usocData.getUsocAmt());
					insertUSOC.addBatch();
				}
				
				if (!insertTrigger()) {
					severe(StaticErrorMsgKeys.POSTPROCESSFILE_ERROR
							+ StaticErrorMsgKeys.TIGGER_TABLE_INSERT_ERROR);
					success = false;
				}

				insertTRNSW.executeBatch();
				insertInfo.executeBatch();
				insertUSOC.executeBatch();
				insertERRSW.executeBatch();
				insertAge.executeBatch();
			} catch (SQLException sqle) {
				severe(StaticErrorMsgKeys.INSERT_ERROR + sqle.getMessage());
				sqle.printStackTrace();
				success = false;
			}
		}
		return super.postprocessFile(file, success);
	}
	
	private boolean insertTrigger() {
		if (lineCount > 0) {
			try {
				String query 	= "SELECT to_char(BILL_RND,'00') FROM RABC_CYCLE_CALENDAR WHERE PROC_DT = to_date('" + runDate + "','yyyyMMdd')";
				String billRnd	= RetrieveStaticInfo.getBillRnd(connection,query);
				if ("0".equals(billRnd) || "00".equals(billRnd) || "".equals(billRnd.trim())){
					billRnd = "0";
				}
				
				for (int i = 0; i < triggers.size(); i++) {
					if (!RabcLoadJobTrig.insertTrigger(connection, currentFile.getName().substring(5, currentFile.getName().length()), currentFile.getName(), (String) triggers.get(i), division, MMDDYYYY_format.format(sqlRunDate) , backupRecovery, billRnd)) {
						return false;
					}
				}
				
			} catch (Exception e) {
				severe(StaticErrorMsgKeys.POSTPROCESSFILE_ERROR + StaticErrorMsgKeys.NORECORD_RABC_CYCLE_CALENDAR + e);
				e.printStackTrace();
				return false;
			}
		}
		return true;
		
	}
	
	public boolean postprocess(boolean success) {
		try {
			insertTRNSW.close();
			insertERRSW.close();
			insertInfo.close();
			insertAge.close();
			updateAge.close();

		} catch (SQLException e) {
			severe(StaticErrorMsgKeys.POSTPROCESS_ERROR
					+ StaticErrorMsgKeys.SQL_CLOSE_ERROR + e);
			success = false;
		}
		return super.postprocess(success);
	}
	
	private String getTrnType(String SEQ_NBR) {
		String trnType = "0" ; 
		if (SEQ_NBR.equals("01") ||  SEQ_NBR.equals("02") ) 
			trnType = "1" ;
		else if (SEQ_NBR.equals("03") ||  SEQ_NBR.equals("04") )
			trnType = "2" ; 
		else if (SEQ_NBR.equals("05") ||  SEQ_NBR.equals("06") )
			trnType = "3" ;
		
		return trnType ;
	}
	 
	private String getRecordType(String line) {
		
		String recordType = null;
		String[] lineFields = line.split(fieldSeperator);
		
		if ("HEADER".equals(lineFields[0].trim())) {
			recordType = "H";
		} else if ("TRAILER".equals(lineFields[0].trim())) {
			recordType = "T";
		} else if ("07".equals(lineFields[1].trim())){ 
			recordType = "D";
		}else {
			recordType = "X";
		}
		return recordType;
	}
	
	private boolean processHeaderRecord(String line) throws Exception {
		boolean success = true;
		//HEADER ;SW;T ;06142006;17:30:45;
		String[] lineFields = line.split(fieldSeperator);
		division = lineFields[2].trim();
		
		args.add(division.trim()) ;

		
		return success;
	}
	
	private boolean processTrailerRecord(String line) throws Exception {
		//TRAILER;SW;T ;06142006;17:30:45;0012345678;
		String[] lineFields = line.split(fieldSeperator);
		int totalRecords = Integer.parseInt(lineFields[5]);
		
		if (totalRecords == lineCount) {
			return true;
		} else {
			throw new Exception("Record count mismatch, trailer record shows " + totalRecords + ", but " + lineCount + " records exist on file " + currentFile.getName());
		}
	}
	
	private boolean processDateRecord(String line)  throws Exception {
		
		lineCount++;
		//RA11OCCS;07;YYYYMMDD;
		
		boolean success = true;
		String[] lineFields = line.split(fieldSeperator);

		runDate = lineFields[2].trim();
		
		sqlRunDate = new java.sql.Date(df.parse(runDate).getTime());

		// check if the file is a rerun. If so, cleanup tables before process ..
		if ("Y".equals(backupRecovery)){

			String tableName = "RABC_SVC_ORD_LOAD";
			success = PrepareTableForRerun.deleteTableData(connection,tableName,division,sqlRunDate);
			tableName = "RABC_SVC_ORD_ERR";
			success = PrepareTableForRerun.deleteTableData(connection, tableName, division, sqlRunDate);
			tableName = "RABC_SVC_ORD_TRN";
			success = PrepareTableForRerun.deleteTableData(connection, tableName, division, sqlRunDate);
			tableName = "RABC_SVC_ORD_AGE";
			success = PrepareTableForRerun.deleteTableData(connection, tableName, division, sqlRunDate);
			tableName = "RABC_DAILY_USOC_ACTVT";
			success = PrepareTableForRerun.deleteTableData(connection, tableName, division, sqlRunDate);
			
		}
		
		try {
			
			ResultSet rs = null;
			getProcDt.setDate(1,sqlRunDate);
			getProcDt.setDate(2,sqlRunDate);
			rs = getProcDt.executeQuery();
			if (rs.next()){
				// check if sub query returned a non null value.. it will do so, if there is no matching proc_dt in cycle_calendar for MVS date record.  
				if (rs.getString("DIFF") != null && !rs.getString("DIFF").equals("") && rs.getLong("DIFF") < DAY_IN_SEC){ 
					procDate = rs.getDate("PROC_DT");
					infoDate = rs.getDate("INFO_DATE");
					isInfoLoad = true;
				}
			}
			
		}catch (SQLException e) {
			severe("Exception while retrieving max non holiday PROC_DT for current month " );
			e.printStackTrace();
			success = false;
		}
	
		return success;
	}
		
		
	 
	 
}
