/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.admin.alert.rule;

import java.util.ArrayList;
import java.util.List;

import com.att.bac.rabc.Column;
import com.att.bac.rabc.PickList;

/**
 * This is a Data Object for Alert Rule Description Main Page. 
 * 
 * @author Shashank weginwar - SW3562
 */
public class AlertItem {
	private String itemName;					//Alert Item Name
	private List columnList;					//List of all columns
	private SupplementType supplementType;		//Supplementry Type Object
	private String alertType;					//Alert Type	
	private String warningIndicator;			//Warning Indicator
	private List alertTypeList;					//List of alert types e.g. <=H, >=L, etc.
	private String allowUpdate;					//To check whether new or update
	private String reportLinkData;				// To get the presentation Id & Alert rule name in case of trending rule
	private String alertUnit;
	
	/**
	 * Constructor to initialise all List variables & allowUpdate variable.
	 */
	public AlertItem() {
		this.columnList = new ArrayList();
		this.alertTypeList = new ArrayList();
		this.allowUpdate = "N";
	}

	/**
	 * @return Returns the alertType.
	 */
	public String getAlertType() {
		return alertType;
	}
	/**
	 * @param alertType The alertType to set.
	 */
	public void setAlertType(String alertType) {
		this.alertType = alertType;
	}
	/**
	 * @return Returns the columnList.
	 */
	public List getColumnList() {
		return columnList;
	}
	/**
	 * @param columnList The columnList to add.
	 */
	public void addColumn(Column column) {
		this.columnList.add(column);
	}
	/**
	 * @param columnList The columnList to add.
	 */
	public void addColumn(int i, Column column) {
		this.columnList.add(i,column);
	}
	/**
	 * @return Returns the itemName.
	 */
	public String getItemName() {
		return itemName;
	}
	/**
	 * @param itemName The itemName to set.
	 */
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	/**
	 * @return Returns the warningIndicator.
	 */
	public String getWarningIndicator() {
		return warningIndicator;
	}
	/**
	 * @param warningIndicator The warningIndicator to set.
	 */
	public void setWarningIndicator(String warningIndicator) {
		this.warningIndicator = warningIndicator;
	}
	/**
	 * @return Returns the alertTypeList.
	 */
	public List getAlertTypeList() {
		return alertTypeList;
	}
	/**
	 * @param alertTypeList The alertTypeList to add.
	 */
	public void addAlertType(PickList type) {
		this.alertTypeList.add(type);
	}
	/**
	 * @return Returns the supplementType.
	 */
	public SupplementType getSupplementType() {
		return supplementType;
	}
	/**
	 * @param supplementType The supplementType to set.
	 */
	public void setSupplementType(SupplementType supplementType) {
		this.supplementType = supplementType;
	}
	/**
	 * @return Returns the allowUpdate.
	 */
	public String getAllowUpdate() {
		return allowUpdate;
	}
	/**
	 * @param allowUpdate The allowUpdate to set.
	 */
	public void setAllowUpdate(String allowUpdate) {
		this.allowUpdate = allowUpdate;
	}
	/**
	 * @return Returns the reportLinkData.
	 */
	public String getReportLinkData() {
		return reportLinkData;
	}
	/**
	 * @param reportLinkData The reportLinkData to set.
	 */
	public void setReportLinkData(String reportLinkData) {
		this.reportLinkData = reportLinkData;
	}

	/**
	 * @return the alertUnit
	 */
	public String getAlertUnit() {
		return alertUnit;
	}

	/**
	 * @param alertUnit the alertUnit to set
	 */
	public void setAlertUnit(String alertUnit) {
		this.alertUnit = alertUnit;
	}
}
