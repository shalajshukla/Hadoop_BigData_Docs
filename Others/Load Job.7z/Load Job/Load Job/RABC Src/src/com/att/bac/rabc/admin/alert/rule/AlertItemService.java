/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.admin.alert.rule;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.att.bac.rabc.Column;
import com.att.bac.rabc.DataTblDdlBean;
import com.att.bac.rabc.PickList;
import com.att.bac.rabc.RABCConstantsLists;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.StaticDataLoader;
import com.att.bac.rabc.WebDataLink;
import com.att.bac.rabc.WebDataLinkDAO;
import com.att.bac.rabc.admin.PresnCalcElem;

/**
 * This is a service class to execute the logic of Alert Item.
 * 
 * @author Shashank Weginwar - SW3562
 */
public class AlertItemService {

	private static final Logger logger = Logger.getLogger(AlertItemService.class);
	private static AlertItemService alertItemService; 
	
	protected static final String q_data = "SELECT ALERT_RULE, ALERT_TYPE, ALERT_ITEM_DDL_NAME, ALERT_ITEM_DDL_DATA, " +
	"ALERT_ITEM_AVG_NAME, ALERT_PROC_TBL, ALERT_PROC_AVG_TBL, ALERT_CREATE_IND, ALERT_MSG_SUPP_DATA_IND, " +
	"ALERT_THRSHLD_DFLT_IND, ALERT_CALC_NUM, ALERT_TBL_SEL_NUM, PARTI_REF_ID FROM RABC_ALERT_PROC " +
	"WHERE ALERT_RULE = ''{0}''";
	
	protected static final String q_dropdowns = "select ALERT_RULE, FILE_ID, ALERT_ITEM_NAME, ALERT_ITEM_IND, " +
	"ALERT_DATE_IND, ALERT_ITEM_EXTRCT_TBL, PARTI_REF_ID, ALERT_ITEM_KEY_LVL, ALERT_ITEM_KEY1_NAME, " +
	"ALERT_ITEM_KEY2_NAME, ALERT_ITEM_KEY3_NAME, ALERT_ITEM_KEY4_NAME, ALERT_ITEM_KEY5_NAME, ALERT_ITEM_DATA_CT, " +
	"ALERT_ITEM1_DDL_NAME, ALERT_ITEM1_SUM_IND, ALERT_ITEM2_DDL_NAME, ALERT_ITEM2_SUM_IND, ALERT_ITEM3_DDL_NAME, " +
	"ALERT_ITEM3_SUM_IND, ALERT_ITEM4_DDL_NAME, ALERT_ITEM4_SUM_IND, ALERT_ITEM5_DDL_NAME, ALERT_ITEM5_SUM_IND, "+  
	"ALERT_ITEM6_DDL_NAME, ALERT_ITEM6_SUM_IND, ALERT_ITEM7_DDL_NAME, ALERT_ITEM7_SUM_IND, ALERT_ITEM8_DDL_NAME, " +
	"ALERT_ITEM8_SUM_IND, ALERT_ITEM9_DDL_NAME, ALERT_ITEM9_SUM_IND, ALERT_ITEM10_DDL_NAME, ALERT_ITEM10_SUM_IND, " +
	"ALERT_ITEM11_DDL_NAME, ALERT_ITEM11_SUM_IND, ALERT_ITEM12_DDL_NAME, ALERT_ITEM12_SUM_IND, ALERT_ITEM13_DDL_NAME, " +
	"ALERT_ITEM13_SUM_IND, ALERT_ITEM14_DDL_NAME, ALERT_ITEM14_SUM_IND, ALERT_ITEM15_DDL_NAME, ALERT_ITEM15_SUM_IND, " +
	"VIEW_NAME, ALERT_ITEM_ORD, ALERT_ITEM1_DDL_NAME_IND, ALERT_ITEM2_DDL_NAME_IND, ALERT_ITEM3_DDL_NAME_IND, " +
	"ALERT_ITEM4_DDL_NAME_IND, ALERT_ITEM5_DDL_NAME_IND, ALERT_ITEM6_DDL_NAME_IND, ALERT_ITEM7_DDL_NAME_IND, " +
	"ALERT_ITEM8_DDL_NAME_IND, ALERT_ITEM9_DDL_NAME_IND, ALERT_ITEM10_DDL_NAME_IND, ALERT_ITEM11_DDL_NAME_IND, " +
	"ALERT_ITEM12_DDL_NAME_IND, ALERT_ITEM13_DDL_NAME_IND, ALERT_ITEM14_DDL_NAME_IND, ALERT_ITEM15_DDL_NAME_IND " +
	"FROM RABC_TRACK_FILE_DTL WHERE ALERT_RULE = ''{0}'' ORDER BY ALERT_ITEM_ORD";
	
	protected static final String q_columns = "SELECT PARTI_REF_ID, EXTRCT_TYPE, EXTRCT_RNDUP_IND, EXTRCT_ITEM_NAME, " +
	"EXTRCT_TO_TBL, FILE_ITEM1_NAME, EXTRCT_ITEM1_NAME, FILE_ITEM2_NAME, EXTRCT_ITEM2_NAME, FILE_ITEM3_NAME, " +
	"EXTRCT_ITEM3_NAME, FILE_ITEM4_NAME, EXTRCT_ITEM4_NAME, FILE_ITEM5_NAME, EXTRCT_ITEM5_NAME, FILE_ITEM6_NAME, " +
	"EXTRCT_ITEM6_NAME, FILE_ITEM7_NAME, EXTRCT_ITEM7_NAME, FILE_ITEM8_NAME, EXTRCT_ITEM8_NAME, FILE_ITEM9_NAME, " +
	"EXTRCT_ITEM9_NAME, EXTRCT_ITEM1_CALC_IND, EXTRCT_ITEM2_CALC_IND, EXTRCT_ITEM3_CALC_IND, EXTRCT_ITEM4_CALC_IND, " +
	"EXTRCT_ITEM5_CALC_IND, EXTRCT_ITEM6_CALC_IND, EXTRCT_ITEM7_CALC_IND, EXTRCT_ITEM8_CALC_IND, EXTRCT_ITEM9_CALC_IND " +
	"FROM RABC_EXTRCT_BUILD_RULE WHERE PARTI_REF_ID = {0}";
	
	protected static final String getRelAlerts = "SELECT ALERT_RULE FROM RABC_ALERT_RULE WHERE " +
	"ALERT_RULE_STATUS != ''DELETED'' AND ALERT_RULE IN(SELECT DISTINCT ALERT_RULE FROM RABC_TRIG_CONVERT WHERE " +
	"FILE_ID IN (''{0}'')) AND ALERT_RULE != ''{1}''";
	
	protected static final String getSelectedRelAlerts = "SELECT A.ALERT_RULE FROM RABC_ALERT_RULE A, " +
	"RABC_ALERT_SUMY_PRESN B WHERE B.ALERT_RULE = ''{0}'' AND B.WEBID = ''RABCPSF00011'' AND A.PRESN_ID = B.ASOC_PRESN_ID " +
	"AND B.ASOC_PRESN_ID != ''{1}''";
	
	protected static final String getSelSuppType = "SELECT ALERT_RULE, ALERT_ITEM_NAME, ALERT_ITEM_DDL_NAME, " +
	"SUPP_SEQ_NUM, TBL_NAME, SUPP_ITEM_NAME, SUPP_ITEM_DDL_NAME, SUPP_PRESN_NAME, SUPP_PIC_LINK " +
	"FROM RABC_ALERT_SUPP_RULE WHERE ALERT_RULE = ''{0}'' ORDER BY ALERT_ITEM_NAME";

	private static final String getAllColumnNames = "SELECT ALERT_PROC_TBL, TBL_DDL_NAME FROM RABC_DATA_TBL_DDL " +
	"WHERE ALERT_PROC_TBL IN (''{0}'') AND TBL_DDL_DATA_TYPE NOT IN (''2'',''3'',''4'',''D'') ORDER BY ALERT_PROC_TBL, " +
	"TBL_DDL_NAME";
			
	private static final String getkeynames = "SELECT DISTINCT ALERT_PROC_TBL, TBL_DDL_NAME FROM RABC_DATA_TBL_DDL " +
	"WHERE ALERT_PROC_TBL IN (''{0}'') AND TBL_DDL_DATA_TYPE != ''1'' ORDER BY ALERT_PROC_TBL, TBL_DDL_NAME";
	
	private static final String qNeg = "SELECT EXTRCT_ITEM1_CALC_IND, EXTRCT_ITEM2_CALC_IND," +
	"EXTRCT_ITEM3_CALC_IND, EXTRCT_ITEM4_CALC_IND, EXTRCT_ITEM5_CALC_IND, EXTRCT_ITEM6_CALC_IND, EXTRCT_ITEM7_CALC_IND," +
	"EXTRCT_ITEM8_CALC_IND, EXTRCT_ITEM9_CALC_IND FROM RABC_EXTRCT_BUILD_RULE WHERE PARTI_REF_ID = ''{0}'' AND ROWNUM = ''1''";
	
	private static final String viewAndTableName = "SELECT DISTINCT VIEW_NAME, TABLE_NAME FROM RABC_VIEW ORDER BY VIEW_NAME";
	
	private static final String getMaxSupp = "SELECT MAX(SUPP_SEQ_NUM) AS MAXSUPP FROM RABC_ALERT_SUPP_RULE WHERE " +
	"ALERT_ITEM_NAME = ''{0}'' AND ALERT_RULE = ''{1}''";
	
	protected static final String getAllDesc = "SELECT ALERT_RULE, PARTI_REF_ID, PRESN_ID, " +
	"FILE_VERIF_IND, DATA_EXTRCT_IND, DATA_CALC_IND, CALC_RULE, WARNING_IND, AVG_IND, ALERT_MSG_IND, " +
	"ALERT_SEQ_NUM_IND, ALERT_TIME_IND, ALERT_DASH_FRESH_IND, ALERT_DESC, ALERT_EXEC_DATE, ALERT_KEY_LVL, " +
	"ALERT_KEY1_NAME, ALERT_KEY2_NAME, ALERT_KEY3_NAME, ALERT_KEY4_NAME, ALERT_KEY5_NAME, ALERT_FILE_CT, " +
	"ASOC_FILE_ID, ALERT_RULE_PRESN_IND, DIVISION_NAME_KEY_LVL, DB_NODE_ID, ALERT_RULE_STATUS, EFF_DATE, " +
	"STD_TYPE, ALERT_EXEMPT_IND, USER_ID, TIME_STAMP, ALERT_RULE_CREATE_IND, ALERT_DATA_KEEP, ALERT_RULE_TYPE, ALERT_MNTH_EXEC_DAY, ALERT_MNTH_EXEC_BILL_RND " +
	"FROM RABC_ALERT_RULE WHERE ALERT_RULE = ''{0}''";
	
	protected static final String qryReportLink = "SELECT PRESN_ID, WEBID, EXEC_PRESN_SEQ_NUM, LINK_NUM, LINK_DDL_NAME, LINK_TO_PGM, LINK_PRESN_ID, "
												+ "LINK_NUM_PARM,LINK_PARM1,LINK_PARM2,LINK_PARM3,LINK_PARM4,LINK_PARM5,LINK_PARM6,LINK_PARM7,"
												+ "LINK_PARM8,LINK_PARM9,LINK_PARM10,LINK_PARM11,LINK_PARM12 FROM RABC_WEB_DATA_LINK "
												+ "WHERE PRESN_ID = {0} AND WEBID = ''RABCPSF00013'' AND LINK_NUM IN "
												+ "(SELECT DATA_LINK_NUM FROM RABC_ALERT_RULE_PRESN_ELEM WHERE PRESN_ID = {1} "
												+ "AND DATA_DDL_NAME IN (SELECT ALERT_ITEM_DDL_DATA FROM RABC_ALERT_PROC WHERE ALERT_RULE IN "
												+ "(SELECT DISTINCT ALERT_RULE FROM RABC_ALERT_RULE WHERE PRESN_ID ={2}) AND ALERT_ITEM_DDL_NAME = ''{3}''))";
	
	protected static final String getCalculationsMap = "select distinct calc_tbl, presn_calc_name, presn_format_code, calc_elem_formula " 
		+ "from rabc_presn_calc_elem " 
		+ "where calc_tbl is not null and presn_calc_name not like '%_PREV'"
		+ "order by calc_tbl";
	
	protected static final String getPresnUnitInd_Trend = "SELECT PRESN_NAME, PRESN_UNIT_IND FROM RABC_ALERT_RULE_PRESN_ELEM WHERE PRESN_ID = {0}";
		
	/**
	 * Synchronized method to return the instance of AlertItemService object.
	 * It checks the existance of the instance of AlertItemService and if it does not exists
	 * then creates one instance of AlertItemService and returns otherwise it returns the
	 * existing instance of AlertItemService.
	 * 
	 * @return AlertItemService
	 */
	public static synchronized AlertItemService getAlertItemService(){
		if (alertItemService == null){
			alertItemService = new AlertItemService();
		}
		return alertItemService;
	}
	
	/**
	 * Method will build the list of alert items for Tracking Rule using information obtained from following tables
	 * 1) rabc_alert_proc
	 * 2) rabc_extrct_build_rule
	 * 3) rabc_track_file_dtl
	 * 
	 * rabc_alert_proc determines the number of alert items.
	 * rabc_extrct_build_rule gives the tables per item.
	 * rabc_track_file_dtl gives the information pertaining to each table entry across all alert items.
	 * 
	 * While getting the table related details from rabc_track_file_dtl we will create a hashmap with key as 
	 * combination of table name & alertItemOrder.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertProcList
	 * @param trackFileDtlList
	 * @param extractBuildRuleList
	 * @param alertRule
	 * @return List
	 */
	protected List getAlertItemList(Connection connection, List failures, List alertProcList,List trackFileDtlList, List extractBuildRuleList, AlertRule alertRule){
		List alertItemList = new ArrayList();
		HashMap extractBuildRuleMap = getExtractBuildRuleMap(extractBuildRuleList);
		HashMap trackFileDtlMap = getTrackFileDtlMap(trackFileDtlList);
		HashMap unitIndMap  = getUnitIndMap(connection,failures,alertRule);
		HashMap viewAndTableMap = getViewAndTableMap(connection, failures);
		
		List alertRuleNameList = new ArrayList();
		int count = 0;

		if (alertProcList.size()>0){
			AlertProc tempAlertProc = (AlertProc)alertProcList.get(0);
			alertRuleNameList.add(tempAlertProc.getAlertRule());
			
			HashMap suppItemMap;
			if ("TRACK".equals(alertRule.getAlertRuleType())){
				suppItemMap = getSupplementaryItems(connection,failures,alertRuleNameList,"Track");
			}else {
				suppItemMap = getSupplementaryItems(connection,failures,alertRuleNameList,"Trend");
			}

			for (int i = 0; i < alertProcList.size(); i++) {
				AlertProc alertProc = (AlertProc)alertProcList.get(i);
				AlertItem alertItem = new AlertItem();

				alertItem.setItemName(alertProc.getAlertItemDdlName());
				alertItem.setAlertType(alertProc.getAlertType().trim());
				
				if ("Y".equals(alertProc.getAlertCreateInd())){
					alertItem.setWarningIndicator("Y");
				}else {
					alertItem.setWarningIndicator(null);
				}
				
				if ("TRACK".equals(alertRule.getAlertRuleType())){
					for (int j=0;j < RABCConstantsLists.getRABCConstantsLists().getAlertTypeListForTrack().size();j++){
						PickList alertType = (PickList)RABCConstantsLists.getRABCConstantsLists().getAlertTypeListForTrack().get(j);
						alertItem.addAlertType(alertType);
					}
				} else {
					for (int j=0;j < RABCConstantsLists.getRABCConstantsLists().getAlertTypeListForTrend().size();j++){
						PickList alertType = (PickList)RABCConstantsLists.getRABCConstantsLists().getAlertTypeListForTrend().get(j);
						alertItem.addAlertType(alertType);
					}
				}
				/*
				 * Get the corresponding extract build rule from the MAP
				 * CALL A DIFFERENT METHOD FOR TRENDING RULE WHICH WILL GET THE COLUMNS IN AN ALERT ITEM 
				 * FROM TRACK_FILE_DTL DIRECTLY
				 */
				if ("TRACK".equals(alertRule.getAlertRuleType())){
					ExtractBuildRule extractBuildRule = (ExtractBuildRule)extractBuildRuleMap.get(alertItem.getItemName());
					alertItem = getAlertItem(alertItem,trackFileDtlMap,extractBuildRule);
				} else {
					count++;
					alertItem = getAlertItemForTrending (alertItem,trackFileDtlList,count, viewAndTableMap);
					/*
					 * Call the method to get the report link details
					 */
					alertItem.setReportLinkData(getReportLinkDetails(connection,failures,alertItem, alertRule));
					if (unitIndMap!=null){
						String presnUnitInd = (String) unitIndMap.get(alertProc.getAlertItemDdlName());
						if (presnUnitInd!=null){
							alertItem.setAlertUnit(presnUnitInd);
						}
					}
				}
				
				SupplementType supplementType = (SupplementType)suppItemMap.get(alertItem.getItemName());
				if (supplementType==null){
					supplementType = new SupplementType();
					supplementType.setAlertItemName(alertItem.getItemName());
				}
				alertItem.setSupplementType(supplementType);
				alertItemList.add(alertItem);
			}
		}

		List resultAlertItemList = new ArrayList();
		
		if (alertItemList.size()>0){
			for (int i = 0; i < alertItemList.size(); i++) {
				AlertItem currAlertItem = (AlertItem) alertItemList.get(i);
				SupplementType currItemSuppType = (SupplementType)currAlertItem.getSupplementType();
				List suppTypeOptionsList = getSupplementTypeOptionsList(alertItemList,currAlertItem.getItemName());

				for (int j = 0; j < suppTypeOptionsList.size(); j++){
						currItemSuppType.addSupplementTypeOption((PickList)suppTypeOptionsList.get(j));
				}
				resultAlertItemList.add(currAlertItem);
			}
		}

		return resultAlertItemList;
	}

	/**
	 * Method will build the get the item related details for each table for Trending rule. In case of trending
	 * rule we can assume that there will be simply 1 record as columns belong to same table. Based on the alert item
	 * being built, we will use corresponding column values.
	 * 
	 * @param alertItem
	 * @param trackFileDtlList
	 * @param count
	 * @return AlertItem
	 */
	private AlertItem getAlertItemForTrending (AlertItem alertItem, List trackFileDtlList, int count, HashMap viewAndTableMap){
		TrackFileDtl trackFileDtl = new TrackFileDtl();
		trackFileDtl = (TrackFileDtl)trackFileDtlList.get(0);
		
		switch (count) {
			case 1:
				if (trackFileDtl.getAlertItem1DdlName()!=null){
					Column column = new Column();
					column.setColumnTBLDDLName(trackFileDtl.getAlertItem1DdlName());
					
					String tableOrView = trackFileDtl.getAlertItemExtrctTbl();
					String check = tableOrView.substring(0,3);
					if(check.equals("VW_")){
						String viewName = trackFileDtl.getAlertItemExtrctTbl();
						column.setColumnAlertProcTBL((viewAndTableMap.get(viewName)).toString());
					}else {
						column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
					}						

					if (trackFileDtl.getViewName()!=null){
						column.setColumnViewName(trackFileDtl.getViewName());
					}
					if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem1DdlNameInd())) {
						column.setColumnTBLDataType("CAL");
					}
					column.setAllowUpdate("N");
					alertItem.addColumn(column);
				}
			
			case 2:
				if (trackFileDtl.getAlertItem2DdlName()!=null){
					Column column = new Column();
					column.setColumnTBLDDLName(trackFileDtl.getAlertItem2DdlName());
					
					String tableOrView = trackFileDtl.getAlertItemExtrctTbl();
					String check = tableOrView.substring(0,3);
					if(check.equals("VW_")){
						String viewName = trackFileDtl.getAlertItemExtrctTbl();
						column.setColumnAlertProcTBL((viewAndTableMap.get(viewName)).toString());
					}else {
						column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
					}
					
					if (trackFileDtl.getViewName()!=null){
						column.setColumnViewName(trackFileDtl.getViewName());
					}
					if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem2DdlNameInd())) {
						column.setColumnTBLDataType("CAL");
					}
					column.setAllowUpdate("N");
					alertItem.addColumn(column);
				}
			
			case 3:
				if (trackFileDtl.getAlertItem3DdlName()!=null){
					Column column = new Column();
					column.setColumnTBLDDLName(trackFileDtl.getAlertItem3DdlName());
					
					String tableOrView = trackFileDtl.getAlertItemExtrctTbl();
					String check = tableOrView.substring(0,3);
					if(check.equals("VW_")){
						String viewName = trackFileDtl.getAlertItemExtrctTbl();
						column.setColumnAlertProcTBL((viewAndTableMap.get(viewName)).toString());
					}else {
						column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
					}
					
					if (trackFileDtl.getViewName()!=null){
						column.setColumnViewName(trackFileDtl.getViewName());
					}
					if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem3DdlNameInd())) {
						column.setColumnTBLDataType("CAL");
					}
					column.setAllowUpdate("N");
					alertItem.addColumn(column);
				}
			
			case 4:
				if (trackFileDtl.getAlertItem4DdlName()!=null){
					Column column = new Column();
					column.setColumnTBLDDLName(trackFileDtl.getAlertItem4DdlName());
					
					String tableOrView = trackFileDtl.getAlertItemExtrctTbl();
					String check = tableOrView.substring(0,3);
					if(check.equals("VW_")){
						String viewName = trackFileDtl.getAlertItemExtrctTbl();
						column.setColumnAlertProcTBL((viewAndTableMap.get(viewName)).toString());
					}else {
						column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
					}
					
					if (trackFileDtl.getViewName()!=null){
						column.setColumnViewName(trackFileDtl.getViewName());
					}
					if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem4DdlNameInd())) {
						column.setColumnTBLDataType("CAL");
					}
					column.setAllowUpdate("N");
					alertItem.addColumn(column);
				}
			
			case 5:
				if (trackFileDtl.getAlertItem5DdlName()!=null){
					Column column = new Column();
					column.setColumnTBLDDLName(trackFileDtl.getAlertItem5DdlName());
					
					String tableOrView = trackFileDtl.getAlertItemExtrctTbl();
					String check = tableOrView.substring(0,3);
					if(check.equals("VW_")){
						String viewName = trackFileDtl.getAlertItemExtrctTbl();
						column.setColumnAlertProcTBL((viewAndTableMap.get(viewName)).toString());
					}else {
						column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
					}
					
					if (trackFileDtl.getViewName()!=null){
						column.setColumnViewName(trackFileDtl.getViewName());
					}
					if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem5DdlNameInd())) {
						column.setColumnTBLDataType("CAL");
					}
					column.setAllowUpdate("N");
					alertItem.addColumn(column);
				}
			
			case 6:
				if (trackFileDtl.getAlertItem6DdlName()!=null){
					Column column = new Column();
					column.setColumnTBLDDLName(trackFileDtl.getAlertItem6DdlName());
					
					String tableOrView = trackFileDtl.getAlertItemExtrctTbl();
					String check = tableOrView.substring(0,3);
					if(check.equals("VW_")){
						String viewName = trackFileDtl.getAlertItemExtrctTbl();
						column.setColumnAlertProcTBL((viewAndTableMap.get(viewName)).toString());
					}else {
						column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
					}
					
					if (trackFileDtl.getViewName()!=null){
						column.setColumnViewName(trackFileDtl.getViewName());
					}
					if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem6DdlNameInd())) {
						column.setColumnTBLDataType("CAL");
					}
					column.setAllowUpdate("N");
					alertItem.addColumn(column);
				}
			
			case 7:
				if (trackFileDtl.getAlertItem7DdlName()!=null){
					Column column = new Column();
					column.setColumnTBLDDLName(trackFileDtl.getAlertItem7DdlName());
					
					String tableOrView = trackFileDtl.getAlertItemExtrctTbl();
					String check = tableOrView.substring(0,3);
					if(check.equals("VW_")){
						String viewName = trackFileDtl.getAlertItemExtrctTbl();
						column.setColumnAlertProcTBL((viewAndTableMap.get(viewName)).toString());
					}else {
						column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
					}
					
					if (trackFileDtl.getViewName()!=null){
						column.setColumnViewName(trackFileDtl.getViewName());
					}
					if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem7DdlNameInd())) {
						column.setColumnTBLDataType("CAL");
					}
					column.setAllowUpdate("N");
					alertItem.addColumn(column);
				}
			
			case 8:
				if (trackFileDtl.getAlertItem8DdlName()!=null){
					Column column = new Column();
					column.setColumnTBLDDLName(trackFileDtl.getAlertItem8DdlName());
					
					String tableOrView = trackFileDtl.getAlertItemExtrctTbl();
					String check = tableOrView.substring(0,3);
					if(check.equals("VW_")){
						String viewName = trackFileDtl.getAlertItemExtrctTbl();
						column.setColumnAlertProcTBL((viewAndTableMap.get(viewName)).toString());
					}else {
						column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
					}
					
					if (trackFileDtl.getViewName()!=null){
						column.setColumnViewName(trackFileDtl.getViewName());
					}
					if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem8DdlNameInd())) {
						column.setColumnTBLDataType("CAL");
					}
					column.setAllowUpdate("N");
					alertItem.addColumn(column);
				}
			
			case 9:
				if (trackFileDtl.getAlertItem9DdlName()!=null){
					Column column = new Column();
					column.setColumnTBLDDLName(trackFileDtl.getAlertItem9DdlName());
					
					String tableOrView = trackFileDtl.getAlertItemExtrctTbl();
					String check = tableOrView.substring(0,3);
					if(check.equals("VW_")){
						String viewName = trackFileDtl.getAlertItemExtrctTbl();
						column.setColumnAlertProcTBL((viewAndTableMap.get(viewName)).toString());
					}else {
						column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
					}
					
					if (trackFileDtl.getViewName()!=null){
						column.setColumnViewName(trackFileDtl.getViewName());
					}
					if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem9DdlNameInd())) {
						column.setColumnTBLDataType("CAL");
					}
					column.setAllowUpdate("N");
					alertItem.addColumn(column);
				}
			
			case 10:
				if (trackFileDtl.getAlertItem10DdlName()!=null){
					Column column = new Column();
					column.setColumnTBLDDLName(trackFileDtl.getAlertItem10DdlName());
					
					String tableOrView = trackFileDtl.getAlertItemExtrctTbl();
					String check = tableOrView.substring(0,3);
					if(check.equals("VW_")){
						String viewName = trackFileDtl.getAlertItemExtrctTbl();
						column.setColumnAlertProcTBL((viewAndTableMap.get(viewName)).toString());
					}else {
						column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
					}
					
					if (trackFileDtl.getViewName()!=null){
						column.setColumnViewName(trackFileDtl.getViewName());
					}
					if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem10DdlNameInd())) {
						column.setColumnTBLDataType("CAL");
					}
					column.setAllowUpdate("N");
					alertItem.addColumn(column);
				}
				
			case 11:
				if (trackFileDtl.getAlertItem11DdlName()!=null){
					Column column = new Column();
					column.setColumnTBLDDLName(trackFileDtl.getAlertItem11DdlName());
					
					String tableOrView = trackFileDtl.getAlertItemExtrctTbl();
					String check = tableOrView.substring(0,3);
					if(check.equals("VW_")){
						String viewName = trackFileDtl.getAlertItemExtrctTbl();
						column.setColumnAlertProcTBL((viewAndTableMap.get(viewName)).toString());
					}else {
						column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
					}
					
					if (trackFileDtl.getViewName()!=null){
						column.setColumnViewName(trackFileDtl.getViewName());
					}
					if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem11DdlNameInd())) {
						column.setColumnTBLDataType("CAL");
					}
					column.setAllowUpdate("N");
					alertItem.addColumn(column);
				}
			
			case 12:
				if (trackFileDtl.getAlertItem12DdlName()!=null){
					Column column = new Column();
					column.setColumnTBLDDLName(trackFileDtl.getAlertItem12DdlName());
					
					String tableOrView = trackFileDtl.getAlertItemExtrctTbl();
					String check = tableOrView.substring(0,3);
					if(check.equals("VW_")){
						String viewName = trackFileDtl.getAlertItemExtrctTbl();
						column.setColumnAlertProcTBL((viewAndTableMap.get(viewName)).toString());
					}else {
						column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
					}
					
					if (trackFileDtl.getViewName()!=null){
						column.setColumnViewName(trackFileDtl.getViewName());
					}
					if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem12DdlNameInd())) {
						column.setColumnTBLDataType("CAL");
					}
					column.setAllowUpdate("N");
					alertItem.addColumn(column);
				}
			
			case 13:
				if (trackFileDtl.getAlertItem13DdlName()!=null){
					Column column = new Column();
					column.setColumnTBLDDLName(trackFileDtl.getAlertItem13DdlName());
					
					String tableOrView = trackFileDtl.getAlertItemExtrctTbl();
					String check = tableOrView.substring(0,3);
					if(check.equals("VW_")){
						String viewName = trackFileDtl.getAlertItemExtrctTbl();
						column.setColumnAlertProcTBL((viewAndTableMap.get(viewName)).toString());
					}else {
						column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
					}
					
					if (trackFileDtl.getViewName()!=null){
						column.setColumnViewName(trackFileDtl.getViewName());
					}
					if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem13DdlNameInd())) {
						column.setColumnTBLDataType("CAL");
					}
					column.setAllowUpdate("N");
					alertItem.addColumn(column);
				}
			
			case 14:
				if (trackFileDtl.getAlertItem14DdlName()!=null){
					Column column = new Column();
					column.setColumnTBLDDLName(trackFileDtl.getAlertItem14DdlName());
					
					String tableOrView = trackFileDtl.getAlertItemExtrctTbl();
					String check = tableOrView.substring(0,3);
					if(check.equals("VW_")){
						String viewName = trackFileDtl.getAlertItemExtrctTbl();
						column.setColumnAlertProcTBL((viewAndTableMap.get(viewName)).toString());
					}else {
						column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
					}
					
					if (trackFileDtl.getViewName()!=null){
						column.setColumnViewName(trackFileDtl.getViewName());
					}
					if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem14DdlNameInd())) {
						column.setColumnTBLDataType("CAL");
					}
					column.setAllowUpdate("N");
					alertItem.addColumn(column);
				}
			
			case 15:
				if (trackFileDtl.getAlertItem15DdlName()!=null){
					Column column = new Column();
					column.setColumnTBLDDLName(trackFileDtl.getAlertItem15DdlName());
					
					String tableOrView = trackFileDtl.getAlertItemExtrctTbl();
					String check = tableOrView.substring(0,3);
					if(check.equals("VW_")){
						String viewName = trackFileDtl.getAlertItemExtrctTbl();
						column.setColumnAlertProcTBL((viewAndTableMap.get(viewName)).toString());
					}else {
						column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
					}
					
					if (trackFileDtl.getViewName()!=null){
						column.setColumnViewName(trackFileDtl.getViewName());
					}
					if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem15DdlNameInd())) {
						column.setColumnTBLDataType("CAL");
					}
					column.setAllowUpdate("N");
					alertItem.addColumn(column);
				}
			default:
				if (trackFileDtl.getAlertItem1DdlName()!=null){
					Column column = new Column();
					column.setColumnTBLDDLName(trackFileDtl.getAlertItem1DdlName());
					
					String tableOrView = trackFileDtl.getAlertItemExtrctTbl();
					String check = tableOrView.substring(0,3);
					if(check.equals("VW_")){
						String viewName = trackFileDtl.getAlertItemExtrctTbl();
						column.setColumnAlertProcTBL((viewAndTableMap.get(viewName)).toString());
					}else {
						column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
					}
					
					if (trackFileDtl.getViewName()!=null){
						column.setColumnViewName(trackFileDtl.getViewName());
					}
					if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem1DdlNameInd())) {
						column.setColumnTBLDataType("CAL");
					}
					column.setAllowUpdate("N");
					alertItem.addColumn(column);
				}
		}
		
		return alertItem;
	}
	
	/**
	 * Method will build the get the item related details for each table for Tracking rule. Based on the current 
	 * alert item being built, we will get the details for all tables for that alert item. For this we will use
	 * corresponding record in rabc_extrct_build_rule to know how many columns were selected in 1st step.
	 * 
	 * @param alertItem
	 * @param trackFileDtlMap
	 * @param extractBuildRule
	 * @return AlertItem
	 */
	private AlertItem getAlertItem(AlertItem alertItem, HashMap trackFileDtlMap,ExtractBuildRule extractBuildRule){
		Column column;
		TrackFileDtl trackFileDtl;

		if (extractBuildRule.getFileItem1Name()!=null && extractBuildRule.getExtrctItem1Name() != null){
			trackFileDtl = (TrackFileDtl)trackFileDtlMap.get(extractBuildRule.getFileItem1Name()+ "~1");
			column = getColumn(trackFileDtl,extractBuildRule.getExtrctItem1Name());
			column.setNegIndicator(extractBuildRule.getExtrctItem1CalcInd());
			alertItem.addColumn(column);
		}
		
		if (extractBuildRule.getFileItem2Name()!=null && extractBuildRule.getExtrctItem2Name() != null){
			trackFileDtl = (TrackFileDtl)trackFileDtlMap.get(extractBuildRule.getFileItem2Name()+ "~2");
			column = getColumn(trackFileDtl,extractBuildRule.getExtrctItem2Name());
			column.setNegIndicator(extractBuildRule.getExtrctItem2CalcInd());
			alertItem.addColumn(column);
		}
		
		if (extractBuildRule.getFileItem3Name()!=null && extractBuildRule.getExtrctItem3Name() != null){
			trackFileDtl = (TrackFileDtl)trackFileDtlMap.get(extractBuildRule.getFileItem3Name()+ "~3");
			column = getColumn(trackFileDtl,extractBuildRule.getExtrctItem3Name());
			column.setNegIndicator(extractBuildRule.getExtrctItem3CalcInd());
			alertItem.addColumn(column);
		}
		
		if (extractBuildRule.getFileItem4Name()!=null && extractBuildRule.getExtrctItem4Name() != null){
			trackFileDtl = (TrackFileDtl)trackFileDtlMap.get(extractBuildRule.getFileItem4Name()+ "~4");
			column = getColumn(trackFileDtl,extractBuildRule.getExtrctItem4Name());
			column.setNegIndicator(extractBuildRule.getExtrctItem4CalcInd());
			alertItem.addColumn(column);
		}
		
		if (extractBuildRule.getFileItem5Name()!=null && extractBuildRule.getExtrctItem5Name() != null){
			trackFileDtl = (TrackFileDtl)trackFileDtlMap.get(extractBuildRule.getFileItem5Name()+ "~5");
			column = getColumn(trackFileDtl,extractBuildRule.getExtrctItem5Name());
			column.setNegIndicator(extractBuildRule.getExtrctItem5CalcInd());
			alertItem.addColumn(column);
		}
		
		if (extractBuildRule.getFileItem6Name()!=null && extractBuildRule.getExtrctItem6Name() != null){
			trackFileDtl = (TrackFileDtl)trackFileDtlMap.get(extractBuildRule.getFileItem6Name()+ "~6");
			column = getColumn(trackFileDtl,extractBuildRule.getExtrctItem6Name());
			column.setNegIndicator(extractBuildRule.getExtrctItem6CalcInd());
			alertItem.addColumn(column);
		}
		
		if (extractBuildRule.getFileItem7Name()!=null && extractBuildRule.getExtrctItem7Name() != null){
			trackFileDtl = (TrackFileDtl)trackFileDtlMap.get(extractBuildRule.getFileItem7Name()+ "~7");
			column = getColumn(trackFileDtl,extractBuildRule.getExtrctItem7Name());
			column.setNegIndicator(extractBuildRule.getExtrctItem7CalcInd());
			alertItem.addColumn(column);
		}
		
		if (extractBuildRule.getFileItem8Name()!=null && extractBuildRule.getExtrctItem8Name() != null){
			trackFileDtl = (TrackFileDtl)trackFileDtlMap.get(extractBuildRule.getFileItem8Name()+ "~8");
			column = getColumn(trackFileDtl,extractBuildRule.getExtrctItem8Name());
			column.setNegIndicator(extractBuildRule.getExtrctItem8CalcInd());
			alertItem.addColumn(column);
		}
		
		if (extractBuildRule.getFileItem9Name()!=null && extractBuildRule.getExtrctItem9Name() != null){
			trackFileDtl = (TrackFileDtl)trackFileDtlMap.get(extractBuildRule.getFileItem9Name()+ "~9");
			column = getColumn(trackFileDtl,extractBuildRule.getExtrctItem9Name());
			column.setNegIndicator(extractBuildRule.getExtrctItem9CalcInd());
			alertItem.addColumn(column);
		}
		
		return alertItem;
	}
	
	/**
	 * Method will build the get the column details for Tracking rule. Based on the current 
	 * alert item being built, we will get the details for the column selected for a particular table entry selected
	 * in step 1.
	 * 
	 * @param trackFileDtl
	 * @param itemName
	 * @return Column
	 */
	private Column getColumn(TrackFileDtl trackFileDtl, String itemName){
		Column column = new Column();
		int endIndex = itemName.lastIndexOf("_");
		String temp = itemName.substring(0,endIndex);
		endIndex = temp.lastIndexOf("_");
		String itemNumberString = itemName.substring(10,endIndex);
		int itemNumber = Integer.parseInt(itemNumberString);
		
		switch (itemNumber) {
			case 1:
				column.setColumnTBLDDLName(trackFileDtl.getAlertItem1DdlName());
				column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
				if (trackFileDtl.getViewName()!=null){
					column.setColumnViewName(trackFileDtl.getViewName());
				}
				if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem1DdlNameInd())) {
					column.setColumnTBLDataType("CAL");
				}
				column.setAllowUpdate("N");
				break;
			case 2:
				column.setColumnTBLDDLName(trackFileDtl.getAlertItem2DdlName());
				column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
				if (trackFileDtl.getViewName()!=null){
					column.setColumnViewName(trackFileDtl.getViewName());
				}
				if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem2DdlNameInd())) {
					column.setColumnTBLDataType("CAL");
				}
				column.setAllowUpdate("N");
				break;
			case 3:
				column.setColumnTBLDDLName(trackFileDtl.getAlertItem3DdlName());
				column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
				if (trackFileDtl.getViewName()!=null){
					column.setColumnViewName(trackFileDtl.getViewName());
				}
				if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem3DdlNameInd())) {
					column.setColumnTBLDataType("CAL");
				}
				column.setAllowUpdate("N");
				break;
			case 4:
				column.setColumnTBLDDLName(trackFileDtl.getAlertItem4DdlName());
				column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
				if (trackFileDtl.getViewName()!=null){
					column.setColumnViewName(trackFileDtl.getViewName());
				}
				if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem4DdlNameInd())) {
					column.setColumnTBLDataType("CAL");
				}
				column.setAllowUpdate("N");
				break;
			case 5:
				column.setColumnTBLDDLName(trackFileDtl.getAlertItem5DdlName());
				column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
				if (trackFileDtl.getViewName()!=null){
					column.setColumnViewName(trackFileDtl.getViewName());
				}
				if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem5DdlNameInd())) {
					column.setColumnTBLDataType("CAL");
				}
				column.setAllowUpdate("N");
				break;
			case 6:
				column.setColumnTBLDDLName(trackFileDtl.getAlertItem6DdlName());
				column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
				if (trackFileDtl.getViewName()!=null){
					column.setColumnViewName(trackFileDtl.getViewName());
				}
				if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem6DdlNameInd())) {
					column.setColumnTBLDataType("CAL");
				}
				column.setAllowUpdate("N");
				break;
			case 7:
				column.setColumnTBLDDLName(trackFileDtl.getAlertItem7DdlName());
				column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
				if (trackFileDtl.getViewName()!=null){
					column.setColumnViewName(trackFileDtl.getViewName());
				}
				if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem7DdlNameInd())) {
					column.setColumnTBLDataType("CAL");
				}
				column.setAllowUpdate("N");
				break;
			case 8:
				column.setColumnTBLDDLName(trackFileDtl.getAlertItem8DdlName());
				column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
				if (trackFileDtl.getViewName()!=null){
					column.setColumnViewName(trackFileDtl.getViewName());
				}
				if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem8DdlNameInd())) {
					column.setColumnTBLDataType("CAL");
				}
				column.setAllowUpdate("N");
				break;
			case 9:
				column.setColumnTBLDDLName(trackFileDtl.getAlertItem9DdlName());
				column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
				if (trackFileDtl.getViewName()!=null){
					column.setColumnViewName(trackFileDtl.getViewName());
				}
				if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem9DdlNameInd())) {
					column.setColumnTBLDataType("CAL");
				}
				column.setAllowUpdate("N");
				break;
			case 10:
				column.setColumnTBLDDLName(trackFileDtl.getAlertItem10DdlName());
				column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
				if (trackFileDtl.getViewName()!=null){
					column.setColumnViewName(trackFileDtl.getViewName());
				}
				if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem10DdlNameInd())) {
					column.setColumnTBLDataType("CAL");
				}
				column.setAllowUpdate("N");
				break;
			case 11:
				column.setColumnTBLDDLName(trackFileDtl.getAlertItem11DdlName());
				column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
				if (trackFileDtl.getViewName()!=null){
					column.setColumnViewName(trackFileDtl.getViewName());
				}
				if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem11DdlNameInd())) {
					column.setColumnTBLDataType("CAL");
				}
				column.setAllowUpdate("N");
				break;
			case 12:
				/*
				 * Bug fix for alert item no 12 not showing the correct column name. It was using getAlertItem3DdlName()
				 * instead of getAlertItem12DdlName()
				 */
				column.setColumnTBLDDLName(trackFileDtl.getAlertItem12DdlName());
				column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
				if (trackFileDtl.getViewName()!=null){
					column.setColumnViewName(trackFileDtl.getViewName());
				}
				if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem12DdlNameInd())) {
					column.setColumnTBLDataType("CAL");
				}
				column.setAllowUpdate("N");
				break;
			case 13:
				column.setColumnTBLDDLName(trackFileDtl.getAlertItem13DdlName());
				column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
				if (trackFileDtl.getViewName()!=null){
					column.setColumnViewName(trackFileDtl.getViewName());
				}
				if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem13DdlNameInd())) {
					column.setColumnTBLDataType("CAL");
				}
				column.setAllowUpdate("N");
				break;
			case 14:
				column.setColumnTBLDDLName(trackFileDtl.getAlertItem14DdlName());
				column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
				if (trackFileDtl.getViewName()!=null){
					column.setColumnViewName(trackFileDtl.getViewName());
				}
				if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem14DdlNameInd())) {
					column.setColumnTBLDataType("CAL");
				}
				column.setAllowUpdate("N");
				break;
			case 15:
				column.setColumnTBLDDLName(trackFileDtl.getAlertItem15DdlName());
				column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
				if (trackFileDtl.getViewName()!=null){
					column.setColumnViewName(trackFileDtl.getViewName());
				}
				if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem15DdlNameInd())) {
					column.setColumnTBLDataType("CAL");
				}
				column.setAllowUpdate("N");
				break;
			default:
				column.setColumnTBLDDLName(trackFileDtl.getAlertItem1DdlName());
				column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
				if (trackFileDtl.getViewName()!=null){
					column.setColumnViewName(trackFileDtl.getViewName());
				}
				if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem1DdlNameInd())) {
					column.setColumnTBLDataType("CAL");
				}
				column.setAllowUpdate("N");
				break;
		}
		
		return column;
	}
		
	/**
	 * Method builds a Hash Map of extrct_build_rule objects, 1 for each alert rule item with key as the item name.
	 * 
	 * @param extractBuildRuleList
	 * @return HashMap
	 */
	private HashMap getExtractBuildRuleMap(List extractBuildRuleList){
		HashMap extractBuildRuleMap = new HashMap();
		
		for (int i=0;i<extractBuildRuleList.size();i++){
			ExtractBuildRule extractBuildRule = (ExtractBuildRule)extractBuildRuleList.get(i);
			extractBuildRuleMap.put(extractBuildRule.getExtrctItemName(),extractBuildRule);
		}
		
		return extractBuildRuleMap;
	}
	
	/**
	 * Method builds a HashMap of Track_File_Dtl objects with keys as the table + alert Item Order [which is basically
	 * the order in which they appear in the alertItem].
	 * 
	 * @param trackFileDtlList
	 * @return HashMap
	 */
	private HashMap getTrackFileDtlMap(List trackFileDtlList){
		HashMap trackFileDtlMap = new HashMap();
		
		for (int i=0;i<trackFileDtlList.size();i++){
			TrackFileDtl trackFileDtl = (TrackFileDtl)trackFileDtlList.get(i);
			if(trackFileDtl.getViewName() != null){
				trackFileDtlMap.put(trackFileDtl.getViewName() + "~" + trackFileDtl.getAlertItemOrd(),trackFileDtl);
			}else {
				trackFileDtlMap.put(trackFileDtl.getAlertItemExtrctTbl() + "~" + trackFileDtl.getAlertItemOrd(),trackFileDtl);
			}
		}
		return trackFileDtlMap;
	}
	
	/**
	 * Method to get the options for supplementType field for a given alertItem.
	 * 
	 * @param alertItemList
	 * @param currAlertItemName
	 * @return List
	 */
	private List getSupplementTypeOptionsList(List alertItemList,String currAlertItemName){
		List supplementTypeOptionsList = new ArrayList();
		
		for (int i=0;i<alertItemList.size();i++){
			AlertItem alertItem = (AlertItem)alertItemList.get(i);
			
			if(alertItem.getItemName()!= null && currAlertItemName != null){
				if (!alertItem.getItemName().equals(currAlertItemName) && !"".equals(currAlertItemName.trim()) && !"Enter Column Name".equalsIgnoreCase(alertItem.getItemName()) ){
					supplementTypeOptionsList.add(new PickList(alertItem.getItemName(),alertItem.getItemName()));
				}
			}
		}
		
		return supplementTypeOptionsList;
	}
	
	/**
	 * Gets the list of supplementary items for a particular alert item & returns a HashMap with supp items 
	 * with key as alert Item name.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertRuleNameList
	 * @param trackTrend
	 * @return HashMap
	 */
	protected HashMap getSupplementaryItems(Connection connection,List failures, List alertRuleNameList,String trackTrend) {
		HashMap supplementTypeMap = new HashMap();		
		String selectSQL = getSelSuppType;
		String previousAlertItemName = null;
		String currentAlertItemName = null;
		String alertRuleName = null;
		List joinList = new ArrayList();
		
		AlertSuppRuleDAO alertSuppRuleDAO = new AlertSuppRuleDAO();	
		List args = new ArrayList();

		args.add(0,alertRuleNameList.get(0));
		List suppItems = alertSuppRuleDAO.get(connection,failures,args,selectSQL);
		List suppItemNamesList = new ArrayList();
		SupplementType supplementType = new SupplementType();
		
		HashMap joinMap = new HashMap();
		for(int i = 0; i < suppItems.size(); i++){
			AlertSuppRule alertSuppRule = (AlertSuppRule) suppItems.get(i);
			List args1 = new ArrayList();
			args1.add(alertSuppRule.getAlertItemName());
			args1.add(alertSuppRule.getAlertRule());
			int maxSupp = getMaxSupp(connection, failures, args1);
			supplementType = new SupplementType();
			currentAlertItemName = alertSuppRule.getAlertItemName();

			if (!joinMap.containsKey(currentAlertItemName) ) {
				joinList = new ArrayList();
				joinMap.put(currentAlertItemName, supplementType);
            } else {
            	supplementType = (SupplementType) joinMap.get(currentAlertItemName);
            }
			
			if ("Track".equals(trackTrend) || "1".equals(trackTrend)){
				joinList.add(alertSuppRule.getSuppItemName());
			}else {
				joinList.add(alertSuppRule.getSuppPresnName());
			}
			
			int suppSeqNum = alertSuppRule.getSuppSeqNum();
			if(suppSeqNum == maxSupp){
				String [] selectedSupplementType = new String[joinList.size()];
				
				for (int j=0;j<joinList.size();j++){
					selectedSupplementType[j] = (String)joinList.get(j);
				}
				supplementType.setAlertItemName(currentAlertItemName);
				supplementType.setSelectedSupplementType(selectedSupplementType);
			}
		}
		return joinMap;
	}
	
	/**
	 * Returns maximum SUPP_SEQ_NUM from RABC_ALERT_SUPP_RULE table for the given ALERT_ITEM_NAME AND ALERT_RULE.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return int
	 */
	protected int getMaxSupp(Connection connection,List failureList, List args){
		String selectSQL = getMaxSupp;
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		int maxSupp = 1;
		try
		{
			MessageFormat mf = new MessageFormat(selectSQL);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
						
			while(rs.next()){
				maxSupp = rs.getInt("MAXSUPP");
				break;
			}
		} 
		catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
			return 1;
		} 
		finally{
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		return (maxSupp);
	}
	
	/**
	 * Returns the HashMap containing VIEW_NAME as key and TABLE_NAME as value.
	 * 
	 * @param connection
	 * @param failures
	 * @return HashMap
	 */
	private HashMap getViewAndTableMap (Connection connection, List failures){
		HashMap viewAndTableMap = new HashMap();
		String selectSQL = viewAndTableName;
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		List arguments = new ArrayList();
		try
		{
			MessageFormat mf = new MessageFormat(selectSQL);
			prepareStatement = mf.format((String[])arguments.toArray(new String[arguments.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			
			while(rs.next()){
				viewAndTableMap.put(rs.getString("VIEW_NAME"),rs.getString("TABLE_NAME"));
			}
		} 
		catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
			return null;
		} 
		finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
		return viewAndTableMap;
	}
	
	/**
	 * Returns AlertRuleDefinition object for track and trend rule.
	 * 
	 * @param connection
	 * @param failures
	 * @param trackFileDtlList
	 * @param alertRuleDefinition
	 * @param alertRule
	 * @return AlertRuleDefinition
	 */
	protected AlertRuleDefinition updateTableList(Connection connection, List failures, List trackFileDtlList, AlertRuleDefinition alertRuleDefinition, AlertRule alertRule){
		HashMap viewAndTableMap = getViewAndTableMap(connection, failures);
		if ("TRACK".equals(alertRule.getAlertRuleType())){
			//For Tracking Rule.
			for (int i=0;i<trackFileDtlList.size();i++){
				TrackFileDtl trackFileDtl = (TrackFileDtl)trackFileDtlList.get(i);
				Column column = new Column();
				if (trackFileDtl.getAlertItemInd()!= null){
					if ("L".equals(trackFileDtl.getAlertItemInd().trim())){
						column.setColumnTBLDDLName(trackFileDtl.getAlertItem1DdlName());
						if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem1DdlNameInd())) {
							column.setColumnTBLDataType("CAL");
						}
						String tableOrView = trackFileDtl.getAlertItemExtrctTbl();
						String check = tableOrView.substring(0,3);
						if(check.equals("VW_")){
							String viewName = trackFileDtl.getAlertItemExtrctTbl();
							column.setColumnAlertProcTBL((viewAndTableMap.get(viewName)).toString());
						}else {
							column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
						}						
						if (trackFileDtl.getViewName()!=null){
							column.setColumnViewName(trackFileDtl.getViewName());
						}
						alertRuleDefinition.addLHSColumn(column);
					} else {
						column.setColumnTBLDDLName(trackFileDtl.getAlertItem1DdlName());
						if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem1DdlNameInd())) {
							column.setColumnTBLDataType("CAL");
						}
						String tableOrView = trackFileDtl.getAlertItemExtrctTbl();
						String check = tableOrView.substring(0,3);
						if(check.equals("VW_")){
							String viewName = trackFileDtl.getAlertItemExtrctTbl();
							column.setColumnAlertProcTBL((viewAndTableMap.get(viewName)).toString());
						}else {
							column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
						}
						if (trackFileDtl.getViewName()!=null){
							column.setColumnViewName(trackFileDtl.getViewName());
						}
						alertRuleDefinition.addRHSColumn(column);
					}
				}
			}
		}else{
			//For Trending Rule.
			
			TrackFileDtl trackFileDtl;
			trackFileDtl = (TrackFileDtl)trackFileDtlList.get(0);
			
			if (trackFileDtl.getAlertItem1DdlName()!=null){
				Column column = new Column();
				column.setColumnTBLDDLName(trackFileDtl.getAlertItem1DdlName());
				if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem1DdlNameInd())) {
					column.setColumnTBLDataType("CAL");
				}
				String tableOrView = trackFileDtl.getAlertItemExtrctTbl();
				String check = tableOrView.substring(0,3);
				if(check.equals("VW_")){
					String viewName = trackFileDtl.getAlertItemExtrctTbl();
					column.setColumnAlertProcTBL((viewAndTableMap.get(viewName)).toString());
				}else {
					column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
				}
				if (trackFileDtl.getViewName()!=null){
					column.setColumnViewName(trackFileDtl.getViewName());
				}
				column.setAllowUpdate("N");
				alertRuleDefinition.addLHSColumn(column);
			}
			
			if (trackFileDtl.getAlertItem2DdlName()!=null){
				Column column = new Column();
				column.setColumnTBLDDLName(trackFileDtl.getAlertItem2DdlName());
				if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem2DdlNameInd())) {
					column.setColumnTBLDataType("CAL");
				}
				String tableOrView = trackFileDtl.getAlertItemExtrctTbl();
				String check = tableOrView.substring(0,3);
				if(check.equals("VW_")){
					String viewName = trackFileDtl.getAlertItemExtrctTbl();
					column.setColumnAlertProcTBL((viewAndTableMap.get(viewName)).toString());
				}else {
					column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
				}
				if (trackFileDtl.getViewName()!=null){
					column.setColumnViewName(trackFileDtl.getViewName());
				}
				column.setAllowUpdate("N");
				alertRuleDefinition.addLHSColumn(column);
			}
			
			if (trackFileDtl.getAlertItem3DdlName()!=null){
				Column column = new Column();
				column.setColumnTBLDDLName(trackFileDtl.getAlertItem3DdlName());
				if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem3DdlNameInd())) {
					column.setColumnTBLDataType("CAL");
				}
				String tableOrView = trackFileDtl.getAlertItemExtrctTbl();
				String check = tableOrView.substring(0,3);
				if(check.equals("VW_")){
					String viewName = trackFileDtl.getAlertItemExtrctTbl();
					column.setColumnAlertProcTBL((viewAndTableMap.get(viewName)).toString());
				}else {
					column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
				}
				if (trackFileDtl.getViewName()!=null){
					column.setColumnViewName(trackFileDtl.getViewName());
				}
				column.setAllowUpdate("N");
				alertRuleDefinition.addLHSColumn(column);
			}
			
			if (trackFileDtl.getAlertItem4DdlName()!=null){
				Column column = new Column();
				column.setColumnTBLDDLName(trackFileDtl.getAlertItem4DdlName());
				if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem4DdlNameInd())) {
					column.setColumnTBLDataType("CAL");
				}
				String tableOrView = trackFileDtl.getAlertItemExtrctTbl();
				String check = tableOrView.substring(0,3);
				if(check.equals("VW_")){
					String viewName = trackFileDtl.getAlertItemExtrctTbl();
					column.setColumnAlertProcTBL((viewAndTableMap.get(viewName)).toString());
				}else {
					column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
				}
				if (trackFileDtl.getViewName()!=null){
					column.setColumnViewName(trackFileDtl.getViewName());
				}
				column.setAllowUpdate("N");
				alertRuleDefinition.addLHSColumn(column);
			}
			
			if (trackFileDtl.getAlertItem5DdlName()!=null){
				Column column = new Column();
				column.setColumnTBLDDLName(trackFileDtl.getAlertItem5DdlName());
				if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem5DdlNameInd())) {
					column.setColumnTBLDataType("CAL");
				}
				String tableOrView = trackFileDtl.getAlertItemExtrctTbl();
				String check = tableOrView.substring(0,3);
				if(check.equals("VW_")){
					String viewName = trackFileDtl.getAlertItemExtrctTbl();
					column.setColumnAlertProcTBL((viewAndTableMap.get(viewName)).toString());
				}else {
					column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
				}
				if (trackFileDtl.getViewName()!=null){
					column.setColumnViewName(trackFileDtl.getViewName());
				}
				column.setAllowUpdate("N");
				alertRuleDefinition.addLHSColumn(column);
			}
			
			if (trackFileDtl.getAlertItem6DdlName()!=null){
				Column column = new Column();
				column.setColumnTBLDDLName(trackFileDtl.getAlertItem6DdlName());
				if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem6DdlNameInd())) {
					column.setColumnTBLDataType("CAL");
				}
				String tableOrView = trackFileDtl.getAlertItemExtrctTbl();
				String check = tableOrView.substring(0,3);
				if(check.equals("VW_")){
					String viewName = trackFileDtl.getAlertItemExtrctTbl();
					column.setColumnAlertProcTBL((viewAndTableMap.get(viewName)).toString());
				}else {
					column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
				}
				if (trackFileDtl.getViewName()!=null){
					column.setColumnViewName(trackFileDtl.getViewName());
				}
				column.setAllowUpdate("N");
				alertRuleDefinition.addLHSColumn(column);
			}
			
			if (trackFileDtl.getAlertItem7DdlName()!=null){
				Column column = new Column();
				column.setColumnTBLDDLName(trackFileDtl.getAlertItem7DdlName());
				if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem7DdlNameInd())) {
					column.setColumnTBLDataType("CAL");
				}
				String tableOrView = trackFileDtl.getAlertItemExtrctTbl();
				String check = tableOrView.substring(0,3);
				if(check.equals("VW_")){
					String viewName = trackFileDtl.getAlertItemExtrctTbl();
					column.setColumnAlertProcTBL((viewAndTableMap.get(viewName)).toString());
				}else {
					column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
				}
				if (trackFileDtl.getViewName()!=null){
					column.setColumnViewName(trackFileDtl.getViewName());
				}
				column.setAllowUpdate("N");
				alertRuleDefinition.addLHSColumn(column);
			}
			
			if (trackFileDtl.getAlertItem8DdlName()!=null){
				Column column = new Column();
				column.setColumnTBLDDLName(trackFileDtl.getAlertItem8DdlName());
				if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem8DdlNameInd())) {
					column.setColumnTBLDataType("CAL");
				}
				String tableOrView = trackFileDtl.getAlertItemExtrctTbl();
				String check = tableOrView.substring(0,3);
				if(check.equals("VW_")){
					String viewName = trackFileDtl.getAlertItemExtrctTbl();
					column.setColumnAlertProcTBL((viewAndTableMap.get(viewName)).toString());
				}else {
					column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
				}
				if (trackFileDtl.getViewName()!=null){
					column.setColumnViewName(trackFileDtl.getViewName());
				}
				column.setAllowUpdate("N");
				alertRuleDefinition.addLHSColumn(column);
			}
			
			if (trackFileDtl.getAlertItem9DdlName()!=null){
				Column column = new Column();
				column.setColumnTBLDDLName(trackFileDtl.getAlertItem9DdlName());
				if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem9DdlNameInd())) {
					column.setColumnTBLDataType("CAL");
				}
				String tableOrView = trackFileDtl.getAlertItemExtrctTbl();
				String check = tableOrView.substring(0,3);
				if(check.equals("VW_")){
					String viewName = trackFileDtl.getAlertItemExtrctTbl();
					column.setColumnAlertProcTBL((viewAndTableMap.get(viewName)).toString());
				}else {
					column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
				}
				if (trackFileDtl.getViewName()!=null){
					column.setColumnViewName(trackFileDtl.getViewName());
				}
				column.setAllowUpdate("N");
				alertRuleDefinition.addLHSColumn(column);
			}
			
			if (trackFileDtl.getAlertItem10DdlName()!=null){
				Column column = new Column();
				column.setColumnTBLDDLName(trackFileDtl.getAlertItem10DdlName());
				if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem10DdlNameInd())) {
					column.setColumnTBLDataType("CAL");
				}
				String tableOrView = trackFileDtl.getAlertItemExtrctTbl();
				String check = tableOrView.substring(0,3);
				if(check.equals("VW_")){
					String viewName = trackFileDtl.getAlertItemExtrctTbl();
					column.setColumnAlertProcTBL((viewAndTableMap.get(viewName)).toString());
				}else {
					column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
				}
				if (trackFileDtl.getViewName()!=null){
					column.setColumnViewName(trackFileDtl.getViewName());
				}
				column.setAllowUpdate("N");
				alertRuleDefinition.addLHSColumn(column);
			}
			
			if (trackFileDtl.getAlertItem11DdlName()!=null){
				Column column = new Column();
				column.setColumnTBLDDLName(trackFileDtl.getAlertItem11DdlName());
				if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem11DdlNameInd())) {
					column.setColumnTBLDataType("CAL");
				}
				String tableOrView = trackFileDtl.getAlertItemExtrctTbl();
				String check = tableOrView.substring(0,3);
				if(check.equals("VW_")){
					String viewName = trackFileDtl.getAlertItemExtrctTbl();
					column.setColumnAlertProcTBL((viewAndTableMap.get(viewName)).toString());
				}else {
					column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
				}
				if (trackFileDtl.getViewName()!=null){
					column.setColumnViewName(trackFileDtl.getViewName());
				}
				column.setAllowUpdate("N");
				alertRuleDefinition.addLHSColumn(column);
			}
			
			if (trackFileDtl.getAlertItem12DdlName()!=null){
				Column column = new Column();
				column.setColumnTBLDDLName(trackFileDtl.getAlertItem12DdlName());
				if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem12DdlNameInd())) {
					column.setColumnTBLDataType("CAL");
				}
				String tableOrView = trackFileDtl.getAlertItemExtrctTbl();
				String check = tableOrView.substring(0,3);
				if(check.equals("VW_")){
					String viewName = trackFileDtl.getAlertItemExtrctTbl();
					column.setColumnAlertProcTBL((viewAndTableMap.get(viewName)).toString());
				}else {
					column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
				}
				if (trackFileDtl.getViewName()!=null){
					column.setColumnViewName(trackFileDtl.getViewName());
				}
				column.setAllowUpdate("N");
				alertRuleDefinition.addLHSColumn(column);
			}
			
			if (trackFileDtl.getAlertItem13DdlName()!=null){
				Column column = new Column();
				column.setColumnTBLDDLName(trackFileDtl.getAlertItem13DdlName());
				if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem13DdlNameInd())) {
					column.setColumnTBLDataType("CAL");
				}
				String tableOrView = trackFileDtl.getAlertItemExtrctTbl();
				String check = tableOrView.substring(0,3);
				if(check.equals("VW_")){
					String viewName = trackFileDtl.getAlertItemExtrctTbl();
					column.setColumnAlertProcTBL((viewAndTableMap.get(viewName)).toString());
				}else {
					column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
				}
				if (trackFileDtl.getViewName()!=null){
					column.setColumnViewName(trackFileDtl.getViewName());
				}
				column.setAllowUpdate("N");
				alertRuleDefinition.addLHSColumn(column);
			}
			
			if (trackFileDtl.getAlertItem14DdlName()!=null){
				Column column = new Column();
				column.setColumnTBLDDLName(trackFileDtl.getAlertItem14DdlName());
				if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem14DdlNameInd())) {
					column.setColumnTBLDataType("CAL");
				}
				String tableOrView = trackFileDtl.getAlertItemExtrctTbl();
				String check = tableOrView.substring(0,3);
				if(check.equals("VW_")){
					String viewName = trackFileDtl.getAlertItemExtrctTbl();
					column.setColumnAlertProcTBL((viewAndTableMap.get(viewName)).toString());
				}else {
					column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
				}
				if (trackFileDtl.getViewName()!=null){
					column.setColumnViewName(trackFileDtl.getViewName());
				}
				column.setAllowUpdate("N");
				alertRuleDefinition.addLHSColumn(column);
			}
			
			if (trackFileDtl.getAlertItem15DdlName()!=null){
				Column column = new Column();
				column.setColumnTBLDDLName(trackFileDtl.getAlertItem15DdlName());
				if ("C".equalsIgnoreCase(trackFileDtl.getAlertItem15DdlNameInd())) {
					column.setColumnTBLDataType("CAL");
				}
				String tableOrView = trackFileDtl.getAlertItemExtrctTbl();
				String check = tableOrView.substring(0,3);
				if(check.equals("VW_")){
					String viewName = trackFileDtl.getAlertItemExtrctTbl();
					column.setColumnAlertProcTBL((viewAndTableMap.get(viewName)).toString());
				}else {
					column.setColumnAlertProcTBL(trackFileDtl.getAlertItemExtrctTbl());
				}
				if (trackFileDtl.getViewName()!=null){
					column.setColumnViewName(trackFileDtl.getViewName());
				}
				column.setAllowUpdate("N");
				alertRuleDefinition.addLHSColumn(column);
			}
		}		
		return alertRuleDefinition;
	}
	
	/**
	 * Get all the attributes from RABC_ALERT_PROC.
	 * 
	 * @param connection
	 * @param failures
	 * @param args
	 * @return List
	 */
	protected List getAlertProcList(Connection connection, List failures, List args){
		AlertProcDAO alertProcDAO = new AlertProcDAO();
		String selectSQL = q_data;
		List alertProcList = alertProcDAO.get(connection,failures,args,selectSQL);
		return alertProcList;
	}
	
	/**
	 * Get all the attributes from RABC_TRACK_FILE_DTL.
	 * 
	 * @param connection
	 * @param failures
	 * @param args
	 * @return List
	 */
	protected List getTrackFileDtlList(Connection connection, List failures, List args){
		TrackFileDtlDAO trackFileDtlDAO = new TrackFileDtlDAO();
		String selectSQL = q_dropdowns; 
		List trackFileDtlList = trackFileDtlDAO.get(connection,failures,args,selectSQL);
		return trackFileDtlList;
	}
	
	/**
	 * Get all the attributes from RABC_EXTRCT_BUILD_RULE.
	 * 
	 * @param connection
	 * @param failures
	 * @param args
	 * @return List
	 */
	protected List getExtrctBuildRuleList(Connection connection, List failures, List args){
		ExtractBuildRuleDAO extractBuildRuleDAO = new ExtractBuildRuleDAO();
		String selectSQL = q_columns;
		List extrctBuildRuleList = extractBuildRuleDAO.get(connection,failures,args,selectSQL);
		return extrctBuildRuleList;
	}
	
	/**
	 * Method to return alertKeyList for a Alert Rule.
	 * 
	 * @param trackFileDtlList
	 * @param alertRule
	 * @return List
	 */
	protected List getalertKeyList(List trackFileDtlList, AlertRule alertRule, Connection connection,List failures){
		List alertKeyList = new ArrayList();
		HashMap viewAndTableMap = getViewAndTableMap(connection, failures);
		if ("TRACK".equals(alertRule.getAlertRuleType())){
			for (int i = 0; i < trackFileDtlList.size(); i++) {
				AlertKey alertKey = new AlertKey();
				alertKey.setTableName(((TrackFileDtl)trackFileDtlList.get(i)).getAlertItemExtrctTbl());
				if (((TrackFileDtl)trackFileDtlList.get(i)).getViewName()!=null){
					alertKey.setViewName(((TrackFileDtl)trackFileDtlList.get(i)).getViewName());
				}
				alertKey.setKey1(((TrackFileDtl)trackFileDtlList.get(i)).getAlertItemKey1Name());
				alertKey.setKey2(((TrackFileDtl)trackFileDtlList.get(i)).getAlertItemKey2Name());
				alertKey.setKey3(((TrackFileDtl)trackFileDtlList.get(i)).getAlertItemKey3Name());
				alertKey.setKey4(((TrackFileDtl)trackFileDtlList.get(i)).getAlertItemKey4Name());
				alertKey.setKey5(((TrackFileDtl)trackFileDtlList.get(i)).getAlertItemKey5Name());
				alertKey.setFileId(((TrackFileDtl)trackFileDtlList.get(i)).getFileId());
				alertKeyList.add(alertKey);		
			}
			return alertKeyList;
		} else {
			AlertKey alertKey = new AlertKey();
			if (((TrackFileDtl)trackFileDtlList.get(0)).getViewName()!=null){
				alertKey.setViewName(((TrackFileDtl)trackFileDtlList.get(0)).getViewName());
				alertKey.setTableName((viewAndTableMap.get(((TrackFileDtl)trackFileDtlList.get(0)).getViewName())).toString());
			} else {
				alertKey.setTableName(((TrackFileDtl)trackFileDtlList.get(0)).getAlertItemExtrctTbl());
			}
			alertKey.setKey1(((TrackFileDtl)trackFileDtlList.get(0)).getAlertItemKey1Name());
			alertKey.setKey2(((TrackFileDtl)trackFileDtlList.get(0)).getAlertItemKey2Name());
			alertKey.setKey3(((TrackFileDtl)trackFileDtlList.get(0)).getAlertItemKey3Name());
			alertKey.setKey4(((TrackFileDtl)trackFileDtlList.get(0)).getAlertItemKey4Name());
			alertKey.setKey5(((TrackFileDtl)trackFileDtlList.get(0)).getAlertItemKey5Name());
			alertKey.setFileId(((TrackFileDtl)trackFileDtlList.get(0)).getFileId());
			alertKeyList.add(alertKey);
			return alertKeyList;
		}
		
    }
 
    /**
     * Method to get the related alerts; return list of picklist objects.
     * 
     * @param connection
     * @param failures
     * @param alertRuleDefinition
     * @param region
     * @return List
     */
    public List getRelatedAlerts(Connection connection, List failures, AlertRuleDefinition alertRuleDefinition, String region){
    	List relatedAlerts = new ArrayList();
    	String fileIds = "";
    	String selectSQL = null;
    	List args = new ArrayList();
    	Statement stmt = null;
    	String sqlStmt = null;
		ResultSet rs = null;
		int sizeOfLHS = alertRuleDefinition.getLHSColumnsList().size();
		int sizeOfRHS = alertRuleDefinition.getRHSColumnsList().size();
		List tableNames = new ArrayList();
		List fileIdsList = new ArrayList();
		List fileIdListForEachTable = new ArrayList();
    	
		selectSQL = getRelAlerts;
		
		if(sizeOfLHS > 0){
			for(int k = 0; k < sizeOfLHS; k++){
				tableNames.add(((Column)alertRuleDefinition.getLHSColumnsList().get(k)).getColumnAlertProcTBL());
			}
		}
		if(sizeOfRHS > 0){
			for(int l = 0; l < sizeOfRHS; l++){
				tableNames.add(((Column)alertRuleDefinition.getRHSColumnsList().get(l)).getColumnAlertProcTBL());
			}
		}
		
		int sizeOfTableNames = tableNames.size();
		for(int m = 0; m < sizeOfTableNames; m++){
			fileIdListForEachTable = StaticDataLoader.getFileMashByTableName((tableNames.get(m)).toString(), region);
			int sizeOfFileIdListForEachTable = fileIdListForEachTable.size();
			for(int n = 0; n < sizeOfFileIdListForEachTable; n++){
				fileIdsList.add(((PickList)fileIdListForEachTable.get(n)).getKey());
			}
		}
		
		int sizeOfFileIdsList = fileIdsList.size();
		for(int i = 0; i < sizeOfFileIdsList; i++){
			if (i == 0){
				fileIds += fileIdsList.get(i).toString() + "',";
			}
			if (i > 0 && i < (sizeOfFileIdsList-1)){
				fileIds +=  "'"+ fileIdsList.get(i).toString() + "',";
			}
			if (i == (sizeOfFileIdsList-1)) {
				fileIds +=  "'"+ fileIdsList.get(i).toString();
			}
		}

		args.add(fileIds);
		args.add(alertRuleDefinition.getAlertRule());
    	
    	try {
			MessageFormat mf = new MessageFormat(selectSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("AlertItemService.getRelatedAlerts() - Executing SQL statement: "+ sqlStmt);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			
			while (rs.next()) {
				relatedAlerts.add(rs.getString("ALERT_RULE"));
			}
			
    	} catch(SQLException sx){
    		logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
    	} finally {
    		SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
    	return relatedAlerts;
    }

    /**
     * Method to get the selected related alerts.
     * @param connection
     * @param failures
     * @param alertRuleDefinition
     * @return List
     */
    protected List getSelectedRelatedAlerts(Connection connection, List failures, AlertRuleDefinition alertRuleDefinition){
    	List selectedRelatedAlerts = new ArrayList();
    	String alertRuleName = null;
    	String selectSQL = null;
    	List args = new ArrayList();
    	Statement stmt = null;
    	String sqlStmt = null;
		ResultSet rs = null;
    	
    	alertRuleName = alertRuleDefinition.getAlertRule();
    	
    	int presnId;
    	List argument = new ArrayList();
    	argument.add(alertRuleName);
    	AlertRule alertRule = AlertRuleDefinitionService.getAlertRuleDefinitionService().getAlertRule(connection,failures,argument,getAllDesc);
    	presnId = alertRule.getPresnId();
    	
    	args.add(alertRuleName);
    	args.add(Integer.toString(presnId));
    	
    	selectSQL = getSelectedRelAlerts;
    	
    	try {
			MessageFormat mf = new MessageFormat(selectSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("AlertItemService.getSelectedRelatedAlerts() - Executing SQL statement: "+ sqlStmt);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			
			while (rs.next()) {
				selectedRelatedAlerts.add(rs.getString("ALERT_RULE"));
			}
			
    	} catch(SQLException sx){
    		logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
    	} finally {
    		SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
    	return selectedRelatedAlerts;
    }
    
    /**
     * Method will add a new alert item to the list of alertItems. For this it will use the column list added in
     * left & right to do the changes.
     * 
     * @param connection
     * @param failures
     * @param leftTableList
     * @param rightTableList
     * @param region
     * @return AlertItem
     */
    protected AlertItem addAlertItem(Connection connection, List failures, List leftTableList, List rightTableList, String region){
    	List selectedTableList = new ArrayList();
    	for (int i=0;i<leftTableList.size();i++){
    		Column leftTableColumn = (Column)leftTableList.get(i);
    		selectedTableList.add(leftTableColumn);
    	}
    	for (int i=0;i<rightTableList.size();i++){
    		Column rightTableColumn = (Column)rightTableList.get(i);
    		selectedTableList.add(rightTableColumn);
    	}
    	
    	AlertItem alertItem = new AlertItem();
    	String alertOrKey = "ALERT";
    	
    	HashMap columnMap = getDropDownMap(connection, failures,selectedTableList, alertOrKey,  region);
    	
    	List selectedTablesList = new ArrayList();
    	for (int i=0;i<leftTableList.size();i++){
    		Column leftTableColumn = (Column)leftTableList.get(i);
    		selectedTablesList.add(leftTableColumn);
    	}
    	for (int i=0;i<rightTableList.size();i++){
    		Column rightTableColumn = (Column)rightTableList.get(i);
    		selectedTablesList.add(rightTableColumn);
    	}
    	
    	alertItem.setAllowUpdate("Y");
    	alertItem.setItemName("");
    	alertItem.setAlertType("");
    	alertItem.setWarningIndicator(null);
    	
    	for (int i=0;i<selectedTableList.size();i++){
    		Column column = new Column();
    		Column selectedColumn = (Column)selectedTablesList.get(i);
    		column.setColumnAlertProcTBL(selectedColumn.getColumnAlertProcTBL());
    		if (selectedColumn.getColumnViewName()!=null){
				column.setColumnViewName(selectedColumn.getColumnViewName());
			}	
    		column.setColumnTBLDDLName("");
    		List dropDownList = null;
    		if (column.getColumnViewName() != null) {
    			dropDownList = (ArrayList) columnMap.get(column.getColumnViewName());
    		} else {
    			dropDownList = (ArrayList) columnMap.get(column.getColumnAlertProcTBL());
    		}
    		if (dropDownList!=null) {
    			for (int j=0;j<dropDownList.size();j++){
        			Column c = (Column)dropDownList.get(j);
        			column.addDropdown((Column)dropDownList.get(j));
        		}
    		}
    		
    		alertItem.addColumn(column);
    	}
    	
    	for (int j=0;j < RABCConstantsLists.getRABCConstantsLists().getAlertTypeListForTrack().size();j++){
				PickList alertType = (PickList)RABCConstantsLists.getRABCConstantsLists().getAlertTypeListForTrack().get(j);
				alertItem.addAlertType(alertType);
		}
    	SupplementType supplementType = new SupplementType();
    	supplementType.setAlertItemName("");
    	supplementType.setSelectedSupplementType(new String[0]);
    	alertItem.setSupplementType(supplementType);
    	
    	return alertItem;
    }
    
    /**
     * Will delete the alert item from the list at the given position.
     * 
     * @param alertRuleDefinition
     * @param deleteIndex
     * @return AlertRuleDefinition
     */
    protected AlertRuleDefinition deleteAlertItem(AlertRuleDefinition alertRuleDefinition, int deleteIndex){
    	alertRuleDefinition.getAlertItemList().remove(deleteIndex);
    	return alertRuleDefinition;
    }

	/**
	 * Returns HashMap of Table_Name and FileIDs for a perticular table.
	 * 
	 * @param connection
	 * @param failures
	 * @param selectedTableList
	 * @param region
	 * @return HashMap
	 */
	protected HashMap getFileIdsList (Connection connection, List failures, List selectedTableList, String region){
		String tableName = null;
		HashMap tableAndFileIds = new HashMap();
		List fileIds = new ArrayList();
		
		for (int i = 0; i < selectedTableList.size(); i++){
			tableName = (((Column)selectedTableList.get(i)).getColumnAlertProcTBL());
			fileIds = StaticDataLoader.getFileMashByTableName(tableName, region);
			tableAndFileIds.put(tableName,fileIds);
		}
		return tableAndFileIds;		
	}
    
	/**
	 * For returning list of columns available as options for every table.
	 * 
	 * @param connection
	 * @param failures
	 * @param selectedTableList
	 * @param alertOrKey
	 * @param region
	 * @return HashMap
	 */
	private HashMap getDropDownMap(Connection connection, List failures, List selectedTableList, String alertOrKey, String region){
		Column tempColumn = null;
		String tempTableName = null;
		String tempViewName = null;
		HashMap columnHashMap = new HashMap() ;
		List columnList = new ArrayList();
		
		HashMap calculationMap = getCalculationMap(connection, failures);
		List calculationList = null;
		
		for (int i = 0; i < selectedTableList.size(); i++){
			tempColumn = (Column) selectedTableList.get(i);
			//tempTableName = (((String)selectedTableList.get(i)));
			tempTableName = tempColumn.getColumnAlertProcTBL();
			tempViewName = tempColumn.getColumnViewName();
			
			List dataTblDdlList = StaticDataLoader.getDataTblDdlByAlertProcTbl(tempTableName, region);
			if (!dataTblDdlList.isEmpty()){
				int dataTblDdlListSize = dataTblDdlList.size();
				columnList = new ArrayList();
				for (int j=0;j<dataTblDdlListSize;j++){
					DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblDdlList.get(j);
					
					if (alertOrKey.equals("KEY")){
						if (!"1".equals(dataTblDdlBean.getTblDdlDataType())){
							Column column = new Column();
							column.setColumnAlertProcTBL(dataTblDdlBean.getAlertProcTbl());
							column.setColumnTBLDDLName(dataTblDdlBean.getTblDdlName());
							columnList.add(column);
						}
					}else {
						if (!"2".equals(dataTblDdlBean.getTblDdlDataType()) && !"3".equals(dataTblDdlBean.getTblDdlDataType()) && !"4".equals(dataTblDdlBean.getTblDdlDataType()) && !"D".equals(dataTblDdlBean.getTblDdlDataType())) {
							Column column = new Column();
							column.setColumnAlertProcTBL(dataTblDdlBean.getAlertProcTbl());
							column.setColumnTBLDDLName(dataTblDdlBean.getTblDdlName());
							column.setDropdownValue(dataTblDdlBean.getTblDdlName());
							columnList.add(column);
						}
					}
				}
			}
			
			if (!alertOrKey.equals("KEY")){
				if (tempViewName != null) {
					calculationList = (ArrayList) calculationMap.get(tempViewName);
				} else {
					calculationList = (ArrayList) calculationMap.get(tempTableName);
				}
				if (calculationList!=null) {
					if (!calculationList.isEmpty()) {
						for (int k=0;k<calculationList.size();k++) {
							PresnCalcElem presnCalcElem = (PresnCalcElem) calculationList.get(k);
							Column column = new Column();
							column.setColumnAlertProcTBL(tempTableName);
							column.setColumnTBLDDLName(presnCalcElem.getPresnCalcName());
							column.setColumnTBLDataType("CAL");
							column.setDropdownValue(presnCalcElem.getPresnCalcName() + "~CAL");
							columnList.add(column);
						}
					}
				}
			}
			
			if (!columnList.isEmpty()) {
				if (tempViewName != null) {
					columnHashMap.put(tempViewName, columnList);
				} else {
					columnHashMap.put(tempTableName, columnList);
				}
			}
		}
			
		return columnHashMap;
	}
	
	/**
	 * Method will be called when the user clicks on Next button. It will carry out the following steps
	 *
	 * 1) Get the total list of columns selected in step 1.
	 * 2) Using the source tables for the selected columns, build the drop down list to be presented to the user.
	 * 3) Build list of supplementary items.
	 * 4) If list is empty implying that this is call for adding new alert item; then add one to the list.
	 * 		- If above is not true, then remove all alertItems from list.
	 * 
	 * @param connection
	 * @param alertRuleDefinition
	 * @param failureList
	 * @param selectedTableList
	 * @param region
	 * @return AlertRuleDefinition
	 */
	protected AlertRuleDefinition updateAlertItemListForTrack(Connection connection,AlertRuleDefinition alertRuleDefinition, List failureList, List selectedTableList, String region){
		List alertItemList = alertRuleDefinition.getAlertItemList();
		List oldAlertItemList = new ArrayList();
		List alertRuleNameList = new ArrayList();
		alertRuleNameList.add(alertRuleDefinition.getAlertRule());
		
		List tableNameList = new ArrayList();
		for (int i=0; i<selectedTableList.size();i++){
			Column selectedColumn = (Column)selectedTableList.get(i);
			tableNameList.add(selectedColumn.getColumnAlertProcTBL());
		}

		HashMap columnHashMap = getDropDownMap(connection,failureList,selectedTableList,"ITEMS",region);
		HashMap suppItemMap = getSupplementaryItems(connection,failureList,alertRuleNameList,alertRuleDefinition.getAlertRuleType());
		/*
		 * Check whether this is the first time user is clicking on Next which would mean that the alertItemList would
		 * be empty. In this case we will create a new alert item & add it to the list
		 */
		if (alertItemList.isEmpty()){
			AlertItem alertItem = new AlertItem();
			alertItem.setItemName("");
			alertItem.setAlertType("");
			alertItem.setWarningIndicator("");
			
			for (int j=0;j < RABCConstantsLists.getRABCConstantsLists().getAlertTypeListForTrack().size();j++){
				PickList alertType = (PickList)RABCConstantsLists.getRABCConstantsLists().getAlertTypeListForTrack().get(j);
				alertItem.addAlertType(alertType);
			}
			
			for (int i=0;i<selectedTableList.size();i++){
				Column column = new Column();
				Column firstColumn = (Column) selectedTableList.get(i);
				column.setColumnAlertProcTBL(firstColumn.getColumnAlertProcTBL());
				column.setColumnTBLDDLName(firstColumn.getColumnTBLDDLName());
				
				if (firstColumn.getColumnViewName()!=null){
					column.setColumnViewName(firstColumn.getColumnViewName());
				}
				column.setColumnTBLDataType(firstColumn.getColumnTBLDataType());
				column.setAllowUpdate("N");

				alertItem.addColumn(column);
			}

			// Write code for setting the supplement type if any
			SupplementType supplementType = new SupplementType();
			supplementType.setAlertItemName("");
			supplementType.setSelectedSupplementType(new String[0]);
			alertItem.setSupplementType(supplementType);

			alertItemList.add(alertItem);
		} else {
			for (int i=0;i < alertItemList.size();i++){
				AlertItem oldAlertItem = (AlertItem) alertItemList.get(i);
				oldAlertItemList.add(oldAlertItem);
			}
			alertRuleDefinition.getAlertItemList().clear();
			alertItemList = oldAlertItemList;
		}

		// loop through the list of tables i.e column objects
		for (int i=0;i<selectedTableList.size();i++){
			Column columnInSelectedTableList = (Column) selectedTableList.get(i);

			for (int j = 0; j < alertItemList.size(); j++){
				AlertItem alertItem = (AlertItem)alertItemList.get(j);
				List columnList = alertItem.getColumnList();

				if (i>=columnList.size()){
					Column column = new Column();
					column.setColumnAlertProcTBL(columnInSelectedTableList.getColumnAlertProcTBL());
					if (columnInSelectedTableList.getColumnViewName()!=null){
						column.setColumnViewName(columnInSelectedTableList.getColumnViewName());
					}
					if (j==0){
						column.setColumnTBLDDLName(columnInSelectedTableList.getColumnTBLDDLName());
						column.setAllowUpdate("N");
						column.setColumnTBLDataType(columnInSelectedTableList.getColumnTBLDataType());
					}else {
						column.setColumnTBLDDLName("");
						column.setAllowUpdate("Y");
					}
					
					List dropDownList = null;
					if (columnInSelectedTableList.getColumnViewName() != null) {
						dropDownList = (List)columnHashMap.get(columnInSelectedTableList.getColumnViewName());
					} else {
						dropDownList = (List)columnHashMap.get(columnInSelectedTableList.getColumnAlertProcTBL());
					}
					for (int k=0;k<dropDownList.size();k++) {
						Column c = (Column)dropDownList.get(k);
						column.addDropdown((Column)dropDownList.get(k));
					}
					
					alertItem.addColumn(i,column);
				} else {
					Column column = (Column)columnList.get(i);
					boolean viewNameCheck = false;
					String viewName = column.getColumnViewName();
					if (viewName!=null){
						if (!viewName.equals(columnInSelectedTableList.getColumnViewName())){
							viewNameCheck = true;
						}
					}else {
						if (columnInSelectedTableList.getColumnViewName()!=null) {
							if (!columnInSelectedTableList.getColumnViewName().equals(viewName)){
								viewNameCheck = true;
							}
						}
					}
					if (!column.getColumnAlertProcTBL().equals(columnInSelectedTableList.getColumnAlertProcTBL()) || !column.getColumnTBLDDLName().equals(columnInSelectedTableList.getColumnTBLDDLName()) || viewNameCheck == true){
						column.setColumnAlertProcTBL(columnInSelectedTableList.getColumnAlertProcTBL());
						if (columnInSelectedTableList.getColumnViewName()!=null){
							column.setColumnViewName(columnInSelectedTableList.getColumnViewName());
						}else {
							column.setColumnViewName(null);
						}
						if (j==0){
							column.setAllowUpdate("N");
							column.setColumnTBLDDLName(columnInSelectedTableList.getColumnTBLDDLName());
							column.setColumnTBLDataType(columnInSelectedTableList.getColumnTBLDataType());
						}else {
							column.setAllowUpdate("Y");
							if (!column.getColumnAlertProcTBL().equals(columnInSelectedTableList.getColumnAlertProcTBL())){
								column.setColumnTBLDDLName("");
							}
						}

						column.getDropdownList().clear();
						List dropDownList = null;
						if (columnInSelectedTableList.getColumnViewName() != null) {
							dropDownList = (List)columnHashMap.get(columnInSelectedTableList.getColumnViewName());
						} else {
							dropDownList = (List)columnHashMap.get(columnInSelectedTableList.getColumnAlertProcTBL());
						}
						for (int k = 0; k < dropDownList.size(); k++) {
							Column c = (Column)dropDownList.get(k);
							column.addDropdown((Column)dropDownList.get(k));
						}
						
						alertItem.getColumnList().remove(i);
						alertItem.addColumn(i,column);
					} 
				}
				//////Check this.
				if(selectedTableList.size() < alertItem.getColumnList().size()){
					for (int k = selectedTableList.size(); k < alertItem.getColumnList().size(); k++){
						alertItem.getColumnList().remove(k);
					}
				}
			}
		}
		
		List newAlertItemList = new ArrayList();
		for (int i=0;i < alertItemList.size();i++){
			AlertItem alertItemToAdd = (AlertItem) alertItemList.get(i);
			SupplementType currItemSuppType = (SupplementType)alertItemToAdd.getSupplementType();
			List suppTypeOptionsList = getSupplementTypeOptionsList(alertItemList,alertItemToAdd.getItemName());

			for (int j = 0; j < suppTypeOptionsList.size(); j++){
				currItemSuppType.addSupplementTypeOption((PickList)suppTypeOptionsList.get(j));
			}
			alertItemToAdd.setSupplementType(currItemSuppType);
			newAlertItemList.add(alertItemToAdd);
		}

		if (!alertRuleDefinition.getAlertItemList().isEmpty()){
			alertRuleDefinition.getAlertItemList().clear();
		}
		
		for (int i=0;i < newAlertItemList.size();i++){
			AlertItem alertItemToAdd = (AlertItem) newAlertItemList.get(i);
			alertRuleDefinition.addAlertItem(alertItemToAdd);
		}
		
		return alertRuleDefinition;
	}
	
	/**
	 * Will update the alert item list for Trending rule.
	 * 
	 * @param connection
	 * @param alertRuleDefinition
	 * @param failureList
	 * @param selectedTableList
	 * @param warningIndicator
	 * @param alertType
	 * @param reportLink
	 * @return AlertRuleDefinition
	 */
	protected AlertRuleDefinition updateAlertItemListForTrend(Connection connection,AlertRuleDefinition alertRuleDefinition, List failureList, List selectedTableList, String [] warningIndicator, String [] alertType,String [] reportLink, String [] alertUnit){
		List alertItemList = alertRuleDefinition.getAlertItemList();
		List oldAlertItemList = new ArrayList();
		List alertRuleNameList = new ArrayList();
		alertRuleNameList.add(alertRuleDefinition.getAlertRule());
		
		if (alertItemList.isEmpty()){
			for (int i=0;i<selectedTableList.size();i++){
				Column firstColumn = (Column) selectedTableList.get(i);
				
				AlertItem alertItem = new AlertItem();	
				alertItem.setItemName(firstColumn.getColumnTBLDDLName());
				
				Column column = new Column();
				column.setColumnAlertProcTBL(firstColumn.getColumnAlertProcTBL());
				column.setColumnTBLDDLName(firstColumn.getColumnTBLDDLName());
				column.setColumnTBLDataType(firstColumn.getColumnTBLDataType());
				column.setAllowUpdate("N");
				alertItem.addColumn(column);
				
				alertItem.setAlertType(alertType[i]);
				alertItem.setWarningIndicator(warningIndicator[i]);
				if (reportLink[i]!=null && !"".equals(reportLink[i])){
					alertItem.setReportLinkData(reportLink[i]);
				}
				if (alertUnit[i]!=null && !"".equals(alertUnit[i])){
					alertItem.setAlertUnit(alertUnit[i]);
				}
				
				List suppTypeOptionsList = getSupplementTypeOptionsList(alertItemList,alertItem.getItemName());
				SupplementType currItemSuppType = new SupplementType();
				for (int j = 0; j < suppTypeOptionsList.size(); j++){
					currItemSuppType.addSupplementTypeOption((PickList)suppTypeOptionsList.get(j));
				}
				alertItem.setSupplementType(currItemSuppType);
				
				alertRuleDefinition.addAlertItem(alertItem);
			}
		} else {
			for (int i=0;i < alertItemList.size();i++){
				AlertItem oldAlertItem = (AlertItem) alertItemList.get(i);
				oldAlertItemList.add(oldAlertItem);
			}
			alertRuleDefinition.getAlertItemList().clear();
			alertItemList = oldAlertItemList;
			
			List newAlertItemList = new ArrayList();
			
			//loop through the list of tables i.e column objects
			for (int i=0;i<selectedTableList.size();i++){
				Column firstColumn = (Column) selectedTableList.get(i);
				boolean exists = false;
				
				AlertItem alertItem = new AlertItem();	
				alertItem.setItemName(firstColumn.getColumnTBLDDLName());
				
				Column column = new Column();
				column.setColumnAlertProcTBL(firstColumn.getColumnAlertProcTBL());
				column.setColumnTBLDDLName(firstColumn.getColumnTBLDDLName());
				if (firstColumn.getColumnViewName()!=null){
					column.setColumnViewName(firstColumn.getColumnViewName());
				}else {
					column.setColumnViewName(null);
				}
				column.setColumnTBLDataType(firstColumn.getColumnTBLDataType());
				column.setAllowUpdate("N");
				alertItem.addColumn(column);
				
				alertItem.setAlertType(alertType[i]);
				alertItem.setWarningIndicator(warningIndicator[i]);
				if (reportLink[i]!=null && !"".equals(reportLink[i])){
					alertItem.setReportLinkData(reportLink[i]);
				}
				if (alertUnit[i]!=null && !"".equals(alertUnit[i])){
					alertItem.setAlertUnit(alertUnit[i]);
				}
				
				String currKey;
				if (column.getColumnViewName()!=null){
					currKey  = column.getColumnViewName() + "." + column.getColumnTBLDDLName();
				}else {
					currKey  = column.getColumnAlertProcTBL() + "." + column.getColumnTBLDDLName();
				}

				for (int j = 0; j < oldAlertItemList.size(); j++){
					AlertItem oldAlertItem = (AlertItem)oldAlertItemList.get(j);
					List columnList = oldAlertItem.getColumnList();
					Column oldColumn = (Column)columnList.get(0);
					
					String key ;
					if (oldColumn.getColumnViewName()!=null){
						key = oldColumn.getColumnViewName() + "." + oldColumn.getColumnTBLDDLName();
					}else {
						key = oldColumn.getColumnAlertProcTBL() + "." + oldColumn.getColumnTBLDDLName();
					}
					
					if (currKey.equals(key)){
						SupplementType supplementType = oldAlertItem.getSupplementType();
						alertItem.setSupplementType(supplementType);
						exists = true;
						break;
					}
				}
				
				if (exists == false){
					List suppTypeOptionsList = getSupplementTypeOptionsList(alertItemList,alertItem.getItemName());
					SupplementType currItemSuppType = new SupplementType();
					for (int j = 0; j < suppTypeOptionsList.size(); j++){
						currItemSuppType.addSupplementTypeOption((PickList)suppTypeOptionsList.get(j));
					}
					alertItem.setSupplementType(currItemSuppType);
				}

				newAlertItemList.add(alertItem);
			}
			
			if (!alertRuleDefinition.getAlertItemList().isEmpty()){
				alertRuleDefinition.getAlertItemList().clear();
			}
			
			for (int i=0;i < newAlertItemList.size();i++){
				AlertItem alertItemToAdd = (AlertItem) newAlertItemList.get(i);
				alertRuleDefinition.addAlertItem(alertItemToAdd);
			}
		}		
		return alertRuleDefinition;
	}
	
	/**
	 * Updates the alert key list and returns AlertRuleDefinition object.
	 * 
	 * @param connection
	 * @param alertRuleDefinition
	 * @param failureList
	 * @param selectedTableList
	 * @param region
	 * @return AlertRuleDefinition
	 */
	protected AlertRuleDefinition updateAlertKeyList(Connection connection, AlertRuleDefinition alertRuleDefinition, List failureList, List selectedTableList, String region){
		List alertKeyList = alertRuleDefinition.getAlertKeyList();
		List oldAlertKeyList = new ArrayList();
		AlertKey alertKey;
		
		List tableNameList = new ArrayList();
		for (int i=0; i<selectedTableList.size();i++){
			Column selectedColumn = (Column)selectedTableList.get(i);
			tableNameList.add(selectedColumn.getColumnAlertProcTBL());
		}

		HashMap columnHashMap = getDropDownMap(connection,failureList,selectedTableList,"KEY",region);

		if (!alertKeyList.isEmpty()){
			for (int i=0;i < alertKeyList.size();i++){
				AlertKey oldAlertKey = (AlertKey) alertKeyList.get(i);
				oldAlertKeyList.add(oldAlertKey);
			}

			alertKeyList = oldAlertKeyList;
			alertRuleDefinition.getAlertKeyList().clear();
		}

		//List newAlertKeyList = new ArrayList();
		if ("Trend".equals(alertRuleDefinition.getAlertRuleType()) || "2".equals(alertRuleDefinition.getAlertRuleType())){
			for (int i=0;i<selectedTableList.size();i++){
				Column columnInSelectedTableList = (Column) selectedTableList.get(i);
				String tableName = columnInSelectedTableList.getColumnAlertProcTBL();
	
				if (i>=alertKeyList.size()){
					alertKey = new AlertKey();
					alertKey.setTableName(tableName);
					if (columnInSelectedTableList.getColumnViewName()!=null){
						alertKey.setViewName(columnInSelectedTableList.getColumnViewName());
					}
					alertKey.setKey1(StaticDataLoader.getDefaultDataTblDdlKey(tableName, region, 1));
					alertKey.setKey2(StaticDataLoader.getDefaultDataTblDdlKey(tableName, region, 2));
					alertKey.setKey3(StaticDataLoader.getDefaultDataTblDdlKey(tableName, region, 3));
					alertKey.setKey4(StaticDataLoader.getDefaultDataTblDdlKey(tableName, region, 4));
					alertKey.setKey5(StaticDataLoader.getDefaultDataTblDdlKey(tableName, region, 5));
					alertKey.setFileId("");
					alertKey.setAllowUpdate("Y");
					
					List fileIdList = StaticDataLoader.getFileMashByTableName(tableName, region);
					for (int j=0;j<fileIdList.size();j++){
						PickList fileId = (PickList)fileIdList.get(j);
						alertKey.addFileId(fileId);
					}
			
					List columnList = null;
					if (columnInSelectedTableList.getColumnViewName() != null) {
						columnList = (List)columnHashMap.get(columnInSelectedTableList.getColumnViewName());
					} else {
						columnList = (List)columnHashMap.get(tableName);
					}
					for (int k=0;k<columnList.size();k++) {
						alertKey.addColumn((Column)columnList.get(k));
					}
	
					alertKeyList.add(alertKey);
				}else {
					alertKey = (AlertKey)alertKeyList.get(i);
					boolean viewNameCheck = false;
					String viewName = alertKey.getViewName();
					if (viewName!=null){
						if (!viewName.equals(columnInSelectedTableList.getColumnViewName())){
							viewNameCheck = true;
						}
					}else {
						if (columnInSelectedTableList.getColumnViewName()!=null) {
							if (!columnInSelectedTableList.getColumnViewName().equals(viewName)){
								viewNameCheck = true;
							}
						}
					}
					if (!tableName.equals(alertKey.getTableName()) || viewNameCheck == true){
						alertKey.setTableName(tableName);
						if (columnInSelectedTableList.getColumnViewName()!=null){
							alertKey.setViewName(columnInSelectedTableList.getColumnViewName());
						}else {
							alertKey.setViewName(null);
						}
						alertKey.setKey1(StaticDataLoader.getDefaultDataTblDdlKey(tableName, region, 1));
						alertKey.setKey2(StaticDataLoader.getDefaultDataTblDdlKey(tableName, region, 2));
						alertKey.setKey3(StaticDataLoader.getDefaultDataTblDdlKey(tableName, region, 3));
						alertKey.setKey4(StaticDataLoader.getDefaultDataTblDdlKey(tableName, region, 4));
						alertKey.setKey5(StaticDataLoader.getDefaultDataTblDdlKey(tableName, region, 5));
						alertKey.setFileId("");
						alertKey.setAllowUpdate("Y");
	
						alertKey.getFileIdList().clear();
						List fileIdList = StaticDataLoader.getFileMashByTableName(tableName, region);
						for (int j=0;j<fileIdList.size();j++){
							PickList fileId = (PickList)fileIdList.get(j);
							alertKey.addFileId(fileId);
						}
	
						alertKey.getColumnList().clear();
						List columnList = null;
						if (columnInSelectedTableList.getColumnViewName() != null) {
							columnList = (List)columnHashMap.get(columnInSelectedTableList.getColumnViewName());
						} else {
							columnList = (List)columnHashMap.get(tableName);
						}
						for (int k=0;k<columnList.size();k++) {
							alertKey.addColumn((Column)columnList.get(k));
						}
	
						alertKeyList.remove(i);
						alertKeyList.add(i,alertKey);
					}
				}
				break;
			}
		}else {
			for (int i=0;i<selectedTableList.size();i++){
				Column columnInSelectedTableList = (Column) selectedTableList.get(i);
				String tableName = columnInSelectedTableList.getColumnAlertProcTBL();
	
				if (i>=alertKeyList.size()){
					alertKey = new AlertKey();
					alertKey.setTableName(tableName);
					if (columnInSelectedTableList.getColumnViewName()!=null){
						alertKey.setViewName(columnInSelectedTableList.getColumnViewName());
					}
					alertKey.setKey1(StaticDataLoader.getDefaultDataTblDdlKey(tableName, region, 1));
					alertKey.setKey2(StaticDataLoader.getDefaultDataTblDdlKey(tableName, region, 2));
					alertKey.setKey3(StaticDataLoader.getDefaultDataTblDdlKey(tableName, region, 3));
					alertKey.setKey4(StaticDataLoader.getDefaultDataTblDdlKey(tableName, region, 4));
					alertKey.setKey5(StaticDataLoader.getDefaultDataTblDdlKey(tableName, region, 5));
					alertKey.setFileId("");
					alertKey.setAllowUpdate("Y");
					
					List fileIdList = StaticDataLoader.getFileMashByTableName(tableName, region);
					for (int j=0;j<fileIdList.size();j++){
						PickList fileId = (PickList)fileIdList.get(j);
						alertKey.addFileId(fileId);
					}
			
					List columnList = null;
					if (columnInSelectedTableList.getColumnViewName() != null) {
						columnList = (List)columnHashMap.get(columnInSelectedTableList.getColumnViewName());
					} else {
						columnList = (List)columnHashMap.get(tableName);
					}
					for (int k=0;k<columnList.size();k++) {
						alertKey.addColumn((Column)columnList.get(k));
					}
	
					alertKeyList.add(alertKey);
				}else {
					alertKey = (AlertKey)alertKeyList.get(i);
					boolean viewNameCheck = false;
					String viewName = alertKey.getViewName();
					if (viewName!=null){
						if (!viewName.equals(columnInSelectedTableList.getColumnViewName())){
							viewNameCheck = true;
						}
					}else {
						if (columnInSelectedTableList.getColumnViewName()!=null) {
							if (!columnInSelectedTableList.getColumnViewName().equals(viewName)){
								viewNameCheck = true;
							}
						}
					}
					
					if (!tableName.equals(alertKey.getTableName()) || viewNameCheck == true){
						alertKey.setTableName(tableName);
						if (columnInSelectedTableList.getColumnViewName()!=null){
							alertKey.setViewName(columnInSelectedTableList.getColumnViewName());
						}else {
							alertKey.setViewName(null);
						}
						alertKey.setKey1(StaticDataLoader.getDefaultDataTblDdlKey(tableName, region, 1));
						alertKey.setKey2(StaticDataLoader.getDefaultDataTblDdlKey(tableName, region, 2));
						alertKey.setKey3(StaticDataLoader.getDefaultDataTblDdlKey(tableName, region, 3));
						alertKey.setKey4(StaticDataLoader.getDefaultDataTblDdlKey(tableName, region, 4));
						alertKey.setKey5(StaticDataLoader.getDefaultDataTblDdlKey(tableName, region, 5));
						alertKey.setFileId("");
						alertKey.setAllowUpdate("Y");
	
						alertKey.getFileIdList().clear();
						List fileIdList = StaticDataLoader.getFileMashByTableName(tableName, region);
						for (int j=0;j<fileIdList.size();j++){
							PickList fileId = (PickList)fileIdList.get(j);
							alertKey.addFileId(fileId);
						}
	
						alertKey.getColumnList().clear();
						List columnList = null;
						if (columnInSelectedTableList.getColumnViewName() != null) {
							columnList = (List)columnHashMap.get(columnInSelectedTableList.getColumnViewName());
						} else {
							columnList = (List)columnHashMap.get(tableName);
						}
						for (int k=0;k<columnList.size();k++) {
							alertKey.addColumn((Column)columnList.get(k));
						}
	
						alertKeyList.remove(i);
						alertKeyList.add(i,alertKey);
					}
				}
				if(selectedTableList.size() < alertKeyList.size()){
					for (int j = selectedTableList.size(); j < alertKeyList.size(); j++){
						alertKeyList.remove(j);
					}
				}
			}
		}

		List newAlertKeyList = new ArrayList();
		for (int i = 0; i < alertKeyList.size(); i++){
			AlertKey alertKeyToAdd = (AlertKey) alertKeyList.get(i);
			newAlertKeyList.add(alertKeyToAdd);
		}
		
		if (!alertRuleDefinition.getAlertKeyList().isEmpty()){
			alertRuleDefinition.getAlertKeyList().clear();
		}
		
		for (int i = 0; i < newAlertKeyList.size(); i++){
			AlertKey alertKeyToAdd = (AlertKey) newAlertKeyList.get(i);
			alertRuleDefinition.addAlertKey(alertKeyToAdd);
		}
		
		return alertRuleDefinition;
	}
	
	/**
	 * Method added to update supplement type options in alert rule definition.
	 * 
	 * @param alertRuleDefinition
	 */
	protected void updateSupplementTypeOptions(AlertRuleDefinition alertRuleDefinition){
		List alertItemList = alertRuleDefinition.getAlertItemList();
		
		if (!alertItemList.isEmpty()){
			List newAlertItemList = new ArrayList();
			
			for (int i=0;i < alertItemList.size();i++){
				AlertItem alertItemToAdd = (AlertItem) alertItemList.get(i);
				SupplementType currItemSuppType = (SupplementType)alertItemToAdd.getSupplementType();
				
				currItemSuppType.getSupplementTypeOptionsList().clear();
				List suppTypeOptionsList = getSupplementTypeOptionsList(alertItemList,alertItemToAdd.getItemName());

				for (int j = 0; j < suppTypeOptionsList.size(); j++){
					currItemSuppType.addSupplementTypeOption((PickList)suppTypeOptionsList.get(j));
				}
				alertItemToAdd.setSupplementType(currItemSuppType);
				newAlertItemList.add(alertItemToAdd);
			}

			if (!alertRuleDefinition.getAlertItemList().isEmpty()){
				alertRuleDefinition.getAlertItemList().clear();
			}
			
			for (int i=0;i < newAlertItemList.size();i++){
				AlertItem alertItemToAdd = (AlertItem) newAlertItemList.get(i);
				alertRuleDefinition.addAlertItem(alertItemToAdd);
			}
		}
	}
	
	/**
	 * Method to get the report link for the columns in case of trending rule.
	 * 
	 * @param connection
	 * @param failureList
	 * @param alertItem
	 * @param alertRule
	 * @return String
	 */
	private String getReportLinkDetails(Connection connection, List failureList, AlertItem alertItem,AlertRule alertRule){
		String reportLinkDetails = null;
		List args = new ArrayList();
		
		/*
		 * Form the arguments
		 */
		args.add(Integer.toString(alertRule.getPresnId()));
		args.add(Integer.toString(alertRule.getPresnId()));
		args.add(Integer.toString(alertRule.getPresnId()));
		Column column = (Column)alertItem.getColumnList().get(0);
		args.add(column.getColumnTBLDDLName());
		
		List webDataLinkList = new ArrayList();
		WebDataLinkDAO webDataLinkDAO = new WebDataLinkDAO();
		webDataLinkList = webDataLinkDAO.get(connection,failureList,args,qryReportLink);
		
		if (!webDataLinkList.isEmpty()){
			WebDataLink webDataLink = (WebDataLink)webDataLinkList.get(0);
			reportLinkDetails = webDataLink.getLinkPresnId() + "~" + webDataLink.getLinkDdlName();
		}
		
		return reportLinkDetails;
	}
	
	/**
	 * Private method to return a map of calculations per table.
	 * 
	 * @param connection
	 * @param failureList
	 * @return HashMap
	 */
	private HashMap getCalculationMap(Connection connection, List failureList) {
		HashMap calculationMap = new HashMap();
		String currentTableName = null;
		String previousTableName = null;
		PresnCalcElem presnCalcElem = null;
		String presnCalcName = null;
		String presnFormatCode = null;
		String calcElemFormula = null;
		List calculationNameList = new ArrayList();
		boolean addFlag = false;
		String sqlStmt =null;
		
		Statement statement = null;
		ResultSet rs = null;
		try{
			sqlStmt = getCalculationsMap;
			statement = connection.createStatement();
			rs = statement.executeQuery(sqlStmt);
			
			while(rs.next()){
				addFlag = false;
				currentTableName = rs.getString("CALC_TBL");

				if (previousTableName==null){
					previousTableName = currentTableName ;
				}
								
				if (!previousTableName.equals(currentTableName)){
					calculationMap.put(previousTableName,calculationNameList);
					previousTableName = currentTableName ;
					calculationNameList = new ArrayList();
					addFlag = true;
				}
				
				presnCalcElem = new PresnCalcElem();
				presnCalcName = rs.getString("PRESN_CALC_NAME");
				presnFormatCode = rs.getString("PRESN_FORMAT_CODE");
				calcElemFormula = rs.getString("CALC_ELEM_FORMULA");
				presnCalcElem.setPresnCalcName(presnCalcName);
				presnCalcElem.setPresnFormatCode(presnFormatCode);
				presnCalcElem.setCalcElemFormula(calcElemFormula);
				calculationNameList.add(presnCalcElem);
			}
			if (previousTableName!=null){
				calculationMap.put(previousTableName,calculationNameList);
			}
		} catch(SQLException sqle){
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sqle.getMessage(), sqle);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sqle));
			calculationMap = null;
		} finally{
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(statement, failureList, logger);
		}
		
		return calculationMap;
	}
	
	/**
	 * Method will build a map of PRESN_UNIT_IND by key as PRESN_NAME
	 * @param connection
	 * @param failureList
	 * @param alertItem
	 * @param alertRule
	 * @return
	 */
	private HashMap getUnitIndMap(Connection connection, List failureList, AlertRule alertRule){
		HashMap unitIndMap = new HashMap();
		String sqlStmt =null;
		Statement statement = null;
		ResultSet rs = null;
		
		/*
		 * Form the arguments
		 */
		List args = new ArrayList();
		args.add(Integer.toString(alertRule.getPresnId()));
		
		try{
			MessageFormat mf = new MessageFormat(getPresnUnitInd_Trend);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			statement = connection.createStatement();
			rs = statement.executeQuery(sqlStmt);
			
			while(rs.next()){
				String presnName = rs.getString("PRESN_NAME");
				String presnUnitInd = rs.getString("PRESN_UNIT_IND");
				if (presnUnitInd!=null && !"".equals(presnUnitInd)){
					unitIndMap.put(presnName, presnUnitInd);
				} else {
					unitIndMap.put(presnName, "none");
				}
			}
		} catch(SQLException sqle){
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sqle.getMessage(), sqle);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sqle));
			unitIndMap = null;
		} finally{
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(statement, failureList, logger);
		}
		
		return unitIndMap;
	}
}
