/* Component Name: RABCPPG00593
 * Module Name: CntrlPtCertComment.java
 * Created on Mar 20, 2006
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.cntrlptcert;

import java.util.Date;

/**This is a transfer object for RABC_CNTRL_PROCESS_CERT table.  It contains data from the table and the 
 * CntrlPtCertService.java class populates it into the form.
 * 
 * @author ml2195
 */
public class CntrlPtCertComment {
	private Date   timeStamp;
	private String alertRule;
	private String alertKeys;
	private String alertItem;
	private String savedUserID;
	private String certInd;
	private String alertStatus;
	private double alertRevenue;
	private int    certNum;
	private String subject;
	private String comment;
	private String bgColor;
	
	/**class constructor
	 */
	public CntrlPtCertComment() {		
		timeStamp = new Date();
		alertRule = "";
		alertKeys = "";
		alertItem = "";		
		savedUserID = "";		
		certInd = "";
		alertStatus = "";
		alertRevenue = 0;
		certNum = 0;
		subject = "";
		comment = "";	
		bgColor = "white";
	}
	
	/**
	 * @return Returns the time stamp.
	 */
	public Date getTimeStamp() {
		return timeStamp;
	}
	/**
	 * @param timeStamp Set TimeStamp 
	 */
	public void setTimeStamp(Date timeStamp) {
		this.timeStamp = timeStamp;
	}
	
	/**
	 * @return Returns the Alert Rule.
	 */
	public String getAlertRule() {
		return alertRule;
	}
	
	/**
	 * @param alertRule Set alertRule
	 */
	public void setAlertRule(String alertRule) {
		this.alertRule = alertRule;
	}
	
	/**
	 * @return Returns the alert keys.
	 */
	public String getAlertKeys() {
		if (this.alertKeys == "") {
			String none = "No alert keys";
			return none;
		} else {
			return alertKeys;
		}
	}
	
	/**
	 * @param stateList Sets the list of states.
	 */
	public void setAlertKeys(String alertKey) {
		this.alertKeys += alertKey + " ";
	}
	
	/**
	 * @return Returns the Alert Item.
	 */
	public String getAlertItem() {
		return alertItem;
	}
	
	/**
	 * @param alertItem Set alertItem
	 */
	public void setAlertItem(String alertItem) {
		this.alertItem = alertItem;
	}
	
	/**
	 * @return Returns the User ID.
	 */
	public String getSavedUserID() {
		return savedUserID;
	}
	
	/**
	 * @param userID Set UserID
	 */
	public void setSavedUserID(String userID) {
		this.savedUserID = userID;
	}
	
	/**
	 * @return Returns the CertInd.
	 */
	public String getCertInd() {
		return certInd;
	}
	
	/**
	 * @param certInd Set CertInd
	 */
	public void setCertInd(String certInd) {
		this.certInd = certInd;
	}
	
	/**
	 * @return Returns the Alert Status.
	 */
	public String getAlertStatus() {
		return alertStatus;
	}
	
	/**
	 * @param alertStatus Set alertStatus
	 */
	public void setAlertStatus(String alertStatus) {
		this.alertStatus = alertStatus;
	}
	
	/**
	 * @return Returns the Alert Revenue.
	 */
	public double getAlertRevenue() {
		return alertRevenue;
	}
	
	/**
	 * @param alertRevenue Set alertRevenue
	 */
	public void setAlertRevenue(double alertRevenue) {
		this.alertRevenue = alertRevenue;
	}
	
	/**
	 * @return Returns the CertNum.
	 */
	public int getCertNum() {
		return certNum;
	}
	
	/**
	 * @param certNum  Set CertNum
	 */
	public void setCertNum(int certNum) {
		this.certNum = certNum;
	}
	
	/**
	 * @return Returns the subject.
	 */
	public String getSubject() {
		return subject;
	}
	
	/**
	 * @param subject Set subject
	 */
	public void setSubject(String subject) {
		this.subject = subject;
	}
	
	/**
	 * @return Returns the comment.
	 */
	public String getComment() {
		return comment;
	}
	
	/**
	 * @param comment Set comment
	 */
	public void setComment(String comment) {
		this.comment = comment;
	}
	
	/**
	 * @return Returns the bgColor.
	 */
	public String getBgColor() {
		return bgColor;
	}
	
	/**
	 * @param bgColor Set bgColor
	 */
	public void setBgColor(String bgColor) {
		this.bgColor = bgColor;
	}
}
