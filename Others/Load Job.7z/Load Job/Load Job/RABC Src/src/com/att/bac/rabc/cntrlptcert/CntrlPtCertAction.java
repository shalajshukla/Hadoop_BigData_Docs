/* Component Name: RABCPPG00592
 * Module Name: CntrlPtCertAction.java
 * Created on Mar 5, 2006
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.cntrlptcert;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.StaticDataLoader;

/**This is the struts Action class for the Control Point Certification process.  The purpose of this class
 * is mainly to interact between the CntrlPtCertForm.java class and the struts framework.  All business 
 * logic is handled in the facade class CntrlPtCertService.java.
 * 
 * @author ml2195
 */
public class CntrlPtCertAction extends DispatchAction {
	private static final Logger logger = Logger.getLogger(CntrlPtCertAction.class);
	
	/**This is the struts framework default method entered when entering the cntrlptcert
	 * process without a dispatch.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of CntrlPtCertForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward unspecified(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = unspecified");
		ActionForward forward= null;
		try {
			CntrlPtCertForm cntrlPtCertForm = (CntrlPtCertForm)form;
			//initialize some of the cntrlPtCertForm main page fields with values
			cntrlPtCertForm.setLoginUserID((String)request.getSession().getAttribute("bacUserID"));
			cntrlPtCertForm.setRegion((String)request.getSession().getAttribute("region"));
			cntrlPtCertForm.setBillRounds(StaticDataLoader.getBillRounds((String)request.getSession().getAttribute("region")));
			cntrlPtCertForm.setProcDates(StaticDataLoader.getProcDates((String)request.getSession().getAttribute("region")));
			cntrlPtCertForm.setHolidayIndicators(StaticDataLoader.getHolidayIndicators((String)request.getSession().getAttribute("region")));
			cntrlPtCertForm.setLoadedDataDates(StaticDataLoader.getLoadedDataDatesByRegion((String)request.getSession().getAttribute("region")));
			
			if ("EN".equals(cntrlPtCertForm.getRegion())){
				if(cntrlPtCertForm.getSelectedRegion()==null){
					cntrlPtCertForm.setSelectedRegion("All");
				}
			}

			
			cntrlPtCertForm = CntrlPtCertService.unspecified(cntrlPtCertForm);
			log(cntrlPtCertForm);
			forward = mapping.findForward("CntrlPtCertMain");
		} catch (RABCException e) {
			return this.processError(request, mapping, e);
		}
		return forward;
	}
	
	/**Displays the Control Process Certification main page after the "View" button from the main page is clicked.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of CntrlPtCertForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward cntrlPtCertView(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = cntrlPtCertView");
		ActionForward forward= null;
		try {
			CntrlPtCertForm cntrlPtCertForm = (CntrlPtCertForm)form;
			cntrlPtCertForm.setLoginUserID((String)request.getSession().getAttribute("bacUserID"));
			cntrlPtCertForm.setRegion((String)request.getSession().getAttribute("region"));
			
			cntrlPtCertForm = CntrlPtCertService.cntrlPtCertView(cntrlPtCertForm);
			
			// List is added to the session for processing Certify All
			HttpSession session = request.getSession(true);
			session.setAttribute("cntrlPtCertViewList", cntrlPtCertForm.getCntrlPtCertViewList());
			
			log(cntrlPtCertForm);			
			forward = mapping.findForward("CntrlPtCertMain");
		} catch (RABCException e) {
			return this.processError(request, mapping, e);
		}
		return forward;
	}
	
	/**Displays the Control Process Certification main page after the "Certify" button from the main page is clicked.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of CntrlPtCertForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward cntrlPtCertCertify(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = cntrlPtCertCertify");
		ActionForward forward= null;
		try {
			CntrlPtCertForm cntrlPtCertForm = (CntrlPtCertForm)form;			
			cntrlPtCertForm.setLoginUserID((String)request.getSession().getAttribute("bacUserID"));
			cntrlPtCertForm.setRegion((String)request.getSession().getAttribute("region"));
			
			cntrlPtCertForm = CntrlPtCertService.cntrlPtCertCertify(cntrlPtCertForm);
			log(cntrlPtCertForm);
			forward = mapping.findForward("CntrlPtCertMain");
		} catch (RABCException e) {
			return this.processError(request, mapping, e);
		}
		return forward;
	}
	
	/**
	 * Method called from certify All
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 */
	public ActionForward cntrlPtCertCertifyAll(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = cntrlPtCertCertifyAll");
		ActionForward forward= null;
		try {
			CntrlPtCertForm cntrlPtCertForm = (CntrlPtCertForm)form;			
			cntrlPtCertForm.setLoginUserID((String)request.getSession().getAttribute("bacUserID"));
			cntrlPtCertForm.setRegion((String)request.getSession().getAttribute("region"));
			
			HttpSession session = request.getSession(true);
			cntrlPtCertForm = CntrlPtCertService.cntrlPtCertCertifyAll(cntrlPtCertForm,(List) session.getAttribute("cntrlPtCertViewList"));
			log(cntrlPtCertForm);
			forward = mapping.findForward("CntrlPtCertMain");
		} catch (RABCException e) {
			return this.processError(request, mapping, e);
		}
		return forward;
	}
	
	
	/**Display the Control Process Certification detail page after the "Add" button  in the main page is clicked. 
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of CntrlPtCertForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward cntrlPtCertAdd(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = cntrlPtCertAdd");
		ActionForward forward= null;
		try {
			CntrlPtCertForm cntrlPtCertForm = (CntrlPtCertForm)form;
			cntrlPtCertForm.setLoginUserID((String)request.getSession().getAttribute("bacUserID"));
			cntrlPtCertForm.setRegion((String)request.getSession().getAttribute("region"));			
			
			if ("EN".equals(cntrlPtCertForm.getRegion())){
				if(cntrlPtCertForm.getSelectedRegion()==null){
					cntrlPtCertForm.setSelectedRegion("All");
				}
			}
			
			cntrlPtCertForm = CntrlPtCertService.cntrlPtCertAdd(cntrlPtCertForm);
			log(cntrlPtCertForm);
			forward = mapping.findForward("CntrlPtCertDetl");
		} catch (RABCException e) {
			return this.processError(request, mapping, e);
		}
		return forward;
	}
	
	/**Display the Control Process Certification detail page after the "Details" button from the main page is clicked.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of CntrlPtCertForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward cntrlPtCertDetails(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = cntrlPtCertDetails");
		ActionForward forward= null;
		try {
			CntrlPtCertForm cntrlPtCertForm = (CntrlPtCertForm)form;								
			cntrlPtCertForm.setLoginUserID((String)request.getSession().getAttribute("bacUserID"));
			cntrlPtCertForm.setRegion((String)request.getSession().getAttribute("region"));
			cntrlPtCertForm = CntrlPtCertService.cntrlPtCertDetails(cntrlPtCertForm);
			log(cntrlPtCertForm);
			forward = mapping.findForward("CntrlPtCertDetl");
		} catch (RABCException e) {
			return this.processError(request, mapping, e);
		}
		return forward;
	}
	
	/**Adds new Control Process in database and returns user to the main page.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of CntrlPtCertForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward cntrlPtCertInsert(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = cntrlPtCertInsert");
		ActionForward forward = null;
		try {
			CntrlPtCertForm cntrlPtCertForm = (CntrlPtCertForm)form;			
			cntrlPtCertForm.setLoginUserID((String)request.getSession().getAttribute("bacUserID"));
			cntrlPtCertForm.setRegion((String)request.getSession().getAttribute("region"));
			
			cntrlPtCertForm = CntrlPtCertService.cntrlPtCertInsert(cntrlPtCertForm);
			log(cntrlPtCertForm);
			forward = mapping.findForward(cntrlPtCertForm.getForwardType());	
		} catch (RABCException e) {
			return this.processError(request, mapping, e);
		}
		return forward;
	}
	
	/**Updates the Control Process in database and returns user to the main page. 
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of CntrlPtCertForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward cntrlPtCertUpdate(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = cntrlPtCertUpdate");
		ActionForward forward = null;
		try {
			CntrlPtCertForm cntrlPtCertForm = (CntrlPtCertForm)form;						
			cntrlPtCertForm.setLoginUserID((String)request.getSession().getAttribute("bacUserID"));
			cntrlPtCertForm.setRegion((String)request.getSession().getAttribute("region"));
			
			cntrlPtCertForm = CntrlPtCertService.cntrlPtCertUpdate(cntrlPtCertForm);
			log(cntrlPtCertForm);
			forward = mapping.findForward("CntrlPtCertMain");
		} catch (RABCException e) {
			return this.processError(request, mapping, e);
		}
		return forward;
	}
	
	/**Resets the Control Process Certification detail page in "Add" mode 
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of CntrlPtCertForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward cntrlPtCertHardReset(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = cntrlPtCertHardReset");
		ActionForward forward= null;
		try {
			CntrlPtCertForm cntrlPtCertForm = (CntrlPtCertForm)form;			
			cntrlPtCertForm.setLoginUserID((String)request.getSession().getAttribute("bacUserID"));
			cntrlPtCertForm.setRegion((String)request.getSession().getAttribute("region"));

			if ("EN".equals(cntrlPtCertForm.getRegion())){
				if(cntrlPtCertForm.getSelectedRegion()==null){
					cntrlPtCertForm.setSelectedRegion("All");
				}
			}
			
			cntrlPtCertForm = CntrlPtCertService.cntrlPtCertHardReset(cntrlPtCertForm);
			log(cntrlPtCertForm);
			forward = mapping.findForward("CntrlPtCertDetl");
		} catch (RABCException e) {
			return this.processError(request, mapping, e);
		}
		return forward;
	}
	
	/**Resets the Control Process Certification detail page in "Update" mode 
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of CntrlPtCertForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward cntrlPtCertSoftReset(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = cntrlPtCertSoftReset");
		ActionForward forward= null;
		try {		
			CntrlPtCertForm cntrlPtCertForm = (CntrlPtCertForm)form;			
			cntrlPtCertForm.setLoginUserID((String)request.getSession().getAttribute("bacUserID"));
			cntrlPtCertForm.setRegion((String)request.getSession().getAttribute("region"));

			cntrlPtCertForm = CntrlPtCertService.cntrlPtCertSoftReset(cntrlPtCertForm);
			log(cntrlPtCertForm);
			forward = mapping.findForward("CntrlPtCertDetl");
		} catch (RABCException e) {
			return this.processError(request, mapping, e);
		}
		return forward;
	}
	
	/**Returns the user to the Control Process Certification main page without saving any changes. 
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of CntrlPtCertForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward cntrlPtCertCancel(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = cntrlPtCertCancel");
		ActionForward forward= null;
		try {
			CntrlPtCertForm cntrlPtCertForm = (CntrlPtCertForm)form;			
			cntrlPtCertForm.setRegion((String)request.getSession().getAttribute("region"));
			cntrlPtCertForm.setLoginUserID((String)request.getSession().getAttribute("bacUserID"));

			cntrlPtCertForm = CntrlPtCertService.cntrlPtCertCancel(cntrlPtCertForm);
			log(cntrlPtCertForm);
			forward = mapping.findForward("CntrlPtCertMain");
		} catch (RABCException e) {
			return this.processError(request, mapping, e);
		}
		return forward;
	}
	
	/**This method sends all error messages to the browser and kills the process.
	 * 
	 * @param request  the HttpServletRequest from the browser
	 * @param mapping  struts ActionMapping
	 * @param e  the error that caused the application to fail.
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	private ActionForward processError(HttpServletRequest request, ActionMapping mapping, Exception e){
		request.setAttribute("javax.servlet.error.exception", e);
		logger.error(e.getMessage(), e);
		return  mapping.findForward("error");
	}
	
	/**This method only shows values in the form to the console when in debug mode.
	 * 
	 * @param cntrlPtCertForm  the ActionForm for this process - CntrlPtCertForm
	 */
	private void log(CntrlPtCertForm cntrlPtCertForm){
		logger.debug("start date = " + cntrlPtCertForm.getStartDate());
		logger.debug("end date = " + cntrlPtCertForm.getEndDate());
		logger.debug("run date = " + cntrlPtCertForm.getRunDate());
		logger.debug("state = " + cntrlPtCertForm.getStateDesc());
		logger.debug("process = " + cntrlPtCertForm.getProcess());
		logger.debug("certified ind = " + cntrlPtCertForm.getCertInd());
		logger.debug("issue found ind = " + cntrlPtCertForm.getIssueInd());
		logger.debug("login user ID = " + cntrlPtCertForm.getLoginUserID());
		logger.debug("javascript msg = " + cntrlPtCertForm.getJSAlertMsg());
		logger.debug("*************************************************************************");
	}
}
