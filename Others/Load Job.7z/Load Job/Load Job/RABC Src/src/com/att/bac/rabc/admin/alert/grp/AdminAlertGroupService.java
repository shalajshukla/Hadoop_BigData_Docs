/* Component Name: RABCPPG00508
 * Module Name: AdminAlertGroupService.java
 * Created on October 18, 2006
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.admin.alert.grp;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.NamingException;

import org.apache.log4j.Logger;

import com.att.bac.rabc.ConnectionManager;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.User;
import com.att.carat.util.JDBCUtil;

/**This is the facade class for the Alert Group process.  The purpose of this class is to handle
 * the business logic and populate the AdminAlertGroupForm.java class with data gathered from the
 * AdminAlertGroupDAO.java class.
 * 
 * @author js3175
 */
public class AdminAlertGroupService {
	private static final Logger logger = Logger.getLogger(AdminAlertGroupService.class);
	
	/**This is the method called to access the DAO to retrieve permissions level and alert group information.
	 * The alert groups retrieved are then populated in a drop down menu on the AdminAlertGroup.jsp page.
	 * 
	 * @param adminAlertGroupForm  a blank AdminAlertGroupForm with userId & region populated
	 * @return adminAlertGroupForm  an AdminAlertGroupForm with data populated from the DAO
	 */
	protected static AdminAlertGroupForm adminAlertGroup(AdminAlertGroupForm adminAlertGroupForm) throws RABCException {
		logger.debug("Starting process AdminAlertGroupService.adminAlertGroup.");
		Connection conn = null;
		try {
			conn = ConnectionManager.getConnection(adminAlertGroupForm.getRegion());
			adminAlertGroupForm.setSuperAdmin(AdminAlertGroupDAO.getSuperPermission(conn, adminAlertGroupForm.getUserId()));
			adminAlertGroupForm.setAlertGroups(AdminAlertGroupDAO.getGroups(conn));
			logger.debug("Finished process AdminAlertGroupService.adminAlertGroup.");
		} catch (SQLException sqle) {
			throw new RABCException("SQL exception in creating a connection: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return adminAlertGroupForm;
	}
	
	/**This is the method called to access the DAO to retrieve all users that have access to RABC, all RABC
	 * application functions for a region, and all RABC alert rules for a region when creating a new alert 
	 * group.  This information is then used to populate the multiselect box for the users and the multiple
	 * checkboxes for the application functions and the alert rules on the AdminAlertGroupDetail.jsp page.
	 * 
	 * @param adminAlertGroupForm  a blank AdminAlertGroupForm with userId & region populated
	 * @return adminAlertGroupForm  an AdminAlertGroupForm with data populated from the DAO
	 */
	protected static AdminAlertGroupForm adminAlertGroupDetailCreate(AdminAlertGroupForm adminAlertGroupForm) throws RABCException {
		logger.debug("Starting process AdminAlertGroupService.adminAlertGroupDetailCreate.");
		Connection conn = null;
		try {
			conn = ConnectionManager.getConnection(adminAlertGroupForm.getRegion());
			adminAlertGroupForm.setUpdatePermission(1);
			adminAlertGroupForm.setUsers(AdminAlertGroupDAO.getAllUsers(conn));
			adminAlertGroupForm.setApplicationFuncts(AdminAlertGroupDAO.getAllApplFuncts(conn));
			adminAlertGroupForm.setAlertRules(AdminAlertGroupDAO.getAllAlrtRules(conn));
			logger.debug("Finished process AdminAlertGroupService.adminAlertGroupDetailCreate.");
		} catch (SQLException sqle) {
			throw new RABCException("SQL exception in creating a connection: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return adminAlertGroupForm;
	}
	
	/**This is the method called to access the DAO to retrieve all users that have access to RABC, all RABC
	 * application functions for a region, and all RABC alert rules for a region, when maintaining an alert 
	 * group.  This method also retrieves who are members of the existing alert group and what application
	 * functions and alert rules the alert group has access to.  This information is then used to populate
	 * the multiselect box for the users and the multiple checkboxes for the application functions and the 
	 * alert rules on the AdminAlertGroupDetail.jsp page.
	 * 
	 * @param adminAlertGroupForm  a blank AdminAlertGroupForm with userId & region populated
	 * @return adminAlertGroupForm  an AdminAlertGroupForm with data populated from the DAO
	 */
	protected static AdminAlertGroupForm adminAlertGroupDetailMaintain(AdminAlertGroupForm adminAlertGroupForm) throws RABCException {
		logger.debug("Starting process AdminAlertGroupService.adminAlertGroupDetailMaintain.");
		Connection conn = null;
		try {
			adminAlertGroupForm.setApplFuncSkipAll(false);
			adminAlertGroupForm.setAlertRuleSkipAll(false);
			adminAlertGroupForm.setSystMssgSkipAll(false);
			adminAlertGroupForm.setApplMssgSkipAll(false);
			conn = ConnectionManager.getConnection(adminAlertGroupForm.getRegion());
			adminAlertGroupForm.setUpdatePermission(AdminAlertGroupDAO.getPermission(conn, adminAlertGroupForm.getSelectedAlertGroup(), adminAlertGroupForm.getUserId()));
			adminAlertGroupForm.setAlertGroupInfo(AdminAlertGroupDAO.getSelectedAlertGroup(conn, adminAlertGroupForm.getSelectedAlertGroup()));
			adminAlertGroupForm.setMaintMode(1);
			adminAlertGroupForm.setPreviousAlertGroupName(adminAlertGroupForm.getSelectedAlertGroup());
			User [] allUsers = AdminAlertGroupDAO.getAllUsers(conn);
			adminAlertGroupForm.setCurrentUsers(AdminAlertGroupDAO.getAllCurrentUsers(conn, adminAlertGroupForm.getSelectedAlertGroup()));
			adminAlertGroupForm.setUsers(getNonSelectedUsers(allUsers, adminAlertGroupForm.getCurrentUsers()));
			adminAlertGroupForm.setApplicationFuncts(AdminAlertGroupDAO.getAllApplFuncts(conn));
			adminAlertGroupForm.setSelectedApplicationFuncts(AdminAlertGroupDAO.getSelectApplFuncts(conn, adminAlertGroupForm.getSelectedAlertGroup()));
			adminAlertGroupForm.setAlertRules(AdminAlertGroupDAO.getAllAlrtRules(conn));
			adminAlertGroupForm.setSelectedAlertRules(AdminAlertGroupDAO.getSelectAlrtRules(conn, adminAlertGroupForm.getSelectedAlertGroup()));
			adminAlertGroupForm.setSendSystemWarning(AdminAlertGroupDAO.getSendSystemMssgs(conn, adminAlertGroupForm.getSelectedAlertGroup()));
			adminAlertGroupForm.setSendApplicationWarning(AdminAlertGroupDAO.getSendApplicationMssgs(conn, adminAlertGroupForm.getSelectedAlertGroup()));
			adminAlertGroupForm.setPreviousAlertRules(buildTransferObject(AdminAlertGroupDAO.getAllAlrtRules(conn), adminAlertGroupForm.getSelectedAlertRules()));
			logger.debug("Finished process AdminAlertGroupService.adminAlertGroupDetailMaintain.");
		} catch (SQLException sqle) {
			throw new RABCException("SQL exception in creating a connection: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return adminAlertGroupForm;
	}
	
	/**This is the method called to access the DAO to check if the alert group being inserted is a duplicate of
	 * an existing one.  If it isn't, it sets the values for the new alert group then displays them on the 
	 * AdminAlertGroupConfirm.jsp page.
	 * 
	 * @param adminAlertGroupForm  a blank AdminAlertGroupForm with userId & region populated
	 * @return adminAlertGroupForm  an AdminAlertGroupForm with data populated from the DAO
	 */
	protected static AdminAlertGroupForm adminAlertGroupCreateConfirm(AdminAlertGroupForm adminAlertGroupForm) throws RABCException {
		logger.debug("Starting process AdminAlertGroupService.adminAlertGroupCreateConfirm.");
		Connection conn = null;
		try {
			conn = ConnectionManager.getConnection(adminAlertGroupForm.getRegion());
			adminAlertGroupForm.setDuplicateAlertGroup(AdminAlertGroupDAO.checkDuplAlertGroup(conn, adminAlertGroupForm.getAlertGroupInfo().getAlertGroup()));
			if (adminAlertGroupForm.getDuplicateAlertGroup() != 1) {
				adminAlertGroupForm.setUsers(AdminAlertGroupDAO.getSelectUsers(conn, adminAlertGroupForm.getSelectedCurrentUsers()));
				adminAlertGroupForm.setApplicationFuncts(buildTransferObject(AdminAlertGroupDAO.getAllApplFuncts(conn), adminAlertGroupForm.getSelectedApplicationFuncts()));
				adminAlertGroupForm.setAlertRules(buildTransferObject(AdminAlertGroupDAO.getAllAlrtRules(conn), adminAlertGroupForm.getSelectedAlertRules(), adminAlertGroupForm.getSendSystemWarning(), adminAlertGroupForm.getSendApplicationWarning()));
			}
			logger.debug("Finished process AdminAlertGroupService.adminAlertGroupCreateConfirm.");
		} catch (SQLException sqle) {
			throw new RABCException("SQL exception in creating a connection: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return adminAlertGroupForm;
	}
	
	/**This is the method called to access the DAO to set the values for updates to an alert group.  The updated
	 * values are displayed AdminAlertGroupConfirm.jsp page before being updated.  It also checks, if any alert
	 * rules are being removed, if this alert group is the only one the alert rule is tied to.
	 * 
	 * @param adminAlertGroupForm  a blank AdminAlertGroupForm with userId & region populated
	 * @return adminAlertGroupForm  an AdminAlertGroupForm with data populated from the DAO
	 */
	protected static AdminAlertGroupForm adminAlertGroupMaintainConfirm(AdminAlertGroupForm adminAlertGroupForm) throws RABCException {
		logger.debug("Starting process AdminAlertGroupService.adminAlertGroupMaintainConfirm.");
		Connection conn = null;
		try {
			conn = ConnectionManager.getConnection(adminAlertGroupForm.getRegion());
			adminAlertGroupForm.setUsers(AdminAlertGroupDAO.getSelectUsers(conn, adminAlertGroupForm.getSelectedCurrentUsers()));
			if (adminAlertGroupForm.getApplFuncSkipAll())
				adminAlertGroupForm.setSelectedApplicationFuncts(new String[0]);
			adminAlertGroupForm.setApplicationFuncts(buildTransferObject(AdminAlertGroupDAO.getAllApplFuncts(conn), adminAlertGroupForm.getSelectedApplicationFuncts()));
			if (adminAlertGroupForm.getAlertRuleSkipAll())
				adminAlertGroupForm.setSelectedAlertRules(new String[0]);
			if (adminAlertGroupForm.getSystMssgSkipAll())
				adminAlertGroupForm.setSendSystemWarning(new String[0]);
			if (adminAlertGroupForm.getApplMssgSkipAll())
				adminAlertGroupForm.setSendApplicationWarning(new String[0]);
			SelectRowTO [] alertRuleList = buildTransferObject(AdminAlertGroupDAO.getAllAlrtRules(conn), adminAlertGroupForm.getSelectedAlertRules(), adminAlertGroupForm.getSendSystemWarning(), adminAlertGroupForm.getSendApplicationWarning());
			adminAlertGroupForm.setAlertRules(AdminAlertGroupDAO.checkUpdatedAlrtRules(conn, alertRuleList, adminAlertGroupForm.getPreviousAlertRules()));
			for (int i = 0; i < adminAlertGroupForm.getAlertRules().length; i++) {
				if (adminAlertGroupForm.getAlertRule(i).getCanDelete() == 1) {
					adminAlertGroupForm.setMaintMode(6);
					break;
				}
			}
			logger.debug("Finished process AdminAlertGroupService.adminAlertGroupMaintainConfirm.");
		} catch (SQLException sqle) {
			throw new RABCException("SQL exception in creating a connection: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return adminAlertGroupForm;
	}
	
	/**This is the method called to access the DAO to set the values of an alert group being deleted.  The 
	 * values are displayed on the AdminAlertGroupConfirm.jsp page before being updated.  It also checks the
	 * alert rules and ad hoc reports to make sure the alert group is not the only one any said alert rule 
	 * or ad hoc report is associated with.
	 * 
	 * @param adminAlertGroupForm  a blank AdminAlertGroupForm with userId & region populated
	 * @return adminAlertGroupForm  an AdminAlertGroupForm with data populated from the DAO
	 */
	protected static AdminAlertGroupForm adminAlertGroupDeleteConfirm(AdminAlertGroupForm adminAlertGroupForm) throws RABCException {
		logger.debug("Starting process AdminAlertGroupService.adminAlertGroupDeleteConfirm.");
		Connection conn = null;
		try {
			conn = ConnectionManager.getConnection(adminAlertGroupForm.getRegion());
			adminAlertGroupForm.setMaintMode(2);
			adminAlertGroupForm.setAlertGroupInfo(AdminAlertGroupDAO.getSelectedAlertGroup(conn, adminAlertGroupForm.getSelectedAlertGroup()));
			adminAlertGroupForm.setUsers(AdminAlertGroupDAO.getAllCurrentUsers(conn, adminAlertGroupForm.getSelectedAlertGroup()));
			adminAlertGroupForm.setApplicationFuncts(buildTransferObject(AdminAlertGroupDAO.getAllApplFuncts(conn), AdminAlertGroupDAO.getSelectApplFuncts(conn, adminAlertGroupForm.getSelectedAlertGroup())));
			adminAlertGroupForm.setAlertRules(AdminAlertGroupDAO.checkAlrtRules(conn, buildTransferObject(AdminAlertGroupDAO.getAllAlrtRules(conn), AdminAlertGroupDAO.getSelectAlrtRules(conn, adminAlertGroupForm.getSelectedAlertGroup()), AdminAlertGroupDAO.getSendSystemMssgs(conn, adminAlertGroupForm.getSelectedAlertGroup()), AdminAlertGroupDAO.getSendApplicationMssgs(conn, adminAlertGroupForm.getSelectedAlertGroup()))));
			for (int i = 0; i < adminAlertGroupForm.getAlertRules().length; i++) {
				if (adminAlertGroupForm.getAlertRule(i).getCanDelete() == 1) {
					adminAlertGroupForm.setMaintMode(3);
					break;
				}
			}
			adminAlertGroupForm.setAdhocReports(buildTransferObject(AdminAlertGroupDAO.getAllAdhocRpts(conn), AdminAlertGroupDAO.getSelectedAdhocRpts(conn, adminAlertGroupForm.getSelectedAlertGroup())));
			adminAlertGroupForm.setAdhocReports(AdminAlertGroupDAO.checkAdhocRpts(conn, adminAlertGroupForm.getAdhocReports()));
			for (int i = 0; i < adminAlertGroupForm.getAdhocReports().length; i++) {
				if (adminAlertGroupForm.getAdhocReport(i).getCanDelete() == 1 && adminAlertGroupForm.getMaintMode() == 3) {
					adminAlertGroupForm.setMaintMode(5);
					break;
				} else if (adminAlertGroupForm.getAdhocReport(i).getCanDelete() == 1) {
					adminAlertGroupForm.setMaintMode(4);
					break;
				}
			}
			logger.debug("Finished process AdminAlertGroupService.adminAlertGroupDeleteConfirm.");
		} catch (SQLException sqle) {
			throw new RABCException("SQL exception in creating a connection: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return adminAlertGroupForm;
	}
	
	/**This is the method called to access the DAO to delete the alert group from RABC_ALERT_GRP, RABC_ALERT_GRP_USER,
	 * RABC_UPDATE_GRP, RABC_ALERT_GRP_FUNCT, & RABC_PROC_RESPONSIBLE.
	 * 
	 * @param adminAlertGroupForm  a blank AdminAlertGroupForm with userId & region populated
	 * @return adminAlertGroupForm  an AdminAlertGroupForm with data populated from the DAO
	 */
	protected static AdminAlertGroupForm deleteAlertGroup(AdminAlertGroupForm adminAlertGroupForm) throws RABCException {
		logger.debug("Starting process AdminAlertGroupService.deleteAlertGroup.");
		Connection conn = null;
		try {
			conn = ConnectionManager.getConnection(adminAlertGroupForm.getRegion());
			AdminAlertGroupDAO.deleteGroup(conn, adminAlertGroupForm.getAlertGroupInfo().getAlertGroup());
			conn.commit();
			adminAlertGroupForm.setSuperAdmin(AdminAlertGroupDAO.getSuperPermission(conn, adminAlertGroupForm.getUserId()));
			adminAlertGroupForm.setAlertGroups(AdminAlertGroupDAO.getGroups(conn));
			logger.debug("Finished process AdminAlertGroupService.deleteAlertGroup.");
		} catch (SQLException sqle) {
			throw new RABCException("SQL exception in creating a connection or committing deletes: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return adminAlertGroupForm;
	}
	
	/**This is the method called to access the DAO to insert the alert group into RABC_ALERT_GRP, RABC_ALERT_GRP_USER,
	 * RABC_UPDATE_GRP, RABC_ALERT_GRP_FUNCT, & RABC_PROC_RESPONSIBLE.
	 * 
	 * @param adminAlertGroupForm  a blank AdminAlertGroupForm with userId & region populated
	 * @return adminAlertGroupForm  an AdminAlertGroupForm with data populated from the DAO
	 */
	protected static AdminAlertGroupForm insertAlertGroup(AdminAlertGroupForm adminAlertGroupForm) throws RABCException {
		logger.debug("Starting process AdminAlertGroupService.insertAlertGroup.");
		Connection conn = null;
		try {
			conn = ConnectionManager.getConnection(adminAlertGroupForm.getRegion());
			AdminAlertGroupDAO.insertGroup(conn, adminAlertGroupForm.getAlertGroupInfo().getAlertGroup(), adminAlertGroupForm.getAlertGroupInfo().getAlertGroupDescription(), adminAlertGroupForm.getUsers(), adminAlertGroupForm.getAlertRules(), adminAlertGroupForm.getApplicationFuncts());
			conn.commit();
			adminAlertGroupForm.setSuperAdmin(AdminAlertGroupDAO.getSuperPermission(conn, adminAlertGroupForm.getUserId()));
			adminAlertGroupForm.setAlertGroups(AdminAlertGroupDAO.getGroups(conn));
			logger.debug("Finished process AdminAlertGroupService.insertAlertGroup.");
		} catch (SQLException sqle) {
			throw new RABCException("SQL exception in creating a connection or committing deletes: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return adminAlertGroupForm;
	}
	
	/**This is the method called to access the DAO to update the alert group into RABC_ALERT_GRP, RABC_ALERT_GRP_USER,
	 * RABC_UPDATE_GRP, RABC_ALERT_GRP_FUNCT, & RABC_PROC_RESPONSIBLE.
	 * 
	 * @param adminAlertGroupForm  a blank AdminAlertGroupForm with userId & region populated
	 * @return adminAlertGroupForm  an AdminAlertGroupForm with data populated from the DAO
	 */
	protected static AdminAlertGroupForm updateAlertGroup(AdminAlertGroupForm adminAlertGroupForm) throws RABCException {
		logger.debug("Starting process AdminAlertGroupService.updateAlertGroup.");
		Connection conn = null;
		try {
			conn = ConnectionManager.getConnection(adminAlertGroupForm.getRegion());
			String [] activeAdHocReports = AdminAlertGroupDAO.getSelectedAdhocRpts(conn, adminAlertGroupForm.getPreviousAlertGroupName());
			AdminAlertGroupDAO.deleteGroup(conn, adminAlertGroupForm.getPreviousAlertGroupName());
			AdminAlertGroupDAO.insertGroup(conn, adminAlertGroupForm.getAlertGroupInfo().getAlertGroup(), adminAlertGroupForm.getAlertGroupInfo().getAlertGroupDescription(), adminAlertGroupForm.getUsers(), adminAlertGroupForm.getAlertRules(), adminAlertGroupForm.getApplicationFuncts());
			AdminAlertGroupDAO.reinsertAdhocReports(conn, adminAlertGroupForm.getAlertGroupInfo().getAlertGroup(), activeAdHocReports);
			conn.commit();
			adminAlertGroupForm.setSuperAdmin(AdminAlertGroupDAO.getSuperPermission(conn, adminAlertGroupForm.getUserId()));
			adminAlertGroupForm.setAlertGroups(AdminAlertGroupDAO.getGroups(conn));
			logger.debug("Finished process AdminAlertGroupService.updateAlertGroup.");
		} catch (SQLException sqle) {
			throw new RABCException("SQL exception in creating a connection or committing updates: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return adminAlertGroupForm;
	}
	
	/**This is the method called to access the DAO to retrieve alert groups a user has access to as well as the
	 * alert rules and application functions those alert groups have access to.
	 * 
	 * @param adminAlertGroupForm  a blank AdminAlertGroupForm with userId & region populated
	 * @return adminAlertGroupForm  an AdminAlertGroupForm with data populated from the DAO
	 */
	protected static AdminAlertGroupForm adminUserAccess(AdminAlertGroupForm adminAlertGroupForm) throws RABCException {
		logger.debug("Starting process AdminAlertGroupService.adminUserAccess.");
		Connection conn = null;
		try {
			conn = ConnectionManager.getConnection(adminAlertGroupForm.getRegion());
			if (adminAlertGroupForm.getViewUserID() != null && !adminAlertGroupForm.getViewUserID().trim().equals("")) {
				adminAlertGroupForm.setUserAccessList(AdminAlertGroupDAO.getUserAccList(conn, adminAlertGroupForm.getViewUserID()));
				if (adminAlertGroupForm.getUserAccessList().length == 0) {
					adminAlertGroupForm.setAreGroups('N');
				} else {
					adminAlertGroupForm.setAreGroups('Y');
				}
			}
			logger.debug("Finished process AdminAlertGroupService.adminUserAccess.");
		} catch (SQLException sqle) {
			throw new RABCException("SQL exception in creating a connection: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return adminAlertGroupForm;
	}
	
	/**This is the method called to separate out users that are not part of an alert group from those
	 * that are.  The total number of users with access to RABC should equal the number that are selected
	 * for an alert group plus the non-selected ones.  Those that are not selected go in the multi-select
	 * box titled User List.
	 * 
	 * @param allUsers  an array of all users with access to RABC
	 * @param selUsers  an array of users that are in a particular alert group
	 * @return (User []) nonSelectedUsers.toArray(new User[nonSelectedUsers.size()])  the users not in
	 *                                                                                the alert group
	 */
	private static User [] getNonSelectedUsers (User [] allUsers, User [] selUsers) {
		ArrayList nonSelectedUsers = new ArrayList();
		for (int i = 0; i < allUsers.length; i++) {
			for (int j = 0; j < selUsers.length; j++) {
				if (allUsers[i].getUserId().equals(selUsers[j].getUserId())) {
					allUsers[i].setUserId("");
					break;
				}
			}
		}
		for (int i = 0; i < allUsers.length; i++) {
			if (!allUsers[i].getUserId().equals(""))
				nonSelectedUsers.add(allUsers[i]);
		}
		return (User []) nonSelectedUsers.toArray(new User[nonSelectedUsers.size()]);
	}
	
	/**This is the method called to build a transfer object to show on the AdminAlertGroupConfirm.jsp
	 * page what application functions the alert group has access to.
	 * 
	 * @param transObj  an array of application function transfer objects
	 * @param selId  an array of application function ID's
	 * @return transObj  an array of application function transfer objects with which application functions
	 *                   are selected
	 */
	private static SelectRowTO [] buildTransferObject (SelectRowTO [] transObj, String [] selId) {
		for (int i = 0; i < transObj.length; i++) {
			transObj[i].setIsSelected(0);
			for (int j = 0; j < selId.length; j++) {
				if (selId[j].equals(transObj[i].getRowID())) {
					transObj[i].setIsSelected(1);
					break;
				}
			}
		}
		return transObj;
	}
	
	/**This is the method called to build a transfer object to show on the AdminAlertGroupConfirm.jsp
	 * page what alert rules the alert group has access to, which alert rules will send system messages 
	 * to members of the alert group, and which ones will send application messages to members of the
	 * alert group.
	 * 
	 * @param transObj  an array of application function transfer objects
	 * @param selRules  an array of application function ID's
	 * @param systMssgs  an array of alert rules that will send out system messages to members of the alert
	 *                   group
	 * @param applMssgs  an array of alert rules that will send out application messages to members of the
	 *                   alert group
	 * @return transObj  an array of application function transfer objects with which application functions
	 *                   are selected
	 */
	private static SelectRowTO [] buildTransferObject (SelectRowTO [] transObj, String [] selRules, String [] systMssgs, String [] applMssgs) {
		for (int i = 0; i < transObj.length; i++) {
			transObj[i].setIsSelected(0);
			for (int j = 0; j < selRules.length; j++) {
				if (selRules[j].equals(transObj[i].getRowID())) {
					transObj[i].setIsSelected(1);
					break;
				}
			}
			transObj[i].setSystemMessage(0);
			for (int k = 0; k < systMssgs.length; k++) {
				if (systMssgs[k].equals(transObj[i].getRowID())) {
					transObj[i].setSystemMessage(1);
					break;
				}
			}
			transObj[i].setApplicationMessage(0);
			for (int m = 0; m < applMssgs.length; m++) {
				if (applMssgs[m].equals(transObj[i].getRowID())) {
					transObj[i].setApplicationMessage(1);
					break;
				}
			}
		}
		return transObj;
	}
}
