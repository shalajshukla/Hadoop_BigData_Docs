/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.admin.adhoc.rpt;
import java.util.Date;

/**
 * This is a Data Object to represent RABC_SCHED_RPT table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class SchedRpt {
	private int presnId;
	private String rptTimeInd;
	private int rptTime;
	private String rollupInd;
	private int schedRptNum;
	private Date effDt;
	private int execNumDays;
	private String rptType;
	private String division;

	/**
	 * @return Returns the PresnId.
	 */
	public int getPresnId() {
		return presnId;
	}
	/**
	 * @return Returns the RptTimeInd.
	 */
	public String getRptTimeInd() {
		return rptTimeInd;
	}
	/**
	 * @return Returns the RptTime.
	 */
	public int getRptTime() {
		return rptTime;
	}
	/**
	 * @return Returns the RollupInd.
	 */
	public String getRollupInd() {
		return rollupInd;
	}
	/**
	 * @return Returns the SchedRptNum.
	 */
	public int getSchedRptNum() {
		return schedRptNum;
	}
	/**
	 * @return Returns the EffDt.
	 */
	public Date getEffDt() {
		return effDt;
	}
	/**
	 * @return Returns the ExecNumDays.
	 */
	public int getExecNumDays() {
		return execNumDays;
	}
	/**
	 * @return Returns the RptType.
	 */
	public String getRptType() {
		return rptType;
	}
	/**
	 * @return Returns the Division.
	 */
	public String getDivision() {
		return division;
	}

	/**
	 * @param PresnId The presnId to set.
	 */
	public void setPresnId(int presnId) {
		this.presnId = presnId;
	}
	/**
	 * @param RptTimeInd The rptTimeInd to set.
	 */
	public void setRptTimeInd(String rptTimeInd) {
		this.rptTimeInd = rptTimeInd;
	}
	/**
	 * @param RptTime The rptTime to set.
	 */
	public void setRptTime(int rptTime) {
		this.rptTime = rptTime;
	}
	/**
	 * @param RollupInd The rollupInd to set.
	 */
	public void setRollupInd(String rollupInd) {
		this.rollupInd = rollupInd;
	}
	/**
	 * @param SchedRptNum The schedRptNum to set.
	 */
	public void setSchedRptNum(int schedRptNum) {
		this.schedRptNum = schedRptNum;
	}
	/**
	 * @param EffDt The effDt to set.
	 */
	public void setEffDt(Date effDt) {
		this.effDt = effDt;
	}
	/**
	 * @param ExecNumDays The execNumDays to set.
	 */
	public void setExecNumDays(int execNumDays) {
		this.execNumDays = execNumDays;
	}
	/**
	 * @param RptType The rptType to set.
	 */
	public void setRptType(String rptType) {
		this.rptType = rptType;
	}
	/**
	 * @param Division The division to set.
	 */
	public void setDivision(String division) {
		this.division = division;
	}
}
