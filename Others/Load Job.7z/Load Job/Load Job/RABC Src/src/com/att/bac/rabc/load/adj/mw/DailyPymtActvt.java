/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.load.adj.mw;

import java.util.Date;

import com.sbc.bac.rabc.load.HashCodeUtil;

/**
 * This is a class representing entries in RABC_DAILY_PYMT_ACTVT table.
 * 
 * @author Shailesh Hemdev - SH8512
 */
public class DailyPymtActvt {
	private Date runDate;
	private String division;
	private String btn;
	private String busType;
	private String trnCd;
	private Date pymtDate;
	private double pymtAmt;

	/**
	 * @return Returns the btn.
	 */
	public String getBtn() {
		return btn;
	}
	/**
	 * @param btn The btn to set.
	 */
	public void setBtn(String btn) {
		this.btn = btn;
	}
	/**
	 * @return Returns the busType.
	 */
	public String getBusType() {
		return busType;
	}
	/**
	 * @param busType The busType to set.
	 */
	public void setBusType(String busType) {
		this.busType = busType;
	}
	/**
	 * @return Returns the division.
	 */
	public String getDivision() {
		return division;
	}
	/**
	 * @param division The division to set.
	 */
	public void setDivision(String division) {
		this.division = division;
	}
	/**
	 * @return Returns the pymtAmt.
	 */
	public double getPymtAmt() {
		return pymtAmt;
	}
	/**
	 * @param pymtAmt The pymtAmt to set.
	 */
	public void setPymtAmt(double pymtAmt) {
		this.pymtAmt = pymtAmt;
	}
	/**
	 * @return Returns the pymtDate.
	 */
	public Date getPymtDate() {
		return pymtDate;
	}
	/**
	 * @param pymtDate The pymtDate to set.
	 */
	public void setPymtDate(Date pymtDate) {
		this.pymtDate = pymtDate;
	}
	/**
	 * @return Returns the runDate.
	 */
	public Date getRunDate() {
		return runDate;
	}
	/**
	 * @param runDate The runDate to set.
	 */
	public void setRunDate(Date runDate) {
		this.runDate = runDate;
	}
	/**
	 * @return Returns the trnCd.
	 */
	public String getTrnCd() {
		return trnCd;
	}
	/**
	 * @param trnCd The trnCd to set.
	 */
	public void setTrnCd(String trnCd) {
		this.trnCd = trnCd;
	}
	
	/**
	 * Equals method overridden for this object so that it can be stored in a hash map where the key 
	 * would be combination of the following 6 attributes:
	 * Run date
	 * Division
	 * BTN
	 * Business Type
	 * Transaction Code
	 * Payment Date
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object o) {
		// Do a quick check for an identical object reference
	    if (this == o) {
	      return true;
	    }
	    if (!(o instanceof DailyPymtActvt)) {
	    	return false;
	    } else {
			if (((DailyPymtActvt)o).getRunDate().getTime() == this.getRunDate().getTime()
				&& ((DailyPymtActvt)o).getDivision().equalsIgnoreCase(this.getDivision())
				&& ((DailyPymtActvt)o).getBtn().equalsIgnoreCase(this.getBtn())	
				&& ((DailyPymtActvt)o).getBusType().equalsIgnoreCase(this.getBusType())	
				&& ((DailyPymtActvt)o).getTrnCd().equalsIgnoreCase(this.getTrnCd())	
				&& ((DailyPymtActvt)o).getPymtDate().getTime() == this.getPymtDate().getTime()
				) {
				return true;
			} else {
				return false;
			}
	    }
	}
	
	/**
	 * Hash code method overridden for this object to categorize this object in sets 
	 * so that the hash collections can search this object efficiently.
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		int hashCode = HashCodeUtil.SEED;
		hashCode = HashCodeUtil.hash( hashCode, this.getBusType());
		hashCode = HashCodeUtil.hash( hashCode, this.getTrnCd());
		hashCode = HashCodeUtil.hash( hashCode, this.getPymtDate().getTime());
	    return hashCode;
	}
}
