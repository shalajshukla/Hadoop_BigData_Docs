/*
 * Created on Feb 10, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.att.bac.rabc.load.paj;

import java.sql.Date;

/**
 * @author pt6471
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class PaymentData {
	
	private String companyId;
	private int cycle;
	private String fileKey;
	private long btn;
	private String businessType;
	private double billPayAmount1;
	private double billPayAmount2;
	private Date lastPaymentDate;
	
	
	public double getBillPayAmount1() {
		return billPayAmount1;
	}
	public void setBillPayAmount1(double billPayAmount1) {
		this.billPayAmount1 = billPayAmount1;
	}
	public double getBillPayAmount2() {
		return billPayAmount2;
	}
	public void setBillPayAmount2(double billPayAmount2) {
		this.billPayAmount2 = billPayAmount2;
	}
	
	
	public long getBtn() {
		return btn;
	}
	public void setBtn(long btn) {
		this.btn = btn;
	}
	public String getBusinessType() {
		return businessType;
	}
	public void setBusinessType(String businessType) {
		switch(Integer.parseInt(businessType)){

		case 1 :
			this.businessType = "RES";	
			break;

		case 2 :
			this.businessType = "BUS";
			break;

		case 3 :
			this.businessType = "RRES";
			break;

		case 4 :
			this.businessType = "RBUS";
			break;

		default :
			this.businessType = "FNL";
			break;
		}
	}
	
	public String getCompanyId() {
		return companyId;
	}
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}
	public int getCycle() {
		return cycle;
	}
	public void setCycle(int cycle) {
		this.cycle = cycle;
	}
	public String getFileKey() {
		return fileKey;
	}
	public void setFileKey(String fileKey) {
		this.fileKey = fileKey;
	}
	public Date getLastPaymentDate() {
		return lastPaymentDate;
	}
	public void setLastPaymentDate(Date lastPaymentDate) {
		this.lastPaymentDate = lastPaymentDate;
	}
}
