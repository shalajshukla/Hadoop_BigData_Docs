package com.att.bac.rabc.load.so.sw;

public class ErrData {

	//RUN_DATE, DIVISION, MKT_IND, SVC_ORD_TYPE, ERR_CD, SVC_ORD_ERR_CT
	private String mktInd ; 
	private String svcOrdType ;
	private long SVC_ORD_ERR_CT = 0 ;
	
	//default value for hashcode return value
	private static final int DEFAULT	= 03;
	
	/**
	 * @return Returns the mktInd.
	 */
	public String getMktInd() {
		return mktInd;
	}
	/**
	 * @param mktInd The mktInd to set.
	 */
	public void setMktInd(String mktInd) {
		this.mktInd = mktInd;
	}
	/**
	 * @return Returns the svcOrdType.
	 */
	public String getSvcOrdType() {
		return svcOrdType;
	}
	/**
	 * @param svcOrdType The svcOrdType to set.
	 */
	public void setSvcOrdType(String svcOrdType) {
		this.svcOrdType = svcOrdType;
	}
	/**
	 * @return Returns the sVC_ORD_CMPL_CT.
	 */

	/**
	 * @return Returns the sVC_ORD_ERR_CT.
	 */
	public long getSVC_ORD_ERR_CT() {
		return SVC_ORD_ERR_CT;
	}
	/**
	 * @param svc_ord_err_ct The sVC_ORD_ERR_CT to set.
	 */
	public void setSVC_ORD_ERR_CT(long svc_ord_err_ct) {
		SVC_ORD_ERR_CT = svc_ord_err_ct;
	}
	
	public boolean equals(Object o) {
		if ((o instanceof ErrData) 
				&& ((ErrData)o).getMktInd().equalsIgnoreCase(this.getMktInd())
				&& ((ErrData)o).getSvcOrdType().equalsIgnoreCase(this.getSvcOrdType())
				) 
		{
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * Hash code method used for categorizing the objects in sets so that the hash collections can search efficiently
	 */
	public int hashCode() {
		if (mktInd !=null) 
			return Integer.parseInt(mktInd);
	
		return DEFAULT;
	}
	
}
