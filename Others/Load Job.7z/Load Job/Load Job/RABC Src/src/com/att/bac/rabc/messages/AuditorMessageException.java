/* Created on Mar 14, 2006 by Peter Foo (pf7941)
 * Copyright 2006-2008 AT&T Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.messages;



public class AuditorMessageException extends Exception {

    /**
     *
     */

    public AuditorMessageException() {
        super();

    }

    /**
     *
     */

    public AuditorMessageException(String message) {
        super(message);

    }

    /**
     *
     */

    public AuditorMessageException(Throwable cause) {
        super(cause);

    }

    /**
     *
     */

    public AuditorMessageException(String message, Throwable cause) {
        super(message, cause);

    }

}
