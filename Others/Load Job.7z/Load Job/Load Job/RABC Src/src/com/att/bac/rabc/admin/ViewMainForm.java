/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.admin;

import java.util.List;

import org.apache.struts.action.ActionForm;

/**
 * Form bean for view definition component from side menu link
 * 
 * @author Umesh Deole - UD7153
 * 
 */
public class ViewMainForm extends ActionForm {

	List viewNameList ;
	String viewName=null;
	private String dispatch = null;
	/*
	 * Variables added for calendar page
	 */
	private String procDates;
	private String billRounds;
	private String holidayIndicators;
	private String loadedDataDates;
	/**
	 * @return billRounds
	 */
	public String getBillRounds() {
		return billRounds;
	}
	
	/**
	 * @param billRounds
	 */
	public void setBillRounds(String billRounds) {
		this.billRounds = billRounds;
	}
	
	/**
	 * @return holidayIndicators
	 */
	public String getHolidayIndicators() {
		return holidayIndicators;
	}
	
	/**
	 * @param holidayIndicators
	 */
	public void setHolidayIndicators(String holidayIndicators) {
		this.holidayIndicators = holidayIndicators;
	}
	
	/**
	 * @return loadedDataDates
	 */
	public String getLoadedDataDates() {
		return loadedDataDates;
	}
	
	/**
	 * 
	 * @param loadedDataDates
	 */
	public void setLoadedDataDates(String loadedDataDates) {
		this.loadedDataDates = loadedDataDates;
	}

	/**
	 * @return procDates
	 */
	public String getProcDates() {
		return procDates;
	}

	/**
	 * @param procDates
	 */
	public void setProcDates(String procDates) {
		this.procDates = procDates;
	}

	
	/**
	 * @return Returns the viewName.
	 */
	public String getViewName() {
		return viewName;
	}
	/**
	 * @param viewName The viewName to set.
	 */
	public void setViewName(String viewName) {
		this.viewName = viewName;
	}
	/**
	 * @return Returns the viewNameList.
	 */
	public List getViewNameList() {
		return viewNameList;
	}
	/**
	 * @param viewNameList The viewNameList to set.
	 */
	public void setViewNameList(List viewNameList) {
		this.viewNameList = viewNameList;
	}
	/**
	 * @return Returns the dispatch.
	 */
	public String getDispatch() {
		return dispatch;
	}
	/**
	 * @param dispatch The dispatch to set.
	 */
	public void setDispatch(String dispatch) {
		this.dispatch = dispatch;
	}
}
