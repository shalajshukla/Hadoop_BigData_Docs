/* Created by Peter Foo (pf7941) on Nov 20, 2006.
 Copyright 2006-2008 AT&T Knowledge Ventures. All rights reserved. */

package com.att.bac.rabc.load.so.calnet;

import java.io.File;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.StringTokenizer;

import com.att.bac.rabc.load.calnet.CalnetException;
import com.att.bac.rabc.load.calnet.CalnetLoadJob;
import com.att.bac.rabc.util.EmcisEventLogger;
import com.att.carat.util.NetUtil;
import com.sbc.bac.rabc.load.StaticErrorMsgKeys;
import com.sbc.bac.rabc.load.StaticFieldKeys;

/**
 * The SOStatusCodeCountLoadJob reads files whose name fits the pattern:
 * WE.[CI].C[0-9]{4}.XT33SODS.* . It parses the file line by line and inserts the records into the
 * RABC_SVC_ORD_TRN table.
 * 
 * Each record contains a status code, which can be one of the following values:<br>
 * Z - Complete<br>
 * P - Complete<br>
 * E - Error<br>
 * D - Error<br>
 * M - Error<br>
 * B - Interim<br>
 * R - Interim<br>
 * 
 * Each record also has a status code count, which is an integer.
 * 
 * @author pf7941
 * 
 */
public class SOStatusCodeCountLoadJob extends CalnetLoadJob {

	private static final String SVC_ORD_CMPL_CD = "ZP";
	private static final String SVC_ORD_ERROR_CD = "EDM";
	private static final String SVC_ORD_INTERM_CD = "BR";
	private String fileId = "XT33SODS";
	private String table = "RABC_SVC_ORD_TRN";
	private List svcOrdTrnList = new ArrayList();
	private HashMap svcOrdTrnMap;
	private String fileName, region;
	
	
	/* (non-Javadoc)
	 * @see com.att.bac.rabc.load.calnet.CalnetLoadJob#preprocessFile(java.io.File)
	 */
	protected boolean preprocessFile(File file) {
		fileName = file.getName();
		region   =	file.getName().substring(0,2);
		svcOrdTrnMap  = new HashMap(); //don't care if the system bombs, we're setting up the map.
		return super.preprocessFile(file);
	}

	/**
	 * Processes a line of data from the file. A line contains fields that are semicolon-delimited in
	 * the following format: <FileId>;<AgencyId>;<ServiceOrderType>;<Status Code>;<Status Code Count> 
	 * 
	 * Example: XT33SODS;AGN00000; 63;B;0000000005;
	 * 
	 * @see com.sbc.bac.load.FileDBLoadJob#parseLine(java.lang.String)
	 */
	protected int processRecord(String line) throws Exception {
		lineCount++;
		StringTokenizer DataLine = new StringTokenizer(line, StaticFieldKeys.SEMICOLON);
		// First token is the file id, which isn't needed for loading into the table.
		DataLine.nextToken(); //Skip the process id.
		String agencyId = DataLine.nextToken().trim(); 
		String orderType = DataLine.nextToken().trim(); 
		String statusCode = DataLine.nextToken().trim();
		int statusCodeCount = Integer.parseInt(DataLine.nextToken().trim());

		// Create a SvcOrdTrn object and add it to a List, which will be used to insert data
		// into the database as a batch.
		SvcOrdTrn s = new SvcOrdTrn();
		s.setRunDate(sqlRunDate);
		s.setDivision(division);
		s.setCycle(cycle);
		s.setAgencyId(agencyId);
		s.setSvcOrdType(orderType);
		s.setSvcOrdStatusCt(statusCodeCount);

		//check to see if the service order was completed, errored, or is interim.
		if (SVC_ORD_CMPL_CD.indexOf(statusCode) != -1) {
			s.setSvcOrdStatus(SvcOrdTrn.STATUS_COMPLETE);
		}
		else if (SVC_ORD_ERROR_CD.indexOf(statusCode) != -1) {
			s.setSvcOrdStatus(SvcOrdTrn.STATUS_ERRORED);
		}
		else if (SVC_ORD_INTERM_CD.indexOf(statusCode) != -1) {
			s.setSvcOrdStatus(SvcOrdTrn.STATUS_INTERIM);
		}
		//build the key. (you know, if we implemented an equals and hashcode method, we could just use a set, might be quicker).
		String key = s.getRunDate() + s.getDivision() + s.getAgencyId() + s.getSvcOrdType() + s.getSvcOrdStatus();

		// Check if an existing svcOrdTrn object is already in the HashMap with the same key.
		SvcOrdTrn sFromMap = (SvcOrdTrn) svcOrdTrnMap.get(key);
		// If the HashMap doesn't already contain a svcOrdTrn object with the same key, then add s to the HashMap.
		if (sFromMap == null) {
			svcOrdTrnMap.put(key, s);
		}
		// Otherwise add the status code count to the existing svcOrdTrn's status count.
		else {
			sFromMap.setSvcOrdStatusCt(sFromMap.getSvcOrdStatusCt() + statusCodeCount);
		}
		

		return SUCCESS;
	}

	/** 
	 * Inserts the elements of svcOrdTrnList into the table via the DAO class.
	 * After the elements are inserted, svcOrdTrnList is cleared.
	 * @see com.sbc.bac.load.FileDBLoadJob#postprocessFile(java.io.File, boolean)
	 **/
	public boolean postprocessFile(File file, boolean success) {
		try{
			//Log the file information to EMCIS_EVENT_LOG and EMCIS_EVENT_LOG_DETAIL
			EmcisEventLogger emcisLogger = new EmcisEventLogger();
			String event_id = "RABC_"+fileId+"_"+region;
            String host = NetUtil.getLocalHostName();
            String hostIP = NetUtil.getLocalIpAddress();
			int sequence = emcisLogger.getEMCISSequence(connection);
			emcisLogger.insertEventLog(connection, sequence, event_id, sqlRunDate, host, hostIP);
			emcisLogger.insertEventLogDetail(connection, sequence, "FileName", fileName);

		}catch (UnknownHostException e) {
            severe("Error getting EMCIS host information ", e);
        }
		//list time yo!
		svcOrdTrnList = new ArrayList(svcOrdTrnMap.values());
		//we're now done with svcOrdTrnMap... Clear it.
		svcOrdTrnMap = null;
		SvcOrdTrnCalnetDAO dao = new SvcOrdTrnCalnetDAO();
		if (success) {
			try {
				// Insert the records into the table.
				success = dao.insertBatchOfRecords(connection, svcOrdTrnList, 1000);
			}
			catch (CalnetException e) {
				severe(StaticErrorMsgKeys.INSERT_ERROR + e.getMessage(), e);
				success = false;
			}
		}
		svcOrdTrnList.clear();
		return super.postprocessFile(file, success);
	}

	public String getFileId() {
		return fileId;
	}

	public String getTable() {
		return table;
	}

}
