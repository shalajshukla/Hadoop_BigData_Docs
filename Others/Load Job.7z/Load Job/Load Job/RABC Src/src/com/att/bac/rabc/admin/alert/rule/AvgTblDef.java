/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.admin.alert.rule;

/**
 * This is a Data Object to represent RABC_AVG_TBL_DEF table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class AvgTblDef {
	private int partiRefId;
	private int avgKeyLvl;
	private String key1Name;
	private String key2Name;
	private String key3Name;
	private String key4Name;
	private String key5Name;
	private String avgItemName;
	private int avgDataCt;
	private String avgData1Name;
	private String avgData2Name;
	private String avgData3Name;
	private String avgData4Name;
	private String avgData5Name;
	private String avgData6Name;
	private String avgData7Name;
	private String avgData8Name;
	private String avgData9Name;
	private String avgData10Name;
	private String avgData11Name;
	private String avgData12Name;
	private String avgData13Name;
	private String avgData14Name;
	private String avgData15Name;

	/**
	 * @return Returns the PartiRefId.
	 */
	public int getPartiRefId() {
		return partiRefId;
	}
	/**
	 * @return Returns the AvgKeyLvl.
	 */
	public int getAvgKeyLvl() {
		return avgKeyLvl;
	}
	/**
	 * @return Returns the Key1Name.
	 */
	public String getKey1Name() {
		return key1Name;
	}
	/**
	 * @return Returns the Key2Name.
	 */
	public String getKey2Name() {
		return key2Name;
	}
	/**
	 * @return Returns the Key3Name.
	 */
	public String getKey3Name() {
		return key3Name;
	}
	/**
	 * @return Returns the Key4Name.
	 */
	public String getKey4Name() {
		return key4Name;
	}
	/**
	 * @return Returns the Key5Name.
	 */
	public String getKey5Name() {
		return key5Name;
	}
	/**
	 * @return Returns the AvgItemName.
	 */
	public String getAvgItemName() {
		return avgItemName;
	}
	/**
	 * @return Returns the AvgDataCt.
	 */
	public int getAvgDataCt() {
		return avgDataCt;
	}
	/**
	 * @return Returns the AvgData1Name.
	 */
	public String getAvgData1Name() {
		return avgData1Name;
	}
	/**
	 * @return Returns the AvgData2Name.
	 */
	public String getAvgData2Name() {
		return avgData2Name;
	}
	/**
	 * @return Returns the AvgData3Name.
	 */
	public String getAvgData3Name() {
		return avgData3Name;
	}
	/**
	 * @return Returns the AvgData4Name.
	 */
	public String getAvgData4Name() {
		return avgData4Name;
	}
	/**
	 * @return Returns the AvgData5Name.
	 */
	public String getAvgData5Name() {
		return avgData5Name;
	}
	/**
	 * @return Returns the AvgData6Name.
	 */
	public String getAvgData6Name() {
		return avgData6Name;
	}
	/**
	 * @return Returns the AvgData7Name.
	 */
	public String getAvgData7Name() {
		return avgData7Name;
	}
	/**
	 * @return Returns the AvgData8Name.
	 */
	public String getAvgData8Name() {
		return avgData8Name;
	}
	/**
	 * @return Returns the AvgData9Name.
	 */
	public String getAvgData9Name() {
		return avgData9Name;
	}
	/**
	 * @return Returns the AvgData10Name.
	 */
	public String getAvgData10Name() {
		return avgData10Name;
	}
	/**
	 * @return Returns the AvgData11Name.
	 */
	public String getAvgData11Name() {
		return avgData11Name;
	}
	/**
	 * @return Returns the AvgData12Name.
	 */
	public String getAvgData12Name() {
		return avgData12Name;
	}
	/**
	 * @return Returns the AvgData13Name.
	 */
	public String getAvgData13Name() {
		return avgData13Name;
	}
	/**
	 * @return Returns the AvgData14Name.
	 */
	public String getAvgData14Name() {
		return avgData14Name;
	}
	/**
	 * @return Returns the AvgData15Name.
	 */
	public String getAvgData15Name() {
		return avgData15Name;
	}

	/**
	 * @param PartiRefId The partiRefId to set.
	 */
	public void setPartiRefId(int partiRefId) {
		this.partiRefId = partiRefId;
	}
	/**
	 * @param AvgKeyLvl The avgKeyLvl to set.
	 */
	public void setAvgKeyLvl(int avgKeyLvl) {
		this.avgKeyLvl = avgKeyLvl;
	}
	/**
	 * @param Key1Name The key1Name to set.
	 */
	public void setKey1Name(String key1Name) {
		this.key1Name = key1Name;
	}
	/**
	 * @param Key2Name The key2Name to set.
	 */
	public void setKey2Name(String key2Name) {
		this.key2Name = key2Name;
	}
	/**
	 * @param Key3Name The key3Name to set.
	 */
	public void setKey3Name(String key3Name) {
		this.key3Name = key3Name;
	}
	/**
	 * @param Key4Name The key4Name to set.
	 */
	public void setKey4Name(String key4Name) {
		this.key4Name = key4Name;
	}
	/**
	 * @param Key5Name The key5Name to set.
	 */
	public void setKey5Name(String key5Name) {
		this.key5Name = key5Name;
	}
	/**
	 * @param AvgItemName The avgItemName to set.
	 */
	public void setAvgItemName(String avgItemName) {
		this.avgItemName = avgItemName;
	}
	/**
	 * @param AvgDataCt The avgDataCt to set.
	 */
	public void setAvgDataCt(int avgDataCt) {
		this.avgDataCt = avgDataCt;
	}
	/**
	 * @param AvgData1Name The avgData1Name to set.
	 */
	public void setAvgData1Name(String avgData1Name) {
		this.avgData1Name = avgData1Name;
	}
	/**
	 * @param AvgData2Name The avgData2Name to set.
	 */
	public void setAvgData2Name(String avgData2Name) {
		this.avgData2Name = avgData2Name;
	}
	/**
	 * @param AvgData3Name The avgData3Name to set.
	 */
	public void setAvgData3Name(String avgData3Name) {
		this.avgData3Name = avgData3Name;
	}
	/**
	 * @param AvgData4Name The avgData4Name to set.
	 */
	public void setAvgData4Name(String avgData4Name) {
		this.avgData4Name = avgData4Name;
	}
	/**
	 * @param AvgData5Name The avgData5Name to set.
	 */
	public void setAvgData5Name(String avgData5Name) {
		this.avgData5Name = avgData5Name;
	}
	/**
	 * @param AvgData6Name The avgData6Name to set.
	 */
	public void setAvgData6Name(String avgData6Name) {
		this.avgData6Name = avgData6Name;
	}
	/**
	 * @param AvgData7Name The avgData7Name to set.
	 */
	public void setAvgData7Name(String avgData7Name) {
		this.avgData7Name = avgData7Name;
	}
	/**
	 * @param AvgData8Name The avgData8Name to set.
	 */
	public void setAvgData8Name(String avgData8Name) {
		this.avgData8Name = avgData8Name;
	}
	/**
	 * @param AvgData9Name The avgData9Name to set.
	 */
	public void setAvgData9Name(String avgData9Name) {
		this.avgData9Name = avgData9Name;
	}
	/**
	 * @param AvgData10Name The avgData10Name to set.
	 */
	public void setAvgData10Name(String avgData10Name) {
		this.avgData10Name = avgData10Name;
	}
	/**
	 * @param AvgData11Name The avgData11Name to set.
	 */
	public void setAvgData11Name(String avgData11Name) {
		this.avgData11Name = avgData11Name;
	}
	/**
	 * @param AvgData12Name The avgData12Name to set.
	 */
	public void setAvgData12Name(String avgData12Name) {
		this.avgData12Name = avgData12Name;
	}
	/**
	 * @param AvgData13Name The avgData13Name to set.
	 */
	public void setAvgData13Name(String avgData13Name) {
		this.avgData13Name = avgData13Name;
	}
	/**
	 * @param AvgData14Name The avgData14Name to set.
	 */
	public void setAvgData14Name(String avgData14Name) {
		this.avgData14Name = avgData14Name;
	}
	/**
	 * @param AvgData15Name The avgData15Name to set.
	 */
	public void setAvgData15Name(String avgData15Name) {
		this.avgData15Name = avgData15Name;
	}
}
