/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.admin.alert.rule;

/**
 * This is a Data Object to represent RABC_CNTRL_PT_ALERT table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class CntrlPtAlert {
	private String cntrlPtCd;
	private String alertRule;
	private int presnSeqNum;
	
	/**
	 * @return Returns the alertRule.
	 */
	public String getAlertRule() {
		return alertRule;
	}
	/**
	 * @return Returns the cntrlPtCd.
	 */
	public String getCntrlPtCd() {
		return cntrlPtCd;
	}
	/**
	 * @return Returns the presnSeqNum.
	 */
	public int getPresnSeqNum() {
		return presnSeqNum;
	}
	/**
	 * @param alertRule The alertRule to set.
	 */
	public void setAlertRule(String alertRule) {
		this.alertRule = alertRule;
	}
	/**
	 * @param cntrlPtCd The cntrlPtCd to set.
	 */
	public void setCntrlPtCd(String cntrlPtCd) {
		this.cntrlPtCd = cntrlPtCd;
	}
	/**
	 * @param presnSeqNum The presnSeqNum to set.
	 */
	public void setPresnSeqNum(int presnSeqNum) {
		this.presnSeqNum = presnSeqNum;
	}
}
