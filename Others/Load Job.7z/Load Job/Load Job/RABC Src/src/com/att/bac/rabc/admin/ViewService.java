/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.admin;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.regex.PatternSyntaxException;

import org.apache.log4j.Logger;

import com.att.bac.rabc.PickList;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.StaticDataLoader;
import com.att.bac.rabc.View;
import com.att.bac.rabc.ViewDAO;


/**
 * This is a service class to provide the business logic.
 * The methods in this class are called by the action class. 
 * They internaly calls the DAO classes to do the required manipulation and returns the result to the action class. 
 * This service class serves the business logic to insert / update the view. 
 * 
 * @author Umesh Deole - UD7153
 */
public class ViewService {
	private static final Logger logger = Logger.getLogger(ViewService.class);
	private static ViewService viewService;
	
	/*
	 * Variables to represent the sql statements.
	 */
	
	// Query to check presense of previous view
	protected static final String qPrevView="SELECT view_name, table_name, view_desc, select_value, "
										+ " prev_ind, user_id, time_stamp FROM rabc_view WHERE view_name = ''{0}''";
	
	// Query to insert previous view
	protected static final String qPrevViewInsert="INSERT INTO RABC_VIEW(table_name,view_name,view_desc,prev_ind,select_value, user_id,time_stamp) "
												+ " VALUES(''{0}'', ''{1}'',''{2}'',''{3}'',''{4}'',''{5}'',SYSDATE)";
	
	protected static final String qView = "SELECT view_name, table_name, view_desc, select_value, "
										+ " prev_ind, user_id, time_stamp FROM rabc_view WHERE view_name = ''{0}''";
	
	protected static final String qViewPrev = qPrevView;
	
	// Query to update view details
	protected static final String qViewUpdate = "UPDATE RABC_VIEW SET  table_name = ''{0}'',prev_ind = ''{1}'', "
											 + " select_value = ''{2}'',user_id = ''{3}'', " 
											 + " time_stamp = SYSDATE WHERE view_name = ''{4}''";
	
	// Query to update the previous view 
	protected static final String qViewPrevUpdate="UPDATE RABC_VIEW SET table_name = ''{0}'',prev_ind = ''Y'', "
												+ "select_value = ''{1}'', user_id = ''{2}'', time_stamp = SYSDATE "
												+ "WHERE view_name = ''{3}''";
	
	// Query to create a previous view
	protected static final String qViewPrevInsert = "INSERT INTO RABC_VIEW(table_name,view_name,view_desc,prev_ind,select_value, user_id,time_stamp) "
													+ " VALUES(''{0}'', ''{1}'',''{2}'','Y',''{3}'',''{4}'',SYSDATE)";
	
	// Query to delete a previous view
	protected static final String qViewPrevDelete = "DELETE FROM RABC_VIEW WHERE view_name = ''{0}''";
	
	// Query to insert view details
	protected static final String qViewInsert = "INSERT INTO RABC_VIEW(table_name,view_name,view_desc,prev_ind,select_value, user_id,time_stamp) "
											+ " VALUES(''{0}'', ''{1}'',''{2}'',''{3}'',''{4}'',''{5}'' ,SYSDATE)";
	
	protected static final String getViewNames = "SELECT view_name, table_name, view_desc, select_value, "
		+ " prev_ind, user_id, time_stamp FROM rabc_view where upper (substr (view_name, -5 )) != ''_PREV'' ";
	
	/**
	 * Synchronized method to return the instance of ViewService object.
	 * It checks the existance of the instance of ViewService and if it does not exists
	 * then creates one instance of ViewService and returns otherwise it returns the
	 * existing instance of ViewService.
	 * 
	 * @return ViewService
	 */
	public static synchronized ViewService getViewService(){
		if (viewService == null){
			viewService = new ViewService();
		}	
		return viewService;
	}

	/**
	 * This method is used to get the view object given the view name as one of the arguments
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return View
	 */
	public View getView(Connection connection,List failureList, List args){
		ViewDAO viewDAO = new ViewDAO();
		List viewList = viewDAO.get(connection,failureList,args,qView);
		if (!viewList.isEmpty()){
			return (View)viewList.get(0);
		}else {
			return null;
		}
	}
	
	/** This method is used to do the following 
	 * 1) Form where clause from the select value of the view which in turn needs to be returned to the java script function
	 * Algorithm consists of following steps
	 * 2) Replace all occurences of " " with "," and remove all occurences of "(" and ")"
	 * 
	 * @param selectValue
	 * @param tableName
	 * @param failureList
	 * @return String
	 */
	public String getViewData(String selectValue, String tableName,List failureList){
		String viewData = "";
		
		/* Replace all occurences of "(" and ")" with "" */
		try {
			selectValue = selectValue.replace('(',' ');
			selectValue = selectValue.replace(')',' ');
		} catch (PatternSyntaxException  pe){
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + pe.getMessage(), pe);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), pe));
		}
		
		/*
		 * Using string tokenizer place all the elements from select_Value in the rabc_view table into a list
		 * taking care that the single quotes ' are replaced by a ""
		 */
		List viewDataList = new ArrayList();
		StringTokenizer selectValueTokenizer = new StringTokenizer(selectValue," ");
		
		while (selectValueTokenizer.hasMoreTokens()) {
			String temp = selectValueTokenizer.nextToken();
			try {
				temp = temp.replaceAll("'","");
				viewDataList.add(temp);
			} catch (PatternSyntaxException  pe){
				logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + pe.getMessage(), pe);
	            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), pe));
			}
        }

		int i = 3;
		int j = 1;
		int n = 0;
		int m = 0;
		int q = 0 ;
		int p;
		String element;
		String viewName;
		String columnName;
		String delimiter;
		String value;
		int index;
		int viewDataListSize = viewDataList.size() ; 
		
		while (i<viewDataListSize){
			if (j==1){
				element = (String) viewDataList.get(j-1);
				index = element.indexOf('.');
				columnName = element.substring(index + 1,element.length());
				viewData = tableName + "," + columnName + "," + element + "," + (String) viewDataList.get(1)+ "," + (String) viewDataList.get(2);
				j = j + 2;
			}else {
				
				q = j + 1;
				p = q - 4;
					
				if (q <= viewDataListSize) {
					String previousElementName = (String) viewDataList.get(p);
					String currentElementName = (String) viewDataList.get(q);
					
					if (previousElementName.trim().equals(currentElementName.trim())){
						m = i + n + 1;
						
						viewData = viewData + "," + (String)viewDataList.get(j)+ "," + viewDataList.get(q+1) + "," + viewDataList.get(q+2);
						j = j + 1;
						j = j + 3;
						n = n + 1;

						if ((q+3)== (viewDataList.size())){
						
							viewData = viewData + "," + "NULL" + "," + "AND";
						} 
						
					}else {
						
							viewData = viewData + "," + "NULL" + "," + (String)viewDataList.get(j) + ";";
							
							m = i + n + 1;
							j = j + 1;
							int z = 0;
							
							element = (String) viewDataList.get(j);
							index = element.indexOf('.');
							columnName = element.substring(index + 1,element.length());
							viewData = viewData + tableName + "," + columnName + "," + element + "," + (String) viewDataList.get(j+1)+ "," + (String) viewDataList.get(j+2);
							//j = j + 2;
							j = j + 3;
							if (m== viewDataList.size()){
								
								viewData = viewData + "," + "NULL" + "," + "AND";
							}
							n = n + 1;
							
					}
				}// if (q <= viewDataListSize) {	
			}
			i = i + 3;
		}
		
		if ("".equals(viewData) && i == viewDataList.size()) {
			element = (String) viewDataList.get(j-1);
			index = element.indexOf('.');
			columnName = element.substring(index + 1,element.length());
			viewData = tableName + "," + columnName + "," + element + "," + (String) viewDataList.get(1)+ "," + (String) viewDataList.get(2);
			viewData = viewData + "," + "NULL" + "," + "AND";
		}
		return viewData ;
	}	
	
	/**
	 * Insert method for view creation,collects the following arguments
	 * 1) View object - this will give the view name, desc, table
	 * 2) View Description from the view object
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 */
	public void insertView(Connection connection , List failureList , List args ) {
		View view = (View)args.get(0);
		view.setViewName("VW_" + view.getViewName());
		String viewData = (String)args.get(1);
		String viewName = view.getViewName();
		String userId = (String)args.get(2);
		
		List returnList = buildSelectClause(viewData,viewName);
		String tableName = (String) returnList.get(0);
		String selectValue = (String) returnList.get(1);
		
		/*
		 * Following code will insert a view provided a view for this view name does not exist in
		 * the database 
		 */
		List viewCheckArgs = new ArrayList();
		viewCheckArgs.add(viewName);
		if (!viewCheck(connection , failureList , viewCheckArgs)){
			ViewDAO viewDAO = new ViewDAO();
			List insertArgs = new ArrayList();
			insertArgs.add(tableName);
			insertArgs.add(view.getViewName());
			insertArgs.add(view.getViewDesc());
			insertArgs.add(view.getPrevInd());
			insertArgs.add(selectValue);
			insertArgs.add(userId);
			viewDAO.executeUpdate(connection,failureList,insertArgs,qViewInsert);
		}
	}
	
	/**
	 * Insert method for previous view creation - collects the following arguments
	 * 1) View object - this will give the view name, desc, table
	 * 2) View Description from the view object
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 */
	public void insertPreviousView(Connection connection , List failureList , List args  ) {
		View view = (View)args.get(0);
		view.setViewName(view.getViewName());
		String viewData = (String)args.get(1);
		String viewName = view.getViewName();
		String userId = (String)args.get(2);		
		List returnList = buildSelectClause(viewData,viewName);
		String tableName = (String) returnList.get(0);
		String selectValue = (String) returnList.get(1);
		
		/*
		 * Following code will insert a previous view provided a previous view for this view does not exist in
		 * the database & the previousView flag has been checked
		 * 
		 */
		if ("Y".equals(view.getPrevInd())){
			List previousViewCheckArgs = new ArrayList();
			previousViewCheckArgs.add(viewName + "_PREV");
			if (!previousViewCheck(connection,failureList,previousViewCheckArgs )){
				ViewDAO viewDAO = new ViewDAO();
				List insertArgs = new ArrayList();
				insertArgs.add(tableName);
				insertArgs.add(view.getViewName()+"_PREV");
				insertArgs.add(view.getViewDesc());
				insertArgs.add("Y");
				insertArgs.add(selectValue);
				insertArgs.add(userId);
				viewDAO.executeUpdate(connection,failureList,insertArgs,qViewInsert);
			}
		}		
	}
	
	/**
	 * Insert method for previous view creation for table - collects the following arguments
	 * 1) View object - this will give the view name, desc, table
	 * 2) View Description from the view object
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 */
	public void insertPreviousViewForTable(Connection connection , List failureList , List args  ) {
		String viewName = (String)args.get(0);
		String tableName = (String) args.get(1);
		String userId = (String)args.get(2);
		String selectValue = "";
		/*
		 * Following code will insert a previous view provided a previous view for this view does not exist in
		 * the database & the previousView flag has been checked
		 * 
		 */
		ViewDAO viewDAO = new ViewDAO();
		List insertArgs = new ArrayList();

		insertArgs.add(tableName);
		insertArgs.add(viewName);
		insertArgs.add("");// view desc 
		insertArgs.add("Y"); // previous indicator 
		insertArgs.add("");//selectValue
		insertArgs.add(userId);
		viewDAO.executeUpdate(connection,failureList,insertArgs,qViewInsert);
	}
	
	/**
	 * This method is used to update view.  
	 * @param connection
	 * @param failureList
	 * @param args
	 */
	public void updateView(Connection connection , List failureList , List args ) {
		View view = (View)args.get(0);
		view.setViewName(view.getViewName());
		String viewData = (String)args.get(1);
		String viewName = "VW_" +view.getViewName();
		String userId = (String)args.get(2);

		List returnList = buildSelectClause(viewData,viewName);
		String tableName = (String) returnList.get(0);
		String selectValue = (String) returnList.get(1);
		/*
		 * Update existing view
		 */
		List viewCheckArgs = new ArrayList();
		viewCheckArgs.add(viewName);
		if (viewCheck(connection , failureList , viewCheckArgs)){
			ViewDAO viewDAO = new ViewDAO();
			List updateArgs = new ArrayList();
			updateArgs.add(tableName);
			updateArgs.add(view.getPrevInd());
			updateArgs.add(selectValue);
			updateArgs.add(userId);
			updateArgs.add("VW_" +view.getViewName());
			viewDAO.executeUpdate(connection,failureList,updateArgs,qViewUpdate);			
		}
	}
	
	/**
	 * This method is used to update previous view.  
	 * @param connection
	 * @param failureList
	 * @param args
	 */
	public void updatePreviousView(Connection connection , List failureList , List args ) {
		
		List previousViewArgs = args ;
		View view = (View)args.get(0);
		view.setViewName("VW_" +view.getViewName());
		String viewData = (String)args.get(1);
		String viewName =  view.getViewName();
		String userId = (String)args.get(2);
		
		List previousViewCheckArgs = new ArrayList();
		previousViewCheckArgs.add(viewName + "_PREV");
		
		/*
		 * Code for previous view not included which includes following scenarios
		 * 1) If it was existing before & user unchecks prev indicator then delete
		 * 2) if it was not existing before & user checks prev indicator then insert
		 * 3) if it was existing before & user checks prev indicator then update
		 */
		
		ViewDAO viewDAO = new ViewDAO();
		
		boolean isPrevViewExists = false ; 
		
		isPrevViewExists = previousViewCheck(connection,failureList,previousViewCheckArgs ) ; 
		
		if (isPrevViewExists && "N".equals(view.getPrevInd())){
			// Delete the previous view 
			viewDAO.executeUpdate(connection,failureList,previousViewCheckArgs,qViewPrevDelete);
		} else if ((!isPrevViewExists) && "Y".equals(view.getPrevInd())) {
			insertPreviousView(connection, failureList, previousViewArgs);
		} else if (isPrevViewExists && "Y".equals(view.getPrevInd())) {
			List returnList = buildSelectClause(viewData,viewName);
			String tableName = (String) returnList.get(0);
			String selectValue = (String) returnList.get(1);
			/*
			 * Update existing previous view
			 */
			List updateArgs = new ArrayList();
			updateArgs.add(tableName);
			//updateArgs.add(view.getPrevInd());
			updateArgs.add(selectValue);
			updateArgs.add(userId);
			updateArgs.add(view.getViewName() + "_PREV");
			viewDAO.executeUpdate(connection,failureList,updateArgs,qViewPrevUpdate);
		}	
	}

	/**
	 * This method is used to build select clause for view creation 
	 * @param viewData
	 * @param viewName
	 * @return
	 */
	protected List buildSelectClause (String viewData, String viewName){
		String selectValue = "" ;
		List viewDataList = new ArrayList();
		List clauseList = new ArrayList();
		List viewDataElementList;
		List returnList = new ArrayList();
		String tableName=null;
		/*
		 * First split the view data into various elements where the column name is changing
		 */
		StringTokenizer viewDataTokenizer = new StringTokenizer(viewData,";");
		
		int columnCount = 0 ; 
		int appendCount = 1 ;
		while (viewDataTokenizer.hasMoreTokens()) {
			viewDataList.add(viewDataTokenizer.nextToken());
			
		}

		while (columnCount < viewDataList.size()) {
			String viewDataElement = viewDataList.get(columnCount).toString();
			StringTokenizer viewDataElementTokenizer = new StringTokenizer(viewDataElement,",");
		
			/*
			 * For every column collect the various values
			 */
			viewDataElementList = new ArrayList();
			while (viewDataElementTokenizer.hasMoreTokens()){
				viewDataElementList.add(viewDataElementTokenizer.nextToken());
			}

			/*
			 * For above column form the where clause
			 */
			if ("OR".equals((String)viewDataElementList.get(5))){
				selectValue = selectValue + "(";
			}
			tableName = (String)viewDataElementList.get(0);
			selectValue = selectValue + viewName + "." + (String)viewDataElementList.get(1);
			selectValue = selectValue + " " + (String)viewDataElementList.get(3);
			selectValue = selectValue + " " + (String)viewDataElementList.get(4);
			
			int i=5;
		
			while (i<viewDataElementList.size()){
				if (!"NULL".equals((String)viewDataElementList.get(i))){
					selectValue = selectValue + " " + (String)viewDataElementList.get(i);
					selectValue = selectValue + " " + viewName + "." + (String)viewDataElementList.get(1);
					selectValue = selectValue + " " + (String)viewDataElementList.get(i+1);
					selectValue = selectValue + " " + (String)viewDataElementList.get(i+2);
				}
				i = i + 3;
			}
			
			if ("OR".equals((String)viewDataElementList.get(5))){
				selectValue = selectValue + ")";
			}
			
			if (appendCount !=  viewDataList.size() ) {
				if ("OR".equals((String)viewDataElementList.get(5)) || "AND".equals((String)viewDataElementList.get(5)))
					selectValue = selectValue + " " + (String)viewDataElementList.get(viewDataElementList.size()-1) + " " ;
				else 
					selectValue = selectValue + " " + (String)viewDataElementList.get(6) + " " ;
			} else {
				selectValue = selectValue + " " ;
			}
						
			columnCount = columnCount + 1 ;
			appendCount = appendCount + 1 ;
        }
		returnList.add(tableName);
		returnList.add(selectValue);
		
		return returnList ;
	}
	
	/**
	 * This method is used tp check for presense of view prior to insert(for duplicate check )
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return true/false
	 */
	public boolean viewCheck(Connection connection, List failureList, List args){
		ViewDAO viewDAO = new ViewDAO();
		List viewList = viewDAO.get(connection,failureList,args,qViewPrev);
		
		if (!viewList.isEmpty()){
			return true;
		}else {
			return false;
		}	
	}
	
	/**
	 * Private method to check for the presence of a previous data view for the current view. It will use the 
	 * view name obtained as one of the arguments, form a string representing the name of the view depicting the 
	 * previous view & check whether the returned list is empty or not
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return true/false
	 */
	public boolean previousViewCheck(Connection connection, List failureList, List args){
		ViewDAO viewDAO = new ViewDAO();
		List viewList = viewDAO.get(connection,failureList,args,qViewPrev);
		
		if (!viewList.isEmpty()){
			return true;
		}else {
			return false;
		}	
	}
	
	/**
	 * Private method that will return list of distinct db nodes which replicates following 2 queries in CFM
	 * 
	 * 1) GettnamesRABC = "SELECT DISTINCT TBL_NODE AS TBL_SUBSYS_ID FROM RABC_TABLE WHERE TBL_NODE <> 'RABC'";
	 * 2) GettnamesODR = "SELECT DISTINCT TBL_NODE AS TBL_SUBSYS_ID FROM RABC_TABLE WHERE TBL_NODE = 'RABC'";
	 * 
	 * @param region
	 * @return List
	 */ 
	public List getDistinctDbNodeList(String region){
		List dbNodeList = StaticDataLoader.getDBNodeList(region);
		List distinctDbNodeList = new ArrayList();
		
		int dbNodeListSize = dbNodeList.size();
		
		for (int i=0;i<dbNodeListSize;i++){
			PickList dbNode = (PickList)dbNodeList.get(i);
			boolean addFlag = true;
			
			int distinctDbNodeListSize = 0;
			if (!distinctDbNodeList.isEmpty()){
				distinctDbNodeListSize = distinctDbNodeList.size();
			}
			
			for (int j=0;j<distinctDbNodeListSize;j++){
				PickList existingDbNode = (PickList)distinctDbNodeList.get(j);
				
				if (dbNode.getKey().equals(existingDbNode.getKey())){
					addFlag = false;
				}
			}
			
			if (addFlag==true){
				distinctDbNodeList.add(dbNode);
			}
		}
		
		return distinctDbNodeList;
	}
	
	/**
	 * This method is used to return the view object given the view name as one of the arguments
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return List
	 */
	public List getViewNames(Connection connection,List failureList, List args){
		ViewDAO viewDAO = new ViewDAO();
		List viewList = viewDAO.get(connection,failureList,args,getViewNames);
		
		return viewList;
	}
}
