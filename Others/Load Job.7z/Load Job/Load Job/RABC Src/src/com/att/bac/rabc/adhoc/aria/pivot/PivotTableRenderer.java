/*
 * Copyright  2002-2007 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.adhoc.aria.pivot;

import com.sbc.bac.aria.ARIAReportProcessor;

public interface PivotTableRenderer {
    String renderBeginTable(ARIAReportProcessor processor);

    String renderEndTable(ARIAReportProcessor processor);
}
