/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.admin;

/**
 * This is a Data Object to represent RABC_MENU_INDEX table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class MenuIndex {
	private String presnType;
	private String presnName;
	private int presnLvl;
	private int presnSeqNum;
	private int assocParentId;
	private int subAssocParentId;
	private int presnId;
	private String alertRule;

	/**
	 * @return Returns the PresnType.
	 */
	public String getPresnType() {
		return presnType;
	}
	/**
	 * @return Returns the PresnName.
	 */
	public String getPresnName() {
		return presnName;
	}
	/**
	 * @return Returns the PresnLvl.
	 */
	public int getPresnLvl() {
		return presnLvl;
	}
	/**
	 * @return Returns the PresnSeqNum.
	 */
	public int getPresnSeqNum() {
		return presnSeqNum;
	}
	/**
	 * @return Returns the AssocParentId.
	 */
	public int getAssocParentId() {
		return assocParentId;
	}
	/**
	 * @return Returns the SubAssocParentId.
	 */
	public int getSubAssocParentId() {
		return subAssocParentId;
	}
	/**
	 * @return Returns the PresnId.
	 */
	public int getPresnId() {
		return presnId;
	}
	/**
	 * @return Returns the AlertRule.
	 */
	public String getAlertRule() {
		return alertRule;
	}

	/**
	 * @param PresnType The presnType to set.
	 */
	public void setPresnType(String presnType) {
		this.presnType = presnType;
	}
	/**
	 * @param PresnName The presnName to set.
	 */
	public void setPresnName(String presnName) {
		this.presnName = presnName;
	}
	/**
	 * @param PresnLvl The presnLvl to set.
	 */
	public void setPresnLvl(int presnLvl) {
		this.presnLvl = presnLvl;
	}
	/**
	 * @param PresnSeqNum The presnSeqNum to set.
	 */
	public void setPresnSeqNum(int presnSeqNum) {
		this.presnSeqNum = presnSeqNum;
	}
	/**
	 * @param AssocParentId The assocParentId to set.
	 */
	public void setAssocParentId(int assocParentId) {
		this.assocParentId = assocParentId;
	}
	/**
	 * @param SubAssocParentId The subAssocParentId to set.
	 */
	public void setSubAssocParentId(int subAssocParentId) {
		this.subAssocParentId = subAssocParentId;
	}
	/**
	 * @param PresnId The presnId to set.
	 */
	public void setPresnId(int presnId) {
		this.presnId = presnId;
	}
	/**
	 * @param AlertRule The alertRule to set.
	 */
	public void setAlertRule(String alertRule) {
		this.alertRule = alertRule;
	}
}
