/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc;
import java.util.Date;

/**
 * This is a Data Object to represent RABC_PRESN_ID table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class PresnId {
	private int presnId;
	private String presnIdDesc;
	private String asocFileId;
	private String presnTblName;
	private String procDateDdlName;
	private int divisionNameKeyLvl;
	private String presnIdPresnInd;
	private int execPresnSeqNum;
	private int begSubTotLvl;
	private int endSubTotLvl;
	private int presnModel;
	private String adhocRptInd;
	private String adhocRptStatus;
	private String dbNodeId;
	private Date effDt;
	private String presnTrendTime;
	private String presnDurTime;
	private String timingFilterCode;

	/**
	 * @return Returns the PresnId.
	 */
	public int getPresnId() {
		return presnId;
	}
	/**
	 * @return Returns the PresnIdDesc.
	 */
	public String getPresnIdDesc() {
		return presnIdDesc;
	}
	/**
	 * @return Returns the AsocFileId.
	 */
	public String getAsocFileId() {
		return asocFileId;
	}
	/**
	 * @return Returns the PresnTblName.
	 */
	public String getPresnTblName() {
		return presnTblName;
	}
	/**
	 * @return Returns the ProcDateDdlName.
	 */
	public String getProcDateDdlName() {
		return procDateDdlName;
	}
	/**
	 * @return Returns the DivisionNameKeyLvl.
	 */
	public int getDivisionNameKeyLvl() {
		return divisionNameKeyLvl;
	}
	/**
	 * @return Returns the PresnIdPresnInd.
	 */
	public String getPresnIdPresnInd() {
		return presnIdPresnInd;
	}
	/**
	 * @return Returns the ExecPresnSeqNum.
	 */
	public int getExecPresnSeqNum() {
		return execPresnSeqNum;
	}
	/**
	 * @return Returns the BegSubTotLvl.
	 */
	public int getBegSubTotLvl() {
		return begSubTotLvl;
	}
	/**
	 * @return Returns the EndSubTotLvl.
	 */
	public int getEndSubTotLvl() {
		return endSubTotLvl;
	}
	/**
	 * @return Returns the PresnModel.
	 */
	public int getPresnModel() {
		return presnModel;
	}
	/**
	 * @return Returns the AdhocRptInd.
	 */
	public String getAdhocRptInd() {
		return adhocRptInd;
	}
	/**
	 * @return Returns the AdhocRptStatus.
	 */
	public String getAdhocRptStatus() {
		return adhocRptStatus;
	}
	/**
	 * @return Returns the DbNodeId.
	 */
	public String getDbNodeId() {
		return dbNodeId;
	}
	/**
	 * @return Returns the EffDt.
	 */
	public Date getEffDt() {
		return effDt;
	}
	/**
	 * @return Returns the PresnTrendTime.
	 */
	public String getPresnTrendTime() {
		return presnTrendTime;
	}
	/**
	 * @return Returns the PresnDurTime.
	 */
	public String getPresnDurTime() {
		return presnDurTime;
	}
	/**
	 * @return Returns the TimingFilterCode.
	 */
	public String getTimingFilterCode() {
		return timingFilterCode;
	}

	/**
	 * @param PresnId The presnId to set.
	 */
	public void setPresnId(int presnId) {
		this.presnId = presnId;
	}
	/**
	 * @param PresnIdDesc The presnIdDesc to set.
	 */
	public void setPresnIdDesc(String presnIdDesc) {
		this.presnIdDesc = presnIdDesc;
	}
	/**
	 * @param AsocFileId The asocFileId to set.
	 */
	public void setAsocFileId(String asocFileId) {
		this.asocFileId = asocFileId;
	}
	/**
	 * @param PresnTblName The presnTblName to set.
	 */
	public void setPresnTblName(String presnTblName) {
		this.presnTblName = presnTblName;
	}
	/**
	 * @param ProcDateDdlName The procDateDdlName to set.
	 */
	public void setProcDateDdlName(String procDateDdlName) {
		this.procDateDdlName = procDateDdlName;
	}
	/**
	 * @param DivisionNameKeyLvl The divisionNameKeyLvl to set.
	 */
	public void setDivisionNameKeyLvl(int divisionNameKeyLvl) {
		this.divisionNameKeyLvl = divisionNameKeyLvl;
	}
	/**
	 * @param PresnIdPresnInd The presnIdPresnInd to set.
	 */
	public void setPresnIdPresnInd(String presnIdPresnInd) {
		this.presnIdPresnInd = presnIdPresnInd;
	}
	/**
	 * @param ExecPresnSeqNum The execPresnSeqNum to set.
	 */
	public void setExecPresnSeqNum(int execPresnSeqNum) {
		this.execPresnSeqNum = execPresnSeqNum;
	}
	/**
	 * @param BegSubTotLvl The begSubTotLvl to set.
	 */
	public void setBegSubTotLvl(int begSubTotLvl) {
		this.begSubTotLvl = begSubTotLvl;
	}
	/**
	 * @param EndSubTotLvl The endSubTotLvl to set.
	 */
	public void setEndSubTotLvl(int endSubTotLvl) {
		this.endSubTotLvl = endSubTotLvl;
	}
	/**
	 * @param PresnModel The presnModel to set.
	 */
	public void setPresnModel(int presnModel) {
		this.presnModel = presnModel;
	}
	/**
	 * @param AdhocRptInd The adhocRptInd to set.
	 */
	public void setAdhocRptInd(String adhocRptInd) {
		this.adhocRptInd = adhocRptInd;
	}
	/**
	 * @param AdhocRptStatus The adhocRptStatus to set.
	 */
	public void setAdhocRptStatus(String adhocRptStatus) {
		this.adhocRptStatus = adhocRptStatus;
	}
	/**
	 * @param DbNodeId The dbNodeId to set.
	 */
	public void setDbNodeId(String dbNodeId) {
		this.dbNodeId = dbNodeId;
	}
	/**
	 * @param EffDt The effDt to set.
	 */
	public void setEffDt(Date effDt) {
		this.effDt = effDt;
	}
	/**
	 * @param PresnTrendTime The presnTrendTime to set.
	 */
	public void setPresnTrendTime(String presnTrendTime) {
		this.presnTrendTime = presnTrendTime;
	}
	/**
	 * @param PresnDurTime The presnDurTime to set.
	 */
	public void setPresnDurTime(String presnDurTime) {
		this.presnDurTime = presnDurTime;
	}
	/**
	 * @param TimingFilterCode The timingFilterCode to set.
	 */
	public void setTimingFilterCode(String timingFilterCode) {
		this.timingFilterCode = timingFilterCode;
	}
}
