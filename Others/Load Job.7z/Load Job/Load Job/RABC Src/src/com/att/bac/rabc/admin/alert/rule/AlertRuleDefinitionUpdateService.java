/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.admin.alert.rule;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;

import com.att.bac.rabc.Column;
import com.att.bac.rabc.ProgressBar;
import com.att.bac.rabc.StaticDataLoader;

/**
 * This is a Service class for Updating Trend and Track Alert Rule.
 * 
 * @author Shashank Weginwar - SW3562
 */
public class AlertRuleDefinitionUpdateService {
	private static final Logger logger = Logger.getLogger(AlertRuleDefinitionService.class);
	private static AlertRuleDefinitionUpdateService alertRuleUpdateService;
	
	/**
	 * Synchronized method to return the instance of AlertRuleDefinitionUpdateService object.
	 * It checks the existance of the instance of AlertRuleDefinitionUpdateService and if it does not exists
	 * then creates one instance of AlertRuleDefinitionUpdateService and returns otherwise it returns the
	 * existing instance of AlertRuleDefinitionUpdateService.
	 * 
	 * @return AlertRuleDefinitionUpdateService
	 */
	public static synchronized AlertRuleDefinitionUpdateService getAlertRuleUpdateService(){
		if (alertRuleUpdateService == null){
			alertRuleUpdateService = new AlertRuleDefinitionUpdateService();
		}
		return alertRuleUpdateService;
	}

	
	/**
	 * This is a main method which updates Trend and Track rules.
	 * 
	 * @param connection
	 * @param failures
	 * @param args
	 * @param alertRuleDefinition
	 * @param progressBar
	 * @param region
	 * @return boolean
	 */
	public boolean updateTrendAndTrackRule (Connection connection, List failures, List args, AlertRuleDefinition alertRuleDefinition, ProgressBar progressBar, String region){
		int mouseOverNumArray [] = new int [5];
		String userId = (String) args.get(0);
		String[] selectedRelatedAlerts = (String []) args.get(2);
		
		/*
		 * Updates values of RABC_ALERT_RULE table.
		 */
		if(!updateAlertRule(connection, failures, alertRuleDefinition,userId)){
			return false;
		}
		
		/*
		 * Updates values to RABC_STD_CALC
		 */
		if (!updateStdDeviation(connection, failures, alertRuleDefinition)){
			return false;
		}
		
		/*
		 * Delete & insert - RABC_TRIG_CONVERT only for Monthly Rule
		 */
		if ("M".equals(alertRuleDefinition.getAlertRuleTiming())){
			if(!deleteTrigConvert(connection, failures, alertRuleDefinition)){
				return false;
			}
			
			if(!insertTrigConvert(connection, failures, alertRuleDefinition)){
				return false;
			}
		}
		
		/*
		 * Updates values of RABC_UPDATE_GRP table.
		 */
		if(!deleteAlertGroup(connection, failures, alertRuleDefinition)){
			return false;
		}
		
		/*
		 * Insert values into RABC_UPDATE_GRP table.
		 */
		if(!insertAlertGroup(connection, failures, alertRuleDefinition)){
			return false;
		}
		progressBar.setProgressPercent(20);
		
		/*
		 * Delete values of RABC_CNTRL_PT_ALERT table.
		 */
		if(!deleteControlPoint(connection, failures, alertRuleDefinition)){
			return false;
		}

		/*
		 * Inserts values into RABC_CNTRL_PT_ALERT table.
		 */
		if(!insertControlPoint(connection, failures, alertRuleDefinition)){
			return false;
		}
		
		String msgInd = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().getAlertRuleDetails(connection, failures, alertRuleDefinition);
		if (msgInd.equals("Y")){
			
			/*
			 * Delete values of RABC_PROC_RESPONSIBLE table.
			 */
			if(!deleteProcResponsible(connection, failures, alertRuleDefinition)){
				return false;
			}
			
			/*
			 * Insert vaules into RABC_PROC_RESPONSIBLE table.
			 */
			if(!insertDefaultProcResponsible(connection, failures, alertRuleDefinition)){
				return false;
			}
			
			/*
			 * Insert vaules into RABC_PROC_RESPONSIBLE table.
			 */
			if(!insertProcResponsible(connection, failures, alertRuleDefinition)){
				return false;
			}
		}
		progressBar.setProgressPercent(30);
		
		/*
		 * Update values of RABC_ALERT_PROC table.
		 */
		if(!updateAlertProc(connection, failures, alertRuleDefinition)){
			return false;
		}
		
		/*
		 * Update values of RABC_AVG_CALC table.
		 */
		if(!updateAvgCalc(connection, failures, alertRuleDefinition)){
			return false;
		}
		progressBar.setProgressPercent(40);
		
		if ("Trend".equals(alertRuleDefinition.getAlertRuleType()) || "2".equals(alertRuleDefinition.getAlertRuleType())){
			int alertItemListSize = alertRuleDefinition.getAlertItemList().size();
			for(int j = 0; j < alertItemListSize; j++){			
				
				String colName = null;
				colName = ((AlertItem)(alertRuleDefinition.getAlertItemList().get(j))).getItemName();
																	
				List suppList = new ArrayList();
				int selectedSupplementTypeLength = ((SupplementType)((AlertItem)(alertRuleDefinition.getAlertItemList().get(j))).getSupplementType()).getSelectedSupplementType().length;
				for(int i = 0; i < selectedSupplementTypeLength; i++){
					suppList.add(((SupplementType)((AlertItem)(alertRuleDefinition.getAlertItemList().get(j))).getSupplementType()).getSelectedSupplementType()[i]);
				}
				
				/*
				 * Delete values of RABC_ALERT_SUPP_RULE table.
				 */
				if(!deleteSuppRule_1(connection, failures, colName, alertRuleDefinition)){
					return false;
				}
				
				/*
				 * Insert values into RABC_ALERT_SUPP_RULE table.
				 */
				if(!insertSuppRule_1(connection, failures, colName, suppList, j, alertRuleDefinition)){
					return false;
				}
			}
		}
	
		if ("Track".equals(alertRuleDefinition.getAlertRuleType()) || "1".equals(alertRuleDefinition.getAlertRuleType())){
			String suppItemDDLName = null;
			suppItemDDLName = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().getDdlName(connection, failures, alertRuleDefinition);
			
			if (suppItemDDLName ==null) {
				suppItemDDLName = "EXTRCT_DATA1";
			}
			
			int alertItemListSize = alertRuleDefinition.getAlertItemList().size();
			for(int i = 1; i <= alertItemListSize; i++ ){
				deleteSuppRule_2(connection, failures, i, alertRuleDefinition);
				List suppList = new ArrayList();
				 
				if(((AlertItem)(alertRuleDefinition.getAlertItemList().get(i-1))).getSupplementType() != null){
					int selectedSupplementTypeLength = ((SupplementType)((AlertItem)(alertRuleDefinition.getAlertItemList().get(i-1))).getSupplementType()).getSelectedSupplementType().length;
					for(int j = 0; j < selectedSupplementTypeLength; j++){
						suppList.add(((SupplementType)((AlertItem)(alertRuleDefinition.getAlertItemList().get(i-1))).getSupplementType()).getSelectedSupplementType()[j]);
					}
				}else{
					suppList = new ArrayList();
				}
				
				/*
				 * Insert values into RABC_ALERT_SUPP_RULE table.
				 */
				if(!insertSuppRule_2(connection, failures, suppList, i, suppItemDDLName, alertRuleDefinition)){
					return false;
				}
			}
		}
		progressBar.setProgressPercent(50);
		
		/*
		 * Delete values of RABC_ALERT_SUMY_PRESN table.
		 */
		if(!deleteAlertSumy(connection, failures, alertRuleDefinition)){
			return false;
		}
		int selectedRelatedAlertsLength = 0;
		if(selectedRelatedAlerts != null){
			selectedRelatedAlertsLength = selectedRelatedAlerts.length;
		}
		if(selectedRelatedAlertsLength > 0){
			String [] asocidArray = new String [selectedRelatedAlertsLength];
			for(int i = 0; i < selectedRelatedAlerts.length; i++){
				String presnId = null;
				String [] argument = new String [1];
				argument[0] =  selectedRelatedAlerts[i];
				presnId = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().getAlertRuleDetails(connection, failures, argument);
				asocidArray[i] = presnId;
			}
			
			int asocidArrayLength = asocidArray.length;
			
			if (asocidArrayLength > 0){
				if(!insertAlertSumy(connection, failures, asocidArray, alertRuleDefinition)){
					return false;
				}
			}
		}
		progressBar.setProgressPercent(60);
		
		if("Trend".equals(alertRuleDefinition.getAlertRuleType()) || "2".equals(alertRuleDefinition.getAlertRuleType())){
			/*
			 * Delete values of RABC_ALERT_RULE_PRESN_ELEM table.
			 */
			if(!deleteAlertRulePresenElemTrend(connection, failures, alertRuleDefinition)){
				return false;
			}
			
			/*
			 * Insert values into RABC_ALERT_RULE_PRESN_ELEM table.
			 */
			if(!insertAlertRulePresenElemTrend(connection, failures, alertRuleDefinition, region)){
				return false;
			}
		}
		
		if("Track".equals(alertRuleDefinition.getAlertRuleType()) || "1".equals(alertRuleDefinition.getAlertRuleType())){
			/*
			 * Delete values of RABC_EXTRCT_BUILD_RULE table.
			 */
			if(!deleteExtrctBuildRuleTrack(connection, failures, alertRuleDefinition)){
				return false;
			}
			
			/*
			 * Insert values into RABC_EXTRCT_BUILD_RULE table.
			 */
			if(!insertExtrctBuildRuleTrack(connection, failures, alertRuleDefinition)){
				return false;
			}
			
			/*
			 * Delete values of RABC_AVG_TBL_DEF table.
			 */
			if(!deleteAvgTblDefTrack(connection, failures, alertRuleDefinition)){
				return false;
			}
			
			/*
			 * Insert values into RABC_AVG_TBL_DEF table.
			 */
			if(!insertAvgTblDefTrack(connection, failures, alertRuleDefinition)){
				return false;
			}
			
		}
		progressBar.setProgressPercent(70);
		
		/*
		 * Delete values of RABC_ALERT_PROC table.
		 */
		if(!deleteAlertProc(connection, failures, alertRuleDefinition)){
			return false;
		}
		
		/*
		 * Insert values into RABC_ALERT_PROC table.
		 */
		if(!insertAlertProc(connection, failures, alertRuleDefinition)){
			return false;
		}
		
		/*
		 * Delete values of RABC_EXTRCT_TBL_DEF table.
		 */
		if(!deleteExtrctTblDef(connection, failures, alertRuleDefinition)){
			return false;
		}
		
		/*
		 * Insert values into RABC_EXTRCT_TBL_DEF table.
		 */
		if(!insertExtrctTblDef(connection, failures, alertRuleDefinition)){
			return false;
		}
		progressBar.setProgressPercent(80);
		
		/*
		 * Delete values of RABC_TRACK_FILE_DTL table.
		 */
		if(!deleteTrackFileDtl(connection, failures, alertRuleDefinition)){
			return false;
		}
		
		/*
		 * Insert values into RABC_TRACK_FILE_DTL table.
		 */
		if(!insertTrackFileDtl(connection, failures, alertRuleDefinition)){
			return false;
		}
		
		/*
		 * Delete values of RABC_MOUSE_OVER_LINK table.
		 */
		if(!deleteMouseOverLink(connection, failures, alertRuleDefinition)){
			return false;
		}
		
		/*
		 * Insert values into RABC_MOUSE_OVER_LINK table.
		 */
		if(!insertMouseOverLink(connection, failures, alertRuleDefinition, mouseOverNumArray)){
			return false;
		}
		progressBar.setProgressPercent(90);
		
		/*
		 * Update values of RABC_ALERT_RULE_PRESN_RULE table.
		 */
		if(!updateAlertRulePresnRule (connection, failures, alertRuleDefinition, mouseOverNumArray)){
			return false;
		}
		
		/*
		 * Update values of RABC_ALERT_RULE_PRESN_RULE table for report link to keys.
		 */
		if(!updateAlertRulePresnRuleForReportLink(connection, failures, alertRuleDefinition)){
			return false;
		}
		
		/*
		 * Delete values of RABC_WEB_DATA_LINK table.
		 */
		if(!deleteWebDataLink(connection, failures, alertRuleDefinition)){
			return false;
		}
		
		/*
		 * Insert values into RABC_WEB_DATA_LINK table.
		 */
		if(!insertWebDataLink(connection, failures, alertRuleDefinition)){
			return false;
		}
		return true;
	}
	
	/**
	 * Updates values of RABC_ALERT_RULE table.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertRuleDefinition
	 * @param userId
	 * @return boolean
	 */
	private boolean updateAlertRule(Connection connection, List failures, AlertRuleDefinition alertRuleDefinition, String userId){
		boolean success = true;
		int pickSql = 1;
		List updARDArguments = new ArrayList();
		updARDArguments.add(alertRuleDefinition.getAlertRuleDescription());
		if (alertRuleDefinition.getDelayExecutionTime()==-1){
			pickSql = 2;
		}else {
			updARDArguments.add(Integer.toString(alertRuleDefinition.getDelayExecutionTime()));   
		}
		updARDArguments.add(alertRuleDefinition.getEffectiveDate());
		updARDArguments.add(alertRuleDefinition.getAlertRule());

		if (alertRuleDefinition.getAlertDataKeep()==-1){
			updARDArguments.add("");
		}else {
			updARDArguments.add(Integer.toString(alertRuleDefinition.getAlertDataKeep()));
		}
		updARDArguments.add(userId);
		
		/*
		 * Code added as a part of PMT 284847
		 */
		if ("M".equals(alertRuleDefinition.getAlertRuleTiming())){
			if ("B".equals(alertRuleDefinition.getAlertRuleMonthlyTimingType())){
				updARDArguments.add("");
				updARDArguments.add(alertRuleDefinition.getMnthExecBillRnd());
			}else {
				updARDArguments.add(alertRuleDefinition.getMnthExecDt());
				updARDArguments.add("");
			}
		} else {
			updARDArguments.add("");
			updARDArguments.add("");
		}
		
		/*
		 * Enabling update of ALERT_EXEMPT_IND
		 */
		if ("on".equals(alertRuleDefinition.getThresholdExemptionCheck())){
			updARDArguments.add("Y");
		}else {
			updARDArguments.add("N");
		}

		success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().alertRuleTransaction(connection, failures, updARDArguments, alertRuleDefinition,pickSql);
		return success;
	}
	
	/**
	 * Updates values of RABC_STD_CALC table.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertRuleDefinition
	 * @param userId
	 * @return boolean
	 */
	private boolean updateStdDeviation(Connection connection, List failures, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;

		List updStdArguments = new ArrayList();
		updStdArguments.add(alertRuleDefinition.getStdNumDate());
		updStdArguments.add(alertRuleDefinition.getAlertRule());

		success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().updateStdDeviation(connection, failures, updStdArguments, alertRuleDefinition);
		return success;
	}
	
	/**
	 * Updates values of RABC_UPDATE_GRP table.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean deleteAlertGroup(Connection connection, List failures, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		List delAlGroupArguments = new ArrayList();
		delAlGroupArguments.add(alertRuleDefinition.getAlertRule());
		success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().alertGroupTransaction(connection, failures, delAlGroupArguments, 1, alertRuleDefinition);
		return success;
	}
	
	/**
	 * Insert values into RABC_UPDATE_GRP table.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean insertAlertGroup(Connection connection, List failures, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		for(int i = 0; i < (alertRuleDefinition.getAlertGroups().length); i++){
			List insAlGrpArguments = new ArrayList();
			insAlGrpArguments.add(alertRuleDefinition.getAlertRule());
			insAlGrpArguments.add(alertRuleDefinition.getAlertGroups()[i]);
			success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().alertGroupTransaction(connection, failures, insAlGrpArguments, 2, alertRuleDefinition);
		}
		return success;
	}
	
	/**
	 * Delete values of RABC_CNTRL_PT_ALERT table.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean deleteControlPoint(Connection connection, List failures, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		List delCntPArguments = new ArrayList();
		delCntPArguments.add(alertRuleDefinition.getAlertRule());
		success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().cntrlPtAlertTransaction(connection, failures, delCntPArguments, 1, alertRuleDefinition);
		return success;
	}
	
	/**
	 * Inserts values into RABC_CNTRL_PT_ALERT table.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean insertControlPoint(Connection connection, List failures, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		List insRabcCntrlPtAlertArguments = new ArrayList();
		insRabcCntrlPtAlertArguments.add(alertRuleDefinition.getControlPoint());
		insRabcCntrlPtAlertArguments.add(alertRuleDefinition.getAlertRule());
		int presnSeqNum = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().getCntrlPtTrans (connection, failures, alertRuleDefinition);
		insRabcCntrlPtAlertArguments.add((new Integer (presnSeqNum)).toString());
		success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().cntrlPtAlertTransaction(connection, failures, insRabcCntrlPtAlertArguments, 2, alertRuleDefinition);
		return success;
	}
	
	/**
	 * Delete values of RABC_PROC_RESPONSIBLE table.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean deleteProcResponsible(Connection connection, List failures, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		List delMsgArguments = new ArrayList();
		delMsgArguments.add(alertRuleDefinition.getAlertRule());
		success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().procResponsibleTransaction(connection, failures, delMsgArguments, 1, alertRuleDefinition);
		return success;
	}
	
	/**
	 * Insert vaules into RABC_PROC_RESPONSIBLE table.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean insertDefaultProcResponsible(Connection connection, List failures, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		List defaultUpdRabcProcResponsibleArguments = new ArrayList();
		defaultUpdRabcProcResponsibleArguments.add(alertRuleDefinition.getAlertRule());
		defaultUpdRabcProcResponsibleArguments.add("1");
		defaultUpdRabcProcResponsibleArguments.add("BAC RABC SYS SUPPORT");
		success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().procResponsibleTransaction(connection, failures, defaultUpdRabcProcResponsibleArguments, 2, alertRuleDefinition);
		return success;
	}
	
	/**
	 * Insert vaules into RABC_PROC_RESPONSIBLE table.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean insertProcResponsible(Connection connection, List failures, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		for(int i = 0; i < alertRuleDefinition.getAlertGroups().length; i ++){
			List updRabcProcResponsibleArguments = new ArrayList();
			updRabcProcResponsibleArguments.add(alertRuleDefinition.getAlertRule());
			updRabcProcResponsibleArguments.add("2");
			updRabcProcResponsibleArguments.add(alertRuleDefinition.getAlertGroups()[i]);
			success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().procResponsibleTransaction(connection, failures, updRabcProcResponsibleArguments, 2, alertRuleDefinition);
		}
		return success;
	}
	
	/**
	 * Update values of RABC_ALERT_PROC table.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean updateAlertProc(Connection connection, List failures, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		for(int i = 1; i <= alertRuleDefinition.getAlertItemList().size(); i++){
			String valt = null;
			String alit = null;
			valt = ((AlertItem)(alertRuleDefinition.getAlertItemList().get(i-1))).getAlertType();
			alit = ((AlertItem)(alertRuleDefinition.getAlertItemList().get(i-1))).getItemName();
			List updRabcAlertProcArguments = new ArrayList();
			updRabcAlertProcArguments.add(valt);
			if((((AlertItem)(alertRuleDefinition.getAlertItemList().get(i-1))).getWarningIndicator()).equals("Y")){
				updRabcAlertProcArguments.add("Y");
			}else {
				updRabcAlertProcArguments.add("N");
			}
			updRabcAlertProcArguments.add(alertRuleDefinition.getAlertRule());
			updRabcAlertProcArguments.add(alit);
			success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().alertProcTransaction(connection, failures, updRabcAlertProcArguments, alertRuleDefinition);
		}
		return success;
	}
	
	/**
	 * Update values of RABC_AVG_CALC table.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean updateAvgCalc(Connection connection, List failures, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		List updAvgCalcArguments = new ArrayList();
		updAvgCalcArguments.add(alertRuleDefinition.getAverageDays());
		updAvgCalcArguments.add(alertRuleDefinition.getAverageRecords());
		updAvgCalcArguments.add(alertRuleDefinition.getAverageType());
		updAvgCalcArguments.add(alertRuleDefinition.getAlertRule());
		if(alertRuleDefinition.getAverageDays() == null && alertRuleDefinition.getAverageRecords() == null){
			success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().avgCalcTransaction(connection, failures, updAvgCalcArguments, 4, alertRuleDefinition);
		}else if(alertRuleDefinition.getAverageDays() != null && alertRuleDefinition.getAverageRecords() == null){
			success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().avgCalcTransaction(connection, failures, updAvgCalcArguments, 3, alertRuleDefinition);
		}else if(alertRuleDefinition.getAverageDays() == null && alertRuleDefinition.getAverageRecords() != null){
			success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().avgCalcTransaction(connection, failures, updAvgCalcArguments, 2, alertRuleDefinition);
		}else if(alertRuleDefinition.getAverageDays() != null && alertRuleDefinition.getAverageRecords() != null){
			success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().avgCalcTransaction(connection, failures, updAvgCalcArguments, 1, alertRuleDefinition);
		}
		return success;
	}
	
	/**
	 * Delete values of RABC_ALERT_SUPP_RULE table.
	 * 
	 * @param connection
	 * @param failures
	 * @param colName
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean deleteSuppRule_1(Connection connection, List failures, String colName, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		List delSuppArguments = new ArrayList();
		delSuppArguments.add(alertRuleDefinition.getAlertRule());
		delSuppArguments.add(colName);
		success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().alertSuppRuleTransaction(connection, failures, delSuppArguments, 1, alertRuleDefinition);
		return success;
	}
	
	/**
	 * Insert values into RABC_ALERT_SUPP_RULE table.
	 * 
	 * @param connection
	 * @param failures
	 * @param colName
	 * @param suppList
	 * @param j
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean insertSuppRule_1(Connection connection, List failures, String colName, List suppList, int j, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		for(int i = 0; i < suppList.size(); i++){
			List insSuppArguments = new ArrayList();
			insSuppArguments.add(alertRuleDefinition.getAlertRule());
			insSuppArguments.add(colName);
			insSuppArguments.add((new Integer(i+1)).toString());
			insSuppArguments.add("EXTRCT_DATA"+(new Integer(j+1)).toString());
			insSuppArguments.add(suppList.get(i));
			success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().alertSuppRuleTransaction(connection, failures, insSuppArguments, 2, alertRuleDefinition);
		}
		return success;
	}
	
	/**
	 * Delete values of RABC_ALERT_SUPP_RULE table.
	 * 
	 * @param connection
	 * @param failures
	 * @param i
	 * @param alertRuleDefinition
	 * @return boolean
	 */ 
	private boolean deleteSuppRule_2(Connection connection, List failures, int i, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		List delSuppArguments = new ArrayList();
		delSuppArguments.add(alertRuleDefinition.getAlertRule());
		delSuppArguments.add(((AlertItem)(alertRuleDefinition.getAlertItemList().get(i-1))).getItemName());
		success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().alertSuppRuleTransaction(connection, failures, delSuppArguments, 1, alertRuleDefinition);
		return success;
	}
	
	/**
	 * Insert values into RABC_ALERT_SUPP_RULE table.
	 * 
	 * @param connection
	 * @param failures
	 * @param suppList
	 * @param i
	 * @param suppItemDDLName
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean insertSuppRule_2(Connection connection, List failures, List suppList, int i, String suppItemDDLName, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		for(int j = 0; j < suppList.size(); j++){
			List insSuppArguments = new ArrayList();
			insSuppArguments.add(alertRuleDefinition.getAlertRule());
			insSuppArguments.add(((AlertItem)(alertRuleDefinition.getAlertItemList().get(i-1))).getItemName());
			insSuppArguments.add((new Integer(j+1)).toString());
			insSuppArguments.add(suppList.get(j));
			insSuppArguments.add(suppItemDDLName);
			insSuppArguments.add(suppList.get(j));
			success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().alertSuppRuleTransaction(connection, failures, insSuppArguments, 3, alertRuleDefinition);
		}
		return success;
	}
	
	/**
	 * Delete values of RABC_ALERT_SUMY_PRESN table.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean deleteAlertSumy(Connection connection, List failures, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		List delRelArguments = new ArrayList();
		String[] argument = new String [1];
		String presnId = null;
		String[] asocPresnId = new String [1];
		argument[0] = alertRuleDefinition.getAlertRule();
		presnId = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().getAlertRuleDetails(connection, failures, argument);
		asocPresnId[0] = presnId; 
		delRelArguments.add(alertRuleDefinition.getAlertRule());
		delRelArguments.add(presnId);
		success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().alertSumyPresnTransaction(connection, failures, delRelArguments, 1, alertRuleDefinition);
		return success;
	}
	
	/**
	 * Insert values into RABC_ALERT_SUMY_PRESN table.
	 * 
	 * @param connection
	 * @param failures
	 * @param asocidArray
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean insertAlertSumy(Connection connection, List failures, String [] asocidArray, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		for(int i = 0; i < asocidArray.length; i++){
			int count = i + 2;
			List insRabcAlertSumyPresnRelArguments = new ArrayList(); 
			if ("Track".equals(alertRuleDefinition.getAlertRuleType()) || "1".equals(alertRuleDefinition.getAlertRuleType())){
				insRabcAlertSumyPresnRelArguments.add(alertRuleDefinition.getAlertRule() + "_SUMY1");
				insRabcAlertSumyPresnRelArguments.add(alertRuleDefinition.getAlertRule());
				insRabcAlertSumyPresnRelArguments.add("RABCPSF00011");
				insRabcAlertSumyPresnRelArguments.add(Integer.toString(count));
				if(alertRuleDefinition.getFileSequenceIndicator() != null){
					if(alertRuleDefinition.getFileSequenceIndicator().equals("on")){
						insRabcAlertSumyPresnRelArguments.add("Y");
					} else {
						insRabcAlertSumyPresnRelArguments.add("N");
					}
				} else {
					insRabcAlertSumyPresnRelArguments.add("N");
				}
				insRabcAlertSumyPresnRelArguments.add(asocidArray[i]);				
			} else {
				insRabcAlertSumyPresnRelArguments.add(alertRuleDefinition.getAlertRule() + "_SUMY");
				insRabcAlertSumyPresnRelArguments.add(alertRuleDefinition.getAlertRule());
				insRabcAlertSumyPresnRelArguments.add("RABCPSF00011");
				insRabcAlertSumyPresnRelArguments.add(Integer.toString(count));
				if(alertRuleDefinition.getFileSequenceIndicator() != null){
					if(alertRuleDefinition.getFileSequenceIndicator().equals("on")){
						insRabcAlertSumyPresnRelArguments.add("Y");
					} else {
						insRabcAlertSumyPresnRelArguments.add("N");
					}
				} else {
					insRabcAlertSumyPresnRelArguments.add("N");
				}
				insRabcAlertSumyPresnRelArguments.add(asocidArray[i]);
			}
			
			success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().alertSumyPresnTransaction(connection, failures, insRabcAlertSumyPresnRelArguments, 2, alertRuleDefinition);
		}
		return success;
	}
	
	/**
	 * Delete from RABC_ALERT_RULE_PRESN_ELEM table for trending rule.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean deleteAlertRulePresenElemTrend(Connection connection, List failures, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		List delPresnRuleArgs = new ArrayList();
		AlertRule alertRule = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().getAlertRule(connection, failures, alertRuleDefinition);
		int newPresnId = alertRule.getPresnId();
		delPresnRuleArgs.add(Integer.toString(newPresnId));
		success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().deleteAlertRulePresenElemForTrend(connection, failures, delPresnRuleArgs);
		return success;
	}
	
	/**
	 * Insert into RABC_ALERT_RULE_PRESN_ELEM table for trending rule.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertRuleDefinition
	 * @param region
	 * @return
	 */
	private boolean insertAlertRulePresenElemTrend(Connection connection, List failures, AlertRuleDefinition alertRuleDefinition, String region){
		List leftColumnList = alertRuleDefinition.getLHSColumnsList();
		int leftColumnListSize = leftColumnList.size();
		boolean success = true;
		int pickSql = 0;
		String formatCode = null;
		
		AlertRule alertRule = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().getAlertRule(connection, failures, alertRuleDefinition);
		
		int newPresnId = alertRule.getPresnId();
		int newPartiId = alertRule.getPartiRefId();
		
		/*
		 * Modification in the code to insert a new row for timing equal to 'Bill-Round'.
		 */
		int iter = 1;
		if ("B".equals(alertRuleDefinition.getAlertRuleTiming())){
			List args0 = new ArrayList();
			args0.add(Integer.toString(newPresnId));
			args0.add("1");
			if ("MW".equals(region)){
				args0.add("PROCESS-GRP");
			}else {
				args0.add("BILL-RND");
			}
			args0.add(Integer.toString(newPartiId));
			args0.add("ALERT_TREND_TIME");
			args0.add(Integer.toString(0));
			args0.add("N");
			args0.add("N");
			args0.add("");
			args0.add("");
			args0.add("");
			iter = 2;
			success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().insertAlertRulePresenElemForTrend(connection, failures, args0);
		}

		/*
		 * Populate counter.
		 */
		int counter = 1;
		if (alertRuleDefinition.getReportLinkKey1()!=null && !"---Select---".equals(alertRuleDefinition.getReportLinkKey1())){
			counter++;
		}
		if (alertRuleDefinition.getReportLinkKey2()!=null && !"---Select---".equals(alertRuleDefinition.getReportLinkKey2())){
			counter++;
		}
		if (alertRuleDefinition.getReportLinkKey3()!=null && !"---Select---".equals(alertRuleDefinition.getReportLinkKey3())){
			counter++;
		}
		if (alertRuleDefinition.getReportLinkKey4()!=null && !"---Select---".equals(alertRuleDefinition.getReportLinkKey4())){
			counter++;
		}
		if (alertRuleDefinition.getReportLinkKey5()!=null && !"---Select---".equals(alertRuleDefinition.getReportLinkKey5())){
			counter++;
		}
		
		for (int i=0;i<leftColumnListSize;i++){
			Column column = (Column)leftColumnList.get(i);
			List args = new ArrayList();
			args.add(Integer.toString(newPresnId));
			args.add(Integer.toString(iter));
			args.add(column.getColumnTBLDDLName());
			args.add(Integer.toString(newPartiId));
			args.add("EXTRCT_DATA" + (i+1));
			String columnName = ((column).getColumnTBLDDLName());
			// Code to take care of calculation wherein we will get the format type of the calculation
			if ("CAL".equalsIgnoreCase(column.getColumnTBLDataType())){
				formatCode = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().getFormatCode(connection, failures,column.getColumnTBLDDLName()); //column.getColumnTBLDDLPRESCSNFormatType();
			}else {
				formatCode = StaticDataLoader.getMaxFormatTypeForTblDdlName(columnName, region);
			}
			
			if(formatCode == null){
				args.add(Integer.toString(0));
			}else{
				args.add(formatCode);
			}
			args.add("");
			args.add("Y");
			AlertItem alertItem = (AlertItem)alertRuleDefinition.getAlertItemList().get(i);
			if (alertItem.getReportLinkData()!=null && !"---Select---".equals(alertItem.getReportLinkData())){
				args.add("Y");
				args.add(Integer.toString(counter));
				counter++;
			}else {
				args.add("");
				args.add("");
			}
			if (alertItem.getAlertUnit()!=null && !"none".equals(alertItem.getAlertUnit())){
				args.add(alertItem.getAlertUnit());
			} else {
				args.add("");
			}
			success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().insertAlertRulePresenElemForTrend(connection, failures, args);
			iter = iter + 1;
		}
		return success;
	}
	
	/**
	 * Delete from RABC_ALERT_PROC table for track and trend rules.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean deleteAlertProc(Connection connection, List failures, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		List delAlertProcArgs = new ArrayList();
		String alertRule = alertRuleDefinition.getAlertRule();
		delAlertProcArgs.add(alertRule);
		success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().deleteAlertProc(connection, failures, delAlertProcArgs);
		return success;
	}
	
	/**
	 * Insert into RABC_ALERT_PROC table for track and trend rules.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean insertAlertProc(Connection connection, List failures, AlertRuleDefinition alertRuleDefinition){
		List alertItemList = alertRuleDefinition.getAlertItemList();
		List alertKeyList = alertRuleDefinition.getAlertKeyList();
		int alertItemListSize = alertItemList.size();
		boolean success = true;
		int msgSuppDataIndSize = 0;
		
		String ruleName = alertRuleDefinition.getAlertRule();
		
		AlertRule alertRule = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().getAlertRule(connection, failures, alertRuleDefinition);
		
		int newPartiId = alertRule.getPartiRefId();
		
		for (int i = 0; i < alertItemListSize; i++){
			List args = new ArrayList();
			AlertItem alertItem = (AlertItem)alertItemList.get(i);
			
			args.add(ruleName);
			args.add(alertItem.getAlertType());
			args.add(alertItem.getItemName());
			
			if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
				args.add("ALERT_DATA");
				args.add("AVG_DATA1");
				args.add("RABC_CALC_ALERT_DATA");
				args.add("RABC_AVG_DATA");
			} else {
				args.add("EXTRCT_DATA" + (i+1));
				args.add("AVG_DATA" + (i+1));
				args.add("RABC_EXTRCT_SUMY_DATA");
				args.add("RABC_AVG_DATA");
			}
			
			if ("Y".equals(alertItem.getWarningIndicator()) /*&& "DT".equals(tempTiming)*/){
				args.add("Y");
			} else {
				args.add("N");
			}
			
			if(alertItem.getSupplementType().getSelectedSupplementType() != null){
				msgSuppDataIndSize = alertItem.getSupplementType().getSelectedSupplementType().length;
			}
			
			if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
				if (msgSuppDataIndSize>0){
					args.add("Y");
				}else {
					args.add("N");
				}
			}
			
			args.add("");
			args.add("");
			args.add(Integer.toString(newPartiId));
			
			success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().insertAlertProc(connection, failures, args, alertRuleDefinition);
		}
		return success;
	}
	
	/**
	 * Delete from RABC_EXTRCT_TBL_DEF table for track and trend rules.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean deleteExtrctTblDef(Connection connection, List failures, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		List delExtrctTblDefArgs = new ArrayList();
		AlertRule alertRule = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().getAlertRule(connection, failures, alertRuleDefinition);
		int newPartiRefId = alertRule.getPartiRefId();
		delExtrctTblDefArgs.add(Integer.toString(newPartiRefId));
		success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().deleteExtrctTblDef(connection, failures, delExtrctTblDefArgs);
		return success;
	}
	
	/**
	 * Insert into RABC_EXTRCT_TBL_DEF table for track and trend rules.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean insertExtrctTblDef(Connection connection, List failures, AlertRuleDefinition alertRuleDefinition){
		List alertItemList = alertRuleDefinition.getAlertItemList();
		List alertKeyList = alertRuleDefinition.getAlertKeyList();
		int alertItemListSize = alertItemList.size();
		boolean success = true;
		
		AlertRule alertRule = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().getAlertRule(connection, failures, alertRuleDefinition);
		int newPartiId = alertRule.getPartiRefId();
		
		int alertKeyLevel = alertRuleDefinition.getAlertKeyLevel();
		
		List leftColumnList = alertRuleDefinition.getLHSColumnsList();
		List rightColumnList = alertRuleDefinition.getRHSColumnsList();
		int leftCount=0;
		int rightCount=0;
		int totalCount=0;
		if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
			leftCount = leftColumnList.size();
			rightCount = rightColumnList.size();
			totalCount = leftCount + rightCount;
		} else {
			totalCount = leftColumnList.size();
		}
		
		if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
			for (int i=0;i<alertItemListSize;i++){
				List args = new ArrayList();
				AlertItem alertItem = (AlertItem)alertItemList.get(i);
				
				args.add(Integer.toString(newPartiId));
				args.add(Integer.toString(alertKeyLevel));
				
				if (alertKeyLevel>=1){
					args.add("ALERT_KEY1");
				}else {
					args.add("");
				}
				if (alertKeyLevel>=2){
					args.add("ALERT_KEY2");
				}else {
					args.add("");
				}
				if (alertKeyLevel>=3){
					args.add("ALERT_KEY3");
				}else {
					args.add("");
				}
				if (alertKeyLevel>=4){
					args.add("ALERT_KEY4");
				}else {
					args.add("");
				}
				if (alertKeyLevel>=5){
					args.add("ALERT_KEY5");
				}else {
					args.add("");
				}
				
				args.add(alertItem.getItemName());
				args.add(Integer.toString(totalCount));
				args.add(Integer.toString(leftCount));
				args.add(Integer.toString(rightCount));
				
				int keyListSize = alertRuleDefinition.getAlertKeyList().size();
				for (int j = 0; j < keyListSize; j++){
					AlertKey alertKey = (AlertKey)alertRuleDefinition.getAlertKeyList().get(j);
					if(alertKey.getFileId().equals("") || alertKey.getFileId().equals(null)){
						args.add("none");
					} else {
						args.add(alertKey.getFileId());
					}
				}
				
				if (alertRuleDefinition.getLHSColumnsList().size()>1){
					args.add("LTOTAL");
					keyListSize = keyListSize + 1;
				}
				
				if (alertRuleDefinition.getRHSColumnsList().size()>1){
					args.add("RTOTAL");
					keyListSize = keyListSize + 1;
				}
				
				for (int j = keyListSize+1; j <= 15; j++){
					args.add("");
				}
				success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().insertExtrctTblDef(connection,failures, args, alertRuleDefinition);
			}
		} else {
			List args = new ArrayList();

			args.add(Integer.toString(newPartiId));
			args.add(Integer.toString(alertKeyLevel));
			
			AlertKey alertKey = (AlertKey)alertRuleDefinition.getAlertKeyList().get(0);
			if (alertKeyLevel>=1){
				args.add(alertKey.getKey1());
			}else {
				args.add("");
			}
			if (alertKeyLevel>=2){
				args.add(alertKey.getKey2());
			}else {
				args.add("");
			}
			if (alertKeyLevel>=3){
				args.add(alertKey.getKey3());
			}else {
				args.add("");
			}
			if (alertKeyLevel>=4){
				args.add(alertKey.getKey4());
			}else {
				args.add("");
			}
			if (alertKeyLevel>=5){
				args.add(alertKey.getKey5());
			}else {
				args.add("");
			}
			
			args.add(Integer.toString(totalCount));
			
			for (int i = 0; i < alertItemListSize; i++){
				AlertItem alertItem = (AlertItem)alertItemList.get(i);
				int columnListSize = alertItem.getColumnList().size();
				Column column = (Column)alertItem.getColumnList().get(0);
				args.add(column.getColumnTBLDDLName());
			}
			
			for (int j = alertItemListSize+1; j <= 15; j++){
				args.add("");
			}
			success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().insertExtrctTblDef(connection,failures, args, alertRuleDefinition);
		}
		return success;
	}
	
	/**
	 * Delete from RABC_TRACK_FILE_DTL table for trending and tracking rule.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean deleteTrackFileDtl(Connection connection, List failures, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		List delTrackFileDtlArgs = new ArrayList();
		String alertRule = alertRuleDefinition.getAlertRule();
		delTrackFileDtlArgs.add(alertRule);
		success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().deleteTrackFileDtl(connection, failures, delTrackFileDtlArgs);
		return success;
	}
	
	/**
	 * Insert into RABC_TRACK_FILE_DTL table for trending and tracking rule.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean insertTrackFileDtl(Connection connection, List failures, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		
		String ruleName = alertRuleDefinition.getAlertRule();

		List leftColumnList = alertRuleDefinition.getLHSColumnsList();
		List rightColumnList = alertRuleDefinition.getRHSColumnsList();
		int leftColumnListSize = leftColumnList.size();
		int rightColumnListSize = rightColumnList.size();
		int alertKeyLevel = alertRuleDefinition.getAlertKeyLevel();
		List alertKeyList = alertRuleDefinition.getAlertKeyList();
		
		if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
			for (int i=0;i<leftColumnListSize;i++){
				List args = new ArrayList();
				
				Column column = (Column)leftColumnList.get(i);
				AlertKey alertKey = (AlertKey)alertKeyList.get(i);
				
				args.add(ruleName);
				if(alertKey.getFileId()!= null && !alertKey.getFileId().equals("")){
					args.add(alertKey.getFileId());
				} else {
					args.add("none");
				}
				args.add("L");
				args.add("Y");
				if (column.getColumnViewName()!=null){
					args.add(column.getColumnViewName());
				}else {
					args.add(column.getColumnAlertProcTBL());
				}
				args.add(Integer.toString(alertRuleDefinition.getAlertKeyLevel()));

				if (alertKey.getKey1()!=null && alertKeyLevel >= 1){
					args.add(alertKey.getKey1());
				}else {
					args.add("");
				}
				if (alertKey.getKey2()!=null && alertKeyLevel >= 2){
					args.add(alertKey.getKey2());
				}else {
					args.add("");
				}
				if (alertKey.getKey3()!=null && alertKeyLevel >= 3){
					args.add(alertKey.getKey3());
				}else {
					args.add("");
				}
				if (alertKey.getKey4()!=null && alertKeyLevel >= 4){
					args.add(alertKey.getKey4());
				}else {
					args.add("");
				}
				if (alertKey.getKey5()!=null && alertKeyLevel >= 5){
					args.add(alertKey.getKey5());
				}else {
					args.add("");
				}
				
				int alertItemDataCnt = alertRuleDefinition.getAlertItemList().size();
				args.add(Integer.toString(alertItemDataCnt));
				
				List alertItemList = alertRuleDefinition.getAlertItemList();
				int alertItemListSize = alertItemList.size();
				for (int j = 0; j < alertItemListSize; j++){
					AlertItem alertItem = (AlertItem)alertItemList.get(j);
					Column itemColumn = (Column) alertItem.getColumnList().get(i);
					args.add(itemColumn.getColumnTBLDDLName());
					args.add(Integer.toString(0));
					// Code added to cater for additional column in table namely ALERT_ITEM*_DDL_NAME_IND
					if ("CAL".equalsIgnoreCase(itemColumn.getColumnTBLDataType())){
						args.add("C");
					}else {
						args.add("");
					}
				}
				for (int j=alertItemListSize+1;j<=15;j++){
					args.add("");
					args.add("");
					// Code added to cater for additional column in table namely ALERT_ITEM*_DDL_NAME_IND
					args.add("");
				}
				
				if (column.getColumnViewName()!= null){
					args.add(column.getColumnViewName());
				}else {
					args.add("");
				}
				
				args.add(Integer.toString(i + 1));
				success =  AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().insertTrackFileDtl(connection, failures, args, alertRuleDefinition);
			}
			for (int i = 0; i < rightColumnListSize; i++){
				List args = new ArrayList();
				
				Column column = (Column)rightColumnList.get(i);
				AlertKey alertKey = (AlertKey)alertKeyList.get(leftColumnListSize+i);
				
				args.add(ruleName);
				if(alertKey.getFileId()!= null && !alertKey.getFileId().equals("")){
					args.add(alertKey.getFileId());
				} else {
					args.add("none");
				}
				args.add("R");
				args.add(""); 
				if (column.getColumnViewName()!=null){
					args.add(column.getColumnViewName());
				}else {
					args.add(column.getColumnAlertProcTBL());
				}
				
				args.add(Integer.toString(alertRuleDefinition.getAlertKeyLevel()));
				
				if (alertKey.getKey1()!=null && alertKeyLevel >= 1){
					args.add(alertKey.getKey1());
				}else {
					args.add("");
				}
				if (alertKey.getKey2()!=null && alertKeyLevel >= 2){
					args.add(alertKey.getKey2());
				}else {
					args.add("");
				}
				if (alertKey.getKey3()!=null && alertKeyLevel >= 3){
					args.add(alertKey.getKey3());
				}else {
					args.add("");
				}
				if (alertKey.getKey4()!=null && alertKeyLevel >= 4){
					args.add(alertKey.getKey4());
				}else {
					args.add("");
				}
				if (alertKey.getKey5()!=null && alertKeyLevel >= 5){
					args.add(alertKey.getKey5());
				}else {
					args.add("");
				}
				
				int alertItemDataCnt = alertRuleDefinition.getAlertItemList().size();
				args.add(Integer.toString(alertItemDataCnt));
				
				List alertItemList = alertRuleDefinition.getAlertItemList();
				int alertItemListSize = alertItemList.size();
				for (int j=0;j<alertItemListSize;j++){
					AlertItem alertItem = (AlertItem)alertItemList.get(j);
					Column itemColumn = (Column) alertItem.getColumnList().get(leftColumnListSize+i);
					args.add(itemColumn.getColumnTBLDDLName());
					args.add(Integer.toString(0));
					// Code added to cater for additional column in table namely ALERT_ITEM*_DDL_NAME_IND
					if ("CAL".equalsIgnoreCase(itemColumn.getColumnTBLDataType())){
						args.add("C");
					}else {
						args.add("");
					}
				}
				for (int j=alertItemListSize+1;j<=15;j++){
					args.add("");
					args.add("");
					// Code added to cater for additional column in table namely ALERT_ITEM*_DDL_NAME_IND
					args.add("");					
				}
				if (column.getColumnViewName()!=null){
					args.add(column.getColumnViewName());
				}else {
					args.add("");
				}
				
				args.add(Integer.toString(leftColumnListSize + i + 1));
				success =  AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().insertTrackFileDtl(connection, failures, args, alertRuleDefinition);
			}
		} else {
			//For Trend.
			List args = new ArrayList(); 
			Column column = (Column)leftColumnList.get(0);
			AlertKey alertKey = (AlertKey)alertKeyList.get(0);
			
			args.add(ruleName);
			if(alertKey.getFileId()!= null && !alertKey.getFileId().equals("")){
				args.add(alertKey.getFileId());
			} else {
				args.add("none");
			}
			if (column.getColumnViewName()!=null){
				args.add(column.getColumnViewName());
			}else {
				args.add(column.getColumnAlertProcTBL());
			}
			args.add(Integer.toString(alertRuleDefinition.getAlertKeyLevel()));

			if (alertKey.getKey1()!=null && alertKeyLevel >= 1){
				args.add(alertKey.getKey1());
			}else {
				args.add("");
			}
			if (alertKey.getKey2()!=null && alertKeyLevel >= 2){
				args.add(alertKey.getKey2());
			}else {
				args.add("");
			}
			if (alertKey.getKey3()!=null && alertKeyLevel >= 3){
				args.add(alertKey.getKey3());
			}else {
				args.add("");
			}
			if (alertKey.getKey4()!=null && alertKeyLevel >= 4){
				args.add(alertKey.getKey4());
			}else {
				args.add("");
			}
			if (alertKey.getKey5()!=null && alertKeyLevel >= 5){
				args.add(alertKey.getKey5());
			}else {
				args.add("");
			}
			
			int alertItemDataCnt = alertRuleDefinition.getAlertItemList().size();
			args.add(Integer.toString(alertItemDataCnt));
			
			List alertItemList = alertRuleDefinition.getAlertItemList();
			int alertItemListSize = alertItemList.size();
			for (int j=0;j<alertItemListSize;j++){
				AlertItem alertItem = (AlertItem)alertItemList.get(j);
				Column itemColumn = (Column) alertItem.getColumnList().get(0);
				args.add(itemColumn.getColumnTBLDDLName());
				args.add(Integer.toString(0));
				// Code added to cater for additional column in table namely ALERT_ITEM*_DDL_NAME_IND
				if ("CAL".equalsIgnoreCase(itemColumn.getColumnTBLDataType())){
					args.add("C");
				}else {
					args.add("");
				}
			}
			for (int j=alertItemListSize+1;j<=15;j++){
				args.add("");
				args.add("");
				// Code added to cater for additional column in table namely ALERT_ITEM*_DDL_NAME_IND
				args.add("");
			}						
			if (column.getColumnViewName()!=null){
				args.add(column.getColumnViewName());
			}else {
				args.add("");
			}
			args.add(Integer.toString(0));
			success =  AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().insertTrackFileDtl(connection, failures, args, alertRuleDefinition);
		}
		return success;
	}
	
	/**
	 * Delete from RABC_EXTRCT_BUILD_RULE table for tracking rule.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean deleteExtrctBuildRuleTrack(Connection connection, List failures, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		List delExtrctBuildRuleArgs = new ArrayList();
		AlertRule alertRule = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().getAlertRule(connection, failures, alertRuleDefinition);
		int newPartiRefId = alertRule.getPartiRefId();
		delExtrctBuildRuleArgs.add(Integer.toString(newPartiRefId));
		success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().deleteExtrctBuildRuleForTrack(connection, failures, delExtrctBuildRuleArgs);
		return success;
	}
	
	/**
	 * Insert into RABC_EXTRCT_BUILD_RULE table for tracking rule.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean insertExtrctBuildRuleTrack(Connection connection, List failures, AlertRuleDefinition alertRuleDefinition){
		String extrctType;
		boolean success = true;
		
		String seltiming = alertRuleDefinition.getAlertRuleTiming();

		if ("S".equals(seltiming)){
			extrctType = "S";
		}else if ("B".equals(seltiming)){
			extrctType = "B";
		}else if ("D".equals(seltiming)) {
			extrctType = "D";
		}else if ("M".equals(seltiming)) {
			extrctType = "M";
		}else {
			extrctType = "S";
		}
		
		AlertRule alertRule = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().getAlertRule(connection, failures, alertRuleDefinition);
		int newPartiRefId = alertRule.getPartiRefId();
		
		List alertItemList = alertRuleDefinition.getAlertItemList();
		List alertKeyList = alertRuleDefinition.getAlertKeyList();
		int alertItemListSize = alertItemList.size();
		
		for (int i = 0; i < alertItemListSize; i++){				
			List args = new ArrayList();
			AlertItem alertItem = (AlertItem)alertItemList.get(i);
			
			args.add(Integer.toString(newPartiRefId));
			args.add(extrctType);
			args.add(alertItem.getItemName());
			
			List columnList = alertItem.getColumnList();
			int columnListSize = columnList.size();
			for (int j = 0; j < columnListSize; j++){
				Column column = (Column)columnList.get(j);
				AlertKey alertKey = (AlertKey) alertKeyList.get(j);
				
				args.add("ALERT_ITEM" + (i+1) + "_DDL_NAME");
					
				AlertItem alertItemForNegInd = (AlertItem)alertItemList.get(0);
				List columnListForNegInd = alertItemForNegInd.getColumnList();
				Column columnForNegInd = (Column)columnListForNegInd.get(j);
				if ("Y".equals(columnForNegInd.getNegIndicator())){
					args.add("Y");
				}else {
					args.add("N");
				}
				
				if (column.getColumnViewName() != null) {
					args.add(column.getColumnViewName());
				}else {
					args.add(column.getColumnAlertProcTBL());
				}
			}
			
			/*
			 * Addition of clause for adding total columns for tracking items 
			 */
			if (alertRuleDefinition.getLHSColumnsList().size()>1){
				args.add("");
				args.add("N");
				args.add("LTOTAL");
				columnListSize = columnListSize + 1;
			}
			
			if (alertRuleDefinition.getRHSColumnsList().size()>1){
				args.add("");
				args.add("N");
				args.add("RTOTAL");
				columnListSize = columnListSize + 1;
			}
			
			for (int j = columnListSize+1; j <= 9; j++){
				args.add("");
				args.add("");
				args.add("");
			}
			success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().insertExtrctBuildRuleForTrack(connection, failures, args);
		}
		return success;
	}
	
	/**
	 * Delete from RABC_AVG_TBL_DEF table for tracking rule.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean deleteAvgTblDefTrack(Connection connection, List failures, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		List delAvgTblDefArgs = new ArrayList();
		AlertRule alertRule = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().getAlertRule(connection, failures, alertRuleDefinition);
		int newPartiRefId = alertRule.getPartiRefId();
		delAvgTblDefArgs.add(Integer.toString(newPartiRefId));
		success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().deleteAvgTblDefForTrack(connection, failures, delAvgTblDefArgs);
		return success;
	}
	
	/**
	 * Insert into RABC_AVG_TBL_DEF table for tracking rule.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean insertAvgTblDefTrack(Connection connection, List failures, AlertRuleDefinition alertRuleDefinition){
		List alertItemList = alertRuleDefinition.getAlertItemList();
		List alertKeyList = alertRuleDefinition.getAlertKeyList();
		int alertItemListSize = alertItemList.size();
		boolean success= true;
		
		int alertKeyLevel = alertRuleDefinition.getAlertKeyLevel();
		
		AlertRule alertRule = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().getAlertRule(connection, failures, alertRuleDefinition);
		int newPartiRefId = alertRule.getPartiRefId();
		
		for (int i = 0; i < alertItemListSize; i++){
			List args = new ArrayList();
			AlertItem alertItem = (AlertItem)alertItemList.get(i);
			
			args.add(Integer.toString(newPartiRefId));
			args.add(Integer.toString(alertRuleDefinition.getAlertKeyLevel()));
			
			if (alertKeyLevel>=1){
				args.add("ALERT_KEY1");
			}else {
				args.add("");
			}
			if (alertKeyLevel>=2){
				args.add("ALERT_KEY2");
			}else {
				args.add("");
			}
			if (alertKeyLevel>=3){
				args.add("ALERT_KEY3");
			}else {
				args.add("");
			}
			if (alertKeyLevel>=4){
				args.add("ALERT_KEY4");
			}else {
				args.add("");
			}
			if (alertKeyLevel>=5){
				args.add("ALERT_KEY5");
			}else {
				args.add("");
			}
		
			args.add(alertItem.getItemName());
			
			List columnList = alertItem.getColumnList();
			int columnListSize = columnList.size();
			
			args.add(Integer.toString(columnListSize));
			
			for (int j = 0; j < columnListSize; j++){
				Column column = (Column)columnList.get(j);
				AlertKey alertKey = (AlertKey) alertKeyList.get(j);
				args.add(alertKey.getFileId());
			}
			
			if (alertRuleDefinition.getLHSColumnsList().size()>1){
				args.add("LTOTAL");
				columnListSize = columnListSize + 1;
			}
			
			if (alertRuleDefinition.getRHSColumnsList().size()>1){
				args.add("RTOTAL");
				columnListSize = columnListSize + 1;
			}
			
			for (int j = columnListSize+1; j <= 15; j++){
				args.add("");
			}
			success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().insertAvgTblDefForTrack(connection, failures, args);
		}
		return success;
	}
	
	/**
	 * Delete from RABC_MOUSE_OVER_LINK table for tracking and trending rules.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean deleteMouseOverLink(Connection connection, List failures, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		List delMouseOverLinkArgs = new ArrayList();
		AlertRule alertRule = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().getAlertRule(connection, failures, alertRuleDefinition);
		int newPresnId = alertRule.getPresnId();
		delMouseOverLinkArgs.add(Integer.toString(newPresnId));
		success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().deleteMouseOverLink(connection, failures, delMouseOverLinkArgs);		
		return success;
	}
	
	/**
	 * Insert into RABC_MOUSE_OVER_LINK table for tracking and trending rules.
	 * 
	 * @param connection
	 * @param failureList
	 * @param alertRuleDefinition
	 * @param mouseOverNumArray
	 * @return boolean
	 */
	private boolean insertMouseOverLink(Connection connection, List failureList, AlertRuleDefinition alertRuleDefinition, int[] mouseOverNumArray){
		List pageList = new ArrayList();
		boolean success = true;
		AlertRule alertRule = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().getAlertRule(connection, failureList, alertRuleDefinition);
		int newPresnId = alertRule.getPresnId();
		int alertKeyLevel = alertRule.getAlertKeyLvl();
		
		if("Track".equals(alertRuleDefinition.getAlertRuleType())){
			pageList.add("RABCPSF00011");
			pageList.add("RABCPSF00012");
			pageList.add("RABCPSF00013");
		}
		
		if ("on".equals(alertRuleDefinition.getFileSequenceIndicator()) && "Track".equals(alertRuleDefinition.getAlertRuleType())){
			pageList.add("RABCPSF00014");
		}
		
		if("Trend".equals(alertRuleDefinition.getAlertRuleType())){
			pageList = new ArrayList();
			pageList.add("RABCPSF00011");
			pageList.add("RABCPSF00013");
		}
		
		int pageListSize = pageList.size();
		int mouseOverNum = 0;
		String mouseOverTableKey = null;
		
		for (int i = 0; i < pageListSize; i++){
			mouseOverNum = 0;
			for (int j = 1; j <= alertKeyLevel; j++){
				switch(j) {
				case 1: mouseOverTableKey = alertRuleDefinition.getMouseOverTableKey1();
						break;
				case 2: mouseOverTableKey = alertRuleDefinition.getMouseOverTableKey2();
						break;
				case 3: mouseOverTableKey = alertRuleDefinition.getMouseOverTableKey3();
						break;
				case 4: mouseOverTableKey = alertRuleDefinition.getMouseOverTableKey4();
						break;
				case 5: mouseOverTableKey = alertRuleDefinition.getMouseOverTableKey5();
						break;
				default: mouseOverTableKey = "";
						break;
				}
				if (!"".equals(mouseOverTableKey) && !"---Select---".equals(mouseOverTableKey)) {
					mouseOverNum++;
					String pgl = (String) pageList.get(i);
					List args = new ArrayList();
					args.add(Integer.toString(newPresnId));
					args.add(pgl);
					args.add(Integer.toString(mouseOverNum));
					StringTokenizer st = new StringTokenizer(mouseOverTableKey,"~");
					while (st.hasMoreTokens()){
						args.add(st.nextToken());
					}
					mouseOverNumArray[j-1] = mouseOverNum;
					success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().insertMouseOverLink(connection,failureList,args);
				} else {
					mouseOverNumArray[j-1] = 0;
				}			
			}
		}
		return success; 
	}
	
	/**
	 * Update the values of RABC_ALERT_RULE_PRESN_RULE 
	 * table for RABC_MOUSE_OVER_LINK modifications done in the above method.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertRuleDefinition
	 * @param mouseOverNumArray
	 * @return boolean
	 */
	private boolean updateAlertRulePresnRule(Connection connection, List failures, AlertRuleDefinition alertRuleDefinition, int[] mouseOverNumArray){
		boolean success = true;
		List args = new ArrayList();
		AlertRule alertRule = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().getAlertRule(connection, failures, alertRuleDefinition);
		int newPresnId = alertRule.getPresnId();
		int alertKeyLevel = alertRule.getAlertKeyLvl();
		for (int j = 0; j < alertKeyLevel; j++){
			args.add(Integer.toString(mouseOverNumArray[j]));
			if (mouseOverNumArray[j]>0){
				args.add("Y");
			}else {
				args.add("");
			}
		}
		for(int k = alertKeyLevel; k < 5; k++){
			args.add("");
			args.add("");
		}
		args.add(Integer.toString(newPresnId));
		success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().updateAlertRulePresnRule(connection,failures,args);
		return success;
	}
	
	/**
	 * Update values of RABC_ALERT_RULE_PRESN_RULE table for Report Link to keys.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean updateAlertRulePresnRuleForReportLink(Connection connection, List failures, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		List args = new ArrayList();
		int counter = 1;
		AlertRule alertRule = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().getAlertRule(connection, failures, alertRuleDefinition);
		int newPresnId = alertRule.getPresnId();
		int alertKeyLevel = alertRule.getAlertKeyLvl();
		String reportLinkKey = null;
		for (int i = 1; i <= alertKeyLevel; i++){
			switch(i) {
				case 1: reportLinkKey = alertRuleDefinition.getReportLinkKey1();
						break;
				case 2: reportLinkKey = alertRuleDefinition.getReportLinkKey2();
						break;
				case 3: reportLinkKey = alertRuleDefinition.getReportLinkKey3();
						break;
				case 4: reportLinkKey = alertRuleDefinition.getReportLinkKey4();
						break;
				case 5: reportLinkKey = alertRuleDefinition.getReportLinkKey5();
						break;
				default: reportLinkKey = "";
						break;
			}
			if (!"".equals(reportLinkKey) && !"---Select---".equals(reportLinkKey)) {
				args.add("Y");
				args.add(Integer.toString(counter));
				counter++;
			} else {
				args.add("");
				args.add("");
			}
		}
		for (int i = alertKeyLevel+1; i <= 5; i++){
			args.add("");
			args.add("");
		}
		args.add(Integer.toString(newPresnId));
		success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().updateAlertRulePresnRuleForReportLink(connection,failures,args);
		return success;
	}
	
	/**
	 * Delete from RABC_WEB_DATA_LINK table for tracking and trending rule.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean deleteWebDataLink(Connection connection, List failures, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		List delWebDataLinkArgs = new ArrayList();
		AlertRule alertRule = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().getAlertRule(connection, failures, alertRuleDefinition);
		int newPresnId = alertRule.getPresnId();
		delWebDataLinkArgs.add(Integer.toString(newPresnId));
		success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().deleteWebDataLink(connection, failures, delWebDataLinkArgs);
		return success;
	}
	
	/**
	 * Inserts Data into RABC_WEB_DATA_LINK table for tracking and trending rule.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean insertWebDataLink(Connection connection, List failures, AlertRuleDefinition alertRuleDefinition){
		boolean success =true;
		int counter = 1;
		
		AlertRule alertRule = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().getAlertRule(connection, failures, alertRuleDefinition);
		int newPresnId = alertRule.getPresnId();
		
		int alertKeyLevel = alertRuleDefinition.getAlertKeyLevel();
		List args3 = null;
		String reportLinkKey = null;
		String[] presnIdAlertRule = null;
		for (int i=1; i<=alertKeyLevel; i++) {
			switch(i) {
				case 1: reportLinkKey = alertRuleDefinition.getReportLinkKey1();
						break;
				case 2: reportLinkKey = alertRuleDefinition.getReportLinkKey2();
						break;
				case 3: reportLinkKey = alertRuleDefinition.getReportLinkKey3();
						break;
				case 4: reportLinkKey = alertRuleDefinition.getReportLinkKey4();
						break;
				case 5: reportLinkKey = alertRuleDefinition.getReportLinkKey5();
						break;
				default: reportLinkKey = "";
						break;
			}
			if (!"".equals(reportLinkKey) && !"---Select---".equals(reportLinkKey)) {
				presnIdAlertRule = reportLinkKey.split("~");
				args3 = new ArrayList();
				args3.add(Integer.toString(newPresnId));
				args3.add(Integer.toString(counter));
				counter++;
				args3.add(presnIdAlertRule[1]);
				args3.add(presnIdAlertRule[0]);
				success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().insertWebDataLink(connection, failures, args3, alertRuleDefinition);
			}
		}
		
		/*
		 * Insert report link values for columns
		 */
		int columnCounter = counter;
		List alertItemList = alertRuleDefinition.getAlertItemList();
		if (!alertItemList.isEmpty()){
			int alertItemListSize = alertItemList.size();
			for (int i=0; i<alertItemListSize; i++) {
				AlertItem alertItem = (AlertItem)alertItemList.get(i);
				if (alertItem.getReportLinkData()!=null && !"---Select---".equals(alertItem.getReportLinkData())){
					presnIdAlertRule = alertItem.getReportLinkData().split("~");
					args3 = new ArrayList();
					args3.add(Integer.toString(newPresnId));
					args3.add(Integer.toString(columnCounter));
					columnCounter++;
					args3.add(presnIdAlertRule[1]);
					args3.add(presnIdAlertRule[0]);
					success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().insertWebDataLink(connection, failures, args3, alertRuleDefinition);
				}
			}
		}
		
		return success;
	}
	
	/**
	 * Method will delete existing entries from RABC_TRIG_CONVERT for 
	 * @param connection
	 * @param failureList
	 * @param alertRuleDefinition
	 * @return
	 */
	private boolean deleteTrigConvert(Connection connection, List failureList, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		List args = new ArrayList();
		args.add(alertRuleDefinition.getAlertRule());
		success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().deleteTrigConvert(connection, failureList, args);
		return success;
	}
	
	/**
	 * Inserts Data into RABC_TRIG_CONVERT table for trend and track rules only for monthly timing
	 * 
	 * PMT 284847: Modification so as to ensure FILE_ID for an alert rule is unique 
	 * 
	 * @param connection
	 * @param failureList
	 * @param alertRuleDefinition
	 * @param tempTiming
	 * @return boolean
	 */
	private boolean insertTrigConvert(Connection connection, List failureList, AlertRuleDefinition alertRuleDefinition){
		String runFreqInd = "M";
		boolean success = true;
		
		List leftColumnList = alertRuleDefinition.getLHSColumnsList();
		List rightColumnList = alertRuleDefinition.getRHSColumnsList();
		int leftColumnListSize = leftColumnList.size();
		int rightColumnListSize = rightColumnList.size();
		
		List alertKeyList = alertRuleDefinition.getAlertKeyList();
		
		if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
			List fileIdList = new ArrayList();
			
			for (int i = 0; i < leftColumnListSize; i++){
				List args = new ArrayList();
				String fileId = "none";
				Column column = (Column)leftColumnList.get(i);
				AlertKey alertKey = (AlertKey)alertKeyList.get(i);
				
				if(alertKey.getFileId()!= null && !alertKey.getFileId().equals("")){
					fileId = alertKey.getFileId();
				} 
				
				/*
				 * Add the entry to the table only if the FILE_ID has not been inserted already for this Alert Rule
				 */
				if (fileIdList.isEmpty() || !fileIdList.contains(fileId)){
					fileIdList.add(fileId);
					args.add(fileId);
					args.add(alertRuleDefinition.getAlertRule());
					args.add(runFreqInd);
					if ("B".equals(alertRuleDefinition.getAlertRuleMonthlyTimingType())){
						args.add(alertRuleDefinition.getMnthExecBillRnd());
					}else {
						args.add(alertRuleDefinition.getMnthExecDt());
					}
					success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().insertTrigConvert(connection,failureList,args,alertRuleDefinition);
				}
			}			
			for (int i = 0; i < rightColumnListSize; i++){
				List args = new ArrayList();
				String fileId = "none";
				Column column = (Column)rightColumnList.get(i);
				AlertKey alertKey = (AlertKey)alertKeyList.get(leftColumnListSize+i);

				if(!alertKey.getFileId().equals(null) && !alertKey.getFileId().equals("")){
					fileId = alertKey.getFileId();
				} 
				
				/*
				 * Add the entry to the table only if the FILE_ID has not been inserted already for this Alert Rule
				 */
				if (fileIdList.isEmpty() || !fileIdList.contains(fileId)){
					fileIdList.add(fileId);
					args.add(fileId);
					args.add(alertRuleDefinition.getAlertRule());
					args.add(runFreqInd);
					if ("B".equals(alertRuleDefinition.getAlertRuleMonthlyTimingType())){
						args.add(alertRuleDefinition.getMnthExecBillRnd());
					}else {
						args.add(alertRuleDefinition.getMnthExecDt());
					}
					success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().insertTrigConvert(connection,failureList,args,alertRuleDefinition);
				}
			}
		} else {
			List args = new ArrayList();
			
			Column column = (Column)leftColumnList.get(0);
			AlertKey alertKey = (AlertKey)alertKeyList.get(0);

			if(!alertKey.getFileId().equals(null) && !alertKey.getFileId().equals("")){
				args.add(alertKey.getFileId());
			} else {
				args.add("none");
			}
			args.add(alertRuleDefinition.getAlertRule());
			args.add(runFreqInd);
			if ("B".equals(alertRuleDefinition.getAlertRuleMonthlyTimingType())){
				args.add(alertRuleDefinition.getMnthExecBillRnd());
			}else {
				args.add(alertRuleDefinition.getMnthExecDt());
			}
			success = AlertRuleDefinitionUpdateSQLService.getAlertRuleDefinitionUpdateSQLService().insertTrigConvert(connection,failureList,args,alertRuleDefinition);
		}
		return success;
	}
}
