/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc;

/**
 * This is a super class for all forms which have paging and sorting functionality.
 * It is itself is the sub class of PagedForm.
 * 
 * @author Vijay Dubey - VD3159
 */
public class SortedForm extends PagedForm {
    private String sortItem = null;
    private String previousSortItem = null;
    private String sortOrder = null;
	
    /**
	 * @return Returns the previousSortItem.
	 */
	public String getPreviousSortItem() {
		return previousSortItem;
	}
	/**
	 * @param previousSortItem The previousSortItem to set.
	 */
	public void setPreviousSortItem(String previousSortItem) {
		this.previousSortItem = previousSortItem;
	}
	/**
	 * @return Returns the sortItem.
	 */
	public String getSortItem() {
		return sortItem;
	}
	/**
	 * @param sortItem The sortItem to set.
	 */
	public void setSortItem(String sortItem) {
		this.sortItem = sortItem;
	}
	/**
	 * @return Returns the sortOrder.
	 */
	public String getSortOrder() {
		return sortOrder;
	}
	/**
	 * @param sortOrder The sortOrder to set.
	 */
	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}
}
