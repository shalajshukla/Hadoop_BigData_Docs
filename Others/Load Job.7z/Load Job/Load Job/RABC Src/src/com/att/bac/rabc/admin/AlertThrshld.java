/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.admin;
import java.util.Date;

/**
 * This is a Data Object to represent RABC_ALERT_THRSHLD table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class AlertThrshld {
	private String alertRule;
	private String alertType;
	private String alertKey1Data;
	private String alertKey2Data;
	private String alertKey3Data;
	private String alertKey4Data;
	private String alertKey5Data;
	private String alertItemName;
	private String alertItemDdlData;
	private int alertThrshldLvl;
	private int alertThrshld;
	private int alertHigh;
	private int alertLow;
	private int minAlertVal;
	private String dfltInd;
	private Date timeStamp;

	/**
	 * @return Returns the AlertRule.
	 */
	public String getAlertRule() {
		return alertRule;
	}
	/**
	 * @return Returns the AlertType.
	 */
	public String getAlertType() {
		return alertType;
	}
	/**
	 * @return Returns the AlertKey1Data.
	 */
	public String getAlertKey1Data() {
		return alertKey1Data;
	}
	/**
	 * @return Returns the AlertKey2Data.
	 */
	public String getAlertKey2Data() {
		return alertKey2Data;
	}
	/**
	 * @return Returns the AlertKey3Data.
	 */
	public String getAlertKey3Data() {
		return alertKey3Data;
	}
	/**
	 * @return Returns the AlertKey4Data.
	 */
	public String getAlertKey4Data() {
		return alertKey4Data;
	}
	/**
	 * @return Returns the AlertKey5Data.
	 */
	public String getAlertKey5Data() {
		return alertKey5Data;
	}
	/**
	 * @return Returns the AlertItemName.
	 */
	public String getAlertItemName() {
		return alertItemName;
	}
	/**
	 * @return Returns the AlertItemDdlData.
	 */
	public String getAlertItemDdlData() {
		return alertItemDdlData;
	}
	/**
	 * @return Returns the AlertThrshldLvl.
	 */
	public int getAlertThrshldLvl() {
		return alertThrshldLvl;
	}
	/**
	 * @return Returns the AlertThrshld.
	 */
	public int getAlertThrshld() {
		return alertThrshld;
	}
	/**
	 * @return Returns the AlertHigh.
	 */
	public int getAlertHigh() {
		return alertHigh;
	}
	/**
	 * @return Returns the AlertLow.
	 */
	public int getAlertLow() {
		return alertLow;
	}
	/**
	 * @return Returns the MinAlertVal.
	 */
	public int getMinAlertVal() {
		return minAlertVal;
	}
	/**
	 * @return Returns the DfltInd.
	 */
	public String getDfltInd() {
		return dfltInd;
	}
	/**
	 * @return Returns the TimeStamp.
	 */
	public Date getTimeStamp() {
		return timeStamp;
	}

	/**
	 * @param AlertRule The alertRule to set.
	 */
	public void setAlertRule(String alertRule) {
		this.alertRule = alertRule;
	}
	/**
	 * @param AlertType The alertType to set.
	 */
	public void setAlertType(String alertType) {
		this.alertType = alertType;
	}
	/**
	 * @param AlertKey1Data The alertKey1Data to set.
	 */
	public void setAlertKey1Data(String alertKey1Data) {
		this.alertKey1Data = alertKey1Data;
	}
	/**
	 * @param AlertKey2Data The alertKey2Data to set.
	 */
	public void setAlertKey2Data(String alertKey2Data) {
		this.alertKey2Data = alertKey2Data;
	}
	/**
	 * @param AlertKey3Data The alertKey3Data to set.
	 */
	public void setAlertKey3Data(String alertKey3Data) {
		this.alertKey3Data = alertKey3Data;
	}
	/**
	 * @param AlertKey4Data The alertKey4Data to set.
	 */
	public void setAlertKey4Data(String alertKey4Data) {
		this.alertKey4Data = alertKey4Data;
	}
	/**
	 * @param AlertKey5Data The alertKey5Data to set.
	 */
	public void setAlertKey5Data(String alertKey5Data) {
		this.alertKey5Data = alertKey5Data;
	}
	/**
	 * @param AlertItemName The alertItemName to set.
	 */
	public void setAlertItemName(String alertItemName) {
		this.alertItemName = alertItemName;
	}
	/**
	 * @param AlertItemDdlData The alertItemDdlData to set.
	 */
	public void setAlertItemDdlData(String alertItemDdlData) {
		this.alertItemDdlData = alertItemDdlData;
	}
	/**
	 * @param AlertThrshldLvl The alertThrshldLvl to set.
	 */
	public void setAlertThrshldLvl(int alertThrshldLvl) {
		this.alertThrshldLvl = alertThrshldLvl;
	}
	/**
	 * @param AlertThrshld The alertThrshld to set.
	 */
	public void setAlertThrshld(int alertThrshld) {
		this.alertThrshld = alertThrshld;
	}
	/**
	 * @param AlertHigh The alertHigh to set.
	 */
	public void setAlertHigh(int alertHigh) {
		this.alertHigh = alertHigh;
	}
	/**
	 * @param AlertLow The alertLow to set.
	 */
	public void setAlertLow(int alertLow) {
		this.alertLow = alertLow;
	}
	/**
	 * @param MinAlertVal The minAlertVal to set.
	 */
	public void setMinAlertVal(int minAlertVal) {
		this.minAlertVal = minAlertVal;
	}
	/**
	 * @param DfltInd The dfltInd to set.
	 */
	public void setDfltInd(String dfltInd) {
		this.dfltInd = dfltInd;
	}
	/**
	 * @param TimeStamp The timeStamp to set.
	 */
	public void setTimeStamp(Date timeStamp) {
		this.timeStamp = timeStamp;
	}
}
