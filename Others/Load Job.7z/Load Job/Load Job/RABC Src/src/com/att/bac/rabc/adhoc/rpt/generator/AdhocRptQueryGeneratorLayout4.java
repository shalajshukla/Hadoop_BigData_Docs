/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.adhoc.rpt.generator;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;

import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.adhoc.aria.ARIAReportRABC;
import com.att.bac.rabc.adhoc.aria.ARIASimpleColumnRABC;
import com.att.bac.rabc.adhoc.rpt.AdhocRptDAO;
import com.att.bac.rabc.adhoc.rpt.AdhocRptDataTO;
import com.sbc.bac.aria.ARIADataPoint;
import com.sbc.bac.aria.ARIAFunction;
import com.sbc.bac.aria.ARIASort;
import com.sbc.bac.aria.ARIASource;


/**
 * Generate an ARIA Report. This is specific to layout 4
 * 
 * <p>
 * <hr>
 * <h3>Release History</h3>
 * <p>
 * <ul>
 * 
 * <li>jb6494 Sep 07, 2006 Created class.
 * <li>jb6494 Oct 16, 2006 Added sorting to outer query.
 * 
 * </ul>
 * <p>
 * 
 */
public class AdhocRptQueryGeneratorLayout4 extends AbstractAdhocGenerator {
    static final Logger logger = Logger.getLogger(AdhocRptQueryGeneratorLayout4.class);


    /**
     * Create the query for the report
     * 
     * @param dto
     * @param sectionIndex
     * @return
     * @throws RABCException
     */
    public ARIAReportRABC generateQuery(AdhocRptDataTO dto, int sectionIndex) throws RABCException {
        getLegacy().setViewNameUniqList(dto);
        getLegacy().setColumnsTabAsOracle(dto);

        // Create the aria report. false because we aren't teradata
        report = new ARIAReportRABC();

        int size = getLegacy().viewNameUniqList.size();
        for (int i = 0; i < size; i++) {
            getLegacy().initSqlArrays();
            getLegacy().getTblFromView(dto, i);
            getLegacy().setVariables(dto);
            if (isNotNullEQ(dto.getPresnTrendTime(), BILL_ROUND)) {
                getLegacy().initBillRound1(dto);
            } else if (isNotNullEQ(dto.getNoProcDate(), NO)) {
                getLegacy().initNotBillRound(dto);
            } else if (isNotNullEQ(dto.getNoProcDate(), YES)) {
                getLegacy().initBillRound2(dto);
            }
            getLegacy().initKeyColumns(dto, sectionIndex);
            getLegacy().updateSelectArray1(dto, i);
            getLegacy().updateModArrays1(i);
            getLegacy().updateModArrays2(dto, sectionIndex, i);
            getLegacy().updateSelectArray2(dto, sectionIndex, i);
            getLegacy().updateSelectArray3(i);
            getLegacy().updateWhereArray(dto, sectionIndex, i);

            buildAriaSource(dto);

        }

        getLegacy().updateMainSelectClause(dto, sectionIndex);
        if (size > 1) {
            getLegacy().updateOtherConditions(dto);
        }
        getLegacy().updateOrderByClause(dto, size);

        addARIAColumns(dto, sectionIndex);
        addARIAOrderBy(dto, sectionIndex);
        addJoins(report, getKeyCount(dto));

        debugARIAReport();

        return report;
    }


    /**
     * @param dto
     * @param loopCount
     */
    protected void addARIAOrderBy(AdhocRptDataTO dto, int loopCount) {
        List orderBy = reorderSort(dto, getLegacy().orderByClauseList);
        report.addSort(getDP(dto, 0, "PROC_DATE"), ARIASort.ASC);
        for (int i = 0; i < orderBy.size(); i++) {
            String element = (String) orderBy.get(i);

            ARIASort sort = ARIASort.ASC;

            int space = element.indexOf(' ');
            if (space != -1) {
                element = element.substring(0, space);
                sort = ARIASort.DESC;
            }

            ARIADataPoint dp = getDP(dto, i, element);
            if (dp != null) {
                dp.getSource().addSort(dp, sort);
                report.addSort(dp, sort);
            }

        }
    }


    /**
     * @param original
     * @return
     */
    protected List reorderSort(AdhocRptDataTO dto, List original) {
        List result = new ArrayList();

        if (dto.getPresnTrendTime().equals("B")) {
            int billRoundKey = getBillRoundKeyIndex(original);
            Object billRound = null;
            if (billRoundKey > 0) {
                billRound = original.get(billRoundKey);
                original.remove(billRoundKey);
            }

            if (billRound != null) {
                result.add(billRound);
            }
        }

        Iterator i = original.iterator();
        Object date = i.next();
        while (i.hasNext()) {
            String k = (String) i.next();
            if (k.matches(".*\\.K.*")) {
                result.add(k);
            }
        }
        result.add(date);

        i = original.iterator();
        while (i.hasNext()) {
            String k = (String) i.next();
            if (!result.contains(k)) {
                result.add(k);
            }
        }

        return result;
    }


    /**
     * @param list
     * @return
     */
    protected int getBillRoundKeyIndex(List list) {
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).toString().matches(".*K.BILL_RND")) {
                return i;
            }
        }
        return -1;
    }


    /**
     * @param dto
     * @param loopCount
     * @throws RABCException
     */
    protected void addARIAColumns(AdhocRptDataTO dto, int loopCount) throws RABCException {
        report.addColumn(new ARIASimpleColumnRABC(getDP(dto, 0, "PROC_DATE"), "File Date", null, "MM/dd/yyyy", -2));

        if (dto.getFileSeqNumInd().equalsIgnoreCase(YES)) {
            report.addColumn(new ARIASimpleColumnRABC(getDP(dto, 0, "file_seq_num"), "Sequence Number", null, -1));
        }
        for (int i = 0; i < dto.getColumnsAsOracleList().size(); i++) {
            String element = (String) dto.getColumnsAsOracleList().get(i);
            element = element.trim();
            //if (!dto.getPresnSuppressIndList().get(i).toString().equalsIgnoreCase(YES)) {
                String outputPattern = null;
                if (dto.getPresnFormatList().get(i).toString().equalsIgnoreCase("D")) {
                    outputPattern = "MM/DD/YYYY";
                }
                
                ARIADataPoint dp = null;
                if (!dto.getPresnCalcNumList().get(i).toString().equals(EMPTY_STRING)) {
                    int calcNum = Integer.parseInt(dto.getPresnCalcNumList().get(i).toString());
                    Calculation calc = new AdhocRptDAO().getCalcElem(dto, calcNum, loopCount);
                    element = calc.getPresnCalcName();
                } 

                dp = getDP(dto, i, element);
                report.addColumn(new ARIASimpleColumnRABC(dp, getColumnHeader(dto, i), null, outputPattern, i));
            //}
        }
    }


    /**
     * @param dto
     * @param index
     */
    protected void buildAriaSource(AdhocRptDataTO dto) {
        ARIASource source = createAriaSource(dto);

        for (int i = 0; i < getLegacy().selectClauseList.size(); i++) {
            String element = (String) getLegacy().selectClauseList.get(i);
            int lastSpace = element.lastIndexOf(' ');
           
            String givenName = null;
            if (lastSpace!=-1 && element.substring(lastSpace, element.length()).indexOf("CALC")!=-1) {
                givenName = element.substring(0,lastSpace).trim();
                int lastTilda = element.lastIndexOf('~');
                String calcFormula = element.substring(lastTilda + 1, element.length());
//              M148 : Calculation Fix: If calculation Formula contains / then put avg else put sum
                if(calcFormula.indexOf('/') != -1){
                	element = "*AVG " + calcFormula + " ";
                }else{
                	element = "*SUM " + calcFormula + " ";
                }
                lastSpace = element.lastIndexOf(' ');
            } else {
            	givenName = dot(getLegacy().viewTbl, element.substring(lastSpace + 1));
            }
            element = element.substring(0, lastSpace).trim();
            
            // if there is an embedded function it needs to be deciphered.
            // AVG MAX MIN COUNT SUM are translated to ARIAFunctions
            // trunc to_char ?
            ARIAFunction function = null;
            if (element.startsWith("*")) {
                if (element.toUpperCase().startsWith("*SUM")) {
                    element = element.substring(5);
                    function = ARIAFunction.inlinePlus(ARIAFunction.SUM);
                }
                if (element.toUpperCase().startsWith("*AVG")) {
                    element = element.substring(5);
                    function = ARIAFunction.inlinePlus(ARIAFunction.AVG);
                }
            }

            ARIADataPoint dp = source.createData(element, function);

            addDataPointReference(givenName, dp);
        }
    }
}
