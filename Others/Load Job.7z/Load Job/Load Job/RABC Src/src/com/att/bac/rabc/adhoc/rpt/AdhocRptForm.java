/*
 * � 2002-2007 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.adhoc.rpt;

import java.util.ArrayList;
import java.util.Calendar;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import com.att.bac.rabc.SortedForm;
import com.att.bac.rabc.StaticDataLoader;


/**
 * This is the Action Form for Adhoc reports.
 * 
 * <p>
 * <hr>
 * <h3>Release History</h3>
 * <p>
 * <ul>
 * 
 * <li>PD2951 20051216 Initial version for EAP 556010
 * <li>PD2951 20060424 Changes for report scheduler
 * <li>PD2951 20060427 Basic paging logic (temporary fix)
 * <li>JB6494 Feb 09, 2007 Changed to sorted form, promoted sorted selections to DTO
 * <li>jb6494 Mar 03, 2007 Updated sorting for ST ML#08
 * <li>jb6494 Mar 19, 2007 Kin: reset division fields
 * 
 * </ul>
 * <p>
 * 
 */
public class AdhocRptForm extends SortedForm {
    private String procDates;

    private String billRounds;

    private String holidayIndicators;

    private String loadedDataDates;

    private static final Logger logger = Logger.getLogger(AdhocRptForm.class);

    private AdhocRptDataTO adhocRptDataTO = null;

    private String dispatch = null;

    private String emailRecipients = null;

    private String fromRow = "1";

    private int gotoPage = 0;

    private int numberOfTables = 1;

    private String numOfRows = null;
    
    private String backgroundProcess;

    private int btnValue = -1;
        
    private String notes = null;    
     
    private String duplicateCriteria="N";    
    
    /**
     * @return String loadedDataDates
     */
    public String getLoadedDataDates() {
        return loadedDataDates;
    }
    

	public void setDuplicateCriteria(String duplicateCriteria) {
		this.duplicateCriteria = duplicateCriteria;
	}
	
	public String getDuplicateCriteria() {
		return duplicateCriteria;
	}
	


    /**
     * @param loadedDataDates String
     */
    public void setLoadedDataDates(String loadedDataDates) {
        this.loadedDataDates = loadedDataDates;
    }

    private ArrayList tables = new ArrayList();

    private String toRow = null; // 20060427

    private String reportAction = null; // 20060424

    private String schedTask = null; // 20060424


    /**
     * REQUIRED default constructor!!!!
     */
    public AdhocRptForm() {
        super();
        this.adhocRptDataTO = new AdhocRptDataTO();
        setPage(1);
    }


    /**
     * @return
     */
    public AdhocRptDataTO getAdhocRptDataTO() {
        return adhocRptDataTO;
    }


    /**
     * @return
     */
    public void reset(ActionMapping mapping, HttpServletRequest request) {
        String region = (String) request.getSession().getAttribute("region");
        setBillRounds(StaticDataLoader.getBillRounds(region));
        setProcDates(StaticDataLoader.getProcDates(region));
        setHolidayIndicators(StaticDataLoader.getHolidayIndicators(region));
        setLoadedDataDates(StaticDataLoader.getLoadedDataDatesByRegion(region));
        
        // clear division
        setSelectedDivs(new String[]{});
        setDivisionName("");
        setDivisionName1("");
        
        
       	setBackgroundProcess("");
        setNotes("");        
        
    }


    /**
     * @return
     */
    public String getAdhocTest() {
        return this.adhocRptDataTO.getAdhocTest();
    }


    /**
     * @return
     */
    public String getAlertTimeInd() {
        return this.adhocRptDataTO.getAlertTimeInd();
    }


    /**
     * @return
     */
    public ArrayList getAlertTimeIndOptions() {
        return this.adhocRptDataTO.getAlertTimeIndOptions();
    }


    /**
     * @return
     */
    public int getAlertTimeValue() {
        return this.adhocRptDataTO.getAlertTimeValue();
    }


    /**
     * @return
     */
    public int getAlertTimeValueBR() {
        return adhocRptDataTO.getAlertTimeValueBR();
    }


    /**
     * @return
     */
    public ArrayList getAlertTimeValueOptions() {
        return adhocRptDataTO.getAlertTimeValueOptions();
    }


    /**
     * @return
     */
    public ArrayList getAlertTimeValueOptionsBR() {
        return this.adhocRptDataTO.getAlertTimeValueOptionsBR();
    }


    /**
     * @return
     */
    public ArrayList getAlertTimeValueOptionsWD() {
        return this.adhocRptDataTO.getAlertTimeValueOptionsWD();
    }


    /**
     * @return
     */
    public int getAlertTimeValueWD() {
        return adhocRptDataTO.getAlertTimeValueWD();
    }


    /**
     * @return
     */
    public int getBillRnd() {
        return adhocRptDataTO.getBillRnd();
    }


    /**
     * @return
     */
    public ArrayList getBillRndOptions() {
        return adhocRptDataTO.getBillRndOptions();
    }


    /**
     * @return
     */
    public String getBillRounds() {
        return billRounds;
    }


    /**
     * @return
     */
    public String getClickLvl() {
        return this.adhocRptDataTO.getClickLvl();
    }


    /**
     * @return
     */
    public String getDatabaseNode() {
        return this.adhocRptDataTO.getDatabaseNode();
    }


    /*
     * (non-Javadoc)
     * 
     * @see com.att.bac.rabc.PagedForm#getDispatch()
     */
    public String getDispatch() {
        return dispatch;
    }


    /**
     * @return
     */
    public String getDivisionList() {
        return this.adhocRptDataTO.getDivisionList();
    }


    /**
     * @return
     */
    public String getDivisionName() {
        return this.adhocRptDataTO.getDivisionName();
    }


    /**
     * @return
     */
    public String getDivisionName1() {
        return this.adhocRptDataTO.getDivisionName1();
    }


    /**
     * @return
     */
    public ArrayList getDivisions() {
        return this.adhocRptDataTO.getDivisions();
    }


    /**
     * @return
     */
    public int getDivNameKeyLvl() {
        return adhocRptDataTO.getDivNameKeyLvl();
    }


    /**
     * @return
     */
    public String getEmailRecipients() {
        return emailRecipients;
    }


    /**
     * @return
     */
    public String getEmailReport() {
        return this.adhocRptDataTO.getEmailReport();
    }


    /**
     * @return
     */
    public String getEndDate() {
        return this.adhocRptDataTO.getEndDate();
    }


    /**
     * @return
     */
    public int getFileSeqNum() {
        return this.adhocRptDataTO.getFileSeqNum();
    }


    /**
     * @return
     */
    public String getFileSeqNumAsString() {
        return this.adhocRptDataTO.getFileSeqNumAsString();
    }


    /**
     * @return
     */
    public String getFromPage() {
        return this.adhocRptDataTO.getFromPage();
    }


    /**
     * @return
     */
    public String getFromRow() {
        return fromRow;
    }


    /**
     * @return
     */
    public String getGenEndDate() {
        return this.adhocRptDataTO.getGenEndDate();
    }


    /**
     * @return
     */
    public String getGenStartDate() {
        return this.adhocRptDataTO.getGenStartDate();
    }


    /**
     * @return
     */
    public int getGotoPage() {
        return gotoPage;
    }


    /**
     * @return
     */
    public String getHolidayIndicators() {
        return holidayIndicators;
    }


    /**
     * @return
     */
    public String getKey1() {
        return this.adhocRptDataTO.getKey1();
    }


    /**
     * @return
     */
    public String getKey2() {
        return this.adhocRptDataTO.getKey2();
    }


    /**
     * @return
     */
    public String getKey3() {
        return this.adhocRptDataTO.getKey3();
    }


    /**
     * @return
     */
    public String getKey4() {
        return this.adhocRptDataTO.getKey4();
    }


    /**
     * @return
     */
    public String getKey5() {
        return this.adhocRptDataTO.getKey5();
    }


    /**
     * @return
     */
    public String getLabelSortKeyList() {
        return this.adhocRptDataTO.getLabelSortKeyList();
    }


    /**
     * @return
     */
    public String getLabelSortKeyList2() {
        return this.adhocRptDataTO.getLabelSortKeyList2();
    }


    /**
     * @return
     */
    public int getMonthSelect() {
        return this.adhocRptDataTO.getMonthSelect();
    }


    /**
     * @return
     */
    public ArrayList getMonthSelectOptions() {
        return adhocRptDataTO.getMonthSelectOptions();
    }


    /**
     * @return
     */
    public int getNumberOfTables() {
        return numberOfTables;
    }


    /**
     * @return
     */
    public String getNumOfRows() {
        return numOfRows;
    }


    /**
     * @return
     */
    public int getPartiRefId() {
        return this.adhocRptDataTO.getPartiRefId();
    }


    /**
     * @return
     */
    public int getPresnId() {
        return this.adhocRptDataTO.getPresnId();
    }


    /**
     * @return
     */
    public String getPresnIdAsString() {
        return this.adhocRptDataTO.getPresnIdAsString();
    }


    /**
     * @return
     */
    public int getPresnModel() {
        return this.adhocRptDataTO.getPresnModel();
    }


    /**
     * @return
     */
    public String getProcDate() {
        return this.adhocRptDataTO.getProcDate();
    }


    /**
     * @return
     */
    public String getProcDateInd() {
        return this.adhocRptDataTO.getProcDateInd();
    }


    /**
     * @return
     */
    public String getProcDates() {
        return procDates;
    }


    /**
     * @return
     */
    public String getRegion() {
        return this.adhocRptDataTO.getRegion();
    }


    /**
     * @return
     */
    public String getReportAction() {
        return reportAction;
    }


    /**
     * @return
     */
    public String getRptHeader1() {
        return this.adhocRptDataTO.getRptHeader1();
    }


    /**
     * @return
     */
    public String getRptHeader2() {
        return this.adhocRptDataTO.getRptHeader2();
    }


    /**
     * @return
     */
    public String getRptHeader3() {
        return this.adhocRptDataTO.getRptHeader3();
    }


    /**
     * @return
     */
    public String getRptHeaderDateInd() {
        return this.adhocRptDataTO.getRptHeaderDateInd();
    }


    /**
     * @return
     */
    public String getSchedTask() {
        return schedTask;
    }


    /**
     * @return
     */
    public String[] getSelectedDivs() {
        return this.adhocRptDataTO.getSelectedDivs();
    }


    /**
     * @return
     */
    public String getSortKeyList() {
        return this.adhocRptDataTO.getSortKeyList();
    }


    /**
     * @return
     */
    public String getSortKeyList2() {
        return this.adhocRptDataTO.getSortKeyList2();
    }


    /**
     * @return
     */
    public String getStartDate() {
        return this.adhocRptDataTO.getStartDate();
    }


    /**
     * @return
     */
    public String getStyleAlertTimeValue() {
        return adhocRptDataTO.getStyleAlertTimeValue();
    }


    /**
     * @return
     */
    public String getStyleAlertTimeValueBR() {
        return adhocRptDataTO.getStyleAlertTimeValueBR();
    }


    /**
     * @return
     */
    public String getStyleAlertTimeValueWD() {
        return adhocRptDataTO.getStyleAlertTimeValueWD();
    }


    /**
     * @return
     */
    public ArrayList getTables() {
        return tables;
    }


    /**
     * @return
     */
    public String getToRow() {
        return toRow;
    }


    /**
     * @return
     */
    public String getWebId() {
        return this.adhocRptDataTO.getWebId();
    }


    /**
     * @return
     */
    public int getYearSelect() {
        return this.adhocRptDataTO.getYearSelect();
    }


    /**
     * @return
     */
    public ArrayList getYearSelectOptions() {
        return adhocRptDataTO.getYearSelectOptions();
    }


    /**
     * @return
     */
    public boolean isHideAlertRuleTiming() {
        return this.adhocRptDataTO.isHideAlertRuleTiming();
    }


    /**
     * @return
     */
    public boolean isHideCreate() {
        return this.adhocRptDataTO.isHideCreate();
    }


    /**
     * @return
     */
    public boolean isHideDivCheckBox() {
        return this.adhocRptDataTO.isHideDivCheckBox();
    }


    /**
     * @return
     */
    public boolean isHideDivDropDown() {
        return this.adhocRptDataTO.isHideDivDropDown();
    }


    /**
     * @return
     */
    public boolean isHideEmail() {
        return this.adhocRptDataTO.isHideEmail();
    }


    /*
     * public boolean isHideDivLabel() { return this.adhocRptDataTO.isHideDivLabel(); } public void
     * setHideDivLabel(boolean hideDivLabel) { this.adhocRptDataTO.setHideDivLabel(hideDivLabel); }
     */
    public boolean isHideFileSeqNum() {
        return this.adhocRptDataTO.isHideFileSeqNum();
    }


    /**
     * @return
     */
    public boolean isHideMonthYear() {
        return adhocRptDataTO.isHideMonthYear();
    }


    /**
     * @return
     */
    public boolean isHideNext() {
        return this.adhocRptDataTO.isHideNext();
    }


    /**
     * @return
     */
    public boolean isHidePrev() {
        return this.adhocRptDataTO.isHidePrev();
    }


    /**
     * @return
     */
    public boolean isHideSortKeyList() {
        return this.adhocRptDataTO.isHideSortKeyList();
    }


    /**
     * @return
     */
    public boolean isHideSortKeyList2() {
        return this.adhocRptDataTO.isHideSortKeyList2();
    }


    /**
     * @return
     */
    public boolean isHideView() {
        return this.adhocRptDataTO.isHideView();
    }


    /**
     * @return
     */
    public boolean isOnlySelected() {
        return this.adhocRptDataTO.isOnlySelected();
    }


    /**
     * @return
     */
    public boolean isSelectUniqRows() {
        return this.adhocRptDataTO.isSelectUniqRows();
    }


    /**
     * @param adhocRptDataTO
     */
    public void setAdhocRptDataTO(AdhocRptDataTO adhocRptDataTO) {
        this.adhocRptDataTO = adhocRptDataTO;
    }


    /**
     * @param adhocTest
     */
    public void setAdhocTest(String adhocTest) {
        this.adhocRptDataTO.setAdhocTest(adhocTest);
    }


    /**
     * @param alertTimeInd
     */
    public void setAlertTimeInd(String alertTimeInd) {
        this.adhocRptDataTO.setAlertTimeInd(alertTimeInd);
    }


    /**
     * @param alertTimeIndOptions
     */
    public void setAlertTimeIndOptions(ArrayList alertTimeIndOptions) {
        this.adhocRptDataTO.setAlertTimeIndOptions(alertTimeIndOptions);
    }


    /**
     * @param alertTimeValue
     */
    public void setAlertTimeValue(int alertTimeValue) {
        this.adhocRptDataTO.setAlertTimeValue(alertTimeValue);
    }


    /**
     * @param alertTimeValueBR
     */
    public void setAlertTimeValueBR(int alertTimeValueBR) {
        this.adhocRptDataTO.setAlertTimeValueBR(alertTimeValueBR);
    }


    /**
     * @param alertTimeValueOptions
     */
    public void setAlertTimeValueOptions(ArrayList alertTimeValueOptions) {
        this.adhocRptDataTO.setAlertTimeValueOptions(alertTimeValueOptions);
    }


    /**
     * @param alertTimeValueOptionsBR
     */
    public void setAlertTimeValueOptionsBR(ArrayList alertTimeValueOptionsBR) {
        this.adhocRptDataTO.setAlertTimeValueOptionsBR(alertTimeValueOptionsBR);
    }


    /**
     * @param alertTimeValueOptionsWD
     */
    public void setAlertTimeValueOptionsWD(ArrayList alertTimeValueOptionsWD) {
        this.adhocRptDataTO.setAlertTimeValueOptionsWD(alertTimeValueOptionsWD);
    }


    /**
     * @param alertTimeValueWD
     */
    public void setAlertTimeValueWD(int alertTimeValueWD) {
        this.adhocRptDataTO.setAlertTimeValueWD(alertTimeValueWD);
    }


    /**
     * @param billRnd
     */
    public void setBillRnd(int billRnd) {
        this.adhocRptDataTO.setBillRnd(billRnd);
    }


    /**
     * @param billRndOptions
     */
    public void setBillRndOptions(ArrayList billRndOptions) {
        this.adhocRptDataTO.setBillRndOptions(billRndOptions);
    }


    /**
     * @param billRounds
     */
    public void setBillRounds(String billRounds) {
        this.billRounds = billRounds;
    }


    /**
     * @param clickLvl
     */
    public void setClickLvl(String clickLvl) {
        this.adhocRptDataTO.setClickLvl(clickLvl);
    }


    /**
     * @param databaseNode
     */
    public void setDatabaseNode(String databaseNode) {
        this.adhocRptDataTO.setDatabaseNode(databaseNode);
    }


    /*
     * (non-Javadoc)
     * 
     * @see com.att.bac.rabc.PagedForm#setDispatch(java.lang.String)
     */
    public void setDispatch(String dispatch) {
        this.dispatch = dispatch;
    }


    /**
     * @param divisionList
     */
    public void setDivisionList(String divisionList) {
        this.adhocRptDataTO.setDivisionList(divisionList);
    }


    /**
     * @param divisionName
     */
    public void setDivisionName(String divisionName) {
        this.adhocRptDataTO.setDivisionName(divisionName);
    }


    /**
     * @param divisionName1
     */
    public void setDivisionName1(String divisionName1) {
        this.adhocRptDataTO.setDivisionName1(divisionName1);
    }


    /**
     * @param divisions
     */
    public void setDivisions(ArrayList divisions) {
        this.adhocRptDataTO.setDivisions(divisions);
    }


    /**
     * @param divNameKeyLvl
     */
    public void setDivNameKeyLvl(int divNameKeyLvl) {
        this.adhocRptDataTO.setDivNameKeyLvl(divNameKeyLvl);
    }


    /**
     * @param emailRecipients
     */
    public void setEmailRecipients(String emailRecipients) {
        this.emailRecipients = emailRecipients;
    }


    /**
     * @param emailReport
     */
    public void setEmailReport(String emailReport) {
        this.adhocRptDataTO.setEmailReport(emailReport);
    }


    /**
     * @param endDate
     */
    public void setEndDate(String endDate) {
        this.adhocRptDataTO.setEndDate(endDate);
    }


    /**
     * @param fileSeqNum
     */
    public void setFileSeqNum(int fileSeqNum) {
        this.adhocRptDataTO.setFileSeqNum(fileSeqNum);
    }


    /**
     * @param fileSeqNumAsString
     */
    public void setFileSeqNumAsString(String fileSeqNumAsString) {
        this.adhocRptDataTO.setFileSeqNumAsString(fileSeqNumAsString);
    }


    /**
     * @param fromPage
     */
    public void setFromPage(String fromPage) {
        this.adhocRptDataTO.setFromPage(fromPage);
    }


    /**
     * @param fromRow
     */
    public void setFromRow(String fromRow) {
        this.fromRow = fromRow;
    }


    /**
     * @param genEndDate
     */
    public void setGenEndDate(String genEndDate) {
        this.adhocRptDataTO.setGenEndDate(genEndDate);
    }


    /**
     * @param genStartDate
     */
    public void setGenStartDate(String genStartDate) {
        this.adhocRptDataTO.setGenStartDate(genStartDate);
    }


    /**
     * @param gotoPage
     */
    public void setGotoPage(int gotoPage) {
        this.gotoPage = gotoPage;
    }


    /**
     * @param hideAlertRuleTiming
     */
    public void setHideAlertRuleTiming(boolean hideAlertRuleTiming) {
        this.adhocRptDataTO.setHideAlertRuleTiming(hideAlertRuleTiming);
    }


    /**
     * @param hideCreate
     */
    public void setHideCreate(boolean hideCreate) {
        this.adhocRptDataTO.setHideCreate(hideCreate);
    }


    /**
     * @param hideDivCheckBox
     */
    public void setHideDivCheckBox(boolean hideDivCheckBox) {
        this.adhocRptDataTO.setHideDivCheckBox(hideDivCheckBox);
    }


    /**
     * @param hideDivDropDown
     */
    public void setHideDivDropDown(boolean hideDivDropDown) {
        this.adhocRptDataTO.setHideDivDropDown(hideDivDropDown);
    }


    /**
     * @param hideEmail
     */
    public void setHideEmail(boolean hideEmail) {
        this.adhocRptDataTO.setHideEmail(hideEmail);
    }


    /**
     * @param hideFileSeqNum
     */
    public void setHideFileSeqNum(boolean hideFileSeqNum) {
        this.adhocRptDataTO.setHideFileSeqNum(hideFileSeqNum);
    }


    /**
     * @param hideMonthYear
     */
    public void setHideMonthYear(boolean hideMonthYear) {
        this.adhocRptDataTO.setHideMonthYear(hideMonthYear);
    }


    /**
     * @param hideNext
     */
    public void setHideNext(boolean hideNext) {
        this.adhocRptDataTO.setHideNext(hideNext);
    }


    /**
     * @param hidePrev
     */
    public void setHidePrev(boolean hidePrev) {
        this.adhocRptDataTO.setHidePrev(hidePrev);
    }


    /**
     * @param hideSortKeyList
     */
    public void setHideSortKeyList(boolean hideSortKeyList) {
        this.adhocRptDataTO.setHideSortKeyList(hideSortKeyList);
    }


    /**
     * @param hideSortKeyList2
     */
    public void setHideSortKeyList2(boolean hideSortKeyList2) {
        this.adhocRptDataTO.setHideSortKeyList2(hideSortKeyList2);
    }


    /**
     * @param hideView
     */
    public void setHideView(boolean hideView) {
        this.adhocRptDataTO.setHideView(hideView);
    }


    /**
     * @param holidayIndicators
     */
    public void setHolidayIndicators(String holidayIndicators) {
        this.holidayIndicators = holidayIndicators;
    }


    /**
     * @param key1
     */
    public void setKey1(String key1) {
        this.adhocRptDataTO.setKey1(key1);
    }


    /**
     * @param key2
     */
    public void setKey2(String key2) {
        this.adhocRptDataTO.setKey2(key2);
    }


    /**
     * @param key3
     */
    public void setKey3(String key3) {
        this.adhocRptDataTO.setKey3(key3);
    }


    /**
     * @param key4
     */
    public void setKey4(String key4) {
        this.adhocRptDataTO.setKey4(key4);
    }


    /**
     * @param key5
     */
    public void setKey5(String key5) {
        this.adhocRptDataTO.setKey5(key5);
    }


    /**
     * @param labelSortKeyList
     */
    public void setLabelSortKeyList(String labelSortKeyList) {
        this.adhocRptDataTO.setLabelSortKeyList(labelSortKeyList);
    }


    /**
     * @param labelSortKeyList2
     */
    public void setLabelSortKeyList2(String labelSortKeyList2) {
        this.adhocRptDataTO.setLabelSortKeyList2(labelSortKeyList2);
    }


    /**
     * @param monthSelect
     */
    public void setMonthSelect(int monthSelect) {
        this.adhocRptDataTO.setMonthSelect(monthSelect);
    }


    /**
     * @param monthSelectOptions
     */
    public void setMonthSelectOptions(ArrayList monthSelectOptions) {
        this.adhocRptDataTO.setMonthSelectOptions(monthSelectOptions);
    }


    /**
     * @param numberOfTables
     */
    public void setNumberOfTables(int numberOfTables) {
        this.numberOfTables = numberOfTables;
    }


    /**
     * @param numOfRows
     */
    public void setNumOfRows(String numOfRows) {
        this.numOfRows = numOfRows;
    }


    /**
     * @param onlySelected
     */
    public void setOnlySelected(boolean onlySelected) {
        this.adhocRptDataTO.setOnlySelected(onlySelected);
    }


    /**
     * @param partiRefId
     */
    public void setPartiRefId(int partiRefId) {
        this.adhocRptDataTO.setPartiRefId(partiRefId);
    }


    /**
     * @param presnId
     */
    public void setPresnId(int presnId) {
        this.adhocRptDataTO.setPresnId(presnId);
    }


    /**
     * @param presnIdAsString
     */
    public void setPresnIdAsString(String presnIdAsString) {
        this.adhocRptDataTO.setPresnIdAsString(presnIdAsString);
    }


    /**
     * @param presnModel
     */
    public void setPresnModel(int presnModel) {
        this.adhocRptDataTO.setPresnModel(presnModel);
    }


    /**
     * @param procDate
     */
    public void setProcDate(String procDate) {
        this.adhocRptDataTO.setProcDate(procDate);
    }


    /**
     * @param procDateInd
     */
    public void setProcDateInd(String procDateInd) {
        this.adhocRptDataTO.setProcDateInd(procDateInd);
    }


    /**
     * @param procDates
     */
    public void setProcDates(String procDates) {
        this.procDates = procDates;
    }


    /**
     * @param region
     */
    public void setRegion(String region) {
        this.adhocRptDataTO.setRegion(region);
    }


    /**
     * @param reportAction
     */
    public void setReportAction(String reportAction) {
        this.reportAction = reportAction;
    }


    /**
     * @param rptHeader1
     */
    public void setRptHeader1(String rptHeader1) {
        this.adhocRptDataTO.setRptHeader1(rptHeader1);
    }


    /**
     * @param rptHeader2
     */
    public void setRptHeader2(String rptHeader2) {
        this.adhocRptDataTO.setRptHeader2(rptHeader2);
    }


    /**
     * @param rptHeader3
     */
    public void setRptHeader3(String rptHeader3) {
        this.adhocRptDataTO.setRptHeader3(rptHeader3);
    }


    /**
     * @param rptHeaderDateInd
     */
    public void setRptHeaderDateInd(String rptHeaderDateInd) {
        this.adhocRptDataTO.setRptHeaderDateInd(rptHeaderDateInd);
    }


    /**
     * @param schedTask
     */
    public void setSchedTask(String schedTask) {
        this.schedTask = schedTask;
    }


    /**
     * @param selectedDivs
     */
    public void setSelectedDivs(String[] selectedDivs) {
        this.adhocRptDataTO.setSelectedDivs(selectedDivs);
    }


    /**
     * @param selectUniqRows
     */
    public void setSelectUniqRows(boolean selectUniqRows) {
        this.adhocRptDataTO.setSelectUniqRows(selectUniqRows);
    }


    /*
     * (non-Javadoc)
     * 
     * @see com.att.bac.rabc.SortedForm#setSortItem(java.lang.String)
     */
    public void setSortItem(String sortItem) {
        super.setSortItem(sortItem);
        adhocRptDataTO.setUserSortColumn(sortItem);
    }


    /**
     * @param sortKeyList
     */
    public void setSortKeyList(String sortKeyList) {
        this.adhocRptDataTO.setSortKeyList(sortKeyList);
    }


    /**
     * @param sortKeyList2
     */
    public void setSortKeyList2(String sortKeyList2) {
        this.adhocRptDataTO.setSortKeyList2(sortKeyList2);
    }


    /*
     * (non-Javadoc)
     * 
     * @see com.att.bac.rabc.SortedForm#setSortOrder(java.lang.String)
     */
    public void setSortOrder(String sortOrder) {
        super.setSortOrder(sortOrder);
        adhocRptDataTO.setUserSortType((sortOrder + " ").charAt(0));
    }


    /**
     * @param startDate
     */
    public void setStartDate(String startDate) {
        this.adhocRptDataTO.setStartDate(startDate);
    }


    /**
     * @param styleAlertTimeValue
     */
    public void setStyleAlertTimeValue(String styleAlertTimeValue) {
        this.adhocRptDataTO.setStyleAlertTimeValue(styleAlertTimeValue);
    }


    /**
     * @param styleAlertTimeValueBR
     */
    public void setStyleAlertTimeValueBR(String styleAlertTimeValueBR) {
        this.adhocRptDataTO.setStyleAlertTimeValueBR(styleAlertTimeValueBR);
    }


    /**
     * @param styleAlertTimeValueWD
     */
    public void setStyleAlertTimeValueWD(String styleAlertTimeValueWD) {
        this.adhocRptDataTO.setStyleAlertTimeValueWD(styleAlertTimeValueWD);
    }


    /**
     * @param tables
     */
    public void setTables(ArrayList tables) {
        this.tables = tables;
    }


    /**
     * @param toRow
     */
    public void setToRow(String toRow) {
        this.toRow = toRow;
    }


    /**
     * @param yearSelect
     */
    public void setYearSelect(int yearSelect) {
        this.adhocRptDataTO.setYearSelect(yearSelect);
    }


    /**
     * @param yearSelectOptions
     */
    public void setYearSelectOptions(ArrayList yearSelectOptions) {
        this.adhocRptDataTO.setYearSelectOptions(yearSelectOptions);
    }

    /**
	 * @return the billRoundCheck
	 */
	public String getBillRoundCheck() {
		return this.adhocRptDataTO.getBillRoundCheck();
	}

	/**
	 * @param billRoundCheck the billRoundCheck to set
	 */
	public void setBillRoundCheck(String billRoundCheck) {
		this.adhocRptDataTO.setBillRoundCheck(billRoundCheck);
	}
	
	/**
	 * @return the hideBillRoundCheck
	 */
	public boolean isHideBillRoundCheck() {
		return this.adhocRptDataTO.isHideBillRoundCheck();
	}

	 /**
     * @param 
     */
    public void setHideBillRoundCheck(boolean hideBillRoundCheck) {
        this.adhocRptDataTO.setHideBillRoundCheck(hideBillRoundCheck);
    }

	/**
	 * @return the btnValue
	 */
	public int getBtnValue() {
		return btnValue;
	}


	/**
	 * @param btnValue the btnValue to set
	 */
	public void setBtnValue(int btnValue) {
		this.btnValue = btnValue;
	}
    /*
     * (non-Javadoc)
     * 
     * @see org.apache.struts.action.ActionForm#validate(org.apache.struts.action.ActionMapping,
     *      javax.servlet.http.HttpServletRequest)
     */
    public ActionErrors validate(ActionMapping mapping, HttpServletRequest req) {
        ActionErrors errors = new ActionErrors();
        
        //added this since procdate is null when dispatch is background and it cannot be
        if ((String)req.getParameter("dispatch")!=null && ((String)req.getParameter("dispatch")).equals("background")) {
        	if (this.adhocRptDataTO.getProcDate() == null || this.adhocRptDataTO.getProcDate().trim().equals("")) {
	    		Calendar lCal = Calendar.getInstance();
	            lCal.add(Calendar.DATE, -1);
	            String month = null;
	            String day = null;
	            String year = null;
	            String procDate = null;
	            
	            if (lCal.get(Calendar.MONTH) < 9){
	    	    	month = "0" + Integer.toString(lCal.get(Calendar.MONTH)+1);
	    	    }else{
	    	    	month = Integer.toString(lCal.get(Calendar.MONTH)+1);
	    	    } 
	            
	            if (lCal.get(Calendar.DATE) < 10){
	    	    	day = "0" + Integer.toString(lCal.get(Calendar.DATE));
	    	    }else{
	    	    	day = Integer.toString(lCal.get(Calendar.DATE));
	    	    }
	            year = Integer.toString(lCal.get(Calendar.YEAR));
	      		
	      		procDate = month + "/" + day +"/" + year;
	      		this.adhocRptDataTO.setProcDate(procDate); 
        	}
        }
        

        // Check for presnid and procDate. If they doen't exists goback to previous page.
        if (this.adhocRptDataTO.getPresnIdAsString() != null && !this.adhocRptDataTO.getPresnIdAsString().trim().equals("")) {
            try {
                this.adhocRptDataTO.setPresnId(Integer.parseInt(this.adhocRptDataTO.getPresnIdAsString()));
            } catch (NumberFormatException nfex) {
                ActionMessage error = new ActionMessage("adhocrpt.error.numericfield", "Presn ID");
                errors.add(ActionMessages.GLOBAL_MESSAGE, error);
            }
        } else {
            ActionMessage error = new ActionMessage("adhocrpt.error.requiredfield", "Presn ID");
            errors.add(ActionMessages.GLOBAL_MESSAGE, error);
        }
        if (this.adhocRptDataTO.getProcDate() == null || this.adhocRptDataTO.getProcDate().trim().equals("")) {
            ActionMessage error = new ActionMessage("adhocrpt.error.requiredfield", "Proc Date");
            errors.add(ActionMessages.GLOBAL_MESSAGE, error);
        }
        if (this.adhocRptDataTO.getFileSeqNumAsString() != null && !this.adhocRptDataTO.getFileSeqNumAsString().trim().equals("")) {
            try {
                this.adhocRptDataTO.setFileSeqNum(Integer.parseInt(this.adhocRptDataTO.getFileSeqNumAsString()));
            } catch (NumberFormatException nfex) {
                ActionMessage error = new ActionMessage("adhocrpt.error.numericfield", "File Sequence Number");
                errors.add(ActionMessages.GLOBAL_MESSAGE, error);
            }
        }

        // consolidate alertTimeValue based on alertTimeInd
        if (adhocRptDataTO.getAlertTimeInd().equalsIgnoreCase("D")) {
            adhocRptDataTO.setAlertTimeValue(adhocRptDataTO.getAlertTimeValueWD());
        } else if (adhocRptDataTO.getAlertTimeInd().equalsIgnoreCase("B")) {
            adhocRptDataTO.setAlertTimeValue(adhocRptDataTO.getAlertTimeValueBR());
        }

        if (toRow == null) {
            try {
                Context context = (Context) new InitialContext().lookup("java:/comp/env");
                toRow = (String) context.lookup("default_toRow");
            } catch (Exception e) {
                logger.warn("Unable to find 'default_toRow'. Using default.", e);
                toRow = "100";
            }
        }
        if (errors.size() > 0) {
            logger.debug("AdhocRptForm validate errors: " + errors);
        }
        return errors;
    }
	public String getBackgroundProcess() {
		return backgroundProcess;
	}


	public void setBackgroundProcess(String backgroundProcess) {
		this.backgroundProcess = backgroundProcess;
	}


	public String getNotes() {
		return notes;
	}


	public void setNotes(String notes) {
		this.notes = notes;
	}


}
