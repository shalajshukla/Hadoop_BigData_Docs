/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/

package com.att.bac.rabc.alerts.rpt;

/**
 * This class represents the data object that holds the attributes required
 * to represent the Alert Report (Control Alert Detail) page.
 * 
 * @author Nalina Pandiyan - NP5434
 */
public class AlertCell {
	private String value;
	private String title;
	private String imageSrc;
	private String bgColor;
	private String thisClass;
	private String href;
	private String hrefForImage;
	private String addlnTitle;
	private String addlnValue;
	private String align;
	private String valign;
	private String nowrap;
	private String excelDataType;

	/**
	 * Default constructor which sets the default value, title, imageSrc, bgColor, thisClass,
	 * href, hrefForImage, addlnTitle, addlnValue, align, valign and nowrap attributes.  
	 */
	public AlertCell() {
		this.value = "";
		this.title = "";
		this.imageSrc = "";
		this.bgColor = "";
		this.thisClass = "cellText";
		this.href = "";
		this.hrefForImage = "";
		this.addlnTitle = "";
		this.addlnValue = "";
		this.align = "center";
		this.valign = "top";
		this.nowrap = "";
		this.excelDataType = "T";
	}
	
	/**
	 * @return Returns the addlnTitle.
	 */
	public String getAddlnTitle() {
		return addlnTitle;
	}

	/**
	 * @param addlnTitle The addlnTitle to set.
	 */
	public void setAddlnTitle(String addlnTitle) {
		this.addlnTitle = addlnTitle==null?"":addlnTitle;
	}

	/**
	 * @return Returns the addlnValue.
	 */
	public String getAddlnValue() {
		return addlnValue;
	}

	/**
	 * @param addlnValue The addlnValue to set.
	 */
	public void setAddlnValue(String addlnValue) {
		this.addlnValue = addlnValue==null?"":addlnValue;
	}

	/**
	 * @return Returns the href.
	 */
	public String getHref() {
		return href;
	}

	/**
	 * @param href The href to set.
	 */
	public void setHref(String href) {
		this.href = href==null?"":href;
	}

	/**
	 * @return Returns the hrefForImage.
	 */
	public String getHrefForImage() {
		return hrefForImage;
	}

	/**
	 * @param hrefForImage The hrefForImage to set.
	 */
	public void setHrefForImage(String hrefForImage) {
		this.hrefForImage = hrefForImage==null?"":hrefForImage;
	}

	/**
	 * @return Returns the imageSrc.
	 */
	public String getImageSrc() {
		return imageSrc;
	}

	/**
	 * @param imageSrc The imageSrc to set.
	 */
	public void setImageSrc(String imageSrc) {
		this.imageSrc = imageSrc==null?"":imageSrc;
	}

	/**
	 * @return Returns the title.
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @param title The title to set.
	 */
	public void setTitle(String title) {
		this.title = title==null?"":title;
	}

	/**
	 * @return Returns the value.
	 */
	public String getValue() {
		return value;
	}

	/**
	 * @param value The value to set.
	 */
	public void setValue(String value) {
		this.value = value==null?"":value;
	}

	/**
	 * @return Returns the bgColor.
	 */
	public String getBgColor() {
		return bgColor;
	}
	/**
	 * @param bgColor The bgColor to set.
	 */
	public void setBgColor(String bgColor) {
		this.bgColor = bgColor==null?"":bgColor;
	}
	/**
	 * @return Returns the thisClass.
	 */
	public String getThisClass() {
		return thisClass;
	}
	/**
	 * @param thisClass The thisClass to set.
	 */
	public void setThisClass(String thisClass) {
		this.thisClass = thisClass==null?"":thisClass;
	}
	/**
	 * @return Returns the align.
	 */
	public String getAlign() {
		return align;
	}

	/**
	 * @param align The align to set.
	 */
	public void setAlign(String align) {
		this.align = align==null?"":align;
	}

	/**
	 * @return Returns the valign.
	 */
	public String getValign() {
		return valign;
	}

	/**
	 * @param valign The valign to set.
	 */
	public void setValign(String valign) {
		this.valign = valign==null?"":valign;
	}

	/**
	 * @return Returns the nowrap.
	 */
	public String getNowrap() {
		return nowrap;
	}

	/**
	 * @param nowrap The nowrap to set.
	 */
	public void setNowrap(String nowrap) {
		this.nowrap = nowrap==null?"":nowrap;
	}

	/**
	 * @return the excelDataType
	 */
	public String getExcelDataType() {
		return excelDataType;
	}

	/**
	 * @param excelDataType the excelDataType to set
	 */
	public void setExcelDataType(String excelDataType) {
		this.excelDataType = excelDataType;
	}
}
