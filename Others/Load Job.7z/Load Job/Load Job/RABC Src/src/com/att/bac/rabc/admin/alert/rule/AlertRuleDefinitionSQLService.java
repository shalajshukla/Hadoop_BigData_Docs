/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.admin.alert.rule;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.att.bac.rabc.ExtrctTblDefDAO;
import com.att.bac.rabc.MouseOverLinkDAO;
import com.att.bac.rabc.PresnIdDAO;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.WebDataLinkDAO;
import com.att.bac.rabc.WebHeaderLinkDAO;
import com.att.bac.rabc.admin.AlertGroupDAO;
import com.att.bac.rabc.admin.MenuIndexDAO;
import com.att.bac.rabc.admin.PresnHeaderDAO;
import com.att.bac.rabc.alerts.AlertRulePresnElemDAO;
import com.att.bac.rabc.alerts.AlertSumyPresnDAO;
import com.att.bac.rabc.alerts.rpt.AlertRulePresenRuleDAO;

/**
 * This is a service class having all sqls for saving an Alert Rule.
 * 
 * @author Shashank Weginwar - SW3562
 */
public class AlertRuleDefinitionSQLService {
	
	private static final Logger logger = Logger.getLogger(AlertRuleDefinitionSQLService.class);
		
	protected static final String getPartiRefID = "SELECT MAX(PARTI_REF_ID) FROM RABC_ALERT_RULE";
	
	protected static final String getPresenId = "SELECT DISTINCT(PRESN_ID) FROM RABC_PRESN_ID ORDER BY PRESN_ID ASC";

	protected static final String getPresnNum = "SELECT MAX(PRESN_SEQ_NUM) FROM RABC_CNTRL_PT_ALERT";
	
	protected static final String INS_RABC_ALERT_RULE_Track_1 = "INSERT INTO RABC_ALERT_RULE (ALERT_RULE, PRESN_ID, " +
	"FILE_VERIF_IND, DATA_EXTRCT_IND, DATA_CALC_IND, CALC_RULE, WARNING_IND, AVG_IND, ALERT_MSG_IND, " +
	"ALERT_SEQ_NUM_IND, ALERT_TIME_IND, ALERT_DASH_FRESH_IND, ALERT_DESC, ALERT_EXEC_DATE, ALERT_KEY_LVL, " +
	"ALERT_KEY1_NAME, ALERT_KEY2_NAME, ALERT_KEY3_NAME, ALERT_KEY4_NAME, ALERT_KEY5_NAME, ALERT_FILE_CT, " +
	"ASOC_FILE_ID, ALERT_RULE_PRESN_IND, DIVISION_NAME_KEY_LVL, DB_NODE_ID, ALERT_RULE_STATUS, EFF_DATE, " +
	"STD_TYPE, ALERT_EXEMPT_IND, USER_ID, TIME_STAMP, PARTI_REF_ID, ALERT_DATA_KEEP, ALERT_RULE_TYPE, " +
	"ALERT_MNTH_EXEC_DAY, ALERT_MNTH_EXEC_BILL_RND) VALUES (''{0}'', ''{1}'', ''Y'', ''Y'', " +
	"''Y'', ''T'', ''Y'', ''Y'', ''{2}'', ''{3}'', {4}, ''{5}'', ''{6}'', ''{7}'', ''{8}'', ''{9}'', " +
	"''{10}'', ''{11}'', ''{12}'', ''{13}'', ''{14}'', NULL, ''{15}'',''{16}'', ''{17}'', ''ACTIVE'', " +
	"TO_DATE(''{18}'',''MM/DD/YYYY''), ''1'', ''{19}'', ''{20}'', SYSDATE, ''{21}'', ''{22}'', ''TRACK'', ''{23}'',''{24}'')";
	
	protected static final String INS_RABC_ALERT_RULE_Track_2 = "INSERT INTO RABC_ALERT_RULE (ALERT_RULE, PRESN_ID, " +
	"FILE_VERIF_IND, DATA_EXTRCT_IND, DATA_CALC_IND, CALC_RULE, WARNING_IND, AVG_IND, ALERT_MSG_IND, " +
	"ALERT_SEQ_NUM_IND, ALERT_TIME_IND, ALERT_DASH_FRESH_IND, ALERT_DESC, ALERT_EXEC_DATE, ALERT_KEY_LVL, " +
	"ALERT_KEY1_NAME, ALERT_KEY2_NAME, ALERT_KEY3_NAME, ALERT_KEY4_NAME, ALERT_KEY5_NAME, ALERT_FILE_CT, " +
	"ASOC_FILE_ID, ALERT_RULE_PRESN_IND, DIVISION_NAME_KEY_LVL, DB_NODE_ID, ALERT_RULE_STATUS, EFF_DATE, " +
	"STD_TYPE, ALERT_EXEMPT_IND, USER_ID, TIME_STAMP, PARTI_REF_ID, ALERT_DATA_KEEP, ALERT_RULE_TYPE, " +
	"ALERT_MNTH_EXEC_DAY, ALERT_MNTH_EXEC_BILL_RND) VALUES (''{0}'', ''{1}'', ''Y'', ''Y'', " +
	"''Y'', ''T'', ''Y'', ''Y'', ''{2}'', ''{3}'', {4}, ''{5}'', ''{6}'', NULL, ''{7}'', ''{8}'', " +
	"''{9}'', ''{10}'', ''{11}'', ''{12}'', ''{13}'', NULL, ''{14}'',''{15}'', ''{16}'', ''ACTIVE'', " +
	"TO_DATE(''{17}'',''MM/DD/YYYY''), ''1'', ''{18}'', ''{19}'', SYSDATE, ''{20}'', ''{21}'', ''TRACK'', ''{22}'',''{23}'')";
	
	protected static final String INS_RABC_ALERT_RULE_Trend_1 = "INSERT INTO RABC_ALERT_RULE (ALERT_RULE, PRESN_ID, " +
	"FILE_VERIF_IND, DATA_EXTRCT_IND, DATA_CALC_IND, WARNING_IND, AVG_IND, ALERT_MSG_IND, ALERT_SEQ_NUM_IND, " +
	"ALERT_TIME_IND, ALERT_DASH_FRESH_IND, ALERT_DESC, ALERT_EXEC_DATE, ALERT_KEY_LVL, ALERT_KEY1_NAME, " +
	"ALERT_KEY2_NAME, ALERT_KEY3_NAME, ALERT_KEY4_NAME, ALERT_KEY5_NAME, ALERT_FILE_CT, ASOC_FILE_ID, " +
	"ALERT_RULE_PRESN_IND, DIVISION_NAME_KEY_LVL, DB_NODE_ID, ALERT_RULE_STATUS, EFF_DATE, STD_TYPE, ALERT_EXEMPT_IND, " +
	"USER_ID, TIME_STAMP, PARTI_REF_ID, ALERT_DATA_KEEP, ALERT_RULE_TYPE,ALERT_MNTH_EXEC_DAY, ALERT_MNTH_EXEC_BILL_RND) " +
	"VALUES (''{0}'', ''{1}'', ''N'', ''Y'', ''N'', ''Y'', ''Y'', ''{2}'', ''{3}'', " +
	"{4}, ''{5}'', ''{6}'', ''{7}'',  ''{8}'', ''{9}'', ''{10}'', ''{11}'', ''{12}'', ''{13}'', ''1'', NULL, " +
	"''{14}'', ''{15}'', ''{16}'', ''ACTIVE'', TO_DATE(''{17}'',''MM/DD/YYYY''), ''1'', ''{18}'', ''{19}'', SYSDATE, " +
	"''{20}'', ''{21}'', ''TREND'', ''{22}'',''{23}'')";
	
	protected static final String INS_RABC_ALERT_RULE_Trend_2 = "INSERT INTO RABC_ALERT_RULE (ALERT_RULE, PRESN_ID, " +
	"FILE_VERIF_IND, DATA_EXTRCT_IND, DATA_CALC_IND, WARNING_IND, AVG_IND, ALERT_MSG_IND, ALERT_SEQ_NUM_IND, " +
	"ALERT_TIME_IND, ALERT_DASH_FRESH_IND, ALERT_DESC, ALERT_EXEC_DATE, ALERT_KEY_LVL, ALERT_KEY1_NAME, " +
	"ALERT_KEY2_NAME, ALERT_KEY3_NAME, ALERT_KEY4_NAME, ALERT_KEY5_NAME, ALERT_FILE_CT, ASOC_FILE_ID, " +
	"ALERT_RULE_PRESN_IND, DIVISION_NAME_KEY_LVL, DB_NODE_ID, ALERT_RULE_STATUS, EFF_DATE, STD_TYPE, ALERT_EXEMPT_IND, " +
	"USER_ID, TIME_STAMP, PARTI_REF_ID, ALERT_DATA_KEEP, ALERT_RULE_TYPE, ALERT_MNTH_EXEC_DAY, ALERT_MNTH_EXEC_BILL_RND) " +
	"VALUES (''{0}'', ''{1}'', ''N'', ''Y'', ''N'', ''Y'', ''Y'', ''{2}'', ''{3}'', " +
	"{4}, ''{5}'', ''{6}'', NULL,  ''{7}'', ''{8}'', ''{9}'', ''{10}'', ''{11}'', ''{12}'', ''1'', NULL, " +
	"''{13}'', ''{14}'', ''{15}'', ''ACTIVE'', TO_DATE(''{16}'',''MM/DD/YYYY''), ''1'', ''{17}'', ''{18}'', SYSDATE, " +
	"''{19}'', ''{20}'', ''TREND'', ''{21}'',''{22}'')";

	protected static final String INS_RABC_PRESN_ID_Track = "INSERT INTO RABC_PRESN_ID (PRESN_ID_DESC, ASOC_FILE_ID, " +
	"PRESN_TBL_NAME, PROC_DATE_DDL_NAME, PRESN_ID_PRESN_IND, DIVISION_NAME_KEY_LVL, EXEC_PRESN_SEQ_NUM, " +
	"BEG_SUB_TOT_LVL, END_SUB_TOT_LVL, PRESN_MODEL, ADHOC_RPT_IND, ADHOC_RPT_STATUS, DB_NODE_ID, EFF_DT, " +
	"PRESN_TREND_TIME, PRESN_DUR_TIME, TIMING_FILTER_CODE, PRESN_ID) VALUES (''{0}'', NULL, ''RABC_EXTRCT_SUMY_DATA'', " +
	"''PROC_DATE'', ''Y'', ''{1}'', ''1'', ''0'', ''0'', ''1'', NULL, ''ACTIVE'', ''{6}'', " +
	"TO_DATE(''{2}'',''MM/DD/YYYY''), {3} , NULL, {4}, ''{5}'')";
	
	protected static final String INS_RABC_PRESN_ID_Trend = "INSERT INTO RABC_PRESN_ID (PRESN_ID_DESC, ASOC_FILE_ID, " +
	"PRESN_TBL_NAME, PROC_DATE_DDL_NAME, PRESN_ID_PRESN_IND, DIVISION_NAME_KEY_LVL, EXEC_PRESN_SEQ_NUM, " +
	"BEG_SUB_TOT_LVL, END_SUB_TOT_LVL, PRESN_MODEL, ADHOC_RPT_IND, ADHOC_RPT_STATUS, DB_NODE_ID, EFF_DT, PRESN_TREND_TIME, " +
	"PRESN_DUR_TIME, TIMING_FILTER_CODE, PRESN_ID) VALUES (''{0}'', NULL, ''RABC_EXTRCT_SUMY_DATA'', ''PROC_DATE'', " +
	"''Y'', ''{1}'', ''{2}'', ''0'', ''0'', ''1'', NULL, ''ACTIVE'', ''{7}'', TO_DATE(''{3}'',''MM/DD/YYYY''), {4}, NULL, " +
	"{5}, ''{6}'')";

	protected static final String INS_RABC_TRACK_FILE_DTL_Track = "INSERT INTO RABC_TRACK_FILE_DTL(ALERT_RULE, " +
	"FILE_ID, ALERT_ITEM_NAME, ALERT_ITEM_IND, ALERT_DATE_IND, ALERT_ITEM_EXTRCT_TBL, PARTI_REF_ID, ALERT_ITEM_KEY_LVL, " +
	"ALERT_ITEM_KEY1_NAME, ALERT_ITEM_KEY2_NAME, ALERT_ITEM_KEY3_NAME, ALERT_ITEM_KEY4_NAME, ALERT_ITEM_KEY5_NAME, " +
	"ALERT_ITEM_DATA_CT, ALERT_ITEM1_DDL_NAME, ALERT_ITEM1_SUM_IND, ALERT_ITEM1_DDL_NAME_IND,ALERT_ITEM2_DDL_NAME, " + 
	"ALERT_ITEM2_SUM_IND,ALERT_ITEM2_DDL_NAME_IND,ALERT_ITEM3_DDL_NAME, ALERT_ITEM3_SUM_IND, ALERT_ITEM3_DDL_NAME_IND, " + 
	"ALERT_ITEM4_DDL_NAME, ALERT_ITEM4_SUM_IND, ALERT_ITEM4_DDL_NAME_IND,ALERT_ITEM5_DDL_NAME,ALERT_ITEM5_SUM_IND, " + 
	"ALERT_ITEM5_DDL_NAME_IND,ALERT_ITEM6_DDL_NAME, ALERT_ITEM6_SUM_IND, ALERT_ITEM6_DDL_NAME_IND,ALERT_ITEM7_DDL_NAME, " + 
	"ALERT_ITEM7_SUM_IND, ALERT_ITEM7_DDL_NAME_IND,ALERT_ITEM8_DDL_NAME, ALERT_ITEM8_SUM_IND, ALERT_ITEM8_DDL_NAME_IND," + 
	"ALERT_ITEM9_DDL_NAME, ALERT_ITEM9_SUM_IND, ALERT_ITEM9_DDL_NAME_IND,ALERT_ITEM10_DDL_NAME,ALERT_ITEM10_SUM_IND, " + 
	"ALERT_ITEM10_DDL_NAME_IND,ALERT_ITEM11_DDL_NAME, ALERT_ITEM11_SUM_IND, ALERT_ITEM11_DDL_NAME_IND,ALERT_ITEM12_DDL_NAME, " + 
	"ALERT_ITEM12_SUM_IND,ALERT_ITEM12_DDL_NAME_IND,ALERT_ITEM13_DDL_NAME, ALERT_ITEM13_SUM_IND, ALERT_ITEM13_DDL_NAME_IND, " + 
	"ALERT_ITEM14_DDL_NAME, ALERT_ITEM14_SUM_IND, ALERT_ITEM14_DDL_NAME_IND,ALERT_ITEM15_DDL_NAME, ALERT_ITEM15_SUM_IND, " + 
	"ALERT_ITEM15_DDL_NAME_IND, VIEW_NAME, ALERT_ITEM_ORD) VALUES(''{0}'', ''{1}'', NULL, ''{2}'', ''{3}'', ''{4}'', NULL, " +
	"''{5}'', ''{6}'', ''{7}'', ''{8}'', ''{9}'', ''{10}'', ''{11}'', ''{12}'', ''{13}'', ''{14}'', ''{15}'', ''{16}'', " +
	"''{17}'', ''{18}'', ''{19}'', ''{20}'', ''{21}'', ''{22}'', ''{23}'', ''{24}'', ''{25}'', ''{26}'', ''{27}'', " +
	"''{28}'', ''{29}'', ''{30}'', ''{31}'', ''{32}'', ''{33}'', ''{34}'', ''{35}'', ''{36}'', ''{37}'', ''{38}'', " +
	"''{39}'', ''{40}'', ''{41}'', ''{42}'', ''{43}'',''{44}'',''{45}'',''{46}'',''{47}'',''{48}'',''{49}'',''{50}'',''{51}''," + 
	"''{52}'',''{53}'',''{54}'',''{55}'',''{56}'',''{57}'',''{58}'')";
	
	protected static final String INS_RABC_TRACK_FILE_DTL_Trend = "INSERT INTO RABC_TRACK_FILE_DTL (ALERT_RULE, FILE_ID, " +
	"ALERT_ITEM_NAME, ALERT_DATE_IND, ALERT_ITEM_EXTRCT_TBL, PARTI_REF_ID, ALERT_ITEM_KEY_LVL, ALERT_ITEM_KEY1_NAME, " +
	"ALERT_ITEM_KEY2_NAME, ALERT_ITEM_KEY3_NAME, ALERT_ITEM_KEY4_NAME, ALERT_ITEM_KEY5_NAME, ALERT_ITEM_DATA_CT, " +
	"ALERT_ITEM1_DDL_NAME, ALERT_ITEM1_SUM_IND, ALERT_ITEM1_DDL_NAME_IND, ALERT_ITEM2_DDL_NAME, ALERT_ITEM2_SUM_IND," + 
	"ALERT_ITEM2_DDL_NAME_IND,ALERT_ITEM3_DDL_NAME, ALERT_ITEM3_SUM_IND, ALERT_ITEM3_DDL_NAME_IND,ALERT_ITEM4_DDL_NAME," + 
	"ALERT_ITEM4_SUM_IND, ALERT_ITEM4_DDL_NAME_IND,ALERT_ITEM5_DDL_NAME, ALERT_ITEM5_SUM_IND, ALERT_ITEM5_DDL_NAME_IND," +
	"ALERT_ITEM6_DDL_NAME, ALERT_ITEM6_SUM_IND, ALERT_ITEM6_DDL_NAME_IND,ALERT_ITEM7_DDL_NAME, ALERT_ITEM7_SUM_IND, " + 
	"ALERT_ITEM7_DDL_NAME_IND,ALERT_ITEM8_DDL_NAME,ALERT_ITEM8_SUM_IND, ALERT_ITEM8_DDL_NAME_IND,ALERT_ITEM9_DDL_NAME, " + 
	"ALERT_ITEM9_SUM_IND, ALERT_ITEM9_DDL_NAME_IND,ALERT_ITEM10_DDL_NAME, ALERT_ITEM10_SUM_IND, ALERT_ITEM10_DDL_NAME_IND," +
	"ALERT_ITEM11_DDL_NAME, ALERT_ITEM11_SUM_IND,ALERT_ITEM11_DDL_NAME_IND, ALERT_ITEM12_DDL_NAME, ALERT_ITEM12_SUM_IND," + 
	"ALERT_ITEM12_DDL_NAME_IND,ALERT_ITEM13_DDL_NAME,ALERT_ITEM13_SUM_IND, ALERT_ITEM13_DDL_NAME_IND,ALERT_ITEM14_DDL_NAME," + 
	"ALERT_ITEM14_SUM_IND,ALERT_ITEM14_DDL_NAME_IND, ALERT_ITEM15_DDL_NAME, ALERT_ITEM15_SUM_IND, ALERT_ITEM15_DDL_NAME_IND," +
	"VIEW_NAME, ALERT_ITEM_ORD) VALUES (''{0}'', ''{1}'', NULL, ''Y'', ''{2}'', NULL,	''{3}'', ''{4}'', ''{5}'', " +
	"''{6}'', ''{7}'',''{8}'', ''{9}'', ''{10}'', ''{11}'', ''{12}'', ''{13}'', ''{14}'', ''{15}'', ''{16}'', " +
	"''{17}'', ''{18}'', ''{19}'', ''{20}'', ''{21}'', ''{22}'', ''{23}'', ''{24}'', ''{25}'', ''{26}'', ''{27}'', " +
	"''{28}'', ''{29}'', ''{30}'', ''{31}'', ''{32}'', ''{33}'', ''{34}'', ''{35}'', ''{36}'', ''{37}'', ''{38}'', ''{39}'', " +
	"''{40}'', ''{41}'', ''{42}'', ''{43}'',''{44}'',''{45}'',''{46}'',''{47}'',''{48}'',''{49}'',''{50}'',''{51}''," + 
	"''{52}'',''{53}'',''{54}'',''{55}'',''{56}'')";
	
	protected static final String INS_RABC_TRIG_CONVERT_Track = "INSERT INTO RABC_TRIG_CONVERT (FILE_ID, ALERT_RULE, " +
	"PROC_PGM, RUN_CHK_DAY, RUN_CHK_HR, RUN_FREQ_IND) VALUES (''{0}'', ''{1}'',''RABC_BKG_CNTRL_RULE_DRIVER.JAVA''," +
	"''{3}'', ''0'', ''{2}'')";

	protected static final String INS_RABC_TRIG_CONVERT_Trend = "INSERT INTO RABC_TRIG_CONVERT (FILE_ID, ALERT_RULE, " +
	"PROC_PGM, RUN_CHK_DAY, RUN_CHK_HR, RUN_FREQ_IND) VALUES (''{0}'', ''{1}'', ''RABC_BKG_CNTRL_RULE_DRIVER.JAVA'', " +
	"''{3}'', ''0'', ''{2}'')";
	
	protected static final String INS_RABC_EXTRCT_BUILD_RULE_Track = "INSERT INTO RABC_EXTRCT_BUILD_RULE (PARTI_REF_ID," +
	"EXTRCT_TYPE,EXTRCT_RNDUP_IND,EXTRCT_ITEM_NAME,EXTRCT_TO_TBL,EXTRCT_ITEM1_NAME, EXTRCT_ITEM1_CALC_IND, " +
	"FILE_ITEM1_NAME,EXTRCT_ITEM2_NAME, EXTRCT_ITEM2_CALC_IND, FILE_ITEM2_NAME, EXTRCT_ITEM3_NAME, EXTRCT_ITEM3_CALC_IND, " +
	"FILE_ITEM3_NAME,EXTRCT_ITEM4_NAME, EXTRCT_ITEM4_CALC_IND, FILE_ITEM4_NAME, EXTRCT_ITEM5_NAME, EXTRCT_ITEM5_CALC_IND, " +
	"FILE_ITEM5_NAME, EXTRCT_ITEM6_NAME, EXTRCT_ITEM6_CALC_IND, FILE_ITEM6_NAME, EXTRCT_ITEM7_NAME, EXTRCT_ITEM7_CALC_IND, " +
	"FILE_ITEM7_NAME, EXTRCT_ITEM8_NAME, EXTRCT_ITEM8_CALC_IND, FILE_ITEM8_NAME, EXTRCT_ITEM9_NAME, EXTRCT_ITEM9_CALC_IND, " +
	"FILE_ITEM9_NAME)VALUES (''{0}'', ''{1}'', NULL, ''{2}'', ''RABC_EXTRCT_SUMY_DATA'', ''{3}'', ''{4}'', ''{5}'', ''{6}'', " +
	"''{7}'', ''{8}'', ''{9}'', ''{10}'', ''{11}'', ''{12}'', ''{13}'', ''{14}'', ''{15}'', ''{16}'', ''{17}'', ''{18}'', " +
	"''{19}'', ''{20}'', ''{21}'', ''{22}'', ''{23}'', ''{24}'', ''{25}'', ''{26}'', ''{27}'', ''{28}'', ''{29}'') ";

	protected static final String INS_RABC_EXTRCT_BUILD_RULE_Trend = "INSERT INTO RABC_EXTRCT_BUILD_RULE (PARTI_REF_ID, " +
	"EXTRCT_TYPE, EXTRCT_RNDUP_IND, EXTRCT_TO_TBL) VALUES (''{0}'', ''{1}'', NULL, ''RABC_EXTRCT_SUMY_DATA'')";
	
	protected static final String INS_RABC_AVG_TBL_DEF_Track = "INSERT INTO RABC_AVG_TBL_DEF (PARTI_REF_ID, AVG_KEY_LVL, " +
	"KEY1_NAME, KEY2_NAME, KEY3_NAME, KEY4_NAME, KEY5_NAME, AVG_ITEM_NAME, AVG_DATA_CT, AVG_DATA1_NAME, AVG_DATA2_NAME, " +
	"AVG_DATA3_NAME, AVG_DATA4_NAME, AVG_DATA5_NAME, AVG_DATA6_NAME, AVG_DATA7_NAME, AVG_DATA8_NAME, AVG_DATA9_NAME, " +
	"AVG_DATA10_NAME, AVG_DATA11_NAME, AVG_DATA12_NAME, AVG_DATA13_NAME, AVG_DATA14_NAME, AVG_DATA15_NAME)VALUES " +
	"(''{0}'', ''{1}'', ''{2}'', ''{3}'', ''{4}'', ''{5}'', ''{6}'', ''{7}'', ''{8}'', ''{9}'', ''{10}'', ''{11}'', " +
	"''{12}'', ''{13}'', ''{14}'', ''{15}'', ''{16}'', ''{17}'', ''{18}'', ''{19}'', ''{20}'', ''{21}'', ''{22}'', ''{23}'')";

	protected static final String INS_RABC_EXTRCT_TBL_DEF_Track = "INSERT INTO RABC_EXTRCT_TBL_DEF(PARTI_REF_ID," +
	"EXTRCT_KEY_LVL, KEY1_NAME, KEY2_NAME, KEY3_NAME, KEY4_NAME, KEY5_NAME, EXTRCT_ITEM_NAME, EXTRCT_DATA_CT, " +
	"EXTRCT_DATA_LEFT_CT, EXTRCT_DATA_RIGHT_CT, EXTRCT_DATA1_NAME, EXTRCT_DATA2_NAME, EXTRCT_DATA3_NAME, " +
	"EXTRCT_DATA4_NAME, EXTRCT_DATA5_NAME, EXTRCT_DATA6_NAME,EXTRCT_DATA7_NAME, EXTRCT_DATA8_NAME, EXTRCT_DATA9_NAME, " +
	"EXTRCT_DATA10_NAME, EXTRCT_DATA11_NAME, EXTRCT_DATA12_NAME, EXTRCT_DATA13_NAME, EXTRCT_DATA14_NAME, " +
	"EXTRCT_DATA15_NAME) VALUES(''{0}'', ''{1}'',''{2}'', ''{3}'', ''{4}'', ''{5}'', ''{6}'', ''{7}'', ''{8}'', " +
	"''{9}'', ''{10}'', ''{11}'', ''{12}'', ''{13}'', ''{14}'', ''{15}'', ''{16}'', ''{17}'', ''{18}'', ''{19}'', " +
	"''{20}'', ''{21}'', ''{22}'', ''{23}'', ''{24}'', ''{25}'')";
	
	protected static final String INS_RABC_EXTRCT_TBL_DEF_Trend = "INSERT INTO RABC_EXTRCT_TBL_DEF (PARTI_REF_ID, " +
	"EXTRCT_KEY_LVL, KEY1_NAME, KEY2_NAME, KEY3_NAME, KEY4_NAME, KEY5_NAME, EXTRCT_ITEM_NAME, EXTRCT_DATA_CT, " +
	"EXTRCT_DATA_LEFT_CT, EXTRCT_DATA_RIGHT_CT, EXTRCT_DATA1_NAME, EXTRCT_DATA2_NAME, EXTRCT_DATA3_NAME, EXTRCT_DATA4_NAME, " +
	"EXTRCT_DATA5_NAME, EXTRCT_DATA6_NAME, EXTRCT_DATA7_NAME, EXTRCT_DATA8_NAME, EXTRCT_DATA9_NAME, EXTRCT_DATA10_NAME, " +
	"EXTRCT_DATA11_NAME, EXTRCT_DATA12_NAME, EXTRCT_DATA13_NAME, EXTRCT_DATA14_NAME, EXTRCT_DATA15_NAME) VALUES " +
	"(''{0}'', ''{1}'', ''{2}'', ''{3}'', ''{4}'', ''{5}'', ''{6}'', NULL, ''{7}'', ''0'', ''0'', ''{8}'', ''{9}'', " +
	"''{10}'', ''{11}'', ''{12}'', ''{13}'', ''{14}'', ''{15}'', ''{16}'', ''{17}'', ''{18}'', ''{19}'', ''{20}'', " +
	"''{21}'', ''{22}'')";
	
	protected static final String INS_RABC_UPDATE_GRP_Track = "INSERT INTO RABC_UPDATE_GRP (ALERT_RULE, " +
	"ALERT_GRP) VALUES (''{0}'', ''{1}'')";
	
	protected static final String INS_RABC_UPDATE_GRP_Trend = "INSERT INTO RABC_UPDATE_GRP (ALERT_RULE, " +
	"ALERT_GRP) VALUES (''{0}'', ''{1}'')";
	
	protected static final String INS_RABC_ALERT_PROC_Track = "INSERT INTO RABC_ALERT_PROC (ALERT_RULE, ALERT_TYPE," +
	"ALERT_ITEM_DDL_NAME, ALERT_ITEM_DDL_DATA, ALERT_ITEM_AVG_NAME, ALERT_PROC_TBL, ALERT_PROC_AVG_TBL, ALERT_CREATE_IND, " +
	"ALERT_MSG_SUPP_DATA_IND, ALERT_THRSHLD_DFLT_IND, ALERT_CALC_NUM, ALERT_TBL_SEL_NUM, PARTI_REF_ID) VALUES(''{0}'', " +
	"''{1}'', ''{2}'', ''{3}'', ''{4}'', ''{5}'', ''{6}'', ''{7}'', ''{8}'', ''N'', ''{9}'', ''{10}'', ''{11}'')"; 
	
	protected static final String INS_RABC_ALERT_PROC_Trend = "INSERT INTO RABC_ALERT_PROC (ALERT_RULE, ALERT_TYPE, " +
	"ALERT_ITEM_DDL_NAME, ALERT_ITEM_DDL_DATA, ALERT_ITEM_AVG_NAME, ALERT_PROC_TBL, ALERT_PROC_AVG_TBL, " +
	"ALERT_CREATE_IND, ALERT_MSG_SUPP_DATA_IND, ALERT_THRSHLD_DFLT_IND, ALERT_CALC_NUM, ALERT_TBL_SEL_NUM, " +
	"PARTI_REF_ID) VALUES (''{0}'', ''{1}'', ''{2}'', ''{3}'', ''{4}'', ''{5}'', ''{6}'', ''{7}'', ''N'', ''N'', " +
	"''{8}'', ''{9}'', ''{10}'')";
	
	protected static final String INS_RABC_AVG_CALC_Track = "INSERT INTO RABC_AVG_CALC (ALERT_RULE, PARTI_REF_ID, " +
	"AVG_NUM_DATE, AVG_NUM_REC, AVG_TREND_TIME_IND, AVG_TBL_NAME, AVG_TYPE) VALUES (''{0}'',''{1}'', {2}, " +
	"{3}, ''{4}'', ''RABC_CALC_ALERT_DATA'', ''{5}'')";  
	
	protected static final String INS_RABC_AVG_CALC_Trend =  "INSERT INTO RABC_AVG_CALC (ALERT_RULE, PARTI_REF_ID, " +
	"AVG_NUM_DATE, AVG_NUM_REC, AVG_TREND_TIME_IND, AVG_TBL_NAME, AVG_TYPE) VALUES (''{0}'', ''{1}'', {2}, " +
	"{3}, ''{4}'', ''RABC_EXTRCT_SUMY_DATA'', ''{5}'')";
	
	protected static final String INS_RABC_CNTRL_PT_ALERT_Track = "INSERT INTO RABC_CNTRL_PT_ALERT (CNTRL_PT_CD, " +
	"ALERT_RULE, PRESN_SEQ_NUM) VALUES (''{0}'', ''{1}'', ''{2}'')";	

	protected static final String INS_RABC_CNTRL_PT_ALERT_Trend = "INSERT INTO RABC_CNTRL_PT_ALERT (CNTRL_PT_CD, " +
	"ALERT_RULE, PRESN_SEQ_NUM) VALUES (''{0}'', ''{1}'', ''{2}'')";
	
	protected static final String INS_RABC_PROC_RESPONSIBLE1_Track="INSERT INTO RABC_PROC_RESPONSIBLE (ALERT_RULE, " +
	"ROLE_CD, ALERT_GRP) VALUES(''{0}'',1,''BAC RABC SYS SUPPORT'')";
	
	protected static final String INS_RABC_PROC_RESPONSIBLE2_Track="INSERT INTO RABC_PROC_RESPONSIBLE(ALERT_RULE, " +
	"ROLE_CD, ALERT_GRP)VALUES (''{0}'',2,''{1}'')";
	
	protected static final String INS_RABC_PROC_RESPONSIBLE1_Trend ="INSERT INTO RABC_PROC_RESPONSIBLE (ALERT_RULE, " +
	"ROLE_CD, ALERT_GRP) VALUES (''{0}'', ''1'', ''BAC RABC SYS SUPPORT'')";
	
	protected static final String INS_RABC_PROC_RESPONSIBLE2_Trend ="INSERT INTO RABC_PROC_RESPONSIBLE (ALERT_RULE, " +
	"ROLE_CD, ALERT_GRP) VALUES (''{0}'', ''2'',''{1}'')";
	
	protected static final String INS_RABC_ALERT_RULE_PRESN_ELEM_0_Track = "INSERT INTO RABC_ALERT_RULE_PRESN_ELEM " +
	"(PRESN_ID, WEBID, EXEC_PRESN_SEQ_NUM, PRESN_SEQ_NUM, PRESN_NAME, DATA_TBL, PARTI_REF_ID, DATA_DDL_NAME, " +
	"HEADER_LINK_IND, HEADER_LINK_NUM, HEADER_DESC_IND, HEADER_MOUSE_OVER_NUM, DATA_LINK_IND, " +
	"DATA_LINK_NUM, DATA_DESC_IND, DATA_MOUSE_OVER_NUM, GRAPH_PRESN_IND, PRESN_ELEM_TOT_IND, PRESN_UNIT_IND, " +
	"PRESN_SUM_IND, DATABASE_NODE, PRESN_CALC_NUM, PRESN_SUPPRESS_IND, PREV_DATA_IND, VIEW_NAME, " +
	"PRESN_ORD_IND, PRESN_FORMAT_CODE, DIFF_DATA_IND )VALUES (''{0}'', ''{1}'', ''1'', ''{2}'', ''{5}'', " +
	"''RABC_EXTRCT_SUMY_DATA'', ''{3}'',''ALERT_TREND_TIME'', NULL, NULL, NULL, NULL, ''N'', NULL, NULL, " +
	"NULL, ''N'', NULL, NULL, ''N'', NULL, NULL, NULL, NULL, ''RABC_EXTRCT_SUMY_DATA'', NULL, ''{4}'', NULL)"; 
	
	protected static final String INS_RABC_ALERT_RULE_PRESN_ELEM_1_Track = "INSERT INTO RABC_ALERT_RULE_PRESN_ELEM " +
	"(PRESN_ID, WEBID, EXEC_PRESN_SEQ_NUM, PRESN_SEQ_NUM, PRESN_NAME, DATA_TBL, PARTI_REF_ID, DATA_DDL_NAME, " +
	"HEADER_LINK_IND, HEADER_LINK_NUM, HEADER_DESC_IND, HEADER_MOUSE_OVER_NUM, DATA_LINK_IND, " +
	"DATA_LINK_NUM, DATA_DESC_IND, DATA_MOUSE_OVER_NUM, GRAPH_PRESN_IND, PRESN_ELEM_TOT_IND, PRESN_UNIT_IND, " +
	"PRESN_SUM_IND, DATABASE_NODE, PRESN_CALC_NUM, PRESN_SUPPRESS_IND, PREV_DATA_IND, VIEW_NAME, " +
	"PRESN_ORD_IND, PRESN_FORMAT_CODE, DIFF_DATA_IND )VALUES (''{0}'', ''{1}'', ''1'', ''{2}'', ''ALERT ITEM'', " +
	"''RABC_EXTRCT_SUMY_DATA'', ''{3}'',''EXTRCT_ITEM'', NULL, NULL, NULL, NULL, ''N'', NULL, NULL, " +
	"NULL, ''N'', NULL, NULL, ''N'', NULL, NULL, NULL, NULL, ''RABC_EXTRCT_SUMY_DATA'', NULL, ''{4}'', NULL)"; 
	
	protected static final String INS_RABC_ALERT_RULE_PRESN_ELEM_2_Track = "INSERT INTO RABC_ALERT_RULE_PRESN_ELEM " +
	"(PRESN_ID,WEBID,EXEC_PRESN_SEQ_NUM, PRESN_SEQ_NUM, PRESN_NAME, DATA_TBL, PARTI_REF_ID, DATA_DDL_NAME, " +
	"HEADER_LINK_IND, HEADER_LINK_NUM, HEADER_DESC_IND, HEADER_MOUSE_OVER_NUM, DATA_LINK_IND, " +
	"DATA_LINK_NUM,DATA_DESC_IND, DATA_MOUSE_OVER_NUM, GRAPH_PRESN_IND, PRESN_ELEM_TOT_IND, PRESN_UNIT_IND, " +
	"PRESN_SUM_IND,DATABASE_NODE, PRESN_CALC_NUM, PRESN_SUPPRESS_IND, PREV_DATA_IND, VIEW_NAME, " +
	"PRESN_ORD_IND, PRESN_FORMAT_CODE, DIFF_DATA_IND) VALUES (''{0}'', ''{1}'', ''1'', ''{2}'', ''LTOTAL'', " +
	"''RABC_EXTRCT_SUMY_DATA'', ''{3}'', ''{4}'', NULL, NULL, NULL, NULL,''{5}'', ''{6}'', " +
	"NULL, NULL, ''Y'', NULL, NULL, NULL, NULL, NULL, NULL, NULL, ''RABC_EXTRCT_SUMY_DATA''," +
	"NULL, ''{7}'', NULL)";   
	
	protected static final String INS_RABC_ALERT_RULE_PRESN_ELEM_3_Track = "INSERT INTO RABC_ALERT_RULE_PRESN_ELEM " +
	"(PRESN_ID,WEBID,EXEC_PRESN_SEQ_NUM,PRESN_SEQ_NUM, PRESN_NAME, DATA_TBL, PARTI_REF_ID, " +
	"DATA_DDL_NAME, HEADER_LINK_IND, HEADER_LINK_NUM, HEADER_DESC_IND, HEADER_MOUSE_OVER_NUM, " +
	"DATA_LINK_IND, DATA_LINK_NUM, DATA_DESC_IND, DATA_MOUSE_OVER_NUM, GRAPH_PRESN_IND, PRESN_ELEM_TOT_IND," +
	"PRESN_UNIT_IND, PRESN_SUM_IND, DATABASE_NODE, PRESN_CALC_NUM, PRESN_SUPPRESS_IND, PREV_DATA_IND, " +
	"VIEW_NAME, PRESN_ORD_IND ,PRESN_FORMAT_CODE, DIFF_DATA_IND) VALUES(''{0}'', ''{1}'', ''1'', ''{2}'', ''Right Side Result'', " +
	"''RABC_EXTRCT_SUMY_DATA'', ''{3}'', ''{4}'', NULL, NULL, NULL, NULL, ''N'', NULL, NULL, " +
	"NULL, ''Y'', NULL, NULL, NULL, NULL, NULL, NULL, NULL, ''RABC_EXTRCT_SUMY_DATA'', NULL, ''{5}'', NULL)";
	
	protected static final String INS_RABC_ALERT_RULE_PRESN_ELEM_4_Track = "INSERT INTO RABC_ALERT_RULE_PRESN_ELEM " +
	"(PRESN_ID,WEBID,EXEC_PRESN_SEQ_NUM,PRESN_SEQ_NUM,PRESN_NAME,DATA_TBL,PARTI_REF_ID,DATA_DDL_NAME," +
	"HEADER_LINK_IND,HEADER_LINK_NUM,HEADER_DESC_IND,HEADER_MOUSE_OVER_NUM,DATA_LINK_IND,DATA_LINK_NUM," +
	"DATA_DESC_IND,DATA_MOUSE_OVER_NUM,GRAPH_PRESN_IND, PRESN_ELEM_TOT_IND, PRESN_UNIT_IND,PRESN_SUM_IND," +
	"DATABASE_NODE,PRESN_CALC_NUM,PRESN_SUPPRESS_IND,PREV_DATA_IND,VIEW_NAME, PRESN_ORD_IND, " +
	"PRESN_FORMAT_CODE, DIFF_DATA_IND) VALUES(''{0}'',''{1}'',''1'',''{2}'',''{3}'',''RABC_EXTRCT_SUMY_DATA'' ," +
	"''{4}'',''{5}'',NULL,NULL,NULL,NULL,''{6}'',''{7}'', NULL,NULL,''Y'', NULL, NULL," +
	"NULL, NULL, NULL, NULL, NULL, ''RABC_EXTRCT_SUMY_DATA'', NULL, ''{8}'', NULL)";
	
	protected static final String INS_RABC_ALERT_RULE_PRESN_ELEM_5_Track = "INSERT INTO RABC_ALERT_RULE_PRESN_ELEM " +
	"(PRESN_ID, WEBID,EXEC_PRESN_SEQ_NUM,PRESN_SEQ_NUM, PRESN_NAME, DATA_TBL, PARTI_REF_ID, DATA_DDL_NAME, " +
	"HEADER_LINK_IND, HEADER_LINK_NUM, HEADER_DESC_IND, HEADER_MOUSE_OVER_NUM, DATA_LINK_IND, DATA_LINK_NUM, " +
	"DATA_DESC_IND, DATA_MOUSE_OVER_NUM, GRAPH_PRESN_IND, PRESN_ELEM_TOT_IND, PRESN_UNIT_IND, PRESN_SUM_IND," +
	"DATABASE_NODE, PRESN_CALC_NUM,PRESN_SUPPRESS_IND, PREV_DATA_IND,VIEW_NAME,PRESN_ORD_IND, " +
	"PRESN_FORMAT_CODE, DIFF_DATA_IND) VALUES (''{0}'', ''RABCPSF00013'',''1'',''{1}'', ''ALERT DATA'', ''RABC_CALC_ALERT_DATA'', " +
	"''{2}'',''ALERT_DATA'',NULL, NULL, NULL, NULL,''{3}'', ''{4}'', NULL, NULL, ''Y'', NULL, ''P'', ''N'', NULL, " +
	"NULL, NULL, NULL, ''RABC_CALC_ALERT_DATA'', NULL ,''{5}'', NULL)";   
	
	protected static final String INS_RABC_ALERT_RULE_PRESN_ELEM_Trend = "INSERT INTO RABC_ALERT_RULE_PRESN_ELEM (PRESN_ID, " +
	"WEBID, EXEC_PRESN_SEQ_NUM, PRESN_SEQ_NUM, PRESN_NAME, DATA_TBL, PARTI_REF_ID, DATA_DDL_NAME, HEADER_LINK_IND, " +
	"HEADER_LINK_NUM, HEADER_DESC_IND, HEADER_MOUSE_OVER_NUM, DATA_LINK_IND, DATA_LINK_NUM, DATA_DESC_IND, " +
	"DATA_MOUSE_OVER_NUM, GRAPH_PRESN_IND, PRESN_ELEM_TOT_IND, PRESN_UNIT_IND, PRESN_SUM_IND, DATABASE_NODE, " +
	"PRESN_CALC_NUM, PRESN_SUPPRESS_IND, PREV_DATA_IND, VIEW_NAME, PRESN_ORD_IND,  PRESN_FORMAT_CODE, DIFF_DATA_IND ) " +
	"VALUES(''{0}'', ''RABCPSF00013'', ''1'', ''{1}'', ''{2}'', ''RABC_EXTRCT_SUMY_DATA'', ''{3}'', ''{4}'', NULL, NULL, " +
	"NULL, NULL, ''{8}'', ''{9}'', NULL, NULL, ''{7}'', NULL, ''{10}'', ''{6}'', NULL, NULL, NULL, NULL, ''RABC_EXTRCT_SUMY_DATA'', " +
	"NULL, ''{5}'', NULL)";
	
	protected static final String INS_RABC_ALERT_RULE_PRESN_RULE_1_Track = "INSERT INTO RABC_ALERT_RULE_PRESN_RULE " +
	"(PRESN_ID, WEBID, EXEC_PRESN_SEQ_NUM, FILE_SEQ_NUM_IND, PRESN_DATA_TBL, DATA_KEY_LVL, MAIN_KEY1_IND, " +
	"KEY1_DDL_NAME, KEY1_HEADER,KEY1_MOUSE_OVER_NUM, KEY2_DDL_NAME, KEY2_HEADER, KEY2_MOUSE_OVER_NUM, " +
	"KEY3_DDL_NAME, KEY3_HEADER,KEY3_MOUSE_OVER_NUM, KEY4_DDL_NAME, KEY4_HEADER, KEY4_MOUSE_OVER_NUM, " +
	"KEY5_DDL_NAME, KEY5_HEADER,KEY5_MOUSE_OVER_NUM, KEY1_DESC_IND)VALUES(''{0}'',''{1}'', ''1'',''{2}'',''RABC_EXTRCT_SUMY_DATA'', " +
	"''{3}'', NULL, ''{4}'', ''{5}'',''{6}'', ''{7}'', ''{8}'', ''{9}'', ''{10}'', ''{11}'', ''{12}'', ''{13}'', " +
	"''{14}'',''{15}'', ''{16}'',''{17}'', ''{18}'', ''{19}'')";
	
	protected static final String INS_RABC_ALERT_RULE_PRESN_RULE_2_Track = "INSERT INTO RABC_ALERT_RULE_PRESN_RULE " +
	"(PRESN_ID, WEBID, EXEC_PRESN_SEQ_NUM, FILE_SEQ_NUM_IND, PRESN_DATA_TBL, DATA_KEY_LVL, MAIN_KEY1_IND, " +
	"KEY1_DDL_NAME,KEY1_HEADER, KEY1_DATA_LINK_IND, KEY1_DATA_LINK_NUM,KEY1_MOUSE_OVER_NUM ,KEY2_DDL_NAME, " +
	"KEY2_HEADER, KEY2_DATA_LINK_IND, KEY2_DATA_LINK_NUM,KEY2_MOUSE_OVER_NUM ,KEY2_DESC_IND, KEY3_DDL_NAME,KEY3_HEADER, " +
	"KEY3_DATA_LINK_IND, KEY3_DATA_LINK_NUM,KEY3_MOUSE_OVER_NUM , KEY3_DESC_IND,KEY4_DDL_NAME,KEY4_HEADER, KEY4_DATA_LINK_IND, " +
	"KEY4_DATA_LINK_NUM,KEY4_MOUSE_OVER_NUM , KEY4_DESC_IND, KEY5_DDL_NAME,KEY5_HEADER, KEY5_DATA_LINK_IND, KEY5_DATA_LINK_NUM, " +
	"KEY5_MOUSE_OVER_NUM, KEY5_DESC_IND,KEY1_DESC_IND) VALUES(''{0}'',''{1}'', ''1'',''{2}'',''RABC_EXTRCT_SUMY_DATA'', ''{3}'', ''1'', ''{4}'', " +
	"''{5}'',''{6}'', ''{7}'', ''{8}'', ''{9}'', ''{10}'',''{11}'', ''{12}'', ''{13}'', ''{14}'',''{15}'', ''{16}'', " +
	"''{17}'', ''{18}'', ''{19}'', ''{20}'', ''{21}'', ''{22}'', ''{23}'', ''{24}'', ''{25}'', ''{26}'', ''{27}'', " +
	"''{28}'', ''{29}'',''{30}'',''{31}'',''{32}'',''{33}'')";
	
	protected static final String INS_RABC_ALERT_RULE_PRESN_RULE_3_Track = "INSERT INTO RABC_ALERT_RULE_PRESN_RULE " +
	"(PRESN_ID, WEBID, EXEC_PRESN_SEQ_NUM, FILE_SEQ_NUM_IND, PRESN_DATA_TBL, DATA_KEY_LVL, MAIN_KEY1_IND, " +
	"KEY1_DDL_NAME, KEY1_HEADER, KEY1_DATA_LINK_IND, KEY1_DATA_LINK_NUM,KEY1_MOUSE_OVER_NUM, KEY2_DDL_NAME,KEY2_HEADER, " + 
	"KEY2_DATA_LINK_IND, KEY2_DATA_LINK_NUM,KEY2_MOUSE_OVER_NUM,KEY2_DESC_IND, KEY3_DDL_NAME, KEY3_HEADER,KEY3_DATA_LINK_IND, KEY3_DATA_LINK_NUM, " + 
	"KEY3_MOUSE_OVER_NUM,KEY3_DESC_IND, KEY4_DDL_NAME, KEY4_HEADER, KEY4_DATA_LINK_IND,KEY4_DATA_LINK_NUM,KEY4_MOUSE_OVER_NUM,KEY4_DESC_IND, KEY5_DDL_NAME, " + 
	"KEY5_HEADER, KEY5_DATA_LINK_IND, KEY5_DATA_LINK_NUM,KEY5_MOUSE_OVER_NUM,KEY5_DESC_IND, KEY1_DESC_IND) VALUES(''{0}'', ''RABCPSF00013'', ''1''," + 
	" ''{1}'', ''RABC_CALC_ALERT_DATA'', ''{2}'', ''1'', ''{3}'', ''{4}'', ''{5}'', ''{6}'', ''{7}'', ''{8}'', ''{9}'', ''{10}'', ''{11}'',''{12}''," + 
	"''{13}'', ''{14}'', ''{15}'', ''{16}'', ''{17}'', ''{18}'', ''{19}'',''{20}'',''{21}'',''{22}'',''{23}'', ''{24}'',''{25}'',''{26}'',''{27}'',''{28}'',''{29}'',''{30}'',''{31}'',''{32}'')";
	
	protected static final String INS_RABC_ALERT_RULE_PRESN_RULE_Trend = " INSERT INTO RABC_ALERT_RULE_PRESN_RULE " +
	"(PRESN_ID, WEBID, EXEC_PRESN_SEQ_NUM, FILE_SEQ_NUM_IND, PRESN_DATA_TBL, DATA_KEY_LVL, MAIN_KEY1_IND, KEY1_DDL_NAME, " +
	"KEY1_HEADER, KEY1_MOUSE_OVER_NUM, KEY1_DATA_LINK_IND, KEY1_DATA_LINK_NUM,KEY2_DDL_NAME, KEY2_HEADER, KEY2_MOUSE_OVER_NUM, " +
	"KEY2_DATA_LINK_IND, KEY2_DATA_LINK_NUM, KEY3_DDL_NAME, KEY3_HEADER,KEY3_MOUSE_OVER_NUM,KEY3_DATA_LINK_IND, KEY3_DATA_LINK_NUM," + 
	"KEY4_DDL_NAME, KEY4_HEADER, KEY4_MOUSE_OVER_NUM, KEY4_DATA_LINK_IND, KEY4_DATA_LINK_NUM,KEY5_DDL_NAME, KEY5_HEADER, " +
	"KEY5_MOUSE_OVER_NUM,KEY5_DATA_LINK_IND, KEY5_DATA_LINK_NUM, KEY1_DESC_IND,KEY2_DESC_IND,KEY3_DESC_IND,KEY4_DESC_IND,KEY5_DESC_IND) " + 
	" VALUES(''{0}'', ''{1}'', ''1'', ''{2}'', ''RABC_EXTRCT_SUMY_DATA'', ''{29}'', ''1'', ''{3}'', ''{4}'', ''{5}'', ''{6}'', ''{7}'', " + 
	"''{8}'', ''{9}'', ''{10}'', ''{11}'', ''{12}'', ''{13}'', ''{14}'',''{15}'', ''{16}'', ''{17}'', ''{18}'',''{19}'',''{20}'',''{21}''," +
	"''{22}'',''{23}'',''{24}'',''{25}'',''{26}'',''{27}'',''{28}'',''{30}'',''{31}'',''{32}'',''{33}'')";
			
	protected static final String INS_RABC_MENU_INDEX1_Track = "INSERT INTO RABC_MENU_INDEX(PRESN_TYPE, PRESN_NAME, " +
	"PRESN_LVL, PRESN_SEQ_NUM, ASSOC_PARENT_ID, SUB_ASSOC_PARENT_ID, PRESN_ID, ALERT_RULE) VALUES (''A'', ''{0}'', " +
	"''2'', ''{1}'', ''{2}'', ''{3}'', ''{4}'', ''{5}'')";
	
	protected static final String INS_RABC_MENU_INDEX2_Track = "INSERT INTO RABC_MENU_INDEX(PRESN_TYPE, PRESN_NAME, " +
	"PRESN_LVL, PRESN_SEQ_NUM, ASSOC_PARENT_ID, SUB_ASSOC_PARENT_ID, PRESN_ID, ALERT_RULE) VALUES (''A'', ''{0}'', " +
	"''3'', ''{1}'', ''{2}'', ''{3}'', ''{4}'', ''{5}'')";
	
	protected static final String INS_RABC_MENU_INDEX3_Track = "INSERT INTO RABC_MENU_INDEX(PRESN_TYPE, PRESN_NAME, " +
	"PRESN_LVL, PRESN_SEQ_NUM, ASSOC_PARENT_ID, SUB_ASSOC_PARENT_ID, PRESN_ID, ALERT_RULE) VALUES (''P'', ''{0}'', " +
	"''3'', ''{1}'', ''{2}'', ''1'', ''{3}'', ''{4}'')";
	
	protected static final String INS_RABC_MENU_INDEX1_Trend = "INSERT INTO RABC_MENU_INDEX (PRESN_TYPE, PRESN_NAME, " +
	"PRESN_LVL, PRESN_SEQ_NUM, ASSOC_PARENT_ID, SUB_ASSOC_PARENT_ID, PRESN_ID, ALERT_RULE) VALUES (''A'', " +
	"''{0}'', ''2'', ''{1}'', ''{2}'', ''{3}'', ''{4}'', ''{5}'')";
	
	protected static final String INS_RABC_MENU_INDEX2_Trend = "INSERT INTO RABC_MENU_INDEX (PRESN_TYPE, PRESN_NAME, " +
	"PRESN_LVL, PRESN_SEQ_NUM, ASSOC_PARENT_ID, SUB_ASSOC_PARENT_ID, PRESN_ID, ALERT_RULE) VALUES (''P'', " +
	"''{0}'', ''3'', ''{1}'', ''{2}'', ''1'', ''{3}'', ''{4}'')";
    
	protected static final String INS_RABC_STD_CALC_Track = "INSERT INTO RABC_STD_CALC (ALERT_RULE, PARTI_REF_ID, " +
	"STD_NUM_DATE, STD_NUM_REC, STD_TREND_TIME_IND, STD_TYPE, STD_TBL_NAME) VALUES (''{0}'', ''{1}'', ''{2}'', " +
	"NULL, ''{3}'', ''1'', ''RABC_ALERT_HIST'')";          	
	
	protected static final String INS_RABC_STD_CALC_Trend = "INSERT INTO RABC_STD_CALC (ALERT_RULE, PARTI_REF_ID, " +
	"STD_NUM_DATE, STD_NUM_REC, STD_TREND_TIME_IND, STD_TYPE, STD_TBL_NAME) VALUES (''{0}'', ''{1}'', ''{2}'', " +
	"NULL, ''{3}'', ''1'', ''RABC_ALERT_HIST'')";
	
	protected static final String INS_RABC_WEB_DATA_LINK_1_Track = "INSERT INTO RABC_WEB_DATA_LINK (PRESN_ID, WEBID, " +
	"EXEC_PRESN_SEQ_NUM, LINK_NUM, LINK_DDL_NAME, LINK_TO_PGM, LINK_PRESN_ID)VALUES(''{0}'', ''RABCPSF00012'', ''1'', " +
	"''1'', NULL, ''AdhocRpt.do'', ''{1}'')";
	
	protected static final String INS_RABC_WEB_DATA_LINK_2_Track = "INSERT INTO RABC_WEB_DATA_LINK (PRESN_ID, WEBID, " +
	"EXEC_PRESN_SEQ_NUM, LINK_NUM,LINK_DDL_NAME, LINK_TO_PGM, LINK_PRESN_ID)VALUES (''{0}'', ''RABCPSF00011'', ''1'', " +
	"''1'', NULL, ''AdhocRpt.do'', ''{1}'')";
	
	protected static final String INS_RABC_WEB_DATA_LINK_3_Track = "INSERT INTO RABC_WEB_DATA_LINK (PRESN_ID, WEBID, " +
	"EXEC_PRESN_SEQ_NUM, LINK_NUM,LINK_DDL_NAME, LINK_TO_PGM, LINK_PRESN_ID)VALUES (''{0}'', ''RABCPSF00013'', ''1'', " +
	"''{1}'', ''{2}'', ''AdhocRpt.do'', ''{3}'')";
	
	protected static final String INS_RABC_WEB_DATA_LINK_1_Trend = "INSERT INTO RABC_WEB_DATA_LINK (PRESN_ID, WEBID, " +
	"EXEC_PRESN_SEQ_NUM, LINK_NUM,LINK_DDL_NAME, LINK_TO_PGM, LINK_PRESN_ID)VALUES (''{0}'', ''RABCPSF00011'', ''1'', " +
	"''1'', NULL, ''AdhocRpt.do'', ''{1}'')";
		
	protected static final String INS_RABC_WEB_DATA_LINK_2_Trend = "INSERT INTO RABC_WEB_DATA_LINK (PRESN_ID, WEBID, " +
	"EXEC_PRESN_SEQ_NUM, LINK_NUM,LINK_DDL_NAME, LINK_TO_PGM, LINK_PRESN_ID)VALUES (''{0}'', ''RABCPSF00012'', ''1'', " +
	"''1'', NULL, ''AdhocRpt.do'', ''{1}'')";
	
	protected static final String INS_RABC_WEB_DATA_LINK_3_Trend = "INSERT INTO RABC_WEB_DATA_LINK (PRESN_ID, WEBID, " +
	"EXEC_PRESN_SEQ_NUM, LINK_NUM,LINK_DDL_NAME, LINK_TO_PGM, LINK_PRESN_ID)VALUES (''{0}'', ''RABCPSF00013'', ''1'', " +
	"''{1}'', ''{2}'', ''AdhocRpt.do'', ''{3}'')";
	
	protected static final String INSBMOL = "INSERT INTO RABC_MOUSE_OVER_LINK (PRESN_ID, WEBID, EXEC_PRESN_SEQ_NUM, " +
	"MOUSE_OVER_NUM, LINK_TBL_NAME, LINK_TBL_KEY_NAME, LINK_TBL_KEY_DATA) VALUES (''{0}'', ''{1}'', ''1'', ''{2}'', " +
	"''{3}'', ''{4}'', ''{5}'')";
	
	protected static final String INS_WEB_HEADER_Track = "INSERT INTO RABC_WEB_HEADER_LINK (PRESN_ID, WEBID, SEQ_NUM, " +
	"LINK_PRESN_NAME, LINK_TO_PGM, LINK_PRESN_ID) VALUES (''{0}'', ''{1}'', ''{2}'', ''{3}'', ''{4}'', ''{5}'')";
	
	protected static final String INS_WEB_HEADER_Trend = "INSERT INTO RABC_WEB_HEADER_LINK (PRESN_ID, WEBID, SEQ_NUM, " +
	"LINK_PRESN_NAME, LINK_TO_PGM, LINK_PRESN_ID) VALUES (''{0}'', ''{1}'', ''{2}'', ''{3}'', ''{4}'', ''{5}'')";
	
	protected static final String INS_RABC_PRESN_HEADER_Track = "INSERT INTO RABC_PRESN_HEADER(PRESN_ID, WEBID, HEADER1, " +
	"HEADER2, HEADER3, PRESN_DATE_IND)VALUES(''{0}'',''{1}'',''{2}'', ''{3}'', ''{4}'', ''1'')";
	
	protected static final String INS_RABC_PRESN_HEADER_Trend = "INSERT INTO RABC_PRESN_HEADER (PRESN_ID, WEBID, HEADER1, " +
	"HEADER2, HEADER3, PRESN_DATE_IND) VALUES (''{0}'', ''{1}'', ''{2}'', ''{3}'', ''{4}'', ''1'')";
	
	protected static final String INS_RABC_ALERT_SUMY_PRESN_1_Track = "INSERT INTO RABC_ALERT_SUMY_PRESN(SUMY_PRESN_NAME, " +
	"ALERT_RULE, WEBID, PRESN_SEQ_NUM, TOT_IND, ASOC_PRESN_ID) VALUES(''{0}'', ''{1}'',  ''{2}'', ''1'', ''N'',''{3}'')";
	
	protected static final String INS_RABC_ALERT_SUMY_PRESN_2_Track = "INSERT INTO RABC_ALERT_SUMY_PRESN(SUMY_PRESN_NAME, " +
	"ALERT_RULE, WEBID, PRESN_SEQ_NUM, TOT_IND, ASOC_PRESN_ID) VALUES (''{0}'',''{1}'',''{2}'', ''{3}'', ''{4}'', ''{5}'')";		          

	protected static final String INS_RABC_ALERT_SUMY_PRESN_Trend = "INSERT INTO RABC_ALERT_SUMY_PRESN (SUMY_PRESN_NAME, " +
	"ALERT_RULE, WEBID, PRESN_SEQ_NUM, TOT_IND, ASOC_PRESN_ID) VALUES (''{0}'', ''{1}'', ''{2}'', ''{3}'', ''{5}'', " +
	"''{4}'')";
	
	protected static final String INS_RABC_ALERT_SUMY_PRESN_REL_Track = "INSERT INTO RABC_ALERT_SUMY_PRESN(SUMY_PRESN_NAME, " +
	"ALERT_RULE, WEBID, PRESN_SEQ_NUM, TOT_IND, ASOC_PRESN_ID)VALUES (''{0}'', ''{1}'',''RABCPSF00011'', ''{2}'', ''N'', ''{3}'')"; 
	
	protected static final String INS_RABC_ALERT_SUPP_RULE_Track = "INSERT INTO RABC_ALERT_SUPP_RULE (ALERT_RULE, " +
	"ALERT_ITEM_NAME, ALERT_ITEM_DDL_NAME, SUPP_SEQ_NUM, TBL_NAME, SUPP_ITEM_NAME, SUPP_ITEM_DDL_NAME, SUPP_PRESN_NAME, " +
	"SUPP_PIC_LINK) VALUES (''{0}'', ''{1}'', ''ALERT_DATA'', ''{2}'', ''RABC_EXTRCT_SUMY_DATA'', ''{3}'', ''{4}'', " +
	"''{5}'', ''SQUARE.GIF'')"; 
	
	protected static final String INS_RABC_ALERT_SUPP_RULE_Trend = "INSERT INTO RABC_ALERT_SUPP_RULE (ALERT_RULE, " +
	"ALERT_ITEM_NAME, ALERT_ITEM_DDL_NAME, SUPP_SEQ_NUM, TBL_NAME, SUPP_ITEM_NAME, SUPP_ITEM_DDL_NAME, SUPP_PRESN_NAME, " +
	"SUPP_PIC_LINK)VALUES (''{0}'', ''{1}'', ''ALERT_DATA'', ''{2}'', ''RABC_EXTRCT_SUMY_DATA'', NULL, ''{3}'', ''{4}'', " +
	"''SQUARE.GIF'')"; 
	
	protected static final String GET_MOUSE_OVER_NUM_Track = "SELECT DISTINCT KEY1_MOUSE_OVER_NUM AS KIND FROM " +
	"RABC_ALERT_RULE_PRESN_RULE WHERE PRESN_ID = ''{0}''";
	
	protected static final String GET_MOUSE_OVER_NUM_Trend = "SELECT DISTINCT KEY1_MOUSE_OVER_NUM AS KIND FROM " +
	"RABC_ALERT_RULE_PRESN_RULE WHERE PRESN_ID = ''{0}''";
	
	protected static final String GET_UPDATE_IDS_Track ="SELECT PARTI_REF_ID, PRESN_ID FROM RABC_ALERT_RULE " +
	"WHERE ALERT_RULE = ''{0}''";
	
	protected static final String GET_PSN = "SELECT NVL(MAX(PRESN_SEQ_NUM),0) AS MPSN FROM RABC_MENU_INDEX";
	
	protected static final String GET_ASOC_PRENSNID_Track = "SELECT PRESN_ID FROM RABC_ALERT_RULE WHERE ALERT_RULE = ''{0}'' ";
	
	protected static final String GET_ASOC_PRENSNID_Trend = "SELECT PRESN_ID FROM RABC_ALERT_RULE WHERE ALERT_RULE = ''{0}'' ";
	
	protected static final String SEL_EXTRCT_DATA_Track = "SELECT DATA_DDL_NAME FROM RABC_ALERT_RULE_PRESN_ELEM WHERE " +
	"PRESN_NAME = ''LTOTAL'' AND PARTI_REF_ID =''{0}'' ";
	
	protected static final String checkDuplicateSave = "SELECT ALERT_RULE FROM RABC_ALERT_RULE WHERE UPPER(ALERT_RULE) " +
	"= UPPER(''{0}'')";
	
	/**
	 * Checks for the duplicate Alert Rule name in RABC_ALERT_RULE table.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	protected boolean getCheckSave (Connection connection, List failures, AlertRuleDefinition alertRuleDefinition){
		String alertRule = null;
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		List arguments = new ArrayList();
		arguments.add(alertRuleDefinition.getAlertRule().trim());
		try
		{
			MessageFormat mf = new MessageFormat(checkDuplicateSave);
			prepareStatement = mf.format((String[])arguments.toArray(new String[arguments.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			
			while(rs.next()){
				alertRule = rs.getString("ALERT_RULE");
				break;
			}
			
			if(alertRule == null){
				return false;
			}else{
				return true;
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
			return false;
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
	}
	
	/**
	 * Returns maximum PRESN_SEQ_NUM from RABC_MENU_INDEX table.
	 * 
	 * @param connection
	 * @param failures
	 * @return int
	 */
	protected int getMPSN(Connection connection, List failures){
		int MPSN = 0;
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		List arguments = new ArrayList();
		try
		{
			MessageFormat mf = new MessageFormat(GET_PSN);
			prepareStatement = mf.format((String[])arguments.toArray(new String[arguments.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			
			while(rs.next()){
				MPSN = rs.getInt("MPSN");
				break;
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
			return 0;
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
		return MPSN;
	}

	/**
	 * Returns new presnId for the new alert rule. 
	 * 
	 * @param connection
	 * @param failureList
	 * @return int
	 */
	protected int getNewPresnId(Connection connection,List failureList){
		/* look for the missing PRESN_ID in the table. If a PRESN_ID is missing in the 
		series, then the new record should be created with the missing PRESEN_ID's
		*/
		
		String selectSQL = getPresenId;
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		List args = new ArrayList();
		int newPresnId=1;
		try
		{
			MessageFormat mf = new MessageFormat(selectSQL);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
						
			while(rs.next()){
				if (rs.getInt(1)!=newPresnId){
					return (newPresnId);
				}
				else{
					newPresnId = newPresnId+1;
				}
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
			return 1;
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		return (newPresnId);
	}

	/**
	 * Returns new partiRefId for the new alert rule.
	 * 
	 * @param connection
	 * @param failureList
	 * @return int
	 */
	protected int getNewPartiRefID(Connection connection,List failureList){
		String selectSQL = getPartiRefID;
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		List args = new ArrayList();
		int newPartiRefID=1;
		try
		{
			MessageFormat mf = new MessageFormat(selectSQL);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
						
			while(rs.next()){
				newPartiRefID = rs.getInt("MAX(PARTI_REF_ID)");
				break;
			}
			newPartiRefID++;
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
			return 1;
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		
		return (newPartiRefID);
	}

	/**
	 * Returns new dashNum for the new alert rule.
	 * 
	 * @param connection
	 * @param failureList
	 * @return int
	 */
	protected int getNewDashNum(Connection connection,List failureList){
		String selectSQL = getPresnNum;
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		List args = new ArrayList();
		int newDashNum=1;
		try
		{
			MessageFormat mf = new MessageFormat(selectSQL);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
						
			while(rs.next()){
				newDashNum = newDashNum + rs.getInt(1);
				break;
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
			return 1;
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		return (newDashNum);
	}

	/**
	 * Returns DATA_DDL_NAME from RABC_ALERT_RULE_PRESN_ELEM table where 
	 * PRESN_NAME is "LTOTAL" PARTI_REF_ID is new partiRefId.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return String
	 */
	protected String getSelExtrctData(Connection connection, List failureList, List args){
		String selectSQL = SEL_EXTRCT_DATA_Track;
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		String dataDdlName=null;
		
		try {
			MessageFormat mf = new MessageFormat(selectSQL);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
						
			while(rs.next()){
				dataDdlName = rs.getString("DATA_DDL_NAME");
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		return dataDdlName;
	}
	
	/**
	 * Returns the PresnID associated with the alert rule related to current rule.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param alertRuleDefinition
	 * @return int
	 */
	protected int getAsocPresnId(Connection connection, List failureList, List args, AlertRuleDefinition alertRuleDefinition){
		String selectSQL = null;
		if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
			selectSQL = GET_ASOC_PRENSNID_Track ;
		}else {
			selectSQL = GET_ASOC_PRENSNID_Trend ;
		}
		
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		int asocPresnId=0;
		
		try {
			MessageFormat mf = new MessageFormat(selectSQL);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
						
			while(rs.next()){
				asocPresnId = rs.getInt("PRESN_ID");
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		return asocPresnId;
	}
	
	/**
	 * Inserts data into RABC_PRESN_ID table.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	protected boolean insertPresnId(Connection connection,List failureList,List args, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		
		PresnIdDAO presnIdDAO = new PresnIdDAO();
		if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
			presnIdDAO.executeUpdate(connection, failureList, args, INS_RABC_PRESN_ID_Track);
		} else {
			presnIdDAO.executeUpdate(connection, failureList, args, INS_RABC_PRESN_ID_Trend);
		}
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}

	/**
	 * Inserts data into RABC_ALERT_RULE table.  
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param alertRuleDefinition
	 * @param pickSql
	 * @return boolean
	 */
	protected boolean insertAlertRule(Connection connection,List failureList,List args, AlertRuleDefinition alertRuleDefinition, int pickSql){
		boolean success = true;
		AlertRuleDAO alertRuleDAO = new AlertRuleDAO();
		if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
			if (pickSql==1){
				alertRuleDAO.executeUpdate(connection,failureList,args,INS_RABC_ALERT_RULE_Track_1);
			}else {
				alertRuleDAO.executeUpdate(connection,failureList,args,INS_RABC_ALERT_RULE_Track_2);
			}
		} else {
			if (pickSql==1){
				alertRuleDAO.executeUpdate(connection,failureList,args,INS_RABC_ALERT_RULE_Trend_1);
			}else {
				alertRuleDAO.executeUpdate(connection,failureList,args,INS_RABC_ALERT_RULE_Trend_2);
			}	
		}
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
	
	/**
	 * Inserts data into RABC_TRACK_FILE_DTL table.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	protected boolean insertTrackFileDtl(Connection connection,List failureList,List args, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		
		TrackFileDtlDAO trackFileDtlDAO = new TrackFileDtlDAO();
		if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
			trackFileDtlDAO.executeUpdate(connection,failureList,args,INS_RABC_TRACK_FILE_DTL_Track);
		} else {
			trackFileDtlDAO.executeUpdate(connection,failureList,args,INS_RABC_TRACK_FILE_DTL_Trend);
		}
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
	
	/**
	 * Inserts data into RABC_TRIG_CONVERT table.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	protected boolean insertTrigConvert(Connection connection,List failureList,List args, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		TrigConvertDAO trigConvertDAO = new TrigConvertDAO();
		if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
			trigConvertDAO.executeUpdate(connection,failureList,args,INS_RABC_TRIG_CONVERT_Track);
		} else {
			trigConvertDAO.executeUpdate(connection,failureList,args,INS_RABC_TRIG_CONVERT_Trend);
		}
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
	
	/**
	 * Inserts data into RABC_EXTRCT_BUILD_RULE table.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	protected boolean insertExtrctBuildRule(Connection connection,List failureList,List args, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		ExtractBuildRuleDAO extractBuildRuleDAO = new ExtractBuildRuleDAO();
		if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
			extractBuildRuleDAO.executeUpdate(connection,failureList,args,INS_RABC_EXTRCT_BUILD_RULE_Track);
		} else {
			extractBuildRuleDAO.executeUpdate(connection,failureList,args,INS_RABC_EXTRCT_BUILD_RULE_Trend);
		}
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
	
	/**
	 * Inserts data into RABC_AVG_TBL_DEF table.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	protected boolean insertAvgTblDef(Connection connection,List failureList,List args, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		AvgTblDefDAO avgTblDefDAO = new AvgTblDefDAO(); 
		avgTblDefDAO.executeUpdate(connection,failureList,args,INS_RABC_AVG_TBL_DEF_Track);
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
	
	/**
	 * Inserts data into RABC_EXTRCT_TBL_DEF table.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	protected boolean insertExtrctTblDef(Connection connection,List failureList,List args, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		ExtrctTblDefDAO extractTblDefDAO = new ExtrctTblDefDAO(); 
		if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
			extractTblDefDAO.executeUpdate(connection,failureList,args,INS_RABC_EXTRCT_TBL_DEF_Track);
		} else {
			extractTblDefDAO.executeUpdate(connection,failureList,args,INS_RABC_EXTRCT_TBL_DEF_Trend);
		}
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;	
	}
	
	/**
	 * Inserts data into RABC_UPDATE_GRP table.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	protected boolean insertAlertGroup(Connection connection,List failureList,List args, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		AlertGroupDAO alertGroupDAO = new AlertGroupDAO(); 
		if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
			alertGroupDAO.executeUpdate(connection,failureList,args,INS_RABC_UPDATE_GRP_Track);
		} else {
			alertGroupDAO.executeUpdate(connection,failureList,args,INS_RABC_UPDATE_GRP_Trend);
		}
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;	
	}
	
	/**
	 * Inserts data into RABC_ALERT_PROC table.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	protected boolean insertAlertProc(Connection connection,List failureList,List args, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		AlertProcDAO alertProcDAO = new  AlertProcDAO();
		if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
			alertProcDAO.executeUpdate(connection,failureList,args,INS_RABC_ALERT_PROC_Track);
		} else {
			alertProcDAO.executeUpdate(connection,failureList,args,INS_RABC_ALERT_PROC_Trend);
		}
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;	
	}
	
	/**
	 * Inserts data into RABC_AVG_CALC table.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	protected boolean insertAvgCalc(Connection connection,List failureList,List args, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		AvgCalcDAO avgCalcDAO = new  AvgCalcDAO();
		if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
			avgCalcDAO.executeUpdate(connection,failureList,args,INS_RABC_AVG_CALC_Track);
		} else {
			avgCalcDAO.executeUpdate(connection,failureList,args,INS_RABC_AVG_CALC_Trend);
		}
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;	
	}
	
	/**
	 * Update into RABC_CNTRL_PT_ALERT table.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	protected boolean updateCntrlPtAlert(Connection connection,List failureList,List args, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		CntrlPtAlertDAO cntrlPtAlertDAO = new CntrlPtAlertDAO(); 
		if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
			cntrlPtAlertDAO.executeUpdate(connection,failureList,args,INS_RABC_CNTRL_PT_ALERT_Track);
		} else {
			cntrlPtAlertDAO.executeUpdate(connection,failureList,args,INS_RABC_CNTRL_PT_ALERT_Trend);
		}
		if (!failureList.isEmpty()){
			success = false;
		}
	return success;	
	}
	
	/**
	 * Insert into RABC_PROC_RESPONSIBLE table.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param alertRuleDefinition
	 * @param pickSql
	 * @return boolean
	 */
	protected boolean insertProcResponsible(Connection connection,List failureList,List args, AlertRuleDefinition alertRuleDefinition,int pickSql){
		boolean success = true;
		ProcResponsibleDAO procResponsibleDAO = new ProcResponsibleDAO(); 
		if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
			if(pickSql == 1){
				procResponsibleDAO.executeUpdate(connection,failureList,args,INS_RABC_PROC_RESPONSIBLE1_Track);
			}else if(pickSql == 2){
				procResponsibleDAO.executeUpdate(connection,failureList,args,INS_RABC_PROC_RESPONSIBLE2_Track);
			}
		}else { 
			if(pickSql == 1){
				procResponsibleDAO.executeUpdate(connection,failureList,args,INS_RABC_PROC_RESPONSIBLE1_Trend);
			}else if(pickSql == 2){
				procResponsibleDAO.executeUpdate(connection,failureList,args,INS_RABC_PROC_RESPONSIBLE2_Trend);
			}	
		}	
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;	
	}
	
	/**
	 * Insert into RABC_ALERT_RULE_PRESN_ELEM table.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param alertRuleDefinition
	 * @param pickSql
	 * @return boolean
	 */
	protected boolean insertAlertRulePresenElem(Connection connection,List failureList,List args, AlertRuleDefinition alertRuleDefinition,int pickSql){
		boolean success = true;
		AlertRulePresnElemDAO alertRulePresenElemDAO = new AlertRulePresnElemDAO();
		if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
			if(pickSql == 0){
				alertRulePresenElemDAO.executeUpdate(connection,failureList,args,INS_RABC_ALERT_RULE_PRESN_ELEM_0_Track );
			} else if(pickSql == 1){
				alertRulePresenElemDAO.executeUpdate(connection,failureList,args,INS_RABC_ALERT_RULE_PRESN_ELEM_1_Track );
			} else if(pickSql == 2){
				alertRulePresenElemDAO.executeUpdate(connection,failureList,args,INS_RABC_ALERT_RULE_PRESN_ELEM_2_Track );
			}else if(pickSql == 3){
				alertRulePresenElemDAO.executeUpdate(connection,failureList,args,INS_RABC_ALERT_RULE_PRESN_ELEM_3_Track );
			}else if(pickSql == 4){
				alertRulePresenElemDAO.executeUpdate(connection,failureList,args,INS_RABC_ALERT_RULE_PRESN_ELEM_4_Track );
			}else if(pickSql ==5){
				alertRulePresenElemDAO.executeUpdate(connection,failureList,args,INS_RABC_ALERT_RULE_PRESN_ELEM_5_Track );
			}
		}else {
			alertRulePresenElemDAO.executeUpdate(connection,failureList,args,INS_RABC_ALERT_RULE_PRESN_ELEM_Trend);
		}
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
	
	/**
	 * Inserts data into RABC_ALERT_RULE_PRESN_RULE table.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param alertRuleDefinition
	 * @param pickSql
	 * @return boolean
	 */
	protected boolean insertAlertRulePresnRule(Connection connection,List failureList,List args, AlertRuleDefinition alertRuleDefinition,int pickSql){
		boolean success = true;
		AlertRulePresenRuleDAO alertRulePresnRuleDAO = new AlertRulePresenRuleDAO(); 
		if("Track".equals(alertRuleDefinition.getAlertRuleType())){
			if(pickSql == 1){
				alertRulePresnRuleDAO.executeUpdate(connection,failureList,args,INS_RABC_ALERT_RULE_PRESN_RULE_1_Track );
			}else if(pickSql == 2){
				alertRulePresnRuleDAO.executeUpdate(connection,failureList,args,INS_RABC_ALERT_RULE_PRESN_RULE_2_Track );
			}else if(pickSql == 3){
				alertRulePresnRuleDAO.executeUpdate(connection,failureList,args,INS_RABC_ALERT_RULE_PRESN_RULE_3_Track );
			}
		}else {
			alertRulePresnRuleDAO.executeUpdate(connection,failureList,args,INS_RABC_ALERT_RULE_PRESN_RULE_Trend);
		}
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
	
	/**
	 * Inserts data into RABC_MENU_INDEX table.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param alertRuleDefinition
	 * @param pickSql
	 * @return boolean
	 */
	protected boolean insertMenuIndex(Connection connection,List failureList,List args, AlertRuleDefinition alertRuleDefinition, int pickSql){
		boolean success = true;
		MenuIndexDAO menuIndexDAO = new MenuIndexDAO(); 
		if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
			if(pickSql == 1){
				menuIndexDAO.executeUpdate(connection, failureList, args, INS_RABC_MENU_INDEX1_Track);
			}else if(pickSql == 2){
				menuIndexDAO.executeUpdate(connection, failureList, args, INS_RABC_MENU_INDEX2_Track);
			}else if(pickSql == 3){
				menuIndexDAO.executeUpdate(connection, failureList, args, INS_RABC_MENU_INDEX3_Track);
			}
		}else{	
			if(pickSql == 1){
				menuIndexDAO.executeUpdate(connection, failureList, args, INS_RABC_MENU_INDEX1_Trend);
			}else if(pickSql == 2){
				menuIndexDAO.executeUpdate(connection, failureList, args, INS_RABC_MENU_INDEX2_Trend);
			}
		}
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
	
	/**
	 * Inserts data into RABC_STD_CALC table.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	protected boolean insertStdCalc(Connection connection,List failureList,List args, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		StdCalDAO stdCalcDAO = new StdCalDAO(); 
		if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
			stdCalcDAO.executeUpdate(connection,failureList,args,INS_RABC_STD_CALC_Track);
		} else {
			stdCalcDAO.executeUpdate(connection,failureList,args,INS_RABC_STD_CALC_Trend);
		}
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
	
	/**
	 * Inserts data into RABC_WEB_HEADER_LINK table.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	protected boolean insertWebHeaderLink(Connection connection,List failureList,List args, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		
		WebHeaderLinkDAO webHeaderLinkDAO = new WebHeaderLinkDAO();
		if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
			webHeaderLinkDAO.executeUpdate(connection,failureList,args, INS_WEB_HEADER_Track);
		}else {
			webHeaderLinkDAO.executeUpdate(connection,failureList,args, INS_WEB_HEADER_Trend);
		}
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
	
	/**
	 * Inserts data into RABC_WEB_DATA_LINK table.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param alertRuleDefinition
	 * @param pickSql
	 * @return boolean
	 */
	protected boolean insertWebDataLink(Connection connection,List failureList,List args, AlertRuleDefinition alertRuleDefinition,int pickSql){
		boolean success = true;
		WebDataLinkDAO webDataLinkDAO = new WebDataLinkDAO();
		if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
			if(pickSql == 1){
				webDataLinkDAO.executeUpdate(connection,failureList,args,INS_RABC_WEB_DATA_LINK_1_Track);
			}else if(pickSql == 2){
				webDataLinkDAO.executeUpdate(connection,failureList,args,INS_RABC_WEB_DATA_LINK_2_Track);
			}else if(pickSql == 3){
				webDataLinkDAO.executeUpdate(connection,failureList,args,INS_RABC_WEB_DATA_LINK_3_Track);
			}
		} else {
			if(pickSql == 1){
				webDataLinkDAO.executeUpdate(connection,failureList,args,INS_RABC_WEB_DATA_LINK_1_Trend);
			}else if(pickSql == 2){
				webDataLinkDAO.executeUpdate(connection,failureList,args,INS_RABC_WEB_DATA_LINK_2_Trend);
			}else if(pickSql == 3){
				webDataLinkDAO.executeUpdate(connection,failureList,args,INS_RABC_WEB_DATA_LINK_3_Trend);
			}
		}
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
	
	/**
	 * Inserts data into RABC_MOUSE_OVER_LINK table.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return boolean
	 */
	protected boolean insertMouseOverLink(Connection connection,List failureList,List args){
		boolean success = true;
		MouseOverLinkDAO mouseOverLinkDAO = new MouseOverLinkDAO(); 	
		mouseOverLinkDAO.executeUpdate(connection, failureList, args, INSBMOL);
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
	
	/**
	 * Inserts data into RABC_PRESN_HEADER table.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	protected boolean insertPresnHeader(Connection connection,List failureList,List args, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		PresnHeaderDAO presnHeaderDAO = new PresnHeaderDAO(); 	
		if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
			 presnHeaderDAO.executeUpdate(connection, failureList, args, INS_RABC_PRESN_HEADER_Track);
		} else {
			 presnHeaderDAO.executeUpdate(connection, failureList, args, INS_RABC_PRESN_HEADER_Trend);
		}
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
		
	/**
	 * Inserts data into RABC_ALERT_SUMY_PRESN
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param alertRuleDefinition
	 * @param pickSql
	 * @return boolean
	 */
	protected boolean insertSumyPresn(Connection connection,List failureList,List args, AlertRuleDefinition alertRuleDefinition, int pickSql){
		boolean success = true;
		AlertSumyPresnDAO sumyPresnDAO = new AlertSumyPresnDAO(); 	
		if("Track".equals(alertRuleDefinition.getAlertRuleType())){
			if(pickSql == 1){
				sumyPresnDAO.executeUpdate(connection,failureList,args,INS_RABC_ALERT_SUMY_PRESN_1_Track);	
			}else if(pickSql == 2){
				sumyPresnDAO.executeUpdate(connection,failureList,args,INS_RABC_ALERT_SUMY_PRESN_2_Track);
			}
		}else {
			sumyPresnDAO.executeUpdate(connection,failureList,args,INS_RABC_ALERT_SUMY_PRESN_Trend);
		}
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
	
	/**
	 * Inserts data into RABC_ALERT_SUPP_RULE.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	protected boolean insertSuppRule(Connection connection,List failureList,List args, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		AlertSuppRuleDAO alertSuppRuleDAO = new AlertSuppRuleDAO(); 	
		if("Track".equals(alertRuleDefinition.getAlertRuleType())){
			alertSuppRuleDAO.executeUpdate(connection, failureList, args, INS_RABC_ALERT_SUPP_RULE_Track);
		}else {
			alertSuppRuleDAO.executeUpdate(connection, failureList, args, INS_RABC_ALERT_SUPP_RULE_Trend);
		}
		
		if (!failureList.isEmpty()){
			success = false;
		}
		return success;
	}
}
