/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

/**
 * This is a DAO that performs SELECT, INSERT and UPDATE on RABC_DATA_TBL_DDL table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class DataTblDdlDAO {
	private static final Logger logger = Logger.getLogger(DataTblDdlDAO.class);
	
	/**
	 * Returns the list of DataTblDdl objects.
	 * 
	 * @param conn 
	 * @param failures
	 * @param args
	 * @param baseSQL
	 * @return List
	 */
	public List get(Connection conn, List failures, List args, String baseSQL) {
		List dataTblDdlList = null;
		DataTblDdl dataTblDdl = null;
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		
		try
		{
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("DataTblDdlDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			dataTblDdlList = new ArrayList();
			while (rs.next()) {
				dataTblDdlList.add(buildDataTblDdl(rs));
			}			
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return null;
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
		
		return dataTblDdlList;
	}

	/**
	 * Private method to build DataTblDdl object and return it to caller.
	 * 
	 * @param rs
	 * @return DataTblDdl
	 * @throws SQLException
	 */
	private DataTblDdl buildDataTblDdl(ResultSet rs) throws SQLException {
		DataTblDdl dataTblDdl = new DataTblDdl();
		
		dataTblDdl.setAlertProcTbl(rs.getString("ALERT_PROC_TBL"));
		dataTblDdl.setTblProcDateDdlName(rs.getString("TBL_PROC_DATE_DDL_NAME"));
		dataTblDdl.setTblBillRndDdlName(rs.getString("TBL_BILL_RND_DDL_NAME"));
		dataTblDdl.setTblDdlKeyLvl(rs.getInt("TBL_DDL_KEY_LVL"));
		dataTblDdl.setTblDdlKey1Name(rs.getString("TBL_DDL_KEY1_NAME"));
		dataTblDdl.setTblDdlKey2Name(rs.getString("TBL_DDL_KEY2_NAME"));
		dataTblDdl.setTblDdlKey3Name(rs.getString("TBL_DDL_KEY3_NAME"));
		dataTblDdl.setTblDdlKey4Name(rs.getString("TBL_DDL_KEY4_NAME"));
		dataTblDdl.setTblDdlKey5Name(rs.getString("TBL_DDL_KEY5_NAME"));
		dataTblDdl.setTblDdlName(rs.getString("TBL_DDL_NAME"));
		dataTblDdl.setTblBillRndDdlMon(rs.getString("TBL_BILL_RND_DDL_MON"));
		dataTblDdl.setTblBillRndDdlYear(rs.getString("TBL_BILL_RND_DDL_YEAR"));
		dataTblDdl.setTblDdlDataType(rs.getString("TBL_DDL_DATA_TYPE"));
		dataTblDdl.setTblSubsysId(rs.getString("TBL_SUBSYS_ID"));
		dataTblDdl.setTblFileSeqNumDdlName(rs.getString("TBL_FILE_SEQ_NUM_DDL_NAME"));
		dataTblDdl.setTblDdlPrescsnFormatType(rs.getString("TBL_DDL_PRESCSN_FORMAT_TYPE"));
		dataTblDdl.setTblDdlNameDesc(rs.getString("TBL_DDL_NAME_DESC"));
		return dataTblDdl;
	}

	/**
	 * Execute the insert or update statement on RABC_DATA_TBL_DDL table.
	 * 
	 * @param conn
	 * @param failures
	 * @param args
	 * @param baseSQL
	 */
	public void executeUpdate(Connection conn, List failures, List args, String baseSQL) {
		int rowsUpdated = 0;
		Statement stmt = null;
		String sqlStmt = null;
		
		try
		{
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("DataTblDdlDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rowsUpdated = stmt.executeUpdate(sqlStmt);
			logger.debug("SQL - Execution complete."+ String.valueOf(rowsUpdated) + "  rows updated");
			
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return;
		} finally {
			SQLHelper.closeStatement(stmt, failures, logger);
		}
	}

}
