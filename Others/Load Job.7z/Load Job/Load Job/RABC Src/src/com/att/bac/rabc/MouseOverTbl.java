/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc;

/**
 * This is a Data Object to represent RABC_MOUSE_OVER_TBL table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class MouseOverTbl {
	private String tableName;
	private String tableDesc;
	private String tableKeyData;
	private String tableKeyName;

	/**
	 * @return Returns the TableName.
	 */
	public String getTableName() {
		return tableName;
	}
	/**
	 * @return Returns the TableDesc.
	 */
	public String getTableDesc() {
		return tableDesc;
	}
	/**
	 * @return Returns the TableKeyData.
	 */
	public String getTableKeyData() {
		return tableKeyData;
	}
	/**
	 * @return Returns the TableKeyName.
	 */
	public String getTableKeyName() {
		return tableKeyName;
	}

	/**
	 * @param TableName The tableName to set.
	 */
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	/**
	 * @param TableDesc The tableDesc to set.
	 */
	public void setTableDesc(String tableDesc) {
		this.tableDesc = tableDesc;
	}
	/**
	 * @param TableKeyData The tableKeyData to set.
	 */
	public void setTableKeyData(String tableKeyData) {
		this.tableKeyData = tableKeyData;
	}
	/**
	 * @param TableKeyName The tableKeyName to set.
	 */
	public void setTableKeyName(String tableKeyName) {
		this.tableKeyName = tableKeyName;
	}
}
