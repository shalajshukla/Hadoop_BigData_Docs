/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.admin.alert.rule;

import java.util.ArrayList;
import java.util.List;

import com.att.bac.rabc.Column;
import com.att.bac.rabc.MyDate;
import com.att.bac.rabc.PickList;
import com.att.bac.rabc.RABCConstantsLists;
import com.att.bac.rabc.StaticDataLoader;
import com.att.bac.rabc.admin.AlertGroupUser;

/**
 * This is a Data Object for Alert Rule Description (All 3 Steps).
 * 
 * @author Shashank Weginwar - SW3562
 */
public class AlertRuleDefinition {
	private String dbNodeId;						//DB Node Id.
	private String dataSource; 						//Data Source Name.
	private String alertRuleType;					//1 or 2 for Tracking & Trending respectively.
	private String alertRule; 						//Name of the alert rule.
	private String alertRuleDescription;			//Description of the alert rule.
	private String [] alertGroups; 					//Alert Groups which are selected during alert rule creation.
	private List alertGroupsList = new ArrayList(); //List of all Alert Groups for a perticular Logged In user.  
	private int delayExecutionTime = -1;			//Delay Execution Time.
	private String fileSequenceIndicator; 			//File Sequence Indicator.
	private String alertRuleTiming;					//Values are "",D, B or M corresponding to Record, Daily, Bill Day & Monthly.
	private List alertRuleTimingListForTracking = new ArrayList();	//List of all Alert Rule Timing for tracking.
	private List alertRuleTimingListForTrending = new ArrayList();	//List of all Alert Rule Timing for trending.
	private String averageDays; 					//Average Days.
	private String averageRecords;					//Average Records. 
	private String averageType;						//value 1 or 2.
	private List averageTypeList = new ArrayList();	//1 and 2 both.
	private String thresholdExemptionCheck;			//Threshold Exemption Check.
	private String controlPoint; 					//The control point under which the alert is to be categorized.
	private String controlPointDesc; 					//Desc of the control point
	private List controlPointsList = new ArrayList();//List of all Control points.
	private String effectiveDate;					//Effective date
	private List LHSColumnsList;					//All LHS field names.	
	private List RHSColumnsList;					//All RHS field names.
	private List alertItemList;						//List of all Alert Item Objects.
	private int alertKeyLevel;						//Alert Key Level for Step 3.	
	private List alertKeyList; 						//List of all Alert Key objects.
	private List relatedAlertRulesList;
	private String [] selectedRelatedAlertRules = null;
	private int alertDataKeep = -1;
	private String clearSupplementaryItemFlag = null;
	private String reportLinkKey1;
	private String reportLinkKey2;
	private String reportLinkKey3;
	private String reportLinkKey4;
	private String reportLinkKey5;
	private List reportLinkOptionsList;
	private String mouseOverTableKey1 = "RABC_DIVISION~DIVISION~DIVISION_DESC";
	private String mouseOverTableKey2;
	private String mouseOverTableKey3;
	private String mouseOverTableKey4;
	private String mouseOverTableKey5;
	private List mouseOverTableOptionsList;
	private String userId;
	private MyDate timeStamp;
	private String alertRuleMonthlyTimingType;	
	private List alertRuleMonthlyTimingTypeList = new ArrayList();	//List of all Alert Rule Monthly Timing types
	private String mnthExecDt; 						//ALERT_MNTH_EXEC_DT
	private String mnthExecBillRnd;					//ALERT_MNTH_EXEC_BILL_RND
	private List billRndOptions = new ArrayList();
	private List dayOptions = new ArrayList();
	private String allowMonthlyTimingUpdate = "false"; 
	private ArrayList alertUnitList = new ArrayList();
	private String stdNumDate; 
	
	/**
	 * Constructor to initialise all List variables.
	 * 
	 * @param region
	 */
	public AlertRuleDefinition(String region){
		this.alertGroupsList= new ArrayList();
		this.LHSColumnsList= new ArrayList();
		this.RHSColumnsList= new ArrayList();
		this.alertKeyList= new ArrayList();
		this.relatedAlertRulesList= new ArrayList();
		this.alertItemList = new ArrayList();
		this.alertRuleTimingListForTracking = RABCConstantsLists.getRABCConstantsLists().getAlertRuleTimingListForTracking(region);
		this.alertRuleTimingListForTrending = RABCConstantsLists.getRABCConstantsLists().getAlertRuleTimingListForTrending(region);
		this.averageTypeList = RABCConstantsLists.getRABCConstantsLists().getAverageTypeList();
		this.controlPointsList = StaticDataLoader.getCntrlPtList(region);
		this.reportLinkOptionsList = new ArrayList();
		this.reportLinkOptionsList.add(new PickList("---Select---","---Select---"));
		this.mouseOverTableOptionsList = new ArrayList();
		this.mouseOverTableOptionsList.add(new PickList("---Select---","---Select---"));
		this.alertRuleMonthlyTimingTypeList = RABCConstantsLists.getRABCConstantsLists().getAlertRuleMonthlyTimingTypesList(region);
		this.dayOptions = RABCConstantsLists.getRABCConstantsLists().getMonthDayOptions();
		this.alertUnitList = RABCConstantsLists.getRABCConstantsLists().getAlertUnitList();
			
		List billRndOptionsList = StaticDataLoader.getBillRndByRegion(region);
		if (!billRndOptionsList.isEmpty()){
			int size = billRndOptionsList.size();
			for (int i=0;i<size;i++){
				this.addBillRndOptions((String)billRndOptionsList.get(i));
			}
		}else {
			this.addBillRndOptions("1");
		}
	}
	
	/**
	 * @return Returns the alertDataKeep.
	 */
	public int getAlertDataKeep() {
		return alertDataKeep;
	}
	/**
	 * @param alertDataKeep The alertDataKeep to set.
	 */
	public void setAlertDataKeep(int alertDataKeep) {
		this.alertDataKeep = alertDataKeep;
	}
	/**
	 * @return Returns the dbNodeId.
	 */
	public String getDbNodeId() {
		return dbNodeId;
	}
	/**
	 * @param dbNodeId The dbNodeId to set.
	 */
	public void setDbNodeId(String dbNodeId) {
		this.dbNodeId = dbNodeId;
	}
	/**
	 * @return Returns the dataSource.
	 */
	public String getDataSource() {
		return dataSource;
	}
	/**
	 * @param dataSource The dataSource to set.
	 */
	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}
	/**
	 * @return Returns the alertRuleType.
	 */
	public String getAlertRuleType() {
		return alertRuleType;
	}
	/**
	 * @param alertRuleType The alertRuleType to set.
	 */
	public void setAlertRuleType(String alertRuleType) {
		this.alertRuleType = alertRuleType;
	}
	/**
	 * @return Returns the alertRule.
	 */
	public String getAlertRule() {
		return alertRule;
	}
	/**
	 * @param alertRule The alertRule to set.
	 */
	public void setAlertRule(String alertRule) {
		this.alertRule = alertRule;
	}
	/**
	 * @return Returns the alertRuleDescription.
	 */
	public String getAlertRuleDescription() {
		return alertRuleDescription;
	}
	/**
	 * @param alertRuleDescription The alertRuleDescription to set.
	 */
	public void setAlertRuleDescription(String alertRuleDescription) {
		this.alertRuleDescription = alertRuleDescription;
	}
	/**
	 * @return Returns the alertGroupsList.
	 */
	public List getAlertGroupsList() {
		return alertGroupsList;
	}
	/**
	 * @param alertGroupsList The alertGroupsList to add.
	 */
	public void addAlertGroup(AlertGroupUser alertGroup) {
		this.alertGroupsList.add(alertGroup);
	}
	/**
	 * @return Returns the selectedAlertGroups.
	 */
	public String[] getAlertGroups() {
		return alertGroups;
	}
	/**
	 * @param selectedAlertGroups The selectedAlertGroups to set.
	 */
	public void setAlertGroups(String[] selectedAlertGroups) {
		this.alertGroups = selectedAlertGroups;
	}
	/**
	 * @return Returns the delayExecutionTime.
	 */
	public int getDelayExecutionTime() {
		return delayExecutionTime;
	}
	/**
	 * @param delayExecutionTime The delayExecutionTime to set.
	 */
	public void setDelayExecutionTime(int delayExecutionTime) {
		this.delayExecutionTime = delayExecutionTime;
	}
	/**
	 * @return Returns the fileSequenceIndicator.
	 */
	public String getFileSequenceIndicator() {
		return fileSequenceIndicator;
	}
	/**
	 * @param fileSequenceIndicator The fileSequenceIndicator to set.
	 */
	public void setFileSequenceIndicator(String fileSequenceIndicator) {
		this.fileSequenceIndicator = fileSequenceIndicator;
	}
	/**
	 * @return Returns the alertRuleTiming.
	 */
	public String getAlertRuleTiming() {
		return alertRuleTiming;
	}
	/**
	 * @param alertRuleTiming The alertRuleTiming to set.
	 */
	public void setAlertRuleTiming(String alertRuleTiming) {
		this.alertRuleTiming = alertRuleTiming;
	}
	/**
	 * @return Returns the averageDays.
	 */
	public String getAverageDays() {
		return averageDays;
	}
	/**
	 * @param averageDays The averageDays to set.
	 */
	public void setAverageDays(String averageDays) {
		this.averageDays = averageDays;
	}
	/**
	 * @return Returns the averageRecords.
	 */
	public String getAverageRecords() {
		return averageRecords;
	}
	/**
	 * @param averageRecords The averageRecords to set.
	 */
	public void setAverageRecords(String averageRecords) {
		this.averageRecords = averageRecords;
	}
	/**
	 * @return Returns the averageType.
	 */
	public String getAverageType() {
		return averageType;
	}
	/**
	 * @param averageType The averageType to set.
	 */
	public void setAverageType(String averageType) {
		this.averageType = averageType;
	}
	/**
	 * @return Returns the averageTypeList.
	 */
	public List getAverageTypeList() {
		return averageTypeList;
	}
	/**
	 * @param averageTypeList The averageTypeList to set.
	 */
	public void setAverageTypeList(List averageTypeList) {
		this.averageTypeList = averageTypeList;
	}
	/**
	 * @return Returns the thresholdExemptionCheck.
	 */
	public String getThresholdExemptionCheck() {
		return thresholdExemptionCheck;
	}
	/**
	 * @param thresholdExemptionCheck The thresholdExemptionCheck to set.
	 */
	public void setThresholdExemptionCheck(String thresholdExemptionCheck) {
		this.thresholdExemptionCheck = thresholdExemptionCheck;
	}
	/**
	 * @return Returns the controlPoint.
	 */
	public String getControlPoint() {
		return controlPoint;
	}
	/**
	 * @param controlPoint The controlPoint to set.
	 */
	public void setControlPoint(String controlPoint) {
		this.controlPoint = controlPoint;
	}
	/**
	 * @return Returns the controlPointsList.
	 */
	public List getControlPointsList() {
		return controlPointsList;
	}
	/**
	 * @param controlPointsList The controlPointsList to add.
	 */
	public void addControlPoints(PickList controlPoint) {
		this.controlPointsList.add(controlPoint);
	}
	/**
	 * @return Returns the alertKeyLevel.
	 */
	public int getAlertKeyLevel() {
		return alertKeyLevel;
	}
	/**
	 * @param alertKeyLevel The alertKeyLevel to set.
	 */
	public void setAlertKeyLevel(int alertKeyLevel) {
		this.alertKeyLevel = alertKeyLevel;
	}
	/**
	 * @return Returns the alertKeyList.
	 */
	public List getAlertKeyList() {
		return alertKeyList;
	}
	/**
	 * @param alertKey The alertKey to add.
	 */
	public void addAlertKey(AlertKey alertKey) {
		this.alertKeyList.add(alertKey);
	}
	/**
	 * @return Returns the relatedAlertRulesList.
	 */
	public List getRelatedAlertRulesList() {
		return relatedAlertRulesList;
	}
	/**
	 * @param relatedAlertRulesList The relatedAlertRules to add.
	 */
	public void addRelatedAlertRulesList(String relatedAlertRule) {
		this.relatedAlertRulesList.add(new PickList(relatedAlertRule,relatedAlertRule));
	}
	/**
	 * @param relatedAlertRulesList The relatedAlertRulesList to set.
	 */
	public void setRelatedAlertRulesList(List relatedAlertRulesList) {
		this.relatedAlertRulesList = relatedAlertRulesList;
	}
	/**
	 * @return Returns the selectedRelatedAlertRules.
	 */
	public String[] getSelectedRelatedAlertRules() {
		return selectedRelatedAlertRules;
	}
	/**
	 * @param selectedRelatedAlertRules The selectedRelatedAlertRules to set.
	 */
	public void setSelectedRelatedAlertRules(String[] selectedRelatedAlertRules) {
		this.selectedRelatedAlertRules = selectedRelatedAlertRules;
	}
	/**
	 * @return Returns the alertItemList.
	 */
	public List getAlertItemList() {
		return alertItemList;
	}
	/**
	 * @param alertItemList The alertItem to add.
	 */
	public void addAlertItem(AlertItem alertItem) {
		this.alertItemList.add(alertItem);
	}
	/**
	 * @return Returns the lHSColumnsList.
	 */
	public List getLHSColumnsList() {
		return LHSColumnsList;
	}
	/**
	 * @param columnsList The lHSColumnsList to add.
	 */
	public void addLHSColumn(Column column) {
		this.LHSColumnsList.add(column);
	}
	/**
	 * @return Returns the rHSColumn
	 */
	public List getRHSColumnsList() {
		return RHSColumnsList;
	}
	/**
	 * @param columnsList The rHSColumn  to add.
	 */
	public void addRHSColumn(Column column) {
		this.RHSColumnsList.add(column);
	}
	/**
	 * @return Returns the alertRuleTimingList.
	 */
	public List getAlertRuleTimingListForTracking() {
		return alertRuleTimingListForTracking;
	}
	/**
	 * @param alertRuleTimingList The alertRuleTimingList to set.
	 */
	public void setAlertRuleTimingListForTracking(List alertRuleTimingListForTracking) {
		this.alertRuleTimingListForTracking = alertRuleTimingListForTracking;
	}
	/**
	 * @return Returns the alertRuleTimingList.
	 */
	public List getAlertRuleTimingListForTrending() {
		return alertRuleTimingListForTrending;
	}
	/**
	 * @param alertRuleTimingList The alertRuleTimingList to set.
	 */
	public void setAlertRuleTimingListForTrending(List alertRuleTimingListForTrending) {
		this.alertRuleTimingListForTrending = alertRuleTimingListForTrending;
	}
	/**
	 * @return Returns the effectiveDate1.
	 */
	public String getEffectiveDate() {
		return effectiveDate;
	}
	/**
	 * @param effectiveDate1 The effectiveDate1 to set.
	 */
	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
		
	/**
	 * @return Returns the clearSupplementaryItemFlag.
	 */
	public String getClearSupplementaryItemFlag() {
		return clearSupplementaryItemFlag;
	}
	/**
	 * @param clearSupplementaryItemFlag The clearSupplementaryItemFlag to set.
	 */
	public void setClearSupplementaryItemFlag(String clearSupplementaryItemFlag) {
		this.clearSupplementaryItemFlag = clearSupplementaryItemFlag;
	}	
	/**
	 * @return Returns the mouseOverTableKey1.
	 */
	public String getMouseOverTableKey1() {
		return mouseOverTableKey1;
	}
	/**
	 * @param mouseOverTableKey1 The mouseOverTableKey1 to set.
	 */
	public void setMouseOverTableKey1(String mouseOverTableKey1) {
		this.mouseOverTableKey1 = mouseOverTableKey1;
	}
	/**
	 * @return Returns the mouseOverTableKey2.
	 */
	public String getMouseOverTableKey2() {
		return mouseOverTableKey2;
	}
	/**
	 * @param mouseOverTableKey2 The mouseOverTableKey2 to set.
	 */
	public void setMouseOverTableKey2(String mouseOverTableKey2) {
		this.mouseOverTableKey2 = mouseOverTableKey2;
	}
	/**
	 * @return Returns the mouseOverTableKey3.
	 */
	public String getMouseOverTableKey3() {
		return mouseOverTableKey3;
	}
	/**
	 * @param mouseOverTableKey3 The mouseOverTableKey3 to set.
	 */
	public void setMouseOverTableKey3(String mouseOverTableKey3) {
		this.mouseOverTableKey3 = mouseOverTableKey3;
	}
	/**
	 * @return Returns the mouseOverTableKey4.
	 */
	public String getMouseOverTableKey4() {
		return mouseOverTableKey4;
	}
	/**
	 * @param mouseOverTableKey4 The mouseOverTableKey4 to set.
	 */
	public void setMouseOverTableKey4(String mouseOverTableKey4) {
		this.mouseOverTableKey4 = mouseOverTableKey4;
	}
	/**
	 * @return Returns the mouseOverTableKey5.
	 */
	public String getMouseOverTableKey5() {
		return mouseOverTableKey5;
	}
	/**
	 * @param mouseOverTableKey5 The mouseOverTableKey5 to set.
	 */
	public void setMouseOverTableKey5(String mouseOverTableKey5) {
		this.mouseOverTableKey5 = mouseOverTableKey5;
	}
	/**
	 * @return Returns the mouseOverTableOptionsList.
	 */
	public List getMouseOverTableOptionsList() {
		return mouseOverTableOptionsList;
	}
	/**
	 * @param mouseOverTableOptionsList The mouseOverTableOptionsList to set.
	 */
	public void addMouseOverTableOption(PickList mouseOverTableOption) {
		this.mouseOverTableOptionsList.add(mouseOverTableOption);
	}
	/**
	 * @return Returns the reportLinkKey1.
	 */
	public String getReportLinkKey1() {
		return reportLinkKey1;
	}
	/**
	 * @param reportLinkKey1 The reportLinkKey1 to set.
	 */
	public void setReportLinkKey1(String reportLinkKey1) {
		this.reportLinkKey1 = reportLinkKey1;
	}
	/**
	 * @return Returns the reportLinkKey2.
	 */
	public String getReportLinkKey2() {
		return reportLinkKey2;
	}
	/**
	 * @param reportLinkKey2 The reportLinkKey2 to set.
	 */
	public void setReportLinkKey2(String reportLinkKey2) {
		this.reportLinkKey2 = reportLinkKey2;
	}
	/**
	 * @return Returns the reportLinkKey3.
	 */
	public String getReportLinkKey3() {
		return reportLinkKey3;
	}
	/**
	 * @param reportLinkKey3 The reportLinkKey3 to set.
	 */
	public void setReportLinkKey3(String reportLinkKey3) {
		this.reportLinkKey3 = reportLinkKey3;
	}
	/**
	 * @return Returns the reportLinkKey4.
	 */
	public String getReportLinkKey4() {
		return reportLinkKey4;
	}
	/**
	 * @param reportLinkKey4 The reportLinkKey4 to set.
	 */
	public void setReportLinkKey4(String reportLinkKey4) {
		this.reportLinkKey4 = reportLinkKey4;
	}
	/**
	 * @return Returns the reportLinkKey5.
	 */
	public String getReportLinkKey5() {
		return reportLinkKey5;
	}
	/**
	 * @param reportLinkKey5 The reportLinkKey5 to set.
	 */
	public void setReportLinkKey5(String reportLinkKey5) {
		this.reportLinkKey5 = reportLinkKey5;
	}
	/**
	 * @return Returns the reportLinkOptionsList.
	 */
	public List getReportLinkOptionsList() {
		return reportLinkOptionsList;
	}
	/**
	 * @param reportLinkOptionsList The reportLinkOptionsList to set.
	 */
	public void addReportLinkOption(PickList reportLinkOption) {
		this.reportLinkOptionsList.add(reportLinkOption);
	}
	/**
	 * @return Returns the userId.
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @param userId The userId to set.
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	/**
	 * @return Returns the timeStamp.
	 */
	public MyDate getTimeStamp() {
		return timeStamp;
	}
	/**
	 * @param timeStamp The timeStamp to set.
	 */
	public void setTimeStamp(MyDate timeStamp) {
		this.timeStamp = timeStamp;
	}
	/**
	 * @return Returns the alertRuleMonthlyTimingType.
	 */
	public String getAlertRuleMonthlyTimingType() {
		return alertRuleMonthlyTimingType;
	}
	/**
	 * @param alertRuleMonthlyTimingType The alertRuleMonthlyTimingType to set.
	 */
	public void setAlertRuleMonthlyTimingType(String alertRuleMonthlyTimingType) {
		this.alertRuleMonthlyTimingType = alertRuleMonthlyTimingType;
	}
	/**
	 * @return Returns the mnthExecBillRnd.
	 */
	public String getMnthExecBillRnd() {
		return mnthExecBillRnd;
	}
	/**
	 * @param mnthExecBillRnd The mnthExecBillRnd to set.
	 */
	public void setMnthExecBillRnd(String mnthExecBillRnd) {
		this.mnthExecBillRnd = mnthExecBillRnd;
	}
	/**
	 * @return Returns the mnthExecDt.
	 */
	public String getMnthExecDt() {
		return mnthExecDt;
	}
	/**
	 * @param mnthExecDt The mnthExecDt to set.
	 */
	public void setMnthExecDt(String mnthExecDt) {
		this.mnthExecDt = mnthExecDt;
	}
	
	
	/**
	 * @return Returns the alertRuleMonthlyTimingTypeList.
	 */
	public List getAlertRuleMonthlyTimingTypeList() {
		return alertRuleMonthlyTimingTypeList;
	}
	/**
	 * @param alertRuleMonthlyTimingTypeList The alertRuleMonthlyTimingTypeList to set.
	 */
	public void setAlertRuleMonthlyTimingTypeList(List alertRuleMonthlyTimingTypeList) {
		this.alertRuleMonthlyTimingTypeList = alertRuleMonthlyTimingTypeList;
	}
	
	/**
	 * @return Returns the billRndOptions.
	 */
	public List getBillRndOptions() {
		return billRndOptions;
	}
	/**
	 * @param billRndOptions The billRndOptions to set.
	 */
	public void addBillRndOptions(String billRndOption) {
		this.billRndOptions.add(new PickList(billRndOption,billRndOption));
	}
	
	/**
	 * @return Returns the dayOptions.
	 */
	public List getDayOptions() {
		return dayOptions;
	}
	/**
	 * @param dayOptions The dayOptions to set.
	 */
	public void setDayOptions(List dayOptions) {
		this.dayOptions = dayOptions;
	}

	/**
	 * @return the allowMonthlyTimingUpdate
	 */
	public String getAllowMonthlyTimingUpdate() {
		return allowMonthlyTimingUpdate;
	}

	/**
	 * @param allowMonthlyTimingUpdate the allowMonthlyTimingUpdate to set
	 */
	public void setAllowMonthlyTimingUpdate(String allowMonthlyTimingUpdate) {
		this.allowMonthlyTimingUpdate = allowMonthlyTimingUpdate;
	}

	/**
	 * @return the alertUnitList
	 */
	public ArrayList getAlertUnitList() {
		return alertUnitList;
	}

	/**
	 * @param alertUnitList the alertUnitList to set
	 */
	public void setAlertUnitList(ArrayList alertUnitList) {
		this.alertUnitList = alertUnitList;
	}

	/**
	 * @return the stdNumDate
	 */
	public String getStdNumDate() {
		return stdNumDate;
	}

	/**
	 * @param stdNumDate the stdNumDate to set
	 */
	public void setStdNumDate(String stdNumDate) {
		this.stdNumDate = stdNumDate;
	}

	/**
	 * @return the controlPointDesc
	 */
	public String getControlPointDesc() {
		return controlPointDesc;
	}

	/**
	 * @param controlPointDesc the controlPointDesc to set
	 */
	public void setControlPointDesc(String controlPointDesc) {
		this.controlPointDesc = controlPointDesc;
	}
}
