/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.admin.alert.rule;

import java.util.ArrayList;
import java.util.List;

import org.apache.struts.action.ActionForm;

/**
 * This is a Form Bean for Alert Rule Description Main Page.
 * 
 * @author Shashank Weginwar - SW3562
 */
public class AlertRuleMainForm extends ActionForm {
	private String dispatch;					
	private List alertRuleTypeList;
	private String alertRuleType;
	private List alertRules;
	private ArrayList dataSourceList;
	private List dataSourceDescriptionList;
	private String dataSource;
	private String[] alertRuleList;
	private String alertRuleSelected;
	private String alertRuleTypeSelected;
	private String message;
	private String checkNewButton;
	
	/*
	 * Variables added for calendar page
	 */
	private String procDates;
	private String billRounds;
	private String holidayIndicators;
	private String loadedDataDates;
	
	/**
	 * @return billRounds
	 */
	public String getBillRounds() {
		return billRounds;
	}
	
	/**
	 * @param billRounds
	 */
	public void setBillRounds(String billRounds) {
		this.billRounds = billRounds;
	}
	
	/**
	 * @return holidayIndicators
	 */
	public String getHolidayIndicators() {
		return holidayIndicators;
	}
	
	/**
	 * @param holidayIndicators
	 */
	public void setHolidayIndicators(String holidayIndicators) {
		this.holidayIndicators = holidayIndicators;
	}
	
	/**
	 * @return loadedDataDates
	 */
	public String getLoadedDataDates() {
		return loadedDataDates;
	}
	
	/**
	 * 
	 * @param loadedDataDates
	 */
	public void setLoadedDataDates(String loadedDataDates) {
		this.loadedDataDates = loadedDataDates;
	}
	
	/**
	 * 
	 * @return procDates
	 */
	public String getProcDates() {
		return procDates;
	}

	/**
	 * 
	 * @param procDates
	 */
	public void setProcDates(String procDates) {
		this.procDates = procDates;
	}

	/**
	 * @return Returns the checkNewButton.
	 */
	public String getCheckNewButton() {
		return checkNewButton;
	}
	/**
	 * @param checkNewButton The checkNewButton to set.
	 */
	public void setCheckNewButton(String checkNewButton) {
		this.checkNewButton = checkNewButton;
	}
	/**
	 * @return Returns the dispatch.
	 */
	public String getDispatch() {
		return dispatch;
	}
	/**
	 * @param dispatch The dispatch to set.
	 */
	public void setDispatch(String dispatch) {
		this.dispatch = dispatch;
	}
	/**
	 * @param alertRuleType The alertRuleType to set.
	 */
	public void setAlertRuleType(String alertRuleType) {
		this.alertRuleType = alertRuleType;
	}
	/**
	 * @return Returns the alertRules.
	 */
	public List getAlertRules() {
		return alertRules;
	}
	/**
	 * @param alertRules The alertRules to set.
	 */
	public void setAlertRules(List alertRules) {
		this.alertRules = alertRules;
	}
	/**
	 * @return Returns the dataSourceDescriptionList.
	 */
	public List getDataSourceDescriptionList() {
		return dataSourceDescriptionList;
	}
	/**
	 * @param dataSourceDescriptionList The dataSourceDescriptionList to set.
	 */
	public void setDataSourceDescriptionList(
			List dataSourceDescriptionList) {
		this.dataSourceDescriptionList = dataSourceDescriptionList;
	}
	/**
	 * @param dataSourceList The dataSourceList to set.
	 */
	public void setDataSourceList(ArrayList dataSourceList) {
		this.dataSourceList = dataSourceList;
	}
	/**
	 * @return Returns the alertRuleList.
	 */
	public String[] getAlertRuleList() {
		return alertRuleList;
	}
	/**
	 * @param alertRuleList The alertRuleList to set.
	 */
	public void setAlertRuleList(String[] alertRuleList) {
		this.alertRuleList = alertRuleList;
	}
	/**
	 * @return Returns the alertRuleType.
	 */
	public String getAlertRuleType() {
		return alertRuleType;
	}	
	/**
	 * @return Returns the dataSource.
	 */
	public String getDataSource() {
		return dataSource;
	}
	/**
	 * @param dataSource The dataSource to set.
	 */
	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}
	/**
	 * @return Returns the dataSourceList.
	 */
	public ArrayList getDataSourceList() {
		return dataSourceList;
	}	
	/**
	 * @return Returns the alertRuleTypeList.
	 */
	public List getAlertRuleTypeList() {
		return alertRuleTypeList;
	}
	/**
	 * @param alertRuleTypeList The alertRuleTypeList to set.
	 */
	public void setAlertRuleTypeList(List alertRuleTypeList) {
		this.alertRuleTypeList = alertRuleTypeList;
	}	
	/**
	 * @return Returns the alertRuleSelected.
	 */
	public String getAlertRuleSelected() {
		return alertRuleSelected;
	}
	/**
	 * @param alertRuleSelected The alertRuleSelected to set.
	 */
	public void setAlertRuleSelected(String alertRuleSelected) {
		this.alertRuleSelected = alertRuleSelected;
	}	
	/**
	 * @return Returns the alertRuleTypeSelected.
	 */
	public String getAlertRuleTypeSelected() {
		return alertRuleTypeSelected;
	}
	/**
	 * @param alertRuleTypeSelected The alertRuleTypeSelected to set.
	 */
	public void setAlertRuleTypeSelected(String alertRuleTypeSelected) {
		this.alertRuleTypeSelected = alertRuleTypeSelected;
	}	
	/**
	 * @return Returns the message.
	 */
	public String getMessage() {
		return message;
	}
	/**
	 * @param message The message to set.
	 */
	public void setMessage(String message) {
		this.message = message;
	}
}
