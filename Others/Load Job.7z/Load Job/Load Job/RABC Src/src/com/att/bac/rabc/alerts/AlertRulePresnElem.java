/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts;

/**
 * This is a Data Object to represent RABC_ALERT_RULE_PRESN_ELEM table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class AlertRulePresnElem {
	private int presnId;
	private String webid;
	private int execPresnSeqNum;
	private int presnSeqNum;
	private String presnName;
	private String dataTbl;
	private int partiRefId;
	private String dataDdlName;
	private String headerLinkInd;
	private int headerLinkNum;
	private String headerDescInd;
	private int headerMouseOverNum;
	private String dataLinkInd;
	private int dataLinkNum;
	private String dataDescInd;
	private int dataMouseOverNum;
	private String graphPresnInd;
	private String presnElemTotInd;
	private String presnUnitInd;
	private String presnSumInd;
	private String databaseNode;
	private int presnCalcNum;
	private String presnSuppressInd;
	private String prevDataInd;
	private String diffDataInd;
	private String viewName;
	private String presnOrdInd;
	private String presnFormatCode;

	/**
	 * @return Returns the PresnId.
	 */
	public int getPresnId() {
		return presnId;
	}
	/**
	 * @return Returns the Webid.
	 */
	public String getWebid() {
		return webid;
	}
	/**
	 * @return Returns the ExecPresnSeqNum.
	 */
	public int getExecPresnSeqNum() {
		return execPresnSeqNum;
	}
	/**
	 * @return Returns the PresnSeqNum.
	 */
	public int getPresnSeqNum() {
		return presnSeqNum;
	}
	/**
	 * @return Returns the PresnName.
	 */
	public String getPresnName() {
		return presnName;
	}
	/**
	 * @return Returns the DataTbl.
	 */
	public String getDataTbl() {
		return dataTbl;
	}
	/**
	 * @return Returns the PartiRefId.
	 */
	public int getPartiRefId() {
		return partiRefId;
	}
	/**
	 * @return Returns the DataDdlName.
	 */
	public String getDataDdlName() {
		return dataDdlName;
	}
	/**
	 * @return Returns the HeaderLinkInd.
	 */
	public String getHeaderLinkInd() {
		return headerLinkInd;
	}
	/**
	 * @return Returns the HeaderLinkNum.
	 */
	public int getHeaderLinkNum() {
		return headerLinkNum;
	}
	/**
	 * @return Returns the HeaderDescInd.
	 */
	public String getHeaderDescInd() {
		return headerDescInd;
	}
	/**
	 * @return Returns the HeaderMouseOverNum.
	 */
	public int getHeaderMouseOverNum() {
		return headerMouseOverNum;
	}
	/**
	 * @return Returns the DataLinkInd.
	 */
	public String getDataLinkInd() {
		return dataLinkInd;
	}
	/**
	 * @return Returns the DataLinkNum.
	 */
	public int getDataLinkNum() {
		return dataLinkNum;
	}
	/**
	 * @return Returns the DataDescInd.
	 */
	public String getDataDescInd() {
		return dataDescInd;
	}
	/**
	 * @return Returns the DataMouseOverNum.
	 */
	public int getDataMouseOverNum() {
		return dataMouseOverNum;
	}
	/**
	 * @return Returns the GraphPresnInd.
	 */
	public String getGraphPresnInd() {
		return graphPresnInd;
	}
	/**
	 * @return Returns the PresnElemTotInd.
	 */
	public String getPresnElemTotInd() {
		return presnElemTotInd;
	}
	/**
	 * @return Returns the PresnUnitInd.
	 */
	public String getPresnUnitInd() {
		return presnUnitInd;
	}
	/**
	 * @return Returns the PresnSumInd.
	 */
	public String getPresnSumInd() {
		return presnSumInd;
	}
	/**
	 * @return Returns the DatabaseNode.
	 */
	public String getDatabaseNode() {
		return databaseNode;
	}
	/**
	 * @return Returns the PresnCalcNum.
	 */
	public int getPresnCalcNum() {
		return presnCalcNum;
	}
	/**
	 * @return Returns the PresnSuppressInd.
	 */
	public String getPresnSuppressInd() {
		return presnSuppressInd;
	}
	/**
	 * @return Returns the PrevDataInd.
	 */
	public String getPrevDataInd() {
		return prevDataInd;
	}
	/**
	 * @return Returns the ViewName.
	 */
	public String getViewName() {
		return viewName;
	}
	/**
	 * @return Returns the PresnOrdInd.
	 */
	public String getPresnOrdInd() {
		return presnOrdInd;
	}
	/**
	 * @return Returns the PresnFormatCode.
	 */
	public String getPresnFormatCode() {
		return presnFormatCode;
	}

	/**
	 * @param PresnId The presnId to set.
	 */
	public void setPresnId(int presnId) {
		this.presnId = presnId;
	}
	/**
	 * @param Webid The webid to set.
	 */
	public void setWebid(String webid) {
		this.webid = webid;
	}
	/**
	 * @param ExecPresnSeqNum The execPresnSeqNum to set.
	 */
	public void setExecPresnSeqNum(int execPresnSeqNum) {
		this.execPresnSeqNum = execPresnSeqNum;
	}
	/**
	 * @param PresnSeqNum The presnSeqNum to set.
	 */
	public void setPresnSeqNum(int presnSeqNum) {
		this.presnSeqNum = presnSeqNum;
	}
	/**
	 * @param PresnName The presnName to set.
	 */
	public void setPresnName(String presnName) {
		this.presnName = presnName;
	}
	/**
	 * @param DataTbl The dataTbl to set.
	 */
	public void setDataTbl(String dataTbl) {
		this.dataTbl = dataTbl;
	}
	/**
	 * @param PartiRefId The partiRefId to set.
	 */
	public void setPartiRefId(int partiRefId) {
		this.partiRefId = partiRefId;
	}
	/**
	 * @param DataDdlName The dataDdlName to set.
	 */
	public void setDataDdlName(String dataDdlName) {
		this.dataDdlName = dataDdlName;
	}
	/**
	 * @param HeaderLinkInd The headerLinkInd to set.
	 */
	public void setHeaderLinkInd(String headerLinkInd) {
		this.headerLinkInd = headerLinkInd;
	}
	/**
	 * @param HeaderLinkNum The headerLinkNum to set.
	 */
	public void setHeaderLinkNum(int headerLinkNum) {
		this.headerLinkNum = headerLinkNum;
	}
	/**
	 * @param HeaderDescInd The headerDescInd to set.
	 */
	public void setHeaderDescInd(String headerDescInd) {
		this.headerDescInd = headerDescInd;
	}
	/**
	 * @param HeaderMouseOverNum The headerMouseOverNum to set.
	 */
	public void setHeaderMouseOverNum(int headerMouseOverNum) {
		this.headerMouseOverNum = headerMouseOverNum;
	}
	/**
	 * @param DataLinkInd The dataLinkInd to set.
	 */
	public void setDataLinkInd(String dataLinkInd) {
		this.dataLinkInd = dataLinkInd;
	}
	/**
	 * @param DataLinkNum The dataLinkNum to set.
	 */
	public void setDataLinkNum(int dataLinkNum) {
		this.dataLinkNum = dataLinkNum;
	}
	/**
	 * @param DataDescInd The dataDescInd to set.
	 */
	public void setDataDescInd(String dataDescInd) {
		this.dataDescInd = dataDescInd;
	}
	/**
	 * @param DataMouseOverNum The dataMouseOverNum to set.
	 */
	public void setDataMouseOverNum(int dataMouseOverNum) {
		this.dataMouseOverNum = dataMouseOverNum;
	}
	/**
	 * @param GraphPresnInd The graphPresnInd to set.
	 */
	public void setGraphPresnInd(String graphPresnInd) {
		this.graphPresnInd = graphPresnInd;
	}
	/**
	 * @param PresnElemTotInd The presnElemTotInd to set.
	 */
	public void setPresnElemTotInd(String presnElemTotInd) {
		this.presnElemTotInd = presnElemTotInd;
	}
	/**
	 * @param PresnUnitInd The presnUnitInd to set.
	 */
	public void setPresnUnitInd(String presnUnitInd) {
		this.presnUnitInd = presnUnitInd;
	}
	/**
	 * @param PresnSumInd The presnSumInd to set.
	 */
	public void setPresnSumInd(String presnSumInd) {
		this.presnSumInd = presnSumInd;
	}
	/**
	 * @param DatabaseNode The databaseNode to set.
	 */
	public void setDatabaseNode(String databaseNode) {
		this.databaseNode = databaseNode;
	}
	/**
	 * @param PresnCalcNum The presnCalcNum to set.
	 */
	public void setPresnCalcNum(int presnCalcNum) {
		this.presnCalcNum = presnCalcNum;
	}
	/**
	 * @param PresnSuppressInd The presnSuppressInd to set.
	 */
	public void setPresnSuppressInd(String presnSuppressInd) {
		this.presnSuppressInd = presnSuppressInd;
	}
	/**
	 * @param PrevDataInd The prevDataInd to set.
	 */
	public void setPrevDataInd(String prevDataInd) {
		this.prevDataInd = prevDataInd;
	}
	/**
	 * @param ViewName The viewName to set.
	 */
	public void setViewName(String viewName) {
		this.viewName = viewName;
	}
	/**
	 * @param PresnOrdInd The presnOrdInd to set.
	 */
	public void setPresnOrdInd(String presnOrdInd) {
		this.presnOrdInd = presnOrdInd;
	}
	/**
	 * @param PresnFormatCode The presnFormatCode to set.
	 */
	public void setPresnFormatCode(String presnFormatCode) {
		this.presnFormatCode = presnFormatCode;
	}
	public String getDiffDataInd() {
		return diffDataInd;
	}
	public void setDiffDataInd(String diffDataInd) {
		this.diffDataInd = diffDataInd;
	}	
}
