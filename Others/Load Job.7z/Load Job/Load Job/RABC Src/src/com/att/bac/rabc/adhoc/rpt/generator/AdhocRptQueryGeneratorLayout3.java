/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.adhoc.rpt.generator;

import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.adhoc.aria.ARIASimpleColumnRABC;
import com.att.bac.rabc.adhoc.rpt.AdhocRptDAO;
import com.att.bac.rabc.adhoc.rpt.AdhocRptDataTO;
import com.sbc.bac.aria.ARIADataPoint;
import com.sbc.bac.aria.ARIAFunction;
import com.sbc.bac.aria.ARIASource;


/**
 * Generate an ARIA Report. Based off of AdhocRptQueryGenerator (deprecated now).
 * 
 * <p>
 * <hr>
 * <h3>Release History</h3>
 * <p>
 * <ul>
 * 
 * <li>jb6494 Aug 01, 2006 Created class.
 * <li>jb6494 Oct 16, 2006 Added sorting to outer query.
 * <li>jb6494 Mar 09, 2007 KC issue: previous data still referenced lag function
 * 
 * </ul>
 * <p>
 * 
 */
public class AdhocRptQueryGeneratorLayout3 extends AdhocRptQueryGeneratorLayout1 {

    /**
     * For layout 3 we need to add a field that computes if the row will be in the first half or the second half of the
     * year.
     * 
     * @param dto
     * @param index
     */
    protected void buildAriaSource(AdhocRptDataTO dto) {
        ARIASource source = createAriaSource(dto);

        for (int i = 0; i < getLegacy().selectClauseList.size(); i++) {
            String element = (String) getLegacy().selectClauseList.get(i);
            int lastSpace = element.lastIndexOf(' ');

            String givenName = null;
            if (lastSpace!=-1 && element.substring(lastSpace, element.length()).indexOf("CALC")!=-1) {
                givenName = element.substring(0,lastSpace).trim();
                int lastTilda = element.lastIndexOf('~');
                String calcFormula = element.substring(lastTilda + 1, element.length());
//              M148 : Calculation Fix: If calculation Formula contains / then put avg else put sum
                if(calcFormula.indexOf('/') != -1){
                	element = "*AVG " + calcFormula + " ";
                }else{
                	element = "*SUM " + calcFormula + " ";
                }
                lastSpace = element.lastIndexOf(' ');
            } else {
            	givenName = dot(getLegacy().viewTbl, element.substring(lastSpace + 1));
            }
            element = element.substring(0, lastSpace).trim();
            
            // if there is an embedded function it needs to be deciphered.
            // AVG MAX MIN COUNT SUM are translated to ARIAFunctions
            // trunc to_char ?
            ARIAFunction function = null;
            if (element.startsWith("*")) {
                if (element.toUpperCase().startsWith("*SUM")) {
                    element = element.substring(5);
                    function = ARIAFunction.inlinePlus(ARIAFunction.SUM);
                }
                if (element.toUpperCase().startsWith("*AVG")) {
                    element = element.substring(5);
                    function = ARIAFunction.inlinePlus(ARIAFunction.AVG);
                }
                if (element.toUpperCase().startsWith("*MIN")) {
                    element = element.substring(5, element.length() - 2);
                    function = ARIAFunction.inlinePlus(ARIAFunction.MIN);
                }
            }
            ARIADataPoint dp = source.createData(element, function);
            addDataPointReference(givenName, dp);
        }
    }

    /**
     * Make sure there are no "functions" tied into the field.
     * 
     * @param dp
     * @return
     */
    private String strippedColumnName(ARIADataPoint dp) {
        String r = dp.getColumn();
        while (r.indexOf('(') >= 0) {
            r = r.substring(r.indexOf('(') + 1);
        }
        int index = r.indexOf(',');
        if (index == -1) {
            index = r.indexOf(')');
        }
        return r.substring(0, index);
    }

    /**
     * @param dto
     * @param loopCount
     * @throws RABCException
     */
    protected void addARIAColumns(AdhocRptDataTO dto, int loopCount) throws RABCException {
    	if (dto.hasSubTotaling()) {
    		report.addColumn(createSubTotalColumn(dto, loopCount));
    	}else {
            report.addColumn(new ARIASimpleColumnRABC(getDP(dto, 0, "PROC_DATE"), "File Date", null, "MM/dd/yyyy", -2));
        }
    	

        if (dto.getFileSeqNumInd().equalsIgnoreCase(YES)) {
            report.addColumn(new ARIASimpleColumnRABC(getDP(dto, 0, "file_seq_num"), "Sequence Number", null, -1));
        }
        if (dto.hasSubTotaling()) {
        	getDP(dto, 0, "PROC_DATE").setSubTotalOrder(1);
            if (dto.getFileSeqNumInd().equalsIgnoreCase(YES)) {
                getDP(dto, 0, "file_seq_num").setSubTotalOrder(2);
            }
        }
        
        for (int i = 0; i < dto.getColumnsAsOracleList().size(); i++) {
            String element = (String) dto.getColumnsAsOracleList().get(i);
        	element = element.trim();
            String outputPattern = null;
            if (dto.getPresnFormatList().get(i).toString().equalsIgnoreCase("D")) {
                outputPattern = "MM/DD/YYYY";
            }
            
            ARIADataPoint dp = null;
            if (!EMPTY_STRING.equals(dto.getPresnCalcNumList().get(i).toString())) {
                int calcNum = Integer.parseInt(dto.getPresnCalcNumList().get(i).toString());
                Calculation calc = new AdhocRptDAO().getCalcElem(dto, calcNum, loopCount);
                element = calc.getPresnCalcName();
            } 
            dp = getDP(dto, i, element);
            report.addColumn(new ARIASimpleColumnRABC(dp, getColumnHeader(dto, i), null, outputPattern, i));
            setDataPointSubTotal(dto, dp, i); 
        }
    }
       
    /**
     * Add subtotaling. Note: KeyPosition is zeroBased.
     * 
     * @param dto
     * @param dp
     * @param keyPosition
     */
    protected void setDataPointSubTotal(AdhocRptDataTO dto, ARIADataPoint dp, int keyPosition) {
    	 if (dto.getUserSortColumn() == null || isNotNullEQ(dto.getUserSortColumn(), "")) {
    		 dp.setSubTotalOrder(keyPosition + 2);
    	 }
    }
}