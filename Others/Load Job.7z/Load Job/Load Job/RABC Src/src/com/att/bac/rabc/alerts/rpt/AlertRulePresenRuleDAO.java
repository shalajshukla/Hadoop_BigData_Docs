/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.rpt;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.ArrayList;
import java.text.MessageFormat;

import org.apache.log4j.Logger;

import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.RABCException;

/**
 * This is a DAO that performs SELECT, INSERT and UPDATE on RABC_ALERT_RULE_PRESN_RULE table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class AlertRulePresenRuleDAO {
	private static final Logger logger = Logger.getLogger(AlertRulePresenRuleDAO.class);

	/**
	 * Returns the list of AlertRulePresenRule objects.
	 * 
	 * @param conn 
	 * @param failures
	 * @param args
	 * @param baseSQL
	 * @return List
	 */
	public List get(Connection conn, List failures, List args, String baseSQL) {
		List alertRulePresenRuleList = null;
		AlertRulePresenRule alertRulePresenRule = null;
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		
		try
		{
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("AlertRulePresenRuleDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			alertRulePresenRuleList = new ArrayList();
			while (rs.next()) {
				alertRulePresenRuleList.add(buildAlertRulePresenRule(rs));
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return null;
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
		
		return alertRulePresenRuleList;
	}

	/**
	 * Private method to build AlertRulePresenRule object and return it to caller.
	 * 
	 * @param rs
	 * @return AlertRulePresenRule
	 * @throws SQLException
	 */
	private AlertRulePresenRule buildAlertRulePresenRule(ResultSet rs) throws SQLException {
		AlertRulePresenRule alertRulePresenRule = new AlertRulePresenRule();
		
		alertRulePresenRule.setAlertDataLinkInd(rs.getString("ALERT_DATA_LINK_IND"));
		alertRulePresenRule.setAlertDataLinkNum(rs.getInt("ALERT_DATA_LINK_NUM"));
		alertRulePresenRule.setAlertParmInd(rs.getString("ALERT_PARM_IND"));
		alertRulePresenRule.setAlertDescInd(rs.getString("ALERT_DESC_IND"));
		alertRulePresenRule.setAlertMouseOverNum(rs.getInt("ALERT_MOUSE_OVER_NUM"));
		alertRulePresenRule.setPresnId(rs.getInt("PRESN_ID"));
		alertRulePresenRule.setWebid(rs.getString("WEBID"));
		alertRulePresenRule.setExecPresnSeqNum(rs.getInt("EXEC_PRESN_SEQ_NUM"));
		alertRulePresenRule.setFileSeqNumInd(rs.getString("FILE_SEQ_NUM_IND"));
		alertRulePresenRule.setPresnDataTbl(rs.getString("PRESN_DATA_TBL"));
		alertRulePresenRule.setDataKeyLvl(rs.getInt("DATA_KEY_LVL"));
		alertRulePresenRule.setKeyDdlNameAt(0,rs.getString("KEY1_DDL_NAME"));
		alertRulePresenRule.setMainKey1Ind(rs.getString("MAIN_KEY1_IND"));
		alertRulePresenRule.setKeyHeaderAt(0,rs.getString("KEY1_HEADER"));
		alertRulePresenRule.setKeyHdLinkIndAt(0,rs.getString("KEY1_HD_LINK_IND"));
		alertRulePresenRule.setKeyHdLinkNumAt(0,rs.getInt("KEY1_HD_LINK_NUM"));
		alertRulePresenRule.setKeyHdParmIndAt(0,rs.getString("KEY1_HD_PARM_IND"));
		alertRulePresenRule.setKeyDataLinkIndAt(0,rs.getString("KEY1_DATA_LINK_IND"));
		alertRulePresenRule.setKeyDataLinkNumAt(0,rs.getInt("KEY1_DATA_LINK_NUM"));
		alertRulePresenRule.setKeyParmIndAt(0,rs.getString("KEY1_PARM_IND"));
		alertRulePresenRule.setKeyDescIndAt(0,rs.getString("KEY1_DESC_IND"));
		alertRulePresenRule.setKeyMouseOverNumAt(0,rs.getInt("KEY1_MOUSE_OVER_NUM"));
		alertRulePresenRule.setKeyDdlNameAt(1,rs.getString("KEY2_DDL_NAME"));
		alertRulePresenRule.setKeyHeaderAt(1,rs.getString("KEY2_HEADER"));
		alertRulePresenRule.setKeyHdLinkIndAt(1,rs.getString("KEY2_HD_LINK_IND"));
		alertRulePresenRule.setKeyHdLinkNumAt(1,rs.getInt("KEY2_HD_LINK_NUM"));
		alertRulePresenRule.setKeyHdParmIndAt(1,rs.getString("KEY2_HD_PARM_IND"));
		alertRulePresenRule.setKeyDataLinkIndAt(1,rs.getString("KEY2_DATA_LINK_IND"));
		alertRulePresenRule.setKeyDataLinkNumAt(1,rs.getInt("KEY2_DATA_LINK_NUM"));
		alertRulePresenRule.setKeyParmIndAt(1,rs.getString("KEY2_PARM_IND"));
		alertRulePresenRule.setKeyDescIndAt(1,rs.getString("KEY2_DESC_IND"));
		alertRulePresenRule.setKeyMouseOverNumAt(1,rs.getInt("KEY2_MOUSE_OVER_NUM"));
		alertRulePresenRule.setKeyDdlNameAt(2,rs.getString("KEY3_DDL_NAME"));
		alertRulePresenRule.setKeyHeaderAt(2,rs.getString("KEY3_HEADER"));
		alertRulePresenRule.setKeyHdLinkIndAt(2,rs.getString("KEY3_HD_LINK_IND"));
		alertRulePresenRule.setKeyHdLinkNumAt(2,rs.getInt("KEY3_HD_LINK_NUM"));
		alertRulePresenRule.setKeyHdParmIndAt(2,rs.getString("KEY3_HD_PARM_IND"));
		alertRulePresenRule.setKeyDataLinkIndAt(2,rs.getString("KEY3_DATA_LINK_IND"));
		alertRulePresenRule.setKeyDataLinkNumAt(2,rs.getInt("KEY3_DATA_LINK_NUM"));
		alertRulePresenRule.setKeyParmIndAt(2,rs.getString("KEY3_PARM_IND"));
		alertRulePresenRule.setKeyDescIndAt(2,rs.getString("KEY3_DESC_IND"));
		alertRulePresenRule.setKeyMouseOverNumAt(2,rs.getInt("KEY3_MOUSE_OVER_NUM"));
		alertRulePresenRule.setKeyDdlNameAt(3,rs.getString("KEY4_DDL_NAME"));
		alertRulePresenRule.setKeyHeaderAt(3,rs.getString("KEY4_HEADER"));
		alertRulePresenRule.setKeyHdLinkIndAt(3,rs.getString("KEY4_HD_LINK_IND"));
		alertRulePresenRule.setKeyHdLinkNumAt(3,rs.getInt("KEY4_HD_LINK_NUM"));
		alertRulePresenRule.setKeyHdParmIndAt(3,rs.getString("KEY4_HD_PARM_IND"));
		alertRulePresenRule.setKeyDataLinkIndAt(3,rs.getString("KEY4_DATA_LINK_IND"));
		alertRulePresenRule.setKeyDataLinkNumAt(3,rs.getInt("KEY4_DATA_LINK_NUM"));
		alertRulePresenRule.setKeyParmIndAt(3,rs.getString("KEY4_PARM_IND"));
		alertRulePresenRule.setKeyDescIndAt(3,rs.getString("KEY4_DESC_IND"));
		alertRulePresenRule.setKeyMouseOverNumAt(3,rs.getInt("KEY4_MOUSE_OVER_NUM"));
		alertRulePresenRule.setKeyDdlNameAt(4,rs.getString("KEY5_DDL_NAME"));
		alertRulePresenRule.setKeyHeaderAt(4,rs.getString("KEY5_HEADER"));
		alertRulePresenRule.setKeyHdLinkIndAt(4,rs.getString("KEY5_HD_LINK_IND"));
		alertRulePresenRule.setKeyHdLinkNumAt(4,rs.getInt("KEY5_HD_LINK_NUM"));
		alertRulePresenRule.setKeyHdParmIndAt(4,rs.getString("KEY5_HD_PARM_IND"));
		alertRulePresenRule.setKeyDataLinkIndAt(4,rs.getString("KEY5_DATA_LINK_IND"));
		alertRulePresenRule.setKeyDataLinkNumAt(4,rs.getInt("KEY5_DATA_LINK_NUM"));
		alertRulePresenRule.setKeyParmIndAt(4,rs.getString("KEY5_PARM_IND"));
		alertRulePresenRule.setKeyDescIndAt(4,rs.getString("KEY5_DESC_IND"));
		alertRulePresenRule.setKeyMouseOverNumAt(4,rs.getInt("KEY5_MOUSE_OVER_NUM"));
		alertRulePresenRule.setAlertDataName(rs.getString("ALERT_DATA_NAME"));
		alertRulePresenRule.setAlertHdName(rs.getString("ALERT_HD_NAME"));
		alertRulePresenRule.setAlertHdLinkInd(rs.getString("ALERT_HD_LINK_IND"));
		alertRulePresenRule.setAlertHdLinkNum(rs.getInt("ALERT_HD_LINK_NUM"));
		alertRulePresenRule.setAlertHdParmInd(rs.getString("ALERT_HD_PARM_IND"));
		return alertRulePresenRule;
	}

	/**
	 * Execute the insert or update statement on RABC_ALERT_RULE_PRESN_RULE table.
	 * 
	 * @param conn
	 * @param failures
	 * @param args
	 * @param baseSQL
	 */
	public void executeUpdate(Connection conn, List failures, List args, String baseSQL) {
		int rowsUpdated = 0;
		Statement stmt = null;
		String sqlStmt = null;
		
		try
		{
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("AlertRulePresenRuleDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rowsUpdated = stmt.executeUpdate(sqlStmt);
			logger.debug("SQL - Execution complete."+ String.valueOf(rowsUpdated) + "  rows updated");
			
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return;
		} finally {
			SQLHelper.closeStatement(stmt, failures, logger);
		}
	}

}
