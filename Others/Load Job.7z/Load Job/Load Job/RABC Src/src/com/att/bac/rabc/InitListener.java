/*
 * Module description: 
 * This class listens for application startup and shutdown events.
 * Hence all application startup info and shutdown info should go here.
 *
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 *
 * Modification History:                                     
 * SBCUID		Date			Description                         	    	
 * ------		--------		-----------
 * PD2951		20051216		Initial version for EAP 556010  
 */

package com.att.bac.rabc;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.att.carat.util.LogUtil;

public class InitListener implements ServletContextListener {
	private static Logger logger = null;
    public void contextInitialized(ServletContextEvent event) {
    	//Initialize logging
    	initLog4j(event);
    	
    	// Initialize references to singleton classes
    	RABCMessages.getRABCMessages();
    	
    	// Load side menu folder list
    	//SidemenuNodes.setSidemenuData();
    }
    
    public void contextDestroyed(ServletContextEvent event) {
    }
    
    private void initLog4j(ServletContextEvent event){
        try {
        	LogUtil.configureLogging("rabc", Level.INFO);
        	logger = Logger.getLogger(InitListener.class);
        	logger.info("initialized");
//            URL url = event.getServletContext().getResource("/WEB-INF/config/log4j.properties");
//            PropertyConfigurator.configure(url);
        } catch(Exception e){
            throw new RuntimeException("Unable to configure logging",e);
        }    	
    }
}
