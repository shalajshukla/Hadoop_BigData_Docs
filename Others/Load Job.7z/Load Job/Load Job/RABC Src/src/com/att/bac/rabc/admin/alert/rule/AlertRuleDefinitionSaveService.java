/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.admin.alert.rule;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import com.att.bac.rabc.Column;
import com.att.bac.rabc.ProgressBar;
import com.att.bac.rabc.StaticDataLoader;

/**
 * This is a service class for saving an Alert Rule.
 * 
 * @author Shashank Weginwar - SW3562
 */
public class AlertRuleDefinitionSaveService {
	private static AlertRuleDefinitionSaveService alertRuleDefinitionSaveService;
	private AlertRuleDefinitionSQLService alertRuleDefinitionSQLService;
	
	/**
	 * Returns AlertRuleDefinitionSQLService
	 * 
	 * @return AlertRuleDefinitionSQLService
	 */
	public AlertRuleDefinitionSQLService getAlertRuleDefinitionSQLService() {
		return alertRuleDefinitionSQLService;
	}
	
	/**
	 * Sets AlertRuleDefinitionSQLService.
	 * 
	 * @param alertRuleDefinitionSQLService
	 */
	public void setAlertRuleDefinitionSQLService(
			AlertRuleDefinitionSQLService alertRuleDefinitionSQLService) {
		this.alertRuleDefinitionSQLService = alertRuleDefinitionSQLService;
	}
	
	/**
	 * Synchronized method to return the instance of AlertRuleDefinitionSaveService object.
	 * It checks the existance of the instance of AlertRuleDefinitionSaveService and if it does not exists
	 * then creates one instance of AlertRuleDefinitionSaveService and returns otherwise it returns the
	 * existing instance of AlertRuleDefinitionSaveService.
	 * 
	 * @return AlertRuleDefinitionSaveService
	 */
	public static synchronized AlertRuleDefinitionSaveService getAlertRuleDefinitionSaveService(){
		if (alertRuleDefinitionSaveService == null){
			alertRuleDefinitionSaveService = new AlertRuleDefinitionSaveService();
		}	
		return alertRuleDefinitionSaveService;
	}
	
	/**
	 * Method will check for the presense of alert rule with the same name.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	public boolean checkDuplicateSave(Connection connection, List failureList, List args, AlertRuleDefinition alertRuleDefinition) {
		AlertRuleDefinitionSQLService alertRuleDefinitionSQLService = new AlertRuleDefinitionSQLService();
		boolean checkSave = false;
		checkSave = alertRuleDefinitionSQLService.getCheckSave(connection, failureList, alertRuleDefinition);
		
		return checkSave;
	}
		
	/**
	 * This is a main method which saves alert rule.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param alertRuleDefinition
	 * @param progressBar
	 * @param region
	 * @return boolean
	 */
	public boolean insert(Connection connection, List failureList, List args, AlertRuleDefinition alertRuleDefinition, ProgressBar progressBar, String region){
		int mouseOverNumArray [] = new int [5];
		int divisionKeyLvl = 0;
		int [] presnIdArr;
		int newPartiId ;
		int newPresnId=0;
		int newDashNum ;
				
		String userId = (String) args.get(0);
		String [] selectedAlertGrps = (String []) args.get(1);
		String [] relatedAlertRules = (String []) args.get(2);
		
		/*
		 * Get Division Key Level.
		 */
		divisionKeyLvl = getDivisionKeyLevel(alertRuleDefinition);
		
		/*
		 * Initialize the SQL service
		 */
		AlertRuleDefinitionSQLService alertRuleDefinitionSQLService = new AlertRuleDefinitionSQLService();
		this.setAlertRuleDefinitionSQLService(alertRuleDefinitionSQLService);
		
		String seltiming = alertRuleDefinition.getAlertRuleTiming();
		
		List ruleList = new ArrayList();
		
		int MnU = 1;
		
		if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
			if ("S".equals(seltiming)){
				MnU= 4;
				if (alertRuleDefinition.getFileSequenceIndicator()!=null && alertRuleDefinition.getThresholdExemptionCheck()!=null){
					if ("on".equals(alertRuleDefinition.getFileSequenceIndicator()) && "on".equals(alertRuleDefinition.getThresholdExemptionCheck())){
						ruleList.add("Record");
					} else {
						ruleList.add("Record");
					}
				} else {
					ruleList.add("Record");
				}
			}else if ("M".equals(seltiming)){
				MnU = 3;
				ruleList.add("Monthly");
			}else if ("B".equals(seltiming)){
				MnU = 2;
				ruleList.add("BillRound");
			}else if ("D".equals(seltiming)){
				MnU = 1;
				ruleList.add("CallDayWeek");
			}else {
				MnU= 4;
				ruleList.add("Record");
			}
		}else {
			if ("S".equals(seltiming)){
				MnU= 4;
				ruleList.add("Record");
			}else if ("M".equals(seltiming)){
				MnU = 3;
				ruleList.add("Monthly");
			}else if ("B".equals(seltiming)){
				MnU = 2;
				ruleList.add("BillRound");
			}else if ("D".equals(seltiming)){
				MnU = 1;
				ruleList.add("CallDayWeek");
			}else {
				MnU= 3;
				ruleList.add("Record");
			}
		}
	
		/*
		 * Check whether empty; if not then loop
		 */
		if (!ruleList.isEmpty()){
			String tempTiming = (String)ruleList.get(0);
			int ruleListSize = ruleList.size();
			presnIdArr = new int[ruleListSize];
			// loop through rulelist 
			for (int iteration = 0; iteration < ruleListSize; iteration++) {
				
				//Get the new parti_ref_id.
				newPartiId = this.getAlertRuleDefinitionSQLService().getNewPartiRefID(connection, failureList);
				//Get the new presnId.
				newPresnId = this.getAlertRuleDefinitionSQLService().getNewPresnId(connection, failureList);
				//Get the new dash_presn_id.
				newDashNum = this.getAlertRuleDefinitionSQLService().getNewDashNum(connection, failureList);

				tempTiming = (String)ruleList.get(iteration);
				
				if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
					/*
					 * Insert into RABC_ALERT_RULE table for track.
					 */
					if (!insertAlertRuleTrack(connection, failureList, tempTiming, newPartiId,newPresnId, divisionKeyLvl, alertRuleDefinition, userId)){
						return false;
					}
				} else {
					/*
					 * Insert into RABC_ALERT_RULE table for trend.
					 */
					if (!insertAlertRuleTrend(connection, failureList, tempTiming, newPartiId, newPresnId, divisionKeyLvl, alertRuleDefinition, userId)){
						return false;
					}
				}
				progressBar.setProgressPercent(20);
				
				/*
				 * Insert into RABC_PRESN_ID table.
				 */
				if (!insertPresnId(connection, failureList, alertRuleDefinition, tempTiming, iteration, newPresnId, divisionKeyLvl)){
					return false;
				}
				
				/*
				 * Insert into RABC_TRACK_FILE_DTL table.
				 */
				if(!insertTrackFileDtl(connection, failureList, alertRuleDefinition, tempTiming)){
					return false;
				}
				progressBar.setProgressPercent(30);
				
				/*
				 * Insert into RABC_TRIG_CONVERT table.
				 */
				if(!insertTrigConvert(connection, failureList, alertRuleDefinition, tempTiming)){
					return false;
				}
				
				/*
				 * Insert into RABC_EXTRCT_BUILD_RULE table.
				 */
				if(!insertExtrctBuildRule(connection, failureList, tempTiming, newPartiId, alertRuleDefinition)){
					return false;
				}
				
				if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
					/*
					 * Insert into RABC_AVG_TBL_DEF table for track.
					 */
					if(!insertAvgTblDef(connection, failureList, tempTiming, newPartiId, alertRuleDefinition)){
						return false;
					}
				}
				progressBar.setProgressPercent(40);
				
				/*
				 * Insert into RABC_EXTRCT_TBL_DEF table.
				 */
				if(!insertExtrctTblDef(connection, failureList, tempTiming, newPartiId, divisionKeyLvl, alertRuleDefinition)){
					return false;
				}

				/*
				 * Insert into RABC_UPDATE_GRP table.
				 */
				if(!insertAlertGroup(connection, failureList, selectedAlertGrps, alertRuleDefinition, tempTiming)){
					return false;
				}
				
				/*
				 * Insert into RABC_ALERT_PROC table.
				 */
				if(!insertAlertProc(connection, failureList, tempTiming, newPartiId, alertRuleDefinition)){
					return false;
				}
				progressBar.setProgressPercent(50);

				/*
				 * Insert into RABC_AVG_CALC table.
				 */
				if(!insertAvgCalc(connection, failureList, tempTiming, newPartiId, alertRuleDefinition)){
					return false;
				}

				/*
				 * Update RABC_CNTRL_PT_ALERT table.
				 */
				if(!updateCntrlPtAlert(connection, failureList, tempTiming, newDashNum, alertRuleDefinition)){
					return false;
				}

				/*
				 * Insert into RABC_PROC_RESPONSIBLE table.
				 */
				if(!insertProcResponsible(connection, failureList, tempTiming, alertRuleDefinition, selectedAlertGrps)){
					return false;
				}
				progressBar.setProgressPercent(60);

				/*
				 * Counter to indicate the starting link number for report links defined for columns in case of trending rules
				 */
				if (iteration==0){
					/*
					 * Insert into RABC_MOUSE_OVER_LINK table.
					 */ 
					if(!insertMouseOverLink(connection, failureList, newPresnId, alertRuleDefinition, mouseOverNumArray)){
						return false;
					}
					
					if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
						/*
						 * Insert into RABC_WEB_DATA_LINK table for track.
						 */
						if(!insertWebDataLinkForTrack(connection, failureList, newPresnId, divisionKeyLvl, alertRuleDefinition)){
							return false;
						}
					} else {
						/*
						 * Insert into RABC_WEB_DATA_LINK table for trend.
						 */
						if(!insertWebDataLinkForTrend(connection, failureList, newPresnId, divisionKeyLvl, alertRuleDefinition)){
							return false;
						}
					}
				}
				
				if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
					/*
					 * Insert RABC_ALERT_RULE_PRESN_ELEM table for track.
					 */
					if(!insertAlertRulePresenElemTrack(connection, failureList, newPresnId, newPartiId, alertRuleDefinition, region)){
						return false;
					}
				}else {
					/*
					 * Insert RABC_ALERT_RULE_PRESN_ELEM table for trend.
					 */
					if(!insertAlertRulePresenElemTrend(connection, failureList, newPresnId, newPartiId, alertRuleDefinition, region)){
						return false;
					}
				}
				progressBar.setProgressPercent(70);
				
				if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
					/*
					 * Insert RABC_ALERT_RULE_PRESN_RULE table for track.
					 */					
					if(!insertAlertRulePresnRuleTrack(connection, failureList, alertRuleDefinition, tempTiming, divisionKeyLvl, newPresnId, mouseOverNumArray)){
						return false;
					}
				}else {
					/*
					 * Insert RABC_ALERT_RULE_PRESN_RULE table for trend.
					 */
					if(!insertAlertRulePresnRuleTrend(connection, failureList, alertRuleDefinition, tempTiming, newPresnId, divisionKeyLvl, mouseOverNumArray)){
						return false;
					}
				}
				
				/*
				 * Insert into RABC_MENU_INDEX table.
				 */
				if(!insertMenuIndex(connection, failureList, tempTiming, newPresnId, alertRuleDefinition, MnU, iteration)){
					return false;
				}
				
				/*
				 * Insert into RABC_STD_CALC table.
				 */
				if(!insertStdCalc(connection, failureList, tempTiming, newPartiId, alertRuleDefinition)){
					return false;
				}
				progressBar.setProgressPercent(80);
				
				if ("Trend".equals(alertRuleDefinition.getAlertRuleType())){
					// Call the method to update mouse over count
				}
				
				if (iteration==0){
					/*
					 * Insert into RABC_WEB_HEADER_LINK table.
					 */
					if(!insertWebHeaderLink(connection, failureList, tempTiming, newPresnId, alertRuleDefinition)){
						return false;
					}
				}
				
				/*
				 * Insert into RABC_PRESN_HEADER table.
				 */ 
				if(!insertPresnHeader(connection, failureList, newPresnId, tempTiming, alertRuleDefinition)){
					return false;
				}
				
				presnIdArr[iteration]= newPresnId;
				
				/*
				 * Insert into RABC_ALERT_SUPP_RULE table.
				 */
				if (!insertSuppRule(connection, failureList, tempTiming, newPartiId, alertRuleDefinition)){
					return false;
				}
				progressBar.setProgressPercent(90);
			}
			 
			if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
				/*
				 * Insert into RABC_ALERT_SUMY_PRESN table for track.
				 */
				if(!insertSumyPresnTrack(connection, failureList, tempTiming, relatedAlertRules, alertRuleDefinition, newPresnId, presnIdArr, ruleList)){
					return false;
				}
			} else {
				/*
				 * Insert into RABC_ALERT_SUMY_PRESN table for trend.
				 */
				if(!insertSumyPresnTrend(connection, failureList, tempTiming, relatedAlertRules, alertRuleDefinition, newPresnId, presnIdArr, ruleList)){
					return false;
				}
			}
		}
		return true;
	}
	

	/**
	 * Returns division key level.
	 * 
	 * @param alertRuleDefinition
	 * @return int
	 */
	private int getDivisionKeyLevel(AlertRuleDefinition alertRuleDefinition){
		int divisionKeyLvl = 0;
		int alertKeyListSize = alertRuleDefinition.getAlertKeyList().size();
		String check = null;
		for(int i = 0; i < alertKeyListSize; i++){
			if(alertRuleDefinition.getAlertKeyLevel() >= 1){
				check = ((AlertKey)((alertRuleDefinition.getAlertKeyList()).get(i))).getKey1();
				if("DIVISION".equals(check)){
					divisionKeyLvl = 1;
				}
			}
			if(alertRuleDefinition.getAlertKeyLevel() >= 2){
				check = ((AlertKey)((alertRuleDefinition.getAlertKeyList()).get(i))).getKey2();
				if("DIVISION".equals(check)){
					divisionKeyLvl = 2;
				}
			}
			if(alertRuleDefinition.getAlertKeyLevel() >= 3){
				check = ((AlertKey)((alertRuleDefinition.getAlertKeyList()).get(i))).getKey3();
				if("DIVISION".equals(check)){
					divisionKeyLvl = 3;
				}
			}
			if(alertRuleDefinition.getAlertKeyLevel() >= 4){
				check = ((AlertKey)((alertRuleDefinition.getAlertKeyList()).get(i))).getKey4();
				if("DIVISION".equals(check)){
					divisionKeyLvl = 4;
				}
			}
			if(alertRuleDefinition.getAlertKeyLevel() >= 5){
				check = ((AlertKey)((alertRuleDefinition.getAlertKeyList()).get(i))).getKey5();
				if("DIVISION".equals(check)){
					divisionKeyLvl = 5;
				}
			}
		}
		return divisionKeyLvl; 
	}
	
	/**
	 * Inserts Data into RABC_ALERT_RULE table for a track rule.
	 * 
	 * @param connection
	 * @param failureList
	 * @param tempTiming
	 * @param newPartId
	 * @param newPresnId
	 * @param divisionKeyLvl
	 * @param alertRuleDefinition
	 * @param userId
	 * @return boolean
	 */
	private boolean insertAlertRuleTrack(Connection connection, List failureList, String tempTiming, int newPartId, int newPresnId, int divisionKeyLvl, AlertRuleDefinition alertRuleDefinition, String userId){
		List args = new ArrayList();
		String ruleName;
		boolean success= true;
		int alertKeyLevel = 0;
		int pickSql = 1;
		
		if ("DT".equals(tempTiming)){
			ruleName = alertRuleDefinition.getAlertRule() + "-DAILY";
		}else {
			ruleName = alertRuleDefinition.getAlertRule();
		}
		
		args.add(ruleName);
				
		String msgInd;
		String dashFreshInd;
		String rulePresnInd;
		
		if ("Record".equals(tempTiming)){
			msgInd = "Y";
			dashFreshInd = "Y";
			rulePresnInd = "Y";
		}else if ("BillRound".equals(tempTiming)){
			msgInd= "Y";
			dashFreshInd = "Y";
			rulePresnInd = "Y";
		}else if ("CallDayWeek".equals(tempTiming)) {
			msgInd= "Y";
			dashFreshInd = "Y";
			rulePresnInd = "Y";	
		}else if ("Monthly".equals(tempTiming)) {
			msgInd= "Y";
			dashFreshInd = "Y";
			rulePresnInd = "Y";
		}else {
			msgInd= "N";
			dashFreshInd = "N";
			rulePresnInd = "N";	
		}
		
		args.add(Integer.toString(newPresnId)); 
		args.add(msgInd);
		if ("DT".equals(tempTiming)){
			args.add("N"); 
		} else {
			if ("on".equals(alertRuleDefinition.getFileSequenceIndicator())){  
				args.add("Y");
			} else {
				args.add("N");
			}
		}
		
		if ("Record".equals(tempTiming)){
			String var = null;
			args.add(var);
		} else if ("Monthly".equals(tempTiming)){
			args.add("'M'");
		} else if ("BillRound".equals(tempTiming)){
			args.add("'B'");
		}else {
			args.add("'D'");
		}
		
		args.add(dashFreshInd);  
		args.add(alertRuleDefinition.getAlertRuleDescription()); 
				
		if ("DT".equals(tempTiming)){
			args.add(Integer.toString(1200)); 
			args.add(Integer.toString(divisionKeyLvl)); 
			alertKeyLevel = divisionKeyLvl; 
		} else {
			if (alertRuleDefinition.getDelayExecutionTime()==-1){
				pickSql = 2;
			}else {
				args.add(Integer.toString(alertRuleDefinition.getDelayExecutionTime()));   
			}
			args.add(Integer.toString(alertRuleDefinition.getAlertKeyLevel())); 
			alertKeyLevel = alertRuleDefinition.getAlertKeyLevel();
		}
	
		if(alertKeyLevel >= 1){
			args.add("ALERT_KEY1"); 
		}else{	
			args.add("");
		}
		if(alertKeyLevel >= 2){
			args.add("ALERT_KEY2");  
		} else {
			args.add("");
		}
		if(alertKeyLevel >= 3){
			args.add("ALERT_KEY3");  
		} else {
			args.add("");
		}
		if(alertKeyLevel >= 4){
			args.add("ALERT_KEY4");
		} else {
			args.add("");
		}
		if(alertKeyLevel >= 5){
			args.add("ALERT_KEY5"); 
		} else {
			args.add("");
		}
	
		int sizeOfLHS = alertRuleDefinition.getLHSColumnsList().size();
		int sizeOfRHS = alertRuleDefinition.getRHSColumnsList().size();
		int tableItemsCount = sizeOfLHS + sizeOfRHS;
		
		args.add(Integer.toString(tableItemsCount));
		args.add(rulePresnInd); 
		args.add(Integer.toString(divisionKeyLvl));  
		args.add(alertRuleDefinition.getDbNodeId()); 
		args.add(alertRuleDefinition.getEffectiveDate()); 
	
		if ("on".equals(alertRuleDefinition.getThresholdExemptionCheck())){
			args.add("Y");
		}else {
			args.add("N");
		}

		args.add(userId);  
		args.add(Integer.toString(newPartId)); 
		
		if (alertRuleDefinition.getAlertDataKeep()==-1){
			args.add("");
		}else {
			args.add(Integer.toString(alertRuleDefinition.getAlertDataKeep()));
		}
		
		if ("Monthly".equals(tempTiming)) {
			if ("B".equals(alertRuleDefinition.getAlertRuleMonthlyTimingType())){
				args.add("");
				args.add(alertRuleDefinition.getMnthExecBillRnd());
			}else {
				args.add(alertRuleDefinition.getMnthExecDt());
				args.add("");
			}
		} else {
			args.add("");
			args.add("");
		}
		
		success = this.getAlertRuleDefinitionSQLService().insertAlertRule(connection, failureList, args, alertRuleDefinition,pickSql);
	
		return success;
	}
	
	/**
	 * Inserts Data into RABC_ALERT_RULE table for a trend rule.
	 * 
	 * @param connection
	 * @param failureList
	 * @param tempTiming
	 * @param newPartId
	 * @param newPresnId
	 * @param divisionKeyLvl
	 * @param alertRuleDefinition
	 * @param userId
	 * @return boolean
	 */
	private boolean insertAlertRuleTrend(Connection connection, List failureList, String tempTiming, int newPartId, int newPresnId, int divisionKeyLvl, AlertRuleDefinition alertRuleDefinition, String userId){
		List args = new ArrayList();
		String ruleName;
		boolean success = true;
		int alertKeyLevel = 0;
		int pickSql = 1;
		
		alertRuleDefinition.setDataSource("RABC");
		
		if ("DT".equals(tempTiming)){
			ruleName = alertRuleDefinition.getAlertRule() + "-DAILY";
		}else {
			ruleName = alertRuleDefinition.getAlertRule();
		}
		
		args.add(ruleName); 
		
		String msgInd;
		String dashFreshInd;
		String rulePresnInd;
		
		if ("Record".equals(tempTiming)){
			msgInd = "Y";
			dashFreshInd = "Y";
			rulePresnInd = "Y";
		}else if ("BillRound".equals(tempTiming)){
			msgInd= "Y";
			dashFreshInd = "Y";
			rulePresnInd = "Y";
		}else if ("CallDayWeek".equals(tempTiming)) {
			msgInd= "Y";
			dashFreshInd = "Y";
			rulePresnInd = "Y";
		}else if ("Monthly".equals(tempTiming)) {
			msgInd= "Y";
			dashFreshInd = "Y";
			rulePresnInd = "Y";
		}else {
			msgInd= "N";
			dashFreshInd = "N";
			rulePresnInd = "N";	
		}

		args.add(Integer.toString(newPresnId)); 
		args.add(msgInd); 

		if ("DT".equals(tempTiming)){
			args.add("N");
		} else {
			if ("on".equals(alertRuleDefinition.getFileSequenceIndicator())){
				args.add("Y");
			} else {
				args.add("N");
			}
		}

		if ("Record".equals(tempTiming)){
			String var = null;
			args.add(var);
		}else if ("Monthly".equals(tempTiming)){
			args.add("'M'");
		} else if ("BillRound".equals(tempTiming)){
			args.add("'B'");
		}else {
			args.add("'D'");
		}

		args.add(dashFreshInd); 
		args.add(alertRuleDefinition.getAlertRuleDescription()); 

		if ("DT".equals(tempTiming)){
			args.add(Integer.toString(1200)); 
			args.add(Integer.toString(divisionKeyLvl)); 
			alertKeyLevel = divisionKeyLvl; 
		} else {
			if (alertRuleDefinition.getDelayExecutionTime()==-1){
				pickSql = 2;
			}else {
				args.add(Integer.toString(alertRuleDefinition.getDelayExecutionTime()));   
			}
			args.add(Integer.toString(alertRuleDefinition.getAlertKeyLevel()));
			alertKeyLevel = alertRuleDefinition.getAlertKeyLevel();
		}
	
		if(alertKeyLevel >= 1){
			args.add("ALERT_KEY1"); 
		} else {
			args.add("");
		}
		if(alertKeyLevel >= 2){
			args.add("ALERT_KEY2"); 
		} else {
			args.add("");
		}
		if(alertKeyLevel >= 3){
			args.add("ALERT_KEY3"); 
		} else {
			args.add("");
		}
		if(alertKeyLevel >= 4){
			args.add("ALERT_KEY4");
		} else {
			args.add("");
		}
		if(alertKeyLevel >= 5){
			args.add("ALERT_KEY5");
		} else {
			args.add("");
		}

		args.add(rulePresnInd);
		args.add(Integer.toString(divisionKeyLvl));
		args.add(alertRuleDefinition.getDbNodeId());
		args.add(alertRuleDefinition.getEffectiveDate());
		
		if ("on".equals(alertRuleDefinition.getThresholdExemptionCheck())){
			args.add("Y");
		}else {
			args.add("N");
		}

		args.add(userId); 
		args.add(Integer.toString(newPartId));
		if (alertRuleDefinition.getAlertDataKeep()==-1){
			args.add("");
		}else {
			args.add(Integer.toString(alertRuleDefinition.getAlertDataKeep()));
		}
		if ("Monthly".equals(tempTiming)) {
			if ("B".equals(alertRuleDefinition.getAlertRuleMonthlyTimingType())){
				args.add("");
				args.add(alertRuleDefinition.getMnthExecBillRnd());
			}else {
				args.add(alertRuleDefinition.getMnthExecDt());
				args.add("");
			}
		} else {
			args.add("");
			args.add("");
		}
		success = this.getAlertRuleDefinitionSQLService().insertAlertRule(connection, failureList, args, alertRuleDefinition,pickSql);
		return success;
	}
		
	/**
	 * Inserts Data into RABC_PRESN_ID table for trend and track rules.
	 * 
	 * @param connection
	 * @param failureList
	 * @param alertRuleDefinition
	 * @param tempTiming
	 * @param iteration
	 * @param newPresnId
	 * @param divisionKeyLvl
	 * @return boolean
	 */ 
	private boolean insertPresnId(Connection connection, List failureList, AlertRuleDefinition alertRuleDefinition, String tempTiming, int iteration, int newPresnId, int divisionKeyLvl){
		List args = new ArrayList();
		String ruleName;
		boolean success = true;

		if ("DT".equals(tempTiming)){
			ruleName = alertRuleDefinition.getAlertRule() + "-DAILY";
		}else {
			ruleName = alertRuleDefinition.getAlertRule();
		}
		args.add(ruleName);

		args.add(Integer.toString(divisionKeyLvl));
		if ("Trend".equals(alertRuleDefinition.getAlertRuleType()) || "2".equals(alertRuleDefinition.getAlertRuleType())){
			args.add(Integer.toString(iteration+1));
		}
		
		args.add(alertRuleDefinition.getEffectiveDate());
		
		if ("Record".equals(tempTiming)){
			String var = null;
			args.add(var);
			args.add("'5'");
		}else if ("BillRound".equals(tempTiming)){
			args.add("'B'");
			args.add("'2'");
		}else if ("Monthly".equals(tempTiming)) {
			args.add("'M'");
			args.add("'3'");
		}else {
			args.add("'D'");
			args.add("'1'");
		}
	
		args.add(Integer.toString(newPresnId));
		args.add(alertRuleDefinition.getDbNodeId());
		
		success = this.getAlertRuleDefinitionSQLService().insertPresnId(connection, failureList, args, alertRuleDefinition);
		return success;
	}
	
	/**
	 * Inserts Data into RABC_TRACK_FILE_DTL table for trend and track rules.
	 * 
	 * @param connection
	 * @param failureList
	 * @param alertRuleDefinition
	 * @param tempTiming
	 * @return boolean
	 */
	private boolean insertTrackFileDtl(Connection connection, List failureList, AlertRuleDefinition alertRuleDefinition, String tempTiming){	
		String ruleName;
		boolean success = true;

		if ("DT".equals(tempTiming)){
			ruleName = alertRuleDefinition.getAlertRule() + "-DAILY";
		}else {
			ruleName = alertRuleDefinition.getAlertRule();
		}

		List leftColumnList = alertRuleDefinition.getLHSColumnsList();
		List rightColumnList = alertRuleDefinition.getRHSColumnsList();
		int leftColumnListSize = leftColumnList.size();
		int rightColumnListSize = rightColumnList.size();
		int alertKeyLevel = alertRuleDefinition.getAlertKeyLevel();
		List alertKeyList = alertRuleDefinition.getAlertKeyList();
		
		if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
			for (int i=0;i<leftColumnListSize;i++){
				List args = new ArrayList();
				
				Column column = (Column)leftColumnList.get(i);
				AlertKey alertKey = (AlertKey)alertKeyList.get(i);
				
				args.add(ruleName);
				if(alertKey.getFileId()!= null && !alertKey.getFileId().equals("")){
					args.add(alertKey.getFileId());
				} else {
					args.add("none");
				}
				args.add("L");
				args.add("Y");
				if (column.getColumnViewName()!=null){
					args.add(column.getColumnViewName());
				}else {
					args.add(column.getColumnAlertProcTBL());
				}
				args.add(Integer.toString(alertRuleDefinition.getAlertKeyLevel()));

				if (alertKey.getKey1()!=null && alertKeyLevel >= 1){
					args.add(alertKey.getKey1());
				}else {
					args.add("");
				}
				if (alertKey.getKey2()!=null && alertKeyLevel >= 2){
					args.add(alertKey.getKey2());
				}else {
					args.add("");
				}
				if (alertKey.getKey3()!=null && alertKeyLevel >= 3){
					args.add(alertKey.getKey3());
				}else {
					args.add("");
				}
				if (alertKey.getKey4()!=null && alertKeyLevel >= 4){
					args.add(alertKey.getKey4());
				}else {
					args.add("");
				}
				if (alertKey.getKey5()!=null && alertKeyLevel >= 5){
					args.add(alertKey.getKey5());
				}else {
					args.add("");
				}
				
				int alertItemDataCnt = alertRuleDefinition.getAlertItemList().size();
				args.add(Integer.toString(alertItemDataCnt));
				
				List alertItemList = alertRuleDefinition.getAlertItemList();
				int alertItemListSize = alertItemList.size();
				for (int j = 0; j < alertItemListSize; j++){
					AlertItem alertItem = (AlertItem)alertItemList.get(j);
					Column itemColumn = (Column) alertItem.getColumnList().get(i);
					args.add(itemColumn.getColumnTBLDDLName());
					args.add(Integer.toString(0));
					// Code added to cater for additional column in table namely ALERT_ITEM*_DDL_NAME_IND
					if ("CAL".equalsIgnoreCase(itemColumn.getColumnTBLDataType())){
						args.add("C");
					}else {
						args.add("");
					}
				}
				for (int j=alertItemListSize+1;j<=15;j++){
					args.add("");
					args.add("");
					// Code added to cater for additional column in table namely ALERT_ITEM*_DDL_NAME_IND
					args.add("");
				}
				
				if (column.getColumnViewName()!= null){
					args.add(column.getColumnViewName());
				}else {
					args.add("");
				}
				
				args.add(Integer.toString(i + 1));
				success =  this.getAlertRuleDefinitionSQLService().insertTrackFileDtl(connection,failureList, args, alertRuleDefinition);
			}
			for (int i = 0; i < rightColumnListSize; i++){
				List args = new ArrayList();
				
				Column column = (Column)rightColumnList.get(i);
				AlertKey alertKey = (AlertKey)alertKeyList.get(leftColumnListSize+i);
				
				args.add(ruleName);
				if(alertKey.getFileId()!= null && !alertKey.getFileId().equals("")){
					args.add(alertKey.getFileId());
				} else {
					args.add("none");
				}
				args.add("R");
				args.add(""); 
				if (column.getColumnViewName()!=null){
					args.add(column.getColumnViewName());
				}else {
					args.add(column.getColumnAlertProcTBL());
				}
				
				args.add(Integer.toString(alertRuleDefinition.getAlertKeyLevel()));
				
				if (alertKey.getKey1()!=null && alertKeyLevel >= 1){
					args.add(alertKey.getKey1());
				}else {
					args.add("");
				}
				if (alertKey.getKey2()!=null && alertKeyLevel >= 2){
					args.add(alertKey.getKey2());
				}else {
					args.add("");
				}
				if (alertKey.getKey3()!=null && alertKeyLevel >= 3){
					args.add(alertKey.getKey3());
				}else {
					args.add("");
				}
				if (alertKey.getKey4()!=null && alertKeyLevel >= 4){
					args.add(alertKey.getKey4());
				}else {
					args.add("");
				}
				if (alertKey.getKey5()!=null && alertKeyLevel >= 5){
					args.add(alertKey.getKey5());
				}else {
					args.add("");
				}
				
				int alertItemDataCnt = alertRuleDefinition.getAlertItemList().size();
				args.add(Integer.toString(alertItemDataCnt));
				
				List alertItemList = alertRuleDefinition.getAlertItemList();
				int alertItemListSize = alertItemList.size();
				for (int j=0;j<alertItemListSize;j++){
					AlertItem alertItem = (AlertItem)alertItemList.get(j);
					Column itemColumn = (Column) alertItem.getColumnList().get(leftColumnListSize+i);
					args.add(itemColumn.getColumnTBLDDLName());
					args.add(Integer.toString(0));
					// Code added to cater for additional column in table namely ALERT_ITEM*_DDL_NAME_IND
					if ("CAL".equalsIgnoreCase(itemColumn.getColumnTBLDataType())){
						args.add("C");
					}else {
						args.add("");
					}
				}
				for (int j=alertItemListSize+1;j<=15;j++){
					args.add("");
					args.add("");
					// Code added to cater for additional column in table namely ALERT_ITEM*_DDL_NAME_IND
					args.add("");
				}
				if (column.getColumnViewName()!=null){
					args.add(column.getColumnViewName());
				}else {
					args.add("");
				}
				
				args.add(Integer.toString(leftColumnListSize + i + 1));
				success =  this.getAlertRuleDefinitionSQLService().insertTrackFileDtl(connection,failureList, args, alertRuleDefinition);
			}
		} else {
			//For Trend.
			List args = new ArrayList(); 
			Column column = (Column)leftColumnList.get(0);
			AlertKey alertKey = (AlertKey)alertKeyList.get(0);
			
			args.add(ruleName);
			if(alertKey.getFileId()!= null && !alertKey.getFileId().equals("")){
				args.add(alertKey.getFileId());
			} else {
				args.add("none");
			}
			if (column.getColumnViewName()!=null){
				args.add(column.getColumnViewName());
			}else {
				args.add(column.getColumnAlertProcTBL());
			}
			args.add(Integer.toString(alertRuleDefinition.getAlertKeyLevel()));

			if (alertKey.getKey1()!=null && alertKeyLevel >= 1){
				args.add(alertKey.getKey1());
			}else {
				args.add("");
			}
			if (alertKey.getKey2()!=null && alertKeyLevel >= 2){
				args.add(alertKey.getKey2());
			}else {
				args.add("");
			}
			if (alertKey.getKey3()!=null && alertKeyLevel >= 3){
				args.add(alertKey.getKey3());
			}else {
				args.add("");
			}
			if (alertKey.getKey4()!=null && alertKeyLevel >= 4){
				args.add(alertKey.getKey4());
			}else {
				args.add("");
			}
			if (alertKey.getKey5()!=null && alertKeyLevel >= 5){
				args.add(alertKey.getKey5());
			}else {
				args.add("");
			}
			
			int alertItemDataCnt = alertRuleDefinition.getAlertItemList().size();
			args.add(Integer.toString(alertItemDataCnt));
			
			List alertItemList = alertRuleDefinition.getAlertItemList();
			int alertItemListSize = alertItemList.size();
			for (int j=0;j<alertItemListSize;j++){
				AlertItem alertItem = (AlertItem)alertItemList.get(j);
				Column itemColumn = (Column) alertItem.getColumnList().get(0);
				args.add(itemColumn.getColumnTBLDDLName());
				args.add(Integer.toString(0));
				// Code added to cater for additional column in table namely ALERT_ITEM*_DDL_NAME_IND
				if ("CAL".equalsIgnoreCase(itemColumn.getColumnTBLDataType())){
					args.add("C");
				}else {
					args.add("");
				}
			}
			for (int j=alertItemListSize+1;j<=15;j++){
				args.add("");
				args.add("");
				// Code added to cater for additional column in table namely ALERT_ITEM*_DDL_NAME_IND
				args.add("");
			}						
			if (column.getColumnViewName()!=null){
				args.add(column.getColumnViewName());
			}else {
				args.add("");
			}
			args.add(Integer.toString(0));
			success =  this.getAlertRuleDefinitionSQLService().insertTrackFileDtl(connection,failureList, args, alertRuleDefinition);
		}
		return success;	
	}
	
	/**
	 * Inserts Data into RABC_TRIG_CONVERT table for trend and track rules.
	 * 
	 * PMT 284847: Modification so as to ensure FILE_ID for an alert rule is unique 
	 * 
	 * @param connection
	 * @param failureList
	 * @param alertRuleDefinition
	 * @param tempTiming
	 * @return boolean
	 */
	private boolean insertTrigConvert(Connection connection, List failureList, AlertRuleDefinition alertRuleDefinition, String tempTiming){
		String ruleName;
		String runFreqInd;
		boolean success = true;
		
		if ("DT".equals(tempTiming)){
			ruleName = alertRuleDefinition.getAlertRule() + "-DAILY";
		}else {
			ruleName = alertRuleDefinition.getAlertRule();
		}

		if ("Record".equals(tempTiming)){
			runFreqInd = "D";
		}else if ("BillRound".equals(tempTiming)){
			runFreqInd = "";
		}else if ("Monthly".equals(tempTiming)) {
			runFreqInd = "M";
		}else if ("CallDayWeek".equals(tempTiming)) {
			runFreqInd = "";
		}else {
			runFreqInd = "";
		}
		
		List leftColumnList = alertRuleDefinition.getLHSColumnsList();
		List rightColumnList = alertRuleDefinition.getRHSColumnsList();
		int leftColumnListSize = leftColumnList.size();
		int rightColumnListSize = rightColumnList.size();
		
		List alertKeyList = alertRuleDefinition.getAlertKeyList();
		
		if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
			List fileIdList = new ArrayList();
			
			for (int i = 0; i < leftColumnListSize; i++){
				List args = new ArrayList();
				String fileId = "none";
				Column column = (Column)leftColumnList.get(i);
				AlertKey alertKey = (AlertKey)alertKeyList.get(i);
				
				if(alertKey.getFileId()!= null && !alertKey.getFileId().equals("")){
					fileId = alertKey.getFileId();
				} 
				
				/*
				 * Add the entry to the table only if the FILE_ID has not been inserted already for this Alert Rule
				 */
				if (fileIdList.isEmpty() || !fileIdList.contains(fileId)){
					fileIdList.add(fileId);
					args.add(fileId);
					args.add(ruleName);
					args.add(runFreqInd);
					if ("Monthly".equals(tempTiming)) {
						if ("B".equals(alertRuleDefinition.getAlertRuleMonthlyTimingType())){
							args.add(alertRuleDefinition.getMnthExecBillRnd());
						}else {
							args.add(alertRuleDefinition.getMnthExecDt());
						}
					}else {
						args.add("0");
					}
					success = this.getAlertRuleDefinitionSQLService().insertTrigConvert(connection,failureList,args,alertRuleDefinition);
				}
			}			
			for (int i = 0; i < rightColumnListSize; i++){
				List args = new ArrayList();
				String fileId = "none";
				Column column = (Column)rightColumnList.get(i);
				AlertKey alertKey = (AlertKey)alertKeyList.get(leftColumnListSize+i);

				if(!alertKey.getFileId().equals(null) && !alertKey.getFileId().equals("")){
					fileId = alertKey.getFileId();
				} 
				
				/*
				 * Add the entry to the table only if the FILE_ID has not been inserted already for this Alert Rule
				 */
				if (fileIdList.isEmpty() || !fileIdList.contains(fileId)){
					fileIdList.add(fileId);
					args.add(fileId);
					args.add(ruleName);
					args.add(runFreqInd);
					if ("Monthly".equals(tempTiming)) {
						if ("B".equals(alertRuleDefinition.getAlertRuleMonthlyTimingType())){
							args.add(alertRuleDefinition.getMnthExecBillRnd());
						}else {
							args.add(alertRuleDefinition.getMnthExecDt());
						}
					}else {
						args.add("0");
					}
					success = this.getAlertRuleDefinitionSQLService().insertTrigConvert(connection,failureList,args,alertRuleDefinition);
				}
			}
		} else {
			List args = new ArrayList();
			
			Column column = (Column)leftColumnList.get(0);
			AlertKey alertKey = (AlertKey)alertKeyList.get(0);

			if(!alertKey.getFileId().equals(null) && !alertKey.getFileId().equals("")){
				args.add(alertKey.getFileId());
			} else {
				args.add("none");
			}
			args.add(ruleName);
			args.add(runFreqInd);
			if ("Monthly".equals(tempTiming)) {
				if ("B".equals(alertRuleDefinition.getAlertRuleMonthlyTimingType())){
					args.add(alertRuleDefinition.getMnthExecBillRnd());
				}else {
					args.add(alertRuleDefinition.getMnthExecDt());
				}
			}else {
				args.add("0");
			}
			success = this.getAlertRuleDefinitionSQLService().insertTrigConvert(connection,failureList,args,alertRuleDefinition);
		}
		return success;
	}
	
	/**
	 * Inserts Data into RABC_EXTRCT_BUILD_RULE table for trend and track rules.
	 * 
	 * @param connection
	 * @param failureList
	 * @param tempTiming
	 * @param newPartiId
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean insertExtrctBuildRule(Connection connection, List failureList, String tempTiming, int newPartiId, AlertRuleDefinition alertRuleDefinition){
		String extrctType;
		boolean success = true;

		if ("Record".equals(tempTiming)){
			extrctType = "S";
		}else if ("BillRound".equals(tempTiming)){
			extrctType = "B";
		}else if ("Monthly".equals(tempTiming)) {
			extrctType = "M";
		}else if ("CallDayWeek".equals(tempTiming)) {
			extrctType = "D";
		}else {
			extrctType = "D";
		}
		
		if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
			List alertItemList = alertRuleDefinition.getAlertItemList();
			List alertKeyList = alertRuleDefinition.getAlertKeyList();
			int alertItemListSize = alertItemList.size();
			
			for (int i = 0; i < alertItemListSize; i++){				
				List args = new ArrayList();
				AlertItem alertItem = (AlertItem)alertItemList.get(i);
				
				args.add(Integer.toString(newPartiId));
				args.add(extrctType);
				args.add(alertItem.getItemName());
				
				List columnList = alertItem.getColumnList();
				int columnListSize = columnList.size();
				for (int j = 0; j < columnListSize; j++){
					Column column = (Column)columnList.get(j);
					AlertKey alertKey = (AlertKey) alertKeyList.get(j);
					
					args.add("ALERT_ITEM" + (i+1) + "_DDL_NAME");
						
					AlertItem alertItemForNegInd = (AlertItem)alertItemList.get(0);
					List columnListForNegInd = alertItemForNegInd.getColumnList();
					Column columnForNegInd = (Column)columnListForNegInd.get(j);
					if ("Y".equals(columnForNegInd.getNegIndicator())){
						args.add("Y");
					}else {
						args.add("N");
					}
					
					if (column.getColumnViewName() != null) {
						args.add(column.getColumnViewName());
					}else {
						args.add(column.getColumnAlertProcTBL());
					}
				}
				
				/*
				 * Addition of clause for adding total columns for tracking items 
				 */
				if (alertRuleDefinition.getLHSColumnsList().size()>1){
					args.add("");
					args.add("N");
					args.add("LTOTAL");
					columnListSize = columnListSize + 1;
				}
				
				if (alertRuleDefinition.getRHSColumnsList().size()>1){
					args.add("");
					args.add("N");
					args.add("RTOTAL");
					columnListSize = columnListSize + 1;
				}
				
				for (int j = columnListSize+1; j <= 9; j++){
					args.add("");
					args.add("");
					args.add("");
				}
				success = this.getAlertRuleDefinitionSQLService().insertExtrctBuildRule(connection, failureList, args, alertRuleDefinition);
			}
		} else {
			List args = new ArrayList();
			args.add(Integer.toString(newPartiId));
			args.add(extrctType);
			success = this.getAlertRuleDefinitionSQLService().insertExtrctBuildRule(connection, failureList, args, alertRuleDefinition);
		}
		return success;
	}
	
	/**
	 * Inserts Data into RABC_AVG_TBL_DEF table for a track rule.
	 * 
	 * @param connection
	 * @param failureList
	 * @param tempTiming
	 * @param newPartiId
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean insertAvgTblDef(Connection connection, List failureList, String tempTiming, int newPartiId,AlertRuleDefinition alertRuleDefinition){
		List alertItemList = alertRuleDefinition.getAlertItemList();
		List alertKeyList = alertRuleDefinition.getAlertKeyList();
		int alertItemListSize = alertItemList.size();
		boolean success= true;
		
		int alertKeyLevel;
		if ("DT".equals(tempTiming)){
			alertKeyLevel = 0;
		}else {
			alertKeyLevel = alertRuleDefinition.getAlertKeyLevel();
		}
		
		for (int i = 0; i < alertItemListSize; i++){
			List args = new ArrayList();
			AlertItem alertItem = (AlertItem)alertItemList.get(i);
			
			args.add(Integer.toString(newPartiId));
			args.add(Integer.toString(alertRuleDefinition.getAlertKeyLevel()));
			
			if (alertKeyLevel>=1){
				args.add("ALERT_KEY1");
			}else {
				args.add("");
			}
			if (alertKeyLevel>=2){
				args.add("ALERT_KEY2");
			}else {
				args.add("");
			}
			if (alertKeyLevel>=3){
				args.add("ALERT_KEY3");
			}else {
				args.add("");
			}
			if (alertKeyLevel>=4){
				args.add("ALERT_KEY4");
			}else {
				args.add("");
			}
			if (alertKeyLevel>=5){
				args.add("ALERT_KEY5");
			}else {
				args.add("");
			}
		
			args.add(alertItem.getItemName());
			
			List columnList = alertItem.getColumnList();
			int columnListSize = columnList.size();
			
			args.add(Integer.toString(columnListSize));
			
			for (int j = 0; j < columnListSize; j++){
				Column column = (Column)columnList.get(j);
				AlertKey alertKey = (AlertKey) alertKeyList.get(j);
				args.add(alertKey.getFileId());
			}
			
			if (alertRuleDefinition.getLHSColumnsList().size()>1){
				args.add("LTOTAL");
				columnListSize = columnListSize + 1;
			}
			
			if (alertRuleDefinition.getRHSColumnsList().size()>1){
				args.add("RTOTAL");
				columnListSize = columnListSize + 1;
			}
			
			for (int j = columnListSize+1; j <= 15; j++){
				args.add("");
			}
			success = this.getAlertRuleDefinitionSQLService().insertAvgTblDef(connection, failureList, args, alertRuleDefinition);
		}
		return success;
	}
	
	/**
	 * Inserts Data into RABC_EXTRCT_TBL_DEF table for trend and track rule.
	 * 
	 * @param connection
	 * @param failureList
	 * @param tempTiming
	 * @param newPartiId
	 * @param divisionKeyLvl
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean insertExtrctTblDef(Connection connection, List failureList, String tempTiming, int newPartiId, int divisionKeyLvl, AlertRuleDefinition alertRuleDefinition){
		List alertItemList = alertRuleDefinition.getAlertItemList();
		List alertKeyList = alertRuleDefinition.getAlertKeyList();
		int alertItemListSize = alertItemList.size();
		boolean success = true;
		
		int alertKeyLevel;
		if ("DT".equals(tempTiming)){
			alertKeyLevel = divisionKeyLvl;
		}else {
			alertKeyLevel = alertRuleDefinition.getAlertKeyLevel();
		}
		
		List leftColumnList = alertRuleDefinition.getLHSColumnsList();
		List rightColumnList = alertRuleDefinition.getRHSColumnsList();
		int leftCount=0;
		int rightCount=0;
		int totalCount=0;
		if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
			leftCount = leftColumnList.size();
			rightCount = rightColumnList.size();
			totalCount = leftCount + rightCount;
		} else {
			totalCount = leftColumnList.size();
		}
		
		if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
			for (int i=0;i<alertItemListSize;i++){
				List args = new ArrayList();
				AlertItem alertItem = (AlertItem)alertItemList.get(i);
				
				args.add(Integer.toString(newPartiId));
				args.add(Integer.toString(alertKeyLevel));
				
				if (alertKeyLevel>=1){
					args.add("ALERT_KEY1");
				}else {
					args.add("");
				}
				if (alertKeyLevel>=2){
					args.add("ALERT_KEY2");
				}else {
					args.add("");
				}
				if (alertKeyLevel>=3){
					args.add("ALERT_KEY3");
				}else {
					args.add("");
				}
				if (alertKeyLevel>=4){
					args.add("ALERT_KEY4");
				}else {
					args.add("");
				}
				if (alertKeyLevel>=5){
					args.add("ALERT_KEY5");
				}else {
					args.add("");
				}
				
				args.add(alertItem.getItemName());
				args.add(Integer.toString(totalCount));
				args.add(Integer.toString(leftCount));
				args.add(Integer.toString(rightCount));
				
				int keyListSize = alertRuleDefinition.getAlertKeyList().size();
				for (int j = 0; j < keyListSize; j++){
					AlertKey alertKey = (AlertKey)alertRuleDefinition.getAlertKeyList().get(j);
					if(alertKey.getFileId().equals("") || alertKey.getFileId().equals(null)){
						args.add("none");
					} else {
						args.add(alertKey.getFileId());
					}
				}
				
				if (alertRuleDefinition.getLHSColumnsList().size()>1){
					args.add("LTOTAL");
					keyListSize = keyListSize + 1;
				}
				
				if (alertRuleDefinition.getRHSColumnsList().size()>1){
					args.add("RTOTAL");
					keyListSize = keyListSize + 1;
				}
				
				for (int j = keyListSize+1; j <= 15; j++){
					args.add("");
				}
				success = this.getAlertRuleDefinitionSQLService().insertExtrctTblDef(connection,failureList,args,alertRuleDefinition);
			}
		} else {
			List args = new ArrayList();

			args.add(Integer.toString(newPartiId));
			args.add(Integer.toString(alertKeyLevel));
			
			AlertKey alertKey = (AlertKey)alertRuleDefinition.getAlertKeyList().get(0);
			if (alertKeyLevel>=1){
				args.add(alertKey.getKey1());
			}else {
				args.add("");
			}
			if (alertKeyLevel>=2){
				args.add(alertKey.getKey2());
			}else {
				args.add("");
			}
			if (alertKeyLevel>=3){
				args.add(alertKey.getKey3());
			}else {
				args.add("");
			}
			if (alertKeyLevel>=4){
				args.add(alertKey.getKey4());
			}else {
				args.add("");
			}
			if (alertKeyLevel>=5){
				args.add(alertKey.getKey5());
			}else {
				args.add("");
			}
			
			args.add(Integer.toString(totalCount));
			
			for (int i = 0; i < alertItemListSize; i++){
				AlertItem alertItem = (AlertItem)alertItemList.get(i);
				int columnListSize = alertItem.getColumnList().size();
				Column column = (Column)alertItem.getColumnList().get(0);
				args.add(column.getColumnTBLDDLName());
			}
			
			for (int j = alertItemListSize+1; j <= 15; j++){
				args.add("");
			}
			success = this.getAlertRuleDefinitionSQLService().insertExtrctTblDef(connection,failureList,args,alertRuleDefinition);
		}
		return success;
	}
	
	/**
	 * Inserts Data into RABC_UPDATE_GRP table for track and trend rules.
	 * 
	 * @param connection
	 * @param failureList
	 * @param selectedAlertGrps
	 * @param alertRuleDefinition
	 * @param tempTiming
	 * @return boolean
	 */
	private boolean insertAlertGroup(Connection connection, List failureList, String [] selectedAlertGrps, AlertRuleDefinition alertRuleDefinition, String tempTiming){
		String ruleName;
		boolean success = true;
		
		if ("DT".equals(tempTiming)){
			ruleName = alertRuleDefinition.getAlertRule() + "-DAILY";
		}else {
			ruleName = alertRuleDefinition.getAlertRule();
		}
		
		String [] selectedAlertGroups = selectedAlertGrps;
		int alertGroupsLength = selectedAlertGroups.length;
		for (int i = 0; i < alertGroupsLength; i++){
			List args = new ArrayList();
			args.add(ruleName);
			args.add(selectedAlertGroups[i]);  
			success = this.getAlertRuleDefinitionSQLService().insertAlertGroup(connection, failureList, args, alertRuleDefinition);
		}
		return success;
	}
	
	/**
	 * Inserts Data into RABC_ALERT_PROC table for track and trend rules.
	 * 
	 * @param connection
	 * @param failureList
	 * @param tempTiming
	 * @param newPartiId
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean insertAlertProc(Connection connection, List failureList, String tempTiming, int newPartiId,AlertRuleDefinition alertRuleDefinition){
		String ruleName;
		List alertItemList = alertRuleDefinition.getAlertItemList();
		List alertKeyList = alertRuleDefinition.getAlertKeyList();
		int alertItemListSize = alertItemList.size();
		boolean success = true;
		int msgSuppDataIndSize = 0;
		
		if ("DT".equals(tempTiming)){
			ruleName = alertRuleDefinition.getAlertRule() + "-DAILY";
		} else {
			ruleName = alertRuleDefinition.getAlertRule();
		}
	
		for (int i = 0; i < alertItemListSize; i++){
			List args = new ArrayList();
			AlertItem alertItem = (AlertItem)alertItemList.get(i);
			
			args.add(ruleName);
			args.add(alertItem.getAlertType());
			args.add(alertItem.getItemName());
			
			if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
				args.add("ALERT_DATA");
				args.add("AVG_DATA1");
				args.add("RABC_CALC_ALERT_DATA");
				args.add("RABC_AVG_DATA");
			} else {
				args.add("EXTRCT_DATA" + (i+1));
				args.add("AVG_DATA" + (i+1));
				args.add("RABC_EXTRCT_SUMY_DATA");
				args.add("RABC_AVG_DATA");
			}
			
			if ("Y".equals(alertItem.getWarningIndicator()) /*&& "DT".equals(tempTiming)*/){
				args.add("Y");
			} else {
				args.add("N");
			}
			
			if(alertItem.getSupplementType().getSelectedSupplementType() != null){
				msgSuppDataIndSize = alertItem.getSupplementType().getSelectedSupplementType().length;
			}
			
			if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
				if (msgSuppDataIndSize>0){
					args.add("Y");
				}else {
					args.add("N");
				}
			}
			
			args.add("");
			args.add("");
			args.add(Integer.toString(newPartiId));
			
			success = this.getAlertRuleDefinitionSQLService().insertAlertProc(connection, failureList, args, alertRuleDefinition);
		}
	return success;
	}
	
	/**
	 * Inserts Data into RABC_AVG_CALC table for track and trend rules.
	 * 
	 * @param connection
	 * @param failureList
	 * @param tempTiming
	 * @param newPartiId
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean insertAvgCalc(Connection connection, List failureList, String tempTiming, int newPartiId,AlertRuleDefinition alertRuleDefinition){
		List args = new ArrayList();
		String ruleName;
		boolean success = true;
		if ("DT".equals(tempTiming)){
			ruleName = alertRuleDefinition.getAlertRule() + "-DAILY";
		}else {
			ruleName = alertRuleDefinition.getAlertRule();
		}
		args.add(ruleName); 
		args.add(Integer.toString(newPartiId));
		String nullVariable = null;
		String avgDays = "'"+alertRuleDefinition.getAverageDays()+"'"; //Making variables compatible for message formatter.
		String avgRecs = "'"+alertRuleDefinition.getAverageRecords()+"'"; //Making variables compatible for message formatter.
		if (alertRuleDefinition.getAverageDays()==null){
			args.add(nullVariable);
		} else {
			args.add(avgDays);
		}
		if (alertRuleDefinition.getAverageRecords()==null){
			args.add(nullVariable);
		} else {
			args.add(avgRecs);
		}
		args.add(alertRuleDefinition.getAlertRuleTiming()); 
		args.add(alertRuleDefinition.getAverageType()); 
		success = this.getAlertRuleDefinitionSQLService().insertAvgCalc(connection,failureList,args,alertRuleDefinition);
		return success;
	}
	
	/**
	 * Inserts Data into RABC_CNTRL_PT_ALERT table for track and trend rules.
	 * 
	 * @param connection
	 * @param failureList
	 * @param tempTiming
	 * @param newDashNum
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean updateCntrlPtAlert(Connection connection, List failureList, String tempTiming, int newDashNum,AlertRuleDefinition alertRuleDefinition){
		List args = new ArrayList();
		String ruleName;
		boolean success = true;
		if ("DT".equals(tempTiming)){
			ruleName = alertRuleDefinition.getAlertRule() + "-DAILY";
		}else {
			ruleName = alertRuleDefinition.getAlertRule();
		}
		args.add(alertRuleDefinition.getControlPoint());
		args.add(ruleName);
		args.add(Integer.toString(newDashNum));
		success = this.getAlertRuleDefinitionSQLService().updateCntrlPtAlert(connection,failureList,args,alertRuleDefinition);
		return success;
	}
	
	/**
	 * Inserts Data into RABC_PROC_RESPONSIBLE table for track and trend rules.
	 * 
	 * @param connection
	 * @param failureList
	 * @param tempTiming
	 * @param alertRuleDefinition
	 * @param selectedAlertGrps
	 * @return boolean
	 */
	private boolean insertProcResponsible(Connection connection, List failureList, String tempTiming,AlertRuleDefinition alertRuleDefinition, String [] selectedAlertGrps){
		List args = new ArrayList();
		String ruleName;
		String msgInd;
		boolean success = true;
		int pickSql = 0;
		
		if ("Record".equals(tempTiming)){
			msgInd = "Y";
		}else if ("BillRound".equals(tempTiming)){
			msgInd= "Y";
		}else if ("CallDayWeek".equals(tempTiming)) {
			msgInd= "Y";
		}else if ("Monthly".equals(tempTiming)) {
			msgInd= "Y";
		}else {
			msgInd= "N";
		}
		
		if ("DT".equals(tempTiming)){
			ruleName = alertRuleDefinition.getAlertRule() + "-DAILY";
		}else {
			ruleName = alertRuleDefinition.getAlertRule();
		}
		
		args.add(ruleName);
		
		pickSql = 1;
		success = this.getAlertRuleDefinitionSQLService().insertProcResponsible(connection,failureList,args,alertRuleDefinition,pickSql);
		
		int alertGroupsLength = selectedAlertGrps.length;
		if ("Y".equals(msgInd)){
			for (int i=0;i<alertGroupsLength;i++){
				List args2 = new ArrayList();
				args2.add(ruleName);
				args2.add(selectedAlertGrps[i]);
				pickSql = 2;
				success = this.getAlertRuleDefinitionSQLService().insertProcResponsible(connection,failureList,args2,alertRuleDefinition,pickSql);
			}
		}
		return success;
	}

	/**
	 * Inserts Data into RABC_ALERT_RULE_PRESN_ELEM table a track rule.
	 * 
	 * @param connection
	 * @param failureList
	 * @param newPresnId
	 * @param newPartiId
	 * @param alertRuleDefinition
	 * @param region
	 * @return boolean
	 */
	private boolean insertAlertRulePresenElemTrack(Connection connection, List failureList, int newPresnId, int newPartiId, AlertRuleDefinition alertRuleDefinition, String region){
		String formatCode = null;
		
		/*
		 * List of web pages. This will allow to iterate through this list and insert into RABC_ALERT_RULE_PRESN_ELEM
		 */
		List TList = new ArrayList();
		TList.add("RABCPSF00012");
		TList.add("RABCPSF00013");
		boolean success =true;
		int pickSql =0;
	
		/*
		 * Get the number of columns in left and right
		 */
		int leftColumnSize = alertRuleDefinition.getLHSColumnsList().size();
		int rightColumnSize = alertRuleDefinition.getRHSColumnsList().size();
		
		/*
		 * Find out the index for left and right total's DDL column index
		 */
		int leftSideTotalInd =0;
		int rightSideTotalInd=0;
		if (leftColumnSize > 1){
			leftSideTotalInd = leftColumnSize + rightColumnSize + 1;
			if (rightColumnSize > 1){
				rightSideTotalInd = leftSideTotalInd + 1;
			}
		}
		if (leftColumnSize < 2 && rightColumnSize > 1){
			rightSideTotalInd = leftColumnSize + rightColumnSize + 1;
		}
		
		/*
		 * ITER variable will be used for inserting into PRESN_SEQ_NUM
		 */
		int ITER=0;
		String TL = "";
		for (int i=0;i<TList.size();i++){
			TL = (String)TList.get(i);
			int rightSideStart = leftColumnSize + 2; // 1 for bill round so L + 1 will be index of last left column. So L + 2 is default index for Right Side column start

			if (leftColumnSize > 1){
				rightSideStart = rightSideStart + 1; // Add 1 since after left columns are over, it will be left side result first
			}
			
			/*
			 * Code added to implement change of additional column
			 */
			if ("B".equals(alertRuleDefinition.getAlertRuleTiming())){
				rightSideStart = rightSideStart + 1; // Add 1 in case timing is Bill Cycle
			}
			
			/*
			 * Initialize counter
			 */
			ITER = 1;
	
			/*
			 * Modification in the code to insert a new row for timing equal to 'Bill-Round'.
			 */
			if ("B".equals(alertRuleDefinition.getAlertRuleTiming())){
				List args0 = new ArrayList();
				args0.add(Integer.toString(newPresnId));
				args0.add(TL);
				args0.add(Integer.toString(ITER));
				args0.add(Integer.toString(newPartiId));
				args0.add(Integer.toString(0));
				if ("MW".equals(region)){
					args0.add("PROCESS-GRP");
				}else {
					args0.add("BILL-RND");
				}
				pickSql = 0;
				ITER = ITER + 1;
				success= this.getAlertRuleDefinitionSQLService().insertAlertRulePresenElem(connection,failureList,args0,alertRuleDefinition,pickSql);
			}
			
			/*
			 * Insert for ALERT ITEM
			 */
			List args1 = new ArrayList();
			args1.add(Integer.toString(newPresnId));
			args1.add(TL);
			args1.add(Integer.toString(ITER));
			args1.add(Integer.toString(newPartiId));
			args1.add(Integer.toString(0));
			pickSql = 1;
			success= this.getAlertRuleDefinitionSQLService().insertAlertRulePresenElem(connection,failureList,args1,alertRuleDefinition,pickSql);
			
			/*
			 * Insert for Left Columns
			 */
			int ind = 0;
			for (int j=0;j<alertRuleDefinition.getLHSColumnsList().size();j++){
				ind = ind + 1;
				if (ind == leftSideTotalInd){
					ind = ind + 1;
					if (ind == rightSideTotalInd){
						ind = ind + 1;
					}
				}
				if (ind == rightSideTotalInd){
					ind = ind + 1;
				}
				
				ITER = ITER + 1;
				
				/*
				 * 1) Modification to take calculation name as PRESN_NAME if current column is actually a calculation
				 * 2) Modification to not take the column name in PRESN_NAME
				 */
				Column column = (Column)alertRuleDefinition.getLHSColumnsList().get(j);
				String p = null;
				if ("CAL".equalsIgnoreCase(column.getColumnTBLDataType())){
					p = column.getColumnTBLDDLName();
				}else if(column.getColumnViewName() != null){
					String viewName = column.getColumnViewName();
					String newViewName = null;
					int endIndex = (viewName).lastIndexOf("_PREV");
					if(endIndex == -1){
						newViewName = column.getColumnViewName();
					}else{						
						if(viewName.substring(3).startsWith("RABC_")||viewName.substring(3).startsWith("rabc_")){
							newViewName = viewName.substring(8);
						}
						else{
							newViewName = viewName.substring(3);
						}						
					}
					p = newViewName;
				} else {
					String tableName = column.getColumnAlertProcTBL();
					String newTableName = null;
					int lengthOfTableName = tableName.length();
					newTableName = tableName.substring(5,lengthOfTableName);
					p = newTableName;
				}
				int lengthOfP = p.length();
				List args4 = new ArrayList();
				args4.add(Integer.toString(newPresnId));
				args4.add(TL);
				args4.add(Integer.toString(ITER));
				if(lengthOfP > 50){
					args4.add(p.substring(0,48));
				} else {
					args4.add(p);
				}
				args4.add(Integer.toString(newPartiId));
				args4.add("EXTRCT_DATA" + ind);
				
				if ("RABCPSF00012".equals(TL)){
					if (ITER==3 && "B".equals(alertRuleDefinition.getAlertRuleTiming())){
						args4.add("Y");
						args4.add("1");
					}else if (ITER==2){
						args4.add("Y");
						args4.add("1");
					}else {
						args4.add("");
						args4.add("");
					}
				}else {
					args4.add("");
					args4.add("");
				}
				String columnName = ((column).getColumnTBLDDLName());
				//	Modification to take format code of calculation if column is a calculation
				if ("CAL".equalsIgnoreCase(column.getColumnTBLDataType())){
					formatCode = column.getColumnTBLDDLPRESCSNFormatType();
				}else {
					formatCode = StaticDataLoader.getMaxFormatTypeForTblDdlName(columnName, region);
				}
				if(formatCode == null){
					args4.add(Integer.toString(0));
				}else{
					args4.add(formatCode);
				}
				pickSql = 4;
				success= this.getAlertRuleDefinitionSQLService().insertAlertRulePresenElem(connection,failureList,args4,alertRuleDefinition,pickSql);
			}
			
			/*
			 * Code for Left Side Total
			 */
			if (leftColumnSize > 1){
				List args2 = new ArrayList();
				ITER = ITER + 1;
				args2.add(Integer.toString(newPresnId));
				args2.add(TL);
				args2.add(Integer.toString(ITER));
				args2.add(Integer.toString(newPartiId));
				args2.add("EXTRCT_DATA" + leftSideTotalInd);
				if ("RABCPSF00012".equals(TL)){
					args2.add("Y");
					args2.add("1");
				}else {
					args2.add("");
					args2.add("");
				}
				args2.add(Integer.toString(0));

				pickSql = 2;
				success= this.getAlertRuleDefinitionSQLService().insertAlertRulePresenElem(connection,failureList,args2,alertRuleDefinition,pickSql);
			}
			
			/*
			 * Code for inserting Right Side Result
			 */
			if (rightColumnSize > 1){
				List args3 = new ArrayList();
				ITER = ITER + 1;
				args3.add(Integer.toString(newPresnId));
				args3.add(TL);
				args3.add(Integer.toString(rightSideStart));
				args3.add(Integer.toString(newPartiId));
				args3.add("EXTRCT_DATA" + rightSideTotalInd);
				args3.add(Integer.toString(0));		
				pickSql = 3;
				success= this.getAlertRuleDefinitionSQLService().insertAlertRulePresenElem(connection,failureList,args3,alertRuleDefinition,pickSql);
				rightSideStart = rightSideStart + 1;
			}
			
			/*
			 * Inserts for Right Side Columns
			 */
			for (int j=0;j<alertRuleDefinition.getRHSColumnsList().size();j++){
				ind = ind + 1;
				if (ind == leftSideTotalInd){
					ind = ind + 1;
					if (ind == rightSideTotalInd){
						ind = ind + 1;
					}
				}
				if (ind == rightSideTotalInd){
					ind = ind + 1;
				}
				
				ITER = ITER + 1;
				
				Column column = (Column)alertRuleDefinition.getRHSColumnsList().get(j);
				String p = null;
				// Modification to take calculation name as PRESN_NAME if current column is actually a calculation
				if ("CAL".equalsIgnoreCase(column.getColumnTBLDataType())){
					p = column.getColumnTBLDDLName();
				} else if (column.getColumnViewName() != null){
					String viewName = column.getColumnViewName();
					String newViewName = null;
					int endIndex = (viewName).lastIndexOf("_PREV");
					if(endIndex == -1){
						newViewName = column.getColumnViewName();
					}else{
						if(viewName.substring(3).startsWith("RABC_")||viewName.substring(3).startsWith("rabc_")){
							newViewName = viewName.substring(8);
						}
						else{
							newViewName = viewName.substring(3);
						}			
					}
					p = newViewName;
				} else {
					String tableName = column.getColumnAlertProcTBL();
					String newTableName = null;
					int lengthOfTableName = tableName.length();
					newTableName = tableName.substring(5,lengthOfTableName);
					p = newTableName;
				}
				int lengthOfP = p.length();
				List args4 = new ArrayList();
				args4.add(Integer.toString(newPresnId));
				args4.add(TL);
				args4.add(Integer.toString(ITER));
				if(lengthOfP > 50){
					args4.add(p.substring(0,48));
				} else {
					args4.add(p);
				}
				args4.add(Integer.toString(newPartiId));
				args4.add("EXTRCT_DATA" + ind);
				
				if ("RABCPSF00012".equals(TL)){
					if (j==0){
						args4.add("Y");
						args4.add("1");
					}else {
						args4.add("");
						args4.add("");
					}
				}else {
					args4.add("");
					args4.add("");
				}
				String columnName = ((column).getColumnTBLDDLName());
				// Modification to take format code of calculation if column is a calculation
				if ("CAL".equalsIgnoreCase(column.getColumnTBLDataType())){
					formatCode = column.getColumnTBLDDLPRESCSNFormatType();
				}else {
					formatCode = StaticDataLoader.getMaxFormatTypeForTblDdlName(columnName, region);
				}
				
				if(formatCode == null){
					args4.add(Integer.toString(0));
				}else{
					args4.add(formatCode);
				}				
				pickSql = 4;
				success= this.getAlertRuleDefinitionSQLService().insertAlertRulePresenElem(connection,failureList,args4,alertRuleDefinition,pickSql);
			}
		}
		
		ITER=ITER+1;
		List args5 = new ArrayList();
		args5.add(Integer.toString(newPresnId));
		args5.add(Integer.toString(ITER));
		args5.add(Integer.toString(newPartiId));
		
		if ("RABCPSF00012".equals(TL)){
			if (ITER==3 && "B".equals(alertRuleDefinition.getAlertRuleTiming())){
				args5.add("Y");
				args5.add("1");
			}else if (ITER==2){
				args5.add("Y");
				args5.add("1");
			}else {
				args5.add("");
				args5.add("");
			}
		}else {
			args5.add("");
			args5.add("");
		}
		
		args5.add(Integer.toString(0));

		pickSql = 5;
		success= this.getAlertRuleDefinitionSQLService().insertAlertRulePresenElem(connection,failureList,args5,alertRuleDefinition,pickSql);
		
		return success;
	}
	
	/**
	 * Inserts Data into RABC_ALERT_RULE_PRESN_ELEM table a trend rule.boolean
	 * 
	 * @param connection
	 * @param failureList
	 * @param newPresnId
	 * @param newPartiId
	 * @param alertRuleDefinition
	 * @param region
	 * @return boolean
	 */
	private boolean insertAlertRulePresenElemTrend(Connection connection, List failureList, int newPresnId, int newPartiId, AlertRuleDefinition alertRuleDefinition, String region){
		List leftColumnList = alertRuleDefinition.getLHSColumnsList();
		int leftColumnListSize = leftColumnList.size();
		boolean success = true;
		int pickSql = 0;
		String formatCode = null;
		
		/*
		 * Modification in the code to insert a new row for timing equal to 'Bill-Round'.
		 */
		int iter = 1;
		if ("B".equals(alertRuleDefinition.getAlertRuleTiming())){
			List args0 = new ArrayList();
			args0.add(Integer.toString(newPresnId));
			args0.add("1");
			if ("MW".equals(region)){
				args0.add("PROCESS-GRP");
			}else {
				args0.add("BILL-RND");
			}
			args0.add(Integer.toString(newPartiId));
			args0.add("ALERT_TREND_TIME");
			args0.add(Integer.toString(0));
			args0.add("N");
			args0.add("N");
			args0.add("");
			args0.add("");
			args0.add("");
			iter = 2;
			success = this.getAlertRuleDefinitionSQLService().insertAlertRulePresenElem(connection,failureList,args0,alertRuleDefinition,pickSql);
		}

		/*
		 * Populate counter
		 */
		int counter = 1;
		if (alertRuleDefinition.getReportLinkKey1()!=null && !"---Select---".equals(alertRuleDefinition.getReportLinkKey1())){
			counter++;
		}
		if (alertRuleDefinition.getReportLinkKey2()!=null && !"---Select---".equals(alertRuleDefinition.getReportLinkKey2())){
			counter++;
		}
		if (alertRuleDefinition.getReportLinkKey3()!=null && !"---Select---".equals(alertRuleDefinition.getReportLinkKey3())){
			counter++;
		}
		if (alertRuleDefinition.getReportLinkKey4()!=null && !"---Select---".equals(alertRuleDefinition.getReportLinkKey4())){
			counter++;
		}
		if (alertRuleDefinition.getReportLinkKey5()!=null && !"---Select---".equals(alertRuleDefinition.getReportLinkKey5())){
			counter++;
		}
		
		for (int i=0;i<leftColumnListSize;i++){
			Column column = (Column)leftColumnList.get(i);
			List args = new ArrayList();
			args.add(Integer.toString(newPresnId));
			args.add(Integer.toString(iter));
			args.add(column.getColumnTBLDDLName());
			args.add(Integer.toString(newPartiId));
			args.add("EXTRCT_DATA" + (i+1));
			String columnName = ((column).getColumnTBLDDLName());
			
			// Code to take care of calculation wherein we will get the format type of the calculation
			if ("CAL".equalsIgnoreCase(column.getColumnTBLDataType())){
				formatCode = column.getColumnTBLDDLPRESCSNFormatType();
			}else {
				formatCode = StaticDataLoader.getMaxFormatTypeForTblDdlName(columnName, region);
			}
			
			if(formatCode == null){
				args.add(Integer.toString(0));
			}else{
				args.add(formatCode);
			}
			args.add("");
			args.add("Y");
			AlertItem alertItem = (AlertItem)alertRuleDefinition.getAlertItemList().get(i);
			if (alertItem.getReportLinkData()!=null && !"---Select---".equals(alertItem.getReportLinkData())){
				args.add("Y");
				args.add(Integer.toString(counter));
				counter++;
			}else {
				args.add("");
				args.add("");
			}
			if (alertItem.getAlertUnit()!=null && !"none".equals(alertItem.getAlertUnit())){
				args.add(alertItem.getAlertUnit());
			} else {
				args.add("");
			}
			success = this.getAlertRuleDefinitionSQLService().insertAlertRulePresenElem(connection,failureList,args,alertRuleDefinition,pickSql);
			iter = iter + 1;
		}
		return success;
	}

	/**
	 * Inserts Data into RABC_ALERT_RULE_PRESN_RULE table a track rule.
	 * 
	 * @param connection
	 * @param failureList
	 * @param alertRuleDefinition
	 * @param tempTiming
	 * @param divisionKeyLvl
	 * @param newPresnId
	 * @param mouseOverNumArray
	 * @return boolean
	 */
	private boolean insertAlertRulePresnRuleTrack(Connection connection, List failureList, AlertRuleDefinition alertRuleDefinition, String tempTiming, int divisionKeyLvl, int newPresnId, int[] mouseOverNumArray){
		List webIDLList = new ArrayList();
		String ruleName;
		int tt=0;
		boolean success =true;
		int pickSql =0;
		
		if ("DT".equals(tempTiming)){
			ruleName = alertRuleDefinition.getAlertRule() + "-DAILY";
		}else {
			ruleName = alertRuleDefinition.getAlertRule();
		}
		
		webIDLList.add("RABCPSF00011");
		webIDLList.add("RABCPSF00012");
		webIDLList.add("RABCPSF00013");
		if ("on".equals(alertRuleDefinition.getFileSequenceIndicator())){
			webIDLList.add("RABCPSF00014");
		}
		int webIDLListSize =  webIDLList.size();
		int ind = webIDLListSize;
		
		if ("DT".equals(tempTiming)){
			tt = divisionKeyLvl;
		}else if ("Record".equals(tempTiming)|| "BillRound".equals(tempTiming) || "CallDayWeek".equals(tempTiming) || "Monthly".equals(tempTiming)){
			tt = alertRuleDefinition.getAlertKeyLevel();
		}
		
		String wb;
		for (int i=0;i<webIDLListSize;i++){
			wb = (String)webIDLList.get(i);
			
			if ("RABCPSF00014".equals(wb)){
				if ("on".equals(alertRuleDefinition.getFileSequenceIndicator())){
					List args1 = new ArrayList();
					args1.add(Integer.toString(newPresnId));
					args1.add(wb);
					if ("Record".equals(tempTiming)|| "BillRound".equals(tempTiming) || "CallDayWeek".equals(tempTiming)|| "Monthly".equals(tempTiming)){
						args1.add("Y");
					}else {
						args1.add("N");
					}
					args1.add(Integer.toString(tt));
					
					List alertKeyList = alertRuleDefinition.getAlertKeyList();
					int alertKeyListSize = alertKeyList.size();
					AlertKey alertKey = (AlertKey)alertKeyList.get(0);
					int alertKeyLevel = alertRuleDefinition.getAlertKeyLevel();
					if (alertKey.getKey1() != null && tt >= 1){
						args1.add("EXTRCT_KEY1");
						args1.add(alertKey.getKey1());
						args1.add(Integer.toString(mouseOverNumArray[0]));
					} else {
						args1.add("");
						args1.add("");
						args1.add("");
					}
					if (alertKey.getKey2() != null && tt >= 2){
						args1.add("EXTRCT_KEY2");
						args1.add(alertKey.getKey2());
						args1.add(Integer.toString(mouseOverNumArray[1]));
					} else {
						args1.add("");
						args1.add("");
						args1.add("");
					}
					if (alertKey.getKey3() != null && tt >= 3){
						args1.add("EXTRCT_KEY3");
						args1.add(alertKey.getKey3());
						args1.add(Integer.toString(mouseOverNumArray[2]));
					} else {
						args1.add("");
						args1.add("");
						args1.add("");
					}
					if (alertKey.getKey4() != null && tt >= 4){
						args1.add("EXTRCT_KEY4");
						args1.add(alertKey.getKey4());
						args1.add(Integer.toString(mouseOverNumArray[3]));
					} else {
						args1.add("");
						args1.add("");
						args1.add("");
					}
					if (alertKey.getKey5() != null && tt >= 5){
						args1.add("EXTRCT_KEY5");
						args1.add(alertKey.getKey5());
						args1.add(Integer.toString(mouseOverNumArray[4]));
					} else {
						args1.add("");
						args1.add("");
						args1.add("");
					}
					if(divisionKeyLvl==1){
						args1.add("Y");
					}else{
						args1.add("");
					}
					
					pickSql = 1;
					success=this.getAlertRuleDefinitionSQLService().insertAlertRulePresnRule(connection,failureList,args1,alertRuleDefinition,pickSql);
				}
			} else if ("RABCPSF00011".equals(wb) || "RABCPSF00012".equals(wb)) {
				List args1 = new ArrayList();
				args1.add(Integer.toString(newPresnId));
				args1.add(wb);
				if ("Record".equals(tempTiming)|| "BillRound".equals(tempTiming) || "CallDayWeek".equals(tempTiming)|| "Monthly".equals(tempTiming)){
					if ("on".equals(alertRuleDefinition.getFileSequenceIndicator())){
						args1.add("Y");
					} else {
						args1.add("N");
					}
				}else {
					args1.add("N");
				}
				args1.add(Integer.toString(tt));
				
				List alertKeyList = alertRuleDefinition.getAlertKeyList();
				int alertKeyListSize = alertKeyList.size();
				AlertKey alertKey = (AlertKey)alertKeyList.get(0);
				int alertKeyLevel = alertRuleDefinition.getAlertKeyLevel();
				if (alertKey.getKey1() != null && tt >= 1){
					args1.add("EXTRCT_KEY1");
					args1.add(alertKey.getKey1());
					if("RABCPSF00011".equals(wb) && divisionKeyLvl == 1){
						args1.add("Y");
						args1.add(Integer.toString(1));
					} else {
						args1.add("");
						args1.add("");
					}
					args1.add(Integer.toString(mouseOverNumArray[0]));
				} else {
					args1.add("");
					args1.add("");
					args1.add("");
					args1.add("");
					args1.add("");
				}
				if (alertKey.getKey2() != null && tt >= 2){
					args1.add("EXTRCT_KEY2");
					args1.add(alertKey.getKey2());
					args1.add("");
					args1.add("");
					args1.add(Integer.toString(mouseOverNumArray[1]));
					if (mouseOverNumArray[1]>0){
						args1.add("Y");
					}else {
						args1.add("");
					}
				} else {
					args1.add("");
					args1.add("");
					args1.add("");
					args1.add("");
					args1.add("");
					args1.add("");
				}
				if (alertKey.getKey3() != null && tt >= 3){
					args1.add("EXTRCT_KEY3");
					args1.add(alertKey.getKey3());
					args1.add("");
					args1.add("");
					args1.add(Integer.toString(mouseOverNumArray[2]));
					if (mouseOverNumArray[2]>0){
						args1.add("Y");
					}else {
						args1.add("");
					}
				} else {
					args1.add("");
					args1.add("");
					args1.add("");
					args1.add("");
					args1.add("");
					args1.add("");
				}
				if (alertKey.getKey4() != null && tt >= 4){
					args1.add("EXTRCT_KEY4");
					args1.add(alertKey.getKey4());
					args1.add("");
					args1.add("");
					args1.add(Integer.toString(mouseOverNumArray[3]));
					if (mouseOverNumArray[3]>0){
						args1.add("Y");
					}else {
						args1.add("");
					}
				} else {
					args1.add("");
					args1.add("");
					args1.add("");
					args1.add("");
					args1.add("");
					args1.add("");
				}
				if (alertKey.getKey5() != null && tt >= 5){
					args1.add("EXTRCT_KEY5");
					args1.add(alertKey.getKey5());
					args1.add("");
					args1.add("");
					args1.add(Integer.toString(mouseOverNumArray[4]));
					if (mouseOverNumArray[4]>0){
						args1.add("Y");
					}else {
						args1.add("");
					}
				} else {
					args1.add("");
					args1.add("");
					args1.add("");
					args1.add("");
					args1.add("");
					args1.add("");
				}
				if(divisionKeyLvl==1){
					args1.add("Y");
				}else{
					args1.add("");
				}
				pickSql = 2;
				success=this.getAlertRuleDefinitionSQLService().insertAlertRulePresnRule(connection,failureList,args1,alertRuleDefinition,pickSql);	
			} else if ("RABCPSF00013".equals(wb)) {
				List args1 = new ArrayList();
				int counter = 1;
				args1.add(Integer.toString(newPresnId));
				args1.add(wb);
				if ("Record".equals(tempTiming)|| "BillRound".equals(tempTiming) || "CallDayWeek".equals(tempTiming)|| "Monthly".equals(tempTiming)){
					if ("on".equals(alertRuleDefinition.getFileSequenceIndicator())){
						args1.add("Y");
					} else {
						args1.add("N");
					}
				}else {
					args1.add("N");
				}
				args1.add(Integer.toString(tt));
				
				List alertKeyList = alertRuleDefinition.getAlertKeyList();
				int alertKeyListSize = alertKeyList.size();
				AlertKey alertKey = (AlertKey)alertKeyList.get(0);
				int alertKeyLevel = alertRuleDefinition.getAlertKeyLevel();
				if (alertKey.getKey1() != null && tt >= 1){
					args1.add("EXTRCT_KEY1");
					args1.add(alertKey.getKey1());
					if (!"---Select---".equals(alertRuleDefinition.getReportLinkKey1())) {
						args1.add("Y");
						args1.add(Integer.toString(counter));
						counter++;
					} else {
						args1.add("");
						args1.add("");
					}
					args1.add(Integer.toString(mouseOverNumArray[0]));
				} else {
					args1.add("");
					args1.add("");
					args1.add("");
					args1.add("");
					args1.add("");
				}
				if (alertKey.getKey2() != null && tt >= 2){
					args1.add("EXTRCT_KEY2");
					args1.add(alertKey.getKey2());
					if (!"---Select---".equals(alertRuleDefinition.getReportLinkKey2())) {
						args1.add("Y");
						args1.add(Integer.toString(counter));
						counter++;
					} else {
						args1.add("");
						args1.add("");
					}
					args1.add(Integer.toString(mouseOverNumArray[1]));
					if (mouseOverNumArray[1]>0){
						args1.add("Y");
					}else {
						args1.add("");
					}
				} else {
					args1.add("");
					args1.add("");
					args1.add("");
					args1.add("");
					args1.add("");
					args1.add("");
				}
				if (alertKey.getKey3() != null && tt >= 3){
					args1.add("EXTRCT_KEY3");
					args1.add(alertKey.getKey3());
					if (!"---Select---".equals(alertRuleDefinition.getReportLinkKey3())) {
						args1.add("Y");
						args1.add(Integer.toString(counter));
						counter++;
					} else {
						args1.add("");
						args1.add("");
					}
					args1.add(Integer.toString(mouseOverNumArray[2]));
					if (mouseOverNumArray[2]>0){
						args1.add("Y");
					}else {
						args1.add("");
					}
				} else {
					args1.add("");
					args1.add("");
					args1.add("");
					args1.add("");
					args1.add("");
					args1.add("");
				}
				if (alertKey.getKey4() != null && tt >= 4){
					args1.add("EXTRCT_KEY4");
					args1.add(alertKey.getKey4());
					if (!"---Select---".equals(alertRuleDefinition.getReportLinkKey4())) {
						args1.add("Y");
						args1.add(Integer.toString(counter));
						counter++;
					} else {
						args1.add("");
						args1.add("");
					}
					args1.add(Integer.toString(mouseOverNumArray[3]));
					if (mouseOverNumArray[3]>0){
						args1.add("Y");
					}else {
						args1.add("");
					}
				} else {
					args1.add("");
					args1.add("");
					args1.add("");
					args1.add("");
					args1.add("");
					args1.add("");
				}
				if (alertKey.getKey5() != null && tt >= 5){
					args1.add("EXTRCT_KEY5");
					args1.add(alertKey.getKey5());
					if (!"---Select---".equals(alertRuleDefinition.getReportLinkKey5())) {
						args1.add("Y");
						args1.add(Integer.toString(counter));
					} else {
						args1.add("");
						args1.add("");
					}
					args1.add(Integer.toString(mouseOverNumArray[4]));
					if (mouseOverNumArray[4]>0){
						args1.add("Y");
					}else {
						args1.add("");
					}
				} else {
					args1.add("");
					args1.add("");
					args1.add("");
					args1.add("");
					args1.add("");
					args1.add("");
				}
				if(divisionKeyLvl==1){
					args1.add("Y");
				}else{
					args1.add("");
				}
				pickSql = 2;
				success=this.getAlertRuleDefinitionSQLService().insertAlertRulePresnRule(connection,failureList,args1,alertRuleDefinition,pickSql);	
			}
		}
	
		List args2 = new ArrayList();
		int counter = 1;
		args2.add(Integer.toString(newPresnId));
		if ("Record".equals(tempTiming)|| "BillRound".equals(tempTiming) || "CallDayWeek".equals(tempTiming)|| "Monthly".equals(tempTiming)){
			if ("on".equals(alertRuleDefinition.getFileSequenceIndicator())){
				args2.add("Y");
			} else {
				args2.add("N");
			}
		}else {
			args2.add("N");
		}
		args2.add(Integer.toString(tt));
		
		List alertKeyList = alertRuleDefinition.getAlertKeyList();
		int alertKeyListSize = alertKeyList.size();
		AlertKey alertKey = (AlertKey)alertKeyList.get(0);
		int alertKeyLevel = alertRuleDefinition.getAlertKeyLevel();
		if (alertKey.getKey1() != null && tt >= 1){
			args2.add("ALERT_KEY1");
			args2.add(alertKey.getKey1());
			if (!"---Select---".equals(alertRuleDefinition.getReportLinkKey1())) {
				args2.add("Y");
				args2.add(Integer.toString(counter));
				counter++;
			} else {
				args2.add("");
				args2.add("");
			}
			args2.add(Integer.toString(mouseOverNumArray[0]));
		} else {
			args2.add("");
			args2.add("");
			args2.add("");
			args2.add("");
			args2.add("");
		}
		if (alertKey.getKey2() != null && tt >= 2){
			args2.add("ALERT_KEY2");
			args2.add(alertKey.getKey2());
			if (!"---Select---".equals(alertRuleDefinition.getReportLinkKey2())) {
				args2.add("Y");
				args2.add(Integer.toString(counter));
				counter++;
			} else {
				args2.add("");
				args2.add("");
			}
			args2.add(Integer.toString(mouseOverNumArray[1]));
			if (mouseOverNumArray[1]>0){
				args2.add("Y");
			}else {
				args2.add("");
			}
		} else {
			args2.add("");
			args2.add("");
			args2.add("");
			args2.add("");
			args2.add("");
			args2.add("");
		}
		if (alertKey.getKey3() != null && tt >= 3){
			args2.add("ALERT_KEY3");
			args2.add(alertKey.getKey3());
			if (!"---Select---".equals(alertRuleDefinition.getReportLinkKey3())) {
				args2.add("Y");
				args2.add(Integer.toString(counter));
				counter++;
			} else {
				args2.add("");
				args2.add("");
			}
			args2.add(Integer.toString(mouseOverNumArray[2]));
			if (mouseOverNumArray[2]>0){
				args2.add("Y");
			}else {
				args2.add("");
			}
		} else {
			args2.add("");
			args2.add("");
			args2.add("");
			args2.add("");
			args2.add("");
			args2.add("");
		}
		if (alertKey.getKey4() != null && tt >= 4){
			args2.add("ALERT_KEY4");
			args2.add(alertKey.getKey4());
			if (!"---Select---".equals(alertRuleDefinition.getReportLinkKey4())) {
				args2.add("Y");
				args2.add(Integer.toString(counter));
				counter++;
			} else {
				args2.add("");
				args2.add("");
			}
			args2.add(Integer.toString(mouseOverNumArray[3]));
			if (mouseOverNumArray[3]>0){
				args2.add("Y");
			}else {
				args2.add("");
			}
		} else {
			args2.add("");
			args2.add("");
			args2.add("");
			args2.add("");
			args2.add("");
			args2.add("");
		}
		if (alertKey.getKey5() != null && tt >= 5){
			args2.add("ALERT_KEY5");
			args2.add(alertKey.getKey5());
			if (!"---Select---".equals(alertRuleDefinition.getReportLinkKey5())) {
				args2.add("Y");
				args2.add(Integer.toString(counter));
				counter++;
			} else {
				args2.add("");
				args2.add("");
			}
			args2.add(Integer.toString(mouseOverNumArray[4]));
			if (mouseOverNumArray[4]>0){
				args2.add("Y");
			}else {
				args2.add("");
			}
		} else {
			args2.add("");
			args2.add("");
			args2.add("");
			args2.add("");
			args2.add("");
			args2.add("");
		}
		if(divisionKeyLvl==1){
			args2.add("Y");
		}else{
			args2.add("");
		}
		pickSql = 3;
		success=this.getAlertRuleDefinitionSQLService().insertAlertRulePresnRule(connection,failureList,args2,alertRuleDefinition,pickSql);
		return success;
	}
	
	/**
	 * Inserts Data into RABC_ALERT_RULE_PRESN_RULE table for Trending rule.
	 * 
	 * @param connection
	 * @param failureList
	 * @param alertRuleDefinition
	 * @param tempTiming
	 * @param newPresnId
	 * @param divisionKeyLvl
	 * @param mouseOverNumArray
	 * @return boolean
	 */
	private boolean insertAlertRulePresnRuleTrend(Connection connection, List failureList, AlertRuleDefinition alertRuleDefinition, String tempTiming, int newPresnId, int divisionKeyLvl, int[] mouseOverNumArray){
		List webIDLList = new ArrayList();
		String ruleName;
		int alertKeyLevel = 0;
		boolean success = true;
		int pickSql = 0;
		
		webIDLList.add("RABCPSF00011");
		webIDLList.add("RABCPSF00013");
		
		if ("DT".equals(tempTiming)){
			ruleName = alertRuleDefinition.getAlertRule() + "-DAILY";
		}else {
			ruleName = alertRuleDefinition.getAlertRule();
		}
		
		alertKeyLevel = alertRuleDefinition.getAlertKeyLevel();
			
		int webIDLListSize =  webIDLList.size();
		int ind = webIDLListSize;
		
		String wb;
		for (int i = 0; i < webIDLListSize; i++){
			wb = (String)webIDLList.get(i);
			
			if ("RABCPSF00013".equals(wb)) {
				List args = new ArrayList();
				int counter = 1;
				args.add(Integer.toString(newPresnId));
				args.add(wb);
				
				if ("on".equals(alertRuleDefinition.getFileSequenceIndicator())){
					args.add("Y");
				}else {
					args.add("N");
				}
				
				List alertKeyList = alertRuleDefinition.getAlertKeyList();
				int alertKeyListSize = alertKeyList.size();
				AlertKey alertKey = (AlertKey)alertKeyList.get(0);
							
				if (alertKey.getKey1() != null && alertKeyLevel >= 1){
					args.add("EXTRCT_KEY1");
					args.add(alertKey.getKey1());
					args.add(Integer.toString(mouseOverNumArray[0]));
					if (!"---Select---".equals(alertRuleDefinition.getReportLinkKey1())) {
						args.add("Y");
						args.add(Integer.toString(counter));
						counter++;
					} else {
						args.add("");
						args.add("");
					}
				} else {
					args.add("");
					args.add("");
					args.add("");
					args.add("");
					args.add("");
				}
				if (alertKey.getKey2() != null && alertKeyLevel >= 2){
					args.add("EXTRCT_KEY2");
					args.add(alertKey.getKey2());
					args.add(Integer.toString(mouseOverNumArray[1]));
					if (!"---Select---".equals(alertRuleDefinition.getReportLinkKey2())) {
						args.add("Y");
						args.add(Integer.toString(counter));
						counter++;
					} else {
						args.add("");
						args.add("");
					}
				} else {
					args.add("");
					args.add("");
					args.add("");
					args.add("");
					args.add("");
				}
				if (alertKey.getKey3() != null && alertKeyLevel >= 3){
					args.add("EXTRCT_KEY3");
					args.add(alertKey.getKey3());
					args.add(Integer.toString(mouseOverNumArray[2]));
					if (!"---Select---".equals(alertRuleDefinition.getReportLinkKey3())) {
						args.add("Y");
						args.add(Integer.toString(counter));
						counter++;
					} else {
						args.add("");
						args.add("");
					}
				} else {
					args.add("");
					args.add("");
					args.add("");
					args.add("");
					args.add("");
				}
				if (alertKey.getKey4() != null && alertKeyLevel >= 4){
					args.add("EXTRCT_KEY4");
					args.add(alertKey.getKey4());
					args.add(Integer.toString(mouseOverNumArray[3]));
					if (!"---Select---".equals(alertRuleDefinition.getReportLinkKey4())) {
						args.add("Y");
						args.add(Integer.toString(counter));
						counter++;
					} else {
						args.add("");
						args.add("");
					}
				} else {
					args.add("");
					args.add("");
					args.add("");
					args.add("");
					args.add("");
				}
				if (alertKey.getKey5() != null && alertKeyLevel >= 5){
					args.add("EXTRCT_KEY5");
					args.add(alertKey.getKey5());
					args.add(Integer.toString(mouseOverNumArray[4]));
					if (!"---Select---".equals(alertRuleDefinition.getReportLinkKey5())) {
						args.add("Y");
						args.add(Integer.toString(counter));
					} else {
						args.add("");
						args.add("");
					}
				} else {
					args.add("");
					args.add("");
					args.add("");
					args.add("");
					args.add("");
				}
				if(divisionKeyLvl==1){
					args.add("Y");
				}else{
					args.add("");
				}
				args.add(Integer.toString(alertRuleDefinition.getAlertKeyLevel()));
				
				/*
				 * Code added to insert the key<i>_desc_ind for key 2 to key 5
				 */
				if (alertKey.getKey2() != null && alertKeyLevel >= 2 && mouseOverNumArray[1]>0){
					args.add("Y");
				}else {
					args.add("");
				}
				if (alertKey.getKey3() != null && alertKeyLevel >= 3 && mouseOverNumArray[2]>0){
					args.add("Y");
				}else {
					args.add("");
				}
				if (alertKey.getKey4() != null && alertKeyLevel >= 4 && mouseOverNumArray[3]>0){
					args.add("Y");
				}else {
					args.add("");
				}
				if (alertKey.getKey5() != null && alertKeyLevel >= 5 && mouseOverNumArray[4]>0){
					args.add("Y");
				}else {
					args.add("");
				}
				
				success = this.getAlertRuleDefinitionSQLService().insertAlertRulePresnRule(connection,failureList,args,alertRuleDefinition,pickSql);
			} else {
				List args = new ArrayList();
				args.add(Integer.toString(newPresnId));
				args.add(wb);
				
				if ("on".equals(alertRuleDefinition.getFileSequenceIndicator())){
					args.add("Y");
				}else {
					args.add("N");
				}
				
				List alertKeyList = alertRuleDefinition.getAlertKeyList();
				int alertKeyListSize = alertKeyList.size();
				AlertKey alertKey = (AlertKey)alertKeyList.get(0);
							
				if (alertKey.getKey1() != null && alertKeyLevel >= 1){
					args.add("EXTRCT_KEY1");
					args.add(alertKey.getKey1());
					args.add(Integer.toString(mouseOverNumArray[0]));
					args.add("Y");
					args.add("1");
				} else {
					args.add("");
					args.add("");
					args.add("");
					args.add("");
					args.add("");
				}
				if (alertKey.getKey2() != null && alertKeyLevel >= 2){
					args.add("EXTRCT_KEY2");
					args.add(alertKey.getKey2());
					args.add(Integer.toString(mouseOverNumArray[1]));
					args.add("");
					args.add("");
				} else {
					args.add("");
					args.add("");
					args.add("");
					args.add("");
					args.add("");
				}
				if (alertKey.getKey3() != null && alertKeyLevel >= 3){
					args.add("EXTRCT_KEY3");
					args.add(alertKey.getKey3());
					args.add(Integer.toString(mouseOverNumArray[2]));
					args.add("");
					args.add("");
				} else {
					args.add("");
					args.add("");
					args.add("");
					args.add("");
					args.add("");
				}
				if (alertKey.getKey4() != null && alertKeyLevel >= 4){
					args.add("EXTRCT_KEY4");
					args.add(alertKey.getKey4());
					args.add(Integer.toString(mouseOverNumArray[3]));
					args.add("");
					args.add("");
				} else {
					args.add("");
					args.add("");
					args.add("");
					args.add("");
					args.add("");
				}
				if (alertKey.getKey5() != null && alertKeyLevel >= 5){
					args.add("EXTRCT_KEY5");
					args.add(alertKey.getKey5());
					args.add(Integer.toString(mouseOverNumArray[4]));
					args.add("");
					args.add("");
				} else {
					args.add("");
					args.add("");
					args.add("");
					args.add("");
					args.add("");
				}
				if(divisionKeyLvl==1){
					args.add("Y");
				}else{
					args.add("");
				}
				args.add(Integer.toString(alertRuleDefinition.getAlertKeyLevel()));
				
				/*
				 * Code added to insert the key<i>_desc_ind for key 2 to key 5
				 */
				if (alertKey.getKey2() != null && alertKeyLevel >= 2 && mouseOverNumArray[1]>0){
					args.add("Y");
				}else {
					args.add("");
				}
				if (alertKey.getKey3() != null && alertKeyLevel >= 3 && mouseOverNumArray[2]>0){
					args.add("Y");
				}else {
					args.add("");
				}
				if (alertKey.getKey4() != null && alertKeyLevel >= 4 && mouseOverNumArray[3]>0){
					args.add("Y");
				}else {
					args.add("");
				}
				if (alertKey.getKey5() != null && alertKeyLevel >= 5 && mouseOverNumArray[4]>0){
					args.add("Y");
				}else {
					args.add("");
				}
				
				success = this.getAlertRuleDefinitionSQLService().insertAlertRulePresnRule(connection,failureList,args,alertRuleDefinition,pickSql);
			}
		}	
		return success;
	}
	
	/**
	 * Inserts Data into RABC_MENU_INDEX table for trend and track rules.
	 * 
	 * @param connection
	 * @param failureList
	 * @param tempTiming
	 * @param newPresnId
	 * @param alertRuleDefinition
	 * @param Mnu
	 * @param iteration
	 * @return boolean
	 */
	private boolean insertMenuIndex(Connection connection, List failureList, String tempTiming, int newPresnId, AlertRuleDefinition alertRuleDefinition, int Mnu, int iteration){
		int maxPresnSeqNum = this.getAlertRuleDefinitionSQLService().getMPSN(connection,failureList);
		String ruleName;
		boolean success =true;
		
		if ("DT".equals(tempTiming)){
			ruleName = alertRuleDefinition.getAlertRule() + "-DAILY";
		}else {
			ruleName = alertRuleDefinition.getAlertRule();
		}
		int pickSQL = 0;
		int maxPresnSeqNum1;
		String pName = ruleName;
		
		if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
			if ((alertRuleDefinition.getAlertKeyLevel()>0 && "on".equals(alertRuleDefinition.getFileSequenceIndicator()))){
				if (!"DT".equals(tempTiming)){
					List args1 = new ArrayList();
					
					args1.add(pName);
					args1.add(Integer.toString(maxPresnSeqNum+1));
					args1.add(Integer.toString(Mnu));
					args1.add(Integer.toString(iteration+1));
					args1.add(Integer.toString(newPresnId));
					args1.add(ruleName);
					pickSQL = 1;
					success=this.getAlertRuleDefinitionSQLService().insertMenuIndex(connection,failureList,args1,alertRuleDefinition,pickSQL);
				}
				maxPresnSeqNum1 = maxPresnSeqNum +1;
				
				List args2 = new ArrayList();
				args2.add(ruleName);
				args2.add(Integer.toString(maxPresnSeqNum+1));
				args2.add(Integer.toString(Mnu));
				args2.add(Integer.toString(maxPresnSeqNum1));
				args2.add(Integer.toString(newPresnId));
				args2.add(ruleName);
				pickSQL = 2;
				success=this.getAlertRuleDefinitionSQLService().insertMenuIndex(connection,failureList,args2,alertRuleDefinition,pickSQL);
			} else {
				List args1 = new ArrayList();
				args1.add(ruleName);
				args1.add(Integer.toString(maxPresnSeqNum+1));
				args1.add(Integer.toString(Mnu));
				args1.add(Integer.toString(iteration+1));
				args1.add(Integer.toString(newPresnId));
				args1.add(ruleName);
				pickSQL = 1;
				success=this.getAlertRuleDefinitionSQLService().insertMenuIndex(connection,failureList,args1,alertRuleDefinition,pickSQL);
			}
			
			List args3 = new ArrayList();
			args3.add(ruleName);
			if ("Record".equals(tempTiming)){
				args3.add(Integer.toString(4));
				args3.add(Integer.toString(4));
			} else if ("CallDayWeek".equals(tempTiming)){
				args3.add(Integer.toString(1));
				args3.add(Integer.toString(1));
			}else if ("Monthly".equals(tempTiming)){
				args3.add(Integer.toString(3));
				args3.add(Integer.toString(3));
			}else {
				args3.add(Integer.toString(2));
				args3.add(Integer.toString(2));
			}
			args3.add(Integer.toString(newPresnId));
			args3.add(ruleName);
			pickSQL = 3;
			success=this.getAlertRuleDefinitionSQLService().insertMenuIndex(connection,failureList,args3,alertRuleDefinition,pickSQL);	
		} else {
			List args1 = new ArrayList();
			args1.add(ruleName);
			args1.add(Integer.toString(maxPresnSeqNum+1));
			args1.add(Integer.toString(Mnu));
			args1.add(Integer.toString(iteration+1));
			args1.add(Integer.toString(newPresnId));
			args1.add(ruleName);
			
			pickSQL = 1;
			success=this.getAlertRuleDefinitionSQLService().insertMenuIndex(connection,failureList,args1,alertRuleDefinition,pickSQL);
			
			List args2 = new ArrayList();
			args2.add(ruleName);
			if ("Record".equals(tempTiming)){
				args2.add(Integer.toString(4));
				args2.add(Integer.toString(4));
			}else if ("CallDayWeek".equals(tempTiming)){
				args2.add(Integer.toString(1));
				args2.add(Integer.toString(1));
			}else if ("Monthly".equals(tempTiming)){
				args2.add(Integer.toString(3));
				args2.add(Integer.toString(3));
			}else {
				args2.add(Integer.toString(2));
				args2.add(Integer.toString(2));
			}
			args2.add(Integer.toString(newPresnId));
			args2.add(ruleName);
			pickSQL = 2;
			success=this.getAlertRuleDefinitionSQLService().insertMenuIndex(connection,failureList,args2,alertRuleDefinition,pickSQL);
		}
		return success;
	}
	
	/**
	 * Inserts Data into RABC_STD_CALC table for trend and track rules.
	 * 
	 * @param connection
	 * @param failureList
	 * @param tempTiming
	 * @param newPartiId
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean insertStdCalc(Connection connection, List failureList, String tempTiming, int newPartiId,AlertRuleDefinition alertRuleDefinition){
		List args = new ArrayList();
		String ruleName;
		int stdNumDate = 0;
		String stdTrendTimeInd;
		boolean success = true;

		if("Record".equals(tempTiming)){
			stdNumDate = 95;
			stdTrendTimeInd = "S";
		}else if("BillRound".equals(tempTiming)){
			stdNumDate = 380;
			stdTrendTimeInd = "B";
		}else if("CallDayWeek".equals(tempTiming)){
			stdNumDate = 190;	
			stdTrendTimeInd = "D";	
		}else if("Monthly".equals(tempTiming)){
			stdNumDate = 95;	
			stdTrendTimeInd = "M";	
		}else{
			stdNumDate = 190;
			stdTrendTimeInd = "D";	
		}
		
		if ("DT".equals(tempTiming)){
			ruleName = alertRuleDefinition.getAlertRule() + "-DAILY";
		}else {
			ruleName = alertRuleDefinition.getAlertRule();
		}
		
		args.add(ruleName);
		args.add(Integer.toString(newPartiId));
		if (alertRuleDefinition.getStdNumDate()!=null && !"".equals(alertRuleDefinition.getStdNumDate())){
			args.add(alertRuleDefinition.getStdNumDate());
		} else {
			args.add(Integer.toString(stdNumDate));
		}
		
		args.add(stdTrendTimeInd);
		
		success = this.getAlertRuleDefinitionSQLService().insertStdCalc(connection,failureList,args,alertRuleDefinition);
		return success;
	}
	
	/**
	 * Inserts Data into RABC_WEB_DATA_LINK table for a track rule.
	 * 
	 * @param connection
	 * @param failureList
	 * @param newPresnId
	 * @param divisionKeyLvl
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean insertWebDataLinkForTrack(Connection connection, List failureList, int newPresnId, int divisionKeyLvl,AlertRuleDefinition alertRuleDefinition){
		boolean success =true;
		int pickSql =0;
		int counter = 1;
		
		List args1 = new ArrayList();
		args1.add(Integer.toString(newPresnId));
		args1.add(Integer.toString(newPresnId));
		pickSql = 1;
		success = this.getAlertRuleDefinitionSQLService().insertWebDataLink(connection,failureList,args1,alertRuleDefinition,pickSql);
		
		if (divisionKeyLvl == 1){
			List args2 = new ArrayList();
			args2.add(Integer.toString(newPresnId));
			args2.add(Integer.toString(newPresnId));
			pickSql = 2;
			success = this.getAlertRuleDefinitionSQLService().insertWebDataLink(connection,failureList,args2,alertRuleDefinition,pickSql);
		}
		
		int alertKeyLevel = alertRuleDefinition.getAlertKeyLevel();
		List args3 = null;
		String reportLinkKey = null;
		String[] presnIdAlertRule = null;
		for (int i=1; i<=alertKeyLevel; i++) {
			switch(i) {
				case 1: reportLinkKey = alertRuleDefinition.getReportLinkKey1();
						break;
				case 2: reportLinkKey = alertRuleDefinition.getReportLinkKey2();
						break;
				case 3: reportLinkKey = alertRuleDefinition.getReportLinkKey3();
						break;
				case 4: reportLinkKey = alertRuleDefinition.getReportLinkKey4();
						break;
				case 5: reportLinkKey = alertRuleDefinition.getReportLinkKey5();
						break;
				default: reportLinkKey = "";
						break;
			}
			if (!"".equals(reportLinkKey) && !"---Select---".equals(reportLinkKey)) {
				presnIdAlertRule = reportLinkKey.split("~");
				args3 = new ArrayList();
				args3.add(Integer.toString(newPresnId));
				args3.add(Integer.toString(counter));
				counter++;
				args3.add(presnIdAlertRule[1]);
				args3.add(presnIdAlertRule[0]);
				pickSql = 3;
				success = this.getAlertRuleDefinitionSQLService().insertWebDataLink(connection,failureList,args3,alertRuleDefinition,pickSql);
			}
		}
		
		return success;
	}
	
	/**
	 * Inserts Data into RABC_WEB_DATA_LINK table for a trend rule.
	 * 
	 * @param connection
	 * @param failureList
	 * @param newPresnId
	 * @param divisionKeyLvl
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean insertWebDataLinkForTrend(Connection connection, List failureList, int newPresnId, int divisionKeyLvl,AlertRuleDefinition alertRuleDefinition){
		boolean success =true;
		int pickSql = 0;
		int counter = 1;
		
		List args1 = new ArrayList();
		args1.add(Integer.toString(newPresnId));
		args1.add(Integer.toString(newPresnId));
		pickSql = 2;
		success = this.getAlertRuleDefinitionSQLService().insertWebDataLink(connection,failureList,args1,alertRuleDefinition,pickSql);
		
		if (divisionKeyLvl == 1){
			List args2 = new ArrayList();
			args2.add(Integer.toString(newPresnId));
			args2.add(Integer.toString(newPresnId));
			pickSql = 1;
			success = this.getAlertRuleDefinitionSQLService().insertWebDataLink(connection,failureList,args2,alertRuleDefinition,pickSql);
		}
		
		int alertKeyLevel = alertRuleDefinition.getAlertKeyLevel();
		List args3 = null;
		String reportLinkKey = null;
		String[] presnIdAlertRule = null;
		for (int i=1; i<=alertKeyLevel; i++) {
			switch(i) {
				case 1: reportLinkKey = alertRuleDefinition.getReportLinkKey1();
						break;
				case 2: reportLinkKey = alertRuleDefinition.getReportLinkKey2();
						break;
				case 3: reportLinkKey = alertRuleDefinition.getReportLinkKey3();
						break;
				case 4: reportLinkKey = alertRuleDefinition.getReportLinkKey4();
						break;
				case 5: reportLinkKey = alertRuleDefinition.getReportLinkKey5();
						break;
				default: reportLinkKey = "";
						break;
			}
			if (!"".equals(reportLinkKey) && !"---Select---".equals(reportLinkKey)) {
				presnIdAlertRule = reportLinkKey.split("~");
				args3 = new ArrayList();
				args3.add(Integer.toString(newPresnId));
				args3.add(Integer.toString(counter));
				counter++;
				args3.add(presnIdAlertRule[1]);
				args3.add(presnIdAlertRule[0]);
				pickSql = 3;
				success = this.getAlertRuleDefinitionSQLService().insertWebDataLink(connection,failureList,args3,alertRuleDefinition,pickSql);
			}
		}
		
		/*
		 * Insert report link values for columns
		 */
		int columnCounter = counter;
		List alertItemList = alertRuleDefinition.getAlertItemList();
		if (!alertItemList.isEmpty()){
			int alertItemListSize = alertItemList.size();
			for (int i=0; i<alertItemListSize; i++) {
				AlertItem alertItem = (AlertItem)alertItemList.get(i);
				if (alertItem.getReportLinkData()!=null && !"---Select---".equals(alertItem.getReportLinkData())){
					presnIdAlertRule = alertItem.getReportLinkData().split("~");
					args3 = new ArrayList();
					args3.add(Integer.toString(newPresnId));
					args3.add(Integer.toString(columnCounter));
					columnCounter++;
					args3.add(presnIdAlertRule[1]);
					args3.add(presnIdAlertRule[0]);
					pickSql = 3;
					success = this.getAlertRuleDefinitionSQLService().insertWebDataLink(connection,failureList,args3,alertRuleDefinition,pickSql);
				}
			}
		}
		
		return success;
	}	
	
	/**
	 * Inserts Data into RABC_MOUSE_OVER_LINK table for track and trend rules.
	 * 
	 * @param connection
	 * @param failureList
	 * @param newPresnId
	 * @param alertRuleDefinition
	 * @param mouseOverNumArray
	 * @return boolean
	 */
	private boolean insertMouseOverLink(Connection connection, List failureList, int newPresnId, AlertRuleDefinition alertRuleDefinition, int[] mouseOverNumArray){
		List pageList = new ArrayList();
		boolean success = true;
		int alertKeyLevel = alertRuleDefinition.getAlertKeyLevel();
		
		if("Track".equals(alertRuleDefinition.getAlertRuleType())){
			pageList.add("RABCPSF00011");
			pageList.add("RABCPSF00012");
			pageList.add("RABCPSF00013");
		}
		
		if ("on".equals(alertRuleDefinition.getFileSequenceIndicator()) && "Track".equals(alertRuleDefinition.getAlertRuleType())){
			pageList.add("RABCPSF00014");
		}
		
		if("Trend".equals(alertRuleDefinition.getAlertRuleType())){
			pageList = new ArrayList();
			pageList.add("RABCPSF00011");
			pageList.add("RABCPSF00013");
		}
		
		int pageListSize = pageList.size();
		int mouseOverNum = 0;
		String mouseOverTableKey = null;
		
		for (int i = 0; i < pageListSize; i++){
			mouseOverNum = 0;
			for (int j = 1; j <= alertKeyLevel; j++){
				switch(j) {
				case 1: mouseOverTableKey = alertRuleDefinition.getMouseOverTableKey1();
						break;
				case 2: mouseOverTableKey = alertRuleDefinition.getMouseOverTableKey2();
						break;
				case 3: mouseOverTableKey = alertRuleDefinition.getMouseOverTableKey3();
						break;
				case 4: mouseOverTableKey = alertRuleDefinition.getMouseOverTableKey4();
						break;
				case 5: mouseOverTableKey = alertRuleDefinition.getMouseOverTableKey5();
						break;
				default: mouseOverTableKey = "";
						break;
				}
				if (!"".equals(mouseOverTableKey) && !"---Select---".equals(mouseOverTableKey)) {
					mouseOverNum++;
					mouseOverNumArray[j-1] = mouseOverNum;
					String pgl = (String) pageList.get(i);
					List args = new ArrayList();
					args.add(Integer.toString(newPresnId));
					args.add(pgl);
					args.add(Integer.toString(mouseOverNum));
					StringTokenizer st = new StringTokenizer(mouseOverTableKey,"~");
					while (st.hasMoreTokens()){
						args.add(st.nextToken());
					}
					success = this.getAlertRuleDefinitionSQLService().insertMouseOverLink(connection,failureList,args);
				}else {
					mouseOverNumArray[j-1] = 0;
				}				
			}
		}
		return success; 
	}

	/**
	 * Inserts Data into RABC_WEB_HEADER_LINK table for track and trend rules.
	 * 
	 * @param connection
	 * @param failureList
	 * @param tempTiming
	 * @param newPresnId
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean insertWebHeaderLink(Connection connection, List failureList, String tempTiming, int newPresnId, AlertRuleDefinition alertRuleDefinition){
		boolean success = true;
		String LLP = null;
		List pageList = new ArrayList();
		String linkDaily = "View Report,Create Report,Email Report"; 
		String link = "Previous Data,Next Data,View Report,Create Report,Email Report"; 
		String link12 = "Create Report,Email Report";
		int pickSql = 0;
		
		if ("Track".equals(alertRuleDefinition.getAlertRuleType())) {
			pageList.add("RABCPSF00011");
			pageList.add("RABCPSF00012");
			pageList.add("RABCPSF00013");
		} else {
			pageList.add("RABCPSF00011");
			pageList.add("RABCPSF00013");
		}
		int pageListSize =  pageList.size();

		if ("Track".equals(alertRuleDefinition.getAlertRuleType())) {
			for (int i = 0; i < pageListSize; i++){
				String pgl = (String) pageList.get(i);
				if ("DT".equals(tempTiming)){
					
					if ("RABCPSF00012".equals(pgl)){
						LLP = link12;
					}else {
						LLP = link;
					}
					
					StringTokenizer st1 = new StringTokenizer(LLP,",");
					int iterator_1 = 0;
					while (st1.hasMoreTokens()){
						List args = new ArrayList();
						String currToken = st1.nextToken();
						String pname = "AdhocRpt.do";
						if ("Create Report".equals(currToken) && "RABCPSF00011".equals(pgl)){
							pname = "AlertTrckMainPage.do";
						} else if (!"Create Report".equals(currToken) && "RABCPSF00011".equals(pgl)){
							pname = "AlertTrckMainPage.do";
						}
						if("Track".equals(alertRuleDefinition.getAlertRuleType())){
							if ("RABCPSF00012".equals(pgl)){
								pname = "AlertTrckDataPage.do";
							}
						}
						if ("Create Report".equals(currToken) && "RABCPSF00013".equals(pgl)){
							pname = "AdhocRpt.do";
						} else if ("Email Report".equals(currToken) && "RABCPSF00013".equals(pgl)){
							pname = "AdhocRpt.do";
						}
						
						args.add(Integer.toString(newPresnId));
						args.add(pgl);
						args.add(Integer.toString(iterator_1+1));
						args.add(currToken);
						args.add(pname);
						args.add(Integer.toString(newPresnId));
						success = this.getAlertRuleDefinitionSQLService().insertWebHeaderLink(connection,failureList,args,alertRuleDefinition);
						iterator_1++;
					}
				} else if ("Record".equals(tempTiming) || "BillRound".equals(tempTiming) || "CallDayWeek".equals(tempTiming)|| "Monthly".equals(tempTiming)){
					if (!"on".equals(alertRuleDefinition.getFileSequenceIndicator())){
						LLP = link;
					} else {
						LLP = linkDaily;
					}
					
					if("Track".equals(alertRuleDefinition.getAlertRuleType())){
						if ("RABCPSF00012".equals(pgl)){
							LLP = link12;
						}
					}
					
					StringTokenizer st1 = new StringTokenizer(LLP,",");
					int iterator_2 = 0;
					while (st1.hasMoreTokens()){
						List args = new ArrayList();
						String currToken = st1.nextToken();
						String pname = "AdhocRpt.do";
						if ("Create Report".equals(currToken) && "RABCPSF00011".equals(pgl)){
							pname = "AlertTrckMainPage.do";
						} else if (!"Create Report".equals(currToken) && "RABCPSF00011".equals(pgl)){
							pname = "AlertTrckMainPage.do";
						}
						if("Track".equals(alertRuleDefinition.getAlertRuleType())){
							if ("RABCPSF00012".equals(pgl)){
								pname = "AlertTrckDataPage.do";
							}
						}
						if ("Create Report".equals(currToken) && "RABCPSF00013".equals(pgl)){
							pname = "AdhocRpt.do";
						} else if ("Email Report".equals(currToken) && "RABCPSF00013".equals(pgl)){
							pname = "AdhocRpt.do";
						}
						
						args.add(Integer.toString(newPresnId));
						args.add(pgl);
						args.add(Integer.toString(iterator_2+1));
						args.add(currToken);
						args.add(pname);
						args.add(Integer.toString(newPresnId));

						success = this.getAlertRuleDefinitionSQLService().insertWebHeaderLink(connection,failureList,args,alertRuleDefinition);
						iterator_2++;
					}
				}
			}
		} else {
			for (int i = 0; i < pageListSize; i++) {
				String pgl = (String) pageList.get(i);
				if(("Record".equals(tempTiming) && !"on".equals(alertRuleDefinition.getFileSequenceIndicator())) || ("BillRound".equals(tempTiming) && !"on".equals(alertRuleDefinition.getFileSequenceIndicator())) || ("CallDayWeek".equals(tempTiming) && !"on".equals(alertRuleDefinition.getFileSequenceIndicator())) || ("Monthly".equals(tempTiming) && !"on".equals(alertRuleDefinition.getFileSequenceIndicator()))) {
					StringTokenizer st1 = new StringTokenizer(link,",");
					int iterator_3 = 0;
					while (st1.hasMoreTokens()){
						List args = new ArrayList();
						String currToken = st1.nextToken();
						String pname = "AdhocRpt.do";
						
						if ("Create Report".equals(currToken) && "RABCPSF00011".equals(pgl)){
							pname = "AlertTrckMainPage.do";
						} else if (!"Create Report".equals(currToken) && "RABCPSF00011".equals(pgl)){
							pname = "AlertTrckMainPage.do";
						}

						if ("Create Report".equals(currToken) && "RABCPSF00013".equals(pgl)){
							pname = "AdhocRpt.do";
						} else if ("Email Report".equals(currToken) && "RABCPSF00013".equals(pgl)){
							pname = "AdhocRpt.do";
						}
						
						args.add(Integer.toString(newPresnId));
						args.add(pgl);
						args.add(Integer.toString(iterator_3+1));
						args.add(currToken);
						args.add(pname);
						args.add(Integer.toString(newPresnId));

						success = this.getAlertRuleDefinitionSQLService().insertWebHeaderLink(connection,failureList,args,alertRuleDefinition);
						iterator_3++;
					}
				} else if (("Record".equals(tempTiming) && "on".equals(alertRuleDefinition.getFileSequenceIndicator())) || ("BillRound".equals(tempTiming))) {
					StringTokenizer st1 = new StringTokenizer(linkDaily,",");
					int iterator_4 = 0;
					while (st1.hasMoreTokens()){
						List args = new ArrayList();
						String currToken = st1.nextToken();
						String pname;
						
						if ("Create Report".equals(currToken) && "RABCPSF00011".equals(pgl)){
							pname = "AlertTrckMainPage.do";
						} else if (!"Create Report".equals(currToken) && "RABCPSF00011".equals(pgl)){
							pname = "AlertTrckMainPage.do";
						}

						if ("Create Report".equals(currToken) && "RABCPSF00013".equals(pgl)){
							pname = "AdhocRpt.do";
						} else if ("Email Report".equals(currToken) && "RABCPSF00013".equals(pgl)){
							pname = "AdhocRpt.do";
						}else {
							pname = "AdhocRpt.do";
						}
						
						args.add(Integer.toString(newPresnId));
						args.add(pgl);
						args.add(Integer.toString(iterator_4+1));
						args.add(currToken);
						args.add(pname);
						args.add(Integer.toString(newPresnId));

						success = this.getAlertRuleDefinitionSQLService().insertWebHeaderLink(connection,failureList,args,alertRuleDefinition);
						iterator_4++;
					}
				}
			}
		}
		return success;
	}
	
	/**
	 * Inserts Data into RABC_PRESN_HEADER table for track and trend rules.
	 * 
	 * @param connection
	 * @param failureList
	 * @param newPresnId
	 * @param tempTiming
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean insertPresnHeader(Connection connection, List failureList, int newPresnId, String tempTiming, AlertRuleDefinition alertRuleDefinition){
		List webIDLList = new ArrayList();
		String ruleName;
		boolean success = true;
		String h3 = null;
		String w1 = null;
		String w = null; 
		
		if ("DT".equals(tempTiming)){
			ruleName = alertRuleDefinition.getAlertRule() + "-DAILY";
		}else {
			ruleName = alertRuleDefinition.getAlertRule();
		}
		
		webIDLList.add("RABCPSF00011");
		if("Track".equals(alertRuleDefinition.getAlertRuleType())){
			webIDLList.add("RABCPSF00012");
		}
		webIDLList.add("RABCPSF00013");
		
		if("Track".equals(alertRuleDefinition.getAlertRuleType())){
			if ("on".equals(alertRuleDefinition.getFileSequenceIndicator())){
				webIDLList.add("RABCPSF00014");
			}
		}
		int webIDLListSize =  webIDLList.size();
		
		for (int i = 0 ; i < webIDLListSize; i++){
			w = (String) webIDLList.get(i);
			if ("RABCPSF00012".equals(w)){
				w1 = "Control Data Report";
			}else if ("RABCPSF00011".equals(w)){
				w1 = "Control Alert Details";
			}else if ("RABCPSF00013".equals(w)){
				w1 = "Control Data History Report";
			}else if ("RABCPSF00014".equals(w)){
				w1 = "Control Alert Details";
			}
			
			if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
				if ("DT".equals(tempTiming)){
					h3 = "Tracking Daily Total";
				}else {
					h3 = "Tracking Alert Rule";
				}
			}else {
				if ("DT".equals(tempTiming)){
					h3 = "Trending Division Total";
				}else {
					h3 = "Trending Alert Rule";
				}
			}

			if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
				if ("RABCPSF00014".equals(w) && "on".equals(alertRuleDefinition.getFileSequenceIndicator())){
					//No code in CFM.
				} else {
					List args = new ArrayList();
					args.add(Integer.toString(newPresnId));
					args.add(w);
					args.add(w1);
					args.add("Alert Rule: " + ruleName);
					args.add(h3);
					
					success = this.getAlertRuleDefinitionSQLService().insertPresnHeader(connection,failureList,args,alertRuleDefinition);
				}
			} else {
				List args = new ArrayList();
				args.add(Integer.toString(newPresnId));
				args.add(w);
				args.add(w1);
				args.add("Alert Rule: " + ruleName);
				args.add(h3);
				
				success = this.getAlertRuleDefinitionSQLService().insertPresnHeader(connection,failureList,args,alertRuleDefinition);
			}	
		}
		return success;
	}

	/**
	 * Inserts Data into RABC_ALERT_SUPP_RULE table for track and trend rules.
	 * 
	 * @param connection
	 * @param failureList
	 * @param tempTiming
	 * @param newPartiId
	 * @param alertRuleDefinition
	 * @return boolean
	 */
	private boolean insertSuppRule(Connection connection, List failureList, String tempTiming, int newPartiId,AlertRuleDefinition alertRuleDefinition){
		String ruleName;
		boolean success =true;
		int pickSql =0;
		
		if ("DT".equals(tempTiming)){
			ruleName = alertRuleDefinition.getAlertRule() + "-DAILY";
		}else {
			ruleName = alertRuleDefinition.getAlertRule();
		}
		
		List args1 = new ArrayList();
		args1.add(Integer.toString(newPartiId));
		
		String dataDdlName = this.getAlertRuleDefinitionSQLService().getSelExtrctData(connection, failureList, args1);
		
		if (dataDdlName == null){
			dataDdlName = "EXTRCT_DATA1";
		}
		
		List alertItemList = alertRuleDefinition.getAlertItemList();
		int alertItemListSize = alertItemList.size();
		
		for (int i = 0; i < alertItemListSize; i++){
			AlertItem alertItem = (AlertItem)alertItemList.get(i);
			
			SupplementType supplementType = (SupplementType)alertItem.getSupplementType();
			String [] supplementColumnsArray = supplementType.getSelectedSupplementType();
			
			for (int j = 0; j < supplementColumnsArray.length; j++){
				List args2 = new ArrayList();
				args2.add(ruleName);
				args2.add(alertItem.getItemName());
				args2.add(Integer.toString((j+1)));
				
				if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
					args2.add(supplementColumnsArray[j]);
					args2.add(dataDdlName);
				} else {
					args2.add("EXTRCT_DATA" + (i+1));
				}
				args2.add(supplementColumnsArray[j]);
				success = this.getAlertRuleDefinitionSQLService().insertSuppRule(connection, failureList, args2, alertRuleDefinition);
			}
		}
		return success;
	}
	
	/**
	 * Inserts Data into RABC_ALERT_SUMY_PRESN table for a track rule.
	 * 
	 * @param connection
	 * @param failureList
	 * @param tempTiming
	 * @param relatedAlertRules
	 * @param alertRuleDefinition
	 * @param newPresnId
	 * @param presnIdArr
	 * @param ruleList
	 * @return boolean
	 */
	private boolean insertSumyPresnTrack (Connection connection, List failureList, String tempTiming, String [] relatedAlertRules,AlertRuleDefinition alertRuleDefinition, int newPresnId, int [] presnIdArr, List ruleList){
		String ruleName;
		boolean success =true;
		int pickSql =0;
		int sizeOfRelatedAlertRules = 0;
		int [] presnIdArray = new int[0];
		List webIDLList = new ArrayList();
		
		if(relatedAlertRules != null){
			sizeOfRelatedAlertRules = relatedAlertRules.length;
			presnIdArray = new int[sizeOfRelatedAlertRules];
		}
		
		webIDLList.add("RABCPSF00011");
		webIDLList.add("RABCPSF00012");
		if ("on".equals(alertRuleDefinition.getFileSequenceIndicator())){
			webIDLList.add("RABCPSF00014");
		}
		
		if ("DT".equals(tempTiming)){
			ruleName = alertRuleDefinition.getAlertRule() + "-DAILY";
		}else {
			ruleName = alertRuleDefinition.getAlertRule();
		}
		
		int webIDLListSize = webIDLList.size();
		
		for(int i = 0; i < sizeOfRelatedAlertRules; i++){
			List args1 = new ArrayList();
			args1.add(relatedAlertRules[i]);
			presnIdArray[i]=this.getAlertRuleDefinitionSQLService().getAsocPresnId(connection, failureList,args1,alertRuleDefinition);
		}
		if ("BillRound".equals(tempTiming) || "Record".equals(tempTiming) || "CallDayWeek".equals(tempTiming) || "Monthly".equals(tempTiming)){
					
			for (int i = 0; i < webIDLListSize; i++){
				List args2 = new ArrayList();
				args2.add(ruleName+"_SUMY1");
				args2.add(ruleName);
				args2.add(webIDLList.get(i));
				/*if(webIDLList.get(i).equals("RABCPSF00011")){
					if(presnIdArray.length > 0){
						args2.add(Integer.toString(presnIdArray[0]));
					} else {
						args2.add(Integer.toString(newPresnId));
					}
				}else{
					args2.add(Integer.toString(newPresnId));
				}*/
				args2.add(Integer.toString(newPresnId));
				pickSql = 1;
				success = this.getAlertRuleDefinitionSQLService().insertSumyPresn(connection,failureList,args2,alertRuleDefinition,pickSql);
			}
		
			if (sizeOfRelatedAlertRules >= 1){
				for (int i=0;i < sizeOfRelatedAlertRules;i++){
					List args = new ArrayList();
					args.add(ruleName+"_SUMY1");
					args.add(ruleName);
					args.add("RABCPSF00011");
					args.add(Integer.toString(i+2));
					args.add("N");
					args.add(Integer.toString(presnIdArray[i]));
					pickSql = 2;
					success = this.getAlertRuleDefinitionSQLService().insertSumyPresn(connection,failureList,args,alertRuleDefinition,pickSql);
				}
			}
		} else {
			int z = 1;
			int count = 1;
			int recPresnId = 1;
			int acinPresnId = 1;
			int dailyPresnId = 1;
			
			for (int i=0;i<presnIdArr.length;i++){
				if ((i+1) == count){
					recPresnId = presnIdArr[i];
				}else if ((i+1) == count) {
					acinPresnId = presnIdArr[i];
				}else {
					dailyPresnId = presnIdArr[i];
				}
				count = count + 1;
			}
			
			int Nind = 1;
			int r;
			int ruleListSize = ruleList.size();
			
			for (int iteration = 0; iteration < ruleListSize; iteration++) {
				String IR = (String)ruleList.get(iteration);
				if ("DT".equals(IR)){
					r =2;
					ruleName= alertRuleDefinition.getAlertRule() + "-DAILY";
				}else {
					r = 1;
					ruleName= alertRuleDefinition.getAlertRule();
				}
				for (int i=0;i<webIDLListSize;i++){
					String w = (String) webIDLList.get(i);
					String sumyName = ruleName + "_SUMY" + z;
					z = z + 1;
					
					String currRule = alertRuleDefinition.getAlertRule();;
					int PSN =1;
					String TI="N";
					int API=1;
					
					for (int k = 0; k < ruleListSize; k++) {
						String IR2 = (String)ruleList.get(k);
						
						if ("Record".equals(IR2)){
							currRule = alertRuleDefinition.getAlertRule();
							PSN = 1;
							TI = "N";
							API = recPresnId;
						}else if ("DT".equals(IR2)){
							currRule = alertRuleDefinition.getAlertRule() + "-DAILY";
							PSN = 2;
							TI = "Y";
							API = acinPresnId;
						} 
						
						if (("DT".equals(IR) && !"Record".equals(IR2)) || "Record".equals(IR)) {
							List args = new ArrayList();
							args.add(sumyName);
							args.add(currRule);
							args.add(w);
							args.add(Integer.toString(PSN));
							args.add(TI);
							args.add(Integer.toString(API));
							pickSql = 2;
							success = this.getAlertRuleDefinitionSQLService().insertSumyPresn(connection,failureList,args,alertRuleDefinition,pickSql);
						}
					}
				}
			}
		}
		return success;
	}
	
	/**
	 * Inserts Data into RABC_ALERT_SUMY_PRESN table for a trend rule.
	 * 
	 * @param connection
	 * @param failureList
	 * @param tempTiming
	 * @param relatedAlertRules
	 * @param alertRuleDefinition
	 * @param newPresnId
	 * @param presnIdArr
	 * @param ruleList
	 * @return boolean
	 */
	private boolean insertSumyPresnTrend(Connection connection, List failureList, String tempTiming, String [] relatedAlertRules,AlertRuleDefinition alertRuleDefinition, int newPresnId, int [] presnIdArr, List ruleList){
		int relatedAlertRulesLength = 0;
		
		if(relatedAlertRules != null){
			relatedAlertRulesLength = relatedAlertRules.length;
		}
		boolean success = true;
		String ruleName;
		int [] presnIdArray = new int[relatedAlertRulesLength];
		int pickSQL = 0;
		
		for (int i = 0; i < relatedAlertRulesLength; i++){
			List args1 = new ArrayList();
			args1.add(relatedAlertRules[i]);
			// Call the DAO to get the presn id & assign it to the array
			presnIdArray[i]=this.getAlertRuleDefinitionSQLService().getAsocPresnId(connection, failureList,args1,alertRuleDefinition);
		}
		
		if (!failureList.isEmpty()){
			return false;
		}
		
		ruleName = alertRuleDefinition.getAlertRule();
		String sName = ruleName + "_SUMY";
		List args = new ArrayList();
		args.add(sName);
		args.add(ruleName);
		args.add("RABCPSF00011");
		args.add("1");
		args.add(Integer.toString(newPresnId));
		if(alertRuleDefinition.getFileSequenceIndicator() != null){
			if(alertRuleDefinition.getFileSequenceIndicator().equals("on")){
				args.add("Y");
			} else {
				args.add("N");
			}
		} else {
		 	args.add("N");
		}
		
		success = this.getAlertRuleDefinitionSQLService().insertSumyPresn(connection,failureList,args,alertRuleDefinition,pickSQL);
		
		for (int i = 0; i < relatedAlertRulesLength; i++){
			List args1 = new ArrayList();
			args1.add(sName);
			args1.add(ruleName);
			args1.add("RABCPSF00011");
			args1.add(Integer.toString(i+1));
			args1.add(Integer.toString(presnIdArray[i]));
			if(alertRuleDefinition.getFileSequenceIndicator() != null){
				if(alertRuleDefinition.getFileSequenceIndicator().equals("on")){
					args1.add("Y");
				} else {
					args1.add("N");
				}
			} else {
				args1.add("N");
			}
			success = this.getAlertRuleDefinitionSQLService().insertSumyPresn(connection,failureList,args1,alertRuleDefinition,pickSQL);
		}		
		return success;
	}
}
