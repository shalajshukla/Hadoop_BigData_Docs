/*
 * Module description: 
 * This bean will parse an input record from the RABC.ACUS.CIS.INFO flat file. 
 *
 * Copyright 2007 ATT Knowledge Ventures. All rights reserved.
 *
 * Modification History:                                     
 * SBCUID		Date			Description                         	    	
 * ------		--------		-----------
 * KW2478		20070314		Initial version for EAP 286915
 * KW2478		20070412		Added new field acusInvoiceAdjAmount
 * KW2478		20070426		Removed StringTokenizer processing and replaced with String[] tokens Split 
 * KW2478		20070501		Changed all int and double fields to String  to allow nulls to be passed  
 * 								back for the fields that are nullable on the RABC_ACUS_CIS_INFO table  
 */
package com.att.bac.rabc.load.acus.calnet;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class InfoBean {
	public  static final String DELIMITER = "|";
	private static DateFormat date_formatter = new SimpleDateFormat("MM-dd-yyyy");

//	detail record values... these will be inserted into the detail table (RABC_ACUS_CIS_INFO).
	private String  providerName,
					btn,    
					billPayerAccount, 
					agencyId;
					
	private String 	providerReceivedAmount,
					providerProcessedAmount,
					adminFee,
					btnInvoiceAmount,
					acusInvoiceCharge,
					acusInvoiceAdjAmount;
						
	private Date 	providerInvoiceDate,
					acusInvoiceDate;  

	private String 	billRound;

	public static InfoBean valueOf(String value) throws ParseException {
		
		date_formatter.setLenient(false);
		String strToken = null;
		InfoBean detail = new InfoBean();
		
		String[] tokens = value.split("\\|",-1);
		
		detail.providerName = tokens[0].trim();
		if (detail.providerName.equals(""))
		{
			detail.providerName = null;
		}
		
		strToken = tokens[1].trim();
		if (strToken.equals(""))
		{
			detail.providerInvoiceDate = null;
		}
		else
		{
			detail.providerInvoiceDate = date_formatter.parse(strToken);
		}
		
		strToken = tokens[2].trim();
		if (strToken.equals(""))
		{
			detail.billRound = null;
		}
		else
		{
			int br = Integer.parseInt(strToken);
			detail.billRound = strToken;
		}		

		detail.btn = tokens[3].trim();

		strToken = tokens[4].trim();
		if (strToken.equals(""))
		{
			detail.providerReceivedAmount = null;
		}
		else
		{
			double pra = Double.parseDouble(strToken);
			detail.providerReceivedAmount = strToken;
		}		
		
		strToken = tokens[5].trim();
		if (strToken.equals(""))
		{
			detail.providerProcessedAmount = null;
		}
		else
		{
			double ppa = Double.parseDouble(strToken);
			detail.providerProcessedAmount = strToken;
		}		
		
		strToken = tokens[6].trim();
		if (strToken.equals(""))
		{
			detail.adminFee = null;
		}
		else
		{
			double af = Double.parseDouble(strToken);
			detail.adminFee = strToken;
		}		
		
		strToken = tokens[7].trim();
		if (strToken.equals(""))
		{
			detail.btnInvoiceAmount = null;
		}
		else
		{
			double bia = Double.parseDouble(strToken);
			detail.btnInvoiceAmount = strToken;
		}		
		
		strToken = tokens[8].trim();
		detail.acusInvoiceDate = date_formatter.parse(strToken);

		detail.billPayerAccount = tokens[9].trim();
		
		detail.agencyId = tokens[10].trim();
		if (detail.agencyId.equals(""))
		{
			detail.agencyId = null;
		}
		
		strToken = tokens[11].trim();
		if (strToken.equals(""))
		{
			detail.acusInvoiceCharge = null;
		}
		else
		{
			double aic = Double.parseDouble(strToken);
			detail.acusInvoiceCharge = strToken;
		}
		
		strToken = tokens[12].trim();
		if (strToken.equals(""))
		{
			detail.acusInvoiceAdjAmount = null;
		}
		else
		{
			double aiaa = Double.parseDouble(strToken);
			detail.acusInvoiceAdjAmount = strToken;
		}
		return detail;
	}

	public Date getAcusInvoiceDate() {
		return acusInvoiceDate;
	}
	public String getAdminFee() {
		return adminFee;
	}
	public String getAgencyId() {
		return agencyId;
	}
	public String getBillPayerAccount() {
		return billPayerAccount;
	}
	public String getBillRound() {
		return billRound;
	}
	public String getBtn() {
		return btn;
	}
	public String getBtnInvoiceAmount() {
		return btnInvoiceAmount;
	}
	public String getInvoiceCharge() {
		return acusInvoiceCharge;
	}
	public String getAcusInvAdjAmount() {
		return acusInvoiceAdjAmount;
	}
	public Date getProviderInvoiceDate() {
		return providerInvoiceDate;
	}
	public String getProviderName() {
		return providerName;
	}
	public String getProviderProcessedAmount() {
		return providerProcessedAmount;
	}
	public String getProviderReceivedAmount() {
		return providerReceivedAmount;
	}

}
