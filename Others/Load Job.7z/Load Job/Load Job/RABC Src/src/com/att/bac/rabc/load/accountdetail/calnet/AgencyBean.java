package com.att.bac.rabc.load.accountdetail.calnet;

import java.util.StringTokenizer;

public class AgencyBean {
	public static final String DELIMITER = ";";
	public static final String FILE_ID = "XT30AGCY";
	public static final String FILE_NAME_PATTERN = "WE.[CI].C\\d{4}."+FILE_ID+".D\\d{7}.T\\d{6}.(TXT|txt)";
	
	//fields populated directly for the XT30AGCY file.
	private String billingAccountId, croCode, btn, agencyId;
	
	//fields indirectly populated by XT30CRIS
	private String accountClassCode, accountName, activeAccountInd;
	
	public static AgencyBean valueOf(String agencyRecord){
		StringTokenizer tokenizer = new StringTokenizer(agencyRecord, DELIMITER);
		AgencyBean agency = new AgencyBean();
		String temp = tokenizer.nextToken();
		if(temp == null || !temp.equals(FILE_ID)){
			throw new IllegalArgumentException("file id is null or does not match "+FILE_ID+" :"+temp);
		}
		agency.setBillingAccountId(tokenizer.nextToken().trim());
		agency.setCroCode(tokenizer.nextToken());
		//BTN logic...
		StringBuffer buffer = new StringBuffer(13);
		buffer.append(tokenizer.nextToken()).append(tokenizer.nextToken()).append(tokenizer.nextToken());
		agency.setBtn(buffer.toString());
		agency.setAgencyId(tokenizer.nextToken().trim());
		return agency;
	}
	

	String getAgencyId() {
		return agencyId;
	}

	void setAgencyId(String agencyId) {
		this.agencyId = agencyId;
	}

	String getBillingAccountId() {
		return billingAccountId;
	}

	void setBillingAccountId(String billingAccountId) {
		this.billingAccountId = billingAccountId;
	}

	String getBtn() {
		return btn;
	}

	void setBtn(String btn) {
		this.btn = btn;
	}

	String getCroCode() {
		return croCode;
	}

	void setCroCode(String croCode) {
		this.croCode = croCode;
	}



	String getAccountClassCode() {
		return accountClassCode;
	}



	void setAccountClassCode(String accountClassCode) {
		this.accountClassCode = accountClassCode;
	}



	String getAccountName() {
		return accountName;
	}



	void setAccountName(String accountName) {
		this.accountName = accountName;
	}



	String getActiveAccountInd() {
		return activeAccountInd;
	}



	void setActiveAccountInd(String activeAccountInd) {
		this.activeAccountInd = activeAccountInd;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((accountClassCode == null) ? 0 : accountClassCode.hashCode());
		result = PRIME * result + ((accountName == null) ? 0 : accountName.hashCode());
		result = PRIME * result + ((activeAccountInd == null) ? 0 : activeAccountInd.hashCode());
		result = PRIME * result + ((agencyId == null) ? 0 : agencyId.hashCode());
		result = PRIME * result + ((billingAccountId == null) ? 0 : billingAccountId.hashCode());
		result = PRIME * result + ((btn == null) ? 0 : btn.hashCode());
		result = PRIME * result + ((croCode == null) ? 0 : croCode.hashCode());
		return result;
	}
	
	public boolean isFromAgencyFile(){
		return accountClassCode == null && accountName == null && activeAccountInd == null;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final AgencyBean other = (AgencyBean) obj;
		if (accountClassCode == null) {
			if (other.accountClassCode != null)
				return false;
		} else if (!accountClassCode.equals(other.accountClassCode))
			return false;
		if (accountName == null) {
			if (other.accountName != null)
				return false;
		} else if (!accountName.equals(other.accountName))
			return false;
		if (activeAccountInd == null) {
			if (other.activeAccountInd != null)
				return false;
		} else if (!activeAccountInd.equals(other.activeAccountInd))
			return false;
		if (agencyId == null) {
			if (other.agencyId != null)
				return false;
		} else if (!agencyId.equals(other.agencyId))
			return false;
		if (billingAccountId == null) {
			if (other.billingAccountId != null)
				return false;
		} else if (!billingAccountId.equals(other.billingAccountId))
			return false;
		if (btn == null) {
			if (other.btn != null)
				return false;
		} else if (!btn.equals(other.btn))
			return false;
		if (croCode == null) {
			if (other.croCode != null)
				return false;
		} else if (!croCode.equals(other.croCode))
			return false;
		return true;
	}
	
	  public String toString() {
		    StringBuffer result = new StringBuffer();

		    result.append(this.getClass().getName() + " Object {");
		    result.append(" btn: ");
		    result.append(this.btn);
		    result.append(",");
		    result.append(" accountClassCode: ");
		    result.append(this.accountClassCode);
		    result.append(",");
		    result.append(" accountName: ");
		    result.append(this.accountName);
		    result.append(",");
		    result.append(" activeAccountInd: ");
		    result.append(this.activeAccountInd);
		    result.append(",");
		    result.append(" agencyId: ");
		    result.append(this.agencyId);
		    result.append(",");
		    result.append(" billingAccountId: ");
		    result.append(this.billingAccountId);
		    result.append(",");
		    result.append(" croCode: ");
		    result.append(this.croCode);

		    result.append("}");

		    return result.toString();
		  }

	
	

}
