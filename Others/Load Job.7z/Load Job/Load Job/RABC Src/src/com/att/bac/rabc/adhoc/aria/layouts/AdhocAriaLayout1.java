/*
 * Copyright  2002-2006 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.adhoc.aria.layouts;

import java.io.BufferedWriter;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.text.NumberFormat;

import javax.naming.NamingException;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;

import com.att.bac.rabc.PagedForm;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.adhoc.aria.ARIAReportRABC;
import com.att.bac.rabc.adhoc.aria.AbstractAdhocAriaLayout;
import com.att.bac.rabc.adhoc.aria.IAdhocDTOIndex;
import com.att.bac.rabc.adhoc.aria.LayoutHelper;
import com.att.bac.rabc.adhoc.aria.pivot.DatedCompositeKey;
import com.att.bac.rabc.adhoc.rpt.AdhocRptDataTO;
import com.sbc.bac.aria.ARIAColumn;
import com.sbc.bac.aria.ARIADataPoint;
import com.sbc.bac.aria.ARIAHTMLPage13Processor;
import com.sbc.bac.aria.ARIAPaging;
import com.sbc.bac.aria.ARIAReportProcessor;
import com.sbc.bac.aria.ARIASimpleColumn;
import com.sbc.bac.aria.ARIAUtil;

import com.sbc.bac.aria.RowElement;


/**
 * Layout 1 for Adhoc reporting. This is "page 13".
 * 
 * <p>
 * <hr>
 * <h3>Release History</h3>
 * <p>
 * <ul>
 * 
 * <li>jb6494 Aug 01, 2006 Created class.
 * <li>jb6494 Feb 13, 2007 Added sorting icons to headers
 * <li>jb6494 Mar 03, 2007 Updated sorting for ST ML#08
 * <li>jb6494 Mar 13, 2007 ML11 Previous data in excel report
 * <li>jb6494 Mar 19, 2007 Kin: "6 month" label was being formatted as a date
 * <li>jb6494 Mar 19, 2007 ML#24: Assumed ownership of formatCellWithLinks and put code in not to add them to totals.
 * <li>jb6494 Mar 20, 2007 ML#09: Fix mouseover
 * 
 * </ul>
 * <p>
 * 
 */
public class AdhocAriaLayout1 extends AbstractAdhocAriaLayout {
    public static Logger logger = Logger.getLogger(AdhocAriaLayout1.class);

    private boolean oddRow;

    private int rows;
    private int actualRows;
    private int currentRowCount;
    private int[] actualRowCounts;
    
    /**
     * Create a layout with region info.
     */
    public AdhocAriaLayout1(ActionForm form, OutputStream os, String userid) {
        super(form, os, userid);
    }

    /**
	 * @return the actualRows
	 */
	public int getActualRows() {
		return actualRows;
	}

	/**
	 * @param actualRows the actualRows to set
	 */
	public void setActualRows(int actualRows) {
		this.actualRows = actualRows;
	}
	
	
	/**
	 * @return the currentRowCount
	 */
	public int getCurrentRowCount() {
		return currentRowCount;
	}

	/**
	 * @param currentRowCount the currentRowCount to set
	 */
	public void setCurrentRowCount(int currentRowCount) {
		this.currentRowCount = currentRowCount;
	}

	/*
     * (non-Javadoc)
     * 
     * @see com.att.bac.rabc.adhoc.rpt.AbstractAdhocAriaLayout#execute(int, java.sql.Connection, java.io.OutputStream)
     */
    public void execute(ARIAReportRABC[] reports, AdhocRptDataTO dto) throws Exception {
        setDtoBase(dto);
        try {
            ARIAHTMLPage13Processor processor = createProcessor(os);

            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(os));

            if (reports != null) {

                /*
                 * Calculate the max row count and also make an array of each reports row counts. We'll use the maxCount
                 * to determine the number of pages, and the rowCounts array to print the "total records" to the form.
                 */
                int maxRows = 0;
                int[] rowCounts = new int[reports.length];
                actualRowCounts = new int[reports.length];
                for (int i = 0; i < reports.length; i++) {
                    dto = reports[i].getDto();
                    logger.debug("START getReportCount...");
                    int rows = getReportCount(reports[i], true);
                    setActualRows(getReportCount(reports[i], false));
                    rowCounts[i] = rows;
                    actualRowCounts[i]= getActualRows();
                    maxRows = Math.max(maxRows, rows);
                    logger.debug("END getReportCount...");
                }

                /*
                 * Main loop to execute each report section.
                 */
                for (int i = 0; i < reports.length; i++) {
                    setDto(reports[i].getDto());
                    setSection(i);
                    bw.write("<span class=\"Title\" title=\"Number of data records only (without sub total and grand total rows)\">Total Records:</span>");
                    bw.write("<span style=' font-size:16px;color:purple;'>&nbsp;" + rowCounts[i] + "</span><br>\n");
                    bw.flush();

                    /*
                     * Setup paging for each report (section).
                     */
                    if (form instanceof PagedForm) {
                    	ARIAPaging paging = null;
            			if (processor.getPaging()==null){
            				paging = new ARIAPaging();
            			} else {
            				paging = processor.getPaging();
            			}
                        PagedForm pForm = (PagedForm) form;
                        paging.setRowsPerPage(getRowsPerPage());
                        paging.setCurrentPage(pForm.getPage());

                        int maxPage = (int) (((float) getReportCount(reports[i], false) / paging.getRowsPerPage()) + .99);
                        int pCount = Math.max(1, maxPage);
                        if (pCount > paging.getTotalPages()) {
                            paging.setTotalPages(pCount);
                            pForm.setPages(paging.getTotalPages());
                        }

                        reports[i].setPaging(paging);
                        processor.setPaging(paging);

                        /*
                         * Disable paging throughout
                         */
                        processor.setShowPaging(ARIAHTMLPage13Processor.PAGING_OFF);
                    }

                    setupPreviousDataTable(i);

                    rows = rowCounts[i];

                    /*
                     * RUN THE REPORT
                     */
                    logger.debug("ARIAReport execute starting...\nSQL:" + reports[i].toSQL());
                    rows = reports[i].execute(getConnection(), processor);
                    logger.debug("ARIAReport execute ending (rows=" + rows + ")...");

                    bw.write("<br>\n");
                    bw.flush();
                }
            }
            
            getDtoBase().setPagedHtml(renderPaging(processor.getPaging()));
            
            bw.flush();
            bw.close();

            /*
             * probably not needed, but it is good house keeping anyway
             */
            processor.setReportRenderer(null);
            processor.setRowRenderer(null);
            processor.setColumnFormatter(null);
            processor.setHeaderRenderer(null);
            processor.setPagingRenderer(null);

        } finally {
            closeConnection();
        }
    }


    /**
     * Call the super classes createReportFilters to create the "search criteria" and write it to the report stream
     */
    public String renderBeginReport(ARIAReportProcessor processor) {
        try {
            createReportFilters();
        } catch (RABCException e) {
            logger.error("AdhocAriaLayout1::renderBeginReport", e);
        }
        
        StringBuffer buf = new StringBuffer(100);
        buf.append("<table border=1 width=99% cellspacing=0 cellpadding=0>");
        String subHeader = "";
        try {
			subHeader = LayoutHelper.getSubHeader(dto, getConnection(), getSection(), logger);
		} catch (NamingException e) {
			logger.debug("Could not get the sub header" + e);
		} catch (SQLException e) {
			logger.debug("Could not get the sub header" + e);
		} //finally{
			//closeConnection();
		//}
		
		if (!"".equals(subHeader)){
			buf.append("<tr class='KeyRow' ><td colspan='100%'>");
			buf.append(subHeader);	
			buf.append("</td></tr>");
		}
		
        return buf.toString();
    }


    /*
     * (non-Javadoc)
     * 
     * @see com.sbc.bac.aria.renderers.ARIAHTMLRowRenderer#renderBeginRow(com.sbc.bac.aria.ARIAReportProcessor)
     */
    public String renderBeginRow(ARIAReportProcessor processor) {
        ARIAHTMLPage13Processor page13 = (ARIAHTMLPage13Processor) processor;
        
        if (currentRowCount == 0){
    		currentRowCount = page13.getPaging().getCurrentStartRow();
    	} else {
    		currentRowCount++;
    	}
        
        setCurrentRowCount(currentRowCount) ;
        if (page13.isSubTotal()) {
        	if (getCurrentRowCount() == (getActualRows() +1 )) {
        		return "<tr bgcolor='D8D8D8' style='font-weight: bold;'>";
        	} else {
        		return "<tr bgcolor='ECECEC' style='font-weight: bold;'>";
        	}
            
        }

        if (page13.isGrandTotal() ) {
            return "<tr bgcolor='D8D8D8' style='font-weight: bold;'>";
        }

        oddRow = !oddRow;
        if (oddRow) {
            return "<tr bgcolor=\"99CCFF\">";
        }
        return "<tr>";
    }


    /*
     * (non-Javadoc)
     * 
     * @see com.sbc.bac.aria.renderers.ARIAHTMLColumnRenderer#renderHTMLColumn(com.sbc.bac.aria.ARIAReportProcessor,
     *      java.lang.String, boolean)
     */
    public String renderColumn(ARIAColumn column, ARIAReportProcessor processor, String value, boolean escape) {
        try {
            ARIAHTMLPage13Processor proc = (ARIAHTMLPage13Processor) processor;
            String  currentValue="";
            String prevValue="";
            
            int elementIndex = ((IAdhocDTOIndex) column).getDtoIndex();
            if (elementIndex<0 || !isIndicatorIn((String) dto.getPresnSuppressIndList().get(elementIndex), "Y")) {
            	 if (value.equals("null")) {
            		// return "<td>&nbsp;</td>";
            		 String columnValue = "<td>&nbsp;</td>";
            		 // if Stat info was required for that column and if the current value is null, then the avg, high and low will also be null..
            		 // one is the original <td>&nbsp;</td> and the other 3 are for Avg, high and low
            		 if (elementIndex>0 && isIndicatorIn((String) dto.getPrevDataIndList().get(elementIndex), "Y")) {
            			 columnValue = columnValue + "<td>&nbsp;</td>";
            		 }
            		 // if Difference info was required for that column and if the current value is null, then others are null
            		            		 
            		 if (elementIndex>0 && isIndicatorIn((String) dto.getDiffDataIndList().get(elementIndex), "Y")) {
            			 columnValue = columnValue + "<td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>";
            		 }            		 
            		 return columnValue;
                 }
            	 
            	 StringBuffer buf = new StringBuffer(100);
                 buf.append("<td class=\"cellText mso\" ");
                 if (elementIndex >= 0) {
                     if (!isIndicatorIn((String) dto.getPresnSumIndList().get(elementIndex), "N")) {
                         buf.append(" align='right' ");
                     }
                     if (isIndicatorIn((String) dto.getPresnUnitIndList().get(elementIndex), "D")) {
                         buf.append(" align='right' ");
                     }
                     if (!dto.getPresnCalcNumList().get(elementIndex).toString().equals("")) {
                    	 buf.append(" align='right' ");
                    }
                 }
                 if (proc.isSubTotal() || proc.isGrandTotal()) {
                     buf.append(" align='left' ");
                 } else {
                     buf.append(getAlignment(column));
                 }
                 buf.append(" title='"+ getMouseOverDescription(elementIndex, "", value) + "' ");
                 buf.append(">");

                 if ((proc.isSubTotal() || proc.isGrandTotal()) && ((elementIndex < dto.getKeysRow1ColumnsList().size()) && (elementIndex >= 0))) {
                     buf.append("&nbsp;");
                 } else {
                     // if subtotal total label just print it.
                     if ((proc.isSubTotal() || proc.isGrandTotal()) && (elementIndex < 0)) {
                     	addTotalLabel(proc,buf, value);
                     }/* else if ((proc.isSubTotal() || proc.isGrandTotal()) && "K".equals(dto.getColumnsDataTypeList().get(elementIndex)) && (dto.getMonthSelect()!=0 || dto.getYearSelect()!=0)) {
                     	buf.append("&nbsp;");
                     }*/  else {
                    	 //formatCellWithLinks(column.getName(), proc, value, escape, elementIndex, buf);
                    	 
                    	 if (elementIndex < 0)
                    	 {
                    	//	 System.out.println("1:: " +value.substring(6, 10));
                     	//	 value=value.substring(6, 10);//changes MM/dd/yyyy2008 to yyyy
                    		 formatCellWithLinks(column.getName(), proc, value, escape, elementIndex, buf); 
                    	 }else if (isIndicatorIn((String) dto.getPresnUnitIndList().get(elementIndex), "P")) 
                    	 {
                    		 if( (proc.getRowData().get(0).getValue()).toString().indexOf("Total") > 0  )
//           IL3693         		 if( (proc.getRowMap().get(0).toString().indexOf("Total") > 0 ) )
                    		 {                   		
                    			buf.append("&nbsp;");
                    		 }else {
                     	              formatCellWithLinks(column.getName(), proc, value, escape, elementIndex, buf);
                    	           }
                 	       }else
                 	       {
                 	    	  formatCellWithLinks(column.getName(), proc, value, escape, elementIndex, buf); 
                 	       }
                    	 
                    	 
                 	}
                 }

                 buf.append("</td>");
                 if (proc.isSubTotal() || proc.isGrandTotal()) {
                     buf.append("</b>");
                 }

                 if (elementIndex >= 0) {
                     if (isIndicatorIn((String) dto.getPrevDataIndList().get(elementIndex), "Y")) {
                    	 //    DatedCompositeKey datedKey = getDatedKey(processor.getRowMap());
//IL3693                  	   DatedCompositeKey datedKey = getDatedKey(processor.getRowMap());
                         DatedCompositeKey datedKey = getDatedKey(processor.getRowData());
                         if (datedKey != null) {
                        	 currentValue = value;
//                             Map rowData = (Map) prevData.findPreviousData(datedKey, dto.getPresnTrendTime(),dto);
                       
                        	 /* Made required changes to get the previous data, for PMT #M169, issue #M12 */
                        	 
                        	 AdhocRptDataTO rowDatadto = (AdhocRptDataTO)prevData.findPreviousData(datedKey, dto.getPresnTrendTime(),dto);
                        	 
                        	 if(rowDatadto!=null){
                 				 //System.out.println("tried to get generated sql = "+rowDatadto.getQueryValue());         				 
                 				List<RowElement> rowData = rowDatadto.getRowData();
                 				prevValue = "";
                 				 for (RowElement el : rowData) {
                 		            if (el.getColumnName().equals(column.getName().toString())) {
                 		            	prevValue = el.getValue().toString();
                 		            	break;
                 		            }
                 		        }      
                 			}
                 			else{
                 				System.out.println("object is not found for previous");
                 			}                        	 
                        	 value = ((prevValue == null) || prevValue.equalsIgnoreCase("")) ? "no data" : prevValue;                        	 
                        	 /* end requirement, for PMT #M169, issue #M12 */ 	 
                             buf.append("<td class=\"cellText mso\" ");
                             if (elementIndex >= 0) {
                                 if (!isIndicatorIn((String) dto.getPresnSumIndList().get(elementIndex), "N")) {
                                     buf.append(" align='right' ");
                                 }
                                 if (isIndicatorIn((String) dto.getPresnUnitIndList().get(elementIndex), "D")) {
                                     buf.append(" align='right' ");
                                 }
                                 
                                 if (!dto.getPresnCalcNumList().get(elementIndex).toString().equals("")) {
                                 	 buf.append(" align='right' ");
                                 }
                             }
                             buf.append(getAlignment(column));
                             buf.append(">");

                             if ("no data".equals(value)){
                             	buf.append(value);
                             } else {
                             	formatCellData(column.getName(), value, escape, elementIndex, buf);
                             }

                             buf.append("</td>");
                         } else {
                             buf.append("<td>&nbsp;</td>");
                         }
                     }                     
                     
                     
                     //sb8798-added for the difference columns
                     if (isIndicatorIn((String) dto.getDiffDataIndList().get(elementIndex), "Y")) {
                  	   DatedCompositeKey datedKey = getDatedKey(processor.getRowData());
                  	   
                       if (datedKey != null) {
                    	   boolean dataPresent = true;
                    	 //if current data value or previous data value has "no data" the difference columns will say "no data" 
                           if (("no data".equals(currentValue)) || ("no data".equals(value)) ) {
		                       	buf.append("<td class=\"cellText mso\" ");
		                       	buf.append(" align='right' ");
		                       	buf.append(">");
		                       	buf.append(value);
		                       	buf.append("</td>");
		                       	buf.append("<td class=\"cellText mso\" ");
		                       	buf.append(" align='right' ");
		                       	buf.append(">");
		                       	buf.append(value);
		                       	buf.append("</td>");
		                       	buf.append("<td class=\"cellText mso\" ");
		                       	buf.append(" align='right' ");
		                       	buf.append(">");
		                       	buf.append(value);
		                       	buf.append("</td>");
		                       	dataPresent=false;
                           } 
                           	
                           if (dataPresent) {
	                          	 
                        	     double previous = Double.parseDouble(value);
                        	     double current= Double.parseDouble(currentValue);

                        	     //display the difference
	                             double difference = current - previous;       
	                             buf.append("<td class=\"cellText mso\" ");
	                             
	                             if (!isIndicatorIn((String) dto.getPresnSumIndList().get(elementIndex), "N")) {
	                                 buf.append(" align='right' ");
	                             }else if (isIndicatorIn((String) dto.getPresnUnitIndList().get(elementIndex), "D")) {
	                                 buf.append(" align='right' ");
	                             }else {
	                            	 	buf.append(" align='right' ");
	                             }
	                             
	                             buf.append(">");
	                             if (!isIndicatorIn((String) dto.getPresnUnitIndList().get(elementIndex), "D") && !isIndicatorIn((String) dto.getPresnUnitIndList().get(elementIndex), "P")){
	                             	long diff = Math.round(difference);
	                             	formatCellData((String) dto.getColumnsToExtractList().get(elementIndex), Long.toString(diff), escape, elementIndex, buf);
	                             } else {
	                             	formatCellData((String) dto.getColumnsToExtractList().get(elementIndex), Double.toString(difference), escape, elementIndex, buf);
	                             }
	                             buf.append("</td>");
	                             
	                             //display absolute difference
	                             double absoluteDifference = Math.abs(difference);
	                             buf.append("<td class=\"cellText mso\" ");
	                             
	                             if (!isIndicatorIn((String) dto.getPresnSumIndList().get(elementIndex), "N")) {
	                                 buf.append(" align='right' ");
	                             }else if (isIndicatorIn((String) dto.getPresnUnitIndList().get(elementIndex), "D")) {
	                                 buf.append(" align='right' ");
	                             }else {
	                            	 	buf.append(" align='right' ");
	                             }
	                             
	                             buf.append(">");
	                             if (!isIndicatorIn((String) dto.getPresnUnitIndList().get(elementIndex), "D") && !isIndicatorIn((String) dto.getPresnUnitIndList().get(elementIndex), "P")){
	                             	long diff = Math.round(absoluteDifference);
	                             	formatCellData((String) dto.getColumnsToExtractList().get(elementIndex), Long.toString(diff), escape, elementIndex, buf);
	                             } else {
	                             	formatCellData((String) dto.getColumnsToExtractList().get(elementIndex), Double.toString(absoluteDifference), escape, elementIndex, buf);
	                             }
	                             buf.append("</td>");
	                             
	                             
	                             //percent difference
	                             double percentDifference = 0;
	                             if (Math.abs(current) > 0){
	                             	//percentDifference = (difference/Math.abs(previous))*100;
	                             	percentDifference = (difference/Math.abs(current))*100;
	                             } 
	                             
	                             buf.append("<td class=\"cellText mso\" ");
	                             if (elementIndex >= 0) {
	                                 if (!isIndicatorIn((String) dto.getPresnSumIndList().get(elementIndex), "N")) {
	                                     buf.append(" align='right' ");
	                                 }else if (isIndicatorIn((String) dto.getPresnUnitIndList().get(elementIndex), "D")) {
	                                     buf.append(" align='right' ");
	                                 }else if (Math.abs(previous) == 0){
	                                 	buf.append(" align='center' ");
	                                 } else {
	                                	 	buf.append(" align='right' ");
	                                 }
	                             }
	                             buf.append(">");
	                             
	                             if (Math.abs(current) == 0){
	                             	buf.append("div zero");
	                             	buf.append("</td>");
	                             } else {
	                             	formatPercentage(Double.toString(percentDifference), escape, buf);
	                             	buf.append("</td>");
	                             }            
                           } //dataPresent

                       } else {
                    	   buf.append("<td>&nbsp;</td>");
                           buf.append("<td>&nbsp;</td>");
                           buf.append("<td>&nbsp;</td>");
                       }
                       
                     }
                    
                 }

                 return buf.toString();
            } else {
            	return "";
            }
        } catch (Exception e) {
            logger.error("renderColumn", e);
            return "";
        }
    }


    /**
     * @param columnName
     * @param processor
     * @param value
     * @param escape
     * @param elementIndex
     * @param buf
     * @throws ParseException
     * @throws RABCException
     * @throws SQLException
     * @throws UnsupportedEncodingException
     */
    protected void formatCellWithLinks(String columnName, ARIAHTMLPage13Processor processor, String value, boolean escape, int elementIndex, StringBuffer buf) throws ParseException, NamingException, RABCException, SQLException, UnsupportedEncodingException {
        if (elementIndex < 0) {
            formatCellData(columnName, value, escape, elementIndex, buf);
        } else {
            boolean addLink = isIndicatorIn((String) dto.getDataLinkIndList().get(elementIndex), "Y");
            addLink &= !processor.isSubTotal();
            addLink &= !processor.isGrandTotal();
            if (addLink) {
                buf.append(getUrl(columnName, processor.getRowData(), elementIndex, value));
            }

            formatCellData(columnName, value, escape, elementIndex, buf);

            if (addLink) {
                buf.append("</a>");
            }

            boolean addGraph = isIndicatorIn((String) dto.getGraphPresnIndList().get(elementIndex), "Y");
            addGraph &= !processor.isSubTotal();
            addGraph &= !processor.isGrandTotal();
            if (addGraph) {
                buf.append("<a href=\"javascript:graphpopup('alertGraph','");
                buf.append(urlEncodedFormat(getGraphUrl(columnName, processor.getRowData(), elementIndex)));
                buf.append("')\"><img src=\"./images/graph.gif\" alt=\"Graph\" height=\"10\" width=\"13\" border=\"0\"/></a>");
            }
        }
    }


    /*
     * (non-Javadoc)
     * 
     * @see com.sbc.bac.aria.renderers.ARIAReportRenderer#renderEndReport(com.sbc.bac.aria.ARIAReportProcessor)
     */
    public String renderEndReport(ARIAReportProcessor processor) {
        StringBuffer buf = new StringBuffer(40);

        /*
         * Find out the maximum page for this section
         */
        ARIAHTMLPage13Processor page13Processor = (ARIAHTMLPage13Processor)processor;
        ARIAPaging paging = page13Processor.getPaging();
        int maxPage = (int) (((float) actualRowCounts[getSection()] / paging.getRowsPerPage()) + .99);
        int pCount = Math.max(1, maxPage);
        
        /*
         * If nothing returned print the no data message
         */
        if (rows == 0) {
            buf.append("<tr><td class='NoData' colspan='100%' align='center'>No data found for the criteria entered.</td></tr>");
        } else if (paging.getCurrentPage()>pCount) {
        	buf.append("<tr><td class='NoData' colspan='100%' align='center'>No data for this section on this page.</td></tr>");
        }

        buf.append("</table>");

        return buf.toString();
    }


    /*
     * (non-Javadoc)
     * 
     * @see com.sbc.bac.aria.renderers.ARIAHTMLRowRenderer#renderEndRow(com.sbc.bac.aria.ARIAReportProcessor)
     */
    public String renderEndRow(ARIAReportProcessor processor) {
        return "</tr>";
    }


    /*
     * (non-Javadoc)
     * 
     * @see com.sbc.bac.aria.renderers.ARIAHeaderRenderer#renderHeader(java.util.List)
     */
    @SuppressWarnings("unchecked")
    public String renderHeader(List columns) {
        StringBuffer buf = new StringBuffer(100);
        Iterator i = columns.iterator();

        while (i.hasNext()) {
            ARIAColumn element = (ARIAColumn) i.next();
            int index = ((IAdhocDTOIndex) element).getDtoIndex();
            
            if (index<0 || !isIndicatorIn((String) dto.getPresnSuppressIndList().get(index), "Y")) {
            	buf.append("<th class='tableHeader' nowrap>");
            	if("DIVISION".equals(getColumnHeader(element.getName(), index))) {
            		buf.append("Division");
            	}
            	else {
            	    String h = getColumnHeader(element.getName(), index);
            		buf.append(ARIAUtil.escape(h.substring(0, 1) + h.substring(1).toLowerCase().replace('_', ' ').replace('-', ' ')));
            	}
                addUserSortLink(buf, element);
                buf.append("</th>");
                if (index >= 0) {
                    if (isIndicatorIn((String) dto.getPrevDataIndList().get(index), "Y")) {
                        buf.append("<th class='tableHeader' nowrap>Previous<br>");
                        buf.append(ARIAUtil.escape(getColumnHeader(element.getName().substring(0, 1) + element.getName().substring(1).toLowerCase().replace('_', ' ').replace('-', ' '), index)));
                        addUserSortLink(buf, element);
                        buf.append("</th>");
                    }
                    //sb8798- will be displayed if the difference was checked in Step 2 of 3. 
                    if (isIndicatorIn((String) dto.getDiffDataIndList().get(index), "Y")) {
                        buf.append("<th class='tableHeader' nowrap>Difference<br>");
                        buf.append(ARIAUtil.escape(getColumnHeader(element.getName().substring(0, 1) + element.getName().substring(1).toLowerCase().replace('_', ' ').replace('-', ' '), index)));
                        addUserSortLink(buf, element);
                        buf.append("</th>");
                        buf.append("<th class='tableHeader' nowrap>Absolute<br>Difference<br>");
                        buf.append(ARIAUtil.escape(getColumnHeader(element.getName().substring(0, 1) + element.getName().substring(1).toLowerCase().replace('_', ' ').replace('-', ' '), index)));
                        addUserSortLink(buf, element);
                        buf.append("</th>");
                        buf.append("<th class='tableHeader' nowrap>Percent<br>Difference<br>");
                        buf.append(ARIAUtil.escape(getColumnHeader(element.getName().substring(0, 1) + element.getName().substring(1).toLowerCase().replace('_', ' ').replace('-', ' '), index)));
                        addUserSortLink(buf, element);
                        buf.append("</th>");
                    }                    
                }
            }
        }
        
        return buf.toString();
    }


    /**
     * @param buf
     * @param column
     */
    protected void addUserSortLink(StringBuffer buf, ARIAColumn column) {
        if (column == null) {
            return;
        }

        if (!(column instanceof ARIASimpleColumn)) {
            return;
        }

        ARIADataPoint dataPoint = ((ARIASimpleColumn) column).getDataPoint();
        boolean isSortColumn = dataPoint.toString().equals(dto.getUserSortColumn());

        buf.append("&nbsp;");

        String imgASC = "<img src=\"./images/ArrowUp2.gif\" border=0 />";
        String imgDESC = "<img src=\"./images/ArrowDown2.gif\" border=0 />";
        String imgNoSort = "<img src=\"./images/arrowRightW.gif\" border=0 />";

        buf.append("<a href=\"javascript:sortBy('");
        buf.append(dataPoint);
        buf.append("','");
        if (isSortColumn) {
            switch (dto.getUserSortType()) {
                case 'A':
                    buf.append('D');
                    break;
                case 'D':
                    buf.append(' ');
                    break;
                default:
                    buf.append('A');
            }
        } else {
            buf.append('A');
        }

        buf.append("');document.AdhocRptForm.submit();\">");

        if (isSortColumn) {
            switch (dto.getUserSortType()) {
                case 'A':
                    buf.append(imgASC);
                    break;
                case 'D':
                    buf.append(imgDESC);
                    break;
                default:
                    buf.append(imgNoSort);
            }
        } else {
            buf.append(imgNoSort);
        }

        buf.append("</a>");

    }
    
    /**
     * Add the total labels
     * @param buf
     */
    protected void addTotalLabel(ARIAHTMLPage13Processor proc, StringBuffer buf, String value){
    	buf.append(value);
    }
    
	/**
	 * Private method to format the %
	 * @param columnName
	 * @param value
	 * @param escape
	 * @param buf
	 * @return
	 * @throws RABCException
	 */
	private StringBuffer formatPercentage(String value, boolean escape,StringBuffer buf) throws RABCException {
        String suffix = "%";

        if (value == null) {
            buf.append("");
            return buf;
        }

        value = escape ? ARIAUtil.escape(value) : value;
        NumberFormat fmt = NumberFormat.getNumberInstance();
        fmt.setMinimumFractionDigits((value.indexOf('.') >= 0) ? 2 : 0);
        fmt.setMaximumFractionDigits(2);
        try {
            buf.append(fmt.format(Double.parseDouble(value)));
        } catch (NumberFormatException e) {
            buf.append("NaN");
        }
        buf.append(suffix);
        return buf;
    }    
}
