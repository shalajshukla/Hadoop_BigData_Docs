/* Component Name: RABCPPG00533
 * Module Name: MenuNode.java
 * Created on Feb 21, 2006
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.sidemenu;

import java.util.ArrayList;
import java.util.Iterator;

/**This class is called by SidemenuList.java.  It is a bean class that holds information on each node in the
 * Alerts tree and the Reports tree and the position of the node in the appropriate tree.  Control of this 
 * expansion and collapsing of the tree is handled on the controlpts_sidemenu.jsp JSP include.
 * 
 * @author pt6471
 */
public class MenuNode {
    private static int UID = 0;
	
	boolean link = false;
    private MenuNode parent = null;
    private ArrayList children = new ArrayList();
    private String name = null;
    private int depth = 0;
    private String id = null;
    private String rptType = null;
    private int guid = UID++;
    private int linkId = 0;
    
    public MenuNode(MenuNode parent, String name, String id, int linkId, boolean link, String rptType){
        this.parent = parent;
        this.name = name;
        this.id = id;
        this.linkId = linkId;
        this.link = link;
        this.rptType = rptType;
        if(parent==null){ 
            depth = 0;
        } else {
            parent.addChild(this);
            this.depth = parent.depth+1; 
        }
    }
    
	/**
	 * @return id  returns the id of the node on the tree.
	 */
    public String getId(){
        return id;
    }
    
	/**
	 * @param id  the node id.
	 * @return child  the MenuNode object.
	 */
    public MenuNode getChild(String id){
        for(Iterator i=children.iterator(); i.hasNext(); ){
            MenuNode child = (MenuNode)i.next();
            if(child.id.equals(id)){
                return child;
            }
        }
        return null;
    }
    
	/**Adds child nodes to the MenuNode object.
	 * 
	 * @param child  the child node to add.
	 */
    public void addChild(MenuNode child){
        children.add(child);
    }
    
	/**This method is called by the controlpts_sidemenu.jsp JSP include to generate the javascript that
	 * expands and collapses the side menu trees.
	 * 
	 * @return b  the StringBuffer that contains the HTML/Javascript that displays the side menu node.
	 */
    public StringBuffer javaScript(){
    	StringBuffer b = new StringBuffer("");
    	if (rptType.equals("P")) {
    		if (link)
    			b.append("new Node(menu, "  + depth  + ",\"<span style =\\\"color: 0059B3; text-decoration: underline; fontFamily: Verdana; font-size:90%;\\\" onmouseover=\\\"style.color='gray',style.fontFamily='Verdana'\\\" onmouseout=\\\"style.color='0059B3',style.fontFamily='Verdana'\\\">"+ name + "</span>\", \"followLink(\\\"forwardTo=AdhocRpt.do&reportType=REPORTS&alertRuleSelect=0&presnIdAsString=" + linkId + "\\\");\");\n");
    		else {
    			b.append("new Node(menu, "  + depth  + ", \"<font size=2>"+ name +"</font>\");\n");
    			if (children.isEmpty())
    				b.append("new Node(menu, "  + ++depth  + ", \"<font color=0059B3><b>No Data</b></font>\", \"\");\n");
    		}
    	} else if (rptType.equals("A")) {
    		if (!children.isEmpty()) {
    			if (link)
    				b.append("new Node(menu, "  + depth  + ", \"<font size=2> <a href=\\\"javascript:followLink('forwardTo=AlertTrckMainPage.do&reportType=ALERTS&presnIDSelect=0&alertRule=xx&alertRuleSelect=0&cntrlPtCd=" + id + "')\\\">"+ name +"</a></font>\");\n");
    			else 
    				b.append("new Node(menu, "  + depth  + ", \"<font size=2>"+ name +"</font>\");\n");
    		} else {
    			if (link) {
    				b.append("new Node(menu, "  + depth  + ",\"<span style =\\\"color: 0059B3; text-decoration: underline; fontFamily: Verdana; font-size:90%;\\\" onmouseover=\\\"style.color='gray',style.fontFamily='Verdana'\\\" onmouseout=\\\"style.color='0059B3',style.fontFamily='Verdana'\\\">"+ name + "</span>\", \"followLink(\\\"forwardTo=AlertTrckMainPage.do&reportType=ALERTS&&cntrlPtCd=&presnIDSelect=0&alertRule=" + name + "&alertRuleSelect=" + linkId + "\\\");\");\n");	
    			} else {
    				b.append("new Node(menu, "  + depth  + ", \"<font size=2>"+ name +"</font>\");\n");
    				b.append("new Node(menu, "  + ++depth  + ", \"<font color=0059B3><b>No Data</b></font>\", \"\");\n");
    			}
    		}
    	}
        for(Iterator i=children.iterator(); i.hasNext(); ){
            MenuNode child = (MenuNode)i.next();
            b.append(child.javaScript());
        }
        return b;
    }
    
	/**This method is used to add right side indentation to children below the parent on the tree.
	 */
    public void visit() {
        for(int i=0; i<depth; i++) {
        	System.out.print("\t");
        }
        System.out.println(guid+" "+name);
        for(Iterator i=children.iterator(); i.hasNext(); ) {
            MenuNode child = (MenuNode)i.next();
            child.visit();
        }
    }

	/**
	 * @return parent  returns the parent node.
	 */
	public MenuNode getParent() {
		return parent;
	}

	/**
	 * @param parent  the parent node to set.
	 */
	public void setParent(MenuNode parent) {
		this.parent = parent;
	}
}
