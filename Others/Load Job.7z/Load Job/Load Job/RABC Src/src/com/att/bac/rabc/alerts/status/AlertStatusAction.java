/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.alerts.status;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.ConnectionManager;
import com.att.bac.rabc.PickList;
import com.att.bac.rabc.ProgressBar;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;

/**
 * Module description: 
 * 
 * This is an action class that controls the actions required to populate the Alert Status Update page
 * and to update the alerts status with the user's input.
 * 
 * @author Abhilash - AC6952
 */
public class AlertStatusAction extends DispatchAction {
	private static Logger logger = Logger.getLogger(AlertStatusAction.class);
	private AlertStatusService alertStatusService = AlertStatusService.getAlertStatusService();
	
	/**
	 * Default dispatch action method to handel the request to populate the Alert Status Update page.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @see org.apache.struts.actions.DispatchAction#unspecified(org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public ActionForward unspecified(ActionMapping mapping, ActionForm form,HttpServletRequest request, HttpServletResponse response) {
		return alertStautus(mapping, form, request, response);
	}
	
	/**
	 * Dispatch action method to handel the request to populate the Alert Status Update page.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward alertStautus(ActionMapping mapping, ActionForm form,HttpServletRequest request, HttpServletResponse response) {
		AlertStatusForm alertStatusForm = (AlertStatusForm) form;
		Connection connection = null;
		List failureList = new ArrayList();
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		String userId = (String) session.getAttribute("bacUserID");
		String region = (String) session.getAttribute("region");
		String popupPage = null;
		int counter = 0;
		try {
			connection = ConnectionManager.getConnection(region);
			
			/*
			 * Call the internal method populateOptions(alertStatusForm, connection, failureList)
			 * to poplate the option lists.
			 */ 
	        populateOptions(alertStatusForm, connection, failureList);
	        progressBar.setProgressPercent(10);
	        
	        /*
	         * Code to get the list of selected AlertReportDetail objects.
	         */
	        List alertReportDetailList = null;
	        if (request.getMethod().equals("GET")) {
	        	String msgNo = request.getParameter("msgNo");
	        	if (msgNo == null) {
	        		msgNo = request.getParameter("msgno");
	        	}
	        	String fromPage = request.getParameter("fromPage");
	        	popupPage = request.getParameter("popup");
	        	alertStatusForm.setFromPage(fromPage);
	        	alertStatusForm.setPopupPage(popupPage);
	        	if (fromPage != null && ("RABCPSF00006".equals(fromPage) || "RABCPSF00011".equals(fromPage) || "RABCPSF00014".equals(fromPage))) {
	        		List args = new ArrayList();
		        	args.add(msgNo);
		        	args.add(fromPage);
		        	alertReportDetailList = alertStatusService.getAlertReportDetailList(connection, failureList, args, progressBar);
	        	} else {
	        		alertReportDetailList = (List) request.getAttribute("selectedAlertReportDetailList");
	        	}
	        } else {
	        	alertReportDetailList = (List) request.getAttribute("selectedAlertReportDetailList");
	        }
	        progressBar.setProgressPercent(60);
	        
	        alertStatusForm.getAlertReportDetailList().clear();
	        if (alertReportDetailList != null) {
	        	int alertReportDetailListSize = alertReportDetailList.size(); 
		        if (alertReportDetailListSize == 1) {
		        	AlertReportDetail alertReportDetail = (AlertReportDetail) alertReportDetailList.get(0);
		        	alertStatusForm.setAlertStatus(alertReportDetail.getAlertStatus());
		        	Double revenueImpactValue = alertReportDetail.getAlertRevenue();
					if (revenueImpactValue != null) {
						alertStatusForm.setRevenueImpactValue(revenueImpactValue.toString());
					}
					Double lostRevenueImpactValue = alertReportDetail.getAlertLostRevenue();
					if (lostRevenueImpactValue != null) {
						alertStatusForm.setLostRevenueImpactValue(lostRevenueImpactValue.toString());
					}
					alertStatusForm.setRootCause(alertReportDetail.getAlertRootCause());
					List alertRootCtgyList = alertReportDetail.getAlertRootCatgyList();
					alertStatusForm.setRootCauseCategories((String[])alertRootCtgyList.toArray(new String[alertRootCtgyList.size()]));
					
					if ("Warning".equals(alertReportDetail.getAlertStatus())) {
						alertStatusForm.setStatusColor("Red");
					} else if ("Closed".equals(alertReportDetail.getAlertStatus())) {
						if (!"Red".equals(alertStatusForm.getStatusColor()) && !"#ff9900".equals(alertStatusForm.getStatusColor()) && !"#ffff00".equals(alertStatusForm.getStatusColor())) {
							alertStatusForm.setStatusColor("#0059B3");
						}
					} else {
						if ("1".equals(alertReportDetail.getAlertSeverityLevelInd())) {
							alertStatusForm.setStatusColor("Red");
						} else if ("2".equals(alertReportDetail.getAlertSeverityLevelInd())) {
							if (!"Red".equals(alertStatusForm.getStatusColor())) {
								alertStatusForm.setStatusColor("#ff9900");
							}
						} else if ("3".equals(alertReportDetail.getAlertSeverityLevelInd())) {
							if (!"Red".equals(alertStatusForm.getStatusColor()) && !"#ff9900".equals(alertStatusForm.getStatusColor())) {
								alertStatusForm.setStatusColor("#ffff00");
							}
						}
					}
				}
		        for(counter = 0; counter < alertReportDetailListSize; counter++) {
					alertStatusForm.addAlertReportDetail((AlertReportDetail)alertReportDetailList.get(counter));
				}
				alertStatusForm.setTotalAlerts(alertReportDetailListSize);
	        }
	        progressBar.setProgressPercent(70);
			
	        /*
	         * Code to get the list of alert comments.
	         */
			List alertCommentList = alertStatusService.getAlertCommentList(connection, alertReportDetailList, failureList, null, null);
			if (alertCommentList != null) {
				alertStatusForm.setTotalComments(alertCommentList.size());
			}
			progressBar.setProgressPercent(80);
			
			/*
			 * Code to get the update access of the logged in user to update the selected alerts.
			 */
			String updateAccess = alertStatusService.getUpdateAccess(connection, alertReportDetailList, userId, failureList);
			alertStatusForm.setUpdateAccess(updateAccess);
			progressBar.setProgressPercent(90);
			
			/*
			 * Set the lsit of selected alert report detail objects into session.
			 */
			session.setAttribute("selectedAlertReportDetailList", alertReportDetailList);
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		}catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		progressBar.setProgressPercent(100);
		
		/*
		 * Code to forward the request to Alert Status Update page in case of no failure
		 * or to Error page in another case.
		 */
		if (!failureList.isEmpty()) {
			request.setAttribute("failures",failureList);
			return mapping.findForward("error");
		} else {
			if (popupPage != null && "Y".equalsIgnoreCase(popupPage)) {
				return mapping.findForward("AlertStatusUpdatePopup");
			} else {
				return mapping.findForward("AlertStatusUpdate");
			}
		}
	}
	
	/**
	 * Dispatch action method to handel the request to update the tables for the selected alerts
	 * with the user's input.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward save(ActionMapping mapping, ActionForm form,HttpServletRequest request, HttpServletResponse response) {
		AlertStatusForm alertStatusForm = (AlertStatusForm) form;
		Connection connection = null;
		List failureList = new ArrayList();
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		String userId = (String) session.getAttribute("bacUserID");
		String region = (String) session.getAttribute("region");
		try {
			connection = ConnectionManager.getConnection(region);
			
			/*
			 * Get the lsit of selected AlertReportDetail objects from session.
			 */
			List alertReportDetailList = (List) session.getAttribute("selectedAlertReportDetailList");
	        
			/*
			 * Call private method listArguments(alertStatusForm, userId) to add the form parameters
			 * in an array list.
			 */
	        List args = listArguments(alertStatusForm, userId);
	        progressBar.setProgressPercent(10);
	        
	        /*
	         * Call a method from service class to update the tables.
	         */
	        alertStatusService.updateAlerts(connection, failureList, args, alertReportDetailList, progressBar);
	        if (!failureList.isEmpty()) {
				connection.rollback();
			} else {
				connection.commit();
			}
	        session.removeAttribute("selectedAlertReportDetailList");
	        progressBar.setProgressPercent(90);
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		}catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		progressBar.setProgressPercent(100);
		
		/*
		 * Code to forward the request to Caller page in case of no failure
		 * or to Error page in another case.
		 */
		if (!failureList.isEmpty()) {
			request.setAttribute("failures",failureList);
			return mapping.findForward("error");
		} else {
			String fromPage = alertStatusForm.getFromPage();
			String popupPage = alertStatusForm.getPopupPage();
			if (popupPage != null && "Y".equals(popupPage)) {
				return null;
			} else {
				if ("RABCPSF00006".equals(fromPage)) {
					return mapping.findForward("SystemMessages");
				} else {
					Hashtable options = (Hashtable) session.getAttribute("options");
					fromPage = ((String) options.get("fromPage"));
					if (("RABCPSF00002".equals(fromPage)) || ("RABCPSF00003".equals(fromPage))) {
						return mapping.findForward("AlertReportDetail");
					} else {
						return mapping.findForward("AlertReportDetail");
					}
				}
			}
		}
	}
	
	/**
	 * Dispatch action method to handel the request to show the Alert Comment History page.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward getComments(ActionMapping mapping, ActionForm form,HttpServletRequest request, HttpServletResponse response) {
		AlertStatusForm alertStatusForm = (AlertStatusForm) form;
		Connection connection = null;
		List failureList = new ArrayList();
		HttpSession session = request.getSession(true);
		String region = (String) session.getAttribute("region");
		try {
			connection = ConnectionManager.getConnection(region);
	        
			/*
			 * Get the lsit of selected alert report detail objects from session.
			 */
			List alertReportDetailList = (List) session.getAttribute("selectedAlertReportDetailList");
			
			/*
			 * Get the sort item and sort order.
			 */
			String sortItem = alertStatusForm.getSortItem();
			String sortOrder = alertStatusForm.getSortOrder();
			
			/*
			 * Call the service class to get the list of alert comments.
			 */
			List alertCommentList = alertStatusService.getAlertCommentList(connection, alertReportDetailList, 
					failureList, sortItem, sortOrder);
			
			alertStatusForm.getAlertCommentList().clear();
			if (alertCommentList != null) {
				int alertCommentListSize = alertCommentList.size();
				int counter = 0;
				for(counter = 0; counter < alertCommentListSize; counter++) {
					alertStatusForm.addAlertComment((AlertComment)alertCommentList.get(counter));
				}
				alertStatusForm.setTotalComments(alertCommentListSize);
			}
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		}catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		
		/*
		 * Code to forward the request to Alert Comments History page in case of no failure
		 * or to Error page in another case.
		 */
		if (!failureList.isEmpty()) {
			request.setAttribute("failures",failureList);
			return mapping.findForward("error");
		} else {
			return mapping.findForward("AlertCommentsHistory");
		}
	}
	
	/**
	 * Private method to pouplate the list objects of the form. These list objects are used to populate
	 * the drop down boxes on the Alert Status Update page.
	 * 
	 * @param alertStatusForm
	 * @param connection
	 * @param failureList
	 */
	private void populateOptions(AlertStatusForm alertStatusForm, Connection connection, List failureList) {
    	List tempList;
    	int temListSize = 0;
    	int counter = 0;
    	
    	if (alertStatusForm.getAlertStatusList() == null || alertStatusForm.getAlertStatusList().size() == 0) {
    		tempList = alertStatusService.getAlertStatusList();
    		if (tempList != null) {
    			temListSize = tempList.size();
	    		for(counter = 0; counter < temListSize; counter++) {
	    			alertStatusForm.addAlertStatus((PickList)tempList.get(counter));
				}
    		}
    	}
    	if ( alertStatusForm.getRootCauseCategoryList() == null || alertStatusForm.getRootCauseCategoryList().size() == 0) {
    		tempList = alertStatusService.getRootCauseCategoryList(connection, failureList);
    		if (tempList != null) {
    			temListSize = tempList.size();
	    		for(counter = 0; counter < temListSize; counter++) {
	    			alertStatusForm.addRootCauseCategory((RootCategory)tempList.get(counter));
				}
    		}
    	}
    }
    
	/**
	 * Private method to return a list of arguments which are passed to service class to 
	 * update the status of the selected alerts.
	 * 
	 * @param AlertStatusForm
	 * @param userId
	 * @return List
	 */
	private List listArguments(AlertStatusForm alertStatusForm, String userId) {
    	List args = new ArrayList();
    	args.add(0, userId);
    	args.add(1, alertStatusForm.getAlertStatus());
    	args.add(2, alertStatusForm.getRevenueImpactValue());
    	args.add(3, alertStatusForm.getRootCauseCategories());
    	args.add(4, alertStatusForm.getRootCause().replaceAll("'", "''"));
    	args.add(5, alertStatusForm.getComments().replaceAll("'", "''"));
    	args.add(6, alertStatusForm.getLostRevenueImpactValue());

    	return args;
    }
}
