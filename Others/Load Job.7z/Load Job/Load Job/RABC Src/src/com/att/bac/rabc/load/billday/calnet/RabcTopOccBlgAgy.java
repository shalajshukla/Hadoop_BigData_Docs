/* Created by Gaurav Bhargava (GB0741) on Dec 11, 2006.
Copyright 2006-2008 AT&T Knowledge Ventures. All rights reserved. */

package com.att.bac.rabc.load.billday.calnet;

import java.util.Date;

import com.att.bac.rabc.load.calnet.CalnetDTO;

/**
 * This class represents table RABC_TOP_OCC_BLG_AGY. It has fields corresponding
 * to columns in the this table and provide getter & setter methods to populate
 * the fields.
 * @author GB0741
 */
public class RabcTopOccBlgAgy extends CalnetDTO {
	private Date runDate;
	private String division;
	private int cycle;
	private String  agencyID;
	private double occAmt;
	private double prevBlgAmt;
	private double currMnthChrgAmt;
	private double currBalDueAmt;
	private String billRnd;
	private String billMm;
	private String billYear;

	/**
	 * @return Returns the agencyID.
	 */
	public String getAgencyID() {
		return agencyID;
	}
	/**
	 * @param agencyID The agencyID to set.
	 */
	public void setAgencyID(String agencyID) {
		this.agencyID = agencyID;
	}
	/**
	 * @return Returns the billMm.
	 */
	public String getBillMm() {
		return billMm;
	}
	/**
	 * @param billMm The billMm to set.
	 */
	public void setBillMm(String billMm) {
		this.billMm = billMm;
	}
	/**
	 * @return Returns the billRnd.
	 */
	public String getBillRnd() {
		return billRnd;
	}
	/**
	 * @param billRnd The billRnd to set.
	 */
	public void setBillRnd(String billRnd) {
		this.billRnd = billRnd;
	}
	/**
	 * @return Returns the billYear.
	 */
	public String getBillYear() {
		return billYear;
	}
	/**
	 * @param billYear The billYear to set.
	 */
	public void setBillYear(String billYear) {
		this.billYear = billYear;
	}
	/**
	 * @return Returns the currBalDueAmt.
	 */
	public double getCurrBalDueAmt() {
		return currBalDueAmt;
	}
	/**
	 * @param currBalDueAmt The currBalDueAmt to set.
	 */
	public void setCurrBalDueAmt(double currBalDueAmt) {
		this.currBalDueAmt = currBalDueAmt;
	}
	/**
	 * @return Returns the currMnthChrgAmt.
	 */
	public double getCurrMnthChrgAmt() {
		return currMnthChrgAmt;
	}
	/**
	 * @param currMnthChrgAmt The currMnthChrgAmt to set.
	 */
	public void setCurrMnthChrgAmt(double currMnthChrgAmt) {
		this.currMnthChrgAmt = currMnthChrgAmt;
	}
	/**
	 * @return Returns the cycle.
	 */
	public int getCycle() {
		return cycle;
	}
	/**
	 * @param cycle The cycle to set.
	 */
	public void setCycle(int cycle) {
		this.cycle = cycle;
	}
	/**
	 * @return Returns the division.
	 */
	public String getDivision() {
		return division;
	}
	/**
	 * @param division The division to set.
	 */
	public void setDivision(String division) {
		this.division = division;
	}
	/**
	 * @return Returns the occAmt.
	 */
	public double getOccAmt() {
		return occAmt;
	}
	/**
	 * @param occAmt The occAmt to set.
	 */
	public void setOccAmt(double occAmt) {
		this.occAmt = occAmt;
	}
	/**
	 * @return Returns the prevBlgAmt.
	 */
	public double getPrevBlgAmt() {
		return prevBlgAmt;
	}
	/**
	 * @param prevBlgAmt The prevBlgAmt to set.
	 */
	public void setPrevBlgAmt(double prevBlgAmt) {
		this.prevBlgAmt = prevBlgAmt;
	}
	/**
	 * @return Returns the runDate.
	 */
	public Date getRunDate() {
		return runDate;
	}
	/**
	 * @param runDate The runDate to set.
	 */
	public void setRunDate(Date runDate) {
		this.runDate = runDate;
	}
}
