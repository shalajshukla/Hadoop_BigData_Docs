/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.admin.alert.rule;

/**
 * This is a Data Object to represent RABC_STD_CALC table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class StdCal {
	private String alertRule;
	private int partiRefId;
	private int stdNumDate;
	private int stdNumRec;
	private String stdTrendTimeInd;
	private String stdType;
	private String stdTblName;

	/**
	 * @return Returns the AlertRule.
	 */
	public String getAlertRule() {
		return alertRule;
	}
	/**
	 * @return Returns the PartiRefId.
	 */
	public int getPartiRefId() {
		return partiRefId;
	}
	/**
	 * @return Returns the StdNumDate.
	 */
	public int getStdNumDate() {
		return stdNumDate;
	}
	/**
	 * @return Returns the StdNumRec.
	 */
	public int getStdNumRec() {
		return stdNumRec;
	}
	/**
	 * @return Returns the StdTrendTimeInd.
	 */
	public String getStdTrendTimeInd() {
		return stdTrendTimeInd;
	}
	/**
	 * @return Returns the StdType.
	 */
	public String getStdType() {
		return stdType;
	}
	/**
	 * @return Returns the StdTblName.
	 */
	public String getStdTblName() {
		return stdTblName;
	}

	/**
	 * @param AlertRule The alertRule to set.
	 */
	public void setAlertRule(String alertRule) {
		this.alertRule = alertRule;
	}
	/**
	 * @param PartiRefId The partiRefId to set.
	 */
	public void setPartiRefId(int partiRefId) {
		this.partiRefId = partiRefId;
	}
	/**
	 * @param StdNumDate The stdNumDate to set.
	 */
	public void setStdNumDate(int stdNumDate) {
		this.stdNumDate = stdNumDate;
	}
	/**
	 * @param StdNumRec The stdNumRec to set.
	 */
	public void setStdNumRec(int stdNumRec) {
		this.stdNumRec = stdNumRec;
	}
	/**
	 * @param StdTrendTimeInd The stdTrendTimeInd to set.
	 */
	public void setStdTrendTimeInd(String stdTrendTimeInd) {
		this.stdTrendTimeInd = stdTrendTimeInd;
	}
	/**
	 * @param StdType The stdType to set.
	 */
	public void setStdType(String stdType) {
		this.stdType = stdType;
	}
	/**
	 * @param StdTblName The stdTblName to set.
	 */
	public void setStdTblName(String stdTblName) {
		this.stdTblName = stdTblName;
	}
}
