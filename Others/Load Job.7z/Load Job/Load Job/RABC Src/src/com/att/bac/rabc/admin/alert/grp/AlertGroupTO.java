/* Component Name: RABCPPG00505
 * Module Name: AlertGroupTO.java
 * Created on Feb 26, 2006
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.admin.alert.grp;

import java.io.Serializable;

/**This is a transfer object class for the Alert Group process.  The purpose of this class is to 
 * contain the alert group name and description extracted from the AdminAlertGroupDAO.java class
 * that is sent back to the AdminAlertGroupForm.java class via the AdminAlertGroupService.java class.
 * 
 * @author js3175
 */
public class AlertGroupTO implements Serializable {
	private static final long serialVersionUID = 0L;
	
	private String alertGroup = "";
	private String alertGroupDescription = "";
	
	/**
	 * @return Returns the alertGroup.
	 */
	public String getAlertGroup() {
		return alertGroup;
	}
	/**
	 * @param alertGroup The alertGroup to set.
	 */
	public void setAlertGroup(String alertGroup) {
		this.alertGroup = alertGroup;
	}
	/**
	 * @return Returns the alertGroupDescription.
	 */
	public String getAlertGroupDescription() {
		return alertGroupDescription;
	}
	/**
	 * @param alertGroupDescription The alertGroupDescription to set.
	 */
	public void setAlertGroupDescription(String alertGroupDescription) {
		this.alertGroupDescription = alertGroupDescription;
	}
}
