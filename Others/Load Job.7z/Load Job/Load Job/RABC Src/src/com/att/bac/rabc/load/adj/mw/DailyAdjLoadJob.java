/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.load.adj.mw;

import java.io.File;
import java.net.UnknownHostException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Iterator;

import com.att.bac.rabc.util.EmcisEventLogger;
import com.att.carat.util.NetUtil;
import com.sbc.bac.rabc.load.FilePatternLoadJob;
import com.sbc.bac.rabc.load.PrepareTableForRerun;
import com.sbc.bac.rabc.load.RabcLoadJobTrig;
import com.sbc.bac.rabc.load.RetrieveStaticInfo;
import com.sbc.bac.rabc.load.StaticErrorMsgKeys;
import com.sbc.bac.rabc.load.StaticFieldKeys;

/**
 * This is a Load job which loads adjustment and deposits data for MW region into the following tables:
 * RABC_DAILY_ADJ_ACTVT
 * RABC_DAILY_BAL_TRSFR_ACTVT
 * RABC_DAILY_PYMT_ACTVT
 * RABC_DAILY_DEP_ACCT
 * RABC_DAILY_DEP_ACTVT
 * 
 * @author Shailesh Hemdev - SH8512
 */
public class DailyAdjLoadJob extends FilePatternLoadJob {
	/*
	 * Varables to represent the date formats
	 */
	private static final SimpleDateFormat YYMMDD_FORMAT 	= new SimpleDateFormat("yyMMdd");
	private static final SimpleDateFormat MMDDYYYY_FORMAT	= new SimpleDateFormat("MMddyyyy");
	private static final SimpleDateFormat MMDDYY_FORMAT	= new SimpleDateFormat("MMddyy");
	
	/*
	 * Variables to represent the table names.
	 */
	private static final String RABC_DAILY_ADJ_ACTVT		= "RABC_DAILY_ADJ_ACTVT";
	private static final String RABC_DAILY_BAL_TRSFR_ACTVT	= "RABC_DAILY_BAL_TRSFR_ACTVT";
	private static final String RABC_DAILY_PYMT_ACTVT		= "RABC_DAILY_PYMT_ACTVT";
	private static final String RABC_DAILY_DEP_ACCT			= "RABC_DAILY_DEP_ACCT";
	private static final String RABC_DAILY_DEP_ACTVT		= "RABC_DAILY_DEP_ACTVT";
	private static final String RABC_TRIG 					= "RABC_TRIG";
	
	/*
	 * Variables to represent the file ids to be inserted in RABC_TRIG table.
	 */
	private static final String ADJ_FILE_ID 		= "MWADJD";
	private static final String BAL_TRSFR_FILE_ID 	= "MWBALD";
	private static final String PYMT_FILE_ID 		= "MWPYMTD";
	private static final String DEP_FILE_ID 		= "MWDEPD";
	
	/*
	 * Variables to represent the prepared statements
	 */
	private PreparedStatement insertAdj;
	private PreparedStatement insertBalTrsfr;
	private PreparedStatement insertPymt;
	private PreparedStatement insertDepAcct;
	private PreparedStatement insertDepActvt;
	
	/*
	 * Global variables
	 */
	private String runDate;
	private java.sql.Date sqlRunDate;
	private String division;
	private String billRound;
	private int recordCount;
	private String backoutRecovery = null;
	private File currentFile;
	private String fieldSeperator = StaticFieldKeys.SEMICOLON;
	private int adjBatchCounter;
	private int balBatchCounter;
	private int pymtBatchCounter;
	private int depAcctBatchCounter;
	private int depActvtBatchCounter;
	private String fileName, fileToken, region;
	
	/*
	 * HashMap variables to contain the groups for various tables.
	 */
	private HashMap adjMap;
	private HashMap balTrsfrMap;
	private HashMap pymtMap;
	private HashMap depAcctMap;
	private HashMap depActvtMap;
	
	/*
	 * boolean variables indicating whether trigger to be inserted for that file id.
	 */
	boolean adj;
	boolean balTrsfr;
	boolean dep;
	boolean pymt;
	
	/*
	 * boolean variables indicating whether the file to be processed or not.
	 */
	boolean isHeaderExists;
	boolean isTrailerExists;
	boolean isDateRecordExists;
	boolean isRecordCountMatches;
	
	/**
	 * Overriding preprocess() method. 
	 * It is executed prior to processing the load job.
	 * Forms the actual prepared statements which need to be fired on to the database.
	 * 
	 * @see com.sbc.bac.load.LoadJob#preprocess()
	 */
	public boolean preprocess() {
		boolean success = super.preprocess();

		if (success) {
			try {
				insertAdj 		= connection.prepareStatement("INSERT INTO RABC_DAILY_ADJ_ACTVT (RUN_DATE, DIVISION, BTN, BUS_TYPE, TRN_CD, ADJ_REASON_CD, ADJ_CLS_CD, ADJ_AMT) VALUES(?, ?, ?, ?, ?, ?, ? , ?) ");
				insertBalTrsfr  = connection.prepareStatement("INSERT INTO RABC_DAILY_BAL_TRSFR_ACTVT (RUN_DATE, DIVISION, BTN, BUS_TYPE, TRN_CD, BAL_TRSFR_AMT) VALUES(?, ?, ?, ?, ?, ?) ");
				insertPymt		= connection.prepareStatement("INSERT INTO RABC_DAILY_PYMT_ACTVT (RUN_DATE, DIVISION, BTN, BUS_TYPE, TRN_CD, PYMT_DT, PYMT_AMT) VALUES(?, ?, ?, ?, ?, ?, ?) ");
				insertDepAcct	= connection.prepareStatement("INSERT INTO RABC_DAILY_DEP_ACCT (RUN_DATE, DIVISION, BTN, MRKT_IND, DEP_TOT_AMT) VALUES(?, ?, ?, ?, ?) ");
				insertDepActvt	= connection.prepareStatement("INSERT INTO RABC_DAILY_DEP_ACTVT (RUN_DATE, DIVISION, MRKT_IND, DEP_CT) VALUES(?, ?, ?, ?) ");
			} catch (SQLException e) {
				severe(StaticErrorMsgKeys.PREPROCESS_ERROR + e.getMessage(), e);
				success = false;
			}
		}
		
		return success;
	}
	
	/**
	 * Overriding preprocessFile(file) method.
	 * It is executed prior to processing the file to be loaded.
	 * It includes the following steps:
	 * 	1) Marks the backoutRecovery flag to "Y" if this file has already been processed earlier.
	 * 	2) Initializes the global variables with default values.
	 * 
	 * @see com.sbc.bac.load.FileDBLoadJob#preprocessFile(java.io.File)
	 */	
	public boolean preprocessFile(File file) {
		boolean success = super.preprocessFile(file);
		fileName = file.getName();
		fileToken = file.getName().substring(file.getName().indexOf("RA140F01"),file.getName().indexOf("RA140F01")+ 8);
		if (success) {
			try {
				region   =	file.getName().substring(0,2);
				
				/*
				 * Check whether this file has been processed before and if yes,
				 * mark the backoutRecovery flag to "Y".
				 */
				if (RabcLoadJobTrig.IsOriginalFileLoaded(connection, file, file.getName().length())) {
					backoutRecovery = "Y";
				}
			} catch (Exception e) {
				severe(StaticErrorMsgKeys.PREPROCESSFILE_ERROR + e.getMessage(), e);
				success = false;
			}
		}
		
		/*
		 * Initialize the global variables with default values.
		 */
		currentFile = file;
		recordCount = 0;
		isHeaderExists = false;
		isTrailerExists = false;
		isDateRecordExists=false;
		isRecordCountMatches = false;
		
		/*
		 * Initialize the maps
		 */
		adjMap = new HashMap();
		balTrsfrMap = new HashMap();
		pymtMap = new HashMap();
		depAcctMap = new HashMap();
		depActvtMap = new HashMap();
		
		/*
		 * Initialize the booleans
		 */
		adj = false;
		balTrsfr = false;
		pymt = false;
		dep = false;
		
		/*
		 * Initialize the batch counters
		 */
		adjBatchCounter = 0;
		balBatchCounter = 0;
		pymtBatchCounter = 0;
		depAcctBatchCounter = 0;
		depActvtBatchCounter = 0;
		
		return success;
	}
	
	/**
	 * Overriding parseLine(line) method.
	 * It accepts a single line and checks whether it is header, trailer, date or detail record.
	 * Depending upon the record type, it calls the respective internal private methods to process the line.
	 * 
	 * @see com.sbc.bac.load.FileDBLoadJob#parseLine(java.lang.String)
	 */
	protected int parseLine(String line) throws Exception {
		boolean status = true;
		String recordIndicator = getRecordType(line);
		
		if ("HEADER".equalsIgnoreCase(recordIndicator)) {
			isHeaderExists = true;
			status = processHeader(line);
		} else if ("DATE".equalsIgnoreCase(recordIndicator)) {
			if (!isHeaderExists) {
				throw new Exception("Either header record is not present in the file or it is not the first record.");
			} else {
				isDateRecordExists = true;
				recordCount++;
				status = processCycleRecord(line);
			}
		} else if ("TRAILER".equalsIgnoreCase(recordIndicator)) {
			if (!isHeaderExists) {
				throw new Exception("Either header record is not present in the file or it is not the first record.");
			}else if (!isDateRecordExists){
				throw new Exception("Either date record is not present in the file or it is not the second record.");
			}else {
				isTrailerExists = true;
				status = processTrailer(line);
			}
		}  else if ("ADJ".equalsIgnoreCase(recordIndicator)) {
			if (!isHeaderExists) {
				throw new Exception("Either header record is not present in the file or it is not the first record.");
			} else if (!isDateRecordExists) {
				throw new Exception("Either date record is not present in the file or it is not the second record.");
			} else if (isTrailerExists) {
				throw new Exception("Trailer record is not the last record.");
			} else {
				recordCount++;
				status = processAdj(line);
			}
		} else if ("BALTRSFR".equalsIgnoreCase(recordIndicator)) {
			if (!isHeaderExists) {
				throw new Exception("Either header record is not present in the file or it is not the first record.");
			} else if (!isDateRecordExists) {
				throw new Exception("Either date record is not present in the file or it is not the second record.");
			} else if (isTrailerExists) {
				throw new Exception("Trailer record is not the last record.");
			} else {
				recordCount++;
				status = processBalTrsfr(line);
			}
		} else if ("PYMT".equalsIgnoreCase(recordIndicator)) {
			if (!isHeaderExists) {
				throw new Exception("Either header record is not present in the file or it is not the first record.");
			} else if (!isDateRecordExists) {
				throw new Exception("Either date record is not present in the file or it is not the second record.");
			} else if (isTrailerExists) {
				throw new Exception("Trailer record is not the last record.");
			} else {
				recordCount++;
				status = processPymt(line);
			}
		} else if ("DEP".equalsIgnoreCase(recordIndicator)) {
			if (!isHeaderExists) {
				throw new Exception("Either header record is not present in the file or it is not the first record.");
			} else if (!isDateRecordExists) {
				throw new Exception("Either date record is not present in the file or it is not the second record.");
			} else if (isTrailerExists) {
				throw new Exception("Trailer record is not the last record.");
			} else {
				recordCount++;
				status = processDep(line);
			}
		} else {
			recordCount++;
			status = false;
		}
		
		if (status) {
			return SUCCESS;
		} else {
			return ERROR;
		}
	}
	
	/**
	 * Private method to return the record type of the line to be processed.
	 * 
	 * @param line
	 * @return String
	 * @throws Exception
	 */
	private String getRecordType(String line) throws Exception {
		String recordType = null;
		
		String [] lineFields 	= line.split(fieldSeperator);
		String firstField		= lineFields[0].trim();
		String secondField		= lineFields[1].trim();
		
		if ("HEADER".equals(firstField)) {
			recordType = "HEADER";
		} else if ("TRAILER".equals(firstField)) {
			recordType = "TRAILER";
		} else if ("RA14DATE".equals(firstField)) {
			recordType = "DATE";
		} else if ("RA14ADJS".equals(firstField)) {
			if ("01".equals(secondField)) {
				recordType = "ADJ";
			} else if ("02".equals(secondField)) {
				recordType = "BALTRSFR";
			} else if ("03".equals(secondField)) {
				recordType = "PYMT";
			}
		} else if ("RA14DEPS".equals(firstField)){
			if ("10".equals(secondField)){
				recordType = "DEP";
			}
		}
		
		return recordType;
	}

	/**
	 * Private method to process the header record.
	 * 
	 * @param line
	 * @return boolean
	 * @throws Exception
	 */
	private boolean processHeader(String line) throws Exception {
		boolean success = false;
		
		String [] lineFields = line.split(fieldSeperator);
		
		/*
		 * Populate the instance variable for division.
		 */
		if (lineFields.length > 2) {
			division = lineFields[2].trim();
			success = true;
		}
		
		return success;
	}
	
	/**
	 * Private method to process the trailer record.
	 * It checks that whether the total number of records (excluding header and trailer records)
	 * in the file is eqaul to the count in the trailer record or not.
	 *  
	 * @param line
	 * @return boolean
	 * @throws Exception
	 */
	private boolean processTrailer(String line) throws Exception {
		boolean success = false;
		int trailerCount = 0;
		
		String [] lineFields = line.split(fieldSeperator);
		
		if (lineFields.length > 5) {
			trailerCount = Integer.parseInt(lineFields[5].trim());
			success = true;
		}
		
		if (success) {
			if (trailerCount == recordCount) {
				isRecordCountMatches = true;
			}
		}
		
		return success;
	}
	
	/**
	 * Private method to process the date record. It does the following steps:
	 * 	1) Retrieves the cycle date from the date record.
	 * 	2) Deletes the records matching with the date and division retrieved form the file from the tables 
	 * 	   RABC_DAILY_ADJ_ACTVT, RABC_DAILY_BAL_TRSFR_ACTVT, RABC_DAILY_PYMT_ACTVT, 
	 * 	   RABC_DAILY_DEP_ACTCT and RABC_DAILY_DEP_ACTVT if the backoutRecovery flag is "Y", 
	 * 	   i.e. this file has already been processed earlier.
	 * 
	 * @param line
	 * @return boolean
	 * @throws Exception
	 */
	private boolean processCycleRecord(String line) throws Exception {
		boolean success = false;
		
		String [] lineFields = line.split(fieldSeperator);
		
		/*
		 * Populate the instance variable for runDate and billRound.
		 */
		if (lineFields.length > 3) {
			runDate = lineFields[2].trim();
			billRound = lineFields[3].trim();
			if ("00".equals(billRound) || "".equals(billRound.trim())) {
				billRound = "0";
			}
			success = true;
		}
		
		if (success) {
			sqlRunDate = new java.sql.Date(YYMMDD_FORMAT.parse(runDate).getTime());
			runDate = MMDDYYYY_FORMAT.format(YYMMDD_FORMAT.parse(runDate));
			
			String runDatequery = "SELECT PROC_DT FROM RABC_CYCLE_CALENDAR WHERE PROC_DT = to_date('" + runDate + "','MMddyyyy')";
			boolean isRunDateExists	= RetrieveStaticInfo.isProcDateExists(connection, runDatequery);
			
			if (!isRunDateExists) {
				throw new Exception("The cycle date " + runDate + " does not exist in RABC_CYCLE_CALENDAR table.");
			}
			
			if ("Y".equals(backoutRecovery)){
				if (!PrepareTableForRerun.deleteTableData(connection, RABC_DAILY_ADJ_ACTVT, division, sqlRunDate)) {
					throw new Exception("Error occurred attempting to backup and recover for rerun for table: " + RABC_DAILY_ADJ_ACTVT);
				}
				if (!PrepareTableForRerun.deleteTableData(connection, RABC_DAILY_BAL_TRSFR_ACTVT, division, sqlRunDate)) {
					throw new Exception("Error occurred attempting to backup and recover for rerun for table: " + RABC_DAILY_BAL_TRSFR_ACTVT);
				}
				if (!PrepareTableForRerun.deleteTableData(connection, RABC_DAILY_PYMT_ACTVT, division, sqlRunDate)) {
					throw new Exception("Error occurred attempting to backup and recover for rerun for table: " + RABC_DAILY_PYMT_ACTVT);
				}
				if (!PrepareTableForRerun.deleteTableData(connection, RABC_DAILY_DEP_ACCT, division, sqlRunDate)) {
					throw new Exception("Error occurred attempting to backup and recover for rerun for table: " + RABC_DAILY_DEP_ACCT);
				}
				if (!PrepareTableForRerun.deleteTableData(connection, RABC_DAILY_DEP_ACTVT, division, sqlRunDate)) {
					throw new Exception("Error occurred attempting to backup and recover for rerun for table: " + RABC_DAILY_DEP_ACTVT);
				}
			}
		}
		
		return success;
	}
	
	/**
	 * Private method to process the records for Adjustments with rule number '01' of rule 'RA14ADJS'.
	 * It does the following steps:
	 * 	1) Retrieves the fields from the line.
	 * 	2) Does conversion of data from String to appropriate data types as well as interpretation for amount.
	 * 	3) Creates the objects of DailyAdjActvt type.
	 * 	4) Populates the hash map with those objects.
	 * 
	 * @param line
	 * @return boolean
	 * @throws Exception
	 */
	private boolean processAdj(String line) throws Exception {
		boolean success = false;
		
		String [] lineFields = line.split(fieldSeperator);
		
		if (lineFields.length == 8) {
			success = true;
			
			String ruleName		= lineFields[0].trim();
			String seqNumber	= lineFields[1].trim();
			String btn			= lineFields[2].trim();
			String custType		= lineFields[3].trim();
			String trnCd		= lineFields[4].trim();
			String adjReasonCd	= lineFields[5].trim();
			String adjClsCd		= lineFields[6].trim();
			String adjTotalAmt	= lineFields[7].trim();
			
			/*
			 * Apply logic for determining business type based on the customer type
			 */
			String busType = null;
			if ("D".equals(custType) || "K".equals(custType) || "R".equals(custType)) {
				busType = "RES";
			} else {
				busType = "BUS";
			}
			
			/*
			 * Format the amount value
			 */
			double totalAdjAmt = Double.parseDouble(adjTotalAmt) / 100 ;
			
			/*
			 * Create object to check for presense - apply grouping logic
			 */
			DailyAdjActvt dailyAdjActvt	= new DailyAdjActvt();
			dailyAdjActvt.setRunDate(MMDDYYYY_FORMAT.parse(runDate));
			dailyAdjActvt.setDivision(division);
			dailyAdjActvt.setBtn(btn);
			dailyAdjActvt.setBusType(busType);
			dailyAdjActvt.setTrnCd(trnCd);
			dailyAdjActvt.setAdjReasonCd(adjReasonCd);
			dailyAdjActvt.setAdjClsCd(adjClsCd);
			
			DailyAdjActvt objRef = (DailyAdjActvt) adjMap.get(dailyAdjActvt);
			if (objRef != null){
				totalAdjAmt += objRef.getAdjAmt();
				objRef.setAdjAmt(totalAdjAmt);
				adjMap.put(objRef, objRef);
			} else {
				dailyAdjActvt.setAdjAmt(totalAdjAmt);
				adjMap.put(dailyAdjActvt, dailyAdjActvt);
			}
		}
		
		return success;
	}
	
	/**
	 * Private method to process the records for Adjustments with rule number '02' of rule 'RA14ADJS'.
	 * It does the following steps:
	 * 	1) Retrieves the fields from the line.
	 * 	2) Does conversion of data from String to appropriate data types as well as interpretation for amount.
	 * 	3) Creates the objects of DailyBalTrsfrActvt type.
	 * 	4) Populates the hash map with those objects.
	 * 
	 * @param line
	 * @return boolean
	 * @throws Exception
	 */
	private boolean processBalTrsfr(String line) throws Exception {
		boolean success = false;
		
		String [] lineFields = line.split(fieldSeperator);
		
		if (lineFields.length == 6) {
			success = true;
			
			String ruleName		= lineFields[0].trim();
			String seqNumber	= lineFields[1].trim();
			String btn			= lineFields[2].trim();
			String custType		= lineFields[3].trim();
			String trnCd		= lineFields[4].trim();
			String balTrsfr		= lineFields[5].trim();
			
			/*
			 * Apply logic for determining business type based on the customer type
			 */
			String busType = null;
			if ("D".equals(custType) || "K".equals(custType) || "R".equals(custType)) {
				busType = "RES";
			} else {
				busType = "BUS";
			}
			
			/*
			 * Format the amount value
			 */
			double balTrsfrAmt = Double.parseDouble(balTrsfr) / 100 ;
			
			/*
			 * Create object to check for presense - apply grouping logic
			 */
			DailyBalTrsfrActvt dailyBalTrsfrActvt = new DailyBalTrsfrActvt();
			dailyBalTrsfrActvt.setRunDate(MMDDYYYY_FORMAT.parse(runDate));
			dailyBalTrsfrActvt.setDivision(division);
			dailyBalTrsfrActvt.setBtn(btn);
			dailyBalTrsfrActvt.setBusType(busType);
			dailyBalTrsfrActvt.setTrnCd(trnCd);
			
			DailyBalTrsfrActvt objRef = (DailyBalTrsfrActvt) balTrsfrMap.get(dailyBalTrsfrActvt);
			if (objRef != null){
				balTrsfrAmt += objRef.getBalTrsfrAmt();
				objRef.setBalTrsfrAmt(balTrsfrAmt);
				balTrsfrMap.put(objRef, objRef);
			} else {
				dailyBalTrsfrActvt.setBalTrsfrAmt(balTrsfrAmt);
				balTrsfrMap.put(dailyBalTrsfrActvt, dailyBalTrsfrActvt);
			}
		}
		
		return success;
	}
	
	/**
	 * Private method to process the records for Adjustments with rule number '03' of rule 'RA14ADJS'.
	 * It does the following steps:
	 * 	1) Retrieves the fields from the line.
	 * 	2) Does conversion of data from String to appropriate data types as well as interpretation for amount.
	 * 	3) Creates the objects of DailyPymtActvt type.
	 * 	4) Populates the hash map with those objects.
	 * 
	 * @param line
	 * @return boolean
	 * @throws Exception
	 */
	private boolean processPymt(String line) throws Exception {
		boolean success = false;
		
		String [] lineFields = line.split(fieldSeperator);
		
		if (lineFields.length == 7) {
			success = true;
			
			String ruleName		= lineFields[0].trim();
			String seqNumber	= lineFields[1].trim();
			String btn			= lineFields[2].trim();
			String custType		= lineFields[3].trim();
			String actvtDt		= lineFields[4].trim();
			String trnCd		= lineFields[5].trim();
			String payment		= lineFields[6].trim();
			
			/*
			 * Apply logic for determining business type based on the customer type
			 */
			String busType = null;
			if ("D".equals(custType) || "K".equals(custType) || "R".equals(custType)) {
				busType = "RES";
			} else {
				busType = "BUS";
			}
			
			/*
			 * Format the amount value
			 */
			double pymtAmt = Double.parseDouble(payment) / 100 ;
			
			/*
			 * Create object to check for presense - apply grouping logic
			 */
			DailyPymtActvt dailyPymtActvt = new DailyPymtActvt();
			dailyPymtActvt.setRunDate(MMDDYYYY_FORMAT.parse(runDate));
			dailyPymtActvt.setDivision(division);
			dailyPymtActvt.setBtn(btn);
			dailyPymtActvt.setBusType(busType);
			dailyPymtActvt.setTrnCd(trnCd);
			dailyPymtActvt.setPymtDate(MMDDYY_FORMAT.parse(actvtDt));
			
			DailyPymtActvt objRef = (DailyPymtActvt) pymtMap.get(dailyPymtActvt);
			if (objRef != null){
				pymtAmt += objRef.getPymtAmt();
				objRef.setPymtAmt(pymtAmt);
				pymtMap.put(objRef, objRef);
			} else {
				dailyPymtActvt.setPymtAmt(pymtAmt);
				pymtMap.put(dailyPymtActvt, dailyPymtActvt);
			}
		}
		
		return success;
	}
	
	/**
	 * Private method to process the records for Deposits with rule number '10' of rule 'RA14DEPS'.
	 * It does the following steps:
	 * 	1) Retrieves the fields from the line.
	 * 	2) Does conversion of data from String to appropriate data types as well as interpretation for amount.
	 * 	3) Creates the objects of DailyDepAcct and DailyDepActvt type.
	 * 	4) Populates the hash map with those objects.
	 * 
	 * @param line
	 * @return boolean
	 * @throws Exception
	 */
	private boolean processDep(String line) throws Exception {
		boolean success = true;
		
		String [] lineFields = line.split(fieldSeperator);
		
		if (lineFields.length == 6) {
			success = true;
			
			String ruleName		= lineFields[0].trim();
			String seqNumber	= lineFields[1].trim();
			String billPeriod	= lineFields[2].trim();
			String btn			= lineFields[3].trim();
			String mktInd		= lineFields[4].trim();
			String amtDep		= lineFields[5].trim();
			
			/*
			 * Format the amount value
			 */	
			double depAmt	= Double.parseDouble(amtDep);
			
			if (mktInd.length() > 1) {
				mktInd = mktInd.substring(0, 1);
			}
			
			/*
			 * Create object to check for presense of DailyDepAcct object - apply grouping logic
			 */
			DailyDepAcct dailyDepAcct	= new DailyDepAcct();
			dailyDepAcct.setRunDate(MMDDYYYY_FORMAT.parse(runDate));
			dailyDepAcct.setDivision(division);
			dailyDepAcct.setBtn(btn);
			dailyDepAcct.setMktInd(mktInd);
			
			DailyDepAcct objRefAcct = (DailyDepAcct) depAcctMap.get(dailyDepAcct);
			if (objRefAcct != null){
				depAmt += objRefAcct.getDepTotAmt();
				objRefAcct.setDepTotAmt(depAmt);
				depAcctMap.put(objRefAcct, objRefAcct);
			} else {
				dailyDepAcct.setDepTotAmt(depAmt);
				depAcctMap.put(dailyDepAcct, dailyDepAcct);
			}
			
			/*
			 * Create object to check for presense of DailyDepActvt object - apply grouping logic
			 */
			DailyDepActvt dailyDepActvt	= new DailyDepActvt();
			dailyDepActvt.setRunDate(MMDDYYYY_FORMAT.parse(runDate));
			dailyDepActvt.setDivision(division);
			dailyDepActvt.setMktInd(mktInd);
			
			DailyDepActvt objRefActvt = (DailyDepActvt) depActvtMap.get(dailyDepActvt);
			if (objRefActvt != null){
				objRefActvt.setDepCt(objRefActvt.getDepCt() + 1);
				depActvtMap.put(objRefActvt, objRefActvt);
			} else {
				dailyDepActvt.setDepCt(1);
				depActvtMap.put(dailyDepActvt, dailyDepActvt);
			}
		}
		
		return success;
	}
		
	/**
	 * Overriding postProcessFile(file, success) method.
	 * It is executed post to processing the file to be loaded.
	 * It includes the following steps:
	 * 	1) It checks whether the header and trailer records exists and 
	 * 	   whether the total number of records (excluding header and trailer records)
	 * 	   in the file is eqaul to the count in the trailer record.
	 * 	   If it is then prcoceeds to next step else return false.
	 * 	2) Loops through the maps and insert entries into respective tables.
	 * 	3) Makes the entries into RABC_TRIG table.
	 * 
	 * @see com.sbc.bac.load.FileDBLoadJob#postprocessFile(java.io.File, boolean)
	 */
	public boolean postprocessFile(File file, boolean success) {
		try{
			//Log the file information to EMCIS_EVENT_LOG and EMCIS_EVENT_LOG_DETAIL
			EmcisEventLogger emcisLogger = new EmcisEventLogger();
			String event_id = "RABC_"+fileToken+"_"+region;
            String host = NetUtil.getLocalHostName();
            String hostIP = NetUtil.getLocalIpAddress();
			int sequence = emcisLogger.getEMCISSequence(connection);
			emcisLogger.insertEventLog(connection, sequence, event_id, sqlRunDate, host, hostIP);
			emcisLogger.insertEventLogDetail(connection, sequence, "FileName", fileName);

		}catch (UnknownHostException e) {
            severe("Error getting EMCIS host information ", e);
        }
		if (success) {
			if (!isTrailerExists) {
				severe("Trailer record is not present in the file.");
				success = false;
			} else if (!isRecordCountMatches) {
				severe("Total number of records in the file is not eqaul to the count in the trailer record.");
				success = false;
			} else {
				try {
					Iterator adjIterator 		= adjMap.keySet().iterator();
					Iterator balTrsfrIterator 	= balTrsfrMap.keySet().iterator();
					Iterator pymtIterator 		= pymtMap.keySet().iterator();
					Iterator depAcctIterator 	= depAcctMap.keySet().iterator();
					Iterator depActvtIterator 	= depActvtMap.keySet().iterator();
					
					/*
					* Inserts to RABC_DAILY_ADJ_ACTVT table
					*/	
					while (adjIterator.hasNext()){
						adjBatchCounter++;
						
						DailyAdjActvt dailyAdjActvt = (DailyAdjActvt) adjIterator.next();		
						insertAdj.setDate(1, sqlRunDate);
						insertAdj.setString(2, division);
						insertAdj.setString(3, dailyAdjActvt.getBtn());
						insertAdj.setString(4, dailyAdjActvt.getBusType());
						insertAdj.setString(5, dailyAdjActvt.getTrnCd());
						
						/* Required changes for PMT# M169 issue number M3
						 * Set Default Value 'NA' for ADJ_REASON_CD and Z for ADJ_CLS_CD 
						 */
						
						//insertAdj.setString(6, dailyAdjActvt.getAdjReasonCd());
						
						if((("").equals(dailyAdjActvt.getAdjReasonCd())) || (dailyAdjActvt.getAdjReasonCd()).equals(null)){
						 insertAdj.setString(6,"NA");			// ADJ_REASON_CD
						}else{
						 insertAdj.setString(6,dailyAdjActvt.getAdjReasonCd());		
						}						
												
						//insertAdj.setString(7, dailyAdjActvt.getAdjClsCd());
						
						if((("").equals(dailyAdjActvt.getAdjClsCd())) || dailyAdjActvt.getAdjClsCd().equals(null)){
							
							insertAdj.setString(7,"Z");			   // ADJ_CLS_CD
						}else{
							insertAdj.setString(7,dailyAdjActvt.getAdjClsCd());		// ADJ_CLS_CD
						}
						/* Closed requirement for PMT# M169 issue # M3*/
						
						insertAdj.setDouble(8, dailyAdjActvt.getAdjAmt());
						insertAdj.addBatch();
						
						if (adjBatchCounter % 1000 == 0){
							insertAdj.executeBatch();
						}
						adj = true;
					}
					
					/*
					 * Execute the last batch
					 */
					insertAdj.executeBatch();
					
					/*
					* Inserts to RABC_DAILY_BAL_TRSFR_ACTVT table
					*/
					while (balTrsfrIterator.hasNext()){
						balBatchCounter++;
						
						DailyBalTrsfrActvt dailyBalTrsfrActvt = (DailyBalTrsfrActvt)balTrsfrIterator.next();		
						insertBalTrsfr.setDate(1, sqlRunDate);
						insertBalTrsfr.setString(2, division);
						insertBalTrsfr.setString(3, dailyBalTrsfrActvt.getBtn());
						insertBalTrsfr.setString(4, dailyBalTrsfrActvt.getBusType());
						insertBalTrsfr.setString(5, dailyBalTrsfrActvt.getTrnCd());
						insertBalTrsfr.setDouble(6, dailyBalTrsfrActvt.getBalTrsfrAmt());
						insertBalTrsfr.addBatch();
						
						if (balBatchCounter % 1000 == 0){
							insertBalTrsfr.executeBatch();
						}
						balTrsfr = true;
					}
					
					/*
					 * Execute the last batch
					 */
					insertBalTrsfr.executeBatch();
					
					/*
					* Inserts to RABC_DAILY_PYMT_ACTVT table
					*/	
					while (pymtIterator.hasNext()){
						pymtBatchCounter++;
						
						DailyPymtActvt dailyPymtActvt = (DailyPymtActvt)pymtIterator.next();		
						java.sql.Date pymtDt = new java.sql.Date(dailyPymtActvt.getPymtDate().getTime());
						insertPymt.setDate(1, sqlRunDate);
						insertPymt.setString(2, division);
						insertPymt.setString(3, dailyPymtActvt.getBtn());
						insertPymt.setString(4, dailyPymtActvt.getBusType());
						insertPymt.setString(5, dailyPymtActvt.getTrnCd());
						insertPymt.setDate(6, pymtDt);
						insertPymt.setDouble(7, dailyPymtActvt.getPymtAmt());
						insertPymt.addBatch();
						
						if (pymtBatchCounter % 1000 == 0){
							insertPymt.executeBatch();
						}
						pymt = true;
					}
					
					/*
					 * Execute the last batch
					 */
					insertPymt.executeBatch();
					
					/*
					* Inserts to RABC_DAILY_DEP_ACCT table
					*/	
					while (depAcctIterator.hasNext()){
						depAcctBatchCounter++;
						
						DailyDepAcct dailyDepAcct = (DailyDepAcct)depAcctIterator.next();
						insertDepAcct.setDate(1, sqlRunDate);
						insertDepAcct.setString(2, division);
						insertDepAcct.setString(3, dailyDepAcct.getBtn());
						insertDepAcct.setString(4, dailyDepAcct.getMktInd());
						insertDepAcct.setDouble(5, dailyDepAcct.getDepTotAmt());
						insertDepAcct.addBatch();
						
						if (depAcctBatchCounter % 1000 == 0){
							insertDepAcct.executeBatch();
						}
					}
					
					/*
					* Inserts to RABC_DAILY_DEP_ACTVT table
					*/	
					while (depActvtIterator.hasNext()){
						depActvtBatchCounter++;
						
						DailyDepActvt dailyDepActvt = (DailyDepActvt)depActvtIterator.next();
						insertDepActvt.setDate(1, sqlRunDate);
						insertDepActvt.setString(2, division);
						insertDepActvt.setString(3, dailyDepActvt.getMktInd());
						insertDepActvt.setLong(4, dailyDepActvt.getDepCt());
						insertDepActvt.addBatch();
						
						if (depActvtBatchCounter % 1000 == 0){
							insertDepActvt.executeBatch();
						}
						dep = true;
					}
					
					/*
					 * Insert a single record with zero count and amount, if no deposit record is there.
					 */
					if (dep == false) {
						insertDepAcct.setDate(1, sqlRunDate);
						insertDepAcct.setString(2, division);
						insertDepAcct.setString(3, "9999999999999");
						insertDepAcct.setString(4, null);
						insertDepAcct.setDouble(5, 0.00);
						insertDepAcct.addBatch();
						
						insertDepActvt.setDate(1, sqlRunDate);
						insertDepActvt.setString(2, division);
						insertDepActvt.setString(3, null);
						insertDepActvt.setLong(4, 0);
						insertDepActvt.addBatch();
					}
					
					/*
					 * Execute the last batches
					 */
					insertDepAcct.executeBatch();
					insertDepActvt.executeBatch();
										
					/*
					 * Call the private method to make the entries into RABC_TRIG table
					 */
					if (!insertTrigger()) {
						success = false;
					}	
				} catch (SQLException sqle){
					severe(StaticErrorMsgKeys.INSERT_ERROR + sqle.getMessage(), sqle);
					success = false;
				}
			}
		}
		
		return super.postprocessFile(file, success);
	}
	
	/**
	 * This is a method to insert entry into RABC_TRIG table
	 * 
	 * @return boolean
	 */
	private boolean insertTrigger() {
		/*
		 * Check whether there were any adjustment records inserted if yes then insert into trigger
		 */
		if (adj) {
			if(!RabcLoadJobTrig.insertTrigger(connection, currentFile.getName().substring(5,currentFile.getName().length()), currentFile.getName(), ADJ_FILE_ID, division, runDate , backoutRecovery, billRound, RABC_TRIG)) {
				return false;
			}
		}
		
		/*
		 * Check whether there were any balance transfer records inserted if yes then insert into trigger
		 */
		if (balTrsfr) {
			if(!RabcLoadJobTrig.insertTrigger(connection, currentFile.getName().substring(5,currentFile.getName().length()), currentFile.getName(), BAL_TRSFR_FILE_ID, division, runDate , backoutRecovery, billRound, RABC_TRIG)) {
				return false;
			}
		}
		
		/*
		 * Check whether there were any payment records inserted if yes then insert into trigger
		 */
		if (pymt) {
			if(!RabcLoadJobTrig.insertTrigger(connection, currentFile.getName().substring(5,currentFile.getName().length()), currentFile.getName(), PYMT_FILE_ID, division, runDate , backoutRecovery, billRound, RABC_TRIG)) {
				return false;
			}
		}
		
		/*
		 * Insert trigger for deposit table
		 */
		if(!RabcLoadJobTrig.insertTrigger(connection, currentFile.getName().substring(5,currentFile.getName().length()), currentFile.getName(), DEP_FILE_ID, division, runDate , backoutRecovery, billRound, RABC_TRIG)) {
			return false;
		}
		
		return true;
	}
	
	/**
	 * Overriding postProcess(success) method.
	 * It is executed post to processing the load job.
	 * It includes the following steps:
	 * 	1) Closes statements that were opened for this load job.
	 * 
	 * @see com.sbc.bac.load.LoadJob#postprocess(boolean)
	 */
	public boolean postprocess(boolean success) {
		try {
			insertAdj.close();
			insertBalTrsfr.close();
			insertDepAcct.close();
			insertDepActvt.close();
			insertPymt.close();
		} catch (SQLException e) {
			severe(StaticErrorMsgKeys.POSTPROCESS_ERROR + StaticErrorMsgKeys.SQL_CLOSE_ERROR + e.getMessage(), e);
			success = false;
		}
		
		return super.postprocess(success);
	}
}
