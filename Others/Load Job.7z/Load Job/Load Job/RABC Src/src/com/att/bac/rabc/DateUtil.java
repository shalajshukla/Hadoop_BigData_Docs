/*
 * Created on Oct 23, 2003
 * Project: Bac Utilities
 * File: DateUtil.java
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc;

import java.sql.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 * @author Brennan Spies(bs8145)
 * Utility class with factory methods for doing common operations with Java dates.
 * This class assumes that you are using a GregorianCalendar, and statically intializes
 * an instance of one. If you are doing a lot of date manipulations, these methods also
 * make your code more efficient, since Calendar objects are expensive to create.
 */
public class DateUtil
{
	private static Calendar calendar = Calendar.getInstance();
	
	/**
	 * Private constructor enforces non-instantiability.
	 */
	private DateUtil() {}
	
	/**
	 * Convenience method to get day of month from a date.
	 * @param date The date from which to extract day of month
	 * @return int The day of month as an integer
	 */
	public static int getDayOfMonth(java.util.Date date)
	{
		calendar.setTime(date);
		return calendar.get(Calendar.DAY_OF_MONTH);
	}
	
	/**
	 * Convenience method to get day of week from a date.
	 * @param date The date from which to extract day of week
	 * @return int The day of week as an integer
	 */
	public static int getDayOfWeek(java.util.Date date)
	{
		calendar.setTime(date);
		return calendar.get(Calendar.DAY_OF_WEEK);
	}
	
	/**
	 * Convnience method to get month of year from date
	 * @param date The date from whcih to extract the month
	 * @return int The month as an integer
	 */
	public static int getMonthOfYear(java.util.Date date)
	{
		calendar.setTime(date);
		return calendar.get(Calendar.MONTH);
	}
	
	/**
	 * Convnience method to get year from date
	 * @param date The date from whcih to extract the month
	 * @return int The year as an integer
	 */
	public static int getYear(java.util.Date date)
	{
		calendar.setTime(date);
		return calendar.get(Calendar.YEAR);
	}
	
	/**
	 * Convenience method to get an SQL Date object representing the
	 * date on the previous day from the date of the method parameter.
	 * @param date The reference date
	 * @return Date The date one day previous to the reference day
	 */
	public static Date getPreviousDay(java.util.Date date)
	{
		calendar.setTime(date);
		calendar.add(Calendar.DAY_OF_YEAR, -1);
		return new Date(calendar.getTimeInMillis());
	}
	
	/**
	 * Convenience method to get an SQL Date object representing the
	 * date on the previous month from the date of the method parameter.
	 * @param date The reference date
	 * @return Date The date one month previous to the reference day
	 */
	public static Date getPreviousMonth(java.util.Date date)
	{
		calendar.setTime(date);
		calendar.add(Calendar.MONTH, -1);
		return new Date(calendar.getTimeInMillis());
	}
	
	/**
	 * Convenience method to get an SQL Date object representing the
	 * date on first of the month using the date of the method parameter.
	 * @param date The reference date
	 * @return Date The date on the first day of the month relative to the reference date
	 */
	public static Date getFirstDayOfMonth(java.util.Date date)
	{
		calendar.setTime(date);
		calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMinimum(Calendar.DAY_OF_MONTH));
		return new Date(calendar.getTimeInMillis());
	}
	
	/**
	 * Convenience method to get an SQL Date object representing the date
	 * on the last day of the month using the date of the method parameter.
	 * @param date The reference date
	 * @return Date The date on the last day of the month relative to the refernce date
	 */
	public static Date getLastDayOfMonth(java.util.Date date)
	{
		calendar.setTime(date);
		calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
		return new Date(calendar.getTimeInMillis());
	}
	
	/**
	 * Convenience method to test for a leap year.
	 * @param date The date from which to extract year
	 * @return boolean True if year is leap year, false otherwise
	 */
	public static boolean isLeapYear(java.util.Date date)
	{
		calendar.setTime(date);
		return ((GregorianCalendar)calendar).isLeapYear(Calendar.YEAR);
	}
	
	/**
	 * Convenience method to adjust a date by a given amount.
	 * @param d The reference date
	 * @param field The date field to adjust, e.g. month, day, etc.
	 * @param delta The amount to adjust the field by in the date
	 * @return Date The adjusted date
	 */
	public static Date addToDate(Date d, int field, int delta ){
		calendar.setTime(d);
		calendar.add(field, delta);
		return new Date(calendar.getTimeInMillis());
	}
	
	/**
	 * Convenience method to get a date from a given year, month, and day.
	 * CAUTION: the month of year starts at zero, so you should use the constants
	 * in the Calendar class: JANUARY, FEBRUARY, etc.
	 * @param year The year to set
	 * @param month The month to set (use Calendar constants)
	 * @param day The day of month to set
	 * @return Date The date corresponding to the parameters
	 */
	public static Date getDate(int year, int month, int day)
	{
		calendar.set(year, month, day);
		return new Date(calendar.getTimeInMillis());
	}
	
	/**
	 * Parses a date string using the SimpleFormat class.
	 * @param date The date string
	 * @param format The format of the date string, as described in SimpleFormat docs
	 * @return Date The data corresponding to the string
	 * @throws ParseException If an error occurs in parsing
	 */
	public static Date parseDate(String date, String format) throws ParseException
	{
		DateFormat df = new SimpleDateFormat(format);
		return new Date(df.parse(date).getTime());
	}
	
	/**
	 * Attempts to parse a simple date (only day, month, year) without knowing the
	 * specific date format. Year MUST be Y2K compliant (i.e., four digits).
	 * @param date The date string
	 * @return Date The parsed date, or null if date format unknown
	 * @throws ParseException If The date cannot be parsed
	 */
	public static Date parseUnknown(String date) throws ParseException
	{
		if(date.matches("\\d{8}")) {
			return parseDate(date, "yyyyMMdd");
		}
		else if(date.matches("\\d{2}[/]\\d{2}[/]\\d{4}")) {
			return parseDate(date, "MM/dd/yyyy");
		}
		else if(date.matches("\\d{4}[-]\\d{2}[-]\\d{2}")) {
			return parseDate(date, "yyyy-MM-dd");
		}
		else if(date.matches("\\d{2}[-]([a-zA-Z]){3}[-]\\d{4}")) {
			return parseDate(date, "dd-MMM-yyyy");
		} else if(date.matches("\\d{2}[-]([a-zA-Z]){3}[-]\\d{2}")) {
			return parseDate(date, "dd-MMM-yy");
		} else if(date.matches("([a-zA-Z]){3}[ ]\\d{2}[,][ ]*\\d{4}")) {
			return parseDate(date, "MMM dd, yyyy");
		} else {
			return null;
		}
	}
}
