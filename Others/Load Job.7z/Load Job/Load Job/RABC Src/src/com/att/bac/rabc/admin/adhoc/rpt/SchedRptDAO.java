/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.admin.adhoc.rpt;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.ArrayList;
import java.text.MessageFormat;

import org.apache.log4j.Logger;

import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.RABCException;

/**
 * This is a DAO that performs SELECT, INSERT and UPDATE on RABC_SCHED_RPT table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class SchedRptDAO {
	private static final Logger logger = Logger.getLogger(SchedRptDAO.class);

	/**
	 * Returns the list of SchedRpt objects.
	 * 
	 * @param conn 
	 * @param failures
	 * @param args
	 * @param baseSQL
	 * @return List
	 */
	public List get(Connection conn, List failures, List args, String baseSQL) {
		List schedRptList = null;
		SchedRpt schedRpt = null;
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		
		try
		{
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("SchedRptDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			schedRptList = new ArrayList();
			while (rs.next()) {
				schedRptList.add(buildSchedRpt(rs));
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return null;
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
		
		return schedRptList;
	}

	/**
	 * Private method to build SchedRpt object and return it to caller.
	 * 
	 * @param rs
	 * @return SchedRpt
	 * @throws SQLException
	 */
	private SchedRpt buildSchedRpt(ResultSet rs) throws SQLException {
		SchedRpt schedRpt = new SchedRpt();
		
		schedRpt.setPresnId(rs.getInt("PRESN_ID"));
		schedRpt.setRptTimeInd(rs.getString("RPT_TIME_IND"));
		schedRpt.setRptTime(rs.getInt("RPT_TIME"));
		schedRpt.setRollupInd(rs.getString("ROLLUP_IND"));
		schedRpt.setSchedRptNum(rs.getInt("SCHED_RPT_NUM"));
		schedRpt.setEffDt(rs.getDate("EFF_DT"));
		schedRpt.setExecNumDays(rs.getInt("EXEC_NUM_DAYS"));
		schedRpt.setRptType(rs.getString("RPT_TYPE"));
		schedRpt.setDivision(rs.getString("DIVISION"));
		return schedRpt;
	}

	/**
	 * Execute the insert or update statement on RABC_SCHED_RPT  table.
	 * 
	 * @param conn
	 * @param failures
	 * @param args
	 * @param baseSQL
	 */
	public void executeUpdate(Connection conn, List failures, List args, String baseSQL) {
		int rowsUpdated = 0;
		Statement stmt = null;
		String sqlStmt = null;
		
		try
		{
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("SchedRptDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rowsUpdated = stmt.executeUpdate(sqlStmt);
			logger.debug("SQL - Execution complete."+ String.valueOf(rowsUpdated) + "  rows updated");
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return;
		} finally {
			SQLHelper.closeStatement(stmt, failures, logger);
		}
	}
	
}
