package com.att.bac.rabc.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;

import com.att.carat.util.JDBCUtil;

public class EmcisEventLogger {

	public static Logger logger = Logger.getLogger(EmcisEventLogger.class);
	
	String INSERT_EVENT_LOG = ""
			+ "INSERT INTO emcis_event_log "
			+ "            (log_id, event_id, tstamp, data_date, HOST, host_ip ) "
			+ "     VALUES (?, ?, sysdate, ?, ?, ? ) ";
	
	String INSERT_EVENT_LOG_DETAIL = ""
			+ "INSERT INTO emcis_event_log_detail "
			+ "            (log_id, KEY, VALUE) "
			+ "     	   VALUES (?, ?, ?) ";

	String GET_EMCIS_SEQUENCE = ""
			+ "Select LOG_SEQ.nextval seq from dual ";

	public int getEMCISSequence(Connection connection) {
        PreparedStatement ps = null;
        ResultSet rs = null;
        int result = -1;
        try {
            ps = connection.prepareStatement(GET_EMCIS_SEQUENCE);
            rs = ps.executeQuery();
            if(rs.next()){
                result = rs.getInt("seq");
            }
        } catch(SQLException e){
        	logger.error("Error getting log_id from log_seq in getEMCISSequence: " , e);
        }finally {
        	JDBCUtil.closeResultSet(rs);
            JDBCUtil.closePreparedStatement(ps);    
        }
        return result;
    }
    
    public void insertEventLog(Connection connection,int sequence,String eventID,java.sql.Date runID,String host,String hostIP) {
        PreparedStatement ps = null;
        int count;
        try {
            ps = connection.prepareStatement(INSERT_EVENT_LOG);
            ps.setInt(1, sequence);
            ps.setString(2, eventID);
            ps.setDate(3, runID);
            ps.setString(4, host);
            ps.setString(5, hostIP);
            count = ps.executeUpdate();
            connection.commit();
        } catch (SQLException e) {
        	logger.error("Error inserting log id: " +sequence+ " with event id: " +eventID+ " into EMCIS log: " , e);
            JDBCUtil.rollback(connection);
        } finally {
            JDBCUtil.closePreparedStatement(ps);
        }
//        return count;
    }
    
    public void insertEventLogDetail(Connection connection,int sequence,String key,String value){
        PreparedStatement ps = null;
        int count;
        try {
            ps = connection.prepareStatement(INSERT_EVENT_LOG_DETAIL);
            ps.setInt(1, sequence);
            ps.setString(2, key);
            ps.setString(3, value);
            count = ps.executeUpdate();
            connection.commit();
        } catch (SQLException e) {
        	logger.error("Error inserting log id: " +sequence+ " with value: " +value+ " into EMCIS detail log: " , e);
            JDBCUtil.rollback(connection);
        } finally {
            JDBCUtil.closePreparedStatement(ps);
        }
//        return count;
    }

}