/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.admin;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;

/**
 * This is a DAO that performs SELECT, INSERT and UPDATE on RABC_PRESN_KEY1_HEADER table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class PresnKey1HeaderDAO {
	private static final Logger logger = Logger.getLogger(PresnKey1HeaderDAO.class);

	/**
	 * Returns the list of PresnKey1Header objects.
	 * 
	 * @param conn 
	 * @param failures
	 * @param args
	 * @param baseSQL
	 * @return List
	 */
	public List get(Connection conn, List failures, List args, String baseSQL) {
		List presnKey1HeaderList = null;
		PresnKey1Header presnKey1Header = null;
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		
		try
		{
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("PresnKey1HeaderDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			presnKey1HeaderList = new ArrayList();
			while (rs.next()) {
				presnKey1HeaderList.add(buildPresnKey1Header(rs));
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return null;
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
		
		return presnKey1HeaderList;
	}

	/**
	 * Private method to build PresnKey1Header object and return it to caller.
	 * 
	 * @param rs
	 * @return PresnKey1Header
	 * @throws SQLException
	 */
	private PresnKey1Header buildPresnKey1Header(ResultSet rs) throws SQLException {
		PresnKey1Header presnKey1Header = new PresnKey1Header();
		
		presnKey1Header.setPresnId(rs.getInt("PRESN_ID"));
		presnKey1Header.setWebid(rs.getString("WEBID"));
		presnKey1Header.setExecPresnSeqNum(rs.getInt("EXEC_PRESN_SEQ_NUM"));
		presnKey1Header.setKey1Value(rs.getString("KEY1_VALUE"));
		presnKey1Header.setMainKey1LineHeader(rs.getString("MAIN_KEY1_LINE_HEADER"));
		return presnKey1Header;
	}

	/**
	 * Execute the insert or update statement on RABC_PRESN_KEY1_HEADER table.
	 * 
	 * @param conn
	 * @param failures
	 * @param args
	 * @param baseSQL
	 */
	public void executeUpdate(Connection conn, List failures, List args, String baseSQL) {
		int rowsUpdated = 0;
		Statement stmt = null;
		String sqlStmt = null;
		
		try
		{
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("PresnKey1HeaderDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rowsUpdated = stmt.executeUpdate(sqlStmt);
			logger.debug("SQL - Execution complete."+ String.valueOf(rowsUpdated) + "  rows updated");
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return;
		} finally {
			SQLHelper.closeStatement(stmt, failures, logger);
		}
	}

}
