/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.admin.alert.rule;
import java.util.Date;

/**
 * This is a Data Object to represent RABC_ALERT_RULE table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class AlertRule {
	private String dbNodeId;
	private String alertRuleStatus;
	private Date effDate;
	private String stdType;
	private String alertExemptInd;
	private String userId;
	private Date timeStamp;
	private String alertRule;
	private int partiRefId;
	private int presnId;
	private String fileVerifInd;
	private String dataExtrctInd;
	private String dataCalcInd;
	private String calcRule;
	private String warningInd;
	private String avgInd;
	private String alertMsgInd;
	private String alertSeqNumInd;
	private String alertTimeInd;
	private String alertDashFreshInd;
	private String alertDesc;
	private int alertExecDate;
	private int alertKeyLvl;
	private String alertKey1Name;
	private String alertKey2Name;
	private String alertKey3Name;
	private String alertKey4Name;
	private String alertKey5Name;
	private int alertFileCt;
	private String asocFileId;
	private String alertRulePresnInd;
	private int divisionNameKeyLvl;
	private int alertDataKeep;
	private String alertRuleType;
	private int alertMnthExecDt ;
	private int alertMnthExecBillRnd;

	/**
	 * @return Returns the alertDataKeep.
	 */
	public int getAlertDataKeep() {
		return alertDataKeep;
	}
	/**
	 * @param alertDataKeep The alertDataKeep to set.
	 */
	public void setAlertDataKeep(int alertDataKeep) {
		this.alertDataKeep = alertDataKeep;
	}
	/**
	 * @return Returns the DbNodeId.
	 */
	public String getDbNodeId() {
		return dbNodeId;
	}
	/**
	 * @return Returns the AlertRuleStatus.
	 */
	public String getAlertRuleStatus() {
		return alertRuleStatus;
	}
	/**
	 * @return Returns the EffDate.
	 */
	public Date getEffDate() {
		return effDate;
	}
	/**
	 * @return Returns the StdType.
	 */
	public String getStdType() {
		return stdType;
	}
	/**
	 * @return Returns the AlertExemptInd.
	 */
	public String getAlertExemptInd() {
		return alertExemptInd;
	}
	/**
	 * @return Returns the UserId.
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @return Returns the TimeStamp.
	 */
	public Date getTimeStamp() {
		return timeStamp;
	}
	/**
	 * @return Returns the AlertRule.
	 */
	public String getAlertRule() {
		return alertRule;
	}
	/**
	 * @return Returns the PartiRefId.
	 */
	public int getPartiRefId() {
		return partiRefId;
	}
	/**
	 * @return Returns the PresnId.
	 */
	public int getPresnId() {
		return presnId;
	}
	/**
	 * @return Returns the FileVerifInd.
	 */
	public String getFileVerifInd() {
		return fileVerifInd;
	}
	/**
	 * @return Returns the DataExtrctInd.
	 */
	public String getDataExtrctInd() {
		return dataExtrctInd;
	}
	/**
	 * @return Returns the DataCalcInd.
	 */
	public String getDataCalcInd() {
		return dataCalcInd;
	}
	/**
	 * @return Returns the CalcRule.
	 */
	public String getCalcRule() {
		return calcRule;
	}
	/**
	 * @return Returns the WarningInd.
	 */
	public String getWarningInd() {
		return warningInd;
	}
	/**
	 * @return Returns the AvgInd.
	 */
	public String getAvgInd() {
		return avgInd;
	}
	/**
	 * @return Returns the AlertMsgInd.
	 */
	public String getAlertMsgInd() {
		return alertMsgInd;
	}
	/**
	 * @return Returns the AlertSeqNumInd.
	 */
	public String getAlertSeqNumInd() {
		return alertSeqNumInd;
	}
	/**
	 * @return Returns the AlertTimeInd.
	 */
	public String getAlertTimeInd() {
		return alertTimeInd;
	}
	/**
	 * @return Returns the AlertDashFreshInd.
	 */
	public String getAlertDashFreshInd() {
		return alertDashFreshInd;
	}
	/**
	 * @return Returns the AlertDesc.
	 */
	public String getAlertDesc() {
		return alertDesc;
	}
	/**
	 * @return Returns the AlertExecDate.
	 */
	public int getAlertExecDate() {
		return alertExecDate;
	}
	/**
	 * @return Returns the AlertKeyLvl.
	 */
	public int getAlertKeyLvl() {
		return alertKeyLvl;
	}
	/**
	 * @return Returns the AlertKey1Name.
	 */
	public String getAlertKey1Name() {
		return alertKey1Name;
	}
	/**
	 * @return Returns the AlertKey2Name.
	 */
	public String getAlertKey2Name() {
		return alertKey2Name;
	}
	/**
	 * @return Returns the AlertKey3Name.
	 */
	public String getAlertKey3Name() {
		return alertKey3Name;
	}
	/**
	 * @return Returns the AlertKey4Name.
	 */
	public String getAlertKey4Name() {
		return alertKey4Name;
	}
	/**
	 * @return Returns the AlertKey5Name.
	 */
	public String getAlertKey5Name() {
		return alertKey5Name;
	}
	/**
	 * @return Returns the AlertFileCt.
	 */
	public int getAlertFileCt() {
		return alertFileCt;
	}
	/**
	 * @return Returns the AsocFileId.
	 */
	public String getAsocFileId() {
		return asocFileId;
	}
	/**
	 * @return Returns the AlertRulePresnInd.
	 */
	public String getAlertRulePresnInd() {
		return alertRulePresnInd;
	}
	/**
	 * @return Returns the DivisionNameKeyLvl.
	 */
	public int getDivisionNameKeyLvl() {
		return divisionNameKeyLvl;
	}

	/**
	 * @param DbNodeId The dbNodeId to set.
	 */
	public void setDbNodeId(String dbNodeId) {
		this.dbNodeId = dbNodeId;
	}
	/**
	 * @param AlertRuleStatus The alertRuleStatus to set.
	 */
	public void setAlertRuleStatus(String alertRuleStatus) {
		this.alertRuleStatus = alertRuleStatus;
	}
	/**
	 * @param EffDate The effDate to set.
	 */
	public void setEffDate(Date effDate) {
		this.effDate = effDate;
	}
	/**
	 * @param StdType The stdType to set.
	 */
	public void setStdType(String stdType) {
		this.stdType = stdType;
	}
	/**
	 * @param AlertExemptInd The alertExemptInd to set.
	 */
	public void setAlertExemptInd(String alertExemptInd) {
		this.alertExemptInd = alertExemptInd;
	}
	/**
	 * @param UserId The userId to set.
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	/**
	 * @param TimeStamp The timeStamp to set.
	 */
	public void setTimeStamp(Date timeStamp) {
		this.timeStamp = timeStamp;
	}
	/**
	 * @param AlertRule The alertRule to set.
	 */
	public void setAlertRule(String alertRule) {
		this.alertRule = alertRule;
	}
	/**
	 * @param PartiRefId The partiRefId to set.
	 */
	public void setPartiRefId(int partiRefId) {
		this.partiRefId = partiRefId;
	}
	/**
	 * @param PresnId The presnId to set.
	 */
	public void setPresnId(int presnId) {
		this.presnId = presnId;
	}
	/**
	 * @param FileVerifInd The fileVerifInd to set.
	 */
	public void setFileVerifInd(String fileVerifInd) {
		this.fileVerifInd = fileVerifInd;
	}
	/**
	 * @param DataExtrctInd The dataExtrctInd to set.
	 */
	public void setDataExtrctInd(String dataExtrctInd) {
		this.dataExtrctInd = dataExtrctInd;
	}
	/**
	 * @param DataCalcInd The dataCalcInd to set.
	 */
	public void setDataCalcInd(String dataCalcInd) {
		this.dataCalcInd = dataCalcInd;
	}
	/**
	 * @param CalcRule The calcRule to set.
	 */
	public void setCalcRule(String calcRule) {
		this.calcRule = calcRule;
	}
	/**
	 * @param WarningInd The warningInd to set.
	 */
	public void setWarningInd(String warningInd) {
		this.warningInd = warningInd;
	}
	/**
	 * @param AvgInd The avgInd to set.
	 */
	public void setAvgInd(String avgInd) {
		this.avgInd = avgInd;
	}
	/**
	 * @param AlertMsgInd The alertMsgInd to set.
	 */
	public void setAlertMsgInd(String alertMsgInd) {
		this.alertMsgInd = alertMsgInd;
	}
	/**
	 * @param AlertSeqNumInd The alertSeqNumInd to set.
	 */
	public void setAlertSeqNumInd(String alertSeqNumInd) {
		this.alertSeqNumInd = alertSeqNumInd;
	}
	/**
	 * @param AlertTimeInd The alertTimeInd to set.
	 */
	public void setAlertTimeInd(String alertTimeInd) {
		this.alertTimeInd = alertTimeInd;
	}
	/**
	 * @param AlertDashFreshInd The alertDashFreshInd to set.
	 */
	public void setAlertDashFreshInd(String alertDashFreshInd) {
		this.alertDashFreshInd = alertDashFreshInd;
	}
	/**
	 * @param AlertDesc The alertDesc to set.
	 */
	public void setAlertDesc(String alertDesc) {
		this.alertDesc = alertDesc;
	}
	/**
	 * @param AlertExecDate The alertExecDate to set.
	 */
	public void setAlertExecDate(int alertExecDate) {
		this.alertExecDate = alertExecDate;
	}
	/**
	 * @param AlertKeyLvl The alertKeyLvl to set.
	 */
	public void setAlertKeyLvl(int alertKeyLvl) {
		this.alertKeyLvl = alertKeyLvl;
	}
	/**
	 * @param AlertKey1Name The alertKey1Name to set.
	 */
	public void setAlertKey1Name(String alertKey1Name) {
		this.alertKey1Name = alertKey1Name;
	}
	/**
	 * @param AlertKey2Name The alertKey2Name to set.
	 */
	public void setAlertKey2Name(String alertKey2Name) {
		this.alertKey2Name = alertKey2Name;
	}
	/**
	 * @param AlertKey3Name The alertKey3Name to set.
	 */
	public void setAlertKey3Name(String alertKey3Name) {
		this.alertKey3Name = alertKey3Name;
	}
	/**
	 * @param AlertKey4Name The alertKey4Name to set.
	 */
	public void setAlertKey4Name(String alertKey4Name) {
		this.alertKey4Name = alertKey4Name;
	}
	/**
	 * @param AlertKey5Name The alertKey5Name to set.
	 */
	public void setAlertKey5Name(String alertKey5Name) {
		this.alertKey5Name = alertKey5Name;
	}
	/**
	 * @param AlertFileCt The alertFileCt to set.
	 */
	public void setAlertFileCt(int alertFileCt) {
		this.alertFileCt = alertFileCt;
	}
	/**
	 * @param AsocFileId The asocFileId to set.
	 */
	public void setAsocFileId(String asocFileId) {
		this.asocFileId = asocFileId;
	}
	/**
	 * @param AlertRulePresnInd The alertRulePresnInd to set.
	 */
	public void setAlertRulePresnInd(String alertRulePresnInd) {
		this.alertRulePresnInd = alertRulePresnInd;
	}
	/**
	 * @param DivisionNameKeyLvl The divisionNameKeyLvl to set.
	 */
	public void setDivisionNameKeyLvl(int divisionNameKeyLvl) {
		this.divisionNameKeyLvl = divisionNameKeyLvl;
	}
	/**
	 * @return Returns the alertRuleType.
	 */
	public String getAlertRuleType() {
		return alertRuleType;
	}
	/**
	 * @param alertRuleType The alertRuleType to set.
	 */
	public void setAlertRuleType(String alertRuleType) {
		this.alertRuleType = alertRuleType;
	}
		
	/**
	 * @return Returns the alertMnthExecBillRnd.
	 */
	public int getAlertMnthExecBillRnd() {
		return alertMnthExecBillRnd;
	}
	/**
	 * @param alertMnthExecBillRnd The alertMnthExecBillRnd to set.
	 */
	public void setAlertMnthExecBillRnd(int alertMnthExecBillRnd) {
		this.alertMnthExecBillRnd = alertMnthExecBillRnd;
	}
	/**
	 * @return Returns the alertMnthExecDt.
	 */
	public int getAlertMnthExecDt() {
		return alertMnthExecDt;
	}
	/**
	 * @param alertMnthExecDt The alertMnthExecDt to set.
	 */
	public void setAlertMnthExecDt(int alertMnthExecDt) {
		this.alertMnthExecDt = alertMnthExecDt;
	}
}
