/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.alerts.status;

import java.sql.Connection;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.att.bac.rabc.DateUtil;
import com.att.bac.rabc.ExtrctTblDef;
import com.att.bac.rabc.ExtrctTblDefDAO;
import com.att.bac.rabc.MyDate;
import com.att.bac.rabc.StaticDataLoader;
import com.att.bac.rabc.admin.alert.rule.AlertRule;
import com.att.bac.rabc.admin.alert.rule.AlertRuleDAO;
import com.att.bac.rabc.admin.alert.rule.TrackFileDtl;
import com.att.bac.rabc.admin.alert.rule.TrackFileDtlDAO;

/**
 * This is a service class to provide the business logic. The methods in this class are called by the
 * action class. They do the required manipulation and returns the result to the action class. 
 * This paricular service class serves the business logic to generate graph.
 * 
 * @author Shailesh Hemdev - SH8512
 */
public class GraphService {
	private static final String RABC_EXTRCT_SUMY_DATA = "RABC_EXTRCT_SUMY_DATA";
	private static final String RABC_CALC_ALERT_DATA = "RABC_CALC_ALERT_DATA";
	private static final String RABC_ALERT_HIST = "RABC_ALERT_HIST";
	
	private static final Logger logger = Logger.getLogger(GraphService.class);
	private static GraphService graphService;
	private GraphSQLService graphSQLService;
	
	/**
	 * Synchronized method to return the instance of GraphService object.
	 * It checks the existance of the instance of GraphService and if it does not exists
	 * then creates one instance of GraphService and returns otherwise it returns the
	 * existing instance of GraphService.
	 * 
	 * @return GraphService
	 */
	public static synchronized GraphService getGraphService(){
		if (graphService == null){
			graphService = new GraphService();
		}	
		return graphService;
	}
	
	/**
	 * @return Returns the graphSQLService.
	 */
	public GraphSQLService getGraphSQLService() {
		return graphSQLService;
	}
	
	/**
	 * @param graphSQLService The graphSQLService to set.
	 */
	public void setGraphSQLService(GraphSQLService graphSQLService) {
		this.graphSQLService = graphSQLService;
	}
	
	/**
	 * Method will accept the GraphParameters object, 
	 * make changes to some of its attributes and then return the reference to the instance.
	 * 
	 * @param graphParameters
	 * @return GraphParameters
	 */
	protected GraphParameters buildGraphParameters(GraphParameters graphParameters){
		return graphParameters;
	}
	
	/**
	 * Method to check whether a value passed is a date or not.
	 * 
	 * @param parameterValue
	 * @return boolean
	 */
	protected boolean isDate(String parameterValue){
		SimpleDateFormat tmpDateFormat = new SimpleDateFormat("MM/dd/yyyy");
		int lenParameterValueComplete;
		String effectiveParameterValue;
		
		if (parameterValue.indexOf("=")!=-1){
			lenParameterValueComplete = parameterValue.trim().length();
			effectiveParameterValue = parameterValue.substring((parameterValue.indexOf("=")+1),lenParameterValueComplete);
			parameterValue = effectiveParameterValue;
		}
		
		if (parameterValue.indexOf("'")!=-1){
			lenParameterValueComplete = parameterValue.trim().length();
			effectiveParameterValue = parameterValue.substring((parameterValue.indexOf("'")+1),lenParameterValueComplete-1);
			parameterValue = effectiveParameterValue;
		}
		
		parameterValue = parameterValue.replace('-', '/');
		
		Date d2=null;
		try {
			d2 = tmpDateFormat.parse(parameterValue);
		}catch (ParseException pe){
			return false;
		}
		
		if (d2 == null) {
			return false;
		}else {
			return true;
		}
	}
	
	/**
	 * Method to return the list of key1 values list.
	 * It also sets the division name key level to the object of GraphParameters.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param graphParameters
	 * @return List
	 */
	protected List getKey1ValuesList(Connection connection, List failureList, List args, GraphParameters graphParameters){
		List key1ValuesList = new ArrayList();
		GraphSQLService graphSQLService = new GraphSQLService(graphParameters);
		this.setGraphSQLService(graphSQLService);
		int divisioNameKeyLvl = this.getGraphSQLService().getDivisioNameKeyLvl(connection, failureList,graphParameters);
		String region = (String) args.get(0);
		if (divisioNameKeyLvl>0){
			graphParameters.setDivisioNameKeyLvl(divisioNameKeyLvl);
			
			key1ValuesList = StaticDataLoader.getDivisionsByRegion(region);
		}
		
		return key1ValuesList;
	}
	
	/**
	 * A method which will return key value after checking whether its a date, etc.
	 * @param parameterValue
	 * @return String
	 */
	protected String getKeyValue(String parameterValue){
		String newKeyValue = "";
		int lenParameterValueComplete;
		String effectiveParameterValue;
		boolean keyColFlag = false;
		String keyCol = "";
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat dateFormat1 = new SimpleDateFormat("MM/dd/yyyy");
		Date tempDate = null;
		
		if (parameterValue.indexOf("to_date")==-1){
			if (parameterValue.indexOf("=")!=-1){
				lenParameterValueComplete = parameterValue.trim().length();
				keyCol = parameterValue.substring(0,parameterValue.indexOf("="));
				effectiveParameterValue = parameterValue.substring((parameterValue.indexOf("=")+1),lenParameterValueComplete );
				parameterValue = effectiveParameterValue;
				keyColFlag = true;
			}
			
			if (parameterValue.indexOf("'")!=-1){
				lenParameterValueComplete = parameterValue.trim().length();
				effectiveParameterValue = parameterValue.substring((parameterValue.indexOf("'")+1),lenParameterValueComplete-1);
				parameterValue = effectiveParameterValue;
			}
			
			if (parameterValue.indexOf(" ") != -1) {
				try {
					tempDate = dateFormat.parse(parameterValue);
				} catch (ParseException e) {
					logger.error("GraphService.getKeyValue() - Error in parsing the date: " + e.getMessage(), e);
				}
				if (tempDate != null) {
					parameterValue = dateFormat1.format(tempDate);
				}
			}
			
			if (parameterValue.indexOf("mm/dd/yyyy")!=-1){
				newKeyValue = keyCol + " = to_date('" + parameterValue + "')";
			}else {
				if (keyColFlag == true){
					newKeyValue = keyCol + " = to_date('" + parameterValue + "','mm/dd/yyyy')";
				}else {
					newKeyValue = "to_date('" + parameterValue + "','mm/dd/yyyy')";
				}
			}
		} else {
			newKeyValue = parameterValue;
		}

		/*
		 * BAND AID FOR THE ERROR OBSERVED
		 */
		if (newKeyValue.lastIndexOf(")")!=-1) {
			if (newKeyValue.charAt(newKeyValue.lastIndexOf(")")-1)=='\'' && newKeyValue.charAt(newKeyValue.lastIndexOf(")")-2)=='\''){
				newKeyValue = newKeyValue.substring(0,newKeyValue.lastIndexOf(")")-1) + ")";
			}
		}

		return newKeyValue;
	}
	
	/**
	 * Method to return the alert time value.
	 * 
	 * @param graphParameters
	 * @return String
	 */
	protected String getAlertTimeValue(GraphParameters graphParameters){
		int dayOfWeek ;
		if (graphParameters.getAlertTimeInd()!=null){
			if ( (graphParameters.getPartiRefId()!=-1) && ("D".equals(graphParameters.getAlertTimeInd())) && (graphParameters.getAlertTimeValue()==null) ){
				if (graphParameters.getProcDate()!=null){
					dayOfWeek = DateUtil.getDayOfWeek(graphParameters.getProcDate());
					
					switch (dayOfWeek){
						case 1:
							return "Monday";
						case 2:
							return "Tuesday";
						case 3:
							return "Wednesday";
						case 4:
							return "Thursday";
						case 5:
							return "Friday";
						case 6:
							return "Saturday";
						case 7:
							return "Saturday";
						default:
							return "Sunday";
					}
				}else {
					return graphParameters.getAlertTimeValue();
				}
			}else {
				return graphParameters.getAlertTimeValue();
			}
		}else {
			return graphParameters.getAlertTimeValue();
		}	
	}
	
	/**
	 * Method to return the start date.
	 * 
	 * @param graphParameters
	 * @return MyDate
	 */
	protected MyDate getStartDate(GraphParameters graphParameters){
		MyDate startDate = null;

		if (graphParameters.getProcDate()!=null){
			if (graphParameters.getDaySpan()!=-1){
				startDate = new MyDate(graphParameters.getProcDate());
				startDate.doAdd(-(graphParameters.getDaySpan()));
			}else {
				String procDateString = graphParameters.getProcDate().toString();
				String procDateDay = procDateString.substring(3,5);
                String procDateMonth = procDateString.substring(0,2);
                String procDateYear = procDateString.substring(6,procDateString.length());
                Date tempDate = DateUtil.getDate(Integer.parseInt(procDateYear),Integer.parseInt(procDateMonth)-1,Integer.parseInt(procDateDay));
                int month = DateUtil.getMonthOfYear(tempDate);
                Date newStartDate;
                
				if ( (graphParameters.getAlertTimeInd()!=null && "D".equals(graphParameters.getAlertTimeInd().trim()))|| (graphParameters.getAlertTimeInd()!=null && "AW".equals(graphParameters.getAlertTimeInd().trim()))){
					//startDate.doAdd(-3);
					/*
					 * Code modified after discussion with respect to SFR. E-mail dated Sat,04/01 with following subject:
					 * "RE: RABC : [Graphs] SFR queries (Graph mainly)"
					 * 
					 * Old code modified after discussion with Kin on 18th May 2006
					 * REF: E-mail with subject "FW:  default date on the graph"
					 * startDate.doAdd(-180);
					*/ 
					 if (month<3){
                    	newStartDate = DateUtil.getDate(Integer.parseInt(procDateYear)-1,11 - (2-month),Integer.parseInt(procDateDay));
                    }else {
                    	newStartDate = DateUtil.getDate(Integer.parseInt(procDateYear),month - 3,Integer.parseInt(procDateDay));
                    }
                    
                    newStartDate = DateUtil.getFirstDayOfMonth(newStartDate);
                    startDate = new MyDate(newStartDate);
				} else if (graphParameters.getAlertTimeInd()!=null && "B".equals(graphParameters.getAlertTimeInd().trim())){
					/*
					 * Addition of condition for timeInd = "B" indicating bill cycle. E-mail dated Sat,04/01 with following subject:
					 * "RE: RABC : [Graphs] SFR queries (Graph mainly)"
					 * 
					 * Further modifications after discussion with Kin on 18th May 2006
					 * REF: E-mail with subject "FW:  default date on the graph"
					 */
                    if (month<1){
                    	newStartDate = DateUtil.getDate(Integer.parseInt(procDateYear)-2,11,Integer.parseInt(procDateDay));
                    }else {
                    	newStartDate = DateUtil.getDate(Integer.parseInt(procDateYear)-1,month - 1,Integer.parseInt(procDateDay));
                    }
                    
                    newStartDate = DateUtil.getFirstDayOfMonth(newStartDate);
                    startDate = new MyDate(newStartDate); 
				} else if ((graphParameters.getAlertTimeInd()!=null && "M".equals(graphParameters.getAlertTimeInd().trim())) || (graphParameters.getAlertTimeInd()!=null && "AB".equals(graphParameters.getAlertTimeInd().trim()))) {
					if (month<1){
                    	newStartDate = DateUtil.getDate(Integer.parseInt(procDateYear)-2,11,Integer.parseInt(procDateDay));
                    }else {
                    	newStartDate = DateUtil.getDate(Integer.parseInt(procDateYear)-1,month - 1,Integer.parseInt(procDateDay));
                    }
                    
                    newStartDate = DateUtil.getFirstDayOfMonth(newStartDate);
                    startDate = new MyDate(newStartDate); 
				} else {
					/*
					 * Will take care of Timing equal to Record
					 * 
					 * Old code modified after discussion with Kin on 18th May 2006
					 * REF: E-mail with subject "FW:  default date on the graph"
					 * startDate.doAdd(-180);
					*/ 
					 if (month<3){
                    	newStartDate = DateUtil.getDate(Integer.parseInt(procDateYear)-1,11 - (2-month),Integer.parseInt(procDateDay));
                    }else {
                    	newStartDate = DateUtil.getDate(Integer.parseInt(procDateYear),month - 3,Integer.parseInt(procDateDay));
                    }
                    
                    newStartDate = DateUtil.getFirstDayOfMonth(newStartDate);
                    startDate = new MyDate(newStartDate);
				}
			}
		}
		
		return startDate;
	}
	
	/**
	 * Method to return the title of the graph. Here it returns the null value.
	 * This method would be overridden in individual classes.
	 * 
	 * @param graphParameters
	 * @return String
	 */
	protected String getTitle(GraphParameters graphParameters){return null;}
	
	/**
	 * Method to return the selection criterias of the graph. Here it returns the null value.
	 * This method would be overridden in individual classes.
	 * 
	 * @param graphParameters
	 * @return String
	 */
	protected String getSelectionCriteria(GraphParameters graphParameters){return null;}
	
	/**
	 * Method to set the values of buttons to be displayed on the graph page.
	 * 
	 * @param graphParameters
	 */
	protected void setGraphButton(GraphParameters graphParameters){
		if (graphParameters.getAlertTimeInd()!=null){
			if ("D".equals(graphParameters.getAlertTimeInd()) && ((graphParameters.getAlertrule()!=null || graphParameters.getPartiRefId()!=-1) || (graphParameters.getAlertrule()==null && graphParameters.getPartiRefId()==-1 && graphParameters.getAlertTimeValue()!=null))){
				graphParameters.setGraphBtn("AW");
			}else if ("AW".equals(graphParameters.getAlertTimeInd())){
				graphParameters.setGraphBtn("D");
			}else if ("B".equals(graphParameters.getAlertTimeInd())){
				graphParameters.setGraphBtn("AB");
			}else if ("AB".equals(graphParameters.getAlertTimeInd())){
				graphParameters.setGraphBtn("B");
			}
		}
	}
	
	/**
	 * Method to set the alertRuleFlag based on the values in the record count, left and right count.
	 * 
	 * @param graphParameters
	 * @param recordCount
	 * @param leftCount
	 * @param rightCount
	 * @return GraphParameters
	 */
	protected GraphParameters getAlertRuleFlag(GraphParameters graphParameters, int recordCount, int leftCount, int rightCount){
		String alertRuleFlag = "N";
		if (recordCount==0 || (leftCount==0 && rightCount==0)){
			graphParameters.setAlertRuleFlag("N");
		}else {
			graphParameters.setAlertRuleFlag("Y");
		}
		
		return graphParameters;
	}
	
	/**
	 * Method to return the alert rule object for the graph to be displayed.
	 * It calls the SQL service class to get the details of alert rule.
	 * 
	 * @param connection
	 * @param failures
	 * @param args
	 * @return AlertRule
	 */
	protected AlertRule chkAlertRule(Connection connection, List failures,List args) {
		AlertRule alertRule = null;
		
		alertRule = this.getGraphSQLService().getAlertRule(connection, failures,args);
		
		return alertRule ;
	}
	
	/**
	 * Method to return the list of key names.
	 * 
	 * @param connection
	 * @param failureList
	 * @param graphParameters
	 * @return List
	 */
	protected List getKeyNames(Connection connection, List failureList, GraphParameters graphParameters){
		List keyNameList = new ArrayList();
		List args = new ArrayList();
		
		/*
		 * Check whether alert rule is null in which case get the alert rule from 
		 */
		if (graphParameters.getAlertRule()==null){
			if (graphParameters.getPresnId()!=-1){
				List args1 = new ArrayList();
				args1.add(Integer.toString(graphParameters.getPresnId()));
				
				AlertRuleDAO alertRuleDAO = new AlertRuleDAO();
				List alertRuleList = alertRuleDAO.get(connection,failureList,args1,GraphSQLService.alertRuleQuery);
				
				if (alertRuleList!=null){
					if (!alertRuleList.isEmpty()){
						AlertRule alertRule = (AlertRule)alertRuleList.get(0);
						graphParameters.setAlertRule(alertRule);
					}
				}
			}
		}
		
		if (graphParameters.getAlertRule()!=null){
			if (graphParameters.getAlertRule().getAlertRuleType().equals("TRACK")) {
				args.add(graphParameters.getAlertRule().getAlertRule());
				
				TrackFileDtlDAO trackFileDtlDAO = new TrackFileDtlDAO();
				List trackFileDtlList = trackFileDtlDAO.get(connection,failureList,args,GraphSQLService.trackFileDtlQuery);
				
				if (trackFileDtlList!=null){
					if (!trackFileDtlList.isEmpty()){
						TrackFileDtl trackFileDtl = (TrackFileDtl)trackFileDtlList.get(0);
						keyNameList.add(trackFileDtl.getAlertItemKey1Name());
						keyNameList.add(trackFileDtl.getAlertItemKey2Name());
						keyNameList.add(trackFileDtl.getAlertItemKey3Name());
						keyNameList.add(trackFileDtl.getAlertItemKey4Name());
						keyNameList.add(trackFileDtl.getAlertItemKey5Name());
					}
				}
			}else {
				if (graphParameters.getExtrctTblDef()==null){
					ExtrctTblDefDAO extrctTblDefDAO = new ExtrctTblDefDAO();
					List args2 = new ArrayList();
					args2.add(Integer.toString(graphParameters.getAlertRule().getPartiRefId()));
					List extrctTblDefList = extrctTblDefDAO.get(connection,failureList, args2,GraphSQLService.qryExtrDataTrend);
					if (extrctTblDefList!=null){
						if (!extrctTblDefList.isEmpty()){
							graphParameters.setExtrctTblDef((ExtrctTblDef)extrctTblDefList.get(0));
						}
					}
				}
				
				if (graphParameters.getExtrctTblDef()!=null){
					keyNameList.add(graphParameters.getExtrctTblDef().getKey1Name());
					keyNameList.add(graphParameters.getExtrctTblDef().getKey2Name());
					keyNameList.add(graphParameters.getExtrctTblDef().getKey3Name());
					keyNameList.add(graphParameters.getExtrctTblDef().getKey4Name());
					keyNameList.add(graphParameters.getExtrctTblDef().getKey5Name());
				}
			}
		}
		
		if (keyNameList.isEmpty()){
			keyNameList.add("");
			keyNameList.add("");
			keyNameList.add("");
			keyNameList.add("");
			keyNameList.add("");
		}
		
		return keyNameList;
	}
}
