/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.admin.alert.rule;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.ArrayList;
import java.text.MessageFormat;

import org.apache.log4j.Logger;

import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.RABCException;

/**
 * This is a DAO that performs SELECT, INSERT and UPDATE on RABC_TRACK_FILE_DTL table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class TrackFileDtlDAO {
	private static final Logger logger = Logger.getLogger(TrackFileDtlDAO.class);

	/**
	 * Returns the list of TrackFileDtl objects.
	 * 
	 * @param conn 
	 * @param failures
	 * @param args
	 * @param baseSQL
	 * @return List
	 */
	public List get(Connection conn, List failures, List args, String baseSQL) {
		List trackFileDtlList = null;
		TrackFileDtl trackFileDtl = null;
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		
		try
		{
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("TrackFileDtlDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			trackFileDtlList = new ArrayList();
			while (rs.next()) {
				trackFileDtlList.add(buildTrackFileDtl(rs));
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return null;
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
		
		return trackFileDtlList;
	}

	/**
	 * Private method to build TrackFileDtl object and return it to caller.
	 * 
	 * @param rs
	 * @return TrackFileDtl
	 * @throws SQLException
	 */
	private TrackFileDtl buildTrackFileDtl(ResultSet rs) throws SQLException {
		TrackFileDtl trackFileDtl = new TrackFileDtl();
		
		trackFileDtl.setAlertItem7DdlName(rs.getString("ALERT_ITEM7_DDL_NAME"));
		trackFileDtl.setAlertItem7SumInd(rs.getInt("ALERT_ITEM7_SUM_IND"));
		trackFileDtl.setAlertItem8DdlName(rs.getString("ALERT_ITEM8_DDL_NAME"));
		trackFileDtl.setAlertItem8SumInd(rs.getInt("ALERT_ITEM8_SUM_IND"));
		trackFileDtl.setAlertItem9DdlName(rs.getString("ALERT_ITEM9_DDL_NAME"));
		trackFileDtl.setAlertItem9SumInd(rs.getInt("ALERT_ITEM9_SUM_IND"));
		trackFileDtl.setAlertItem10DdlName(rs.getString("ALERT_ITEM10_DDL_NAME"));
		trackFileDtl.setAlertItem10SumInd(rs.getInt("ALERT_ITEM10_SUM_IND"));
		trackFileDtl.setAlertItem11DdlName(rs.getString("ALERT_ITEM11_DDL_NAME"));
		trackFileDtl.setAlertItem11SumInd(rs.getInt("ALERT_ITEM11_SUM_IND"));
		trackFileDtl.setAlertItem12DdlName(rs.getString("ALERT_ITEM12_DDL_NAME"));
		trackFileDtl.setAlertItem12SumInd(rs.getInt("ALERT_ITEM12_SUM_IND"));
		trackFileDtl.setAlertItem13DdlName(rs.getString("ALERT_ITEM13_DDL_NAME"));
		trackFileDtl.setAlertItem13SumInd(rs.getInt("ALERT_ITEM13_SUM_IND"));
		trackFileDtl.setAlertItem14DdlName(rs.getString("ALERT_ITEM14_DDL_NAME"));
		trackFileDtl.setAlertItem14SumInd(rs.getInt("ALERT_ITEM14_SUM_IND"));
		trackFileDtl.setAlertItem15DdlName(rs.getString("ALERT_ITEM15_DDL_NAME"));
		trackFileDtl.setAlertItem15SumInd(rs.getInt("ALERT_ITEM15_SUM_IND"));
		trackFileDtl.setViewName(rs.getString("VIEW_NAME"));
		trackFileDtl.setAlertItemOrd(rs.getInt("ALERT_ITEM_ORD"));
		trackFileDtl.setAlertRule(rs.getString("ALERT_RULE"));
		trackFileDtl.setFileId(rs.getString("FILE_ID"));
		trackFileDtl.setAlertItemName(rs.getString("ALERT_ITEM_NAME"));
		trackFileDtl.setAlertItemInd(rs.getString("ALERT_ITEM_IND"));
		trackFileDtl.setAlertDateInd(rs.getString("ALERT_DATE_IND"));
		trackFileDtl.setAlertItemExtrctTbl(rs.getString("ALERT_ITEM_EXTRCT_TBL"));
		trackFileDtl.setPartiRefId(rs.getInt("PARTI_REF_ID"));
		trackFileDtl.setAlertItemKeyLvl(rs.getInt("ALERT_ITEM_KEY_LVL"));
		trackFileDtl.setAlertItemKey1Name(rs.getString("ALERT_ITEM_KEY1_NAME"));
		trackFileDtl.setAlertItemKey2Name(rs.getString("ALERT_ITEM_KEY2_NAME"));
		trackFileDtl.setAlertItemKey3Name(rs.getString("ALERT_ITEM_KEY3_NAME"));
		trackFileDtl.setAlertItemKey4Name(rs.getString("ALERT_ITEM_KEY4_NAME"));
		trackFileDtl.setAlertItemKey5Name(rs.getString("ALERT_ITEM_KEY5_NAME"));
		trackFileDtl.setAlertItemDataCt(rs.getInt("ALERT_ITEM_DATA_CT"));
		trackFileDtl.setAlertItem1DdlName(rs.getString("ALERT_ITEM1_DDL_NAME"));
		trackFileDtl.setAlertItem1SumInd(rs.getInt("ALERT_ITEM1_SUM_IND"));
		trackFileDtl.setAlertItem2DdlName(rs.getString("ALERT_ITEM2_DDL_NAME"));
		trackFileDtl.setAlertItem2SumInd(rs.getInt("ALERT_ITEM2_SUM_IND"));
		trackFileDtl.setAlertItem3DdlName(rs.getString("ALERT_ITEM3_DDL_NAME"));
		trackFileDtl.setAlertItem3SumInd(rs.getInt("ALERT_ITEM3_SUM_IND"));
		trackFileDtl.setAlertItem4DdlName(rs.getString("ALERT_ITEM4_DDL_NAME"));
		trackFileDtl.setAlertItem4SumInd(rs.getInt("ALERT_ITEM4_SUM_IND"));
		trackFileDtl.setAlertItem5DdlName(rs.getString("ALERT_ITEM5_DDL_NAME"));
		trackFileDtl.setAlertItem5SumInd(rs.getInt("ALERT_ITEM5_SUM_IND"));
		trackFileDtl.setAlertItem6DdlName(rs.getString("ALERT_ITEM6_DDL_NAME"));
		trackFileDtl.setAlertItem6SumInd(rs.getInt("ALERT_ITEM6_SUM_IND"));
		/*
		 * Impact of new columns added for ALERT_ITEM*_DDL_NAME_IND - calls to respective setter methods to complete the object
		 */
		trackFileDtl.setAlertItem1DdlNameInd(rs.getString("ALERT_ITEM1_DDL_NAME_IND"));
		trackFileDtl.setAlertItem2DdlNameInd(rs.getString("ALERT_ITEM2_DDL_NAME_IND"));
		trackFileDtl.setAlertItem3DdlNameInd(rs.getString("ALERT_ITEM3_DDL_NAME_IND"));
		trackFileDtl.setAlertItem4DdlNameInd(rs.getString("ALERT_ITEM4_DDL_NAME_IND"));
		trackFileDtl.setAlertItem5DdlNameInd(rs.getString("ALERT_ITEM5_DDL_NAME_IND"));
		trackFileDtl.setAlertItem6DdlNameInd(rs.getString("ALERT_ITEM6_DDL_NAME_IND"));
		trackFileDtl.setAlertItem7DdlNameInd(rs.getString("ALERT_ITEM7_DDL_NAME_IND"));
		trackFileDtl.setAlertItem8DdlNameInd(rs.getString("ALERT_ITEM8_DDL_NAME_IND"));
		trackFileDtl.setAlertItem9DdlNameInd(rs.getString("ALERT_ITEM9_DDL_NAME_IND"));
		trackFileDtl.setAlertItem10DdlNameInd(rs.getString("ALERT_ITEM10_DDL_NAME_IND"));
		trackFileDtl.setAlertItem11DdlNameInd(rs.getString("ALERT_ITEM11_DDL_NAME_IND"));
		trackFileDtl.setAlertItem12DdlNameInd(rs.getString("ALERT_ITEM12_DDL_NAME_IND"));
		trackFileDtl.setAlertItem13DdlNameInd(rs.getString("ALERT_ITEM13_DDL_NAME_IND"));
		trackFileDtl.setAlertItem14DdlNameInd(rs.getString("ALERT_ITEM14_DDL_NAME_IND"));
		trackFileDtl.setAlertItem15DdlNameInd(rs.getString("ALERT_ITEM15_DDL_NAME_IND"));		
		return trackFileDtl;
	}

	/**
	 * Execute the insert or update statement on RABC_TRACK_FILE_DTL table.
	 * 
	 * @param conn
	 * @param failures
	 * @param args
	 * @param baseSQL
	 */
	public void executeUpdate(Connection conn, List failures, List args, String baseSQL) {
		int rowsUpdated = 0;
		Statement stmt = null;
		String sqlStmt = null;
		
		try
		{
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("TrackFileDtlDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rowsUpdated = stmt.executeUpdate(sqlStmt);
			logger.debug("SQL - Execution complete."+ String.valueOf(rowsUpdated) + "  rows updated");
			
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return;
		} finally {
			SQLHelper.closeStatement(stmt, failures, logger);
		}
	}

}
