/*
 * Module description: 
 * This is a singleton class that provides database connections. 
 * It reads the DBCP configuration info from tomcat configuration.
 *
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 *
 * Modification History:                                     
 * SBCUID		Date			Description                         	    	
 * ------		--------		-----------
 * PD2951		20051216		Initial version for EAP 556010
 * JS3175		20060830		Code for 3 different regions for EAP 556013
 * SH8512		20070213		Code for Enterprise region
 */

package com.att.bac.rabc;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

public class ConnectionManager {
	private static final Logger logger = Logger.getLogger(ConnectionManager.class);
	
	private static ConnectionManager ref = new ConnectionManager();
	
	private DataSource ds_w = null;
	private DataSource ds_e = null;
	private DataSource ds_sw = null;
	private DataSource ds_mw = null;
	private DataSource ds_c2 = null;
	private DataSource ds_se = null;
	private DataSource ds_se_moss = null;
	private DataSource ds_ent = null;
	private DataSource ds_mb = null;
	
	private ConnectionManager(){}

	/**
	 * @return Returns the ref.
	 */
	public static ConnectionManager getRef() {
		return ref;
	}
	
    private synchronized DataSource getDataSource(String region) throws NamingException, SQLException {
        if(region.trim().equals("WE")){
            return getDataSource(ds_w,region);
        } else if(region.trim().equals("E")){
            return getDataSource(ds_e,region);
        } else if(region.trim().equals("MW")){
            return getDataSource(ds_mw,region);
        } else if(region.trim().equals("SW")){
            return getDataSource(ds_sw,region);
        } else if(region.trim().equals("C2")){
            return getDataSource(ds_c2,region);
        } else if(region.trim().equals("SE")){
            return getDataSource(ds_se,region);    
        } else if(region.trim().equals("EN")){
            return getDataSource(ds_ent,region); 
        } else if(region.trim().equals("MB")){
            return getDataSource(ds_mb,region);
        } else {
            throw new IllegalArgumentException("Unrecognized region: "+region);
        }
    }
    private synchronized DataSource getMossDataSource(String region) throws NamingException, SQLException {
        if(region.trim().equals("SE")){
            return getMossDataSource(ds_se_moss,region);         
        } else {
            throw new IllegalArgumentException("Unrecognized region: "+region);
        }
    }
    
    private synchronized DataSource getDataSource(DataSource ds, String region) throws NamingException, SQLException {
        if(ds == null){
            Context initContext = new InitialContext();
            Context envContext = (Context)initContext.lookup("java:/comp/env");
            ds = (DataSource)envContext.lookup("jdbc/RABC" + region.trim().toUpperCase());
        }
        return ds;
    }
    private synchronized DataSource getMossDataSource(DataSource ds, String region) throws NamingException, SQLException {
        if(ds == null){
            Context initContext = new InitialContext();
            Context envContext = (Context)initContext.lookup("java:/comp/env");
           
            ds = (DataSource)envContext.lookup("jdbc/RABCMOSS" + region.trim().toUpperCase());
        }
        return ds;
    }
    
    private synchronized Connection getConn(String region) throws NamingException, SQLException {
    	logger.debug("Setting up connection for region " + region);
    	DataSource ds = getDataSource(region);
    	Connection connection = ds.getConnection();
    	connection.setAutoCommit(false);
    	logger.debug("Set up connection for region " + region);
    	return connection;
    }
    private synchronized Connection getMossConn(String region) throws NamingException, SQLException {
    	logger.debug("Setting up connection for MOSS region " + region);
    	DataSource ds = getMossDataSource(region);
    	Connection connection = ds.getConnection();
    	connection.setAutoCommit(true);
    	logger.debug("Set up connection for MOSS region " + region);
    	return connection;
    }
    
    public static Connection getConnection(String region) throws NamingException, SQLException {
        return getRef().getConn(region);
    }
    public static Connection getMossConnection(String region) throws NamingException, SQLException {
        return getRef().getMossConn(region);
    }
}
