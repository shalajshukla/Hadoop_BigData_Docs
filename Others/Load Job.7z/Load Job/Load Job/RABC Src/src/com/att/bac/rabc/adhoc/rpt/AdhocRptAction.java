/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.adhoc.rpt;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.att.bac.rabc.ProgressBar;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.adhoc.aria.ARIAReportRABC;
import com.att.bac.rabc.adhoc.aria.AbstractAdhocAriaLayout;
import com.att.bac.rabc.adhoc.aria.AbstractAriaLayoutPivot;
import com.att.bac.rabc.adhoc.aria.LayoutHelper;
import com.att.bac.rabc.adhoc.aria.layouts.AdhocAriaLayoutFactory;
import com.att.bac.rabc.rmi.RMIRunReport;
import com.att.carat.util.email.EmailFactory;
import com.att.carat.util.io.FileIO;
import com.sbc.bac.aria.ARIAReportException;


/**
 * Module description: This is the Action class for Adhoc reports.
 * 
 * <p>
 * <hr>
 * <h3>Release History</h3>
 * <p>
 * <ul>
 * 
 * <li>PD2951 20051216 Initial version for EAP556010
 * <li>PD2951 20050224 Changes for report scheduler
 * <li>PD2951 20060427 Basic paging logic (temporary fix)
 * <li>jb6494 May 08, 2006 Added code to clear lists from DataTO objects.
 * <li>jb6494 May 10, 2006 Added smasher code to nextprev.
 * <li>JB6494 Sep 29, 2006 Removed doCal.. method and put the code in the forms reset method.
 * <li>JB6494 Nov 01, 2006 Changed processError to return good error info.
 * 
 * </ul>
 * <p>
 * 
 * 
 */
public class AdhocRptAction extends DispatchAction implements IActionPaging {

    private static final Logger logger = Logger.getLogger(AdhocRptAction.class);


    /**
     * Create a report and output it as the response. It is a excel output that will prompt the user to open or save.
     * 
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return
     * @throws IOException
     * @throws ServletException
     */
    public ActionForward createreport(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        ActionForward forward = null;
        try {
        	addBackgroundReportInfo(form, request);
            request.setAttribute("close", "Y");
            forward = mapping.findForward("createwindow");
        } catch (Exception e) {
            forward = processError(request, form, mapping, e);
        }
        return forward;
    }


    /**
     * Email a report
     * 
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return
     * @throws IOException
     * @throws ServletException
     */
    @SuppressWarnings("static-access")
	public ActionForward emailreport(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        ActionForward forward = null;
        try {
            AdhocRptForm adhocRptForm = (AdhocRptForm) form;

            String smbUrl = null;
            // get email address(es) from popup window
            String toAddress = adhocRptForm.getEmailRecipients();
            Context initContext = new InitialContext();
            String rootFolder = null;
            String spServer = null;
            String spUser = null;
            String spPasswd = null;
            SimpleDateFormat sdft = new SimpleDateFormat("MMddyyyyHHmmss");
            String fileName = null;
             
                spServer = initContext.lookup("java:/comp/env/saved_report_server").toString();
                rootFolder = initContext.lookup("java:/comp/env/saved_report_folder").toString();
                spUser = initContext.lookup("java:/comp/env/saved_report_user").toString();
                spPasswd = initContext.lookup("java:/comp/env/saved_report_passwd").toString();
                fileName = "Control_data_history_report_" + spUser + "_" + sdft.format(new Date()) + ".xls";
                smbUrl = "smb://" + spUser + ":" + spPasswd + "@" + spServer + "/" + rootFolder ;

            FileIO fio = new FileIO(smbUrl,fileName);
            
            OutputStream os = fio.createOutputStream();
            createExcelReport(mapping, form, request, os);
            fio.closeOutputStream(os);

           // createExcelReport(mapping, form, request, fio.createOutputStream());

            // send email
            boolean sendEmail = false;
            if (adhocRptForm.getSchedTask() != null && adhocRptForm.getSchedTask().equalsIgnoreCase("Y")) {
                if (adhocRptForm.getReportAction() != null && (adhocRptForm.getReportAction().equalsIgnoreCase("E") || adhocRptForm.getReportAction().equalsIgnoreCase("B"))) {
                    sendEmail = true;
                }
            } else {
                sendEmail = true;
            }
            if (sendEmail) {
                String[] emailRecipients = toAddress.split(",");
                // pb3879 added to create correct subject line.
                String fromEnvironment = initContext.lookup("java:/comp/env/application_env").toString();
                String rptHeader1 = adhocRptForm.getRptHeader1();
               // SmbFile f = new SmbFile(fio.getQualifiedFilename());
                
                for (int count = 0; count < emailRecipients.length; count++) {
                	 String subject = "RABC (" + fromEnvironment + " - " + spServer + ") " + rptHeader1;
                     EmailFactory.sendEmail(emailRecipients[count], subject, adhocRptForm.getRptHeader1(), fio);
                //	Email.sendSmbEmail(emailRecipients[count] + "@att.com", "RABC (" + fromEnvironment + " - " + spServer + ") " + rptHeader1, adhocRptForm.getRptHeader1(), false, f);                    
                }
            }


            if (adhocRptForm.getSchedTask() != null && adhocRptForm.getSchedTask().equalsIgnoreCase("Y")) {
                return null;
            }
            if (adhocRptForm.getAdhocTest().equalsIgnoreCase("N")) {
                adhocRptForm.getAdhocRptDataTO().getDistExecPresnSeqNumList().clear();
                forward = viewreport(mapping, form, request, response);// mapping.findForward("report");
            } else {
                forward = mapping.findForward("popupreport");
            }

        } catch (Exception e) {
            forward = processError(request, form, mapping, e);
        }
        return forward;
    }



    /**
     * Fetch repords. Just forward to viewReport
     * 
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return
     * @throws IOException
     * @throws ServletException
     */
    public ActionForward fetchrecords(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        return runReport(mapping, form, request, response);
    }


    /*
     * (non-Javadoc)
     * 
     * @see com.att.bac.rabc.adhoc.rpt.IActionPaging#first(org.apache.struts.action.ActionMapping,
     *      org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest,
     *      javax.servlet.http.HttpServletResponse, boolean)
     */
    public ActionForward first(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        AdhocRptForm f = (AdhocRptForm) form;
        f.setPage(1);
        return runReport(mapping, form, request, response);
    }


    /*
     * (non-Javadoc)
     * 
     * @see com.att.bac.rabc.adhoc.rpt.IActionPaging#gotoPage(org.apache.struts.action.ActionMapping,
     *      org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest,
     *      javax.servlet.http.HttpServletResponse, boolean)
     */
    public ActionForward gotoPage(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        AdhocRptForm f = (AdhocRptForm) form;
        if ((f.getGotoPage() >= 1) && (f.getGotoPage() <= f.getPages())) {
            f.setPage(f.getGotoPage());
        } else {
            f.setGotoPage(f.getPage());
        }

        return runReport(mapping, form, request, response);
    }


    /*
     * (non-Javadoc)
     * 
     * @see com.att.bac.rabc.adhoc.rpt.IActionPaging#last(org.apache.struts.action.ActionMapping,
     *      org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest,
     *      javax.servlet.http.HttpServletResponse, boolean)
     */
    public ActionForward last(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        AdhocRptForm f = (AdhocRptForm) form;
        f.setPage(f.getPages());
        return runReport(mapping, form, request, response);
    }


    /*
     * (non-Javadoc)
     * 
     * @see com.att.bac.rabc.adhoc.rpt.IActionPaging#next(org.apache.struts.action.ActionMapping,
     *      org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest,
     *      javax.servlet.http.HttpServletResponse, boolean)
     */
    public ActionForward next(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        AdhocRptForm f = (AdhocRptForm) form;
        f.setPage(Math.min(f.getPages(), f.getPage() + 1));
        return runReport(mapping, form, request, response);
    }


    /**
     * Get the next data
     * 
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return
     * @throws IOException
     * @throws ServletException
     */
    public ActionForward nextdata(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
    	AdhocRptForm f = (AdhocRptForm) form;
    	f.setBtnValue(1);
    	return this.nextPrev(mapping, form, request, true);
    }


    /**
     * Opens the window for create reports 
     * 
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return
     * @throws IOException
     * @throws ServletException
     */
    public ActionForward opencreatewindow(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        return mapping.findForward("createwindow");
    }


    /*
     * (non-Javadoc)
     * 
     * @see com.att.bac.rabc.adhoc.rpt.IActionPaging#previous(org.apache.struts.action.ActionMapping,
     *      org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest,
     *      javax.servlet.http.HttpServletResponse, boolean)
     */
    public ActionForward previous(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        AdhocRptForm f = (AdhocRptForm) form;
        f.setPage(Math.max(1, f.getPage() - 1));
        return runReport(mapping, form, request, response);
    }


    /**
     * Get previous data
     * 
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return
     * @throws IOException
     * @throws ServletException
     */
    public ActionForward previousdata(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
    	AdhocRptForm f = (AdhocRptForm) form;
    	f.setBtnValue(0);
    	return this.nextPrev(mapping, form, request, false);
    }


    /*
     * (non-Javadoc)
     * 
     * @see org.apache.struts.actions.DispatchAction#unspecified(org.apache.struts.action.ActionMapping,
     *      org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest,
     *      javax.servlet.http.HttpServletResponse)
     */
    public ActionForward unspecified(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        logger.debug("\ndispatch=" + request.getParameter("dispatch") + "\n");
        AdhocRptForm f = (AdhocRptForm) form;
        
        // Set default value for bill round check as "on" - change communicated on 20-MAR-2007
        f.setBillRoundCheck("on");
        
        f.setPage(1);
        return runReport(mapping, form, request, response);
    }


    /**
     * View the report
     * 
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return
     * @throws IOException
     * @throws ServletException
     */
    public ActionForward viewreport(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        AdhocRptForm f = (AdhocRptForm) form;
        f.setPage(1);
        return runReport(mapping, form, request, response);
    }

    /**
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return
     */
    public ActionForward saveBackgroundInfo(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
    	ActionForward dashboardRedirect = new ActionForward();
        String redirectPath = "/AlertDashboard.do?dispatch=unspecified&saveBackground=Y";        
        dashboardRedirect.setRedirect(true);
        String askedQuestion = null; 
        ActionForward forward = null;
        try {        	
        	addBackgroundReportInfo(form, request);
        	AdhocRptForm f = (AdhocRptForm) form;
        	HttpSession session = request.getSession(false);
        	askedQuestion = (String)session.getAttribute("notasked");        	
        	if (f.getDuplicateCriteria().equalsIgnoreCase("Y") && askedQuestion.equalsIgnoreCase("N")){        		
        		forward = mapping.findForward("popupreport");
        	}else{
        	if(f.getDuplicateCriteria().equalsIgnoreCase("Y")){
        		addBackgroundReportInfo(form, request);	
        	}        	
            dashboardRedirect.setPath(redirectPath);
            forward = dashboardRedirect;
        	}
        } catch (Exception e) {
            forward = processError(request, form, mapping, e);
        }
        return forward;
    }
    
    /**
     * Save a record for a report request to the appropriate tables, poke RMI to run reports.
     * 
     * @param form
     * @param request
     * @throws RABCException
     * @throws ARIAReportException
     * @throws NamingException
     */
    private void addBackgroundReportInfo(ActionForm form, HttpServletRequest request) throws RABCException, ARIAReportException, NamingException {
        AdhocRptForm f = (AdhocRptForm) form;
        HttpSession session = request.getSession(false);
        String askedQuestion = (String)session.getAttribute("notasked");
        String userid = (String) request.getSession().getAttribute("bacUserID");      
        ProgressBar progressBar = new ProgressBar(session);

        f.setRegion((String) request.getSession().getAttribute("region"));
        String tableNode = (String) request.getSession().getAttribute("tableNode");
        progressBar.setProgressPercent(10);
       
        AdhocRptDAO adhocRptDAO = new AdhocRptDAO();
        adhocRptDAO.validatePresnId(f.getAdhocRptDataTO());
        adhocRptDAO.getDivision(f.getAdhocRptDataTO());
    
        adhocRptDAO.getDates(f.getAdhocRptDataTO());
        adhocRptDAO.getPresnSeqNumArray(f.getAdhocRptDataTO());
        progressBar.setProgressPercent(25);
        ARIAReportRABC[] reports = adhocRptDAO.processPresnSeqNumArray(f.getAdhocRptDataTO(), -1);
        progressBar.setProgressPercent(50);
        addGeneratedSQLForDebugging(request, reports, f.getAdhocRptDataTO());

        AdhocRptDataTO dto = f.getAdhocRptDataTO();
        HashMap<String, String> weekdayOptions = null;
        try {
            dto = LayoutHelper.createReportFilters(dto, weekdayOptions);
        } catch (RABCException e) {
            logger.error("AdhocReportAction:background", e);
        }

        // generate previousSQL, if required
        ArrayList<String> previousSQLList = new ArrayList<String>();
        boolean previousExists = false;
        for (int i = 0; i < reports.length; i++) {
            previousExists = false;
            AdhocRptDataTO tempDto = reports[i].getDto();
            for (int j = 0; j < tempDto.getPrevDataIndList().size(); j++) {
                if (LayoutHelper.isIndicatorIn((String) tempDto.getPrevDataIndList().get(j), "Y")) {
                    previousExists = true;
                    break;
                }
            }

            if (previousExists) {
                PreviousDataGeneratorMediator mediator = new PreviousDataGeneratorMediator();
                String previousSQL = mediator.generatePreviousDataQuery(tempDto, i).toSQL();
                previousSQLList.add(previousSQL);
            } else {
                previousSQLList.add(" ");
            }
        }

        // save all the criteria
        AdhocBackgroundReportDAO bkgrndDao = new AdhocBackgroundReportDAO();
        int rptId = bkgrndDao.getId(dto);
        String fileName = bkgrndDao.getFileName(f, dto, userid, f.getRegion(), tableNode);
        boolean duplicateCheck = bkgrndDao.checkForDuplicateBkgroundInfo(dto, userid);
       if (duplicateCheck && askedQuestion.equalsIgnoreCase("N")){
        	f.setDuplicateCriteria("Y");          	
        }else { 
		        bkgrndDao.saveBackgroundInfo(dto, rptId, f.getNotes(), userid, fileName, previousSQLList);
		
		        progressBar.setProgressPercent(100);
		
		        // IL3693 add RMI to background request
		        Context initContext;
		        // try {
		        initContext = new InitialContext();
		
		        String region = (String) request.getSession().getAttribute("region");
		        String port = initContext.lookup("java:/comp/env/report_engine_port_" + region).toString();
		        String host = initContext.lookup("java:/comp/env/report_engine_host").toString();
		        String rmiName = initContext.lookup("java:/comp/env/rmi_name").toString();
		
		        new RMIRunReport(rmiName, host, port).runAsThread();
        }
       
    }
  
    /**
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return
     */
    public ActionForward background(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        ActionForward forward = null;
        try {
            AdhocRptForm f = (AdhocRptForm) form;

           // ByteArrayOutputStream os = new ByteArrayOutputStream(1024);
          //  String userid = (String) request.getSession().getAttribute("bacUserID");
            
            HttpSession session = request.getSession(false);
            ProgressBar progressBar = new ProgressBar(session);

            f.setRegion((String) request.getSession().getAttribute("region"));
           // f.setTableNode((String)request.getSession().getAttribute("tableNode"));
            String tableNode = (String)request.getSession().getAttribute("tableNode");
            progressBar.setProgressPercent(10);
          //  f.getAdhocRptDataTO().setTableNode(tableNode);
            AdhocRptDAO adhocRptDAO = new AdhocRptDAO();
            adhocRptDAO.validatePresnId(f.getAdhocRptDataTO());
            adhocRptDAO.getDivision(f.getAdhocRptDataTO());
          //  if (f.getRegion().equals("ENTR")) {
          //  	adhocRptDAO.getSortKeyLists(f.getAdhocRptDataTO());
          //  }
            adhocRptDAO.getDates(f.getAdhocRptDataTO());
            adhocRptDAO.getPresnSeqNumArray(f.getAdhocRptDataTO());
            progressBar.setProgressPercent(25);
            ARIAReportRABC[] reports = adhocRptDAO.processPresnSeqNumArray(f.getAdhocRptDataTO(), -1);
            progressBar.setProgressPercent(50); 
            addGeneratedSQLForDebugging(request, reports, f.getAdhocRptDataTO());
            AdhocRptDataTO dto = f.getAdhocRptDataTO();
            
            HashMap<String, String> weekdayOptions = null;
            try {
            	dto = LayoutHelper.createReportFilters(dto, weekdayOptions);
            } catch (RABCException e) {
                logger.error("AdhocReportAction:background", e);
            }
            
            f.setBackgroundProcess("Y");
            progressBar.setProgressPercent(100);
            forward = mapping.findForward("report");
        } catch (Exception e) {
            forward = processError(request, form, mapping, e);
        }
        
        return forward;
                    
    }




    /**
     * Get the excel report.
     * 
     * @param form
     * @param response
     * @param report
     * @throws IOException
     * @throws ServletException
     * @throws RABCException
     */
    private void createExcelReport(ActionMapping mapping, ActionForm form, HttpServletRequest request, OutputStream os) throws IOException, ServletException, RABCException {
        try {
            AdhocRptForm f = (AdhocRptForm) form;
            String userid = (String) request.getSession().getAttribute("bacUserID");
            f.setRegion((String) request.getSession().getAttribute("region"));

            AdhocRptDAO adhocRptDAO = new AdhocRptDAO();
            adhocRptDAO.validatePresnId(f.getAdhocRptDataTO());
            adhocRptDAO.getDivision(f.getAdhocRptDataTO());
            adhocRptDAO.getDates(f.getAdhocRptDataTO());
            adhocRptDAO.getPresnSeqNumArray(f.getAdhocRptDataTO());

            ARIAReportRABC[] reports = adhocRptDAO.processPresnSeqNumArray(f.getAdhocRptDataTO(), -1);
            
            if (f.getAdhocRptDataTO().getPresnModel() == 2 || f.getAdhocRptDataTO().getPresnModel() == 4) {
            	AbstractAriaLayoutPivot pivotLayout = AdhocAriaLayoutFactory.getPivotExcelLayout(f.getAdhocRptDataTO().getPresnModel(), f.getAdhocRptDataTO().getPresnTrendTime(), f, os, userid);
            	pivotLayout.execute(reports, f.getAdhocRptDataTO());
            } else {
            	AbstractAdhocAriaLayout layout = AdhocAriaLayoutFactory.getExcelLayout(f.getAdhocRptDataTO().getPresnModel(), f.getAdhocRptDataTO().getPresnTrendTime(), f, os, userid);
                layout.execute(reports, f.getAdhocRptDataTO());
            }
            
            f.setNumberOfTables(f.getTables().size());

            // request.setAttribute("report", os.toString());
            os.flush();
        } catch (Exception e) {
            processError(request, form, mapping, new RABCException("Adhoc Excel report error", e));
        }
    }


    /**
     * Get next/previous
     * 
     * @param mapping
     * @param form
     * @param request
     * @param next
     * @return
     * @throws IOException
     * @throws ServletException
     */
    private ActionForward nextPrev(ActionMapping mapping, ActionForm form, HttpServletRequest request, boolean next) {
        ActionForward forward = null;
        try {
            request.getSession().removeAttribute("adhoc_dto");
            request.getSession().removeAttribute("adhoc_tables");

            AdhocRptForm f = (AdhocRptForm) form;
            f.setPage(1);

            ByteArrayOutputStream os = new ByteArrayOutputStream(1024);
            String userid = (String) request.getSession().getAttribute("bacUserID");

            f.setRegion((String) request.getSession().getAttribute("region"));
            AdhocRptDAO adhocRptDAO = new AdhocRptDAO();

            adhocRptDAO.validatePresnId(f.getAdhocRptDataTO());
            adhocRptDAO.getDivision(f.getAdhocRptDataTO());

            adhocRptDAO.getPresnSeqNumArray(f.getAdhocRptDataTO());
            ARIAReportRABC[] reports = adhocRptDAO.processPresnSeqNumArray(f.getAdhocRptDataTO(),f.getBtnValue());

            addGeneratedSQLForDebugging(request, reports, f.getAdhocRptDataTO());

            if (f.getAdhocRptDataTO().getPresnModel() == 2 || f.getAdhocRptDataTO().getPresnModel() == 4){
            	AbstractAriaLayoutPivot pivotLayout = AdhocAriaLayoutFactory.getPivotLayout(f.getAdhocRptDataTO().getPresnModel(), f.getAdhocRptDataTO().getPresnTrendTime(), f, os, userid);
            	pivotLayout.execute(reports, f.getAdhocRptDataTO());
            } else {
            	AbstractAdhocAriaLayout layout = AdhocAriaLayoutFactory.getLayout(f.getAdhocRptDataTO().getPresnModel(), f.getAdhocRptDataTO().getPresnTrendTime(), f, os, userid);
                layout.execute(reports, f.getAdhocRptDataTO());
            }
            
            f.setNumberOfTables(f.getTables().size());

            request.setAttribute("pagingButtons", f.getAdhocRptDataTO().getPagedHtml());
            request.setAttribute("report", os.toString());
            os.flush();
            os.close();

            if (f.getAdhocTest().equalsIgnoreCase("N")) {
                forward = mapping.findForward("report");
            } else {
                forward = mapping.findForward("popupreport");
            }

        } catch (Exception e) {
            processError(request, form, mapping, e);
        }
        return forward;
    }


    /**
     * Process errors for display
     * 
     * @param request
     * @param form TODO
     * @param mapping
     * @param e
     * @return
     */
    private ActionForward processError(HttpServletRequest request, ActionForm form, ActionMapping mapping, Exception e) {
        RABCException exception = null;
        request.setAttribute("javax.servlet.error.exception", e);
        List<Exception> failureList = new ArrayList<Exception>();
        if (e instanceof RABCException) {
            exception = (RABCException) e;
        } else {
            exception = new RABCException(e.getMessage(), e);
        }

        if (form instanceof AdhocRptForm) {
            AdhocRptForm f = (AdhocRptForm) form;
            exception = new RABCException(exception.getMessage() + "\n\r" + f.getAdhocRptDataTO(), (Exception) exception.getCause());
        }

        failureList.add(exception);

        request.setAttribute("failures", failureList);
        logger.warn(e.getMessage(), e);
        return mapping.findForward("error");
    }


    /**
     * Perform the running of the report
     * 
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return
     */
    private ActionForward runReport(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        ActionForward forward = null;
        try {
            AdhocRptForm f = (AdhocRptForm) form;

            ByteArrayOutputStream os = new ByteArrayOutputStream(1024);
            String userid = (String) request.getSession().getAttribute("bacUserID");

            f.setRegion((String) request.getSession().getAttribute("region"));

            AdhocRptDAO adhocRptDAO = new AdhocRptDAO();
            adhocRptDAO.validatePresnId(f.getAdhocRptDataTO());
            adhocRptDAO.getDivision(f.getAdhocRptDataTO());
            adhocRptDAO.getDates(f.getAdhocRptDataTO());
            adhocRptDAO.getPresnSeqNumArray(f.getAdhocRptDataTO());
           
            ARIAReportRABC[] reports = adhocRptDAO.processPresnSeqNumArray(f.getAdhocRptDataTO(),-1);

            addGeneratedSQLForDebugging(request, reports, f.getAdhocRptDataTO());

            if (f.getAdhocRptDataTO().getPresnModel() == 2 || f.getAdhocRptDataTO().getPresnModel() == 4){
            	AbstractAriaLayoutPivot pivotLayout = AdhocAriaLayoutFactory.getPivotLayout(f.getAdhocRptDataTO().getPresnModel(), f.getAdhocRptDataTO().getPresnTrendTime(), f, os, userid);
            	pivotLayout.execute(reports, f.getAdhocRptDataTO());
            } else {
            	AbstractAdhocAriaLayout layout = AdhocAriaLayoutFactory.getLayout(f.getAdhocRptDataTO().getPresnModel(), f.getAdhocRptDataTO().getPresnTrendTime(), f, os, userid);
            	layout.execute(reports, f.getAdhocRptDataTO());
            }
            
            f.setNumberOfTables(f.getTables().size());

            request.setAttribute("pagingButtons", f.getAdhocRptDataTO().getPagedHtml());
            request.setAttribute("report", os.toString());
            os.flush();
            os.close();

            if (f.getAdhocTest().equalsIgnoreCase("N")) {
                forward = mapping.findForward("report");
            } else {
                forward = mapping.findForward("popupreport");
            }

        } catch (Exception e) {
            forward = processError(request, form, mapping, e);
        }      
      
        return forward;
    }


    /**
     * To help with debugging the actual queries used will be put in comments in the html source
     * 
     * @param request
     * @param reports
     * @param dto
     * @throws ARIAReportException
     */
    private void addGeneratedSQLForDebugging(HttpServletRequest request, ARIAReportRABC[] reports, AdhocRptDataTO dto) throws ARIAReportException {
        String[] queries = new String[reports.length];
        String sql = null;
        for (int i = 0; i < reports.length; i++) {
            sql = reports[i].toSQL();
            queries[i] = sql;
            dto.getGeneratedSQL().add(sql);
        }
        request.setAttribute("REPORT_QUERIES", queries);
    }


 //   /**
 //    * Write to the remote store
 //    * 
//     * @param tempFile
 //    * @param smbUrl
 //    * @return
 //    * @throws IOException
 //    */
 //   private boolean writeToRemoteShare(File tempFile, String smbUrl) throws IOException {
 //       try {

 //           InputStream bis = new BufferedInputStream(new FileInputStream(tempFile));
 //           SmbFileOutputStream out = new SmbFileOutputStream(smbUrl);
 //           byte[] data = new byte[1024];
  //          while ((bis.read(data)) != -1) {
 //               out.write(data);
 //               data = new byte[1024];
 //           }
 //           bis.close();
 //           out.close();

 //           return true;

 //       } catch (SmbException e) {
  //          logger.fatal("smb Exception while connecting!!", e);
  //      } catch (MalformedURLException e) {
  //          logger.fatal("smbURL not correctly formated", e);
  //      } catch (UnknownHostException e) {
  //          logger.fatal("remote server not found", e);
  //      } catch (FileNotFoundException e) {
  //          logger.fatal("Unable to find the file", e);
  //      }
 //       return false;
  //  }
}
