/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.admin;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;

/**
 * This is a DAO that performs SELECT, INSERT and UPDATE on RABC_PRESN_CALC_ELEM table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class PresnCalcElemDAO {
	private static final Logger logger = Logger.getLogger(PresnCalcElemDAO .class);

	/**
	 * Returns the list of PresnCalcElem objects.
	 * 
	 * @param conn 
	 * @param failures
	 * @param args
	 * @param baseSQL
	 * @return List
	 */
	public List get(Connection conn, List failures, List args, String baseSQL) {
		List presnCalcElemList = null;
		PresnCalcElem presnCalcElem = null;
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		
		try
		{
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("PresnCalcElemDAO  - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			presnCalcElemList = new ArrayList();
			while (rs.next()) {
				presnCalcElemList.add(buildPresnCalcElem(rs));
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return null;
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
		
		return presnCalcElemList;
	}

	/**
	 * Private method to build PresnCalcElem object and return it to caller.
	 * 
	 * @param rs
	 * @return PresnCalcElem
	 * @throws SQLException
	 */
	private PresnCalcElem buildPresnCalcElem(ResultSet rs) throws SQLException {
		PresnCalcElem presnCalcElem = new PresnCalcElem();
		
		presnCalcElem.setPresnCalcName(rs.getString("PRESN_CALC_NAME"));
		presnCalcElem.setPresnCalcNum(rs.getInt("PRESN_CALC_NUM"));
		presnCalcElem.setCalcElemFormula(rs.getString("CALC_ELEM_FORMULA"));
		presnCalcElem.setCalcElemUserView(rs.getString("CALC_ELEM_USER_VIEW"));
		presnCalcElem.setCalcDivInd(rs.getString("CALC_DIV_IND"));
		presnCalcElem.setCalcElemDisplay(rs.getString("CALC_ELEM_DISPLAY"));
		presnCalcElem.setCalcDisplayElem(rs.getString("CALC_DISPLAY_ELEM"));
		presnCalcElem.setPresnFormatCode(rs.getString("PRESN_FORMAT_CODE"));
		presnCalcElem.setCalcTbl(rs.getString("CALC_TBL")) ;
		presnCalcElem.setCalcElemSqlFormula(rs.getString("CALC_ELEM_SQL_FORMULA")) ;
		return presnCalcElem;
	}

	/**
	 * Execute the insert or update statement on RABC_PRESN_CALC_ELEM  table.
	 * 
	 * @param conn
	 * @param failures
	 * @param args
	 * @param baseSQL
	 */
	public void executeUpdate(Connection conn, List failures, List args, String baseSQL) {
		int rowsUpdated = 0;
		Statement stmt = null;
		String sqlStmt = null;
		
		try
		{
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("PresnCalcElemDAO  - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rowsUpdated = stmt.executeUpdate(sqlStmt);
			logger.debug("SQL - Execution complete."+ String.valueOf(rowsUpdated) + "  rows updated");
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return;
		} finally {
			SQLHelper.closeStatement(stmt, failures, logger);
		}
	}

}
