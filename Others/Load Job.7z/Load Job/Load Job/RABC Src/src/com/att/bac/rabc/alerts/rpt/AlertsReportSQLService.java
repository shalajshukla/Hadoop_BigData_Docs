/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.rpt;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;

import com.att.bac.rabc.DataTblDdlBean;
import com.att.bac.rabc.ExtrctTblDefDAO;
import com.att.bac.rabc.MyDate;
import com.att.bac.rabc.PickList;
import com.att.bac.rabc.PresnId;
import com.att.bac.rabc.RABCConstantsLists;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.StaticDataLoader;
import com.att.bac.rabc.admin.alert.rule.AlertRule;
import com.att.bac.rabc.admin.alert.rule.AlertRuleDAO;
import com.att.bac.rabc.alerts.AlertSumyPresn;
import com.att.bac.rabc.alerts.AlertSumyPresnDAO;

/**
 * This class represents the Service class which handles processing of 
 * various SQLs requests for PAGE 11 and PAGE 14.
 * 
 * @author Nalina Pandiyan - NP5434
 */
public class AlertsReportSQLService {
	private static final Logger logger = Logger.getLogger(AlertsReportSQLService.class);
	private static final int PREVIOUS_BUTTON = 1;
	private static final int NEXT_BUTTON = 2;
	// SQL statements
	private final static String getDefaultAlertRuleInfSQL = "SELECT DB_NODE_ID, ALERT_RULE_STATUS, EFF_DATE, STD_TYPE, " +
					"ALERT_EXEMPT_IND, USER_ID, TIME_STAMP, ALERT_RULE, PARTI_REF_ID, PRESN_ID, FILE_VERIF_IND, DATA_EXTRCT_IND, DATA_CALC_IND, " +
					"CALC_RULE, WARNING_IND, AVG_IND, ALERT_MSG_IND, ALERT_SEQ_NUM_IND, ALERT_TIME_IND, ALERT_DASH_FRESH_IND, " +
					"ALERT_DESC, ALERT_EXEC_DATE, ALERT_KEY_LVL, ALERT_KEY1_NAME, ALERT_KEY2_NAME, ALERT_KEY3_NAME, ALERT_KEY4_NAME, " +
					"ALERT_KEY5_NAME, ALERT_FILE_CT, ASOC_FILE_ID, ALERT_RULE_PRESN_IND, DIVISION_NAME_KEY_LVL, ALERT_DATA_KEEP, " +
					"ALERT_RULE_TYPE, ALERT_MNTH_EXEC_DAY, ALERT_MNTH_EXEC_BILL_RND FROM RABC_ALERT_RULE where {0}";
	//private final static String qrySumyPresnRulesInnerSQL = "SELECT SUMY_PRESN_NAME FROM rabc_alert_sumy_presn WHERE ALERT_RULE = ''{0}'' and SUMY_PRESN_NAME like ''{0}%'' and webid = ''{1}''";
	private final static String qrySumyPresnRuleSQL = "select * from rabc_alert_sumy_presn WHERE ALERT_RULE = ''{0}'' and webid = ''{1}''";
	//private final static String qrySumyPresnRulesSQL = "select * from rabc_alert_sumy_presn where ALERT_RULE IN ( {0} ) and webid = ''{1}''";
	private final static String qryRelatedRulesSQL = "select * from rabc_alert_rule where PRESN_ID IN ( {0} )";
	private final static String qryTotInd = "select * from rabc_alert_sumy_presn where alert_rule = ''{0}'' and webid = ''{1}''";
	private final static String rabcAlertSumyPresnSQL = "select * from rabc_alert_sumy_presn where webid = ''{0}''";
	private final static String rabcDataTblDdlSQL = "select distinct alert_proc_tbl, tbl_proc_date_ddl_name from RABC_DATA_TBL_DDL";
	private final static String qryAlertRuleSQL = "SELECT distinct r.*, {0} FROM ({1}) r, {2} WHERE {3} r.WEBID = ''{4}'' AND {5} ORDER BY r.alert_rule";
	private final static String qryAlertRuleInnerSQL_1 = "SELECT r.alert_rule, r.parti_ref_id, r.file_verif_ind, " +
														"r.data_extrct_ind, r.data_calc_ind, r.alert_rule_type, r.calc_rule, " +
														"r.warning_ind, r.avg_ind, r.alert_msg_ind, " +
														"r.alert_seq_num_ind,r.alert_time_ind, r.alert_dash_fresh_ind, " +
														"r.alert_desc, r.alert_key_lvl, r.alert_key1_name, " +
														"r.alert_key2_name, r.alert_key3_name, r.alert_key4_name, " +
														"r.alert_key5_name, r.alert_file_ct, r.division_name_key_lvl, " +						
														"pr.*, " +
														"decode(nvl(lower(key1_header),''na''),''na'',3,1) AS key1_seq, " +
														"p.tot_ind as p_tot_ind, DECODE(r.calc_rule,''T'',1,0) AS calcCnt, " +
														"DECODE(r.alert_seq_num_ind,''Y'',1,0) AS seqCnt, " +
														"td.TBL_PROC_DATE_DDL_NAME, " +
														"l.key1_link_ddl_name, l.key1_link_to_pgm, l.key1_link_presn_id, " +
														"l.key1_link_tbl_key_name, l.key1_link_tbl_key_data, l.key1_link_tbl_name, " +
														"l.key2_link_ddl_name, l.key2_link_to_pgm, l.key2_link_presn_id, " +
														"l.key2_link_tbl_key_name, l.key2_link_tbl_key_data, l.key2_link_tbl_name, " +
														"l.key3_link_ddl_name, l.key3_link_to_pgm, l.key3_link_presn_id, " +
														"l.key3_link_tbl_key_name, l.key3_link_tbl_key_data, l.key3_link_tbl_name, " +
														"l.key4_link_ddl_name, l.key4_link_to_pgm, l.key4_link_presn_id, " +
														"l.key4_link_tbl_key_name, l.key4_link_tbl_key_data, l.key4_link_tbl_name, " +
														"l.key5_link_ddl_name, l.key5_link_to_pgm, l.key5_link_presn_id, " +
														"l.key5_link_tbl_key_name, l.key5_link_tbl_key_data, l.key5_link_tbl_name " +
														"FROM " +
															"RABC_ALERT_RULE r, " +
															"RABC_PRESN_ID pi, " +
															"RABC_ALERT_RULE_PRESN_RULE pr, " +
															"rabc_vw_presn_rule_links l, " +
															"({0}) p, " +
															"({1}) td " +
														"WHERE r.PRESN_ID = pr.PRESN_ID " +
															"AND r.PRESN_ID = pi.PRESN_ID " +
															"AND pr.PRESN_DATA_TBL = td.ALERT_PROC_TBL " +
															"AND pr.PRESN_ID = l.PRESN_ID(+) " +
															"AND pr.WEBID = l.WEBID(+) " +
															"AND pr.EXEC_PRESN_SEQ_NUM = l.EXEC_PRESN_SEQ_NUM(+) " +
															"AND r.alert_rule = p.alert_rule " +
															"AND r.ALERT_RULE IN ( {2} ) " +
															"AND pr.WEBID = ''{3}'' "; 

	private final static String qryAlertRuleInnerSQL_1_0 =  "select distinct r.alert_rule, nvl(asp.tot_ind,''N'') as tot_ind from rabc_alert_rule r, ({0}) asp where r.alert_rule = asp.alert_rule(+) ";
	private final static String qryAlertRuleInnerSQL_1_1 = "select distinct alert_proc_tbl, tbl_proc_date_ddl_name from RABC_DATA_TBL_DDL";
	private final static String qryAlertHistSQL = "SELECT h.* FROM rabc_alert_hist h {0} WHERE h.parti_ref_id IN ({1}) AND h.PRESN_CD IN (''A'', ''B'') {2} {3}";
	
	/*
	 * Modified SQL to improve performance
	 */
	private final static String qryAlertHistSQL1 = "select * from (select data1.*,rownum rn from (SELECT DISTINCT h.* FROM rabc_alert_hist h {0} WHERE h.parti_ref_id IN ({1}) AND h.PRESN_CD IN (''A'', ''B'') {2} {3}) data1 ) {4} ";
	private final static String qryAlertHistCount = "SELECT count(*) FROM (SELECT DISTINCT h.* FROM rabc_alert_hist h {0} WHERE h.parti_ref_id IN ({1}) AND h.PRESN_CD IN (''A'',''B'')   {2} {3})";
	private final static String qryAlertHistMinDate = "SELECT min(h.proc_date) FROM rabc_alert_hist h {0} WHERE h.parti_ref_id IN ({1}) AND h.PRESN_CD IN (''A'', ''B'') and h.proc_date < to_date(''{4}'',''mm/dd/yyyy'') {2} {3}";
	private final static String qryAlertHistMaxDate = "SELECT max(h.proc_date) FROM rabc_alert_hist h {0} WHERE h.parti_ref_id IN ({1}) AND h.PRESN_CD IN (''A'', ''B'') and h.proc_date > to_date(''{4}'',''mm/dd/yyyy'') {2} {3}";
	
	private final static String qryAlertHistNextDate = "SELECT min(h.proc_date) FROM rabc_alert_hist h {0} WHERE h.parti_ref_id IN ({1}) AND h.PRESN_CD IN (''A'', ''B'') and h.proc_date > to_date(''{4}'',''mm/dd/yyyy'') {2} {3}";
	private final static String qryAlertHistPreviousDate = "SELECT max(h.proc_date) FROM rabc_alert_hist h {0} WHERE h.parti_ref_id IN ({1}) AND h.PRESN_CD IN (''A'', ''B'') and h.proc_date < to_date(''{4}'',''mm/dd/yyyy'') {2} {3}";
	
	private final static String qryAlertMsgSQL = "SELECT DISTINCT MSG_NUM,PROC_DATE,FILE_SEQ_NUM,ALERT_RULE,ALERT_TYPE,ALERT_TIME_IND,ALERT_TIME_VALUE,ALERT_KEY_LVL," +
												"ALERT_KEY1,ALERT_KEY2,ALERT_KEY3,ALERT_KEY4,ALERT_KEY5,ALERT_DATA1,ALERT_DATA2,ALERT_DATA3,ALERT_DATA4,ALERT_DATA5," +
												"ALERT_ITEM,ALERT_SUPP_IND,ALERT_ACTUAL,ALERT_UNIT_IND,ALERT_DATA,ALERT_PCT,ALERT_USER_ID,ALERT_GRP,ALERT_REVENUE," +
												"ALERT_STATUS,ALERT_MSG,ALERT_ROOT_CATGY_CD,ALERT_ROOT_CAUSE,ALERT_SEVERE_LVL_IND,ALERT_SYS_ERR_CD,TIME_STAMP,ALERT_RULE_RUN_DT," +
												"ALERT_LOST_REVENUE FROM rabc_alert_msg m WHERE " +
												"m.alert_rule IN ({0}) " +
												"AND m.alert_severe_lvl_ind IN (''0'',''1'',''2'',''3'',''N'') {1} {2} ";
	private final static String qryPrevDataSQL = "SELECT DISTINCT p.* FROM rabc_vw_alert_hist_prev p WHERE p.parti_ref_id IN ( {0} ) {1} {2} {3}";
	private final static String notCompleteFilesQry1SQL = "Select file_seq_num, proc_date, alert_key1, alert_key2,  alert_key3, alert_key4,  alert_key5, alert_item From ({0}) order by file_seq_num, proc_date, alert_key1, alert_key2,  alert_key3, alert_key4,  alert_key5";
	private final static String notCompleteFilesQry1InnerSQL = "SELECT h.alert_item,h.alert_data,h.alert_actual_data,h.proc_date,h.file_seq_num,h.alert_key1,h.alert_key2,h.alert_key3,h.alert_key4,h.alert_key5 " + 
																"FROM  rabc_alert_hist h {0} WHERE h.parti_ref_id = {1} " + 
																"and h.PRESN_CD IN (''A'', ''B'') " +
																"and h.proc_date >= {2} " + 
																"and h.proc_date <= {3} {4} {5} {6} " +
																"Minus " +
																"SELECT  h.alert_item,h.alert_data,h.alert_actual_data,h.proc_date,h.file_seq_num,h.alert_key1,h.alert_key2,h.alert_key3,h.alert_key4,h.alert_key5 " +
																"FROM    rabc_alert_hist h ,rabc_alert_msg m " +
																"WHERE  h.parti_ref_id = {1} " +
																"and h.PRESN_CD IN (''A'', ''B'') " + 
																"and m.alert_rule = ''{7}'' " +
																"and m.alert_item= h.alert_item " +
																"and ((h.file_seq_num = m.file_seq_num ) or (h.file_seq_num is null and  m.file_seq_num is null)) " +
																"and h.alert_actual_data = m.alert_actual " +
																"and h.alert_data = m.alert_data " +
																"and h.proc_date >= {2} " +
																"and h.proc_date <= {3} " +
																"and h.proc_date=m.proc_date {8} {9} {10} ";
	private final static String alertItemsQrySQL = "SELECT count(*) RECORD_COUNT from rabc_extrct_tbl_def where parti_ref_id = {0}";
	private final static String notCompleteFilesQrySQL = "select FILE_SEQ_NUM,PROC_DATE,ALERT_KEY1,ALERT_KEY2,ALERT_KEY3,ALERT_KEY4,ALERT_KEY5 " + 
															"from ({0}) " +
															"Group By file_seq_num,proc_date,alert_key1,alert_key2,alert_key3,alert_key4,alert_key5 " +
															"Having count(alert_item) < {1}";
	
	private final static String qrySeqNumberSQL = "SELECT  a.alert_rule as ALERT_RULE, max(proc_date) as max_proc_date FROM " +
													"rabc_alert_hist h ,rabc_alert_rule a ,rabc_presn_id p " +
													"WHERE file_seq_num = ''{0}''  and a.parti_ref_id = h.parti_ref_id " + 
													"and presn_cd in (''A'',''B'') " +
													"and proc_date >= to_date(''{1}'',''mm/dd/yyyy'') " +
													"and proc_date <= to_date(''{2}'',''mm/dd/yyyy'') " +
													"and a.presn_id = p.presn_id " +
													"GROUP BY	a.alert_rule ORDER BY max_proc_date";

	private final static String qryCntrPtCdSQL = "SELECT DISTINCT A.ALERT_RULE FROM RABC_ALERT_RULE A, RABC_CNTRL_PT_ALERT B WHERE A.ALERT_RULE = B.ALERT_RULE AND A.ALERT_RULE_STATUS = ''ACTIVE'' AND B.CNTRL_PT_CD = ''{0}''";
	
	private final static String qryalertItemSQL = "SELECT DISTINCT ALERT_ITEM FROM RABC_ALERT_HIST WHERE PARTI_REF_ID IN ({0}) ORDER BY ALERT_ITEM";
	
	private final static String getDefaultDivision = "SELECT DIVISION FROM RABC_USER_DEFAULT_DIVISION WHERE USER_ID = ''{0}''";
	
	private final static String getDefaultLineCount = "SELECT LINE_CT FROM RABC_USER_DEFAULT_RPT_LINE WHERE USER_ID = ''{0}''";

	private static final String PAGE_14 = "RABCPSF00014";
	private static final String PAGE_11 = "RABCPSF00011";
	private final static int NEXT_ROW = 0;
	private final static int INSERT_ROW = 1;

	// Class level attributes
	private Connection connection = null;
	private List failureList = null;
	private AlertReportParameters alertReportParameters = null;

	private List qryAlertDataList = null;
	private List notCompleteFilesQryList = null;
	private List notCompleteFilesQry1List = null;
	private List previousDataList = null;
	private List qryAlertMsgList = null;
	//private List keyColumnList = null;

	private List qryAlertRuleList = new ArrayList();
	private List qryAlertHistAllList = new ArrayList();

	// The following MAP contains alert rule as key and AlertRuleInfoStruct as value. 
	private HashMap alertRuleMap = null;
	
	// This will hold SQL stmt which will again executed.
	private String notCompleteFilesQry1SQLStmt = null;
	
	/**
	 * This method is used to return the object of AlertsReportSQLService class.
	 * 
	 * @return AlertsReportSQLService
	 */
	public static AlertsReportSQLService getAlertsReportSQLService() {
		return new AlertsReportSQLService();
	}

	/**
	 * @param qryAlertDataList The qryAlertDataList to set.
	 */
	public void setQryAlertDataList(List qryAlertDataList) {
		this.qryAlertDataList = qryAlertDataList;
	}

	/**
	 * @param notCompleteFilesQry The notCompleteFilesQry to set.
	 */
	public void setNotCompleteFilesQryList(List notCompleteFilesQry) {
		this.notCompleteFilesQryList = notCompleteFilesQry;
	}

	/**
	 * @param notCompleteFilesQry1 The notCompleteFilesQry1 to set.
	 */
	public void setNotCompleteFilesQry1List(List notCompleteFilesQry1) {
		this.notCompleteFilesQry1List = notCompleteFilesQry1;
	}

	/**
	 * @param previousDataList The previousDataList to set.
	 */
	public void setPreviousDataList(List previousDataList) {
		this.previousDataList = previousDataList;
	}

	/**
	 * @param qryAlertMsgList The qryAlertMsgList to set.
	 */
	public void setQryAlertMsgList(List qryAlertMsgList) {
		this.qryAlertMsgList = qryAlertMsgList;
	}

	/**
	 * @param alertReportParameters The alertReportParameters to set.
	 */
	public void setAlertReportParameters(AlertReportParameters alertReportParameters) {
		this.alertReportParameters = alertReportParameters;
	}

	/**
	 * @param connection The connection to set.
	 */
	public void setConnection(Connection connection) {
		this.connection = connection;
	}

	/**
	 * @param failureList The failureList to set.
	 */
	public void setFailureList(List failureList) {
		this.failureList = failureList;
	}

	/**
	 * @param alertRuleMap The alertRuleMap to set.
	 */
	public void setAlertRuleMap(HashMap alertRuleMap) {
		this.alertRuleMap = alertRuleMap;
	}

	/**
	 * This method is used to get Default alert rule information.
	 * It calls the alertRuleDAO.
	 */
	public void getDefaultAlertRuleInfo() {
		int i = 0;
		int size = 0;
		List args = new ArrayList();
		String key = "";
		AlertRule alertRule = null;
		AlertRuleInfoStruct alertRuleInfo = null;
		
		if (alertReportParameters.getCntrlPtCd().length() != 0) {
			// This means that request by click on Control Point Code is being executed.
			key = alertReportParameters.getAlertRules();
			args.add(new String("alert_rule in ("+key+")"));			
		} else {
			if (alertReportParameters.getPartiRefId() != null) {
				key = alertReportParameters.getPartiRefId().toString();
				args.add(new String("parti_ref_id = "+ key));
			} else {
				key = alertReportParameters.getAlertRule();
				args.add(new String("alert_rule = '"+key+"'"));
			}
		}
		AlertRuleDAO alertRuleDAO = new AlertRuleDAO();
		List alertRuleList = alertRuleDAO.get(connection, failureList, args, getDefaultAlertRuleInfSQL);
		if (alertRuleList.isEmpty()) {
			logger.error(RABCMessages.getMessage("ERR_ALERT_RULE", new String[] {key}));
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_ALERT_RULE", new String[] {key}), null));
			return;
		} else {
			size = alertRuleList.size();
			for (i = 0; i < size; i++) {
				alertRule = (AlertRule) alertRuleList.get(i);
				
				alertRuleInfo = new AlertRuleInfoStruct();
				alertRuleInfo.alertRule = alertRule.getAlertRule();
				alertRuleInfo.alertRules = quotedValueList(alertRuleInfo.alertRules, alertRuleInfo.alertRule);
				alertRuleInfo.partiRefId = alertRule.getPartiRefId();
				alertRuleInfo.partiRefIds = commaValueList(alertRuleInfo.partiRefIds, alertRuleInfo.partiRefId);
				alertRuleInfo.alertKeyLvl = alertRule.getAlertKeyLvl();
				alertRuleInfo.presnId = alertRule.getPresnId();
				if (alertRule.getDivisionNameKeyLvl() > 0) {
					alertRuleInfo.divisionNameKeyLvl = alertRule.getDivisionNameKeyLvl();
					alertReportParameters.setDivisionNameKeyLvl(new Integer(alertRuleInfo.divisionNameKeyLvl));
				}
				if (alertReportParameters.getPresnId() == null) {
					alertReportParameters.setPresnId(new Integer(alertRule.getPresnId()));
				}
				if (alertReportParameters.getPartiRefId() == null) {
					alertReportParameters.setPartiRefId(new Integer(alertRule.getPartiRefId()));
				}
				alertReportParameters.setAlertKeyLvl(new Integer(alertRuleInfo.alertKeyLvl));
				alertReportParameters.addPresnId(new Integer(alertRule.getPresnId()));
				alertReportParameters.addPartiRefId(new Integer(alertRule.getPartiRefId()));
				if (alertReportParameters.getAlertRules().length() == 0) {
					alertReportParameters.addAlertRule(alertRule.getAlertRule());
				}
				alertReportParameters.setAlertRule(alertRule.getAlertRule());
				alertRuleMap.put(alertRule.getAlertRule(),alertRuleInfo);
			}
		}
		return;
	}

	/**
	 * This method finds related alerts and sumy presn name for each alert rule.
	 */
	public void updateAlertRulesAndSumyPresn() {
		Set set = null; 
		Iterator iter = null; 
		AlertsReportSQLService.AlertRuleInfoStruct alertRuleInfo = null;
		String alertRule = null;
		int i = 0;
		int size = 0;
		
		logger.debug("Finding related alerts and sumy presn name for each alert rule ...");
		set = alertRuleMap.keySet();
		iter = set.iterator();
		while(iter.hasNext()) {			
			alertRule = (String) iter.next();
			alertRuleInfo = (AlertRuleInfoStruct) alertRuleMap.get(alertRule);
			updateSumyPresnName(alertRuleInfo, alertRule);
			alertRuleMap.put(alertRule, alertRuleInfo);
		}
	}
	
	/**
	 * This method finds related sumy presn name for each alert rule.
	 * 
	 * @param alertRuleInfo
	 * @param alertRule
	 */
	private void updateSumyPresnName(AlertRuleInfoStruct alertRuleInfo, String alertRule) {

		MessageFormat mf = null;
		//String qrySumyPresnRulesInnerSQLStmt = null;
		AlertSumyPresnDAO alertSumyPresnDAO = null;
		AlertSumyPresn alertSumyPresn = null;
		String assocPresnIds = "";
		AlertRuleDAO alertRuleDAO = null;
		AlertRule alertRuleObject = null;
		List alertRuleObjectList = null;
		List args = null;
		List alertSumyPresnList = null;
		int i = 0;
		int size = 0;
		
		mf = new MessageFormat(qrySumyPresnRuleSQL);
		String qrySumyPresnRuleSQLStmt = mf.format(new String[] {alertRule, alertReportParameters.getWebPageId()});
		logger.debug("Preparing qrySumyPresnRuleSQL=" + qrySumyPresnRuleSQLStmt);
		logger.debug("Alert Rule Value = " + alertRule);
		logger.debug("Alert Rule Web Page Id = " + alertReportParameters.getWebPageId());
		args = new ArrayList();
		alertSumyPresnDAO = new AlertSumyPresnDAO();
		alertSumyPresnList = alertSumyPresnDAO.get(connection, failureList, args, qrySumyPresnRuleSQLStmt);
		if (!failureList.isEmpty()) return;
		size = alertSumyPresnList.size();
		for(i=0;i<size;i++) {				
			if (alertReportParameters.getRelatedAlertInd().equals("Y")) { 
				alertSumyPresn = (AlertSumyPresn) alertSumyPresnList.get(i);
				//alertRuleInfo.alertRules = quotedValueList(alertRuleInfo.alertRules, alertSumyPresn.getAlertRule());
				assocPresnIds = commaValueList(assocPresnIds, alertSumyPresn.getAsocPresnId());
				//alertRuleInfo.sumyPresnNames = quotedValueList(alertRuleInfo.sumyPresnNames, alertSumyPresn.getSumyPresnName());
			} else {
				if (alertRuleInfo.alertRule.indexOf("-DAILY") > 0) {
					alertSumyPresn = (AlertSumyPresn) alertSumyPresnList.get(i);
					alertRuleInfo.sumyPresnNames = quotedValueList(alertRuleInfo.sumyPresnNames, alertSumyPresn.getSumyPresnName());
				}
			}
		}
		
		if (alertReportParameters.getRelatedAlertInd().equals("Y")) {
			mf = new MessageFormat(qryRelatedRulesSQL);
			String qryRelatedRulesSQLStmt = null;
			if (assocPresnIds.equals("")) {
				qryRelatedRulesSQLStmt = mf.format(new String[] {"''''"});
			} else {
				qryRelatedRulesSQLStmt = mf.format(new String[] {assocPresnIds.substring(1)});
			}
			logger.debug("Preparing qryRelatedRulesSQL=" + qryRelatedRulesSQLStmt);
			args = new ArrayList();
			alertRuleDAO = new AlertRuleDAO();
			alertRuleObjectList = alertRuleDAO.get(connection, failureList, args, qryRelatedRulesSQLStmt);
			if (!failureList.isEmpty()) return;
			if (alertRuleObjectList != null) {
				size = alertRuleObjectList.size();
				for(i=0;i<size;i++) {				
					alertRuleObject = (AlertRule) alertRuleObjectList.get(i);
					alertRuleInfo.alertRules = quotedValueList(alertRuleInfo.alertRules, alertRuleObject.getAlertRule());
					alertRuleInfo.partiRefIds = commaValueList(alertRuleInfo.partiRefIds, alertRuleObject.getPartiRefId());
				}
			}
			
			/*mf = new MessageFormat(qrySumyPresnRulesSQL);
			String qrySumyPresnRulesSQLStmt = mf.format(new String[] {alertRuleInfo.alertRules.substring(1), alertReportParameters.getWebPageId()});
			logger.debug("Preparing qrySumyPresnRulesSQL=" + qrySumyPresnRulesSQLStmt);
			args = new ArrayList();
			alertSumyPresnDAO = new AlertSumyPresnDAO();
			alertSumyPresnList = alertSumyPresnDAO.get(connection, failureList, args, qrySumyPresnRulesSQLStmt);
			if (!failureList.isEmpty()) return;
			size = alertSumyPresnList.size();
			for(i=0;i<size;i++) {				
				alertSumyPresn = (AlertSumyPresn) alertSumyPresnList.get(i);
				alertRuleInfo.sumyPresnNames = quotedValueList(alertRuleInfo.sumyPresnNames, alertSumyPresn.getSumyPresnName());
			}*/
		}
	}

	/**
	 * This method returns curList for quotedValueList.
	 * 
	 * @param curList
	 * @param newValue
	 * @return String
	 */
	private String quotedValueList(String curList, String newValue) {
		String newList = "";
		String tmpId;
		int index  = 0;

		if (newValue == null) return curList;
		tmpId = ",'" + newValue + "'";
		if (curList == null) {
			newList = tmpId;
			return newList;
		}
		index = curList.indexOf(tmpId);
		if (index == -1) {
			newList = curList + tmpId;
			return newList;
		}
		return curList;
	}
	
	/**
	 * This method returns curList for commaValueList.
	 * 
	 * @param curList
	 * @param newValue
	 * @return String
	 */
	private String commaValueList(String curList, int newValue) {
		String newList = "";
		String tmpId;
		int index  = 0;

		tmpId = "," + newValue;
		if (curList == null) {
			newList = tmpId;
			return newList;
		}
		index = curList.indexOf(tmpId);
		if (index == -1) {
			newList = curList + tmpId;
			return newList;
		}
		index = curList.indexOf(tmpId + ",");
		if (index == -1) {
			newList = curList + tmpId;
			return newList;			
		}
		if (curList.length() != (index + tmpId.length())) {
			newList = curList + tmpId;
			return newList;						
		}
		return curList;
	}

	/**
	 * This method prepares qryAlertRule SQL statment.
	 * 
	 * @param alertRuleInfo
	 * @return String
	 */
	private String prepareQryAlertRuleSQL(AlertRuleInfoStruct alertRuleInfo) {
		MessageFormat mf = null;
			
		logger.debug("Preparing qryAlertRule SQL statment ....");
		mf = new MessageFormat(rabcAlertSumyPresnSQL);
		logger.debug("Preparing SELECT from RABC_ALERT_SUMY_PRESN SQL statment ....");
		String rabcAlertSumyPresnSQLStmt = mf.format(new String[] {alertReportParameters.getWebPageId()});
		logger.debug("Preparing Inner SQL 1.0 for qryAlertRule ....");
		mf = new MessageFormat(qryAlertRuleInnerSQL_1_0);
		String qryAlertRuleInnerSQL_1_0Stmt = mf.format(new String[] {rabcAlertSumyPresnSQLStmt});

		logger.debug("Preparing Inner SQL 1 for qryAlertRule ....");
		mf = new MessageFormat(qryAlertRuleInnerSQL_1);
		String alertRules = alertRuleInfo.alertRules.substring(1);
		String alertRule = alertRuleInfo.alertRule; 
		String qryAlertRuleInnerSQL_1Stmt = mf.format(new String[] {qryAlertRuleInnerSQL_1_0Stmt,
																	rabcDataTblDdlSQL,
																	alertRules,
																	alertReportParameters.getWebPageId()});
	
		logger.debug("Preparing main SQL for qryAlertRule ....");
		logger.debug("Preparing argument 0 for qryAlertRule SQL ....");
		String arg_0 = new String();
		String arg_2 = new String();
		String arg_3 = new String();
		String arg_5 = new String();
	
		if (alertReportParameters.getWebPageId().equals(PAGE_14)) {
			arg_0 = "d.presn_seq_num AS rule_presn_seq_num";
			arg_2 = "rabc_dash_alert_presn d";
			arg_5 = "r.ALERT_RULE = d.ALERT_RULE";
		} else {
			arg_0 = "sp.presn_seq_num, sp.tot_ind, sp.sumy_presn_name, nvl(sp.cnt_sumy_presn_name, 0) AS cnt_sumy_presn_name";
			arg_2 = "rabc_vw_alert_sumy_presn sp";
			arg_5 = "r.presn_id = sp.asoc_presn_id AND r.webid = sp.webid(+)";
		}
		/*if (alertRuleInfo.sumyPresnNames != null) {
			arg_3 = "sp.sumy_presn_name IN (" + alertRuleInfo.sumyPresnNames.substring(1) + ") AND";
		} else {
			arg_3 = "sp.ALERT_RULE = '" + alertRule + "' AND"; 
		}*/
		arg_3 = "sp.ALERT_RULE = '" + alertRule + "' AND"; 
		mf = new MessageFormat(qryAlertRuleSQL);
		String qryAlertRuleSQLStmt = mf.format(new String[]	{arg_0,
															 qryAlertRuleInnerSQL_1Stmt,
															 arg_2,
															 arg_3,
															 alertReportParameters.getWebPageId(),
															 arg_5});		
		logger.debug("qryAlertRule =" + qryAlertRuleSQLStmt);
		
		return qryAlertRuleSQLStmt;
	}
	
	/**
	 * This method processes qry Alert Rule for each alert rule.
	 */
	public void executeQryAlertRule() {
		Set set = null; 
		Iterator iter = null; 
		AlertsReportSQLService.AlertRuleInfoStruct alertRuleInfo = null;
		String alertRule = null;
		int i = 0;
		int size = 0;
		
		logger.debug("Processing qry Alert Rule for each alert rule ...");
		set = alertRuleMap.keySet();
		iter = set.iterator();
		while(iter.hasNext()) {			
			alertRule = (String) iter.next();
			alertRuleInfo = (AlertRuleInfoStruct) alertRuleMap.get(alertRule);
			processQryAlertRule(alertRuleInfo);
			alertRuleMap.put(alertRule, alertRuleInfo);
		}
		
	}

	/**
	 * This method executes QryAlertRule query to process QryAlertRule.
	 * 
	 * @param alertRuleInfo
	 */
	public void processQryAlertRule(AlertRuleInfoStruct alertRuleInfo) {
		Statement stmt = null;
		ResultSet rs = null;
		
		String qryAlertRuleSQLStmt = prepareQryAlertRuleSQL(alertRuleInfo);
		if (!failureList.isEmpty()) return;

		alertRuleInfo.calcCnt = 0;
		alertRuleInfo.seqCnt = 0;
		try {
			logger.debug("Executing QryAlertRule query ...." + qryAlertRuleSQLStmt);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qryAlertRuleSQLStmt);
			if (rs != null) {
				while (rs.next()) {												
					QryAlertRule qryAlertRule = buildQryAlertRule(rs);
					alertRuleInfo.seqCnt += qryAlertRule.getSeqcnt();

					//build  presnIdINString and execPresnSeqNumINString
					alertReportParameters.addPresnId(new Integer(qryAlertRule.getPresnId()));
					alertReportParameters.addExecPresnSeqNum(new Integer(qryAlertRule.getExecPresnSeqNum()).toString());
					qryAlertRuleList.add(qryAlertRule);
				}
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryAlertRuleSQLStmt}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryAlertRuleSQLStmt}), sx));
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
	}

	/**
	 * This method builds QryAlertRule parameters.
	 * 
	 * @param rs
	 * @return QryAlertRule
	 * @throws SQLException
	 */
	private QryAlertRule buildQryAlertRule(ResultSet rs) throws SQLException {
		QryAlertRule qryAlertRule = new QryAlertRule();

		qryAlertRule.setAlertRule(rs.getString("ALERT_RULE"));
		qryAlertRule.setPartiRefId(rs.getInt("PARTI_REF_ID"));
		qryAlertRule.setFileVerifInd(rs.getString("FILE_VERIF_IND"));
		qryAlertRule.setDataExtrctInd(rs.getString("DATA_EXTRCT_IND"));
		qryAlertRule.setDataCalcInd(rs.getString("DATA_CALC_IND"));
		qryAlertRule.setAlertRuleType(rs.getString("ALERT_RULE_TYPE"));
		qryAlertRule.setCalcRule(rs.getString("CALC_RULE"));
		qryAlertRule.setWarningInd(rs.getString("WARNING_IND"));
		qryAlertRule.setAvgInd(rs.getString("AVG_IND"));
		qryAlertRule.setAlertMsgInd(rs.getString("ALERT_MSG_IND"));
		qryAlertRule.setAlertSeqNumInd(rs.getString("ALERT_SEQ_NUM_IND"));
		qryAlertRule.setAlertTimeInd(rs.getString("ALERT_TIME_IND"));
		qryAlertRule.setAlertDashFreshInd(rs.getString("ALERT_DASH_FRESH_IND"));
		qryAlertRule.setAlertDesc(rs.getString("ALERT_DESC"));
		qryAlertRule.setAlertKeyLvl(rs.getInt("ALERT_KEY_LVL"));
		qryAlertRule.setAlertKey1NameAt(0,rs.getString("ALERT_KEY1_NAME"));
		qryAlertRule.setAlertKey1NameAt(1,rs.getString("ALERT_KEY2_NAME"));
		qryAlertRule.setAlertKey1NameAt(2,rs.getString("ALERT_KEY3_NAME"));
		qryAlertRule.setAlertKey1NameAt(3,rs.getString("ALERT_KEY4_NAME"));
		qryAlertRule.setAlertKey1NameAt(4,rs.getString("ALERT_KEY5_NAME"));
		qryAlertRule.setAlertFileCt(rs.getInt("ALERT_FILE_CT"));
		qryAlertRule.setDivisionNameKeyLvl(rs.getInt("DIVISION_NAME_KEY_LVL"));
		qryAlertRule.setPresnId(rs.getInt("PRESN_ID"));
		qryAlertRule.setWebid(rs.getString("WEBID"));
		qryAlertRule.setExecPresnSeqNum(rs.getInt("EXEC_PRESN_SEQ_NUM"));
		qryAlertRule.setFileSeqNumInd(rs.getString("FILE_SEQ_NUM_IND"));
		qryAlertRule.setPresnDataTbl(rs.getString("PRESN_DATA_TBL"));
		qryAlertRule.setDataKeyLvl(rs.getInt("DATA_KEY_LVL"));
		qryAlertRule.setKeyDdlNameAt(0,rs.getString("KEY1_DDL_NAME"));
		qryAlertRule.setMainKey1Ind(rs.getString("MAIN_KEY1_IND"));
		qryAlertRule.setKeyHeaderAt(0,rs.getString("KEY1_HEADER"));
		qryAlertRule.setKeyHdLinkIndAt(0,rs.getString("KEY1_HD_LINK_IND"));
		qryAlertRule.setKeyHdLinkNumAt(0,rs.getInt("KEY1_HD_LINK_NUM"));
		qryAlertRule.setKeyHdParmIndAt(0,rs.getString("KEY1_HD_PARM_IND"));
		qryAlertRule.setKeyDataLinkIndAt(0,rs.getString("KEY1_DATA_LINK_IND"));
		qryAlertRule.setKeyDataLinkNumAt(0,rs.getInt("KEY1_DATA_LINK_NUM"));
		qryAlertRule.setKeyParmIndAt(0,rs.getString("KEY1_PARM_IND"));
		qryAlertRule.setKeyDescIndAt(0,rs.getString("KEY1_DESC_IND"));
		qryAlertRule.setKeyMouseOverNumAt(0,rs.getInt("KEY1_MOUSE_OVER_NUM"));
		qryAlertRule.setKeyDdlNameAt(1,rs.getString("KEY2_DDL_NAME"));
		qryAlertRule.setKeyHeaderAt(1,rs.getString("KEY2_HEADER"));
		qryAlertRule.setKeyHdLinkIndAt(1,rs.getString("KEY2_HD_LINK_IND"));
		qryAlertRule.setKeyHdLinkNumAt(1,rs.getInt("KEY2_HD_LINK_NUM"));
		qryAlertRule.setKeyHdParmIndAt(1,rs.getString("KEY2_HD_PARM_IND"));
		qryAlertRule.setKeyDataLinkIndAt(1,rs.getString("KEY2_DATA_LINK_IND"));
		qryAlertRule.setKeyDataLinkNumAt(1,rs.getInt("KEY2_DATA_LINK_NUM"));
		qryAlertRule.setKeyParmIndAt(1,rs.getString("KEY2_PARM_IND"));
		qryAlertRule.setKeyDescIndAt(1,rs.getString("KEY2_DESC_IND"));
		qryAlertRule.setKeyMouseOverNumAt(1,rs.getInt("KEY2_MOUSE_OVER_NUM"));
		qryAlertRule.setKeyDdlNameAt(2,rs.getString("KEY3_DDL_NAME"));
		qryAlertRule.setKeyHeaderAt(2,rs.getString("KEY3_HEADER"));
		qryAlertRule.setKeyHdLinkIndAt(2,rs.getString("KEY3_HD_LINK_IND"));
		qryAlertRule.setKeyHdLinkNumAt(2,rs.getInt("KEY3_HD_LINK_NUM"));
		qryAlertRule.setKeyHdParmIndAt(2,rs.getString("KEY3_HD_PARM_IND"));
		qryAlertRule.setKeyDataLinkIndAt(2,rs.getString("KEY3_DATA_LINK_IND"));
		qryAlertRule.setKeyDataLinkNumAt(2,rs.getInt("KEY3_DATA_LINK_NUM"));
		qryAlertRule.setKeyParmIndAt(2,rs.getString("KEY3_PARM_IND"));
		qryAlertRule.setKeyDescIndAt(2,rs.getString("KEY3_DESC_IND"));
		qryAlertRule.setKeyMouseOverNumAt(2,rs.getInt("KEY3_MOUSE_OVER_NUM"));
		qryAlertRule.setKeyDdlNameAt(3,rs.getString("KEY4_DDL_NAME"));
		qryAlertRule.setKeyHeaderAt(3,rs.getString("KEY4_HEADER"));
		qryAlertRule.setKeyHdLinkIndAt(3,rs.getString("KEY4_HD_LINK_IND"));
		qryAlertRule.setKeyHdLinkNumAt(3,rs.getInt("KEY4_HD_LINK_NUM"));
		qryAlertRule.setKeyHdParmIndAt(3,rs.getString("KEY4_HD_PARM_IND"));
		qryAlertRule.setKeyDataLinkIndAt(3,rs.getString("KEY4_DATA_LINK_IND"));
		qryAlertRule.setKeyDataLinkNumAt(3,rs.getInt("KEY4_DATA_LINK_NUM"));
		qryAlertRule.setKeyParmIndAt(3,rs.getString("KEY4_PARM_IND"));
		qryAlertRule.setKeyDescIndAt(3,rs.getString("KEY4_DESC_IND"));
		qryAlertRule.setKeyMouseOverNumAt(3,rs.getInt("KEY4_MOUSE_OVER_NUM"));
		qryAlertRule.setKeyDdlNameAt(4,rs.getString("KEY5_DDL_NAME"));
		qryAlertRule.setKeyHeaderAt(4,rs.getString("KEY5_HEADER"));
		qryAlertRule.setKeyHdLinkIndAt(4,rs.getString("KEY5_HD_LINK_IND"));
		qryAlertRule.setKeyHdLinkNumAt(4,rs.getInt("KEY5_HD_LINK_NUM"));
		qryAlertRule.setKeyHdParmIndAt(4,rs.getString("KEY5_HD_PARM_IND"));
		qryAlertRule.setKeyDataLinkIndAt(4,rs.getString("KEY5_DATA_LINK_IND"));
		qryAlertRule.setKeyDataLinkNumAt(4,rs.getInt("KEY5_DATA_LINK_NUM"));
		qryAlertRule.setKeyParmIndAt(4,rs.getString("KEY5_PARM_IND"));
		qryAlertRule.setKeyDescIndAt(4,rs.getString("KEY5_DESC_IND"));
		qryAlertRule.setKeyMouseOverNumAt(4,rs.getInt("KEY5_MOUSE_OVER_NUM"));
		qryAlertRule.setAlertDataName(rs.getString("ALERT_DATA_NAME"));
		qryAlertRule.setAlertHdName(rs.getString("ALERT_HD_NAME"));
		qryAlertRule.setAlertHdLinkInd(rs.getString("ALERT_HD_LINK_IND"));
		qryAlertRule.setAlertHdLinkNum(rs.getInt("ALERT_HD_LINK_NUM"));
		qryAlertRule.setAlertHdParmInd(rs.getString("ALERT_HD_PARM_IND"));
		qryAlertRule.setAlertDataLinkInd(rs.getString("ALERT_DATA_LINK_IND"));
		qryAlertRule.setAlertDataLinkNum(rs.getInt("ALERT_DATA_LINK_NUM"));
		qryAlertRule.setAlertParmInd(rs.getString("ALERT_PARM_IND"));
		qryAlertRule.setAlertDescInd(rs.getString("ALERT_DESC_IND"));
		qryAlertRule.setAlertMouseOverNum(rs.getInt("ALERT_MOUSE_OVER_NUM"));
		qryAlertRule.setKey1Seq(rs.getInt("KEY1_SEQ"));
		qryAlertRule.setTotInd(rs.getString("P_TOT_IND"));
		qryAlertRule.setCalccnt(rs.getInt("CALCCNT"));
		qryAlertRule.setSeqcnt(rs.getInt("SEQCNT"));
		qryAlertRule.setTblProcDateDdlName(rs.getString("TBL_PROC_DATE_DDL_NAME"));
		qryAlertRule.setKeyLinkDdlNameAt(0,rs.getString("KEY1_LINK_DDL_NAME"));
		qryAlertRule.setKeyLinkToPgmAt(0,rs.getString("KEY1_LINK_TO_PGM"));
		qryAlertRule.setKeyLinkPresnIdAt(0,rs.getInt("KEY1_LINK_PRESN_ID"));
		qryAlertRule.setKeyLinkTblKeyNameAt(0,rs.getString("KEY1_LINK_TBL_KEY_NAME"));
		qryAlertRule.setKeyLinkTblKeyDataAt(0,rs.getString("KEY1_LINK_TBL_KEY_DATA"));
		qryAlertRule.setKeyLinkTblNameAt(0,rs.getString("KEY1_LINK_TBL_NAME"));
		qryAlertRule.setKeyLinkDdlNameAt(1,rs.getString("KEY2_LINK_DDL_NAME"));
		qryAlertRule.setKeyLinkToPgmAt(1,rs.getString("KEY2_LINK_TO_PGM"));
		qryAlertRule.setKeyLinkPresnIdAt(1,rs.getInt("KEY2_LINK_PRESN_ID"));
		qryAlertRule.setKeyLinkTblKeyNameAt(1,rs.getString("KEY2_LINK_TBL_KEY_NAME"));
		qryAlertRule.setKeyLinkTblKeyDataAt(1,rs.getString("KEY2_LINK_TBL_KEY_DATA"));
		qryAlertRule.setKeyLinkTblNameAt(1,rs.getString("KEY2_LINK_TBL_NAME"));
		qryAlertRule.setKeyLinkDdlNameAt(2,rs.getString("KEY3_LINK_DDL_NAME"));
		qryAlertRule.setKeyLinkToPgmAt(2,rs.getString("KEY3_LINK_TO_PGM"));
		qryAlertRule.setKeyLinkPresnIdAt(2,rs.getInt("KEY3_LINK_PRESN_ID"));
		qryAlertRule.setKeyLinkTblKeyNameAt(2,rs.getString("KEY3_LINK_TBL_KEY_NAME"));
		qryAlertRule.setKeyLinkTblKeyDataAt(2,rs.getString("KEY3_LINK_TBL_KEY_DATA"));
		qryAlertRule.setKeyLinkTblNameAt(2,rs.getString("KEY3_LINK_TBL_NAME"));
		qryAlertRule.setKeyLinkDdlNameAt(3,rs.getString("KEY4_LINK_DDL_NAME"));
		qryAlertRule.setKeyLinkToPgmAt(3,rs.getString("KEY4_LINK_TO_PGM"));
		qryAlertRule.setKeyLinkPresnIdAt(3,rs.getInt("KEY4_LINK_PRESN_ID"));
		qryAlertRule.setKeyLinkTblKeyNameAt(3,rs.getString("KEY4_LINK_TBL_KEY_NAME"));
		qryAlertRule.setKeyLinkTblKeyDataAt(3,rs.getString("KEY4_LINK_TBL_KEY_DATA"));
		qryAlertRule.setKeyLinkTblNameAt(3,rs.getString("KEY4_LINK_TBL_NAME"));
		qryAlertRule.setKeyLinkDdlNameAt(4,rs.getString("KEY5_LINK_DDL_NAME"));
		qryAlertRule.setKeyLinkToPgmAt(4,rs.getString("KEY5_LINK_TO_PGM"));
		qryAlertRule.setKeyLinkPresnIdAt(4,rs.getInt("KEY5_LINK_PRESN_ID"));
		if (alertReportParameters.getWebPageId().equals(PAGE_11)) {
			qryAlertRule.setPresnSeqNum(rs.getInt("PRESN_SEQ_NUM"));
			qryAlertRule.setSumyPresnName(rs.getString("SUMY_PRESN_NAME"));
			qryAlertRule.setCntSumyPresnName(rs.getString("CNT_SUMY_PRESN_NAME"));
		}
		if (alertReportParameters.getWebPageId().equals(PAGE_14)) {
			qryAlertRule.setPresnSeqNum(rs.getInt("RULE_PRESN_SEQ_NUM"));
		}
		return qryAlertRule;
	}

	/**
	 * This method prepares QryAlertHist for all SQL statements.
	 * 
	 * @return String
	 */
	private String prepareQryAlertHistAllSQL() {
		MessageFormat mf = null;
		
		String [] args1 = getQryHistArguments(1);
		String [] args = new String[5];
		for (int i=0;i<args1.length;i++){
			args[i]=args1[i];
		}
		
		int pageSize = alertReportParameters.getPageSize();
		int page = alertReportParameters.getPage();
		int startIndex = ((page - 1) * pageSize) + 1;
		int endIndex = ((page - 1) * pageSize) + pageSize;
		if (alertReportParameters.getDispatch() == null) {
			args[4] = " where rn between " + startIndex + " and " + endIndex;
    	} else {
	    	if ("createReport".equals(alertReportParameters.getDispatch()) || "emailReport".equals(alertReportParameters.getDispatch())) {
	    		args[4] = " ";
			} else {
				args[4] = " where rn between " + startIndex + " and " + endIndex;
			}
    	}
		
		alertReportParameters.setPageshow(page);
		
		mf = new MessageFormat(qryAlertHistSQL1);
		String qryAlertHistSQLStmt = mf.format(args);
		logger.debug("qryAlertHist =" + qryAlertHistSQLStmt);
		
		return qryAlertHistSQLStmt;
	}

	/**
	 * This method sets the pages for qryAlertHist count.
	 */
	private void setPages(){
		Statement stmt = null;
		ResultSet rs = null;
		MessageFormat mf = null;
		String [] args = getQryHistArguments(1);
		String qryAlertHistCountSQLStmt = null;
		int pageSize = alertReportParameters.getPageSize();
		int totalRows =0;
		
		try {
			mf = new MessageFormat(qryAlertHistCount);
			qryAlertHistCountSQLStmt = mf.format(args);
			logger.debug("qryAlertHist count =" + qryAlertHistCountSQLStmt);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qryAlertHistCountSQLStmt);
			if (rs != null && rs.next()) {
				totalRows = rs.getInt(1);
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryAlertHistCountSQLStmt}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryAlertHistCountSQLStmt}), sx));
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		
		int pages = totalRows / pageSize;
		if ((totalRows % pageSize) != 0) {
			pages++;
		}
		if ((totalRows <= pageSize) || (pageSize == 0)) {
			alertReportParameters.setPages(0); // don't show page related buttons
		}
		alertReportParameters.setPages(pages);
	}
	
	/**
	 * Private method will return the min date for the rabc_alert_hist.
	 * 
	 * @return
	 */
	public MyDate getMinDate(){
		Statement stmt = null;
		ResultSet rs = null;
		MessageFormat mf = null;
		
		String [] args1 = getQryHistArguments(0);
		String [] args = new String[5];
		for (int i=0;i<args1.length;i++){
			args[i]=args1[i];
		}
		args[4] = alertReportParameters.getStartDate().toString();
		
		String qryAlertHistMinDateSQLStmt = null;
		MyDate minDate = null;
		try {
			mf = new MessageFormat(qryAlertHistMinDate);
			qryAlertHistMinDateSQLStmt = mf.format(args);
			logger.debug("qryAlertHist min date = " + qryAlertHistMinDateSQLStmt);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qryAlertHistMinDateSQLStmt);
			
			if (rs != null) {
				while (rs.next()) {
					Date tempDate = rs.getDate(1);
					if (tempDate!=null){
						minDate = new MyDate(tempDate);	
					}
				}
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryAlertHistMinDateSQLStmt}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryAlertHistMinDateSQLStmt}), sx));
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		
		return minDate;
	}
	
	/**
	 * Private method will return the max date for the rabc_alert_hist.
	 * 
	 * @return
	 */
	public MyDate getMaxDate(){
		Statement stmt = null;
		ResultSet rs = null;
		MessageFormat mf = null;
		
		String [] args1 = getQryHistArguments(0);
		String [] args = new String[5];
		for (int i=0;i<args1.length;i++){
			args[i]=args1[i];
		}
		args[4] = alertReportParameters.getEndDate().toString();
		String qryAlertHistMaxDateSQLStmt = null;
		MyDate maxDate = null;
		try {
			mf = new MessageFormat(qryAlertHistMaxDate);
			qryAlertHistMaxDateSQLStmt = mf.format(args);
			logger.debug("qryAlertHist max date =" + qryAlertHistMaxDateSQLStmt);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qryAlertHistMaxDateSQLStmt);
			
			if (rs != null) {
				while (rs.next()) {
					Date tempDate = rs.getDate(1);
					if (tempDate!=null){
						maxDate = new MyDate(tempDate);	
					}
				}
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryAlertHistMaxDateSQLStmt}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryAlertHistMaxDateSQLStmt}), sx));
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		
		return maxDate;
	}

	/**
	 * Method to get the qryHist arguments.
	 * 
	 * @param alertRuleInfo
	 * @return
	 */
	private String[] getQryHistArguments(int param){
		Set set = null; 
		Iterator iter = null; 
		AlertRuleInfoStruct alertRuleInfo = null;
		String alertRule = null;
		String [] args = new String[4];
		String arg_0 = new String();
		String arg_1 = new String();
		String arg_2 = new String();
		String arg_3 = new String();
		int alertRuleCount = 0;
		
		logger.debug("Preparing qryAlertHist SQL statment ....");

		if (alertReportParameters.getWebPageId().equals(PAGE_14)) {
			// PAGE_14 request is being executed hence set arg_0 to blank
			arg_0 = "";
		} else {
			// PAGE_11 request is being executed hence set arg_2 accordingly.
			if ((alertReportParameters.getTimeStampInd()!= null) && (alertReportParameters.getTimeStampInd().length() != 0)) {
				arg_0 = ",rabc_cntrl_run  c";
			} else {
				arg_0 = "";
			}
		}
		
		String alertRuleList = null;
		set = alertRuleMap.keySet();
		iter = set.iterator();
		while(iter.hasNext()) {			
			alertRuleInfo = (AlertRuleInfoStruct) alertRuleMap.get((String)iter.next());
			
			if ("".equals(arg_1)){
				arg_1 = alertRuleInfo.partiRefIds.substring(1);
			}else {
				arg_1 += "," + alertRuleInfo.partiRefIds.substring(1);
			}
			
			if (alertRuleList == null){
				alertRuleList = alertRuleInfo.alertRules.substring(1);
			}else {
				alertRuleList += "," + alertRuleInfo.alertRules.substring(1);
			}
			
			alertRuleCount++;
		}

		arg_2 = "";

		if (alertReportParameters.getWebPageId().equals(PAGE_14)) {
			// PAGE_14 request is being executed hence set arg_0 to blank
			arg_2 = arg_2 + "AND h.file_seq_num = " + alertReportParameters.getFileSeqNum().toString() + " ";
			MyDate sDate = new MyDate(alertReportParameters.getStartDate());
			MyDate eDate = new MyDate(alertReportParameters.getStartDate());

			sDate.doAdd(-90);
			eDate.doAdd(90);
			arg_2 = arg_2 + "AND proc_date >= to_date('" + sDate.toString() + "','mm/dd/yyyy') AND proc_date <= to_date('" + eDate.toString() + "','mm/dd/yyyy') ";
			arg_3 = "";
		} else {
			// PAGE_11 request is being executed hence set arg_2 accordingly.
			if ((alertReportParameters.getTimeStampInd() != null) && (alertReportParameters.getTimeStampInd().length() != 0)) {
				if (!alertReportParameters.getTimeStampInd().equalsIgnoreCase("No")) {
					arg_2 = "AND c.alert_rule_run_dt = to_date('" + alertReportParameters.getTimeStampInd() + "' ,'mm/dd/yyyy') ";
				}

				arg_2 = arg_2 + "AND c.alert_rule in (" + alertRuleList + ") AND c.proc_date = h.proc_date ";
				if (alertReportParameters.getRelatedAlertInd().equals("Y")) {
					arg_2 = arg_2 + "AND c.severe_lvl_ind in ('0','N') ";
				} else {
					arg_2 = arg_2 + "AND c.severe_lvl_ind = '0' ";
				}
				arg_2 = arg_2 + "AND (h.file_seq_num = c.file_seq_num or (h.file_seq_num IS NULL AND c.file_seq_num IS NULL)) ";
				
				/*
				 * CONDITION TO BE EXAMINED
				 */
				if (alertRuleCount==1){
					if (alertRuleInfo.divisionNameKeyLvl > 0) {
						if (alertReportParameters.getRelatedAlertInd().equals("Y")) {				
							arg_2 = arg_2 + "AND (c.key1 = h.alert_key" + alertRuleInfo.divisionNameKeyLvl +" or c.key1 is null) ";
						} else {
							arg_2 = arg_2 + "AND c.key1 = h.alert_key" + alertRuleInfo.divisionNameKeyLvl + " ";
						}
					} else {
						arg_2 = arg_2 + "AND c.key1 is null ";
					}
				}else {
					// Code to fix the issue of data in case of control point
					arg_2 = arg_2 + "AND c.key1 = h.alert_key1 ";
				}
			}

			/*
			 * CONDITION TO BE EXAMINED
			 */
			String key1List = new String();
			if (alertRuleCount==1){
				if ((!alertReportParameters.getDivisionName().equals("ALL")) && (alertRuleInfo.divisionNameKeyLvl > 0)) { 
					arg_2 = arg_2 + "and (alert_key"+ alertRuleInfo.divisionNameKeyLvl + " in (" + alertReportParameters.getKey1s() +") or alert_key" + alertRuleInfo.divisionNameKeyLvl + " is null) ";
				}
				if (alertRuleInfo.divisionNameKeyLvl > 1) {
					if (!alertReportParameters.getKeysAt(0).equals("")) {
						arg_2 = arg_2 + "and (upper(alert_key1) = upper('" + alertReportParameters.getKeysAt(0) + "') or alert_key1 is null) ";
					}
				}
			}else {
				if (!"ALL".equals(alertReportParameters.getDivisionName())){
					if (alertReportParameters.getDivisionName()!=null){
						String divisionNamesList=null;
						if (alertReportParameters.getDivisionName().indexOf(" ")!=-1){
							StringTokenizer divisionTokens = new StringTokenizer(alertReportParameters.getDivisionName()," ");
							while (divisionTokens.hasMoreTokens()){
								if (divisionNamesList==null){
									divisionNamesList = "'" + divisionTokens.nextToken() + "'";
								}else {
									divisionNamesList = divisionNamesList +  ",'" + divisionTokens.nextToken() + "'";
								}
							}
						}else {
							divisionNamesList = "'" + alertReportParameters.getDivisionName() + "'";
						}
						arg_2 = arg_2 + "and alert_key1 IN (" + divisionNamesList +  ") ";
					}
					
					
				}
				/* Code to fix the issue of data in case of control point
				if (!"".equals(alertReportParameters.getKeysAt(0))) {
					arg_2 = arg_2 + "and alert_key1 = '" + alertReportParameters.getKeysAt(0) + "' ";
				}*/
			}
			
			if (!alertReportParameters.getKeysAt(1).equals("")) {
				arg_2 = arg_2 + "and upper(alert_key2) = upper('" + alertReportParameters.getKeysAt(1) + "') "; 
			}
			
			if (!alertReportParameters.getKeysAt(2).equals("")) {
				arg_2 = arg_2 + "and upper(alert_key3) = upper('" + alertReportParameters.getKeysAt(2) + "') "; 
			}
			
			if (!alertReportParameters.getKeysAt(3).equals("")) {
				arg_2 = arg_2 + "and upper(alert_key4) = upper('" + alertReportParameters.getKeysAt(3) + "') "; 
			}
			
			if (!alertReportParameters.getKeysAt(4).equals("")) {
				arg_2 = arg_2 + "and upper(alert_key5) = upper('" + alertReportParameters.getKeysAt(4) + "') "; 
			}
			
			if (alertReportParameters.getAlertTimeInd()!=null){
				if ("".equals(alertReportParameters.getAlertTimeInd())){
					if (alertReportParameters.getAlertTimeValue()!=null && !"".equals(alertReportParameters.getAlertTimeValue())){
						arg_2 = arg_2 + "and alert_trend_time = '" + alertReportParameters.getAlertTimeValue() + "' "; 
					}
				}else if ("B".equals(alertReportParameters.getAlertTimeInd())){
					if (alertReportParameters.getAlertTimeValueBR()!=null && !"-1".equals(alertReportParameters.getAlertTimeValueBR())){
						if (!"0".equals(alertReportParameters.getAlertTimeValueBR()) && !"".equals(alertReportParameters.getAlertTimeValueBR())){
							arg_2 = arg_2 + "and alert_trend_time = '" + Integer.parseInt(alertReportParameters.getAlertTimeValueBR()) + "' "; 
						}
					}
				}else if ("D".equals(alertReportParameters.getAlertTimeInd())){
					if (alertReportParameters.getAlertTimeValueWD()!=null && !"-1".equals(alertReportParameters.getAlertTimeValueWD())){
						if (!"0".equals(alertReportParameters.getAlertTimeValueWD()) && !"".equals(alertReportParameters.getAlertTimeValueWD())){
							arg_2 = arg_2 + "and alert_trend_time = '" + alertReportParameters.getAlertTimeValueWD() + "' "; 
						}
					}
				}
			}
			
			if ((alertReportParameters.getAlertItem() != null) && (!"0".equals(alertReportParameters.getAlertItem()))) {
				arg_2 = arg_2 + "and upper(alert_item) = upper('" + alertReportParameters.getAlertItem() + "') ";
			}
			
			/*
			 * Condition added for the dates
			 */
			if (param != 0){
				if (alertReportParameters.getStartDate()!=null){
					arg_2 = arg_2 + " and h.proc_date >= to_date('" + alertReportParameters.getStartDate().toString() + "','mm/dd/yyyy') ";
				}
				if (alertReportParameters.getEndDate()!=null){
					arg_2 = arg_2 + " and h.proc_date <= to_date('" + alertReportParameters.getEndDate().toString() + "','mm/dd/yyyy') ";
				}
			}

			if ((alertReportParameters.getCntrlPtCd().length() != 0)) {
				arg_3 = " order by alert_key1,h.parti_ref_id, h.proc_date,alert_key2, alert_key3, alert_key4, alert_key5, h.file_seq_num ,h.alert_item";
			} else {
				arg_3 = " order by alert_key1, h.proc_date,alert_key2, alert_key3, alert_key4, alert_key5, h.file_seq_num,h.alert_item ";
			}
		}
		args[0] = arg_0;
		args[1]=arg_1;
		args[2]=arg_2;
		args[3]=arg_3;
		
		return args;
	}
	
	/**
	 * This method executes qry Alert Hist All for all alert rules.
	 */
	public void executeQryAlertHistAll() {
		List tmpQryAlertHistAll = null;
		AlertHist alertHist = null;
		int i = 0;
		int size = 0;
		// check whether data exist in the range requested
		int condCounter = 0;
		int maxCounter = 0;
		
		logger.debug("Execute qry Alert Hist All for all alert rules ...");
		
		tmpQryAlertHistAll = getQryAlertHistAll(alertRuleMap);
		if (!failureList.isEmpty()) return;
		
		size = tmpQryAlertHistAll.size();
		for(i=0;i<size;i++) {
			qryAlertHistAllList.add((AlertHist)tmpQryAlertHistAll.get(i));
		}
		size = qryAlertHistAllList.size();

		// Key 2 condition
		if (alertReportParameters.getKeysAt(1).length() != 0) {
			maxCounter = maxCounter + 1;
		}
		// fileSeqNum condition
		if ((alertReportParameters.getFileSeqNum()!=null) && alertReportParameters.getFileSeqNum().intValue() != -1) {
			maxCounter = maxCounter + 1;
		}
		// date condition
		maxCounter = maxCounter + 1;
		MyDate procDate = null;

		if (qryAlertRuleList.isEmpty()) {
			alertReportParameters.setDataPresent("N");
			return;
		}

		if (alertReportParameters.getWebPageId().equals(PAGE_14)) {
			alertReportParameters.setDataPresent("Y");
			if (qryAlertHistAllList.isEmpty()) {
				// for Page 14 no check with fileSeqNum, key2, date required, hence set dataPresent to N
				alertReportParameters.setDataPresent("N");
			}
			return;
		}


		// for Page 11, set dataPresent accordingly
		alertReportParameters.setDataPresent("N");;
		for(i = 0; i < size; i++) {
			alertHist = (AlertHist) qryAlertHistAllList.get(i);
			condCounter = 0;
			// Key 2 condition
			if (!alertReportParameters.getKeysAt(1).equals("")) {
				if (alertHist.getAlertKeyAt(1).toUpperCase().equals(alertReportParameters.getKeysAt(1))) {
					condCounter = condCounter + 1;
				}
			}
			// fileSeqNum condition
			if ((alertReportParameters.getFileSeqNum()!=null) && alertReportParameters.getFileSeqNum().intValue() != -1) {
				if ((alertReportParameters.getFileSeqNum()!=null) && alertReportParameters.getFileSeqNum().intValue() == alertHist.getFileSeqNum()) {
					condCounter = condCounter + 1;
				}
			}
			// date condition
			procDate = new MyDate(alertHist.getProcDate());
			if (alertReportParameters.getEndDate().toString().equals("")) {
				// compare only start date				
				if (procDate.compareTo(alertReportParameters.getStartDate()) == 0) { 
					condCounter = condCounter + 1;
				}
			} else {
				// compare with start date and end date
				if (((procDate.compareTo(alertReportParameters.getStartDate()) == 0) || (procDate.compareTo(alertReportParameters.getStartDate()) > 0)) && 
					((procDate.compareTo(alertReportParameters.getEndDate()) == 0) || (procDate.compareTo(alertReportParameters.getEndDate()) < 0))) {
					condCounter = condCounter + 1;
				}
			}
			if (maxCounter == condCounter) {
				// match record in AlertHist found, hence set NoData to "N" and break
				alertReportParameters.setDataPresent("Y");;
				break;
			}
		}
		
	}

	/**
	 * This method to get the QryAlertHist for all SQL statemants.
	 * 
	 * @param alertRuleMap
	 * @return List
	 */
	public List getQryAlertHistAll(HashMap alertRuleMap) {
		Statement stmt = null;
		ResultSet rs = null;
		List args = new ArrayList();
		setPages();
		String qryAlertHistAllSQLStmt = prepareQryAlertHistAllSQL();
		if (!failureList.isEmpty()) return null;
		AlertHistDAO alertHistDAO = new AlertHistDAO();
		return alertHistDAO.get(connection, failureList, args, qryAlertHistAllSQLStmt);
	}

	/**
	 * This method prepares Arguments for qryAlertMsg SQL to execute QryAlertMsg.
	 */
	public void executeQryAlertMsg() {
		// prepare arguments
		logger.debug("Preparing Arguments for qryAlertMsg SQL");
		List args = new ArrayList();
		String arg = "";
		
		arg = "";
		args.add(alertReportParameters.getAlertRules());
		arg = "";
		
		if (alertReportParameters.getWebPageId().equals(PAGE_14)) {
			// Page 14 is being processed, hence set arguments accordingly.
			args.add("AND m.file_seq_num = " + alertReportParameters.getFileSeqNum().toString() + " ");
			MyDate sDate = new MyDate(alertReportParameters.getStartDate());
			MyDate eDate = new MyDate(alertReportParameters.getStartDate());

			sDate.doAdd(-90);
			eDate.doAdd(90);
			args.add("AND proc_date >= to_date('" + sDate.toString() + "','mm/dd/yyyy') AND proc_date <= to_date('" + eDate.toString() + "','mm/dd/yyyy') ");			
		} else {
			// Page 11 is being processed, hence set argumments accordingly
			if (alertReportParameters.getEndDate() == null) {
				arg = "AND proc_date = to_date('" + alertReportParameters.getStartDate().toString() + "','mm/dd/yyyy') "; 
			} else {
				arg = "AND proc_date >= to_date('" + alertReportParameters.getStartDate().toString() + "','mm/dd/yyyy')" + " AND proc_date <= to_date('" + alertReportParameters.getEndDate().toString() + "','mm/dd/yyyy') ";
			}
			args.add(arg);
			arg = "";
			if ((alertReportParameters.getTimeStampInd() != null) && (alertReportParameters.getTimeStampInd().length() != 0) && (!alertReportParameters.getTimeStampInd().equalsIgnoreCase("No"))) {
				arg = "AND alert_rule_run_dt = to_date('" + alertReportParameters.getTimeStampInd() + "' ,'mm/dd/yyyy') ";
			}
		}
		
		String procDateInString = null;
		String key1InString = null;
		String key2InString = null;
		String key3InString = null;
		String key4InString = null;
		String key5InString = null;
		String alertItemInString = null;
		List procDateList = new ArrayList();
		List key1List = new ArrayList();
		List key2List = new ArrayList();
		List key3List = new ArrayList();
		List key4List = new ArrayList();
		List key5List = new ArrayList();
		List alertItemList = new ArrayList();
		
		int qryAlertHistAllListSize = qryAlertHistAllList.size();
		for (int histSize = 0 ; histSize <qryAlertHistAllListSize;histSize++){
			AlertHist alertHist = (AlertHist)qryAlertHistAllList.get(histSize);

			if (alertHist.getProcDate() != null){
				MyDate procDate = new MyDate(alertHist.getProcDate());
				if (procDateList.isEmpty()){
					procDateList.add(procDate.toString());
				} else {
					if (!procDateList.contains(procDate.toString())){
						procDateList.add(procDate.toString());
					}
				}
			}
			if (alertHist.getAlertKeyAt(0)!=null && !"".equals(alertHist.getAlertKeyAt(0))){
				if (key1List.isEmpty()) {
					key1List.add(alertHist.getAlertKeyAt(0));
				}else {
					if (!key1List.contains(alertHist.getAlertKeyAt(0))){
						key1List.add(alertHist.getAlertKeyAt(0));
					}
				}
			}
			if (alertHist.getAlertKeyAt(1)!=null && !"".equals(alertHist.getAlertKeyAt(1))){
				if (key2List.isEmpty()) {
					key2List.add(alertHist.getAlertKeyAt(1));
				}else {
					if (!key2List.contains(alertHist.getAlertKeyAt(1))){
						key2List.add(alertHist.getAlertKeyAt(1));
					}
				}
			}
			if (alertHist.getAlertKeyAt(2)!=null && !"".equals(alertHist.getAlertKeyAt(2))){
				if (key3List.isEmpty()) {
					key3List.add(alertHist.getAlertKeyAt(2));
				}else {
					if (!key3List.contains(alertHist.getAlertKeyAt(2))){
						key3List.add(alertHist.getAlertKeyAt(2));
					}
				}
			}
			if (alertHist.getAlertKeyAt(3)!=null && !"".equals(alertHist.getAlertKeyAt(3))){
				if (key4List.isEmpty()) {
					key4List.add(alertHist.getAlertKeyAt(3));
				}else {
					if (!key4List.contains(alertHist.getAlertKeyAt(3))){
						key4List.add(alertHist.getAlertKeyAt(3));
					}
				}
			}
			if (alertHist.getAlertKeyAt(4)!=null && !"".equals(alertHist.getAlertKeyAt(4))){
				if (key5List.isEmpty()) {
					key5List.add(alertHist.getAlertKeyAt(4));
				}else {
					if (!key5List.contains(alertHist.getAlertKeyAt(4))){
						key5List.add(alertHist.getAlertKeyAt(4));
					}
				}
			}
			if (alertHist.getAlertItem()!=null && !"".equals(alertHist.getAlertItem())){
				if (alertItemList.isEmpty()){
					alertItemList.add(alertHist.getAlertItem());
				}else {
					if (!alertItemList.contains(alertHist.getAlertItem())){
						alertItemList.add(alertHist.getAlertItem());
					}
				}
			}
		}
		
		if (!procDateList.isEmpty()){
			int procDateListSize = procDateList.size();
			for (int j=0;j<procDateListSize;j++){
				if (procDateInString==null){
					procDateInString = " to_date('" + (String) procDateList.get(j) + "','mm/dd/yyyy') ";
				}else {
					procDateInString += " ,to_date('" + (String) procDateList.get(j) + "','mm/dd/yyyy') ";
				}
			}
			arg += "AND m.proc_date IN (" + procDateInString + ") ";
		}
		if (!key1List.isEmpty()){
			int key1ListSize = key1List.size();
			for (int j=0;j<key1ListSize;j++){
				if (key1InString==null){
					key1InString = "'" + (String) key1List.get(j) + "' ";
				}else {
					key1InString += ",'" + (String) key1List.get(j) + "' ";
				}
			}
			arg += "AND m.alert_data1 IN (" + key1InString + ") ";
		}
		if (!key2List.isEmpty()){
			int key2ListSize = key2List.size();
			for (int j=0;j<key2ListSize;j++){
				if (key2InString==null){
					key2InString = "'" + (String) key2List.get(j) + "' ";
				}else {
					key2InString += ",'" + (String) key2List.get(j) + "' ";
				}
			}
			arg += "AND m.alert_data2 IN (" + key2InString + ") ";
		}
		if (!key3List.isEmpty()){
			int key3ListSize = key3List.size();
			for (int j=0;j<key3ListSize;j++){
				if (key3InString==null){
					key3InString = "'" + (String) key3List.get(j) + "' ";
				}else {
					key3InString += ",'" + (String) key3List.get(j) + "' ";
				}
			}
			arg += "AND m.alert_data3 IN (" + key3InString + ") ";
		}
		if (!key4List.isEmpty()){
			int key4ListSize = key4List.size();
			for (int j=0;j<key4ListSize;j++){
				if (key4InString==null){
					key4InString = "'" + (String) key4List.get(j) + "' ";
				}else {
					key4InString += ",'" + (String) key4List.get(j) + "' ";
				}
			}
			arg += "AND m.alert_data4 IN (" + key4InString + ") ";
		}
		if (!key5List.isEmpty()){
			int key5ListSize = key5List.size();
			for (int j=0;j<key5ListSize;j++){
				if (key5InString==null){
					key5InString = "'" + (String) key5List.get(j) + "' ";
				}else {
					key5InString += ",'" + (String) key5List.get(j) + "' ";
				}
			}
			arg += "AND m.alert_data5 IN (" + key5InString + ") ";
		}
		if (!alertItemList.isEmpty()){
			int alertItemListSize = alertItemList.size();
			for (int j=0;j<alertItemListSize;j++){
				if (alertItemInString==null){
					alertItemInString = "'" + (String)alertItemList.get(j) + "' ";
				}else {
					alertItemInString += ",'" + (String)alertItemList.get(j) + "' ";
				}
			}
			arg += "AND m.alert_item IN (" + alertItemInString + ") ";
		}
		
		args.add(arg);
		AlertMsgDAO alertMsgDAO = new AlertMsgDAO();
		List tmpQryAlertMsgList = alertMsgDAO.get(connection, failureList, args, qryAlertMsgSQL);
		if (!tmpQryAlertMsgList.isEmpty()) {
			int i = 0;
			int size = tmpQryAlertMsgList.size();
			for (i=0;i<size;i++)
				qryAlertMsgList.add((AlertMsg)tmpQryAlertMsgList.get(i));
		}
	}

	/**
	 * This method processes Previous Data Query for each alert rule.
	 */
	public void executeQryPrevData() {
		Set set = null; 
		Iterator iter = null; 
		AlertRuleInfoStruct alertRuleInfo = null;
		
		logger.debug("Processing Previous Data Query for each alert rule ...");
		set = alertRuleMap.keySet();
		iter = set.iterator();
		previousDataList.clear();
		while(iter.hasNext()) {			
			alertRuleInfo = (AlertsReportSQLService.AlertRuleInfoStruct) alertRuleMap.get((String)iter.next());
			logger.debug("Processing Previous Data Query for alert rule = " + alertRuleInfo.alertRule);
			processQryPrevData(alertRuleInfo);
			if (!failureList.isEmpty()) return;
		}
	}

	/**
	 * This method prepares Arguments for qryPrevData SQL.
	 * 
	 * @param alertRuleInfo
	 */
	public void processQryPrevData(AlertRuleInfoStruct alertRuleInfo) {
		int i = 0;
		int size = 0;
		List args = new ArrayList();
		List tmpPrevDataList = null;
		String arg = "";
		
		// prepare arguments
		logger.debug("Preparing Arguments for qryPrevData SQL");
		arg = "";
		arg = arg + alertRuleInfo.partiRefIds.substring(1);
		args.add(arg);
		
		arg = "";
		int index = alertRuleInfo.divisionNameKeyLvl;
		if ((!alertReportParameters.getDivisionName().equals("ALL")) && (index > 0)) {
			arg = "and prev_alert_key" + index + " in (" + alertReportParameters.getKey1s() + ")";
		}
		args.add(arg);
		
		arg = "";
		if (index > 1) {
			if (!alertReportParameters.getKeysAt(0).equals("")) {
				arg = arg + "and prev_alert_key1 = '" + alertReportParameters.getKeysAt(0) + "'";
			}
		}
		args.add(arg);

		arg = "";
		if (alertReportParameters.getFileSeqNum().intValue() != -1) {
			arg = arg + " AND file_seq_num = " + alertReportParameters.getFileSeqNum() + " ";
		}
		if (alertReportParameters.getEndDate() == null) {
			arg = arg + " AND proc_date = to_date('" + alertReportParameters.getStartDate().toString() + "','mm/dd/yyyy')";
		} else {
			arg = arg + " AND proc_date >= to_date('"+alertReportParameters.getStartDate().toString()+"','mm/dd/yyyy') AND proc_date  <= to_date('"+alertReportParameters.getEndDate()+"','mm/dd/yyyy')";
		}
		
		String procDateInString = null;
		String key1InString = null;
		String key2InString = null;
		String key3InString = null;
		String key4InString = null;
		String key5InString = null;
		String alertItemInString = null;
		String alertTrendTimeInString = null; 
		List procDateList = new ArrayList();
		List key1List = new ArrayList();
		List key2List = new ArrayList();
		List key3List = new ArrayList();
		List key4List = new ArrayList();
		List key5List = new ArrayList();
		List alertItemList = new ArrayList();
		List alertTrendTimeList = new ArrayList();
		
		int qryAlertHistAllListSize = qryAlertHistAllList.size();
		for (int histSize = 0 ; histSize <qryAlertHistAllListSize;histSize++){
			AlertHist alertHist = (AlertHist)qryAlertHistAllList.get(histSize);

			if (alertHist.getProcDate() != null){
				MyDate procDate = new MyDate(alertHist.getProcDate());
				if (procDateList.isEmpty()){
					procDateList.add(procDate.toString());
				} else {
					if (!procDateList.contains(procDate.toString())){
						procDateList.add(procDate.toString());
					}
				}
			}
			if (alertHist.getAlertKeyAt(0)!=null && !"".equals(alertHist.getAlertKeyAt(0))){
				if (key1List.isEmpty()) {
					key1List.add(alertHist.getAlertKeyAt(0));
				}else {
					if (!key1List.contains(alertHist.getAlertKeyAt(0))){
						key1List.add(alertHist.getAlertKeyAt(0));
					}
				}
			}
			if (alertHist.getAlertKeyAt(1)!=null && !"".equals(alertHist.getAlertKeyAt(1))){
				if (key2List.isEmpty()) {
					key2List.add(alertHist.getAlertKeyAt(1));
				}else {
					if (!key2List.contains(alertHist.getAlertKeyAt(1))){
						key2List.add(alertHist.getAlertKeyAt(1));
					}
				}
			}
			if (alertHist.getAlertKeyAt(2)!=null && !"".equals(alertHist.getAlertKeyAt(2))){
				if (key3List.isEmpty()) {
					key3List.add(alertHist.getAlertKeyAt(2));
				}else {
					if (!key3List.contains(alertHist.getAlertKeyAt(2))){
						key3List.add(alertHist.getAlertKeyAt(2));
					}
				}
			}
			if (alertHist.getAlertKeyAt(3)!=null && !"".equals(alertHist.getAlertKeyAt(3))){
				if (key4List.isEmpty()) {
					key4List.add(alertHist.getAlertKeyAt(3));
				}else {
					if (!key4List.contains(alertHist.getAlertKeyAt(3))){
						key4List.add(alertHist.getAlertKeyAt(3));
					}
				}
			}
			if (alertHist.getAlertKeyAt(4)!=null && !"".equals(alertHist.getAlertKeyAt(4))){
				if (key5List.isEmpty()) {
					key5List.add(alertHist.getAlertKeyAt(4));
				}else {
					if (!key5List.contains(alertHist.getAlertKeyAt(4))){
						key5List.add(alertHist.getAlertKeyAt(4));
					}
				}
			}
			if (alertHist.getAlertItem()!=null && !"".equals(alertHist.getAlertItem())){
				if (alertItemList.isEmpty()){
					alertItemList.add(alertHist.getAlertItem());
				}else {
					if (!alertItemList.contains(alertHist.getAlertItem())){
						alertItemList.add(alertHist.getAlertItem());
					}
				}
			}
			
			if (alertHist.getAlertTrendTime()!=null && !"".equals(alertHist.getAlertTrendTime())){
				if (alertTrendTimeList.isEmpty()) {
					alertTrendTimeList.add(alertHist.getAlertTrendTime());
				}else {
					if (!alertTrendTimeList.contains(alertHist.getAlertTrendTime())){
						alertTrendTimeList.add(alertHist.getAlertTrendTime());
					}
				}
			}	
		}
		
		if (!procDateList.isEmpty()){
			int procDateListSize = procDateList.size();
			for (int j=0;j<procDateListSize;j++){
				if (procDateInString==null){
					procDateInString = " to_date('" + (String) procDateList.get(j) + "','mm/dd/yyyy') ";
				}else {
					procDateInString += " ,to_date('" + (String) procDateList.get(j) + "','mm/dd/yyyy') ";
				}
			}
			arg += "AND p.proc_date IN (" + procDateInString + ") ";
		}
		if (!key1List.isEmpty()){
			int key1ListSize = key1List.size();
			for (int j=0;j<key1ListSize;j++){
				if (key1InString==null){
					key1InString = "'" + (String) key1List.get(j) + "' ";
				}else {
					key1InString += ",'" + (String) key1List.get(j) + "' ";
				}
			}
			arg += "AND p.prev_alert_key1 IN (" + key1InString + ") ";
		}
		if (!key2List.isEmpty()){
			int key2ListSize = key2List.size();
			for (int j=0;j<key2ListSize;j++){
				if (key2InString==null){
					key2InString = "'" + (String) key2List.get(j) + "' ";
				}else {
					key2InString += ",'" + (String) key2List.get(j) + "' ";
				}
			}
			arg += "AND p.prev_alert_key2 IN (" + key2InString + ") ";
		}
		if (!key3List.isEmpty()){
			int key3ListSize = key3List.size();
			for (int j=0;j<key3ListSize;j++){
				if (key3InString==null){
					key3InString = "'" + (String) key3List.get(j) + "' ";
				}else {
					key3InString += ",'" + (String) key3List.get(j) + "' ";
				}
			}
			arg += "AND p.prev_alert_key3 IN (" + key3InString + ") ";
		}
		if (!key4List.isEmpty()){
			int key4ListSize = key4List.size();
			for (int j=0;j<key4ListSize;j++){
				if (key4InString==null){
					key4InString = "'" + (String) key4List.get(j) + "' ";
				}else {
					key4InString += ",'" + (String) key4List.get(j) + "' ";
				}
			}
			arg += "AND p.prev_alert_key4 IN (" + key4InString + ") ";
		}
		if (!key5List.isEmpty()){
			int key5ListSize = key5List.size();
			for (int j=0;j<key5ListSize;j++){
				if (key5InString==null){
					key5InString = "'" + (String) key5List.get(j) + "' ";
				}else {
					key5InString += ",'" + (String) key5List.get(j) + "' ";
				}
			}
			arg += "AND p.prev_alert_key5 IN (" + key5InString + ") ";
		}
		if (!alertItemList.isEmpty()){
			int alertItemListSize = alertItemList.size();
			for (int j=0;j<alertItemListSize;j++){
				if (alertItemInString==null){
					alertItemInString = "'" + (String)alertItemList.get(j) + "' ";
				}else {
					alertItemInString += ",'" + (String)alertItemList.get(j) + "' ";
				}
			}
			arg += "AND p.prev_alert_item IN (" + alertItemInString + ") ";
		}

		if (!alertTrendTimeList.isEmpty()){
			int alertTrendTimeListSize = alertTrendTimeList.size();
			for (int j=0;j<alertTrendTimeListSize;j++){
				if (alertTrendTimeInString==null){
					alertTrendTimeInString = "'" + (String)alertTrendTimeList.get(j) + "' ";
				}else {
					alertTrendTimeInString += ",'" + (String)alertTrendTimeList.get(j) + "' ";
				}
			}
			arg += "AND alert_trend_time IN (" + alertTrendTimeInString + ") ";
		}
		
		args.add(arg);

		VwAlertHistPrevDAO vwAlertHistPrevDAO = new VwAlertHistPrevDAO();
		tmpPrevDataList = vwAlertHistPrevDAO.get(connection, failureList, args, qryPrevDataSQL);
		size = tmpPrevDataList.size();		
		for (i=0;i<size;i++)
			previousDataList.add((VwAlertHistPrev)tmpPrevDataList.get(i));	
		
	}

	/**
	 * This method processes Not Complete Files Query for each alert rule.
	 */
	public void executeNotCompleteFilesQry1() {
		Set set = null; 
		Iterator iter = null; 
		AlertRuleInfoStruct alertRuleInfo = null;
		List notCompleteFiles = null;
		
		logger.debug("Processing Not Complete Files Query for each alert rule ...");
		set = alertRuleMap.keySet();
		iter = set.iterator();
		previousDataList.clear();
		while(iter.hasNext()) {			
			alertRuleInfo = (AlertsReportSQLService.AlertRuleInfoStruct) alertRuleMap.get((String)iter.next());
			logger.debug("Processing Not Complete Files Query for alert rule = " + alertRuleInfo.alertRule);
			notCompleteFiles = processNotCompleteFilesQry1(alertRuleInfo);
			if (!failureList.isEmpty()) return;
			
			// execute NotCompleteFilesQry
			executeNotCompleteFilesQry(alertRuleInfo, notCompleteFiles);
		}
	}

	/**
	 * This method prepares NotCompleteFilesQry1 SQL statement.
	 * 
	 * @param alertRuleInfo
	 * @return List
	 */
	public List processNotCompleteFilesQry1(AlertRuleInfoStruct alertRuleInfo) {
		List notCompleteFiles = null;
		NotCompleteFilesQryStruct notCompleteFilesQryStruct = null;
		// <!---Query figuring out what groups of alert_items (proc_data,file_seq_num) don't have all the alert items they are supposed to---->
		// prepare NotCompleteFilesQry1 SQL statement
		String notCompleteFilesQry1SQLStmt = prepareNotCompleteFilesQry1SQL(alertRuleInfo);
		if (notCompleteFilesQry1SQLStmt == null) return null;

		Statement stmt = null;
		ResultSet rs = null;

		try {
			logger.debug("Executing notCompleteFilesQry1SQLStmt query ...." + notCompleteFilesQry1SQLStmt);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(notCompleteFilesQry1SQLStmt);
			if (rs != null) {
				notCompleteFiles = new ArrayList();
				while (rs.next()) {
					notCompleteFilesQryStruct = buildNotCompleteFilesQryStruct(rs);
					notCompleteFilesQry1List.add(notCompleteFilesQryStruct);
					notCompleteFiles.add(notCompleteFilesQryStruct);
				}
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {notCompleteFilesQry1SQLStmt}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {notCompleteFilesQry1SQLStmt}), sx));
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		
		return notCompleteFiles;
	}

	/**
	 * This method prepares inner SQL for notCompleteFilesQry1.
	 * 
	 * @param alertRuleInfo
	 * @return String
	 */
	public String prepareNotCompleteFilesQry1SQL(AlertRuleInfoStruct alertRuleInfo) {
		MessageFormat mf = null;
		String arg_0 = " ";
		String arg_1 = " ";
		String arg_2 = " ";
		String arg_3 = " ";
		String arg_4 = " ";
		String arg_5 = " ";
		String arg_6 = " ";
		String arg_7 = " ";
		String arg_8 = " ";
		String key1List = "";
		
		logger.debug("Preparing inner SQL for notCompleteFilesQry1 ....");
		mf = new MessageFormat(notCompleteFilesQry1InnerSQL);
		
		if ((alertReportParameters.getTimeStampInd() != null) && (alertReportParameters.getTimeStampInd().length() != 0)) {
			arg_0 = ",rabc_cntrl_run  c";
		}
		arg_1 = alertRuleInfo.partiRefIds.substring(1);
		arg_2 = "to_date('"+ alertReportParameters.getStartDate().toString() + "','mm/dd/yyyy')";
		arg_3 = "to_date('"+ alertReportParameters.getEndDate().toString() + "','mm/dd/yyyy')";
		String alertRules = "";
		if ((alertReportParameters.getTimeStampInd() != null) && (alertReportParameters.getTimeStampInd().length() != 0)) {
			if (!alertReportParameters.getTimeStampInd().equalsIgnoreCase("No")) {
				arg_4 = arg_4 + "AND c.alert_rule_run_dt = to_date('" + alertReportParameters.getTimeStampInd() + "' ,'mm/dd/yyyy') ";
			}
			// prepare alert rule list			
			arg_4 = arg_4 + "AND c.alert_rule in (" + alertRuleInfo.alertRules.substring(1) + ") ";
			arg_4 = arg_4 + " AND c.proc_date = h.proc_date ";
			if (alertReportParameters.getRelatedAlertInd().equals("Y")) {
				arg_4 = arg_4 + " AND c.severe_lvl_ind in ('0','N') ";
			} else {
				arg_4 = arg_4 + " AND c.severe_lvl_ind = '0' ";
			}
			arg_4 = arg_4 + " AND (h.file_seq_num = c.file_seq_num or (h.file_seq_num IS NULL AND c.file_seq_num IS NULL)) ";
			if (alertRuleInfo.divisionNameKeyLvl > 0) {
				if (alertReportParameters.getRelatedAlertInd().equals("Y")) {
					arg_4 = arg_4 + " AND (c.key1 = h.alert_key" + alertRuleInfo.divisionNameKeyLvl + " or c.key1 is null) ";
				} else {
					arg_4 = arg_4 + " AND c.key1 = h.alert_key" + alertRuleInfo.divisionNameKeyLvl + " ";					
				}
			} else {
				arg_4 = arg_4 + " AND c.key1 is null ";
			}
		}
		if ((!alertReportParameters.getDivisionName().equals("ALL")) && (alertRuleInfo.divisionNameKeyLvl > 0)) {
			arg_5 = arg_5 + "and h.alert_key"+ alertRuleInfo.divisionNameKeyLvl + " in (" + alertReportParameters.getKey1s() + ")";
		}
		if (alertRuleInfo.divisionNameKeyLvl > 1) {
			if (alertReportParameters.getKeysAt(0).length() != 0) {
				arg_6 = arg_6 + "and h.alert_key1 = '" + alertReportParameters.getKeysAt(0) + "' ";
			}
		}
		arg_7 = alertRuleInfo.alertRule;
		if ((alertReportParameters.getTimeStampInd()!=null) && (alertReportParameters.getTimeStampInd().length() != 0) && (!alertReportParameters.getTimeStampInd().equalsIgnoreCase("No"))) {
			arg_8 = "and m.alert_rule_run_dt = to_date('" + alertReportParameters.getTimeStampInd() + "' ,'mm/dd/yyyy') ";
		}

		String notCompleteFilesQry1InnerSQLStmt = mf.format(new String[]{arg_0,
																		arg_1,
																		arg_2,
																		arg_3,
																		arg_4,
																		arg_5,
																		arg_6,
																		arg_7,
																		arg_8,
																		arg_5,
																		arg_6});		
		logger.debug("notCompleteFilesQry1InnerSQLStmt =" + notCompleteFilesQry1InnerSQLStmt);
		logger.debug("Preparing notCompleteFilesQry1 SQL statment ....");
		mf = new MessageFormat(notCompleteFilesQry1SQL);
		notCompleteFilesQry1SQLStmt = mf.format(new String[]{notCompleteFilesQry1InnerSQLStmt});
		logger.debug("notCompleteFilesQry1SQLStmt =" + notCompleteFilesQry1SQLStmt);
		
		return notCompleteFilesQry1SQLStmt;
	}
	
	/**
	 * This method builds NotCompleteFilesQryStruct for each alert item.
	 * 
	 * @param rs
	 * @return NotCompleteFilesQryStruct
	 * @throws SQLException
	 */
	private NotCompleteFilesQryStruct buildNotCompleteFilesQryStruct(ResultSet rs) throws SQLException {
		String value = null;
		NotCompleteFilesQryStruct notCompleteFilesQryStruct = new NotCompleteFilesQryStruct();
		notCompleteFilesQryStruct.fileSeqNum = rs.getInt("FILE_SEQ_NUM");
		notCompleteFilesQryStruct.procDate = rs.getDate("PROC_DATE");
		value = rs.getString("ALERT_KEY1");
		notCompleteFilesQryStruct.alertKey[0] = (value==null?"":value);
		value = rs.getString("ALERT_KEY2");
		notCompleteFilesQryStruct.alertKey[1] = (value==null?"":value);
		value = rs.getString("ALERT_KEY3");
		notCompleteFilesQryStruct.alertKey[2] = (value==null?"":value);
		value = rs.getString("ALERT_KEY4");
		notCompleteFilesQryStruct.alertKey[3] = (value==null?"":value);
		value = rs.getString("ALERT_KEY5");
		notCompleteFilesQryStruct.alertKey[4] = (value==null?"":value);
		notCompleteFilesQryStruct.alertItem = rs.getString("ALERT_ITEM");
		return notCompleteFilesQryStruct;
	}

	/**
	 * This method executes NotCompleteFilesQry.
	 * 
	 * @param alertRuleInfo
	 * @param notCompleteFiles
	 */
	public void executeNotCompleteFilesQry(AlertRuleInfoStruct alertRuleInfo, List notCompleteFiles) {
		int i = 0;
		int size = 0;
		int alertItemCount = 0;
		boolean sameRecord = false;
		NotCompleteFilesQryStruct prevNotCompleteFileStruct = null;
		NotCompleteFilesQryStruct curNotCompleteFileStruct = null;
		//<!---find out how many alert_items should be in each group of (proc_data,file_seq_num)---> 
		ExtrctTblDefDAO extrctTblDefDAO = new ExtrctTblDefDAO();
		List args = new ArrayList();
		args.add(alertRuleInfo.partiRefIds.substring(1));
		Long numberOfItems = extrctTblDefDAO.getCount(connection, failureList, args, alertItemsQrySQL);
		if (numberOfItems == null) return; // errro occurred, return
		
		size = notCompleteFiles.size();
		while (i < size) {
			curNotCompleteFileStruct = (NotCompleteFilesQryStruct) notCompleteFiles.get(i);
			if (prevNotCompleteFileStruct == null) {
				prevNotCompleteFileStruct = curNotCompleteFileStruct;
				alertItemCount = 0;
				if (curNotCompleteFileStruct.alertItem != null) alertItemCount++;
			} else {
				sameRecord = true;
				if (curNotCompleteFileStruct.fileSeqNum != prevNotCompleteFileStruct.fileSeqNum) sameRecord = false;
				if ((curNotCompleteFileStruct.procDate != null) && (prevNotCompleteFileStruct.procDate != null)) {
					if (curNotCompleteFileStruct.procDate.compareTo(prevNotCompleteFileStruct.procDate) != 0) {
						sameRecord = false;
					}
				} else {
					if ((curNotCompleteFileStruct.procDate == null) && (prevNotCompleteFileStruct.procDate == null)) {
						// same record
					} else {
						sameRecord = false;
					}
				}
				if (!curNotCompleteFileStruct.alertKey[0].equals(prevNotCompleteFileStruct.alertKey[0])) sameRecord = false;
				if (!curNotCompleteFileStruct.alertKey[1].equals(prevNotCompleteFileStruct.alertKey[1])) sameRecord = false;
				if (!curNotCompleteFileStruct.alertKey[2].equals(prevNotCompleteFileStruct.alertKey[2])) sameRecord = false;
				if (!curNotCompleteFileStruct.alertKey[3].equals(prevNotCompleteFileStruct.alertKey[3])) sameRecord = false;
				if (!curNotCompleteFileStruct.alertKey[4].equals(prevNotCompleteFileStruct.alertKey[4])) sameRecord = false;
				if (sameRecord) {
					if (curNotCompleteFileStruct.alertItem != null) alertItemCount++;
				} else {
					if (alertItemCount < numberOfItems.longValue()) {
						notCompleteFilesQryList.add(prevNotCompleteFileStruct);
					}
					prevNotCompleteFileStruct = curNotCompleteFileStruct;
					alertItemCount = 0;
					if (curNotCompleteFileStruct.alertItem != null) alertItemCount++;
				}
			}
			i++;
		}
	}
	
	/**
	 * This class handles NotCompleteFilesQryStruct.
	 */
	protected class NotCompleteFilesQryStruct {
		int fileSeqNum;
		Date procDate;
		String[] alertKey = {"","","","",""};
		String alertItem;
	}

	/**
	 * This method builds QryAlertData for each alert rule.
	 */
	public void buildQryAlertData() {
		AlertHist alertHist = null;
		QryAlertRule qryAlertRule = null;
		
		// build qryAlertData, compute sum(calcCnt), sum(SeqCnt), totCnt, determine maxDate, minDate, build keyColumnList and build arKeyColMap
		int calcCnt = 0;
		int seqCnt = 0;
		int totCnt = 0;
		MyDate procDate = null;
		MyDate maxProcDate = null;
		MyDate minProcDate = null;
		int condCounter = 0;
		int maxCounter = 0;
		int dataAllCondCounter = 0;
		int dataAllMaxCounter = 0;
		List columns = null; 
		List multiColumnList = null;
		AlertRuleInfoStruct alertRuleInfo = null;
		//List
		//logger.debug("COUNTERS *************************** = ");

		// partiRef condition
		maxCounter = maxCounter + 1;

		// For Page 14 only PartiRefID is required for match while for Page 11 we need others listed below.
		if (alertReportParameters.getWebPageId().equals(PAGE_11)) {
			dataAllMaxCounter = dataAllMaxCounter + 1;
			// Division condition
			//logger.debug("alertReportParameters.getDivisionName() = " + alertReportParameters.getDivisionName());
			if ((!alertReportParameters.getDivisionName().equals("ALL")) && (alertReportParameters.getDivisionNameKeyLvl().intValue() > 0)) {
				maxCounter = maxCounter + 1;
				dataAllMaxCounter = dataAllMaxCounter + 1;
			}
			// divisionNameKeyLvl <> 1 and Key1 not blank condition
			//logger.debug("alertReportParameters.getKey1() = " + alertReportParameters.getKey1());
			if (alertReportParameters.getDivisionNameKeyLvl().intValue() > 1 && (!alertReportParameters.getKeysAt(0).equals(""))) {
				maxCounter = maxCounter + 1;
				dataAllMaxCounter = dataAllMaxCounter + 1;
			}

			// Key 2 condition
			//logger.debug("alertReportParameters.getKey2() = " + alertReportParameters.getKey2());
			if (!alertReportParameters.getKeysAt(1).equals("")) {
				maxCounter = maxCounter + 1;
			}
			// fileSeqNum condition
			//logger.debug("alertReportParameters.getFileSeqNum() =  " + alertReportParameters.getFileSeqNum());
			if (alertReportParameters.getFileSeqNum().intValue() != -1) {
				maxCounter = maxCounter + 1;
			}
			// date condition
			maxCounter = maxCounter + 1;
			//logger.debug("maxCounter = "+maxCounter);
			//logger.debug("dataAllMaxCounter = "+dataAllMaxCounter);			
		}
		/*
		 * Find out the min & max dates
		 */
		maxProcDate = getMaxDate();
		minProcDate = getMinDate();
		
		//logger.debug("ENTERING LOOP *************************** = ");
		for(int i=0; i < qryAlertHistAllList.size(); i++) {
			//logger.debug("RECORD *************************** = "+i);
			alertHist = (AlertHist) qryAlertHistAllList.get(i);
			for(int j=0; j < qryAlertRuleList.size(); j++) {
				qryAlertRule = (QryAlertRule) qryAlertRuleList.get(j);
				if (alertReportParameters.getRelatedAlertInd().equalsIgnoreCase("Y")) {
					alertRuleInfo = getAlertRuleInfoStruct(qryAlertRule.getAlertRule());
				} else {
					alertRuleInfo = (AlertRuleInfoStruct) alertRuleMap.get(qryAlertRule.getAlertRule());
				}
				if (alertRuleInfo != null) {
					condCounter=0;
					dataAllCondCounter = 0;
					// partiRef condition
					//logger.debug("alertHist.getPartiRefId() =  " + alertHist.getPartiRefId() + " qryAlertRule.getPartiRefId() =  " + qryAlertRule.getPartiRefId());
					if (alertHist.getPartiRefId() == qryAlertRule.getPartiRefId()) {
						condCounter = condCounter + 1;
						dataAllCondCounter = dataAllCondCounter + 1;
					}
	
					if (alertReportParameters.getWebPageId().equals(PAGE_11)) {
						// Division condition
						//logger.debug("alertHist.getAlertKeyAt(" + new Integer(alertReportParameters.getDivisionNameKeyLvl() - 1).toString() + " ) =  " + alertHist.getAlertKeyAt(alertReportParameters.getDivisionNameKeyLvl() - 1) + " alertReportParameters.getKey1INString() =  " + alertReportParameters.getKey1INString());
						if ((!alertReportParameters.getDivisionName().equals("ALL")) && (alertRuleInfo.divisionNameKeyLvl > 0)) {
							if ((alertHist.getAlertKeyAt(alertRuleInfo.divisionNameKeyLvl - 1).equals("")) || 
								(alertReportParameters.getKey1s().indexOf(alertHist.getAlertKeyAt(alertRuleInfo.divisionNameKeyLvl - 1)) > -1)) {
								condCounter = condCounter + 1;
								dataAllCondCounter = dataAllCondCounter + 1;
							}
						}
	
						// divisionNameKeyLvl <> 1 and Key1 not blank condition
						//logger.debug("alertHist.getAlertKeyAt(0) =  " + alertHist.getAlertKeyAt(0) + " alertReportParameters.getKey1() =  " + alertReportParameters.getKey1());
						if ((!alertReportParameters.getKeysAt(0).equals("")) && (alertRuleInfo.divisionNameKeyLvl > 1)) {
							if ((alertHist.getAlertKeyAt(0).equals("")) || 
								(alertReportParameters.getKeysAt(0).equals(alertHist.getAlertKeyAt(0)))) {
								condCounter = condCounter + 1;
								dataAllCondCounter = dataAllCondCounter + 1;
							}					
						}
						// Key 2 condition
						//logger.debug("alertHist.getAlertKeyAt(1) =  " + alertHist.getAlertKeyAt(1) + " alertReportParameters.getKey2() =  " + alertReportParameters.getKey2());
						if (!alertReportParameters.getKeysAt(1).equals("")) {
							if (alertHist.getAlertKeyAt(1).equalsIgnoreCase(alertReportParameters.getKeysAt(1))) {
								condCounter = condCounter + 1;
							}
						}
					
						// fileSeqNum condition
						//logger.debug("alertHist.getFileSeqNum() =  " + alertHist.getFileSeqNum() + " alertReportParameters.getFileSeqNum() =  " + alertReportParameters.getFileSeqNum());
						if (alertReportParameters.getFileSeqNum().intValue() != -1) {
							if (alertReportParameters.getFileSeqNum().intValue() == alertHist.getFileSeqNum()) {
								condCounter = condCounter + 1;
							}
						}
	
						// date condition
						procDate = new MyDate(alertHist.getProcDate());
						//logger.debug("procDate =  " + procDate.toString() + " alertReportParameters.getStartDate() =  " + alertReportParameters.getStartDate().toString()+ " alertReportParameters.getEndDate() =  " + alertReportParameters.getEndDate().toString());
					
						if (alertReportParameters.getEndDate().toString().equals("")) {
							// compare only start date				
							if (procDate.toString().compareTo(alertReportParameters.getStartDate().toString()) == 0) { 
								condCounter = condCounter + 1;
							}
						} else {
							// compare with start date and end date
							if (((procDate.compareTo(alertReportParameters.getStartDate()) == 0) || (procDate.compareTo(alertReportParameters.getStartDate()) > 0)) && 
								((procDate.compareTo(alertReportParameters.getEndDate()) == 0) || (procDate.compareTo(alertReportParameters.getEndDate()) < 0))) {
								condCounter = condCounter + 1;
							}
						}					
					}
	
					if (condCounter == maxCounter) {
						//logger.debug("condition met for qryAlertData");
						// condition satisfied, build qryAlertData and add to list
						addToQryAlertDataList(qryAlertDataList, qryAlertRule, alertHist, alertReportParameters);
	
						//compute sum(calcCnt), sum(SeqCnt) and totCnt and determine maxDate and minDate
						calcCnt = calcCnt + qryAlertRule.getCalccnt();
						seqCnt = seqCnt + qryAlertRule.getSeqcnt();
	
						// build keyColumnList and build alertRuleMap
						 
						columns = new ArrayList();
						multiColumnList = new ArrayList();
						alertRuleInfo.calcCnt += calcCnt;
						alertRuleInfo.seqCnt += seqCnt;
						alertRuleInfo.totCnt += 1;
						if (qryAlertRule.getAlertKeyLvl() > 0) {
							for(int k = 0; k < 5; k++) {
								if ((qryAlertRule.getKeyHeaderAt(k) != null) && (!qryAlertRule.getKeyHeaderAt(k).equals(""))) {
									// find the position of key Column, if not found then add
									int position = foundAtInColumns(columns, qryAlertRule.getKeyHeaderAt(k));
									if (position == -1) {
										columns.add(qryAlertRule.getKeyHeaderAt(k));
										position = columns.size();
									}
									// build multi column struct with position of column and key num
									MultiColumnStruct multiColumnStruct = new MultiColumnStruct();
									multiColumnStruct.keyColPos = position;
									multiColumnStruct.keyNum = k + 1;	
									multiColumnList.add(multiColumnStruct);
								}
							} // end of int k loop
						} // end if AlertKeyLvl > 0
						alertRuleInfo.columns = columns;
						alertRuleInfo.multiColumnList = multiColumnList;
						alertRuleInfo.nbrOfKeyCols = columns.size();
						alertRuleMap.put(alertRuleInfo.alertRule, alertRuleInfo);
					}
				}
			}
		}
		//logger.debug("EXISTED LOOP *************************** = ");
		alertReportParameters.setTotCnt(qryAlertDataList.size()+1);
		alertReportParameters.setCalcCnt(calcCnt);
		alertReportParameters.setSeqCnt(seqCnt);
		alertReportParameters.setMaxDate(maxProcDate);
		alertReportParameters.setMinDate(minProcDate);
	}

	/**
	 * This method finds element at specific keyColumn.
	 * 
	 * @param columns
	 * @param keyColumn
	 * @return int
	 */
	private int foundAtInColumns(List columns, String keyColumn) {
		int m = 0;
		int size = columns.size();
		for(m=0; m < size; m++) {
			if (((String)columns.get(m)).equals(keyColumn)) 
				return m + 1;
		}
		return -1;
	}

	/**
	 * This method adds data to QryAlertDataList.
	 * 
	 * @param qryAlertDataList
	 * @param qryAlertRule
	 * @param alertHist
	 * @param alertReportParameters
	 */
	private void addToQryAlertDataList(List qryAlertDataList, QryAlertRule qryAlertRule, AlertHist alertHist, AlertReportParameters alertReportParameters) {
		// build qryAlertData, Check whether it is added, if not, insert at appropriate location as per following order
		// qryAlertRule.key1Seq, alertHist.alertKey1, alertHist.procDate, alertHist.alertKey2, alertHist.alertKey3, 
		// alertHist.alertKey4, alertHist.alertKey5, qryAlertRule.presnSeqNum, alertHist.fileSeqNum
		QryAlertData qryAlertData = new QryAlertData(qryAlertRule, alertHist);
		if (notAdded(qryAlertDataList, qryAlertData)) {
			addAtAppropriatePosition(qryAlertDataList, qryAlertData, alertReportParameters);
		}
	}

	/**
	 * This method returns boolean value depend upon the data added or not.
	 * 
	 * @param qryAlertDataList
	 * @param qryAlertDataArg
	 * @return boolean
	 */
	private boolean notAdded(List qryAlertDataList, QryAlertData qryAlertDataArg) {
		QryAlertData qryAlertData = null;
		for(int i=0; i < qryAlertDataList.size(); i++) {
			qryAlertData = (QryAlertData) qryAlertDataList.get(i);
			if (qryAlertData.equals(qryAlertDataArg)) {
				return false;
			}
		}
		return true;
	}
	
	/**
	 * This method returns row value depend upon received list.
	 * 
	 * @param inputParameters
	 * @param currentParameters
	 * @return int
	 */
	private int decideForAsc(List inputParameters, List currentParameters) {
		if (inputParameters.isEmpty()) {
			logger.warn("Received empty list in order by logic....");
			return NEXT_ROW;
		}
		for (int i=0; i < inputParameters.size(); i++) {
			Object obj = inputParameters.get(i);
			if (obj != null) {
				if (obj instanceof String) {
					String inputStr = (String) obj;
					String currentStr = (String) currentParameters.get(i);
					if (currentStr == null) {
						logger.warn("Received null object in current Parameter List....");
						return NEXT_ROW;
					}
					if (inputStr.compareTo(currentStr) < 0) {
						return INSERT_ROW;
					}
					if (inputStr.compareTo(currentStr) > 0) return NEXT_ROW;
					// process next key
				} else {
					if (obj instanceof Integer) {
						Integer inputInt = (Integer) obj;
						Integer currentInt = (Integer) currentParameters.get(i);
						if (currentInt == null) {
							logger.warn("Received null object in current Parameter List....");
							return NEXT_ROW;
						}
						if (inputInt.intValue() < currentInt.intValue()) {
							return INSERT_ROW;
						}
						if (inputInt.intValue() > currentInt.intValue()) return NEXT_ROW;
						// process next key					
					} else {
						if (obj instanceof Date) {
							MyDate inputDate = new MyDate((Date)obj);
							if (currentParameters.get(i) == null) {
								logger.warn("Received null object in current Parameter List....");
								return NEXT_ROW;
							}
							MyDate currentDate = new MyDate((Date)currentParameters.get(i));
							if (inputDate.compareTo(currentDate) < 0) {
								return INSERT_ROW;
							}
							if (inputDate.compareTo(currentDate) > 0) return NEXT_ROW;
							// process next key
						} else {
							logger.warn("Received unsupported object type in Order By logic .....");
							return NEXT_ROW;							
						}
					}
				}
			}
		} // end of for loop
		return NEXT_ROW;
	}

	/**
	 * This method adds data at AppropriatePosition of list.
	 * 
	 * @param qryAlertDataList
	 * @param qryAlertDataArg
	 * @param alertReportParameters
	 */
	private void addAtAppropriatePosition(List qryAlertDataList, QryAlertData qryAlertDataArg, AlertReportParameters alertReportParameters) {
		QryAlertData qryAlertData = null;
		List currentColumnList = new ArrayList();
		List newColumnList = new ArrayList();
		int option = 0;
		int size = 0;
		size = qryAlertDataList.size();

		if (size == 0) {
			qryAlertDataList.add(qryAlertDataArg);
			return;
		}
		
		// Key1Seq
		newColumnList.add(new Integer(qryAlertDataArg.getQryAlertRule().getKey1Seq()));
		
		// AlertKey1
		newColumnList.add(qryAlertDataArg.getAlertHist().getAlertKeyAt(0));
		
		// Add parti ref id for comparison when you go from control point
		if ((alertReportParameters.getCntrlPtCd().length() != 0)) {
			newColumnList.add(new Integer(qryAlertDataArg.getQryAlertRule().getPartiRefId()));
		}
		
		// ProcDate
		newColumnList.add(qryAlertDataArg.getAlertHist().getProcDate());
		
		if (alertReportParameters.getWebPageId().equals(PAGE_11)) {
			// fileSeqNum
			newColumnList.add(new Integer(qryAlertDataArg.getAlertHist().getFileSeqNum()));
		}
		
		// AlertKey2
		newColumnList.add(qryAlertDataArg.getAlertHist().getAlertKeyAt(1));
		// AlertKey3
		newColumnList.add(qryAlertDataArg.getAlertHist().getAlertKeyAt(2));
		// AlertKey4
		newColumnList.add(qryAlertDataArg.getAlertHist().getAlertKeyAt(3));
		// AlertKey5
		newColumnList.add(qryAlertDataArg.getAlertHist().getAlertKeyAt(4));
		
		// alertRule
		newColumnList.add(qryAlertDataArg.getQryAlertRule().getAlertRule());

		// presnSeqNum
		newColumnList.add(new Integer(qryAlertDataArg.getQryAlertRule().getPresnSeqNum()));
		
		// alert item - code changed on 14th 
		newColumnList.add(qryAlertDataArg.getAlertHist().getAlertItem());
		
		for(int i=0; i < size; i++) {
			qryAlertData = (QryAlertData) qryAlertDataList.get(i);
			currentColumnList.clear();
			
			// Key1Seq
			currentColumnList.add(new Integer(qryAlertData.getQryAlertRule().getKey1Seq()));
			
			// AlertKey1
			currentColumnList.add(qryAlertData.getAlertHist().getAlertKeyAt(0));
			
			// Add parti ref id for comparison when you go from control point
			if ((alertReportParameters.getCntrlPtCd().length() != 0)) {
				currentColumnList.add(new Integer(qryAlertData.getAlertHist().getPartiRefId()));
			}
			
			// ProcDate
			currentColumnList.add(qryAlertData.getAlertHist().getProcDate());
			
			if (alertReportParameters.getWebPageId().equals(PAGE_11)) {
				// fileSeqNum
				currentColumnList.add(new Integer(qryAlertData.getAlertHist().getFileSeqNum()));
			}
			
			// AlertKey2
			currentColumnList.add(qryAlertData.getAlertHist().getAlertKeyAt(1));
			// AlertKey3
			currentColumnList.add(qryAlertData.getAlertHist().getAlertKeyAt(2));
			// AlertKey4
			currentColumnList.add(qryAlertData.getAlertHist().getAlertKeyAt(3));
			// AlertKey5
			currentColumnList.add(qryAlertData.getAlertHist().getAlertKeyAt(4));
			
			// alertRule
			currentColumnList.add(qryAlertData.getQryAlertRule().getAlertRule());

			// presnSeqNum
			currentColumnList.add(new Integer(qryAlertData.getQryAlertRule().getPresnSeqNum()));
			
			//	 alert item - code changed on 14th
			currentColumnList.add(qryAlertData.getAlertHist().getAlertItem());

			option = decideForAsc(newColumnList, currentColumnList);
			if (option == INSERT_ROW) {
				qryAlertDataList.add(i, qryAlertDataArg);
				return;
			}
		}
		qryAlertDataList.add(qryAlertDataArg);
		return;
	}

	/**
	 * Default constructor which sets default qryAlertRuleList attribute.
	 */
	public void clearQryAlertRuleList() {
		this.qryAlertRuleList.clear();
	}
	
	/**
	 * Default constructor which sets default qryAlertHistAllList attribute.
	 */
	public void clearQryAlertHistAllList() {
		this.qryAlertHistAllList.clear();
	}

	/**
	 * This methods attempts to find unique rules for the file seq num / account name.
	 * It executes query qrySeqNumberSQL.
	 */
	public void getAlertRules() {
		// This methods attempts to find unique rules for the file seq num / account name combo
		// qrySeqNumberSQL 
		Statement stmt = null;
		ResultSet rs = null;
		MyDate startDate = null;
		MyDate endDate = null;		
		String returnValue = null;
		String qrySeqNumberSQLStmt = null;
		String alertRule = "";
		String alertRules = "";
		
		try {
			logger.debug("Executing query qrySeqNumberSQL ...");
			MessageFormat mf = new MessageFormat(qrySeqNumberSQL);
			startDate = new MyDate(alertReportParameters.getProcDate());
			endDate = new MyDate(alertReportParameters.getProcDate()); 

			// substract -90 from the startDate and add 90 to endDate
			startDate.doAdd(-90);
			endDate.doAdd(90);
			
			qrySeqNumberSQLStmt = mf.format(new String[]{alertReportParameters.getFileSeqNum().toString(), startDate.toString(), endDate.toString()});
			logger.debug("qrySeqNumberSQLStmt statement = " + qrySeqNumberSQLStmt);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qrySeqNumberSQLStmt);
			if (rs != null) {
				while (rs.next()) {
					alertRule = rs.getString("ALERT_RULE");
					if (alertReportParameters.getAlertRule() == null)
						alertReportParameters.setAlertRule(alertRule);
					alertReportParameters.addAlertRule(alertRule);
				}
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qrySeqNumberSQLStmt}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qrySeqNumberSQLStmt}), sx));
			return;
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
	}

	/**
	 * This methods attempts to find unique rules for the cntrl_pt_cd.
	 * It executes query qryCntrPtCdSQL.
	 */
	public void getAlertRulesByCntrlPtCd() {
		// This methods attempts to find unique rules for the cntrl_pt_cd
		Statement stmt = null;
		ResultSet rs = null;
		String qryCntrPtCdSQLStmt = null;
		String alertRule = "";
		String alertRules = "";
		try {
			logger.debug("Executing query qryCntrPtCdSQL ...");
			MessageFormat mf = new MessageFormat(qryCntrPtCdSQL);
			
			qryCntrPtCdSQLStmt = mf.format(new String[]{alertReportParameters.getCntrlPtCd()});
			logger.debug("qryCntrPtCdSQLStmt statement = " + qryCntrPtCdSQLStmt);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qryCntrPtCdSQLStmt);
			if (rs != null) {
				while (rs.next()) {
					alertRule = rs.getString("ALERT_RULE");
					alertReportParameters.addAlertRule(alertRule);
				}
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryCntrPtCdSQLStmt}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryCntrPtCdSQLStmt}), sx));
			return;
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		
		if (alertReportParameters.getAlertRules() == null) {
			logger.debug("Found zero records qryCntrPtCdSQLStmt SQL....");
			failureList.add(RABCMessages.getMessage("ERR_GET_ALERT_RULE_BY_CNTRL_CD", new String[] {alertReportParameters.getCntrlPtCd()}));			
		}
	}
	
	/**
	 * This method to get AlertItemOptions.
	 * It executes query qryalertItemSQL.
	 */
	public void getAlertItemOptions(){
		List alertItemOptions = new ArrayList();
		String alertItem = null;
		String partiRefIds = null;
		StringBuffer partiRefIdsBuf = new StringBuffer();

		Statement stmt = null;
		ResultSet rs = null;
		String qryalertItemSQLStmt = null;
		
		Set set = null; 
		Iterator iter = null; 
		AlertsReportSQLService.AlertRuleInfoStruct alertRuleInfo = null;
		String alertRule = null;
		set = alertRuleMap.keySet();
		iter = set.iterator();
		while(iter.hasNext()) {			
			alertRule = (String) iter.next();
			alertRuleInfo = (AlertRuleInfoStruct) alertRuleMap.get(alertRule);
			if (iter.hasNext()) {
				partiRefIdsBuf.append(alertRuleInfo.partiRefId).append(",");
			} else {
				partiRefIdsBuf.append(alertRuleInfo.partiRefId);
			}
		}
		partiRefIds = partiRefIdsBuf.toString();
		
		try {
			logger.debug("Executing query qryalertItemSQL ...");
			MessageFormat mf = new MessageFormat(qryalertItemSQL);
			qryalertItemSQLStmt = mf.format(new String[]{partiRefIds});
			logger.debug("qryalertItemSQLStmt statement = " + qryalertItemSQLStmt);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qryalertItemSQLStmt);
			if (rs != null) {
				while (rs.next()) {
					alertItem = rs.getString("ALERT_ITEM");
					alertItemOptions.add(new PickList(alertItem, alertItem));
				}
			}
			alertReportParameters.setAlertItemOptions(alertItemOptions);
			
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryalertItemSQLStmt}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryalertItemSQLStmt}), sx));
			return;
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
	}

	/**
	 * This method handles the AlertRuleInfoStruct.
	 */
	protected class AlertRuleInfoStruct {
		List multiColumnList = null;
		List columns = null;
		int nbrOfKeyCols = 0;
		int calcCnt = 0;
		int seqCnt = 0;
		int totCnt = 0;
		char totInd;
		int presnId = 0;
		int partiRefId = 0; 
		int alertKeyLvl = 0; 
		int divisionNameKeyLvl = -1;
		String alertRule = null;
		String partiRefIds = null;
		String alertRules = null;
		String sumyPresnNames = null;
	}
	
	/**
	 * This method handles the MultiColumnStruct.
	 */
	protected class MultiColumnStruct {
		int keyColPos;
		int keyNum;  
	}

	/**
	 * @return Returns the getDefaultAlertRuleInfSQL.
	 */
	public static String getGetDefaultAlertRuleInfSQL() {
		return getDefaultAlertRuleInfSQL;
	}
	
	/**
	 * This method to get AlertRuleInfoStruct for the passed alertrule.
	 * 
	 * @param alertRule
	 * @return AlertRuleInfoStruct
	 */
	private AlertRuleInfoStruct getAlertRuleInfoStruct(String alertRule){
		AlertsReportSQLService.AlertRuleInfoStruct alertRuleInfo = null;
		Set set = null; 
		Iterator iter = null; 
		String currAlertRule = null;
		int i = 0;
		int size = 0;
		alertRule = "'" + alertRule + "'";
		set = alertRuleMap.keySet();
		iter = set.iterator();
		while(iter.hasNext()) {			
			currAlertRule = (String) iter.next();
			alertRuleInfo = (AlertRuleInfoStruct) alertRuleMap.get(currAlertRule);
			String relatedAlertRules = alertRuleInfo.alertRules;
			StringTokenizer tokens = new StringTokenizer(relatedAlertRules.substring(1),",");
			while (tokens.hasMoreTokens()){
				String currRule = tokens.nextToken();
				if (currRule.equals(alertRule)){
					return alertRuleInfo;
				}
			}
		}
		return null;
	}

	/**
	 * Method to return the default division.
	 * 
	 * @param connection
	 * @param failures
	 * @param userId
	 * @return String
	 */
	protected String getDefaultDivision(Connection connection, List failures, String userId) {
		String defaultDivision = null;
		String selectSQL = getDefaultDivision;
		List args = new ArrayList();
		args.add(userId);
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		try{
			MessageFormat mf = new MessageFormat(selectSQL);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			if (rs != null && rs.next()) {
				defaultDivision = rs.getString(1);
			} else {
				defaultDivision = "";
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		
		return defaultDivision;
	}

	/**
	 * Method to return the default line count.
	 * 
	 * @param connection
	 * @param failureList
	 * @param userId
	 * @return int
	 */
	protected int getDefaultLineCount(Connection connection, List failureList, String userId) {
		int defaultLineCount = 0;
		String selectSQL = getDefaultLineCount;
		List args = new ArrayList();
		args.add(userId);
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		try{
			MessageFormat mf = new MessageFormat(selectSQL);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			if (rs != null && rs.next()) {
				defaultLineCount = rs.getInt(1);
			} else {
				defaultLineCount = RABCConstantsLists.getRABCConstantsLists().getPageSize();
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		
		return defaultLineCount;
	}
	
	
	/**
	 * Method return the list of distinct alert rule timing indicators.
	 * 	 
	 * @return list of distinct alert rule timing indicators
	 */
	public List getDistinctAlertRuleTimingIndicators(){
		List distinctTimeIndicatorList = new ArrayList();	
		for(int i = 0; i < this.qryAlertRuleList.size() ; i++){
			QryAlertRule qryAlertRule = (QryAlertRule) qryAlertRuleList.get(i);
			String timeIndicator = qryAlertRule.getAlertTimeInd();
			if(timeIndicator == null){
				timeIndicator = "";
			}
			
			if(!distinctTimeIndicatorList.contains(timeIndicator)){
				distinctTimeIndicatorList.add(timeIndicator);
			}
		}
		return distinctTimeIndicatorList;
	}
	
	/**
	 * This is a method to set the start and end dates depend upon the next/previous buttton.
	 * 
	 * @param region
	 */
	public void setStartEndDates() {
		MyDate procDate = getNextPreviousDate();
 
		if(alertReportParameters.getSelectedButton() == NEXT_BUTTON) {			
			if (procDate == null) {
				alertReportParameters.setHideNext(true);
			} else {
				if (alertReportParameters.getStartDate().compareTo(procDate) == 0) {
					alertReportParameters.setHideNext(true);
				} else {
					alertReportParameters.setStartDate(procDate);
					alertReportParameters.setEndDate(procDate);
				}
			}
		}
		if(alertReportParameters.getSelectedButton() == PREVIOUS_BUTTON) {			
			if (procDate == null) {
				alertReportParameters.setHidePrev(true);
			} else {
				if (alertReportParameters.getStartDate().compareTo(procDate) == 0) {
					alertReportParameters.setHidePrev(true);
				} else {
					alertReportParameters.setStartDate(procDate);
					alertReportParameters.setEndDate(procDate);
				}
			}
		}
	}
	
	/**
	 * It returns the minimum/maximum proc date.
	 * 
	 * @param region
	 * @return MyDate
	 */
	private MyDate getNextPreviousDate() {
		logger.debug("Determine previous/next proc date ...");
		MyDate procDate = null;
		MyDate tmpProcDate = null;
		tmpProcDate = getProcDate();
		if (tmpProcDate != null) {
			procDate = tmpProcDate;
		}
		
		return procDate;
	}
	
	/**
	 * This method is used to get proc date for the passed alertRuleInfo and region.
	 * 
	 * @param alertRuleInfo
	 * @param region
	 * @return MyDate
	 */
	private MyDate getProcDate() {
		MyDate tmpProcDate = null;
		
		if (alertReportParameters.getSelectedButton() == NEXT_BUTTON) {
			tmpProcDate = getNextDate();
		} 
		if (alertReportParameters.getSelectedButton() == PREVIOUS_BUTTON) {
			tmpProcDate = getPreviousDate();
		}
		
		return tmpProcDate;
	}
	
	/**
	 * Private method will return the next date for the rabc_alert_hist.
	 * 
	 * @return
	 */
	public MyDate getNextDate(){
		Statement stmt = null;
		ResultSet rs = null;
		MessageFormat mf = null;
		
		String [] args1 = getQryHistArguments(0);
		String [] args = new String[5];
		for (int i=0;i<args1.length;i++){
			args[i]=args1[i];
		}
		args[4] = alertReportParameters.getEndDate().toString();
		String qryAlertHistMaxDateSQLStmt = null;
		MyDate nextDate = null;
		try {
			mf = new MessageFormat(qryAlertHistNextDate);
			qryAlertHistMaxDateSQLStmt = mf.format(args);
			logger.debug("qryAlertHist max date =" + qryAlertHistMaxDateSQLStmt);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qryAlertHistMaxDateSQLStmt);
			
			if (rs != null) {
				while (rs.next()) {
					Date tempDate = rs.getDate(1);
					if (tempDate!=null){
						nextDate = new MyDate(tempDate);	
					}
				}
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryAlertHistMaxDateSQLStmt}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryAlertHistMaxDateSQLStmt}), sx));
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		
		return nextDate;
	}
	
	/**
	 * Private method will return the previous date for the rabc_alert_hist.
	 * 
	 * @return
	 */
	public MyDate getPreviousDate(){
		Statement stmt = null;
		ResultSet rs = null;
		MessageFormat mf = null;
		
		String [] args1 = getQryHistArguments(0);
		String [] args = new String[5];
		for (int i=0;i<args1.length;i++){
			args[i]=args1[i];
		}
		args[4] = alertReportParameters.getStartDate().toString();
		
		String qryAlertHistMinDateSQLStmt = null;
		MyDate prevDate = null;
		try {
			mf = new MessageFormat(qryAlertHistPreviousDate);
			qryAlertHistMinDateSQLStmt = mf.format(args);
			logger.debug("qryAlertHist previous date = " + qryAlertHistMinDateSQLStmt);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qryAlertHistMinDateSQLStmt);
			
			if (rs != null) {
				while (rs.next()) {
					Date tempDate = rs.getDate(1);
					if (tempDate!=null){
						prevDate = new MyDate(tempDate);	
					}
				}
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryAlertHistMinDateSQLStmt}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryAlertHistMinDateSQLStmt}), sx));
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		
		return prevDate;
	}
}
