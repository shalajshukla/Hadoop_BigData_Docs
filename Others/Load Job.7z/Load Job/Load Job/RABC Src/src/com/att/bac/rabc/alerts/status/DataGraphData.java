/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.alerts.status;

import com.att.bac.rabc.MyDate;

/**
 * Data object representing the each value to be plotted on the data graph.
 * 
 * @author Shailesh Hemdev - SH8512
 */
public class DataGraphData {
	private int fileSeqNum = -1; // A value of -1 indicates that this is equal to null
	private MyDate procDate;
	private String procDateString;
	private double sumData;
	private double totalData;	
	private String alertTrendTime;
	
	/**
	 * @return Returns the fileSeqNum.
	 */
	public int getFileSeqNum() {
		return fileSeqNum;
	}
	/**
	 * @param fileSeqNum The fileSeqNum to set.
	 */
	public void setFileSeqNum(int fileSeqNum) {
		this.fileSeqNum = fileSeqNum;
	}
	/**
	 * @return Returns the procDate.
	 */
	public MyDate getProcDate() {
		return procDate;
	}
	/**
	 * @param procDate The procDate to set.
	 */
	public void setProcDate(MyDate procDate) {
		this.procDate = procDate;
	}
	/**
	 * @return Returns the sumData.
	 */
	public double getSumData() {
		return sumData;
	}
	/**
	 * @param sumData The sumData to set.
	 */
	public void setSumData(double sumData) {
		this.sumData = sumData;
	}
	/**
	 * @return Returns the totalData.
	 */
	public double getTotalData() {
		return totalData;
	}
	/**
	 * @param totalData The totalData to set.
	 */
	public void setTotalData(double totalData) {
		this.totalData = totalData;
	}
	/**
	 * @return Returns the procDateString.
	 */
	public String getProcDateString() {
		return procDateString;
	}
	/**
	 * @param procDateString The procDateString to set.
	 */
	public void setProcDateString(String procDateString) {
		this.procDateString = procDateString;
	}
	/**
	 * @return Returns the alertTrendTime.
	 */
	public String getAlertTrendTime() {
		return alertTrendTime;
	}
	/**
	 * @param alertTrendTime The alertTrendTime to set.
	 */
	public void setAlertTrendTime(String alertTrendTime) {
		this.alertTrendTime = alertTrendTime;
	}
}
