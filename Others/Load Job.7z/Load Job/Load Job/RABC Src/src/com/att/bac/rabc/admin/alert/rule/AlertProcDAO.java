/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.admin.alert.rule;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.ArrayList;
import java.text.MessageFormat;

import org.apache.log4j.Logger;

import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.RABCException;

/**
 * This is a DAO that performs SELECT, INSERT and UPDATE on RABC_ALERT_PROC table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class AlertProcDAO {
	private static final Logger logger = Logger.getLogger(AlertProcDAO .class);

	/**
	 * Returns the list of AlertProc objects.
	 * 
	 * @param conn 
	 * @param failures
	 * @param args
	 * @param baseSQL
	 * @return List
	 */
	public List get(Connection conn, List failures, List args, String baseSQL) {
		List alertProcList = null;
		AlertProc alertProc = null;
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		
		try
		{
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("AlertProcDAO  - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			alertProcList = new ArrayList();
			while (rs.next()) {
				alertProcList.add(buildAlertProc(rs));
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return null;
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
		
		return alertProcList;
	}

	/**
	 * Private method to build AlertProc object and return it to caller.
	 * 
	 * @param rs
	 * @return AlertProc
	 * @throws SQLException
	 */
	private AlertProc buildAlertProc(ResultSet rs) throws SQLException {
		AlertProc alertProc = new AlertProc();
		
		alertProc.setAlertRule(rs.getString("ALERT_RULE"));
		alertProc.setAlertType(rs.getString("ALERT_TYPE"));
		alertProc.setAlertItemDdlName(rs.getString("ALERT_ITEM_DDL_NAME"));
		alertProc.setAlertItemDdlData(rs.getString("ALERT_ITEM_DDL_DATA"));
		alertProc.setAlertItemAvgName(rs.getString("ALERT_ITEM_AVG_NAME"));
		alertProc.setAlertProcTbl(rs.getString("ALERT_PROC_TBL"));
		alertProc.setAlertProcAvgTbl(rs.getString("ALERT_PROC_AVG_TBL"));
		alertProc.setAlertCreateInd(rs.getString("ALERT_CREATE_IND"));
		alertProc.setAlertMsgSuppDataInd(rs.getString("ALERT_MSG_SUPP_DATA_IND"));
		alertProc.setAlertThrshldDfltInd(rs.getString("ALERT_THRSHLD_DFLT_IND"));
		alertProc.setAlertCalcNum(rs.getInt("ALERT_CALC_NUM"));
		alertProc.setAlertTblSelNum(rs.getInt("ALERT_TBL_SEL_NUM"));
		alertProc.setPartiRefId(rs.getInt("PARTI_REF_ID"));
		return alertProc;
	}

	/**
	 * Execute the insert or update statement on RABC_ALERT_PROC table.
	 * 
	 * @param conn
	 * @param failures
	 * @param args
	 * @param baseSQL
	 */
	public void executeUpdate(Connection conn, List failures, List args, String baseSQL) {
		int rowsUpdated = 0;
		Statement stmt = null;
		String sqlStmt = null;
		
		try
		{
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("AlertProcDAO  - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rowsUpdated = stmt.executeUpdate(sqlStmt);
			logger.debug("SQL - Execution complete."+ String.valueOf(rowsUpdated) + "  rows updated");
			
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return;
		} finally {
			SQLHelper.closeStatement(stmt, failures, logger);
		}
	}

}
