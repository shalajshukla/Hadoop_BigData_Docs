/* Created on Sep 24, 2006 by Daniel Baker (db8237). 
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.load.bfmt.sw;

import java.io.File;
import java.net.UnknownHostException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import com.att.bac.rabc.util.EmcisEventLogger;
import com.att.bac.util.NetUtil;
import com.att.carat.util.JDBCUtil;
import com.sbc.bac.rabc.load.FilePatternLoadJob;
import com.sbc.bac.rabc.load.PrepareTableForRerun;
import com.sbc.bac.rabc.load.RabcLoadJobTrig;
import com.sbc.bac.rabc.load.RetrieveStaticInfo;
import com.sbc.bac.rabc.load.StaticErrorMsgKeys;

/**
 * @author db8237
 * 
 * Subclass of FilePatternLoadJob, which will process a delimited file.
 */
public class BillFormatSWLoadJob extends FilePatternLoadJob {
	
//	 Array of tables accessed by this Load Job, used during backout for reruns
	private static final String[] tableNames = {"RABC_BILL_PRT_SUMY"};
	
// SQL for accessing table RABC_BILL_PRT_SUMY
	private static final StringBuffer insertBillFormatSQL = new StringBuffer("INSERT INTO RABC_BILL_PRT_SUMY " +
			"(RUN_DATE, DIVISION, CUST_CLS_CD, DOC_CD, BILL_RND, DOC_COPY_CT) " +
			"VALUES(?, ?, ?, ?, ?, ?) ");
	
// Prepared Statements
	private PreparedStatement insertBillFormat;
	
// Common variables
	private ArrayList triggers = new ArrayList();
	private File currentFile;
	private String division;
	private java.sql.Date sqlRunDate;
	private String runDate;
	private int billRnd;
	private boolean backupRecovery;
	private boolean trailerProcessed;
	private boolean firstRecord;
	private int lineCount = 0;
	DateFormat yyyyDDD = new SimpleDateFormat("yyyyDDD");
	DateFormat MMddyyyy = new SimpleDateFormat("MMddyyyy");
	DateFormat yyyyMMdd = new SimpleDateFormat("yyyyMMdd");
	/*
	 * HashMap variables to contain the group as well boolean to decide whether to insert in RABC_TRIG or not
	 */
	private HashMap billMediaMap;
	private boolean isBfmt;
	private int bfmtBatchCounter;
	private String fileName, fileToken, region;
    /**
     * Runs prior to processing. Sets up all necessary prepared statements.
     * 
     * @return false if an error is encountered during set up, otherwise true
     */
	public boolean preprocess() {
		super.preprocess();

		try {
			insertBillFormat = connection.prepareStatement(insertBillFormatSQL.toString());
		} catch (SQLException e) {
			severe(StaticErrorMsgKeys.PREPROCESS_ERROR + e.getMessage(), e);
			return false;
		}
		return true;
	}
	
    /**
     * Runs prior to file processing. Initializes application variables.
     * 
     * @return false if an error is encountered during initialization, otherwise true
     */
	public boolean preprocessFile(File file) {
		boolean success = super.preprocessFile(file);
		fileName = file.getName();
		fileToken = file.getName().substring(file.getName().indexOf("RA140F01"),file.getName().indexOf("RA140F01")+ 8);
		region   =	file.getName().substring(0,2);
		if (success) {
			try {
				triggers = new ArrayList();
				backupRecovery = false;
				trailerProcessed = false;
				firstRecord = true;
				lineCount = 0;

				if (RabcLoadJobTrig.IsOriginalFileLoaded(connection, file, file.getName().length())) {
					backupRecovery = true;
				}
			} catch (Exception e) {
				severe(StaticErrorMsgKeys.PREPROCESSFILE_ERROR + StaticErrorMsgKeys.FILE_NAME_PARSING_ERROR + e, e);
				return false;
			}
		}
		currentFile = file;
		billMediaMap = new HashMap();
		isBfmt = false;
		bfmtBatchCounter = 0;
		return success;
	}

    /**
     * Parses the most recently read line of the input file, determines what type of record it is, and passes it
     * to the appropriate routine for processing.
     * 
     * @param line
     *   The most recently read line of the input file.
     * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob
     * @throws Exception
     *   if any unhandled Exception is encountered, if the TRAILER record is not the last record on the processing file,
     *   if the HEADER record is not he first record on the processing file, and also if the DATE record does not
     *   immediately follow the HEADER record.
     */
	protected int parseLine(String line) throws Exception {
		String[] fields = line.split("[ ]*;[ ]*");
		
		if (trailerProcessed) {									// trailer must be last record on file
			throw new Exception("TRAILER was not the last record on currently processing file: " + currentFile.getName());
		}
		
		if (firstRecord) {										// header must be first record on file
			firstRecord = false;
			if ("HEADER".equalsIgnoreCase(fields[0])) {
				division = fields[2];
				return SUCCESS;
			} else {
				throw new Exception("HEADER was not the first record on currently processing file: " + currentFile.getName());
			}
		}
		
		if ("TRAILER".equalsIgnoreCase(fields[0])) {
			trailerProcessed = true;
			return processTrailerRecord(fields);
		}
		
		lineCount++;											// only header and trailer are uncounted
		
		if (lineCount == 1) {									// date record must be second record on file
			if ("RA14FMTR".equalsIgnoreCase(fields[0]) && "02".equals(fields[1])) {
				return processDateRecord(fields);
			} else {
				throw new Exception("DATE record did not immediately follow the HEADER on currently processing file: " + currentFile.getName());
			}
		}
		
		if ("RA14FMTR".equalsIgnoreCase(fields[0])) {
			if ("01".equals(fields[1])) {
				return insertBillFormatRecord(fields);
			}
		}
		
		warning(StaticErrorMsgKeys.INVAID_RECORD_TYPE + fields[0] + fields[1]);
		return ERROR;
	}
	
    /**
     * Processes the most recently read line of the input file, once it has been identified as a Date record.
     * 
     * @param fields
     *   an Array of the fields in the most recently read line of the input file.
     * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob
     */
	private int processDateRecord(String[] fields) {
		try {
			sqlRunDate = new java.sql.Date(yyyyDDD.parse(fields[2]).getTime());
			runDate = yyyyMMdd.format(sqlRunDate);
			billRnd = getBillRnd(runDate);
		} catch (SQLException e) {
			severe(StaticErrorMsgKeys.INSERT_ERROR + "Error occurred while acquiring billRnd for file: " + e, e);
			return ERROR;
		} catch (ParseException e) {
			severe(StaticErrorMsgKeys.PARSELINE_ERROR + "Error occurred while parsing Date on file: " + e, e);
			return ERROR;
		}
		
		if (backupRecovery) {
			for (int i = 0; i < tableNames.length; i++) {
				if (!PrepareTableForRerun.deleteTableData(connection, tableNames[i], division, sqlRunDate)) {
					severe("Error occurred attempting to backup and recover for rerun for table: " + tableNames[i]);
					return ERROR;
				}
			}
		}
		
		return SUCCESS;
	}
	
    /**
     * Processes the most recently read line of the input file, once it has been identified as a Trailer record.
     * Validates that the number of records processed is equal to the record count on the Trailer record.
     * Header and trailer records are the only records not included in the line count.
     * 
     * @param fields
     *   an Array of the fields in the most recently read line of the input file.
     * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob
     * @throws Exception
     *   if the line count on the trailer does not match the number of lines processed
     */
	private int processTrailerRecord(String[] fields) throws Exception {
		int totalRecords = Integer.parseInt(fields[5]);
		
		if (totalRecords == lineCount) {
			return SUCCESS;
		}
		
		throw new Exception("Record count mismatch, trailer record shows " + totalRecords + ", but " + lineCount + " records exist on file " + currentFile.getName());
	}
	
    /**
     * Performs an Insert to table RABC_BILL_PRT_SUMY, using the data from the most recently read line
     * of the input file.
     * 
     * @param fields
     *   an Array of the fields in the most recently read line of the input file.
     * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob.
     */
	private int insertBillFormatRecord(String[] fields) throws Exception {
		// If CUST_CLS_CD is blank then insert space
		if (fields[3]==null || "".equals(fields[3].trim())){
			fields[3] = " ";
		}
		// If DOC_CD is blank then insert space
		if (fields[5]==null || "".equals(fields[5].trim())){
			fields[5] = " ";
		}
		
		/*
		 * Change as per e mail on 8th January 2007 - Implement grouping
		 */
		BillMedia objRef	= null;
		long docCopyCt = Long.parseLong(fields[6]) / 1000000;
		BillMedia billMedia	= new BillMedia();
		billMedia.setRunDate(yyyyMMdd.parse(runDate));
		billMedia.setDivision(division);
		billMedia.setBillRound(billRnd);
		billMedia.setCustClsCd(fields[3]);
		billMedia.setDocCd(fields[5]);
		
		objRef = (BillMedia) billMediaMap.get(billMedia); 
		if (objRef != null){
			docCopyCt += objRef.getDocCopyCt() ;
			objRef.setDocCopyCt(docCopyCt);
			billMediaMap.put(objRef,objRef);
		} else {
			billMedia.setDocCopyCt(docCopyCt);
			billMediaMap.put(billMedia,billMedia);
		}
				
		return SUCCESS;
	}
	
	/**
	 * Performs the appropriate database query to retrieve the BillRnd value associated with the provided Date.
	 * 
	 * @param billRndDate
	 *   an String containing a Date in format 'yyyyMMdd', for which we want to retrieve the BillRnd.
	 * @return a long containing the retrieved BillRnd.
	 * @throws SQLException
	 *   if a database error is encountered while retrieving the BillRnd.
	 */
	private int getBillRnd(String billRndDate) throws SQLException {
		String query = "SELECT to_char(BILL_RND,'00') FROM RABC_CYCLE_CALENDAR WHERE PROC_DT = to_date('" + billRndDate + "','yyyyMMdd')";
		String billRnd = RetrieveStaticInfo.getBillRnd(connection, query);
		if ("00".equals(billRnd) || "".equals(billRnd)){
			billRnd = "0";
		}
		return Integer.parseInt(billRnd);
	}
	
	/**
	 * Processes once the file has been completely processed. Performs final batch execution of database calls. 
	 * Inserts Triggers for each data type that was processed during this run.
	 * 
	 * @param file
	 *   the currently processing file.
	 * @param success
	 *   the success so far for the application
	 * @return success for the application.
	 */
	public boolean postprocessFile(File file, boolean success) {
		try{

			//Log the file information to EMCIS_EVENT_LOG and EMCIS_EVENT_LOG_DETAIL
			EmcisEventLogger emcisLogger = new EmcisEventLogger();
			String event_id = "RABC_"+fileToken+"_"+region;
            String host = NetUtil.getLocalHostName();
            String hostIP = NetUtil.getLocalIpAddress();
			int sequence = emcisLogger.getEMCISSequence(connection);
			emcisLogger.insertEventLog(connection, sequence, event_id, sqlRunDate, host, hostIP);
			emcisLogger.insertEventLogDetail(connection, sequence, "FileName", fileName);

		}catch (UnknownHostException e) {
            severe("Error getting EMCIS host information ", e);
        }
		if (success) {
			try {
				/*
				 * Iterate through the entire hash map and insert entries into the RABC_BILL_PRT_SUMY table
				 */
				Set billMediaSet			= billMediaMap.keySet();
				Iterator billMediaIterator 	= billMediaSet.iterator();
				
				while (billMediaIterator.hasNext()){
					bfmtBatchCounter++;
					BillMedia billMedia	 = (BillMedia) billMediaIterator.next();
					
					insertBillFormat.setDate(1, sqlRunDate);								// RUN_DATE
					insertBillFormat.setString(2, division);								// DIVISION
					insertBillFormat.setString(3, billMedia.getCustClsCd());				// CUST_CLS_CD
					insertBillFormat.setString(4, billMedia.getDocCd());					// DOC_CD
					insertBillFormat.setLong(5, billRnd);									// BILL_RND
					insertBillFormat.setLong(6, billMedia.getDocCopyCt());					// DOC_COPY_CT
					
					insertBillFormat.addBatch();
					
					if (bfmtBatchCounter % 1000 == 0){
						insertBillFormat.executeBatch();
					}
					
					isBfmt = true;
				}
				
				/*
				 * Execute the batch after all entries in map are processed
				 */
				insertBillFormat.executeBatch();

				/*
				 * Check whether there were any trn record inserted, if yes then insert into trigger
				 */
				if (isBfmt && billRnd > 0) {
					if (!triggers.contains("SWBLGFMT")) {
						triggers.add("SWBLGFMT");
					}
				}
				
				if (!insertTrigger()) {
					severe(StaticErrorMsgKeys.POSTPROCESSFILE_ERROR
							+ StaticErrorMsgKeys.TIGGER_TABLE_INSERT_ERROR);
					success = false;
				}
			} catch (SQLException sqle) {
				severe(StaticErrorMsgKeys.INSERT_ERROR + " from method postprocessFile(String[] fields) " + sqle.getMessage(), sqle);
				success = false;
			}

		}
		return super.postprocessFile(file, success);
	}
	
	/**
	 * Inserts Triggers for each data type that was processed during this run.
	 * 
	 * @return true if all triggers were inserted, false otherwise.
	 */
	private boolean insertTrigger() {
		String recovery = null;
		
		if (lineCount > 0) {
			if (backupRecovery) {
				recovery = "Y";
			}
			
			for (int i = 0; i < triggers.size(); i++) {
				if (!RabcLoadJobTrig.insertTrigger(connection, currentFile.getName().substring(5, currentFile.getName().length()), currentFile.getName(), (String) triggers.get(i), division, MMddyyyy.format(sqlRunDate) , recovery, Long.toString(billRnd))) {
					return false;
				}
			}
		}
		return true;
	}
	
	/**
	 * Processes at the end of the application. Closes all open PreparedStatements.
	 * 
	 * @param success
	 *   the success of the application thus far
	 * @return success for the application.
	 */
	public boolean postprocess(boolean success) {
		JDBCUtil.closePreparedStatement(insertBillFormat);
		
		return super.postprocess(success);
	}

}
