package com.att.bac.rabc.load.accountdetail.calnet;

import java.io.File;
import java.io.FileFilter;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import com.att.bac.rabc.load.calnet.CalnetLoadUtil;
import com.att.bac.rabc.util.EmcisEventLogger;
import com.att.carat.util.NetUtil;
//changes for M168 by as635b
import com.att.carat.load.FileLoadJob;
import com.att.carat.load.FileSetDBLoadJob;
//import com.sbc.bac.load.FileLoadJob;
//import com.sbc.bac.load.FileSetDBLoadJob;
import com.sbc.bac.rabc.load.PrepareTableForRerun;
import com.sbc.bac.rabc.load.RabcLoadJobTrig;
import com.sbc.bac.rabc.load.RetrieveStaticInfo;
import com.sbc.bac.rabc.load.StaticErrorMsgKeys;
import com.sbc.bac.rabc.load.StaticFieldKeys;

/**
 * <p>Loads agency and account detail information, and generates an account average.</p>
 * <p>Job requires both the agency and account file for a given cycle, division, and region. </p>
 * <p>If the account file has an agency code that does not appear on the agency file (other than the 
 * "no agency" code), it will error out both files </p>
 * <p>All BTNs on the agency are unique</p>
 * <p>If an agency comes in on the agency file that is already stored in the agency info table, then the new data will
 * overwrite the old. There is no date information on agency table, so keeping a historical record with that table is impossible.</p>
 * 
 * <ul>
 * file names-
 * <li>account file - XT30CRIS file</li>
 * <li>agency file - XT30AGCY file</li>
 * </ul>
 * 
 * <ul>table names-
 * <li>account average table: RABC_ACCT_BLG_DTL_AVG</li>
 * <li>account detail table: RABC_ACCT_BLG_DTL</li> 
 * <li>agency info table: RABC_ACCT_INFO</li>
 * <li>trigger table: RABC_TRIG</li>
 * </ul> 
 * 
 * <ul>inserts into the following table -
 * <li>account detail table (based on info found on the account detail information)</li>
 * <li>account average table (based on values in the account detail table)</li>
 * <li>trigger table</li>
 * </ul>
 * <ul>updates -
 * <li>agency info table (based on info found in the agency file, with possible additional information from the detail file)</li> 
 * </ul>
 * 
 * <ul>selects from -
 * <li>agency info table (to determine if an agency exists. no need for prepopulation).</li>
 * </ul>
 * 
 * <ul>deletes from -
 * <li>account average table (clears old averages for data being loaded, or in case of rerun)</li>
 * <li>account detail table (in case of rerun)</li>
 * </ul>
 * other tables maybe required/modified by included classes. Please populate all necessary application data tables.
 * 
 * 
 * @author John Haggerty jh9874
 */
public class CalnetAccountDetailLoadJob extends FileSetDBLoadJob {
	//table names
	public static final String AGENCY_TABLE_NAME = "RABC_ACCT_INFO";
	public static final String DETAIL_TABLE_NAME = "RABC_ACCT_BLG_DTL";
	
	//error message prefixes...
	public static final String UNKNOWN_RECORD_LINE_PREFIX = "unknow type of line ";
	public static final String MISMATCH_RECORD_COUNT_PREFIX = "record count mismatch (internal line count, trailer record count): ";
	public static final String REPEAT_BTN_PREFIX ="repeat BTN in same file ";
	public static final String NO_AGENCY_FOR_BTN_PREFIX = "no agency for BTN ";
	
	//these are the position in the file array where the agency and account records are expected.
	private static final int XT30AGCY_INDEX = 0;
	private static final int XT30CRIS_INDEX = 1;
	
	//perpared statements... also see delete method for queries.
	//Added BOC_AMT field
	private static final String INSERT_DETAIL_QUERY = "insert into RABC_ACCT_BLG_DTL (CTCUSTID, BTN, AGENCY_ID, CURR_MNTH_CHRG_AMT, CURR_BAL_DUE_AMT, ADJ_AMT, OTR_BAL_ADJ_AMT, OCC_AMT, REG_DSCT_OCC_AMT, NRG_DSCT_OCC_AMT, MCC_AMT, REG_DSCT_MCC_AMT, NRG_DSCT_MCC_AMT, MNTH_SRV_AMT, EUCL_CHRG_AMT, TOLL_TOT_AMT, TOLL_SUB_AMT, TOT_DSCT_TOLL_AMT, DA_AMT, IEC_AMT, FED_TAX_AMT, STATE_TAX_AMT, CITY_TAX_AMT, BLG_SRCG_AMT, HCAP_SRCG_AMT, LFLN_SRCG_AMT, CPUC_SRCG_AMT, CHCFA_SRCG_AMT, CHCFB_SRCG_AMT, USSC_SRCG_AMT, ATT_SRCG_AMT, CTF_SRCG_AMT, SRV_USFF_AMT, CALL_900_AMT, ZONE1_AMT, ZONE1_CT, ZONE1_MOU, ZONE23_AMT, ZONE23_CT, ZONE23_MOU, DA_CT, RUN_DATE, BILL_RND, BILL_MM, BILL_YEAR, DIVISION, CYCLE, SD_UNDERGRD_SRCG_AMT, BOC_AMT) values "+
								"(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	
	private static final String INSERT_AGENCY_QUERY ="insert into RABC_ACCT_INFO (CTCUSTID, CRO_CD, BTN, AGENCY_ID, ACCT_CLS_CD, ACCT_NAME, ACCT_ACTIVE_IND) values (?, ?, ?, ?, ?, ?, ?)";
	
	private static final String UPDATE_AGENCY_QUERY ="update RABC_ACCT_INFO set CTCUSTID = ?, CRO_CD = ?,  AGENCY_ID = ?, ACCT_CLS_CD = ?, ACCT_NAME = ?, ACCT_ACTIVE_IND = ? where BTN = ?";
	
	private static final String CHECK_AGENCY_QUERY ="select ACCT_NAME from RABC_ACCT_INFO where btn = ?";
	
	private static final String AVERAGE_DETAIL_QUERY =	"INSERT INTO RABC_ACCT_BLG_DTL_AVG (RUN_DATE, DIVISION, BTN, AGENCY_ID, CTCUSTID, TOT_BLG_CHRG_AMT_AVG, CURR_MNTH_CHRG_AMT_AVG, CURR_BAL_DUE_AMT_AVG, ADJ_AMT_AVG, OTR_BAL_ADJ_AMT_AVG, OCC_AMT_AVG, NRG_DSCT_OCC_AMT_AVG, REG_DSCT_OCC_AMT_AVG, MCC_AMT_AVG, NRG_DSCT_MCC_AMT_AVG, REG_DSCT_MCC_AMT_AVG, MNTH_SRV_AMT_AVG, EUCL_CHRG_AMT_AVG, TOLL_SUB_AMT_AVG, TOT_DSCT_TOLL_AMT_AVG, ZONE1_AMT_AVG, ZONE1_CT_AVG, ZONE1_MOU_AVG, ZONE23_AMT_AVG, ZONE23_CT_AVG, ZONE23_MOU_AVG, TOLL_TOT_AMT_AVG, DA_AMT_AVG, DA_CT_AVG, IEC_AMT_AVG, " +
														"CALL_900_AMT_AVG, " +
														"FED_TAX_AMT_AVG, STATE_TAX_AMT_AVG, CITY_TAX_AMT_AVG, BLG_SRCG_AMT_AVG, HCAP_SRCG_AMT_AVG, LFLN_SRCG_AMT_AVG, CPUC_SRCG_AMT_AVG, CHCFA_SRCG_AMT_AVG, CHCFB_SRCG_AMT_AVG, USSC_SRCG_AMT_AVG, CTF_SRCG_AMT_AVG, ATT_SRCG_AMT_AVG, SRV_USFF_AMT_AVG, PAYMENT_AMT_AVG, SD_UNDERGRD_SRCG_AVG)" +
														" (SELECT MAX(RUN_DATE),DIVISION, BTN, AGENCY_ID, CTCUSTID" +
														",AVG(TOT_BLG_CHRG_AMT)"+
														",AVG(CURR_MNTH_CHRG_AMT)"+
														",AVG(CURR_BAL_DUE_AMT)" +
														",AVG(ADJ_AMT)" +
														",AVG(OTR_BAL_ADJ_AMT)"+
														",AVG(OCC_AMT)"+
														",AVG(NRG_DSCT_OCC_AMT)"+
														",AVG(REG_DSCT_OCC_AMT)" +
														",AVG(MCC_AMT)"+
														",AVG(NRG_DSCT_MCC_AMT)" +
														",AVG(REG_DSCT_MCC_AMT)"+
														",AVG(MNTH_SRV_AMT)"+
														",AVG(EUCL_CHRG_AMT)"+
														",AVG(TOLL_SUB_AMT)"+
														",AVG(TOT_DSCT_TOLL_AMT)"+
														",AVG(ZONE1_AMT)"+
														",AVG(ZONE1_CT)"+
														",AVG(ZONE1_MOU)"+
														",AVG(ZONE23_AMT)"+
														",AVG(ZONE23_CT)" +
														",AVG(ZONE23_MOU)" +
														",AVG(TOLL_TOT_AMT)"+
														",AVG(DA_AMT)"+
														",AVG(DA_CT)"+
														",AVG(IEC_AMT)"+
														",AVG(CALL_900_AMT)"+
														",AVG(FED_TAX_AMT)"+
														",AVG(STATE_TAX_AMT)"+
														",AVG(CITY_TAX_AMT)"+
														",AVG(BLG_SRCG_AMT)"+
														",AVG(HCAP_SRCG_AMT)"+
														",AVG(LFLN_SRCG_AMT)"+
														",AVG(CPUC_SRCG_AMT)"+
														",AVG(CHCFA_SRCG_AMT)"+
														",AVG(CHCFB_SRCG_AMT)"+
														",AVG(USSC_SRCG_AMT)"+
														",AVG(CTF_SRCG_AMT)"+
														",AVG(ATT_SRCG_AMT)"+
														",AVG(SRV_USFF_AMT)"+
														",AVG(PAYMENT_AMT)"+
														",AVG(SD_UNDERGRD_SRCG_AMT)"+														
														" FROM RABC_ACCT_BLG_DTL"+
														" WHERE DIVISION = ?"+
														" AND BTN = ? AND AGENCY_ID = ? AND CTCUSTID = ?" +
														" GROUP BY DIVISION, BTN, AGENCY_ID,CTCUSTID)";
	
	public static final String DELETE_AVERAGE_DETAIL_QUERY = "Delete from RABC_ACCT_BLG_DTL_AVG where DIVISION = ? and BTN = ? and AGENCY_ID = ? and CTCUSTID = ? ";
	
	//make static variables visible for testing
	public static final int SKIPPED = FileSetDBLoadJob.SKIPPED;
	public static final int ERROR = FileSetDBLoadJob.ERROR;
	public static final int SUCCESS = FileSetDBLoadJob.SUCCESS;
	
	//internal file filters used to pick up the agency and account files.
	private static final FileFilter XT30AGCY_FILTER =new FileFilter(){public boolean accept(File pathname) {
		return pathname.getName().matches(AgencyBean.FILE_NAME_PATTERN);
	}};
	private static final FileFilter XT30CRIS_FILTER= new FileFilter(){public boolean accept(File pathname){
		return pathname.getName().matches(AccountDetailBean.FILE_NAME_PATTERN);
	}};
	
	//common calnet2 loadjob variables.
	protected String region;
	protected String division;
	protected int cycle;
	protected String runDate;
	protected String billRndDate;
	protected Date sqlRunDate;
	protected int lineCount;
	protected String backoutRecovery;
	protected String billRnd;
	protected File currentFile;
	
	//stores all the agencies by their btn number.
	protected Map agenciesByBtn;
	
	//for batching. currently set to 1 due to issues with averaging. DO NOT CHANGE without fixing averaging.
	protected int batchsize = 1;
	
	private PreparedStatement insertDetail, insertAgency, updateAgency, checkAgency;
	private PreparedStatement deleteDetailAverage;
	private PreparedStatement insertDetailAverage;

	/**
	 * takes two files and see if they make a complete set (same cycle, division, and region).
	 * 
	 * @param xt30agcy the XT30AGCY file
	 * @param xt30cris the XT30CRIS file
	 * @return
	 */
	protected static boolean filesAreRelated(File xt30agcy, File  xt30cris){
		if(!AgencyBean.FILE_ID.equals(CalnetLoadUtil.getFileId(xt30agcy))){
			return false;
		}
		if(!AccountDetailBean.FILE_ID.equals(CalnetLoadUtil.getFileId(xt30cris))){
			return false;
		}
		if(CalnetLoadUtil.getCycle(xt30agcy) != CalnetLoadUtil.getCycle(xt30cris)){
			return false;
		}
		if(!CalnetLoadUtil.getDivision(xt30agcy).equals(CalnetLoadUtil.getDivision(xt30cris))){
			return false;
		}
		if(!CalnetLoadUtil.getRegion(xt30agcy).equals(CalnetLoadUtil.getRegion(xt30cris))){
			return false;
		}
		return true;
	}

	/**
	 * checks to see if we're ready to run. expects matching agency and account information.
	 * 
	 * developer's note: this is more streamlined version then the one used in FileSetDBLoadJob, and does not use the superclass.
	 * 
	 * @return true if we've got a complete set ready to run
	 * @see FileSetDBLoadJob#check()
	 */
	protected boolean check() {
		//first get the cris and agcy files
		File [] xt30agcy = source_directory.listFiles(XT30AGCY_FILTER);
		File [] xt30cris = source_directory.listFiles(XT30CRIS_FILTER);
		//build an array to hold the complete sets. make it as long as the shorter of the two
		List completeSets = new ArrayList(xt30agcy.length < xt30cris.length?xt30agcy.length:xt30cris.length);
		if(xt30agcy.length == 0 || xt30cris.length == 0){
			files = new File[0][];
			return false; //if one or both lists are zero length, then there is nothing to run;
		}
		for(int i = 0; i < xt30agcy.length; i++){
			for(int j = 0; j < xt30cris.length; j++){
				if(filesAreRelated(xt30agcy[i],xt30cris[j])){
					//files are related, add them to the complete set list and leave the inner loop.
					completeSets.add(new File [] {xt30agcy[i],xt30cris[j]}); //NOTE: it's important that the xt30agcy file goes first!
					break; 
				}
			}
		}
		files = (File [][]) completeSets.toArray(new File[completeSets.size()][]); //drop results into the files array
		return files.length > 0; //if we have at least one complete set, then we have a true check condition.
	}

	
	/**
	 * Scans though each complete file set to process the files.
	 * 
	 * developer's note: this is more streamlined version then the one used in FileSetDBLoadJob, and does not use the superclass.
	 * 
	 * @return success/failure of processing of the files.
	 * @see FileLoadJob#action()
	 */
	protected boolean action() {
		boolean success = true;
		try {
			for (int set_index = 0; set_index < files.length; set_index++) {
				boolean setSuccess = preprocessFileSet(files[set_index]);
				for (int file_index = 0; file_index < files[set_index].length && setSuccess; file_index++) {
					success = processFile(files[set_index][file_index]);
				}
				success &= postprocessFileSet(files[set_index], setSuccess);
			}
		} catch (SQLException e) {
			severe("SQLException: " + e.toString(),e);
			success = false;
		}
		return success;
	}

	/**
	 * Called prior to file set execution (before we ever process the agency or account file). All application specific preprocessing
	 * happens after a call to super.preprocessFileSet. The preparedstatements are setup. The agencies by btn map is initialized.
	 * The region, division, cycle, runDate, bill round date, and sql run date are either captured or generated. The database is checked
	 * to see if this is a rerun scenario.
	 * 
	 * @param files the matching agency/account pair. @see #XT30AGCY_INDEX @see #XT30CRIS_INDEX for correct positioning.
	 * @return true if there were no errors which should cause the file set to error out.
	 * @see FileSetDBLoadJob#preprocessFileSet(java.io.File[])
	 */
	protected boolean preprocessFileSet(File[] files) throws SQLException {
		if(!super.preprocessFileSet(files)){
			return false; //the super failed preprocessing, don't bother going any further.
		}
		boolean success = true;
		try {
			//setup the queries
			setupPreparedStatements();
			
			//parse the information from file name
			File file = files[XT30AGCY_INDEX]; //might as well use the info from the XT30AGCY file.
			region = CalnetLoadUtil.getRegion(file);
			division = CalnetLoadUtil.getDivision(file);
			if (division == null){ //shouldn't happen, but it's in the rest of the load jobs... fix here.
				return false;
			}
			cycle = CalnetLoadUtil.getCycle(file);
			runDate = getProcDateByCycle();
			billRndDate = getBillRoundDateByCycle();
			if (runDate.equals(StaticFieldKeys.ZERO)) {
				severe(StaticErrorMsgKeys.NORECORD_RABC_CYCLE_CALENDAR + cycle);
				throw new Exception();
			}

			DateFormat df = new SimpleDateFormat("MMddyyyy");
			sqlRunDate = new java.sql.Date(df.parse(runDate).getTime());

			backoutRecovery = null;

			//since the XT30AGCY is mostly static, work off the CRIS file.
			if (isFileLoaded(files[XT30CRIS_INDEX])) {
				success = deleteTable(); //if the file is there, clear the tables.
			}

			billRnd = getBillRndByCycle(cycle);

		} catch (Exception e) {
			severe(StaticErrorMsgKeys.PREPROCESSFILE_ERROR
					+ StaticErrorMsgKeys.FILE_NAME_PARSING_ERROR + e,e);
			return false;
		}

		agenciesByBtn = new HashMap();
		return success;
	}

	
	/**
	 * sets up the prepared statements used by this load job.
	 * @throws SQLException
	 */
	protected void setupPreparedStatements() throws SQLException {
		insertDetail = connection.prepareStatement(INSERT_DETAIL_QUERY);
		insertAgency = connection.prepareStatement(INSERT_AGENCY_QUERY);
		updateAgency = connection.prepareStatement(UPDATE_AGENCY_QUERY);
		checkAgency = connection.prepareStatement(CHECK_AGENCY_QUERY);
		deleteDetailAverage = connection.prepareStatement(DELETE_AVERAGE_DETAIL_QUERY);
		insertDetailAverage = connection.prepareStatement(AVERAGE_DETAIL_QUERY);
	}


	/**
	 * gets the String representation of the bill round date based on the cycle. 
	 * 
	 * @return the bill round date in the expected String format.
	 * @throws SQLException
	 * @see RetrieveStaticInfo#getbillRndDt_ByCycle(Connection, int)
	 */
	protected String getBillRoundDateByCycle() throws SQLException {
		return RetrieveStaticInfo.getbillRndDt_ByCycle(connection, cycle);
	}

	
	/**
	 * gets the String representation of the process date based on the cycle. 
	 * @return the process date in the expected String format
	 * @throws SQLException
	 * @see RetrieveStaticInfo#getProc_dtByCycle(Connection, int)
	 */
	protected String getProcDateByCycle() throws SQLException {
		return RetrieveStaticInfo.getProc_dtByCycle(connection, cycle);
	}

	
	/**
	 * checks to see if the file has already been loaded.
	 * @param xt30cris
	 * @return true if the file is loaded
	 * @see RabcLoadJobTrig#IsFileLoaded(Connection, File);
	 */
	protected boolean isFileLoaded(File xt30cris){
		return RabcLoadJobTrig.IsFileLoaded(connection, xt30cris);
	}

	
	/**
	 * determines the bill round by cycle.
	 * @param cycle
	 * @return the bill round as a String.
	 * @throws SQLException
	 * @see RetrieveStaticInfo#getBillRndByCycle(Connection, int)
	 */
	protected String getBillRndByCycle(int cycle) throws SQLException{
		return RetrieveStaticInfo.getBillRndByCycle(connection, cycle).trim();
	}

	
	/**
	 * Clears the average and detail table for the current file, and flags this load as a rerun scenario.
	 * @return true if no problems were encountered.
	 * @see PrepareTableForRerun#deleteTableData(Connection, String, String, java.sql.Date)
	 */
	protected boolean deleteTable(){
		backoutRecovery = "Y";
		boolean success = false;
		String tableNm = "RABC_ACCT_BLG_DTL";
		success = PrepareTableForRerun.deleteTableData(connection,tableNm,division,sqlRunDate);
		tableNm = "RABC_ACCT_BLG_DTL_AVG";
		success = PrepareTableForRerun.deleteTableData(connection,tableNm,division,sqlRunDate);
		return success;
	}
	
	/**
	 * Clears the line count prior to running each file. calls super.preprocessFile(java.io.File)
	 * @see com.sbc.bac.load.FileDBLoadJob#preprocessFile(java.io.File)
	 */
	protected boolean preprocessFile(File file) {
		boolean success =  super.preprocessFile(file);
		lineCount = 0; //clear the line count for the current file processing.
		return success;
	}
	
	

	/**
	 * Identifies all records (lines) and sends them to the appropriate handler. Header records are skipped.
	 * 
	 * @see com.sbc.bac.load.FileDBLoadJob#parseLine(java.lang.String)
	 */
	protected int parseLine(String line) throws Exception {
		if (line.length() < 10)
			return SKIPPED;
		
		if(CalnetLoadUtil.isHeader(line )){
			return SKIPPED;
		}else if (CalnetLoadUtil.isTrailer(line)){
			return handleTrailerRecord(line);
		}else if( AgencyBean.FILE_ID.equals(line.substring(0,8))){
			lineCount++;
			return parseAgencyRecord(line);
		}else if( AccountDetailBean.FILE_ID.equals(line.substring(0,8))){
			lineCount++;
			return parseAccountDetail(line);
		}
		severe(UNKNOWN_RECORD_LINE_PREFIX+line);
		return ERROR;
	}
	

	/**
	 * parses out the trailer record count and matches against the local count. 
	 * This is the count of data records only (no header, trailer).
	 * 
	 * @param trailerRecord a String in the trailer record format.
	 * @return SUCCESS or ERROR code.
	 * @see #SUCCESS @see #ERROR
	 */
	protected int handleTrailerRecord(String trailerRecord){
		StringTokenizer st = new StringTokenizer(trailerRecord,";");
		st.nextToken(); //Trailer ... ignore it.
		st.nextToken(); //region ... guess we could check it.
		st.nextToken(); //division ... guess we could check it.
		st.nextToken(); //current date ... ignore it.
		st.nextToken(); //current time ... ignore it.
		int recordCount = Integer.parseInt(st.nextToken());
		if(recordCount == lineCount){
			return SUCCESS;
		}else{
			severe(MISMATCH_RECORD_COUNT_PREFIX +lineCount+","+recordCount);
			return ERROR;
		}
	}
	
	
	/**
	 * handles the parsing of a line from the agency file. Generates an AgencyBean and stores it in the 
	 * agencyByBtn map with the BTN as the key. If the same BTN appears twice or more on the agency file,
	 * it is considered an error and the file set should be errored out.
	 * 
	 * @param line a String in the agency record format.
	 * @return SUCCESS or ERROR if there's a repeated BTN.
	 */
	protected int parseAgencyRecord(String line){
		AgencyBean agency = AgencyBean.valueOf(line);
		if(agenciesByBtn.put(agency.getBtn(), agency) != null){
			severe(REPEAT_BTN_PREFIX+agency.getBtn());
			return ERROR;
		}
		return SUCCESS;
	}

	
	/**
	 * handles the parsing of a line from the account detail file. Finds and updates agency information (if necessary), inserts the
	 * row, and updates the average. 
	 * @param line a String in the account detail format.
	 * @return SUCCESS or ERROR if there is no agency for the btn or the shared agency information does not match the account information.
	 * @throws SQLException
	 */
	protected int parseAccountDetail(String line) throws SQLException{
		
		//parse
		AccountDetailBean detail = AccountDetailBean.valueOf(line);
		//
		if(detail.isAgencyDetail()){
			//get the agency detail
			AgencyBean agency = (AgencyBean) agenciesByBtn.get(detail.getBtn());
			if(agency == null){
				//no agency in the agency file... ERROR!
				severe(NO_AGENCY_FOR_BTN_PREFIX+detail.getBtn());
				return ERROR;
			}
			//agency/detail issue
			if(!agencyDetailLogic(agency, detail.buildAgencyBean())){
				return ERROR;
			}
			
		}
		return insertAccountDetail(detail);
	}

	
	/**
	 * inserts account detail information into the account detail information table (RABC_ACCT_BLG_DTL) and updates the average information.
	 * 
	 * @param detail the AccountDetailBean to insert
	 * @return SUCCESS or ERROR
	 * @throws SQLException
	 */
	protected int insertAccountDetail(AccountDetailBean detail) throws SQLException{
		/*
		 * INSERT_DETAIL_QUERY = "insert into RABC_ACCT_BLG_DTL (CTCUSTID, BTN, AGENCY_ID, CURR_MNTH_CHRG_AMT, CURR_BAL_DUE_AMT, ADJ_AMT, 
		 * 						OTR_BAL_ADJ_AMT, OCC_AMT, REG_DSCT_OCC_AMT, NRG_DSCT_OCC_AMT, MCC_AMT, REG_DSCT_MCC_AMT, NRG_DSCT_MCC_AMT, 
		 * 						MNTH_SRV_AMT, EUCL_CHRG_AMT, TOLL_TOT_AMT, TOLL_SUB_AMT, TOT_DSCT_TOLL_AMT, DA_AMT, IEC_AMT, FED_TAX_AMT, 
		 * 						STATE_TAX_AMT, CITY_TAX_AMT, BLG_SRCG_AMT, HCAP_SRCG_AMT, LFLN_SRCG_AMT, CPUC_SRCG_AMT, CHCFA_SRCG_AMT, 
		 * 						CHCFB_SRCG_AMT, USSC_SRCG_AMT, ATT_SRCG_AMT, CTF_SRCG_AMT, SRV_USFF_AMT, CALL_900_AMT, ZONE1_AMT, ZONE1_CT, 
		 * 						ZONE1_MOU, ZONE23_AMT, ZONE23_CT, ZONE23_MOU, DA_CT, RUN_DATE, BILL_RND, BILL_MM, BILL_YEAR, DIVISION, CYCLE) values "+
		 *					"(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)";
		 */
		try {
			insertDetail.setString(1, detail.getBillingAccountId());	//CTCUSTID
			insertDetail.setString(2, detail.getBtn());					//BTN
			insertDetail.setString(3, detail.getAgencyId());			//AGENCY_ID
			insertDetail.setDouble(4, detail.getCurrentMonthChargeAmt() );	//CURR_MNTH_CHRG_AMT
			insertDetail.setDouble(5, detail.getCurrentBalanceDueAmt());	//CURR_BAL_DUE_AMT
			insertDetail.setDouble(6, detail.getAdjustmentAmount());		//ADJ_AMT
			insertDetail.setDouble(7, detail.getOtherBalanceAdjAmts());		//OTR_BAL_ADJ_AMT
			insertDetail.setDouble(8, detail.getOccAmount());			//OCC_AMT
			insertDetail.setDouble(9, detail.getRegDsctOccAmt());		//REG_DSCT_OCC_AMT
			insertDetail.setDouble(10, detail.getNrgDsctOccAmt());		//NRG_DSCT_OCC_AMT
			insertDetail.setDouble(11, detail.getMccAmount());			//MCC_AMT
			insertDetail.setDouble(12, detail.getRegDsctMccAmt());		//REG_DSCT_MCC_AMT
			insertDetail.setDouble(13, detail.getNrgDsctMccAmt() );		//NRG_DSCT_MCC_AMT
			insertDetail.setDouble(14, detail.getMonthlyServiceAmount());	//MNTH_SRV_AMT
			insertDetail.setDouble(15, detail.getEuclChargeAmount());	//EUCL_CHRG_AMT
			insertDetail.setDouble(16, detail.getTollTotalAmount());	//TOLL_TOT_AMT
			insertDetail.setDouble(17, detail.getTollSubAmount());		//TOLL_SUB_AMT
			insertDetail.setDouble(18, detail.getTotDsctTollAmt());		//TOT_DSCT_TOLL_AMT
			insertDetail.setDouble(19, detail.getDaAmt());				//DA_AMT
			insertDetail.setDouble(20, detail.getIecAmt());				//IEC_AMT
			insertDetail.setDouble(21, detail.getFedTaxAmount());		//FED_TAX_AMT
			insertDetail.setDouble(22, detail.getStateTaxAmount());		//STATE_TAX_AMT
			insertDetail.setDouble(23, detail.getCityTaxAmount());		//CITY_TAX_AMT
			insertDetail.setDouble(24, detail.getBlgSrcgAmt());			//BLG_SRCG_AMT
			insertDetail.setDouble(25, detail.getHcapSrcgAmt());		//HCAP_SRCG_AMT
			insertDetail.setDouble(26, detail.getLflnSrcgAmt());		//LFLN_SRCG_AMT
			insertDetail.setDouble(27, detail.getCpucSrcgAmt());		//CPUC_SRCG_AMT
			insertDetail.setDouble(28, detail.getChcfaSrcgAmt());		//CHCFA_SRCG_AMT
			insertDetail.setDouble(29, detail.getChcfbSrcgAmt());		//CHCFB_SRCG_AMT
			insertDetail.setDouble(30, detail.getUsscSrcgAmt());		//USSC_SRCG_AMT
			insertDetail.setDouble(31, detail.getAttSrcgAmt());			//ATT_SRCG_AMT
			insertDetail.setDouble(32, detail.getCtfSrcgAmt());			//CTF_SRCG_AMT
			insertDetail.setDouble(33, detail.getSrvUssfAmt());			//SRV_USFF_AMT
			insertDetail.setDouble(34, detail.getCallAmt900());			//CALL_900_AMT
			insertDetail.setDouble(35, detail.getZone1amt());			//ZONE1_AMT
			insertDetail.setInt(36, detail.getZone1ct());				//ZONE1_CT
			insertDetail.setDouble(37, detail.getZone1mou());			//ZONE1_MOU
			insertDetail.setDouble(38, detail.getZone23amt());			//ZONE23_AMT
			insertDetail.setInt(39, detail.getZone23ct());				//ZONE23_CT
			insertDetail.setDouble(40, detail.getZone23mou());			//ZONE23_MOU
			insertDetail.setInt(41, detail.getDaCt());					//DA_CT
			insertDetail.setDate(42, sqlRunDate);						//RUN_DATE
			insertDetail.setString(43, billRnd);						//BILL_RND
			insertDetail.setString(44,billRndDate.substring(0,2));		//BILL_MM
			insertDetail.setString(45,billRndDate.substring(4,8));		//BILL_YEAR
			insertDetail.setString(46, division);						//DIVISION
			insertDetail.setInt(47, cycle); 							//CYCLE		
			insertDetail.setDouble(48, detail.getSdUndergrdSrcgAmt());	//SD_UNDERGRD_SRCG_AMT
			insertDetail.setDouble(49, detail.getBocAmt());				//BOC_AMT	Added BOC AMT field
			if(insertDetail.executeUpdate() != 1){
				return ERROR;
			}
			//matching RABC... not sure this is this best method.
			if(!billRnd.equals(StaticFieldKeys.ZERO)){
				averageDetail(detail);
			}
			return SUCCESS;
		} catch (SQLException e) {
			severe("insertXt30Cris encounter an SQLException "+e +" "+detail, e);
			return ERROR;
		}
	}

	/**
	 * @param detail
	 * @throws SQLException
	 */
	protected void averageDetail(AccountDetailBean detail) throws SQLException {
		//need to delete prior to each individual insert. We only want one average per btn. 
		//we could clean out all the averages, but I don't wanna.
		//probably a better way to do it is probably out there.
		deleteDetailAverage.setString(1,division);
		deleteDetailAverage.setString(2,detail.getBtn());
		deleteDetailAverage.setString(3,detail.getAgencyId());
		deleteDetailAverage.setString(4,detail.getBillingAccountId());
		deleteDetailAverage.execute();

		insertDetailAverage.setString(1,division);
		insertDetailAverage.setString(2,detail.getBtn());
		insertDetailAverage.setString(3,detail.getAgencyId());
		insertDetailAverage.setString(4,detail.getBillingAccountId());
		insertDetailAverage.execute();
	}

	
	/**
	 * updates agency information. Make sure that previously entered agency information is not contradicted by new account detail information.
	 * @param agency the old agency data (either directly from the agency file, or previously updated by an account detail)
	 * @param modAgency the new data (generated from the account detail information).
	 * @return true if there are no problems. false if there's an unacceptable mismatch
	 */
	protected boolean agencyDetailLogic(AgencyBean agency, AgencyBean modAgency){
		if(modAgency.equals(agency)){
			//perfect match, we're done.
			return true;
		}
		if(agency.isFromAgencyFile()){
			//update the agency from the detail file.
			agenciesByBtn.put(modAgency.getBtn(), modAgency);
			return true;
		}
		//problem... determine the cause.
		String errorPattern = "Mismatched {0} {1}. {2} -> {3} ({4})";
		if(!agency.getAccountClassCode().equals(modAgency.getAccountClassCode())){
			severe(MessageFormat.format(errorPattern, new String [] {"account class code","on detail file",
								agency.getAccountClassCode(),modAgency.getAccountClassCode(),agency.getBtn()}));
			return false;
		}
		if(!agency.getAccountName().equals(modAgency.getAccountName())){
			severe(MessageFormat.format(errorPattern, new String [] {"account name","on detail file",
					agency.getAccountName(),modAgency.getAccountName(),agency.getBtn()}));
			return false;
		}
		if(!agency.getActiveAccountInd().equals(modAgency.getActiveAccountInd())){
			severe(MessageFormat.format(errorPattern, new String [] {"active account ind","on detail file",
					agency.getActiveAccountInd(),modAgency.getActiveAccountInd(),agency.getBtn()}));
			return false;
		}
		if(!agency.getAgencyId().equals(modAgency.getAgencyId())){
			severe(MessageFormat.format(errorPattern, new String [] {"agency id","between detail and agency file",
					agency.getAgencyId(),modAgency.getAgencyId(),agency.getBtn()}));
			return false;
		}
		if(!agency.getBillingAccountId().equals(modAgency.getBillingAccountId())){
			severe(MessageFormat.format(errorPattern, new String [] {"billing account id","between detail and agency file",
					agency.getBillingAccountId(),modAgency.getBillingAccountId(),agency.getBtn()}));
			return false;
		}
		if(!agency.getCroCode().equals(modAgency.getCroCode()) ){
			severe(MessageFormat.format(errorPattern, new String [] {"cro code","between detail and agency file",
					agency.getCroCode(),modAgency.getCroCode(),agency.getBtn()}));
			return false;
		}
		severe("Mismatch agency records reasons unknown. "+agency+" "+modAgency);
		return false;
	}

	/**
	 * Called after each file. Overridden to avoid moving part of an errored set to the archive file.
	 */
	protected int postprocessFileOpt(File file, int success) {
		boolean temp = postprocessFile(file, success == SUCCESS);
		if (success == SUCCESS && temp == false) {
			success = ERROR;
		}
		if (success == SUCCESS) {
			info("Finished file '" + file.getName() + "' / time elapsed = " + (System.currentTimeMillis() - timestamp) + "ms / lines processed = " + counter[SUCCESS] + " / lines skipped = " + counter[SKIPPED] + " / lines per second = " + (int) ((counter[SUCCESS] * 1.0 / ((System.currentTimeMillis() - timestamp) * 0.001))));
		} 
		else if(success == EMPTY_FILE) {
			info("Finished empty file '" + file.getName() + "' / time elapsed = " + (System.currentTimeMillis() - timestamp) + "ms / lines processed = " + counter[SUCCESS] + " / lines skipped = " + counter[SKIPPED] + " / lines per second = " + (int) ((counter[SUCCESS] * 1.0 / ((System.currentTimeMillis() - timestamp) * 0.001))));
		}
		else if (success == SKIPPED) {
			info("Skipped file '" + file.getName() + "'");
		} else if (success == ERROR) {
			severe("Errored out file '" + file.getName() + "'");
		}
		return success;
	}


	/**
	 * called after a set is finished processing. calls the handleAgency method to store agency information.
	 */
	protected boolean postprocessFileSet(File[] files, boolean success) {
		try{
			//Log the file information to EMCIS_EVENT_LOG and EMCIS_EVENT_LOG_DETAIL
			EmcisEventLogger emcisLogger = new EmcisEventLogger();
			String host = NetUtil.getLocalHostName();
	        String hostIP = NetUtil.getLocalIpAddress();
	        String event_id = "";
			for(int i = 0; i<files.length; i++){
				if(files[i].getName().contains("XT30AGCY")){
					event_id = "RABC_"+AgencyBean.FILE_ID+"_"+region;
				}else{
					event_id = "RABC_"+AccountDetailBean.FILE_ID+"_"+region;
				}
				
				int sequence = emcisLogger.getEMCISSequence(connection);
				emcisLogger.insertEventLog(connection, sequence, event_id, sqlRunDate, host, hostIP);
				emcisLogger.insertEventLogDetail(connection, sequence, "FileName", files[i].getName());
			}
		}catch (UnknownHostException e) {
            severe("Error getting EMCIS host information ", e);
        }
		if (success && handleAgencies()) {
			if (!insertTrigger(files[XT30CRIS_INDEX])) {
				severe(StaticErrorMsgKeys.POSTPROCESSFILE_ERROR
						+ StaticErrorMsgKeys.TIGGER_TABLE_INSERT_ERROR);
				success = false;
			}
		}
		closePreparedStatements();
		return super.postprocessFileSet(files, success);
	}

	
	/**
	 * closes all the prepared statements that the job uses.
	 * @return
	 */
	protected boolean closePreparedStatements() {
		boolean success = true;
		try {
			checkAgency.close();
			insertAgency.close();
			insertDetail.close();
			updateAgency.close();
			deleteDetailAverage.close();
			insertDetailAverage.close();
		} catch (SQLException e) {
			severe("SQLException on close "+e, e);
			success = false;
		}
		return success;
	}
	

	/**
	 * this method runs down all the agencies pulled from the agency file (XT30AGCY) and see if they're new or if they need to be 
	 * updated.
	 * @return true if there's no issues. false if it failed.
	 */
	protected boolean handleAgencies(){
		try {
			for(Iterator agencies = agenciesByBtn.values().iterator(); agencies.hasNext(); ){
				AgencyBean agency = (AgencyBean) agencies.next();
				if(doesAgencyExist(agency)){
					updateAgency(agency);
				}else{
					insertAgency(agency);
				}
			}
		} catch (SQLException e) {
			severe("handleAgencies failed due to exception "+e,e);
			return false;
		}
		return true;
	}
	
	
	/**
	 * checks to see if the agency already exists in the agency info table.
	 * @param agency
	 * @return true if the agency is already in the database.
	 * @throws SQLException
	 */
	protected boolean doesAgencyExist(AgencyBean agency) throws SQLException{
		boolean result = false;
		ResultSet rs = null;
		try {
			checkAgency.setString(1, agency.getBtn());
			rs = checkAgency.executeQuery();
			result = rs.next();
		} catch (SQLException e) {
			severe("checkAgency encountered an SQLException "+agency);
			throw e;
		}finally{
			try {
				if(rs != null){
					rs.close();
				}
			} catch (SQLException e) {
				severe("exception on clean up "+e,e);
				//don't need to do much more.
			}
		}
		return result;
	}

	
	/**
	 * updates an agency in the agency info table.
	 * @param agency
	 * @throws SQLException
	 */
	protected void updateAgency(AgencyBean agency) throws SQLException{
		//"update RABC_ACCT_INFO set CTCUSTID = ?, CRO_CD = ?,  AGENCY_ID = ?, ACCT_CLS_CODE = ?, ACCT_NAME = ?, ACCT_ACTIVE_IND = ? where BTN = ?";
		try {
			updateAgency.setString(1,agency.getBillingAccountId());
			updateAgency.setString(2, agency.getCroCode());
			updateAgency.setString(3, agency.getAgencyId());
			updateAgency.setString(4, agency.getAccountClassCode());
			updateAgency.setString(5, agency.getAccountName());
			updateAgency.setString(6, agency.getActiveAccountInd());
			updateAgency.setString(7, agency.getBtn());
			updateAgency.executeUpdate();
		} catch (SQLException e) {
			severe("updateAgency encountered an SQLException "+agency);
			throw e;
		}
		
	}

	
	/**
	 * Stores an agency in the agency info table.
	 * @param agency
	 * @throws SQLException
	 */
	protected void insertAgency(AgencyBean agency) throws SQLException{
		//"insert into RABC_ACCT_INFO (CTCUSTID, CRO_CD, BTN, AGENCY_ID, ACCT_CLS_CODE, ACCT_NAME, ACCT_ACTIVE_IND) values (?, ?, ?, ?, ?, ?, ?)";
		try {
			insertAgency.setString(1, agency.getBillingAccountId());
			insertAgency.setString(2, agency.getCroCode());
			insertAgency.setString(3, agency.getBtn());
			insertAgency.setString(4, agency.getAgencyId());
			insertAgency.setString(5, agency.getAccountClassCode());
			insertAgency.setString(6, agency.getAccountName());
			insertAgency.setString(7, agency.getActiveAccountInd());
			insertAgency.executeUpdate();
		} catch (SQLException e) {
			severe("insertAgency encountered an SQLException "+agency);
			throw e;
		}
	}
	

	/**
	 * Inserts a record into the trigger table indicating that file has been processed for a given run
	 * date
	 * 
	 * @return boolean indicating success or failure
	 * @see RabcLoadJobTrig#insertTrigger(Connection, String, String, String, String, String, String)
	 */
	protected boolean insertTrigger(File file) {
		return RabcLoadJobTrig.insertTrigger(connection,file.getName() , AccountDetailBean.FILE_ID,
				division, runDate, backoutRecovery, billRnd);
	}

/*
 * UNIT TESTING RELATED METHODS
 * These are used to access certain member values. And yes, they are package private for a reason.
 */
	void setSourceDirectory(File sourceDir){
		this.source_directory = sourceDir;
	}
	
	File [][] getFiles(){
		return files;
	}

	String getBackoutRecovery() {
		return backoutRecovery;
	}

	String getBillRnd() {
		return billRnd;
	}
	
	void setBillRnd(String billRnd) {
		this.billRnd = billRnd;
	}

	String getBillRndDate() {
		return billRndDate;
	}
	
	void setBillRndDate(String billRndDate) {
		this.billRndDate = billRndDate;
	}

	int getCycle() {
		return cycle;
	}

	String getDivision() {
		return division;
	}

	String getRegion() {
		return region;
	}

	String getRunDate() {
		return runDate;
	}

	Date getSqlRunDate() {
		return sqlRunDate;
	}
	
	void setSqlRunDate(Date sqlRunDate) {
		this.sqlRunDate = sqlRunDate;
	}
	
	Connection getConnection(){
		return connection;
	}
	
	void setConnection(Connection connection){
		this.connection = connection;
	}
}