/* Created by Prachi Chhabra (PC2774) on Dec 19, 2006.
Copyright 2006-2008 AT&T Knowledge Ventures. All rights reserved. */

package com.att.bac.rabc.load.usage.calnet;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.att.bac.rabc.load.usage.calnet.BillDayUsgPlanActv;

import com.att.bac.rabc.load.calnet.CalnetDAO;
import com.att.bac.rabc.load.calnet.CalnetException;
import com.att.bac.rabc.load.calnet.CalnetDTO;

/**
 * Data Access Object class for RABC_BILLDAY_USG_PLAN_ACTVT table.
 * It is used to perform database operation on this table.
 * @author PC2774
 */
public class BillDayUsgPlanActvDAO extends CalnetDAO {

	private static final String INSERT_SQL = "INSERT INTO RABC_BILLDAY_USG_PLAN_ACTVT(RUN_DATE,DIVISION, " +
			"CYCLE,AGENCY_ID,USG_PLAN_CD,BUS_RES_IND,TOT_MINS_OF_USE,TOT_MSG_CT,TOT_BLG_CHGS,TOT_BLG_DSCT, " +
			"TOT_MINS_MSG_ALWN,TOT_AMT_ALWN,TOT_NUM_OF_ACCTS,AMT_PER_UNIT,BILL_RND,BILL_MM,BILL_YEAR) " +
			"VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

	/**
	 * Returns the insert statement used to insert a record into RABC_BILLDAY_USG_PLAN_ACTVT table.
	 *@return Returns the insert statement
	 */
	protected String getInsertSql(){
		return INSERT_SQL;
	}

	/**
	 * Reads the field values from passed DTO object and sets as corresponding parameters of the PreparedStatement
	 * @param pstmt - PreparedStatement object for setting the parameters.
	 * @param dataTransferObject - CalnetDTO for reading the field values.
	 * @throws CalnetException Throws exception when there is an error in setting the parameter.
	 */
	protected void setValues(PreparedStatement pstmt, CalnetDTO dataTransferObject)
				throws CalnetException{
		BillDayUsgPlanActv actv = (BillDayUsgPlanActv)dataTransferObject;
		try{
			pstmt.setDate(1, new Date(actv.getRunDate().getTime()));
			pstmt.setString(2, actv.getDivision());
			pstmt.setInt(3,actv.getCycle());
			pstmt.setString(4, actv.getAgencyID());
			pstmt.setInt(5, actv.getUsgPlanCd());
			pstmt.setString(6, actv.getBusResInd());
			pstmt.setDouble(7, actv.getTotMinsOfUse());
			pstmt.setLong(8, actv.getTotMsgCt());
			pstmt.setDouble(9, actv.getTotBlgChgs());
			pstmt.setDouble(10, actv.getTotBlgDsct());
			pstmt.setLong(11, actv.getTotMinsMsgAlwn());
			pstmt.setDouble(12, actv.getTotAmtAlwn());
			pstmt.setLong(13, actv.getTotNumOfAccts());
			pstmt.setDouble(14, actv.getAmtPerUnit());
			pstmt.setString(15, actv.getBillRnd());
			pstmt.setString(16, actv.getBillMm());
			pstmt.setString(17, actv.getBillYear());

		}catch(SQLException ex){
			throw new CalnetException("Error setting values in prepared statement: AgencyID: "
											+ actv.getAgencyID() + ex.getMessage(), ex);
		}
	}
}
