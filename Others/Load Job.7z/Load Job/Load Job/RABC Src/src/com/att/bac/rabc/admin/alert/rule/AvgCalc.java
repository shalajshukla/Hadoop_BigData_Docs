/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.admin.alert.rule;

/**
 * This is a Data Object to represent RABC_AVG_CALC table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class AvgCalc {
	private String alertRule;
	private int partiRefId;
	private int avgNumDate;
	private int avgNumRec;
	private String avgTrendTimeInd;
	private String avgTblName;
	private String avgType;

	/**
	 * @return Returns the AlertRule.
	 */
	public String getAlertRule() {
		return alertRule;
	}
	/**
	 * @return Returns the PartiRefId.
	 */
	public int getPartiRefId() {
		return partiRefId;
	}
	/**
	 * @return Returns the AvgNumDate.
	 */
	public int getAvgNumDate() {
		return avgNumDate;
	}
	/**
	 * @return Returns the AvgNumRec.
	 */
	public int getAvgNumRec() {
		return avgNumRec;
	}
	/**
	 * @return Returns the AvgTrendTimeInd.
	 */
	public String getAvgTrendTimeInd() {
		return avgTrendTimeInd;
	}
	/**
	 * @return Returns the AvgTblName.
	 */
	public String getAvgTblName() {
		return avgTblName;
	}
	/**
	 * @return Returns the AvgType.
	 */
	public String getAvgType() {
		return avgType;
	}

	/**
	 * @param AlertRule The alertRule to set.
	 */
	public void setAlertRule(String alertRule) {
		this.alertRule = alertRule;
	}
	/**
	 * @param PartiRefId The partiRefId to set.
	 */
	public void setPartiRefId(int partiRefId) {
		this.partiRefId = partiRefId;
	}
	/**
	 * @param AvgNumDate The avgNumDate to set.
	 */
	public void setAvgNumDate(int avgNumDate) {
		this.avgNumDate = avgNumDate;
	}
	/**
	 * @param AvgNumRec The avgNumRec to set.
	 */
	public void setAvgNumRec(int avgNumRec) {
		this.avgNumRec = avgNumRec;
	}
	/**
	 * @param AvgTrendTimeInd The avgTrendTimeInd to set.
	 */
	public void setAvgTrendTimeInd(String avgTrendTimeInd) {
		this.avgTrendTimeInd = avgTrendTimeInd;
	}
	/**
	 * @param AvgTblName The avgTblName to set.
	 */
	public void setAvgTblName(String avgTblName) {
		this.avgTblName = avgTblName;
	}
	/**
	 * @param AvgType The avgType to set.
	 */
	public void setAvgType(String avgType) {
		this.avgType = avgType;
	}
}
