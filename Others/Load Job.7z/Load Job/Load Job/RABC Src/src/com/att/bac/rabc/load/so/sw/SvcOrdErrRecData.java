package com.att.bac.rabc.load.so.sw;

import com.sbc.bac.rabc.load.HashCodeUtil;

public class SvcOrdErrRecData {


	//RUN_DATE, DIVISION, MKT_IND, SVC_ORD_TYPE, ERR_CD, SVC_ORD_ERR_CT
	private String mktInd ; 
	private String svcOrdType ;
	private String svcOrdErrCd;
	private long SVC_ORD_ERR_CT = 0 ;
	
	public String getMktInd() {
		return mktInd;
	}

	public void setMktInd(String mktInd) {
		this.mktInd = mktInd;
	}

	public String getSvcOrdType() {
		return svcOrdType;
	}

	public void setSvcOrdType(String svcOrdType) {
		this.svcOrdType = svcOrdType;
	}

	public long getSVC_ORD_ERR_CT() {
		return SVC_ORD_ERR_CT;
	}

	public void setSVC_ORD_ERR_CT(long svc_ord_err_ct) {
		SVC_ORD_ERR_CT = svc_ord_err_ct;
	}
	
	public boolean equals(Object o) {
		if ((o instanceof SvcOrdErrRecData) 
			  && ((SvcOrdErrRecData)o).getSvcOrdErrCd().equalsIgnoreCase(this.getSvcOrdErrCd())
			) 
		{
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * Hash code method used for categorizing the objects in sets so that 
	 * the hash collections can search efficiently
	 */
		
	public int hashCode() {
		int hashCode = HashCodeUtil.SEED;
		hashCode = HashCodeUtil.hash( hashCode, this.getSvcOrdType());
		hashCode = HashCodeUtil.hash( hashCode, this.getSvcOrdErrCd());
	    return hashCode;
	}
	
	public String getSvcOrdErrCd() {
		return svcOrdErrCd;
	}
	public void setSvcOrdErrCd(String svcOrdErrCd) {
		this.svcOrdErrCd = svcOrdErrCd;
	}
	
}
