/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.dashboard;

import java.util.Date;
/**
 * This is a Data Object to represent RABC_CYCLE_CALENDAR table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class CycleCalendar {
	private int cycle;
	private int billRnd;
	private Date procDt;
	private Date billRndDt;
	/**
	 * @return Returns the billRnd.
	 */
	public int getBillRnd() {
		return billRnd;
	}
	/**
	 * @param billRnd The billRnd to set.
	 */
	public void setBillRnd(int billRnd) {
		this.billRnd = billRnd;
	}
	/**
	 * @return Returns the billRndDt.
	 */
	public Date getBillRndDt() {
		return billRndDt;
	}
	/**
	 * @param billRndDt The billRndDt to set.
	 */
	public void setBillRndDt(Date billRndDt) {
		this.billRndDt = billRndDt;
	}
	/**
	 * @return Returns the cycle.
	 */
	public int getCycle() {
		return cycle;
	}
	/**
	 * @param cycle The cycle to set.
	 */
	public void setCycle(int cycle) {
		this.cycle = cycle;
	}
	/**
	 * @return Returns the procCt.
	 */
	public Date getProcDt() {
		return procDt;
	}
	/**
	 * @param procCt The procCt to set.
	 */
	public void setProcDt(Date procDt) {
		this.procDt = procDt;
	}
}
