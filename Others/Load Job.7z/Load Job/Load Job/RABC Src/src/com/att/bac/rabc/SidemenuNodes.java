/*
 * Created on Jan 17, 2006
 *
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TreeMap;

import javax.naming.NamingException;

import org.apache.log4j.Logger;

import com.att.carat.util.JDBCUtil;

/**
 * @author pt6471
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class SidemenuNodes {
	
	private static final Logger logger = Logger.getLogger(SidemenuNodes.class);
	
	private static TreeMap topLevelMap = new TreeMap();
	private static TreeMap level1Map = new TreeMap();
	private static final int REPORTS = 8888;
	private static final int ALERTS = 9999;
	
	public static synchronized void setSidemenuData(String region){


		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try{
			conn = ConnectionManager.getConnection(region);
			stmt = conn.createStatement();
			rs = stmt.executeQuery("SELECT presn_name, presn_seq_num FROM rabc_menu_index WHERE presn_type = 'P' AND presn_lvl = 1 ORDER BY presn_seq_num");
			
			while(rs.next()){  
				level1Map.put(Integer.toString(rs.getInt(2)) + ";" + rs.getString(1).trim() + ";", getLevel2ReportsData(rs.getString(1).trim(), region));
			}
			topLevelMap.put(REPORTS + ";REPORTS;",level1Map); 
			
			rs = stmt.executeQuery("SELECT   presn_name, presn_seq_num FROM rabc_menu_index WHERE presn_type = 'A' AND presn_lvl = 1 ORDER BY presn_seq_num");
			level1Map =  new TreeMap();
			
			while(rs.next()){
				level1Map.put(Integer.toString(rs.getInt(2)) + ";" + rs.getString(1).trim() + ";", getLevel2AlertsData(rs.getString(1).trim(), region));
			}
			topLevelMap.put(ALERTS + ";ALERTS;",level1Map); 
			
		}catch(SQLException sqle){
			logger.fatal("SQLException ", sqle);
		}catch(NamingException ne){
			logger.fatal("NamingException ", ne);
		}finally{
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closeStatement(stmt);
			JDBCUtil.closeConnection(conn);
		}	
	}
	

	static synchronized TreeMap getLevel2ReportsData(String presnName, String region){

		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		
		TreeMap level2Map = new TreeMap();
		
		try{
			conn = ConnectionManager.getConnection(region);
			stmt = conn.createStatement();
			StringBuffer sql = new StringBuffer();
			
			sql.append(" SELECT   bm1.presn_name, bm2.presn_name level2, ");
			sql.append("  bm2.presn_seq_num bm2_presn_seq_num, ");
			sql.append("  bm2.assoc_parent_id bm2_assoc_parent_id ");
			sql.append(" FROM rabc_menu_index bm1, rabc_menu_index bm2 ");
			sql.append(" WHERE bm1.presn_seq_num = bm2.assoc_parent_id ");
			sql.append(" AND bm1.presn_lvl = 1 ");
			sql.append(" AND bm2.presn_lvl = 2 ");
			sql.append(" AND bm1.presn_name = '").append(presnName).append("'");
			sql.append(" AND bm1.presn_type = 'P' ");
			sql.append(" AND bm2.presn_type = 'P' ");
			sql.append(" ORDER BY bm2.presn_seq_num, bm2.ASSOC_PARENT_ID ");
			

			
			rs = stmt.executeQuery(sql.toString());
			while(rs.next()){ 
				level2Map.put(Integer.toString(rs.getInt(4)) + Integer.toString(rs.getInt(3)) + ";" + rs.getString(2).trim() + ";", getLevel3ReportData(rs.getString(2).trim(),rs.getInt(3),rs.getInt(4),region));
			}
			
		
			
		}catch(SQLException sqle){
			logger.fatal("SQLException ", sqle);
		}catch(NamingException ne){
			logger.fatal("NamingException ", ne);
		}finally{
			try{
				
				try{
					rs.close();	
				}catch (SQLException sqle){
					logger.fatal("SQLException in releasing resources", sqle);
				}
				try{
					stmt.close();	
				}catch (SQLException sqle){
					logger.fatal("SQLException in releasing resources", sqle);
				}
				conn.close();
			}catch(SQLException sqle){
				logger.fatal("SQLException in releasing resources", sqle);
			}
		}	
		return level2Map;
	}

	static synchronized TreeMap getLevel2AlertsData(String presnName, String region){

		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		
		TreeMap level2AlertMap = new TreeMap();
		TreeMap level2TempMap = new TreeMap();
		ArrayList leve2Links = new ArrayList();
		String saveCtlPt = "";
		
		try{
			conn = ConnectionManager.getConnection(region);
			stmt = conn.createStatement();
			StringBuffer sql = new StringBuffer();
			
			
			sql.append(" SELECT DISTINCT bm1.presn_name, bm2.presn_name AS level2, ");
			sql.append(" bm2.presn_seq_num AS bm2_presn_seq_num, ");
			sql.append(" bm2.assoc_parent_id AS bm2_assoc_parent_id, ");
			sql.append(" rabc_alert_rule.std_type, bm2.presn_id, ca1.CNTRL_PT_CD, rabc_alert_rule.parti_ref_id ");
			sql.append(" FROM rabc_menu_index bm1, ");
			sql.append(" rabc_menu_index bm2, ");
			sql.append(" rabc_alert_rule, ");
			sql.append(" rabc_presn_id, RABC_CNTRL_PT_ALERT ca1 ");
			sql.append(" WHERE bm2.presn_id = rabc_alert_rule.presn_id ");
			sql.append(" AND rabc_alert_rule.presn_id = rabc_presn_id.presn_id ");
			sql.append(" AND UPPER (rabc_alert_rule.alert_rule_status) = 'ACTIVE' ");
			sql.append(" AND bm1.presn_seq_num = bm2.assoc_parent_id ");
			sql.append(" AND bm1.presn_lvl = 1 ");
			sql.append(" AND bm2.presn_lvl = 2 ");
			sql.append(" AND bm1.presn_name = '").append(presnName).append("' ");
			sql.append(" AND bm1.presn_type = 'A' ");
			sql.append(" AND bm2.presn_type = 'A' ");
			sql.append("AND bm2.ALERT_RULE =  ca1.ALERT_RULE ");
			sql.append(" ORDER BY UPPER(CA1.CNTRL_PT_CD), UPPER (bm2.presn_name) ");
			
			rs = stmt.executeQuery(sql.toString());
			/*
			 while(rs.next()){
				if (!saveCtlPt.equals(rs.getString("CNTRL_PT_CD").trim())){
					// add control point logic ??
					saveCtlPt = rs.getString("CNTRL_PT_CD").trim();
				}
				ArrayList tempL3list = new ArrayList();
				tempL3list = getLevel3AlertData(rs.getInt(3));
				if (tempL3list.size() > 0)
				level2Map.put("11" + ";" + rs.getString(2).trim() + ";" , tempL3list);
				else leve2Links.add("111;"+ "ALERTS;" +rs.getString(2).trim()+";");
			}
			*/
			
			while(rs.next()){
				
				if (!saveCtlPt.equals(rs.getString("CNTRL_PT_CD").trim())){
					// add control point logic ??
					if (saveCtlPt.equals(""))
					saveCtlPt = rs.getString("CNTRL_PT_CD").trim();
					else {
						level2AlertMap.put("11" + ";" + saveCtlPt + ";",level2TempMap);
						level2TempMap = new TreeMap();
						saveCtlPt = rs.getString("CNTRL_PT_CD").trim();
					}
				}
				
				ArrayList tempL3list = new ArrayList();
				tempL3list = getLevel3AlertData(rs.getInt(3), region);
				if (tempL3list.size() > 0)
					level2TempMap.put("44" + ";" + rs.getString(2).trim() + ";" , tempL3list);
				else level2TempMap.put(rs.getString(2).trim(), "111;"+ "P4;" + rs.getString(2).trim()+ ";" + rs.getString("parti_ref_id") + ";");
			}
			
			//level2AlertMap.put("11;" + presnName,leve2Links);
			
		}catch(SQLException sqle){
			logger.fatal("SQLException", sqle);
		}catch(NamingException ne){
			logger.fatal("NamingException ", ne);
		}finally{
			
			try{
				if (!saveCtlPt.equals("")) 
					level2AlertMap.put("11" + ";" + saveCtlPt + ";",level2TempMap);
				try{
					rs.close();	
				}catch (SQLException sqle){
					logger.fatal("SQLException in releasing resources", sqle);
				}
				try{
					stmt.close();	
				}catch (SQLException sqle){
					logger.fatal("SQLException in releasing resources", sqle);
				}
				conn.close();
			}catch(SQLException sqle){
				logger.fatal("SQLException in releasing resources", sqle);
			}
		}	
		return level2AlertMap;
	}
	static synchronized ArrayList getLevel3ReportData(String level2, int bm2_presn_seq_num, int bm2_assoc_parent_id, String region){

		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		ArrayList level3 = new ArrayList();
		try{
			conn = ConnectionManager.getConnection(region);
			stmt = conn.createStatement();
			StringBuffer sql = new StringBuffer();
			
			sql.append(" SELECT DISTINCT rabc_menu_index.presn_name level3, rabc_menu_index.presn_id ");
			sql.append(" FROM rabc_menu_index, rabc_presn_id ");
			sql.append(" WHERE rabc_menu_index.presn_id = rabc_presn_id.presn_id ");
			sql.append(" AND UPPER (rabc_presn_id.adhoc_rpt_status) = 'ACTIVE' ");
			sql.append(" AND rabc_menu_index.presn_lvl = 3 ");
			sql.append(" AND rabc_menu_index.presn_type = 'P' ");
			sql.append(" AND rabc_menu_index.assoc_parent_id = ").append(bm2_assoc_parent_id);
			
			sql.append(" AND rabc_menu_index.sub_assoc_parent_id = ").append(bm2_presn_seq_num);
			
			sql.append(" ORDER BY UPPER (rabc_menu_index.presn_name) ");
			
			rs = stmt.executeQuery(sql.toString());
			while(rs.next()){
				level3.add("111;"+ "REPORTS;"+ level2.trim()+";" + rs.getString(1)+";"  + rs.getString(2)+";");
			}
		}catch(SQLException sqle){
			logger.fatal("SQLException", sqle);
		}catch(NamingException ne){
			logger.fatal("NamingException ", ne);
		}finally{
			try{
				try{
					rs.close();	
				}catch (SQLException sqle){
					logger.fatal("SQLException in releasing resources", sqle);
				}
				try{
					stmt.close();	
				}catch (SQLException sqle){
					logger.fatal("SQLException in releasing resources", sqle);
				}
				conn.close();
			}catch(SQLException sqle){
				logger.fatal("SQLException in releasing resources", sqle);
			}
		}	
		return level3;
		
	}


	static synchronized ArrayList getLevel3AlertData(int bm2_sub_assoc_parent_id, String region){

		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		ArrayList level3 = new ArrayList();
		try{
			conn = ConnectionManager.getConnection(region);
			stmt = conn.createStatement();
			StringBuffer sql = new StringBuffer();
			
			sql.append(" SELECT DISTINCT rabc_menu_index.presn_name AS level3, ");
			sql.append(" rabc_menu_index.alert_rule, rabc_menu_index.presn_id, rabc_menu_index.sub_assoc_parent_id, parti_ref_id ");
			sql.append(" FROM rabc_menu_index, rabc_alert_rule ");
			sql.append(" WHERE rabc_menu_index.presn_id = rabc_alert_rule.presn_id ");
			sql.append(" AND UPPER (rabc_alert_rule.alert_rule_status) = 'ACTIVE' ");
			sql.append(" AND rabc_menu_index.presn_lvl = 3 ");
			sql.append(" AND rabc_menu_index.presn_type = 'A' ");
			sql.append(" AND rabc_menu_index.assoc_parent_id = 1 ");
			sql.append(" AND rabc_menu_index.sub_assoc_parent_id = ").append(bm2_sub_assoc_parent_id);
			sql.append(" ORDER BY UPPER (rabc_menu_index.presn_name) ");

			
			rs = stmt.executeQuery(sql.toString());
			while(rs.next()){
				level3.add("111;"+ "P5;" +rs.getString(1)+";" + rs.getString("parti_ref_id") + ";");
			}
		}catch(SQLException sqle){
			logger.fatal("SQLException", sqle);
		}catch(NamingException ne){
			logger.fatal("NamingException ", ne);
		}finally{
			try{
				try{
					rs.close();	
				}catch (SQLException sqle){
					logger.fatal("SQLException in releasing resources", sqle);
				}
				try{
					stmt.close();	
				}catch (SQLException sqle){
					logger.fatal("SQLException in releasing resources", sqle);
				}
				conn.close();
			}catch(SQLException sqle){
				logger.fatal("SQLException in releasing resources", sqle);
			}
		}	
		return level3;
		
	}

	private static String lock = new String();
	public static TreeMap getSidemenuData() {
		TreeMap ret = null;
		synchronized(lock){
			ret = topLevelMap;
		}
		//return level1Map;
		return ret;
	}

	 public static synchronized String createControlMenu(Collection collection){
	 	StringBuffer results = new StringBuffer("");
	 	return formatCollection(collection,results,1);
	 }
	 
	 public static String formatCollection(Collection collection, StringBuffer results, int level) {
	  	StringBuffer placeHolder = new StringBuffer("");
	    Iterator iterator = collection.iterator();
	    while (iterator.hasNext()) {
	    	 Map.Entry me = (Map.Entry)iterator.next();
	         Object ok = me.getKey();
	         Object ov = me.getValue();
	       if (((ov instanceof Map)||(ov instanceof ArrayList)))
	         	results.append(setAsNode(ok.toString()));
	       if (ov instanceof TreeMap){
	       		level++;
	       		Set testY = ((TreeMap)ov).entrySet();
	       		placeHolder.append(formatCollection(testY,results,level));
	       	}
	       if (ov instanceof ArrayList){
	   		ArrayList xx = new ArrayList(((ArrayList)ov));
	   			level++;
			   	for (int i=0;i< xx.size();i++){
			   		results.append(setAsNode(xx.get(i).toString()));
			   	}
	       }
	       if (!((ov instanceof Map)||(ov instanceof ArrayList)))
	       	results.append(setAsNode(ov.toString())); 
	   	 }
	    	return results.toString();
	 	}
	 
	 private static String  setAsNode(String nodeData){
	 	String nodeInfo = "";
	 	boolean link = false;
	 	StringTokenizer parseData = new StringTokenizer(nodeData, ";");
	 	int node = Integer.parseInt(parseData.nextToken().trim());
	 	int level = 2;
	 	if (node > 0 && node < 10)	level = 3;
	 	else if (node > 10 && node < 44) level = 4;
	 	else if (node >= 44 && node < 100) level = 5;
	 	else if (node > 100 && node < 999) {
	 		level = 5;
	 		link = true;
	 	}else if (node > 1000 && node < 2000) {
	 		level = 6;
	 		link = true;
	 	}
	 	else if (node == REPORTS || node == ALERTS) level = 2;
	 	if (level == 2) {
	 		nodeInfo= "new Node(menu, " + level + ", \"<font size=1 color=0059B3><b>" + parseData.nextToken().trim() + "</b></font>\");\n" ;
	 		return nodeInfo;
	 	}
	 	if (level == 3 || level == 4){
	 		nodeInfo= "new Node(menu, " + level + ", \"<font size=2>" + parseData.nextToken().trim() + "</font>\");\n" ;
	 		return nodeInfo;
	 	}
	 	if (level == 5 && !link){
	 		nodeInfo= "new Node(menu, " + level + ", \"<font size=2>" + parseData.nextToken().trim() + "</font>\");\n" ;
	 		return nodeInfo;
	 	}
	 	if (link){
	 		String linkLevel = parseData.nextToken().trim();
	 		if (linkLevel.equals("REPORTS")){
	 			if(parseData.nextToken().trim().equals("Alert Reports"))
	 				nodeInfo= "new Node(menu, 5,\"<span style =\\\"color: 0059B3; text-decoration: underline; fontFamily: Verdana; font-size:90%;\\\" onmouseover=\\\"style.color='gray',style.fontFamily='Verdana'\\\" onmouseout=\\\"style.color='0059B3',style.fontFamily='Verdana'\\\">" + parseData.nextToken().trim() + "</span>\", \"followLink(\\\"forwardTo=AdhocRpt.do&reportType=REPORTS_ALERTS&alertRuleSelect=0&presnIdAsString=" + parseData.nextToken().trim() + "\\\");\");\n" ;
	 			else 
	 				nodeInfo= "new Node(menu, 5,\"<span style =\\\"color: 0059B3; text-decoration: underline; fontFamily: Verdana; font-size:90%;\\\" onmouseover=\\\"style.color='gray',style.fontFamily='Verdana'\\\" onmouseout=\\\"style.color='0059B3',style.fontFamily='Verdana'\\\">" + parseData.nextToken().trim() + "</span>\", \"followLink(\\\"forwardTo=AdhocRpt.do&reportType=REPORTS_ADHOC&alertRuleSelect=0&presnIdAsString=" + parseData.nextToken().trim() + "\\\");\");\n" ;
	 		}
	 		else {
	 		if (linkLevel.equals("P3")) level = 4;
	 		else 
	 		if (linkLevel.equals("P4")) level = 5;
	 		else
	 		if (linkLevel.equals("P5")) level = 6;

	 		String alertRuleName = parseData.nextToken().trim();
	 		
	 		nodeInfo= "new Node(menu, " + level + ",\"<span style =\\\"color: 0059B3; text-decoration: underline; fontFamily: Verdana; font-size:90%;\\\" onmouseover=\\\"style.color='gray',style.fontFamily='Verdana'\\\" onmouseout=\\\"style.color='0059B3',style.fontFamily='Verdana'\\\">" + alertRuleName + "</span>\", \"followLink(\\\"forwardTo=AlertTrckMainPage.do&reportType=ALERTS&alertRule="+ alertRuleName + "&presnIDSelect=0&alertRuleSelect=" + parseData.nextToken().trim() + "\\\");\");\n" ;
	 		}
	 	}
	 	return nodeInfo;
	 }
	 
	 private static String getLink(){
	 	
	 	return "";
	 }
}
