/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.alerts.status;

import java.util.ArrayList;
import java.util.List;

import com.att.bac.rabc.ExtrctTblDef;
import com.att.bac.rabc.MyDate;
import com.att.bac.rabc.PickList;
import com.att.bac.rabc.admin.alert.rule.AlertRule;

/**
 * This class represents the data object that contains the attributes to be 
 * used to generate the graph.
 * 
 * @author Shailesh Hemdev - SH8512
 */
public class GraphParameters {
	private String alertrule;
	private String alertRuleFlag;
	private String alertItem;
	private String alertTimeInd;
	private String alertTimeValue;
	private String extractDateName;
	private String fileSeqNum;
	private String itemDDlName;
	private String key1;
	private String key2;
	private String key3;
	private String key4;
	private String key5;
	
	/*
	 * Parameters added to address exception in Page 13. Since page 13 cannot pass the parameter values as 
	 * expected by the graph program, this modification has been done in graph program despite redundancy
	 */
	private String akey1;
	private String akey2;
	private String akey3;
	private String akey4;
	private String akey5;
	private int partiRefId = -1;
	private MyDate procDate;
	private String tableName;
	private int presnId = -1;
	private String key1colname;
	private String graphBtn;
	private String graphType = "Line";
	private String extrctIndItem;
	private String columnName;
	private String columnValue;
	private String trendTimeInd;
	private int daySpan = -1;
	private MyDate startDate;
	private String header;
	private int divisioNameKeyLvl;
	private String error;
	private List buttonList = new ArrayList();
	private String yaxisTitle;
	private AlertRule alertRule;
	private ExtrctTblDef extrctTblDef;

	/**
	 * @return Returns the alertItem.
	 */
	public String getAlertItem() {
		return alertItem;
	}
	/**
	 * @param alertItem The alertItem to set.
	 */
	public void setAlertItem(String alertItem) {
		this.alertItem = alertItem;
	}
	/**
	 * @return Returns the alertrule.
	 */
	public String getAlertrule() {
		return alertrule;
	}
	/**
	 * @param alertrule The alertrule to set.
	 */
	public void setAlertrule(String alertrule) {
		this.alertrule = alertrule;
	}
	
	/**
	 * @return Returns the alertRuleFlag.
	 */
	public String getAlertRuleFlag() {
		return alertRuleFlag;
	}
	/**
	 * @param alertRuleFlag The alertRuleFlag to set.
	 */
	public void setAlertRuleFlag(String alertRuleFlag) {
		this.alertRuleFlag = alertRuleFlag;
	}
	/**
	 * @return Returns the columnName.
	 */
	public String getColumnName() {
		return columnName;
	}
	/**
	 * @param columnName The columnName to set.
	 */
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}
	
	/**
	 * @return Returns the columnValue.
	 */
	public String getColumnValue() {
		return columnValue;
	}
	/**
	 * @param columnValue The columnValue to set.
	 */
	public void setColumnValue(String columnValue) {
		this.columnValue = columnValue;
	}
	/**
	 * @return Returns the graphBtn.
	 */
	public String getGraphBtn() {
		return graphBtn;
	}
	/**
	 * @param graphBtn The graphBtn to set.
	 */
	public void setGraphBtn(String graphBtn) {
		this.graphBtn = graphBtn;
	}
	/**
	 * @return Returns the graphType.
	 */
	public String getGraphType() {
		return graphType;
	}
	/**
	 * @param graphType The graphType to set.
	 */
	public void setGraphType(String graphType) {
		this.graphType = graphType;
	}
	/**
	 * @return Returns the itemDDlName.
	 */
	public String getItemDDlName() {
		return itemDDlName;
	}
	/**
	 * @param itemDDlName The itemDDlName to set.
	 */
	public void setItemDDlName(String itemDDlName) {
		this.itemDDlName = itemDDlName;
	}
	/**
	 * @return Returns the key1.
	 */
	public String getKey1() {
		return key1;
	}
	/**
	 * @param key1 The key1 to set.
	 */
	public void setKey1(String key1) {
		this.key1 = key1;
	}
	/**
	 * @return Returns the key1colname.
	 */
	public String getKey1colname() {
		return key1colname;
	}
	/**
	 * @param key1colname The key1colname to set.
	 */
	public void setKey1colname(String key1colname) {
		this.key1colname = key1colname;
	}
	/**
	 * @return Returns the key2.
	 */
	public String getKey2() {
		return key2;
	}
	/**
	 * @param key2 The key2 to set.
	 */
	public void setKey2(String key2) {
		this.key2 = key2;
	}
	/**
	 * @return Returns the key3.
	 */
	public String getKey3() {
		return key3;
	}
	/**
	 * @param key3 The key3 to set.
	 */
	public void setKey3(String key3) {
		this.key3 = key3;
	}
	/**
	 * @return Returns the key4.
	 */
	public String getKey4() {
		return key4;
	}
	/**
	 * @param key4 The key4 to set.
	 */
	public void setKey4(String key4) {
		this.key4 = key4;
	}
	/**
	 * @return Returns the key5.
	 */
	public String getKey5() {
		return key5;
	}
	/**
	 * @param key5 The key5 to set.
	 */
	public void setKey5(String key5) {
		this.key5 = key5;
	}
	/**
	 * @return Returns the partiRefId.
	 */
	public int getPartiRefId() {
		return partiRefId;
	}
	/**
	 * @param partiRefId The partiRefId to set.
	 */
	public void setPartiRefId(int partiRefId) {
		this.partiRefId = partiRefId;
	}
	/**
	 * @return Returns the presnId.
	 */
	public int getPresnId() {
		return presnId;
	}
	/**
	 * @param presnId The presnId to set.
	 */
	public void setPresnId(int presnId) {
		this.presnId = presnId;
	}
	/**
	 * @return Returns the tableName.
	 */
	public String getTableName() {
		return tableName;
	}
	/**
	 * @param tableName The tableName to set.
	 */
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	
	
	/**
	 * @return Returns the fileSeqNum.
	 */
	public String getFileSeqNum() {
		return fileSeqNum;
	}
	/**
	 * @param fileSeqNum The fileSeqNum to set.
	 */
	public void setFileSeqNum(String fileSeqNum) {
		this.fileSeqNum = fileSeqNum;
	}
	
	/**
	 * @return Returns the alertTimeInd.
	 */
	public String getAlertTimeInd() {
		return alertTimeInd;
	}
	/**
	 * @param alertTimeInd The alertTimeInd to set.
	 */
	public void setAlertTimeInd(String alertTimeInd) {
		this.alertTimeInd = alertTimeInd;
	}
	
	/**
	 * @return Returns the extractDateName.
	 */
	public String getExtractDateName() {
		return extractDateName;
	}
	/**
	 * @param extractDateName The extractDateName to set.
	 */
	public void setExtractDateName(String extractDateName) {
		this.extractDateName = extractDateName;
	}
	
	/**
	 * @return Returns the startDate.
	 */
	public MyDate getStartDate() {
		return startDate;
	}
	/**
	 * @param startDate The startDate to set.
	 */
	public void setStartDate(MyDate startDate) {
		this.startDate = startDate;
	}
	
	/**
	 * @return Returns the procDate.
	 */
	public MyDate getProcDate() {
		return procDate;
	}
	/**
	 * @param procDate The procDate to set.
	 */
	public void setProcDate(MyDate procDate) {
		this.procDate = procDate;
	}
	
	/**
	 * @return Returns the alertTimeValue.
	 */
	public String getAlertTimeValue() {
		return alertTimeValue;
	}
	/**
	 * @param alertTimeValue The alertTimeValue to set.
	 */
	public void setAlertTimeValue(String alertTimeValue) {
		this.alertTimeValue = alertTimeValue;
	}
		
	/**
	 * @return Returns the header.
	 */
	public String getHeader() {
		return header;
	}
	/**
	 * @param header The header to set.
	 */
	public void setHeader(String header) {
		this.header = header;
	}
	
	/**
	 * @return Returns the daySpan.
	 */
	public int getDaySpan() {
		return daySpan;
	}
	/**
	 * @param daySpan The daySpan to set.
	 */
	public void setDaySpan(int daySpan) {
		this.daySpan = daySpan;
	}
	
	/**
	 * @return Returns the trendTimeInd.
	 */
	public String getTrendTimeInd() {
		return trendTimeInd;
	}
	
	/**
	 * @param trendTimeInd The trendTimeInd to set.
	 */
	public void setTrendTimeInd(String trendTimeInd) {
		this.trendTimeInd = trendTimeInd;
	}
	
	/**
	 * @return Returns the extrctIndItem.
	 */
	public String getExtrctIndItem() {
		return extrctIndItem;
	}
	/**
	 * @param extrctIndItem The extrctIndItem to set.
	 */
	public void setExtrctIndItem(String extrctIndItem) {
		this.extrctIndItem = extrctIndItem;
	}
	
	/**
	 * @return Returns the divisioNameKeyLvl.
	 */
	public int getDivisioNameKeyLvl() {
		return divisioNameKeyLvl;
	}
	/**
	 * @param divisioNameKeyLvl The divisioNameKeyLvl to set.
	 */
	public void setDivisioNameKeyLvl(int divisioNameKeyLvl) {
		this.divisioNameKeyLvl = divisioNameKeyLvl;
	}
	
	/**
	 * @return Returns the error.
	 */
	public String getError() {
		return error;
	}
	/**
	 * @param error The error to set.
	 */
	public void setError(String error) {
		this.error = error;
	}
	
	/**
	 * @return Returns the buttonList.
	 */
	public List getButtonList() {
		return buttonList;
	}
	/**
	 * @param buttonList The buttonList to set.
	 */
	public void addButton(PickList button) {
		this.buttonList.add(button);
	}
	
	/**
	 * @return Returns the yaxisTitle.
	 */
	public String getYaxisTitle() {
		return yaxisTitle;
	}
	/**
	 * @param yaxisTitle The yaxisTitle to set.
	 */
	public void setYaxisTitle(String yaxisTitle) {
		this.yaxisTitle = yaxisTitle;
	}
	
	/**
	 * @return Returns the alertRule.
	 */
	public AlertRule getAlertRule() {
		return alertRule;
	}
	/**
	 * @param alertRule The alertRule to set.
	 */
	public void setAlertRule(AlertRule alertRule) {
		this.alertRule = alertRule;
	}
	
	/**
	 * @return Returns the extrctTblDef.
	 */
	public ExtrctTblDef getExtrctTblDef() {
		return extrctTblDef;
	}
	/**
	 * @param extrctTblDef The extrctTblDef to set.
	 */
	public void setExtrctTblDef(ExtrctTblDef extrctTblDef) {
		this.extrctTblDef = extrctTblDef;
	}
	
	/**
	 * @return Returns the akey1.
	 */
	public String getAkey1() {
		return akey1;
	}
	/**
	 * @param akey1 The akey1 to set.
	 */
	public void setAkey1(String akey1) {
		this.akey1 = akey1;
	}
	/**
	 * @return Returns the akey2.
	 */
	public String getAkey2() {
		return akey2;
	}
	/**
	 * @param akey2 The akey2 to set.
	 */
	public void setAkey2(String akey2) {
		this.akey2 = akey2;
	}
	/**
	 * @return Returns the akey3.
	 */
	public String getAkey3() {
		return akey3;
	}
	/**
	 * @param akey3 The akey3 to set.
	 */
	public void setAkey3(String akey3) {
		this.akey3 = akey3;
	}
	/**
	 * @return Returns the akey4.
	 */
	public String getAkey4() {
		return akey4;
	}
	/**
	 * @param akey4 The akey4 to set.
	 */
	public void setAkey4(String akey4) {
		this.akey4 = akey4;
	}
	/**
	 * @return Returns the akey5.
	 */
	public String getAkey5() {
		return akey5;
	}
	/**
	 * @param akey5 The akey5 to set.
	 */
	public void setAkey5(String akey5) {
		this.akey5 = akey5;
	}
}
