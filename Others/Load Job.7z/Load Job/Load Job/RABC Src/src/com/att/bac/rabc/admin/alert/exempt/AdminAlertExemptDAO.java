/* Component Name: RABCPPG01233
 * Module Name: AdminAlertExemptDAO.java
 * Created on Jul 17, 2006
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.admin.alert.exempt;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.att.bac.rabc.PickList;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.StaticDataLoader;
import com.att.bac.rabc.admin.alert.rule.AlertRule;
import com.att.carat.util.JDBCUtil;

/**This is the Data Access Object class for the admin alert exempt process.  The purpose of this class
 * is to interact with the database to get the active and deactive exempts for either trend time or key
 * level and return this data to the AdminAlertExemptService.java class.  All exceptions are thrown back
 * to the AdminAlertExemptAction.java class via the AdminAlertExemptService.java class.
 * 
 * @author js3175
 */
public class AdminAlertExemptDAO {
	private static final Logger logger = Logger.getLogger(AdminAlertExemptDAO.class);
	
	static final String ACTIVE = "A";
	static final String DEACTIVE = "D";
	
	/**This static method is called by the service class to get the alert rules to be displayed in a
	 * drop down on the main page.
	 * 
	 * @param conn  the connection created in the service class
	 * @return list  an ArrayList object of alert rules.
	 */
	protected static ArrayList getRules(Connection conn) throws RABCException {
		ArrayList list = new ArrayList();
		Statement stmt = null;
		ResultSet rs = null;
		String getRules = "SELECT BAR.ALERT_RULE ALERT_RULE, BAR.ALERT_TIME_IND ALERT_TIME_IND " +
						  "FROM RABC_ALERT_RULE BAR, RABC_PRESN_ID BPI " +
						  "WHERE (BAR.ALERT_RULE_STATUS IS NULL OR BAR.ALERT_RULE_STATUS <> 'DELETED') " +
						  "AND BAR.ALERT_RULE_PRESN_IND = 'Y' " +
						  "AND BAR.PRESN_ID = BPI.PRESN_ID " +
						  "ORDER BY INITCAP(ALERT_RULE)";
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(getRules);
			logger.debug("Starting rs loop...");
			while (rs.next()) {
				PickList pickList = new PickList(rs.getString("ALERT_RULE"), rs.getString("ALERT_TIME_IND"));
				list.add(pickList);
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving alert rules using getRules query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closeStatement(stmt);
		}
		if (list.size() == 0) {
			PickList pickList = new PickList("no alert rules found", "");
			list.add(pickList);
		}
		return list;
	}
	
	/**This static method is called by the service class to set the variable that gives the level of permissions
	 * the user has on the exempt pages.
	 * 
	 * @param conn  the connection created in the service class
	 * @param sbcuid  the user's AT&T user ID
	 * @param ruleToCheck  the rule whose exempts the user is accessing
	 * @return permission  1 allows end dating, 0 is view only.
	 */
	protected static int getPermission(Connection conn, String sbcuid, String ruleToCheck) throws RABCException {
		int permission = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String updateSelectPermissions = "SELECT BAG.ALERT_GRP " +
										 "FROM RABC_ALERT_GRP BAG, RABC_ALERT_GRP_USER BAGU, RABC_ALERT_GRP_FUNCT BAGF, RABC_UPDATE_GRP BUG	" +
										 "WHERE BAGU.USER_ID = ? " +
										 "AND BAGF.FUNCT_CD = 'TH' " +
										 "AND BUG.ALERT_RULE = ?" +
										 "AND BAG.ALERT_GRP = BAGU.ALERT_GRP " +
										 "AND BAG.ALERT_GRP = BAGF.ALERT_GRP " +
										 "AND BAG.ALERT_GRP = BUG.ALERT_GRP";
		try {
			ps = conn.prepareStatement(updateSelectPermissions);
			ps.setString(1, sbcuid);
			ps.setString(2, ruleToCheck);
			rs = ps.executeQuery();
			if (rs.next()){
				permission = 1;
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving alert group using updateSelectPermissions query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
		return permission;
	}
	
	/**This static method is called by the service class to set the daily trend time values and descriptions.
	 * 
	 * @return (TrendTimeTO[]) list.toArray(new TrendTimeTO[list.size()])  an array of trend time objects.
	 */
	protected static TrendTimeTO[] getDailyTrendTime() {
		ArrayList list = new ArrayList();
		for (int i = 0; i < 7; i++) {
			TrendTimeTO trndTim = new TrendTimeTO();
			switch (i) {
				case 0: trndTim.setAlertTrendTime("1");
						trndTim.setAlertTrendTimeDesc("Sunday");
						break;
				case 1: trndTim.setAlertTrendTime("2");
						trndTim.setAlertTrendTimeDesc("Monday");
						break;
				case 2: trndTim.setAlertTrendTime("3");
						trndTim.setAlertTrendTimeDesc("Tuesday");
						break;
				case 3: trndTim.setAlertTrendTime("4");
						trndTim.setAlertTrendTimeDesc("Wednesday");
						break;
				case 4: trndTim.setAlertTrendTime("5");
						trndTim.setAlertTrendTimeDesc("Thursday");
						break;
				case 5: trndTim.setAlertTrendTime("6");
						trndTim.setAlertTrendTimeDesc("Friday");
						break;
				default: trndTim.setAlertTrendTime("7");
						 trndTim.setAlertTrendTimeDesc("Saturday");
			}
			list.add(trndTim);
		}
		return (TrendTimeTO[]) list.toArray(new TrendTimeTO[list.size()]);
	}
	
	/**This static method is called by the service class to set the descriptions for daily trend time objects.
	 * 
	 * @param trendTimes  an array of trend time objects.
	 */
	protected static void getDailyTrendTime(TrendTimeTO[] trendTimes) throws RABCException {
		try {
			for (int i = 0; i < trendTimes.length; i++) {
				switch (Integer.parseInt(trendTimes[i].getAlertTrendTime().trim())) {
					case 1: trendTimes[i].setAlertTrendTimeDesc("Sunday");
							break;
					case 2: trendTimes[i].setAlertTrendTimeDesc("Monday");
							break;
					case 3: trendTimes[i].setAlertTrendTimeDesc("Tuesday");
							break;
					case 4: trendTimes[i].setAlertTrendTimeDesc("Wednesday");
							break;
					case 5: trendTimes[i].setAlertTrendTimeDesc("Thursday");
							break;
					case 6: trendTimes[i].setAlertTrendTimeDesc("Friday");
							break;
					default: trendTimes[i].setAlertTrendTimeDesc("Saturday");
				}
			}
		} catch (NumberFormatException nfe) {
			throw new RABCException("Error parsing day of week values: ", nfe);
		}
	}
	
	/**This static method is called by the service class to set the bill period trend time values and descriptions.
	 * 
	 * @param region  The region the user is processing data in.
	 * @return (TrendTimeTO[]) list.toArray(new TrendTimeTO[list.size()])  an array of trend time objects.
	 */
	protected static TrendTimeTO[] getBillPeriodTrendTime(String region) throws RABCException {
		ArrayList list = new ArrayList();
		try {
			String [] bpList = (String[]) StaticDataLoader.getBillRndByRegion(region).toArray(new String[0]);
			for (int i = 0; i < bpList.length; i++) {
				TrendTimeTO trndTim = new TrendTimeTO();
				trndTim.setAlertTrendTime(bpList[i]);
				trndTim.setAlertTrendTimeDesc(bpList[i]);
				list.add(trndTim);
			}
		} catch (IllegalArgumentException iae) {
			throw new RABCException("Error in assigning values: ", iae);
		}
		return (TrendTimeTO[]) list.toArray(new TrendTimeTO[list.size()]);
	}
	
	/**This static method is called by the service class to set the descriptions for bill period trend time objects.
	 * 
	 * @param trendTimes  an array of trend time objects.
	 */
	protected static void getBillPeriodTrendTime(TrendTimeTO[] trendTimes) {
		for (int i = 0; i < trendTimes.length; i++) {
			trendTimes[i].setAlertTrendTimeDesc(trendTimes[i].getAlertTrendTime());
		}
	}
	
	/**This static method is called by the service class to set the objects that are used to make up the active
	 * trend time exempts table.  These trend time exempts can be created or updated.
	 * 
	 * @param conn  the connection created in the service class
	 * @param trendTimes  an array of trend time objects.
	 * @param alrtRule  the rule whose active exempts the user is accessing
	 */
	protected static void updateActiveTrendTimes(Connection conn, TrendTimeTO[] trendTimes, String alrtRule) throws RABCException {
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		PreparedStatement ps = null;
		ResultSet rs = null;
		String selectTrendTimes = "SELECT DISTINCT ALERT_TREND_TIME, EFF_DATE, USER_ID, TIME_STAMP " +
								  "FROM RABC_ALERT_EXMPT_TIME " +
								  "WHERE ALERT_RULE = ? " +
								  "  AND EFF_DATE > SYSDATE " +
								  "  AND STATUS = ?";
		try {
			ps = conn.prepareStatement(selectTrendTimes);
			ps.setString(1, alrtRule);
			ps.setString(2, AdminAlertExemptDAO.ACTIVE);
			rs = ps.executeQuery();
			while (rs.next()){
				for (int i = 0; i < trendTimes.length; i++) {
					if (trendTimes[i].getAlertTrendTime().equals(rs.getString("ALERT_TREND_TIME").trim())) {
						if (rs.getDate("EFF_DATE") != null || !rs.getString("EFF_DATE").trim().equals("")) {
							trendTimes[i].setEndEffectiveDate(sdf.format(rs.getDate("EFF_DATE")));
						} else {
							trendTimes[i].setEndEffectiveDate(" ");
						}
						if (rs.getString("USER_ID") != null || !rs.getString("USER_ID").trim().equals("")) {
							trendTimes[i].setUserId(rs.getString("USER_ID"));
						} else {
							trendTimes[i].setUserId(" ");
						}
						if (rs.getDate("TIME_STAMP") != null || !rs.getString("TIME_STAMP").trim().equals("")) {
							trendTimes[i].setTimeStamp(sdf.format(rs.getDate("TIME_STAMP")));
						} else {
							trendTimes[i].setTimeStamp(" ");
						}
						break;
					}
				}
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving alert trend times using selectTrendTimes query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
	}
	
	/**This static method is called by the service class to set the objects that are used to make up the deactive
	 * trend time exempts table.  These trend time exempts cannot be created or updated.
	 * 
	 * @param conn  the connection created in the service class
	 * @param alrtRule  the rule whose active exempts the user is accessing
	 * @return (TrendTimeTO[]) list.toArray(new TrendTimeTO[list.size()])  an array of deactive trend time objects.
	 */
	protected static TrendTimeTO[] getDeactiveTrendTimes(Connection conn, String alrtRule) throws RABCException {
		ArrayList list = new ArrayList();
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		PreparedStatement ps = null;
		ResultSet rs = null;
		String selectTrendTimes = "SELECT ALERT_TREND_TIME, EFF_DATE, USER_ID, TIME_STAMP " +
								  "FROM RABC_ALERT_EXMPT_TIME " +
								  "WHERE ALERT_RULE = ? " +
								  "  AND (EFF_DATE <= SYSDATE OR STATUS = ?) " +
								  "ORDER BY TIME_STAMP DESC, ALERT_TREND_TIME, EFF_DATE";
		try {
			ps = conn.prepareStatement(selectTrendTimes);
			ps.setString(1, alrtRule);
			ps.setString(2, AdminAlertExemptDAO.DEACTIVE);
			rs = ps.executeQuery();
			while (rs.next()){
				if (rs.getString("ALERT_TREND_TIME") != null || !rs.getString("ALERT_TREND_TIME").trim().equals("")) {
					TrendTimeTO trends = new TrendTimeTO();
					trends.setAlertTrendTime(rs.getString("ALERT_TREND_TIME"));
					if (rs.getDate("EFF_DATE") != null || !rs.getString("EFF_DATE").trim().equals("")) {
						trends.setEndEffectiveDate(sdf.format(rs.getDate("EFF_DATE")));
					} else {
						trends.setEndEffectiveDate(" ");
					}
					if (rs.getString("USER_ID") != null || !rs.getString("USER_ID").trim().equals("")) {
						trends.setUserId(rs.getString("USER_ID"));
					} else {
						trends.setUserId(" ");
					}
					if (rs.getDate("TIME_STAMP") != null || !rs.getString("TIME_STAMP").trim().equals("")) {
						trends.setTimeStamp(sdf.format(rs.getDate("TIME_STAMP")));
					} else {
						trends.setTimeStamp(" ");
					}
					list.add(trends);
				}
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving alert trend times using selectTrendTimes query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
		return (TrendTimeTO[]) list.toArray(new TrendTimeTO[list.size()]);
	}
	
	/**This static method is called by the service class to get descriptive information on the alert rule
	 * selected.  This information is passed back as an alert rule object.
	 * 
	 * @param conn  the connection created in the service class
	 * @param alertRule  the rule whose active exempts the user is accessing
	 * @return alertRuleObject  an alert rule object containing descriptive info on the alertRule.
	 */
	protected static AlertRule getRuleDescription(Connection conn, String alertRule) throws RABCException {
		PreparedStatement ps = null;
		ResultSet rs = null;
		AlertRule alertRuleObject = new AlertRule();
		String ruleDescription = "SELECT BAR.ALERT_RULE, BAR.ALERT_DESC, " +
		   						 "       DECODE(BAR.STD_TYPE,NULL,0,BAR.STD_TYPE) STD_TYPE, " +
								 "       DECODE(BAR.ALERT_KEY_LVL,NULL,0,BAR.ALERT_KEY_LVL) ALERT_KEY_LVL, " +
								 "       DECODE(BAR.DIVISION_NAME_KEY_LVL,NULL,0,BAR.DIVISION_NAME_KEY_LVL) DIVISION_NAME_KEY_LVL, " +
								 "       BAR.ALERT_RULE_TYPE ALERT_RULE_TYPE, " +
								 "		 BAR.ALERT_TIME_IND ALERT_TIME_IND " +
								 "FROM RABC_ALERT_RULE BAR, RABC_PRESN_ID BPI " +
								 "WHERE BAR.ALERT_RULE = ? " +
								 "AND BAR.ALERT_RULE_PRESN_IND = 'Y' " +
								 "AND BAR.PRESN_ID = BPI.PRESN_ID";
		try {
			ps = conn.prepareStatement(ruleDescription);
			ps.setString(1, alertRule.trim());
			rs = ps.executeQuery();
			if (rs.next()) {
				alertRuleObject.setAlertRule(rs.getString("ALERT_RULE"));
				alertRuleObject.setAlertDesc(rs.getString("ALERT_DESC"));
				alertRuleObject.setAlertKeyLvl(rs.getInt("ALERT_KEY_LVL"));
				alertRuleObject.setDivisionNameKeyLvl(rs.getInt("DIVISION_NAME_KEY_LVL"));
				alertRuleObject.setAlertRuleType(rs.getString("ALERT_RULE_TYPE"));
				alertRuleObject.setAlertTimeInd(rs.getString("ALERT_TIME_IND"));
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving alert rule description using ruleDescription query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
		return alertRuleObject;
	}
	
	/**This static method is called by the service class to get descriptive information on the alert rule
	 * selected.  This information is passed back as an alert rule object.
	 * 
	 * @param conn  the connection created in the service class
	 * @param userId  the user ID of the user making the updates
	 * @return name  the name of the user making the updates.
	 */
	protected static String getUserName(Connection conn, String userId) throws RABCException {
		PreparedStatement ps = null;
		ResultSet rs = null;
		String name = "";
		String getUserNm = "SELECT UPPER(USER_NAME) USER_NAME " +
						   "FROM RABC_USER " +
						   "WHERE USER_ID = ? ";
		try {
			ps = conn.prepareStatement(getUserNm);
			ps.setString(1, userId.trim());
			rs = ps.executeQuery();
			if (rs.next()) {
				name = rs.getString("USER_NAME");
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving the user's name using getUserNm query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
		return name;
	}
	
	/**This static method is called by the service class to set the objects that are used to make up the active
	 * key level exempts table.  These key level exempts can be created or end dated.
	 * 
	 * @param conn  the connection created in the service class
	 * @param region  the region the user is processing RABC data in.
	 * @param alertRule  the rule whose active exempts the user is accessing.
	 * @param alertKeyLvl  the number of keys the alert rule has.
	 * @param alertTimeInd  null for record, 'D' for daily, & 'B' for bill period.
	 * @return (KeysTO[]) list.toArray(new KeysTO[list.size()])  the active key exempts that can be end dated.
	 */
	protected static KeysTO[] getActiveKeyExempts(Connection conn, String region, String alertRule, int alertKeyLvl, String alertTimeInd) throws RABCException {
		ArrayList list = new ArrayList();
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		String activKeyExempts = "SELECT DISTINCT ALERT_RULE, ALERT_KEY1_DATA, ALERT_KEY2_DATA, ALERT_KEY3_DATA, " +
								 "ALERT_KEY4_DATA, ALERT_KEY5_DATA, ALERT_ITEM_NAME, USER_ID, END_EFF_DT, TIME_STAMP " +
								 "FROM RABC_ALERT_EXMPT " +
								 "WHERE ALERT_RULE = ? " +
								 "  AND END_EFF_DT > SYSDATE " +
								 "  AND STATUS = ?";
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(activKeyExempts);
			ps.setString(1, alertRule);
			ps.setString(2, AdminAlertExemptDAO.ACTIVE);
			rs = ps.executeQuery();
			logger.debug("Starting rs loop...");
			while (rs.next()) {
				String desc = StaticDataLoader.getDivisionDesc(region, rs.getString("ALERT_KEY1_DATA"));
				String alertItem = " ";
				String effDate = " ";
				String userId = " ";
				String timestamp = " ";
				if (rs.getString("ALERT_ITEM_NAME") != null)
					alertItem = rs.getString("ALERT_ITEM_NAME");
				if (rs.getString("USER_ID") != null)
					userId = rs.getString("USER_ID");
				if (rs.getDate("END_EFF_DT") != null)
					effDate = sdf.format(rs.getDate("END_EFF_DT"));
				if (rs.getDate("TIME_STAMP") != null)
					timestamp = sdf.format(rs.getDate("TIME_STAMP"));
				if (alertKeyLvl > 1) {
					String [] keys = new String[alertKeyLvl - 1];
					for (int i = 0; i < alertKeyLvl - 1; i++) {
						keys[i] = " ";
						if (rs.getString(i + 3) != null)
							keys[i] = rs.getString(i + 3);
					}
					KeysTO keyData = new KeysTO(alertItem, rs.getString("ALERT_KEY1_DATA"), desc, keys, userId, effDate, timestamp);
					list.add(keyData);
				} else {
					KeysTO keyData = new KeysTO(alertItem, rs.getString("ALERT_KEY1_DATA"), desc, userId, effDate, timestamp);
					list.add(keyData);
				}
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving key level data using activKeyExempts query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
		return (KeysTO[]) list.toArray(new KeysTO[list.size()]);
	}
	
	/**This static method is called by the service class to set the objects that are used to make up the deactive
	 * key level exempts table.  These key level exempts cannot be created or updated.
	 * 
	 * @param conn  the connection created in the service class
	 * @param region  the region the user is processing RABC data in.
	 * @param alertRule  the rule whose active exempts the user is accessing.
	 * @param alertKeyLvl  the number of keys the alert rule has.
	 * @param alertTimeInd  null for record, 'D' for daily, & 'B' for bill period.
	 * @return (KeysTO[]) list.toArray(new KeysTO[list.size()])  the deactive key exempts in the history table.
	 */
	protected static KeysTO[] getDeactiveKeyExempts(Connection conn, String region, String alertRule, int alertKeyLvl, String alertTimeInd) throws RABCException {
		ArrayList list = new ArrayList();
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		PreparedStatement ps = null;
		ResultSet rs = null;
		String deactKeyExempts = "SELECT ALERT_RULE, ALERT_KEY1_DATA, ALERT_KEY2_DATA, ALERT_KEY3_DATA, ALERT_KEY4_DATA, " +
								 "ALERT_KEY5_DATA, ALERT_ITEM_NAME, USER_ID, END_EFF_DT, TIME_STAMP " +
								 "FROM RABC_ALERT_EXMPT " +
								 "WHERE ALERT_RULE = ? " +
								 "  AND (END_EFF_DT <= SYSDATE OR STATUS = ?) " +
								 "ORDER BY TIME_STAMP DESC, ALERT_KEY1_DATA, ALERT_KEY2_DATA, ALERT_KEY3_DATA, ALERT_KEY4_DATA, ALERT_KEY5_DATA, ALERT_ITEM_NAME, END_EFF_DT, USER_ID";
		try {
			ps = conn.prepareStatement(deactKeyExempts);
			ps.setString(1, alertRule);
			ps.setString(2, AdminAlertExemptDAO.DEACTIVE);
			rs = ps.executeQuery();
			logger.debug("Starting rs loop...");
			while (rs.next()) {
				String desc = StaticDataLoader.getDivisionDesc(region, rs.getString("ALERT_KEY1_DATA"));
				String alertItem = " ";
				String effDate = " ";
				String userId = " ";
				String timestamp = " ";
				if (rs.getString("ALERT_ITEM_NAME") != null)
					alertItem = rs.getString("ALERT_ITEM_NAME");
				if (rs.getString("USER_ID") != null)
					userId = rs.getString("USER_ID");
				if (rs.getDate("END_EFF_DT") != null)
					effDate = sdf.format(rs.getDate("END_EFF_DT"));
				if (rs.getDate("TIME_STAMP") != null)
					timestamp = sdf.format(rs.getDate("TIME_STAMP"));
				if (alertKeyLvl > 1) {
					String [] keys = new String[alertKeyLvl - 1];
					for (int i = 0; i < alertKeyLvl - 1; i++) {
						keys[i] = " ";
						if (rs.getString(i + 3) != null)
							keys[i] = rs.getString(i + 3);
					}
					KeysTO keyData = new KeysTO(alertItem, rs.getString("ALERT_KEY1_DATA"), desc, keys, userId, effDate, timestamp);
					list.add(keyData);
				} else {
					KeysTO keyData = new KeysTO(alertItem, rs.getString("ALERT_KEY1_DATA"), desc, userId, effDate, timestamp);
					list.add(keyData);
				}
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving key level data using deactKeyExempts query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
		return (KeysTO[]) list.toArray(new KeysTO[list.size()]);
	}
	
	/**This static method is called by the service class to set the column names for the current key level table
	 * and the historical key level table to better describe the columns.
	 * 
	 * @param conn  the connection created in the service class.
	 * @param keyLevel  the number of keys the alert rule has.
	 * @param alertRule  the rule whose active exempts the user is accessing.
	 * @return keyHeaders  the key level columns for the alertRule.
	 */
	protected static String [] getKeyLevelHeaders(Connection conn, int keyLevel, String alertRule) throws RABCException {
		String [] keyHeaders = new String[keyLevel];
		PreparedStatement ps = null;
		ResultSet rs = null;
		String keyLevelHeaders = "SELECT DISTINCT KEY1_HEADER, KEY2_HEADER, KEY3_HEADER, KEY4_HEADER, KEY5_HEADER " +
								 "FROM RABC_ALERT_RULE_PRESN_RULE " +
								 "WHERE PRESN_ID IN (SELECT PRESN_ID " +
								 "					 FROM RABC_ALERT_RULE " +
								 "					 WHERE ALERT_RULE = ?)";
		try {
			ps = conn.prepareStatement(keyLevelHeaders);
			ps.setString(1, alertRule.trim());
			rs = ps.executeQuery();
			logger.debug("Starting rs loop...");
			if (rs.next()) {
				for (int i = 0; i < keyLevel; i++) {
					if (rs.getString(i + 1) == null) {
						keyHeaders[i] = " ";
					} else {
						keyHeaders[i] = rs.getString(i + 1);
					}
				}
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving key level headers using keyLevelHeaders query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
		return keyHeaders;
	}
	
	/**This static method is called by the service class to populate the alert item drop down in the create
	 * key row.
	 * 
	 * @param conn  the connection created in the service class.
	 * @param alertRule  the rule whose active exempts the user is accessing.
	 * @return list  the ArrayList of alert items that is populated in the drop down.
	 */
	protected static ArrayList getAlertItem(Connection conn, String alertRule) throws RABCException {
		PreparedStatement ps = null;
		ResultSet rs = null;
		ArrayList list = new ArrayList();
		String alertItem = "";
		String ruleDataItem = "SELECT DISTINCT ALERT_ITEM_DDL_NAME, ALERT_ITEM_DDL_DATA " +
		 					  "FROM RABC_ALERT_PROC " +
							  "WHERE ALERT_RULE = ? " +
							  "ORDER BY ALERT_ITEM_DDL_NAME";
		try {
			ps = conn.prepareStatement(ruleDataItem);
			ps.setString(1, alertRule.trim());
			rs = ps.executeQuery();
			logger.debug("Starting rs loop...");
			while (rs.next()) {
				if (rs.getString("ALERT_ITEM_DDL_NAME") == null)
					alertItem = " ";
				else
					alertItem = rs.getString("ALERT_ITEM_DDL_NAME");
				list.add(alertItem);
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving data items using ruleDataItem query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
		return list;
	}
	
	/**This static method is called by the service class to enter new trend time exempts into the database or
	 * re-enter trend times with a new end effective date.  Old trend time exempts are not deleted but will
	 * appear on the historical table.
	 * 
	 * @param conn  the connection created in the service class.
	 * @param alertRule  the rule whose active exempts the user is accessing.
	 * @param trendTime  the trend time exempt value that is being updated.
	 * @param userId  the user who is updating the trend time exempt value.
	 * @param endEffDate  the new end effective date of the trend time exempt being updated.
	 */
	protected static void insertTrendTime(Connection conn, String alertRule, String trendTime, String userId, String endEffDate) throws RABCException {
		PreparedStatement ps = null;
		String insTrendTimes = "INSERT INTO RABC_ALERT_EXMPT_TIME (ALERT_RULE, ALERT_TREND_TIME, USER_ID, TIME_STAMP, EFF_DATE, STATUS) " +
		   					   "VALUES (?,?,?,SYSDATE,?,?)";
		try {
			AdminAlertExemptDAO.deactivateTrendTime(conn, alertRule, trendTime);
			String month = endEffDate.trim().substring(0, 2);
			String day = endEffDate.trim().substring(3, 5);
			String year = endEffDate.trim().substring(6);
			ps = conn.prepareStatement(insTrendTimes);
			ps.setString(1, alertRule.trim());
			ps.setString(2, trendTime.trim());
			ps.setString(3, userId.trim());
			ps.setDate(4, Date.valueOf(year + "-" + month + "-" + day));
			ps.setString(5, AdminAlertExemptDAO.ACTIVE);
			ps.execute();
			conn.commit();
		} catch (SQLException sqle) {
			JDBCUtil.rollback(conn);
			throw new RABCException("Error in inserting using insTrendTimes query: ", sqle);
		} finally {
			JDBCUtil.closePreparedStatement(ps);
		}
	}
	
	/**This static method is called by the service class to enter new trend time exempts into the database or
	 * re-enter trend times with a new end effective date.  Old trend time exempts are not deleted but will
	 * appear on the historical table.
	 * 
	 * @param conn  the connection created in the service class.
	 * @param alertRule  the rule whose active exempts the user is accessing.
	 * @param alertItem  the alert item of the key level exempt being created or updated.
	 * @param key1  the first key (division) of the key level exempt being created or updated.
	 * @param key2  the second key of the key level exempt being created or updated.
	 * @param key3  the third key of the key level exempt being created or updated.
	 * @param key4  the fourth key of the key level exempt being created or updated.
	 * @param key5  the fifth key of the key level exempt being created or updated.
	 * @param userId  the user who is creating or updating the key level exempt.
	 * @param endEffDate  the new end effective date of the key level exempt being created or updated.
	 */
	protected static void insertAlertExemptKeyValues(Connection conn, String alertRule, String alertItem, String key1, String key2, String key3, String key4, String key5, String userId, String endEffDate) throws RABCException {
		PreparedStatement ps = null;
		String insertKeyExemptValues = "INSERT INTO RABC_ALERT_EXMPT (ALERT_RULE, ALERT_ITEM_NAME, ALERT_KEY1_DATA, ALERT_KEY2_DATA, ALERT_KEY3_DATA, ALERT_KEY4_DATA, ALERT_KEY5_DATA, USER_ID, END_EFF_DT, TIME_STAMP, STATUS) " +
									   "VALUES (?,?,?,?,?,?,?,?,?,SYSDATE,?)";
		try {
			AdminAlertExemptDAO.deactivateKeyLevel(conn, alertRule, alertItem, key1, key2, key3, key4, key5);
			String month = endEffDate.trim().substring(0, 2);
			String day = endEffDate.trim().substring(3, 5);
			String year = endEffDate.trim().substring(6);
			ps = conn.prepareStatement(insertKeyExemptValues);
			ps.setString(1, alertRule.trim());
			ps.setString(2, alertItem.trim().toUpperCase());
			ps.setString(3, key1.trim().toUpperCase());
			ps.setString(4, key2.trim().toUpperCase());
			ps.setString(5, key3.trim().toUpperCase());
			ps.setString(6, key4.trim().toUpperCase());
			ps.setString(7, key5.trim().toUpperCase());
			ps.setString(8, userId.trim());
			ps.setDate(9, Date.valueOf(year + "-" + month + "-" + day));
			ps.setString(10, AdminAlertExemptDAO.ACTIVE);
			ps.execute();
			conn.commit();
		} catch (SQLException sqle) {
			JDBCUtil.rollback(conn);
			throw new RABCException("Error in inserting key level exempt values using insertKeyExemptValues query: ", sqle);
		} finally {
			JDBCUtil.closePreparedStatement(ps);
		}
	}
	
	/**This static method is called by AdminAlertExemptDAO.insertTrendTime() to deactivate all trend time rows for
	 * an alert rule.  These rows will then appear in the historical table if they don't already.
	 * 
	 * @param conn  the connection created in the service class.
	 * @param alertRule  the rule whose active exempts the user is accessing.
	 * @param trendTime  the trend time exempt value that is being updated.
	 */
	private static void deactivateTrendTime(Connection conn, String alertRule, String trendTime) throws RABCException {
		PreparedStatement ps = null;
		String deactTrendTimes = "UPDATE RABC_ALERT_EXMPT_TIME SET " +
								 "STATUS = ? " +
								 "WHERE ALERT_RULE = ? " +
								 "  AND ALERT_TREND_TIME = ?";
		try {
			ps = conn.prepareStatement(deactTrendTimes);
			ps.setString(1, AdminAlertExemptDAO.DEACTIVE);
			ps.setString(2, alertRule.trim());
			ps.setString(3, trendTime.trim());
			ps.execute();
		} catch (SQLException sqle) {
			JDBCUtil.rollback(conn);
			throw new RABCException("Error in updating trend time status using deactTrendTimes query: ", sqle);
		} finally {
			JDBCUtil.closePreparedStatement(ps);
		}
	}
	
	/**This static method is called by AdminAlertExemptDAO.insertAlertExemptKeyValues() to deactivate all key
	 * level rows for an alert rule, division, key2, key3, key4, key5, and alert item combination.  These rows
	 * will then appear in the historical table if they don't already.
	 * 
	 * @param conn  the connection created in the service class.
	 * @param alertRule  the rule whose active exempts the user is accessing.
	 * @param alertItem  the alert item of the key level exempt being created or updated.
	 * @param key1  the first key (division) of the key level exempt being created or updated.
	 * @param key2  the second key of the key level exempt being created or updated.
	 * @param key3  the third key of the key level exempt being created or updated.
	 * @param key4  the fourth key of the key level exempt being created or updated.
	 * @param key5  the fifth key of the key level exempt being created or updated.
	 */
	private static void deactivateKeyLevel(Connection conn, String alertRule, String alertItem, String key1, String key2, String key3, String key4, String key5) throws RABCException {
		PreparedStatement ps = null;
		String deactKeyLevel = "UPDATE RABC_ALERT_EXMPT SET " +
							   "STATUS = ? " +
							   "WHERE ALERT_RULE = ? " +
							   "  AND UPPER(ALERT_KEY1_DATA) = ? " +
							   "  AND NVL(UPPER(ALERT_KEY2_DATA), -1) = NVL(?, -1) " +
							   "  AND NVL(UPPER(ALERT_KEY3_DATA), -1) = NVL(?, -1) " +
							   "  AND NVL(UPPER(ALERT_KEY4_DATA), -1) = NVL(?, -1) " +
							   "  AND NVL(UPPER(ALERT_KEY5_DATA), -1) = NVL(?, -1) " +
							   "  AND NVL(UPPER(ALERT_ITEM_NAME), -1) = NVL(?, -1)";
		try {
			ps = conn.prepareStatement(deactKeyLevel);
			ps.setString(1, AdminAlertExemptDAO.DEACTIVE);
			ps.setString(2, alertRule.trim());
			ps.setString(3, key1.trim().toUpperCase());
			ps.setString(4, key2.trim().toUpperCase());
			ps.setString(5, key3.trim().toUpperCase());
			ps.setString(6, key4.trim().toUpperCase());
			ps.setString(7, key5.trim().toUpperCase());
			ps.setString(8, alertItem.trim().toUpperCase());
			ps.execute();
		} catch (SQLException sqle) {
			JDBCUtil.rollback(conn);
			throw new RABCException("Error in updating key level status using deactKeyLevel query: ", sqle);
		} finally {
			JDBCUtil.closePreparedStatement(ps);
		}
	}
}
