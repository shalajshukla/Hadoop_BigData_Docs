/*
 * Copyright  2002-2006 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.adhoc.rpt;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.att.bac.rabc.ConnectionManager;
import com.att.bac.rabc.DateUtil;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.adhoc.aria.LayoutHelper;
import com.att.bac.rabc.adhoc.aria.pivot.CompositeKey;
import com.att.bac.rabc.adhoc.rpt.generator.AbstractAdhocGenerator;
import com.att.bac.rabc.adhoc.rpt.generator.AdhocGeneratorFactory;
import com.att.carat.util.JDBCUtil;
import com.sbc.bac.aria.ARIAReport;
import com.sbc.bac.aria.ARIAReportException;


/**
 * Mediate creation of a previous data query for layouts 1 & 3
 * 
 * <p>
 * <hr>
 * <h3>Release History</h3>
 * <p>
 * <ul>
 * 
 * <li>jb6494 Dec 13, 2006 Created class.
 * 
 * </ul>
 * <p>
 * 
 */
public class PreviousDataGeneratorMediator {
	private static final Logger logger = Logger.getLogger(PreviousDataGeneratorMediator.class);
	private static final SimpleDateFormat MMDDYYYY_FORMAT	= new SimpleDateFormat("MM/dd/yyyy");
    private static final SimpleDateFormat YYYYMMDD_FORMAT	= new SimpleDateFormat("yyyyMMdd");
    
    /**
     * Generate a report using established "previous data" for the start date range.
     * 
     * @param dto
     * @param section
     * @return
     * @throws RABCException
     */
    public ARIAReport generatePreviousDataQuery(AdhocRptDataTO dto, int section) throws RABCException {
        AbstractAdhocGenerator gen = AdhocGeneratorFactory.createGenerator(dto);
        String tempStartDate = dto.getStartDate();
        String tempEndDate = dto.getEndDate();
        int monthSelect = dto.getMonthSelect();
        int yearSelect = dto.getYearSelect();
        ARIAReport report = null;
        
        if (dto.getPresnModel()==1 && "B".equals(dto.getPresnTrendTime()) && (dto.getMonthSelect()!=0 || dto.getYearSelect()!=0)){
        	List prevProcDates = AdhocRptDAO.getBillRndPrevDates(dto);
        	if (!prevProcDates.isEmpty()){
        		Date prevStartDt = (Date)prevProcDates.get(0);
        		Date prevEndDt = (Date)prevProcDates.get(1);

        		if (prevStartDt==null || prevEndDt == null) {
        			try {
						prevStartDt  = MMDDYYYY_FORMAT.parse(tempStartDate);
						prevEndDt = MMDDYYYY_FORMAT.parse(tempEndDate);
						
						Calendar cal = Calendar.getInstance();
	        			cal.setTime(prevStartDt);
	        			cal.add(Calendar.MONTH, -1);
	        			cal.setTime(DateUtil.getFirstDayOfMonth(cal.getTime()));
	        			dto.setStartDate(MMDDYYYY_FORMAT.format(cal.getTime()));

	        			cal.setTime(prevEndDt);
	        			cal.add(Calendar.MONTH, -1);
	        			cal.setTime(DateUtil.getFirstDayOfMonth(cal.getTime()));
	        			dto.setEndDate(MMDDYYYY_FORMAT.format(cal.getTime()));
					} catch (ParseException e) {
						dto.setStartDate(getPreviousDate(tempStartDate, dto.getPresnTrendTime(), dto));
					}
        		} else {
        			String prevStartDate = MMDDYYYY_FORMAT.format(prevStartDt);
        			String prevEndDate = MMDDYYYY_FORMAT.format(prevEndDt);
        		    dto.setStartDate(prevStartDate);
        		    dto.setEndDate(prevEndDate);
        		}
                if (monthSelect==1){
                	dto.setMonthSelect(12);
                    dto.setYearSelect(yearSelect-1);
                } else {
                	dto.setMonthSelect(monthSelect-1);
                    dto.setYearSelect(yearSelect);
                }
        	}
        	report = gen.generateQuery(dto, section);
        } else if ("M".equals(dto.getPresnTrendTime())) {
        	Calendar cal = Calendar.getInstance();
        	Date prevStartDate;
			try {
				prevStartDate = MMDDYYYY_FORMAT.parse(getPreviousDate(tempStartDate, dto.getPresnTrendTime(), dto));
				cal.setTime(DateUtil.getFirstDayOfMonth(prevStartDate));
	        	dto.setStartDate(MMDDYYYY_FORMAT.format(cal.getTime()));
			} catch (ParseException e) {
				dto.setStartDate(getPreviousDate(tempStartDate, dto.getPresnTrendTime(), dto));
			}
            report = gen.generateQuery(dto, section);
        } else {
        	dto.setStartDate(getPreviousDate(tempStartDate, dto.getPresnTrendTime(), dto));
            report = gen.generateQuery(dto, section);
        }
       
        dto.setMonthSelect(monthSelect);
        dto.setYearSelect(yearSelect);
        dto.setStartDate(tempStartDate);
        dto.setEndDate(tempEndDate);
        return report;
    }


    /**
     * Get the previous date
     * 
     * @param dto
     * @throws RABCException
     */
    private String getPreviousDate(String startDate, String trendTime,AdhocRptDataTO dto) throws RABCException {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
            Date d = sdf.parse(startDate);
            d = AdhocRptUtil.getPreviousDate(d, trendTime,dto,false);
            return sdf.format(d);
        } catch (ParseException e) {
            throw new RABCException("PreviousDataGeneratorMediator::generateQuery invalid start date", e);
        }
    }
    
    /**
     * 
     * @param dto
     * @param section
     * @param gen
     * @return
     * @throws RABCException
     */
    private ARIAReport generatePreviousDataQuery(AdhocRptDataTO dto, int section,AbstractAdhocGenerator gen) throws RABCException {
    	ARIAReport report = gen.generateQuery(dto, section);

    	try {
    		String keySql = LayoutHelper.getKeySQL(report.toSQL(), dto);
    		List keyList = getKeyList(keySql, dto);
    		
    		if (!keyList.isEmpty()){
    			String prevDtQry = getPreviousDateQry(report, dto, keyList, gen, section);
    			String prevDate = getPreviousDate(dto, prevDtQry);
    			if (prevDate != null){
    				dto.setStartDate(prevDate);
    				report = gen.generateQuery(dto, section);
    			}
    		}
    	} catch (ARIAReportException e) {
    		logger.debug("Error in getting the report Sql while forming previous data for Record report" + e);
    	} 

    	return report;
    }
    
    /**
     * Private method to return the key list
     * @param keySql
     * @param dto
     * @return
     */
    private List getKeyList(String keySql,AdhocRptDataTO dto){
    	Connection conn = null;
    	PreparedStatement ps = null;
        ResultSet rs = null;
        List keyList = new ArrayList();
        
        try {
        	conn = ConnectionManager.getConnection(dto.getRegion());
            logger.debug(keySql);
            ps = conn.prepareStatement(keySql);
            rs = ps.executeQuery();
            int cols = rs.getMetaData().getColumnCount();
            while (rs.next()){
            	CompositeKey key = new CompositeKey();
            	key.setNumKeys(cols);
            	for (int i=1;i<=cols;i++){
            		key.addKey(rs.getString(i));
            	}
            	keyList.add(key);
            }
        } catch (Exception e) {
            logger.error("Formation of keys", e);
        } finally {
            JDBCUtil.closeResultSet(rs);
            JDBCUtil.closePreparedStatement(ps);
            JDBCUtil.closeConnection(conn);
        }
        
        return keyList;
    }
    
    /**
     * Get the previous date query for Record type of report
     * @param sql
     * @param dto
     * @param keyList
     * @return
     * @throws ARIAReportException  
     * @throws RABCException 
     * @throws ParseException 
     */
    private String getPreviousDateQry(ARIAReport report,AdhocRptDataTO dto, List keyList,AbstractAdhocGenerator gen, int sectionIndex) throws ARIAReportException {
    	boolean shouldMax = false;
    	
    	// Use a new end date
    	String endDate = dto.getEndDate();
    	SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
        Date endDt;
		try {
			endDt = sdf.parse(dto.getStartDate());
			endDt = AdhocRptUtil.getPreviousDate(endDt);
			dto.setEndDate(sdf.format(endDt)); 
			dto.setStartDate(getPreviousDate(dto.getStartDate(), dto.getPresnTrendTime(), dto));
			report = gen.generateQuery(dto, sectionIndex);
			shouldMax = true;
		} catch (ParseException e) {
			dto.setEndDate(endDate);
		} catch (RABCException e) {
			dto.setEndDate(endDate);
		}
 	
    	// Get the sql
    	String sql = report.toSQL();
    	
		// Create a new string buffer to store the SQL
		StringBuffer completeSql = new StringBuffer();
		if (shouldMax){
			completeSql.append("SELECT MAX(");
		} else {
			completeSql.append("SELECT MIN(");
		}
		completeSql.append("\"");
		completeSql.append("File Date");
		completeSql.append("\"");
		completeSql.append(")");
		completeSql.append(" FROM (");
		completeSql.append(sql.toString());
		completeSql.append(") ");

		// Boolean
		boolean isFirst = true;
		int count = 0;

		// Loop through the list of columns
		for (int i = 0; i < dto.getColumnsAsOracleList().size(); i++) {
            String element = (String) dto.getColumnsAsOracleList().get(i);
            element = element.trim();
            if (!dto.getColumnsDataTypeList().get(i).toString().equalsIgnoreCase("C")) {
            	 String header = dto.getColumnsHeadersList().get(i).toString();
                 if (header.indexOf(".") != -1) {
                     header = header.replace('.', ' ');
                 } else if (header.equalsIgnoreCase("RTOTAL")) {
                     header = "Right Side Total";
                 } else if (dto.getColumnsHeadersList().get(i).toString().equalsIgnoreCase("LTOTAL")) {
                     header = "Left Side Total";
                 }
                 if (!isFirst){
                	 completeSql.append(" AND ");
                 } else {
                	 completeSql.append(" WHERE ");
                 }
                 completeSql.append("\"");
                 completeSql.append(header);
                 completeSql.append("\"");
                 completeSql.append(" IN (");
                 
				for (int j = 0; j < keyList.size(); j++) {
					CompositeKey key = (CompositeKey) keyList.get(j);
					completeSql.append("'");
					completeSql.append((String)key.getKey(count));
					completeSql.append("'");
					if (j<keyList.size()-1){
						completeSql.append(",");
					}
				}
				completeSql.append(" )");
                isFirst = false;
                count++;
            }
	    }
		
		dto.setEndDate(endDate);
		return completeSql.toString();
    }
    
    /**
     * Overloaded method for Record type of report
     * @param startDate
     * @param dto
     * @return
     */
    private String getPreviousDate(AdhocRptDataTO dto, String prevDtSql){
    	Connection conn = null;
    	PreparedStatement ps = null;
        ResultSet rs = null;
        String prevDt = null;

        try {
        	conn = ConnectionManager.getConnection(dto.getRegion());
            logger.debug(prevDtSql);
            ps = conn.prepareStatement(prevDtSql);
            rs = ps.executeQuery();
         
            while (rs.next()){
            	prevDt = getFileDate(rs, dto);
            }
        } catch (Exception e) {
            logger.error("Formation of keys", e);
        } finally {
            JDBCUtil.closeResultSet(rs);
            JDBCUtil.closePreparedStatement(ps);
            JDBCUtil.closeConnection(conn);
        }
        
        return prevDt;
    }
    
    /**
	 * Private method will return the file date based on the format of PROC_DATE
	 * @param fileDate
	 * @return
	 */
	private static String getFileDate(ResultSet rs,AdhocRptDataTO dto) throws SQLException, ParseException {
		String fileDate = rs.getString(1);
		
		if ("MM/DD/YYYY".equals(dto.getProcDateFormat())){
			return fileDate;
		} else if ("MM/YYYY".equals(dto.getProcDateFormat())){
			return fileDate;
		} else if ("YYYY".equals(dto.getProcDateFormat())){
			return fileDate;
		} else if ("YYYYMM".equals(dto.getProcDateFormat())){
			String yr = fileDate.substring(0,4);
			String mth = fileDate.substring(4,fileDate.length());
			fileDate = mth + "/" + yr;
			return fileDate;
		} else if ("YYYYMMDD".equals(dto.getProcDateFormat())){
			Date fileDt = YYYYMMDD_FORMAT.parse(fileDate);
			fileDate = MMDDYYYY_FORMAT.format(fileDt);
			return fileDate;
		} else if ("YYYY/MM".equals(dto.getProcDateFormat())){
			String yr = fileDate.substring(0,4);
			String mth = fileDate.substring(5,fileDate.length());
			fileDate = mth + "/" + yr;
			return fileDate;
		} else if ("DATE".equals(dto.getProcDateFormat())){
			Date fileDt = rs.getDate("File Date");
			fileDate = MMDDYYYY_FORMAT.format(fileDt);
			return fileDate;
		} else {
			return fileDate;
		}
	}
}
