/* Component Name: RABCPPG01202
 * Module Name: DefaultsAction.java
 * Created on Jul 17, 2006
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.defaults;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.att.bac.rabc.ConnectionManager;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.StaticDataLoader;
import com.att.carat.util.JDBCUtil;

/**This is the struts Action class for the User Defaults process.  The purpose of this class
 * is mainly to interact between the AdminAlertExemptForm.java class and the struts framework.
 * Since this is such a small process, all business logic is handled here also.
 * 
 * @author js3175
 */
public class DefaultsAction extends DispatchAction {
	private static final Logger logger = Logger.getLogger(DefaultsAction.class);
	
	/**This is the struts framework default method entered when entering the defaults
	 * process without a dispatch.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of DefaultsForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward unspecified(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) 
			throws RABCException {
		logger.debug("dispatch = unspecified");
		ActionForward forward = defaults(mapping, form, request, response);
		return forward;
	}
	
	/**This is the struts framework method called to set up and present the entry page into
	 * the defaults process.  This method is also responsible for catching and logging
	 * all exceptions thrown.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of DefaultsForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward defaults(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = defaults");
		ActionForward forward = null;
		Connection conn = null;
		HttpSession session = request.getSession();
		String tableNode =(String)session.getAttribute("tableNode");
		try {
			DefaultsForm defaultsForm = (DefaultsForm)form;
			defaultsForm.setRegion((String)request.getSession().getAttribute("region"));
			defaultsForm.setUserId((String)request.getSession().getAttribute("bacUserID"));
			conn = ConnectionManager.getConnection(defaultsForm.getRegion());
			defaultsForm.setDivisions(StaticDataLoader.getDivisionsByRegion(defaultsForm.getRegion()));
			defaultsForm.setSelectedDivision(DefaultsDAO.getDivisionChoice(conn, defaultsForm.getUserId()));
			defaultsForm.setLineCount(DefaultsDAO.getLineCountChoice(conn, defaultsForm.getUserId()));
			Defaults d =  DefaultsDAO.getDisableSeverityValues(conn, defaultsForm.getUserId(), tableNode);
			defaultsForm.setNotification(d.getNotifcation());
			defaultsForm.setSeverity(d.getSeverity());
			log(defaultsForm);
			forward = mapping.findForward("defaults");
		} catch (SQLException sqle) {
			return this.processError(request, mapping, sqle);
		} catch (NamingException ne) {
			return this.processError(request, mapping, ne);
		} catch (RABCException e) {
			return this.processError(request, mapping, e);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return forward;
	}
	
	/**This is the struts framework method called to update the user defaults then present them back to the
	 * user.  This method is also responsible for catching and logging all exceptions thrown.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param form  ActionForm - superclass of DefaultsForm
	 * @param request  the HttpServletRequest from the browser
	 * @param response  the HttpServletResponse to the browser
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	public ActionForward updateDefaults(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		logger.debug("dispatch = updateDefaults");
		ActionForward forward = null;
		Connection conn = null;
		HttpSession session = request.getSession();
		String tableNode =(String)session.getAttribute("tableNode");
		try {
			DefaultsForm defaultsForm = (DefaultsForm)form;
			defaultsForm.setRegion((String)request.getSession().getAttribute("region"));
			defaultsForm.setUserId((String)request.getSession().getAttribute("bacUserID"));
			conn = ConnectionManager.getConnection(defaultsForm.getRegion());
			DefaultsDAO.deleteDivisionChoice(conn, defaultsForm.getUserId());
			DefaultsDAO.deleteLineCountChoice(conn, defaultsForm.getUserId());
			DefaultsDAO.insertDivisionChoice(conn, defaultsForm.getUserId(), defaultsForm.getSelectedDivision());
			DefaultsDAO.insertLineCountChoice(conn, defaultsForm.getUserId(), defaultsForm.getLineCount());
			DefaultsDAO.updateDisableEmailNotifyChoice(conn, tableNode, defaultsForm.getNotification(),defaultsForm.getSeverity(),defaultsForm.getUserId());
			conn.commit();
			defaultsForm.setDivisions(StaticDataLoader.getDivisionsByRegion(defaultsForm.getRegion()));
			log(defaultsForm);
			forward = mapping.findForward("defaults");
		} catch (SQLException sqle) {
			return this.processError(request, mapping, sqle);
		} catch (NamingException ne) {
			return this.processError(request, mapping, ne);
		} catch (RABCException e) {
			return this.processError(request, mapping, e);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return forward;
	}
	
	/**This method sends all error messages to the browser and kills the process.
	 * 
	 * @param mapping  struts ActionMapping
	 * @param request  the HttpServletRequest from the browser
	 * @param e  the error that caused the application to fail.
	 * @return forward  the ActionForward object returned to the struts framework
	 */
	private ActionForward processError(HttpServletRequest request, ActionMapping mapping, Exception e){
		request.setAttribute("javax.servlet.error.exception", e);
		logger.error(e.getMessage(), e);
		return  mapping.findForward("error");
	}
	
	/**This method only shows values in the form to the console when in debug mode.
	 * 
	 * @param defaultsForm  the ActionForm for this process - defaultsForm
	 */
	private void log(DefaultsForm defaultsForm){
		logger.debug("region = " + defaultsForm.getRegion());
		logger.debug("userId = " + defaultsForm.getUserId());
		logger.debug("*************************************************************************");
	}
}
