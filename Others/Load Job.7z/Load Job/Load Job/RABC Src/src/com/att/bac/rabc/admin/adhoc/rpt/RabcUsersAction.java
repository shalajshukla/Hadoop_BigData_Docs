/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.admin.adhoc.rpt;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.att.bac.rabc.ConnectionManager;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;

/**
 * Module description: 
 * 
 * This is an Action class to get RABC users pop up  
 *
 * @author Anup Thomas - AT1862
 */
public class RabcUsersAction extends DispatchAction{

	private static final Logger logger = Logger.getLogger(RabcUsersAction.class);
	
	/**
	 * Default dispatch action method to load RABC users.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @see org.apache.struts.actions.DispatchAction#unspecified(org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public ActionForward unspecified(ActionMapping mapping,ActionForm form,HttpServletRequest request, HttpServletResponse response) {
		ActionForward forward = null ;
		RabcUsersForm rabcUsersForm = (RabcUsersForm) form;
		RabcUsersService  rabcUsersService = new RabcUsersService();
		forward =  mapping.findForward("RabcUsers");
		Connection connection = null ;
		List failureList = new ArrayList();
		List args = new ArrayList();
		
		try {
			connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
			List rabcUserList = new ArrayList();
			rabcUserList = rabcUsersService.getRabcUsersList(connection,failureList,args);
			rabcUsersForm.setRabcUsersList(rabcUserList);
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
			forward = mapping.findForward("error");
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
			forward = mapping.findForward("error");
		} catch(Exception e){
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
			forward = mapping.findForward("error");
		} finally {
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		return forward ;
	}
}
