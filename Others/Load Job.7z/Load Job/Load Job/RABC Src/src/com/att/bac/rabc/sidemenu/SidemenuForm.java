/* Component Name: RABCPPG00536
 * Module Name: SidemenuForm.java
 * Created on Jan 12, 2006
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.sidemenu;

import java.util.Collection;

import org.apache.struts.action.ActionForm;

/**This is the struts Form class for the sidemenu process.  The purpose of this bean class
 * is to hold preliminary data to be presented in either AlertTrckMainPage.jsp (page 11)
 * or AdhocReport.jsp (page 13).
 * 
 * @author pt6471
 */
public class SidemenuForm extends ActionForm {
	private static final long serialVersionUID = 0L;
	
    private int presnIDSelect;
    private Collection allLevels;
    private String region;
    private String userId;
    private String controlMonthSelect;
    private String controlYearSelect;
    private String treeid;
    private String alertRuleSelect;
    private String alertRule;
    private String reportType;
    private String alertLevel;
    private String forwardTo;
    private String cntrlPtCd;
    private String presnIdAsString;
    private String procDate;
	private String startDate;
    private String endDate;
    private String selectedDivision;
    private String allAlertsExpanded = "false";
    private String allReportsExpanded = "false";
    
	/**
	 * @return Returns the selectedDivision.
	 */
	public String getSelectedDivision() {
		return selectedDivision;
	}
	/**
	 * @param selectedDivision The selectedDivision to set.
	 */
	public void setSelectedDivision(String selectedDivision) {
		this.selectedDivision = selectedDivision;
	}
    
	public String getControlMonthSelect() {
		return controlMonthSelect;
	}

	public void setControlMonthSelect(String controlMonthSelect) {
		this.controlMonthSelect = controlMonthSelect;
	}

	public String getControlYearSelect() {
		return controlYearSelect;
	}

	public void setControlYearSelect(String controlYearSelect) {
		this.controlYearSelect = controlYearSelect;
	}
	
    public String getEndDate() {
		return endDate;
	}

    public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

    public String getProcDate() {
		return procDate;
	}

	public void setProcDate(String procDate) {
		this.procDate = procDate;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getPresnIdAsString() {
		return presnIdAsString;
	}
	
	public void setPresnIdAsString(String presnIdAsString) {
		this.presnIdAsString = presnIdAsString;
	}

	public String getAlertLevel() {
		return alertLevel;
	}

	public void setAlertLevel(String alertLevel) {
		this.alertLevel = alertLevel;
	}

	public String getReportType() {
		return reportType;
	}

	public void setReportType(String reportType) {
		this.reportType = reportType;
	}

	public String getAlertRuleSelect() {
		return alertRuleSelect;
	}

	public void setAlertRuleSelect(String alertRuleSelect) {
		this.alertRuleSelect = alertRuleSelect;
	}


	public int getPresnIDSelect() {
		return presnIDSelect;
	}

	public void setPresnIDSelect(int presnIDSelect) {
		this.presnIDSelect = presnIDSelect;
	}

	public void reset(){
		System.out.println("ss");
	}

	public Collection getAllLevels() {
		return allLevels;
	}

	public void setAllLevels(Collection allLevels) {
		this.allLevels = allLevels;
	}

	public String getTreeid() {
		return treeid;
	}

	public void setTreeid(String treeid) {
		this.treeid = treeid;
	}

	public String getForwardTo() {
		return forwardTo;
	}
	
	public void setForwardTo(String forwardTo) {
		this.forwardTo = forwardTo;
	}

	public String getAlertRule() {
		return alertRule;
	}
 
	public void setAlertRule(String alertRule) {
		this.alertRule = alertRule;
	}

	public String getCntrlPtCd() {
		return cntrlPtCd;
	}

	public void setCntrlPtCd(String cntrlPtCd) {
		this.cntrlPtCd = cntrlPtCd;
	}
	/**
	 * @return Returns the region.
	 */
	public String getRegion() {
		return region;
	}
	/**
	 * @param region The region to set.
	 */
	public void setRegion(String region) {
		this.region = region;
	}
	/**
	 * @return Returns the userId.
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @param userId The userId to set.
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	/**
	 * @return Returns the allAlertsExpanded.
	 */
	public String getAllAlertsExpanded() {
		return allAlertsExpanded;
	}
	/**
	 * @param allAlertsExpanded The allAlertsExpanded to set.
	 */
	public void setAllAlertsExpanded(String allAlertsExpanded) {
		this.allAlertsExpanded = allAlertsExpanded;
	}
	/**
	 * @return Returns the allReportsExpanded.
	 */
	public String getAllReportsExpanded() {
		return allReportsExpanded;
	}
	/**
	 * @param allReportsExpanded The allReportsExpanded to set.
	 */
	public void setAllReportsExpanded(String allReportsExpanded) {
		this.allReportsExpanded = allReportsExpanded;
	}
}
