/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.admin;

/**
 * This is a Data Object to represent RABC_PRESN_CALC_ELEM_RPT table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class PresnCalcElemRpt {
	private int presnId;
	private String webid;
	private int execPresnSeqNum;
	private String presnCalcName;
	private int presnCalcNum;
	private String calcElemFormula;
	private String calcElemUserView;
	private String calcDivInd;
	private String calcElemDisplay;
	private String presnFormatCode;

	/**
	 * @return Returns the PresnId.
	 */
	public int getPresnId() {
		return presnId;
	}
	/**
	 * @return Returns the Webid.
	 */
	public String getWebid() {
		return webid;
	}
	/**
	 * @return Returns the ExecPresnSeqNum.
	 */
	public int getExecPresnSeqNum() {
		return execPresnSeqNum;
	}
	/**
	 * @return Returns the PresnCalcName.
	 */
	public String getPresnCalcName() {
		return presnCalcName;
	}
	/**
	 * @return Returns the PresnCalcNum.
	 */
	public int getPresnCalcNum() {
		return presnCalcNum;
	}
	/**
	 * @return Returns the CalcElemFormula.
	 */
	public String getCalcElemFormula() {
		return calcElemFormula;
	}
	/**
	 * @return Returns the CalcElemUserView.
	 */
	public String getCalcElemUserView() {
		return calcElemUserView;
	}
	/**
	 * @return Returns the CalcDivInd.
	 */
	public String getCalcDivInd() {
		return calcDivInd;
	}
	/**
	 * @return Returns the CalcElemDisplay.
	 */
	public String getCalcElemDisplay() {
		return calcElemDisplay;
	}
	/**
	 * @return Returns the PresnFormatCode.
	 */
	public String getPresnFormatCode() {
		return presnFormatCode;
	}

	/**
	 * @param PresnId The presnId to set.
	 */
	public void setPresnId(int presnId) {
		this.presnId = presnId;
	}
	/**
	 * @param Webid The webid to set.
	 */
	public void setWebid(String webid) {
		this.webid = webid;
	}
	/**
	 * @param ExecPresnSeqNum The execPresnSeqNum to set.
	 */
	public void setExecPresnSeqNum(int execPresnSeqNum) {
		this.execPresnSeqNum = execPresnSeqNum;
	}
	/**
	 * @param PresnCalcName The presnCalcName to set.
	 */
	public void setPresnCalcName(String presnCalcName) {
		this.presnCalcName = presnCalcName;
	}
	/**
	 * @param PresnCalcNum The presnCalcNum to set.
	 */
	public void setPresnCalcNum(int presnCalcNum) {
		this.presnCalcNum = presnCalcNum;
	}
	/**
	 * @param CalcElemFormula The calcElemFormula to set.
	 */
	public void setCalcElemFormula(String calcElemFormula) {
		this.calcElemFormula = calcElemFormula;
	}
	/**
	 * @param CalcElemUserView The calcElemUserView to set.
	 */
	public void setCalcElemUserView(String calcElemUserView) {
		this.calcElemUserView = calcElemUserView;
	}
	/**
	 * @param CalcDivInd The calcDivInd to set.
	 */
	public void setCalcDivInd(String calcDivInd) {
		this.calcDivInd = calcDivInd;
	}
	/**
	 * @param CalcElemDisplay The calcElemDisplay to set.
	 */
	public void setCalcElemDisplay(String calcElemDisplay) {
		this.calcElemDisplay = calcElemDisplay;
	}
	/**
	 * @param PresnFormatCode The presnFormatCode to set.
	 */
	public void setPresnFormatCode(String presnFormatCode) {
		this.presnFormatCode = presnFormatCode;
	}
}
