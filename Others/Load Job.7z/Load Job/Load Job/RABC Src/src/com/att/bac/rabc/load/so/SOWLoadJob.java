/*
 * Created on Jan 31, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.att.bac.rabc.load.so;

import java.io.File;
import java.net.UnknownHostException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.StringTokenizer;

import com.att.bac.rabc.util.EmcisEventLogger;
import com.att.carat.util.NetUtil;
import com.sbc.bac.rabc.load.FilePatternLoadJob;
import com.sbc.bac.rabc.load.RabcLoadJobTrig;
import com.sbc.bac.rabc.load.RetrieveStaticInfo;
import com.sbc.bac.rabc.load.StaticErrorMsgKeys;
import com.sbc.bac.rabc.load.StaticFieldKeys;

/** 
 * @author pt6471
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class SOWLoadJob extends FilePatternLoadJob {
	
	 //private static final String FILEPATTERN = "WE.[CI].C[0-9]{4}.X16[ABC].*";
	 
	 private static final String SVC_ORD_CMPL_CD = "ZP";
	 private static final String SVC_ORD_ERROR_CD = "EDM";
	 private static final String SVC_ORD_INTERM_CD = "BR";
	 
	 private static final int AGE_1_CYCLE = 1;
	 private static final int AGE_5_CYCLE = 5;
	 private static final int AGE_10_CYCLE = 10;
	 private static final int AGE_15_CYCLE = 15;
	 private static final int AGE_20_CYCLE = 20;
	 private static final int AGE_30_CYCLE = 30;
	 private static final int AGE_90_CYCLE = 90;
	 private static final int AGE_GT_90_CYCLE = 90;
	 
	 private PreparedStatement insert_xt16sode, insert_xt16sods, insert_xt16some, insert_xt16some_summary;
	 private String division, bill_rnd, run_date;
	 
	 private File currentFile;
	 
	 private String saveOrderType, fileToken, fileName;
	
	 private int cycle, lineCount;
	 
	 private java.sql.Date sqlrun_date;
	 
	 private boolean  xt16sode_file, xt16sods_file, xt16some_file, firstRcd;
	
	 private int[] svcOrdCt = new int[3];
	 private int[] ageCycleCt = new int[8];
	 
	 public boolean preprocess() {
	 super.preprocess();

	  try {
			StringBuffer sql = new StringBuffer();
			sql.append("  insert into RABC_SVC_ORD_ERR (DIVISION, RUN_DATE, ERROR_CD, ERROR_CT) ");
			sql.append("  VALUES(?, ?, ?, ?) ");
			insert_xt16sode = connection.prepareStatement(sql.toString());
			sql.setLength(0);
			
			sql.append("  insert into RABC_SVC_ORD_TRN (DIVISION, RUN_DATE, SVC_ORD_TYPE, SVC_ORD_CMPL_CT, SVC_ORD_ERR_CT, SVC_ORD_INTERIM_CT) ");
			sql.append("  VALUES(?, ?, ?, ?, ?, ?) ");
			insert_xt16sods = connection.prepareStatement(sql.toString());
			sql.setLength(0);
			
			sql.append(" insert into  RABC_SVC_ORD_INFO (DIVISION, RUN_DATE, SVC_ORD, CREATE_CYCLE, AGE_CYCLE) ");
			sql.append(" VALUES (?, ?, ?, ?, ? )");
			insert_xt16some = connection.prepareStatement(sql.toString());
			sql.setLength(0);
			
			sql.append("insert into RABC_SVC_ORD_AGE (DIVISION, RUN_DATE, AGE_1_CYCLE_CT, AGE_5_CYCLE_CT, AGE_10_CYCLE_CT, AGE_15_CYCLE_CT, AGE_20_CYCLE_CT, AGE_30_CYCLE_CT, AGE_90_CYCLE_CT, AGE_GT_90_CYCLE_CT)");
			sql.append("VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			insert_xt16some_summary = connection.prepareStatement(sql.toString());
			sql.setLength(0);
			
		} catch (SQLException e) {
			severe(StaticErrorMsgKeys.PREPROCESS_ERROR + e.getMessage());
			return false;
		}
		return true;
	}

	public boolean preprocessFile(File file) {
		boolean success = super.preprocessFile(file);
		xt16sode_file = false;
		xt16sods_file = false;
		xt16some_file = false;

		if (file.getName().indexOf("X16B") > 0) xt16sode_file = true;
		else if (file.getName().indexOf("X16A") > 0) xt16sods_file = true;
		else if (file.getName().indexOf("X16C") > 0) xt16some_file = true;
		else return false;
		
		firstRcd  = true;
		fileName = file.getName();
		fileToken = file.getName().substring(file.getName().indexOf("X16"),file.getName().indexOf("X16")+ 4);
		
		if (RabcLoadJobTrig.IsFileLoaded(connection, file)) {
			severe(StaticErrorMsgKeys.DUPLICATE_FILE);
			return false;
			// TODO Change logic to modify return BY delete logic .. So, always new file will be loaded. !!!
		}

		if (success) {
			try {
				
				if 	(file.getName().charAt(3) == StaticFieldKeys.C)	
				  division = StaticFieldKeys.PACBELLNORTH;
				else if (file.getName().charAt(3) == StaticFieldKeys.I)	
				  division = StaticFieldKeys.PACBELLSOUTH;
				else 
					return false;
				
				cycle = Integer.parseInt(file.getName().substring(6, 10));
				
				run_date = RetrieveStaticInfo.getProc_dtByCycle(connection, cycle);
				if (run_date.equals(StaticFieldKeys.ZERO)){
					severe(StaticErrorMsgKeys.NORECORD_RABC_CYCLE_CALENDAR + cycle);
					throw new Exception();	
				}
				
				
				DateFormat df = new SimpleDateFormat("MMddyyyy");
				sqlrun_date = new java.sql.Date(df.parse(run_date).getTime());

				lineCount = 0;
				
			} catch (Exception e) {
				severe(
					StaticErrorMsgKeys.PREPROCESSFILE_ERROR
						+ StaticErrorMsgKeys.FILE_NAME_PARSING_ERROR
						+ e);
				return false;
			}
		}

		try {

				
			bill_rnd = RetrieveStaticInfo.getBillRndByCycle(connection, cycle);
			if (bill_rnd.equals(StaticFieldKeys.ZERO) || bill_rnd.equals(StaticFieldKeys.ZERO2)){
			 severe(StaticErrorMsgKeys.PREPROCESSFILE_ERROR+":No Bill Round");
			 return false;
			}

		} catch (SQLException e) {
			success = false;
			severe(StaticErrorMsgKeys.PREPROCESSFILE_ERROR + e.getMessage());
		}

		currentFile = file;
		return success;
	}

	
	
	public int parseLine(String line) throws Exception {
		boolean status;

		if (xt16sode_file) 
			status = process16XTSODE(line);
		else if (xt16sods_file)
			status = process16XTSODS(line);
		else 
			status = process16XTSOME(line);

		// add a status check on return
		return SUCCESS;
	}
	
	
	private boolean process16XTSODE (String line) throws Exception {
		
		lineCount++;
		
		StringTokenizer DataLine = new StringTokenizer(line, StaticFieldKeys.SEMICOLON);
		String recordId = DataLine.nextToken().trim();
		String errorCd 	= DataLine.nextToken().trim();
		double errorCdCnt = Double.parseDouble(DataLine.nextToken().trim());

		try {
			insert_xt16sode.setString(1,division);		
			insert_xt16sode.setDate(2,sqlrun_date);
			insert_xt16sode.setString(3,errorCd);
			insert_xt16sode.setDouble(4,errorCdCnt);
			insert_xt16sode.addBatch();
			
			if (lineCount % 100 == 0){
				insert_xt16sode.executeBatch();
			}
			
			
		}catch (SQLException sqle){
			severe(StaticErrorMsgKeys.INSERT_ERROR + sqle.getMessage());
			 throw new Exception("Exception is from method process16XTSODE");
		}
		
		return true;
	}
	
	private boolean process16XTSODS(String line) throws Exception {
		
		lineCount++;
		
		StringTokenizer DataLine = new StringTokenizer(line, StaticFieldKeys.SEMICOLON);
		String recordId 	= DataLine.nextToken().trim();
		String orderType 	= DataLine.nextToken().trim();
		String statusCd 	= DataLine.nextToken().trim();
		int orderTypeCnt = Integer.parseInt(DataLine.nextToken().trim());

		if (firstRcd) {
			saveOrderType = orderType;
			firstRcd = false;
		}
		
		if (!firstRcd && !saveOrderType.equals(orderType))
		try {
			insert_xt16sods.setString(1,division);		
			insert_xt16sods.setDate(2,sqlrun_date);
			insert_xt16sods.setString(3,saveOrderType);
			insert_xt16sods.setInt(4,svcOrdCt[0]);
			insert_xt16sods.setInt(5,svcOrdCt[1]);
			insert_xt16sods.setInt(6,svcOrdCt[2]);
			insert_xt16sods.addBatch();
			
			if (lineCount % 1000 == 0){
				insert_xt16sods.execute();
			}
			
			saveOrderType = orderType;
			for (int i = 0; i < svcOrdCt.length; i++) svcOrdCt[i] = 0;
			
			
		}catch (SQLException sqle){
			severe(StaticErrorMsgKeys.INSERT_ERROR + sqle.getMessage());
			 throw new Exception("Exception is from method process16XTSODS");
		}
		
		if (SVC_ORD_CMPL_CD.indexOf(statusCd) != -1) svcOrdCt[0] = svcOrdCt[0] + orderTypeCnt;
		else if (SVC_ORD_ERROR_CD.indexOf(statusCd) != -1) svcOrdCt[1] = svcOrdCt[1] + orderTypeCnt;
		else if (SVC_ORD_INTERM_CD.indexOf(statusCd) != -1) svcOrdCt[2] = svcOrdCt[2] + orderTypeCnt;

		return true;
	}
	
	private boolean process16XTSOME(String line ) throws Exception {
		
		
		lineCount++;
		
		StringTokenizer DataLine = new StringTokenizer(line, StaticFieldKeys.SEMICOLON);
		String recordId 	= DataLine.nextToken().trim();
		String serviceOrd	= DataLine.nextToken().trim();
		int startCycle		= Integer.parseInt(DataLine.nextToken().trim());
		int ageCycle 		= (cycle - startCycle) + 1;
		
		// If ageCycle is greater than 999, it is a bad record .. So, change it to 999 and capture(LOAD) for investigation
		
		if (ageCycle > 999) ageCycle = 999;	
		
		try {
			insert_xt16some.setString(1,division);		
			insert_xt16some.setDate(2,sqlrun_date);
			insert_xt16some.setString(3,serviceOrd);
			insert_xt16some.setInt(4,startCycle);
			insert_xt16some.setInt(5,ageCycle);
			insert_xt16some.addBatch();
			
			if (lineCount % 1000 == 0){
				insert_xt16some.executeBatch();
			}
			
			if (ageCycle == AGE_1_CYCLE ) ageCycleCt[0]++;
			else if (ageCycle == AGE_1_CYCLE ) ageCycleCt[0]++;
			else if (ageCycle > AGE_1_CYCLE && ageCycle <= AGE_5_CYCLE) ageCycleCt[1]++;
			else if (ageCycle > AGE_5_CYCLE && ageCycle <= AGE_10_CYCLE) ageCycleCt[2]++;
			else if (ageCycle > AGE_10_CYCLE && ageCycle <= AGE_15_CYCLE) ageCycleCt[3]++;
			else if (ageCycle > AGE_15_CYCLE && ageCycle <= AGE_20_CYCLE) ageCycleCt[4]++;
			else if (ageCycle > AGE_20_CYCLE && ageCycle <= AGE_30_CYCLE) ageCycleCt[5]++;
			else if (ageCycle > AGE_30_CYCLE && ageCycle <= AGE_90_CYCLE) ageCycleCt[6]++;
			else if (ageCycle > AGE_90_CYCLE) ageCycleCt[7]++;
			else return false;
			
		}catch (SQLException sqle){
			severe(StaticErrorMsgKeys.INSERT_ERROR + sqle.getMessage());
			 throw new Exception("Exception is from method process16XTSOME");
		}
		
		return true;
	}
	
	
	public boolean postprocessFile(File file, boolean success) {

		try{
			//Log the file information to EMCIS_EVENT_LOG and EMCIS_EVENT_LOG_DETAIL
			EmcisEventLogger emcisLogger = new EmcisEventLogger();
			String event_id = "RABC_"+fileToken+"_WE";
            String host = NetUtil.getLocalHostName();
            String hostIP = NetUtil.getLocalIpAddress();
			int sequence = emcisLogger.getEMCISSequence(connection);
			emcisLogger.insertEventLog(connection, sequence, event_id, sqlrun_date, host, hostIP);
			emcisLogger.insertEventLogDetail(connection, sequence, "FileName", fileName);
		}catch (UnknownHostException e) {
            severe("Error getting EMCIS host information ", e);
        }
		
		if (success) {

			try {
			if (xt16sode_file)
				insert_xt16sode.executeBatch();

			if (xt16sods_file){
	
				insert_xt16sods.setString(1,division);		
				insert_xt16sods.setDate(2,sqlrun_date);
				insert_xt16sods.setString(3,saveOrderType);
				insert_xt16sods.setInt(4,svcOrdCt[0]);
				insert_xt16sods.setInt(5,svcOrdCt[1]);
				insert_xt16sods.setInt(6,svcOrdCt[2]);
				insert_xt16sods.addBatch();

				insert_xt16sods.executeBatch();
			}

			if (xt16some_file){
				insert_xt16some.executeBatch();
				
				insert_xt16some_summary.setString(1,division);	
				insert_xt16some_summary.setDate(2,sqlrun_date);
				insert_xt16some_summary.setInt(3,ageCycleCt[0]);
				insert_xt16some_summary.setInt(4,ageCycleCt[1]);
				insert_xt16some_summary.setInt(5,ageCycleCt[2]);
				insert_xt16some_summary.setInt(6,ageCycleCt[3]);
				insert_xt16some_summary.setInt(7,ageCycleCt[4]);
				insert_xt16some_summary.setInt(8,ageCycleCt[5]);
				insert_xt16some_summary.setInt(9,ageCycleCt[6]);
				insert_xt16some_summary.setInt(10,ageCycleCt[7]);
				
				int summary_cnt = insert_xt16some_summary.executeUpdate();
				info(" insert to summary count: " + summary_cnt);
			}

			if ( xt16sode_file || xt16sods_file){
				if (!insertTrigger()) {
					severe(
						StaticErrorMsgKeys.POSTPROCESSFILE_ERROR
							+ StaticErrorMsgKeys.TIGGER_TABLE_INSERT_ERROR);
					success = false;
				}
				
			}
			
			}catch (SQLException sqle){
				severe(StaticErrorMsgKeys.INSERT_ERROR + sqle.getMessage());
				success = false;
			}
			
			}
		return super.postprocessFile(file, success);
	}

	
	public boolean postprocess(boolean success) {

		try {
			
			insert_xt16sode.close();
			insert_xt16sods.close();
			insert_xt16some.close();
			insert_xt16some_summary.close();

		} catch (SQLException e) {
			severe(
				StaticErrorMsgKeys.POSTPROCESS_ERROR
					+ StaticErrorMsgKeys.SQL_CLOSE_ERROR
					+ e);
			success = false;
		}

		return super.postprocess(success);
	}

	private boolean insertTrigger() {

		 if(!RabcLoadJobTrig.insertTrigger(connection,currentFile.getName(),fileToken,division,run_date,bill_rnd)){
			return false;	
		 }
		return true;
		
	}
	

}


