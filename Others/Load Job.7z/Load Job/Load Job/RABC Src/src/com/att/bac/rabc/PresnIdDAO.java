/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

/**
 * This is a DAO that performs SELECT, INSERT and UPDATE on RABC_PRESN_ID table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class PresnIdDAO {
	private static final Logger logger = Logger.getLogger(PresnIdDAO.class);

	/**
	 * Returns the list of PresnId objects.
	 * 
	 * @param conn 
	 * @param failures
	 * @param args
	 * @param baseSQL
	 * @return List
	 */
	public List get(Connection conn, List failures, List args, String baseSQL) {
		List presnIdList = null;
		PresnId presnId = null;
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		
		try
		{
			logger.debug("Processing SELECT from RABC_PRESN_ID table....");
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("PresnIdDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			logger.debug("SQL - Execution complete.");
			presnIdList = new ArrayList();
			while (rs.next()) {
				presnIdList.add(buildPresnId(rs));
			}
			
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return null;
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
		
		return presnIdList;
	}

	/**
	 * Private method to build PresnId object and return it to caller.
	 * 
	 * @param rs
	 * @return PresnId
	 * @throws SQLException
	 */
	private PresnId buildPresnId(ResultSet rs) throws SQLException {
		PresnId presnId = new PresnId();
		
		presnId.setPresnId(rs.getInt("PRESN_ID"));
		presnId.setPresnIdDesc(rs.getString("PRESN_ID_DESC"));
		presnId.setAsocFileId(rs.getString("ASOC_FILE_ID"));
		presnId.setPresnTblName(rs.getString("PRESN_TBL_NAME"));
		presnId.setProcDateDdlName(rs.getString("PROC_DATE_DDL_NAME"));
		presnId.setDivisionNameKeyLvl(rs.getInt("DIVISION_NAME_KEY_LVL"));
		presnId.setPresnIdPresnInd(rs.getString("PRESN_ID_PRESN_IND"));
		presnId.setExecPresnSeqNum(rs.getInt("EXEC_PRESN_SEQ_NUM"));
		presnId.setBegSubTotLvl(rs.getInt("BEG_SUB_TOT_LVL"));
		presnId.setEndSubTotLvl(rs.getInt("END_SUB_TOT_LVL"));
		presnId.setPresnModel(rs.getInt("PRESN_MODEL"));
		presnId.setAdhocRptInd(rs.getString("ADHOC_RPT_IND"));
		presnId.setAdhocRptStatus(rs.getString("ADHOC_RPT_STATUS"));
		presnId.setDbNodeId(rs.getString("DB_NODE_ID"));
		presnId.setEffDt(rs.getDate("EFF_DT"));
		presnId.setPresnTrendTime(rs.getString("PRESN_TREND_TIME"));
		presnId.setPresnDurTime(rs.getString("PRESN_DUR_TIME"));
		presnId.setTimingFilterCode(rs.getString("TIMING_FILTER_CODE"));
		return presnId;
	}

	/**
	 * Execute the insert or update statement on RABC_PRESN_ID table.
	 * 
	 * @param conn
	 * @param failures
	 * @param args
	 * @param baseSQL
	 */
	public void executeUpdate(Connection conn, List failures, List args, String baseSQL) {
		int rowsUpdated = 0;
		Statement stmt = null;
		String sqlStmt = null;
		
		try
		{
			logger.debug("Processing executeUpdate on RABC_PRESN_ID table....");
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("PresnIdDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rowsUpdated = stmt.executeUpdate(sqlStmt);
			logger.debug("SQL - Execution complete."+ String.valueOf(rowsUpdated) + "  rows updated");
			
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return;
		} finally {
			SQLHelper.closeStatement(stmt, failures, logger);
		}
	}

}
