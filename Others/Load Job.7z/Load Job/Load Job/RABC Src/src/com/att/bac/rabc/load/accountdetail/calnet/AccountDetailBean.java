package com.att.bac.rabc.load.accountdetail.calnet;

import java.util.StringTokenizer;


/**
 * 
 * 
 * @author John Haggerty jh9874
 */
public class AccountDetailBean {
	public static final String DELIMITER = ";";
	public static final String FILE_ID = "XT30CRIS";
	public static final String FILE_NAME_PATTERN = "WE.[CI].C\\d{4}."+FILE_ID+".D\\d{7}.T\\d{6}.(TXT|txt)";
	
	
	//value for internal use only.
	private String croCode;
	
	//detail record values... these will be inserted into the detail table (RABC_ACCT_BLG_DTL).
	private String 	billingAccountId, 	//CTCUSTID
					btn,				//BTN
					agencyId;			//AGENCY_ID
	
	
	private double	currentMonthChargeAmt,	//CURR_MNTH_CHRG_AMT 
					currentBalanceDueAmt,	//CURR_BAL_DUE_AMT
					adjustmentAmount,		//ADJ_AMT
					otherBalanceAdjAmts,	//OTR_BAL_ADJ_AMT
					occAmount,				//OCC_AMT
					regDsctOccAmt,			//REG_DSCT_OCC_AMT
					nrgDsctOccAmt,			//NRG_DSCT_OCC_AMT
					mccAmount,				//MCC_AMT
					regDsctMccAmt,			//REG_DSCT_MCC_AMT
					nrgDsctMccAmt,			//NRG_DSCT_MCC_AMT
					monthlyServiceAmount,	//MNTH_SRV_AMT
					euclChargeAmount,		//EUCL_CHR_AMT
					tollTotalAmount,		//TOLL_TOT_AMT
					tollSubAmount,			//TOLL_SUB_AMT
					totDsctTollAmt,			//TOT_DSCT_TOLL_AMT
					daAmt,					//DA_AMT
					iecAmt,					//IEC_AMT
					fedTaxAmount,			//FED_TAX_AMT
					stateTaxAmount,			//STATE_TAX_AMT
					cityTaxAmount,			//CITY_TAX_AMT
					blgSrcgAmt,				//BLG_SRCG_AMT
					hcapSrcgAmt,			//HCAP_SRCG_AMT
					lflnSrcgAmt,			//LFLN_SRCG_AMT
					cpucSrcgAmt,			//CPUC_SRCG_AMT
					chcfaSrcgAmt,			//CHCFA_SRCG_AMT
					chcfbSrcgAmt,			//CHCFB_SRCG_AMT
					usscSrcgAmt,			//USSC_SRCG_AMT
					attSrcgAmt,				//ATT_SRCG_AMT
					ctfSrcgAmt,				//CTF_SRCG_AMT
					srvUssfAmt,				//SRV_USSF_AMT
					callAmt900,				//900_CALL_AMT
					zone1amt,				//ZONE_1_AMT
					zone1mou,				//ZONE_1_MOU
					zone23amt,				//ZONE_23_AMT
					zone23mou,				//ZONE_23_MOU
					sdUndergrdSrcgAmt,		//SD_UNDERGRD_SRCG_AMT
					bocAmt; 				//BOC_AMT 	Added BOC_AMT Field
	
	private int 	zone1ct,	//ZONE_1_CT
					zone23ct,	//ZONE_23_CT
					daCt;		//DA_CT
	
					
	
	
	//agency record values... these will be matched with the appropriate AgencyBean and inserted into the agency table (RABC_ACCT_INFO) 
	private String	accountClassCode, 	//ACCT_CLS_CD
					accountName,		//ACCT_NAME
					activeAccountInd;	//ACCT_ACTIVE_IND

	/**
	 *  helper method. Generates a double from a String. The String should just be numbers (NO DECIMAL POINTS), and the last two digits
	 *  are considered to be to the right of the decimal point.
	 *  
	 * @param value a String where the last two digits are to the right of the decimal point. No decimal points.
	 * @return
	 */
	private static double parseDouble(String value){
		double d = Double.parseDouble(value);
		d /= 1000000d;
		return d;
	}
	

	/**
	 * generates an AccountDetailBean from a XT30CRIS data record.
	 * 
	 * @param value a String in the XT30CRIS data record format.
	 * @return
	 */
	public static AccountDetailBean valueOf(String value){
		AccountDetailBean detail = new AccountDetailBean();
		StringTokenizer st = new StringTokenizer(value, DELIMITER);
		
		String fileId = st.nextToken();//1
		if(fileId == null || !fileId.equals(FILE_ID)){
			throw new IllegalArgumentException("file id is null or does not match "+FILE_ID+" :"+fileId);
		}
		detail.billingAccountId = st.nextToken().trim();//2
		detail.croCode = st.nextToken();//3
		StringBuffer buffer = new StringBuffer(13);
		buffer.append(st.nextToken()).append(st.nextToken()).append(st.nextToken());//4, 5, 6
		detail.btn = buffer.toString();
		detail.accountClassCode = st.nextToken().trim();//7
		detail.accountName = st.nextToken().trim();//8
		detail.activeAccountInd = st.nextToken().trim();//9
		detail.agencyId = st.nextToken().trim();//10
		st.nextToken(); //blank field... skip it//11
		detail.currentMonthChargeAmt = parseDouble(st.nextToken().trim());//12
		detail.currentBalanceDueAmt = parseDouble(st.nextToken().trim());//13
		detail.adjustmentAmount = parseDouble(st.nextToken().trim());//14
		detail.otherBalanceAdjAmts = parseDouble(st.nextToken().trim());//15
		detail.otherBalanceAdjAmts += parseDouble(st.nextToken().trim());//16		
		detail.occAmount = parseDouble(st.nextToken().trim());//17
		detail.regDsctOccAmt = parseDouble(st.nextToken().trim());//18
		detail.nrgDsctOccAmt = parseDouble(st.nextToken().trim());//19
		detail.mccAmount = parseDouble(st.nextToken().trim());//20
		detail.regDsctMccAmt = parseDouble(st.nextToken().trim());//21
		detail.nrgDsctMccAmt = parseDouble(st.nextToken().trim());//22
		detail.monthlyServiceAmount = parseDouble(st.nextToken().trim());//23
		detail.euclChargeAmount = parseDouble(st.nextToken().trim());//24
		double temp = parseDouble(st.nextToken().trim()); //CUR_TOLL_AMT field feeds two fields;//25
		detail.tollTotalAmount = temp;
		detail.tollSubAmount = temp;
		detail.tollTotalAmount += parseDouble(st.nextToken().trim());//26
		temp = parseDouble(st.nextToken().trim()); //CURR_OPTL_PLAN_AMT adds to two fields//27
		detail.tollSubAmount += temp;
		detail.tollTotalAmount += temp;
		detail.totDsctTollAmt = parseDouble(st.nextToken().trim());//28
		detail.totDsctTollAmt += parseDouble(st.nextToken().trim());//29
		detail.daAmt = parseDouble(st.nextToken().trim());//30
		detail.iecAmt = parseDouble(st.nextToken().trim());//31
		detail.fedTaxAmount = parseDouble(st.nextToken().trim());//32
		detail.stateTaxAmount = parseDouble(st.nextToken().trim());//33
		detail.cityTaxAmount = parseDouble(st.nextToken().trim());//34
		detail.blgSrcgAmt = parseDouble(st.nextToken().trim());//35
		detail.hcapSrcgAmt = parseDouble(st.nextToken().trim());//36
		detail.lflnSrcgAmt =parseDouble(st.nextToken().trim());//37
		detail.cpucSrcgAmt = parseDouble(st.nextToken().trim());//38
		detail.chcfaSrcgAmt = parseDouble(st.nextToken().trim());//39
		detail.chcfbSrcgAmt = parseDouble(st.nextToken().trim());//40
		detail.usscSrcgAmt = parseDouble(st.nextToken().trim());//41
		detail.attSrcgAmt = parseDouble(st.nextToken().trim());//42
		detail.ctfSrcgAmt = parseDouble(st.nextToken().trim());//43
		detail.srvUssfAmt = parseDouble(st.nextToken().trim());//44
		detail.callAmt900 = parseDouble(st.nextToken().trim());//45
		double sd = parseDouble(st.nextToken().trim());
		detail.sdUndergrdSrcgAmt = sd;//46
		detail.bocAmt = parseDouble(st.nextToken().trim());//47	..Added BOC_AMT Field
		
		for(int i = 0; i < 32; i++){//need to skip 32 sets of zeros.After addition of BOC_AMT field
			st.nextToken(); //meaningless zeros... skip.//48-79
		}
		detail.zone1amt = parseDouble(st.nextToken().trim());//80
		//detail.zone1ct = Integer.parseInt(st.nextToken().trim()); 
		detail.zone1ct = (int)parseDouble(st.nextToken().trim());//81
		detail.zone1mou = parseDouble(st.nextToken().trim());//82
		detail.zone23amt = parseDouble(st.nextToken().trim());//83
		//detail.zone23ct = Integer.parseInt(st.nextToken().trim());
		detail.zone23ct = (int)parseDouble(st.nextToken().trim());//84
		detail.zone23mou = parseDouble(st.nextToken().trim());//85
		//detail.daCt = Integer.parseInt(st.nextToken().trim());
		detail.daCt = (int)parseDouble(st.nextToken().trim());//86
		
		
		return detail;
	}

	/**
	 * @return the accountName
	 */
	public String getAccountName() {
		return accountName;
	}

	/**
	 * @return the acountClassCode
	 */
	public String getAccountClassCode() {
		return accountClassCode;
	}

	/**
	 * @return the activeAccountInd
	 */
	public String getActiveAccountInd() {
		return activeAccountInd;
	}

	/**
	 * @return the adjustmentAmount
	 */
	public double getAdjustmentAmount() {
		return adjustmentAmount;
	}

	/**
	 * @return the agencyId
	 */
	public String getAgencyId() {
		return agencyId;
	}

	/**
	 * @return the attSrcgAmt
	 */
	public double getAttSrcgAmt() {
		return attSrcgAmt;
	}

	/**
	 * @return the billingAccountId
	 */
	public String getBillingAccountId() {
		return billingAccountId;
	}

	/**
	 * @return the blgSrcgAmt
	 */
	public double getBlgSrcgAmt() {
		return blgSrcgAmt;
	}

	/**
	 * @return the btn
	 */
	public String getBtn() {
		return btn;
	}

	/**
	 * @return the callAmt900
	 */
	public double getCallAmt900() {
		return callAmt900;
	}

	/**
	 * @return the chcfaSrcgAmt
	 */
	public double getChcfaSrcgAmt() {
		return chcfaSrcgAmt;
	}

	/**
	 * @return the chcfbSrcgAmt
	 */
	public double getChcfbSrcgAmt() {
		return chcfbSrcgAmt;
	}

	/**
	 * @return the cityTaxAmount
	 */
	public double getCityTaxAmount() {
		return cityTaxAmount;
	}

	/**
	 * @return the cpucSrcgAmt
	 */
	public double getCpucSrcgAmt() {
		return cpucSrcgAmt;
	}

	/**
	 * @return the ctfSrcgAmt
	 */
	public double getCtfSrcgAmt() {
		return ctfSrcgAmt;
	}

	/**
	 * @return the currentBalanceDueAmt
	 */
	public double getCurrentBalanceDueAmt() {
		return currentBalanceDueAmt;
	}

	/**
	 * @return the currentMonthChargeAmt
	 */
	public double getCurrentMonthChargeAmt() {
		return currentMonthChargeAmt;
	}

	/**
	 * @return the daAmt
	 */
	public double getDaAmt() {
		return daAmt;
	}

	/**
	 * @return the daCt
	 */
	public int getDaCt() {
		return daCt;
	}

	/**
	 * @return the euclChargeAmount
	 */
	public double getEuclChargeAmount() {
		return euclChargeAmount;
	}

	/**
	 * @return the fedTaxAmount
	 */
	public double getFedTaxAmount() {
		return fedTaxAmount;
	}

	/**
	 * @return the hcapSrcgAmt
	 */
	public double getHcapSrcgAmt() {
		return hcapSrcgAmt;
	}

	/**
	 * @return the iecAmt
	 */
	public double getIecAmt() {
		return iecAmt;
	}

	/**
	 * @return the lflnSrcgAmt
	 */
	public double getLflnSrcgAmt() {
		return lflnSrcgAmt;
	}

	/**
	 * @return the mccAmount
	 */
	public double getMccAmount() {
		return mccAmount;
	}

	/**
	 * @return the monthlyServiceAmount
	 */
	public double getMonthlyServiceAmount() {
		return monthlyServiceAmount;
	}

	/**
	 * @return the nrgDsctMccAmt
	 */
	public double getNrgDsctMccAmt() {
		return nrgDsctMccAmt;
	}

	/**
	 * @return the nrgDsctOccAmt
	 */
	public double getNrgDsctOccAmt() {
		return nrgDsctOccAmt;
	}

	/**
	 * @return the occAmount
	 */
	public double getOccAmount() {
		return occAmount;
	}

	/**
	 * @return the otherBalanceAdjAmts
	 */
	public double getOtherBalanceAdjAmts() {
		return otherBalanceAdjAmts;
	}

	/**
	 * @return the regDsctMccAmt
	 */
	public double getRegDsctMccAmt() {
		return regDsctMccAmt;
	}

	/**
	 * @return the regDsctOccAmt
	 */
	public double getRegDsctOccAmt() {
		return regDsctOccAmt;
	}

	/**
	 * @return the srvUssfAmt
	 */
	public double getSrvUssfAmt() {
		return srvUssfAmt;
	}

	/**
	 * @return the stateTaxAmount
	 */
	public double getStateTaxAmount() {
		return stateTaxAmount;
	}

	/**
	 * @return the tollSubAmount
	 */
	public double getTollSubAmount() {
		return tollSubAmount;
	}

	/**
	 * @return the tollTotalAmount
	 */
	public double getTollTotalAmount() {
		return tollTotalAmount;
	}

	/**
	 * @return the totDsctTollAmt
	 */
	public double getTotDsctTollAmt() {
		return totDsctTollAmt;
	}

	/**
	 * @return the usscSrcgAmt
	 */
	public double getUsscSrcgAmt() {
		return usscSrcgAmt;
	}

	/**
	 * @return the zone1amt
	 */
	public double getZone1amt() {
		return zone1amt;
	}

	/**
	 * @return the zone1ct
	 */
	public int getZone1ct() {
		return zone1ct;
	}

	/**
	 * @return the zone1mou
	 */
	public double getZone1mou() {
		return zone1mou;
	}

	/**
	 * @return the zone23amt
	 */
	public double getZone23amt() {
		return zone23amt;
	}

	/**
	 * @return the zone23ct
	 */
	public int getZone23ct() {
		return zone23ct;
	}

	/**
	 * @return the zone23mou
	 */
	public double getZone23mou() {
		return zone23mou;
	}
	
	/**
	 * @return the sdUndergrdSrcgAmt
	 */
	public double getSdUndergrdSrcgAmt()
		{
			return sdUndergrdSrcgAmt;
		}
	
	//code change for BOC_AMT Field
	/**
	 * @return the bocAmt
	 */
	public double getBocAmt()
		{
			return bocAmt;
		}
	/**
	 * generates an AgencyBean from data stored in the AccountDetailBean.
	 * @return an AgencyBean if the detail belongs to an agency, or null if otherwise.
	 */
	public AgencyBean buildAgencyBean(){
		if(!isAgencyDetail()){
			return null;
		}
		AgencyBean agency = new AgencyBean();
		agency.setAccountClassCode(this.accountClassCode);
		agency.setAccountName(accountName);
		agency.setActiveAccountInd(activeAccountInd);
		agency.setAgencyId(agencyId);
		agency.setBillingAccountId(billingAccountId);
		agency.setBtn(btn);
		agency.setCroCode(croCode);
		return agency;
	}
	
	
	/**
	 * determines if the AccountDetailBean belongs to an agency.
	 * An agencyId of all zeroes means a non-agency AccountDetailBean.
	 * @return true if it belongs to an agency.
	 */
	public boolean isAgencyDetail(){
		return !agencyId.matches("^0+$");
	}
	


	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((accountClassCode == null) ? 0 : accountClassCode.hashCode());
		result = PRIME * result + ((accountName == null) ? 0 : accountName.hashCode());
		result = PRIME * result + ((activeAccountInd == null) ? 0 : activeAccountInd.hashCode());
		long temp;
		temp = Double.doubleToLongBits(adjustmentAmount);
		result = PRIME * result + (int) (temp ^ (temp >>> 32));
		result = PRIME * result + ((agencyId == null) ? 0 : agencyId.hashCode());
		temp = Double.doubleToLongBits(attSrcgAmt);
		result = PRIME * result + (int) (temp ^ (temp >>> 32));
		result = PRIME * result + ((billingAccountId == null) ? 0 : billingAccountId.hashCode());
		temp = Double.doubleToLongBits(blgSrcgAmt);
		result = PRIME * result + (int) (temp ^ (temp >>> 32));
		result = PRIME * result + ((btn == null) ? 0 : btn.hashCode());
		temp = Double.doubleToLongBits(callAmt900);
		result = PRIME * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(chcfaSrcgAmt);
		result = PRIME * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(chcfbSrcgAmt);
		result = PRIME * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(cityTaxAmount);
		result = PRIME * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(cpucSrcgAmt);
		result = PRIME * result + (int) (temp ^ (temp >>> 32));
		result = PRIME * result + ((croCode == null) ? 0 : croCode.hashCode());
		temp = Double.doubleToLongBits(ctfSrcgAmt);
		result = PRIME * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(currentBalanceDueAmt);
		result = PRIME * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(currentMonthChargeAmt);
		result = PRIME * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(daAmt);
		result = PRIME * result + (int) (temp ^ (temp >>> 32));
		result = PRIME * result + daCt;
		temp = Double.doubleToLongBits(euclChargeAmount);
		result = PRIME * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(fedTaxAmount);
		result = PRIME * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(hcapSrcgAmt);
		result = PRIME * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(iecAmt);
		result = PRIME * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(lflnSrcgAmt);
		result = PRIME * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(mccAmount);
		result = PRIME * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(monthlyServiceAmount);
		result = PRIME * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(nrgDsctMccAmt);
		result = PRIME * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(nrgDsctOccAmt);
		result = PRIME * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(occAmount);
		result = PRIME * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(otherBalanceAdjAmts);
		result = PRIME * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(regDsctMccAmt);
		result = PRIME * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(regDsctOccAmt);
		result = PRIME * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(srvUssfAmt);
		result = PRIME * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(stateTaxAmount);
		result = PRIME * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(tollSubAmount);
		result = PRIME * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(tollTotalAmount);
		result = PRIME * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(totDsctTollAmt);
		result = PRIME * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(usscSrcgAmt);
		result = PRIME * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(zone1amt);
		result = PRIME * result + (int) (temp ^ (temp >>> 32));
		result = PRIME * result + zone1ct;
		temp = Double.doubleToLongBits(zone1mou);
		result = PRIME * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(zone23amt);
		result = PRIME * result + (int) (temp ^ (temp >>> 32));
		result = PRIME * result + zone23ct;
		temp = Double.doubleToLongBits(zone23mou);
		result = PRIME * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(sdUndergrdSrcgAmt);
		result = PRIME * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(bocAmt);					//Added BOC_AMT Field
		result = PRIME * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final AccountDetailBean other = (AccountDetailBean) obj;
		if (accountClassCode == null) {
			if (other.accountClassCode != null)
				return false;
		} else if (!accountClassCode.equals(other.accountClassCode))
			return false;
		if (accountName == null) {
			if (other.accountName != null)
				return false;
		} else if (!accountName.equals(other.accountName))
			return false;
		if (activeAccountInd == null) {
			if (other.activeAccountInd != null)
				return false;
		} else if (!activeAccountInd.equals(other.activeAccountInd))
			return false;
		if (Double.doubleToLongBits(adjustmentAmount) != Double.doubleToLongBits(other.adjustmentAmount))
			return false;
		if (agencyId == null) {
			if (other.agencyId != null)
				return false;
		} else if (!agencyId.equals(other.agencyId))
			return false;
		if (Double.doubleToLongBits(attSrcgAmt) != Double.doubleToLongBits(other.attSrcgAmt))
			return false;
		if (billingAccountId == null) {
			if (other.billingAccountId != null)
				return false;
		} else if (!billingAccountId.equals(other.billingAccountId))
			return false;
		if (Double.doubleToLongBits(blgSrcgAmt) != Double.doubleToLongBits(other.blgSrcgAmt))
			return false;
		if (btn == null) {
			if (other.btn != null)
				return false;
		} else if (!btn.equals(other.btn))
			return false;
		if (Double.doubleToLongBits(callAmt900) != Double.doubleToLongBits(other.callAmt900))
			return false;
		if (Double.doubleToLongBits(chcfaSrcgAmt) != Double.doubleToLongBits(other.chcfaSrcgAmt))
			return false;
		if (Double.doubleToLongBits(chcfbSrcgAmt) != Double.doubleToLongBits(other.chcfbSrcgAmt))
			return false;
		if (Double.doubleToLongBits(cityTaxAmount) != Double.doubleToLongBits(other.cityTaxAmount))
			return false;
		if (Double.doubleToLongBits(cpucSrcgAmt) != Double.doubleToLongBits(other.cpucSrcgAmt))
			return false;
		if (croCode == null) {
			if (other.croCode != null)
				return false;
		} else if (!croCode.equals(other.croCode))
			return false;
		if (Double.doubleToLongBits(ctfSrcgAmt) != Double.doubleToLongBits(other.ctfSrcgAmt))
			return false;
		if (Double.doubleToLongBits(currentBalanceDueAmt) != Double.doubleToLongBits(other.currentBalanceDueAmt))
			return false;
		if (Double.doubleToLongBits(currentMonthChargeAmt) != Double.doubleToLongBits(other.currentMonthChargeAmt))
			return false;
		if (Double.doubleToLongBits(daAmt) != Double.doubleToLongBits(other.daAmt))
			return false;
		if (daCt != other.daCt)
			return false;
		if (Double.doubleToLongBits(euclChargeAmount) != Double.doubleToLongBits(other.euclChargeAmount))
			return false;
		if (Double.doubleToLongBits(fedTaxAmount) != Double.doubleToLongBits(other.fedTaxAmount))
			return false;
		if (Double.doubleToLongBits(hcapSrcgAmt) != Double.doubleToLongBits(other.hcapSrcgAmt))
			return false;
		if (Double.doubleToLongBits(iecAmt) != Double.doubleToLongBits(other.iecAmt))
			return false;
		if (Double.doubleToLongBits(lflnSrcgAmt) != Double.doubleToLongBits(other.lflnSrcgAmt))
			return false;
		if (Double.doubleToLongBits(mccAmount) != Double.doubleToLongBits(other.mccAmount))
			return false;
		if (Double.doubleToLongBits(monthlyServiceAmount) != Double.doubleToLongBits(other.monthlyServiceAmount))
			return false;
		if (Double.doubleToLongBits(nrgDsctMccAmt) != Double.doubleToLongBits(other.nrgDsctMccAmt))
			return false;
		if (Double.doubleToLongBits(nrgDsctOccAmt) != Double.doubleToLongBits(other.nrgDsctOccAmt))
			return false;
		if (Double.doubleToLongBits(occAmount) != Double.doubleToLongBits(other.occAmount))
			return false;
		if (Double.doubleToLongBits(otherBalanceAdjAmts) != Double.doubleToLongBits(other.otherBalanceAdjAmts))
			return false;
		if (Double.doubleToLongBits(regDsctMccAmt) != Double.doubleToLongBits(other.regDsctMccAmt))
			return false;
		if (Double.doubleToLongBits(regDsctOccAmt) != Double.doubleToLongBits(other.regDsctOccAmt))
			return false;
		if (Double.doubleToLongBits(srvUssfAmt) != Double.doubleToLongBits(other.srvUssfAmt))
			return false;
		if (Double.doubleToLongBits(stateTaxAmount) != Double.doubleToLongBits(other.stateTaxAmount))
			return false;
		if (Double.doubleToLongBits(tollSubAmount) != Double.doubleToLongBits(other.tollSubAmount))
			return false;
		if (Double.doubleToLongBits(tollTotalAmount) != Double.doubleToLongBits(other.tollTotalAmount))
			return false;
		if (Double.doubleToLongBits(totDsctTollAmt) != Double.doubleToLongBits(other.totDsctTollAmt))
			return false;
		if (Double.doubleToLongBits(usscSrcgAmt) != Double.doubleToLongBits(other.usscSrcgAmt))
			return false;
		if (Double.doubleToLongBits(zone1amt) != Double.doubleToLongBits(other.zone1amt))
			return false;
		if (zone1ct != other.zone1ct)
			return false;
		if (Double.doubleToLongBits(zone1mou) != Double.doubleToLongBits(other.zone1mou))
			return false;
		if (Double.doubleToLongBits(zone23amt) != Double.doubleToLongBits(other.zone23amt))
			return false;
		if (zone23ct != other.zone23ct)
			return false;
		if (Double.doubleToLongBits(zone23mou) != Double.doubleToLongBits(other.zone23mou))
			return false;
		if (Double.doubleToLongBits(sdUndergrdSrcgAmt) != Double.doubleToLongBits(other.sdUndergrdSrcgAmt))
			return false;	
		if (Double.doubleToLongBits(bocAmt) != Double.doubleToLongBits(other.bocAmt))	//Added BOC_AMT Field
			return false;	
		return true;
	}



	
	


}
