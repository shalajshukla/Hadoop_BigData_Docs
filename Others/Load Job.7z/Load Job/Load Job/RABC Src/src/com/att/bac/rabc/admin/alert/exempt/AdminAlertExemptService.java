/* Component Name: RABCPPG01237
 * Module Name: AdminAlertExemptService.java
 * Created on Sep 12, 2006
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.admin.alert.exempt;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.NamingException;

import org.apache.log4j.Logger;

import com.att.bac.rabc.ConnectionManager;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.StaticDataLoader;
import com.att.bac.rabc.admin.alert.rule.AlertRule;
import com.att.carat.util.JDBCUtil;

/**This is the facade class for the Alert Exempt process.  The purpose of this class is to handle
 * the business logic and populate the AdminAlertExemptForm.java class with data gathered from the
 * AdminAlertExemptDAO.java class.
 * 
 * @author js3175
 */
public class AdminAlertExemptService {
	private static final Logger logger = Logger.getLogger(AdminAlertExemptService.class);
	
	/**This is the method called to access the DAO for alert rule information.  This information is then 
	 * populated in a drop down menu.
	 * 
	 * @param adminAlertExemptForm  a blank AdminAlertExemptForm with userId & region populated
	 * @return adminAlertExemptForm  an AdminAlertExemptForm with data populated from the DAO
	 */
	protected static AdminAlertExemptForm adminAlertExempt(AdminAlertExemptForm adminAlertExemptForm) throws RABCException {
		logger.debug("Starting process AdminAlertExemptService.adminAlertExempt.");
		Connection conn = null;
		try {
			conn = ConnectionManager.getConnection(adminAlertExemptForm.getRegion());
			adminAlertExemptForm.setSelectedAlertRule("");
			adminAlertExemptForm.setAlertRules(AdminAlertExemptDAO.getRules(conn));
			logger.debug("Finished process AdminAlertExemptService.adminAlertExempt.");
		} catch (SQLException sqle) {
			throw new RABCException("SQL exception in creating a connection: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return adminAlertExemptForm;
	}
	
	/**This is the method called to access the DAO to get information on the active trend time
	 * exempts and the history of those trend time exempts.
	 * 
	 * @param adminAlertExemptForm  a blank AdminAlertExemptForm with userId & region populated
	 * @return adminAlertExemptForm  an AdminAlertExemptForm with data populated from the DAO
	 */
	protected static AdminAlertExemptForm adminAlertExemptTime(AdminAlertExemptForm adminAlertExemptForm) throws RABCException {
		logger.debug("Starting process AdminAlertExemptService.adminAlertExemptTime.");
		Connection conn = null;
		try {
			conn = ConnectionManager.getConnection(adminAlertExemptForm.getRegion());
			adminAlertExemptForm.setUpdatePermission(AdminAlertExemptDAO.getPermission(conn, adminAlertExemptForm.getUserId(), adminAlertExemptForm.getSelectedAlertRule()));
			AlertRule alertRuleObject = AdminAlertExemptDAO.getRuleDescription(conn, adminAlertExemptForm.getSelectedAlertRule());
			adminAlertExemptForm.setSelectedAlertRule(alertRuleObject.getAlertRule());
			adminAlertExemptForm.setSelectedAlertRuleDesc(alertRuleObject.getAlertDesc());
			adminAlertExemptForm.setAlertKeyLevel(alertRuleObject.getAlertKeyLvl());
			adminAlertExemptForm.setDivisionKeyLevel(alertRuleObject.getDivisionNameKeyLvl());
			adminAlertExemptForm.setSelectedAlertRuleType(alertRuleObject.getAlertRuleType());
			adminAlertExemptForm.setSelectedAlertTimeInd(alertRuleObject.getAlertTimeInd());
			if (adminAlertExemptForm.getSelectedAlertTimeInd().trim().equals("D"))
				adminAlertExemptForm.setActiveTrendTimes(AdminAlertExemptDAO.getDailyTrendTime());
			else
				adminAlertExemptForm.setActiveTrendTimes(AdminAlertExemptDAO.getBillPeriodTrendTime(adminAlertExemptForm.getRegion()));
			AdminAlertExemptDAO.updateActiveTrendTimes(conn, adminAlertExemptForm.getActiveTrendTimes(), adminAlertExemptForm.getSelectedAlertRule());
			adminAlertExemptForm.setDeactiveTrendTimes(AdminAlertExemptDAO.getDeactiveTrendTimes(conn, adminAlertExemptForm.getSelectedAlertRule()));
			if (adminAlertExemptForm.getSelectedAlertTimeInd().trim().equals("D"))
				AdminAlertExemptDAO.getDailyTrendTime(adminAlertExemptForm.getDeactiveTrendTimes());
			else
				AdminAlertExemptDAO.getBillPeriodTrendTime(adminAlertExemptForm.getDeactiveTrendTimes());
			logger.debug("Finished process AdminAlertExemptService.adminAlertExemptTime.");
		} catch (SQLException sqle) {
			throw new RABCException("SQL exception in creating a connection: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return adminAlertExemptForm;
	}
	
	/**This is the method called to access the DAO to get information on the active key level
	 * exempts and the history of those key level exempts.
	 * 
	 * @param adminAlertExemptForm  a blank AdminAlertExemptForm with userId & region populated
	 * @return adminAlertExemptForm  an AdminAlertExemptForm with data populated from the DAO
	 */
	protected static AdminAlertExemptForm adminAlertExemptKey(AdminAlertExemptForm adminAlertExemptForm) throws RABCException {
		logger.debug("Starting process AdminAlertExemptService.adminAlertExemptKey.");
		Connection conn = null;
		try {
			conn = ConnectionManager.getConnection(adminAlertExemptForm.getRegion());
			adminAlertExemptForm.setUpdatePermission(AdminAlertExemptDAO.getPermission(conn, adminAlertExemptForm.getUserId(), adminAlertExemptForm.getSelectedAlertRule()));
			AlertRule alertRuleObject = AdminAlertExemptDAO.getRuleDescription(conn, adminAlertExemptForm.getSelectedAlertRule());
			adminAlertExemptForm.setSelectedAlertRule(alertRuleObject.getAlertRule());
			adminAlertExemptForm.setSelectedAlertRuleDesc(alertRuleObject.getAlertDesc());
			adminAlertExemptForm.setAlertKeyLevel(alertRuleObject.getAlertKeyLvl());
			adminAlertExemptForm.setDivisionKeyLevel(alertRuleObject.getDivisionNameKeyLvl());
			adminAlertExemptForm.setSelectedAlertRuleType(alertRuleObject.getAlertRuleType());
			adminAlertExemptForm.setSelectedAlertTimeInd(alertRuleObject.getAlertTimeInd());
			adminAlertExemptForm.setActiveKeyExempts(AdminAlertExemptDAO.getActiveKeyExempts(conn, adminAlertExemptForm.getRegion(), adminAlertExemptForm.getSelectedAlertRule(), adminAlertExemptForm.getAlertKeyLevel(), adminAlertExemptForm.getSelectedAlertTimeInd()));
			adminAlertExemptForm.setDeactiveKeyExempts(AdminAlertExemptDAO.getDeactiveKeyExempts(conn, adminAlertExemptForm.getRegion(), adminAlertExemptForm.getSelectedAlertRule(), adminAlertExemptForm.getAlertKeyLevel(), adminAlertExemptForm.getSelectedAlertTimeInd()));
			adminAlertExemptForm.setKeyHeaders(AdminAlertExemptDAO.getKeyLevelHeaders(conn, adminAlertExemptForm.getAlertKeyLevel(), adminAlertExemptForm.getSelectedAlertRule()));
			adminAlertExemptForm.setDivisions(StaticDataLoader.getDivisionsByRegion(adminAlertExemptForm.getRegion()));
			adminAlertExemptForm.setDataItems(AdminAlertExemptDAO.getAlertItem(conn, adminAlertExemptForm.getSelectedAlertRule()));
			logger.debug("Finished process AdminAlertExemptService.adminAlertExemptKey.");
		} catch (SQLException sqle) {
			throw new RABCException("SQL exception in creating a connection: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return adminAlertExemptForm;
	}
	
	/**This is the method called to access the DAO to get information to populate the confirm page
	 * for updates to a trend time exempt.
	 * 
	 * @param adminAlertExemptForm  a blank AdminAlertExemptForm with userId & region populated
	 * @return adminAlertExemptForm  an AdminAlertExemptForm with data populated from the DAO
	 */
	protected static AdminAlertExemptForm adminAlertExemptConfirmTime(AdminAlertExemptForm adminAlertExemptForm) throws RABCException {
		logger.debug("Starting process AdminAlertExemptService.adminAlertExemptConfirmTime.");
		Connection conn = null;
		try {
			conn = ConnectionManager.getConnection(adminAlertExemptForm.getRegion());
			adminAlertExemptForm.setSelectedUserId(adminAlertExemptForm.getUserId());
			adminAlertExemptForm.setSelectedUserName(AdminAlertExemptDAO.getUserName(conn, adminAlertExemptForm.getSelectedUserId()));
			logger.debug("Finished process AdminAlertExemptService.adminAlertExemptConfirmTime.");
		} catch (SQLException sqle) {
			throw new RABCException("SQL exception in creating a connection: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return adminAlertExemptForm;
	}
	
	/**This is the method called to access the DAO to get information to populate the confirm page
	 * with information on new key level exempts entered.
	 * 
	 * @param adminAlertExemptForm  a blank AdminAlertExemptForm with userId & region populated
	 * @return adminAlertExemptForm  an AdminAlertExemptForm with data populated from the DAO
	 */
	protected static AdminAlertExemptForm adminAlertExemptConfirmKey(AdminAlertExemptForm adminAlertExemptForm) throws RABCException {
		logger.debug("Starting process AdminAlertExemptService.adminAlertExemptConfirmKey.");
		Connection conn = null;
		try {
			conn = ConnectionManager.getConnection(adminAlertExemptForm.getRegion());
			adminAlertExemptForm.setSelectedDataItem(adminAlertExemptForm.getSelectedNewDataItem());
			adminAlertExemptForm.setSelectedDivision(adminAlertExemptForm.getSelectedNewDivision());
			adminAlertExemptForm.setSelectedDivisionDesc(StaticDataLoader.getDivisionDesc(adminAlertExemptForm.getRegion(), adminAlertExemptForm.getSelectedDivision()));
			adminAlertExemptForm.setSelectedKey2(adminAlertExemptForm.getSelectedNewKey2().trim().toUpperCase());
			adminAlertExemptForm.setSelectedKey3(adminAlertExemptForm.getSelectedNewKey3().trim().toUpperCase());
			adminAlertExemptForm.setSelectedKey4(adminAlertExemptForm.getSelectedNewKey4().trim().toUpperCase());
			adminAlertExemptForm.setSelectedKey5(adminAlertExemptForm.getSelectedNewKey5().trim().toUpperCase());
			adminAlertExemptForm.setSelectedEndEffDate(adminAlertExemptForm.getSelectedNewEndEffDate().trim());
			adminAlertExemptForm.setKeyHeaders(AdminAlertExemptDAO.getKeyLevelHeaders(conn, adminAlertExemptForm.getAlertKeyLevel(), adminAlertExemptForm.getSelectedAlertRule()));
			AlertRule alertRuleObject = AdminAlertExemptDAO.getRuleDescription(conn, adminAlertExemptForm.getSelectedAlertRule());
			adminAlertExemptForm.setSelectedAlertRule(alertRuleObject.getAlertRule());
			adminAlertExemptForm.setSelectedAlertRuleDesc(alertRuleObject.getAlertDesc());
			adminAlertExemptForm.setAlertKeyLevel(alertRuleObject.getAlertKeyLvl());
			adminAlertExemptForm.setDivisionKeyLevel(alertRuleObject.getDivisionNameKeyLvl());
			logger.debug("Finished process AdminAlertExemptService.adminAlertExemptConfirmKey.");
		} catch (SQLException sqle) {
			throw new RABCException("SQL exception in creating a connection: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return adminAlertExemptForm;
	}
	
	/**This is the method called to access the DAO to get information to populate the confirm page
	 * with updates to the end effective date of key level exempts entered.
	 * 
	 * @param adminAlertExemptForm  a blank AdminAlertExemptForm with userId & region populated
	 * @return adminAlertExemptForm  an AdminAlertExemptForm with data populated from the DAO
	 */
	protected static AdminAlertExemptForm adminAlertExemptEndDateKey(AdminAlertExemptForm adminAlertExemptForm) throws RABCException {
		logger.debug("Starting process AdminAlertExemptService.adminAlertExemptEndDateKey.");
		Connection conn = null;
		try {
			conn = ConnectionManager.getConnection(adminAlertExemptForm.getRegion());
			adminAlertExemptForm.setKeyHeaders(AdminAlertExemptDAO.getKeyLevelHeaders(conn, adminAlertExemptForm.getAlertKeyLevel(), adminAlertExemptForm.getSelectedAlertRule()));
			if (adminAlertExemptForm.getSelectedDivision().equals("*"))
				adminAlertExemptForm.setSelectedDivisionDesc("*");
			else
				adminAlertExemptForm.setSelectedDivisionDesc(StaticDataLoader.getDivisionDesc(adminAlertExemptForm.getRegion(), adminAlertExemptForm.getSelectedDivision()));
			AlertRule alertRuleObject = AdminAlertExemptDAO.getRuleDescription(conn, adminAlertExemptForm.getSelectedAlertRule());
			adminAlertExemptForm.setSelectedAlertRule(alertRuleObject.getAlertRule());
			adminAlertExemptForm.setSelectedAlertRuleDesc(alertRuleObject.getAlertDesc());
			adminAlertExemptForm.setAlertKeyLevel(alertRuleObject.getAlertKeyLvl());
			adminAlertExemptForm.setDivisionKeyLevel(alertRuleObject.getDivisionNameKeyLvl());
			logger.debug("Finished process AdminAlertExemptService.adminAlertExemptEndDateKey.");
		} catch (SQLException sqle) {
			throw new RABCException("SQL exception in creating a connection: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return adminAlertExemptForm;
	}
	
	/**This is the method called update information on a particular trend time then send the user back
	 * to the main page.
	 * 
	 * @param adminAlertExemptForm  a blank AdminAlertExemptForm with userId & region populated
	 * @return adminAlertExemptForm  an AdminAlertExemptForm with data populated from the DAO
	 */
	protected static AdminAlertExemptForm updateTrendTimes(AdminAlertExemptForm adminAlertExemptForm) throws RABCException {
		logger.debug("Starting process AdminAlertExemptService.updateTrendTimes.");
		Connection conn = null;
		try {
			conn = ConnectionManager.getConnection(adminAlertExemptForm.getRegion());
			AdminAlertExemptDAO.insertTrendTime(conn, adminAlertExemptForm.getSelectedAlertRule(), adminAlertExemptForm.getSelectedAlertTrendTime(), adminAlertExemptForm.getUserId(), adminAlertExemptForm.getSelectedEndEffDate());
			adminAlertExemptForm.setAlertRules(AdminAlertExemptDAO.getRules(conn));
			logger.debug("Finished process AdminAlertExemptService.updateTrendTimes.");
		} catch (SQLException sqle) {
			throw new RABCException("SQL exception in creating a connection: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return adminAlertExemptForm;
	}
	
	/**This is the method called update information on a particular key level exempt then send the user back
	 * to the main page.
	 * 
	 * @param adminAlertExemptForm  a blank AdminAlertExemptForm with userId & region populated
	 * @return adminAlertExemptForm  an AdminAlertExemptForm with data populated from the DAO
	 */
	protected static AdminAlertExemptForm adminAlertExemptInsert(AdminAlertExemptForm adminAlertExemptForm) throws RABCException {
		logger.debug("Starting process AdminAlertExemptService.adminAlertExemptInsert.");
		Connection conn = null;
		try {
			conn = ConnectionManager.getConnection(adminAlertExemptForm.getRegion());
			AdminAlertExemptDAO.insertAlertExemptKeyValues(conn, adminAlertExemptForm.getSelectedAlertRule(), adminAlertExemptForm.getSelectedDataItem(), adminAlertExemptForm.getSelectedDivision(), adminAlertExemptForm.getSelectedKey2(), adminAlertExemptForm.getSelectedKey3(), adminAlertExemptForm.getSelectedKey4(), adminAlertExemptForm.getSelectedKey5(), adminAlertExemptForm.getUserId(), adminAlertExemptForm.getSelectedEndEffDate());
			adminAlertExemptForm.setAlertRules(AdminAlertExemptDAO.getRules(conn));
			logger.debug("Finished process AdminAlertExemptService.adminAlertExemptInsert.");
		} catch (SQLException sqle) {
			throw new RABCException("SQL exception in creating a connection: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return adminAlertExemptForm;
	}
}
