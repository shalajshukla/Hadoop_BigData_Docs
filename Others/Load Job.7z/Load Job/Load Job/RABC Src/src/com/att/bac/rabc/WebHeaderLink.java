/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc;

/**
 * This is a Data Object to represent RABC_WEB_HEADER_LINK table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class WebHeaderLink {
	private int presnId;
	private String webid;
	private int seqNum;
	private String linkPresnName;
	private String linkToPgm;
	private int linkPresnId;

	/**
	 * @return Returns the PresnId.
	 */
	public int getPresnId() {
		return presnId;
	}
	/**
	 * @return Returns the Webid.
	 */
	public String getWebid() {
		return webid;
	}
	/**
	 * @return Returns the SeqNum.
	 */
	public int getSeqNum() {
		return seqNum;
	}
	/**
	 * @return Returns the LinkPresnName.
	 */
	public String getLinkPresnName() {
		return linkPresnName;
	}
	/**
	 * @return Returns the LinkToPgm.
	 */
	public String getLinkToPgm() {
		return linkToPgm;
	}
	/**
	 * @return Returns the LinkPresnId.
	 */
	public int getLinkPresnId() {
		return linkPresnId;
	}

	/**
	 * @param PresnId The presnId to set.
	 */
	public void setPresnId(int presnId) {
		this.presnId = presnId;
	}
	/**
	 * @param Webid The webid to set.
	 */
	public void setWebid(String webid) {
		this.webid = webid;
	}
	/**
	 * @param SeqNum The seqNum to set.
	 */
	public void setSeqNum(int seqNum) {
		this.seqNum = seqNum;
	}
	/**
	 * @param LinkPresnName The linkPresnName to set.
	 */
	public void setLinkPresnName(String linkPresnName) {
		this.linkPresnName = linkPresnName;
	}
	/**
	 * @param LinkToPgm The linkToPgm to set.
	 */
	public void setLinkToPgm(String linkToPgm) {
		this.linkToPgm = linkToPgm;
	}
	/**
	 * @param LinkPresnId The linkPresnId to set.
	 */
	public void setLinkPresnId(int linkPresnId) {
		this.linkPresnId = linkPresnId;
	}
}
