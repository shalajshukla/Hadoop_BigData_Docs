/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.rpt;
import java.util.Date;

/**
 * This is a Data Object to represent RABC_ALERT_HIST table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class AlertHist {
	private int partiRefId;
	private Date procDate;
	private int fileSeqNum;
	private String alertTrendTime;
	private String[] alertKey = {"","","","",""};
	private String alertItem;
	private double alertAvg;
	private double alertHigh;
	private double alertLow;
	private double variancePct;
	private double varianceData;
	private double alertData;
	private double alertActualData;
	private String presnCd;

	/**
	 * @return Returns the PartiRefId.
	 */
	public int getPartiRefId() {
		return partiRefId;
	}
	/**
	 * @return Returns the ProcDate.
	 */
	public Date getProcDate() {
		return procDate;
	}
	/**
	 * @return Returns the FileSeqNum.
	 */
	public int getFileSeqNum() {
		return fileSeqNum;
	}
	/**
	 * @return Returns the AlertTrendTime.
	 */
	public String getAlertTrendTime() {
		return alertTrendTime;
	}
	/**
	 * @return Returns the AlertKey
	 */
	public String getAlertKeyAt(int i) {
		return alertKey[i].trim() ;
	}
	/**
	 * @return Returns the AlertItem.
	 */
	public String getAlertItem() {
		return alertItem;
	}
	/**
	 * @return Returns the AlertAvg.
	 */
	public double getAlertAvg() {
		return alertAvg;
	}
	/**
	 * @return Returns the AlertHigh.
	 */
	public double getAlertHigh() {
		return alertHigh;
	}
	/**
	 * @return Returns the AlertLow.
	 */
	public double getAlertLow() {
		return alertLow;
	}
	/**
	 * @return Returns the VariancePct.
	 */
	public double getVariancePct() {
		return variancePct;
	}
	/**
	 * @return Returns the VarianceData.
	 */
	public double getVarianceData() {
		return varianceData;
	}
	/**
	 * @return Returns the AlertData.
	 */
	public double getAlertData() {
		return alertData;
	}
	/**
	 * @return Returns the AlertActualData.
	 */
	public double getAlertActualData() {
		return alertActualData;
	}
	/**
	 * @return Returns the PresnCd.
	 */
	public String getPresnCd() {
		return presnCd;
	}

	/**
	 * @param PartiRefId The partiRefId to set.
	 */
	public void setPartiRefId(int partiRefId) {
		this.partiRefId = partiRefId;
	}
	/**
	 * @param ProcDate The procDate to set.
	 */
	public void setProcDate(Date procDate) {
		this.procDate = procDate;
	}
	/**
	 * @param FileSeqNum The fileSeqNum to set.
	 */
	public void setFileSeqNum(int fileSeqNum) {
		this.fileSeqNum = fileSeqNum;
	}
	/**
	 * @param AlertTrendTime The alertTrendTime to set.
	 */
	public void setAlertTrendTime(String alertTrendTime) {
		this.alertTrendTime = alertTrendTime;
	}
	/**
	 * @param AlertKey1 The alertKey1 to set.
	 */
	public void setAlertKeyAt(int i, String alertKey1) {
		this.alertKey[i] = alertKey1;
	}
	/**
	 * @param AlertItem The alertItem to set.
	 */
	public void setAlertItem(String alertItem) {
		this.alertItem = alertItem;
	}
	/**
	 * @param AlertAvg The alertAvg to set.
	 */
	public void setAlertAvg(double alertAvg) {
		this.alertAvg = alertAvg;
	}
	/**
	 * @param AlertHigh The alertHigh to set.
	 */
	public void setAlertHigh(double alertHigh) {
		this.alertHigh = alertHigh;
	}
	/**
	 * @param AlertLow The alertLow to set.
	 */
	public void setAlertLow(double alertLow) {
		this.alertLow = alertLow;
	}
	/**
	 * @param VariancePct The variancePct to set.
	 */
	public void setVariancePct(double variancePct) {
		this.variancePct = variancePct;
	}
	/**
	 * @param VarianceData The varianceData to set.
	 */
	public void setVarianceData(double varianceData) {
		this.varianceData = varianceData;
	}
	/**
	 * @param AlertData The alertData to set.
	 */
	public void setAlertData(double alertData) {
		this.alertData = alertData;
	}
	/**
	 * @param AlertActualData The alertActualData to set.
	 */
	public void setAlertActualData(double alertActualData) {
		this.alertActualData = alertActualData;
	}
	/**
	 * @param PresnCd The presnCd to set.
	 */
	public void setPresnCd(String presnCd) {
		this.presnCd = presnCd;
	}
	
	public boolean equals(AlertHist alertHistArg) {
		if (this.partiRefId != alertHistArg.getPartiRefId()) return false;
		if (this.fileSeqNum != alertHistArg.getFileSeqNum()) return false;
		
		if ((alertHistArg.getAlertTrendTime() != null) && (!this.alertTrendTime.equals(alertHistArg.getAlertTrendTime()))) return false;
		if ((alertHistArg.getAlertKeyAt(0) != null) && (!this.alertKey[0].equals(alertHistArg.getAlertKeyAt(0)))) return false;
		if ((alertHistArg.getAlertKeyAt(1) != null) && (!this.alertKey[1].equals(alertHistArg.getAlertKeyAt(1)))) return false;
		if ((alertHistArg.getAlertKeyAt(2) != null) && (!this.alertKey[2].equals(alertHistArg.getAlertKeyAt(2)))) return false;
		if ((alertHistArg.getAlertKeyAt(3) != null) && (!this.alertKey[3].equals(alertHistArg.getAlertKeyAt(3)))) return false;
		if ((alertHistArg.getAlertKeyAt(4) != null) && (!this.alertKey[4].equals(alertHistArg.getAlertKeyAt(4)))) return false;
		if ((alertHistArg.getAlertItem() != null) && (!this.alertItem.equals(alertHistArg.getAlertItem()))) return false;
		if (this.alertAvg != alertHistArg.getAlertAvg()) return false;
		if (this.alertHigh != alertHistArg.getAlertHigh()) return false;
		if (this.alertLow != alertHistArg.getAlertLow()) return false;
		if (this.variancePct != alertHistArg.getVariancePct()) return false;
		if (this.varianceData != alertHistArg.getVarianceData()) return false;
		if (this.alertData != alertHistArg.getAlertData()) return false;
		if (this.alertActualData != alertHistArg.getAlertActualData()) return false;
		if ((alertHistArg.getPresnCd() != null) && (!this.presnCd.equals(alertHistArg.getPresnCd()))) return false;
		
		// Code added on 21-Nov-06 to fix AL#48
		if ("".equals(alertHistArg.getAlertTrendTime()) && "".equals(alertHistArg.getAlertTrendTime())) return false;
		// Code uncommented on 18-April-2007 for CAL#44 fix
		if (this.getProcDate().getTime()!=alertHistArg.getProcDate().getTime()) return false;
		return true;
	}
	
	public String getLabels() {
		StringBuffer tmpStrBuf = new StringBuffer();
		tmpStrBuf.append("partiRefId");
		tmpStrBuf.append(",");
		tmpStrBuf.append("procDate");
		tmpStrBuf.append(",");
		tmpStrBuf.append("fileSeqNum");
		tmpStrBuf.append(",");
		tmpStrBuf.append("alertTrendTime");
		tmpStrBuf.append(",");
		tmpStrBuf.append("alertKey_1"); 
		tmpStrBuf.append(",");
		tmpStrBuf.append("alertKey_2"); 
		tmpStrBuf.append(",");
		tmpStrBuf.append("alertKey_3"); 
		tmpStrBuf.append(",");
		tmpStrBuf.append("alertKey_4"); 
		tmpStrBuf.append(",");
		tmpStrBuf.append("alertKey_5"); 
		tmpStrBuf.append(",");
		tmpStrBuf.append("alertItem");
		tmpStrBuf.append(",");
		tmpStrBuf.append("alertAvg");
		tmpStrBuf.append(",");
		tmpStrBuf.append("alertHigh");
		tmpStrBuf.append(",");
		tmpStrBuf.append("alertLow");
		tmpStrBuf.append(",");
		tmpStrBuf.append("variancePct");
		tmpStrBuf.append(",");
		tmpStrBuf.append("varianceData");
		tmpStrBuf.append(",");
		tmpStrBuf.append("alertData");
		tmpStrBuf.append(",");
		tmpStrBuf.append("alertActualData");
		tmpStrBuf.append(",");
		tmpStrBuf.append("presnCd");
		
		return tmpStrBuf.toString();
	}
	public String toString() {
		StringBuffer tmpStrBuf = new StringBuffer();
		tmpStrBuf.append(this.partiRefId);
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.procDate==null?"":this.procDate.toString()));
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.fileSeqNum);
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.alertTrendTime==null?"":this.alertTrendTime));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.alertKey[0]==null?"":this.alertKey[0]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.alertKey[1]==null?"":this.alertKey[1]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.alertKey[2]==null?"":this.alertKey[2]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.alertKey[3]==null?"":this.alertKey[3]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.alertKey[4]==null?"":this.alertKey[4]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.alertItem==null?"":this.alertItem));
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.alertAvg);
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.alertHigh);
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.alertLow);
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.variancePct);
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.varianceData);
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.alertData);
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.alertActualData);
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.presnCd==null?"":this.presnCd));
		return tmpStrBuf.toString();
	}
}
