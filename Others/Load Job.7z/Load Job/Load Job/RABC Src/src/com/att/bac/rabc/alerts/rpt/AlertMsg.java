/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.rpt;
import java.util.Date;

/**
 * This is a Data Object to represent RABC_ALERT_MSG table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class AlertMsg {
	private int msgNum;
	private Date procDate;
	private int fileSeqNum;
	private String alertRule;
	private String alertType;
	private String alertTimeInd;
	private String alertTimeValue;
	private int alertKeyLvl;
	private String[] alertKey = {"","","","",""};
	private String[] alertData = {"","","","",""};
	private String alertItem;
	private String alertSuppInd;
	private double alertActual;
	private String alertUnitInd;
	private double iAlertData;
	private double alertPct;
	private String alertUserId;
	private String alertGrp;
	private double alertRevenue;
	private String alertStatus;
	private String alertMsg;
	private String alertRootCatgyCd;
	private String alertRootCause;
	private String alertSevereLvlInd;
	private int alertSysErrCd;
	private Date timeStamp;
	private Date alertRuleRunDt;
	private double alertLostRevenue;

	/**
	 * @return Returns the MsgNum.
	 */
	public int getMsgNum() {
		return msgNum;
	}
	/**
	 * @return Returns the ProcDate.
	 */
	public Date getProcDate() {
		return procDate;
	}
	/**
	 * @return Returns the FileSeqNum.
	 */
	public int getFileSeqNum() {
		return fileSeqNum;
	}
	/**
	 * @return Returns the AlertRule.
	 */
	public String getAlertRule() {
		return alertRule;
	}
	/**
	 * @return Returns the AlertType.
	 */
	public String getAlertType() {
		return alertType;
	}
	/**
	 * @return Returns the AlertTimeInd.
	 */
	public String getAlertTimeInd() {
		return alertTimeInd;
	}
	/**
	 * @return Returns the AlertTimeValue.
	 */
	public String getAlertTimeValue() {
		return alertTimeValue;
	}
	/**
	 * @return Returns the AlertKeyLvl.
	 */
	public int getAlertKeyLvl() {
		return alertKeyLvl;
	}
	/**
	 * @return Returns the AlertKey1.
	 */
	public String getAlertKeyAt(int i) {
		return this.alertKey[i];
	}
	/**
	 * @return Returns the AlertData1.
	 */
	public String getAlertDataAt(int i) {
		return this.alertData[i];
	}
	/**
	 * @return Returns the AlertItem.
	 */
	public String getAlertItem() {
		return alertItem;
	}
	/**
	 * @return Returns the AlertSuppInd.
	 */
	public String getAlertSuppInd() {
		return alertSuppInd;
	}
	/**
	 * @return Returns the AlertActual.
	 */
	public double getAlertActual() {
		return alertActual;
	}
	/**
	 * @return Returns the AlertUnitInd.
	 */
	public String getAlertUnitInd() {
		return alertUnitInd;
	}
	/**
	 * @return Returns the AlertData.
	 */
	public double getIAlertData() {
		return iAlertData;
	}
	/**
	 * @return Returns the AlertPct.
	 */
	public double getAlertPct() {
		return alertPct;
	}
	/**
	 * @return Returns the AlertUserId.
	 */
	public String getAlertUserId() {
		return alertUserId;
	}
	/**
	 * @return Returns the AlertGrp.
	 */
	public String getAlertGrp() {
		return alertGrp;
	}
	/**
	 * @return Returns the AlertRevenue.
	 */
	public double getAlertRevenue() {
		return alertRevenue;
	}
	/**
	 * @return Returns the AlertStatus.
	 */
	public String getAlertStatus() {
		return alertStatus;
	}
	/**
	 * @return Returns the AlertMsg.
	 */
	public String getAlertMsg() {
		return alertMsg;
	}
	/**
	 * @return Returns the AlertRootCatgyCd.
	 */
	public String getAlertRootCatgyCd() {
		return alertRootCatgyCd;
	}
	/**
	 * @return Returns the AlertRootCause.
	 */
	public String getAlertRootCause() {
		return alertRootCause;
	}
	/**
	 * @return Returns the AlertSevereLvlInd.
	 */
	public String getAlertSevereLvlInd() {
		return alertSevereLvlInd;
	}
	/**
	 * @return Returns the AlertSysErrCd.
	 */
	public int getAlertSysErrCd() {
		return alertSysErrCd;
	}
	/**
	 * @return Returns the TimeStamp.
	 */
	public Date getTimeStamp() {
		return timeStamp;
	}
	/**
	 * @return Returns the AlertRuleRunDt.
	 */
	public Date getAlertRuleRunDt() {
		return alertRuleRunDt;
	}
	/**
	 * @return Returns the AlertLostRevenue.
	 */
	public double getAlertLostRevenue() {
		return alertLostRevenue;
	}

	/**
	 * @param MsgNum The msgNum to set.
	 */
	public void setMsgNum(int msgNum) {
		this.msgNum = msgNum;
	}
	/**
	 * @param ProcDate The procDate to set.
	 */
	public void setProcDate(Date procDate) {
		this.procDate = procDate;
	}
	/**
	 * @param FileSeqNum The fileSeqNum to set.
	 */
	public void setFileSeqNum(int fileSeqNum) {
		this.fileSeqNum = fileSeqNum;
	}
	/**
	 * @param AlertRule The alertRule to set.
	 */
	public void setAlertRule(String alertRule) {
		this.alertRule = alertRule;
	}
	/**
	 * @param AlertType The alertType to set.
	 */
	public void setAlertType(String alertType) {
		this.alertType = alertType;
	}
	/**
	 * @param AlertTimeInd The alertTimeInd to set.
	 */
	public void setAlertTimeInd(String alertTimeInd) {
		this.alertTimeInd = alertTimeInd;
	}
	/**
	 * @param AlertTimeValue The alertTimeValue to set.
	 */
	public void setAlertTimeValue(String alertTimeValue) {
		this.alertTimeValue = alertTimeValue;
	}
	/**
	 * @param AlertKeyLvl The alertKeyLvl to set.
	 */
	public void setAlertKeyLvl(int alertKeyLvl) {
		this.alertKeyLvl = alertKeyLvl;
	}
	/**
	 * @param AlertKey1 The alertKey1 to set.
	 */
	public void setAlertKeyAt(int i, String alertKey1) {
		this.alertKey[i] = alertKey1;
	}
	/**
	 * @param AlertData1 The alertData1 to set.
	 */
	public void setAlertDataAt(int i, String alertData) {
		this.alertData[i] = alertData;
	}
	/**
	 * @param AlertItem The alertItem to set.
	 */
	public void setAlertItem(String alertItem) {
		this.alertItem = alertItem;
	}
	/**
	 * @param AlertSuppInd The alertSuppInd to set.
	 */
	public void setAlertSuppInd(String alertSuppInd) {
		this.alertSuppInd = alertSuppInd;
	}
	/**
	 * @param AlertActual The alertActual to set.
	 */
	public void setAlertActual(double alertActual) {
		this.alertActual = alertActual;
	}
	/**
	 * @param AlertUnitInd The alertUnitInd to set.
	 */
	public void setAlertUnitInd(String alertUnitInd) {
		this.alertUnitInd = alertUnitInd;
	}
	/**
	 * @param AlertData The alertData to set.
	 */
	public void setIAlertData(double iAlertData) {
		this.iAlertData = iAlertData;
	}
	/**
	 * @param AlertPct The alertPct to set.
	 */
	public void setAlertPct(double alertPct) {
		this.alertPct = alertPct;
	}
	/**
	 * @param AlertUserId The alertUserId to set.
	 */
	public void setAlertUserId(String alertUserId) {
		this.alertUserId = alertUserId;
	}
	/**
	 * @param AlertGrp The alertGrp to set.
	 */
	public void setAlertGrp(String alertGrp) {
		this.alertGrp = alertGrp;
	}
	/**
	 * @param AlertRevenue The alertRevenue to set.
	 */
	public void setAlertRevenue(double alertRevenue) {
		this.alertRevenue = alertRevenue;
	}
	/**
	 * @param AlertStatus The alertStatus to set.
	 */
	public void setAlertStatus(String alertStatus) {
		this.alertStatus = alertStatus;
	}
	/**
	 * @param AlertMsg The alertMsg to set.
	 */
	public void setAlertMsg(String alertMsg) {
		this.alertMsg = alertMsg;
	}
	/**
	 * @param AlertRootCatgyCd The alertRootCatgyCd to set.
	 */
	public void setAlertRootCatgyCd(String alertRootCatgyCd) {
		this.alertRootCatgyCd = alertRootCatgyCd;
	}
	/**
	 * @param AlertRootCause The alertRootCause to set.
	 */
	public void setAlertRootCause(String alertRootCause) {
		this.alertRootCause = alertRootCause;
	}
	/**
	 * @param AlertSevereLvlInd The alertSevereLvlInd to set.
	 */
	public void setAlertSevereLvlInd(String alertSevereLvlInd) {
		this.alertSevereLvlInd = alertSevereLvlInd;
	}
	/**
	 * @param AlertSysErrCd The alertSysErrCd to set.
	 */
	public void setAlertSysErrCd(int alertSysErrCd) {
		this.alertSysErrCd = alertSysErrCd;
	}
	/**
	 * @param TimeStamp The timeStamp to set.
	 */
	public void setTimeStamp(Date timeStamp) {
		this.timeStamp = timeStamp;
	}
	/**
	 * @param AlertRuleRunDt The alertRuleRunDt to set.
	 */
	public void setAlertRuleRunDt(Date alertRuleRunDt) {
		this.alertRuleRunDt = alertRuleRunDt;
	}
	/**
	 * @param AlertLostRevenue The alertLostRevenue to set.
	 */
	public void setAlertLostRevenue(double alertLostRevenue) {
		this.alertLostRevenue = alertLostRevenue;
	}
}
