/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.admin.adhoc.rpt;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.att.bac.rabc.ConnectionManager;
import com.att.bac.rabc.ProgressBar;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.StaticDataLoader;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Module description: 
 * 
 * This is an Main Page Action class for the Adhoc report definition Component. 
 *
 * @author Anup Thomas - AT1862
 */
public class AdhocMainPageAction extends DispatchAction {
	private static final Logger logger = Logger.getLogger(AdhocMainPageAction.class);
	AdhocMainPageService adhocMainPageService = AdhocMainPageService.getAdhocMainPageService();

	/**
	 * Default dispatch action method to handle the request for Adhoc Report navigation.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @see org.apache.struts.actions.DispatchAction#unspecified(org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public ActionForward unspecified(ActionMapping mapping,ActionForm form,HttpServletRequest request, HttpServletResponse response)  {
		AdhocMainPageForm adhocMainPageForm = (AdhocMainPageForm) form;
		HttpSession session = request.getSession();
		ProgressBar progressBar = new ProgressBar(session);
		ActionForward forward = null ;
		Connection connection = null ;
		List failureList = new ArrayList();
		List permissionArgs = new ArrayList();
		boolean hasPermission = false ; 
		progressBar.setProgressPercent(10);
		try {
			// Get the connection from the available pool
			connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
			progressBar.setProgressPercent(20);

			List args = new ArrayList();
			
			// Get the existing adhoc reports and store them in arraylist
			List result = adhocMainPageService.getReportNameList(connection,failureList,args) ;
			progressBar.setProgressPercent(50);
			
			// Set the report names to form 
			adhocMainPageForm.setReportNameList(result);
			
			//Set calendar attributes
			adhocMainPageForm.setBillRounds(StaticDataLoader.getBillRounds((String)request.getSession().getAttribute("region")));
			adhocMainPageForm.setProcDates(StaticDataLoader.getProcDates((String)request.getSession().getAttribute("region")));
			adhocMainPageForm.setHolidayIndicators(StaticDataLoader.getHolidayIndicators((String)request.getSession().getAttribute("region")));
			adhocMainPageForm.setLoadedDataDates(StaticDataLoader.getLoadedDataDatesByRegion((String)request.getSession().getAttribute("region")));
			
			//find whether the user has the permission to create new report / copy report  
			permissionArgs.add((String)request.getSession().getAttribute("bacUserID")) ;
			permissionArgs.add("UR") ;// UR for Update Report 
			progressBar.setProgressPercent(60);

			hasPermission  = adhocMainPageService.getPermissionAdhocReport(connection,permissionArgs,failureList);
			progressBar.setProgressPercent(90);
			
			//adhocMainPageForm.setHasPermission(hasPermission) ;
			adhocMainPageForm.setHasPermission(true) ;
				
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		progressBar.setProgressPercent(100);
		
		if (!failureList.isEmpty()){
			request.setAttribute("failures", failureList);
			forward =  mapping.findForward("error");
		} else {
			forward =  mapping.findForward("AdhocMain");
		}
		  
		return forward ;
	}
	
	/**
	 * Dispatch action method to handle the request for new adhoc report page.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward newReport(ActionMapping mapping,ActionForm form,HttpServletRequest request, HttpServletResponse response){
		AdhocMainPageForm adhocMainPageForm = (AdhocMainPageForm) form;
		HttpSession session = request.getSession();
		ProgressBar progressBar = new ProgressBar(session);
		ActionForward forward = null ;
		forward =  mapping.findForward("newReport");
		return forward ;
	}
	
	/**
	 * Dispatch action method to handle the request for update adhoc report.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward updateReport(ActionMapping mapping,ActionForm form,HttpServletRequest request, HttpServletResponse response) {
		AdhocMainPageForm adhocMainPageForm = (AdhocMainPageForm) form;
		HttpSession session = request.getSession();
		ProgressBar progressBar = new ProgressBar(session);
		Connection connection = null;
		List failureList = new ArrayList();
		List accessArgs = new ArrayList();
		List groupArgs = new ArrayList();
		boolean updateAccess = false;
		String currGroups = "";
		
		try {
			connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
			
			if (session.getAttribute("bacUserID")!=null){
				accessArgs.add((String)session.getAttribute("bacUserID"));
				accessArgs.add(adhocMainPageForm.getReportId());
				//updateAccess = adhocMainPageService.checkUpdateAccess(connection,failureList,accessArgs);
				updateAccess = true;
				groupArgs.add(adhocMainPageForm.getReportId());
				currGroups = adhocMainPageService.getCurrGrps(connection,failureList,groupArgs);
			}	
			
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		
		/*
		 * Forward to error in case of error; to main page in case of insufficient permissions
		 */
		if (!failureList.isEmpty()){
			request.setAttribute("failures", failureList);
			progressBar.setProgressPercent(100);
			return mapping.findForward("error");
		} else if (updateAccess){
			request.setAttribute("presnId",adhocMainPageForm.getReportId());
			return mapping.findForward("updateReport");
		} else {
			progressBar.setProgressPercent(100);
			adhocMainPageForm.setMessage("In order to update this ad hoc report, you must be a member of one of the following groups:" + currGroups);
			return unspecified(mapping,adhocMainPageForm, request, response);
		}
	}

	/**
	 * Dispatch action method to handle the request for copy adhoc report.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward copyReport(ActionMapping mapping,ActionForm form,HttpServletRequest request, HttpServletResponse response) {
		AdhocMainPageForm adhocMainPageForm = (AdhocMainPageForm)form;
		HttpSession session = request.getSession();
		ProgressBar progressBar = new ProgressBar(session);
		request.setAttribute("presnId",adhocMainPageForm.getReportId());
		return mapping.findForward("copyReport");
	}
	
	/**
	 * Dispatch action method to handle the request after saving adhoc report.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward save(ActionMapping mapping,ActionForm form,HttpServletRequest request, HttpServletResponse response) {
		return unspecified(mapping,form,request, response);
	}
	
	/**
	 * Dispatch action method to handle the request for deleting adhoc report.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward AdhocReportDelete(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)  {
		AdhocMainPageForm adhocMainPageForm = (AdhocMainPageForm) form;
		HttpSession session = request.getSession();
		ProgressBar progressBar = new ProgressBar(session);
		Connection connection = null;
		List failureList = new ArrayList();
		List accessArgs = new ArrayList();
		List groupArgs = new ArrayList();
		boolean updateAccess = false;
		String currGroups = "";
		
		try {
			connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
			
			if (session.getAttribute("bacUserID")!=null){
				accessArgs.add((String)session.getAttribute("bacUserID"));
				accessArgs.add(adhocMainPageForm.getReportId());
				updateAccess = adhocMainPageService.checkUpdateAccess(connection,failureList,accessArgs);
				groupArgs.add(adhocMainPageForm.getReportId());
				currGroups = adhocMainPageService.getCurrGrps(connection,failureList,groupArgs);
			}	
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch(Exception e){
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		
		/*
		 * Forward to error in case of error; to main page in case of insufficient permissions
		 */
		if (!failureList.isEmpty()){
			request.setAttribute("failures", failureList);
			progressBar.setProgressPercent(100);
			return mapping.findForward("error");
		} else if (updateAccess){
			request.setAttribute("presnId",adhocMainPageForm.getReportId());
			return mapping.findForward("AdhocReportDelete");
		} else {
			progressBar.setProgressPercent(100);
			adhocMainPageForm.setMessage("In order to delete this ad hoc report, you must be a member of one of the following groups:" + currGroups);
			return unspecified(mapping,adhocMainPageForm, request, response);
		}
	}
	
	/**
	 * Dispatch action method to handle the request to load adhoc scheduler page.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward loadSchedule(ActionMapping mapping,ActionForm form,HttpServletRequest request, HttpServletResponse response) {
		AdhocMainPageForm adhocMainPageForm = (AdhocMainPageForm)form;
		HttpSession session = request.getSession();
		ProgressBar progressBar = new ProgressBar(session);
		request.setAttribute("presnId",adhocMainPageForm.getReportId());
		return mapping.findForward("loadSchedule");
	}
}
