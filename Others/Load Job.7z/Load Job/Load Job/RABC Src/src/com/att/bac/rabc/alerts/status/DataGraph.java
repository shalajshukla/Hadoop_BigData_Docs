/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.alerts.status;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;

import com.att.bac.rabc.DateUtil;

import de.laures.cewolf.DatasetProduceException;
import de.laures.cewolf.DatasetProducer;
import de.laures.cewolf.links.CategoryItemLinkGenerator;
import de.laures.cewolf.tooltips.CategoryToolTipGenerator;

/**
 * Data Graph object which is used by the CeWolf Renderer servlet to render data into a chart. This object
 * implements the DatasetProducer interface & its produceDataset() method is invoked by the servlet to render 
 * the graph. It should be ensured that this object has the list of DataGraphData objects available by the time the 
 * produceDataset() method is invoked.
 * 
 * @author Shailesh Hemdev - SH8512
 */
public class DataGraph implements DatasetProducer, CategoryToolTipGenerator, CategoryItemLinkGenerator, Serializable {
	private static final Logger logger = Logger.getLogger(DataGraph.class);
    private List dataGraphDataList = new ArrayList();
    private final String [] itemNames = {"Base Data", "Actual Data"};
    
	/**
	 * @return Returns the percentGraphDataList.
	 */
	public List getDataGraphDataList() {
		return dataGraphDataList;
	}

	/**
     * Method to add DataGraphData objects to the class attribute dataGraphDataList list.
     * 
     * @param dataGraphDataList
     */ 
    public void updateList(List dataGraphDataList) {
    	int size = dataGraphDataList.size();
    	for (int i=0;i<size;i++){
    		DataGraphData dataGraphData = (DataGraphData)dataGraphDataList.get(i);
    		this.dataGraphDataList.add(dataGraphData);
    	}
    }
	
    /**
     * Method to produce the graph with the following parameters:
	 * 1) Series = Item + total
	 * 2) Y Axis values = Sum data for sum + total for total
	 * 3) X Axis values = File sequence number if not null else Proc Date
     * 
     * @param map
     * @see de.laures.cewolf.DatasetProducer#produceDataset(java.util.Map)
     */
    public Object produceDataset(Map map) throws DatasetProduceException {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset() {
			/**
			 * @see java.lang.Object#finalize()
			 */
			protected void finalize() throws Throwable {
				super.finalize();
				logger.debug(this +" finalized.");
			}
        };
        
        for (int series = 0; series < this.getDataGraphDataList().size(); series ++) {
        	DataGraphData dataGraphData = (DataGraphData)this.dataGraphDataList.get(series);
        	String category;
        	String itemName;
        	
        	if (dataGraphData.getFileSeqNum()==-1){
        		if (dataGraphData.getProcDate()!=null){
        			String procDateDay = dataGraphData.getProcDate().toString().substring(3,5);
                    String procDateMonth = getDisplayMonth(dataGraphData.getProcDate().toString());
                    String procDateYear = dataGraphData.getProcDate().toString().substring(6,dataGraphData.getProcDate().toString().length());
                    category = procDateDay + "-" + procDateMonth + "-" + procDateYear;
        		}else {
                    category = dataGraphData.getProcDateString();
        		}
        	 	
        	}else {
           		category = Integer.toString(dataGraphData.getFileSeqNum());
        	}
        	
        	if (dataGraphData.getAlertTrendTime()!=null){
        		category = category + "," + dataGraphData.getAlertTrendTime();
        	}
        	
        	dataset.addValue(dataGraphData.getSumData(),itemNames[0],category);
        	
        	if (dataGraphData.getTotalData()!=-1){
        		dataset.addValue(dataGraphData.getTotalData(),itemNames[1],category);
        	}
        }
        return dataset;
    }
    
    /**
     * Method to invalidate producer's data after 5 seconds. By this method the
     * producer can influence Cewolf's caching behaviour the way it wants to.
     * 
     * @param map
     * @param since
     * @see de.laures.cewolf.DatasetProducer#hasExpired(java.util.Map, java.util.Date)
     */
    public boolean hasExpired(Map map, Date since) {
	        logger.debug(getClass().getName() + "hasExpired()");
	        return (System.currentTimeMillis() - since.getTime())  > 5000;
	}

    /**
     * Method to return a unique ID for this DatasetProducer.
     * 
     * @see de.laures.cewolf.DatasetProducer#hasExpired(java.util.Map, java.util.Date)
     */
	public String getProducerId() {
		return "DataGraph DatasetProducer";
	}

	/**
     * Method to return a link target for a special data item.
     * 
     * @param data
     * @param series
     * @param category
     * @see de.laures.cewolf.links.CategoryItemLinkGenerator#generateLink(java.lang.Object, int, java.lang.Object)
     */
    public String generateLink(Object data, int series, Object category) {
        return itemNames[series];
    }
    
	/**
	 * @see java.lang.Object#finalize()
	 */
	protected void finalize() throws Throwable {
		super.finalize();
		logger.debug(this + " finalized.");
	}
	
	/**
	 * @see de.laures.cewolf.tooltips.CategoryToolTipGenerator#generateToolTip(org.jfree.data.category.CategoryDataset, int, int)
	 */
	public String generateToolTip(CategoryDataset arg0, int series, int arg2) {
		return arg0.getColumnKey(arg2).toString() + ":" + arg0.getValue(series,arg2).toString();
	}
	
	/**
	 * Factory method which returns the String to represent the month.
	 * 
	 * @param dateString
	 * @return String
	 */
	private String getDisplayMonth(String dateString){
        SimpleDateFormat tmpDateFormat = new SimpleDateFormat("MM/dd/yyyy");
        String displayMonth;

        try {
        	Date date = tmpDateFormat.parse(dateString);

    		int month = DateUtil.getMonthOfYear(date);

    		switch (month){
    			case 0:
    				displayMonth = "JAN";
    				break;
    			case 1:
    				displayMonth = "FEB";
    				break;
    			case 2:
    				displayMonth = "MAR";
    				break;
    			case 3:
    				displayMonth = "APR";
    				break;
    			case 4:
    				displayMonth = "MAY";
    				break;
    			case 5:
    				displayMonth = "JUN";
    				break;
    			case 6:
    				displayMonth = "JUL";
    				break;
    			case 7:
    				displayMonth = "AUG";
    				break;
    			case 8:
    				displayMonth = "SEP";
    				break;
    			case 9:
    				displayMonth = "OCT";
    				break;
    			case 10:
    				displayMonth = "NOV";
    				break;
    			case 11:
    				displayMonth = "DEC";
    				break;
    			default:
    				displayMonth = "JAN";
    				break;
    		}

        } catch (ParseException e){
        	displayMonth = "ERR";
        }

		return displayMonth;
	}
}
