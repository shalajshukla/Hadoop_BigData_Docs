/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.admin.alert.rule;

/**
 * This is a Data Object to represent RABC_TRIG_CONVERT table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class TrigConvert {
	private String fileId;
	private String alertRule;
	private String procPgm;
	private int runChkDay;
	private int runChkHr;
	private String runFreqInd;

	/**
	 * @return Returns the FileId.
	 */
	public String getFileId() {
		return fileId;
	}
	/**
	 * @return Returns the AlertRule.
	 */
	public String getAlertRule() {
		return alertRule;
	}
	/**
	 * @return Returns the ProcPgm.
	 */
	public String getProcPgm() {
		return procPgm;
	}
	/**
	 * @return Returns the RunChkDay.
	 */
	public int getRunChkDay() {
		return runChkDay;
	}
	/**
	 * @return Returns the RunChkHr.
	 */
	public int getRunChkHr() {
		return runChkHr;
	}
	/**
	 * @return Returns the RunFreqInd.
	 */
	public String getRunFreqInd() {
		return runFreqInd;
	}

	/**
	 * @param FileId The fileId to set.
	 */
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	/**
	 * @param AlertRule The alertRule to set.
	 */
	public void setAlertRule(String alertRule) {
		this.alertRule = alertRule;
	}
	/**
	 * @param ProcPgm The procPgm to set.
	 */
	public void setProcPgm(String procPgm) {
		this.procPgm = procPgm;
	}
	/**
	 * @param RunChkDay The runChkDay to set.
	 */
	public void setRunChkDay(int runChkDay) {
		this.runChkDay = runChkDay;
	}
	/**
	 * @param RunChkHr The runChkHr to set.
	 */
	public void setRunChkHr(int runChkHr) {
		this.runChkHr = runChkHr;
	}
	/**
	 * @param RunFreqInd The runFreqInd to set.
	 */
	public void setRunFreqInd(String runFreqInd) {
		this.runFreqInd = runFreqInd;
	}
}
