/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.alerts.status;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.att.bac.rabc.ExtrctTblDef;

/**
 * This is a service class to provide the business logic. The methods in this class are called by the
 * action class. They do the required manipulation and returns the result to the action class. 
 * This paricular service class serves the business logic to generate percent graph.
 * 
 * @author Shailesh Hemdev - SH8512
 */
public class PercentGraphService extends GraphService {
	private static final String RABC_EXTRCT_SUMY_DATA = "RABC_EXTRCT_SUMY_DATA";
	private static final String RABC_CALC_ALERT_DATA = "RABC_CALC_ALERT_DATA";
	private static final String RABC_ALERT_HIST = "RABC_ALERT_HIST";
	
	private static final Logger logger = Logger.getLogger(PercentGraphService.class);
	private static PercentGraphService percentGraphService;
	
	/**
	 * Synchronized method to return the instance of PercentGraphService object.
	 * It checks the existance of the instance of PercentGraphService and if it does not exists
	 * then creates one instance of PercentGraphService and returns otherwise it returns the
	 * existing instance of PercentGraphService.
	 * 
	 * @return PercentGraphService
	 */
	public static synchronized PercentGraphService getPercentGraphService(){
		if (percentGraphService == null){
			percentGraphService = new PercentGraphService();
		}	
		return percentGraphService;
	}
	
	/**
	 * Method to return the title to be displayed on top of the percent graph page.
	 * 
	 * @param graphParameters
	 * @return String
	 * @see com.att.bac.rabc.alerts.status.GraphService#getTitle(com.att.bac.rabc.alerts.status.GraphParameters)
	 */
	protected String getTitle(GraphParameters graphParameters){
		String title = null;
		
		if (graphParameters.getAlertrule()!=null || (graphParameters.getTableName()!=null && (RABC_EXTRCT_SUMY_DATA.equals(graphParameters.getTableName().trim().toUpperCase()) || RABC_CALC_ALERT_DATA.equals(graphParameters.getTableName().trim().toUpperCase()) || RABC_ALERT_HIST.equals(graphParameters.getTableName().trim().toUpperCase())))){
			if (graphParameters.getAlertrule()!=null){
				title = "Alert Rule: " + graphParameters.getAlertrule() + " Percentage Graph";
			}else {
				title = "Percentage Graph";
			}
		}else {
			title = "Percentage Graph";
		}
		
		return title;
	}
	
	/**
	 * Method to return a string having the criterias selected to generate the percent graph.
	 * 
	 * @param graphParameters
	 * @param connection
	 * @param failureList
	 * @return String
	 */
	protected String getSelectionCriteria(GraphParameters graphParameters,Connection connection, List failureList,String region){
		String selectionCriteria = "";
		
		if (graphParameters.getStartDate()!=null){
			selectionCriteria = selectionCriteria + "Start Date:" + graphParameters.getStartDate().toString() + ",";
		}
		if (graphParameters.getProcDate()!=null){
			selectionCriteria = selectionCriteria + "End Date:" + graphParameters.getProcDate().toString()+"";
		}

		/*
		 * Get the key names
		 */
		List keyNameList = getKeyNames(connection, failureList, graphParameters);
		
		if (graphParameters.getKey1()!=null){
			if ( graphParameters.getKey1colname()!=null && graphParameters.getKey1colname().indexOf("=")==-1 ){
				if (!"".equals(graphParameters.getKey1colname())){
					String key1Value = graphParameters.getKey1();
					if (key1Value.indexOf("'")!=-1){
						key1Value = key1Value.substring((key1Value.indexOf("'")+1),key1Value.length()-1);
					}
					selectionCriteria = selectionCriteria + "," + graphParameters.getKey1colname() + " (Key 1):" + key1Value+ "";
				}else {
					String keyName = (String)keyNameList.get(0);
					if (!"".equals(keyName)){
						selectionCriteria = selectionCriteria + "," + keyName + " (Key 1):" + graphParameters.getKey1() + "";
					}else {
						selectionCriteria = selectionCriteria + ",Key 1: " + graphParameters.getKey1() + "";
					}
				}
			}else {
				String keyName = (String)keyNameList.get(0);
				if (!"".equals(keyName)){
					selectionCriteria = selectionCriteria + "," + keyName + " (Key 1):" + graphParameters.getKey1() + "";
				}else {
					selectionCriteria = selectionCriteria + ",Key 1: " + graphParameters.getKey1() + "";
				}
			}
		}
		
		if (graphParameters.getKey2()!=null){
			String tempKey2=graphParameters.getKey2();
			if (tempKey2.indexOf("=")!=-1){
				if (tempKey2.indexOf("to_date")!=-1) {
					tempKey2 = tempKey2.substring(0, tempKey2.indexOf(","));
				}
				int lenKey2complete = tempKey2.trim().length();
				String key2Field = tempKey2.substring(2,tempKey2.indexOf("="));
				String key2Value = tempKey2.substring((tempKey2.indexOf("=")+1),lenKey2complete);
				if (tempKey2.indexOf("'")!=-1){
					key2Value = tempKey2.substring((tempKey2.indexOf("'")+1),lenKey2complete-1);
				}
				selectionCriteria = selectionCriteria + "," + key2Field + " (Key 2):"+ key2Value + "";
			} else {
				String keyName = (String)keyNameList.get(1);
				if (!"".equals(keyName)){
					selectionCriteria = selectionCriteria + "," + keyName + " (Key 2):" + graphParameters.getKey2() + "";
				}else {
					selectionCriteria = selectionCriteria + ",Key 2: " + graphParameters.getKey2() + "";
				}
			}
		}
		if (graphParameters.getKey3()!=null){
			String tempKey3=graphParameters.getKey3();
			if (tempKey3.indexOf("=")!=-1){
				if (tempKey3.indexOf("to_date")!=-1) {
					tempKey3 = tempKey3.substring(0, tempKey3.indexOf(","));
				}
				int lenKey3complete = tempKey3.trim().length();
				String key3Field = tempKey3.substring(2,tempKey3.indexOf("="));
				String key3Value = tempKey3.substring((tempKey3.indexOf("=")+1),lenKey3complete);
				if (tempKey3.indexOf("'")!=-1){
					key3Value = tempKey3.substring((tempKey3.indexOf("'")+1),lenKey3complete-1);
				}
				selectionCriteria = selectionCriteria + "," + key3Field + " (Key 3):"+ key3Value + "";
			} else {
				String keyName = (String)keyNameList.get(2);
				if (!"".equals(keyName)){
					selectionCriteria = selectionCriteria + "," + keyName + " (Key 3):" + graphParameters.getKey3() + "";
				}else {
					selectionCriteria = selectionCriteria + ",Key 3: " + graphParameters.getKey3() + "";
				}
			}
		}
		if (graphParameters.getKey4()!=null){
			String tempKey4=graphParameters.getKey4();
			if (tempKey4.indexOf("=")!=-1){
				if (tempKey4.indexOf("to_date")!=-1) {
					tempKey4 = tempKey4.substring(0, tempKey4.indexOf(","));
				}
				int lenKey4complete = tempKey4.trim().length();
				String key4Field = tempKey4.substring(2,tempKey4.indexOf("="));
				String key4Value = tempKey4.substring((tempKey4.indexOf("=")+1),lenKey4complete);
				if (tempKey4.indexOf("'")!=-1){
					key4Value = tempKey4.substring((tempKey4.indexOf("'")+1),lenKey4complete-1);
				}
				selectionCriteria = selectionCriteria + "," + key4Field + " (Key 4):"+ key4Value + "";
			} else {
				String keyName = (String)keyNameList.get(3);
				if (!"".equals(keyName)){
					selectionCriteria = selectionCriteria + "," + keyName + " (Key 4):" + graphParameters.getKey4() + "";
				}else {
					selectionCriteria = selectionCriteria + ",Key 4: " + graphParameters.getKey4() + "";
				}
			}
		}
		if (graphParameters.getKey5()!=null){
			String tempKey5=graphParameters.getKey5();
			if (tempKey5.indexOf("=")!=-1){
				if (tempKey5.indexOf("to_date")!=-1) {
					tempKey5 = tempKey5.substring(0, tempKey5.indexOf(","));
				}
				int lenKey5complete = tempKey5.trim().length();
				String key5Field = tempKey5.substring(2,tempKey5.indexOf("="));
				String key5Value = tempKey5.substring((tempKey5.indexOf("=")+1),lenKey5complete);
				if (tempKey5.indexOf("'")!=-1){
					key5Value = tempKey5.substring((tempKey5.indexOf("'")+1),lenKey5complete-1);
				}
				selectionCriteria = selectionCriteria + "," + key5Field + " (Key 5):"+ key5Value + "";
			} else {
				String keyName = (String)keyNameList.get(4);
				if (!"".equals(keyName)){
					selectionCriteria = selectionCriteria + "," + keyName + " (Key 5):" + graphParameters.getKey5() + "";
				}else {
					selectionCriteria = selectionCriteria + ",Key 5: " + graphParameters.getKey5() + "";
				}
			}
		}

		if (graphParameters.getAlertItem()!=null && !"".equals(graphParameters.getAlertItem())){
			selectionCriteria = selectionCriteria + ",Alert Item: " + graphParameters.getAlertItem() + "";
		}
		
		if ("D".equals(graphParameters.getAlertTimeInd()) && isNumeric(graphParameters.getAlertTimeInd())){
			selectionCriteria = selectionCriteria + ", Week Day:   " + dayOfWeek(Integer.parseInt(graphParameters.getAlertTimeValue()));
		}else if ("B".equals(graphParameters.getAlertTimeInd())){
			if ("MW".equals(region)){
				selectionCriteria = selectionCriteria + ", Process Group:  " + graphParameters.getAlertTimeValue();
			}else {
				selectionCriteria = selectionCriteria + ", Bill Cycle:  " + graphParameters.getAlertTimeValue();
			}
		}
		
		return selectionCriteria;
	}
	
	/**
	 * Method to return the boolean value stating that whether the passed string is numeric or not.
	 * 
	 * @param str
	 * @return boolean
	 */
	private boolean isNumeric(String str){
		boolean result = false;
		
		try {
			int i = Integer.parseInt(str);
			result = true;
		}catch (NumberFormatException e){
			result = false;
		}
		
		return result;
	}
	
	/**
	 * Utility method to return the day of the week.
	 * 
	 * @param day
	 * @return String
	 */
	private String dayOfWeek(int day) {
		String dayOfWeek = "";
		
		switch (day){
			case 1:
				dayOfWeek = "Sunday";
				break;
			case 2:
				dayOfWeek = "Monday";
				break;
			case 3:
				dayOfWeek = "Tuesday";
				break;
			case 4:
				dayOfWeek = "Wednesday";
				break;
			case 5:
				dayOfWeek = "Thursday";
				break;
			case 6:
				dayOfWeek = "Friday";
				break;
			case 7:
				dayOfWeek = "Saturday";
				break;
		}
		
		return dayOfWeek;
	}
	
	/**
	 * Method to return the list of PercentGraphData objects and it is called from the action. 
	 * It builds the list of PercentGraphData. 
	 * The data would be obtained from the rabc_extrct_sumy_data table for which the 
	 * PercentGraphSQLService will be used.
	 * 
	 * @param graphParameters
	 * @param connection
	 * @param failureList
	 * @return List
	 */
	public List buildPercentGraph(GraphParameters graphParameters, Connection connection, List failureList){
		List percentGraphDataList = null;
		/*
		 * First call the super-class method to get the graphParameters object
		 */
		graphParameters = buildGraphParameters(graphParameters);
		
		/*
		 * Use the PercentGraphSQLService to perform the SQL queries
		 */
		PercentGraphSQLService percentGraphSQLService = new PercentGraphSQLService(graphParameters);

		List extrctTblDefList = percentGraphSQLService.getExtrctTblDefList(graphParameters,connection, failureList);
		if (extrctTblDefList!=null){
			if (!extrctTblDefList.isEmpty()){
				ExtrctTblDef extrctTblDef = (ExtrctTblDef)extrctTblDefList.get(0);
				
				List calcAlertDataList = percentGraphSQLService.getQryAlertData(connection, failureList);
				percentGraphDataList = new ArrayList();

				if (calcAlertDataList!=null){
					if (!calcAlertDataList.isEmpty()){
						int calcAlertDataListSize = calcAlertDataList.size();
						
						for (int i=0;i<calcAlertDataListSize;i++){
							CalcAlertData calcAlertData = (CalcAlertData)calcAlertDataList.get(i);
							PercentGraphData percentGraphData = getPercentGraphData(extrctTblDef,calcAlertData);

							if (percentGraphData!=null){
								int dataCnt = 0;

								/*
								 * Get the list of extrctSumyData objects
								 */
								int extrctDataCnt = extrctTblDef.getExtrctDataLeftCt() + 1;
								String itemString = "extrct_data" + extrctDataCnt;
								int totalCnt = extrctTblDef.getExtrctDataLeftCt() + extrctTblDef.getExtrctDataRightCt();
								int fromCnt = extrctDataCnt + 1;
								int percentageSize = totalCnt - extrctDataCnt + 1;
								double [] percentageArray = new double[percentageSize + 1];

								List extrctSumyDataList = percentGraphSQLService.getQrySumExtrData(connection, failureList,calcAlertData);
								if (extrctSumyDataList!=null){
									if (!extrctSumyDataList.isEmpty()){
										ExtrctSumyData extrctSumyData = (ExtrctSumyData) extrctSumyDataList.get(0);

										double totalSum = getTotal(extrctDataCnt,totalCnt, extrctSumyData);
										int counter = extrctDataCnt;
										for (int j=0;j<percentageSize;j++){
											double percentage = getPercentage(counter,totalSum,extrctSumyData);
											percentageArray[j] = percentage;
											counter = counter + 1;
										}
										percentageArray[percentageSize]= calcAlertData.getAlertData();	
									} // End of !extrctSumyDataList.isEmpty() condition
								} // End of extrctSumyDataList!=null condition
								
								percentGraphData.setPercentages(percentageArray);
								percentGraphDataList.add(percentGraphData);
							} // End of percentGraphData!=null condition
						} // End of loop for calcAlertData objects
					} // End of !calcAlertDataList.isEmpty() condition
				} // End of calcAlertDataList!=null condition
			}else {
				// end of extrctTblDefList.isEmpty() condition
				graphParameters.setError("Error : No data in table RABC_EXTRCT_TBL_DEF for parti_ref_id: " + graphParameters.getPartiRefId() + " and alert_item: " + graphParameters.getAlertItem());
			}
		} else {
			// End of extrctTblDefList!=null condition
			graphParameters.setError("Error : No data in table RABC_EXTRCT_TBL_DEF for parti_ref_id: " + graphParameters.getPartiRefId() + " and alert_item: " + graphParameters.getAlertItem());
		}
		
		return percentGraphDataList;
	}
	
	/**
	 * Method to build and return the PercentGraphData object.
	 * 
	 * @param extrctTblDef
	 * @param calcAlertData
	 * @return PercentGraphData
	 */
	private PercentGraphData getPercentGraphData(ExtrctTblDef extrctTblDef,CalcAlertData calcAlertData){
		PercentGraphData percentGraphData = new PercentGraphData();
		
		percentGraphData.setFileSeqNum(calcAlertData.getFileSeqNum());
		if (calcAlertData.getProcDate()!=null){
			percentGraphData.setProcDate(calcAlertData.getProcDate());
		}else {
			percentGraphData.setProcMonth(calcAlertData.getProcMonth());
		}

		int t_extrct_data_cnt = extrctTblDef.getExtrctDataLeftCt() + 1;
		String t_item_string = "extrct_data" + t_extrct_data_cnt;
		int t_total_cnt = extrctTblDef.getExtrctDataLeftCt() + extrctTblDef.getExtrctDataRightCt();
		int t_from_cnt = t_extrct_data_cnt + 1;
	
		int k=t_extrct_data_cnt;
		int size = t_total_cnt - t_extrct_data_cnt + 1;
		String [] t_extrct_data_name = new String[size + 1];
		for (int i=0;i<size;i++){
			switch (k){
				case 1:
					t_extrct_data_name[i]= extrctTblDef.getExtrctData1Name();
					break;
				case 2:
					t_extrct_data_name[i]= extrctTblDef.getExtrctData2Name();
					break;
				case 3:
					t_extrct_data_name[i]= extrctTblDef.getExtrctData3Name();
					break;	
				case 4:
					t_extrct_data_name[i]= extrctTblDef.getExtrctData4Name();
					break;
				case 5:
					t_extrct_data_name[i]= extrctTblDef.getExtrctData5Name();
					break;
				case 6:
					t_extrct_data_name[i]= extrctTblDef.getExtrctData6Name();
					break;
				case 7:
					t_extrct_data_name[i]= extrctTblDef.getExtrctData7Name();
					break;
				case 8:
					t_extrct_data_name[i]= extrctTblDef.getExtrctData8Name();
					break;
				case 9:
					t_extrct_data_name[i]= extrctTblDef.getExtrctData9Name();
					break;
				case 10:
					t_extrct_data_name[i]= extrctTblDef.getExtrctData10Name();
					break;
				case 11:
					t_extrct_data_name[i]= extrctTblDef.getExtrctData11Name();
					break;
				case 12:
					t_extrct_data_name[i]= extrctTblDef.getExtrctData12Name();
					break;
				case 13:
					t_extrct_data_name[i]= extrctTblDef.getExtrctData13Name();
					break;
				case 14:
					t_extrct_data_name[i]= extrctTblDef.getExtrctData14Name();
					break;
				case 15:
					t_extrct_data_name[i]= extrctTblDef.getExtrctData15Name();
					break;
				default:
					t_extrct_data_name[i]= extrctTblDef.getExtrctData1Name();
					break;
			}
			k = k + 1;
		}
		
		t_extrct_data_name[size] = "Total";
		percentGraphData.setItemNames(t_extrct_data_name);

		return percentGraphData;
	}
	
	/**
	 * Method to return the total of extrctData values.
	 * 
	 * @param extrctDataCnt
	 * @param totalCnt
	 * @param extrctSumyData
	 * @return double
	 */
	private double getTotal(int extrctDataCnt, int totalCnt, ExtrctSumyData extrctSumyData){
		double totalSum = 0;
		
		for (int i=extrctDataCnt;i<=totalCnt;i++){
			switch (i){
				case 1:
					totalSum = totalSum + extrctSumyData.getExtrctData1();
					break;
				case 2:
					totalSum = totalSum + extrctSumyData.getExtrctData2();
					break;
				case 3:
					totalSum = totalSum + extrctSumyData.getExtrctData3();
					break;
				case 4:
					totalSum = totalSum + extrctSumyData.getExtrctData4();
					break;
				case 5:
					totalSum = totalSum + extrctSumyData.getExtrctData5();
					break;
				case 6:
					totalSum = totalSum + extrctSumyData.getExtrctData6();
					break;
				case 7:
					totalSum = totalSum + extrctSumyData.getExtrctData7();
					break;
				case 8:
					totalSum = totalSum + extrctSumyData.getExtrctData8();
					break;
				case 9:
					totalSum = totalSum + extrctSumyData.getExtrctData9();
					break;
				case 10:
					totalSum = totalSum + extrctSumyData.getExtrctData10();
					break;
				case 11:
					totalSum = totalSum + extrctSumyData.getExtrctData11();
					break;
				case 12:
					totalSum = totalSum + extrctSumyData.getExtrctData12();
					break;
				case 13:
					totalSum = totalSum + extrctSumyData.getExtrctData13();
					break;
				case 14:
					totalSum = totalSum + extrctSumyData.getExtrctData14();
					break;
				case 15:
					totalSum = totalSum + extrctSumyData.getExtrctData15();
					break;
				default:
					totalSum = totalSum + extrctSumyData.getExtrctData1();
					break;
			}
		}
		
		return totalSum;
	}
	
	/**
	 * Method to return the percentage for every extrctData value.
	 * 
	 * @param fieldCounter
	 * @param totalSum
	 * @param extrctSumyData
	 * @return double
	 */
	private double getPercentage(int fieldCounter, double totalSum, ExtrctSumyData extrctSumyData){
		double percentage = 0;
		
		switch (fieldCounter){
		case 1:
			percentage = (extrctSumyData.getExtrctData1()/totalSum) * 100;
			break;
		case 2:
			percentage = (extrctSumyData.getExtrctData2()/totalSum) * 100;
			break;
		case 3:
			percentage = (extrctSumyData.getExtrctData3()/totalSum) * 100;
			break;
		case 4:
			percentage = (extrctSumyData.getExtrctData4()/totalSum) * 100;
			break;
		case 5:
			percentage = (extrctSumyData.getExtrctData5()/totalSum) * 100;
			break;
		case 6:
			percentage = (extrctSumyData.getExtrctData6()/totalSum) * 100;
			break;
		case 7:
			percentage = (extrctSumyData.getExtrctData7()/totalSum) * 100;
			break;
		case 8:
			percentage = (extrctSumyData.getExtrctData8()/totalSum) * 100;
			break;
		case 9:
			percentage = (extrctSumyData.getExtrctData9()/totalSum) * 100;
			break;
		case 10:
			percentage = (extrctSumyData.getExtrctData10()/totalSum) * 100;
			break;
		case 11:
			percentage = (extrctSumyData.getExtrctData11()/totalSum) * 100;
			break;
		case 12:
			percentage = (extrctSumyData.getExtrctData12()/totalSum) * 100;
			break;
		case 13:
			percentage = (extrctSumyData.getExtrctData13()/totalSum) * 100;
			break;
		case 14:
			percentage = (extrctSumyData.getExtrctData14()/totalSum) * 100;
			break;
		case 15:
			percentage = (extrctSumyData.getExtrctData15()/totalSum) * 100;
			break;
		default:
			percentage = (extrctSumyData.getExtrctData1()/totalSum) * 100;
			break;
		}
		
		return percentage;
	}
}
