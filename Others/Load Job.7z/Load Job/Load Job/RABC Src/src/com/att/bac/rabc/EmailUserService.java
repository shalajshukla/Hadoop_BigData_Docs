/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.att.bac.rabc.admin.AlertGroupDAO;
import com.att.bac.rabc.alerts.status.RootCategory;

/**
 * This is a service class to provide the business logic. The methods in this class are called by the
 * action class. They internaly calls the DAO classes to do the required manipulation and returns the 
 * result to the action class. This paricular service class serves the business logic to populate the
 * email user's selection page and to send email.
 * 
 * @author Vijay Dubey - VD3159
 */
public class EmailUserService {
	private static final Logger logger = Logger.getLogger(EmailUserService.class);
	private static EmailUserService emailUserService;
	
	private final String getGroupList = "SELECT distinct alert_grp, "
		+ "alert_grp_desc, funct_cd, pnt_alert_grp_ind  "
		+ "FROM RABC_ALERT_GRP "
		+ "ORDER BY UPPER(ALERT_GRP)";
	
	private final String getUserGroupList = "select distinct BAGU.user_id user_id, "
		+ "BAGU.alert_grp alert_grp, "
		+ "upper(BUSER.user_name) user_name "
		+ "from	rabc_alert_grp_user BAGU, rabc_user BUSER " 
		+ "where BAGU.user_id = BUSER.user_id "
		+ "and BAGU.alert_grp = ''{0}''";
	
	/**
	 * Synchronized method to return the instance of EmailUserService object.
	 * It checks the existance of the instance of EmailUserService and if it does not exists
	 * then creates one instance of EmailUserService and returns otherwise it returns the
	 * existing instance of EmailUserService.
	 * 
	 * @return EmailUserService
	 */
	public static EmailUserService getEmailUserService(){
		if (emailUserService == null) {
			emailUserService = new EmailUserService();
		}
		return emailUserService;
	}
	
	/**
	 * Method to return the list of Alert Groups.
	 * It calls the AlertGroupDAO class to get the list of Alert Groups.
	 * 
	 * @param connection
	 * @param failureList
	 * @return List
	 */
	public List getAlertGroupList(Connection connection, List failureList) {
		List alertGroupList = new ArrayList();
		RootCategory rootCategory = null;
		List args = new ArrayList();
		
		alertGroupList = new AlertGroupDAO().get(connection, failureList, args, getGroupList);
		if (!failureList.isEmpty()) {
			return null;
		}
		
		return alertGroupList;
	}
	
	/**
	 * Method to return the list of Alert Users.
	 * 
	 * @param connection
	 * @param failureList
	 * @param alertGroup
	 * @return List
	 */
	public List getAlertUserList(Connection connection, List failureList, String alertGroup) {
		List alertUserList = new ArrayList();
		List args = new ArrayList();
		if (alertGroup == null) {
			args.add("");
		} else {
			args.add(alertGroup);
		}
		
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		try{
			MessageFormat mf = new MessageFormat(getUserGroupList);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("To get Alert User List - Executing SQL statement: "+ prepareStatement);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			if (rs != null) {
				while(rs.next()) {
					alertUserList.add(new PickList(rs.getString(1),rs.getString(2),rs.getString(3)));
				}
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
			return null;
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		return alertUserList;
	}
}
