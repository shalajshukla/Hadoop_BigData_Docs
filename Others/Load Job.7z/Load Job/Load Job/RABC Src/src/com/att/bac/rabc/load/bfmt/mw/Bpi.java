/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.load.bfmt.mw;

import java.util.Date;

import com.sbc.bac.rabc.load.HashCodeUtil;

/**
 * This is a class representing entries in RABC_BPI_BLG_SUMY table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class Bpi {
	private Date runDate;
	private String division;
	private int billRound;
	private String busType;
	private String EBATInd;
	private long bpiAcctCtDb;
	private double bpiBlgAmtDb;
	private long bpiAcctCtCr;
	private double bpiBlgAmtCr;
	
	/**
	 * @return Returns the billRound.
	 */
	public int getBillRound() {
		return billRound;
	}
	/**
	 * @param billRound The billRound to set.
	 */
	public void setBillRound(int billRound) {
		this.billRound = billRound;
	}
	/**
	 * @return Returns the bpiAcctCtCr.
	 */
	public long getBpiAcctCtCr() {
		return bpiAcctCtCr;
	}
	/**
	 * @param bpiAcctCtCr The bpiAcctCtCr to set.
	 */
	public void setBpiAcctCtCr(long bpiAcctCtCr) {
		this.bpiAcctCtCr = bpiAcctCtCr;
	}
	/**
	 * @return Returns the bpiAcctCtDb.
	 */
	public long getBpiAcctCtDb() {
		return bpiAcctCtDb;
	}
	/**
	 * @param bpiAcctCtDb The bpiAcctCtDb to set.
	 */
	public void setBpiAcctCtDb(long bpiAcctCtDb) {
		this.bpiAcctCtDb = bpiAcctCtDb;
	}
	/**
	 * @return Returns the bpiBlgAmtCr.
	 */
	public double getBpiBlgAmtCr() {
		return bpiBlgAmtCr;
	}
	/**
	 * @param bpiBlgAmtCr The bpiBlgAmtCr to set.
	 */
	public void setBpiBlgAmtCr(double bpiBlgAmtCr) {
		this.bpiBlgAmtCr = bpiBlgAmtCr;
	}
	/**
	 * @return Returns the bpiBlgAmtDb.
	 */
	public double getBpiBlgAmtDb() {
		return bpiBlgAmtDb;
	}
	/**
	 * @param bpiBlgAmtDb The bpiBlgAmtDb to set.
	 */
	public void setBpiBlgAmtDb(double bpiBlgAmtDb) {
		this.bpiBlgAmtDb = bpiBlgAmtDb;
	}
	/**
	 * @return Returns the busType.
	 */
	public String getBusType() {
		return busType;
	}
	/**
	 * @param busType The busType to set.
	 */
	public void setBusType(String busType) {
		this.busType = busType;
	}
	/**
	 * @return Returns the EBATInd.
	 */
	public String getEBATInd() {
		return EBATInd;
	}
	/**
	 * @param EBATInd The EBATInd to set.
	 */
	public void setEBATInd(String EBATInd) {
		this.EBATInd = EBATInd;
	}
	/**
	 * @return Returns the division.
	 */
	public String getDivision() {
		return division;
	}
	/**
	 * @param division The division to set.
	 */
	public void setDivision(String division) {
		this.division = division;
	}
	/**
	 * @return Returns the runDate.
	 */
	public Date getRunDate() {
		return runDate;
	}
	/**
	 * @param runDate The runDate to set.
	 */
	public void setRunDate(Date runDate) {
		this.runDate = runDate;
	}
	
	/**
	 * Equals method overridden for this object so that it can be stored in a hash map where the key 
	 * would be combination of the following 4 attributes:
	 * Run date
	 * Division
	 * Bill Round
	 * Customer type
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object o) {
		// Do a quick check for an identical object reference
	    if (this == o) {
	      return true;
	    }
	    if (!(o instanceof Bpi)) {
	    	return false;
	    } else {
			if (((Bpi)o).getRunDate().getTime() == this.getRunDate().getTime()
				&& ((Bpi)o).getDivision().equalsIgnoreCase(this.getDivision())
				&& ((Bpi)o).getBillRound()== this.getBillRound()
				&& ((Bpi)o).getBusType().equalsIgnoreCase(this.getBusType())
				&& ((Bpi)o).getEBATInd().equalsIgnoreCase(this.getEBATInd())
				) {
				return true;
			} else {
				return false;
			}
	    }
	}
	
	/**
	 * Hash code method overridden for this object to categorize this object in sets 
	 * so that the hash collections can search this object efficiently.
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		int hashCode = HashCodeUtil.SEED;
		hashCode = HashCodeUtil.hash( hashCode, this.getBusType());
		hashCode = HashCodeUtil.hash( hashCode, this.getEBATInd());
	    return hashCode;
	}
}
