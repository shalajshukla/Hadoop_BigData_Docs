/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.load.occ.mw;

import java.util.Date;

import com.sbc.bac.rabc.load.HashCodeUtil;

/**
 * This is a data object representing entries in RABC_BILLDAY_OCC_ACTVT table.
 * 
 * @author Sonali Uttarwar - SU3643
 */
public class BillDayOccActvt {
	private Date runDate;
	private String division;
	private String billRnd;
	private String busType;
	private String occPhraseCd;
	private long occCt;
	private double occAmt;
		
	/**
	 * @return Returns the occPhraseCd.
	 */
	public String getOccPhraseCd() {
		return occPhraseCd;
	}
	/**
	 * @param occPhraseCd The occPhraseCd to set.
	 */
	public void setOccPhraseCd(String occPhraseCd) {
		this.occPhraseCd = occPhraseCd;
	}
	/**
	 * @return Returns the division.
	 */
	public String getDivision() {
		return division;
	}
	/**
	 * @param division The division to set.
	 */
	public void setDivision(String division) {
		this.division = division;
	}
	/**
	 * @return Returns the billRnd.
	 */
	public String getBillRnd() {
		return billRnd;
	}
	/**
	 * @param billRnd The billRnd to set.
	 */
	public void setBillRnd(String billRnd) {
		this.billRnd = billRnd;
	}
	/**
	 * @return Returns the busType.
	 */
	public String getBusType() {
		return busType;
	}
	/**
	 * @param busType The busType to set.
	 */
	public void setBusType(String busType) {
		this.busType = busType;
	}
	/**
	 * @return Returns the runDate.
	 */
	public Date getRunDate() {
		return runDate;
	}
	/**
	 * @param runDate The runDate to set.
	 */
	public void setRunDate(Date runDate) {
		this.runDate = runDate;
	}
	/**
	 * @return Returns the occAmt.
	 */
	public double getOccAmt() {
		return occAmt;
	}
	/**
	 * @param occAmt The occAmt to set.
	 */
	public void setOccAmt(double occAmt) {
		this.occAmt = occAmt;
	}
	/**
	 * @return Returns the occCt.
	 */
	public long getOccCt() {
		return occCt;
	}
	/**
	 * @param occCt The occCt to set.
	 */
	public void setOccCt(long occCt) {
		this.occCt = occCt;
	}
	
	/**
	 * Equals method overridden for this object so that it can be stored in a hash map where the key 
	 * would be combination of the following 5 attributes:
	 * Run date
	 * Division
	 * Bill round
	 * Business type
	 * OCC phrase code
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object o) {
		// Do a quick check for an identical object reference
	    if (this == o) {
	      return true;
	    }
	    if (!(o instanceof BillDayOccActvt)) {
	    	return false;
	    } else {
			if (((BillDayOccActvt)o).getRunDate().getTime() == this.getRunDate().getTime()
				&& ((BillDayOccActvt)o).getDivision().equalsIgnoreCase(this.getDivision())
				&& ((BillDayOccActvt)o).getBillRnd().equalsIgnoreCase(this.getBillRnd())	
				&& ((BillDayOccActvt)o).getBusType().equalsIgnoreCase(this.getBusType())
				&& ((BillDayOccActvt)o).getOccPhraseCd().equalsIgnoreCase(this.getOccPhraseCd())
				) {
				return true;
			} else {
				return false;
			}
	    }
	}
	
	/**
	 * Hash code method overridden for this object to categorize this object in sets 
	 * so that the hash collections can search this object efficiently.
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		int hashCode = HashCodeUtil.SEED;
		hashCode = HashCodeUtil.hash( hashCode, this.getBusType());
		hashCode = HashCodeUtil.hash( hashCode, this.getOccPhraseCd());
	    return hashCode;
	}
}
