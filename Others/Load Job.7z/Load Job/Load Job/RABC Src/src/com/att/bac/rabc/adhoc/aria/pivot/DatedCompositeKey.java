/*
 * Copyright  2002-2006 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.adhoc.aria.pivot;

import java.util.Date;


/**
 * Description of class
 * 
 * <p>
 * <hr>
 * <h3>Release History</h3>
 * <p>
 * <ul>
 * 
 * <li>jb6494 Nov 30, 2006 Created class.
 * 
 * </ul>
 * <p>
 * 
 */
public class DatedCompositeKey extends CompositeKey {

    private Date date;


    /**
     * Constructor
     */
    public DatedCompositeKey(Date date) {
        super();
        setDate(date);
    }
    
    /**
     * Creates a cloned object. The key data is not cloned, but the date is.
     * 
     * @see java.lang.Object#clone()
     */
    public DatedCompositeKey createClone() {
        DatedCompositeKey temp = new DatedCompositeKey(new Date(getDate().getTime()));
        temp.setNumKeys(this.getNumKeys()) ;
        for (int i = 0; i < keys.size(); i++) {
            temp.addKey(getKey(i));
        }
        return temp;
    }


    /*
     * (non-Javadoc)
     * 
     * @see com.att.bac.rabc.adhoc.aria.pivot.CompositeKey#equals(java.lang.Object)
     */
    public boolean equals(Object obj) {
        boolean b = super.equals(obj);
        b &= obj instanceof DatedCompositeKey;
        if (b) {
            b &= ((DatedCompositeKey) obj).getDate().equals(getDate());
        }
        return b;
    }


    /**
     * @return Returns the date.
     */
    public Date getDate() {
        return date;
    }


    /**
     * @param date
     */
    public void setDate(Date date) {
        this.date = date;
    }


    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    public int hashCode() {
        return date.hashCode();
    }


    /* (non-Javadoc)
     * @see com.att.bac.rabc.adhoc.aria.pivot.CompositeKey#toString()
     */
    public String toString() {
        StringBuffer buf = new StringBuffer(100);
        buf.append(super.toString());
        buf.append(", d=");
        buf.append(date);

        return buf.toString();
    }
}
