/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.admin;

/**
 * This is a Data Object to represent RABC_ALERT_GRP table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class AlertGroup {
	private String alertGrp;
	private String alertGrpDesc;
	private String functionCd;
	private String pntAlertGrpInd;

	/**
	 * @return Returns the AlertGrp.
	 */
	public String getAlertGrp() {
		return alertGrp;
	}
	/**
	 * @param AlertGrp The alertGrp to set.
	 */
	public void setAlertGrp(String alertGrp) {
		this.alertGrp = alertGrp;
	}
	/**
	 * @return Returns the alertGrpDesc.
	 */
	public String getAlertGrpDesc() {
		return alertGrpDesc;
	}
	/**
	 * @param alertGrpDesc The alertGrpDesc to set.
	 */
	public void setAlertGrpDesc(String alertGrpDesc) {
		this.alertGrpDesc = alertGrpDesc;
	}
	/**
	 * @return Returns the functionCd.
	 */
	public String getFunctionCd() {
		return functionCd;
	}
	/**
	 * @param functionCd The functionCd to set.
	 */
	public void setFunctionCd(String functionCd) {
		this.functionCd = functionCd;
	}
	/**
	 * @return Returns the pntAlertGrpInd.
	 */
	public String getPntAlertGrpInd() {
		return pntAlertGrpInd;
	}
	/**
	 * @param pntAlertGrpInd The pntAlertGrpInd to set.
	 */
	public void setPntAlertGrpInd(String pntAlertGrpInd) {
		this.pntAlertGrpInd = pntAlertGrpInd;
	}
}
