/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.rpt;

/**
 * This is a Data Object to represent RABC_ALERT_RULE_PRESN_RULE table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class AlertRulePresenRule {
	private String alertDataLinkInd;
	private int alertDataLinkNum;
	private String alertParmInd;
	private String alertDescInd;
	private int alertMouseOverNum;
	private int presnId;
	private String webid;
	private int execPresnSeqNum;
	private String fileSeqNumInd;
	private String presnDataTbl;
	private int dataKeyLvl;
	private String mainKey1Ind;

	private String[] keyDdlName = {"","","","",""};
	private String[] keyHeader = {"","","","",""};
	private String[] keyHdLinkInd = {"","","","",""};
	private int[] keyHdLinkNum = {-1,-1,-1,-1,-1};
	private String[] keyHdParmInd = {"","","","",""};
	private String[] keyDataLinkInd = {"","","","",""};
	private int[] keyDataLinkNum = {-1,-1,-1,-1,-1};
	private String[] keyParmInd = {"","","","",""};
	private String[] keyDescInd = {"","","","",""};
	private int[] keyMouseOverNum = {-1,-1,-1,-1,-1};

	private String alertDataName;
	private String alertHdName;
	private String alertHdLinkInd;
	private int alertHdLinkNum;
	private String alertHdParmInd;

	/**
	 * @return Returns the AlertDataLinkInd.
	 */
	public String getAlertDataLinkInd() {
		return alertDataLinkInd;
	}
	/**
	 * @return Returns the AlertDataLinkNum.
	 */
	public int getAlertDataLinkNum() {
		return alertDataLinkNum;
	}
	/**
	 * @return Returns the AlertParmInd.
	 */
	public String getAlertParmInd() {
		return alertParmInd;
	}
	/**
	 * @return Returns the AlertDescInd.
	 */
	public String getAlertDescInd() {
		return alertDescInd;
	}
	/**
	 * @return Returns the AlertMouseOverNum.
	 */
	public int getAlertMouseOverNum() {
		return alertMouseOverNum;
	}
	/**
	 * @return Returns the PresnId.
	 */
	public int getPresnId() {
		return presnId;
	}
	/**
	 * @return Returns the Webid.
	 */
	public String getWebid() {
		return webid;
	}
	/**
	 * @return Returns the ExecPresnSeqNum.
	 */
	public int getExecPresnSeqNum() {
		return execPresnSeqNum;
	}
	/**
	 * @return Returns the FileSeqNumInd.
	 */
	public String getFileSeqNumInd() {
		return fileSeqNumInd;
	}
	/**
	 * @return Returns the PresnDataTbl.
	 */
	public String getPresnDataTbl() {
		return presnDataTbl;
	}
	/**
	 * @return Returns the DataKeyLvl.
	 */
	public int getDataKeyLvl() {
		return dataKeyLvl;
	}
	/**
	 * @return Returns the Key1DdlName.
	 */
	public String getKeyDdlNameAt(int i) {
		return keyDdlName[i];
	}
	/**
	 * @return Returns the MainKey1Ind.
	 */
	public String getMainKey1Ind() {
		return mainKey1Ind;
	}
	/**
	 * @return Returns the AlertDataName.
	 */
	public String getAlertDataName() {
		return alertDataName;
	}
	/**
	 * @return Returns the AlertHdName.
	 */
	public String getAlertHdName() {
		return alertHdName;
	}
	/**
	 * @return Returns the AlertHdLinkInd.
	 */
	public String getAlertHdLinkInd() {
		return alertHdLinkInd;
	}
	/**
	 * @return Returns the AlertHdLinkNum.
	 */
	public int getAlertHdLinkNum() {
		return alertHdLinkNum;
	}
	/**
	 * @return Returns the AlertHdParmInd.
	 */
	public String getAlertHdParmInd() {
		return alertHdParmInd;
	}

	/**
	 * @param AlertDataLinkInd The alertDataLinkInd to set.
	 */
	public void setAlertDataLinkInd(String alertDataLinkInd) {
		this.alertDataLinkInd = alertDataLinkInd;
	}
	/**
	 * @param AlertDataLinkNum The alertDataLinkNum to set.
	 */
	public void setAlertDataLinkNum(int alertDataLinkNum) {
		this.alertDataLinkNum = alertDataLinkNum;
	}
	/**
	 * @param AlertParmInd The alertParmInd to set.
	 */
	public void setAlertParmInd(String alertParmInd) {
		this.alertParmInd = alertParmInd;
	}
	/**
	 * @param AlertDescInd The alertDescInd to set.
	 */
	public void setAlertDescInd(String alertDescInd) {
		this.alertDescInd = alertDescInd;
	}
	/**
	 * @param AlertMouseOverNum The alertMouseOverNum to set.
	 */
	public void setAlertMouseOverNum(int alertMouseOverNum) {
		this.alertMouseOverNum = alertMouseOverNum;
	}
	/**
	 * @param PresnId The presnId to set.
	 */
	public void setPresnId(int presnId) {
		this.presnId = presnId;
	}
	/**
	 * @param Webid The webid to set.
	 */
	public void setWebid(String webid) {
		this.webid = webid;
	}
	/**
	 * @param ExecPresnSeqNum The execPresnSeqNum to set.
	 */
	public void setExecPresnSeqNum(int execPresnSeqNum) {
		this.execPresnSeqNum = execPresnSeqNum;
	}
	/**
	 * @param FileSeqNumInd The fileSeqNumInd to set.
	 */
	public void setFileSeqNumInd(String fileSeqNumInd) {
		this.fileSeqNumInd = fileSeqNumInd;
	}
	/**
	 * @param PresnDataTbl The presnDataTbl to set.
	 */
	public void setPresnDataTbl(String presnDataTbl) {
		this.presnDataTbl = presnDataTbl;
	}
	/**
	 * @param DataKeyLvl The dataKeyLvl to set.
	 */
	public void setDataKeyLvl(int dataKeyLvl) {
		this.dataKeyLvl = dataKeyLvl;
	}
	/**
	 * @param Key1DdlName The key1DdlName to set.
	 */
	public void setKeyDdlNameAt(int i, String keyDdlName) {
		this.keyDdlName[i] = keyDdlName;
	}
	/**
	 * @param MainKey1Ind The mainKey1Ind to set.
	 */
	public void setMainKey1Ind(String mainKey1Ind) {
		this.mainKey1Ind = mainKey1Ind;
	}
	/**
	 * @param AlertDataName The alertDataName to set.
	 */
	public void setAlertDataName(String alertDataName) {
		this.alertDataName = alertDataName;
	}
	/**
	 * @param AlertHdName The alertHdName to set.
	 */
	public void setAlertHdName(String alertHdName) {
		this.alertHdName = alertHdName;
	}
	/**
	 * @param AlertHdLinkInd The alertHdLinkInd to set.
	 */
	public void setAlertHdLinkInd(String alertHdLinkInd) {
		this.alertHdLinkInd = alertHdLinkInd;
	}
	/**
	 * @param AlertHdLinkNum The alertHdLinkNum to set.
	 */
	public void setAlertHdLinkNum(int alertHdLinkNum) {
		this.alertHdLinkNum = alertHdLinkNum;
	}
	/**
	 * @param AlertHdParmInd The alertHdParmInd to set.
	 */
	public void setAlertHdParmInd(String alertHdParmInd) {
		this.alertHdParmInd = alertHdParmInd;
	}
	/**
	 * @return Returns the Key1Header.
	 */
	public String getKeyHeaderAt(int i) {
		return this.keyHeader[i];
	}
	/**
	 * @return Returns the Key1HdLinkInd.
	 */
	public String getKeyHdLinkIndAt(int i) {
		return this.keyHdLinkInd[i];
	}
	/**
	 * @return Returns the Key1HdLinkNum.
	 */
	public int getKeyHdLinkNumAt(int i) {
		return this.keyHdLinkNum[i];
	}
	/**
	 * @return Returns the Key1HdParmInd.
	 */
	public String getKeyHdParmIndAt(int i) {
		return this.keyHdParmInd[i];
	}
	/**
	 * @return Returns the Key1DataLinkInd.
	 */
	public String getKeyDataLinkIndAt(int i) {
		return this.keyDataLinkInd[i];
	}
	/**
	 * @return Returns the Key1DataLinkNum.
	 */
	public int getKeyDataLinkNumAt(int i) {
		return this.keyDataLinkNum[i];
	}
	/**
	 * @return Returns the Key1ParmInd.
	 */
	public String getKeyParmIndAt(int i) {
		return this.keyParmInd[i];
	}
	/**
	 * @return Returns the Key1DescInd.
	 */
	public String getKeyDescIndAt(int i) {
		return this.keyDescInd[i];
	}
	/**
	 * @return Returns the Key1MouseOverNum.
	 */
	public int getKeyMouseOverNumAt(int i) {
		return this.keyMouseOverNum[i];
	}
	/**
	 * @param Key1Header The key1Header to set.
	 */
	public void setKeyHeaderAt(int i, String key1Header) {
		this.keyHeader[i] = key1Header;
	}
	/**
	 * @param Key1HdLinkInd The key1HdLinkInd to set.
	 */
	public void setKeyHdLinkIndAt(int i, String key1HdLinkInd) {
		this.keyHdLinkInd[i] = key1HdLinkInd;
	}
	/**
	 * @param Key1HdLinkNum The key1HdLinkNum to set.
	 */
	public void setKeyHdLinkNumAt(int i, int key1HdLinkNum) {
		this.keyHdLinkNum[i] = key1HdLinkNum;
	}
	/**
	 * @param Key1HdParmInd The key1HdParmInd to set.
	 */
	public void setKeyHdParmIndAt(int i, String key1HdParmInd) {
		this.keyHdParmInd[i] = key1HdParmInd;
	}
	/**
	 * @param Key1DataLinkInd The key1DataLinkInd to set.
	 */
	public void setKeyDataLinkIndAt(int i, String key1DataLinkInd) {
		this.keyDataLinkInd[i] = key1DataLinkInd;
	}
	/**
	 * @param Key1DataLinkNum The key1DataLinkNum to set.
	 */
	public void setKeyDataLinkNumAt(int i, int key1DataLinkNum) {
		this.keyDataLinkNum[i] = key1DataLinkNum;
	}
	/**
	 * @param Key1ParmInd The key1ParmInd to set.
	 */
	public void setKeyParmIndAt(int i, String key1ParmInd) {
		this.keyParmInd[i] = key1ParmInd;
	}
	/**
	 * @param Key1DescInd The key1DescInd to set.
	 */
	public void setKeyDescIndAt(int i, String key1DescInd) {
		this.keyDescInd[i] = key1DescInd;
	}
	/**
	 * @param Key1MouseOverNum The key1MouseOverNum to set.
	 */
	public void setKeyMouseOverNumAt(int i, int key1MouseOverNum) {
		this.keyMouseOverNum[i] = key1MouseOverNum;
	}	
}
