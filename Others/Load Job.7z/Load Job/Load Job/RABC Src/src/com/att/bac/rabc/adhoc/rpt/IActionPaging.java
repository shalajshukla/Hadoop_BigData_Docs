/*
 * Copyright  2002-2006 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.adhoc.rpt;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;


/**
 * Description of class
 * 
 * <p>
 * <hr>
 * <h3>Release History</h3>
 * <p>
 * <ul>
 * 
 * <li>jb6494 Aug 16, 2006 Created class.
 * 
 * </ul>
 * <p>
 * 
 */
public interface IActionPaging {

    /**
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return
     * @throws IOException
     * @throws ServletException
     */
    ActionForward first(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response);


    /**
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return
     * @throws IOException
     * @throws ServletException
     */
    ActionForward last(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response);


    /**
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return
     * @throws IOException
     * @throws ServletException
     */
    ActionForward previous(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response);


    /**
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return
     * @throws IOException
     * @throws ServletException
     */
    ActionForward next(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response);


    /**
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return
     * @throws IOException
     * @throws ServletException
     */
    ActionForward gotoPage(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response);

}