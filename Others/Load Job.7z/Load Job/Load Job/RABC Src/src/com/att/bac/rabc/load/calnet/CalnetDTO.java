/* Created by Peter Foo (pf7941) on Dec 8, 2006.
Copyright 2006-2008 AT&T Knowledge Ventures. All rights reserved. */

package com.att.bac.rabc.load.calnet;

/**
 * An abstract class for CALNET-2 Load Job data transfer objects.
 * @author pf7941
 *
 */
public abstract class CalnetDTO {

}
