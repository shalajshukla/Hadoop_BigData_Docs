/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.dashboard;

/**
 * This class represents the data object that holds the attributes required
 * to represent the AlertRule Investigations. 
 * 
 * @author Sandhya Chinala - SC3837
 */
public class AlertRuleInvestigations {
	private String certificationDate;
	private String division;
	private double revenueImpact;
	private double credit;
	private double debit;
	private double unrecoverableRevenue;
	private String status;
	
		
	/**
	 * @return Returns the certificationDate.
	 */
	public String getCertificationDate() {
		return certificationDate;
	}
	/**
	 * @param certificationDate The certificationDate to set.
	 */
	public void setCertificationDate(String certificationDate) {
		this.certificationDate = certificationDate;
	}
	/**
	 * @return Returns the credit.
	 */
	public double getCredit() {
		return credit;
	}
	/**
	 * @param credit The credit to set.
	 */
	public void setCredit(double credit) {
		this.credit = credit;
	}
	/**
	 * @return Returns the debit.
	 */
	public double getDebit() {
		return debit;
	}
	/**
	 * @param debit The debit to set.
	 */
	public void setDebit(double debit) {
		this.debit = debit;
	}
	/**
	 * @return Returns the division.
	 */
	public String getDivision() {
		return division;
	}
	/**
	 * @param division The division to set.
	 */
	public void setDivision(String division) {
		this.division = division;
	}
	/**
	 * @return Returns the revenueImpact.
	 */
	public double getRevenueImpact() {
		return revenueImpact;
	}
	/**
	 * @param revenueImpact The revenueImpact to set.
	 */
	public void setRevenueImpact(double revenueImpact) {
		this.revenueImpact = revenueImpact;
	}
	/**
	 * @return Returns the status.
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status The status to set.
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return Returns the unrecoverableRevenue.
	 */
	public double getUnrecoverableRevenue() {
		return unrecoverableRevenue;
	}
	/**
	 * @param unrecoverableRevenue The unrecoverableRevenue to set.
	 */
	public void setUnrecoverableRevenue(double unrecoverableRevenue) {
		this.unrecoverableRevenue = unrecoverableRevenue;
	}
}
