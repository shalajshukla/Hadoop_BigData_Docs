/**
 * 
 */
package com.sbc.bac.rabc.load;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Properties;

import com.att.carat.util.Email;
import com.att.carat.util.JDBCUtil;
//changes for M168 by as635b
//import com.sbc.bac.load.Application;
//import com.sbc.bac.load.LoadJob;
//import com.sbc.bac.load.MultipleConnectionApplication;
import com.att.carat.load.Application;
import com.att.carat.load.LoadJob;
import com.att.carat.load.MultipleConnectionApplication;


/**
 * @author pt6471
 * 
 *   This job will check if the DB2 extract log RABC_DATA_EXTRCT_LOG for a given file ID if rerun ind set or 
 *   if RABC_DATA_EXTRCT_SCHEDULE is ready to run for next Extract ( NEXT_RUN_DATE =  BILL_RND_DT & PROC_DT <= SYSDATE )
 *    checking Against RABC_CYCLE_CALENDAR to trigger the DB2 table extract process. 
 *    Checks once per day since "ALL DB*" tables are loaded over night between 12:00AM to 5:00AM .. 
 *    MVS(DB2) suggested time to schedule and run our Extract is about 6:00AM local time per region.. 
 *    Note:
 *    If this need to be expanded to other regions ( Other than MW) just add the region conversion to DIVISION_MAP
 *
 */
abstract public class CheckDB2Extract extends LoadJob{

	private static final String DEFAULT_USERS = "CARATSysMessages@att.com";
	protected String notify_users;
	
	private Calendar runtime = Calendar.getInstance();
	private SimpleDateFormat df = new SimpleDateFormat("HH:mm");
	
	private String admin_address = null;
	private String file_id = null;
	//private String checkSql = null;
	private boolean scheduledRun = false;
	private boolean rerunInd = false;
	private boolean skipProcess = false;
	private PreparedStatement checkExtractSchedule = null;
	private PreparedStatement checkRerunSchedule = null;
	protected MultipleConnectionApplication multiApplication = null;
	protected Connection ORAconnection = null;
	protected Connection DB2connection = null;
	
	protected PreparedStatement getExtractSchedule = null;
	protected PreparedStatement getExtractQry = null;
	protected PreparedStatement getRerunLog = null;
	protected PreparedStatement updateRerunLog = null;
	protected PreparedStatement insertExtractLog = null;
	private PreparedStatement deleteRerunData = null;
	private PreparedStatement updateExtractSchedule = null;
	
	private final String BILL_DAY_EXT = "B";
	private final String DAILY_EXT = "D";
	private final String MONTHLY_EXT = "M";
	
	protected static HashMap DIVISION_MAP = new HashMap();
	protected static HashMap BILLRND_MAP = new HashMap();
    static {
        DIVISION_MAP.put("WI","W");
        DIVISION_MAP.put("MI","M");
        DIVISION_MAP.put("IL","L");
        DIVISION_MAP.put("IN","N");
        DIVISION_MAP.put("OH","O");
        DIVISION_MAP.put("W","WI");
        DIVISION_MAP.put("M","MI");
        DIVISION_MAP.put("L","IL");
        DIVISION_MAP.put("N","IN");
        DIVISION_MAP.put("O","OH");
    }
    
    static {
    	BILLRND_MAP.put("01","01");
    	BILLRND_MAP.put("02","01");
    	BILLRND_MAP.put("03","04");
    	BILLRND_MAP.put("04","04");
    	BILLRND_MAP.put("05","07");
    	BILLRND_MAP.put("06","07");
    	BILLRND_MAP.put("07","10");
    	BILLRND_MAP.put("08","10");
    	BILLRND_MAP.put("09","13");
    	BILLRND_MAP.put("10","13");
    	BILLRND_MAP.put("11","16");
    	BILLRND_MAP.put("12","16");
    	BILLRND_MAP.put("13","19");
    	BILLRND_MAP.put("14","19");
    	BILLRND_MAP.put("15","22");
    	BILLRND_MAP.put("16","22");
    	BILLRND_MAP.put("17","25");
    	BILLRND_MAP.put("18","25");
    	BILLRND_MAP.put("19","28");
    	BILLRND_MAP.put("20","28");
    }
	
	 protected boolean configure(Application application, Properties properties) {
        boolean success = super.configure(application, properties);
        if (!success) 
        	return false;
        
        if (success) {
            try {
                this.multiApplication = (MultipleConnectionApplication) application;
          
            }
            catch (Exception e) {
                severe("Invalid application class: " + application.getClass().getName()
                        + ". Please use a MultipleConnectionApplication");
            }
        }

        // get run time from config
        
        String time = properties.getProperty("runtime");
		if (time == null) return false;
		
		try {
			runtime.setTime(df.parse(time));
		} catch (ParseException e) {
			severe("runtime entry could not be parsed.");
			return false;
		}
		
		Calendar now = Calendar.getInstance();
		runtime.set(now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DATE));
		if (now.after(runtime)) runtime.add(Calendar.DATE, 1);
		
        // get File ID for each job from config
		file_id = properties.getProperty("file_id");
		if (file_id==null){
			severe(" file_id is not defined in config data Extraction is aborting.");
			return false;
		}
		
		// Get the notification email addresses
    	if (properties.containsKey("notify_users") && properties.getProperty("notify_users").trim().length() != 0) {
    		notify_users = properties.getProperty("notify_users");
    	}else {
    		info("\"notify_users\" property is not set. Using default: " + DEFAULT_USERS);
    		notify_users = DEFAULT_USERS;
    	}
    	
/*
		checkSql = properties.getProperty("checkSQL");
		
		if (checkSql==null){
			severe(" checkSql is not defined in config .. data Extraction is aborting.");
			return false;
		}
*/
		
	        return success;
	    }
	 
	 
		protected boolean preprocess(){
			
			boolean success = super.preprocess();
			if(success){
				try {
					getExtractQry = ORAconnection.prepareStatement(" select EXTRCT_TO_TBL, CHECK_QUERY, EXTRACT_QUERY from RABC_DATA_EXTRCT_QUERY where FILE_ID = ? ");

					getExtractSchedule = ORAconnection.prepareStatement(" SELECT DIVISION, FILE_ID, EXTRCT_TIME_IND, EXTRCT_TIME, EFF_DT, " +
																	" NEXT_RUN_DATE,BILL_RND, PROC_DT, BILL_RND_DT " +
																	" FROM RABC_DATA_EXTRCT_SCHEDULE, RABC_CYCLE_CALENDAR " +
																	" where NEXT_RUN_DATE =  BILL_RND_DT " +
																	" and FILE_ID = ? and proc_dt <= SYSDATE  and BILL_RND is not null ");
									
					getRerunLog = ORAconnection.prepareStatement(" SELECT DIVISION, RUN_DATE, BILL_RND FROM rabc_data_extrct_log WHERE file_id = ? AND RERUN_IND in ('Y','S') and RUN_DATE > add_months(SYSDATE,-1)");
					
					updateRerunLog = ORAconnection.prepareStatement(" update rabc_data_extrct_log  " +
																	" set RERUN_IND = NULL " +
																	"	WHERE file_id = ? AND RUN_DATE = ? and DIVISION = ?");
					
					insertExtractLog = ORAconnection.prepareStatement(" INSERT into  rabc_data_extrct_log " +
																	  " ( DIVISION, FILE_ID, RUN_DATE, TIMESTAMP, RERUN_IND, BILL_RND ) " +
																	  " values(?, ?, ?, SYSDATE, ?, ?) ");
					
				} catch (SQLException e) {
					severe("Exception while creating prepareStatement "+e, e );
					success = false;
				}
			}
				return success;
		}
		
		
	protected boolean check() {

		//check if job is ready to run next time.. if not back to sleep & wait.
		
		if (!Calendar.getInstance().after(runtime)) return false;
		
		// 	since check is called 2 times just check if any of the flags for the job set already , 
		//	if not check and set them ..
		ResultSet rs = null;
		if (!isScheduledRun() && !isRerunInd())
		try{
			
			
			if (ORAconnection == null || ORAconnection.isClosed())
    			ORAconnection = multiApplication.getConnection("ORACLE");
            
            if (DB2connection == null || DB2connection.isClosed())
            	DB2connection = multiApplication.getConnection("DB2");

			checkExtractSchedule = ORAconnection.prepareStatement(" SELECT count(*) " +
					" FROM RABC_DATA_EXTRCT_SCHEDULE, RABC_CYCLE_CALENDAR " +
					" where NEXT_RUN_DATE =  BILL_RND_DT " +
					" and FILE_ID = ? and PROC_DT <= SYSDATE  and BILL_RND is not null");
			
			checkRerunSchedule = ORAconnection.prepareStatement(" select  count(*) " +
					" from  rabc_data_extrct_Log " +
					" where file_id = ? and RERUN_IND is not null ");
			
			checkExtractSchedule.setString(1,file_id);
			rs = checkExtractSchedule.executeQuery();
			if (rs.next()) 
				if (rs.getInt(1) > 0){
					setScheduledRun(true);
				}
			
			checkRerunSchedule.setString(1,file_id);
			rs = checkRerunSchedule.executeQuery();
			if (rs.next())
				if (rs.getInt(1) > 0){
					setRerunInd(true);
				}
					
		} catch (java.lang.Exception e) {
			severe("Exception in Check() process", e);
			String body = "DB2 RBS Extract Error in RABC - "+e.getMessage();
			Email.sendEmail(getAdmin_address(), "RABC - Failure in DB2 check()", body);
			return false;					
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(checkExtractSchedule);
			JDBCUtil.closePreparedStatement(checkRerunSchedule);
			
		}
		
		if (isScheduledRun() || isRerunInd()) 
			return true;
		else {
			// IF there is no match, then check back next day for this Entry ( RABC_DATA_EXTRCT_SCHEDULE )
			runtime.add(Calendar.DATE, 1);     
			return true;
		}
	}
	 

	/**
	 * @return Returns the admin_address.
	 */
	protected String getAdmin_address() {
		return admin_address;
	}


	/**
	 * @return Returns the file_id.
	 */
	protected String getFile_id() {
		return file_id;
	}

	/**
	 * @return Returns the scheduledRun.
	 */
	protected boolean isScheduledRun() {
		return scheduledRun;
	}

	/**
	 * @return Returns the rerunInd.
	 */
	protected boolean isRerunInd() {
		return rerunInd;
	}

	/**
	 * @param rerunInd The rerunInd to set.
	 */
	protected void setRerunInd(boolean rerunInd) {
		this.rerunInd = rerunInd;
	}

	/**
	 * @param scheduledRun The scheduledRun to set.
	 */
	protected void setScheduledRun(boolean scheduledRun) {
		this.scheduledRun = scheduledRun;
	}
	 
	protected boolean postprocess(boolean success) {
		// close all preparedStatements .. 		
		
					
			JDBCUtil.closePreparedStatement(getExtractSchedule);
			JDBCUtil.closePreparedStatement(getExtractQry);
			JDBCUtil.closePreparedStatement(getRerunLog);
			JDBCUtil.closePreparedStatement(updateRerunLog);
			JDBCUtil.closePreparedStatement(insertExtractLog);
		
		
		success = super.postprocess(success);
		
		// set to run nextday ..
		runtime.add(Calendar.DATE, 1);
		
		// committing the DB2 RBS groups tables to free the share read locks that CARAT has obtained.
		// note that CARAT does not update the RBS tables. only reads them. 
		try	{
			DB2connection.commit();
		}
		
		
		catch (SQLException e) {
			severe("Exception while executing DB2 commit statement "+e, e );			
		}

		
		return success;
	}


	/**
	 * @return Returns the skipProcess.
	 */
	public boolean isSkipProcess() {
		return skipProcess;
	}


	/**
	 * @param skipProcess The skipProcess to set.
	 */
	public void setSkipProcess(boolean skipProcess) {
		this.skipProcess = skipProcess;
	}
	

	// add a log entry to rabc_data_extrct_log once extraction completed. once entry per extraction. 
	// this log table can be used to request for rerun.  
	protected boolean insertExtractCompLog(String division, Date billDate, String billRnd, String fileId, String sourceTable, boolean skip){

		boolean status = true;
		try {
		
			insertExtractLog.setString(1,division);
			insertExtractLog.setString(2,fileId);
			insertExtractLog.setDate(3,billDate);
			if (skip)
				insertExtractLog.setString(4,"S");
			else
			insertExtractLog.setNull(4,Types.VARCHAR);
			insertExtractLog.setString(5,billRnd);
			insertExtractLog.execute();
		
		} catch (SQLException e) {
			severe("Exception while creating statements "+e, e );
			status = false;
		}
		return status;
	}

	//cleanup before rerun
	protected boolean deleteRerunData(String state, Date billDate, String billRnd, String sourceTable){
		
		boolean status = true;
		String delSQL = " Delete from " + sourceTable + " where DIVISION = ? and RUN_DATE = ? and BILL_RND = ?";
		try {
			
			deleteRerunData = ORAconnection.prepareStatement(delSQL);
			deleteRerunData.setString(1,state);
			deleteRerunData.setDate(2,billDate);
			deleteRerunData.setString(3,billRnd);
			
			int delCnt = deleteRerunData.executeUpdate();
			info("RERUN : deleted for rerun table " + sourceTable + " CNT " + delCnt);
			
		} catch (SQLException e) {
			severe("Exception while processing ResultSet "+e, e );
			
			status = false;
		}finally {
			JDBCUtil.closePreparedStatement(deleteRerunData);
		}
		
		return status;
	}

	// update schedule once extraction completed successfully. This update will be done by getting next_run_date from 
	// cycle_calendar table. 
	protected boolean updateSchedule(String extractTimeInd, Date procDt, String billRnd, String division) {

		boolean status = true;
		StringBuffer updCnlRun = new StringBuffer("update RABC_DATA_EXTRCT_SCHEDULE set NEXT_RUN_DATE = ( SELECT min(bill_rnd_dt)");
		updCnlRun.append("	FROM rabc_cycle_calendar WHERE proc_dt > ? ");
		
		try {
		if (extractTimeInd.equals(BILL_DAY_EXT) ){
		
			updCnlRun.append(" and BILL_RND is not null ) where FILE_ID = ? and division = ?");
			
			updateExtractSchedule = ORAconnection.prepareStatement(updCnlRun.toString());
			updateExtractSchedule.setDate(1,procDt);
			//updateExtractSchedule.setString(2,billRnd);
			updateExtractSchedule.setString(2,getFile_id());
			updateExtractSchedule.setString(3,division);
			updateExtractSchedule.executeUpdate();
			
		} else if ( extractTimeInd.equals(DAILY_EXT) ) {

			updCnlRun.append(" ) where FILE_ID = ? and division = ?");
			updateExtractSchedule = ORAconnection.prepareStatement(updCnlRun.toString());
			updateExtractSchedule.setDate(1,procDt);
			updateExtractSchedule.setString(2,getFile_id());
			updateExtractSchedule.setString(3,division);
			updateExtractSchedule.executeUpdate();

			
		} else if ( extractTimeInd.equals(MONTHLY_EXT) ) {
			
			updCnlRun.append(" and BILL_RND = ? ) where FILE_ID = ? and division = ?");
			
			updateExtractSchedule = ORAconnection.prepareStatement(updCnlRun.toString());
			updateExtractSchedule.setDate(1,procDt);
			updateExtractSchedule.setString(2,billRnd);
			updateExtractSchedule.setString(3,getFile_id());
			updateExtractSchedule.setString(4,division);
			updateExtractSchedule.executeUpdate();
			
		} else {
			
			updCnlRun.append(" ) where FILE_ID = ? and division = ?");
			
			updateExtractSchedule = ORAconnection.prepareStatement(updCnlRun.toString());
			updateExtractSchedule.setDate(1,procDt);
			updateExtractSchedule.setString(2,getFile_id());
			updateExtractSchedule.setString(3,division);
			updateExtractSchedule.executeUpdate();
		}
		} catch (SQLException e) {
			severe("Exception while creating statements "+e,e );
			status = false;
		}finally {
			JDBCUtil.closePreparedStatement(updateExtractSchedule);
		}
		
		return status;
	}

	//	return BILLROUND date in RBS tables .. using translation table provided by RBS 
	protected Date getBillroundDate(Date rabcBillDate, String programGroup) throws ParseException{
		DateFormat df = new SimpleDateFormat("MMddyyyy");
		String run_date = df.format(rabcBillDate);
		String billRound = BILLRND_MAP.get(programGroup).toString();
		String tempDate = run_date.substring(0,2)+ billRound + run_date.substring(4,8);
		long dateValue = df.parse(tempDate).getTime();
		java.sql.Date rbsBillDate=new java.sql.Date(dateValue);
		return rbsBillDate;
	}

    protected void sendAlertMessage(String alertRule,String division, Date procDt, String msg) throws SQLException {
        String sql = "INSERT INTO rabc_alert_msg (MSG_NUM, PROC_DATE, ALERT_RULE, ALERT_KEY1, ALERT_DATA1, ALERT_STATUS, ALERT_MSG, ALERT_SEVERE_LVL_IND, TIME_STAMP) VALUES (?, ?, ?, 'DIVISION', ?, 'Warning', ?, 'S', SYSDATE)";
        PreparedStatement ps = ORAconnection.prepareStatement(sql);
        ps.setInt(1, createMsgNum());
        ps.setDate(2, procDt); 
        ps.setString(3, alertRule);
        ps.setString(4, division);  // ALERT_KEY1
        ps.setString(5, msg);
        ps.execute();
        JDBCUtil.closePreparedStatement(ps);
}
    private int createMsgNum() throws SQLException {
        PreparedStatement ps = ORAconnection.prepareStatement("select EWSSEQ_MSG_NO.nextval from dual");
        ResultSet rs = ps.executeQuery();
        rs.next();
        int result = rs.getInt(1);
        JDBCUtil.closeResultSet(rs);
        JDBCUtil.closePreparedStatement(ps);
        return result;
    }

}
