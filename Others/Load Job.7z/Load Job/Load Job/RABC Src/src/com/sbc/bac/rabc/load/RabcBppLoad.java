/*
 * Created on May 31, 2005
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package com.sbc.bac.rabc.load;
import java.io.File;
import java.net.UnknownHostException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Properties;
import java.util.StringTokenizer;

import com.att.bac.rabc.util.EmcisEventLogger;
import com.att.bac.util.NetUtil;
import com.att.carat.util.Email;
//changes for M168 by as635b
import com.att.carat.load.Application;
import com.att.carat.load.FileDBLoadJob;
//import com.sbc.bac.load.Application;
//import com.sbc.bac.load.FileDBLoadJob;

/******************************************************************************
 * @author sr8948
 *
 * Class Name : RabcBppLoad
 * Program Id : RABCPPG00323
 * Author     : Srikanth Reddy
 * Purpose    : Loadjob for following input filenames
 *               re.x.Cxxxx.XT14POFX.TIMESTAMP.TXT
 *              Also loads the Trigger Table.
 * Comments	  : Input files is sorted by POF_ID & ACCT TYPE	    
 ******************************************************************************/

public class RabcBppLoad extends FileDBLoadJob {

	private String region, location, bill_rnd, bill_rnd_dt, run_date;
	private String pofId, busType, division;
	private String PrevPofId, PrevBusType;
	private String maillist, bac_home, to_address;
	private double Nchrg,Ndisc,Rchrg,Rdisc,Uchrg,Udisc,Ochrg,Odisc,Tchrg,Totalchrg;

	private java.sql.Date sqlrun_date;

	private boolean firstrecord;
	private HashMap crocd_division;
	private int cycle;
	private File currentFile;

	private PreparedStatement insert_pof_blg_sumy;

	private String backoutRecovery = null;
	private boolean billdayFile;
	private String fileName, fileToken;
	
	public boolean configure(
		Application application,
		Properties configuration) {

		to_address =
			configuration.getProperty(StaticFieldKeys.STATUS_TO_ADDRESS);

		boolean result = super.configure(application, configuration);
		return result;
	}

	public boolean preprocess() {
		super.preprocess();

		try {
			insert_pof_blg_sumy =
				connection.prepareStatement(
					StaticInsertSQLQuerys.INSERT_POF_BLG_SUMY());
		} catch (SQLException e) {
			severe(StaticErrorMsgKeys.PREPROCESS_ERROR + e.getMessage());
			return false;
		}
		return true;
	}

	public boolean postprocess(boolean success) {

		try {
			insert_pof_blg_sumy.close();

		} catch (SQLException e) {
			severe(
				StaticErrorMsgKeys.POSTPROCESS_ERROR
					+ StaticErrorMsgKeys.SQL_CLOSE_ERROR
					+ e);
			success = false;
		}

		return super.postprocess(success);
	}

	public boolean preprocessFile(File file) {
		boolean success = super.preprocessFile(file);
		billdayFile = true;

		fileName = file.getName();
		fileToken = file.getName().substring(11,19);
		
		if (success) {
			try {

				region = file.getName().substring(0, 2);
				location =
					file.getName().charAt(3) == StaticFieldKeys.C
						? StaticFieldKeys.LOCATION_N
						: StaticFieldKeys.LOCATION_S;
				
				if 	(file.getName().charAt(3) == StaticFieldKeys.C)	
				  division = StaticFieldKeys.PACBELLNORTH;
				else if (file.getName().charAt(3) == StaticFieldKeys.I)	
				  division = StaticFieldKeys.PACBELLSOUTH;
				
				cycle = Integer.parseInt(file.getName().substring(6, 10));
				
				run_date = RetrieveStaticInfo.getProc_dtByCycle(connection, cycle);
				bill_rnd_dt = RetrieveStaticInfo.getbillRndDt_ByCycle(connection, cycle);
				if (run_date.equals(StaticFieldKeys.ZERO)){
					severe(StaticErrorMsgKeys.NORECORD_RABC_CYCLE_CALENDAR + cycle);
					throw new Exception();	
				}
				
				
				DateFormat df = new SimpleDateFormat("MMddyyyy");
				sqlrun_date = new java.sql.Date(df.parse(run_date).getTime());
				
				currentFile = file;
				firstrecord = true;
				
				String tableNm = null;
				
				if (RabcLoadJobTrig.IsFileLoaded(connection, file)) {
				//	severe(StaticErrorMsgKeys.DUPLICATE_FILE);
				//	return false;
					backoutRecovery = "Y";
					if (location.equals("N")){
						tableNm = "RABC_POF_BLG_SUMY";
						success = PrepareTableForRerun.deleteTableData(connection,tableNm,"PN",sqlrun_date);
						success = PrepareTableForRerun.deleteTableData(connection,tableNm,"NB",sqlrun_date);
					}else {
						// location.equals("S")
						tableNm = "RABC_POF_BLG_SUMY";
						success = PrepareTableForRerun.deleteTableData(connection,tableNm,"PS",sqlrun_date);
					}
				}
				

			} catch (Exception e) {
				severe(
					StaticErrorMsgKeys.PREPROCESSFILE_ERROR
						+ StaticErrorMsgKeys.FILE_NAME_PARSING_ERROR
						+ e);
				return false;
			}
		}

		try {

				
			bill_rnd = RetrieveStaticInfo.getBillRndByCycle(connection, cycle);
			if (bill_rnd.equals(StaticFieldKeys.ZERO) || bill_rnd.equals(StaticFieldKeys.ZERO2)){
				billdayFile = false;
			}
			//crocd_division =
			//	RetrieveStaticInfo.getCrocd_Divsion(connection, region.trim());

		} catch (SQLException e) {
			success = false;
			severe(StaticErrorMsgKeys.PREPROCESSFILE_ERROR + e.getMessage());
		}

		return success;
	}

	public boolean postprocessFile(File file, boolean success) {
		try{
			//Log the file information to EMCIS_EVENT_LOG and EMCIS_EVENT_LOG_DETAIL
			EmcisEventLogger emcisLogger = new EmcisEventLogger();
			String event_id = "RABC_"+fileToken+"_"+region;
            String host = NetUtil.getLocalHostName();
            String hostIP = NetUtil.getLocalIpAddress();
			int sequence = emcisLogger.getEMCISSequence(connection);
			emcisLogger.insertEventLog(connection, sequence, event_id, sqlrun_date, host, hostIP);
			emcisLogger.insertEventLogDetail(connection, sequence, "FileName", fileName);

		}catch (UnknownHostException e) {
            severe("Error getting EMCIS host information ", e);
        }
		if (success) {
			if (!insertPOFRow())success = false;
			//Insert into Trigger Table only if Bill round exists.
			if(billdayFile && success)
				if (!insertTrigger()) {
					severe(
						StaticErrorMsgKeys.POSTPROCESSFILE_ERROR
							+ StaticErrorMsgKeys.TIGGER_TABLE_INSERT_ERROR);
					success = false;
				}
			
		}

		if (!success) {
			Email.sendEmail(
				to_address,
				StaticFieldKeys.FROM_ADDRESS,
				StaticFieldKeys.SUBJECT_LINE,
				StaticErrorMsgKeys.XT14_ERROR_MESSAGE);
		}

		return super.postprocessFile(file, success);
	}

	public int parseLine(String line) throws Exception {

		if (line.length() < 23)
			return SKIPPED;

		StringTokenizer SummaryLine = new StringTokenizer(line, StaticFieldKeys.SEMICOLON);
		
		String Record_Id	 = SummaryLine.nextToken().trim();
		pofId 	= SummaryLine.nextToken().trim();
		busType = SummaryLine.nextToken().trim();
		
		// to make bus type look same as other (like RABC_TOT_BLG_SUMY ) .. Kin  
		if (busType.equals("NBU")) busType = "BUS";
		else if (busType.equals("NRE")) busType = "RES";
		else if (busType.equals("RRE")||busType.equals("RBU")) busType += "S";
		
		String Ignore = SummaryLine.nextToken().trim();
		//String crocd = SummaryLine.nextToken().trim();
		//division = (String) crocd_division.get(crocd);
        	
		//if (division.equals(null)){
		//	severe(StaticErrorMsgKeys.NORECORD_RABC_CRO_CD_DIVISION + crocd);
		//	throw new Exception();	
		//}
        
		String pb = pofId + busType;
		String prevpb = PrevPofId + PrevBusType;

		if (!pb.equals(prevpb)) {
			if (!firstrecord) {
				if (!insertPOFRow()) {
					throw new SQLException(StaticErrorMsgKeys.INSERT_ERROR);
				}
			}
		}

		PrevPofId = pofId;
		PrevBusType = busType;
		firstrecord = false;

		if (Record_Id.equals(StaticFieldKeys.RECORD_NON_RECUR)){ 
			Nchrg = Double.parseDouble(SummaryLine.nextToken().trim())/1000000;
			Ndisc = Double.parseDouble(SummaryLine.nextToken().trim())/1000000;
			Totalchrg = Totalchrg+Nchrg+Ndisc;
		} else if (Record_Id.equals(StaticFieldKeys.RECORD_RECUR)) {
			Rchrg = Double.parseDouble(SummaryLine.nextToken().trim())/1000000;
			Rdisc = Double.parseDouble(SummaryLine.nextToken().trim())/1000000;
			Totalchrg = Totalchrg+Rchrg+Rdisc;
		} else if (Record_Id.equals(StaticFieldKeys.RECORD_USAGE)) {
			Uchrg = Double.parseDouble(SummaryLine.nextToken().trim())/1000000;
			Udisc = Double.parseDouble(SummaryLine.nextToken().trim())/1000000;
			Totalchrg = Totalchrg+Uchrg+Udisc;
		} else if (Record_Id.equals(StaticFieldKeys.RECORD_OTHER)) {
			Ochrg = Double.parseDouble(SummaryLine.nextToken().trim())/1000000;
			Odisc = Double.parseDouble(SummaryLine.nextToken().trim())/1000000;
			Totalchrg = Totalchrg+Ochrg+Odisc;
		} else if (Record_Id.equals(StaticFieldKeys.RECORD_TAX)) {
			Tchrg = Double.parseDouble(SummaryLine.nextToken().trim())/1000000;
			Totalchrg = Totalchrg+Tchrg;
			//Tdisc = Double.parseDouble(SummaryLine.nextToken().trim())/1000000;
		} else
			throw new Exception(StaticErrorMsgKeys.INVAID_RECORD_TYPE + Record_Id);
        
		return SUCCESS;
	}

	public boolean accept(File file) {

		boolean ret = false;

		if (((file.getName().charAt(3) == StaticFieldKeys.C)
			|| (file.getName().charAt(3) == StaticFieldKeys.I))
			&& (file.getName().indexOf(StaticFieldKeys.FILEID_POFX) != -1)
			&& (file.length() > 0))
			ret = true;

		return ret;
	}

	private boolean insertPOFRow() {

		try {

			insert_pof_blg_sumy.setString(1, division);
			insert_pof_blg_sumy.setDate(2, sqlrun_date);
			insert_pof_blg_sumy.setInt(3, cycle);
			insert_pof_blg_sumy.setInt(4, Integer.parseInt(bill_rnd));
			insert_pof_blg_sumy.setString(5, PrevPofId);
			insert_pof_blg_sumy.setString(6, PrevBusType);
			insert_pof_blg_sumy.setDouble(7, Totalchrg);
			insert_pof_blg_sumy.setDouble(8, Tchrg);
			insert_pof_blg_sumy.setDouble(9, Uchrg);
			insert_pof_blg_sumy.setDouble(10, Nchrg);
			insert_pof_blg_sumy.setDouble(11, Rchrg);
			insert_pof_blg_sumy.setDouble(12, Ochrg);
			insert_pof_blg_sumy.setDouble(13, Udisc);
			insert_pof_blg_sumy.setDouble(14, Ndisc);
			insert_pof_blg_sumy.setDouble(15, Rdisc);
			insert_pof_blg_sumy.setDouble(16, Odisc);
			insert_pof_blg_sumy.setDate(17,
				new java.sql.Date(new java.util.Date().getTime()));
			insert_pof_blg_sumy.setString(18,bill_rnd_dt.substring(0,2));
			insert_pof_blg_sumy.setString(19,bill_rnd_dt.substring(4,8));

			insert_pof_blg_sumy.execute();

		} catch (SQLException e) {
			severe(StaticErrorMsgKeys.INSERT_ERROR + e.getMessage());
			return false;
		}

		Nchrg = 0;Ndisc = 0;Rchrg = 0;Rdisc = 0;Uchrg = 0;Udisc = 0;
		Ochrg = 0;Odisc = 0;Tchrg = 0;Totalchrg = 0;
		return true;
	}

	private boolean insertTrigger() {

		 if(!RabcLoadJobTrig.insertTrigger(connection,currentFile.getName(),"XT14",division,run_date,backoutRecovery,bill_rnd)){
			return false;	
		 }
		return true;
		
	}

}
