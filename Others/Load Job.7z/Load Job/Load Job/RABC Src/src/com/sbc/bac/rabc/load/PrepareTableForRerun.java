/*
 * Created on Feb 26, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.sbc.bac.rabc.load;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * @author pt6471
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class PrepareTableForRerun {
	
	public static boolean deleteTableData(
			Connection con,
			String tableNm,
			String division,
			java.sql.Date run_date) {


		PreparedStatement deleteStatement;

		StringBuffer sbQuery1 = new StringBuffer();

		sbQuery1.append(" DELETE FROM ").append(tableNm);
		sbQuery1.append(" where DIVISION = ? and RUN_DATE = ? ");

		try {

			deleteStatement = con.prepareStatement(sbQuery1.toString());

			deleteStatement.setString(1, division);
			deleteStatement.setDate(2, run_date);

			deleteStatement.execute();

			deleteStatement.close();

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	public static boolean deleteBossTableData(
			Connection conn,
			java.sql.Date dataCreateDate,
			String region,
			String division,
			String processGroup) {


		PreparedStatement deleteStatement;

		StringBuffer sbQuery2 = new StringBuffer();

		sbQuery2.append(" DELETE FROM TCCSEG_BOSS");
		sbQuery2.append(" where DATA_CREATE_DT = ? and REGION = ? and DIVISION = ? and PROCESS_GRP = ? ");

		try {

			deleteStatement = conn.prepareStatement(sbQuery2.toString());

			deleteStatement.setDate(1, dataCreateDate);
			deleteStatement.setString(2, region);
			deleteStatement.setString(3, division);
			deleteStatement.setString(4, processGroup);
			
			deleteStatement.execute();
			
			deleteStatement.close();

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public static boolean deleteFileStatusTableData(
			Connection conn,
			java.sql.Date dataCreateDate,
			String jobId) {


		PreparedStatement deleteStatement;

		StringBuffer sbQuery3 = new StringBuffer();

		sbQuery3.append(" DELETE FROM TCCSEG_FILE_STATUS");
		sbQuery3.append(" where DATA_CREATE_DT = ? and JOB_ID = ? ");

		try {

			deleteStatement = conn.prepareStatement(sbQuery3.toString());

			deleteStatement.setDate(1, dataCreateDate);
			deleteStatement.setString(2, jobId);
			
			deleteStatement.execute();

			deleteStatement.close();

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	
	/**
	 * Used to delete previously loaded data from a given table based on DIVISION and PROC_DATE 
	 * 
	 * @param con
	 * @param tableName
	 * @param division
	 * @param procDate
	 * @return
	 */
	public static boolean deletePreviouslyLoadedData(Connection con,String tableName,String division,Date procDate) {
		
		StringBuffer sbQuery = new StringBuffer();

		sbQuery.append(" DELETE FROM ").append(tableName);
		
		if(tableName.equalsIgnoreCase("RABC_ED_SUMY_DATA")){
			sbQuery.append(" where DIVISION = ? and PROC_DT = ? ");
		}else{
			sbQuery.append(" where DIVISION = ? and PROC_DATE = ? ");
		}
		
		
		PreparedStatement deleteStatement = null ;
		try {

			deleteStatement = con.prepareStatement(sbQuery.toString());
			deleteStatement.setString(1, division);
			deleteStatement.setDate(2, procDate);
			deleteStatement.execute();
			deleteStatement.close();

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
		
}

