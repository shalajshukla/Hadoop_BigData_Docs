package com.sbc.bac.rabc.load;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.Properties;

/******************************************************************************
 * @author sr8948
 *
 * Class Name : CreateRankFileTemp
 * Program Id : RABCPPG00328
 * Author     : Srikanth Reddy
 * Purpose    : Creates the following file for cris
 * 				"c" + cycle + ".B269100drcd.txt";
 * Comments	  : 
 * Re_Eng File Format:
 * CYCLE
 * BILL_ROUND
 * YYYYMMDD
 * *****Repeats for "PB","NB","PS" ********
 * DIVISION
 * ACCT_CT
 * BUS_ACCT_CT
 * RES_ACCT_CT
 * LIVE_ACCT_CT
 * FNL_ACCT_CT
 * RESALE_ACCT_CT
 * CURR_BLG_AMT
 * BUS_BLG_AMT
 * RES_BLG_AMT
 * LIVE_BLG_AMT
 * FNL_BLG_AMT
 * TOLL_AMT
 * OCC_AMT
 * BOC_AMT
 * ATT_AMT
 * IEC_AMT
 * RESALE_AMT
 * TAX_SURCH_AMT)
 * 1(Dummy Values)
 * 1(Dummy Values)
 ******** 20 Rank Info
 *RANK
 *NAME
 *BTN
 *AMT			
 ******************************************************************************/


public class CreateRankFileTemp {

	public static boolean createSummaryFile(
		Connection con,
		String filename,
		String bill_rnd,
		String run_date,
		int cycle) {
		boolean check1=false;
		boolean check2=false;
		
		Properties configuration1 = new Properties();
				File file = new File("rabc.cfg");
				FileInputStream fis;
				try {
					fis = new FileInputStream(file);
					configuration1.load(fis);
					fis.close();  
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				} catch (IOException e) {
				  e.printStackTrace();
				}
		String crisdirectory = configuration1.getProperty("crisdirectory");
		
     
		if(!checkTriggerForReEng(con,filename,bill_rnd,run_date)) return true;
		try {
			con.commit();
		} catch (SQLException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		String out = "";
		String SC  = ";";
		out += cycle+SC+bill_rnd+SC+run_date.substring(4,8)+run_date.substring(0,2)+run_date.substring(2,4)+SC;
		out += getData(con,"PN",run_date,cycle,bill_rnd);
		out += SC;
		out += getData(con,"NB",run_date,cycle,bill_rnd);
		out += SC;
		out += getData(con,"PS",run_date,cycle,bill_rnd);
				
		String query2="";
		String query3="";
		
		PreparedStatement Pquery2;
		PreparedStatement Pquery3;
		//String query = "select distinct acct_cls_cd from rabc_acct_blg_dtl where division = '"+ divi+"' and cycle="+cycle;
		
		query2 = "SELECT";
		query2 += " ';'|| a.RANK";
		query2 += "||';'||b.ACCT_NAME";
		query2 += "||';'||substr(a.BTN,0,10)";
		query2 += "||';'||(a.BAL_DUE_AMT)";
		query2 += " from RABC_TOP_TEN_BLG_ACCT a,RABC_ACCT_INFO b";
		query2 += " where 1 = 1";
		query2 += " and a.DIVISION = 'PN'";
		query2 += " and a.BTN = b.BTN";
		query2 += " and to_char(a.run_date(+),'mmddyyyy') = ?";
		query2 += " and a.cycle = ?";
		query2 += " and a.bill_rnd = ?";
		query2 += " and a.rank < 11";
		query2 += " order by a.Rank";

		query3 = "SELECT";
		query3 += " ';'|| a.RANK";
		query3 += " ||';'||b.ACCT_NAME";
		query3 += " ||';'||substr(a.BTN,0,10)";
		query3 += " ||';'||a.BAL_DUE_AMT";
		query3 += " from RABC_TOP_TEN_BLG_ACCT a,RABC_ACCT_INFO b";
		query3 += " where 1 = 1";
		query3 += " and a.DIVISION = 'PS'";
		query3 += " and a.BTN = b.BTN";
		query3 += " and to_char(a.run_date(+),'mmddyyyy') = ?";
		query3 += " and a.cycle = ?";
		query3 += " and a.bill_rnd = ?";
		query3 += " and a.rank < 11";
		query3 += " order by a.Rank";

		try {
			
			Pquery2 = con.prepareStatement(query2);
			Pquery3 = con.prepareStatement(query3);
			
			Pquery2.setString(1,run_date);
			Pquery2.setInt(2,cycle);
			Pquery2.setString(3,bill_rnd);
			ResultSet rs2 = Pquery2.executeQuery();
			
			while (rs2.next()) {
				out += rs2.getString(1);
				check1 = true;
			}
			rs2.close();
			if (!check1)   return false;
			
			Pquery3.setString(1,run_date);
			Pquery3.setInt(2,cycle);
			Pquery3.setString(3,bill_rnd);
			ResultSet rs3 = Pquery3.executeQuery();
			while (rs3.next()) {
				out += rs3.getString(1);
				check2= true;
			}

			rs3.close();
			if (!check2)   return false;
			
			Pquery2.close();
			Pquery3.close();
			
			String newfilename = "c"+cycle + ".B269100drcd.txt";
			File txtfile = new File(crisdirectory,newfilename);
			FileWriter fw = new FileWriter(txtfile);
			BufferedWriter bw = new BufferedWriter(fw);
			out += ";";
			bw.write(out);
			bw.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return false;
		} catch (IOException e1) {
			e1.printStackTrace();
			return false;
		}
		
		return true;

	}

	
	public static boolean checkTriggerForReEng(
			Connection con,
			String filename,
			String bill_rnd,
			String run_date) {
				
			PreparedStatement divStatement = null;
			ResultSet divRs = null;
			int count = 0;
			boolean truefalse = false;
			String s1 =   "XT11";
			int s2 =   Integer.parseInt(run_date.substring(2, 4));
			int s3 =   Integer.parseInt(run_date.substring(0, 2));
			int s4 =   Integer.parseInt(run_date.substring(4, 8));
			
			String query =	"select distinct DIVISION FROM RABC_TRIG"
							+ " where DIVISION IN ('PN','PS')"
							+ " AND FILE_ID = '"+ s1+"'"
							+ " AND CYCLE_RUN_DAY = "	 + s2
							+ " AND CYCLE_RUN_MONTH = " + s3
							+ " AND CYCLE_RUN_YEAR = " + s4;
			try {
				divStatement = con.prepareStatement(query);
				divRs = divStatement.executeQuery();

				while (divRs.next()) {
					count = count + 1;
				  }
				
				if (count == 2) truefalse = true;

				divRs.close();
				divStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}

			return truefalse;
		
		}
    
	private static String getData(Connection con, String div, String run_date, int cycle, String bill_rnd) {
		        
		        
				String type="";
				String rd="",query1="";
		        
				int	acct_ct,BUS_ACCT_CT = 0,RES_ACCT_CT = 0,RBU_ACCT_CT = 0,FNL_ACCT_CT = 0,RRE_ACCT_CT = 0;
				double	curr_blg_amt,BUS_BLG_AMT = 0,RES_BLG_AMT = 0,RBU_BLG_AMT = 0,FNL_BLG_AMT = 0,RRE_BLG_AMT = 0;
				
				double CURR_BLG_AMT =0,LIVE_BLG_AMT=0,RESALE_AMT=0;        	
				int ACCT_CT=0,LIVE_ACCT_CT=0,RESALE_ACCT_CT = 0;        	 
				
				double TOLL_AMT=0,OCC_AMT=0,BOC_AMT=0,ATT_AMT=0,IEC_AMT=0,TAX_SURCH_AMT=0;
				
				PreparedStatement Pquery1;
				
				try {
				
				query1 += "Select bus_type,acct_ct,bal_due_amt+curr_blg_amt,toll_amt,occ_amt,boc_amt,att_amt,iec_amt,tax_surch_amt";
				query1 += " from RABC_TOT_BLG_SUMY";
				query1 += " where division = ?";
				query1 += " and to_char(run_date,'mmddyyyy') = ?";
				query1 += " and cycle = ?";
				query1 += " and bill_rnd = ?";
		
				Pquery1 = con.prepareStatement(query1);
		
				Pquery1.setString(1,div);
				Pquery1.setString(2,run_date);
				Pquery1.setInt(3,cycle);
				Pquery1.setInt(4,Integer.parseInt(bill_rnd));
			
				ResultSet rs1 = Pquery1.executeQuery();

				while (rs1.next()) {
		
					type 			= rs1.getString(1);
					acct_ct 		= rs1.getInt(2);
					curr_blg_amt  	= rs1.getDouble(3);
		            
					TOLL_AMT        = TOLL_AMT + rs1.getDouble(4);
					OCC_AMT         = OCC_AMT  + rs1.getDouble(5);
					BOC_AMT         = BOC_AMT  + rs1.getDouble(6);
					ATT_AMT         = ATT_AMT  + rs1.getDouble(7);
					IEC_AMT         = IEC_AMT  + rs1.getDouble(8);
					
					if(!type.equals("FNL")){		
					 TAX_SURCH_AMT   = TAX_SURCH_AMT  + rs1.getDouble(9);
					}
					
					if (type.equals("BUS")){
						BUS_ACCT_CT = acct_ct;
						BUS_BLG_AMT = curr_blg_amt;
					}else if(type.equals("RES")){
						RES_ACCT_CT = acct_ct;
						RES_BLG_AMT = curr_blg_amt;
					}else if(type.equals("RRES")){
						RRE_ACCT_CT = acct_ct;
						RRE_BLG_AMT = curr_blg_amt;
					}else if(type.equals("RBUS")){
						RBU_ACCT_CT = acct_ct;
						RBU_BLG_AMT = curr_blg_amt;
					}else if(type.equals("FNL")){		
						FNL_ACCT_CT = acct_ct;
						FNL_BLG_AMT = curr_blg_amt;
					}
		
				}
				
				
				rs1.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			
			
			
								
			BUS_BLG_AMT         = BUS_BLG_AMT+ RBU_BLG_AMT;	
			BUS_ACCT_CT         = BUS_ACCT_CT+ RBU_ACCT_CT;
					
			RES_BLG_AMT         = RES_BLG_AMT+RRE_BLG_AMT;
			RES_ACCT_CT         = RES_ACCT_CT+RRE_ACCT_CT; 
			
			RESALE_ACCT_CT  	= RRE_ACCT_CT+RBU_ACCT_CT;
			RESALE_AMT          = RRE_BLG_AMT+RBU_BLG_AMT;
			
			ACCT_CT 			= BUS_ACCT_CT+RES_ACCT_CT;
			CURR_BLG_AMT 		= BUS_BLG_AMT+RES_BLG_AMT;
			
			LIVE_ACCT_CT  		= ACCT_CT-FNL_ACCT_CT;
			LIVE_BLG_AMT  		= CURR_BLG_AMT-FNL_BLG_AMT;
			
			
			String SC = ";";
			String retString="";
			if (div.equals("PN")) div = "PB";
			retString += div+SC+ACCT_CT+SC+BUS_ACCT_CT+SC+RES_ACCT_CT+SC;
			retString += LIVE_ACCT_CT+SC+FNL_ACCT_CT+SC+RESALE_ACCT_CT+SC+round2(CURR_BLG_AMT)+SC+round2(BUS_BLG_AMT)+SC;
			retString += round2(RES_BLG_AMT)+SC+round2(LIVE_BLG_AMT)+SC+round2(FNL_BLG_AMT)+SC+round2(TOLL_AMT)+SC+round2(OCC_AMT)+SC+round2(BOC_AMT)+SC+round2(ATT_AMT)+SC;
			retString += round2(IEC_AMT)+SC+round2(RESALE_AMT)+SC+round2(TAX_SURCH_AMT)+SC+1+SC+1;
			
			return retString;
		}
    
		 public static String round2(double x){//round, floor, or ceil
			DecimalFormat df = new DecimalFormat("0.00");
			String stringValue = df.format(x);
			return stringValue;
		}


}
