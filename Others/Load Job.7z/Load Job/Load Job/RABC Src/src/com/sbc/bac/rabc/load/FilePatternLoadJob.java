/*
 * Created on Feb 9, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.sbc.bac.rabc.load;

import java.io.File;
import java.util.Properties;

//changes for M168 by as635b
import com.att.carat.load.Application;
import com.att.carat.load.FileDBLoadJob;
//import com.sbc.bac.load.Application;
//import com.sbc.bac.load.FileDBLoadJob;

/**
 * @author pt6471
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public abstract class FilePatternLoadJob extends FileDBLoadJob{
	
	 private String file_pattern = null;
		
	   protected boolean configure(Application application, Properties configuration) {
			boolean result = super.configure(application, configuration);
			if(configuration.getProperty("file_pattern") == null || configuration.getProperty("file_pattern").equals("")){
				severe("'file_pattern' configuration property missing. Please specify 'file_pattern' in load job configuration file.");
				result = false;
			} else{
				file_pattern = configuration.getProperty("file_pattern");
			}
			return result;
		}
		 
		public boolean accept(File file) {

			boolean ret = false;

			if ((file.getName().matches(file_pattern))
				&& (file.length() > 0))
				ret = true;

			return ret;
		}
		

}
