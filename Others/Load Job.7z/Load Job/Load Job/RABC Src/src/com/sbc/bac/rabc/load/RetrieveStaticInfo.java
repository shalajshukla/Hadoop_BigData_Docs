/*
 * Created on Jun 1, 2005
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package com.sbc.bac.rabc.load;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
/******************************************************************************
 * @author sr8948
 *
 * Class Name : RetrieveStaticInfo
 * Progam Id  : RABCPPG00332
 * Author     : Srikanth Reddy
 *   	    
 ******************************************************************************/
 public class RetrieveStaticInfo {
    
    
	public static String getBillRndByCycle(Connection connection,int cycle) throws SQLException{
		String query =	"SELECT to_char(BILL_RND,'00') "
						+ "FROM RABC_CYCLE_CALENDAR WHERE CYCLE = "
						+ cycle;
	
	    return getBillRnd(connection,query);
	}
    
	public static String getBillRndByProc_ct(Connection connection,String proc_ct) throws SQLException{
			String query =	"SELECT to_char(BILL_RND,'00') "
							+ "FROM RABC_CYCLE_CALENDAR WHERE to_char(PROC_CT,'MMDDYYY') = "
							+ proc_ct;
	
			return getBillRnd(connection,query);
	}
    
    
	public static String getBillRndByBill_Rnd_dt(Connection connection,String billrnd_dt) throws SQLException{
			String query =	"SELECT to_char(BILL_RND,'00') "
								+ "FROM RABC_CYCLE_CALENDAR WHERE to_char(PROC_CT,'MMDDYYY') = "
								+ billrnd_dt;
	
			return getBillRnd(connection,query);
	}
    
    
	public static String getCyclebyBill_Rnd(Connection connection,String billrnd) throws SQLException{
		String query =	"SELECT cycle"
						+ "FROM RABC_CYCLE_CALENDAR WHERE BILL_RND = "
						+ billrnd;
	
		return getBillRnd(connection,query);
	}
    
	public static String getProc_dtByBill_Rnd(Connection connection,String billrnd) throws SQLException{
			String query =	"SELECT to_char(PROC_CT,'MMDDYYYY')"
							+ "FROM RABC_CYCLE_CALENDAR WHERE BILL_RND = "
							+ billrnd;
	
			return getBillRnd(connection,query);
	}
    
	public static String getProc_dtByCycle(Connection connection,int cycle) throws SQLException{
				String query =	"SELECT to_char(PROC_DT,'MMDDYYYY') "
								+ " FROM RABC_CYCLE_CALENDAR WHERE CYCLE = "
								+ cycle;
	
				return getBillRnd(connection,query);
	}
	
	public static String getbillRndDt_ByCycle(Connection connection,int cycle) throws SQLException{
		String query =	"SELECT to_char(BILL_RND_DT,'MMDDYYYY') "
						+ " FROM RABC_CYCLE_CALENDAR WHERE CYCLE = "
						+ cycle;

		return getBillRnd(connection,query);
	}
	
    public static String getBillRnd(Connection connection,String query) throws SQLException{
		
		String returnvalue = "0";
		
		PreparedStatement brStatement = null;
		ResultSet brRs = null;

			brStatement = connection.prepareStatement(query);
							
			brRs = brStatement.executeQuery();
	
			if (brRs.next()) {
				returnvalue = brRs.getString(1);
			}
			
			brRs.close();
			brStatement.close();
						
		
    	return returnvalue.trim();
       }


	public static HashMap getCrocd_Divsion(Connection connection,String region) throws SQLException{
		
			HashMap hashmap = new HashMap();
			ResultSet brRs  = null;		
		
			try{
			PreparedStatement  select_division =
								connection.prepareStatement("select cro_cd,division from RABC_CRO_CD_DIVISION where REGION = ?");
			
		     select_division.setString(1,region);				
			 brRs = select_division.executeQuery();
	
			while(brRs.next()) {
				hashmap.put(brRs.getString(1),brRs.getString(2));
			}
			
			brRs.close();
			select_division.close();
			
			}catch(Exception e){
				return hashmap;			
			}
		
			return hashmap;
    }

	
	public static boolean IsAcctInfoExists(Connection connection,String btn,String ctcusid) throws SQLException {
		
		ResultSet brRs  = null;	
		boolean ret     = false;	
			
			PreparedStatement  check_record =
					connection.prepareStatement("select * from RABC_ACCT_INFO where BTN = ? AND CTCUSTID = ?");
			
			check_record.setString(1,btn);
			check_record.setString(2,ctcusid);
									
			brRs = check_record.executeQuery();
	
			while(brRs.next()) {
				ret = true;
			}
			
			brRs.close();
		    check_record.close();
	
		return ret;
	}
	
	/**
	 * Method to return the boolean value which indicates whether the passed run date exists 
	 * in the table RABC_CYCLE_CALENDAR or not.
	 * 
	 * @param connection
	 * @param query
	 * @return true/false
	 * @throws SQLException
	 */
	public static boolean isProcDateExists(Connection connection, String query) throws SQLException{
		
		boolean procDateExists = false;
		
		PreparedStatement statement = null;
		ResultSet rs = null;

		statement = connection.prepareStatement(query);
		rs = statement.executeQuery();
		if (rs != null && rs.next()) {
			procDateExists = true;
		}
		
		rs.close();
		statement.close();
		
    	return procDateExists;
	}

}
