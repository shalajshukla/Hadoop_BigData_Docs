/*
 * Created on May 25, 2005
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package com.sbc.bac.rabc.load;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.GregorianCalendar;

/******************************************************************************
 * @author sr8948
 *
 * Class Name : RabcLoadJobTrig
 * Program Id : RABCPPG00324
 * Author     : Srikanth Reddy
 * Purpose    : Loads the trigger table after successful file Load and also 
 * 				checks for any duplicate file before loading.              
 *            
 * Comments	  : 	    
 ******************************************************************************/

/*
 * Modification History:                                     
 * SBCUID		Date			Description                         	    	
 * ------		--------		-----------
 * SH8512		20060821		Added a new method for ICBS files to check for file being processed before based on original file name
 * SH8512		20060822		Added an overloaded method for insertTrigger which accepts table name as additional argument for ICBS files
 */

public class RabcLoadJobTrig {

	public static boolean insertTrigger(
		Connection con,
		String filename,
		String originalFilename,
		String fileid,
		String division,
		java.util.Date timeStamp, 
		java.util.Date processDate,
		String backOutRecoveryInd) {
		
		Calendar processDateCal = GregorianCalendar.getInstance();
		processDateCal.setTime( processDate );
		
		int cycleDay = 0;

		try {			
			PreparedStatement getCycleRunDay = con.prepareStatement(
					"select BILL_RND from RABC_CYCLE_CALENDAR where PROC_DT = ?");
			
			getCycleRunDay.setDate( 1, new java.sql.Date(processDate.getTime()) );
	
			ResultSet rs = getCycleRunDay.executeQuery();
			if( rs.next() ){
				cycleDay = rs.getInt("BILL_RND");
			} else {
				return false;
			}
			
			PreparedStatement insertTriggerStatement;
	
			StringBuffer sbQuery1 = new StringBuffer();
	
			sbQuery1.append("INSERT INTO RABC_TRIG ");
			sbQuery1.append("(FILE_NAME,ORIGINAL_FILE_NAME,DIVISION,FILE_ID,");
			sbQuery1.append("TIME_STAMP,CYCLE_RUN_MONTH,CYCLE_RUN_DAY,CYCLE_RUN_YEAR,CYCLE_DAY,BACKUP_RECOVERY_IND) ");
			sbQuery1.append("VALUES(?,?,?,?,?,?,?,?,?,?)");


			insertTriggerStatement = con.prepareStatement(sbQuery1.toString());

			insertTriggerStatement.setString(1, filename);								//FILE_NAME
			insertTriggerStatement.setString(2, originalFilename);						//ORIGINAL_FILE_NAME
			insertTriggerStatement.setString(3, division);								//DIVISION
			insertTriggerStatement.setString(4, fileid);								//FILE_ID
			insertTriggerStatement.setDate(5, new java.sql.Date(timeStamp.getTime()));	//TIME_STAMP
			insertTriggerStatement.setInt(6, processDateCal.get(Calendar.MONTH)+1);		//CYCLE_RUN_MONTH
			insertTriggerStatement.setInt(7, processDateCal.get(Calendar.DATE));		//CYCLE_RUN_DAY
			insertTriggerStatement.setInt(8, processDateCal.get(Calendar.YEAR));		//CYCLE_RUN_YEAR
			insertTriggerStatement.setInt(9, cycleDay );								//CYCLE_DAY
			insertTriggerStatement.setString(10, backOutRecoveryInd);					//BACKUP_RECOVERY_IND

			insertTriggerStatement.execute();

			insertTriggerStatement.close();

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public static boolean insertTriggerSE(
		Connection con,
		String filename,
		String fileid,
		String division,
		String run_date,
		String billRound) {

		PreparedStatement insertTriggerStatement;

		StringBuffer sbQuery1 = new StringBuffer();

		sbQuery1.append("INSERT INTO RABC_TRIG");
		sbQuery1.append("(FILE_NAME,DIVISION,FILE_ID,");
		sbQuery1.append("CYCLE_DAY,CYCLE_RUN_MONTH,CYCLE_RUN_DAY,CYCLE_RUN_YEAR,TIME_STAMP, SEQNUM)");
		sbQuery1.append("VALUES(?,?,?,?,?,?,?,?,?)");

		try {

			insertTriggerStatement = con.prepareStatement(sbQuery1.toString());

			insertTriggerStatement.setString(1, filename);
			insertTriggerStatement.setString(2, division);
			insertTriggerStatement.setString(3, fileid);
			insertTriggerStatement.setInt(4,Integer.parseInt(billRound));
			insertTriggerStatement.setInt(5,Integer.parseInt(run_date.substring(0,2)));
			insertTriggerStatement.setInt(6,Integer.parseInt(run_date.substring(2,4)));
			insertTriggerStatement.setInt(7,Integer.parseInt(run_date.substring(4,8)));
			insertTriggerStatement.setDate(8, new java.sql.Date(new java.util.Date().getTime()));
			insertTriggerStatement.setString(9, "0");

			insertTriggerStatement.execute();

			insertTriggerStatement.close();

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;

	}
	
	
	public static boolean insertTrigger(
			Connection con,
			String filename,
			String fileid,
			String division,
			String run_date,
			String billRound) {

			PreparedStatement insertTriggerStatement;

			StringBuffer sbQuery1 = new StringBuffer();

			sbQuery1.append("INSERT INTO RABC_TRIG");
			sbQuery1.append("(FILE_NAME,DIVISION,FILE_ID,");
			sbQuery1.append("CYCLE_DAY,CYCLE_RUN_MONTH,CYCLE_RUN_DAY,CYCLE_RUN_YEAR,TIME_STAMP)");
			sbQuery1.append("VALUES(?,?,?,?,?,?,?,?)");

			try {

				insertTriggerStatement = con.prepareStatement(sbQuery1.toString());

				insertTriggerStatement.setString(1, filename);
				insertTriggerStatement.setString(2, division);
				insertTriggerStatement.setString(3, fileid);
				insertTriggerStatement.setInt(4,Integer.parseInt(billRound));
				insertTriggerStatement.setInt(5,Integer.parseInt(run_date.substring(0,2)));
				insertTriggerStatement.setInt(6,Integer.parseInt(run_date.substring(2,4)));
				insertTriggerStatement.setInt(7,Integer.parseInt(run_date.substring(4,8)));
				insertTriggerStatement.setDate(8, new java.sql.Date(new java.util.Date().getTime()));
			

				insertTriggerStatement.execute();

				insertTriggerStatement.close();

			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
			return true;

		}
	
	
	
	public static boolean insertTrigger(
			Connection con,
			String filename,
			String fileid,
			String division,
			String run_date,
			String backout,
			String billRound) {

			PreparedStatement insertTriggerStatement;

			StringBuffer sbQuery1 = new StringBuffer();

			sbQuery1.append("INSERT INTO RABC_TRIG");
			sbQuery1.append("(FILE_NAME,DIVISION,FILE_ID,");
			sbQuery1.append("CYCLE_DAY,CYCLE_RUN_MONTH,CYCLE_RUN_DAY,CYCLE_RUN_YEAR,TIME_STAMP, BACKUP_RECOVERY_IND)");
			sbQuery1.append("VALUES(?,?,?,?,?,?,?,?,?)");

			try {

				insertTriggerStatement = con.prepareStatement(sbQuery1.toString());

				insertTriggerStatement.setString(1, filename);											//FILE_NAME
				insertTriggerStatement.setString(2, division);											//DIVISION
				insertTriggerStatement.setString(3, fileid);											//FILE_ID
				insertTriggerStatement.setInt(4, Integer.parseInt(billRound));							//CYCLE_DAY
				insertTriggerStatement.setInt(5, Integer.parseInt(run_date.substring(0,2)));			//CYCLE_RUN_MONTH
				insertTriggerStatement.setInt(6, Integer.parseInt(run_date.substring(2,4)));			//CYCLE_RUN_DAY
				insertTriggerStatement.setInt(7, Integer.parseInt(run_date.substring(4,8)));			//CYCLE_RUN_YEAR
				insertTriggerStatement.setDate(8, new java.sql.Date(new java.util.Date().getTime()));	//TIME_STAMP
				insertTriggerStatement.setString(9, backout);											//BACKUP_RECOVERY_IND

				insertTriggerStatement.execute();

				insertTriggerStatement.close();

			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
			return true;

		}
	
	public static boolean insertTrigger(
			Connection con,
			String filename,
			String fileid,
			String division,
			String run_date) {

			PreparedStatement insertTriggerStatement;

			StringBuffer sbQuery1 = new StringBuffer();

			sbQuery1.append("INSERT INTO RABC_TRIG");
			sbQuery1.append("(FILE_NAME,DIVISION,FILE_ID,");
			sbQuery1.append("CYCLE_DAY,CYCLE_RUN_MONTH,CYCLE_RUN_DAY,CYCLE_RUN_YEAR,TIME_STAMP, BACKUP_RECOVERY_IND)");
			sbQuery1.append("VALUES(?,?,?,?,?,?,?,?,?)");

			try {

				insertTriggerStatement = con.prepareStatement(sbQuery1.toString());

				insertTriggerStatement.setString(1, filename);											//FILE_NAME
				insertTriggerStatement.setString(2, division);											//DIVISION
				insertTriggerStatement.setString(3, fileid);											//FILE_ID
				insertTriggerStatement.setString(4, null);							//CYCLE_DAY
				insertTriggerStatement.setInt(5, Integer.parseInt(run_date.substring(0,2)));			//CYCLE_RUN_MONTH
				insertTriggerStatement.setInt(6, Integer.parseInt(run_date.substring(2,4)));			//CYCLE_RUN_DAY
				insertTriggerStatement.setInt(7, Integer.parseInt(run_date.substring(4,8)));			//CYCLE_RUN_YEAR
				insertTriggerStatement.setDate(8, new java.sql.Date(new java.util.Date().getTime()));	//TIME_STAMP
				insertTriggerStatement.setString(9, null);											//BACKUP_RECOVERY_IND

				insertTriggerStatement.execute();

				insertTriggerStatement.close();

			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
			return true;

		}
	public static boolean insertTrigger(
			Connection con,
			String filename,
			String originalFileNm,
			String fileid,
			String division,
			String run_date,
			String backout,
			String billRound) {

			PreparedStatement insertTriggerStatement;

			StringBuffer sbQuery1 = new StringBuffer();

			sbQuery1.append("INSERT INTO RABC_TRIG");
			sbQuery1.append("(FILE_NAME,DIVISION,FILE_ID,");
			sbQuery1.append("CYCLE_DAY,CYCLE_RUN_MONTH,CYCLE_RUN_DAY,CYCLE_RUN_YEAR,TIME_STAMP, BACKUP_RECOVERY_IND, ORIGINAL_FILE_NAME)");
			sbQuery1.append("VALUES(?,?,?,?,?,?,?,?,?,?)");

			try {

				insertTriggerStatement = con.prepareStatement(sbQuery1.toString());

				insertTriggerStatement.setString(1, filename);
				insertTriggerStatement.setString(2, division);
				insertTriggerStatement.setString(3, fileid);
				insertTriggerStatement.setInt(4,Integer.parseInt(billRound));
				insertTriggerStatement.setInt(5,Integer.parseInt(run_date.substring(0,2)));
				insertTriggerStatement.setInt(6,Integer.parseInt(run_date.substring(2,4)));
				insertTriggerStatement.setInt(7,Integer.parseInt(run_date.substring(4,8)));
				insertTriggerStatement.setDate(8, new java.sql.Date(new java.util.Date().getTime()));
				insertTriggerStatement.setString(9, backout);
				insertTriggerStatement.setString(10, originalFileNm);

				insertTriggerStatement.execute();

				insertTriggerStatement.close();

			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
			return true;

		}
	
	
		/**
		 * insertTrigger method for BillDayEDFM3xLoadJob
		 * @param con
		 * @param filename
		 * @param fileid
		 * @param division
		 * @param processDate
		 * @param backout
		 * @param billRoundDate
		 * @return
		 */
		public static boolean insertTrigger(
				Connection con,
				String filename,
				String fileid,
				String division,
				java.util.Date processDate,
				String backout) {
				
				int cycleDay = 0;
				
	
				try {
						PreparedStatement getCycleRunDay = con.prepareStatement(
						"select BILL_RND from RABC_CYCLE_CALENDAR where PROC_DT = ?");
				
						getCycleRunDay.setDate( 1, new java.sql.Date(processDate.getTime()) );
				
						ResultSet rs = getCycleRunDay.executeQuery();
						if( rs.next() ){
							cycleDay = rs.getInt("BILL_RND");
						} else {
							return false;
						}
						
						PreparedStatement insertTriggerStatement; 
						
						StringBuffer sbQuery1 = new StringBuffer(); 
	
						Calendar processDateCal = GregorianCalendar.getInstance();
						processDateCal.setTime( processDate );
						
						sbQuery1.append("INSERT INTO RABC_TRIG");
						sbQuery1.append("(FILE_NAME,DIVISION,FILE_ID,");
						sbQuery1.append("CYCLE_DAY,CYCLE_RUN_MONTH,CYCLE_RUN_DAY,CYCLE_RUN_YEAR,TIME_STAMP, BACKUP_RECOVERY_IND)");
						sbQuery1.append("VALUES(?,?,?,?,?,?,?,?,?)");
						
						insertTriggerStatement = con.prepareStatement(sbQuery1.toString());
		
						insertTriggerStatement.setString(1, filename);											//FILE_NAME
						insertTriggerStatement.setString(2, division);											//DIVISION
						insertTriggerStatement.setString(3, fileid);											//FILE_ID
						insertTriggerStatement.setInt(4, cycleDay);							                    //CYCLE_DAY
						insertTriggerStatement.setInt(5, processDateCal.get(Calendar.MONTH)+1);			        //CYCLE_RUN_MONTH
						insertTriggerStatement.setInt(6, processDateCal.get(Calendar.DATE));			        //CYCLE_RUN_DAY
						insertTriggerStatement.setInt(7, processDateCal.get(Calendar.YEAR));			        //CYCLE_RUN_YEAR
						insertTriggerStatement.setDate(8, new java.sql.Date(new java.util.Date().getTime()));	//TIME_STAMP
						insertTriggerStatement.setString(9, backout);											//BACKUP_RECOVERY_IND
		
						insertTriggerStatement.execute();
		
						insertTriggerStatement.close();
	
				} catch (SQLException e) {
					e.printStackTrace();
					return false;
				} catch (Exception e) {
					e.printStackTrace();
					return false;
				}
				return true;
	
			}
	
	public static boolean IsFileLoaded(Connection con,File file) {
		// Returns true...If File already Processed
		PreparedStatement dupStatement = null;
		ResultSet dupRs = null;

		try {

			String query =
				"SELECT FILE_NAME FROM RABC_TRIG WHERE FILE_NAME like '"
					+ file.getName().substring(0,23)+"%'";

			dupStatement = con.prepareStatement(query);
			dupRs = dupStatement.executeQuery();

			if (dupRs.next()) {
			 return true; 
			}

			dupRs.close();
			dupStatement.close();

		} catch (SQLException e) {
			e.printStackTrace();
			return true; 
		}
		return false;
	}
	
	// This needed to check for small file names < 25 in file name length ..  
	
	public static boolean IsFileLoaded(Connection con,File file, int fileLength) {
		// Returns true...If File already Processed
		PreparedStatement dupStatement = null;
		ResultSet dupRs = null;

		try {

			String query =
				"SELECT FILE_NAME FROM RABC_TRIG WHERE FILE_NAME like '"
					+ file.getName().substring(0,fileLength)+"%'";

			dupStatement = con.prepareStatement(query);
			dupRs = dupStatement.executeQuery();

			if (dupRs.next()) {
			 return true; 
			}

			dupRs.close();
			dupStatement.close();

		} catch (SQLException e) {
			e.printStackTrace();
			return true; 
		}
		return false;
	}
	
	/**
	 * New method to check whether this file has been loaded. Returns true...If File already Processed
	 */
	public static boolean IsOriginalFileLoaded(Connection con,File file, int fileLength) {
		PreparedStatement dupStatement = null;
		ResultSet dupRs = null;

		try {

			String query = "SELECT ORIGINAL_FILE_NAME FROM RABC_TRIG WHERE ORIGINAL_FILE_NAME like '" + file.getName().substring(0,fileLength)+"%'";

			dupStatement = con.prepareStatement(query);
			dupRs = dupStatement.executeQuery();

			if (dupRs.next()) {
			 return true; 
			}

			dupRs.close();
			dupStatement.close();

		} catch (SQLException e) {
			e.printStackTrace();
			return true; 
		}
		return false;
	}
	
	/**
	 * Overloaded insertTrigger method in case of ICBS files for inserting trigger which also takes the table name as an argument
	 */
	public static boolean insertTrigger(
			Connection con,
			String filename,
			String originalFileNm,
			String fileid,
			String division,
			String run_date,
			String backout,
			String billRound,
			String tableNm) {

			PreparedStatement insertTriggerStatement;

			StringBuffer sbQuery1 = new StringBuffer();

			sbQuery1.append("INSERT INTO ");
			sbQuery1.append(tableNm);
			sbQuery1.append("(FILE_NAME,DIVISION,FILE_ID,");
			sbQuery1.append("CYCLE_DAY,CYCLE_RUN_MONTH,CYCLE_RUN_DAY,CYCLE_RUN_YEAR,TIME_STAMP, BACKUP_RECOVERY_IND, ORIGINAL_FILE_NAME)");
			sbQuery1.append("VALUES(?,?,?,?,?,?,?,?,?,?)");

			try {

				insertTriggerStatement = con.prepareStatement(sbQuery1.toString());

				insertTriggerStatement.setString(1, filename);
				insertTriggerStatement.setString(2, division);
				insertTriggerStatement.setString(3, fileid);
				insertTriggerStatement.setInt(4,Integer.parseInt(billRound));
				insertTriggerStatement.setInt(5,Integer.parseInt(run_date.substring(0,2)));
				insertTriggerStatement.setInt(6,Integer.parseInt(run_date.substring(2,4)));
				insertTriggerStatement.setInt(7,Integer.parseInt(run_date.substring(4,8)));
				insertTriggerStatement.setDate(8, new java.sql.Date(new java.util.Date().getTime()));
				insertTriggerStatement.setString(9, backout);
				insertTriggerStatement.setString(10, originalFileNm);

				insertTriggerStatement.execute();

				insertTriggerStatement.close();

			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
			return true;

		}
}
