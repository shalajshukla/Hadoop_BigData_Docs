package com.sbc.bac.rabc.load;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

/******************************************************************************
 * @author sr8948
 *
 * Class Name : CreateAcctFileTemp
 * Program Id : RABCPPG00327
 * Author     : Srikanth Reddy
 * Purpose    : Creates the following file for cris
 * 				"C.C."+cycle+".B268.TXT"
 * 				"I.C."+cycle+".B270.TXT"
 * Comments	  : 	    
 ******************************************************************************/



public class CreateAcctFileTemp {
	    
		
	public static boolean createAcctFile(Connection con,int cntl,String run_date,String filename) {
		
		String query = "";
		PreparedStatement AcctTempFile;
		
		
		Properties configuration1 = new Properties();
		File file = new File("rabc.cfg");
		FileInputStream fis;
		try {
			fis = new FileInputStream(file);
			configuration1.load(fis);
			fis.close();  
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
		  e.printStackTrace();
		}
		String crisdirectory = configuration1.getProperty("crisdirectory");
		
		int cycle    = Integer.parseInt(filename.substring(6, 10));
		String region   = filename.substring(3, 4);

		query = "SELECT distinct";
		query += " '0'||a.CYCLE";
		query += "||';'||a.DIVISION";
		query += "||';0'||a.CNTL_PT";
		query += "||';'||0";
		query += "||';'||a.CTCUSTID";
		query += "||';'||b.CRO_CD";
		query += "||';'||substr(a.BTN,0,3)";
		query += "||';'||substr(a.BTN,4,7)";
		query += "||';'||substr(a.BTN,11,3)";
		query += "||';'||a.ACCT_CLS_CD";
		query += "||';'||to_char(a.ACCT_TOT_BLG_CHRGS,'000000000000')";
		query += "||';'||to_char(a.ACCT_CURR_MNTH_CHRGS,'000000000000')";
		query += "||';'||to_char(a.ACCT_BAL_DUE,'000000000000')";
		query += "||';'||to_char(a.ACCT_BILL_ADJ,'000000000000')";
		query += "||';'||to_char(a.ACCT_PAYMENT_AMT,'000000000000')";
		query += "||';'||to_char(a.ACCT_OTR_BAL_ADJ,'000000000000')";
		query += "||';'||to_char(a.ACCT_OCC,'000000000000')";
		query += "||';'||to_char(a.ACCT_DSCT_OCC,'000000000000')";
		query += "||';'||to_char(a.ACCT_MCC,'000000000000')";
		query += "||';'||to_char(a.ACCT_DSCT_MCC,'000000000000')";
		query += "||';'||to_char(a.ACCT_MNTH_SRV_AMT,'000000000000')";
		query += "||';'||to_char(a.ACCT_FED_ACCES_AMT,'000000000000')";
		query += "||';'||to_char(a.ACCT_TOT_TOLL,'000000000000')";
		
		query += "||';'||to_char(a.ACCT_TOT_DSCT_TOLL,'000000000000')";
		query += "||';'||to_char(a.ACCT_ZONE1_AMT,'000000000000')";
		query += "||';'||to_char(a.ACCT_ZONE1_CT,'000000000000')";
		query += "||';'||to_char(a.ACCT_ZONE1_MOU,'000000000000')";
		query += "||';'||to_char(a.ACCT_ZONE23_AMT,'000000000000')";
		query += "||';'||to_char(a.ACCT_ZONE23_CT,'000000000000')";
		query += "||';'||to_char(a.ACCT_ZONE23_MOU,'000000000000')";
		query += "||';'||to_char(a.ACCT_TOT_TOLL_AMT,'000000000000')";
		
		//As per Kin(06/30) put Zero
		//query += "||';'||to_char(a.ACCT_TOT_TOLL_CT,'000000000000')";
		//query += "||';'||to_char(a.ACCT_TOT_MOU,'000000000000')";
		query += "||';'||' 000000000000'";
		query += "||';'||' 000000000000'";
		
		
		query += "||';'||to_char(a.ACCT_DA_AMT,'000000000000')";
		query += "||';'||to_char(a.ACCT_DA_CT,'000000000000')";
		query += "||';'||to_char(a.ACCT_IEC_CHRG,'000000000000')";
		query += "||';'||to_char(a.ACCT_FED_TAX,'000000000000')";
		query += "||';'||to_char(a.ACCT_STATE_TAX,'000000000000')";
		query += "||';'||to_char(a.ACCT_CITY_TAX,'000000000000')";
		query += "||';'||to_char(a.ACCT_BLG_SRCHG,'000000000000')";
		query += "||';'||to_char(a.ACCT_HCAP_SRCHG,'000000000000')";
		query += "||';'||to_char(a.ACCT_LFLN_SRCHG,'000000000000')";
		query += "||';'||to_char(a.ACCT_CPUC_SRCHG,'000000000000')";
		query += "||';'||to_char(a.ACCT_CHCFA_SRCHG,'000000000000')";
		query += "||';'||to_char(a.ACCT_CHCFB_SRCHG,'000000000000')";
		query += "||';'||to_char(a.ACCT_CTF_SRCHG,'000000000000')";
		query += "||';'||to_char(a.ACCT_USSC_SRCHG,'000000000000')";
		query += "||';'||to_char(a.ACCT_LPC_AMT,'000000000000')";
		query += "||';'||to_char(a.ACCT_ATT_SRCHG,'000000000000')";
		query += "||';'||' 000000000000'";
		query += "||';'||' 000000000000'";
		query += "||';'||substr(a.BTN,4,3)";
		query += "||';'||substr(a.BTN,7,4)";
		query += "||';'||b.ACCT_NAME";
		query += " from RABC_ACCT_BLG_DTL a,RABC_ACCT_INFO b";
		query += " where to_char(a.RUN_DATE,'mmddyyyy') = ?";
		query += " and a.CYCLE = ?";
		query += " and a.CNTL_PT = ?";
		query += " and a.BTN = b.BTN";
		query += " and a.CTCUSTID = b.CTCUSTID";
		if (region.equals("I"))
		query += " and a.DIVISION = 'PS'";
		else
		query += " and a.DIVISION in ('PN','NB')";
		
			
		String newfilename = "";
		
		if (cntl == 1){
			newfilename = region+".C"+cycle+"B270.TXT";
		}else if (cntl == 2){
			newfilename = region+".C"+cycle+"B268.TXT";
		}else return false;
		
		
		try {
		File txtfile = new File(crisdirectory,newfilename);
		FileWriter fw = new FileWriter(txtfile);
		BufferedWriter bw = new BufferedWriter(fw);
       
		AcctTempFile = con.prepareStatement(query);
		AcctTempFile.setString(1,run_date);
		AcctTempFile.setInt(2,cycle);
		AcctTempFile.setInt(3,cntl);
		
		ResultSet rs = AcctTempFile.executeQuery();
		
		while(rs.next()){
			bw.write(rs.getString(1)+"                                   ;");
			bw.newLine();
		}
		bw.close();
		rs.close();
		AcctTempFile.close();
		
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return false;
		} catch (IOException e1) {
			e1.printStackTrace();
			return false;
		}
		
		return true;

	}

}
