package com.sbc.bac.rabc.load;

import java.io.File;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.StringTokenizer;
//changes for M168 by as635b
import com.att.carat.load.FileDBLoadJob;
//import com.sbc.bac.load.FileDBLoadJob;


/**
 * This is the main class which gets the file and process the MVS FILE .
 * It also inserts the parsed FILE contents into the RABC_CYCLE_CALENDAR table.
 * 
 * @author MALLOY ROBERT (rx2452)
 * @author SRINIVAS ARCHINAPALLI(sa7653)
 */
public class WestCycleCalLoadJob extends FileDBLoadJob {
	
	// Date format constants
	private static final SimpleDateFormat MM_DD_YYYY_FORMAT = new SimpleDateFormat("MM/dd/yyyy");
	private static final SimpleDateFormat MM_DD_YYYY_HOUR_FORMAT = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
	
	// File field order constants
	private static final int DATE = 0;
	private static final int BILL_ROUND = 1;
	private static final int JOURNAL_DATE_INDICATOR = 2;
	private static final int CYCLE_NUMBER = 3;
	private static final int CABS_CYCLE_INDICATOR = 4;
	private static final int DATE_LAST_MODIFIED = 5;
	private static final int FILLER = 6;

	// DB Index based constants
	private static final int CYCLE_INDEX = 1;
	private static final int BILL_ROUND_INDEX = 2;
	private static final int PROCEDURE_DATE_INDEX = 3;
	private static final int BILL_ROUND_DATE_INDEX = 4;

	// General constants
	private static final String NO_BILL_CALL = "NBC";
	private static final String COMMA = ",";

	private PreparedStatement insertLCC;
	private PreparedStatement deleteLCC;
	private PreparedStatement insertBR;	
	private PreparedStatement deleteBR;
	
	private boolean isFirstRecord;
	
	/* (non-Javadoc)
	 * @see com.sbc.bac.load.DBLoadJob#preprocess()
	 */
	
	protected boolean preprocess() {
		super.preprocess();
	
		try {
	
			String DELETE_LCC = "DELETE FROM RABC_CYCLE_CALENDAR where PROC_DT >= ?";
			String INSERT_LCC = "INSERT INTO RABC_CYCLE_CALENDAR(CYCLE, BILL_RND, PROC_DT, BILL_RND_DT) values (?, ?, ?, ?)";
			
			String DELETE_BR = "DELETE FROM BILL_RD where PROC_DT >= ?";
			String INSERT_BR = "INSERT INTO BILL_RD(CYCLE, BILL_RD, PROC_DT) values (?, ?, ?)";
			
			// Initialize the prepared statements...
			deleteLCC = connection.prepareStatement(DELETE_LCC);
			insertLCC = connection.prepareStatement(INSERT_LCC);
			deleteBR  = connection.prepareStatement(DELETE_BR);
			insertBR  = connection.prepareStatement(INSERT_BR);	
			
			
			isFirstRecord = true;
					
		} catch (SQLException e) {
			severe("Unable to create the statement");

			return false;
		}

		return true;
	}

	// Gets the connection from the base class..
	private Connection getConnection() {
		return connection;
	}

	/* (non-Javadoc)
	 * @see com.sbc.bac.load.FileDBLoadJob#parseLine(java.lang.String)
	 */
	protected int parseLine(String line) throws Exception {
		// Token it by the delimiter
		StringTokenizer tokenizer = new StringTokenizer(line, COMMA);

		int count = 0;
		String billround = "";
		String token;

		Date procedureDate = null;
		Timestamp tstamp=null;
		String procedureDateString = "";
		// For all the tokens in this line... 
		
		while (tokenizer.hasMoreTokens()) {
			token = tokenizer.nextToken().trim();

			switch (count) {
				case DATE :
					// Since this is the first element, check for the valid value, if it is thru,
					// then everything in this line will be perfect...
					if (token.length() > 0) {
						procedureDateString = token;
						procedureDate = getDate(token, MM_DD_YYYY_FORMAT);
						insertLCC.setDate(PROCEDURE_DATE_INDEX, procedureDate);
						insertBR.setDate(PROCEDURE_DATE_INDEX, procedureDate);
						debug("Procedure date: " + procedureDate);
					}
					break;

				case BILL_ROUND :
					if (NO_BILL_CALL.equals(token)) {
						// when it is NBC token is assigned to '0'
						token = "0";
					}
		
					insertLCC.setInt(BILL_ROUND_INDEX, Integer.parseInt(token));
					insertBR.setInt(BILL_ROUND_INDEX, Integer.parseInt(token));
					billround = token;
					debug("Bill round: " + token);
					break;

				case JOURNAL_DATE_INDICATOR :
					debug("journal date indicator: " + token);
					// ignore does nothing as of now
					break;

				case CYCLE_NUMBER :
					insertLCC.setInt(CYCLE_INDEX, Integer.parseInt(token));
					insertBR.setInt(CYCLE_INDEX, Integer.parseInt(token));
					debug("cycle number: " + token);
					break;

				case CABS_CYCLE_INDICATOR :
					debug("CABS cycle indicator: " + token);
					// ignore does nothing
					break;

				case DATE_LAST_MODIFIED :
					insertLCC.setTimestamp(BILL_ROUND_DATE_INDEX, getTimestamp(procedureDateString, billround, MM_DD_YYYY_FORMAT));
					debug("Last modified: " + getTimestamp(procedureDateString,billround, MM_DD_YYYY_FORMAT));
					break;

				case FILLER :
				default :
					debug("filler: " + token);
					// reserved for future...
			}
			count++;
		}

		// If it is first record, then... delete all the
		// records greater than the current record's year
		if (isFirstRecord) {
			isFirstRecord = false;

			Calendar cal = Calendar.getInstance();
			cal.setTime(procedureDate);
			cal.set(Calendar.MONTH,Calendar.JANUARY);
			cal.set(Calendar.DAY_OF_MONTH,1);
				
			// Set the date parameter
			deleteLCC.setDate(1, new java.sql.Date(cal.getTime().getTime()));
			deleteBR.setDate(1, new java.sql.Date(cal.getTime().getTime()));

			debug("Deleting ....");
			// Delete it
			deleteLCC.execute();
			deleteBR.execute();
		}
		
		if (count >=BILL_ROUND_DATE_INDEX ) {
			insertLCC.execute();
			insertBR.execute();
			return SUCCESS;
		}

		return SKIPPED;
	}

	/**
	 * @param token
	 * @param billround
	 * @param MM_DD_YYYY_HOUR_FORMAT
	 * @return
	 */
	
	/* (non-Javadoc)
	 * @see java.io.FileFilter#accept(java.io.File)
	 */
	public boolean accept(File file) {
		return (file.getPath().toUpperCase().indexOf("XT15WCAL") > 0);
	}

	/**
	 * This method is used to get the date from the given string with the given format
	 *  
	 * @param string The date in the string format
	 * @param format The date format
	 * @return The sql date
	 */
	private Date getDate(String string, SimpleDateFormat format) throws ParseException {
		return new Date(format.parse(string).getTime());
	}
	
	/**
	 * This method is used to get the TimeStamp from the given string with the given format
	 *  
	 * @param string The date in the string format
	 * @param format The date format
	 * @return The sql date
	 */
	
	private Timestamp getTimestamp(String date, String billRound, SimpleDateFormat format) throws ParseException {
		String month = "";
		String day = "";
		String year = "";
		int br = 0;
		int dy = 0;
		int mo = 0;
		int yr = 0;
		if (!billRound.trim().equals("0")){
		   date = date.trim();
		   month = date.substring(0, 2);
		   day = date.substring(3, 5);
		   year = date.substring(6, 10);
		   br = Integer.parseInt(billRound);
		   mo = Integer.parseInt(month);
		   dy = Integer.parseInt(day);
		   yr = Integer.parseInt(year);
		   if (br < dy) {
		   		dy = br;
		   } else if (mo == 1) {
		   		yr = yr - 1;
		   		mo = 12;
		   		dy = br;
		   } else {
		   		mo = mo - 1;
		   		dy = br;
		   }
		   if (mo < 10) {
		   		month = "0" + Integer.toString(mo);
		   } else {
		   		month = Integer.toString(mo);
		   }
		   if (dy < 10) {
	   			day = "0" + Integer.toString(dy);
		   } else {
	   			day = Integer.toString(dy);
		   }
		   year = Integer.toString(yr);
		   date = month + "/" + day + "/" + year;
		}
		return new Timestamp(format.parse(date).getTime());
	}
	
	 /*
	 ************************************************************************************
	 ******************************Srikanth Reddy****************************************
	 ************************************************************************************
	 ************************************************************************************
	 */
	 
	protected boolean postprocess(boolean success) {
		try {
			deleteLCC.close();
			insertLCC.close();
			deleteBR.close();
			insertBR.close();
		} catch (SQLException e) {
			severe("Error closing the prepared statement", e);

			return false;
		}

		return super.postprocess(success);
	}
}
