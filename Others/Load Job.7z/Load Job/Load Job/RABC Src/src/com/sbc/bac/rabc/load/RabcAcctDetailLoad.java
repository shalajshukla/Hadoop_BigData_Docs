package com.sbc.bac.rabc.load;

import java.io.File;
import java.net.UnknownHostException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;
import java.util.StringTokenizer;

import com.att.bac.rabc.util.EmcisEventLogger;
import com.att.bac.util.NetUtil;
import com.att.carat.util.Email;
//changes for M168 by as635b
import com.att.carat.load.Application;
import com.att.carat.load.FileDBLoadJob;
//import com.sbc.bac.load.Application;
//import com.sbc.bac.load.FileDBLoadJob;



/* ***************************************************************************
 * Class Name : RabcAcctDetailLoad
 * Program Id : RABCPPG00320
 * Author     : Srikanth Reddy
 * Purpose    : Loadjob for following input filenames
 *               1. re.x.Cxxxx.XT10CRIS.TIMESTAMP.TXT
 * 				 2. re.x.Cxxxx.XT12BDYT.TIMESTAMP.TXT
 *              Also loads the Trigger Table.
 * Comments	  : Remove the Re-Eng Logic when Implemented fully.
 * 
 * 
 * 	
Acct Detail Table    -- MVS file  Mapping info
*****************       ******** 
ACCT_TOT_BLG_CHRGS      CUR MNTH CHG + BAL DUE AMT 
ACCT_CURR_MNTH_CHRGS    CUR MNTH CHG 
ACCT_PAYMENT_AMT        PYMT AMT 
ACCT_BAL_DUE            BAL DUE AMT 
ACCT_BILL_ADJ           ADJ AMT 
ACCT_OTR_BAL_ADJ        OCS-BAL-TR-AMT + BAL-TR-AMT 
ACCT_OCC                OCC AMT 
ACCT_NRG_OCC            NREG OCC DSCT AMT 
ACCT_DSCT_OCC           REG OCC DSCT AMT 
ACCT_MCC                MCC AMT 
ACCT_NRG_MCC            NREG MCC DSCT AMT 
ACCT_DSCT_MCC           REG MCC DSCT AMT 
ACCT_MNTH_SRV_AMT       LOCL SRV AMT 
ACCT_FED_ACCES_AMT      FED ACES AMT 
ACCT_TOT_TOLL           TOLL-AMT + MU-AMT + OPTL-PLAN-AMT 
ACCT_TOT_DSCT_TOLL      REG USG DSCT AMT + NREG USG DSCT 
ACCT_ZONE1_AMT          BOC ZUM 1 TOT AMT 
ACCT_ZONE1_CT           BOC ZUM 1 MSG CT 
ACCT_ZONE1_MOU          BOC_ ZUM 1 TOT MINS 
ACCT_ZONE23_AMT         BOC ZUM 23 TOT AMT 
ACCT_ZONE23_CT          BOC ZUM 23 MSG CT 
ACCT_ZONE23_MOU         BOC_ ZUM 23 TOT MINS 
ACCT_TOT_TOLL_AMT       TOLL-AMT + OPTL-PLAN-AMT  
ACCT_DA_AMT             DA_AMT 
ACCT_DA_CT              BOC 411 DA MSG CT 
ACCT_IEC_CHRG           IEC_CHRG 
ACCT_900_CALL_CHRG      CUR INFO SRV AMT 
ACCT_FED_TAX            FED TAX 
ACCT_STATE_TAX          ST TAX 
ACCT_CITY_TAX           CITY TAX 
ACCT_BLG_SRCHG          BLG SRCG AMT 
ACCT_HCAP_SRCHG         HCAP SRCG AMT 
ACCT_LFLN_SRCHG         LFLN SRCG AMT 
ACCT_CPUC_SRCHG         CPUC SRCG AMT 
ACCT_CHCFA_SRCHG        CHCFA SRCG AMT 
ACCT_CHCFB_SRCHG        CHCFB SRCG AMT 
ACCT_USSC_SRCHG         USSC SRCG AMT 
ACCT_LPC_AMT            CURR-LPC-AMT + PREV-LPC-AMT  
ACCT_CTF_SRCHG          CTF SRCG AMT 
ACCT_ATT_SRCHG          ATT AMT 
ACCT_SRV_USFF_AMT       MNTY SRV USFF AMT 
    
******************************************************************************/

public class RabcAcctDetailLoad extends FileDBLoadJob {

	private String location;
	private String region;
	private int cycle;
	private int cntl_pt;
	private String bill_rnd;
	private File currentFile;
	private HashMap crocd_division;
	private String currRecord;
	private String prevRecord;
	private Set DivSet;
    
    
    
	private String run_date, bill_rnd_dt;
	private java.sql.Date sqlrun_date;
	private String maillist;
	private String bac_home;
	private String to_address;

	private PreparedStatement insert_acct_blg_dtl;
	private PreparedStatement insert_acct_blg_dtl_update_rank;
	private PreparedStatement delete_acct_blg_dtl_avg;
	private PreparedStatement insert_acct_blg_dtl_avg;
	private PreparedStatement insert_acct_info;

	private String backoutRecovery = null;
	private boolean billdayFile;
	
	private String fileName, fileToken;

	public boolean configure(
		Application application,
		Properties configuration) {

		to_address = configuration.getProperty(StaticFieldKeys.STATUS_TO_ADDRESS);

		boolean result = super.configure(application, configuration);
		return result;
	}

	public boolean preprocess() {
		super.preprocess();

		try {
			insert_acct_blg_dtl =
				connection.prepareStatement(
					StaticInsertSQLQuerys.INSERT_RABC_ACCT_BLG_DTL());
			insert_acct_blg_dtl_update_rank =
				connection.prepareStatement(
					StaticInsertSQLQuerys.INSERT_RABC_ACCT_BLG_DTL_WITH_RANK());		
			delete_acct_blg_dtl_avg =
				connection.prepareStatement("Delete from RABC_ACCT_BLG_DTL_AVG where DIVISION = ? and BTN = ? and CTCUSTID = ? and CNTL_PT = ?");
			insert_acct_blg_dtl_avg =
				connection.prepareStatement(
					StaticInsertSQLQuerys.INSERT_RABC_ACCT_BLG_DTL_AVG());
			insert_acct_info =
				connection.prepareStatement(
					StaticInsertSQLQuerys.INSERT_RABC_ACCT_INFO());				
		} catch (SQLException e) {
			severe(StaticErrorMsgKeys.PREPROCESS_ERROR + e.getMessage());
			return false;
		}
		return true;
	}

	public boolean postprocess(boolean success) {
		
		try {
			
			insert_acct_blg_dtl.close();
			insert_acct_info.close();
			insert_acct_blg_dtl_avg.close();
			delete_acct_blg_dtl_avg.close();
			
			} catch (SQLException e) {
			severe(StaticErrorMsgKeys.POSTPROCESS_ERROR + e.getMessage());
			success = false;
		}
		
		return super.postprocess(success);
	}

	public boolean preprocessFile(File file) {
		boolean success = super.preprocessFile(file);
		billdayFile = true;
		fileName = file.getName();
		fileToken = file.getName().substring(11,19);
		
		if (success) {
		    try{
				region   =	file.getName().substring(0,2);
			    location =	file.getName().charAt(3) == StaticFieldKeys.C
							? StaticFieldKeys.LOCATION_N
							: StaticFieldKeys.LOCATION_S;
				cycle    = Integer.parseInt(file.getName().substring(6, 10));
				
				run_date = RetrieveStaticInfo.getProc_dtByCycle(connection, cycle);
				bill_rnd_dt = RetrieveStaticInfo.getbillRndDt_ByCycle(connection, cycle);
				if (run_date.equals(StaticFieldKeys.ZERO)){
					severe(StaticErrorMsgKeys.NORECORD_RABC_CYCLE_CALENDAR + cycle);
					throw new Exception();	
				}
				
				
				DateFormat df = new SimpleDateFormat("MMddyyyy");
				sqlrun_date = new java.sql.Date(df.parse(run_date).getTime());
				currentFile = file;
				DivSet = new HashSet();
					
				if (file.getName().indexOf(StaticFieldKeys.FILEID_CRIS) != -1)
					cntl_pt = 1;
				else if (file.getName().indexOf(StaticFieldKeys.FILEID_BDYT) != -1)
					cntl_pt = 2;
				else{
					throw new Exception("");
				}	
				String tableNm = null;
				if (RabcLoadJobTrig.IsFileLoaded(connection,file)){
					backoutRecovery = "Y";
					if (location.equals("N")){
						tableNm = "RABC_ACCT_BLG_DTL";
						success = PrepareTableForRerun.deleteTableData(connection,tableNm,"PN",sqlrun_date);
						success = PrepareTableForRerun.deleteTableData(connection,tableNm,"NB",sqlrun_date);
						tableNm = "RABC_ACCT_BLG_DTL_AVG";
						success = PrepareTableForRerun.deleteTableData(connection,tableNm,"PN",sqlrun_date);
						success = PrepareTableForRerun.deleteTableData(connection,tableNm,"NB",sqlrun_date);
					}else {
						// location.equals("S")
						tableNm = "RABC_ACCT_BLG_DTL";
						success = PrepareTableForRerun.deleteTableData(connection,tableNm,"PS",sqlrun_date);
						tableNm = "RABC_ACCT_BLG_DTL_AVG";
						success = PrepareTableForRerun.deleteTableData(connection,tableNm,"PS",sqlrun_date);
					}
					//	severe(StaticErrorMsgKeys.DUPLICATE_FILE);
					//   return false;
				}
			
			}catch(Exception e){
				severe(StaticErrorMsgKeys.PREPROCESSFILE_ERROR + StaticErrorMsgKeys.FILE_NAME_PARSING_ERROR + e);
				return false;
			}
		}

		try {
			
			crocd_division  = RetrieveStaticInfo.getCrocd_Divsion(connection,region.trim());	
			bill_rnd 		= RetrieveStaticInfo.getBillRndByCycle(connection,cycle).trim();
			if (bill_rnd.equals(StaticFieldKeys.ZERO) || bill_rnd.equals(StaticFieldKeys.ZERO2)){
				billdayFile = false;
			}
			
			
			
		} catch (SQLException e) {
			success = false;
			severe(StaticErrorMsgKeys.PREPROCESSFILE_ERROR+":"+"No Bill Round/No CroCode Division" + e.getMessage());
		}

		return success;
	}

	public boolean postprocessFile(File file, boolean success) {
		try{
			//Log the file information to EMCIS_EVENT_LOG and EMCIS_EVENT_LOG_DETAIL
			EmcisEventLogger emcisLogger = new EmcisEventLogger();
			String event_id = "RABC_"+fileToken+"_"+region;
            String host = NetUtil.getLocalHostName();
            String hostIP = NetUtil.getLocalIpAddress();
			int sequence = emcisLogger.getEMCISSequence(connection);
			emcisLogger.insertEventLog(connection, sequence, event_id, sqlrun_date, host, hostIP);
			emcisLogger.insertEventLogDetail(connection, sequence, "FileName", fileName);
			
		}catch (UnknownHostException e) {
            severe("Error getting EMCIS host information ", e);
        }
		
		if (success){
        	   Iterator it = DivSet.iterator();
			   while (it.hasNext()&&(success)){
				   if(!updateRankInSumyTable((String)it.next()))
				   success = false;
			   }
			   
			if (success){
        	   String deleteQuery = "Delete from RABC_ACCT_BLG_DTL where ranking = 0";
			    try {
					Statement delStatement = connection.createStatement();
					delStatement.executeUpdate(deleteQuery);
				} catch (SQLException e) {
				  severe(deleteQuery + " : "+ e.getMessage());
			 	  return false;
				}
		
			}
		}
        
        if (success){
		  //Insert into Trigger Table only if Bill round exists.
          if (billdayFile)
       		if(!insertTrigger()){
				severe(StaticErrorMsgKeys.POSTPROCESSFILE_ERROR + StaticErrorMsgKeys.TIGGER_TABLE_INSERT_ERROR);
				success = false;
			}
        }  
	
/*		//Re-Eng Logic:Following Code can be removed when Re-Eng Logic is Removed
		
		if (success){
       
			 if (!CreateAcctFileTemp
				  .createAcctFile(connection,cntl_pt,run_date,currentFile.getName())) {
						  
		   	  String message = "Re-Eng Job Failed for " + currentFile.getName();
			  Email.sendEmail(
							  to_address,
							  "CARATNotify@att.com",
							  "Background Re Eng File Creation Job Failed",
							  message);
			  success = false;		  
			  severe("Error Occured in while Re-Eng the File");	  
			  }
		}
		//Re-Eng Logic:Remove till here
*/		
		if (!success) {
			Email.sendEmail(
							to_address,
							StaticFieldKeys.FROM_ADDRESS,
							StaticFieldKeys.SUBJECT_LINE,
							StaticErrorMsgKeys.XT10XT12_ERROR_MESSAGE);
		}	
					
		return super.postprocessFile(file, success);
	}

	
	
	private boolean updateRankInSumyTable(String divi) {
		PreparedStatement clscdStatement = null;
		ResultSet clsRs = null;
		String s = "";
		String query = "select distinct acct_cls_cd from rabc_acct_blg_dtl where division = '"+ divi+"' and cycle="+cycle;
		try {
			clscdStatement = connection.prepareStatement(query);
			clsRs = clscdStatement.executeQuery();

					while (clsRs.next()) {
						
						if(!insertWithRank(clsRs.getInt(1),divi)){
							clsRs.close();
							clscdStatement.close();
							return false;	
						  }

					}

			clsRs.close();
			clscdStatement.close();

		} catch (SQLException e) {
			severe(query + " : "+ e.getMessage());
			return false;
		}
		
		return true;
	}
	
	
	
	private boolean insertWithRank(int clscd, String divi) {
		
		try {
		
			insert_acct_blg_dtl_update_rank.setString(1,divi.trim());
			insert_acct_blg_dtl_update_rank.setInt(2,clscd);
			insert_acct_blg_dtl_update_rank.setInt(3,cycle);
			insert_acct_blg_dtl_update_rank.setInt(4,cntl_pt);
			insert_acct_blg_dtl_update_rank.execute();
		
		} catch (SQLException e) {
			severe(StaticInsertSQLQuerys.INSERT_RABC_ACCT_BLG_DTL_WITH_RANK() + " : "+ e.getMessage());
			return false;
		}
		
		return true;
	}

	

	private boolean insertTrigger() {

		Iterator it = DivSet.iterator();
			   while (it.hasNext()){
				 if(!RabcLoadJobTrig.insertTrigger(connection,currentFile.getName(),currentFile.getName().substring(11,15),(String)it.next(),run_date,backoutRecovery,bill_rnd)){
				    return false;	
				 }
			   }
   		return true;
    }
  

	public int parseLine(String line) throws Exception {
		
		if (line.length() < 10)
			return SKIPPED;

		try{
		
		StringTokenizer SummaryLine = 	new StringTokenizer(line, StaticFieldKeys.SEMICOLON);
		
		String Record_Id	 = SummaryLine.nextToken().trim();//1
		
		if ((!Record_Id.equals(StaticFieldKeys.RECORD_CRIS)) && (!Record_Id.equals(StaticFieldKeys.RECORD_BDYT))){
			severe(StaticErrorMsgKeys.INVAID_RECORD_TYPE + Record_Id);
			throw new Exception();	
		}
		String ctcusid   = SummaryLine.nextToken().trim().substring(1);//2
		if 	(ctcusid.equals("000000000000"))
		return SKIPPED;				
        String crocd 	 = SummaryLine.nextToken().trim();//3
        String div 		 = (String) crocd_division.get(crocd);
		if (div == null){
          severe(StaticErrorMsgKeys.NORECORD_RABC_CRO_CD_DIVISION + crocd);
		  throw new Exception();	
		}
		DivSet.add(div);
		String btn 		 = SummaryLine.nextToken().trim()+SummaryLine.nextToken().trim()+SummaryLine.nextToken().trim();//4, 5, 6
		
		String classcd   = SummaryLine.nextToken().trim();//7
		String acctName  = SummaryLine.nextToken().trim();//8
		String activeInd = SummaryLine.nextToken().trim();//9
		
		insert_acct_blg_dtl.setString(1, div);
		insert_acct_blg_dtl.setDate  (2, sqlrun_date);
		insert_acct_blg_dtl.setInt	 (3, cycle);
		insert_acct_blg_dtl.setInt	 (4, cntl_pt);
		insert_acct_blg_dtl.setString(5, btn);
		insert_acct_blg_dtl.setString(6, ctcusid);
		insert_acct_blg_dtl.setInt	 (7, 0);
		insert_acct_blg_dtl.setString(8, bill_rnd);
		insert_acct_blg_dtl.setString(9, classcd);
		
		String ignore = SummaryLine.nextToken().trim();//10
		
		double curr_mth_chrg = Double.parseDouble(SummaryLine.nextToken().trim())/1000000;//11
		double bal_due_amt   = Double.parseDouble(SummaryLine.nextToken().trim())/1000000;//12
		double tot_blg_chrgs = curr_mth_chrg + bal_due_amt;
		
		insert_acct_blg_dtl.setDouble(10,tot_blg_chrgs);
		insert_acct_blg_dtl.setDouble(11,curr_mth_chrg);
		
		double adj_amt       = Double.parseDouble(SummaryLine.nextToken().trim())/1000000;//13
		double pymt_amt      = Double.parseDouble(SummaryLine.nextToken().trim())/1000000;//14
		insert_acct_blg_dtl.setDouble(12,pymt_amt);
		insert_acct_blg_dtl.setDouble(13,bal_due_amt);
		insert_acct_blg_dtl.setDouble(14,adj_amt);
		
		double ocs_bal_tr_amt = Double.parseDouble(SummaryLine.nextToken().trim())/1000000;//15
		double bal_tr_amt     = Double.parseDouble(SummaryLine.nextToken().trim())/1000000;//16
		double otr_bal_adj    = ocs_bal_tr_amt + bal_tr_amt;
		
		insert_acct_blg_dtl.setDouble(15,otr_bal_adj);
				
		insert_acct_blg_dtl.setDouble(16,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);//ACCT_OCC //17
		insert_acct_blg_dtl.setDouble(18,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);//ACCT_DSCT_OCC //18
		insert_acct_blg_dtl.setDouble(17,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);//ACCT_NRG_OCC //19
		
		insert_acct_blg_dtl.setDouble(19,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);//ACCT_MCC //20
		insert_acct_blg_dtl.setDouble(21,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);//ACCT_DSCT_MCC //21
		insert_acct_blg_dtl.setDouble(20,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);//ACCT_NRG_MCC //22
		
		
		insert_acct_blg_dtl.setDouble(22,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);//ACCT_MNTH_SRV_AMT //23
		insert_acct_blg_dtl.setDouble(23,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);//ACCT_FED_ACCES_AMT //24
		
		double toll_amt 		 = Double.parseDouble(SummaryLine.nextToken().trim())/1000000; //25
		double mu_amt 			 = Double.parseDouble(SummaryLine.nextToken().trim())/1000000; //26
		double optnl_plan_amt	 = Double.parseDouble(SummaryLine.nextToken().trim())/1000000; //27
		double acct_tot_toll     = toll_amt + mu_amt + optnl_plan_amt;
		double acct_tot_toll_amt = toll_amt + optnl_plan_amt;
		
		insert_acct_blg_dtl.setDouble(24,acct_tot_toll);//ACCT_TOT_TOLL
		
		
		double usg_dsct_reg		= Double.parseDouble(SummaryLine.nextToken().trim())/1000000; //28
		double usg_dsct_nreg 	= Double.parseDouble(SummaryLine.nextToken().trim())/1000000; //29
		double acct_tot_dsct_toll = usg_dsct_reg + usg_dsct_nreg;
		insert_acct_blg_dtl.setDouble(25,acct_tot_dsct_toll);//ACCT_TOT_DSCT_TOLL
		
		/*Assigned At the end
		insert_acct_blg_dtl.setDouble(26,Double.parseDouble(SummaryLine.nextToken().trim()));
		insert_acct_blg_dtl.setInt	 (27,Integer.parseInt(SummaryLine.nextToken().trim()));
		insert_acct_blg_dtl.setInt	 (28,Integer.parseInt(SummaryLine.nextToken().trim()));
		
		insert_acct_blg_dtl.setDouble(29,Double.parseDouble(SummaryLine.nextToken().trim()));
		insert_acct_blg_dtl.setInt	 (30,Integer.parseInt(SummaryLine.nextToken().trim()));
		insert_acct_blg_dtl.setInt	 (31,Integer.parseInt(SummaryLine.nextToken().trim()));
		*/
		
		insert_acct_blg_dtl.setDouble(32,acct_tot_toll_amt);//ACCT_TOT_TOLL_AMT
		
		insert_acct_blg_dtl.setDouble(33,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);//ACCT_DA_AMT //30
		
		/*
		insert_acct_blg_dtl.setDouble(34,Double.parseDouble(SummaryLine.nextToken().trim()));//ACCT_DA_CT
		*/
		
		insert_acct_blg_dtl.setDouble(35,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);//ACCT_IEC_CHRG //31
		/*
		insert_acct_blg_dtl.setDouble(36,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);//ACCT_900_CALL_CHRG
		*/		
		insert_acct_blg_dtl.setDouble(37,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);//ACCT_FED_TAX //32
		insert_acct_blg_dtl.setDouble(38,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);//ACCT_STATE_TAX //33
		insert_acct_blg_dtl.setDouble(39,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);//ACCT_CITY_TAX //34
		insert_acct_blg_dtl.setDouble(40,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);//ACCT_BLG_SRCHG //35
		insert_acct_blg_dtl.setDouble(41,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);//ACCT_HCAP_SRCHG //36
		insert_acct_blg_dtl.setDouble(42,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);//ACCT_LFLN_SRCHG //37
		insert_acct_blg_dtl.setDouble(43,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);//ACCT_CPUC_SRCHG //38
		insert_acct_blg_dtl.setDouble(44,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);//ACCT_CHCFA_SRCHG //39
		insert_acct_blg_dtl.setDouble(45,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);//ACCT_CHCFB_SRCHG //40
		insert_acct_blg_dtl.setDouble(46,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);//ACCT_USSC_SRCHG //41
		
		double lpc1 = Double.parseDouble(SummaryLine.nextToken().trim())/1000000; //42
		double lpc2 = Double.parseDouble(SummaryLine.nextToken().trim())/1000000; //43
		double lpc = lpc1+lpc2;
		insert_acct_blg_dtl.setDouble(47,lpc);//ACCT_LPC_AMT
		
		insert_acct_blg_dtl.setDouble(49,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);//ACCT_ATT_SRCHG //44
		insert_acct_blg_dtl.setDouble(50,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);//ACCT_SRV_USFF_AMT //45
		insert_acct_blg_dtl.setString(51,bill_rnd_dt.substring(0,2));
		insert_acct_blg_dtl.setString(52,bill_rnd_dt.substring(4,8));
		
		insert_acct_blg_dtl.setDouble(48,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);//ACCT_CTF_SRCHG //46
		
		
        insert_acct_blg_dtl.setDouble(36,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);//ACCT_900_CALL_CHRG //47
        
		double sdUndergrdSrcgAmt		= Double.parseDouble(SummaryLine.nextToken().trim())/1000000; //48
		insert_acct_blg_dtl.setDouble(53,sdUndergrdSrcgAmt);//ACCT_SD_UNDERGRD_SRCHG
		
		int i = 1;
		while(i < 31){
		   ignore = SummaryLine.nextToken().trim(); //49 - 79
		   i++;
		}
	
			
		insert_acct_blg_dtl.setDouble(26,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);//ACCT_ZONE1_AMT //80
		insert_acct_blg_dtl.setLong	 (27,Long.parseLong(SummaryLine.nextToken().trim())/1000000);//ACCT_ZONE1_CT //81
		insert_acct_blg_dtl.setLong	 (28,Long.parseLong(SummaryLine.nextToken().trim())/1000000);//ACCT_ZONE1_MOU //82
		
		insert_acct_blg_dtl.setDouble(29,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);//ACCT_ZONE23_AMT //83
		insert_acct_blg_dtl.setLong	 (30,Long.parseLong(SummaryLine.nextToken().trim())/1000000);//ACCT_ZONE23_CT //84
		insert_acct_blg_dtl.setLong	 (31,Long.parseLong(SummaryLine.nextToken().trim())/1000000);//ACCT_ZONE23_MOU //85
		
		insert_acct_blg_dtl.setLong   (34,Long.parseLong(SummaryLine.nextToken().trim())/1000000);//ACCT_DA_CT //86
		

						
		insert_acct_blg_dtl.execute();
		
		if(!bill_rnd.equals(StaticFieldKeys.ZERO)){
			
			delete_acct_blg_dtl_avg.setString(1,div);
			delete_acct_blg_dtl_avg.setString(2,btn);
			delete_acct_blg_dtl_avg.setString(3,ctcusid);
			delete_acct_blg_dtl_avg.setInt(4,cntl_pt);
		
			delete_acct_blg_dtl_avg.execute();
		
			insert_acct_blg_dtl_avg.setString(1,div);
			insert_acct_blg_dtl_avg.setString(2,btn);
			insert_acct_blg_dtl_avg.setString(3,ctcusid);
			insert_acct_blg_dtl_avg.setInt(4,cntl_pt);
		
			insert_acct_blg_dtl_avg.execute();
		}
		
		
		if (!RetrieveStaticInfo.IsAcctInfoExists(connection,btn,ctcusid)){
		
			insert_acct_info.setString(1,btn);
			insert_acct_info.setString(2,ctcusid);
			insert_acct_info.setString(3,acctName);
			insert_acct_info.setString(4,classcd);
			insert_acct_info.setString(5,activeInd);
			insert_acct_info.setString(6,crocd);
		   
			insert_acct_info.execute();
		}
		
		}catch(SQLException e){
			severe(StaticErrorMsgKeys.PARSELINE_ERROR + e.toString());
			throw new SQLException();	
		
		}catch (Exception e) {
			severe(StaticErrorMsgKeys.PARSELINE_ERROR + e.toString());
			throw new Exception();	
		}
		
		return SUCCESS;
	}

	public boolean accept(File file) {
		
		boolean ret = false;
		long a= file.length();
		char b = file.getName().charAt(3);
		int c = file.getName().indexOf(StaticFieldKeys.FILEID_CRIS);
		
		if(((file.getName().charAt(3) == StaticFieldKeys.C)
				|| (file.getName().charAt(3) == StaticFieldKeys.I))
				&& ((file.getName().indexOf(StaticFieldKeys.FILEID_CRIS) != -1)
					|| (file.getName().indexOf(StaticFieldKeys.FILEID_BDYT) != -1))
				&& (file.length() > 0)) 
		ret = true;
        
        return ret;
	}

}
