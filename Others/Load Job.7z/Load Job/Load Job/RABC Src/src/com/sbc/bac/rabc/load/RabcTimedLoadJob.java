package com.sbc.bac.rabc.load;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Properties;
//changes for M168 by as635b
//import com.sbc.bac.load.Application;
//import com.sbc.bac.load.DBLoadJob;
import com.att.carat.load.Application;
import com.att.carat.load.DBLoadJob;

public abstract class RabcTimedLoadJob extends DBLoadJob{
	
    // default interval of time before job will run again (in minutes)
    protected static final int DEFAULT_CHECK_TIME_INTERVAL = 1;
    protected Calendar runtime = Calendar.getInstance();
    protected Calendar endtime = Calendar.getInstance();
    protected String initialRunTime = null;
    protected Properties config = null;
    
    protected SimpleDateFormat df = new SimpleDateFormat("HH:mm");
    protected int runInterval = DEFAULT_CHECK_TIME_INTERVAL;
    

    protected boolean check() {
        debug("check runtime: " + runtime.getTime());
        debug("check endtime: " + endtime.getTime());
        Calendar now = Calendar.getInstance();
        return now.after(runtime);
    }

    
    protected boolean configure(Application application, Properties configuration) {
    	
        boolean success = super.configure(application, configuration);
        String intervalProperty = configuration.getProperty("run_interval");
        String timeProperty = configuration.getProperty("runtime");
        String endTimeProperty = configuration.getProperty("endtime");
        initialRunTime = timeProperty;
        config = configuration;

        if (timeProperty == null || endTimeProperty == null) {
            return false;
        }
        try {
            runtime.setTime(df.parse(timeProperty));
        }
        catch (ParseException e) {
            severe("runtime entry could not be parsed.");
            return false;
        }
        try {
            endtime.setTime(df.parse(endTimeProperty));
        }
        catch (ParseException e1) {
            severe("endtime entry could not be parsed.");
            return false;
        }
        if (intervalProperty == null) {
            runInterval = DEFAULT_CHECK_TIME_INTERVAL;
        }
        else {
            runInterval = Integer.parseInt(intervalProperty);
        }
        Calendar now = Calendar.getInstance();
        runtime.set(now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DATE));
        if (now.after(runtime))
            runtime.add(Calendar.DATE, 1);
        endtime.set(now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DATE));
        if (now.after(endtime))
            endtime.add(Calendar.DATE, 1);
        return success;
    }


    protected boolean postprocess(boolean success) {
        // if runtime exceeds the endtime, then set both runtime and endtime to the next day
        if (runtime.equals(endtime) || runtime.after(endtime)) {
            try {
                runtime.setTime(df.parse(initialRunTime));
                runtime.set(endtime.get(Calendar.YEAR), endtime.get(Calendar.MONTH), endtime.get(Calendar.DATE) + 1);
                endtime.set(endtime.get(Calendar.YEAR), endtime.get(Calendar.MONTH), endtime.get(Calendar.DATE) + 1);
                info("Job is scheduled to run again at " + runtime.getTime());
            }
            catch (ParseException e) {
                severe("runtime entry could not be parsed.");
                return false;
            }
        }
        // otherwise, set next runtime to current runtime + interval (default is 1 min)
        else {
            runtime.add(Calendar.MINUTE, runInterval);
            info("Job will double-check at " + runtime.getTime());
        }
        return super.postprocess(success);
    }
}
