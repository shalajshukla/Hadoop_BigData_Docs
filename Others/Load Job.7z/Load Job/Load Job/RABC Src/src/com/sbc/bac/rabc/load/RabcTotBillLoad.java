/*
 * Created on May 31, 2005
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package com.sbc.bac.rabc.load;
import java.io.File;
import java.net.UnknownHostException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;
import java.util.StringTokenizer;

import com.att.bac.rabc.util.EmcisEventLogger;
import com.att.bac.util.NetUtil;
import com.att.carat.util.Email;
//changes for M168 by as635b
import com.att.carat.load.Application;
import com.att.carat.load.FileDBLoadJob;
//import com.sbc.bac.load.Application;
//import com.sbc.bac.load.FileDBLoadJob;

/******************************************************************************
 * @author sr8948
 *
 * Class Name : RabcTotBillLoad
 * Progam Id  : RABCPPG00321
 * Author     : Srikanth Reddy
 * Purpose    : Loadjob for following input filenames
 *               re.x.Cxxxx.XT11SUMY.TIMESTAMP.TXT
 *               012345678901234567890123456789012  
 *              Also loads the Trigger Table.
 * Assumptions:
 * 
 * Comments	  :
 *  	    
 ******************************************************************************/
/*------------------------------------------------------------------------------
Modification History

Date		Version		Author			Description
----------	-----------	--------------- ----------------------------------------
12-10-2010	1.0			ss1644			Changes done for Q-FIX 10-63
										1.Added ACCT_CLS_CD and ACCT_ACTIVE_IND in
										 INSERT_RABC_TOP_TEN_BLG_ACCT query
						dp111r			2. changes done to insert data in RABC_TRIG TABLE
										   when bill round is '0' or '00'
------------------------------------------------------------------------------*/

public class RabcTotBillLoad  extends FileDBLoadJob {
	    
	    private String location;
		private int cycle;
	
		private String bill_rnd;
		private File currentFile;

		private String run_date, bill_rnd_dt;
		private java.sql.Date sqlrun_date;
		private String maillist;
		private String bac_home;
		private String to_address;
		private HashMap crocd_division;
		private String region;
	    private int rank;
		private Set divSet;
	    private String prev_div  = StaticFieldKeys.EMPTY;
		
		private PreparedStatement insert_top_ten_blg_acct;
		private PreparedStatement insert_tot_blg_sumy;
		private PreparedStatement insert_acct_info;
		
		private String backoutRecovery = null;
		 private boolean billdayFile;
		private String fileName, fileToken;

		public boolean configure(
			Application application,
			Properties configuration) {

			//maillist = configuration.getProperty(StaticFieldKeys.MAILLIST);
			//bac_home = configuration.getProperty(StaticFieldKeys.BAC_HOME);
			to_address = configuration.getProperty(StaticFieldKeys.STATUS_TO_ADDRESS);

			boolean result = super.configure(application, configuration);
			return result;
		}

		public boolean preprocess() {
			super.preprocess();

			try {
				insert_top_ten_blg_acct =
					connection.prepareStatement(
						StaticInsertSQLQuerys.INSERT_RABC_TOP_TEN_BLG_ACCT());
				insert_tot_blg_sumy =
					connection.prepareStatement(
						StaticInsertSQLQuerys.INSERT_RABC_TOT_BLG_SUMY());		
				insert_acct_info =
								connection.prepareStatement(
									StaticInsertSQLQuerys.INSERT_RABC_ACCT_INFO());				
	
			} catch (SQLException e) {
				severe(StaticErrorMsgKeys.PREPROCESS_ERROR + e.getMessage());
				return false;
			}
			return true;
		}

		public boolean postprocess(boolean success) {
		
			try {
			
				insert_top_ten_blg_acct.close();
				insert_tot_blg_sumy.close();
				insert_acct_info.close();
			
				} catch (SQLException e) {
				severe(StaticErrorMsgKeys.POSTPROCESS_ERROR + e.getMessage());
				success = false;
			}
		
			return super.postprocess(success);
		}

		public boolean preprocessFile(File file) {
			boolean success = super.preprocessFile(file);
			billdayFile = true;
			fileName = file.getName();
			fileToken = file.getName().substring(11,19);
			
			if (success) {
				try{
			
					region   =	file.getName().substring(0,2);
			   	
					location =	file.getName().charAt(3) == StaticFieldKeys.C
								? StaticFieldKeys.LOCATION_N
								: StaticFieldKeys.LOCATION_S;
					cycle    = Integer.parseInt(file.getName().substring(6, 10));
					
					run_date = RetrieveStaticInfo.getProc_dtByCycle(connection, cycle);
					bill_rnd_dt = RetrieveStaticInfo.getbillRndDt_ByCycle(connection, cycle);
					
					if (run_date.equals(StaticFieldKeys.ZERO)){
						severe(StaticErrorMsgKeys.NORECORD_RABC_CYCLE_CALENDAR + cycle);
						throw new Exception();	
					}
					
					DateFormat df = new SimpleDateFormat("MMddyyyy");
					sqlrun_date = new java.sql.Date(df.parse(run_date).getTime());
					
					currentFile = file;
					rank = 0;
					divSet = new HashSet();
					
					String tableNm = null;
					if (RabcLoadJobTrig.IsFileLoaded(connection,file)){
						//severe(StaticErrorMsgKeys.DUPLICATE_FILE);
					   //return false;
						backoutRecovery = "Y";
						if (location.equals("N")){
							tableNm = "RABC_TOP_TEN_BLG_ACCT";
							success = PrepareTableForRerun.deleteTableData(connection,tableNm,"PN",sqlrun_date);
							success = PrepareTableForRerun.deleteTableData(connection,tableNm,"NB",sqlrun_date);
							tableNm = "RABC_TOT_BLG_SUMY";
							success = PrepareTableForRerun.deleteTableData(connection,tableNm,"PN",sqlrun_date);
							success = PrepareTableForRerun.deleteTableData(connection,tableNm,"NB",sqlrun_date);
						}else {
							// location.equals("S")
							tableNm = "RABC_TOP_TEN_BLG_ACCT";
							success = PrepareTableForRerun.deleteTableData(connection,tableNm,"PS",sqlrun_date);
							tableNm = "RABC_TOT_BLG_SUMY";
							success = PrepareTableForRerun.deleteTableData(connection,tableNm,"PS",sqlrun_date);
						}
					}
					
				}catch(Exception e){
					severe(StaticErrorMsgKeys.PREPROCESSFILE_ERROR + StaticErrorMsgKeys.FILE_NAME_PARSING_ERROR + e);
					return false;
				}
			}

			try {
				
			bill_rnd = RetrieveStaticInfo.getBillRndByCycle(connection,cycle);
			if (bill_rnd.equals(StaticFieldKeys.ZERO)|| bill_rnd.equals(StaticFieldKeys.ZERO2)){
				billdayFile = true;
			}
			
			crocd_division  = RetrieveStaticInfo.getCrocd_Divsion(connection,region.trim());
			
			} catch (SQLException e) {
				success = false;
				severe(StaticErrorMsgKeys.PREPROCESSFILE_ERROR + e.getMessage());
			}

			return success;
		}

		public boolean postprocessFile(File file, boolean success) {
			try{
				//Log the file information to EMCIS_EVENT_LOG and EMCIS_EVENT_LOG_DETAIL
				EmcisEventLogger emcisLogger = new EmcisEventLogger();
				String event_id = "RABC_"+fileToken+"_"+region;
	            String host = NetUtil.getLocalHostName();
	            String hostIP = NetUtil.getLocalIpAddress();
				int sequence = emcisLogger.getEMCISSequence(connection);
				emcisLogger.insertEventLog(connection, sequence, event_id, sqlrun_date, host, hostIP);
				emcisLogger.insertEventLogDetail(connection, sequence, "FileName", fileName);
			
			}catch (UnknownHostException e) {
	            severe("Error getting EMCIS host information ", e);
	        }
		
        
			if (success){
				//Insert into Trigger Table only if Bill round exists.

				if (billdayFile)
					if(!insertTrigger()){
						severe(StaticErrorMsgKeys.POSTPROCESSFILE_ERROR + StaticErrorMsgKeys.TIGGER_TABLE_INSERT_ERROR);
						success = false;
					}
				
/*				//Re-Eng Logic:Following Code can be removed when Re-Eng Logic is Removed
				if (!CreateRankFileTemp
						  .createSummaryFile(connection,currentFile.getName(),bill_rnd,run_date,cycle)) {
						  
						  String message = "Re-Eng Job Failed for " + currentFile.getName();
						  Email.sendEmail(
										  to_address,
										  "CARATNotify@att.com",
										  "Background Re Eng File Creation Job Failed",
										  message);
						  success = false;		  
						  severe("Error Occured in while Re-Eng the File");	  
				}
				//Re-Eng Logic:Remove till here
*/		    
		    }
			
			
			if (!success) {
				Email.sendEmail(
								to_address,
								StaticFieldKeys.FROM_ADDRESS,
								StaticFieldKeys.SUBJECT_LINE,
								StaticErrorMsgKeys.XT11_ERROR_MESSAGE);
			}	
					
			return super.postprocessFile(file, success);
		}

		/**
		 * 
		 */
		private boolean insertTrigger() {
                
            Iterator I = divSet.iterator();
			while (I.hasNext()) {
			  String divi = (String)I.next();
			  if(!RabcLoadJobTrig.insertTrigger(connection,currentFile.getName(),"XT11T001",divi,run_date,backoutRecovery,bill_rnd)){
			 	return false;	
			  }
			  if(!RabcLoadJobTrig.insertTrigger(connection,currentFile.getName(),"XT11",divi,run_date,backoutRecovery,bill_rnd)){
				return false;	
			  }
			}
			return true;
		}

		public int parseLine(String line) throws Exception {
			
			String Record_Id = StaticFieldKeys.EMPTY;
			String bus_type  = StaticFieldKeys.EMPTY;
			String crocd 	 = StaticFieldKeys.EMPTY;
			String div 		 = StaticFieldKeys.EMPTY;
			
			
			if (line.length() < 10)
				return SKIPPED;

		    try{
		    	
			StringTokenizer SummaryLine = 	new StringTokenizer(line, StaticFieldKeys.SEMICOLON);
			
			Record_Id = SummaryLine.nextToken().trim(); //1
			crocd = SummaryLine.nextToken().trim(); //2
			
			// Temporary fix until MVS fixes the Null crocd for Nevada Bell
			if (crocd.equals("")){
				if (location.equals("N"))
					crocd = "D";
				else return SUCCESS;
			}
			//Temporary fix until MVS fixes the Null crocd for Nevada Bell
			
			div   = (String)crocd_division.get(crocd);
			
			if (div == null){
				severe(StaticErrorMsgKeys.NORECORD_RABC_CRO_CD_DIVISION + crocd);
				throw new Exception();	
			}
			divSet.add((String)div);
			
			if (Record_Id.equals(StaticFieldKeys.RECORD_TOPTEN)){
			
				String acctName   =  SummaryLine.nextToken().trim(); //3
				
				insert_top_ten_blg_acct.setString(1,div);
				insert_top_ten_blg_acct.setDate(2,sqlrun_date);
				insert_top_ten_blg_acct.setInt(3,cycle);
				insert_top_ten_blg_acct.setInt(4,Integer.parseInt(bill_rnd));
				
				if(div.equals(prev_div))rank = rank+1;
				else rank = 1;
				prev_div = div;
				
				insert_top_ten_blg_acct.setInt(5,rank);
				
				String btn = SummaryLine.nextToken().trim()+SummaryLine.nextToken().trim()+SummaryLine.nextToken().trim(); //4, 5, 6
				insert_top_ten_blg_acct.setString(6,btn);
				
				
				String ctcusid   = SummaryLine.nextToken().trim().substring(1); //7
				String classcd   = SummaryLine.nextToken().trim(); //8
				String activeInd = SummaryLine.nextToken().trim(); //9
				
				String Ignore    = SummaryLine.nextToken().trim(); //10
				
				insert_top_ten_blg_acct.setDouble(7,Double.parseDouble(SummaryLine.nextToken().trim())/1000000); //11
				insert_top_ten_blg_acct.setDouble(8,Double.parseDouble(SummaryLine.nextToken().trim())/1000000); //12
				insert_top_ten_blg_acct.setString(9,bill_rnd_dt.substring(0,2));
				insert_top_ten_blg_acct.setString(10,bill_rnd_dt.substring(4,8));
				insert_top_ten_blg_acct.setString(11,classcd);
				insert_top_ten_blg_acct.setString(12,activeInd);
			    
			    insert_top_ten_blg_acct.execute();
			    
			    
				if (!RetrieveStaticInfo.IsAcctInfoExists(connection,btn,ctcusid)){
		
					insert_acct_info.setString(1,btn);
					insert_acct_info.setString(2,ctcusid);
					insert_acct_info.setString(3,acctName);
					insert_acct_info.setString(4,classcd);
					insert_acct_info.setString(5,activeInd);
					insert_acct_info.setString(6,crocd);
		   
					insert_acct_info.execute();
				}
			  
			    
			
			}else if ((Record_Id.equals(StaticFieldKeys.RECORD_RESIDENCE))  ||
					  (Record_Id.equals(StaticFieldKeys.RECORD_BUSINESS))  || 
					  (Record_Id.equals(StaticFieldKeys.RECORD_RESALERES)) || 
					  (Record_Id.equals(StaticFieldKeys.RECORD_RESALEBUS)) || 
					  (Record_Id.equals(StaticFieldKeys.RECORD_FINAL))) {
					
			  	
			  	bus_type = Record_Id.substring(5,8);

			  	// The following change was requested by Kin to add S to RRE or RBU .. more readable? 
			  	//for resale residential (RRES) & resale business ( RBUS )
			  	
			  	if (bus_type.equals("RRE")||bus_type.equals("RBU")) bus_type += "S";
			  	
				/*
				INSERT INTO RABC_TOT_BLG_SUMY(1DIVISION,2RUN_DATE,3CYCLE,4BILL_RND,5BUS_TYPE,
				6BAL_DUE_AMT,7CURR_BLG_AMT,8TOLL_AMT,9OCC_AMT,0BOC_AMT,11ATT_AMT,12IEC_AMT,13TAX_SURCH_AMT,
				14FED_TAX_AMT,15CITY_TAX_AMT,16ST_TAX_AMT,17MNTY_USFF_AMT,18EUCL_CHG_AMT,19ACCT_CT,20TIME_STAMP)
				*/
				insert_tot_blg_sumy.setString(1,div);
				insert_tot_blg_sumy.setDate	 (2,sqlrun_date);
				insert_tot_blg_sumy.setInt	 (3,cycle);
				insert_tot_blg_sumy.setInt	 (4,Integer.parseInt(bill_rnd));
				insert_tot_blg_sumy.setString(5,bus_type);
				
				insert_tot_blg_sumy.setDouble(6,Double.parseDouble(reformat(SummaryLine.nextToken().trim()))); //13
				insert_tot_blg_sumy.setDouble(7,Double.parseDouble(reformat(SummaryLine.nextToken().trim()))); //14
				insert_tot_blg_sumy.setDouble(8,Double.parseDouble(reformat(SummaryLine.nextToken().trim()))); //15
				insert_tot_blg_sumy.setDouble(9,Double.parseDouble(reformat(SummaryLine.nextToken().trim()))); //16
				insert_tot_blg_sumy.setDouble(10,Double.parseDouble(reformat(SummaryLine.nextToken().trim()))); //17
				insert_tot_blg_sumy.setDouble(11,Double.parseDouble(reformat(SummaryLine.nextToken().trim()))); //18
				insert_tot_blg_sumy.setDouble(12,Double.parseDouble(reformat(SummaryLine.nextToken().trim()))); //19
				
				double cpuc          = Double.parseDouble(reformat(SummaryLine.nextToken().trim()));//20
				double fed_tax       = Double.parseDouble(reformat(SummaryLine.nextToken().trim()));//21
				double city_tax      = Double.parseDouble(reformat(SummaryLine.nextToken().trim()));//22
				double st_tax        = Double.parseDouble(reformat(SummaryLine.nextToken().trim()));//23
				double tax_surch_amt = cpuc+fed_tax+city_tax+st_tax;
				
				insert_tot_blg_sumy.setDouble(13,tax_surch_amt);
				insert_tot_blg_sumy.setDouble(14,fed_tax);
				insert_tot_blg_sumy.setDouble(15,city_tax);
				insert_tot_blg_sumy.setDouble(16,st_tax);
				
				insert_tot_blg_sumy.setDouble(17,Double.parseDouble(reformat(SummaryLine.nextToken().trim())));//24
				insert_tot_blg_sumy.setDouble(18,Double.parseDouble(reformat(SummaryLine.nextToken().trim())));//25
				
				double billingSurchargeAmt =  Double.parseDouble(reformat(SummaryLine.nextToken().trim()));//26
				double chcfaSurchargeAmt =  Double.parseDouble(reformat(SummaryLine.nextToken().trim()));//27
				double chcfbSurchargeAmt =  Double.parseDouble(reformat(SummaryLine.nextToken().trim()));//28
				double lifeLineSurchargeAmt =  Double.parseDouble(reformat(SummaryLine.nextToken().trim()));//29
				double hcapSurchargeAmt =  Double.parseDouble(reformat(SummaryLine.nextToken().trim()));//30
				double ctfSurchargeAmt =  Double.parseDouble(reformat(SummaryLine.nextToken().trim()));//31

				String ignore_cur_blg_amt = SummaryLine.nextToken().trim();//32
				
				insert_tot_blg_sumy.setDouble(19,Integer.parseInt(SummaryLine.nextToken().trim()));//33
				
				double lpcAmt =  Double.parseDouble(reformat(SummaryLine.nextToken().trim()));//34
				
				insert_tot_blg_sumy.setDate	 (20,new java.sql.Date(new java.util.Date().getTime()));
				
				insert_tot_blg_sumy.setString(21,bill_rnd_dt.substring(0,2));
				insert_tot_blg_sumy.setString(22,bill_rnd_dt.substring(4,8));

				//new fields added to XT11 part of release Phase 1 of RABC 
				// CA_BLG_SRCG_AMT,CHCFA_SRCG_AMT,CHCFB_SRCG_AMT,LIFE_LINE_SRCG_AMT,HCAP_SRCG_AMT,CTF_SRCG,LPC_AMT
				
				insert_tot_blg_sumy.setDouble(23,billingSurchargeAmt);
				insert_tot_blg_sumy.setDouble(24,chcfaSurchargeAmt);
				insert_tot_blg_sumy.setDouble(25,chcfbSurchargeAmt);
				insert_tot_blg_sumy.setDouble(26,lifeLineSurchargeAmt);
				insert_tot_blg_sumy.setDouble(27,hcapSurchargeAmt);
				insert_tot_blg_sumy.setDouble(28,ctfSurchargeAmt);
				insert_tot_blg_sumy.setDouble(29,lpcAmt);
				
				//new fields added to Sandiago Underground project   -- SD_UNDERGRD_SRCG_AMT
				double sdUndergrdSrcgAmt =  Double.parseDouble(reformat(SummaryLine.nextToken().trim()));//35
				insert_tot_blg_sumy.setDouble(30,sdUndergrdSrcgAmt);
				
				insert_tot_blg_sumy.execute();
			
			}else{
				severe(StaticErrorMsgKeys.INVAID_RECORD_TYPE + Record_Id);
				throw new Exception();	
			}
		    
			
		    
		    
			}catch(SQLException e){
					severe(StaticErrorMsgKeys.PARSELINE_ERROR + e.getMessage());
					throw new SQLException(e.getMessage());	
		
			}catch (Exception e) {
					severe(StaticErrorMsgKeys.PARSELINE_ERROR + e.getMessage());
					throw new Exception(e.getMessage());	
			}
		
			return SUCCESS;
		}

		public boolean accept(File file) {
		
			boolean ret = false;
		
			if(((file.getName().charAt(3) == StaticFieldKeys.C)
					|| (file.getName().charAt(3) == StaticFieldKeys.I))
					&& (file.getName().indexOf(StaticFieldKeys.FILEID_SUMY) != -1)
					&& (file.length() > 0)) 
			ret = true;
        
			return ret;
		}
		
		public String reformat(String token){
		//If '-' exists at end of the string the put it in front
			String s = token;
			if(s.charAt(s.length()-1) == '-')
			 s = '-'+ s.substring(0,s.length()-1);
			return s;
			
		}

	}
