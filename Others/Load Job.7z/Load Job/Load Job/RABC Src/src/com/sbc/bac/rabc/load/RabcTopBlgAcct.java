/*
 * Created on May 31, 2005
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package com.sbc.bac.rabc.load;
import java.io.File;
import java.net.UnknownHostException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;
import java.util.StringTokenizer;

import com.att.bac.rabc.util.EmcisEventLogger;
import com.att.bac.util.NetUtil;
import com.att.carat.util.Email;
//changes for M168 by as635b
import com.att.carat.load.Application;
import com.att.carat.load.FileDBLoadJob;
//import com.sbc.bac.load.Application;
//import com.sbc.bac.load.FileDBLoadJob;

/******************************************************************************
 * @author sr8948
 *
 * Class Name : RabcTopBlgAcct
 * Progam Id  : RABCPPG00322
 * Author     : Srikanth Reddy
 * Purpose    : Loadjob for following input filenames
 *               re.x.Cxxxx.XT13TOPX.TIMESTAMP.TXT
 *              Also loads the Trigger Table.
 * Comments	  : 	    
 ******************************************************************************/
public class RabcTopBlgAcct  extends FileDBLoadJob {
	    
	    private String Ignore;
	    private String location;
		private int cycle;
		private int cntl_pt;
		private String bill_rnd, bill_rnd_dt;
		private File currentFile;
		private HashMap crocd_division;
		private String region;
		private Set divSet;
		
		private String run_date;
		private java.sql.Date sqlrun_date;
		private String maillist;
		private String bac_home;
		private String to_address;

		private PreparedStatement insert_top_adj_blg_accts;
		private PreparedStatement insert_top_occ_blg_accts;
		private PreparedStatement insert_top_payment_accts;
		private PreparedStatement insert_top_lpc_accts;
	
		private String backoutRecovery = null;
		private boolean billdayFile;

		private String fileName, fileToken;
		
		public boolean configure(
			Application application,
			Properties configuration) {

			to_address = configuration.getProperty(StaticFieldKeys.STATUS_TO_ADDRESS);

			boolean result = super.configure(application, configuration);
			return result;
		}

		public boolean preprocess() {
			super.preprocess();

			try {
				insert_top_adj_blg_accts =
					connection.prepareStatement(
						StaticInsertSQLQuerys.INSERT_RABC_TOP_ADJ_BLG_ACCTS());
				insert_top_occ_blg_accts =
					connection.prepareStatement(
						StaticInsertSQLQuerys.INSERT_RABC_TOP_OCC_BLG_ACCTS());
				insert_top_payment_accts =
					connection.prepareStatement(
						StaticInsertSQLQuerys.INSERT_RABC_TOP_PAYMENT_ACCTS());			
				insert_top_lpc_accts =
					connection.prepareStatement(
						StaticInsertSQLQuerys.INSERT_RABC_TOP_LPC_ACCTS());
			} catch (SQLException e) {
				severe(StaticErrorMsgKeys.PREPROCESS_ERROR + e.getMessage());
				return false;
			}
			return true;
		}

		public boolean postprocess(boolean success) {
		
			try {
				insert_top_adj_blg_accts.close();
				insert_top_occ_blg_accts.close();
				insert_top_payment_accts.close();
				insert_top_lpc_accts.close();
				
				} catch (SQLException e) {
				severe(StaticErrorMsgKeys.POSTPROCESS_ERROR + StaticErrorMsgKeys.SQL_CLOSE_ERROR + e);
				success = false;
			}
		
			return super.postprocess(success);
		}

		public boolean preprocessFile(File file) {
			boolean success = super.preprocessFile(file);
			billdayFile = true;
			fileName = file.getName();
			fileToken = file.getName().substring(11,19);
		
			if (success) {
				try{
					region   =	file.getName().substring(0,2);
			   	
					location =	file.getName().charAt(3) == StaticFieldKeys.C
								? StaticFieldKeys.LOCATION_N
								: StaticFieldKeys.LOCATION_S;
					cycle    = Integer.parseInt(file.getName().substring(6, 10));
					run_date = RetrieveStaticInfo.getProc_dtByCycle(connection, cycle);
					if (run_date.equals(StaticFieldKeys.ZERO)){
						severe(StaticErrorMsgKeys.NORECORD_RABC_CYCLE_CALENDAR + cycle);
						throw new Exception();	
					}
					
					
					DateFormat df = new SimpleDateFormat("MMddyyyy");
					sqlrun_date = new java.sql.Date(df.parse(run_date).getTime());
					currentFile = file;
					divSet = new HashSet();
					
					String tableNm = null;
					
					if (RabcLoadJobTrig.IsFileLoaded(connection,file)){
					 //  severe(StaticErrorMsgKeys.DUPLICATE_FILE);
					 //  return false;
						backoutRecovery = "Y";
						if (location.equals("N")){
							tableNm = "RABC_TOP_ADJ_BLG_ACCTS";
							success = PrepareTableForRerun.deleteTableData(connection,tableNm,"PN",sqlrun_date);
							success = PrepareTableForRerun.deleteTableData(connection,tableNm,"NB",sqlrun_date);
							tableNm = "RABC_TOP_OCC_BLG_ACCTS";
							success = PrepareTableForRerun.deleteTableData(connection,tableNm,"PN",sqlrun_date);
							success = PrepareTableForRerun.deleteTableData(connection,tableNm,"NB",sqlrun_date);
							tableNm = "RABC_TOP_PAYMENT_ACCTS";
							success = PrepareTableForRerun.deleteTableData(connection,tableNm,"PN",sqlrun_date);
							success = PrepareTableForRerun.deleteTableData(connection,tableNm,"NB",sqlrun_date);
							tableNm = "RABC_TOP_LPC_ACCTS";
							success = PrepareTableForRerun.deleteTableData(connection,tableNm,"PN",sqlrun_date);
							success = PrepareTableForRerun.deleteTableData(connection,tableNm,"NB",sqlrun_date);
						}else {
							// location.equals("S")
							tableNm = "RABC_TOP_ADJ_BLG_ACCTS";
							success = PrepareTableForRerun.deleteTableData(connection,tableNm,"PS",sqlrun_date);
							tableNm = "RABC_TOP_OCC_BLG_ACCTS";
							success = PrepareTableForRerun.deleteTableData(connection,tableNm,"PS",sqlrun_date);
							tableNm = "RABC_TOP_PAYMENT_ACCTS";
							success = PrepareTableForRerun.deleteTableData(connection,tableNm,"PS",sqlrun_date);
							tableNm = "RABC_TOP_LPC_ACCTS";
							success = PrepareTableForRerun.deleteTableData(connection,tableNm,"PS",sqlrun_date);

						}
					}
					
					
				}catch(Exception e){
					severe(StaticErrorMsgKeys.PREPROCESSFILE_ERROR + StaticErrorMsgKeys.FILE_NAME_PARSING_ERROR + e);
					return false;
				}
			}

			try {
				
            bill_rnd = RetrieveStaticInfo.getBillRndByCycle(connection,cycle);
            bill_rnd_dt = RetrieveStaticInfo.getbillRndDt_ByCycle(connection, cycle);
			if (bill_rnd.equals(StaticFieldKeys.ZERO) || bill_rnd.equals(StaticFieldKeys.ZERO2)){
				billdayFile = false;
			}
			crocd_division  = RetrieveStaticInfo.getCrocd_Divsion(connection,region.trim());
		
			} catch (SQLException e) {
				success = false;
				severe(StaticErrorMsgKeys.PREPROCESSFILE_ERROR + e.getMessage());
			}

			return success;
		}

		public boolean postprocessFile(File file, boolean success) {
			try{	//Log the file information to EMCIS_EVENT_LOG and EMCIS_EVENT_LOG_DETAIL
				EmcisEventLogger emcisLogger = new EmcisEventLogger();
				String event_id = "RABC_"+fileToken+"_"+region;
	            String host = NetUtil.getLocalHostName();
	            String hostIP = NetUtil.getLocalIpAddress();
				int sequence = emcisLogger.getEMCISSequence(connection);
				emcisLogger.insertEventLog(connection, sequence, event_id, sqlrun_date, host, hostIP);
				emcisLogger.insertEventLogDetail(connection, sequence, "FileName", fileName);
			}catch (UnknownHostException e) {
	            severe("Error getting EMCIS host information ", e);
	        }
			if (success){
				//Insert into Trigger Table only if Bill round exists.
				if(billdayFile)
       				if(!insertTrigger()){
						severe(StaticErrorMsgKeys.POSTPROCESSFILE_ERROR + StaticErrorMsgKeys.TIGGER_TABLE_INSERT_ERROR);
						success = false;
					}
			}
        
			if (!success) {
				Email.sendEmail(
								to_address,
								StaticFieldKeys.FROM_ADDRESS,
								StaticFieldKeys.SUBJECT_LINE,
								StaticErrorMsgKeys.XT13_ERROR_MESSAGE);
			}	
					
			return super.postprocessFile(file, success);
		}

		/**
		 * 
		 */
		private boolean insertTrigger() {

			Iterator I = divSet.iterator();
			
			while (I.hasNext()) {
				String divi = (String)I.next();
				if(!RabcLoadJobTrig.insertTrigger(connection,currentFile.getName(),"XT13SADJ",divi,run_date,backoutRecovery,bill_rnd)){
				   return false;	
				 }
				if(!RabcLoadJobTrig.insertTrigger(connection,currentFile.getName(),"XT13SOCC",divi,run_date,backoutRecovery,bill_rnd)){
				   return false;	
				 }
				if(!RabcLoadJobTrig.insertTrigger(connection,currentFile.getName(),"XT13SPAY",divi,run_date,backoutRecovery,bill_rnd)){
				   return false;	
				 }
				if(!RabcLoadJobTrig.insertTrigger(connection,currentFile.getName(),"XT13SLPC",divi,run_date,backoutRecovery,bill_rnd)){
					   return false;	
				}
			}
			
			return true;
		}
		
				
		public int parseLine(String line) throws Exception {
			if (line.length() < 100)
				return SKIPPED;
			
			try{
				
			StringTokenizer SummaryLine = 	new StringTokenizer(line, StaticFieldKeys.SEMICOLON);
			
			String Record_type = SummaryLine.nextToken().trim();
			String crocd = SummaryLine.nextToken().trim();
			String div   = (String)crocd_division.get(crocd);
			String busType = null;
			if (Record_type.substring(4,5).equals("S")) 
				busType = "RES";
			else
				busType = "BUS";
			
			if (div.equals(null)){
				severe(StaticErrorMsgKeys.NORECORD_RABC_CRO_CD_DIVISION + crocd);
				throw new Exception();	
			}
			divSet.add((String)div);
			
			if (Record_type.equals(StaticFieldKeys.RECORD_TOP_ADJR)||Record_type.equals(StaticFieldKeys.RECORD_TOP_ADJB)){
			   
				insert_top_adj_blg_accts.setString(1, div);
				insert_top_adj_blg_accts.setDate  (2, sqlrun_date);
				insert_top_adj_blg_accts.setInt	 (3, cycle);
				insert_top_adj_blg_accts.setInt	 (4, Integer.parseInt(bill_rnd));
				insert_top_adj_blg_accts.setString(5, SummaryLine.nextToken().trim()+SummaryLine.nextToken().trim()+SummaryLine.nextToken().trim());
			
				Ignore = SummaryLine.nextToken().trim()+SummaryLine.nextToken().trim()+SummaryLine.nextToken().trim();
			
				insert_top_adj_blg_accts.setString(6, SummaryLine.nextToken().trim().substring(1));
			
				Ignore = SummaryLine.nextToken().trim();
			
				insert_top_adj_blg_accts.setDouble(7,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);
				insert_top_adj_blg_accts.setDouble(8,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);
				insert_top_adj_blg_accts.setDouble(9,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);
				insert_top_adj_blg_accts.setDouble(10,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);
				insert_top_adj_blg_accts.setString(11,bill_rnd_dt.substring(0,2));
				insert_top_adj_blg_accts.setString(12,bill_rnd_dt.substring(4,8));
				insert_top_adj_blg_accts.setString(13,busType);
			
				insert_top_adj_blg_accts.execute();
			
			}else if(Record_type.equals(StaticFieldKeys.RECORD_TOP_OCCR)||Record_type.equals(StaticFieldKeys.RECORD_TOP_OCCB)){ 
				insert_top_occ_blg_accts.setString(1, div);
				insert_top_occ_blg_accts.setDate  (2, sqlrun_date);
				insert_top_occ_blg_accts.setInt	 (3, cycle);
				insert_top_occ_blg_accts.setInt	 (4, Integer.parseInt(bill_rnd));
				insert_top_occ_blg_accts.setString(5, SummaryLine.nextToken().trim()+SummaryLine.nextToken().trim()+SummaryLine.nextToken().trim());
				Ignore = SummaryLine.nextToken().trim()+SummaryLine.nextToken().trim()+SummaryLine.nextToken().trim();
				insert_top_occ_blg_accts.setString(6, SummaryLine.nextToken().trim().substring(1));
				Ignore = SummaryLine.nextToken().trim();
				//PREV_BLG_AMT,CURR_BLG_AMT,TOT_BLG_AMT,"skip", "skip", OCC_AMT, "skip", NRG_OCC_AMT,BLG_MM,BLG_YEAR,BUS_TYPE
				insert_top_occ_blg_accts.setDouble(7,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);
				insert_top_occ_blg_accts.setDouble(8,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);
				insert_top_occ_blg_accts.setDouble(9,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);
				Ignore = SummaryLine.nextToken().trim() + SummaryLine.nextToken().trim();
				insert_top_occ_blg_accts.setDouble(10,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);
				Ignore = SummaryLine.nextToken().trim();
				insert_top_occ_blg_accts.setNull(11,Types.DOUBLE);
				insert_top_occ_blg_accts.setString(12,bill_rnd_dt.substring(0,2));
				insert_top_occ_blg_accts.setString(13,bill_rnd_dt.substring(4,8));
				insert_top_occ_blg_accts.setString(14,busType);
			
				insert_top_occ_blg_accts.execute();
			
			}else if(Record_type.equals(StaticFieldKeys.RECORD_TOP_PAYR)||Record_type.equals(StaticFieldKeys.RECORD_TOP_PAYB)){ 

				insert_top_payment_accts.setString(1, div);
				insert_top_payment_accts.setDate  (2, sqlrun_date);
				insert_top_payment_accts.setInt	 (3, cycle);
				insert_top_payment_accts.setInt	 (4, Integer.parseInt(bill_rnd));
				insert_top_payment_accts.setString(5, SummaryLine.nextToken().trim()+SummaryLine.nextToken().trim()+SummaryLine.nextToken().trim());
				Ignore = SummaryLine.nextToken().trim()+SummaryLine.nextToken().trim()+SummaryLine.nextToken().trim();
				insert_top_payment_accts.setString(6, SummaryLine.nextToken().trim().substring(1));
				Ignore = SummaryLine.nextToken().trim();
				insert_top_payment_accts.setDouble(7,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);
				insert_top_payment_accts.setDouble(8,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);
				insert_top_payment_accts.setDouble(9,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);
				Ignore = SummaryLine.nextToken().trim();
				insert_top_payment_accts.setDouble(10,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);
				insert_top_payment_accts.setString(11,bill_rnd_dt.substring(0,2));
				insert_top_payment_accts.setString(12,bill_rnd_dt.substring(4,8));
				insert_top_payment_accts.setString(13,busType);
			    
				insert_top_payment_accts.execute();
			    
			}else if(Record_type.equals(StaticFieldKeys.RECORD_TOP_LPCR)||Record_type.equals(StaticFieldKeys.RECORD_TOP_LPCB)){
				
				insert_top_lpc_accts.setString(1, div);
				insert_top_lpc_accts.setDate  (2, sqlrun_date);
				insert_top_lpc_accts.setInt	 (3, cycle);
				insert_top_lpc_accts.setInt	 (4, Integer.parseInt(bill_rnd));
				insert_top_lpc_accts.setString(5, SummaryLine.nextToken().trim()+SummaryLine.nextToken().trim()+SummaryLine.nextToken().trim());
				Ignore = SummaryLine.nextToken().trim()+SummaryLine.nextToken().trim()+SummaryLine.nextToken().trim();
				insert_top_lpc_accts.setString(6, SummaryLine.nextToken().trim().substring(1));
				Ignore = SummaryLine.nextToken().trim();
				insert_top_lpc_accts.setDouble(7,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);
				Ignore = SummaryLine.nextToken().trim() + SummaryLine.nextToken().trim();
				insert_top_lpc_accts.setDouble(8,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);
				insert_top_lpc_accts.setDouble(9,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);
				insert_top_lpc_accts.setDouble(10,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);
				insert_top_lpc_accts.setDouble(11,Double.parseDouble(SummaryLine.nextToken().trim())/1000000);
				insert_top_lpc_accts.setString(12,bill_rnd_dt.substring(0,2));
				insert_top_lpc_accts.setString(13,bill_rnd_dt.substring(4,8));
				insert_top_lpc_accts.setString(14,busType);
			
				insert_top_lpc_accts.execute();
			
				
			}else{
				//SKIP all new record types because they don't have expected data -- Kin 
				//throw new Exception(StaticErrorMsgKeys.INVAID_RECORD_TYPE + Record_type);
			}
			
			}catch(SQLException e){
					severe(StaticErrorMsgKeys.PARSELINE_ERROR + e.getMessage());
					throw new SQLException(e.getMessage());	
		
			}catch (Exception e) {
					severe(StaticErrorMsgKeys.PARSELINE_ERROR + e.getMessage());
					throw new Exception(e.getMessage());	
			}
			return SUCCESS;
		}
        
        
         
		public boolean accept(File file) {
		
			boolean ret = false;
		
			if(((file.getName().charAt(3) == StaticFieldKeys.C)
					|| (file.getName().charAt(3) == StaticFieldKeys.I))
					&& (file.getName().indexOf(StaticFieldKeys.FILEID_TOPX) != -1)
					&& (file.length() > 0)) 
			ret = true;
        
			return ret;
		}

	}
