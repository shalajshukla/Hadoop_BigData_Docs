/*
 * Created on May 25, 2005
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package com.sbc.bac.rabc.load;

/******************************************************************************
 * @author sr8948
 *
 * Class Name : StaticErrorMsgKeys
 * Program Id : RABCPPG00329
 * Author     : Srikanth Reddy
 * Purpose    : 
 * Comments	  : 	    
 ******************************************************************************/
public final class StaticErrorMsgKeys {

	
	public static final String INSERT_ERROR				  = "Error Occured While Inserting Row  ";  
	public static final String PREPROCESS_ERROR		  	  = "Error Occured in preprocess Method: ";
	public static final String POSTPROCESS_ERROR	  	  = "Error Occured in postprocess Method: ";
	public static final String PREPROCESSFILE_ERROR	  	  = "Error Occured in preprocessFile Method: ";
	public static final String POSTPROCESSFILE_ERROR	  = "Error Occured in postprocessFile Method: ";
	public static final String PARSELINE_ERROR	  		  = "Error Occured in parseline Method: ";
	
	public static final String FILE_NAME_PARSING_ERROR    = "Error Occured while Parsing File Name: ";
	public static final String TIGGER_TABLE_INSERT_ERROR  = "Error Occured while Inserting into Trigger Table - Rollback: ";
	public static final String INVAID_RECORD_TYPE    	  = "Invalid Record Type: ";
	public static final String SQL_CLOSE_ERROR       	  = "Error Occured while Closing the JDBC Objects:  ";
	public static final String DUPLICATE_FILE        	  = "Duplicate File,This File Already Processd..Abort: " ;
	public static final String AVERAGE_TABLE_INSERT_ERROR = "Error Occured whilE Inserting/Updating Averages in RABC_ACCT_BTG_DTL_AVG table: ";
	
	
	public static final String NORECORD_RABC_CRO_CD_DIVISION = "No Record found in RABC_CRO_CD_DIVISION for Cro Code: " ;
	public static final String NORECORD_RABC_CYCLE_CALENDAR  = "No Record found in RABC_CYCLE_CALENDAR for Cycle: " ;
	
	
	
	public static final String XT10XT12_ERROR_MESSAGE     = "The XT10 OR XT12 Billday Upload File Background Job has failed.\n"
	                                                        + "Look at the file 'loadprocess.log' in the source directory for more info.\n";
	
	public static final String XT11_ERROR_MESSAGE    	  = "The XT11 Sumy Upload File Background Job has failed.\n"
															+ "Look at the file 'loadprocess.log' in the source directory for more info.\n";
	
	public static final String XT13_ERROR_MESSAGE    	  = "The XT13 File Background Job has failed.\n"
															+ "Look at the file 'loadprocess.log' in the source directory for more info.\n";
	
	public static final String XT14_ERROR_MESSAGE    	  = "The XT14 File Background Job has failed.\n"
																+ "Look at the file 'loadprocess.log' in the source directory for more info.\n";
	
	
	
	
}
