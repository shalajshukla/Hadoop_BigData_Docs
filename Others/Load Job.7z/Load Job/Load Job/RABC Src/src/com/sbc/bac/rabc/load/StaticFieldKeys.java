/*
 * Created on May 25, 2005
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package com.sbc.bac.rabc.load;


/******************************************************************************
 * @author sr8948
 *
 * Class Name : StaticFieldKeys
 * Program Id : RABCPPG00330
 * Author     : Srikanth Reddy
 * Purpose    : 
 * Comments	  : 	    
 ******************************************************************************/
public final class StaticFieldKeys {
  
 
  public static final String MAILLIST 			= "maillist";
  public static final String BAC_HOME 			= "bac_home";
  public static final String STATUS_TO_ADDRESS  = "status_to_addresses";
  public static final String FROM_ADDRESS  		= "CARATNotify@att.com";
  public static final String SUBJECT_LINE  		= "Background Job Failed";
  
  public static final String FILEID_CRIS  		= "XT10CRIS";
  public static final String FILEID_SUMY  		= "XT11SUMY";
  public static final String FILEID_BDYT  		= "XT12BDYT";
  public static final String FILEID_TOPX  		= "XT13TOPX";
  public static final String FILEID_POFX  		= "XT14POFX";
  
  public static final String RECORD_CRIS	    = "XT100001";
  public static final String RECORD_BDYT        = "XT120001";
  
  public static final String RECORD_RESIDENCE  	= "XT11SRES";
  public static final String RECORD_BUSINESS 	= "XT11SBUS";
  public static final String RECORD_RESALERES	= "XT11SRRE";
  public static final String RECORD_RESALEBUS	= "XT11SRBU";
  public static final String RECORD_FINAL	  	= "XT11SFNL";
  public static final String RECORD_TOPTEN  	= "XT11T001";
  
  public static final String RECORD_TOP_ADJR     = "XT13SADJ";
  public static final String RECORD_TOP_ADJB     = "XT13BADJ";
  public static final String RECORD_TOP_OCCR     = "XT13SOCC";
  public static final String RECORD_TOP_OCCB     = "XT13BOCC";
  public static final String RECORD_TOP_PAYR     = "XT13SPAY";
  public static final String RECORD_TOP_PAYB     = "XT13BPAY";
  public static final String RECORD_TOP_LPCR     = "XT13SLPC";
  public static final String RECORD_TOP_LPCB     = "XT13BLPC";
  
  public static final String RECORD_NON_RECUR	= "XT14001N";
  public static final String RECORD_RECUR		= "XT14001R";
  public static final String RECORD_USAGE		= "XT14001U";
  public static final String RECORD_OTHER		= "XT14001O";
  public static final String RECORD_TAX		 	= "XT14001T";
  
  public static final String PACBELLNORTH		= "PN";
  public static final String PACBELLSOUTH		= "PS";
  public static final String NEVADABELL  		= "NB";
     
  public static final char C  					= 'C';
  public static final char I  					= 'I';
  public static final char NORTH				= 'J';
  public static final char SOUTH				= 'O';
  
  public static final String LOCATION_N  		= "N";
  public static final String LOCATION_S  		= "S";
  
  public static final String SEMICOLON  		= ";";
  public static final String ZERO  				= "0";
  public static final String ZERO2 				= "00";
  public static final String BLANK				= "";
  public static final String EMPTY				= "";
  public static final String SINGLESPACE		= " ";
  
  
 
}
