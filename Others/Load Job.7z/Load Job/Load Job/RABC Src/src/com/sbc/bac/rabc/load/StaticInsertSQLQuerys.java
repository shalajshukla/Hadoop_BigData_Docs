/*
 * Created on May 26, 2005
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package com.sbc.bac.rabc.load;

/******************************************************************************
 * @author sr8948
 *
 * Class Name : StaticInsertSQLQuerys
 * Program Id : RABCPPG00331
 * Author     : Srikanth Reddy
 * Purpose    : 
 * Comments	  : 	    
 ******************************************************************************/
/*------------------------------------------------------------------------------
Modification History

Date		Version		Author			Description
----------	-----------	--------------- ----------------------------------------
12-10-2010	1.0			ss1644			Changes done for Q-FIX 10-63
										Added ACCT_CLS_CD and ACCT_ACTIVE_IND in
										INSERT_RABC_TOP_TEN_BLG_ACCT query
------------------------------------------------------------------------------*/


public final class StaticInsertSQLQuerys {
    	
   
   public static String INSERT_RABC_ACCT_BLG_DTL(){
	
	StringBuffer sb = new StringBuffer();
	sb.append("INSERT INTO RABC_ACCT_BLG_DTL(DIVISION,RUN_DATE,CYCLE,CNTL_PT,");
	sb.append("BTN,CTCUSTID,RANKING,BILL_RND,ACCT_CLS_CD,ACCT_TOT_BLG_CHRGS,");
	sb.append("ACCT_CURR_MNTH_CHRGS,ACCT_PAYMENT_AMT,ACCT_BAL_DUE,ACCT_BILL_ADJ,");
	sb.append("ACCT_OTR_BAL_ADJ,ACCT_OCC,ACCT_NRG_OCC,ACCT_DSCT_OCC,ACCT_MCC,ACCT_NRG_MCC,ACCT_DSCT_MCC,");
	sb.append("ACCT_MNTH_SRV_AMT,ACCT_FED_ACCES_AMT,ACCT_TOT_TOLL,ACCT_TOT_DSCT_TOLL,");
	sb.append("ACCT_ZONE1_AMT,ACCT_ZONE1_CT,ACCT_ZONE1_MOU,ACCT_ZONE23_AMT,ACCT_ZONE23_CT,");
	sb.append("ACCT_ZONE23_MOU,ACCT_TOT_TOLL_AMT,ACCT_DA_AMT,");
	sb.append("ACCT_DA_CT,ACCT_IEC_CHRG,ACCT_900_CALL_CHRG,ACCT_FED_TAX,ACCT_STATE_TAX,ACCT_CITY_TAX,");
	sb.append("ACCT_BLG_SRCHG,ACCT_HCAP_SRCHG,ACCT_LFLN_SRCHG,ACCT_CPUC_SRCHG,ACCT_CHCFA_SRCHG,");
	sb.append("ACCT_CHCFB_SRCHG,ACCT_USSC_SRCHG,ACCT_LPC_AMT,ACCT_CTF_SRCHG,ACCT_ATT_SRCHG,ACCT_SRV_USFF_AMT,BLG_MM,BLG_YEAR,ACCT_SD_UNDERGRD_SRCHG)");
	sb.append("VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
	
	return sb.toString();
   }
   
   public static String INSERT_RABC_ACCT_BLG_DTL_WITH_RANK(){
	StringBuffer sb = new StringBuffer();
	
	sb.append("INSERT INTO RABC_ACCT_BLG_DTL "); 
	sb.append("SELECT DIVISION,RUN_DATE,CYCLE,CNTL_PT,BTN,CTCUSTID,ROWNUM,BILL_RND,ACCT_CLS_CD,ACCT_TOT_BLG_CHRGS");
	sb.append(",ACCT_CURR_MNTH_CHRGS,ACCT_PAYMENT_AMT,ACCT_BAL_DUE,ACCT_BILL_ADJ,ACCT_OTR_BAL_ADJ,ACCT_OCC");
	sb.append(",ACCT_NRG_OCC,ACCT_DSCT_OCC,ACCT_MCC,ACCT_NRG_MCC,ACCT_DSCT_MCC,ACCT_MNTH_SRV_AMT,ACCT_FED_ACCES_AMT");
	sb.append(",ACCT_TOT_TOLL,ACCT_TOT_DSCT_TOLL,ACCT_ZONE1_AMT,ACCT_ZONE1_CT,ACCT_ZONE1_MOU,ACCT_ZONE23_AMT");
	sb.append(",ACCT_ZONE23_CT,ACCT_ZONE23_MOU,ACCT_TOT_TOLL_AMT,ACCT_DA_AMT,ACCT_DA_CT,ACCT_IEC_CHRG");
	sb.append(",ACCT_900_CALL_CHRG,ACCT_FED_TAX,ACCT_STATE_TAX,ACCT_CITY_TAX,ACCT_BLG_SRCHG,ACCT_HCAP_SRCHG");
	sb.append(",ACCT_LFLN_SRCHG,ACCT_CPUC_SRCHG,ACCT_CHCFA_SRCHG,ACCT_CHCFB_SRCHG,ACCT_USSC_SRCHG,ACCT_LPC_AMT");
	sb.append(",ACCT_CTF_SRCHG,ACCT_ATT_SRCHG,ACCT_SRV_USFF_AMT,BLG_MM,BLG_YEAR,ACCT_SD_UNDERGRD_SRCHG FROM ");
	sb.append("(select * from RABC_ACCT_BLG_DTL where division = ? AND ACCT_CLS_CD = ? AND CYCLE = ? AND CNTL_PT = ? ORDER BY ACCT_CURR_MNTH_CHRGS desc)");
	
	return sb.toString();	
   }
   
   public static String INSERT_RABC_TOT_BLG_SUMY(){
    
    StringBuffer sb = new StringBuffer();
	sb.append("INSERT INTO RABC_TOT_BLG_SUMY(DIVISION,RUN_DATE,CYCLE,BILL_RND,BUS_TYPE,");
	sb.append("BAL_DUE_AMT,CURR_BLG_AMT,TOLL_AMT,OCC_AMT,BOC_AMT,ATT_AMT,IEC_AMT,TAX_SURCH_AMT,");
	sb.append("FED_TAX_AMT,CITY_TAX_AMT,ST_TAX_AMT,MNTY_USFF_AMT,EUCL_CHG_AMT,ACCT_CT,TIME_STAMP,BLG_MM,BLG_YEAR,CA_BLG_SRCG_AMT,CHCFA_SRCG_AMT,CHCFB_SRCG_AMT,LIFE_LINE_SRCG_AMT,HCAP_SRCG_AMT,CTF_SRCG,LPC_AMT,SD_UNDERGRD_SRCG_AMT)");
	sb.append(" VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
	
	return sb.toString();
    
   }
   
   public static String INSERT_RABC_TOP_TEN_BLG_ACCT(){
   
   	StringBuffer sb = new StringBuffer();
   	sb.append("INSERT INTO RABC_TOP_TEN_BLG_ACCT(DIVISION,RUN_DATE,CYCLE,BILL_RND,");
   	sb.append("RANK,BTN,BAL_DUE_AMT,CUR_BLG_AMT,BLG_MM,BLG_YEAR,ACCT_CLS_CD,ACCT_ACTIVE_IND)");
   	sb.append(" VALUES(?,?,?,?,?,?,?,?,?,?,?,?)");
	return sb.toString();
   
   }
   
   
   public static String INSERT_RABC_ACCT_BLG_DTL_AVG(){
	
	StringBuffer sb = new StringBuffer();
	
	sb.append("INSERT INTO RABC_ACCT_BLG_DTL_AVG");
	sb.append(" (SELECT DIVISION,MAX(RUN_DATE),CNTL_PT,BTN,CTCUSTID");
	sb.append(",AVG(ACCT_TOT_BLG_CHRGS)");
	sb.append(",AVG(ACCT_CURR_MNTH_CHRGS)");
	sb.append(",AVG(ACCT_PAYMENT_AMT)");
	sb.append(",AVG(ACCT_BAL_DUE)");
	sb.append(",AVG(ACCT_BILL_ADJ)");
	sb.append(",AVG(ACCT_OTR_BAL_ADJ)");
	sb.append(",AVG(ACCT_OCC)");
	sb.append(",AVG(ACCT_NRG_OCC)");
	sb.append(",AVG(ACCT_DSCT_OCC)");
	sb.append(",AVG(ACCT_MCC)");
	sb.append(",AVG(ACCT_NRG_MCC)");
	sb.append(",AVG(ACCT_DSCT_MCC)");
	sb.append(",AVG(ACCT_MNTH_SRV_AMT)");
	sb.append(",AVG(ACCT_FED_ACCES_AMT)");
	sb.append(",AVG(ACCT_TOT_TOLL)");
	sb.append(",AVG(ACCT_TOT_DSCT_TOLL)");
	sb.append(",AVG(ACCT_ZONE1_AMT)");
	sb.append(",AVG(ACCT_ZONE1_CT)");
	sb.append(",AVG(ACCT_ZONE1_MOU)");
	sb.append(",AVG(ACCT_ZONE23_AMT)");
	sb.append(",AVG(ACCT_ZONE23_CT)");
	sb.append(",AVG(ACCT_ZONE23_MOU)");
	sb.append(",AVG(ACCT_TOT_TOLL_AMT)");
	sb.append(",AVG(ACCT_DA_AMT)");
	sb.append(",AVG(ACCT_DA_CT)");
	sb.append(",AVG(ACCT_IEC_CHRG)");
	sb.append(",AVG(ACCT_900_CALL_CHRG)");
	sb.append(",AVG(ACCT_FED_TAX)");
	sb.append(",AVG(ACCT_STATE_TAX)");
	sb.append(",AVG(ACCT_CITY_TAX)");
	sb.append(",AVG(ACCT_BLG_SRCHG)");
	sb.append(",AVG(ACCT_HCAP_SRCHG)");
	sb.append(",AVG(ACCT_LFLN_SRCHG)");
	sb.append(",AVG(ACCT_CPUC_SRCHG)");
    sb.append(",AVG(ACCT_CHCFA_SRCHG)");
	sb.append(",AVG(ACCT_CHCFB_SRCHG)");
	sb.append(",AVG(ACCT_USSC_SRCHG)");
	sb.append(",AVG(ACCT_LPC_AMT)");
	sb.append(",AVG(ACCT_CTF_SRCHG)");
	sb.append(",AVG(ACCT_ATT_SRCHG)");
	sb.append(",AVG(ACCT_SRV_USFF_AMT)");
	sb.append(",AVG(ACCT_SD_UNDERGRD_SRCHG)");
	sb.append(" FROM RABC_ACCT_BLG_DTL");
	sb.append(" WHERE DIVISION = ?");
	sb.append(" AND BTN = ?");
	sb.append(" AND CTCUSTID = ?");
	sb.append(" AND CNTL_PT  = ?");
	sb.append(" AND RANKING != 0");
	sb.append(" GROUP BY DIVISION,CNTL_PT,BTN,CTCUSTID)");
	
	return sb.toString();
  }

public static String INSERT_RABC_TOP_ADJ_BLG_ACCTS() {
	StringBuffer sb = new StringBuffer();
	sb.append("INSERT INTO RABC_TOP_ADJ_BLG_ACCTS(DIVISION,RUN_DATE,CYCLE,BILL_RND,");
	// old format sb.append("BTN,CTCUSTID,ADJ_AMT,PREV_BLG_AMT,TOT_BLG_AMT,CURR_BLG_AMT,BLG_MM,BLG_YEAR,BUS_TYPE)");
	sb.append("BTN,CTCUSTID,PREV_BLG_AMT,CURR_BLG_AMT,TOT_BLG_AMT,ADJ_AMT,BLG_MM,BLG_YEAR,BUS_TYPE)");
	sb.append(" VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)");
	return sb.toString();
}


public static String INSERT_RABC_TOP_OCC_BLG_ACCTS() {
	StringBuffer sb = new StringBuffer();
	sb.append("INSERT INTO RABC_TOP_OCC_BLG_ACCTS(DIVISION,RUN_DATE,CYCLE,BILL_RND,");
  //sb.append("BTN,CTCUSTID,OCC_AMT,NRG_OCC_AMT,PREV_BLG_AMT,TOT_BLG_AMT,CURR_BLG_AMT,BLG_MM,BLG_YEAR,BUS_TYPE)");
	sb.append("BTN,CTCUSTID,PREV_BLG_AMT,CURR_BLG_AMT,TOT_BLG_AMT,OCC_AMT,NRG_OCC_AMT,BLG_MM,BLG_YEAR,BUS_TYPE)");
	//PREV_BLG_AMT,CURR_BLG_AMT,TOT_BLG_AMT,"skip", "skip", OCC_AMT, "skip", NRG_OCC_AMT,BLG_MM,BLG_YEAR,BUS_TYPE
	sb.append(" VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
	return sb.toString();
}

public static String INSERT_RABC_TOP_PAYMENT_ACCTS() {
	StringBuffer sb = new StringBuffer();
	sb.append("INSERT INTO RABC_TOP_PAYMENT_ACCTS(DIVISION,RUN_DATE,CYCLE,BILL_RND,");
  //sb.append("BTN,CTCUSTID,PAYMENT_AMT,PREV_BLG_AMT,TOT_BLG_AMT,CURR_BLG_AMT,BLG_MM,BLG_YEAR,BUS_TYPE)");
	sb.append("BTN,CTCUSTID,PREV_BLG_AMT,CURR_BLG_AMT,TOT_BLG_AMT,PAYMENT_AMT,BLG_MM,BLG_YEAR,BUS_TYPE)");
	sb.append(" VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)");
	return sb.toString();
}

public static String INSERT_RABC_TOP_LPC_ACCTS() {
	StringBuffer sb = new StringBuffer();
	sb.append("INSERT INTO RABC_TOP_LPC_ACCTS(DIVISION, RUN_DATE, CYCLE, BILL_RND, BTN, CTCUSTID, ");
  //sb.append("LPC_AMT,PREV_BLG_AMT,CURR_PAYMENT_AMT,CURR_OCC_AMT,CURR_ADJ_AMT,BLG_MM,BLG_YEAR,BUS_TYPE)");
	sb.append("PREV_BLG_AMT,CURR_ADJ_AMT,CURR_PAYMENT_AMT,CURR_OCC_AMT,LPC_AMT,BLG_MM,BLG_YEAR,BUS_TYPE)");
	sb.append(" VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
	return sb.toString();
}

public static String INSERT_POF_BLG_SUMY() {
	StringBuffer sb = new StringBuffer();
	sb.append("INSERT INTO RABC_POF_BLG_SUMY(DIVISION,RUN_DATE,CYCLE,BILL_RND,");
	sb.append(" POF_ID,BUS_TYPE,TOT_BLG_CHRGS,TAX_SRCG_AMT,USAGE_CHRGS,NRCUR_CHRGS,");
	sb.append(" RCUR_CHRGS,OTH_CHRGS,USAGE_DSCT,NRCUR_DSCT,RECUR_DSCT,OTH_DSCT,TIME_STAMP,BLG_MM,BLG_YEAR)");
	sb.append(" VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
	return sb.toString();
}


public static String INSERT_RABC_ACCT_INFO() {
	StringBuffer sb = new StringBuffer();
	sb.append("INSERT INTO RABC_ACCT_INFO(BTN,CTCUSTID,ACCT_NAME,");
	sb.append("ACCT_CLS_CD,ACCT_ACTIVE_IND,CRO_CD)");
	sb.append(" VALUES(?,?,?,?,?,?)");
	return sb.toString();
}

// WR 0803058017 - PMT 319034 - begin - Add SQL INSERT statements for RABC_BILL_PRNT and RABC_BCAM tables
public static String INSERT_RABC_BILL_PRNT() {
	StringBuffer sb = new StringBuffer();
	sb.append("INSERT INTO RABC_BILL_PRINT(BILL_PERIOD, BILLED_DATE, REGION, DIVISION,");
	sb.append("LANG_IND, BUS_RES_IND, TOT_NUM_BILLS, TOT_CURR_CHRGS)");
	sb.append(" VALUES(?,?,?,?,?,?,?,?)");
	return sb.toString();
}

public static String INSERT_RABC_BCAM() {
	StringBuffer sb = new StringBuffer();
	sb.append("INSERT INTO RABC_BCAM(RUN_DATE, REGION, DIVISION, PROD_TYPE, TOT_NUM_BILLS)");
	sb.append(" VALUES(?,?,?,?,?)");
	return sb.toString();
}
// WR 0803058017 - PMT 319034 - end - Add SQL INSERT statements for RABC_BILL_PRNT and RABC_BCAM tables

}
