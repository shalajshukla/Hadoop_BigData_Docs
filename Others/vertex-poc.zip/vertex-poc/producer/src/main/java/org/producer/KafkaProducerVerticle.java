package org.producer;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.producer.ProducerRecord;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.json.JsonObject;
import io.vertx.kafka.client.producer.KafkaWriteStream;

public class KafkaProducerVerticle extends AbstractVerticle {


	private KafkaWriteStream<String, JsonObject> producer;
	public final String topic = "topic2";

	@Override
	public void start() throws Exception {
		System.out.println("Producer verticle is being started...");
		
		Map<String, Object> producerMap = new HashMap<>();
		producerMap.put("bootstrap.servers", "localhost:9092");
		producerMap.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		producerMap.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		producerMap.put("acks", "1");
		
		JsonObject contextConfig = new JsonObject(producerMap);
		
		producer = KafkaWriteStream.create(vertx, contextConfig.getMap(), String.class, JsonObject.class);

			
		vertx.eventBus().consumer("kafkaproducerverticle", message -> {
			System.out.println(" kafka producer Verticle received message: " + message.body());
			JsonObject jsonRec = (JsonObject) message.body();
			producer.write(new ProducerRecord<>(topic, jsonRec));
		});

	

	}

}
