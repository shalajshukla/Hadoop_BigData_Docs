package org.mysql;

import java.sql.Timestamp;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Future;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.asyncsql.MySQLClient;
import io.vertx.ext.sql.SQLClient;
import io.vertx.ext.sql.SQLConnection;

public class MySqlVerticle extends AbstractVerticle {

	JsonObject mySQLClientConfig = new JsonObject().put("host", "172.27.155.92").put("port", 3306)
			.put("username", "root").put("password", "password").put("database", "test");

	private static int EVENT_COUNT = 0;
	
	@Override
	public void start(Future<Void> startFuture) throws Exception {
		System.out.println("Mysql verticle is being started...");
		
		DBMetrics dbMetrics = new DBMetrics();
			
		SQLClient client = MySQLClient.createShared(vertx, mySQLClientConfig);
		
		
		vertx.eventBus().consumer("mysqlverticle", message -> {
			client.getConnection(conn -> {
				
				if (conn.failed()) {
					System.err.println(conn.cause().getMessage());
					return;
				} if (conn.succeeded()) {

					SQLConnection connection = conn.result();
					
					System.out.println(" MySql Verticle received message: " + message.body());
					JsonObject jsonRec = (JsonObject) message.body();
					connection.queryWithParams("insert into employees values(?,?)",
						new JsonArray().add(jsonRec.getString("id")).add(jsonRec.getString("name")), insert -> {
							Timestamp beforeInsert = new Timestamp(System.currentTimeMillis());
							dbMetrics.setStartTime(beforeInsert.toString());
							if (insert.succeeded()) {
								System.out.println(" sunccefully inserted employee data");
								dbMetrics.setCount(++EVENT_COUNT);
								Timestamp afterInsert = new Timestamp(System.currentTimeMillis());
								dbMetrics.setEndTime(afterInsert.toString());
								JsonObject dbMetricsjsonObj = new JsonObject(dbMetrics.toString());
								vertx.eventBus().send("mysqlMetricVerticle", dbMetricsjsonObj);
							} else if (insert.failed()) {
								System.err.println(" issue while inserting employee data: " + insert.cause().getMessage());
							}
							connection.close();
					});
				}
			});
			
		});
		vertx.eventBus().consumer("mysqlMetricVerticle", message -> {
			client.getConnection(conn -> {
				
				if (conn.failed()) {
					System.err.println(conn.cause().getMessage());
					return;
				} if (conn.succeeded()) {

					SQLConnection connection = conn.result();
					
					System.out.println(" mysqlMetricVerticle received message: " + message.body());
					JsonObject jsonRec = (JsonObject) message.body();
					connection.queryWithParams("insert into metrics values(?,?,?)",
						new JsonArray().add(jsonRec.getString("startTime")).add(jsonRec.getString("endTime")).add(jsonRec.getString("count")), insert -> {
							if (insert.succeeded()) {
								System.out.println(" sunccefully inserted metric data");
							} else if (insert.failed()) {
								System.err.println(" issue while inserting metric data: " + insert.cause().getMessage());
							}
							connection.close();
					});
					
				}
			});
		});
	}
}