package org.mysql;

public class DBMetrics {

	private String startTime;
	private String endTime;
	private int count;

	public String getStartTime() {
		return startTime;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	@Override
	public String toString() {
		return "{\"startTime\":\"" + startTime + "\",\"endTime\":\"" + endTime + "\",\"count\":\"" + count + "\"}";
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

}