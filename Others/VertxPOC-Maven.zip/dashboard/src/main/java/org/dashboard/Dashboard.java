package org.dashboard;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Vertx;
import io.vertx.core.VertxOptions;
import io.vertx.core.http.HttpServer;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.dropwizard.DropwizardMetricsOptions;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.handler.StaticHandler;
import io.vertx.ext.web.handler.sockjs.BridgeOptions;
import io.vertx.ext.web.handler.sockjs.PermittedOptions;
import io.vertx.ext.web.handler.sockjs.SockJSHandler;

/**
 * @author <a href="http://tfox.org">Tim Fox</a>
 */
public class Dashboard extends AbstractVerticle {
	// Convenience method so you can run it in your IDE
	public final static VertxOptions DROPWIZARD_OPTIONS = new VertxOptions()
			.setMetricsOptions(new DropwizardMetricsOptions().setEnabled(true));

	public static void main(String[] args) {
		Vertx vertx = Vertx.vertx(DROPWIZARD_OPTIONS);
		vertx.deployVerticle(new Dashboard());
	}

	@Override
	public void start() {
		//vertx = Vertx.vertx(DROPWIZARD_OPTIONS);
		Router router = Router.router(vertx);

		// Allow outbound traffic to the news-feed address

		BridgeOptions options = new BridgeOptions().addOutboundPermitted(new PermittedOptions().setAddress("metrics"));

		router.route("/eventbus/*").handler(SockJSHandler.create(vertx).bridge(options));

		// Serve the static resources
		router.route().handler(StaticHandler.create());

		HttpServer httpServer = vertx.createHttpServer();
		httpServer.requestHandler(router::accept).listen(8080);

		vertx.eventBus().consumer("dashboard", message -> {
			JsonObject metrics = (JsonObject) message.body();
			vertx.eventBus().publish("metrics", metrics);
		});
	}

}
