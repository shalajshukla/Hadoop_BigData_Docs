package org.mysql;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Future;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.asyncsql.MySQLClient;
import io.vertx.ext.sql.SQLClient;
import io.vertx.ext.sql.SQLConnection;

public class MySqlVerticle extends AbstractVerticle {

	JsonObject mySQLClientConfig = new JsonObject().put("host", "172.27.155.92").put("port", 3306)
			.put("username", "root").put("password", "password").put("database", "test");

	
	@Override
	public void start(Future<Void> startFuture) throws Exception {
		System.out.println("Mysql verticle is being started...");
		
		
			
		SQLClient client = MySQLClient.createShared(vertx, mySQLClientConfig);
		
		
		vertx.eventBus().consumer("mysqlverticle", message -> {
			client.getConnection(conn -> {
				
				if (conn.failed()) {
					System.err.println(conn.cause().getMessage());
					return;
				} if (conn.succeeded()) {

					SQLConnection connection = conn.result();
					Map<String,Object> dbMetricsMap = new HashMap<String, Object>();
					System.out.println(" MySql Verticle received message: " + message.body());
					JsonObject jsonRec = (JsonObject) message.body();
					connection.queryWithParams("insert into employees values(?,?)",
						new JsonArray().add(jsonRec.getString("id")).add(jsonRec.getString("name")), insert -> {
							long start = System.currentTimeMillis();
							dbMetricsMap.put("startTime",start/1000);
							dbMetricsMap.put("empid",jsonRec.getString("id"));
							if (insert.succeeded()) {
								System.out.println(" sunccefully inserted employee data");
								Random random = new Random();
								vertx.setTimer(1000 *random.nextInt(50), handler -> {
									long end = System.currentTimeMillis();
									dbMetricsMap.put("endTime",end/1000);
									double diffSec = (end -start)/1000;
									dbMetricsMap.put("processTime",diffSec);
									JsonObject dbMetricsjsonObj = new JsonObject(dbMetricsMap);
									vertx.eventBus().send("mysqlMetricVerticle", dbMetricsjsonObj);
								});
							} else if (insert.failed()) {
								System.err.println(" issue while inserting employee data: " + insert.cause().getMessage());
							}
							connection.close();
					});
				}
			});
			
		});
		vertx.eventBus().consumer("mysqlMetricVerticle", message -> {
			client.getConnection(conn -> {
				
				if (conn.failed()) {
					System.err.println(conn.cause().getMessage());
					return;
				} if (conn.succeeded()) {

					SQLConnection connection = conn.result();
					
					System.out.println(" mysqlMetricVerticle received message: " + message.body());
					JsonObject jsonRec = (JsonObject) message.body();
					JsonArray values = new JsonArray().add(jsonRec.getString("empid")).add(jsonRec.getLong("startTime")).add(jsonRec.getLong("endTime")).add(jsonRec.getDouble("processTime"));
					connection.queryWithParams("insert into metrics1 (emp_id,start_time,end_time,process_time) values(?,from_unixtime(?),from_unixtime(?),?)",
							values, insert -> {
							if (insert.succeeded()) {
								System.out.println(" sunccefully inserted metric data");
							} else if (insert.failed()) {
								System.err.println(" issue while inserting metric data: " + insert.cause().getMessage());
							}
							connection.close();
					});
					Map<String, Object> map = new HashMap<>();
					map.put("processTime", jsonRec.getDouble("processTime"));
					JsonObject json = new JsonObject(map);
					vertx.eventBus().send("dashboard", json);
					
				}
			});
		});
	}
}