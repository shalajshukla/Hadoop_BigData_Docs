package org.rest;

import java.util.logging.Logger;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.http.HttpServerResponse;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.RoutingContext;
import io.vertx.ext.web.handler.BodyHandler;

public class RESTVerticle extends AbstractVerticle {
	Logger logger = Logger.getLogger(RESTVerticle.class.getName());
	@Override
	public void start() throws Exception {
		logger.info(" Started Rest Verticle "+this);
		Router router = Router.router(vertx);
		router.route().handler(BodyHandler.create());
		router.post("/message").handler(this::postMessage);

		vertx.createHttpServer().requestHandler(router::accept).listen(8888);

	}

	private void postMessage(RoutingContext routingContext) {
		System.out.println(" request received by server "+this);
		logger.info(" request received by server "+this);
		HttpServerResponse response = routingContext.response();
		JsonObject message = routingContext.getBodyAsJson();
		vertx.eventBus().send("kafkaproducerverticle", message);
		response.end();
	}

}
