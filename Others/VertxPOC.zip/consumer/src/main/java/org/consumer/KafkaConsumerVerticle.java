package org.consumer;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Future;
import io.vertx.core.json.JsonObject;
import io.vertx.kafka.client.consumer.KafkaReadStream;

public class KafkaConsumerVerticle extends AbstractVerticle {

	public final String topic = "topic2";

	@Override
	public void start(Future<Void> startFuture) throws Exception {
		System.out.println("Consumer verticle is being started...");
		
		Map<String, Object> consumerMap = new HashMap<>();
		consumerMap.put("bootstrap.servers", "localhost:9092");
		consumerMap.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
		consumerMap.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
		consumerMap.put("group.id", "my_group");
		consumerMap.put("auto.offset.reset", "latest"); //earliest to read consume from beginning 
		consumerMap.put("enable.auto.commit", "false");
		
		JsonObject contextConfig = new JsonObject(consumerMap);

		KafkaReadStream<String, JsonObject> consumer = KafkaReadStream.create(vertx, contextConfig.getMap(), String.class,
				JsonObject.class);


		consumer.handler(record -> {
			JsonObject jsonRec = record.value();
			System.out.println(" consumer message " + jsonRec.toString());
			System.out.println(" Sending message via event bus to mysql vericle");
			vertx.eventBus().send("mysqlverticle", jsonRec);
			/*vertx.eventBus().send("mysqlverticle", jsonRec, response -> {
				 if(response.succeeded()) System.out.println("success");
				 else System.out.println("failure");
			});*/
		});

		consumer.subscribe(Collections.singleton(topic));

	}

}
