/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.carat.load;

import java.io.File;
import java.io.FileFilter;
import java.sql.SQLException;

/**
* Abstract class based on FileLoadJob that instead of loading file separately can load files in groups together. <BR><BR>
* 
* The list of parameters is the same as FileDBLoadJob. <BR><BR>
*  
* @author Michael Peterson - mp2154
* @author Kevin Scudder - ks9383
* 
* 
*/
abstract public class FileSetDBLoadJob extends FileDBLoadJob implements FileFilter {
	protected	long	timestamp;
	protected String[][] filenames;
	protected File[][] files;
	protected boolean[] fileset_complete;
	/**
	 * Scans though each file set to determine if all the files for a particular set are present. If there's a complete set then returns true.
	 * Currently there's no method to setup the filesets in the configuration file. You must do this in the configuration method in a subclass of this class.
	 * 
	 * @return Boolean if there are any files in the source directory.
	 * @see FileLoadJob#check()
	 */
	protected boolean check() {
		File[] filelist = source_directory.listFiles(this);
		files = new File[filenames.length][];
		fileset_complete = new boolean[filenames.length];
		for (int set_index = 0; set_index < filenames.length; set_index++) {
			files[set_index] = new File[filenames[set_index].length];
			fileset_complete[set_index] = true;
			for (int file_index = 0; file_index < filenames[set_index].length; file_index++) {
				for (int list_index = 0; list_index < filelist.length; list_index++) {
					if (filelist[list_index].getName().equals(filenames[set_index][file_index]))
						files[set_index][file_index] = filelist[list_index];
				}
				if (files[set_index][file_index] == null)
					fileset_complete[set_index] = false;
			}
		}
		// Check if we have a complete set or not.
		boolean result = false;
		for (int set_index = 0; set_index < fileset_complete.length; set_index++)
			result |= fileset_complete[set_index];
		return result;
	}
	/**
	 * Scans though each complete file set to process the files.
	 * 
	 * @return Boolean success/failure of processing of the files.
	 * @see FileLoadJob#action()
	 */
	protected boolean action() {
		boolean success = true;
		try {
			for (int set_index = 0; set_index < files.length; set_index++) {
				if (fileset_complete[set_index]) {
					success = preprocessFileSet(files[set_index]);
					for (int file_index = 0; file_index < files[set_index].length && success; file_index++) {
						success = processFile(files[set_index][file_index]);
					}
					success = postprocessFileSet(files[set_index], success);
				}
			}
		} catch (SQLException e) {
			logger.error("SQL Exception ", e);
			success = false;
		}
		return success;
	}
	/**
	 * Method that gets processed before each complete fileset starts getting loaded.
	 * 
	 * @param files An array of files in the curent fileset.
	 * @return Boolean success/failure of preprocessing of the fileset.
	 */
	protected boolean preprocessFileSet(File files[]) throws SQLException {
		timestamp = System.currentTimeMillis();
		logger.info("Starting fileset");
		return true;
	}
	/**
	 * Method that gets processed after each complete fileset is finished getting loaded.
	 * 
	 * @param files An array of files in the curent fileset.
	 * @param success Boolean whether the files process completed successfully or not.
	 * @return success Boolean success/failure of postprocessing of the fileset.
	 */
	protected boolean postprocessFileSet(File files[], boolean success) {
		logger.info("Finished fileset / time elapsed = " + (System.currentTimeMillis() - timestamp) + "ms");
		File destination = null;
		if (success) {
			try {
				connection.commit();
			} catch (SQLException e) {
			    logger.error("Commit failed. exception: ", e);
				success = false;
			}
			destination = archive_directory;
		}
		if (!success) {
			try {
				connection.rollback();
			} catch (SQLException e) {
			    logger.error("Rollback failed. exception: ", e);
			}
			logger.error("Errored out fileset.");
			destination = error_directory;
		}
		for (int index = 0; index < files.length; index++) {
			File file = files[index];
			if (!success) { 
				logger.error("Errored out file '" + file.getName() + "'"); }
			File file_destination = new File(destination, file.getName() + fileSubfix(file));
			if (file_destination.exists())
				file_destination.delete();
			if (!file.renameTo(file_destination)) {
			    logger.warn("File rename failed for file '" + file.getPath() + "' to '" + file_destination.getPath() + "'");
			}
		}
		return success;
	}
	/**
	 * Override of the method in super that gets called after each complete file is finished getting loaded.
	 * Mostly used to avoid getting connection.submit and connection.rollback from being called which are now located in the postprocessFileSet moethod.
	 * 
	 * @param file File object representing the curent file.
	 * @param success Boolean whether the file process completed successfully or not.
	 * @return success Boolean success/failure of postprocessing of the file.
	 * @see FileLoadJob#postprocessFile(File, boolean)
	 */
	protected boolean postprocessFile(File file, boolean success) {
		logger.info("Finished file '" + file.getName() + "' / time elapsed = " + (System.currentTimeMillis() - super.timestamp) + "ms / lines processed = " + counter[SUCCESS] + " / lines skipped = " + counter[SKIPPED] + " / lines per second = " + (int) ((counter[SUCCESS] * 1.0 / ((System.currentTimeMillis() - super.timestamp) * 0.001))));
		return success;
	}
	/**
	 * Check each existing file against all the files in all the file sets to see if that file should be accepted or not.
	 * 
	 * @param file File object representing the curent file.
	 * @return Boolean include or remove file from list.
	 * @see FileLoadJob#accept(File)
	 */
	public boolean accept(File file) {
		boolean result;
		for (int set_index = 0; set_index < filenames.length; set_index++)
			for (int file_index = 0; file_index < filenames[set_index].length; file_index++)
				if (file.getName().equals(filenames[set_index][file_index]))
					return true;
		return false;
	}
}
