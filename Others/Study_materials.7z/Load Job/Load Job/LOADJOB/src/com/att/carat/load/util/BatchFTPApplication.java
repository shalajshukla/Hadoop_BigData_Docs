package com.att.carat.load.util;

import java.io.File;
import java.io.FileInputStream;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.util.Properties;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.ShortBufferException;

import com.att.bac.carat.security.PasswordSecurity;
import com.att.carat.load.Application;

/** The BatchFTPApplication allows users of BatchFTPJob to run multiple jobs
 * with the same connection parameters. It looks for the connection properties
 * in the application configuration file and applies them to all child BatchFTPJobs
 * missing their own connection information. This allows BatchFTPJob to be 
 * backwards-compatible with the old BatchFTPApplication.
 */
public class BatchFTPApplication extends Application {
	private String server = null;
	private String username = null;
	private String password = null;
	
	protected boolean configure(String config_file) {
	    try {
		    //Load properties from file
		    FileInputStream propsFile = new FileInputStream(new File(config_file));
		    Properties configuration = new Properties();
		    configuration.load(propsFile);
		    propsFile.close();
		    
		    //Look up connection properties
			server = configuration.getProperty("server");
			username = configuration.getProperty("username");
			/* Added by RS980G for PMT M168 */			
			PasswordSecurity ps = new PasswordSecurity();			
			password = ps.Decrypt(configuration.getProperty("password").trim()).trim();
			logger.info("Password decrypted successfully");
	    }catch (IllegalBlockSizeException e) {
			logger.error("Unable to decrypt. Check database passwords.", e);
			return false;
		}catch (ShortBufferException e) {
			logger.error("Unable to decrypt. Check database passwords.", e);
			return false;
		}catch (BadPaddingException e) {
			logger.error("Unable to decrypt. Check database passwords.", e);
			return false;
		}catch (InvalidKeyException e) {
			logger.error("Unable to decrypt. Check database passwords.", e);
			return false;
		}catch (NoSuchAlgorithmException e) {
			logger.error("Unable to decrypt.", e);
			return false;
		}catch (NoSuchProviderException e) {
			logger.error("Unable to decrypt.", e);
			return false;
		}catch (NoSuchPaddingException e) {
			logger.error("Unable to decrypt. Check database passwords.", e);
			return false; 
		}catch(Exception e){
	        severe("Unable to load properties",e);
	        return false;
	    }
	    return super.configure(config_file);
	}
	
	protected String getPassword() {
		return password;
	}
	
	protected void setPassword(String password) {
		this.password = password;
	}
	
	protected String getServer() {
		return server;
	}

	protected void setServer(String server) {
		this.server = server;
	}
	
	protected String getUsername() {
		return username;
	}
	
	protected void setUsername(String username) {
		this.username = username;
	}
}
