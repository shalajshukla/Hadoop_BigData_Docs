/**
* � 2002-2006 AT&T Knowledge Ventures. All rights reserved.
* 
* @author mp2154
* @author Eric Teng - et8278
* 
* 
* A load job that takes all files matching a pattern specified in the config file
* and compresses them all to zip. All original files in source directory are deleted.
*/
package com.att.carat.load.util;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.FileNotFoundException;
import java.io.RandomAccessFile;
import java.util.Properties;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.channels.Channels;
import java.nio.channels.ClosedChannelException;
import java.nio.channels.OverlappingFileLockException;
import com.att.carat.load.Application;
import com.att.carat.load.LoadJob;

public class BatchCompressJob extends LoadJob implements FileFilter {
	private File	source_directory;
	private Pattern pattern = null;
	private Pattern zip_pattern = Pattern.compile(".*\\Q.\\EZIP"); //this pattern takes only files that end in ".ZIP"
	
	protected boolean configure(Application application, Properties configuration) {
		boolean result = super.configure(application, configuration);
		
		// Sets the optional pattern for the regular expression matching on determining if the file is to be transferred.
		String pattern = configuration.getProperty("pattern");
		if (pattern != null && !pattern.equals(""))
			this.pattern = Pattern.compile(pattern.toUpperCase());
		
		//SOURCE DIRECTORY
		if (configuration.getProperty("source_directory") == null || configuration.getProperty("source_directory").equals("")) {
			severe("'source_directory' configuration property missing.");
			return false;
		} else {
			source_directory = new File(configuration.getProperty("source_directory"));
		}
		
		return result;
	}
	
	protected boolean action() {
		boolean success = true;
		File files[] = source_directory.listFiles(this);
		
		for (int index = 0; index < files.length; index++) {
			
			boolean temp = true;
			File file = files[index];
			
			// Zipped file's filename.
			String zipped_file_filename = file.getName().substring(0, file.getName().lastIndexOf(".")) + ".ZIP";
			
			// Create new file_name for zipped file in source directory.
			File zipped_file = new File(source_directory, zipped_file_filename);
			
			if(zipped_file.exists()) {
				severe("Conflicting file in upload directory with name: " + zipped_file.getName());
				success = false;
				continue;
			}
			
			// Create Zip entry for file.
			ZipEntry entry = new ZipEntry(file.getName());
			
			// Create locks and channels
			FileLock lock = null;
			FileLock zipLock = null;
			FileChannel channel = null;
			FileChannel zipChannel = null;
			
			InputStream is = null;
			ZipOutputStream zos = null;
			
			try {
				// Lock stream reading from file
				channel = new RandomAccessFile(file, "rw").getChannel();
				lock = channel.tryLock();
				if (lock == null) {
					severe("Cannot read from " + file.getName() + ". Another program holds an overlapping lock.");
					success = false;
					continue;
				}
				
				is = Channels.newInputStream(channel);
				
				// Lock stream writing to zip
				zipChannel = new RandomAccessFile(zipped_file, "rw").getChannel();
				zipLock = zipChannel.tryLock();
				zos = new ZipOutputStream(Channels.newOutputStream(zipChannel));
				
				// Output the zip entry.
				zos.putNextEntry(entry);
				
				// Then output all the data for the file itself.
				byte[] data = new byte[1000];
				
				int count = is.read(data);
				while (count != -1) {
					zos.write(data, 0, count);
					count = is.read(data);
				}
				
			} catch (OverlappingFileLockException fle) {
	        	severe("Overlapping FileLock exception: "+fle.getMessage(),fle);
	        	temp = false;
	        } catch (ClosedChannelException ce) {
	        	severe("Closed channel exception: "+ce.getMessage(),ce);
	        	temp = false;
	        } catch (FileNotFoundException e) {
				severe("File '" + file.getName() + "' compression failed...Exception: " + e.toString()); 
				temp = false;
			} catch(IOException ioe){
				severe("IO file exception: "+ioe.getMessage(),ioe);
				temp = false;
			} catch(NullPointerException npe){
				severe("Null pointer exception: "+npe.getMessage(),npe);
				temp = false;
			} catch (Exception e){
				severe("Fatal exception: "+e.getMessage(),e);
				temp = false;
			} finally {
				//Close everything.
				try {
					if(lock != null)   		lock.release();
					if(zipLock != null)		zipLock.release();
					if(is != null)			is.close();
					if(zos != null)			zos.close();
					if(channel != null)		channel.close();
					if(zipChannel != null)	zipChannel.close();
				} catch (ClosedChannelException ce) {
		        	severe("Closed channel exception: "+ce.getMessage(),ce);
		        	temp = false;
		        } catch(IOException ioe){
					severe("IO file exception: "+ioe.getMessage(),ioe);
					temp = false;
				} catch(NullPointerException npe){
					severe("Null pointer exception, a lock, channel, or stream is null: "+npe.getMessage(),npe);
					temp = false;
				} catch (Exception e){
					severe("Fatal exception: "+e.getMessage(),e);
					temp = false;
				}
				
				if (temp) {
					file.delete();
					info("File '" + file.getName() + "' compression successful."); 
				} else {
					severe("File '" + file.getName() + "' compression failed."); 
				}
			}
			success &= temp;
		}
		
		return success;
	}
	
	protected boolean check() {
		return source_directory.listFiles(this).length > 0;
	}
	
	public boolean accept(File file) {
		return file.isFile() && (pattern == null || pattern.matcher(file.getName().toUpperCase()).matches()) && !zip_pattern.matcher(file.getName().toUpperCase()).matches();
	}
}
