/* Project: BAC_BATCH_FTP
 * RevenueFile: ArchiveZipJob.java
 * Package: com.sbc.bac.zip
 * Created on August 2, 2005 by gj7832
 * � 2002-2005 SBC Knowledge Ventures, L.P.  All rights reserved.
 */
package com.att.carat.load.util;

import java.io.InputStream;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import com.att.carat.load.Application;
import com.att.carat.load.FileModComparator;
import com.att.carat.load.LoadJob;

/** This job takes all the files in an input directory that match a given pattern and adds them
 * to a new zip archive in the archive directory. Input files successfully added to the archive 
 * are deleted.
 * 
 * Properties:
 * source_directory - Where the input files are coming from
 * archive_directory - Where to put the zip file
 * error_directory - Where to put files that cannot be added to the archive
 * pattern - A regular expression to match against file names. Those that match are added to the archive.
 * prefix - The file name. A time stamp and .ZIP extension will be appended
 * runtime - Day of week and time of day to run job. Format: EEE HH:mm (e.g. tue 23:59)
 * 
 * Sample configuration:
 * job1.name=MARVAL SO Extract Archive Job
 * job1.class=com.sbc.bac.zip.ArchiveZipJob
 * job1.source_directory=output
 * job1.archive_directory=output/archive
 * job1.error_directory=output/error
 * job1.pattern=MARVAL\\.SOXTRCT\\.(.)*?\\.TXT
 * job1.prefix=MARVAL.SOEXTRACT.ARCHIVE
 * job1.runtime=tue 10:00
 * 
 * Given files that look like this:
 * MARVAL.SOXTRCT.D2005234.T101003.TXT
 * MARVAL.SOXTRCT.D2005235.T101003.TXT
 * MARVAL.ADXTRCT.D2005235.T101003.TXT
 * 
 * This job will create a single archive that looks like this:
 * MARVAL.SOEXTRACT.ARCHIVE.08012005101000.ZIP
 * 
 * Containing 2 files:
 * MARVAL.SOXTRCT.D2005234.T101003.TXT
 * MARVAL.SOXTRCT.D2005235.T101003.TXT
 * 
 * The job will run on tuesday at 10:00 AM
 */
public final class ArchiveZipJob extends LoadJob implements FileFilter {
	private static final int BLKSIZE = 8192;
	private static final FileModComparator FILE_MOD_COMPARATOR = new FileModComparator();
	private static final SimpleDateFormat TIMESTAMP_FORMAT = new SimpleDateFormat("MMddyyyyHHmmss");
	private static final SimpleDateFormat RUNTIME_FORMAT = new SimpleDateFormat("EEE HH:mm");
	private static final String EXTENSION = ".ZIP";
	
	private Calendar runtime = Calendar.getInstance();
	private File source_directory;
	private File archive_directory;
	private File error_directory;
	private Pattern pattern = null;
	private boolean append_timestamp = false;
	private String prefix = null;
	private File zipFile = null;
	private ZipOutputStream zos = null;
	
	protected boolean configure(Application application, Properties configuration) {
		boolean result = super.configure(application, configuration);
		
		//Archive prefix
		if (configuration.getProperty("prefix") == null || configuration.getProperty("prefix").equals("")){
			severe("'prefix' configuration property missing.");
			result = false;
		}  else {
			prefix = configuration.getProperty("prefix");
		}
		
		//SOURCE DIRECTORY
		if (configuration.getProperty("source_directory") == null || configuration.getProperty("source_directory").equals("")){
			severe("'source_directory' configuration property missing.");
			result = false;
		}  else {
			source_directory = new File(configuration.getProperty("source_directory"));
		}
		
		//ERROR DIRECTORY
		if(configuration.getProperty("error_directory") == null || configuration.getProperty("error_directory").equals("")) {
			severe("'error_directory' configuration property missing.");
			result = false;
		} else {
			error_directory = new File(configuration.getProperty("error_directory"));
		}
			  
		//ARCHIVE DIRECTORY
		if(configuration.getProperty("archive_directory") == null || configuration.getProperty("archive_directory").equals("")){
			severe("'archive_directory' configuration property missing.");
			result = false;
		} else{
			archive_directory = new File(configuration.getProperty("archive_directory"));
		}
		
		// Pattern is the regular expression to use to match files in the source directory against. If the file name matches
		// the pattern, then the file will be uploaded. If no pattern is specified, it is assumed that all files in the source
		// directory are to be transfered
		String pattern = configuration.getProperty("pattern");
		if(pattern != null && !pattern.equals("")){
			this.pattern = Pattern.compile(pattern);
		}
		
		//Set load job runtime
		if(configuration.getProperty("runtime") == null || configuration.getProperty("runtime").equals("")){
			severe("'runtime' configuration property missing.");
			result = false;
		} else{
			String time = configuration.getProperty("runtime");
			try {
				//Set the run time
				runtime.setTime(RUNTIME_FORMAT.parse(time));
				
				//Set mm/dd/yy of runtime
				Calendar now = Calendar.getInstance();
				runtime.set(now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DATE));
				
				//Adjust if runtime has passed
				if (now.after(runtime)) runtime.add(Calendar.DATE, 7);
				info("'"+load_job_name+"' is scheduled to run again "+new Date(runtime.getTimeInMillis()));
			} catch (ParseException e) {
				severe("runtime entry could not be parsed.");
				result = false;
			}
			
		}
		
		return result;
	}
	
	protected boolean check() {
		if(Calendar.getInstance().after(runtime)){
			if(source_directory.listFiles(this).length > 0){
				return true;
			} else {
				info("No files to archive");
				runtime.add(Calendar.DATE, 7);
				info("'"+load_job_name+"' is scheduled to run again "+new Date(runtime.getTimeInMillis()));
				return false;
			}
		} else {
			return false;
		}
	}

	public boolean accept(File file) {
		return file.isFile() && file.canWrite() && (pattern == null || pattern.matcher(file.getName()).matches());
	}
	
	protected boolean action() {
		File files[] = source_directory.listFiles(this);
		Arrays.sort(files, FILE_MOD_COMPARATOR);
		for (int index = 0; index < files.length; index++){
			processFile(files[index]);
		}
		return true;
	}
	
	protected boolean preprocess() {
		boolean success = super.preprocess();
		if(success){
			zipFile = new File(archive_directory, getZipFileName());
			try {
				zos = new ZipOutputStream(new FileOutputStream(zipFile));
			} catch(IOException ioe){
				severe("Unable to create zip archive",ioe);
				success = false;
			}
		}
		return success;
	}
	
	private boolean preprocessFile(File file) {
		boolean success = true;
		timestamp = System.currentTimeMillis();
		
		//Add a zip entry for the file
		info("Adding file '" + file.getName() + "' to archive");
		try {
			zos.putNextEntry(new ZipEntry(file.getName()));
		} catch(IOException ioe){
			severe("Unable to add zip entry for file '"+file.getName()+"'",ioe);
			success = false;
		}
		
		return success;
	}
	
	protected boolean processFile(File file) {
		boolean success = preprocessFile(file);
		
		if(success) {
			InputStream is = null;
			try {
				is = new FileInputStream(file);
				byte[] b = new byte[BLKSIZE];
				int count = 0;
				while((count=is.read(b))!=-1){ 
					zos.write(b,0,count); 
				}
			} catch (FileNotFoundException e) {
				severe("Unable to open source file",e);
				success =  false;
			} catch (IOException e) {
				severe("Error adding entry to zip file",e);
				success = false;
			} finally {
				if(is != null){
					try { is.close(); } 
					catch (IOException e) {
						severe("Error closing input file",e);
						success = false;
					}
				}
			}
		}
		
		return postprocessFile(file, success);
	}
	
	private boolean postprocessFile(File file, boolean success) {
		try {
			zos.closeEntry();
		} catch(IOException ioe){
			severe("Unable to close zip entry for file '"+file.getName()+"'",ioe);
			success = false;
		}
		
		if(success) {
			info("Finished file '" + file.getName() + "'");
			file.delete();
		} else {
			severe("Errored file '" + file.getName() + "'");
			File destination = new File(error_directory, file.getName());
			if(destination.exists()){
				destination.delete();
			}
			if(!file.renameTo(destination)){
				severe("File rename failed for file '" + file.getPath() + "' to '" + destination.getPath() + "'");
			}
		}
		
		return success;
	}
	
	protected boolean postprocess(boolean success) {
		if(zos!=null){
			try { zos.close(); }
			catch(IOException ioe){
				severe("Error closing zip file",ioe);
				success = false;
			}
			zos = null;
		}
		
		if(success) { 
			runtime.add(Calendar.DATE, 7);
			info("'"+load_job_name+"' is scheduled to run again "+new Date(runtime.getTimeInMillis()));
		}
		
		return super.postprocess(success);
	}
	
	private String getZipFileName(){
		return prefix+"."+TIMESTAMP_FORMAT.format(new Date(timestamp))+EXTENSION;
	}
}
