/* Created on Sep 10, 2007 by Konstantin Degtyarenko (kd6197)
 * Copyright 2002-2006 AT&T Knowledge Ventures. All rights reserved
 */
package com.att.carat.load.util;

import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.Collections;
import java.util.List;
import java.util.Properties;
import java.util.Calendar;
import java.util.Vector;

import org.apache.log4j.Logger;

public class RuntimeUtil {
	
	protected static Logger logger = Logger.getLogger(RuntimeUtil.class);

	public static Calendar calculateRuntime(String interval, Properties configuration, Calendar now) throws IllegalArgumentException {
		Calendar runtime = Calendar.getInstance();
		SimpleDateFormat df = new SimpleDateFormat("HH:mm");
		String time = configuration.getProperty("runTime");
		try {
			if(time==null || time.length()==0) {
				throw new IllegalArgumentException("runTime cannot be null for interval daily");
			} else {
				runtime.setTime(df.parse(time.trim()));
			}
			if(interval.equalsIgnoreCase("daily")) {
				runtime.set(now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DATE));
			} else if (interval.equalsIgnoreCase("weekly")) {
				Integer dayOfWeek = Integer.parseInt(configuration.getProperty("dayOfWeek"));
				if (dayOfWeek>7 || dayOfWeek<1) {
					throw new IllegalArgumentException("Day of week must be between 1 and 7.");
				}
				runtime.set(now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DATE));
				if (now.get(Calendar.DAY_OF_WEEK)>dayOfWeek) {
					runtime.add(Calendar.DATE, 7);
				} else if (now.get(Calendar.DAY_OF_WEEK)==dayOfWeek) {
					if(now.after(runtime)) {
						runtime.add(Calendar.DATE, 7);
					}
				}
				if (runtime.get(Calendar.DAY_OF_WEEK)!=dayOfWeek) {
					runtime.set(Calendar.DAY_OF_WEEK,dayOfWeek);
				}
			} else if (interval.equalsIgnoreCase("monthly")) {
				Integer dayOfMonth = Integer.parseInt(configuration.getProperty("dayOfMonth"));
				runtime.set(now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DATE));
				if (now.get(Calendar.DAY_OF_MONTH)>dayOfMonth) {
					runtime.add(Calendar.MONTH, 1);
				} else if (now.get(Calendar.DAY_OF_MONTH)==dayOfMonth) {
					if(now.after(runtime)) {
						runtime.add(Calendar.MONTH, 1);
					}
				}
				runtime.set(Calendar.DAY_OF_MONTH, dayOfMonth);
			} else if (interval.equalsIgnoreCase("yearly")) {
				String date = configuration.getProperty("date");
				if (date==null || date.length()==0) throw new IllegalArgumentException("Date property is null.");
				String[] datez = date.split("/");
				if (datez.length!=2) throw new IllegalArgumentException("Date is not in valid format MM/DD");
				runtime.set(now.get(Calendar.YEAR), Integer.parseInt(datez[0])-1, Integer.parseInt(datez[1]));
				if(now.after(runtime)) {
					runtime.add(Calendar.YEAR, 1);
				}
			} else if(interval.equalsIgnoreCase("daysOfWeek")) {
				List<Integer> daysOfWeek = new Vector<Integer>();
				String days = configuration.getProperty("days")==null?null:configuration.getProperty("days").trim();
				daysOfWeek = getRunDays(days);
				runtime.set(now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DATE));
				if (daysOfWeek.contains(now.get(Calendar.DAY_OF_WEEK))) {
					if (now.after(runtime)) {
						while(!daysOfWeek.contains(runtime.get(Calendar.DAY_OF_WEEK))) {
							runtime.add(Calendar.DATE, 1);
						}
					}
				} else {
					while(!daysOfWeek.contains(runtime.get(Calendar.DAY_OF_WEEK))) {
						runtime.add(Calendar.DATE, 1);
					}
				} 
			} else {
				throw new IllegalArgumentException("Interval "+interval+" is unrecognized.");
			}
		} catch (ParseException pe) {
			throw new IllegalArgumentException("Unable to parse properties", pe);	
		}	
		return runtime;
	}
	
	public static Calendar incrementRuntime(String interval, Calendar runtime, Properties configuration) throws IllegalArgumentException {;
		if(interval.equalsIgnoreCase("daily")) runtime.add(Calendar.DATE, 1);
		else if (interval.equalsIgnoreCase("weekly")) runtime.add(Calendar.DATE, 7);
		else if (interval.equalsIgnoreCase("monthly")) runtime.add(Calendar.MONTH, 1);
		else if (interval.equalsIgnoreCase("yearly")) runtime.add(Calendar.YEAR, 1);
		else if (interval.equalsIgnoreCase("daysOfWeek")) {
			String dayz = configuration.getProperty("days")==null?null:configuration.getProperty("days").trim();
			List<Integer> days = getRunDays(dayz);
			runtime.add(Calendar.DATE, 1);
			while(!days.contains(runtime.get(Calendar.DAY_OF_WEEK))) {
				runtime.add(Calendar.DATE, 1);
			}
		}
		return runtime;
	}
	
	private static List<Integer> getRunDays(String days) throws IllegalArgumentException{
		List<Integer> daysOfWeek = new Vector<Integer>();
		String[] dayz = days.split(",");
		for (String day:dayz) {
			Integer d = Integer.parseInt(day);
			if (d>7 || d<1) {
				throw new IllegalArgumentException("Day "+d+" is invalid.");
			}
			daysOfWeek.add(Integer.parseInt(day));
		}
		Collections.sort(daysOfWeek);
		return daysOfWeek;
	}		
}
