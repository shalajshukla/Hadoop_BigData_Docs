/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.carat.load;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.FileNotFoundException;
import java.nio.channels.OverlappingFileLockException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Properties;
import java.nio.channels.*;
import java.io.RandomAccessFile;

/**
* Abstract class based on DBLoadJob that expects using files as the source of data to be loaded. 
* It looks for files matching the accept method to drive the parseLine method which takes the read 
* lines from the file and places it into the database.
* 
* In addition to parameters required for a regular load job, the following additional parameters must
* be specified in the applications configuration file: <BR>
* 	<BR>
* <code>
* 	<pre>
*   #Job Specific Parameters 
* 	
*   job1.source_directory=some_directory
*   job1.archive_directory=some_directory 
*   job1.error_directory=some_directory 
*	</pre>
*</code>
* @author Michael Peterson - mp2154
* @author Kevin Scudder - ks9383 
*/
abstract public class FileLoadJob extends LoadJob implements FileFilter {
	private static final FileModComparator file_mod_comp = new FileModComparator();
	
	/**Int value for success*/
	protected static final int SUCCESS = 0;
	/**Int value for skipped file*/
	protected static final int SKIPPED = 1;
	/**Int value for error*/
	protected static final int ERROR = 2;
	/**Counter variable*/
	protected int		counter[];
	/** Source directory file object*/
	protected File		source_directory;
	/** Archived directory file object*/
	protected File		archive_directory;
	/** Error Directory file object*/
	protected File		error_directory;
	
	/**
	 * Calls the super.configure, then stores where the source, archive, and error directories are.
	 * 
	 * @param application Application object.
	 * @param configuration Properties object with configuration info.
	 * @return success Boolean representing success/failure of configuration.
	 * @see DBLoadJob#configure(Application, Properties)
	 */
	protected boolean configure(Application application, Properties configuration) {
		boolean success = super.configure(application, configuration);
		//SOURCE DIRECTORY
		if (configuration.getProperty("source_directory") == null || configuration.getProperty("source_directory").equals("")){
			logger.error("'source_directory' configuration property missing.");
			return false;
		}  else {
			source_directory = new File(configuration.getProperty("source_directory").trim());
		}
		//ERROR DIRECTORY
		if(configuration.getProperty("error_directory") == null || configuration.getProperty("error_directory").equals("")) {
			logger.error("'error_directory' configuration property missing.");
			return false;
		} else {
			error_directory = new File(configuration.getProperty("error_directory").trim());
		}
		//ARCHIVE DIRECTORY
		if(configuration.getProperty("archive_directory") == null || configuration.getProperty("archive_directory").equals("")){
			logger.warn("'archive_directory' configuration property missing. Completed files will be deleted.");
			archive_directory = null;
		} else{
			archive_directory = new File(configuration.getProperty("archive_directory").trim());
		}
		
		return success;
	}
	/**
	 * This type of load job is required to run anytime there are available files in the source directory.
	 * 
	 * @return Boolean representing if there are any files in the source directory.
	 * @see LoadJob#check()
	 */
	protected boolean check() {
		return source_directory.listFiles(this).length > 0;
	}
	/**
	 * Processes each file individually.
	 * 
	 * @return result Boolean success/failure of processing of the files.
	 * @see LoadJob#action()
	 */
	protected boolean action() {
		File files[] = source_directory.listFiles(this);
		Arrays.sort(files, file_mod_comp);
		boolean result = true;
		for (int index = 0; index < files.length; index++)
			result &= processFile(files[index]);
		return result;
	}
	/**
	 * Do anything we need to on a file basis before we actually start loading the file such as setup a timer and counters.
	 * 
	 * @param file The current file in the process.
	 * @return Boolean success/failure of preprocessing of the files.
	 */
	protected boolean preprocessFile(File file) {
		timestamp = System.currentTimeMillis();
		logger.info("Starting file '" + file.getName() + "'");
		counter = new int[3];
		return true;
	}
	/**
	 * Do anything we need to on a file basis after we finish loading a file.
	 * This load job commits/rollsback each file individually.
	 * Any file commited gets moved to the archive directory, while any rolledback goes to the error directory.
	 * 
	 * @param file The current file in the process.
	 * @param success Boolean true/false whether file processed successfully.
	 * @return Boolean success/failure of postprocessing of the files.
	 */
	protected boolean postprocessFile(File file, boolean success) {
		File destination = null;
		if (success) {
			logger.info("Finished file '" + file.getName() + "' / time elapsed = " + (System.currentTimeMillis() - timestamp) + "ms / lines processed = " + counter[SUCCESS] + " / lines skipped = " + counter[SKIPPED] + " / lines per second = " + (int) ((counter[SUCCESS] * 1.0 / ((System.currentTimeMillis() - timestamp) * 0.001))));
			destination = archive_directory;
		} else {
		    logger.error("Errored file '" + file.getName() + "'");
			destination = error_directory;
		}
		//If the destination is null then delete the file, otherwise archive it
		if(destination==null){
			logger.info("Deleting file '"+file.getName()+"'");
			file.delete();
		} else {
			logger.info("Archiving file '"+file.getName()+"' to '"+destination.getPath()+"'");
			destination = new File(destination, file.getName() + fileSubfix(file));
			if (destination.exists())
				destination.delete();
			if (!file.renameTo(destination)) {
			    logger.error("File rename failed for file '" + file.getPath() + "' to '" + destination.getPath() + "'");
			}    
		}
		return success;
	}
	/**
	 * For the current file preform any preprocessing, then open the file reading it one line at a time which each line being parsed by the abstract method parseLine. Once all of the lines have been processed we execute the postprocess method and exit.
	 * 
	 * @param file the current file in the process.
	 * @return Boolean success/failure of processing of the current file.
	 */
	protected boolean processFile(File file) {
		boolean success = true;
		BufferedReader reader = null;
		FileChannel channel = null;
		FileLock lock = null;
		try {
		    channel = new RandomAccessFile(file, "rw").getChannel();
		    // Use the file channel to create a lock on the file.
		    lock = channel.tryLock();   
		    if (lock == null) {
		    	logger.warn("Could not aquire lock, file skipped"+file.getName());
		    	return true;
		    }
		    success = preprocessFile(file);
		    if (success) {
		    //Create reader
		    	InputStream is = Channels.newInputStream(channel);
		    	InputStreamReader in = new InputStreamReader(is); 
		    	reader = new BufferedReader(in);
		    	//Process file
		    	String line = reader.readLine();
		    	while (line != null) {
	    			if (line.length() != 0) counter[parseLine(line)]++;
	    			line = reader.readLine();
		    	}
		    }
		} catch (FileNotFoundException e) {
					logger.error("FileNotFoundException. File skipped.", e);
					success = true;
		} catch (OverlappingFileLockException e) {
		    	     // File is already locked in this thread or virtual machine
		    	  	logger.warn("File already locked by another thread . File skipped" + file.getName(), e);
		    	  	success = true;  	
		} catch (ClosedChannelException e) {
    	  			logger.error("Channel to file is closed. " + file.getName(), e);
    	  			success = false; 
		} catch (IOException e) {
		    		logger.error("File error occured - line " + (counter[0] + counter[1] + counter[2]) + " - ", e);
		    		success = false;
		} catch (SQLException e) {
		    		logger.error("Database error occured - line " + (counter[0] + counter[1] + counter[2]) + " - ", e);
		    		success = false;
		} catch (Exception e) {
		    		logger.error("Error occured " +e.getMessage(), e);
		    		success = false;
		} finally {
		    	try {
		    		if (reader != null) reader.close();
		    		// Release the lock
		    		if(lock != null) lock.release();
		    		// Close the file
		    		if (channel != null) channel.close();
		    	}   catch (IOException e) {
						logger.error("Error closing file - ", e);
				}	
		 }					
		return postprocessFile(file, success);
	}
	
	/**
	 * For files without changing names we can add a suffix to the file name when moving them to the archive or error directory. This method specifies the subfix.
	 * 
	 * @param file The current file in the process.
	 * @return A string containing the subfix of the file, if any.
	 */
	protected String fileSubfix(File file) {
		return "";
	}
	
	/**
	 * An abstract method of parsing the current line of the current file.
	 * 
	 * @param line The string with current line of the file in the process.
	 * @return The integer status of the current line.
	 */
	
	abstract protected int parseLine(String line) throws Exception;
	
	
	/**
	 * An abstract method of determining which files in the source directory to include or remove using the FileFilter interface.
	 * 
	 * @param dir The current file to include or remove from this load job.
	 * @return Boolean include or remove file from list.
	 * @see java.io.FileFilter
	 */
	
	abstract public boolean accept(File dir);
}
