/* Created on Aug 29, 2007 by Konstantin Degtyarenko (kd6197)
 * Copyright 2002-2006 AT&T Knowledge Ventures. All rights reserved
 */
package com.att.carat.load.hibernate.application;

import org.apache.log4j.Logger;

import java.sql.SQLException;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import com.att.carat.load.*;
import com.att.carat.load.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

/**
 * 
 * @author kd6197
 *
 */
public class HibernateApplication extends Application {
	protected Integer numberOfSessions;
	protected Map<String,Session> sessions = new HashMap<String, Session>();
	protected Map<String,SessionFactory> factories = new HashMap<String, SessionFactory>();
	protected Map<String, Transaction> transactions = new HashMap<String, Transaction>();
	protected Logger logger = Logger.getLogger(HibernateApplication.class);
	protected HibernateUtil util = HibernateUtil.getInstance();
	
	/**
	 * 
	 */
	protected boolean configure(String config_file) {
		String sessionName="";
		if (!super.configure(config_file)) 
			return false;
		try {
			Integer numberOfSessions = Integer.parseInt(configuration.getProperty("numberOfSessions"));
			for (int count=0; count<numberOfSessions; count++) {
				sessionName = configuration.getProperty("session"+(count+1)+".name");
				String sessionConfiguration = configuration.getProperty("session"+(count+1)+".config_file");
				if(sessionName==null || sessionName.equals("") || sessionConfiguration==null || sessionConfiguration.equals("")) {
					logger.error("Hibernate session parameters are missing.");
					return false;
				} else {
					logger.debug("Session config file: "+sessionConfiguration);
					SessionFactory factory = util.getSessionFactory(sessionConfiguration);
					factories.put(sessionName, factory);
				}
			}
		} catch (Exception e) {
			logger.error("Unable to create session "+sessionName, e);
			return false;
		}
		return true;
	}
	
	protected boolean preprocess() {
		Boolean result = super.preprocess();
		if (result) {
			for (String key : factories.keySet()) {
				sessions.put(key, factories.get(key).openSession());
			}
		}
		return result;
	}
		
	/**
	 * 
	 * 
	 */
	private void closeAllSessions() {
		util.shutdownAll();
	}
	
	/**
	 * 
	 * @param name
	 * @return
	 * @throws SQLException
	 */
	public Session getSession (String name) throws SQLException {
		if (name==null||!sessions.containsKey(name))
			throw new SQLException("Unrecognized session "+name);
		else
			return sessions.get(name);
	}
	
	
	/**
	 * 
	 * @param name
	 * @return
	 * @throws SQLException
	 */
	public Transaction getOpenTransaction(String name) throws SQLException {
		if (name==null||!sessions.containsKey(name)) {
			throw new SQLException("Unrecognized transaction "+name);
		} else {
			if (transactions.containsKey(name))
				return transactions.get(name);
			else {
				Transaction transaction = sessions.get(name).beginTransaction();
				transactions.put(name,transaction);
				return transaction;
			}
		}
	}
	
	public Map getAllOpenTransactions() throws SQLException {
		Set<String> sessionNames = sessions.keySet();
		Map<String, Transaction> transactions = new HashMap<String, Transaction>();
		for (String sessionName : sessionNames) {
			Transaction trans = getOpenTransaction(sessionName);
			transactions.put(sessionName, trans);
		}
		return transactions;
	}
	
	
	public void commitTransaction(String name) throws SQLException {
		if (name==null||!transactions.containsKey(name)) {
			throw new SQLException("Unrecognized transaction "+name);
		} else {
			Transaction transaction = transactions.get(name);
			transaction.commit();
		}
	}
	
	public void rollbackTransaction(String name) throws SQLException {
		if (name==null||!transactions.containsKey(name)) {
			throw new SQLException("Unrecognized transaction "+name);
		} else {
			Transaction transaction = transactions.get(name);
			transaction.rollback();
		}	
	}
	
	
	public void commitAllTransactionsAndClose() throws SQLException {
		Set<String> transactionNames = transactions.keySet();
		for (String transactionName : transactionNames) {
			Transaction trans = getOpenTransaction(transactionName);
			trans.commit();
		}
		//closeAllSessions();
	}
	
	public void rollbackAllTransactionsAndClose() throws SQLException {
		Set<String> transactionNames = transactions.keySet();
		for (String transactionName : transactionNames) {
			Transaction trans = getOpenTransaction(transactionName);
			trans.rollback();
		}
		//closeAllSessions();
	}
	
	protected boolean postprocess(boolean success) {
		info("Closing hibernate sessions");
		closeAllSessions();
		return super.postprocess(success);
	}

}
