/* Created on Aug 6, 2007 by Konstantin Degtyarenko (kd6197)
 * Copyright 2002-2006 AT&T Knowledge Ventures. All rights reserved
 */

package com.att.carat.load.util;

import org.apache.log4j.Logger;
import org.hibernate.*;
import org.hibernate.cfg.*;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Collection;

public class HibernateUtil {

	private static boolean initialized = false;
	private static Object lock = new Object();
	private static HibernateUtil instance = null;
	private Map<String, SessionFactory> sessionFactories = new HashMap<String, SessionFactory>();
	protected Logger logger = Logger.getLogger(HibernateUtil.class);
	
	private HibernateUtil() {
		// construct the singleton instance
	}
	
	public static HibernateUtil getInstance() {
		if (!initialized) {
			synchronized(lock) {
				if (instance == null) {
					instance = new HibernateUtil();
					initialized = true;
				}
	        }
		}
		return instance;
	}

	public SessionFactory getSessionFactory(String configuration) throws Exception {
		logger.debug("Configuration :"+configuration);
		if (sessionFactories.containsKey(configuration)) return sessionFactories.get(configuration);
		else {
			SessionFactory factory = new Configuration().configure(configuration).buildSessionFactory();
			sessionFactories.put(configuration, factory);
			return factory;
		}
	}
	
	public void shutdownAll() {
		Set<String> configurations = sessionFactories.keySet();
		for (String config : configurations) {
			logger.info("Closing "+config);
			sessionFactories.get(config).close();
		}
	}
	
}

