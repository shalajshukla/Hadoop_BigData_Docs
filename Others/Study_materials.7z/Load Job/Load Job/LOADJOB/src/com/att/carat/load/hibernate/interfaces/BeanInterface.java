/* Created on Aug 30, 2007 by Konstantin Degtyarenko (kd6197)
 * Copyright 2002-2006 AT&T Knowledge Ventures. All rights reserved
 */
package com.att.carat.load.hibernate.interfaces;

public interface BeanInterface extends java.io.Serializable {
	public void convert(Object...pars);
}
