/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.carat.load;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.ShortBufferException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;

import com.att.bac.carat.security.PasswordSecurity;
/**
* Subclass of Application class to account for load jobs where database processing is required. The primary changes are that the configuration now 
* expects database parameters and it opens a db connection during preprocess and closes the connection during post-process. <BR><BR>
* 
* Additional configuration parameters are required for this applications in the configuration file:<BR>
* <BR><BR>
* <code>
*   <pre>
*   driver_class=oracle.jdbc.OracleDriver
*   url=jdbc:oracle:url_string
*   username=your_username
*   password=your_password
*   </pre>
* </code>
* 
* @author Michael Peterson - mp2154
* @author Kevin Scudder - ks9383
* 
* 
*/
public class DBApplication extends Application {
	/**The database connection string */
	protected 	String			url;
	/**The database username string */
	protected 	String			username;
	/**The database password string */
	protected 	String			password;
	/**The database connection object */
	protected 	Connection 		connection = null;	
	/**
	 * Calls the super.configure, then looks for the database parameter plus loads the db driver class.
	 * Note...this function doesn't deal with the config_file, rather allows the super.configure to read the file and uses the resulting propreties object.
	 * 
	 * @param config_file String representing the property file name with configuration values.
	 * @return Boolean representing success/failure of configuration.
	 * @see Application#configure(String)
	 */
	protected boolean configure(String config_file) {
		if (!super.configure(config_file)) 
			return false;
		try {
			Class.forName(configuration.getProperty("driver_class").trim());
			url = configuration.getProperty("url").trim();
			/* Added by RS980G for PMT M168 */					
			PasswordSecurity ps = new PasswordSecurity();
			username = configuration.getProperty("username").trim();			
			password = ps.Decrypt(configuration.getProperty("password").trim()).trim();
			logger.info("Password decrypted successfully");
			if (url == null || url.equals("") ||
					username == null || username.equals("") ||
					password == null || password.equals("")) {
				logger.error("Database parameters missing.");
				return false;
			}
		}catch (ClassNotFoundException e) {
			logger.error("Driver class not found", e);
			return false;
		}catch (IllegalBlockSizeException e) {
			logger.error("Unable to decrypt. Check database passwords.", e);
			return false;
		}catch (ShortBufferException e) {
			logger.error("Unable to decrypt. Check database passwords.", e);
			return false;
		}catch (BadPaddingException e) {
			logger.error("Unable to decrypt. Check database passwords.", e);
			return false;
		}catch (InvalidKeyException e) {
			logger.error("Unable to decrypt. Check database passwords.", e);
			return false;
		}catch (NoSuchAlgorithmException e) {
			logger.error("Unable to decrypt.", e);
			return false;
		}catch (NoSuchProviderException e) {
			logger.error("Unable to decrypt.", e);
			return false;
		}catch (NoSuchPaddingException e) {
			logger.error("Unable to decrypt. Check database passwords.", e);
			return false; 
		}catch (Exception e) {
			logger.error("Check database parameters in the config file.", e);
			return false;
		}
		return true;
	}
	/**
	 * Gets the db connection generated in the preprocess method.
	 * 
	 * @return A valid connection to the database.
	 */
	public Connection getConnection() {
		try {
			logger.debug("Getting database connection.");
			if (connection == null || connection.isClosed()){ 
				connection = DriverManager.getConnection(url, username, password);
				connection.setAutoCommit(false);
			}
			return connection;
		} catch (SQLException e) {
			logger.error("SQL Connection Error", e);
			return null;
		}
	}
	/**
	 * Overridden version of Application.preprocess which after calling super.preprocess creates a db connection.
	 * 
	 * @return Boolean representing if preprocessing was successful.
	 * @see Application#preprocess()
	 */
	protected boolean preprocess() {
		if (!super.preprocess()) return false;
		return (getConnection() != null);
	}
	/**
	 * Overridden version of Application.postprocess which closes the db connection then calls super.postprocess.
	 * 
	 * @return Boolean representing if postprocessing was successful.
	 * @see Application#postprocess(boolean)
	 */
	protected boolean postprocess(boolean success) {
		try {
			if (connection != null) connection.close();
		} catch (SQLException e) {;
			logger.error("SQL close connection error.", e);
			success = false;
		} finally {
			connection = null;
		}
		return super.postprocess(success);
	}
	/**
	 * Gets the sequence name id from the "dual" table
	 * 
	 * @return Integer representing the id retrieved from table.
	 * @throws java.lang.exception If could not retrieve value.
	 * @throws java.lang.exception If SQL error occured.
	 **/
	public int getId(String sequence_name) throws java.lang.Exception {
		String sql = "select " + sequence_name + ".nextval from dual";
		int result = 0;		
		Statement statement = null;
		ResultSet rs = null;
		try {
			statement = connection.createStatement();
			rs = statement.executeQuery(sql);
			if (rs.next()) {
				result = rs.getInt(1);
			} else {
				throw new java.lang.Exception("Could not get id - Report.getId()");
			}
			rs.close();
			rs = null;
			statement.close();
			statement = null;
		} catch (SQLException e) {
			if (rs != null) {
				try {
					rs.close();
					statement.close();
				} catch (SQLException e2) {
					logger.error("SQL Exception", e2);}
				rs = null;
			}	
			throw new java.lang.Exception("Database error - Report.getId() - " + e.getMessage());
		}	
		return result;
	}	
}
