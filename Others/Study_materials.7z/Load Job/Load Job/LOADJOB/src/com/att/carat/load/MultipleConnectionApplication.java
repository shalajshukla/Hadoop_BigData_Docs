/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.carat.load;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;

import com.att.bac.carat.security.PasswordSecurity;
import com.att.carat.load.Application;
/**
* Class derived from the Application class representing applications with 
* multiple databse connections. <BR><BR>
* 
* Specify database configuration like this: <BR><BR>
*<code>
* <pre>
* number_of_connections=2 
* 
* connection_1.name=APPLICATION 
* connection_1.driver_class=oracle.jdbc.OracleDriver 
* connection_1.url=jdbc:oracle:thin:@ffups9a.ffcrc.pacbell.com:1521:ofar47 <BR>
* connection_1.username=dvlp0_application 
* connection_1.password=pa$$wo|2d 
* 
* connection_2.name=ANOTHER
* connection_2.driver_class=com.ncr.teradata.TeraDriver>
* connection_2.url=jdbc:teradata://CNEWD.sbc.com
* connection_2.username=usaname
* connection_2.password=fo-shizzle
* </pre>
*</code>
*
* If you don't specify a name for the connection it will be called "connection_x" where x is the connection number.
* 
* You must manually commit and rollback your connections in your load job's postprocess.
* 
* You will probably have to use a FileLoadJob and give it a custom application reference.
* 
* Call application.getConnection("CONNECTIONNAME") to get a specific connection.
* 
* @author Michael Peterson - mp2154
* @author Kevin Scudder - ks9383
* 
**/
public class MultipleConnectionApplication extends Application {
	
    private HashMap connections = new HashMap();
    
	private class ConnectionInfo {
	    /**Database connection string*/
		public String url;
		/**Database username*/
		public String username;
		/**Database password*/
		public String password;
		/**Database driver location*/
		public String driver;
		/**Database connection object*/
		public Connection connection = null;
	}
	/**
	 * Calls the super.configure, then looks for the database parameter plus loads the db driver class.
	 * Reads the config file and retrieves information such as the driver, url, username
	 * and password.
	 * 
	 * @param config_file String representing the property file name with configuration values.
	 * @return Boolean representing success/failure of configuration.
	 * @see Application#configure(String)
	 */

	protected boolean configure(String config_file) {
		if (!super.configure(config_file)) return false;
		
		int connectionCount = Integer.parseInt(configuration.getProperty("number_of_connections").trim());
		for(int i=1; i<=connectionCount; i++){
		    String connectionName = configuration.getProperty("connection_"+i+".name","connection_"+i).trim();
		    ConnectionInfo info = new ConnectionInfo();
			info.driver = configuration.getProperty("connection_"+i+".driver_class").trim();
			info.url = configuration.getProperty("connection_"+i+".url").trim();
			info.username = configuration.getProperty("connection_"+i+".username").trim();
			/* Added by RS980G for PMT M168 */
			PasswordSecurity ps = new PasswordSecurity();
			try{
				info.password = ps.Decrypt(configuration.getProperty("connection_"+i+".password").trim()).trim();
				logger.info("Password decrypted successfully for "+connectionName);
			}catch (Exception e) {
				logger.error("Unable to decrypt. Check database password for "+connectionName, e);
				return false;
			}			
			if (info.url == null || info.url.equals("") || info.username == null || info.username.equals("") || info.password == null || info.password.equals("")) {
				logger.error("Database parameters missing for"+connectionName);
				return false;
			}
			try {
			    Class.forName(info.driver);
			} catch (ClassNotFoundException e) {
				logger.error("Class Not Found for"+connectionName, e);
				return false;
			}
			connections.put(connectionName,info);
		}
		
		return true;
	}
	/**
	 * Gets the db connection generated in the preprocess method.
	 * 
	 * @param name A string representing the connection name.
	 * @throws SQLException if database error is encountered.
	 * @return A valid connection to the database.
	 */	
	public Connection getConnection(String name) throws SQLException {
	    ConnectionInfo info = (ConnectionInfo)connections.get(name);
	    if(info==null){
	        throw new SQLException("Unrecognized connection \""+name+"\"");
	    } else {
		    if (info.connection == null || info.connection.isClosed()){ 
		        info.connection = DriverManager.getConnection(info.url, info.username, info.password);
		        info.connection.setAutoCommit(false);
		    }
	    }
	    return info.connection;
	}
	/**
	 * Opens all database connections. Method is called my the preprocess
	 * @return Boolean true/false whether the connection openning was successful
	 */	
	private boolean openAllConnections(){
		logger.info("Opening all database connections");
	    for(Iterator i = connections.keySet().iterator(); i.hasNext(); ){
	        String connectionName = (String)i.next();
		    try {
			    getConnection(connectionName);
			} catch (SQLException e) {
				logger.error("Database error during connection to \""+connectionName+"\"- SQLException: ", e);
				return false;
			}
	    }
		return true;
	}
	/**
	 * Closes all database connections. Method is called by the postprocess.
	 * 
	 */	
	private void closeAllConnections(){
		logger.info("Closing all database connections");
	    for(Iterator i = connections.keySet().iterator(); i.hasNext(); ){
	        String connectionName = (String)i.next();
	        ConnectionInfo info = (ConnectionInfo)connections.get(connectionName);
	        if(info!=null&&info.connection!=null){
	            try { info.connection.close(); }
	            catch(SQLException sqle){ /* Ignore */ }
	        }
	    }
	}
	/** Does general preprocessing. Calls the OpenAllConnections method
	 * @return Boolean whether preprocess was successful.
	 *  
	 */
	protected boolean preprocess() {
		if (!super.preprocess()) return false;
		return openAllConnections();
	}
	/** Does general postprocessing. Calls CloseAllConnections. No commit 
	 * or rollback is done on any connection.
	 * @return Boolean whether the postprocessing was successful.
	 *  */
	protected boolean postprocess(boolean success) {
		closeAllConnections();
		return super.postprocess(success);
	}
}
