/* Created on Sep 4, 2007 by Konstantin Degtyarenko (kd6197)
 * Copyright 2002-2006 AT&T Knowledge Ventures. All rights reserved
 */
package com.att.carat.load.hibernate.loadjob;

import com.att.carat.load.hibernate.interfaces.BeanInterface;

public class Loadable {
	public final String whereClause;
	public final BeanInterface beanClass;
	//public final Object beanInstance;
	
	public Loadable(String whereClause, BeanInterface beanClass) {
		this.whereClause=whereClause;
		this.beanClass=beanClass;
	}
	
}
