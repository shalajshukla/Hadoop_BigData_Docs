/**
* � 2002-2006 AT&T Knowledge Ventures. All rights reserved.
* 
* @author mp2154
* @author Eric Teng - et8278
* 
* 
* A load job that takes all files matching a pattern specified in the config file
* and FTP's each file. Completed files are moved to archive directory
* and errored files are moved to error directory.
*/
package com.att.carat.load.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.io.FileFilter;
import java.nio.channels.Channels;
import java.nio.channels.FileLock;
import java.nio.channels.FileChannel;
import java.nio.channels.OverlappingFileLockException;
import java.nio.channels.ClosedChannelException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Properties;
import java.util.regex.Pattern;

import com.oroinc.net.ftp.FTP;
import com.oroinc.net.ftp.FTPClient;
import com.oroinc.net.ftp.FTPReply;
import com.att.carat.load.Application;
import com.att.carat.load.FileModComparator;
import com.att.carat.load.LoadJob;

/** FTPs files to an FTP server.
 * 
 * Properties:
 * source_directory - Where the files we want to upload come from
 * archive_directory - Where the files we want to upload are stored after upload
 * error_directory - Where the files we want to upload go when they die
 * destination_directory - Where the files are going to end up on the remote machine (only required for non-mvs)
 * transfer_directory - Where the files are going to go on the remote machine during transfer (optional, defaults to destination_directory)
 * server - The host name or ip of the ftp server
 * username - The ftp user name
 * password - The ftp password
 * append_timestamp - Add a timestamp to the files after archiving them (not on remote machine)? (true|false)
 * to_mvs - Is the destination an MVS system? (true|false) If true, destination_directory and transfer_directory are ignored
 * binary_mode - Sending a binary file? This mode is incompatible with MVS.
 * 
 * Sample config:
 * job1.name=Save Chris From Hippies
 * job1.class=com.sbc.bac.ftp.BatchFTPJob
 * job1.server=ftp.alvorddesert.com
 * job1.username=joebob
 * job1.password=chrisledouxrox
 * job1.source_directory=chris_ledoux_mp3
 * job1.archive_directory=chris_ledoux_mp3/yeehaw
 * job1.error_directory=chris_ledoux_mp3/dang
 * job1.destination_directory=/safe/and/sound
 * job1.transfer_directory=/var/temp
 * job1.pattern=(Chris)(.)(LeDoux)(.)+\\.[Mm][Pp]3
 * job1.append_timestamp=false
 * job1.to_mvs=false
 * 
 * The result of this will be that all of Joe-Bob's Chris LeDoux MP3's will be archived to a secure location, 
 * probably in a geothermal-powered, underground datacenter in Eastern Oregon's Alvord Desert.
 */
public class BatchFTPJob extends LoadJob implements FileFilter{
	
	private static final FileModComparator file_mod_comp = new FileModComparator();
	
	protected static final int SUCCESS = 0;
	protected static final int SKIPPED = 1;
	protected static final int ERROR = 2;
	protected static final int DUPLICATE = 3;
	protected static int EMPTY_FILE = 4;
	
	protected File source_directory = null;
	protected File error_directory = null;
	protected File archive_directory = null;
	
	
	private static SimpleDateFormat timestampFormat = new SimpleDateFormat("MMddyyyyHHmmss");
	private String server = null;
	private String username = null;
	private String password = null;
	protected FTPClient ftp = null;
	private String transfer_directory = null;
	private String destination_directory = null;
	private Pattern pattern = null;
	private boolean compress = false;
	private boolean append_timestamp = false;
	private boolean to_mvs = false;
	private int lrecl = 200;
	private int blocksize = 0;
	private String recfm = "FB";
	private boolean binary_mode = false;
	
	protected FileChannel channel = null;
	protected FileLock lock = null;
	protected InputStream is = null;
	
	protected boolean configure(Application application, Properties configuration) {
		boolean result = super.configure(application, configuration);
		
		//Server is the host name of the FTP server
		server = configuration.getProperty("server");
		if(server == null || server.equals("")){
		    //Try to get it from the application if the application is a BatchFTPApplication
		    if(application instanceof BatchFTPApplication){
		        server = ((BatchFTPApplication)application).getServer();
		    }
			
			//If it is still missing, print error
			if(server == null || server.equals("")){
			    severe("FTP job configuration missing 'server' property. Please add 'server' property to FTP job configuration.");
			    result = false;
			}
		}
		
		//Username is the FTP user name
		username = configuration.getProperty("username");
		if(username == null || username.equals("")){
		    //Try to get it from the application if the application is a BatchFTPApplication
		    if(application instanceof BatchFTPApplication){
		        username = ((BatchFTPApplication)application).getUsername();
		    }
		    
		    //If it is still missing, print error and fail
		    if(username == null || username.equals("")){
		        severe("FTP job configuration missing 'username' property. Please add 'username' property to FTP job configuration.");
		        result = false;
		    }
		}
		
		//Password is the FTP password
		password = configuration.getProperty("password");
		if(password == null || password.equals("")){
		    //Try to get it from the application if the application is a BatchFTPApplication
		    if(application instanceof BatchFTPApplication){
		        password = ((BatchFTPApplication)application).getPassword();
		    }
		    
		    //If it is still missing, print error and fail
		    if(password == null || password.equals("")){
		        severe("FTP job configuration missing 'password' property. Please add 'password' property to FTP job configuration.");
		        result = false;
		    }
		}
		
		// destination directory is the final destination of the file on the FTP server
		destination_directory = configuration.getProperty("destination_directory");
		// Zero length folder means we're going to an MVS system
		if (destination_directory!=null && destination_directory.length() > 0){
		    char last = destination_directory.charAt(destination_directory.length() - 1); 
		    if(last != '/' && last !='\\'){
		        destination_directory += "/";
		    }
		}
		
		// transfer directory is the destination of the file during transfer. The job will move the file from the
		// transfer directory to the destination directory when file transfer is complete. If transfer directory is
		// not supplied it is assumed that the destination directory can be used for transfer
		transfer_directory = configuration.getProperty("transfer_directory");
		// Zero length folder probably means we're going to an MVS system or directly to the destination folder
		if(transfer_directory!=null && transfer_directory.length() > 0){
		    char last = transfer_directory.charAt(transfer_directory.length() - 1); 
		    if(last != '/' && last !='\\'){
		        transfer_directory += "/";
		    }
		} else {
			transfer_directory = destination_directory;
		}
		
		// source directory is the where the files are pulled from.
		// If there is no source directory currently existing, an error is logged
		if(configuration.getProperty("source_directory") == null || configuration.getProperty("source_directory").equals("")){
			severe("'source_directory' configuration property missing. Please specify 'source_directory' in ftp configuration file.");
			result = false;
		} else{
			source_directory = new File(configuration.getProperty("source_directory"));
			if(!source_directory.isDirectory()){
				severe("Missing source directory.");
			}
		}
		
		// error directory is the destination of files that do not complete successfully. The job will move the file
		// from the source directory to this directory if this is an errored file.
		// If there is no error directory currently existing, a notification is logged that the directory is created.
		if(configuration.getProperty("error_directory") == null || configuration.getProperty("error_directory").equals("")){
			severe("'error_directory' configuration property missing. Please specify 'error_directory' in ftp configuration file.");
			result = false;
		} else{
			error_directory = new File(configuration.getProperty("error_directory"));
			if(!error_directory.isDirectory()){
				error_directory.mkdirs();
				info("Error Directory Successfully Created.");
			}
		}
		
		// archive directory is the destination of files that complete successfully. The job will move the file
		// from the source directory to this directory if the file is sent successfully.
		// If there is no archive directory currently existing, a notification is logged that the directory is created.
		if(configuration.getProperty("archive_directory") == null || configuration.getProperty("archive_directory").equals("")){
			severe("'archive_directory' configuration property missing. Please specify 'archive_directory' in ftp configuration file.");
			result = false;
		} else{
			archive_directory = new File(configuration.getProperty("archive_directory"));
			if(!archive_directory.isDirectory()){
				archive_directory.mkdirs();
				info("Archive Directory Successfully Created.");
			}
		}
		
		// Pattern is the regular expression to use to match files in the source directory against. If the file name matches
		// the pattern, then the file will be uploaded. If no pattern is specified, it is assumed that all files in the source
		// directory are to be transfered
		String pattern = configuration.getProperty("pattern");
		if (pattern != null && !pattern.equals(""))
			this.pattern = Pattern.compile(pattern);
		
		// Set the flag for compressing the file before transferring it.
		compress = configuration.getProperty("compress", "false").equalsIgnoreCase("true");
		
		// Set the flag for appending a timestamp to the archived file. This is particularly useful for MVS uploads
		// with generation tags (i.e. '(+1)').
		append_timestamp = configuration.getProperty("append_timestamp", "false").equalsIgnoreCase("true");
		
		// Set the flag for transferring files to MVS. If sending a file to MVS, then transfer directory and destination
		// directory are ignored. It is assumed that the file name correctly specifies the destination.
		to_mvs = configuration.getProperty("to_mvs", "false").equalsIgnoreCase("true");
		
		// Set the flag for transferring binary files. Default mode is auto
		binary_mode = configuration.getProperty("binary_mode","false").equalsIgnoreCase("true");
		
		//Check to make sure we aren't trying to send binary to MVS
		if(binary_mode && to_mvs){
		    severe("Binary and MVS modes are incompatible. Please choose one or the other.");
			result = false;
		}
		
		//Check to make sure we have a destination directory if we are going to a server and not MVS
		if(!to_mvs&&(destination_directory==null||"".equals(destination_directory))){
			severe("Please specify a destination directory when sending files to a UNIX or Windows server. Set the 'to_mvs' property to 'true' when sending files to an MVS system.");
			result = false;
		}
		
		if(to_mvs){
			//Must have an LRECL when sending to MVS
			String lrecl_string = configuration.getProperty("lrecl");
			if(lrecl_string==null || !lrecl_string.matches("[0-9]+")){
				severe("Please specify a value for LRECL when sending files to MVS.");
				result = false;
			} else {
				lrecl = Integer.parseInt(lrecl_string);
			}
		} 
		
		//Print info id transfer_directory is not specified and we are not going to MVS
		if(!to_mvs && transfer_directory.equals(destination_directory)){
		    info("'transfer_directory' not specified. Files will be transferred directly to destination directory.");
		}
		
		return result;
	}
	
	/**
	 * To process this load job we must process each file individually.
	 * 
	 * @return success/failure of processing of the files.
	 * @see LoadJob#action()
	 */
	
	protected boolean action() {
		//Process each file in source directory
		File files[] = source_directory.listFiles(this);
		Arrays.sort(files, file_mod_comp);
		boolean result = true;
		for (int index = 0; index < files.length; index++)
			result &= processFile(files[index]);
		
		return result;
	}
	
	/** Connect to FTP server */
	protected boolean preprocess() {
		boolean success = super.preprocess();
		
		if(success){ 
			ftp = new FTPClient();

			ftp.enterLocalActiveMode();
			try {
				ftp.connect(server);

				if (FTPReply.isPositiveCompletion(ftp.getReplyCode())) {
					ftp.login(username, password);
					if(ftp.getReplyCode()!=230){
						severe("Unable to login to FTP server: "+ftp.getReplyString());
						success = false;
					}
				} else {
					ftp.disconnect();
					severe("FTP server refused connection.");
					success = false;
				}
			} catch (IOException e) {
		    	if(ftp!=null&&ftp.isConnected()) {
					try { ftp.disconnect();	} 
					catch(IOException ignore) { /* ignore */ }
				}
				severe("Error connecting to FTP server."+e,e);
				ftp = null;
				success = false;
			}
		}
		
		return success;
	}
	
	/** upload the file to the transfer directory and move it to the destination directory */
	protected boolean processFile(File file) {
	    int success = preprocessFile(file);
	    
		try{
			if (success == SUCCESS) {
				try {					
					//Get input stream from locked file channel
					is = Channels.newInputStream(channel);
					
					//If we are sending to mvs we need to send the LRECL, BLOCKSIZE and RECFM
					if(to_mvs){
						ftp.sendSiteCommand("LRECL="+lrecl);
						if(ftp.getReplyCode()==200){
							ftp.sendSiteCommand("BLOCKSIZE=0");
							if(ftp.getReplyCode()==200){
								ftp.sendSiteCommand("RECFM=FB");
								if(ftp.getReplyCode()==200){
									//Yay!
								} else {
									severe("Unable to set RECFM: "+ftp.getReplyString());
									success = ERROR;
								}
							} else {
								severe("Unable to set BLOCKSIZE: "+ftp.getReplyString());
								success = ERROR;
							}
						} else {
							severe("Unable to set LRECL: "+ftp.getReplyString());
							success = ERROR;
						}
					}
					
					//If it is still happy, transfer file to FTP server transfer directory
					if(success == SUCCESS){
						if(binary_mode){
							info("Mode is Binary");
							ftp.setFileType(FTP.BINARY_FILE_TYPE);
						}
						if (!ftp.storeFile(to_mvs?("'"+file.getName()+"'"):(transfer_directory + file.getName()), is)) {
							success = ERROR;
						}
						if(ftp.getReplyCode()!=(to_mvs?250:226)){
							severe("Unable to upload file to FTP server: "+ftp.getReplyString());
							success = ERROR;
						} else {
							//Move file to FTP destination directory when sending to a server and the destination does not equal the transfer directory
							if ((success == SUCCESS) && !to_mvs && !(transfer_directory + file.getName()).equals(destination_directory + file.getName())){
								if(!ftp.rename(transfer_directory+file.getName(), destination_directory+file.getName())) {
									success = ERROR;
								}
								if(ftp.getReplyCode()!=250){
									severe("Unable to move file from transfer directory to destination directory: "+ftp.getReplyString());
									success = ERROR;
								}
							}
						}
					}
				} catch (FileNotFoundException e) {
					severe("File input stream - Exception: " + e.toString());
					success =  ERROR;
				} catch (IOException e) {
					severe("FTP store file or rename - IOException: " + e.toString());
					success = ERROR;
				} 
			}	
		} catch(RuntimeException re){
			severe("Runtime exception "+re,re);
			return false;
		}
		
		success = postprocessFile(file, success);
		
		return (success == SUCCESS || success == SKIPPED || success == EMPTY_FILE);
	}
	
	/** Disconnect from FTP server */
	protected boolean postprocess(boolean success) {
		if(ftp!=null){
			try {
				ftp.disconnect();
			} catch(IOException e){
				ftp = null;
				success = false;
			}
		}
		return super.postprocess(success);
	}
	
	
	protected int preprocessFile(File file) {
		timestamp = System.currentTimeMillis();
		info("Starting file '" + file.getName() + "'");
		
		int success = SUCCESS;
		
		try {
			//Try locking the file
			channel = new RandomAccessFile(file, "rw").getChannel();
			lock = channel.tryLock();
			if (lock == null) {
				severe("Cannot lock " + file.getName() + ". Another program holds an overlapping lock.");
				success = SKIPPED;
			} 
		} catch (FileNotFoundException e) {
			severe("File not found - Exception: " + e.toString());
			success = SKIPPED;
		} catch (OverlappingFileLockException fle) {
			application.severe("Overlapping FileLock exception: "+fle.getMessage(),fle);
			success = SKIPPED;
		} catch (ClosedChannelException ce) {
			application.severe("Closed channel exception: "+ce.getMessage(),ce);
			success = SKIPPED;
		} catch (IOException e) {
			severe("Error while locking file - IOException: " + e.toString());
			success = ERROR;
		}
		return success;
	}
	
	/**Release lock on file from other threads */
	protected int postprocessFile(File file, int success) {
		try {
			//Release lock on file
			if(lock != null) lock.release(); 
			if(is != null) is.close(); 
			if(channel != null) channel.close();
		} catch (ClosedChannelException ce) {
			severe("Closed channel exception: "+ce.getMessage(),ce);
			success = ERROR;
		} catch (IOException e) {
			severe("Error closing file - IOException: " + e.toString());
			success = ERROR;
		} 
		
		//Deal with situations
		File destination = null;
		
		if (success == SUCCESS) {
			info("Finished file '" + file.getName() + "' / time elapsed = " + (System.currentTimeMillis() - timestamp) + "ms");
			destination = archive_directory;
		} 
		else if(success == EMPTY_FILE) {
			info("Finished empty file '" + file.getName() + "' / time elapsed = " + (System.currentTimeMillis() - timestamp) + "ms");
			destination = archive_directory;
		}
		else if (success == SKIPPED) {
			info("Skipped file '" + file.getName() + "'");
			//Do nothing, next time run it should pick it up
			
		} else if (success == ERROR) {
			severe("Errored out file '" + file.getName() + "'");			
			destination = error_directory;
		}
		
		if (destination != null) {
			destination = new File(destination, file.getName() + fileSubfix(file));
			if (destination.exists())
				destination.delete();
			if (!file.renameTo(destination))
				severe("File rename failed for file '" + file.getPath() + "' to '" + destination.getPath() + "'");
		}
		
		return success;
	}
	
	protected int parseLine(String line) throws Exception {
		throw new UnsupportedOperationException("parseLine is not used in this job");
	}
	
	/** Append any necessary timestamps to the file */
	protected String fileSubfix(File file) {
		if(append_timestamp && file!=null){
			Date ts = new Date(timestamp);
			return "."+timestampFormat.format(ts);
		} else {
			return "";
		}
	}
	
	/**
	 * This type of load job is required to run anytime there are available files in the source directory.
	 * 
	 * @return if there are any files in the source directory.
	 * @see LoadJob#check()
	 */
	
	protected boolean check() {
		return source_directory.listFiles(this).length > 0;
	}
	
	/**
	 * An abstract method of determining which files in the source directory to using by implememting the FileFilter interface.
	 * 
	 * @param file- the current file to include or remove from this load job.
	 * @return include or remove file from list.
	 * @see java.io.FileFilter
	 */
	public boolean accept(File file) {
		return file.isFile() && file.canWrite() && (pattern == null || pattern.matcher(file.getName()).matches());
	}
	
	
}
