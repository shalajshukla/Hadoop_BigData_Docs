/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.carat.load;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

/** Abstract class based on LoadJob that adds things like db connections and commit/rollback functionality.
*   Database parameters must be specified in the application's configuration file in the following format. <BR><BR>
*
* <code>
*  <pre>
*   driver_class=oracle.jdbc.OracleDriver
*   url=jdbc:oracle:url_string
*   username=your_username
*   password=your_password
*  </pre>
*</code>
* 	@author Michael Peterson - mp2154
* 	@author Kevin Scudder - ks9383
**/
abstract public class DBLoadJob extends LoadJob {
	/**Database connection object instance*/
	protected	Connection connection = null;
	/**DBApplication object instance*/
	protected	DBApplication application;
	
	/**
	 * Calls the super.configure, then stores an instance of the DBApplication to access it's specific methods.
	 * 
	 * @param application The application object instance.
	 * @param configuration The properties object with configuration info.
	 * @return Boolean success/failure of configuration.
	 * @see LoadJob#configure(Application, Properties)
	 */
	protected boolean configure(Application application, Properties configuration) {
		if (!super.configure(application, configuration)) return false;
		try {this.application = (DBApplication) application;}
		catch (Exception e){
			logger.error("Runtime exception occured ", e);	
			return false;
		}
		return true;
	}
	/**
	 * Calls super.preprocess, then sets the local connection variable to the one in application.
	 * 
	 * @return Boolean success/failure of preprocessing.
	 * @see LoadJob#preprocess()
	 */
	protected boolean preprocess() {
		boolean success = super.preprocess();
		logger.info("Requesting database connection from application");
		connection = application.getConnection();
		return true;
	}
	/**
	 * Commits or rollsback the connection, depending on the success variable, before calling super.postprocess.
	 * 
	 * @param success Success/failure of the processing so far.
	 * @return Boolean success/failure of postprocessing.
	 * @see LoadJob#postprocess(boolean)
	 */
	protected boolean postprocess(boolean success) {
		if (success) {
			try  {
				connection.commit();
			} catch (SQLException e) {
				logger.error("Commit failed. ", e);
				success = false;
			}
		}
		if (!success) {
			logger.error("Job ended with errors");
			try  {
				connection.rollback();
			} catch (SQLException e) {
				logger.error("Rollback failed", e);
			}
		}
		return super.postprocess(success);
	}
	
}
