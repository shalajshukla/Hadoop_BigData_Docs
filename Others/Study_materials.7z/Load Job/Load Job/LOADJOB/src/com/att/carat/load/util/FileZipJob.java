/* Project: BAC_BATCH_FTP
 * RevenueFile: FileZipJob.java
 * Package: com.sbc.bac.zip
 * Created on August 2, 2005 by gj7832
 * � 2002-2005 SBC Knowledge Ventures, L.P.  All rights reserved.
 */
package com.att.carat.load.util;

import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Properties;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import com.att.carat.load.Application;
import com.att.carat.load.FileModComparator;
import com.att.carat.load.LoadJob;

/** This job takes all the files in a directory that match a given pattern and places them into
 * an archive. There is one archive per input file. Input files that are successfully zipped will
 * be deleted.
 * 
 * Properties:
 * source_directory - Where the input files are coming from
 * archive_directory - Where to put the zip files
 * error_directory - Where to put files that error out
 * pattern - A regular expression to match against file names. Those that match are placed in an archive
 * append_timestamp - Add a timestamp to the file name (true|false)
 * 
 * Sample configuration:
 * job1.name=Zip File Job
 * job1.class=com.sbc.bac.zip.FileZipJob
 * job1.source_directory=output
 * job1.archive_directory=output/archive
 * job1.error_directory=output/error
 * job1.pattern=TEST(.*)\\.TXT
 * job1.append_timestamp=true
 * 
 * Given files like this:
 * TEST01.TXT
 * TEST02.TXT
 * TEST03.TXT
 * 
 * This job will produce archives that look like this:
 * TEST01.TXT.08012005101011.ZIP
 * TEST02.TXT.08012005101012.ZIP
 * TEST03.TXT.08012005101013.ZIP
 */
public class FileZipJob extends LoadJob implements FileFilter {
	private static final int BLKSIZE = 8192;
	private static final FileModComparator FILE_MOD_COMPARATOR = new FileModComparator();
	private static SimpleDateFormat TIMESTAMP_FORMAT = new SimpleDateFormat("MMddyyyyHHmmss");
	private String EXTENSION = ".ZIP";
	
	protected int counter[];
	protected File source_directory;
	protected File archive_directory;
	protected File error_directory;
	private Pattern pattern = null;
	private boolean append_timestamp = false;
	
	protected boolean configure(Application application, Properties configuration) {
		boolean result = super.configure(application, configuration);
		
		//SOURCE DIRECTORY
		if (configuration.getProperty("source_directory") == null || configuration.getProperty("source_directory").equals("")){
			severe("'source_directory' configuration property missing.");
			result = false;
		}  else {
			source_directory = new File(configuration.getProperty("source_directory"));
		}
		
		//ERROR DIRECTORY
		if(configuration.getProperty("error_directory") == null || configuration.getProperty("error_directory").equals("")) {
			severe("'error_directory' configuration property missing.");
			result = false;
		} else {
			error_directory = new File(configuration.getProperty("error_directory"));
		}
			  
		//ARCHIVE DIRECTORY
		if(configuration.getProperty("archive_directory") == null || configuration.getProperty("archive_directory").equals("")){
			severe("'archive_directory' configuration property missing.");
			result = false;
		} else{
			archive_directory = new File(configuration.getProperty("archive_directory"));
		}
		
		// Pattern is the regular expression to use to match files in the source directory against. If the file name matches
		// the pattern, then the file will be uploaded. If no pattern is specified, it is assumed that all files in the source
		// directory are to be transfered
		String pattern = configuration.getProperty("pattern");
		if(pattern != null && !pattern.equals("")){
			this.pattern = Pattern.compile(pattern);
		}
		
		// Set the flag for appending a timestamp to the archived file. This is particularly useful for MVS uploads
		// with generation tags (i.e. '(+1)').
		append_timestamp = configuration.getProperty("append_timestamp", "false").equalsIgnoreCase("true");
		
		return result;
	}
	
	protected boolean check() {
		return source_directory.listFiles(this).length > 0;
	}

	public boolean accept(File file) {
		return file.isFile() && file.canWrite() && (pattern == null || pattern.matcher(file.getName()).matches());
	}
	
	protected boolean action() {
		File files[] = source_directory.listFiles(this);
		Arrays.sort(files, FILE_MOD_COMPARATOR);
		for (int index = 0; index < files.length; index++){
			processFile(files[index]);
		}
		return true;
	}
	
	protected boolean preprocessFile(File file) {
		timestamp = System.currentTimeMillis();
		info("Starting file '" + file.getName() + "'");
		counter = new int[3];
		return true;
	}
	
	/** upload the file to the transfer directory and move it to the destination directory */
	protected boolean processFile(File file) {
		boolean success = preprocessFile(file);
		
		if (success) {
			InputStream is = null;
			ZipOutputStream zos = null;
			try {
				//Open file
				File zipFile = new File(archive_directory, getZipFileName(file));
				is = new FileInputStream(file);
				zos = new ZipOutputStream(new FileOutputStream(zipFile));
				zos.putNextEntry(new ZipEntry(file.getName()));
				int count = 0;
				byte[] b = new byte[BLKSIZE];
				while((count=is.read(b))!=-1){ 
					zos.write(b,0,count); 
				}
				zos.closeEntry();
			} catch (FileNotFoundException e) {
				severe("Unable to open source file",e);
				success =  false;
			} catch (IOException e) {
				severe("Error creating zip file",e);
				success = false;
			} finally {
				if(zos!=null){
					try { zos.close(); } 
					catch(IOException e){
						severe("Error closing zip file",e);
						success = false;
					}
				}
				if(is != null){
					try { is.close(); } 
					catch (IOException e) {
						severe("Error closing input file",e);
						success = false;
					}
				}
			}
		}
		
		return postprocessFile(file, success);
	}
	
	protected boolean postprocessFile(File file, boolean success) {
		if(success) {
			info("Finished file '" + file.getName() + "'");
			file.delete();
		} else {
			severe("Errored file '" + file.getName() + "'");
			File destination = new File(error_directory, file.getName());
			if (destination.exists()){
				destination.delete();
			}
			if (!file.renameTo(destination)){
				severe("File rename failed for file '" + file.getPath() + "' to '" + destination.getPath() + "'");
			}
		}
		
		return success;
	}
	
	public String getZipFileName(File file){
		if(append_timestamp){
			return file.getName()+"."+TIMESTAMP_FORMAT.format(new Date(timestamp))+".zip";
		} else {
			return file.getName()+".zip";
		}
	}
}
