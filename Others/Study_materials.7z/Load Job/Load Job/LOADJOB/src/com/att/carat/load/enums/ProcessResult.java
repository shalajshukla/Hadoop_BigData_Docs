/*
 * *Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.carat.load.enums;

/**
* Extends the result class to add DUPLICATE and EMPTY_FILE Enum patterns
* 
* @author Brennan Spies - bs8145
* @author Kevin Scudder - ks9383
* 
* @version $Revision:
*/
public class ProcessResult extends Result
{
	/**
	 * Default constructor.
	 * @param name The string representation of the enum
	 */
	private ProcessResult(String name)
	{
		super(name);
	}
	/**Enum pattern for Duplicate */
	public static final ProcessResult DUPLICATE = new ProcessResult("duplicate file");
	/**Int Enum pattern for Emplty File  */
	public static final ProcessResult EMPTY_FILE = new ProcessResult("empty file");
}
