/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.carat.load;

import java.util.Properties;
/**
* Abstract class based on DBLoadJob that adds the time interval functionality. The loadjob
* can be configured to run in certain amount of milliseconds after the current time. <BR><BR>
* 
* The following additional loadjob parameter is required in the application config file: <BR><BR>
* <code>
* 	<pre>
* job1.interval=some_number
* 	</pre>
* </code>
* @author Michael Peterson - mp2154
* @author Kevin Scudder - ks9383
* 
*/
abstract public class IntervalLoadJob extends DBLoadJob {
	/**The timestamp when the configure was run*/
	protected long timestamp;
	/**The interval representing the number of milliseconds after which a loadjob should run.*/
	protected long interval;
	/**
	 * Cofigures the load job to run in interval after a given time
	 * 
	 * @param application The application object instance.
	 * @param configuration The properties object with configuration info.
	 * @return result Boolean success/failure of configuration.
	 * @see DBLoadJob#configure(Application, Properties)
	 */	
	protected boolean configure(Application application, Properties configuration) {
		boolean result = super.configure(application, configuration);
		String tmp = configuration.getProperty("interval").trim();
		if (tmp == null) {
			logger.error("interval entry missing in cofiguration file");
			return false;
		}
		try {
			interval = Integer.parseInt(tmp);
		} catch (NumberFormatException e) {
			logger.error("Interval entry could not be parsed");
			return false;
		}	
		timestamp = System.currentTimeMillis();
		return result;
	}
	/**
	 * Checks to see if the interval has passed after the timestamp
	 * 
	 * @return Boolean true/false if current time greater than timestamp plus interval.
	 * 
	 */	
	protected boolean check() {
		return System.currentTimeMillis() > (timestamp + interval);
	}
	/**
	 * Does posprocessing, calls the super class postrocess method.
	 * 
	 * @param success Boolean true/false if the processing was successful.
	 * @return Boolean success/failure of postprocessing.
	 * 
	 */			
	protected boolean postprocess(boolean success) {
		success = super.postprocess(success);
		if (success) timestamp = System.currentTimeMillis();
		return success;
	}
}
