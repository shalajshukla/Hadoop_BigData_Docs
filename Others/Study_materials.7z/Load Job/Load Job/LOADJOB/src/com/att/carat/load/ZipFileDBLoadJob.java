/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.carat.load;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import com.att.carat.load.enums.Result;
/**
* A load job that can read data from zip files. Assumes that the zip archive
* contains one and only one entry and that that file is in text format. 
* Extends FileDBLoadJob. <BR><BR>
* 
* Parameters are the same as for FileDBLoadJob.
* 
* @author Gideon M. Juve - gj7832
* @author Kevin Scudder - ks9383
* 
* 
*/
public abstract class ZipFileDBLoadJob extends FileDBLoadJob {
	/**
	* A method to retrieve entries from zip file.
	* 
	* @param file File object to be processed
	* @return Boolean true/false if reading was successful
	* @see FileDBLoadJob#preprocessFileOpt(File)
	*/
	protected boolean processFile(File file) {
		int result = preprocessFileOpt(file);
		if(result == SUCCESS){
			//create reader for file
			ZipFile zipFile = null;
			BufferedReader reader = null;
			try {
				zipFile = new ZipFile(file);
				Enumeration entries = zipFile.entries();
				ZipEntry entry = null;
				if(entries.hasMoreElements()){
					entry = (ZipEntry)entries.nextElement();
				} else {
					logger.error("Zip file did not contain any entries");
					return false;
				}
				reader = new BufferedReader(new InputStreamReader(zipFile.getInputStream(entry)));
			} catch(FileNotFoundException fnfe) {
				logger.error("Unable to find file: " + file.getAbsolutePath(), fnfe);
				return false;
			} catch(IOException ioe){
				logger.error("Error retrieving zip entry",ioe);
				return false;
			}
			int[] counter = new int[3];
			long timestamp = System.currentTimeMillis();
			try {
				//Parse all the lines in the file 1 by 1
				String line = reader.readLine();
				while(line != null) {
					if(line.length() > 0) {
					    if (line.length() != 0) counter[parseLine(line)]++;
					}
					line = reader.readLine();
				}
				//log statistics
				logger.info("Finished file '" + file.getName() + "' / time elapsed = " +
					(System.currentTimeMillis() - timestamp) + "ms / lines processed = " + 
					counter[Result.SUCCESS.toInt()] + " / lines skipped = " + counter[Result.SKIPPED.toInt()]
					+ " / line errored = " + counter[Result.ERROR.toInt()]);
				//if any errored lines, change result
				if(counter[Result.ERROR.toInt()] > 0)
				    result = ERROR;					
			} catch(IOException ioe) {
				logger.error("File error occurred at line " + (counter[0] + counter[1] + counter[2]), ioe);
				result = ERROR;
			} catch(SQLException sqle) {
				logger.error("Database error occurred at line " + (counter[0] + counter[1] + counter[2]), sqle);
				result = ERROR;
			} catch(Exception e) {
				logger.error("Error occurred at line " + (counter[0] + counter[1] + counter[2]), e);
				result = ERROR;
			} finally {
				try {
					if(reader != null){
						reader.close(); 
					}
					if(zipFile!=null){
						zipFile.close();
					}
				} catch(IOException ioe) {
					logger.error("Error closing file: " + ioe);
				}
				zipFile = null;
				reader = null;
			}
		}
		result = postprocessFileOpt(file, result);
		return (result == SUCCESS || result == SKIPPED || result == EMPTY_FILE);
	}
}

