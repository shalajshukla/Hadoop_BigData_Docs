/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.carat.load;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.nio.channels.Channels;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.channels.OverlappingFileLockException;
import java.sql.SQLException;
import java.util.Properties;

import com.att.carat.load.enums.ProcessResult;
import com.att.carat.load.enums.Result;

/**
* Abstract class based on DBLoadJob that expects using files as the source of data to be loaded.
* It looks for files matching the accept method to drive the parseLine method which takes the read 
* lines from the file and places it into the database. <BR><BR>
* 
* In addition to parameters required for a regular load job, the following additional parameters must
* be specified in the applications configuration file: <BR>
* <BR>
* <code>
* 	<pre>
*   driver_class=oracle.jdbc.OracleDriver
*   url=url_string
*   username=your_username
*   password=your_password
* 
*   #Job Specific Parameters 
* 	
*   job1.source_directory=some_directory 
*   job1.archive_directory=some_directory 
*   job1.error_directory=some_directory 
*	</pre>
* </code>
* @author Michael Peterson - mp2154
* @author Kevin Scudder - ks9383
* 
* 
*/
abstract public class FileDBLoadJob extends DBLoadJob implements FileFilter
{
	/**Int representing successful file */
	protected static final int SUCCESS = Result.SUCCESS.toInt();
	/**Int representing skipped file */
	protected static final int SKIPPED = Result.SKIPPED.toInt();
	/**Int representing errored out file */
	protected static final int ERROR = Result.ERROR.toInt();
	/**Int representing duplicate file */
	protected static final int DUPLICATE = ProcessResult.DUPLICATE.toInt();
	/**Int representing number of empty files */
	protected static int EMPTY_FILE = ProcessResult.EMPTY_FILE.toInt();
	/**Counter */
	protected int	counter[];
	/**File object source directory */
	protected File	source_directory;
	/**File object archived directory */
	protected File	archive_directory;
	/**File object error directory */
	protected File	error_directory;
	
	/**
	 * Calls the super.configure, then stores where the source, archive, and error directories are.
	 * 
	 * @param application The application object ibstance.
	 * @param configuration The properties object with configuration info.
	 * @return Boolean success/failure of configuration.
	 * @see DBLoadJob#configure(Application, Properties)
	 */
	protected boolean configure(Application application, Properties configuration) {
		boolean success = super.configure(application, configuration);
		String source_directory_path = configuration.getProperty("source_directory").trim();
		String archive_directory_path = configuration.getProperty("archive_directory").trim();
		String error_directory_path = configuration.getProperty("error_directory").trim();
		if (source_directory_path == null || source_directory_path.equals("") ||
				archive_directory_path == null || archive_directory_path.equals("") ||
				error_directory_path == null || error_directory_path.equals("")) {
			logger.error("Directory parameters missing");
			return false;
		}
		source_directory = new File(configuration.getProperty("source_directory").trim());
		archive_directory = new File(configuration.getProperty("archive_directory").trim());
		error_directory = new File(configuration.getProperty("error_directory").trim());	
		return success;
	}		
	/**
	 * Retrives the location of the source directory.
	 * 
	 * @return A file object pointing to the source directory.
	 */
	protected File getSourceDirectory() {
		return source_directory;
	}
	
	/**
	 * Retrives the location of the archive directory.
	 * 
	 * @return A file object pointing to the archive directory.
	 */
	protected File getArchiveDirectory() {
		return archive_directory;
	}
	
	/**
	 * Retrives the location of the error directory.
	 * 
	 * @return A file object pointing to the error directory.
	 */
	protected File getErrorDirectory() {
		return error_directory;
	}
	
	/**
	 * This type of load job is required to run anytime there are available files in the source directory.
	 * 
	 * @return Boolean, true if there are any files in the source directory.
	 * @see LoadJob#check()
	 */
	protected boolean check() {
		return source_directory.listFiles(this).length > 0;
	}
	
	/**
	 * To process this load job we must process each file individually.
	 * 
	 * @return Boolean success/failure of processing of the files.
	 * @see LoadJob#action()
	 */
	protected boolean action() {	
		File files[] = source_directory.listFiles(this);
		boolean result = true;
		for (int index = 0; index < files.length; index++)
			result &= processFile(files[index]);
		return result;
	}
	
	/**
	 * Do anything we need to on a file basis before we actually start loading the file such as setup a timer and counters.
	 * 
	 * @param file - File object  in the process.
	 * @return Boolean success/failure of preprocessing of the files.
	 */
	protected int preprocessFileOpt(File file) {
		timestamp = System.currentTimeMillis();
		logger.info("Starting file '" + file.getName() + "'");
		counter = new int[3];
		return preprocessFile(file) ? SUCCESS : ERROR;
	}
	/**
	 * Do preprocessing on a file
	 * 
	 * @param file File object  in the process.
	 * @return Boolean success/failure of preprocessing of the files.
	 */
	protected boolean preprocessFile(File file) {
		return true;
	}
	
	/**
	 * Do anything we need to on a file basis after we finish loading a file.
	 * This load job commits/rollsback each file individually.
	 * Any file commited gets moved to the archive directory, while any rolledback goes to the error directory.
	 * 
	 * @param file The current file object in the process.
	 * @param success Int representing whether file processed successfully.
	 * @return Boolean success/failure of postprocessing of the files.
	 */
	protected int postprocessFileOpt(File file, int success) {
		boolean temp = postprocessFile(file, success == SUCCESS);
		if (success == SUCCESS && temp == false) {
			success = ERROR;
		}
		File destination = null;
		if (success == SUCCESS) {
			logger.info("Finished file '" + file.getName() + "' / time elapsed = " + (System.currentTimeMillis() - timestamp) + "ms / lines processed = " + counter[SUCCESS] + " / lines skipped = " + counter[SKIPPED] + " / lines per second = " + (int) ((counter[SUCCESS] * 1.0 / ((System.currentTimeMillis() - timestamp) * 0.001))));
			try {
				connection.commit();
			} catch (SQLException e) {
			    logger.error("Commit failed, exception: ", e);
				success = ERROR;
			}
			destination = archive_directory;
		} 
		else if(success == EMPTY_FILE) {
			logger.info("Finished empty file '" + file.getName() + "' / time elapsed = " + (System.currentTimeMillis() - timestamp) + "ms / lines processed = " + counter[SUCCESS] + " / lines skipped = " + counter[SKIPPED] + " / lines per second = " + (int) ((counter[SUCCESS] * 1.0 / ((System.currentTimeMillis() - timestamp) * 0.001))));
			try {
				connection.commit();
			} catch (SQLException e) {
			    logger.error("Commit failed, exception: ", e);
				success = ERROR;
			}
			destination = archive_directory;
		}
		else if (success == SKIPPED) {
			logger.warn("Skipped file '" + file.getName() + "'");
			try {
				connection.rollback();
			} catch (SQLException e) {
			    logger.error("Rollback failed, exception. ", e);
				success = ERROR;
			}
		} else if (success == ERROR) {
		    logger.error("Errored out file '" + file.getName() + "'");
			try {
				connection.rollback();
			} catch (SQLException e) {
			    logger.error("Rollback failed, exception: ", e);
			}
			destination = error_directory;
		}	
		if (destination != null) {
			destination = new File(destination, file.getName() + fileSubfix(file));
			if (destination.exists())
				destination.delete();
			if (!file.renameTo(destination)) {
			    logger.error("File rename failed for file '" + file.getPath() + "' to '" + destination.getPath() + "'");
		
			}
		}
		return success;
	}
	
	/**
	 * Returns exactly the boolean that was passed to it. Not sure about the purpose.
	 * 
	 * @param file The file object in the process.
	 * @param success A boolean.
	 * @return success Returns the boolean that was passed to it.
	 */
	protected boolean postprocessFile(File file, boolean success) {
		return success;
	}
	/**
	 * For the current file preform any preprocessing, then open the file reading it one line at a time which each line being parsed by the abstract method parseLine. Once all of the lines have been processed we execute the postprocess method and exit.
	 * 
	 * @param file The file object for processing.
	 * @return Boolean success/failure of processing of the current file.
	 */
	protected boolean processFile(File file) {
		int success;
		BufferedReader reader = null;
		FileChannel channel = null;
		FileLock lock = null;
		try {
		    channel = new RandomAccessFile(file, "rw").getChannel();
		    // Use the file channel to create a lock on the file.
		    lock = channel.tryLock();   
		    if (lock == null) {
		    	logger.warn("Could not aquire lock, file skipped"+file.getName());
		    	return true;
		    }
		    success = preprocessFileOpt(file);
		    if (success == SUCCESS) {
		    	//Create reader
		    	InputStream is = Channels.newInputStream(channel);
		    	InputStreamReader in = new InputStreamReader(is); 
		    	reader = new BufferedReader(in);
		    	//Process file
				String line = reader.readLine();
				while (line != null) {
					if (line.length() != 0) counter[parseLine(line)]++;
					line = reader.readLine();
				}
		    }
		} catch (OverlappingFileLockException e) {
            	// File is already locked in this thread or virtual machine
				logger.warn("File already locked by another thread . File skipped" + file.getName(), e);
				success = SKIPPED;  
		} catch (FileNotFoundException e) {
			    logger.error("FileNotFoundException. File skipped.", e);
				success = SKIPPED;
		} catch (IOException e) {
				logger.error("File error occured - line " + (counter[0] + counter[1] + counter[2]) + " - " + e.toString(),e);
				success = ERROR;
		} catch (SQLException e) {
			    logger.error("Database error occured - line " + (counter[0] + counter[1] + counter[2]) + " - " + e.toString(),e);
				success = ERROR;
		} catch (Exception e) {
			    logger.error("Error occured - line " + (counter[0] + counter[1] + counter[2]) + " - " + e.toString(),e);
				success = ERROR;
		} finally {
				try {
		    		if (reader != null) reader.close();
		    		// Release the lock
		    		if(lock != null && lock.isValid()) lock.release();
		    		// Close the file
		    		if (channel != null) channel.close();
				} catch (IOException e) {
				    logger.error("Error closing file - ", e);
				}
				reader = null;
		}
		success = postprocessFileOpt(file, success);
		return (success == SUCCESS || success == SKIPPED || success == EMPTY_FILE);
	}
	/**
	 * For files without changing names we can add a suffix to the file name when moving them to the archive or error directory. This method specifies the subfix.
	 * Not implemented, returns empty space
	 * 
	 * @param file The file object.
	 * @return A space.
	 */
	protected String fileSubfix(File file) {
		return "";
	}
	/**
	 * An abstract method of parsing the current line of the current file.
	 * 
	 * @param line String representing the current line of the file in the process.
	 * @return The status of the current line.
	 */
	abstract protected int parseLine(String line) throws Exception;
	/**
	 * An abstract method of determining which files in the source directory to using by implememting the FileFilter interface.
	 * 
	 * @param dir The current file to include or remove from this load job.
	 * @return Boolean to include or remove file from list.
	 * @see java.io.FileFilter
	 */
	abstract public boolean accept(File dir);
}
