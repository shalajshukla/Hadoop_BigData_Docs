/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.carat.load;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Properties;
/**
* Subclass of DBLoadJob which will run once every day at or soon after the specified time.
* 
* In addition to regular loadjob parameters, the following parameter is required in the
* application configuration file: <BR><BR>
* <code>
* 	<pre>
* job1.runtime=HH:MM
* 	</pre>
* </code>
* @author Michael Peterson - mp2154
* @author Kevin Scudder - ks9383
* 
* 
*/
abstract public class TimedLoadJob extends DBLoadJob {
	/**Current instance of the calendar object*/
	protected Calendar runtime = Calendar.getInstance();
	/**Time string*/
	protected SimpleDateFormat df = new SimpleDateFormat("HH:mm");
	
	/**
	 * Reads the basic configuration information which TimedLoadJob requires above DBLoadJob. Namely the time to run.
	 * It also checks if the time has already passed and if it has presets the time for tomorrow instead.
	 * 
	 * @param application The application object.
	 * @param configuration The properties object with configuration info.
	 * @return Boolean success/failure of configuration.
	 */
	protected boolean configure(Application application, Properties configuration) {
		boolean result = super.configure(application, configuration);
		
		String time = configuration.getProperty("runtime").trim();
		if (time == null) return false;
		
		try {
			runtime.setTime(df.parse(time));
		} catch (ParseException e) {
			logger.error("Error setting runtime ", e);
			return false;
		}
		
		Calendar now = Calendar.getInstance();
		runtime.set(now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DATE));
		if (now.after(runtime)) runtime.add(Calendar.DATE, 1);
		
		return result;
	}
	
	/**
	 * Tests if the current time is after the stored runtime...if it is that return true.
	 * 
	 * @return Boolean success/failure of check.
	 */
	protected boolean check() {
		return Calendar.getInstance().after(runtime);
	}

	/**
	 * Resets the next processing time to the next day if the process ran successfully.
	 * 
	 * @param success Boolean success/failure of the processing.
	 * @return Boolean success/failure of postprocessing.
	 */
	protected boolean postprocess(boolean success) {
		success = super.postprocess(success);
		if (success) 
			runtime.add(Calendar.DATE, 1);	
		return success;
	}
}
