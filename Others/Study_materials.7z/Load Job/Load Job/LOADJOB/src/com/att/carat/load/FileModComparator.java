/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.carat.load;

import java.util.Comparator;
import java.io.File;

/**
*Implements functionality to check if two files are equal.
* 
* @author Tim McNamara- tm6419
* @author Kevin Scudder - ks9383
* 
*/
public class FileModComparator implements Comparator {

	/**
	* Compares the last modified date in two objects
    *
    *  @param arg0 The first object to compare
    *  @param arg1 The second object to compare
    * 
    *  @return Integer: 1 if the first modified date is later, 0 if equal or -1
	*  @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
	*/
	public int compare(Object arg0, Object arg1) {
		if (!(arg0 instanceof File) || !(arg1 instanceof File)) {
		    throw new ClassCastException();
		}
		File f0 = (File) arg0;
		File f1 = (File) arg1;
		if (f0.lastModified() > f1.lastModified()) return 1;
		if (f0.lastModified() == f1.lastModified()) return 0;
		return -1;
	}
	/**
	* Compares the last modified date in two objects
    *
    *  @param arg0 The first object to compare
    *  @param arg1 The second object to compare
    * 
    *  @return Boolean true if modified dates are equal, else false
	*  @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
	*/	
	public boolean equals(Object arg0, Object arg1){
		if (!(arg0 instanceof File) || !(arg1 instanceof File)) {
			throw new ClassCastException();
		}
		File f0 = (File)arg0;
		File f1 = (File)arg1;
		if (f0.lastModified() == f1.lastModified()) return true;
		return false; 
	}
}
