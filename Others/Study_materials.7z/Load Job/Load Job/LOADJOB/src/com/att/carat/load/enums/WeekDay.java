/*
 * Created on Apr 29, 2004
 * Project: BAC Load 2.0
 * File: WeekDay.java
 */
package com.att.carat.load.enums;

import java.util.HashMap;
import java.util.Map;


/**
 * @author Brennan Spies (bs8145)
 * <p>Enum class for week day. Has two static methods to look up
 * the appropriate enum by the 3-letter abbreviation and by week day.</p>
 */
public final class WeekDay extends Enum
{
	private static final Map byNumber = new HashMap(7);
	private static final Map byAbbrev = new HashMap(7);
	int day;
	
	/**
	 * Default constructor.
	 * @param name The name of the enum
	 */
	public WeekDay(String name, int day)
	{
		super(name);
		this.day = day;
		byNumber.put(new Integer(day), this);
		byAbbrev.put(name, this);
	}
	
	/**
	 * Retrieves the week day (1-7) associated with this enum.
	 * @return int The week day
	 */
	public int getDay() {
		return day;
	}
	
	/**
	 * Retrieves the WeekDay enum by day (1-7). Values <1 or >7 will
	 * return a null. 1=SUNDAY and 7=SATURDAY.
	 * @param day The week day, 1-7
	 * @return The WeekDay enum corresponding to the parameter
	 */
	public static WeekDay getWeekDay(int day) {
		return (WeekDay)byNumber.get(new Integer(day));
	}
	
	public static WeekDay getWeekDay(String abbrev) {
		if(abbrev.length() > 3)
			throw new IllegalArgumentException("Must use 3-letter abbreviation to retrieve WeekDay enum");
		return (WeekDay)byAbbrev.get(abbrev.toUpperCase());
	}
	
	public static final WeekDay SUNDAY = new WeekDay("SUN", 1);
	public static final WeekDay MONDAY = new WeekDay("MON", 2);
	public static final WeekDay TUESDAY = new WeekDay("TUE", 3);
	public static final WeekDay WEDNESDAY = new WeekDay("WED", 4);
	public static final WeekDay THURSDAY = new WeekDay("THU", 5);
	public static final WeekDay FRIDAY = new WeekDay("FRI", 6);
	public static final WeekDay SATURDAY = new WeekDay("SAT", 7);
}
