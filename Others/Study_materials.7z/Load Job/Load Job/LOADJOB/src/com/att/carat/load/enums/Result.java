/*
 * *Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.carat.load.enums;

import com.att.carat.load.enums.Enum;
/**
* A typesafe enum class to implement return results from either the line parsing or the optional pre-/post-processing methods.
* 
* @author Brennan Spies - bs8145
* @author Kevin Scudder - ks9383
* 
* @version $Revision:
* 
* 
*/
public class Result extends Enum
{
	private int ordinal = nextOrdinal++;
	private static int nextOrdinal = 0;
	
	/**
	 * Default constructor.
	 * @param name The string representation of the enum
	 */
	protected Result(String name)
	{
		super(name);
	}
	
	/**
	 * Method to convert enum value to an int.
	 * @return int The ordinal value of the Result enum
	 */
	public int toInt()
	{
		return ordinal;
	}
	/**Enum pattern for success  */
	public static final Result SUCCESS = new Result("success");
	/**Enum pattern for skipped  */
	public static final Result SKIPPED = new Result("skipped");
	/**Enum pattern for result */
	public static final Result ERROR = new Result("error");
}
