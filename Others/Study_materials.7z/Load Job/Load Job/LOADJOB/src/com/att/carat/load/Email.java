/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.carat.load;

import java.util.Properties;
import java.util.StringTokenizer;

import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import org.apache.log4j.Logger;

/**
 * A utility class for holding the email specific static variables and methods.
 *
 *@author Michael Peterson - mp2154
 */
public class Email {
	private static String HOST = "smtp.pacbell.com";
	private static String FROM = "CARATNotify@att.com";
	
	/**
	 * Calls the fully specified method of sendEmail with the html flag set to false from the default sender.
	 * 
	 * @param to String of the to addresses seperated by semicolons.
	 * @param subject String representing the subject line.
	 * @param body String representing the body of the message.
	 * @return Boolean representing the success/failure of email.
	 * @see #sendEmail(String, String, String, String, boolean)
	 */
	public static boolean sendEmail(String to, String subject, String body) {
		return sendEmail(to, FROM, subject, body, false);
	}
	/**
	 * Creates an email message and sends it from the default sender.
	 * 
	 * @param to String of the to addresses seperated by semicolons.
	 * @param subject String representing the subject line.
	 * @param body String representing the body of the message.
	 * @param html Boolean representing if message is in html
	 * @return Boolean success/failure of email.
	 */
	public static boolean sendEmail(String to, String subject, String body, boolean html) {
		return sendEmail(to, FROM, subject, body, html);
	}
	/**
	 * Calls the fully specified method of sendEmail with the html flag set to false.
	 * 
	 * @param to String representing the list of the to addresses seperated by semicolons.
	 * @param from A String representing the from address
	 * @param subject The subject line.
	 * @param body The body of the message.
	 * @return Boolean success/failure of email.
	 * @see #sendEmail(String, String, String, String, boolean)
	 */
	public static boolean sendEmail(String to, String from, String subject, String body) {
		return sendEmail(to, from, subject, body, false);
	}
	/**
	 * Creates an email message and sends it.
	 * 
	 * @param to String of the to addresses seperated by semicolons.
	 * @param from String representing the from address.
	 * @param subject String representing the subject line.
	 * @param body String representing the body of the message.
	 * @param html Boolean true if body is in html format.
	 * @return Boolean success/failure of email.
	 */
	public static boolean sendEmail(String to, String from, String subject, String body, boolean html) {
		if (to == null || from == null || subject == null || body == null) 
			return false;
		try {
			Properties props = System.getProperties();
			props.put("mail.smtp.host", HOST);
			Session session = Session.getDefaultInstance(props, null);
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(from));
			message.setSubject(subject);
			message.setContent(body, (html ? "text/html" : "text/plain"));
			StringTokenizer tokenizer = new StringTokenizer(to, ";");
			InternetAddress addresses[] = new InternetAddress[tokenizer.countTokens()];
			for (int index = 0; tokenizer.hasMoreTokens(); index++)
				addresses[index] = new InternetAddress(tokenizer.nextToken());
			message.setRecipients(MimeMessage.RecipientType.TO, addresses);	
			Transport.send(message);
		} catch (Exception e) {
			Logger.getLogger(Email.class).error("Messaging error ", e);
			return false;
		}
		return true;
	}
}
