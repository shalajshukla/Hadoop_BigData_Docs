
/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.carat.load;

import java.util.Properties;
import org.apache.log4j.Logger;

/**
* Abstract class that defines basic load job methods and implements a configure method that configures the load job name.
* Configuration parameters for the loadjob are specified in the application's configuration file. Each loadjob class has
* specific configuration parameters. Please refer to the appropriate load job documentation for list of specific parameters.<BR><BR>
* 
* In general loadjob parameters are specified in application's configuration file in the following format: <BR><BR>
*  
* <code>
*  <pre>
*  application_name=MyApplicationName
*  status_to_addresses=myemail@somedomain.com
*  number_of_jobs=1
*
*  #####################################################
*  #   Job Specific Configuration Parameters           #
*  #####################################################
*  job1.name=MyJobName
*  job1.class=some.package.class
*  </pre>
* </code> 
* 
* @author Michael Peterson - mp2154
* @author Kevin Scudder - ks9383
* 
*/
abstract public class LoadJob {
    /**Logger object*/
	protected 	Logger 			logger = Logger.getLogger(LoadJob.class);
    /**Application object*/
	protected	Application 	application;
	/**The load_job_name from config file*/
	protected	String			load_job_name;
	/**The currect time*/
	protected	long			timestamp;
	/**
	 * Reads the basic configuration information which in this case is simply the job name.
	 * 
	 * @param application - application object.
	 * @param configuration - properties object with configuration info.
	 * @return success/failure of configuration.
	 */
	protected boolean configure(Application application, Properties configuration) {
		this.application = application;
		load_job_name = configuration.getProperty("name");
		logger.info(load_job_name+" configuration Started.");
		if (load_job_name == null || load_job_name.equals("")) {
			load_job_name = this.getClass().getPackage() + "." + this.getClass().getName(); }
		return true;
	}
	/**
	 * Abstract method to test if this load job requires processing or not.
	 * 
	 * @return processing required or not.
	 */
	abstract protected boolean check();
	/**
	 * Does general load job setup stuff.
	 * Can be overridden to add load job functionality.
	 * Should always call the super class when overridding this method.
	 * 
	 * @return Boolean success/failure of preprocessing.
	 */
	protected boolean preprocess() {
		timestamp = System.currentTimeMillis();
		logger.info(load_job_name+" starting job");		
		return true;
	}
	/**
	 * Does general load job cleanup stuff.
	 * Can be overridden to add load job functionality.
	 * Should always call the super class when overridding this method.
	 * 
	 * @return Boolean success/failure of postprocessing.
	 */
	protected boolean postprocess(boolean success) {
		logger.info("Finished job / time elapsed = " + (System.currentTimeMillis() - timestamp) + "ms");	
		return success;
	}
	/**
	 * Preforms all the steps required in processing the load job.
	 * Starts by calling the preprocess, the individual load job action, then finishes by calling postprocess.
	 * 
	 * @return Boolean true/false if processing successful.
	 */
	protected boolean process() {
			boolean success = preprocess();
			if (success) success = action();
			return postprocess(success);	
	}
	/**
	 * Abstract method that contains the specific actions needed for the load job.
	 * 
	 * @return Boolean true/false if action successful.
	 */
	abstract protected boolean action ();
	/**
	 * Set the debug status.
	 * 
	 * @param enable Boolean debug status.
	 */
	public void enableDebug(boolean enable) { 
		application.enableDebug(enable); 
	}
	/**
	 * Returns the current debug status.
	 * 
	 * @return Boolean true if debug status set.
	 */
	public boolean debugEnabled() {	
		return application.debugEnabled(); 
	}
	/**
	 * Logging method to log debug messages.
	 * 
	 * @param msg String with debug message.
	 */
	public void debug(String msg) {
		application.debug(load_job_name + "/" + msg);
	}
	/**
	 * Logging method to log informational messages.
	 * 
	 * @param msg String with informational message.
	 */
	public void info(String msg) {
		application.info(load_job_name + "/" + msg);
	}
	/**
	 * Logging method to log configuration messages.
	 * 
	 * @param msg String with configuration message.
	 */
	public void config(String msg) {
		application.config(load_job_name + "/" + msg);
	}
	/**
	 * Logging method to log warning messages.
	 * 
	 * @param msg - informational message.
	 */
	public void warning(String msg) {
		application.warning(load_job_name + "/" + msg);
	}
	/**
	 * Logging method to log warning messages.
	 * 
	 * @param msg String with warning message.
	 */
	public void severe(String msg) {
		application.severe(load_job_name + "/" + msg);
	}
	/**
	 * Logging method to log severe error messages with stack trace.
	 * 
	 * @param msg String with error message.
	 * @param exception Thrown exception.
	 */
	public void severe(String msg, Throwable exception) {
		application.severe(load_job_name + "/" + msg, exception);
	}
}
