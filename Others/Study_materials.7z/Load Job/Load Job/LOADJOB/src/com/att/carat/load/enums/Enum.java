/*
 * Created on Oct 23, 2003
 * Project: Bac Utilities
 * File: Enum.java
 */
package com.att.carat.load.enums;

/**
 * @author Brennan Spies(bs8145)<br/>
 * <p>Abstract class that implements the type-safe enumeration pattern as described
 * by Joshua Bloch in "Effective Java". To get your own enumeration, simply extend
 * this class and add your own public static final (class) constants to it, then
 * add a parameterized constructor (takes a String) that calls the Enum constructor.</p>
 * <p>Here's an example:</p>
 * <pre>
 * public class MyEnum extends Enum {
 * 		public MyEnum(String name) { super(name); }
 * 		public static final MyEnum ONE = new MyEnum("ONE");
 * 		public static final MyEnum TWO = new MyEnum("TWO");
 * 		//etc...
 * }
 * </pre>
 * <p>This class enforces the use of the correct enumeration instance, which can be
 * referenced much like the less-safe public static final members, e.g. MyEnum.ONE.
 * Since all constants defined are unique instances of your enumeration class, you can
 * use the "==" operator to test for equivalence (unless they are in different JVMs/classloaders,
 * in which case you need to use the equals(Object) method).</p>
 * <p>NOTE: Every Enum subclass that is not intended to be itself subclassed
 * should be declared <pre>final</pre>.</p>
 */
public abstract class Enum
{
	private final transient String name;
	
	/**
	 * Parameterized constructor, enforces choice of enumerated value.
	 * @param name The name of the enumeration
	 */
	protected Enum(String name)
	{
		this.name = name;
	}
	
	/**
	 * This is a failsafe method to use to test for equivalence, in the case that the two
	 * Enum classes are in different JVMs/classloaders. If this is not the case, using the
	 * "==" operator will suffice.
	 * @see java.lang.Object#equals(java.lang.Object)
	 * @param o The enum to test for equivalence
	 * @return boolean True if enums are equivalent, false otherwise
	 */
	public final boolean equals(Object o)
	{
		return super.equals(o);
	}
	
	/**
	 * Prevents subclasses from overriding this method.
	 * @see java.lang.Object#hashCode()
	 */
	public final int hashCode()
	{
		return super.hashCode();
	}
	
	/**
	 * Returns the enumeration string of this class.
	 * @see java.lang.Object#toString()
	 * @return String The string representation of the enum
	 */
	public String toString()
	{
		return name;
	}
}
