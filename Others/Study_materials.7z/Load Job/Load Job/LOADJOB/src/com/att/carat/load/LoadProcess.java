/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.carat.load;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.StringWriter;
import java.util.Enumeration;
import java.util.Properties;
import java.util.Date;
import java.net.InetAddress;
import org.apache.log4j.WriterAppender;
import org.apache.log4j.Appender;
import org.apache.log4j.Logger;
import org.apache.log4j.Level;
import org.apache.log4j.PatternLayout;
/**
 * Load process is the backround process that calls reads the configuration file
 * specified on the command line, creates appropriate application objects and calls the 
 * application methods. It then goes into infinite loop periodically calling
 * the application.check() which calls the loadjob.check() method to see if
 * the loadjob is ready to run. If the loadjob is ready, it tells the loadjob to
 * execute the action. The actions are logged in the logs directory in 
 * loadprocess.log. The runOnce string and the configuration filename can be specified
 * as parameters for the main. <BR><BR>
 * 
 * The log4j configuration file must be specified as an argument for JVM as
 * -Dlog4j.configuration=file:Loadlog4j.properties <BR><BR>
 * 
 * <b>Sample Configuration file loadprocess.cfg: </b> <BR>
 *<code>
 *   <pre>
 *     #Use a semi-colon to comment out the attributes 
 *      sleepTime=1
 *      to_addresses=someemail@domain.com
 *
 *     #Application configuration
 *      number_of_applications=2
 *
 *     #First Application
 *      application1.class=some.package.class
 *      application1.config_file=YourFile.cfg
 *
 *     #Second Application
 *      application2.class=some.package.class2
 *      application2.config_file=YourFile2.cfg
 *  </pre>
 *</code>
 * 
 * @author Michael Peterson - mp2154
 */
public class LoadProcess {
	/**StringWriter to store error message */
	public StringWriter myStringWriter = new StringWriter();
	/**File logger for the background load job*/
	private Logger logger = Logger.getLogger(LoadProcess.class);
	/**Sleep time, ie the interval in which the background process sleeps*/
	private long sleepTime = 60 * 1000; // 1 minute.
	/**The email address string to send error messages*/
	private String to_addresses = System.getProperty("user.name")+"@att.com";
	/**The application object array*/
	private Application 	applications[];
	/**Boolean representing whether to quit the background process*/
	private boolean quit = false;
	/**Configuration filename*/
	private String logsconfigfile="loadprocess.cfg";
	/**Properties from configuration file*/
	private Properties configuration = new Properties();
	/**Boolean representing if application should run only once*/
	private boolean runOnce = false;
	/**Singleton instance of LoadProcess*/
	private static LoadProcess _instance = new LoadProcess();
	
	/**Getter method to return the instance of LoadProcess
	 * @return LoadProcess object instance
	 * */
	public static LoadProcess getInstance() {
		return _instance;
		}

	/**Getter method for the error string writer myStringWriter
	 * 
	 * @return Error StringWriter;
	 */
	public StringWriter getLoggerBuffer() {
		return myStringWriter;
	}
	/**Public method to flush the error buffer*/
	public void flushLoggerBuffer() {
		myStringWriter.flush();
	}
	
	/**Private default constructor*/
	private LoadProcess() {
	}

	/**
	 * The main starts the background process, reads the loadprocess.cfg file,
	 * creates appropriate application objects, configures application objects
	 * and runs the loadjobs when they are ready to run
	 * 
	 * @param	args String array of parameters: runOnce and loadprocess configuration filename.
	 * Both are optional by default runOnce is false and configuration file is loadprocess.cfg 
	 */		
	public static void main(String[] args) {
		LoadProcess.getInstance().start(args);
	}
	
	/**
	 * The start method calls calls the configuration method, which reads the configuration files, 
	 * calls the createApplications method and processApplication method. T
	 * 
	 * @param	args String array of parameters: runOnce and loadprocess configuration filename.
	 * Both are optional by default runOnce is false and configuration file is loadprocess.cfg 
	 */	
	private void start(String[] args) {
		//Call configuration method to read the config file.
		myStringWriter.flush();
		boolean success = configure(args);
		if(!success) {
			logger.fatal("Configuration failed");
			logger.info("Exiting background process");
			return;
		}
		//Create applications based on what is in the config file.
		success = createApplications(success);
		if(!success) {
			logger.fatal("Application initialization failed");
			logger.info("Exiting background process");
		}
		//Quit if the application creation was not successful.
		if (quit == true) {
			if (!sendEmail(to_addresses, myStringWriter)) {
				logger.warn("Error sending email.");
				logger.info("Exiting background process");
				return;
			}
			return;
		}
		//Finally, process the applications.
		success = processApplications(success);
		if (!success) {
			logger.fatal("Application process failed");
			logger.info("Exiting background process");
			return;
		}
	}
	/**
	 * Private method to configure log4j WriterAppender
	 * 
	 * @return boolean success failure
	 * 
	 */
	private boolean configWriterAppender () {
		boolean create_append = false;
		try {
			//Go through existing appenders and see if there is a layout, create WriterAppender and attach it to rootLogger
			for (Enumeration e = Logger.getRootLogger().getAllAppenders() ; e.hasMoreElements() ;) {
				Appender ap = (Appender) e.nextElement();
				if (ap.getLayout()!=null) {
					WriterAppender myWriterAppender = new WriterAppender(ap.getLayout(), myStringWriter);
					myWriterAppender.setThreshold(Level.INFO);
					Logger.getRootLogger().addAppender(myWriterAppender);
					create_append=true;
					break;
				}
			}
			//If previous action failed, create WriterAppender with new layout and attach it to rootLogger
			if (create_append == false) {
				WriterAppender myWriterAppender = new WriterAppender(new PatternLayout(), myStringWriter);
				myWriterAppender.setThreshold(Level.INFO);
				Logger.getRootLogger().addAppender(myWriterAppender);
			}
		} catch(Exception e) {
			logger.warn("Failed attaching writer appender to logger");
			return false;
		}  
		return true;
	}
	
	
	/**
	 * Private method to read the configuration from the Loadprocess config file.
	 * 
	 * @param	args String array of parameters: runOnce and loadprocess configuration filename.
	 * Both are optional by default runOnce is false and configuration file is loadprocess.cfg 
	 */			
	private boolean configure(String args[]) {
		//Exit if creation of WriterAppender failed
		if (!configWriterAppender()) {
			return false;
		}
		//Read command line parameters
		if (args.length > 0 && args[0].equals("runOnce")) {
	    	runOnce = true;
	    }
	    if (args.length > 1) {
	    	logsconfigfile = args[1];
	    }		
		logger.info("Loading configuration.");
		//Load configuration from the config file
		try {
			File file = new File(logsconfigfile);
			FileInputStream fis = new FileInputStream(file);
			configuration.load(fis);
			fis.close();
		} catch (FileNotFoundException e) {
			logger.fatal(logsconfigfile+" cannot be found", e);
			return false;
		} catch (IOException e) {
			logger.fatal("LoadProcess configuration file cannot be read - exiting.", e);
			return false;
		}
		//Parse configuration parameters sleepTime and to_addresses
		try {
			sleepTime *= Integer.parseInt(configuration.getProperty("sleepTime", "1").trim());
		} catch (Exception e) {
			logger.fatal("sleepTime entry in configuration file could not be parsed.", e);
			return false; 
		}
		if (configuration.getProperty("to_addresses") == null || configuration.getProperty("to_addresses").equals("")) {
			logger.error("to_addresses config option not set.");
		} else {
			to_addresses = configuration.getProperty("to_addresses").trim();
		}		
		logger.info("Configuration loaded successfully.");
		return true;
	}
	
	/**Private method to initialize application objects
	 * @param status Boolean if configuration executed successfully
	 * @return Boolean success/failure of application initialization
	 * */
	private boolean createApplications(boolean status) {
		logger.info("Initializing applications");
		try {
			//Parse number_of_applications configuration parameter
			String appNum = configuration.getProperty("number_of_applications").trim();
			if (appNum == null) {
				throw new IllegalArgumentException("number_of_applications configuration parameter is missing.");
			}
			int appNumInt = Integer.parseInt(appNum);
			if(appNumInt <= 0){
				throw new IllegalArgumentException("number_of_applications configuration parameter is invalid.");
			}
			//Create an array of applications
			applications = new Application[appNumInt];
		    Class application_class;
		    //Run application cofiguration for each element in array 
			for (int index = 0; index < applications.length; index++) {
				String which = "application" + (index + 1);
				application_class = Class.forName(configuration.getProperty(which + ".class").trim());
				applications[index] = (Application) application_class.newInstance();
				File dir = new File(configuration.getProperty(which + ".config_file").toString().trim());
				if(dir.exists() == false) {
			    	throw new IOException("File "+ configuration.getProperty(which + ".config_file")+" does not exist");
			    }
				if (!applications[index].configure(configuration.getProperty(which + ".config_file").trim())) {
						throw new IOException("Configuration of "+applications[index].application_name+" failed.");
				}				
			}
		} catch (ClassNotFoundException e) {
			logger.error("Class not found. ", e);
			quit = true;
			return false;
		} catch (InstantiationException e) {
			logger.error("Class instantiation failed: ", e);
			quit = true;
			return false;
		} catch (IllegalAccessException e) {
			logger.error("Class access failed: ", e);
			quit = true;
			return false;
		} catch (IllegalArgumentException e) {
			logger.error("number_of_applications entry is either 0, missing or invalid", e);
			quit = true;
			return false;
		} catch (IOException e) {
			logger.error("Error "+e.getMessage());
			quit = true;
			return false;
		} catch(NullPointerException e) {	
			logger.error("An error occured. Application could not be initialized. Make sure configuration files are correct.", e);
			quit = true;
			return false;
		} catch (Exception e) {
			logger.error("Error occured", e);
			quit = true;
			return false;
		}	
		logger.info("Application initialization successful ");
		return status;
	}
	
	/**
	 * Private process loop method that enters an infinite loop and checks if application is ready to run by
	 * calling the Application.check() method. 
	 * @param success Boolean status of application intialization 
	 * @return Boolean success/failure of processing
	 */
	private boolean processApplications(boolean success) {
		logger.info("Starting process loop");
		//Loop until all applications are processed, an error occured or quit is set to true
		while (!quit && applications.length != 0) {
			//Check to see if application is ready to run, if so call the process method
			for (int index = 0; index < applications.length; index++) {
				if (applications[index].check()) {
					try {
						logger.info(applications[index].application_name+" process started");
						applications[index].process();
						myStringWriter.flush();
					} catch (Throwable e) {
						logger.error(applications[index].application_name + "Serious LoadProcess Error", e);
						if (!sendEmail(to_addresses, myStringWriter)) {
							logger.warn("Error sending email.");
							quit = true;
						}	
					}
					logger.info(applications[index].application_name+" process completed");
				}
			}
			if (runOnce){
				quit = true;
			}	
			else {
				try {Thread.sleep(sleepTime);}
				catch (InterruptedException e) {
					logger.fatal("Thread Interrupted", e);
					sendEmail(to_addresses, myStringWriter);
				}
			}
		}
		logger.info("Ending process loop");
		return true;
	}

	/**Sends email notification of failure
	 *@param StringWriter with error message to be sent
	 *@return Boolean success/failure of email notification. 
	 */
	private boolean sendEmail(String to_addresses, StringWriter myStringWriter) {
		StringBuffer message = new StringBuffer();
		message.append("Serious LoadProcess error has occured \n");
		message.append("-------------------------------------------------------------------------------------------------------------------\n");
		message.append(myStringWriter.toString());
		myStringWriter.flush();
		message.append("\n\n"); 
		message.append("-------------------------------------------------------------------------------------------------------------------\n");
		try {
			message.append("This message was sent from "+InetAddress.getLocalHost().toString()+" on "+ new Date());
		}
		catch (Exception e) {
			logger.error("Failed inserting IP address or date into email message");
		}
		if (!Email.sendEmail(to_addresses, "Serious LoadProcess Error", message.toString())) {
			logger.warn("Email notification failed");
			return false;
		}
		else {
			logger.info("Email sent");
			return true;
		}
		
	}
}
