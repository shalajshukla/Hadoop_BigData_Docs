/* Created on Aug 30, 2007 by Konstantin Degtyarenko (kd6197)
 * Copyright 2002-2006 AT&T Knowledge Ventures. All rights reserved
 */
package com.att.carat.load.hibernate.loadjob;

//import java.text.ParseException;
//import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Properties;
import java.util.List;
import java.util.Vector;
//import java.util.Collections;
import java.sql.SQLException;

import org.hibernate.Criteria;
import org.hibernate.Transaction;
import org.hibernate.criterion.Expression;

import org.apache.log4j.Logger;
import com.att.carat.load.hibernate.application.HibernateApplication;
import com.att.carat.load.LoadJob;
import com.att.carat.load.Application;
import com.att.carat.load.hibernate.interfaces.BeanInterface;
import com.att.carat.load.util.RuntimeUtil;

/**
 * 
 * @author kd6197
 *
 */
public class HibernateLoadJob extends LoadJob {
	protected Logger logger = Logger.getLogger(HibernateLoadJob.class);
	protected String sourceSession;
	protected Transaction retrieve;
	protected Transaction persist;
	protected String destinationSession;
	protected Integer numberOfEntities=0;
	protected List<Integer> daysOfWeek = new Vector<Integer>();
	protected List<Loadable> entities = new Vector<Loadable>();
	protected Calendar runtime = Calendar.getInstance();
	protected HibernateApplication app;
	protected String interval;
	protected Properties configuration;
	
	/**
	 * 
	 */
	protected boolean configure(Application application, Properties configuration) {
		//SimpleDateFormat df = new SimpleDateFormat("HH:mm");
		Calendar now = Calendar.getInstance();
		this.configuration=configuration;
		try {
			this.app=(HibernateApplication)application;
		} catch (ClassCastException cce) {
			logger.error("Application class is not of type HibernateApplication", cce);
			return false;
		}
		boolean result = super.configure(application, configuration);
		interval = configuration.getProperty("interval")==null?null:configuration.getProperty("interval").trim();
		if(!interval.equalsIgnoreCase("daily")&&!interval.equalsIgnoreCase("weekly")&&!interval.equalsIgnoreCase("monthly")&&!interval.equalsIgnoreCase("yearly")&&!interval.equalsIgnoreCase("daysOfWeek")) {
			logger.error("Interval value not valid. Choices: daily, weekly, monthly, yearly, daysOfWeek");
			return false;
		}
		runtime = RuntimeUtil.calculateRuntime(interval, configuration, now);
		sourceSession = configuration.getProperty("sourceSession")==null?null:configuration.getProperty("sourceSession").trim();
		destinationSession = configuration.getProperty("destinationSession")==null?null:configuration.getProperty("destinationSession").trim();
		Integer numberOfEntities = Integer.parseInt(configuration.getProperty("numberOfEntities"));
		String entityClass="";
		try {
			for (int i=0; i<numberOfEntities; i++) {
				entityClass = configuration.getProperty("entity"+(i+1)+".class");
				logger.debug("Entity class"+entityClass);
				BeanInterface entity = (BeanInterface) Class.forName(entityClass).newInstance();
				String whereClause = configuration.getProperty("entity"+(i+1)+".whereClause");
				entities.add(new Loadable (whereClause, entity));
			}
		} catch (ClassNotFoundException ce) {
			logger.error("Cannot find class "+entityClass, ce);
			return false;
		} catch (InstantiationException ie) {
			logger.error("Error instantiating bean class", ie);
			return false;
		} catch (IllegalAccessException iae) {
			logger.error("Error accessing bean class", iae);
			return false;
		} catch (ClassCastException cce) {
			logger.error("Entity "+entityClass+" does not implement BeanInterface", cce);
			return false;
		}
		logger.info("Runtime configured "+new java.util.Date(this.runtime.getTimeInMillis()));	
		if (now.after(runtime)) {
			runtime=RuntimeUtil.incrementRuntime(interval, runtime, configuration);
		}
		return result;
	}
		
	/**
	 * 
	 */
	protected boolean preprocess() {
		boolean success = super.preprocess();		
		logger.info("Opening transaction "+sourceSession);
		logger.info("Opening transaction "+destinationSession);
		try {
			retrieve = app.getOpenTransaction(sourceSession);
			persist = app.getOpenTransaction(destinationSession);
		} catch (SQLException le) {
			logger.error("Source session or destination session are not valid", le);
			return false;
		}
		return success;
	}
	
	/**
	 * 
	 */
	protected boolean postprocess(boolean success) {
		if (success) {
			try  {
				app.commitAllTransactionsAndClose();
				runtime=RuntimeUtil.incrementRuntime(interval, runtime, configuration);
				logger.info("Runtime configured "+new java.util.Date(this.runtime.getTimeInMillis()));
			} catch (SQLException e) {
				logger.error("Commit failed. ", e);
				success = false;
			}
		}
		if (!success) {
			logger.error("Job ended with errors");
			try  {
				app.rollbackAllTransactionsAndClose();
			} catch (SQLException e) {
				logger.error("Rollback failed", e);
			}
		}
		return super.postprocess(success);
	}
	
	/**
	 * 
	 */
	@SuppressWarnings("unchecked")
	protected boolean action() {
		try {
			for (Loadable ld : entities) {
				info("Processing "+ld.beanClass.getClass().getName());
				String clause = ld.whereClause;
				BeanInterface bn = ld.beanClass;
				Criteria criteria = app.getSession(sourceSession).createCriteria(bn.getClass());
				if (clause!=null && clause.length()>0) {
					criteria.add(Expression.sql(clause));
				}
				List<BeanInterface> beans = criteria.list();
				for(BeanInterface bean : beans) {
					bean.convert();
					app.getSession(destinationSession).saveOrUpdate(bean);
				}
			}
		} catch (SQLException sqle) {
			logger.error("Error persisting data using source "+sourceSession+" and destination "+destinationSession, sqle);
			return false;
		}
		return true;
	}

	/**
	 * 
	 */
	protected boolean check() {
		return Calendar.getInstance().after(runtime);
	}

}
