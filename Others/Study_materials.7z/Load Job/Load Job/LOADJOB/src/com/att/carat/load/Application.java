/*
 * *Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.carat.load;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.StringWriter;
import java.io.IOException;
import java.net.InetAddress;
import java.util.Date;
import java.util.Enumeration;
import java.util.Properties;
import org.apache.log4j.Logger;
import org.apache.log4j.Level;


/**
 * A class to configure load jobs, log messages, and do general pre-, post- and
 * main processing by calling the appropriate LoadJob methods. <BR><BR>
 * The configuration file for the application file must match the application's
 * configuration file specified in LoadProcess' configuration file. For DBApplication
 * or MultipleConnectionApplication additional parameters are required in the the
 * configuration file. Refer to those classes' javadocs for appropriate parameters.
 * <BR><BR>
 * 
 * Sample application configuration file:<BR>
 * <code>
 *   <pre>
 *  
 * 	application_name=SomeName
 *	status_to_addresses=myemail@somedomain.com
 *
 *	number_of_jobs=1
 *
 *  #####################################################
 *  #   Job Specific Configuration Parameters           #
 *  #####################################################
 *	job1.name=SomeJobName
 *	job1.class=some.package.class
 *  </pre>	
 *</code>
 *
 * @author Michael Peterson - mp2154
 */
public class Application {
	private LoadJob jobs[];
	/**Application name string */
	protected String application_name;
	/**Email address string to sent report to */
	protected String status_to_addresses;
	/**Logger output object */
	protected Logger logger = Logger.getLogger(Application.class);
	/**Properties object containing configuration information */
	protected Properties		configuration = new Properties();
	/**Contains the time application ran */
	protected long timestamp;
	/**Stores the error messages */
	protected StringWriter myStringWriter;
	
	private		boolean			debug = false;
	private		int				error_count = 0;
	private 	boolean			error_message_sent = false;

	/**
	 * Loads configuration from property file specified in LoadProcess config file.
	 * 
	 * @param config_file String for property file name with configuration values.
	 * @return Boolean success/failure of configuration.
	 */
	protected boolean configure(String config_file) {
		boolean result = true;
		try {
			//Read configuration from file specified in LoadProcess cofig file
			configuration = new Properties();
			File file = new File(config_file);
			FileInputStream fis = new FileInputStream(file);
			configuration.load(fis);
			fis.close();
			//Set application name if null, assign default value
			application_name = configuration.getProperty("application_name").trim();
			if (application_name == null || application_name.equals("")) {
				int first = 0;
				if (config_file.lastIndexOf(System.getProperty("file.separator")) != -1)
					first = config_file.lastIndexOf(System.getProperty("file.separator"));
				int last = config_file.length();
				if (config_file.lastIndexOf(".") != -1 && config_file.lastIndexOf(".") > first)
					last = config_file.lastIndexOf(".");
				application_name = config_file.substring(first, last);
			}
			logger.info("Configuration started"); 
			//Set to_address to whatever is in configuration file
			status_to_addresses = configuration.getProperty("status_to_addresses").trim();
			if (status_to_addresses == null || status_to_addresses.equals("")) {
				logger.error("status_to_addresses not set in config file."); 
				return false;
			}
			enableDebug(configuration.getProperty("debug", "false").trim().equalsIgnoreCase("true"));
			logger.info("Creating loadjobs.");
			//Create an array of Load Jobs and configure the Load Jobs
			jobs = new LoadJob[Integer.parseInt(configuration.getProperty("number_of_jobs").trim())];
			for (int index = 0; index < jobs.length; index++) {
				Properties job_configuration = new Properties();
				for (Enumeration e = configuration.propertyNames() ; e.hasMoreElements() ;) {
					String key = (String) e.nextElement();
					if (key.indexOf("job" + (index + 1) + ".") == 0)
						job_configuration.setProperty(key.substring(key.indexOf('.') + 1, key.length()), configuration.getProperty(key).trim());
				}
				Class load_job_class = Class.forName(configuration.getProperty("job" + (index + 1) + ".class").trim());
				jobs[index] = (LoadJob) load_job_class.newInstance();
				result &= jobs[index].configure(this, job_configuration);
			}
		} catch (FileNotFoundException e) {
		    logger.error("Application configuration file '" + config_file + "' cannot be found ", e);
			return false;
		} catch (NullPointerException e) {
		    logger.error("An error occured. Check the application configuration file to make sure it is correct. ", e );
			return false;
		} catch (IOException e) {
		    logger.error("Application configuration file '" + config_file + "' cannot be read. ", e);
			return false;
		} catch (ClassNotFoundException e) {
		    logger.error("Class not found.", e);
			return false;
		} catch (InstantiationException e) {
		    logger.error("Class instantiation failed.", e);
			return false;
		} catch (IllegalAccessException e) {
		    logger.error("Class access failed. ", e);
			return false;
		} catch (Exception e) {
			logger.error("Loadjob configuration error occured.", e);
			return false;
		}
		if (result == true) {
			logger.info("LoadJob configuration successful");
		}
		else {
			logger.error("LoadJob configuration failed");
		}
		return result;
	}
	/**
	 * Checks if application ready to run by checking each if each load job is ready to run yet.
	 * 
	 * @return Boolean that represents if the job is ready to run.
	 */
	protected boolean check() {
		boolean result = false;
		if (error_count >= 3) {
			if (!error_message_sent) {
				logger.warn(application_name+"disabled due to excessive errors");
				sendStatusEmail("WARNING - " + application_name + " disabled due to excessive errors.", application_name + " disabled due to excessive errors.");
				error_message_sent = true;
			} 
			return result;
		}
		for (int index = 0; index < jobs.length; index++)
			result |= jobs[index].check();
		return result;
	}
	/**
	 * Does general application setup stuff. Can be overridden to add application wide functionality. 
	 * Should always call the super class when overridding this method.
	 * 
	 * @return Boolean representing successful preprocessing.
	 */
	protected boolean preprocess() {
		timestamp = System.currentTimeMillis();
		logger.info("Beginning application");
		return true;
	}
	/**
	 * Does general application cleanup stuff. Can be overridden to add application wide functionality.
	 * Should always call the super class when overridding this method.
	 * 
	 * @param success Boolean representing if the load process was successful or not.
	 * @return Boolean representing if the postprocessing is successful.
	 */
	protected boolean postprocess(boolean success) {
		if (success) error_count = 0;
		else error_count++;
		logger.info("Finishing application  / time elapsed = " + (System.currentTimeMillis() - timestamp) + "ms");
		if(!success){
		    sendStatusEmail(application_name + " load status - Errors occurred", LoadProcess.getInstance().getLoggerBuffer().toString());
		    logger.error("Application postprocess not successful");
		}
		myStringWriter = new StringWriter();
		return success;
	}
	/**
	 * Preforms all the steps required in processing the application.
	 * Starts by calling the preprocess, all the individual load job processes which are ready to process, then finishes by calling postprocess.
	 * 
	 * @return Boolean representing successful processing.
	 */
	protected boolean process() {
		boolean success = preprocess();
		if (success) {
			for (int index = 0; index < jobs.length; index++)
				if (jobs[index].check()) {
					logger.info("Processing loadjob");
					success &= jobs[index].process();
				}	
		}
		return postprocess(success);
	}
	/**
	 * Method is deprecated. All messages are logged in the log file.
	 * 
	 * @param enable Boolean representing the debug status. True if enable, false if not.
	 */
	public void enableDebug(boolean enable) {
		this.debug = enable;
	}  
	/**
	 * Returns the debug status. Deprecated, all messages are logged in the log file.
	 * 
	 * @return Debug status. True if debug status set, otherwise false
	 */
	public boolean debugEnabled() {	
		return this.debug;
	}
	
	/**
	 * Logging method for debug messages.
	 * 
	 * @param msg String debug message to log.
	 */
	public void debug(String msg) {
		if (!debug) return;
		logger.debug(application_name + "/" + msg);
	}
	
	/**
	 * Logging method to log informational messages.
	 * 
	 * @param msg String informational message.
	 */
	public void info(String msg) {
		logger.log((Level) Level.INFO, "/"+msg);
	}
	/**
	 * Logging method to log configuration messages.
	 * 
	 * @param msg String configuation message.
	 */
	public void config(String msg) {
		logger.log((Level)Level.INFO, "/"+msg);
	}
	/**
	 * Logging method to log informational messages.
	 * 
	 * @param msg String informational message.
	 */
	public void warning(String msg) {
		logger.log((Level) Level.WARN, "/" + msg);
	}
	/**
	 * Logging method to log severe error messages.
	 * 
	 * @param msg String error message.
	 */
	public void severe(String msg) {
		logger.log((Level) Level.ERROR, "/" + msg );
	}
	/**
	 * Logging method to log severe error messages with exception stack trace.
	 * 
	 * @param msg Error message.
	 * @param exception Thrown exception.
	 */
	public void severe(String msg, Throwable exception) {
		logger.log(Level.ERROR, "/"+msg, exception);
	}
	/**
	 * Logging method to log warning error messages with exception stack trace.
	 * 
	 * @param msg Warning message.
	 * @param exception Thrown exception.
	 */
	public void warning(String msg, Throwable exception) {
		logger.log(Level.WARN, "/"+msg, exception);
	}
	/**
	 * Sends an email to the designated status addresses from the designated status address.
	 * 
	 * @param subject String representing the email subject
	 * @param body String representing the email body
	 * @return Boolean true if email sent successfully, false otherwise
	 */
	public boolean sendStatusEmail(String subject, String body) {
		StringBuffer message = new StringBuffer();
		message.append(body);
		message.append("--------------------------------------------------------------------------------------------------------------------------\n");
		try {
			message.append("This message was sent from "+InetAddress.getLocalHost().toString()+" on "+ new Date());
		}
		catch (Exception e) {
			logger.error("Failed inserting IP address and date into email message");
		}
		if (Email.sendEmail(status_to_addresses, subject, message.toString())) {
			logger.info("Email sent");
			LoadProcess.getInstance().flushLoggerBuffer();
			return true;
		}
		else {
			logger.warn("Email notification failed.");
			return false;
		}
	}
}
