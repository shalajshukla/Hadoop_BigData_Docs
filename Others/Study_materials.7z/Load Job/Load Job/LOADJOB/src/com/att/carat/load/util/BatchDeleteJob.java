/*
 * Created on Apr 5, 2005
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.att.carat.load.util;

import java.io.File;
import java.io.FileFilter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.regex.Pattern;

import com.att.carat.load.Application;
import com.att.carat.load.LoadJob;

/**
 * @author mp2154
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class BatchDeleteJob extends LoadJob implements FileFilter {
	private File	source_directory;
	private Pattern pattern = null;
	private Date	start_date = null;
	private Date	end_date = null;
	
	protected boolean configure(Application application, Properties configuration) {
		boolean result = super.configure(application, configuration);
		
		// Sets the optional pattern for the regular expression matching on determining if the file is to be transferred.
		String pattern = configuration.getProperty("pattern");
		if (pattern != null && !pattern.equals(""))
			this.pattern = Pattern.compile(pattern.toUpperCase());
		
		//SOURCE DIRECTORY
		if (configuration.getProperty("source_directory") == null || configuration.getProperty("source_directory").equals("")) {
			severe("'source_directory' configuration property missing.");
			return false;
		} else {
			source_directory = new File(configuration.getProperty("source_directory"));
		}
		
		// Create a formatted to parse the date strings in the config file.
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		
		String date = configuration.getProperty("start_date");
		if (date != null && !date.equals("")) {
			try {
				start_date = formatter.parse(date);
			} catch (ParseException e) {
				severe("'start_date' configuration property error: " + e.toString());
				return false;
			}
		}
		
		date = configuration.getProperty("end_date");
		if (date != null && !date.equals("")) {
			try {
				end_date = formatter.parse(date);
			} catch (ParseException e) {
				severe("'end_date' configuration property error: " + e.toString());
				return false;
			}
		}
	
		if (start_date != null && end_date != null && start_date.after(end_date)) {
			severe("'start_date' configuration property is after 'end_date' configuration property.");
			return false;
		}
		
		if (end_date != null && end_date.before(new Date(System.currentTimeMillis())))
			warning("'end_date' configuration property is before today's date.");
		
		if (start_date != null)
			info("'start_date' configuration property: " + start_date);
		
		if (end_date != null)
			info("'end_date' configuration property: " + end_date);
		
		return result;
	}
	
	protected boolean action() {
		boolean success = true;
		File files[] = source_directory.listFiles(this);
		
		for (int index = 0; index < files.length; index++) {
			File file = files[index];
			boolean temp = file.delete();
			if (temp) {
				info("File '" + file.getName() + "' deletion successful."); 
			} else {
				warning("File '" + file.getName() + "' deletion failed."); 
			}
		}
		
		return success;
	}
	
	protected boolean check() {
		Date now = new Date(System.currentTimeMillis());
		if ((start_date == null || start_date.before(now)) && (end_date == null || now.after(end_date)))
			return source_directory.listFiles(this).length > 0;
		return false;
	}
	
	public boolean accept(File file) {
		return file.isFile() && (pattern == null || pattern.matcher(file.getName().toUpperCase()).matches());
	}
}
