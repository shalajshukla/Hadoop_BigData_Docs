/*
 * Created on Feb 24, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.att.bac.rabc.load.bir;

import java.io.File;
import java.net.UnknownHostException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.StringTokenizer;

import com.att.bac.rabc.util.EmcisEventLogger;
import com.att.carat.util.NetUtil;
import com.sbc.bac.rabc.load.FilePatternLoadJob;
import com.sbc.bac.rabc.load.PrepareTableForRerun;
import com.sbc.bac.rabc.load.RabcLoadJobTrig;
import com.sbc.bac.rabc.load.RetrieveStaticInfo;
import com.sbc.bac.rabc.load.StaticErrorMsgKeys;
import com.sbc.bac.rabc.load.StaticFieldKeys;

/**
 * @author pt6471
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class WBPCalnetLoad extends FilePatternLoadJob {
	
	// private static final String FILEPATTERN = "WE.[CI].C[0-9][0-9]*.XT21CALB.*";
	
	 private PreparedStatement insert_xt21calb;
	 private String division, bill_rnd, run_date, bill_rnd_dt, btnCCGrp, fileName;
	 
	 private String region;
	 private String backoutRecovery = null;
	 
	 private HashMap crocd_division;
	 private HashMap acctTypeMap;
		
	 private double[] calnet_amt = new double[8];
	
	 // Based on the following types -- data will be populated to calnet_amt to load to DB by record
	 
	 private static final int OCC_CHRG = 59007;
	 private static final int RECUR_CHRG = 59001;
	 private static final int LOCAL_USAGE_CHRG = 59005;
	 private static final int LOCAL_TOLL_CHRG = 59014;
	 private static final int SURCHRG_CHRG = 59016;
	 private static final int TAXES_CHRG = 59017;
	 private static final int REFUND_AMT = 59018;
	 private static final int PROMO_AMT = 59000;
	 
	 private File currentFile;
	 
	 private String savebtnCCgrp, fileToken;
	
	 private int cycle, lineCount;
	 
	 private java.sql.Date sqlrun_date;
	 
	 private boolean firstRcd;
	 private boolean nevadaBellData, billdayFile;
	 	 
	public boolean preprocess() {
		super.preprocess();

		try {
			StringBuffer sql = new StringBuffer();
			sql.append("  insert into RABC_CALNET_ACCT_BILL (DIVISION, RUN_DATE, BTN, OCC_CHRG, RECUR_CHRG, LOCAL_USAGE_CHRG, LOCAL_TOLL_CHRG, SURCHRG_CHRG, TAXES_CHRG, REFUND_AMT, PROMO_AMT, BLG_MM, BLG_YEAR, BILL_RND) ");
			sql.append("  VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ");
			insert_xt21calb = connection.prepareStatement(sql.toString());
			sql.setLength(0);
			
		} catch (SQLException e) {
			severe(StaticErrorMsgKeys.PREPROCESS_ERROR + e.getMessage());
			return false;
		}
		return true;
	}

	public boolean preprocessFile(File file) {
		boolean success = super.preprocessFile(file);
		fileName = file.getName();
		for (int i=0; i< calnet_amt.length; i++) calnet_amt[i]=0;
		
		//fileToken = file.getName().substring(file.getName().indexOf("XT21CALB"),file.getName().indexOf("XT21CALB")+ 8);
		
		fileToken = "XT21CALB";
		firstRcd  = true;
		nevadaBellData = false;
		billdayFile = true;
		
		if (success) {
			try {
				
				region   =	file.getName().substring(0,2);
				
				if 	(file.getName().charAt(3) == StaticFieldKeys.C)	
				  division = StaticFieldKeys.PACBELLNORTH;
				else if (file.getName().charAt(3) == StaticFieldKeys.I)	
				  division = StaticFieldKeys.PACBELLSOUTH;
				else 
					return false;
				
				cycle = Integer.parseInt(file.getName().substring(6, 10));
				
				run_date = RetrieveStaticInfo.getProc_dtByCycle(connection, cycle);
				bill_rnd_dt = RetrieveStaticInfo.getbillRndDt_ByCycle(connection, cycle);
				if (run_date.equals(StaticFieldKeys.ZERO)){
					severe(StaticErrorMsgKeys.NORECORD_RABC_CYCLE_CALENDAR + cycle);
					throw new Exception();	
				}
				
				
				DateFormat df = new SimpleDateFormat("MMddyyyy");
				sqlrun_date = new java.sql.Date(df.parse(run_date).getTime());

				lineCount = 0;
				
				
				backoutRecovery = null;
				
				if (RabcLoadJobTrig.IsFileLoaded(connection, file)) {
					backoutRecovery = "Y";
					String tableNm = "RABC_CALNET_ACCT_BILL";
					success = PrepareTableForRerun.deleteTableData(connection,tableNm,division,sqlrun_date);
					//	Both divisions NB (NEVADABELL) and PN (PACBELLNORTH) come from same file!!
					if (division == StaticFieldKeys.PACBELLNORTH)
					 	success = PrepareTableForRerun.deleteTableData(connection,tableNm,StaticFieldKeys.NEVADABELL,sqlrun_date);
				}
				
				
			} catch (Exception e) {
				severe(
					StaticErrorMsgKeys.PREPROCESSFILE_ERROR
						+ StaticErrorMsgKeys.FILE_NAME_PARSING_ERROR
						+ e);
				return false;
			}
		}

		try {

			crocd_division  = RetrieveStaticInfo.getCrocd_Divsion(connection,region.trim());
				
			bill_rnd = RetrieveStaticInfo.getBillRndByCycle(connection, cycle).trim();
			if (bill_rnd.equals(StaticFieldKeys.ZERO) || bill_rnd.equals(StaticFieldKeys.ZERO2)){
			 //severe(StaticErrorMsgKeys.PREPROCESSFILE_ERROR+":No Bill Round");
			 //return false;
				billdayFile = false;
			}

		} catch (SQLException e) {
			success = false;
			severe(StaticErrorMsgKeys.PREPROCESSFILE_ERROR + e.getMessage());
		}

		currentFile = file;
		return success;
	}

	
	
	public int parseLine(String line) throws Exception {
		boolean status;

		
			status = process21xtCALB(line);
		
			return SUCCESS;
	}
	
	
	
	private boolean process21xtCALB(String line) throws Exception {
		
		lineCount++;
		
		StringTokenizer DataLine = new StringTokenizer(line, StaticFieldKeys.SEMICOLON);
		
		// No record type since the file is per record type !!
		
		btnCCGrp 	= DataLine.nextToken().trim();
		String fitCtgyGrp	= DataLine.nextToken().trim();
		double occ_rcr_amt 	= Double.parseDouble(DataLine.nextToken().trim());
		int fitCode	 		= Integer.parseInt(DataLine.nextToken().trim());
		String  croCode  	= DataLine.nextToken().trim();

		String div  = (String) crocd_division.get(croCode);
		if (div == null){
	          severe(StaticErrorMsgKeys.NORECORD_RABC_CRO_CD_DIVISION + croCode);
			  throw new Exception(" No CRO CODE MATCH in job BIRWLoadJob");	
			} else if (div.equals(StaticFieldKeys.NEVADABELL)) {
				nevadaBellData = true;
			}
		
		if (firstRcd) {
			savebtnCCgrp = btnCCGrp;
			firstRcd = false;
		}
		if (!savebtnCCgrp.equals(btnCCGrp))
		try {
			insert_xt21calb.setString(1,div);		
			insert_xt21calb.setDate(2,sqlrun_date);
			insert_xt21calb.setString(3,savebtnCCgrp);
			insert_xt21calb.setDouble(4,calnet_amt[0]);
			insert_xt21calb.setDouble(5,calnet_amt[1]);
			insert_xt21calb.setDouble(6,calnet_amt[2]);
			insert_xt21calb.setDouble(7,calnet_amt[3]);
			insert_xt21calb.setDouble(8,calnet_amt[4]);
			insert_xt21calb.setDouble(9,calnet_amt[5]);
			insert_xt21calb.setDouble(10,calnet_amt[6]);
			insert_xt21calb.setDouble(11,calnet_amt[7]);
			insert_xt21calb.setString(12,bill_rnd_dt.substring(0,2));
			insert_xt21calb.setString(13,bill_rnd_dt.substring(4,8));
			insert_xt21calb.setInt(14,Integer.parseInt(bill_rnd));
			insert_xt21calb.addBatch();
			
			if (lineCount % 1000 == 0){
				insert_xt21calb.executeBatch();
			}
			
			savebtnCCgrp = btnCCGrp;
			for (int i=0; i< calnet_amt.length; i++) calnet_amt[i]=0;
			
		}catch (SQLException sqle){
			severe(StaticErrorMsgKeys.INSERT_ERROR + sqle.getMessage());
			 throw new Exception("Exception is from method process21xtSODS");
		}
		
		switch (fitCode) {
		case (OCC_CHRG) 		: calnet_amt[0] += occ_rcr_amt;
		break;
		case (RECUR_CHRG) 		: calnet_amt[1] += occ_rcr_amt;
		break;
		case (LOCAL_USAGE_CHRG) : calnet_amt[2] += occ_rcr_amt;
		break;
		case (LOCAL_TOLL_CHRG) 	: calnet_amt[3] += occ_rcr_amt;
		break;
		case (SURCHRG_CHRG) 	: calnet_amt[4] += occ_rcr_amt;
		break;
		case (TAXES_CHRG) 		: calnet_amt[5] += occ_rcr_amt;
		break;
		case (REFUND_AMT) 		: calnet_amt[6] += occ_rcr_amt;
		break;
		case (PROMO_AMT) 		: calnet_amt[7] += occ_rcr_amt;
		}
		
		return true;
	}
	

	
	public boolean postprocessFile(File file, boolean success) {
		try{

			//Log the file information to EMCIS_EVENT_LOG and EMCIS_EVENT_LOG_DETAIL
			EmcisEventLogger emcisLogger = new EmcisEventLogger();
			String event_id = "RABC_"+fileToken+"_"+region;
            String host = NetUtil.getLocalHostName();
            String hostIP = NetUtil.getLocalIpAddress();
			int sequence = emcisLogger.getEMCISSequence(connection);
			emcisLogger.insertEventLog(connection, sequence, event_id, sqlrun_date, host, hostIP);
			emcisLogger.insertEventLogDetail(connection, sequence, "FileName", fileName);
			
		}catch (UnknownHostException e) {
            severe("Error getting EMCIS host information ", e);
        }
		if (success) {
			
				try {
					insert_xt21calb.setString(1,division);		
					insert_xt21calb.setDate(2,sqlrun_date);
					insert_xt21calb.setString(3,savebtnCCgrp);
					insert_xt21calb.setDouble(4,calnet_amt[0]);
					insert_xt21calb.setDouble(5,calnet_amt[1]);
					insert_xt21calb.setDouble(6,calnet_amt[2]);
					insert_xt21calb.setDouble(7,calnet_amt[3]);
					insert_xt21calb.setDouble(8,calnet_amt[4]);
					insert_xt21calb.setDouble(9,calnet_amt[5]);
					insert_xt21calb.setDouble(10,calnet_amt[6]);
					insert_xt21calb.setDouble(11,calnet_amt[7]);
					insert_xt21calb.setString(12,bill_rnd_dt.substring(0,2));
					insert_xt21calb.setString(13,bill_rnd_dt.substring(4,8));
					insert_xt21calb.setInt(14,Integer.parseInt(bill_rnd));
					insert_xt21calb.addBatch();
					
					insert_xt21calb.executeBatch();
					
				}catch (SQLException sqle){
					severe(StaticErrorMsgKeys.INSERT_ERROR + sqle.getMessage());
					return false;
				}
		
				
			if (billdayFile)
			if (!insertTrigger()) {
				severe(
					StaticErrorMsgKeys.POSTPROCESSFILE_ERROR
						+ StaticErrorMsgKeys.TIGGER_TABLE_INSERT_ERROR);
				success = false;
			}
			
		}
		return super.postprocessFile(file, success);
	}

	
	public boolean postprocess(boolean success) {

		try {
			
			insert_xt21calb.close(); 

		} catch (SQLException e) {
			severe(
				StaticErrorMsgKeys.POSTPROCESS_ERROR
					+ StaticErrorMsgKeys.SQL_CLOSE_ERROR
					+ e);
			success = false;
		}

		return super.postprocess(success);
	}

	private boolean insertTrigger() {

		 if(!RabcLoadJobTrig.insertTrigger(connection,currentFile.getName(),fileToken,division,run_date, backoutRecovery,bill_rnd))
			return false;	
		 
		 if (nevadaBellData)
		 	if(!RabcLoadJobTrig.insertTrigger(connection,currentFile.getName(),fileToken,"NB",run_date, backoutRecovery,bill_rnd))
				return false;	
			 
		return true;
		
	}

}
