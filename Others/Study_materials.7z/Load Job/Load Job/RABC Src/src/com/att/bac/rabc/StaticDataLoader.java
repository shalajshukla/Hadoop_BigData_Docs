/*
 * Module description: 
 * This is a singleton class that loads all static data. 
 * The following tables are being loaded into in-memory objects:
 * 	RABC_DIVISION
 * 	RABC_FILE_MASH
 * 	RABC_DB_NODE
 * 	RABC_CNTRL_PT_TRANS
 * 	RABC_DATA_TBL_DDL
 *  RABC_MOUSE_OVER_TBL
 *  RABC_TABLE
 *  USER_TAB_COLUMNS (partially)
 *  RABC_REGION_BILL_RND
 *  RABC_PROCESS
 * 
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 *
 * Modification History:                                     
 * SBCUID		Date			Description                         	    	
 * ------		--------		-----------
 * PD2951		20051229		Initial version for EAP 556010.
 * VD3159		20060731		To implement the column name description change.
 * JS3175		20060905		Add functionality to change regional databases for EAP556013.
 */

package com.att.bac.rabc;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.log4j.Logger;




public class StaticDataLoader {
	
	private static final Logger logger = Logger.getLogger(InitListener.class);	
	private static final String[] REGIONS = {"WE", "SW", "MW", "EN", "C2", "SE","E", "MB"};  
	private static final String QRY_SELECT_DIVISION	= "SELECT REGION, STATE, DIVISION, DIVISION_DESC, STATE_DESC FROM RABC_DIVISION ORDER BY REGION, STATE_DESC, DIVISION_DESC";
	private static final String QRY_SELECT_FILE_MASH= "SELECT TABLE_NAME, FILE_ID, FILE_MASH FROM RABC_FILE_MASH";
	private static final String QRY_SELECT_DB_NODE 	= "SELECT DB_NODE_ID, DB_NODE, DB_NODE_DESC FROM RABC_DB_NODE";
	private static final String QRY_SELECT_CNTRL_PT	= "SELECT CNTRL_PT_CODE, PRESN_SEQ_NUM, CNTRL_PT_DESC FROM RABC_CNTRL_PT_TRANS ORDER BY PRESN_SEQ_NUM";
	private static final String QRY_SELECT_DATA_TBL	= "SELECT ALERT_PROC_TBL, " +
			                                          "TBL_PROC_DATE_DDL_NAME, " +
			                                          "TBL_BILL_RND_DDL_NAME, " +
			                                          "TBL_DDL_KEY_LVL, " +
			                                          "TBL_DDL_KEY1_NAME, " +
			                                          "TBL_DDL_KEY2_NAME, " +
			                                          "TBL_DDL_KEY3_NAME, " +
			                                          "TBL_DDL_KEY4_NAME, " +
			                                          "TBL_DDL_KEY5_NAME, " +
			                                          "TBL_DDL_NAME, " +
			                                          "TBL_BILL_RND_DDL_MON, " +
			                                          "TBL_BILL_RND_DDL_YEAR, " +
			                                          "TBL_DDL_DATA_TYPE, " +
			                                          "TBL_SUBSYS_ID, " +
			                                          "TBL_FILE_SEQ_NUM_DDL_NAME, " +
			                                          "TBL_DDL_PRESCSN_FORMAT_TYPE, " +
			                                          "TBL_DDL_NAME_DESC " +
			                                          "FROM RABC_DATA_TBL_DDL " +
			                                          "WHERE ALERT_PROC_TBL IS NOT NULL " +
			                                          "ORDER BY ALERT_PROC_TBL, TBL_DDL_NAME";
	private static final String QRY_SELECT_MAX_FORMAT_TYPE = 
													  "SELECT TBL_DDL_NAME, MAX(TBL_DDL_PRESCSN_FORMAT_TYPE) " +
													  	"FROM RABC_DATA_TBL_DDL " +
													  	"GROUP BY TBL_DDL_NAME " +
													  	"ORDER BY TBL_DDL_NAME ";	
	private static final String QRY_SELECT_MOUSE_OVER = 
													  "SELECT DISTINCT(TABLE_DESC), TABLE_NAME, TABLE_KEY_DATA, TABLE_KEY_NAME " +
													    "FROM RABC_MOUSE_OVER_TBL " +
													   "ORDER BY TABLE_DESC ";
	private static final String QRY_SELECT_ALERT_RULE = 
		                                                "SELECT ALERT_RULE, PARTI_REF_ID " +
		                                                "FROM  RABC_ALERT_RULE " +
		                                                "WHERE ALERT_RULE_STATUS = 'ACTIVE' " + 
		                                                "ORDER BY ALERT_RULE ";
	private static final String QRY_SELECT_RABC_TABLE = 
													  "SELECT ALERT_PROC_TBL, TBL_DESC, TBL_NODE, PARTI_REF_ID_IND " +
													    "FROM RABC_TABLE ORDER BY UPPER(TBL_DESC)";
	private static final String QRY_GET_NUMBER_TYPE_COLUMN = 
													  "SELECT DISTINCT COLUMN_NAME " +
													  	"FROM USER_TAB_COLUMNS " +
													   "WHERE TABLE_NAME LIKE 'RABC%' " +
													   	 "AND DATA_TYPE = 'NUMBER' ";
	private static final String QRY_GET_DATE_TYPE_COLUMN = 
													  "SELECT DISTINCT COLUMN_NAME " +
													  	"FROM USER_TAB_COLUMNS " +
													   "WHERE TABLE_NAME LIKE 'RABC%' " +
													   	 "AND DATA_TYPE = 'DATE' ";	
	private static final String QRY_GET_BILL_RND = 
													  "SELECT REGION, BILL_RND " +
													    "FROM RABC_REGION_BILL_RND " +
													   "ORDER BY REGION, BILL_RND";
	private static final String QRY_GET_PROCESS =
		                                              "SELECT PROCESS, CNTRL_PT_CD " +
		                                                "FROM RABC_PROCESS " +
		                                               "ORDER BY PROCESS, CNTRL_PT_CD";
	//Query to load bill rounds that have loaded data from the RABC_ACCT_BLG_DTL table
	private static final String QRY_GET_LOADED_BILLROUND = 
														"SELECT DISTINCT PROC_DT FROM RABC_CYCLE_CALENDAR C, RABC_ACCT_BLG_DTL B " +
														"WHERE TO_CHAR(EXTRACT(YEAR FROM C.PROC_DT)) = B.BILL_YEAR AND " +
														"TRIM(TO_CHAR (EXTRACT (MONTH FROM C.PROC_DT),'00')) = B.BILL_MM AND " +
														"C.BILL_RND = TO_CHAR(B.BILL_RND)";
	//New SQL query to get list of all cycles in RABC_CYCLE_CALENDAR
	private static final String QRY_GET_BILLCYCLES = "SELECT PROC_DT,BILL_RND,DECODE(PROC_DT_IND,NULL,'N',PROC_DT_IND) PROC_DT_IND FROM RABC_CYCLE_CALENDAR ORDER BY PROC_DT";
	
	// New queries added for Enterprise portal
	private static final String QRY_SELECT_DIVISION_ENT	= "SELECT REGION, STATE, DIVISION, DIVISION_DESC,REGION_DESC, STATE_DESC FROM RABC_DIVISION ORDER BY STATE_DESC";
	private static final String QRY_SELECT_DB_NODE_ENT 	= "SELECT REGION, DB_NODE, DECODE(REGION,'WE',1,'MW',2,'SW',3,NULL,0,4) LIST_ORDER FROM RABC_REGION_DB_NODE ORDER BY LIST_ORDER";
	private static final String QRY_GET_PROCESS_ENT = "SELECT DISTINCT PROCESS, CNTRL_PT_CD FROM RABC_PROCESS ORDER BY PROCESS, CNTRL_PT_CD";
	
	private static StaticDataLoader ref = null;
	private static int offset = 3600; //refer to staticDataLoader_refreshTimeInterval property in server.xml 
	
	private long loaded = 0;
	
	private Map<String, Long> loadedRegion = new HashMap<String, Long>();
	
	private ArrayList divisionList_w 	 = new ArrayList();
	private ArrayList divisionList_e 	 = new ArrayList();
	private ArrayList divisionList_sw	 = new ArrayList();
	private ArrayList divisionList_mw 	 = new ArrayList();
	private ArrayList divisionList_c2 	 = new ArrayList();
	private ArrayList divisionList_se 	 = new ArrayList();
	private ArrayList divisionList_ent 	 = new ArrayList();
	private ArrayList divisionList_mb 	 = new ArrayList();
	
	private ArrayList fileMashList_w 	 = new ArrayList();
	private ArrayList fileMashList_e 	 = new ArrayList();
	private ArrayList fileMashList_sw 	 = new ArrayList();
	private ArrayList fileMashList_mw 	 = new ArrayList();
	private ArrayList fileMashList_c2 	 = new ArrayList();
	private ArrayList fileMashList_se 	 = new ArrayList();
	private ArrayList fileMashList_mb 	 = new ArrayList();
	
	private ArrayList dbNodeList_w		 = new ArrayList();
	private ArrayList dbNodeList_e		 = new ArrayList();
	private ArrayList dbNodeList_sw		 = new ArrayList();
	private ArrayList dbNodeList_mw		 = new ArrayList();
	private ArrayList dbNodeList_c2		 = new ArrayList();
	private ArrayList dbNodeList_se		 = new ArrayList();
	private ArrayList dbNodeList_ent	 = new ArrayList();
	private ArrayList dbNodeList_mb	 	 = new ArrayList();	
	
	private ArrayList cntrlPtList_w  	 = new ArrayList();
	private ArrayList cntrlPtList_e  	 = new ArrayList();
	private ArrayList cntrlPtList_sw  	 = new ArrayList();
	private ArrayList cntrlPtList_mw  	 = new ArrayList();
	private ArrayList cntrlPtList_c2  	 = new ArrayList();
	private ArrayList cntrlPtList_se  	 = new ArrayList();
	private ArrayList cntrlPtList_mb  	 = new ArrayList();
	
	private ArrayList dataTblList_w  	 = new ArrayList();
	private ArrayList dataTblList_e  	 = new ArrayList();
	private ArrayList dataTblList_sw  	 = new ArrayList();
	private ArrayList dataTblList_mw  	 = new ArrayList();
	private ArrayList dataTblList_c2  	 = new ArrayList();
	private ArrayList dataTblList_se  	 = new ArrayList();
	private ArrayList dataTblList_mb  	 = new ArrayList();
	
	private ArrayList maxFormatList_w	 = new ArrayList();
	private ArrayList maxFormatList_e	 = new ArrayList();
	private ArrayList maxFormatList_sw	 = new ArrayList();
	private ArrayList maxFormatList_mw	 = new ArrayList();
	private ArrayList maxFormatList_c2	 = new ArrayList();
	private ArrayList maxFormatList_se	 = new ArrayList();
	private ArrayList maxFormatList_mb	 = new ArrayList();
	
	private ArrayList mouseOverList_w	 = new ArrayList();
	private ArrayList mouseOverList_e	 = new ArrayList();
	private ArrayList mouseOverList_sw	 = new ArrayList();
	private ArrayList mouseOverList_mw	 = new ArrayList();
	private ArrayList mouseOverList_c2	 = new ArrayList();
	private ArrayList mouseOverList_se	 = new ArrayList();
	private ArrayList mouseOverList_mb	 = new ArrayList();	
	
	private ArrayList alertRuleList_w	 = new ArrayList();
	private ArrayList alertRuleList_e	 = new ArrayList();
	private ArrayList alertRuleList_sw	 = new ArrayList();
	private ArrayList alertRuleList_mw	 = new ArrayList();
	private ArrayList alertRuleList_c2	 = new ArrayList();
	private ArrayList alertRuleList_se	 = new ArrayList();
	private ArrayList alertRuleList_mb	 = new ArrayList();
	
	private ArrayList rabcTableList_w	 = new ArrayList();
	private ArrayList rabcTableList_e	 = new ArrayList();
	private ArrayList rabcTableList_sw	 = new ArrayList();
	private ArrayList rabcTableList_mw	 = new ArrayList();
	private ArrayList rabcTableList_c2	 = new ArrayList();
	private ArrayList rabcTableList_se	 = new ArrayList();
	private ArrayList rabcTableList_mb	 = new ArrayList();
	
	private HashSet	  numberColumnSet_w	 = new HashSet();
	private HashSet	  numberColumnSet_e	 = new HashSet();
	private HashSet	  numberColumnSet_sw = new HashSet();
	private HashSet	  numberColumnSet_mw = new HashSet();
	private HashSet	  numberColumnSet_c2 = new HashSet();
	private HashSet	  numberColumnSet_se = new HashSet();
	private HashSet	  numberColumnSet_mb = new HashSet();
	
	private HashSet	  dateColumnSet_w 	 = new HashSet();
	private HashSet	  dateColumnSet_e 	 = new HashSet();
	private HashSet	  dateColumnSet_sw 	 = new HashSet();
	private HashSet	  dateColumnSet_mw 	 = new HashSet();
	private HashSet	  dateColumnSet_c2 	 = new HashSet();
	private HashSet	  dateColumnSet_se 	 = new HashSet();
	private HashSet	  dateColumnSet_mb 	 = new HashSet();
	
	private ArrayList billRndList_w		 = new ArrayList();
	private ArrayList billRndList_e		 = new ArrayList();
	private ArrayList billRndList_sw	 = new ArrayList();
	private ArrayList billRndList_mw	 = new ArrayList();
	private ArrayList billRndList_c2	 = new ArrayList();
	private ArrayList billRndList_se	 = new ArrayList();
	private ArrayList billRndList_mb	 = new ArrayList();
	
	private ArrayList processList_w		 = new ArrayList();
	private ArrayList processList_e		 = new ArrayList();
	private ArrayList processList_sw	 = new ArrayList();
	private ArrayList processList_mw	 = new ArrayList();
	private ArrayList processList_c2	 = new ArrayList();
	private ArrayList processList_se	 = new ArrayList();
	private ArrayList processList_ent	 = new ArrayList();
	private ArrayList processList_mb	 = new ArrayList();
	
	private String	  procDates_w		 = "";
	private String	  procDates_e		 = "";
	private String	  procDates_sw		 = "";
	private String	  procDates_mw		 = "";
	private String	  procDates_c2		 = "";
	private String	  procDates_se		 = "";
	private String	  procDates_mb		 = "";
	
	private String	  billRounds_w		 = "";
	private String	  billRounds_e		 = "";
	private String	  billRounds_sw		 = "";
	private String	  billRounds_mw		 = "";
	private String	  billRounds_c2		 = "";
	private String	  billRounds_se		 = "";
	private String	  billRounds_mb		 = "";
		
	private String	  holidayIndicators_w  = "";
	private String	  holidayIndicators_e  = "";
	private String	  holidayIndicators_sw = "";
	private String	  holidayIndicators_mw = "";
	private String	  holidayIndicators_c2 = "";
	private String	  holidayIndicators_se = "";
	private String	  holidayIndicators_mb = "";
	
	//List of dates when the data has been loaded based on RABC_ACCT_BLG_DTL table
	private String loadedDataDates_c2 = "";
	
	// Array List to store the region description for Enterprise
	private ArrayList regionList_ent 	 = new ArrayList();
	
	private StaticDataLoader(){
		for(int i =0; i < REGIONS.length; i++){
			loadedRegion.put(REGIONS[i],new Long(0));
		}
	}
	
	public static synchronized StaticDataLoader getRef(String region) {

		if (ref == null || (ref.loadedRegion.get(region) + (offset*1000)) < System.currentTimeMillis()) {
			StaticDataLoader temp;
			try {
				if(ref == null){
					temp = new StaticDataLoader();
					temp.load(region);
					ref = temp;
				}else{
					ref.load(region);
				}
				offset = lookupRefreshTimeInterval();
				//ref = temp;
			} catch(NamingException ne) {
				IllegalStateException e = new IllegalStateException("Unable to load static data: ");
				e.initCause(ne);
				throw e;
			} catch(SQLException sqle) {
				IllegalStateException e = new IllegalStateException("Unable to load static data: ");
				e.initCause(sqle);
				throw e;
			} catch(IllegalArgumentException iae) {
				IllegalStateException e = new IllegalStateException("Unable to load static data: ");
				e.initCause(iae);
				throw e;
			} finally {
				temp = null;
			}
		}
		return ref;
	}
	
	private void load(String region) throws SQLException, NamingException, IllegalArgumentException {
		Connection conn = null;
		//for (int i = 0; i < REGIONS.length; i++) {
		logger.info("Loading RABC static tables for region " + region);
			
			try {
				conn = ConnectionManager.getConnection(region);
				if ("EN".equals(region)){
					this.loadEnterpriseDBNode(conn, region);
					this.loadEnterpriseDivisions(conn, region);
					this.loadEnterpriseProcessList(conn, region);
				} else {
					this.loadDivision(conn, region);
					this.loadFileMash(conn, region);
					this.loadDBNode(conn, region);
					this.loadCntrlPtTrans(conn, region);
					this.loadDataTblDdl(conn, region);
					this.loadMaxFormat(conn, region);
					this.loadMouseOver(conn, region);
					this.loadAlertRule(conn, region);
					this.loadRabcTable(conn, region);
					this.loadNumberColumnSet(conn, region);
					this.loadDateColumnSet(conn, region);
					this.loadBillRndList(conn, region);
					this.loadProcessList(conn, region);
					this.loadCalendar(conn, region);
					this.loadDataDates(conn, region);
				}
			} catch(SQLException sqle) {
				logger.error("SQLException: ", sqle);
				throw sqle;
			} catch(NamingException ne) {
				logger.error("NamingException: ", ne);
				throw ne;
			} finally {
				try {
					if (conn != null)
						conn.close();
				} catch(SQLException sqle) {
					logger.error("SQLException in closing connection for region " + region + ": ", sqle);
					throw sqle;
				} finally {
					conn = null;
				}
			}
			logger.info("RABC static tables loaded for region " + region);
		//}
		//this.loaded = System.currentTimeMillis();
			loadedRegion.put(region,System.currentTimeMillis());
	}
	
	private static int lookupRefreshTimeInterval() throws NamingException {
		//Lookup offset
		Context initContext = new InitialContext();
		Context envContext = (Context)initContext.lookup("java:/comp/env");
		return ((Integer)envContext.lookup("staticDataLoader_refreshTimeInterval")).intValue();
	}
	
	public Object clone() throws CloneNotSupportedException {
		throw new CloneNotSupportedException(); 
	}	
	
	//The following methods load RABC static tables into in-memory objects
	/**
	 * @param region
	 * Loads the RABC_DIVISION table into an ArrayList of PickList objects, where
	 * where for each PickList, key = region:state:division, value1 = division desc 
	 */
	private void loadDivision(Connection conn, String region) throws SQLException {
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(StaticDataLoader.QRY_SELECT_DIVISION);
			if(region.equals("WE")) {
				divisionList_w.clear();
				while(rs.next()){
					divisionList_w.add(new PickList(rs.getString(1)+":"+rs.getString(2)+":"+rs.getString(3), rs.getString(4)));
				}
		    } else if(region.equals("E")) {
		    	divisionList_e.clear();
				while(rs.next()){
					divisionList_e.add(new PickList(rs.getString(1)+":"+rs.getString(2)+":"+rs.getString(3), rs.getString(4)));
				}
		    } else if(region.equals("MW")) {
		    	divisionList_mw.clear();
				while(rs.next()){
					divisionList_mw.add(new PickList(rs.getString(1)+":"+rs.getString(2)+":"+rs.getString(3), rs.getString(4)));
				}
		    } else if(region.equals("SW")) {
		    	divisionList_sw.clear();
				while(rs.next()){
					divisionList_sw.add(new PickList(rs.getString(1)+":"+rs.getString(2)+":"+rs.getString(3), rs.getString(4)));
				}
		    } else if(region.equals("C2")) {
		    	divisionList_c2.clear();
				while(rs.next()){
					divisionList_c2.add(new PickList(rs.getString(1)+":"+rs.getString(2)+":"+rs.getString(3), rs.getString(4)));
				}
		    } else if(region.equals("SE")) {
		    	divisionList_se.clear();
				while(rs.next()){
					divisionList_se.add(new PickList(rs.getString(1)+":"+rs.getString(2)+":"+rs.getString(3), rs.getString(4)));
				}	
		    } else if(region.equals("MB")) {
		    	divisionList_mb.clear();
				while(rs.next()){
					divisionList_mb.add(new PickList(rs.getString(1)+":"+rs.getString(2)+":"+rs.getString(3), rs.getString(4)));
				}
		    }else {
		        throw new IllegalArgumentException("Unrecognized region: " + region);
		    }
		} catch(SQLException sqle) {
			logger.error("SQLException: ", sqle);
			throw sqle;
		} finally {
			try {
				if (rs != null)
					rs.close();
			} catch(SQLException sqle) {
				logger.error("SQLException in closing result set: ", sqle);
				throw sqle;
			} finally {
				rs = null;
			}
			try {
				if (stmt != null)
					stmt.close();
			} catch(SQLException sqle) {
				logger.error("SQLException in closing statement: ", sqle);
				throw sqle;
			} finally {
				stmt = null;
			}
		}
	}
	
	/**
	 * Loads divisions for enterprise
	 * @param conn
	 * @param region
	 * @throws SQLException
	 */
	private void loadEnterpriseDivisions(Connection conn, String region) throws SQLException {
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(StaticDataLoader.QRY_SELECT_DIVISION_ENT);
			divisionList_ent.clear();
			regionList_ent.clear();
			while(rs.next()){
				divisionList_ent.add(new PickList(rs.getString(1)+":"+rs.getString(2)+":"+rs.getString(3), rs.getString(4)));
				// Populate the regionList_ent list
				String regionCd = rs.getString(1);
				if (regionList_ent.isEmpty()){
					regionList_ent.add(new PickList(rs.getString(1),rs.getString(5)));
				} else {
					boolean exists = false;
					int regionList_entSize = regionList_ent.size();
					for (int i=0;i<regionList_entSize;i++){
						PickList regionPickList = (PickList)regionList_ent.get(i);
						if (regionCd.equalsIgnoreCase(regionPickList.getKey())){
							exists = true;
							break;
						}
					}
					if (exists == false){
						regionList_ent.add(new PickList(rs.getString(1),rs.getString(5)));
					}
				}
			}
		} catch(SQLException sqle) {
			logger.error("SQLException: ", sqle);
			throw sqle;
		} finally {
			try {
				if (rs != null)
					rs.close();
			} catch(SQLException sqle) {
				logger.error("SQLException in closing result set: ", sqle);
				throw sqle;
			} finally {
				rs = null;
			}
			try {
				if (stmt != null)
					stmt.close();
			} catch(SQLException sqle) {
				logger.error("SQLException in closing statement: ", sqle);
				throw sqle;
			} finally {
				stmt = null;
			}
		}
	}
	
	/**
	 * Loads the RABC_FILE_MASH table into an ArrayList of PickList objects, where
	 * for each PickList, key = table name, value1 = file ID and value2 = file mash   
	 */
	private void loadFileMash(Connection conn, String region) throws SQLException {
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(StaticDataLoader.QRY_SELECT_FILE_MASH);
			if(region.equals("WE")) {
				fileMashList_w.clear();
				while(rs.next()){
					fileMashList_w.add(new PickList(rs.getString(1),rs.getString(2),rs.getString(3)));
				}
		    } else if(region.equals("E")) {
		    	fileMashList_e.clear();
				while(rs.next()){
					fileMashList_e.add(new PickList(rs.getString(1),rs.getString(2),rs.getString(3)));
				}
		    } else if(region.equals("MW")) {
		    	fileMashList_mw.clear();
				while(rs.next()){
					fileMashList_mw.add(new PickList(rs.getString(1),rs.getString(2),rs.getString(3)));
				}
		    } else if(region.equals("SW")) {
		    	fileMashList_sw.clear();
				while(rs.next()){
					fileMashList_sw.add(new PickList(rs.getString(1),rs.getString(2),rs.getString(3)));
				}
		    } else if(region.equals("C2")) {
		    	fileMashList_c2.clear();
				while(rs.next()){
					fileMashList_c2.add(new PickList(rs.getString(1),rs.getString(2),rs.getString(3)));
				}
		    } else if(region.equals("SE")) {
		    	fileMashList_se.clear();
				while(rs.next()){
					fileMashList_se.add(new PickList(rs.getString(1),rs.getString(2),rs.getString(3)));
				}	
		    }else if(region.equals("MB")) {
		    	fileMashList_mb.clear();
				while(rs.next()){
					fileMashList_mb.add(new PickList(rs.getString(1),rs.getString(2),rs.getString(3)));
				}
		    }else {
		        throw new IllegalArgumentException("Unrecognized region: " + region);
		    }
		} catch(SQLException sqle) {
			logger.error("SQLException: ", sqle);
			throw sqle;
		} finally {
			try {
				if (rs != null)
					rs.close();
			} catch(SQLException sqle) {
				logger.error("SQLException in closing result set: ", sqle);
				throw sqle;
			} finally {
				rs = null;
			}
			try {
				if (stmt != null)
					stmt.close();
			} catch(SQLException sqle) {
				logger.error("SQLException in closing statement: ", sqle);
				throw sqle;
			} finally {
				stmt = null;
			}
		}		
	}

	/**
	 * Loads the RABC_DB_NODE table into an ArrayList of PickList objects, where
	 * for each PickList, key = DB node ID, value1 = DB node and value2 = DB node description   
	 */
	private void loadDBNode(Connection conn, String region) throws SQLException {
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(StaticDataLoader.QRY_SELECT_DB_NODE);
			if(region.equals("WE")) {
				dbNodeList_w.clear();
				while(rs.next()){
					dbNodeList_w.add(new PickList(rs.getString(1),rs.getString(2),rs.getString(3)));
				}
		    } else if(region.equals("E")) {
		    	dbNodeList_e.clear();
				while(rs.next()){
					dbNodeList_e.add(new PickList(rs.getString(1),rs.getString(2),rs.getString(3)));
				}
		    } else if(region.equals("MW")) {
		    	dbNodeList_mw.clear();
				while(rs.next()){
					dbNodeList_mw.add(new PickList(rs.getString(1),rs.getString(2),rs.getString(3)));
				}
		    } else if(region.equals("SW")) {
		    	dbNodeList_sw.clear();
				while(rs.next()){
					dbNodeList_sw.add(new PickList(rs.getString(1),rs.getString(2),rs.getString(3)));
				}
		    } else if(region.equals("C2")) {
		    	dbNodeList_c2.clear();
				while(rs.next()){
					dbNodeList_c2.add(new PickList(rs.getString(1),rs.getString(2),rs.getString(3)));
				}
		    } else if(region.equals("SE")) {
		    	dbNodeList_se.clear();
				while(rs.next()){
					dbNodeList_se.add(new PickList(rs.getString(1),rs.getString(2),rs.getString(3)));
				}	
		    } else if(region.equals("MB")) {
		    	dbNodeList_mb.clear();
				while(rs.next()){
					dbNodeList_mb.add(new PickList(rs.getString(1),rs.getString(2),rs.getString(3)));
				}
		    } else {
		        throw new IllegalArgumentException("Unrecognized region: " + region);
		    }
		} catch(SQLException sqle) {
			logger.error("SQLException: ", sqle);
			throw sqle;
		} finally {
			try {
				if (rs != null)
					rs.close();
			} catch(SQLException sqle) {
				logger.error("SQLException in closing result set: ", sqle);
				throw sqle;
			} finally {
				rs = null;
			}
			try {
				if (stmt != null)
					stmt.close();
			} catch(SQLException sqle) {
				logger.error("SQLException in closing statement: ", sqle);
				throw sqle;
			} finally {
				stmt = null;
			}
		}		
	}
	
	/**
	 * Loads the RABC_REGION_DB_NODE table into an ArrayList of PickList objects, where
	 * for each PickList, key = DB node ID, value1 = DB node and value2 = DB node description   
	 */
	private void loadEnterpriseDBNode(Connection conn, String region) throws SQLException {
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(StaticDataLoader.QRY_SELECT_DB_NODE_ENT);

			dbNodeList_ent.clear();
			while(rs.next()){
				dbNodeList_ent.add(new PickList(rs.getString(1),rs.getString(2)));
			}   
		} catch(SQLException sqle) {
			logger.error("SQLException: ", sqle);
			throw sqle;
		} finally {
			try {
				if (rs != null)
					rs.close();
			} catch(SQLException sqle) {
				logger.error("SQLException in closing result set: ", sqle);
				throw sqle;
			} finally {
				rs = null;
			}
			try {
				if (stmt != null)
					stmt.close();
			} catch(SQLException sqle) {
				logger.error("SQLException in closing statement: ", sqle);
				throw sqle;
			} finally {
				stmt = null;
			}
		}		
	}	

	/**
	 * Loads the RABC_CNTRL_PT_TRANS table into an ArrayList of PickList objects, where
	 * for each PickList, key = control point code, value1 = sequence number and value2 = control point desc   
	 */
	private void loadCntrlPtTrans(Connection conn, String region) throws SQLException {
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(StaticDataLoader.QRY_SELECT_CNTRL_PT);
			if(region.equals("WE")) {
				cntrlPtList_w.clear();
				while(rs.next()){
					cntrlPtList_w.add(new PickList(rs.getString(1),rs.getString(2),rs.getString(3)));
				}
		    } else if(region.equals("E")) {
		    	cntrlPtList_e.clear();
				while(rs.next()){
					cntrlPtList_e.add(new PickList(rs.getString(1),rs.getString(2),rs.getString(3)));
				}
		    } else if(region.equals("MW")) {
		    	cntrlPtList_mw.clear();
				while(rs.next()){
					cntrlPtList_mw.add(new PickList(rs.getString(1),rs.getString(2),rs.getString(3)));
				}
		    } else if(region.equals("SW")) {
		    	cntrlPtList_sw.clear();
				while(rs.next()){
					cntrlPtList_sw.add(new PickList(rs.getString(1),rs.getString(2),rs.getString(3)));
				}
		    } else if(region.equals("C2")) {
		    	cntrlPtList_c2.clear();
				while(rs.next()){
					cntrlPtList_c2.add(new PickList(rs.getString(1),rs.getString(2),rs.getString(3)));
				}
		    } else if(region.equals("SE")) {
		    	cntrlPtList_se.clear();
				while(rs.next()){
					cntrlPtList_se.add(new PickList(rs.getString(1),rs.getString(2),rs.getString(3)));
				}	
		    }else if(region.equals("MB")) {
		    	cntrlPtList_mb.clear();
				while(rs.next()){
					cntrlPtList_mb.add(new PickList(rs.getString(1),rs.getString(2),rs.getString(3)));
				}
		    } else {
		        throw new IllegalArgumentException("Unrecognized region: " + region);
		    }
		} catch(SQLException sqle) {
			logger.error("SQLException: ", sqle);
			throw sqle;
		} finally {
			try {
				if (rs != null)
					rs.close();
			} catch(SQLException sqle) {
				logger.error("SQLException in closing result set: ", sqle);
				throw sqle;
			} finally {
				rs = null;
			}
			try {
				if (stmt != null)
					stmt.close();
			} catch(SQLException sqle) {
				logger.error("SQLException in closing statement: ", sqle);
				throw sqle;
			} finally {
				stmt = null;
			}
		}
	}	

	/**
	 * Loads the RABC_DATA_TBL_DDL table into an ArrayList of DataTblDdlBean objects   
	 */
	private void loadDataTblDdl(Connection conn, String region) throws SQLException {
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(StaticDataLoader.QRY_SELECT_DATA_TBL);
			if(region.equals("WE")) {
				dataTblList_w.clear();
				while(rs.next()){
					dataTblList_w.add(new DataTblDdlBean(rs.getString(1), rs.getString(2), rs.getString(3), rs.getInt(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10), rs.getString(11), rs.getString(12), rs.getString(13), rs.getString(14), rs.getString(15), rs.getString(16), rs.getString(17)));
				}
		    } else if(region.equals("E")) {
		    	dataTblList_e.clear();
				while(rs.next()){
					dataTblList_e.add(new DataTblDdlBean(rs.getString(1), rs.getString(2), rs.getString(3), rs.getInt(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10), rs.getString(11), rs.getString(12), rs.getString(13), rs.getString(14), rs.getString(15), rs.getString(16), rs.getString(17)));
				}
		    } else if(region.equals("MW")) {
		    	dataTblList_mw.clear();
				while(rs.next()){
					dataTblList_mw.add(new DataTblDdlBean(rs.getString(1), rs.getString(2), rs.getString(3), rs.getInt(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10), rs.getString(11), rs.getString(12), rs.getString(13), rs.getString(14), rs.getString(15), rs.getString(16), rs.getString(17)));
				}
		    } else if(region.equals("SW")) {
		    	dataTblList_sw.clear();
				while(rs.next()){
					dataTblList_sw.add(new DataTblDdlBean(rs.getString(1), rs.getString(2), rs.getString(3), rs.getInt(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10), rs.getString(11), rs.getString(12), rs.getString(13), rs.getString(14), rs.getString(15), rs.getString(16), rs.getString(17)));
				}
		    } else if(region.equals("C2")) {
		    	dataTblList_c2.clear();
				while(rs.next()){
					dataTblList_c2.add(new DataTblDdlBean(rs.getString(1), rs.getString(2), rs.getString(3), rs.getInt(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10), rs.getString(11), rs.getString(12), rs.getString(13), rs.getString(14), rs.getString(15), rs.getString(16), rs.getString(17)));
				}
		    } else if(region.equals("SE")) {
		    	dataTblList_se.clear();
				while(rs.next()){
					dataTblList_se.add(new DataTblDdlBean(rs.getString(1), rs.getString(2), rs.getString(3), rs.getInt(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10), rs.getString(11), rs.getString(12), rs.getString(13), rs.getString(14), rs.getString(15), rs.getString(16), rs.getString(17)));
				}	
		    }else if(region.equals("MB")) {
		    	dataTblList_mb.clear();
				while(rs.next()){
					dataTblList_mb.add(new DataTblDdlBean(rs.getString(1), rs.getString(2), rs.getString(3), rs.getInt(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10), rs.getString(11), rs.getString(12), rs.getString(13), rs.getString(14), rs.getString(15), rs.getString(16), rs.getString(17)));
				}
		    }else {
		        throw new IllegalArgumentException("Unrecognized region: " + region);
		    }
		} catch(SQLException sqle) {
			logger.error("SQLException: ", sqle);
			throw sqle;
		} finally {
			try {
				if (rs != null)
					rs.close();
			} catch(SQLException sqle) {
				logger.error("SQLException in closing result set: ", sqle);
				throw sqle;
			} finally {
				rs = null;
			}
			try {
				if (stmt != null)
					stmt.close();
			} catch(SQLException sqle) {
				logger.error("SQLException in closing statement: ", sqle);
				throw sqle;
			} finally {
				stmt = null;
			}
		}
	}	

	/**
	 * Loads the RABC_DATA_TBL_DDL table into an ArrayList of PickList objects, where
	 * for each PickList, key = TBL_DDL_NAME, value1 = MAX(TBL_DDL_PRESCSN_FORMAT_TYPE)
	 */	
	private void loadMaxFormat(Connection conn, String region) throws SQLException {
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(StaticDataLoader.QRY_SELECT_MAX_FORMAT_TYPE);
			if(region.equals("WE")) {
				maxFormatList_w.clear();
				while(rs.next()){
					maxFormatList_w.add(new PickList(rs.getString(1), rs.getString(2)));
				}
		    } else if(region.equals("E")) {
		    	maxFormatList_e.clear();
				while(rs.next()){
					maxFormatList_e.add(new PickList(rs.getString(1), rs.getString(2)));
				}
		    } else if(region.equals("MW")) {
		    	maxFormatList_mw.clear();
				while(rs.next()){
					maxFormatList_mw.add(new PickList(rs.getString(1), rs.getString(2)));
				}
		    } else if(region.equals("SW")) {
		    	maxFormatList_sw.clear();
				while(rs.next()){
					maxFormatList_sw.add(new PickList(rs.getString(1), rs.getString(2)));
				}
		    } else if(region.equals("C2")) {
		    	maxFormatList_c2.clear();
				while(rs.next()){
					maxFormatList_c2.add(new PickList(rs.getString(1), rs.getString(2)));
				}
		    } else if(region.equals("SE")) {
		    	maxFormatList_se.clear();
				while(rs.next()){
					maxFormatList_se.add(new PickList(rs.getString(1), rs.getString(2)));
				}	
		    }else if(region.equals("MB")) {
		    	maxFormatList_mb.clear();
				while(rs.next()){
					maxFormatList_mb.add(new PickList(rs.getString(1), rs.getString(2)));
				}
		    }else {
		        throw new IllegalArgumentException("Unrecognized region: " + region);
		    }
		} catch(SQLException sqle) {
			logger.error("SQLException: ", sqle);
			throw sqle;
		} finally {
			try {
				if (rs != null)
					rs.close();
			} catch(SQLException sqle) {
				logger.error("SQLException in closing result set: ", sqle);
				throw sqle;
			} finally {
				rs = null;
			}
			try {
				if (stmt != null)
					stmt.close();
			} catch(SQLException sqle) {
				logger.error("SQLException in closing statement: ", sqle);
				throw sqle;
			} finally {
				stmt = null;
			}
		}
	}

	/**
	 * Loads the RABC_MOUSE_OVER_TBL table into an ArrayList of PickList objects, where
	 * for each PickList, key = TABLE_NAME, value1 = TABLE_DESC 
	 */	
	private void loadMouseOver(Connection conn, String region) throws SQLException {
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(StaticDataLoader.QRY_SELECT_MOUSE_OVER);
			if(region.equals("WE")) {
				mouseOverList_w.clear();
				while(rs.next()){
					mouseOverList_w.add(new PickList(rs.getString(2), rs.getString(1), rs.getString(3), rs.getString(4)));
				}
		    } else if(region.equals("E")) {
		    	mouseOverList_e.clear();
				while(rs.next()){
					mouseOverList_e.add(new PickList(rs.getString(2), rs.getString(1), rs.getString(3), rs.getString(4)));
				}
		    } else if(region.equals("MW")) {
		    	mouseOverList_mw.clear();
				while(rs.next()){
					mouseOverList_mw.add(new PickList(rs.getString(2), rs.getString(1), rs.getString(3), rs.getString(4)));
				}
		    } else if(region.equals("SW")) {
		    	mouseOverList_sw.clear();
				while(rs.next()){
					mouseOverList_sw.add(new PickList(rs.getString(2), rs.getString(1), rs.getString(3), rs.getString(4)));
				}
		    } else if(region.equals("C2")) {
		    	mouseOverList_c2.clear();
				while(rs.next()){
					mouseOverList_c2.add(new PickList(rs.getString(2), rs.getString(1), rs.getString(3), rs.getString(4)));
				}
		    } else if(region.equals("SE")) {
		    	mouseOverList_se.clear();
				while(rs.next()){
					mouseOverList_se.add(new PickList(rs.getString(2), rs.getString(1), rs.getString(3), rs.getString(4)));
				}	
		    }else if(region.equals("MB")) {
		    	mouseOverList_mb.clear();
				while(rs.next()){
					mouseOverList_mb.add(new PickList(rs.getString(2), rs.getString(1), rs.getString(3), rs.getString(4)));
				}
		    }else {
		        throw new IllegalArgumentException("Unrecognized region: " + region);
		    }
		} catch(SQLException sqle) {
			logger.error("SQLException: ", sqle);
			throw sqle;
		} finally {
			try {
				if (rs != null)
					rs.close();
			} catch(SQLException sqle) {
				logger.error("SQLException in closing result set: ", sqle);
				throw sqle;
			} finally {
				rs = null;
			}
			try {
				if (stmt != null)
					stmt.close();
			} catch(SQLException sqle) {
				logger.error("SQLException in closing statement: ", sqle);
				throw sqle;
			} finally {
				stmt = null;
			}
		}
	}
	/**
	 * Loads the RABC_ALERT_RULE_TBL table into an ArrayList of PickList objects, where
	 * for each PickList, key = PARTI_REF_ID, value1 = ALERT_RULE 
	 */	
	
	private void loadAlertRule(Connection conn, String region) throws SQLException {
		Statement stmt = null;
		ResultSet rs   = null;
		
		try {
			stmt = conn.createStatement();
			rs   = stmt.executeQuery(StaticDataLoader.QRY_SELECT_ALERT_RULE);
			if(region.equals("WE")) {
		    	alertRuleList_w.clear();
				while(rs.next()){
					alertRuleList_w.add(new PickList(rs.getString(1), rs.getString(2)));
				}
		    } else if(region.equals("E")) {
		    	alertRuleList_e.clear();
				while(rs.next()){
					alertRuleList_e.add(new PickList(rs.getString(1), rs.getString(2)));
				}
		    } else if(region.equals("SW")) {
		    	alertRuleList_sw.clear();
				while(rs.next()){
					alertRuleList_sw.add(new PickList(rs.getString(1), rs.getString(2)));
				}
		    } else if(region.equals("MW")) {
		    	alertRuleList_mw.clear();
				while(rs.next()){
					alertRuleList_mw.add(new PickList(rs.getString(1), rs.getString(2)));
				}
		    } else if(region.equals("C2")) {
		    	alertRuleList_c2.clear();
				while(rs.next()){
					alertRuleList_c2.add(new PickList(rs.getString(1), rs.getString(2)));
				}
		    } else if(region.equals("SE")) {
		    	alertRuleList_se.clear();
				while(rs.next()){
					alertRuleList_se.add(new PickList(rs.getString(1), rs.getString(2)));
				}	
		    } else if(region.equals("MB")) {
		    	alertRuleList_mb.clear();
				while(rs.next()){
					alertRuleList_mb.add(new PickList(rs.getString(1), rs.getString(2)));
				}
		    }else {
		        throw new IllegalArgumentException("Unrecognized region: " + region);
		    }
		} catch(SQLException sqle) {
			logger.error("SQLException: ", sqle);
			throw sqle;
		} finally {
			try {
				if (rs != null)
					rs.close();
			} catch(SQLException sqle) {
				logger.error("SQLException in closing result set: ", sqle);
				throw sqle;
			} finally {
				rs = null;
			}
			try {
				if (stmt != null)
					stmt.close();
			} catch(SQLException sqle) {
				logger.error("SQLException in closing statement: ", sqle);
				throw sqle;
			} finally {
				stmt = null;
			}
		}
	}	
	
	
	/**
	 * Loads the RABC_TABLE table into an ArrayList of PickList objects, where
	 * for each PickList, key = ALERT_PROC_TBL, value1 = TBL_DESC, value2 = TBL_NODE, value3 = PARTI_REF_ID_IND
	 */	
	private void loadRabcTable(Connection conn, String region) throws SQLException {
		Statement stmt = null;
		ResultSet rs = null;
		
		
		
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(StaticDataLoader.QRY_SELECT_RABC_TABLE);
			if(region.equals("WE")) {
				rabcTableList_w.clear();
				while(rs.next()){
					rabcTableList_w.add(new PickList(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4)));
				}
		    } else if(region.equals("E")) {
		    	rabcTableList_e.clear();
				while(rs.next()){
					rabcTableList_e.add(new PickList(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4)));
				}
		    } else if(region.equals("MW")) {
		    	rabcTableList_mw.clear();
				while(rs.next()){
					rabcTableList_mw.add(new PickList(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4)));
				}
		    } else if(region.equals("SW")) {
		    	rabcTableList_sw.clear();
				while(rs.next()){
					rabcTableList_sw.add(new PickList(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4)));
				}
		    } else if(region.equals("C2")) {
		    	rabcTableList_c2.clear();
				while(rs.next()){
					rabcTableList_c2.add(new PickList(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4)));
				}
		    } else if(region.equals("SE")) {
		    	rabcTableList_se.clear();
				while(rs.next()){
					rabcTableList_se.add(new PickList(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4)));
				}	
		    } else if(region.equals("MB")) {
		    	rabcTableList_mb.clear();
				while(rs.next()){
					rabcTableList_mb.add(new PickList(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4)));
				}
		    }else {
		        throw new IllegalArgumentException("Unrecognized region: " + region);
		    }
		} catch(SQLException sqle) {
			logger.error("SQLException: ", sqle);
			throw sqle;
		} finally {
			try {
				if (rs != null)
					rs.close();
			} catch(SQLException sqle) {
				logger.error("SQLException in closing result set: ", sqle);
				throw sqle;
			} finally {
				rs = null;
			}
			try {
				if (stmt != null)
					stmt.close();
			} catch(SQLException sqle) {
				logger.error("SQLException in closing statement: ", sqle);
				throw sqle;
			} finally {
				stmt = null;
			}
		}
	}	
	
	private void loadNumberColumnSet(Connection conn, String region) throws SQLException {
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(StaticDataLoader.QRY_GET_NUMBER_TYPE_COLUMN);
			if(region.equals("WE")) {
				numberColumnSet_w.clear();
				while(rs.next()){
					numberColumnSet_w.add(rs.getString(1));
				}
		    } else if(region.equals("E")) {
		    	numberColumnSet_e.clear();
				while(rs.next()){
					numberColumnSet_e.add(rs.getString(1));
				}
		    } else if(region.equals("MW")) {
		    	numberColumnSet_mw.clear();
				while(rs.next()){
					numberColumnSet_mw.add(rs.getString(1));
				}
		    } else if(region.equals("SW")) {
		    	numberColumnSet_sw.clear();
				while(rs.next()){
					numberColumnSet_sw.add(rs.getString(1));
				}
		    } else if(region.equals("C2")) {
		    	numberColumnSet_c2.clear();
				while(rs.next()){
					numberColumnSet_c2.add(rs.getString(1));
				}
		    } else if(region.equals("SE")) {
		    	numberColumnSet_se.clear();
				while(rs.next()){
					numberColumnSet_se.add(rs.getString(1));
				}	
		    }else if(region.equals("MB")) {
		    	numberColumnSet_mb.clear();
				while(rs.next()){
					numberColumnSet_mb.add(rs.getString(1));
				}
		    }else {
		        throw new IllegalArgumentException("Unrecognized region: " + region);
		    }
		} catch(SQLException sqle) {
			logger.error("SQLException: ", sqle);
			throw sqle;
		} finally {
			try {
				if (rs != null)
					rs.close();
			} catch(SQLException sqle) {
				logger.error("SQLException in closing result set: ", sqle);
				throw sqle;
			} finally {
				rs = null;
			}
			try {
				if (stmt != null)
					stmt.close();
			} catch(SQLException sqle) {
				logger.error("SQLException in closing statement: ", sqle);
				throw sqle;
			} finally {
				stmt = null;
			}
		}
	}

	private void loadDateColumnSet(Connection conn, String region) throws SQLException {
		Statement stmt = null;
		ResultSet rs = null;	
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(StaticDataLoader.QRY_GET_DATE_TYPE_COLUMN);
			if(region.equals("WE")) {
				dateColumnSet_w.clear();
				while(rs.next()){
					dateColumnSet_w.add(rs.getString(1));
				}
		    } else if(region.equals("E")) {
		    	dateColumnSet_e.clear();
				while(rs.next()){
					dateColumnSet_e.add(rs.getString(1));
				}
		    } else if(region.equals("MW")) {
		    	dateColumnSet_mw.clear();
				while(rs.next()){
					dateColumnSet_mw.add(rs.getString(1));
				}
		    } else if(region.equals("SW")) {
		    	dateColumnSet_sw.clear();
				while(rs.next()){
					dateColumnSet_sw.add(rs.getString(1));
				}
		    } else if(region.equals("C2")) {
		    	dateColumnSet_c2.clear();
				while(rs.next()){
					dateColumnSet_c2.add(rs.getString(1));
				}
		    } else if(region.equals("SE")) {
		    	dateColumnSet_se.clear();
				while(rs.next()){
					dateColumnSet_se.add(rs.getString(1));
				}	
		    }else if(region.equals("MB")) {
		    	dateColumnSet_mb.clear();
				while(rs.next()){
					dateColumnSet_mb.add(rs.getString(1));
				}
		    }else {
		        throw new IllegalArgumentException("Unrecognized region: " + region);
		    }
		} catch(SQLException sqle) {
			logger.error("SQLException: ", sqle);
			throw sqle;
		} finally {
			try {
				if (rs != null)
					rs.close();
			} catch(SQLException sqle) {
				logger.error("SQLException in closing result set: ", sqle);
				throw sqle;
			} finally {
				rs = null;
			}
			try {
				if (stmt != null)
					stmt.close();
			} catch(SQLException sqle) {
				logger.error("SQLException in closing statement: ", sqle);
				throw sqle;
			} finally {
				stmt = null;
			}
		}
	}
	
	/**
	 * Loads the RABC_REGION_BILL_RND table into an ArrayList of PickList objects, where
	 * for each PickList, key = REGION, value1 = BILL_RND
	 */		
	private void loadBillRndList(Connection conn, String region) throws SQLException {
		Statement stmt = null;
		ResultSet rs = null;	
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(StaticDataLoader.QRY_GET_BILL_RND);
			if(region.equals("WE")) {
				billRndList_w.clear();
				while(rs.next()){
					billRndList_w.add(new PickList(rs.getString(1), rs.getString(2)));
				}
		    } else if(region.equals("E")) {
		    	billRndList_e.clear();
				while(rs.next()){
					billRndList_e.add(new PickList(rs.getString(1), rs.getString(2)));
				}
		    } else if(region.equals("MW")) {
		    	billRndList_mw.clear();
				while(rs.next()){
					billRndList_mw.add(new PickList(rs.getString(1), rs.getString(2)));
				}
		    } else if(region.equals("SW")) {
		    	billRndList_sw.clear();
				while(rs.next()){
					billRndList_sw.add(new PickList(rs.getString(1), rs.getString(2)));
				}
		    } else if(region.equals("C2")) {
		    	billRndList_c2.clear();
				while(rs.next()){
					billRndList_c2.add(new PickList(rs.getString(1), rs.getString(2)));
				}
		    } else if(region.equals("SE")) {
		    	billRndList_se.clear();
				while(rs.next()){
					billRndList_se.add(new PickList(rs.getString(1), rs.getString(2)));
				}	
		    }else if(region.equals("MB")) {
		    	billRndList_mb.clear();
				while(rs.next()){
					billRndList_mb.add(new PickList(rs.getString(1), rs.getString(2)));
				}
		    } else {
		        throw new IllegalArgumentException("Unrecognized region: " + region);
		    }
		} catch(SQLException sqle) {
			logger.error("SQLException: ", sqle);
			throw sqle;
		} finally {
			try {
				if (rs != null)
					rs.close();
			} catch(SQLException sqle) {
				logger.error("SQLException in closing result set: ", sqle);
				throw sqle;
			} finally {
				rs = null;
			}
			try {
				if (stmt != null)
					stmt.close();
			} catch(SQLException sqle) {
				logger.error("SQLException in closing statement: ", sqle);
				throw sqle;
			} finally {
				stmt = null;
			}
		}
	}
	
	/**
	 * Loads the RABC_PROCESS table into an ArrayList of PickList objects, where
	 * for each PickList, key = PROCESS, value1 = CNTRL_PT_CD
	 */		
	private void loadProcessList(Connection conn, String region) throws SQLException {
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(StaticDataLoader.QRY_GET_PROCESS);
			if(region.equals("WE")) {
				processList_w.clear();
				while(rs.next()){
					processList_w.add(new PickList(rs.getString(1), rs.getString(2)));
				}
		    } else if(region.equals("E")) {
		    	processList_e.clear();
				while(rs.next()){
					processList_e.add(new PickList(rs.getString(1), rs.getString(2)));
				}
		    } else if(region.equals("MW")) {
		    	processList_mw.clear();
				while(rs.next()){
					processList_mw.add(new PickList(rs.getString(1), rs.getString(2)));
				}
		    } else if(region.equals("SW")) {
		    	processList_sw.clear();
				while(rs.next()){
					processList_sw.add(new PickList(rs.getString(1), rs.getString(2)));
				}
		    } else if(region.equals("C2")) {
		    	processList_c2.clear();
				while(rs.next()){
					processList_c2.add(new PickList(rs.getString(1), rs.getString(2)));
				}
		    } else if(region.equals("SE")) {
		    	processList_se.clear();
				while(rs.next()){
					processList_se.add(new PickList(rs.getString(1), rs.getString(2)));
				}	
		    } else if(region.equals("MB")) {
		    	processList_mb.clear();
				while(rs.next()){
					processList_mb.add(new PickList(rs.getString(1), rs.getString(2)));
				}	
		    }else {
		        throw new IllegalArgumentException("Unrecognized region: " + region);
		    }
		} catch(SQLException sqle) {
			logger.error("SQLException: ", sqle);
			throw sqle;
		} finally {
			try {
				if (rs != null)
					rs.close();
			} catch(SQLException sqle) {
				logger.error("SQLException in closing result set: ", sqle);
				throw sqle;
			} finally {
				rs = null;
			}
			try {
				if (stmt != null)
					stmt.close();
			} catch(SQLException sqle) {
				logger.error("SQLException in closing statement: ", sqle);
				throw sqle;
			} finally {
				stmt = null;
			}
		}
	}
	
	/**
	 * Loads the RABC_PROCESS table into an ArrayList of PickList objects, where
	 * for each PickList, key = PROCESS, value1 = CNTRL_PT_CD
	 */		
	private void loadEnterpriseProcessList(Connection conn, String region) throws SQLException {
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(StaticDataLoader.QRY_GET_PROCESS_ENT);

			processList_ent.clear();
			while(rs.next()){
				processList_ent.add(new PickList(rs.getString(1), rs.getString(2)));
			}
		    
		} catch(SQLException sqle) {
			logger.error("SQLException: ", sqle);
			throw sqle;
		} finally {
			try {
				if (rs != null)
					rs.close();
			} catch(SQLException sqle) {
				logger.error("SQLException in closing result set: ", sqle);
				throw sqle;
			} finally {
				rs = null;
			}
			try {
				if (stmt != null)
					stmt.close();
			} catch(SQLException sqle) {
				logger.error("SQLException in closing statement: ", sqle);
				throw sqle;
			} finally {
				stmt = null;
			}
		}
	}
	
	/**
	 * Loads the RABC_CYCLE_CALENDAR table into an ArrayList of picklist objects, where
	 * for each PickList, key = PROC_DATE, value1 = BILL_RND and value2= HOLIDAY_IND
	 */		
	private void loadCalendar(Connection conn, String region) throws SQLException {
		Statement stmt = null;
		ResultSet rs = null;
		try{
			stmt = conn.createStatement();
			rs = stmt.executeQuery(StaticDataLoader.QRY_GET_BILLCYCLES);
			if(region.equals("WE")) {
				StringBuffer billRoundsBuffer_w = new StringBuffer();
				StringBuffer procDatesBuffer_w = new StringBuffer();
				StringBuffer holidayIndicatorBuffer_w = new StringBuffer();
				while(rs.next()) {
					MyDate procDate = new MyDate(rs.getDate(1));
					if("".equals(procDatesBuffer_w)) {
						procDatesBuffer_w.append(procDate.toString());
						billRoundsBuffer_w.append(Integer.toString(rs.getInt(2)));
						holidayIndicatorBuffer_w.append(rs.getString(3));
					} else {
						procDatesBuffer_w.append("~");
						procDatesBuffer_w.append(procDate.toString());
						
						billRoundsBuffer_w.append("~");
						billRoundsBuffer_w.append(Integer.toString(rs.getInt(2)));
						
						holidayIndicatorBuffer_w.append("~");
						holidayIndicatorBuffer_w.append(rs.getString(3));
					}
				}
				procDates_w = procDatesBuffer_w.toString();
				billRounds_w = billRoundsBuffer_w.toString();
				holidayIndicators_w = holidayIndicatorBuffer_w.toString();
				billRoundsBuffer_w = null;
				procDatesBuffer_w = null;
				holidayIndicatorBuffer_w = null;
		    } else if(region.equals("E")) {
		    	StringBuffer billRoundsBuffer_e = new StringBuffer();
		    	StringBuffer procDatesBuffer_e = new StringBuffer();
		    	StringBuffer holidayIndicatorBuffer_e = new StringBuffer();
				while(rs.next()){
					MyDate procDate = new MyDate(rs.getDate(1));
					if("".equals(procDatesBuffer_e)) {
						procDatesBuffer_e.append(procDate.toString());
						billRoundsBuffer_e.append(Integer.toString(rs.getInt(2)));
						holidayIndicatorBuffer_e.append(rs.getString(3));
					} else {
						procDatesBuffer_e.append("~");
						procDatesBuffer_e.append(procDate.toString());
						
						billRoundsBuffer_e.append("~");
						billRoundsBuffer_e.append(Integer.toString(rs.getInt(2)));
						
						holidayIndicatorBuffer_e.append("~");
						holidayIndicatorBuffer_e.append(rs.getString(3));
					}
				}
				procDates_e = procDatesBuffer_e.toString();
				billRounds_e = billRoundsBuffer_e.toString();
				holidayIndicators_e = holidayIndicatorBuffer_e.toString();
				billRoundsBuffer_e = null;
				procDatesBuffer_e = null;
				holidayIndicatorBuffer_e = null;
		    } else if(region.equals("MW")) {
		    	StringBuffer billRoundsBuffer_mw = new StringBuffer();
		    	StringBuffer procDatesBuffer_mw = new StringBuffer();
		    	StringBuffer holidayIndicatorBuffer_mw = new StringBuffer();
				while(rs.next()){
					MyDate procDate = new MyDate(rs.getDate(1));
					if("".equals(procDatesBuffer_mw)) {
						procDatesBuffer_mw.append(procDate.toString());
						billRoundsBuffer_mw.append(Integer.toString(rs.getInt(2)));
						holidayIndicatorBuffer_mw.append(rs.getString(3));
					} else {
						procDatesBuffer_mw.append("~");
						procDatesBuffer_mw.append(procDate.toString());
						
						billRoundsBuffer_mw.append("~");
						billRoundsBuffer_mw.append(Integer.toString(rs.getInt(2)));
						
						holidayIndicatorBuffer_mw.append("~");
						holidayIndicatorBuffer_mw.append(rs.getString(3));
					}
				}
				procDates_mw = procDatesBuffer_mw.toString();
				billRounds_mw = billRoundsBuffer_mw.toString();
				holidayIndicators_mw = holidayIndicatorBuffer_mw.toString();
				billRoundsBuffer_mw = null;
				procDatesBuffer_mw = null;
				holidayIndicatorBuffer_mw = null;
		    } else if(region.equals("SW")) {
		    	StringBuffer billRoundsBuffer_sw = new StringBuffer();
		    	StringBuffer procDatesBuffer_sw = new StringBuffer();
		    	StringBuffer holidayIndicatorBuffer_sw = new StringBuffer();
				while(rs.next()){
					MyDate procDate = new MyDate(rs.getDate(1));
					if("".equals(procDatesBuffer_sw)) {
						procDatesBuffer_sw.append(procDate.toString());
						billRoundsBuffer_sw.append(Integer.toString(rs.getInt(2)));
						holidayIndicatorBuffer_sw.append(rs.getString(3));
					} else {
						procDatesBuffer_sw.append("~");
						procDatesBuffer_sw.append(procDate.toString());
						
						billRoundsBuffer_sw.append("~");
						billRoundsBuffer_sw.append(Integer.toString(rs.getInt(2)));
						
						holidayIndicatorBuffer_sw.append("~");
						holidayIndicatorBuffer_sw.append(rs.getString(3));
					}
				}
				procDates_sw = procDatesBuffer_sw.toString();
				billRounds_sw = billRoundsBuffer_sw.toString();
				holidayIndicators_sw = holidayIndicatorBuffer_sw.toString();
				billRoundsBuffer_sw = null;
				procDatesBuffer_sw = null;
				holidayIndicatorBuffer_sw = null;
		    } else if(region.equals("C2")) {
		    	StringBuffer billRoundsBuffer_c2 = new StringBuffer();
		    	StringBuffer procDatesBuffer_c2 = new StringBuffer();
		    	StringBuffer holidayIndicatorBuffer_c2 = new StringBuffer();
				while(rs.next()){
					MyDate procDate = new MyDate(rs.getDate(1));
					if("".equals(procDatesBuffer_c2)) {
						procDatesBuffer_c2.append(procDate.toString());
						billRoundsBuffer_c2.append(Integer.toString(rs.getInt(2)));
						holidayIndicatorBuffer_c2.append(rs.getString(3));
					} else {
						procDatesBuffer_c2.append("~");
						procDatesBuffer_c2.append(procDate.toString());
						
						billRoundsBuffer_c2.append("~");
						billRoundsBuffer_c2.append(Integer.toString(rs.getInt(2)));
						
						holidayIndicatorBuffer_c2.append("~");
						holidayIndicatorBuffer_c2.append(rs.getString(3));
					}
				}
				procDates_c2 = procDatesBuffer_c2.toString();
				billRounds_c2 = billRoundsBuffer_c2.toString();
				holidayIndicators_c2 = holidayIndicatorBuffer_c2.toString();
				billRoundsBuffer_c2 = null;
				procDatesBuffer_c2 = null;
				holidayIndicatorBuffer_c2 = null;
		    } else if(region.equals("SE")) {
		    	StringBuffer billRoundsBuffer_se = new StringBuffer();
		    	StringBuffer procDatesBuffer_se = new StringBuffer();
		    	StringBuffer holidayIndicatorBuffer_se = new StringBuffer();
				while(rs.next()){
					MyDate procDate = new MyDate(rs.getDate(1));
					if("".equals(procDatesBuffer_se)) {
						procDatesBuffer_se.append(procDate.toString());
						billRoundsBuffer_se.append(Integer.toString(rs.getInt(2)));
						holidayIndicatorBuffer_se.append(rs.getString(3));
					} else {
						procDatesBuffer_se.append("~");
						procDatesBuffer_se.append(procDate.toString());
						
						billRoundsBuffer_se.append("~");
						billRoundsBuffer_se.append(Integer.toString(rs.getInt(2)));
						
						holidayIndicatorBuffer_se.append("~");
						holidayIndicatorBuffer_se.append(rs.getString(3));
					}
				}
				procDates_se = procDatesBuffer_se.toString();
				billRounds_se = billRoundsBuffer_se.toString();
				holidayIndicators_se = holidayIndicatorBuffer_se.toString();
				billRoundsBuffer_se = null;
				procDatesBuffer_se = null;
				holidayIndicatorBuffer_se = null;	
		    } else if(region.equals("MB")) {
		    	StringBuffer billRoundsBuffer_mb = new StringBuffer();
		    	StringBuffer procDatesBuffer_mb = new StringBuffer();
		    	StringBuffer holidayIndicatorBuffer_mb = new StringBuffer();
				while(rs.next()){
					MyDate procDate = new MyDate(rs.getDate(1));
					if("".equals(procDatesBuffer_mb)) {
						procDatesBuffer_mb.append(procDate.toString());
						billRoundsBuffer_mb.append(Integer.toString(rs.getInt(2)));
						holidayIndicatorBuffer_mb.append(rs.getString(3));
					} else {
						procDatesBuffer_mb.append("~");
						procDatesBuffer_mb.append(procDate.toString());
						
						billRoundsBuffer_mb.append("~");
						billRoundsBuffer_mb.append(Integer.toString(rs.getInt(2)));
						
						holidayIndicatorBuffer_mb.append("~");
						holidayIndicatorBuffer_mb.append(rs.getString(3));
					}
				}
				procDates_mb = procDatesBuffer_mb.toString();
				billRounds_mb = billRoundsBuffer_mb.toString();
				holidayIndicators_mb = holidayIndicatorBuffer_mb.toString();
				billRoundsBuffer_mb = null;
				procDatesBuffer_mb = null;
				holidayIndicatorBuffer_mb = null;
		    }else {
		        throw new IllegalArgumentException("Unrecognized region: " + region);
		    }
		} catch(SQLException sqle) {
			logger.error("SQLException: ", sqle);
			throw sqle;
		} finally {
			try {
				if (rs != null)
					rs.close();
			} catch(SQLException sqle) {
				logger.error("SQLException in closing result set: ", sqle);
				throw sqle;
			} finally {
				rs = null;
			}
			try {
				if (stmt != null)
					stmt.close();
			} catch(SQLException sqle) {
				logger.error("SQLException in closing statement: ", sqle);
				throw sqle;
			} finally {
				stmt = null;
			}
		}
	}
	
	
	/**
	 * Loads the proc date for which data is available based on the bill_mm, bill_year
	 * and bill_rnd in the RABC_ACCT_BLG_DTL table and the proc_dt in RABC_CYCLE_CALENDAR 
	 * view
	 */		
	private void loadDataDates(Connection conn, String region) throws SQLException {
		Statement stmt = null;
		ResultSet rs = null;
		StringBuffer loadedDataDatesBuffer = new StringBuffer();
		try{
			if(region.equals("C2")) {
				stmt = conn.createStatement();
				rs = stmt.executeQuery(StaticDataLoader.QRY_GET_LOADED_BILLROUND);
				while(rs.next()){
					MyDate procDate = new MyDate(rs.getDate(1));
					if(loadedDataDatesBuffer.length()==0) {
						loadedDataDatesBuffer.append(procDate.toString());
					} else {
						loadedDataDatesBuffer.append("~");
						loadedDataDatesBuffer.append(procDate.toString());
					}
				}
				loadedDataDates_c2 = loadedDataDatesBuffer.toString();
		    }
		} catch(SQLException sqle) {
			logger.error("SQLException: ", sqle);
			throw sqle;
		} finally {
			try {
				if (rs != null)
					rs.close();
			} catch(SQLException sqle) {
				logger.error("SQLException in closing result set: ", sqle);
				throw sqle;
			} finally {
				rs = null;
			}
			try {
				if (stmt != null)
					stmt.close();
			} catch(SQLException sqle) {
				logger.error("SQLException in closing statement: ", sqle);
				throw sqle;
			} finally {
				stmt = null;
			}
		}
	}
	
	
	//The following methods read the in-memory objects loaded above
	
	/**
	 * @param region
	 * @return ArrayList of PickList objects
	 * Called method that hides getting the StaticDataLoader object.
	 */
	public static ArrayList getDivisionsByRegion(String region) throws IllegalArgumentException {
		ArrayList list = new ArrayList();
		if(region.trim().equals("WE")){
			return getRef(region).getDivisionsByRegion_w(list, region);
        } else if(region.trim().equals("E")){
        	return getRef(region).getDivisionsByRegion_e(list, region);
        } else if(region.trim().equals("MW")){
        	return getRef(region).getDivisionsByRegion_mw(list, region);
        } else if(region.trim().equals("SW")){
        	return getRef(region).getDivisionsByRegion_sw(list, region);
        } else if(region.trim().equals("C2")){
        	return getRef(region).getDivisionsByRegion_c2(list, region);
        } else if(region.trim().equals("SE")){
        	return getRef(region).getDivisionsByRegion_se(list, region);	
        } else if(region.trim().equals("EN")){
        	return getRef(region).getDivisionsByRegion_ent(list, region);
        } else if(region.trim().equals("MB")){
        	return getRef(region).getDivisionsByRegion_mb(list, region);
        }else {
            throw new IllegalArgumentException("Unrecognized region: " + region);
        }
	}

	/**
	 * @param list
	 * @param region
	 * @return ArrayList of PickList objects, 
	 * where for each PickList, key = division, value1 = division desc
	 * Underlying table: RABC_DIVISION
	 */
	private ArrayList getDivisionsByRegion_w(ArrayList list, String region) {
		for (int i=0; i<divisionList_w.size(); i++){
			PickList pickList = (PickList)divisionList_w.get(i);
			String key = pickList.getKey();
			if (key.substring(0,key.indexOf(":")).equalsIgnoreCase(region)){
				list.add(new PickList(key.substring(key.lastIndexOf(":")+1,key.length()),pickList.getValue1()));
			}
		}
		return list;				
	}
	
	/**
	 * @param list
	 * @param region
	 * @return ArrayList of PickList objects, 
	 * where for each PickList, key = division, value1 = division desc
	 * Underlying table: RABC_DIVISION
	 */
	private ArrayList getDivisionsByRegion_e(ArrayList list, String region) {
		for (int i=0; i<divisionList_e.size(); i++){
			PickList pickList = (PickList)divisionList_e.get(i);
			String key = pickList.getKey();
			if (key.substring(0,key.indexOf(":")).equalsIgnoreCase(region)){
				list.add(new PickList(key.substring(key.lastIndexOf(":")+1,key.length()),pickList.getValue1()));
			}
		}
		return list;				
	}
	
	/**
	 * @param list
	 * @param region
	 * @return ArrayList of PickList objects, 
	 * where for each PickList, key = division, value1 = division desc
	 * Underlying table: RABC_DIVISION
	 */
	private ArrayList getDivisionsByRegion_mw(ArrayList list, String region) {
		for (int i=0; i<divisionList_mw.size(); i++){
			PickList pickList = (PickList)divisionList_mw.get(i);
			String key = pickList.getKey();
			if (key.substring(0,key.indexOf(":")).equalsIgnoreCase(region)){
				list.add(new PickList(key.substring(key.lastIndexOf(":")+1,key.length()),pickList.getValue1()));
			}
		}
		return list;				
	}
	
	/**
	 * @param list
	 * @param region
	 * @return ArrayList of PickList objects, 
	 * where for each PickList, key = division, value1 = division desc
	 * Underlying table: RABC_DIVISION
	 */
	private ArrayList getDivisionsByRegion_sw(ArrayList list, String region) {
		for (int i=0; i<divisionList_sw.size(); i++){
			PickList pickList = (PickList)divisionList_sw.get(i);
			String key = pickList.getKey();
			if (key.substring(0,key.indexOf(":")).equalsIgnoreCase(region)){
				list.add(new PickList(key.substring(key.lastIndexOf(":")+1,key.length()),pickList.getValue1()));
			}
		}
		return list;				
	}

	/**
	 * @param list
	 * @param region
	 * @return ArrayList of PickList objects, 
	 * where for each PickList, key = division, value1 = division desc
	 * Underlying table: RABC_DIVISION
	 */
	private ArrayList getDivisionsByRegion_mb(ArrayList list, String region) {
		for (int i=0; i<divisionList_mb.size(); i++){
			PickList pickList = (PickList)divisionList_mb.get(i);
			String key = pickList.getKey();
			if (key.substring(0,key.indexOf(":")).equalsIgnoreCase(region)){
				list.add(new PickList(key.substring(key.lastIndexOf(":")+1,key.length()),pickList.getValue1()));
			}
		}
		return list;				
	}	
     /**
	 * @param list
	 * @param region
	 * @return ArrayList of PickList objects, 
	 * where for each PickList, key = division, value1 = division desc
	 * Underlying table: RABC_DIVISION
	 */
	private ArrayList getDivisionsByRegion_ent(ArrayList list, String region) {
		for (int i=0; i<divisionList_ent.size(); i++){
			PickList pickList = (PickList)divisionList_ent.get(i);
			String key = pickList.getKey();
			
			if ("EN".equals(region)){
				list.add(new PickList(key.substring(key.lastIndexOf(":")+1,key.length()),pickList.getValue1()));
			} else {
				if (key.substring(0,key.indexOf(":")).equalsIgnoreCase(region)){
					list.add(new PickList(key.substring(key.lastIndexOf(":")+1,key.length()),pickList.getValue1()));
				}
			}
		}
		return list;				
	}
	
	/**
	 * @param list
	 * @param region
	 * @return ArrayList of PickList objects, 
	 * where for each PickList, key = division, value1 = division desc
	 * Underlying table: RABC_DIVISION
	 */
	private ArrayList getDivisionsByRegion_c2(ArrayList list, String region) {
		for (int i=0; i<divisionList_c2.size(); i++){
			PickList pickList = (PickList)divisionList_c2.get(i);
			String key = pickList.getKey();
			if (key.substring(0,key.indexOf(":")).equalsIgnoreCase(region)){
				list.add(new PickList(key.substring(key.lastIndexOf(":")+1,key.length()),pickList.getValue1()));
			}
		}
		return list;				
	}
	/**
	 * @param list
	 * @param region
	 * @return ArrayList of PickList objects, 
	 * where for each PickList, key = division, value1 = division desc
	 * Underlying table: RABC_DIVISION
	 */
	private ArrayList getDivisionsByRegion_se(ArrayList list, String region) {
		for (int i=0; i<divisionList_se.size(); i++){
			PickList pickList = (PickList)divisionList_se.get(i);
			String key = pickList.getKey();
			if (key.substring(0,key.indexOf(":")).equalsIgnoreCase(region)){
				list.add(new PickList(key.substring(key.lastIndexOf(":")+1,key.length()),pickList.getValue1()));
			}
		}
		return list;				
	}
	
		/**
	 * @param region
	 * @return ArrayList of PickList objects
	 * Called method that hides getting the StaticDataLoader object.
	 */
	public static ArrayList getStatesByRegion(String region) throws IllegalArgumentException {
		ArrayList list = new ArrayList();
		if(region.trim().equals("WE")){
			return getRef(region).getStatesByRegion_w(list, region);
        } else if(region.trim().equals("E")){
        	return getRef(region).getStatesByRegion_e(list, region);
        } else if(region.trim().equals("MW")){
        	return getRef(region).getStatesByRegion_mw(list, region);
        } else if(region.trim().equals("SW")){
        	return getRef(region).getStatesByRegion_sw(list, region);
        } else if(region.trim().equals("SE")){
        	return getRef(region).getStatesByRegion_se(list, region);	
        } else if(region.trim().equals("MB")){
        	return getRef(region).getStatesByRegion_mb(list, region);	
        } else {
            throw new IllegalArgumentException("Unrecognized region: " + region);
        }
	}
	
	/**
	 * @param list
	 * @param region
	 * @return ArrayList of String objects, each String is a State for that region
	 * Underlying table: RABC_DIVISION
	 */
	private ArrayList getStatesByRegion_w(ArrayList list, String region) {
		for (int i=0; i<divisionList_w.size(); i++){
			PickList pickList = (PickList)divisionList_w.get(i);
			String key = pickList.getKey();
			if (key.substring(0,key.indexOf(":")).equalsIgnoreCase(region)){
				String afterRegion = key.substring(key.indexOf(":")+1,key.length());
				String state = afterRegion.substring(0,key.indexOf(":"));
				if (!list.contains(state)){
					list.add(state);
				}
			}
		}
		return list;				
	}
	
	/**
	 * @param list
	 * @param region
	 * @return ArrayList of String objects, each String is a State for that region
	 * Underlying table: RABC_DIVISION
	 */
	private ArrayList getStatesByRegion_e(ArrayList list, String region) {
		for (int i=0; i<divisionList_e.size(); i++){
			PickList pickList = (PickList)divisionList_e.get(i);
			String key = pickList.getKey();
			if (key.substring(0,key.indexOf(":")).equalsIgnoreCase(region)){
				String afterRegion = key.substring(key.indexOf(":")+1,key.length());
				String state = afterRegion.substring(0,key.indexOf(":"));
				if (!list.contains(state)){
					list.add(state);
				}
			}
		}
		return list;				
	}
	
	/**
	 * @param list
	 * @param region
	 * @return ArrayList of String objects, each String is a State for that region
	 * Underlying table: RABC_DIVISION
	 */
	private ArrayList getStatesByRegion_mw(ArrayList list, String region) {
		for (int i=0; i<divisionList_mw.size(); i++){
			PickList pickList = (PickList)divisionList_mw.get(i);
			String key = pickList.getKey();
			if (key.substring(0,key.indexOf(":")).equalsIgnoreCase(region)){
				String afterRegion = key.substring(key.indexOf(":")+1,key.length());
				String state = afterRegion.substring(0,key.indexOf(":"));
				if (!list.contains(state)){
					list.add(state);
				}
			}
		}
		return list;				
	}
	
	/**
	 * @param list
	 * @param region
	 * @return ArrayList of String objects, each String is a State for that region
	 * Underlying table: RABC_DIVISION
	 */
	private ArrayList getStatesByRegion_sw(ArrayList list, String region) {
		for (int i=0; i<divisionList_sw.size(); i++){
			PickList pickList = (PickList)divisionList_sw.get(i);
			String key = pickList.getKey();
			if (key.substring(0,key.indexOf(":")).equalsIgnoreCase(region)){
				String afterRegion = key.substring(key.indexOf(":")+1,key.length());
				String state = afterRegion.substring(0,key.indexOf(":"));
				if (!list.contains(state)){
					list.add(state);
				}
			}
		}
		return list;				
	}
	
	/**
	 * @param list
	 * @param region
	 * @return ArrayList of String objects, each String is a State for that region
	 * Underlying table: RABC_DIVISION
	 */
	private ArrayList getStatesByRegion_se(ArrayList list, String region) {
		for (int i=0; i<divisionList_se.size(); i++){
			PickList pickList = (PickList)divisionList_se.get(i);
			String key = pickList.getKey();
			if (key.substring(0,key.indexOf(":")).equalsIgnoreCase(region)){
				String afterRegion = key.substring(key.indexOf(":")+1,key.length());
				String state = afterRegion.substring(0,key.indexOf(":"));
				if (!list.contains(state)){
					list.add(state);
				}
			}
		}
		return list;				
	}
	
	/**
	 * @param list
	 * @param region
	 * @return ArrayList of String objects, each String is a State for that region
	 * Underlying table: RABC_DIVISION
	 */
	private ArrayList getStatesByRegion_mb(ArrayList list, String region) {
		for (int i=0; i<divisionList_mb.size(); i++){
			PickList pickList = (PickList)divisionList_mb.get(i);
			String key = pickList.getKey();
			if (key.substring(0,key.indexOf(":")).equalsIgnoreCase(region)){
				String afterRegion = key.substring(key.indexOf(":")+1,key.length());
				String state = afterRegion.substring(0,key.indexOf(":"));
				if (!list.contains(state)){
					list.add(state);
				}
			}
		}
		return list;				
	}
	
	/**
	 * @param region
	 * @param division
	 * @return division description 
	 * Called method that hides getting the StaticDataLoader object.
	 */
	public static String getDivisionDesc(String region, String division) throws IllegalArgumentException {
		if(region.trim().equals("WE")){
			return getRef(region).getDivisionDesc_w(region, division);
        } else if(region.trim().equals("E")){
        	return getRef(region).getDivisionDesc_e(region, division);
        } else if(region.trim().equals("MW")){
        	return getRef(region).getDivisionDesc_mw(region, division);
        } else if(region.trim().equals("SW")){
        	return getRef(region).getDivisionDesc_sw(region, division);
        } else if(region.trim().equals("C2")){
        	return getRef(region).getDivisionDesc_c2(region, division);
        } else if(region.trim().equals("SE")){
        	return getRef(region).getDivisionDesc_se(region, division);	
        } else if(region.trim().equals("EN")){
        	return getRef(region).getDivisionDesc_ent(region, division);
        } else if(region.trim().equals("MB")){
        	return getRef(region).getDivisionDesc_mb(region, division);
        } else {
            throw new IllegalArgumentException("Unrecognized region: " + region);
        }				
	}
	
	/**
	 * @param region
	 * @param division
	 * @return division description 
	 * Underlying table: RABC_DIVISION
	 */
	private String getDivisionDesc_ent(String region, String division) {
		String divisionDesc = "";
		for (int i=0; i<divisionList_ent.size(); i++){
			PickList pickList = (PickList)divisionList_ent.get(i);
			String key = pickList.getKey();
			if (key.substring(0,key.indexOf(":")).equalsIgnoreCase(region)
			&&  key.substring(key.lastIndexOf(":")+1,key.length()).equalsIgnoreCase(division)){
				divisionDesc = pickList.getValue1().trim();
			}
		}
		if (divisionDesc.equals("")){
			divisionDesc = division;
		}
		return divisionDesc;				
	}
	
	/**
	 * @param region
	 * @param division
	 * @return division description 
	 * Underlying table: RABC_DIVISION
	 */
	private String getDivisionDesc_w(String region, String division) {
		String divisionDesc = "";
		for (int i=0; i<divisionList_w.size(); i++){
			PickList pickList = (PickList)divisionList_w.get(i);
			String key = pickList.getKey();
			if (key.substring(0,key.indexOf(":")).equalsIgnoreCase(region)
			&&  key.substring(key.lastIndexOf(":")+1,key.length()).equalsIgnoreCase(division)){
				divisionDesc = pickList.getValue1().trim();
			}
		}
		if (divisionDesc.equals("")){
			divisionDesc = division;
		}
		return divisionDesc;				
	}
	
	/**
	 * @param region
	 * @param division
	 * @return division description 
	 * Underlying table: RABC_DIVISION
	 */
	private String getDivisionDesc_e(String region, String division) {
		String divisionDesc = "";
		for (int i=0; i<divisionList_e.size(); i++){
			PickList pickList = (PickList)divisionList_e.get(i);
			String key = pickList.getKey();
			if (key.substring(0,key.indexOf(":")).equalsIgnoreCase(region)
			&&  key.substring(key.lastIndexOf(":")+1,key.length()).equalsIgnoreCase(division)){
				divisionDesc = pickList.getValue1().trim();
			}
		}
		if (divisionDesc.equals("")){
			divisionDesc = division;
		}
		return divisionDesc;				
	}
	
	/**
	 * @param region
	 * @param division
	 * @return division description 
	 * Underlying table: RABC_DIVISION
	 */
	private String getDivisionDesc_mw(String region, String division) {
		String divisionDesc = "";
		for (int i=0; i<divisionList_mw.size(); i++){
			PickList pickList = (PickList)divisionList_mw.get(i);
			String key = pickList.getKey();
			if (key.substring(0,key.indexOf(":")).equalsIgnoreCase(region)
			&&  key.substring(key.lastIndexOf(":")+1,key.length()).equalsIgnoreCase(division)){
				divisionDesc = pickList.getValue1().trim();
			}
		}
		if (divisionDesc.equals("")){
			divisionDesc = division;
		}
		return divisionDesc;				
	}
	
	/**
	 * @param region
	 * @param division
	 * @return division description 
	 * Underlying table: RABC_DIVISION
	 */
	private String getDivisionDesc_sw(String region, String division) {
		String divisionDesc = "";
		for (int i=0; i<divisionList_sw.size(); i++){
			PickList pickList = (PickList)divisionList_sw.get(i);
			String key = pickList.getKey();
			if (key.substring(0,key.indexOf(":")).equalsIgnoreCase(region)
			&&  key.substring(key.lastIndexOf(":")+1,key.length()).equalsIgnoreCase(division)){
				divisionDesc = pickList.getValue1().trim();
			}
		}
		if (divisionDesc.equals("")){
			divisionDesc = division;
		}
		return divisionDesc;				
	}
	
	/**
	 * @param region
	 * @param division
	 * @return division description 
	 * Underlying table: RABC_DIVISION
	 */
	private String getDivisionDesc_c2(String region, String division) {
		String divisionDesc = "";
		for (int i=0; i<divisionList_c2.size(); i++){
			PickList pickList = (PickList)divisionList_c2.get(i);
			String key = pickList.getKey();
			if (key.substring(0,key.indexOf(":")).equalsIgnoreCase(region)
			&&  key.substring(key.lastIndexOf(":")+1,key.length()).equalsIgnoreCase(division)){
				divisionDesc = pickList.getValue1().trim();
			}
		}
		if (divisionDesc.equals("")){
			divisionDesc = division;
		}
		return divisionDesc;				
	}
	
	/**
	 * @param region
	 * @param division
	 * @return division description 
	 * Underlying table: RABC_DIVISION
	 */
	private String getDivisionDesc_se(String region, String division) {
		String divisionDesc = "";
		for (int i=0; i<divisionList_se.size(); i++){
			PickList pickList = (PickList)divisionList_se.get(i);
			String key = pickList.getKey();
			if (key.substring(0,key.indexOf(":")).equalsIgnoreCase(region)
			&&  key.substring(key.lastIndexOf(":")+1,key.length()).equalsIgnoreCase(division)){
				divisionDesc = pickList.getValue1().trim();
			}
		}
		if (divisionDesc.equals("")){
			divisionDesc = division;
		}
		return divisionDesc;				
	}
	
	/**
	 * @param region
	 * @param division
	 * @return division description 
	 * Underlying table: RABC_DIVISION
	 */
	private String getDivisionDesc_mb(String region, String division) {
		String divisionDesc = "";
		for (int i=0; i<divisionList_mb.size(); i++){
			PickList pickList = (PickList)divisionList_mb.get(i);
			String key = pickList.getKey();
			if (key.substring(0,key.indexOf(":")).equalsIgnoreCase(region)
			&&  key.substring(key.lastIndexOf(":")+1,key.length()).equalsIgnoreCase(division)){
				divisionDesc = pickList.getValue1().trim();
			}
		}
		if (divisionDesc.equals("")){
			divisionDesc = division;
		}
		return divisionDesc;				
	}
	/**
	 * @param region
	 * @return ArrayList of PickList objects
	 * Called method that hides getting the StaticDataLoader object.
	 */
	public static ArrayList getFileMashList(String region) throws IllegalArgumentException {
		if(region.trim().equals("WE")){
			return getRef(region).getFileMashList_w();
        } else if(region.trim().equals("E")){
        	return getRef(region).getFileMashList_e();
        } else if(region.trim().equals("MW")){
        	return getRef(region).getFileMashList_mw();
        } else if(region.trim().equals("SW")){
        	return getRef(region).getFileMashList_sw();
        } else if(region.trim().equals("C2")){
        	return getRef(region).getFileMashList_c2();
        } else if(region.trim().equals("SE")){
        	return getRef(region).getFileMashList_se();	
        } else if(region.trim().equals("MB")){
        	return getRef(region).getFileMashList_mb();	
        } else {
            throw new IllegalArgumentException("Unrecognized region: " + region);
        }
	}
	
	/**
	 * @return ArrayList of PickList objects, where
	 * for each PickList, key = table name, value1 = file ID and value2 = file mash
	 * Underlying table: RABC_FILE_MASH
	 */
	private ArrayList getFileMashList_w() {
		return fileMashList_w;
	}
	
	/**
	 * @return ArrayList of PickList objects, where
	 * for each PickList, key = table name, value1 = file ID and value2 = file mash
	 * Underlying table: RABC_FILE_MASH
	 */
	private ArrayList getFileMashList_e() {
		return fileMashList_e;
	}
	
	/**
	 * @return ArrayList of PickList objects, where
	 * for each PickList, key = table name, value1 = file ID and value2 = file mash
	 * Underlying table: RABC_FILE_MASH
	 */
	private ArrayList getFileMashList_sw() {
		return fileMashList_sw;
	}
	
	/**
	 * @return ArrayList of PickList objects, where
	 * for each PickList, key = table name, value1 = file ID and value2 = file mash
	 * Underlying table: RABC_FILE_MASH
	 */
	private ArrayList getFileMashList_mb() {
		return fileMashList_mb;
	}
	/**
	 * @return ArrayList of PickList objects, where
	 * for each PickList, key = table name, value1 = file ID and value2 = file mash
	 * Underlying table: RABC_FILE_MASH
	 */
	private ArrayList getFileMashList_mw() {
		return fileMashList_mw;
	}
	
	/**
	 * @return ArrayList of PickList objects, where
	 * for each PickList, key = table name, value1 = file ID and value2 = file mash
	 * Underlying table: RABC_FILE_MASH
	 */
	private ArrayList getFileMashList_c2() {
		return fileMashList_c2;
	}
	
	/**
	 * @return ArrayList of PickList objects, where
	 * for each PickList, key = table name, value1 = file ID and value2 = file mash
	 * Underlying table: RABC_FILE_MASH
	 */
	private ArrayList getFileMashList_se() {
		return fileMashList_se;
	}
	
	/**
	 * @param tableName
	 * @param region
	 * @return ArrayList of PickList objects
	 * Called method that hides getting the StaticDataLoader object.
	 */
	public static ArrayList getFileMashByTableName(String tableName, String region) throws IllegalArgumentException {
		ArrayList list = new ArrayList();
		if(region.trim().equals("WE")){
			return getRef(region).getFileMashByTableName_w(list, tableName);
        } else if(region.trim().equals("E")){
        	return getRef(region).getFileMashByTableName_e(list, tableName);
        } else if(region.trim().equals("MW")){
        	return getRef(region).getFileMashByTableName_mw(list, tableName);
        } else if(region.trim().equals("SW")){
        	return getRef(region).getFileMashByTableName_sw(list, tableName);
        } else if(region.trim().equals("C2")){
        	return getRef(region).getFileMashByTableName_c2(list, tableName);
        } else if(region.trim().equals("SE")){
        	return getRef(region).getFileMashByTableName_se(list, tableName);	
        } else if(region.trim().equals("MB")){
        	return getRef(region).getFileMashByTableName_mb(list, tableName);	
        } else {
            throw new IllegalArgumentException("Unrecognized region: " + region);
        }
	}
	
	/**
	 * @param list
	 * @param tableName
	 * @return ArrayList of PickList objects, where 
	 * for each PickList, key = file ID, value1 = file mash
	 * Underlying table: RABC_FILE_MASH
	 */
	private ArrayList getFileMashByTableName_w(ArrayList list, String tableName) {
		for (int i=0; i<fileMashList_w.size(); i++){
			PickList pickList = (PickList)fileMashList_w.get(i);
			if (pickList.getKey().equalsIgnoreCase(tableName)){
				list.add(new PickList(pickList.getValue1(),pickList.getValue2()));
			}
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param tableName
	 * @return ArrayList of PickList objects, where 
	 * for each PickList, key = file ID, value1 = file mash
	 * Underlying table: RABC_FILE_MASH
	 */
	private ArrayList getFileMashByTableName_e(ArrayList list, String tableName) {
		for (int i=0; i<fileMashList_e.size(); i++){
			PickList pickList = (PickList)fileMashList_e.get(i);
			if (pickList.getKey().equalsIgnoreCase(tableName)){
				list.add(new PickList(pickList.getValue1(),pickList.getValue2()));
			}
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param tableName
	 * @return ArrayList of PickList objects, where 
	 * for each PickList, key = file ID, value1 = file mash
	 * Underlying table: RABC_FILE_MASH
	 */
	private ArrayList getFileMashByTableName_mw(ArrayList list, String tableName) {
		for (int i=0; i<fileMashList_mw.size(); i++){
			PickList pickList = (PickList)fileMashList_mw.get(i);
			if (pickList.getKey().equalsIgnoreCase(tableName)){
				list.add(new PickList(pickList.getValue1(),pickList.getValue2()));
			}
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param tableName
	 * @return ArrayList of PickList objects, where 
	 * for each PickList, key = file ID, value1 = file mash
	 * Underlying table: RABC_FILE_MASH
	 */
	private ArrayList getFileMashByTableName_sw(ArrayList list, String tableName) {
		for (int i=0; i<fileMashList_sw.size(); i++){
			PickList pickList = (PickList)fileMashList_sw.get(i);
			if (pickList.getKey().equalsIgnoreCase(tableName)){
				list.add(new PickList(pickList.getValue1(),pickList.getValue2()));
			}
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param tableName
	 * @return ArrayList of PickList objects, where 
	 * for each PickList, key = file ID, value1 = file mash
	 * Underlying table: RABC_FILE_MASH
	 */
	private ArrayList getFileMashByTableName_c2(ArrayList list, String tableName) {
		for (int i=0; i<fileMashList_c2.size(); i++){
			PickList pickList = (PickList)fileMashList_c2.get(i);
			if (pickList.getKey().equalsIgnoreCase(tableName)){
				list.add(new PickList(pickList.getValue1(),pickList.getValue2()));
			}
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param tableName
	 * @return ArrayList of PickList objects, where 
	 * for each PickList, key = file ID, value1 = file mash
	 * Underlying table: RABC_FILE_MASH
	 */
	private ArrayList getFileMashByTableName_se(ArrayList list, String tableName) {
		for (int i=0; i<fileMashList_se.size(); i++){
			PickList pickList = (PickList)fileMashList_se.get(i);
			if (pickList.getKey().equalsIgnoreCase(tableName)){
				list.add(new PickList(pickList.getValue1(),pickList.getValue2()));
			}
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param tableName
	 * @return ArrayList of PickList objects, where 
	 * for each PickList, key = file ID, value1 = file mash
	 * Underlying table: RABC_FILE_MASH
	 */
	private ArrayList getFileMashByTableName_mb(ArrayList list, String tableName) {
		for (int i=0; i<fileMashList_mb.size(); i++){
			PickList pickList = (PickList)fileMashList_mb.get(i);
			if (pickList.getKey().equalsIgnoreCase(tableName)){
				list.add(new PickList(pickList.getValue1(),pickList.getValue2()));
			}
		}
		return list;
	}
	
	/**
	 * @param region
	 * @return ArrayList of PickList objects
	 * Called method that hides getting the StaticDataLoader object.
	 */
	public static ArrayList getDBNodeList(String region){
		if(region.trim().equals("WE")){
			return getRef(region).getDBNodeList_w();
        } else if(region.trim().equals("E")){
        	return getRef(region).getDBNodeList_e();
        } else if(region.trim().equals("MW")){
        	return getRef(region).getDBNodeList_mw();
        } else if(region.trim().equals("SW")){
        	return getRef(region).getDBNodeList_sw();
        } else if(region.trim().equals("C2")){
        	return getRef(region).getDBNodeList_c2();
        } else if(region.trim().equals("SE")){
        	return getRef(region).getDBNodeList_se();	
        } else if(region.trim().equals("EN")){
        	return getRef(region).getDBNodeList_ent();
        } else if(region.trim().equals("MB")){
        	return getRef(region).getDBNodeList_mb();
        } else {
            throw new IllegalArgumentException("Unrecognized region: "+region);
        }
	}
	
	/**
	 * @return ArrayList of PickList objects, where
	 * for each PickList, key = DB node ID, value1 = DB node and value2 = DB node description
	 * Underlying table: RABC_DB_NODE
	 */
	private ArrayList getDBNodeList_w(){
		return dbNodeList_w;
	}
	
	/**
	 * @return ArrayList of PickList objects, where
	 * for each PickList, key = DB node ID, value1 = DB node and value2 = DB node description
	 * Underlying table: RABC_DB_NODE
	 */
	private ArrayList getDBNodeList_e(){
		return dbNodeList_e;
	}
	
	/**
	 * @return ArrayList of PickList objects, where
	 * for each PickList, key = DB node ID, value1 = DB node and value2 = DB node description
	 * Underlying table: RABC_DB_NODE
	 */
	private ArrayList getDBNodeList_sw(){
		return dbNodeList_sw;
	}	
	
	/**
	 * @return ArrayList of PickList objects, where
	 * for each PickList, key = DB node ID, value1 = DB node and value2 = DB node description
	 * Underlying table: RABC_DB_NODE
	 */
	private ArrayList getDBNodeList_mb(){
		return dbNodeList_mb;
	}	
	
	/**
	 * @return ArrayList of PickList objects, where
	 * for each PickList, key = DB node ID, value1 = DB node and value2 = DB node description
	 * Underlying table: RABC_DB_NODE
	 */
	private ArrayList getDBNodeList_mw(){
		return dbNodeList_mw;
	}
	
	/**
	 * @return ArrayList of PickList objects, where
	 * for each PickList, key = DB node ID, value1 = DB node and value2 = DB node description
	 * Underlying table: RABC_DB_NODE
	 */
	private ArrayList getDBNodeList_c2(){
		return dbNodeList_c2;
	}
	
	/**
	 * @return ArrayList of PickList objects, where
	 * for each PickList, key = DB node ID, value1 = DB node and value2 = DB node description
	 * Underlying table: RABC_DB_NODE
	 */
	private ArrayList getDBNodeList_se(){
		return dbNodeList_se;
	}
	
	/**
	 * @return ArrayList of PickList objects, where
	 * for each PickList, key = DB node ID, value1 = DB node and value2 = DB node description
	 * Underlying table: RABC_DB_NODE
	 */
	private ArrayList getDBNodeList_ent(){
		return dbNodeList_ent;
	}
	
	/**
	 * @param dbNodeID
	 * @param region
	 * @return ArrayList of PickList objects
	 * Called method that hides getting the StaticDataLoader object.
	 */
	public static ArrayList getDBNodeByID(String dbNodeID, String region) throws IllegalArgumentException {
		ArrayList list = new ArrayList();
		if(region.trim().equals("WE")){
			return getRef(region).getDBNodeByID_w(list, dbNodeID);
        } else if(region.trim().equals("E")){
        	return getRef(region).getDBNodeByID_e(list, dbNodeID);
        } else if(region.trim().equals("MW")){
        	return getRef(region).getDBNodeByID_mw(list, dbNodeID);
        } else if(region.trim().equals("SW")){
        	return getRef(region).getDBNodeByID_sw(list, dbNodeID);
        } else if(region.trim().equals("C2")){
        	return getRef(region).getDBNodeByID_c2(list, dbNodeID);
        } else if(region.trim().equals("SE")){
        	return getRef(region).getDBNodeByID_se(list, dbNodeID);	
        } else if(region.trim().equals("EN")){
        	return getRef(region).getDBNodeByID_ent(list, dbNodeID);
        } else if(region.trim().equals("MB")){
        	return getRef(region).getDBNodeByID_mb(list, dbNodeID);
        } else {
            throw new IllegalArgumentException("Unrecognized region: " + region);
        }
	}	

	/**
	 * @param list
	 * @param dbNodeID
	 * @return ArrayList of PickList objects, where 
	 * for each PickList, key = DB node, value1 = DB node description
	 * Underlying table: RABC_DB_NODE
	 */
	private ArrayList getDBNodeByID_mb(ArrayList list, String dbNodeID){
		for (int i=0; i<dbNodeList_mb.size(); i++){
			PickList pickList = (PickList)dbNodeList_mb.get(i);
			if (pickList.getKey().equalsIgnoreCase(dbNodeID)){
				list.add(new PickList(pickList.getValue1(),pickList.getValue2()));
			}
		}
		return list;
	}
	/**
	 * @param list
	 * @param dbNodeID
	 * @return ArrayList of PickList objects, where 
	 * for each PickList, key = DB node, value1 = DB node description
	 * Underlying table: RABC_DB_NODE
	 */
	private ArrayList getDBNodeByID_w(ArrayList list, String dbNodeID){
		for (int i=0; i<dbNodeList_w.size(); i++){
			PickList pickList = (PickList)dbNodeList_w.get(i);
			if (pickList.getKey().equalsIgnoreCase(dbNodeID)){
				list.add(new PickList(pickList.getValue1(),pickList.getValue2()));
			}
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param dbNodeID
	 * @return ArrayList of PickList objects, where 
	 * for each PickList, key = DB node, value1 = DB node description
	 * Underlying table: RABC_DB_NODE
	 */
	private ArrayList getDBNodeByID_e(ArrayList list, String dbNodeID){
		for (int i=0; i<dbNodeList_e.size(); i++){
			PickList pickList = (PickList)dbNodeList_e.get(i);
			if (pickList.getKey().equalsIgnoreCase(dbNodeID)){
				list.add(new PickList(pickList.getValue1(),pickList.getValue2()));
			}
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param dbNodeID
	 * @return ArrayList of PickList objects, where 
	 * for each PickList, key = DB node, value1 = DB node description
	 * Underlying table: RABC_DB_NODE
	 */
	private ArrayList getDBNodeByID_mw(ArrayList list, String dbNodeID){
		for (int i=0; i<dbNodeList_mw.size(); i++){
			PickList pickList = (PickList)dbNodeList_mw.get(i);
			if (pickList.getKey().equalsIgnoreCase(dbNodeID)){
				list.add(new PickList(pickList.getValue1(),pickList.getValue2()));
			}
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param dbNodeID
	 * @return ArrayList of PickList objects, where 
	 * for each PickList, key = DB node, value1 = DB node description
	 * Underlying table: RABC_DB_NODE
	 */
	private ArrayList getDBNodeByID_sw(ArrayList list, String dbNodeID){
		for (int i=0; i<dbNodeList_sw.size(); i++){
			PickList pickList = (PickList)dbNodeList_sw.get(i);
			if (pickList.getKey().equalsIgnoreCase(dbNodeID)){
				list.add(new PickList(pickList.getValue1(),pickList.getValue2()));
			}
		}
		return list;
	}
		
	/**
	 * @param list
	 * @param dbNodeID
	 * @return ArrayList of PickList objects, where 
	 * for each PickList, key = DB node, value1 = DB node description
	 * Underlying table: RABC_DB_NODE
	 */
	private ArrayList getDBNodeByID_c2(ArrayList list, String dbNodeID){
		for (int i=0; i<dbNodeList_c2.size(); i++){
			PickList pickList = (PickList)dbNodeList_c2.get(i);
			if (pickList.getKey().equalsIgnoreCase(dbNodeID)){
				list.add(new PickList(pickList.getValue1(),pickList.getValue2()));
			}
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param dbNodeID
	 * @return ArrayList of PickList objects, where 
	 * for each PickList, key = DB node, value1 = DB node description
	 * Underlying table: RABC_DB_NODE
	 */
	private ArrayList getDBNodeByID_se(ArrayList list, String dbNodeID){
		for (int i=0; i<dbNodeList_se.size(); i++){
			PickList pickList = (PickList)dbNodeList_se.get(i);
			if (pickList.getKey().equalsIgnoreCase(dbNodeID)){
				list.add(new PickList(pickList.getValue1(),pickList.getValue2()));
			}
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param dbNodeID
	 * @return ArrayList of PickList objects, where 
	 * for each PickList, key = DB node, value1 = DB node description
	 * Underlying table: RABC_DB_NODE
	 */
	private ArrayList getDBNodeByID_ent(ArrayList list, String dbNodeID){
		for (int i=0; i<dbNodeList_ent.size(); i++){
			PickList pickList = (PickList)dbNodeList_ent.get(i);
			if (pickList.getKey().equalsIgnoreCase(dbNodeID)){
				list.add(new PickList(pickList.getValue1(),pickList.getValue1()));
			}
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param dbNodeID
	 * @return ArrayList of PickList objects, where 
	 * for each PickList, key = DB node, value1 = DB node description
	 * Underlying table: RABC_DB_NODE
	 */
	public static String getDBNodeByRegion(String region) throws IllegalArgumentException {
		String dbNode = null;
		
		for (int i=0; i<getRef(region).dbNodeList_ent.size(); i++){
			PickList pickList = (PickList)getRef(region).dbNodeList_ent.get(i);
			if (pickList.getKey().equalsIgnoreCase(region)){
				dbNode = pickList.getValue1();
			}
		}
		return dbNode;
	}
	
	/**
	 * @param region
	 * @return ArrayList of PickList objects
	 * Called method that hides getting the StaticDataLoader object.
	 */
	public static ArrayList getCntrlPtList(String region){
		if(region.trim().equals("WE")){
			return getRef(region).getCntrlPtList_w();
        } else if(region.trim().equals("E")){
        	return getRef(region).getCntrlPtList_e();
        } else if(region.trim().equals("MW")){
        	return getRef(region).getCntrlPtList_mw();
        } else if(region.trim().equals("SW")){
        	return getRef(region).getCntrlPtList_sw();
        } else if(region.trim().equals("C2")){
        	return getRef(region).getCntrlPtList_c2();
        } else if(region.trim().equals("SE")){
        	return getRef(region).getCntrlPtList_se();	
        }else if(region.trim().equals("MB")){
        	return getRef(region).getCntrlPtList_mb();	
        }else {
            throw new IllegalArgumentException("Unrecognized region: "+region);
        }
	}
	
	/**
	 * @return ArrayList of PickList objects, where
	 * for each PickList, key = control point code, value1 = sequence number and value2 = control point desc
	 * Underlying table: RABC_CNTRL_PT_TRANS
	 */
	private ArrayList getCntrlPtList_mb(){
		return cntrlPtList_mb;
	}
	
	/**
	 * @return ArrayList of PickList objects, where
	 * for each PickList, key = control point code, value1 = sequence number and value2 = control point desc
	 * Underlying table: RABC_CNTRL_PT_TRANS
	 */
	private ArrayList getCntrlPtList_w(){
		return cntrlPtList_w;
	}	
	
	/**
	 * @return ArrayList of PickList objects, where
	 * for each PickList, key = control point code, value1 = sequence number and value2 = control point desc
	 * Underlying table: RABC_CNTRL_PT_TRANS
	 */
	private ArrayList getCntrlPtList_e(){
		return cntrlPtList_e;
	}
	
	/**
	 * @return ArrayList of PickList objects, where
	 * for each PickList, key = control point code, value1 = sequence number and value2 = control point desc
	 * Underlying table: RABC_CNTRL_PT_TRANS
	 */
	private ArrayList getCntrlPtList_sw(){
		return cntrlPtList_sw;
	}	
	
	/**
	 * @return ArrayList of PickList objects, where
	 * for each PickList, key = control point code, value1 = sequence number and value2 = control point desc
	 * Underlying table: RABC_CNTRL_PT_TRANS
	 */
	private ArrayList getCntrlPtList_mw(){
		return cntrlPtList_mw;
	}
	
	/**
	 * @return ArrayList of PickList objects, where
	 * for each PickList, key = control point code, value1 = sequence number and value2 = control point desc
	 * Underlying table: RABC_CNTRL_PT_TRANS
	 */
	private ArrayList getCntrlPtList_c2(){
		return cntrlPtList_c2;
	}
	
	/**
	 * @return ArrayList of PickList objects, where
	 * for each PickList, key = control point code, value1 = sequence number and value2 = control point desc
	 * Underlying table: RABC_CNTRL_PT_TRANS
	 */
	private ArrayList getCntrlPtList_se(){
		return cntrlPtList_se;
	}
	
	/**
	 * @param cntrlPtCode
	 * @param region
	 * @return ArrayList of PickList objects, where 
	 * Called method that hides getting the StaticDataLoader object.
	 */
	public static ArrayList getCntrlPtByCode(String cntrlPtCode, String region) throws IllegalArgumentException {
		ArrayList list = new ArrayList();
		if(region.trim().equals("WE")){
			return getRef(region).getCntrlPtByCode_w(list, cntrlPtCode);
        } else if(region.trim().equals("E")){
        	return getRef(region).getCntrlPtByCode_e(list, cntrlPtCode);
        } else if(region.trim().equals("MW")){
        	return getRef(region).getCntrlPtByCode_mw(list, cntrlPtCode);
        } else if(region.trim().equals("SW")){
        	return getRef(region).getCntrlPtByCode_sw(list, cntrlPtCode);
        } else if(region.trim().equals("C2")){
        	return getRef(region).getCntrlPtByCode_c2(list, cntrlPtCode);
        } else if(region.trim().equals("SE")){
        	return getRef(region).getCntrlPtByCode_se(list, cntrlPtCode);	
        }else if(region.trim().equals("MB")){
        	return getRef(region).getCntrlPtByCode_mb(list, cntrlPtCode);	
        }else {
            throw new IllegalArgumentException("Unrecognized region: " + region);
        }
	}	
	
	/**
	 * @param list
	 * @param cntrlPtCode
	 * @return ArrayList of PickList objects, where 
	 * for each PickList, key = sequence number, value1 = control point description
	 * Underlying table: RABC_CNTRL_PT_TRANS
	 */
	private ArrayList getCntrlPtByCode_mb(ArrayList list, String cntrlPtCode) {
		for (int i=0; i<cntrlPtList_mb.size(); i++){
			PickList pickList = (PickList)cntrlPtList_mb.get(i);
			if (pickList.getKey().equalsIgnoreCase(cntrlPtCode)){
				list.add(new PickList(pickList.getValue1(),pickList.getValue2()));
			}
		}
		return list;
	}
	/**
	 * @param list
	 * @param cntrlPtCode
	 * @return ArrayList of PickList objects, where 
	 * for each PickList, key = sequence number, value1 = control point description
	 * Underlying table: RABC_CNTRL_PT_TRANS
	 */
	private ArrayList getCntrlPtByCode_w(ArrayList list, String cntrlPtCode) {
		for (int i=0; i<cntrlPtList_w.size(); i++){
			PickList pickList = (PickList)cntrlPtList_w.get(i);
			if (pickList.getKey().equalsIgnoreCase(cntrlPtCode)){
				list.add(new PickList(pickList.getValue1(),pickList.getValue2()));
			}
		}
		return list;
	}	
	
	/**
	 * @param list
	 * @param cntrlPtCode
	 * @return ArrayList of PickList objects, where 
	 * for each PickList, key = sequence number, value1 = control point description
	 * Underlying table: RABC_CNTRL_PT_TRANS
	 */
	private ArrayList getCntrlPtByCode_e(ArrayList list, String cntrlPtCode) {
		for (int i=0; i<cntrlPtList_e.size(); i++){
			PickList pickList = (PickList)cntrlPtList_e.get(i);
			if (pickList.getKey().equalsIgnoreCase(cntrlPtCode)){
				list.add(new PickList(pickList.getValue1(),pickList.getValue2()));
			}
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param cntrlPtCode
	 * @return ArrayList of PickList objects, where 
	 * for each PickList, key = sequence number, value1 = control point description
	 * Underlying table: RABC_CNTRL_PT_TRANS
	 */
	private ArrayList getCntrlPtByCode_mw(ArrayList list, String cntrlPtCode) {
		for (int i=0; i<cntrlPtList_mw.size(); i++){
			PickList pickList = (PickList)cntrlPtList_mw.get(i);
			if (pickList.getKey().equalsIgnoreCase(cntrlPtCode)){
				list.add(new PickList(pickList.getValue1(),pickList.getValue2()));
			}
		}
		return list;
	}	
	
	/**
	 * @param list
	 * @param cntrlPtCode
	 * @return ArrayList of PickList objects, where 
	 * for each PickList, key = sequence number, value1 = control point description
	 * Underlying table: RABC_CNTRL_PT_TRANS
	 */
	private ArrayList getCntrlPtByCode_sw(ArrayList list, String cntrlPtCode) {
		for (int i=0; i<cntrlPtList_sw.size(); i++){
			PickList pickList = (PickList)cntrlPtList_sw.get(i);
			if (pickList.getKey().equalsIgnoreCase(cntrlPtCode)){
				list.add(new PickList(pickList.getValue1(),pickList.getValue2()));
			}
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param cntrlPtCode
	 * @return ArrayList of PickList objects, where 
	 * for each PickList, key = sequence number, value1 = control point description
	 * Underlying table: RABC_CNTRL_PT_TRANS
	 */
	private ArrayList getCntrlPtByCode_c2(ArrayList list, String cntrlPtCode) {
		for (int i=0; i<cntrlPtList_c2.size(); i++){
			PickList pickList = (PickList)cntrlPtList_c2.get(i);
			if (pickList.getKey().equalsIgnoreCase(cntrlPtCode)){
				list.add(new PickList(pickList.getValue1(),pickList.getValue2()));
			}
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param cntrlPtCode
	 * @return ArrayList of PickList objects, where 
	 * for each PickList, key = sequence number, value1 = control point description
	 * Underlying table: RABC_CNTRL_PT_TRANS
	 */
	private ArrayList getCntrlPtByCode_se(ArrayList list, String cntrlPtCode) {
		for (int i=0; i<cntrlPtList_se.size(); i++){
			PickList pickList = (PickList)cntrlPtList_se.get(i);
			if (pickList.getKey().equalsIgnoreCase(cntrlPtCode)){
				list.add(new PickList(pickList.getValue1(),pickList.getValue2()));
			}
		}
		return list;
	}
	
	/**
	 * @param tblSubsysId
	 * @param region
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Called method that hides getting the StaticDataLoader object.
	 */	
	public static ArrayList getDataTblDdlByTblSubsysId(String tblSubsysId, String region) throws IllegalArgumentException {
		ArrayList list = new ArrayList();
		if(region.trim().equals("WE")){
			return getRef(region).getDataTblDdlByTblSubsysId_w(list, tblSubsysId, region);
        } else if(region.trim().equals("E")){
        	return getRef(region).getDataTblDdlByTblSubsysId_e(list, tblSubsysId, region);
        } else if(region.trim().equals("MW")){
        	return getRef(region).getDataTblDdlByTblSubsysId_mw(list, tblSubsysId, region);
        } else if(region.trim().equals("SW")){
        	return getRef(region).getDataTblDdlByTblSubsysId_sw(list, tblSubsysId, region);
        } else if(region.trim().equals("C2")){
        	return getRef(region).getDataTblDdlByTblSubsysId_c2(list, tblSubsysId, region);
        } else if(region.trim().equals("SE")){
        	return getRef(region).getDataTblDdlByTblSubsysId_se(list, tblSubsysId, region);	
        }else if(region.trim().equals("MB")){
        	return getRef(region).getDataTblDdlByTblSubsysId_mb(list, tblSubsysId, region);
        } else {
            throw new IllegalArgumentException("Unrecognized region: " + region);
        }
	}	
	
	/**
	 * @param list
	 * @param tblSubsysId
	 * @param region
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */	
	private ArrayList getDataTblDdlByTblSubsysId_mb(ArrayList list, String tblSubsysId, String region){
		for (int i=0; i<dataTblList_mb.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_mb.get(i);
			if (dataTblDdlBean.getTblSubsysId().equalsIgnoreCase(tblSubsysId)){
				list.add(dataTblDdlBean);
			}
		}
		return list;		
	}
	
	/**
	 * @param list
	 * @param tblSubsysId
	 * @param region
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */	
	private ArrayList getDataTblDdlByTblSubsysId_w(ArrayList list, String tblSubsysId, String region){
		for (int i=0; i<dataTblList_w.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_w.get(i);
			if (dataTblDdlBean.getTblSubsysId().equalsIgnoreCase(tblSubsysId)){
				list.add(dataTblDdlBean);
			}
		}
		return list;		
	}	
	
	/**
	 * @param list
	 * @param tblSubsysId
	 * @param region
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */	
	private ArrayList getDataTblDdlByTblSubsysId_e(ArrayList list, String tblSubsysId, String region){
		for (int i=0; i<dataTblList_e.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_e.get(i);
			if (dataTblDdlBean.getTblSubsysId().equalsIgnoreCase(tblSubsysId)){
				list.add(dataTblDdlBean);
			}
		}
		return list;		
	}
	
	/**
	 * @param list
	 * @param tblSubsysId
	 * @param region
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */	
	private ArrayList getDataTblDdlByTblSubsysId_mw(ArrayList list, String tblSubsysId, String region){
		for (int i=0; i<dataTblList_mw.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_mw.get(i);
			if (dataTblDdlBean.getTblSubsysId().equalsIgnoreCase(tblSubsysId)){
				list.add(dataTblDdlBean);
			}
		}
		return list;		
	}	
	
	/**
	 * @param list
	 * @param tblSubsysId
	 * @param region
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */	
	private ArrayList getDataTblDdlByTblSubsysId_sw(ArrayList list, String tblSubsysId, String region){
		for (int i=0; i<dataTblList_sw.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_sw.get(i);
			if (dataTblDdlBean.getTblSubsysId().equalsIgnoreCase(tblSubsysId)){
				list.add(dataTblDdlBean);
			}
		}
		return list;		
	}
	
	/**
	 * @param list
	 * @param tblSubsysId
	 * @param region
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */	
	private ArrayList getDataTblDdlByTblSubsysId_c2(ArrayList list, String tblSubsysId, String region){
		for (int i=0; i<dataTblList_c2.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_c2.get(i);
			if (dataTblDdlBean.getTblSubsysId().equalsIgnoreCase(tblSubsysId)){
				list.add(dataTblDdlBean);
			}
		}
		return list;		
	}
	
	/**
	 * @param list
	 * @param tblSubsysId
	 * @param region
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */	
	private ArrayList getDataTblDdlByTblSubsysId_se(ArrayList list, String tblSubsysId, String region){
		for (int i=0; i<dataTblList_se.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_se.get(i);
			if (dataTblDdlBean.getTblSubsysId().equalsIgnoreCase(tblSubsysId)){
				list.add(dataTblDdlBean);
			}
		}
		return list;		
	}
	
	/**
	 * @param tblSubsysId
	 * @param alertProcTbl
	 * @param region
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Called method that hides getting the StaticDataLoader object.
	 */	
	public static ArrayList getDataTblDdlByAlertProcTbl(String tblSubsysId, String alertProcTbl, String region) throws IllegalArgumentException {
		ArrayList list = new ArrayList();
		if(region.trim().equals("WE")){
			return getRef(region).getDataTblDdlByAlertProcTbl_w(list, tblSubsysId, alertProcTbl);
        } else if(region.trim().equals("E")){
        	return getRef(region).getDataTblDdlByAlertProcTbl_e(list, tblSubsysId, alertProcTbl);
        } else if(region.trim().equals("MW")){
        	return getRef(region).getDataTblDdlByAlertProcTbl_mw(list, tblSubsysId, alertProcTbl);
        } else if(region.trim().equals("SW")){
        	return getRef(region).getDataTblDdlByAlertProcTbl_sw(list, tblSubsysId, alertProcTbl);
        } else if(region.trim().equals("C2")){
        	return getRef(region).getDataTblDdlByAlertProcTbl_c2(list, tblSubsysId, alertProcTbl);
        } else if(region.trim().equals("SE")){
        	return getRef(region).getDataTblDdlByAlertProcTbl_se(list, tblSubsysId, alertProcTbl);	
        }else if(region.trim().equals("MB")){
        	return getRef(region).getDataTblDdlByAlertProcTbl_mb(list, tblSubsysId, alertProcTbl);	
        }else {
            throw new IllegalArgumentException("Unrecognized region: " + region);
        }
	}
	
	/**
	 * @param list
	 * @param tblSubsysId
	 * @param alertProcTbl
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */	
	private ArrayList getDataTblDdlByAlertProcTbl_mb(ArrayList list, String tblSubsysId, String alertProcTbl) {
		for (int i=0; i<dataTblList_mb.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_mb.get(i);
			if (dataTblDdlBean.getTblSubsysId().equalsIgnoreCase(tblSubsysId) & dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl)){
				list.add(dataTblDdlBean);
			}			
		}
		return list;
	}
	
	
	/**
	 * @param list
	 * @param tblSubsysId
	 * @param alertProcTbl
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */	
	private ArrayList getDataTblDdlByAlertProcTbl_w(ArrayList list, String tblSubsysId, String alertProcTbl) {
		for (int i=0; i<dataTblList_w.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_w.get(i);
			if (dataTblDdlBean.getTblSubsysId().equalsIgnoreCase(tblSubsysId) & dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl)){
				list.add(dataTblDdlBean);
			}			
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param tblSubsysId
	 * @param alertProcTbl
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */	
	private ArrayList getDataTblDdlByAlertProcTbl_e(ArrayList list, String tblSubsysId, String alertProcTbl) {
		for (int i=0; i<dataTblList_e.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_e.get(i);
			if (dataTblDdlBean.getTblSubsysId().equalsIgnoreCase(tblSubsysId) & dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl)){
				list.add(dataTblDdlBean);
			}			
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param tblSubsysId
	 * @param alertProcTbl
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */	
	private ArrayList getDataTblDdlByAlertProcTbl_mw(ArrayList list, String tblSubsysId, String alertProcTbl) {
		for (int i=0; i<dataTblList_mw.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_mw.get(i);
			if (dataTblDdlBean.getTblSubsysId().equalsIgnoreCase(tblSubsysId) & dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl)){
				list.add(dataTblDdlBean);
			}			
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param tblSubsysId
	 * @param alertProcTbl
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */	
	private ArrayList getDataTblDdlByAlertProcTbl_sw(ArrayList list, String tblSubsysId, String alertProcTbl) {
		for (int i=0; i<dataTblList_sw.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_sw.get(i);
			if (dataTblDdlBean.getTblSubsysId().equalsIgnoreCase(tblSubsysId) & dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl)){
				list.add(dataTblDdlBean);
			}			
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param tblSubsysId
	 * @param alertProcTbl
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */	
	private ArrayList getDataTblDdlByAlertProcTbl_c2(ArrayList list, String tblSubsysId, String alertProcTbl) {
		for (int i=0; i<dataTblList_c2.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_c2.get(i);
			if (dataTblDdlBean.getTblSubsysId().equalsIgnoreCase(tblSubsysId) & dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl)){
				list.add(dataTblDdlBean);
			}			
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param tblSubsysId
	 * @param alertProcTbl
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */	
	private ArrayList getDataTblDdlByAlertProcTbl_se(ArrayList list, String tblSubsysId, String alertProcTbl) {
		for (int i=0; i<dataTblList_se.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_se.get(i);
			if (dataTblDdlBean.getTblSubsysId().equalsIgnoreCase(tblSubsysId) & dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl)){
				list.add(dataTblDdlBean);
			}			
		}
		return list;
	}
	
	/**
	 * @param alertProcTbl
	 * @param region
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Called method that hides getting the StaticDataLoader object.
	 */	
	public static ArrayList getDataTblDdlByAlertProcTbl(String alertProcTbl, String region) throws IllegalArgumentException {
		ArrayList list = new ArrayList();
		if(region.trim().equals("WE")){
			return getRef(region).getDataTblDdlByAlertProcTbl_w(list, alertProcTbl);
        } else if(region.trim().equals("E")){
        	return getRef(region).getDataTblDdlByAlertProcTbl_e(list, alertProcTbl);
        } else if(region.trim().equals("MW")){
        	return getRef(region).getDataTblDdlByAlertProcTbl_mw(list, alertProcTbl);
        } else if(region.trim().equals("SW")){
        	return getRef(region).getDataTblDdlByAlertProcTbl_sw(list, alertProcTbl);
        } else if(region.trim().equals("C2")){
        	return getRef(region).getDataTblDdlByAlertProcTbl_c2(list, alertProcTbl);
        } else if(region.trim().equals("SE")){
        	return getRef(region).getDataTblDdlByAlertProcTbl_se(list, alertProcTbl);	
        }else if(region.trim().equals("MB")){
        	return getRef(region).getDataTblDdlByAlertProcTbl_mb(list, alertProcTbl);	
        } else {
            throw new IllegalArgumentException("Unrecognized region: " + region);
        }
	}	

	/**
	 * @param list
	 * @param alertProcTbl
	 * @param region
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */	
	private ArrayList getDataTblDdlByAlertProcTbl_mb(ArrayList list, String alertProcTbl){
		for (int i=0; i<dataTblList_mb.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_mb.get(i);
			if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl)){
				list.add(dataTblDdlBean);
			}			
		}
		return list;
	}
	/**
	 * @param list
	 * @param alertProcTbl
	 * @param region
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */	
	private ArrayList getDataTblDdlByAlertProcTbl_w(ArrayList list, String alertProcTbl){
		for (int i=0; i<dataTblList_w.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_w.get(i);
			if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl)){
				list.add(dataTblDdlBean);
			}			
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param alertProcTbl
	 * @param region
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */	
	private ArrayList getDataTblDdlByAlertProcTbl_e(ArrayList list, String alertProcTbl){
		for (int i=0; i<dataTblList_e.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_e.get(i);
			if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl)){
				list.add(dataTblDdlBean);
			}			
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param alertProcTbl
	 * @param region
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */	
	private ArrayList getDataTblDdlByAlertProcTbl_mw(ArrayList list, String alertProcTbl){
		for (int i=0; i<dataTblList_mw.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_mw.get(i);
			if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl)){
				list.add(dataTblDdlBean);
			}			
		}
		return list;
	}	
	
	/**
	 * @param list
	 * @param alertProcTbl
	 * @param region
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */	
	private ArrayList getDataTblDdlByAlertProcTbl_sw(ArrayList list, String alertProcTbl){
		for (int i=0; i<dataTblList_sw.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_sw.get(i);
			if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl)){
				list.add(dataTblDdlBean);
			}			
		}
		return list;
	}	
	
	/**
	 * @param list
	 * @param alertProcTbl
	 * @param region
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */	
	private ArrayList getDataTblDdlByAlertProcTbl_c2(ArrayList list, String alertProcTbl){
		for (int i=0; i<dataTblList_c2.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_c2.get(i);
			if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl)){
				list.add(dataTblDdlBean);
			}			
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param alertProcTbl
	 * @param region
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */	
	private ArrayList getDataTblDdlByAlertProcTbl_se(ArrayList list, String alertProcTbl){
		for (int i=0; i<dataTblList_se.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_se.get(i);
			if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl)){
				list.add(dataTblDdlBean);
			}			
		}
		return list;
	}
	
	/**
	 * @param alertProcTbl
	 * @param tblDdlName
	 * @param region
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Called method that hides getting the StaticDataLoader object.
	 */		
	public static ArrayList getDataTblDdlByTblDdlName(String alertProcTbl, String tblDdlName, String region) throws IllegalArgumentException {
		ArrayList list = new ArrayList();
		if(region.trim().equals("WE")){
			return getRef(region).getDataTblDdlByTblDdlName_w(list, alertProcTbl, tblDdlName);
        } else if(region.trim().equals("E")){
        	return getRef(region).getDataTblDdlByTblDdlName_e(list, alertProcTbl, tblDdlName);
        } else if(region.trim().equals("MW")){
        	return getRef(region).getDataTblDdlByTblDdlName_mw(list, alertProcTbl, tblDdlName);
        } else if(region.trim().equals("SW")){
        	return getRef(region).getDataTblDdlByTblDdlName_sw(list, alertProcTbl, tblDdlName);
        } else if(region.trim().equals("C2")){
        	return getRef(region).getDataTblDdlByTblDdlName_c2(list, alertProcTbl, tblDdlName);
        } else if(region.trim().equals("SE")){
        	return getRef(region).getDataTblDdlByTblDdlName_se(list, alertProcTbl, tblDdlName);	
        } else if(region.trim().equals("MB")){
        	return getRef(region).getDataTblDdlByTblDdlName_mb(list, alertProcTbl, tblDdlName);
        } else {
            throw new IllegalArgumentException("Unrecognized region: " + region);
        }
	}
	
	/**
	 * @param list
	 * @param alertProcTbl
	 * @param tblDdlName
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */		
	private ArrayList getDataTblDdlByTblDdlName_mb(ArrayList list, String alertProcTbl, String tblDdlName) {
		for (int i=0; i<dataTblList_mb.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_mb.get(i);
			if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) & dataTblDdlBean.getTblDdlName().equalsIgnoreCase(tblDdlName)){
				list.add(dataTblDdlBean);
			}			
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param alertProcTbl
	 * @param tblDdlName
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */		
	private ArrayList getDataTblDdlByTblDdlName_w(ArrayList list, String alertProcTbl, String tblDdlName) {
		for (int i=0; i<dataTblList_w.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_w.get(i);
			if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) & dataTblDdlBean.getTblDdlName().equalsIgnoreCase(tblDdlName)){
				list.add(dataTblDdlBean);
			}			
		}
		return list;
	}
		
	/**
	 * @param list
	 * @param alertProcTbl
	 * @param tblDdlName
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */		
	private ArrayList getDataTblDdlByTblDdlName_e(ArrayList list, String alertProcTbl, String tblDdlName) {
		for (int i=0; i<dataTblList_e.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_e.get(i);
			if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) & dataTblDdlBean.getTblDdlName().equalsIgnoreCase(tblDdlName)){
				list.add(dataTblDdlBean);
			}			
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param alertProcTbl
	 * @param tblDdlName
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */		
	private ArrayList getDataTblDdlByTblDdlName_mw(ArrayList list, String alertProcTbl, String tblDdlName) {
		for (int i=0; i<dataTblList_mw.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_mw.get(i);
			if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) & dataTblDdlBean.getTblDdlName().equalsIgnoreCase(tblDdlName)){
				list.add(dataTblDdlBean);
			}			
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param alertProcTbl
	 * @param tblDdlName
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */		
	private ArrayList getDataTblDdlByTblDdlName_sw(ArrayList list, String alertProcTbl, String tblDdlName) {
		for (int i=0; i<dataTblList_sw.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_sw.get(i);
			if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) & dataTblDdlBean.getTblDdlName().equalsIgnoreCase(tblDdlName)){
				list.add(dataTblDdlBean);
			}			
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param alertProcTbl
	 * @param tblDdlName
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */		
	private ArrayList getDataTblDdlByTblDdlName_c2(ArrayList list, String alertProcTbl, String tblDdlName) {
		for (int i=0; i<dataTblList_c2.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_c2.get(i);
			if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) & dataTblDdlBean.getTblDdlName().equalsIgnoreCase(tblDdlName)){
				list.add(dataTblDdlBean);
			}			
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param alertProcTbl
	 * @param tblDdlName
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */		
	private ArrayList getDataTblDdlByTblDdlName_se(ArrayList list, String alertProcTbl, String tblDdlName) {
		for (int i=0; i<dataTblList_se.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_se.get(i);
			if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) & dataTblDdlBean.getTblDdlName().equalsIgnoreCase(tblDdlName)){
				list.add(dataTblDdlBean);
			}			
		}
		return list;
	}
	
	/**
	 * @param alertProcTbl
	 * @param tblDdlDataType 
	 * @param true, if data required is equal to tblDdlDataType
	 *        false, if data required is not equal to tblDdlDataType
	 * @param region
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Called method that hides getting the StaticDataLoader object.
	 */		
	public static ArrayList getDataTblDdlByDataType(String alertProcTbl, String tblDdlDataType, boolean equal, String region) throws IllegalArgumentException {
		ArrayList list = new ArrayList();
		if(region.trim().equals("WE")){
			return getRef(region).getDataTblDdlByDataType_w(list, alertProcTbl, tblDdlDataType, equal);
        } else if(region.trim().equals("E")){
        	return getRef(region).getDataTblDdlByDataType_e(list, alertProcTbl, tblDdlDataType, equal);
        } else if(region.trim().equals("MW")){
        	return getRef(region).getDataTblDdlByDataType_mw(list, alertProcTbl, tblDdlDataType, equal);
        } else if(region.trim().equals("SW")){
        	return getRef(region).getDataTblDdlByDataType_sw(list, alertProcTbl, tblDdlDataType, equal);
        } else if(region.trim().equals("C2")){
        	return getRef(region).getDataTblDdlByDataType_c2(list, alertProcTbl, tblDdlDataType, equal);
        } else if(region.trim().equals("SE")){
        	return getRef(region).getDataTblDdlByDataType_se(list, alertProcTbl, tblDdlDataType, equal);	
        } else if(region.trim().equals("MB")){
        	return getRef(region).getDataTblDdlByDataType_mb(list, alertProcTbl, tblDdlDataType, equal);
        }else {
            throw new IllegalArgumentException("Unrecognized region: " + region);
        }
	}
	
	/**
	 * @param list
	 * @param alertProcTbl
	 * @param tblDdlDataType 
	 * @param true, if data required is equal to tblDdlDataType
	 *        false, if data required is not equal to tblDdlDataType
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */		
	private ArrayList getDataTblDdlByDataType_mb(ArrayList list, String alertProcTbl, String tblDdlDataType, boolean equal) {
		if (equal){
			for (int i=0; i<dataTblList_mb.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_mb.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && dataTblDdlBean.getTblDdlDataType().equalsIgnoreCase(tblDdlDataType)){
					list.add(dataTblDdlBean);
				}			
			}		
		}else{
			for (int i=0; i<dataTblList_mb.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_mb.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && !dataTblDdlBean.getTblDdlDataType().equalsIgnoreCase(tblDdlDataType)){
					list.add(dataTblDdlBean);
				}			
			}
		}
		return list;
	}	
	/**
	 * @param list
	 * @param alertProcTbl
	 * @param tblDdlDataType 
	 * @param true, if data required is equal to tblDdlDataType
	 *        false, if data required is not equal to tblDdlDataType
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */		
	private ArrayList getDataTblDdlByDataType_w(ArrayList list, String alertProcTbl, String tblDdlDataType, boolean equal) {
		if (equal){
			for (int i=0; i<dataTblList_w.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_w.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && dataTblDdlBean.getTblDdlDataType().equalsIgnoreCase(tblDdlDataType)){
					list.add(dataTblDdlBean);
				}			
			}		
		}else{
			for (int i=0; i<dataTblList_w.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_w.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && !dataTblDdlBean.getTblDdlDataType().equalsIgnoreCase(tblDdlDataType)){
					list.add(dataTblDdlBean);
				}			
			}
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param alertProcTbl
	 * @param tblDdlDataType 
	 * @param true, if data required is equal to tblDdlDataType
	 *        false, if data required is not equal to tblDdlDataType
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */		
	private ArrayList getDataTblDdlByDataType_e(ArrayList list, String alertProcTbl, String tblDdlDataType, boolean equal) {
		if (equal){
			for (int i=0; i<dataTblList_e.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_e.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && dataTblDdlBean.getTblDdlDataType().equalsIgnoreCase(tblDdlDataType)){
					list.add(dataTblDdlBean);
				}			
			}		
		}else{
			for (int i=0; i<dataTblList_e.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_e.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && !dataTblDdlBean.getTblDdlDataType().equalsIgnoreCase(tblDdlDataType)){
					list.add(dataTblDdlBean);
				}			
			}
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param alertProcTbl
	 * @param tblDdlDataType 
	 * @param true, if data required is equal to tblDdlDataType
	 *        false, if data required is not equal to tblDdlDataType
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */		
	private ArrayList getDataTblDdlByDataType_mw(ArrayList list, String alertProcTbl, String tblDdlDataType, boolean equal) {
		if (equal){
			for (int i=0; i<dataTblList_mw.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_mw.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && dataTblDdlBean.getTblDdlDataType().equalsIgnoreCase(tblDdlDataType)){
					list.add(dataTblDdlBean);
				}			
			}		
		}else{
			for (int i=0; i<dataTblList_mw.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_mw.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && !dataTblDdlBean.getTblDdlDataType().equalsIgnoreCase(tblDdlDataType)){
					list.add(dataTblDdlBean);
				}			
			}
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param alertProcTbl
	 * @param tblDdlDataType 
	 * @param true, if data required is equal to tblDdlDataType
	 *        false, if data required is not equal to tblDdlDataType
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */		
	private ArrayList getDataTblDdlByDataType_sw(ArrayList list, String alertProcTbl, String tblDdlDataType, boolean equal) {
		if (equal){
			for (int i=0; i<dataTblList_sw.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_sw.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && dataTblDdlBean.getTblDdlDataType().equalsIgnoreCase(tblDdlDataType)){
					list.add(dataTblDdlBean);
				}			
			}		
		}else{
			for (int i=0; i<dataTblList_sw.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_sw.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && !dataTblDdlBean.getTblDdlDataType().equalsIgnoreCase(tblDdlDataType)){
					list.add(dataTblDdlBean);
				}			
			}
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param alertProcTbl
	 * @param tblDdlDataType 
	 * @param true, if data required is equal to tblDdlDataType
	 *        false, if data required is not equal to tblDdlDataType
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */		
	private ArrayList getDataTblDdlByDataType_c2(ArrayList list, String alertProcTbl, String tblDdlDataType, boolean equal) {
		if (equal){
			for (int i=0; i<dataTblList_c2.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_c2.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && dataTblDdlBean.getTblDdlDataType().equalsIgnoreCase(tblDdlDataType)){
					list.add(dataTblDdlBean);
				}			
			}		
		}else{
			for (int i=0; i<dataTblList_c2.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_c2.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && !dataTblDdlBean.getTblDdlDataType().equalsIgnoreCase(tblDdlDataType)){
					list.add(dataTblDdlBean);
				}			
			}
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param alertProcTbl
	 * @param tblDdlDataType 
	 * @param true, if data required is equal to tblDdlDataType
	 *        false, if data required is not equal to tblDdlDataType
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */		
	private ArrayList getDataTblDdlByDataType_se(ArrayList list, String alertProcTbl, String tblDdlDataType, boolean equal) {
		if (equal){
			for (int i=0; i<dataTblList_se.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_se.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && dataTblDdlBean.getTblDdlDataType().equalsIgnoreCase(tblDdlDataType)){
					list.add(dataTblDdlBean);
				}			
			}		
		}else{
			for (int i=0; i<dataTblList_se.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_se.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && !dataTblDdlBean.getTblDdlDataType().equalsIgnoreCase(tblDdlDataType)){
					list.add(dataTblDdlBean);
				}			
			}
		}
		return list;
	}
	
	/**
	 * @param alertProcTbl
	 * @param selTiming
	 * @param region
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Called method that hides getting the StaticDataLoader object.
	 */		
	public static ArrayList getDataTblDdlBySelTiming(String alertProcTbl, String selTiming, String region) throws IllegalArgumentException {
		ArrayList list = new ArrayList();
		if(region.trim().equals("WE")){
			return getRef(region).getDataTblDdlBySelTiming_w(list, alertProcTbl, selTiming);
        } else if(region.trim().equals("E")){
        	return getRef(region).getDataTblDdlBySelTiming_e(list, alertProcTbl, selTiming);
        } else if(region.trim().equals("MW")){
        	return getRef(region).getDataTblDdlBySelTiming_mw(list, alertProcTbl, selTiming);
        } else if(region.trim().equals("SW")){
        	return getRef(region).getDataTblDdlBySelTiming_sw(list, alertProcTbl, selTiming);
        } else if(region.trim().equals("C2")){
        	return getRef(region).getDataTblDdlBySelTiming_c2(list, alertProcTbl, selTiming);
        } else if(region.trim().equals("SE")){
        	return getRef(region).getDataTblDdlBySelTiming_se(list, alertProcTbl, selTiming);	
        } else if(region.trim().equals("MB")){
        	return getRef(region).getDataTblDdlBySelTiming_mb(list, alertProcTbl, selTiming);	
        } else {
            throw new IllegalArgumentException("Unrecognized region: " + region);
        }
	}

	/**
	 * @param list
	 * @param alertProcTbl
	 * @param selTiming
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */		
	private ArrayList getDataTblDdlBySelTiming_mb(ArrayList list, String alertProcTbl, String selTiming) {
		if (selTiming.equalsIgnoreCase("B")){
			for (int i=0; i<dataTblList_mb.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_mb.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && (dataTblDdlBean.getTblBillRndDdlMon() != null || dataTblDdlBean.getTblBillRndDdlYear() != null)){
					list.add(dataTblDdlBean);
				}			
			}		
		}else{
			for (int i=0; i<dataTblList_mb.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_mb.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && dataTblDdlBean.getTblProcDateDdlName() != null){
					list.add(dataTblDdlBean);
				}			
			}
		}
		return list;
	}
	/**
	 * @param list
	 * @param alertProcTbl
	 * @param selTiming
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */		
	private ArrayList getDataTblDdlBySelTiming_w(ArrayList list, String alertProcTbl, String selTiming) {
		if (selTiming.equalsIgnoreCase("B")){
			for (int i=0; i<dataTblList_w.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_w.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && (dataTblDdlBean.getTblBillRndDdlMon() != null || dataTblDdlBean.getTblBillRndDdlYear() != null)){
					list.add(dataTblDdlBean);
				}			
			}		
		}else{
			for (int i=0; i<dataTblList_w.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_w.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && dataTblDdlBean.getTblProcDateDdlName() != null){
					list.add(dataTblDdlBean);
				}			
			}
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param alertProcTbl
	 * @param selTiming
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */		
	private ArrayList getDataTblDdlBySelTiming_e(ArrayList list, String alertProcTbl, String selTiming) {
		if (selTiming.equalsIgnoreCase("B")){
			for (int i=0; i<dataTblList_e.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_e.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && (dataTblDdlBean.getTblBillRndDdlMon() != null || dataTblDdlBean.getTblBillRndDdlYear() != null)){
					list.add(dataTblDdlBean);
				}			
			}		
		}else{
			for (int i=0; i<dataTblList_e.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_e.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && dataTblDdlBean.getTblProcDateDdlName() != null){
					list.add(dataTblDdlBean);
				}			
			}
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param alertProcTbl
	 * @param selTiming
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */		
	private ArrayList getDataTblDdlBySelTiming_mw(ArrayList list, String alertProcTbl, String selTiming) {
		if (selTiming.equalsIgnoreCase("B")){
			for (int i=0; i<dataTblList_mw.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_mw.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && (dataTblDdlBean.getTblBillRndDdlMon() != null || dataTblDdlBean.getTblBillRndDdlYear() != null)){
					list.add(dataTblDdlBean);
				}			
			}		
		}else{
			for (int i=0; i<dataTblList_mw.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_mw.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && dataTblDdlBean.getTblProcDateDdlName() != null){
					list.add(dataTblDdlBean);
				}			
			}
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param alertProcTbl
	 * @param selTiming
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */		
	private ArrayList getDataTblDdlBySelTiming_sw(ArrayList list, String alertProcTbl, String selTiming) {
		if (selTiming.equalsIgnoreCase("B")){
			for (int i=0; i<dataTblList_sw.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_sw.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && (dataTblDdlBean.getTblBillRndDdlMon() != null || dataTblDdlBean.getTblBillRndDdlYear() != null)){
					list.add(dataTblDdlBean);
				}			
			}		
		}else{
			for (int i=0; i<dataTblList_sw.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_sw.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && dataTblDdlBean.getTblProcDateDdlName() != null){
					list.add(dataTblDdlBean);
				}			
			}
		}
		return list;
	}
	
		/**
	 * 
	 * @param region
	 * @return
	 * @throws IllegalArgumentException
	 */	
	public static ArrayList getDataTblDdlForBillRndNotNull(String region) throws IllegalArgumentException {
		ArrayList list = new ArrayList();
		if(region.trim().equals("WE")){
			return getRef(region).getDataTblDdlForBillRndNotNull_w(list);
        } else if(region.trim().equals("E")){
        	return getRef(region).getDataTblDdlForBillRndNotNull_e(list);
        } else if(region.trim().equals("MW")){
        	return getRef(region).getDataTblDdlForBillRndNotNull_mw(list);
        } else if(region.trim().equals("SW")){
        	return getRef(region).getDataTblDdlForBillRndNotNull_sw(list);
        } else if(region.trim().equals("C2")){
        	return getRef(region).getDataTblDdlForBillRndNotNull_c2(list);
        } else if(region.trim().equals("SE")){
        	return getRef(region).getDataTblDdlForBillRndNotNull_se(list);	
        } else if(region.trim().equals("MB")){
        	return getRef(region).getDataTblDdlForBillRndNotNull_mb(list);	
        } else {
            throw new IllegalArgumentException("Unrecognized region: " + region);
        }
	}

	/**
	 * Returns DataTblDdlBean objects list for W such that TBL_BILL_RND_DDL_NAME IS NOT NULL
	 * @param list
	 * @return
	 */
	private ArrayList getDataTblDdlForBillRndNotNull_mb(ArrayList list) {
		for (int i=0; i<dataTblList_mb.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_mb.get(i);
			if (dataTblDdlBean.getTblBillRndDdlName() != null){
				list.add(dataTblDdlBean);
			}			
		}		

		return list;
	}
	/**
	 * Returns DataTblDdlBean objects list for W such that TBL_BILL_RND_DDL_NAME IS NOT NULL
	 * @param list
	 * @return
	 */
	private ArrayList getDataTblDdlForBillRndNotNull_w(ArrayList list) {
		for (int i=0; i<dataTblList_w.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_w.get(i);
			if (dataTblDdlBean.getTblBillRndDdlName() != null){
				list.add(dataTblDdlBean);
			}			
		}		

		return list;
	}
	
	/**
	 * Returns DataTblDdlBean objects list for E such that TBL_BILL_RND_DDL_NAME IS NOT NULL
	 * @param list
	 * @return
	 */
	private ArrayList getDataTblDdlForBillRndNotNull_e(ArrayList list) {
		for (int i=0; i<dataTblList_e.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_e.get(i);
			if (dataTblDdlBean.getTblBillRndDdlName() != null){
				list.add(dataTblDdlBean);
			}			
		}		

		return list;
	}
	
	/**
	 * Returns DataTblDdlBean objects list for MW such that TBL_BILL_RND_DDL_NAME IS NOT NULL
	 * @param list
	 * @return
	 */
	private ArrayList getDataTblDdlForBillRndNotNull_mw(ArrayList list) {
		for (int i=0; i<dataTblList_mw.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_mw.get(i);
			if (dataTblDdlBean.getTblBillRndDdlName() != null){
				list.add(dataTblDdlBean);
			}			
		}		

		return list;
	}
	
	/**
	 * Returns DataTblDdlBean objects list for W such that TBL_BILL_RND_DDL_NAME IS NOT NULL
	 * @param list
	 * @return
	 */
	private ArrayList getDataTblDdlForBillRndNotNull_sw(ArrayList list) {
		for (int i=0; i<dataTblList_sw.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_sw.get(i);
			if (dataTblDdlBean.getTblBillRndDdlName() != null){
				list.add(dataTblDdlBean);
			}			
		}		

		return list;
	}
	
	/**
	 * Returns DataTblDdlBean objects list for W such that TBL_BILL_RND_DDL_NAME IS NOT NULL
	 * @param list
	 * @return
	 */
	private ArrayList getDataTblDdlForBillRndNotNull_c2(ArrayList list) {
		for (int i=0; i<dataTblList_c2.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_c2.get(i);
			if (dataTblDdlBean.getTblBillRndDdlName() != null){
				list.add(dataTblDdlBean);
			}			
		}		

		return list;
	}
	
	/**
	 * Returns DataTblDdlBean objects list for SE such that TBL_BILL_RND_DDL_NAME IS NOT NULL
	 * @param list
	 * @return
	 */
	private ArrayList getDataTblDdlForBillRndNotNull_se(ArrayList list) {
		for (int i=0; i<dataTblList_se.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_se.get(i);
			if (dataTblDdlBean.getTblBillRndDdlName() != null){
				list.add(dataTblDdlBean);
			}			
		}		

		return list;
	}
	
	/**
	 * @param list
	 * @param alertProcTbl
	 * @param selTiming
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */		
	private ArrayList getDataTblDdlBySelTiming_c2(ArrayList list, String alertProcTbl, String selTiming) {
		if (selTiming.equalsIgnoreCase("B")){
			for (int i=0; i<dataTblList_c2.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_c2.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && (dataTblDdlBean.getTblBillRndDdlMon() != null || dataTblDdlBean.getTblBillRndDdlYear() != null)){
					list.add(dataTblDdlBean);
				}			
			}		
		}else{
			for (int i=0; i<dataTblList_c2.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_c2.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && dataTblDdlBean.getTblProcDateDdlName() != null){
					list.add(dataTblDdlBean);
				}			
			}
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param alertProcTbl
	 * @param selTiming
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */		
	private ArrayList getDataTblDdlBySelTiming_se(ArrayList list, String alertProcTbl, String selTiming) {
		if (selTiming.equalsIgnoreCase("B")){
			for (int i=0; i<dataTblList_se.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_se.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && (dataTblDdlBean.getTblBillRndDdlMon() != null || dataTblDdlBean.getTblBillRndDdlYear() != null)){
					list.add(dataTblDdlBean);
				}			
			}		
		}else{
			for (int i=0; i<dataTblList_se.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_se.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && dataTblDdlBean.getTblProcDateDdlName() != null){
					list.add(dataTblDdlBean);
				}			
			}
		}
		return list;
	}
	
	
	/**
	 * @param alertProcTbl
	 * @param tblFileSeqNumDdlName, can be null
	 * @param region
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Called method that hides getting the StaticDataLoader object.
	 */	
	public static ArrayList getDataTblDdlBySeqNumDdlName(String alertProcTbl, String tblFileSeqNumDdlName, String region) throws IllegalArgumentException {
		ArrayList list = new ArrayList();
		if(region.trim().equals("WE")){
			return getRef(region).getDataTblDdlBySeqNumDdlName_w(list, alertProcTbl, tblFileSeqNumDdlName);
        } else if(region.trim().equals("E")){
        	return getRef(region).getDataTblDdlBySeqNumDdlName_e(list, alertProcTbl, tblFileSeqNumDdlName);
        } else if(region.trim().equals("MW")){
        	return getRef(region).getDataTblDdlBySeqNumDdlName_mw(list, alertProcTbl, tblFileSeqNumDdlName);
        } else if(region.trim().equals("SW")){
        	return getRef(region).getDataTblDdlBySeqNumDdlName_sw(list, alertProcTbl, tblFileSeqNumDdlName);
        } else if(region.trim().equals("C2")){
        	return getRef(region).getDataTblDdlBySeqNumDdlName_c2(list, alertProcTbl, tblFileSeqNumDdlName);
        } else if(region.trim().equals("SE")){
        	return getRef(region).getDataTblDdlBySeqNumDdlName_se(list, alertProcTbl, tblFileSeqNumDdlName);	
        } else if(region.trim().equals("MB")){
        	return getRef(region).getDataTblDdlBySeqNumDdlName_mb(list, alertProcTbl, tblFileSeqNumDdlName);	
        }else {
            throw new IllegalArgumentException("Unrecognized region: " + region);
        }
	}
	
	/**
	 * @param list
	 * @param alertProcTbl
	 * @param tblFileSeqNumDdlName, can be null
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */	
	private ArrayList getDataTblDdlBySeqNumDdlName_mb(ArrayList list, String alertProcTbl, String tblFileSeqNumDdlName) {
		if (tblFileSeqNumDdlName == null){
			for (int i=0; i<dataTblList_mb.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_mb.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && dataTblDdlBean.getTblFileSeqNumDdlName() == null){
					list.add(dataTblDdlBean);
				}			
			}			
		}else{
			for (int i=0; i<dataTblList_mb.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_mb.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && dataTblDdlBean.getTblFileSeqNumDdlName().equalsIgnoreCase(tblFileSeqNumDdlName)){
					list.add(dataTblDdlBean);
				}			
			}			
		}
		return list;
	}
	/**
	 * @param list
	 * @param alertProcTbl
	 * @param tblFileSeqNumDdlName, can be null
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */	
	private ArrayList getDataTblDdlBySeqNumDdlName_w(ArrayList list, String alertProcTbl, String tblFileSeqNumDdlName) {
		if (tblFileSeqNumDdlName == null){
			for (int i=0; i<dataTblList_w.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_w.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && dataTblDdlBean.getTblFileSeqNumDdlName() == null){
					list.add(dataTblDdlBean);
				}			
			}			
		}else{
			for (int i=0; i<dataTblList_w.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_w.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && dataTblDdlBean.getTblFileSeqNumDdlName().equalsIgnoreCase(tblFileSeqNumDdlName)){
					list.add(dataTblDdlBean);
				}			
			}			
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param alertProcTbl
	 * @param tblFileSeqNumDdlName, can be null
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */	
	private ArrayList getDataTblDdlBySeqNumDdlName_e(ArrayList list, String alertProcTbl, String tblFileSeqNumDdlName) {
		if (tblFileSeqNumDdlName == null){
			for (int i=0; i<dataTblList_e.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_e.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && dataTblDdlBean.getTblFileSeqNumDdlName() == null){
					list.add(dataTblDdlBean);
				}			
			}			
		}else{
			for (int i=0; i<dataTblList_e.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_e.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && dataTblDdlBean.getTblFileSeqNumDdlName().equalsIgnoreCase(tblFileSeqNumDdlName)){
					list.add(dataTblDdlBean);
				}			
			}			
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param alertProcTbl
	 * @param tblFileSeqNumDdlName, can be null
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */	
	private ArrayList getDataTblDdlBySeqNumDdlName_mw(ArrayList list, String alertProcTbl, String tblFileSeqNumDdlName) {
		if (tblFileSeqNumDdlName == null){
			for (int i=0; i<dataTblList_mw.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_mw.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && dataTblDdlBean.getTblFileSeqNumDdlName() == null){
					list.add(dataTblDdlBean);
				}			
			}			
		}else{
			for (int i=0; i<dataTblList_mw.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_mw.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && dataTblDdlBean.getTblFileSeqNumDdlName().equalsIgnoreCase(tblFileSeqNumDdlName)){
					list.add(dataTblDdlBean);
				}			
			}			
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param alertProcTbl
	 * @param tblFileSeqNumDdlName, can be null
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */	
	private ArrayList getDataTblDdlBySeqNumDdlName_sw(ArrayList list, String alertProcTbl, String tblFileSeqNumDdlName) {
		if (tblFileSeqNumDdlName == null){
			for (int i=0; i<dataTblList_sw.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_sw.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && dataTblDdlBean.getTblFileSeqNumDdlName() == null){
					list.add(dataTblDdlBean);
				}			
			}			
		}else{
			for (int i=0; i<dataTblList_sw.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_sw.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && dataTblDdlBean.getTblFileSeqNumDdlName().equalsIgnoreCase(tblFileSeqNumDdlName)){
					list.add(dataTblDdlBean);
				}			
			}			
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param alertProcTbl
	 * @param tblFileSeqNumDdlName, can be null
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */	
	private ArrayList getDataTblDdlBySeqNumDdlName_c2(ArrayList list, String alertProcTbl, String tblFileSeqNumDdlName) {
		if (tblFileSeqNumDdlName == null){
			for (int i=0; i<dataTblList_c2.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_c2.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && dataTblDdlBean.getTblFileSeqNumDdlName() == null){
					list.add(dataTblDdlBean);
				}			
			}			
		}else{
			for (int i=0; i<dataTblList_c2.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_c2.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && dataTblDdlBean.getTblFileSeqNumDdlName().equalsIgnoreCase(tblFileSeqNumDdlName)){
					list.add(dataTblDdlBean);
				}			
			}			
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param alertProcTbl
	 * @param tblFileSeqNumDdlName, can be null
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Underlying table: RABC_DATA_TBL_DDL
	 */	
	private ArrayList getDataTblDdlBySeqNumDdlName_se(ArrayList list, String alertProcTbl, String tblFileSeqNumDdlName) {
		if (tblFileSeqNumDdlName == null){
			for (int i=0; i<dataTblList_se.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_se.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && dataTblDdlBean.getTblFileSeqNumDdlName() == null){
					list.add(dataTblDdlBean);
				}			
			}			
		}else{
			for (int i=0; i<dataTblList_se.size(); i++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_se.get(i);
				if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl) && dataTblDdlBean.getTblFileSeqNumDdlName().equalsIgnoreCase(tblFileSeqNumDdlName)){
					list.add(dataTblDdlBean);
				}			
			}			
		}
		return list;
	}
	
	/**
	 * @param tblDdlName
	 * @param region
	 * @return String, MAX(TBL_DDL_PRESCSN_FORMAT_TYPE)
	 * Called method that hides getting the StaticDataLoader object.
	 */	
	public static String getMaxFormatTypeForTblDdlName(String tblDdlName, String region) throws IllegalArgumentException {
		if(region.trim().equals("WE")){
			return getRef(region).getMaxFormatTypeForTblDdlName_w(tblDdlName);
        } else if(region.trim().equals("E")){
        	return getRef(region).getMaxFormatTypeForTblDdlName_e(tblDdlName);
        } else if(region.trim().equals("MW")){
        	return getRef(region).getMaxFormatTypeForTblDdlName_mw(tblDdlName);
        } else if(region.trim().equals("SW")){
        	return getRef(region).getMaxFormatTypeForTblDdlName_sw(tblDdlName);
        } else if(region.trim().equals("C2")){
        	return getRef(region).getMaxFormatTypeForTblDdlName_c2(tblDdlName);
        } else if(region.trim().equals("SE")){
        	return getRef(region).getMaxFormatTypeForTblDdlName_se(tblDdlName);	
        } else if(region.trim().equals("MB")){
        	return getRef(region).getMaxFormatTypeForTblDdlName_mb(tblDdlName);	
        } else {
            throw new IllegalArgumentException("Unrecognized region: " + region);
        }
	}

	/**
	 * @param tblDdlName
	 * @return String, MAX(TBL_DDL_PRESCSN_FORMAT_TYPE)
	 * Underlying table: RABC_DATA_TBL_DDL
	 */	
	private String getMaxFormatTypeForTblDdlName_mb(String tblDdlName){
		String result = "";
		for (int i=0; i<maxFormatList_mb.size(); i++){
			PickList pickList = (PickList)maxFormatList_mb.get(i);
			if (pickList.getKey().equalsIgnoreCase(tblDdlName)){
				result = pickList.getValue1();
			}			
		}
		return result;
	}
	
	/**
	 * @param tblDdlName
	 * @return String, MAX(TBL_DDL_PRESCSN_FORMAT_TYPE)
	 * Underlying table: RABC_DATA_TBL_DDL
	 */	
	private String getMaxFormatTypeForTblDdlName_w(String tblDdlName){
		String result = "";
		for (int i=0; i<maxFormatList_w.size(); i++){
			PickList pickList = (PickList)maxFormatList_w.get(i);
			if (pickList.getKey().equalsIgnoreCase(tblDdlName)){
				result = pickList.getValue1();
			}			
		}
		return result;
	}
	
	/**
	 * @param tblDdlName
	 * @return String, MAX(TBL_DDL_PRESCSN_FORMAT_TYPE)
	 * Underlying table: RABC_DATA_TBL_DDL
	 */	
	private String getMaxFormatTypeForTblDdlName_e(String tblDdlName){
		String result = "";
		for (int i=0; i<maxFormatList_e.size(); i++){
			PickList pickList = (PickList)maxFormatList_e.get(i);
			if (pickList.getKey().equalsIgnoreCase(tblDdlName)){
				result = pickList.getValue1();
			}			
		}
		return result;
	}
	
	/**
	 * @param tblDdlName
	 * @return String, MAX(TBL_DDL_PRESCSN_FORMAT_TYPE)
	 * Underlying table: RABC_DATA_TBL_DDL
	 */	
	private String getMaxFormatTypeForTblDdlName_mw(String tblDdlName){
		String result = "";
		for (int i=0; i<maxFormatList_mw.size(); i++){
			PickList pickList = (PickList)maxFormatList_mw.get(i);
			if (pickList.getKey().equalsIgnoreCase(tblDdlName)){
				result = pickList.getValue1();
			}			
		}
		return result;
	}
	
	/**
	 * @param tblSubsysId
	 * @param region
	 * @return ArrayList of DataTblDdlBean objects matching input criteria 
	 * Called method that hides getting the StaticDataLoader object.
	 */	
	public static String getDefaultDataTblDdlKey(String alertProcTbl, String region, int key) throws IllegalArgumentException {
		String defaultKeyColumn = "";
		if(region.trim().equals("WE")){
			return getRef(region).getDefaultDataTblDdlKey_w(defaultKeyColumn, alertProcTbl, key);
        } else if(region.trim().equals("E")){
        	return getRef(region).getDefaultDataTblDdlKey_e(defaultKeyColumn, alertProcTbl, key);
        } else if(region.trim().equals("MW")){
        	return getRef(region).getDefaultDataTblDdlKey_mw(defaultKeyColumn, alertProcTbl, key);
        } else if(region.trim().equals("SW")){
        	return getRef(region).getDefaultDataTblDdlKey_sw(defaultKeyColumn, alertProcTbl, key);
        } else if(region.trim().equals("C2")){
        	return getRef(region).getDefaultDataTblDdlKey_c2(defaultKeyColumn, alertProcTbl, key);
        } else if(region.trim().equals("SE")){
        	return getRef(region).getDefaultDataTblDdlKey_se(defaultKeyColumn, alertProcTbl, key);	
        }else if(region.trim().equals("MB")){
        	return getRef(region).getDefaultDataTblDdlKey_mb(defaultKeyColumn, alertProcTbl, key);	
        }else {
            throw new IllegalArgumentException("Unrecognized region: " + region);
        }
	}	

	/**
	 * Method will return the default key column for West
	 * @param defaultKeyColumn
	 * @param alertProcTbl
	 * @param key
	 * @return
	 */
	private String getDefaultDataTblDdlKey_mb(String defaultKeyColumn, String alertProcTbl, int key){
		for (int i=0; i<dataTblList_mb.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_mb.get(i);
			if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl)){
				switch (key){
					case 1:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey1Name();
						break;
					case 2:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey2Name();
						break;
					case 3:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey3Name();
						break;
					case 4:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey4Name();
						break;
					case 5:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey5Name();
						break;
					default:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey1Name();
						break;
				}
				
				if (defaultKeyColumn!=null && !"".equals(defaultKeyColumn)){
					break;
				}
			}
		}
		return defaultKeyColumn;
	}
	/**
	 * Method will return the default key column for West
	 * @param defaultKeyColumn
	 * @param alertProcTbl
	 * @param key
	 * @return
	 */
	private String getDefaultDataTblDdlKey_w(String defaultKeyColumn, String alertProcTbl, int key){
		for (int i=0; i<dataTblList_w.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_w.get(i);
			if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl)){
				switch (key){
					case 1:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey1Name();
						break;
					case 2:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey2Name();
						break;
					case 3:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey3Name();
						break;
					case 4:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey4Name();
						break;
					case 5:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey5Name();
						break;
					default:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey1Name();
						break;
				}
				
				if (defaultKeyColumn!=null && !"".equals(defaultKeyColumn)){
					break;
				}
			}
		}
		return defaultKeyColumn;
	}	
	
	/**
	 * Method will return the default key column for East
	 * @param defaultKeyColumn
	 * @param alertProcTbl
	 * @param key
	 * @return
	 */
	private String getDefaultDataTblDdlKey_e(String defaultKeyColumn, String alertProcTbl, int key){
		for (int i=0; i<dataTblList_e.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_e.get(i);
			if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl)){
				switch (key){
					case 1:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey1Name();
						break;
					case 2:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey2Name();
						break;
					case 3:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey3Name();
						break;
					case 4:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey4Name();
						break;
					case 5:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey5Name();
						break;
					default:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey1Name();
						break;
				}
				
				if (defaultKeyColumn!=null && !"".equals(defaultKeyColumn)){
					break;
				}
			}
		}
		return defaultKeyColumn;
	}
	
	/**
	 * Method will return the default key column for Midwest
	 * @param defaultKeyColumn
	 * @param alertProcTbl
	 * @param key
	 * @return
	 */
	private String getDefaultDataTblDdlKey_mw(String defaultKeyColumn, String alertProcTbl, int key){
		for (int i=0; i<dataTblList_mw.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_mw.get(i);
			if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl)){
				switch (key){
					case 1:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey1Name();
						break;
					case 2:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey2Name();
						break;
					case 3:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey3Name();
						break;
					case 4:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey4Name();
						break;
					case 5:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey5Name();
						break;
					default:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey1Name();
						break;
				}
				
				if (defaultKeyColumn!=null && !"".equals(defaultKeyColumn)){
					break;
				}
			}
		}
		return defaultKeyColumn;
	}	
	
	/**
	 * Method will return the default key column for Southwest
	 * @param defaultKeyColumn
	 * @param alertProcTbl
	 * @param key
	 * @return
	 */
	private String getDefaultDataTblDdlKey_sw(String defaultKeyColumn, String alertProcTbl, int key){
		for (int i=0; i<dataTblList_sw.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_sw.get(i);
			if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl)){
				switch (key){
					case 1:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey1Name();
						break;
					case 2:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey2Name();
						break;
					case 3:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey3Name();
						break;
					case 4:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey4Name();
						break;
					case 5:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey5Name();
						break;
					default:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey1Name();
						break;
				}
				
				if (defaultKeyColumn!=null && !"".equals(defaultKeyColumn)){
					break;
				}
			}
		}
		return defaultKeyColumn;
	}	
	
	/**
	 * Method will return the default key column for Calnet
	 * @param defaultKeyColumn
	 * @param alertProcTbl
	 * @param key
	 * @return
	 */
	private String getDefaultDataTblDdlKey_c2(String defaultKeyColumn, String alertProcTbl, int key){
		for (int i=0; i<dataTblList_c2.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_c2.get(i);
			if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl)){
				switch (key){
					case 1:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey1Name();
						break;
					case 2:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey2Name();
						break;
					case 3:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey3Name();
						break;
					case 4:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey4Name();
						break;
					case 5:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey5Name();
						break;
					default:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey1Name();
						break;
				}
				
				if (defaultKeyColumn!=null && !"".equals(defaultKeyColumn)){
					break;
				}
			}
		}
		return defaultKeyColumn;
	}	
	
	/**
	 * Method will return the default key column for Calnet
	 * @param defaultKeyColumn
	 * @param alertProcTbl
	 * @param key
	 * @return
	 */
	private String getDefaultDataTblDdlKey_se(String defaultKeyColumn, String alertProcTbl, int key){
		for (int i=0; i<dataTblList_se.size(); i++){
			DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblList_se.get(i);
			if (dataTblDdlBean.getAlertProcTbl().equalsIgnoreCase(alertProcTbl)){
				switch (key){
					case 1:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey1Name();
						break;
					case 2:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey2Name();
						break;
					case 3:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey3Name();
						break;
					case 4:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey4Name();
						break;
					case 5:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey5Name();
						break;
					default:
						defaultKeyColumn = dataTblDdlBean.getTblDdlKey1Name();
						break;
				}
				
				if (defaultKeyColumn!=null && !"".equals(defaultKeyColumn)){
					break;
				}
			}
		}
		return defaultKeyColumn;
	}	
	
	/**
	 * @param tblDdlName
	 * @return String, MAX(TBL_DDL_PRESCSN_FORMAT_TYPE)
	 * Underlying table: RABC_DATA_TBL_DDL
	 */	
	private String getMaxFormatTypeForTblDdlName_sw(String tblDdlName){
		String result = "";
		for (int i=0; i<maxFormatList_sw.size(); i++){
			PickList pickList = (PickList)maxFormatList_sw.get(i);
			if (pickList.getKey().equalsIgnoreCase(tblDdlName)){
				result = pickList.getValue1();
			}			
		}
		return result;
	}
	
	/**
	 * @param tblDdlName
	 * @return String, MAX(TBL_DDL_PRESCSN_FORMAT_TYPE)
	 * Underlying table: RABC_DATA_TBL_DDL
	 */	
	private String getMaxFormatTypeForTblDdlName_c2(String tblDdlName){
		String result = "";
		for (int i=0; i<maxFormatList_c2.size(); i++){
			PickList pickList = (PickList)maxFormatList_c2.get(i);
			if (pickList.getKey().equalsIgnoreCase(tblDdlName)){
				result = pickList.getValue1();
			}			
		}
		return result;
	}
	
	/**
	 * @param tblDdlName
	 * @return String, MAX(TBL_DDL_PRESCSN_FORMAT_TYPE)
	 * Underlying table: RABC_DATA_TBL_DDL
	 */	
	private String getMaxFormatTypeForTblDdlName_se(String tblDdlName){
		String result = "";
		for (int i=0; i<maxFormatList_se.size(); i++){
			PickList pickList = (PickList)maxFormatList_se.get(i);
			if (pickList.getKey().equalsIgnoreCase(tblDdlName)){
				result = pickList.getValue1();
			}			
		}
		return result;
	}
	
	/**
	 * @param region
	 * @return ArrayList of PickList objects
	 * Called method that hides getting the StaticDataLoader object.
	 */
	public static ArrayList getMouseOverList(String region){
		if(region.trim().equals("WE")){
			return getRef(region).getMouseOverList_w();
        } else if(region.trim().equals("E")){
        	return getRef(region).getMouseOverList_e();
        } else if(region.trim().equals("MW")){
        	return getRef(region).getMouseOverList_mw();
        } else if(region.trim().equals("SW")){
        	return getRef(region).getMouseOverList_sw();
        } else if(region.trim().equals("C2")){
        	return getRef(region).getMouseOverList_c2();
        } else if(region.trim().equals("SE")){
        	return getRef(region).getMouseOverList_se();	
        } else if(region.trim().equals("MB")){
        	return getRef(region).getMouseOverList_mb();	
        }else {
            throw new IllegalArgumentException("Unrecognized region: "+region);
        }
	}

	/**
	 * @return ArrayList of PickList objects, where
	 * for each PickList, key = TABLE_NAME, value1 = TABLE_DESC
	 * Underlying table: RABC_MOUSE_OVER_TBL
	 */
	private ArrayList getMouseOverList_mb(){
		return mouseOverList_mb;
	}
	
	/**
	 * @return ArrayList of PickList objects, where
	 * for each PickList, key = TABLE_NAME, value1 = TABLE_DESC
	 * Underlying table: RABC_MOUSE_OVER_TBL
	 */
	private ArrayList getMouseOverList_w(){
		return mouseOverList_w;
	}
	
	/**
	 * @return ArrayList of PickList objects, where
	 * for each PickList, key = TABLE_NAME, value1 = TABLE_DESC
	 * Underlying table: RABC_MOUSE_OVER_TBL
	 */
	private ArrayList getMouseOverList_e(){
		return mouseOverList_e;
	}
	
	/**
	 * @return ArrayList of PickList objects, where
	 * for each PickList, key = TABLE_NAME, value1 = TABLE_DESC
	 * Underlying table: RABC_MOUSE_OVER_TBL
	 */
	private ArrayList getMouseOverList_sw(){
		return mouseOverList_sw;
	}
	
	/**
	 * @return ArrayList of PickList objects, where
	 * for each PickList, key = TABLE_NAME, value1 = TABLE_DESC
	 * Underlying table: RABC_MOUSE_OVER_TBL
	 */
	private ArrayList getMouseOverList_mw(){
		return mouseOverList_mw;
	}
	
	/**
	 * @return ArrayList of PickList objects, where
	 * for each PickList, key = TABLE_NAME, value1 = TABLE_DESC
	 * Underlying table: RABC_MOUSE_OVER_TBL
	 */
	private ArrayList getMouseOverList_c2(){
		return mouseOverList_c2;
	}
	
	/**
	 * @return ArrayList of PickList objects, where
	 * for each PickList, key = TABLE_NAME, value1 = TABLE_DESC
	 * Underlying table: RABC_MOUSE_OVER_TBL
	 */
	private ArrayList getMouseOverList_se(){
		return mouseOverList_se;
	}
	
	/**
	 * @param region
	 * @return ArrayList of PickList objects
	 * Called method that hides getting the StaticDataLoader object.
	 */
	public static ArrayList getAlertRuleList(String region){
		if(region.trim().equals("WE")){
        	return getRef(region).getAlertRuleList_w();
        }else if(region.trim().equals("E")){
        	return getRef(region).getAlertRuleList_e();
        }else if(region.trim().equals("SW")){
        	return getRef(region).getAlertRuleList_sw();
        }else if(region.trim().equals("MW")){
        	return getRef(region).getAlertRuleList_mw();
        }else if(region.trim().equals("C2")){
        	return getRef(region).getAlertRuleList_c2();
        }else if(region.trim().equals("SE")){
        	return getRef(region).getAlertRuleList_se();
        }else if(region.trim().equals("MB")){
        	return getRef(region).getAlertRuleList_mb();
        }else {
            throw new IllegalArgumentException("Unrecognized region: "+region);
        }
	}
	
	/**
	 * @return ArrayList of PickList objects, where
	 * for each PickList, key = PARTI_REF_ID, value1 = ALERT_RULE
	 * Underlying table: RABC_ALERT_RULE
	 */
	private ArrayList getAlertRuleList_mb(){
		return alertRuleList_mb;
	}
	private ArrayList getAlertRuleList_w(){
		return alertRuleList_w;
	}
	private ArrayList getAlertRuleList_e(){
		return alertRuleList_e;
	}
	private ArrayList getAlertRuleList_sw(){
		return alertRuleList_sw;
	}
	private ArrayList getAlertRuleList_mw(){
		return alertRuleList_mw;
	}
	private ArrayList getAlertRuleList_c2(){
		return alertRuleList_c2;
	}	
	private ArrayList getAlertRuleList_se(){
		return alertRuleList_se;
	}
	
	/**
	 * @param region
	 * @return ArrayList of PickList objects
	 * Called method that hides getting the StaticDataLoader object.
	 */
	public static ArrayList getRabcTableList(String region){
		if(region.trim().equals("WE")){
			return getRef(region).getRabcTableList_w();
        } else if(region.trim().equals("E")){
        	return getRef(region).getRabcTableList_e();
        } else if(region.trim().equals("MW")){
        	return getRef(region).getRabcTableList_mw();
        } else if(region.trim().equals("SW")){
        	return getRef(region).getRabcTableList_sw();
        } else if(region.trim().equals("C2")){
        	return getRef(region).getRabcTableList_c2();
        } else if(region.trim().equals("SE")){
        	return getRef(region).getRabcTableList_se();	
        }else if(region.trim().equals("MB")){
        	return getRef(region).getRabcTableList_mb();	
        }else {
            throw new IllegalArgumentException("Unrecognized region: "+region);
        }
	}

	/**
	 * @return ArrayList of PickList objects, where
	 * for each PickList, key = ALERT_PROC_TBL, value1 = TBL_DESC, value2 = TBL_NODE, value3 = PARTI_REF_ID_IND
	 * Underlying table: RABC_TABLE
	 */
	private ArrayList getRabcTableList_mb(){
		return rabcTableList_mb;
	}
	/**
	 * @return ArrayList of PickList objects, where
	 * for each PickList, key = ALERT_PROC_TBL, value1 = TBL_DESC, value2 = TBL_NODE, value3 = PARTI_REF_ID_IND
	 * Underlying table: RABC_TABLE
	 */
	private ArrayList getRabcTableList_w(){
		return rabcTableList_w;
	}
	
	/**
	 * @return ArrayList of PickList objects, where
	 * for each PickList, key = ALERT_PROC_TBL, value1 = TBL_DESC, value2 = TBL_NODE, value3 = PARTI_REF_ID_IND
	 * Underlying table: RABC_TABLE
	 */
	private ArrayList getRabcTableList_e(){
		return rabcTableList_e;
	}
	
	/**
	 * @return ArrayList of PickList objects, where
	 * for each PickList, key = ALERT_PROC_TBL, value1 = TBL_DESC, value2 = TBL_NODE, value3 = PARTI_REF_ID_IND
	 * Underlying table: RABC_TABLE
	 */
	private ArrayList getRabcTableList_sw(){
		return rabcTableList_sw;
	}	
	
	/**
	 * @return ArrayList of PickList objects, where
	 * for each PickList, key = ALERT_PROC_TBL, value1 = TBL_DESC, value2 = TBL_NODE, value3 = PARTI_REF_ID_IND
	 * Underlying table: RABC_TABLE
	 */
	private ArrayList getRabcTableList_mw(){
		return rabcTableList_mw;
	}	
	
	/**
	 * @return ArrayList of PickList objects, where
	 * for each PickList, key = ALERT_PROC_TBL, value1 = TBL_DESC, value2 = TBL_NODE, value3 = PARTI_REF_ID_IND
	 * Underlying table: RABC_TABLE
	 */
	private ArrayList getRabcTableList_c2(){
		return rabcTableList_c2;
	}
	
	/**
	 * @return ArrayList of PickList objects, where
	 * for each PickList, key = ALERT_PROC_TBL, value1 = TBL_DESC, value2 = TBL_NODE, value3 = PARTI_REF_ID_IND
	 * Underlying table: RABC_TABLE
	 */
	private ArrayList getRabcTableList_se(){
		return rabcTableList_se;
	}	
	
	/**
	 * @param columnName
	 * @param region
	 * @return boolean
	 * Called method that hides getting the StaticDataLoader object.
	 */
	public static boolean isNumberColumn(String columnName, String region){
		if(region.trim().equals("WE")){
			return getRef(region).isNumberColumn_w(columnName);
        } else if(region.trim().equals("E")){
        	return getRef(region).isNumberColumn_e(columnName);
        } else if(region.trim().equals("MW")){
        	return getRef(region).isNumberColumn_mw(columnName);
        } else if(region.trim().equals("SW")){
        	return getRef(region).isNumberColumn_sw(columnName);
        } else if(region.trim().equals("C2")){
        	return getRef(region).isNumberColumn_c2(columnName);
        } else if(region.trim().equals("SE")){
        	return getRef(region).isNumberColumn_se(columnName);	
        }else if(region.trim().equals("MB")){
        	return getRef(region).isNumberColumn_mb(columnName);	
        }else {
            throw new IllegalArgumentException("Unrecognized region: "+region);
        }
	}

	/**
	 * @param columnName
	 * @return true if columnName is a NUMBER type column, otherwise false
	 * Underlying table: USER_TAB_COLUMNS
	 */	
	private boolean isNumberColumn_mb(String columnName){
		return numberColumnSet_mb.contains(columnName.toUpperCase());
	}
	/**
	 * @param columnName
	 * @return true if columnName is a NUMBER type column, otherwise false
	 * Underlying table: USER_TAB_COLUMNS
	 */	
	private boolean isNumberColumn_w(String columnName){
		return numberColumnSet_w.contains(columnName.toUpperCase());
	}
	
	/**
	 * @param columnName
	 * @return true if columnName is a NUMBER type column, otherwise false
	 * Underlying table: USER_TAB_COLUMNS
	 */	
	private boolean isNumberColumn_e(String columnName){
		return numberColumnSet_e.contains(columnName.toUpperCase());
	}
	
	/**
	 * @param columnName
	 * @return true if columnName is a NUMBER type column, otherwise false
	 * Underlying table: USER_TAB_COLUMNS
	 */	
	private boolean isNumberColumn_sw(String columnName){
		return numberColumnSet_sw.contains(columnName.toUpperCase());
	}
	
	/**
	 * @param columnName
	 * @return true if columnName is a NUMBER type column, otherwise false
	 * Underlying table: USER_TAB_COLUMNS
	 */	
	private boolean isNumberColumn_mw(String columnName){
		return numberColumnSet_mw.contains(columnName.toUpperCase());
	}
	
	/**
	 * @param columnName
	 * @return true if columnName is a NUMBER type column, otherwise false
	 * Underlying table: USER_TAB_COLUMNS
	 */	
	private boolean isNumberColumn_c2(String columnName){
		return numberColumnSet_c2.contains(columnName.toUpperCase());
	}
	
	/**
	 * @param columnName
	 * @return true if columnName is a NUMBER type column, otherwise false
	 * Underlying table: USER_TAB_COLUMNS
	 */	
	private boolean isNumberColumn_se(String columnName){
		return numberColumnSet_se.contains(columnName.toUpperCase());
	}
	
	/**
	 * @param columnName
	 * @param region
	 * @return boolean
	 * Called method that hides getting the StaticDataLoader object.
	 */
	public static boolean isDateColumn(String columnName, String region){
		if(region.trim().equals("WE")){
			return getRef(region).isDateColumn_w(columnName);
        } else if(region.trim().equals("E")){
        	return getRef(region).isDateColumn_e(columnName);
        } else if(region.trim().equals("MW")){
        	return getRef(region).isDateColumn_mw(columnName);
        } else if(region.trim().equals("SW")){
        	return getRef(region).isDateColumn_sw(columnName);
        } else if(region.trim().equals("C2")){
        	return getRef(region).isDateColumn_c2(columnName);
        } else if(region.trim().equals("SE")){
        	return getRef(region).isDateColumn_se(columnName);	
        }else if(region.trim().equals("MB")){
        	return getRef(region).isDateColumn_mb(columnName);	
        }else {
            throw new IllegalArgumentException("Unrecognized region: "+region);
        }
	}
	
	/**
	 * @param columnName
	 * @return true if columnName is a DATE type column, otherwise false
	 * Underlying table: USER_TAB_COLUMNS
	 */	
	private boolean isDateColumn_mb(String columnName){
		return dateColumnSet_mb.contains(columnName.toUpperCase());
	}
	/**
	 * @param columnName
	 * @return true if columnName is a DATE type column, otherwise false
	 * Underlying table: USER_TAB_COLUMNS
	 */	
	private boolean isDateColumn_w(String columnName){
		return dateColumnSet_w.contains(columnName.toUpperCase());
	}
	
	/**
	 * @param columnName
	 * @return true if columnName is a DATE type column, otherwise false
	 * Underlying table: USER_TAB_COLUMNS
	 */	
	private boolean isDateColumn_e(String columnName){
		return dateColumnSet_e.contains(columnName.toUpperCase());
	}
	
	/**
	 * @param columnName
	 * @return true if columnName is a DATE type column, otherwise false
	 * Underlying table: USER_TAB_COLUMNS
	 */	
	private boolean isDateColumn_sw(String columnName){
		return dateColumnSet_sw.contains(columnName.toUpperCase());
	}	
	
	/**
	 * @param columnName
	 * @return true if columnName is a DATE type column, otherwise false
	 * Underlying table: USER_TAB_COLUMNS
	 */	
	private boolean isDateColumn_mw(String columnName){
		return dateColumnSet_mw.contains(columnName.toUpperCase());
	}	
	
	/**
	 * @param columnName
	 * @return true if columnName is a DATE type column, otherwise false
	 * Underlying table: USER_TAB_COLUMNS
	 */	
	private boolean isDateColumn_c2(String columnName){
		return dateColumnSet_c2.contains(columnName.toUpperCase());
	}
	
	/**
	 * @param columnName
	 * @return true if columnName is a DATE type column, otherwise false
	 * Underlying table: USER_TAB_COLUMNS
	 */	
	private boolean isDateColumn_se(String columnName){
		return dateColumnSet_se.contains(columnName.toUpperCase());
	}	
	
	/**
	 * @param region
	 * @return list of bill rounds for input region
	 * Called method that hides getting the StaticDataLoader object.
	 */
	public static ArrayList getBillRndByRegion(String region) throws IllegalArgumentException {
		ArrayList list = new ArrayList();
		if(region.trim().equals("WE")){
			return getRef(region).getBillRndByRegion_w(list, region);
        } else if(region.trim().equals("E")){
        	return getRef(region).getBillRndByRegion_e(list, region);
        } else if(region.trim().equals("MW")){
        	return getRef(region).getBillRndByRegion_mw(list, region);
        } else if(region.trim().equals("SW")){
        	return getRef(region).getBillRndByRegion_sw(list, region);
        } else if(region.trim().equals("C2")){
        	return getRef(region).getBillRndByRegion_c2(list, region);
        } else if(region.trim().equals("SE")){
        	return getRef(region).getBillRndByRegion_se(list, region);	
        }else if(region.trim().equals("MB")){
        	return getRef(region).getBillRndByRegion_mb(list, region);	
        }else {
            throw new IllegalArgumentException("Unrecognized region: " + region);
        }
	}

	/**
	 * @param list
	 * @param region
	 * @return list of bill rounds for input region
	 * Underlying table: RABC_REGION_BILL_RND
	 */
	private ArrayList getBillRndByRegion_mb(ArrayList list, String region) {
		for (int i=0; i<billRndList_mb.size(); i++){
			PickList pickList = (PickList)billRndList_mb.get(i);
			if (pickList.getKey().equalsIgnoreCase(region)){
				list.add(pickList.getValue1());
			}			
		}
		return list;
	}
	/**
	 * @param list
	 * @param region
	 * @return list of bill rounds for input region
	 * Underlying table: RABC_REGION_BILL_RND
	 */
	private ArrayList getBillRndByRegion_w(ArrayList list, String region) {
		for (int i=0; i<billRndList_w.size(); i++){
			PickList pickList = (PickList)billRndList_w.get(i);
			if (pickList.getKey().equalsIgnoreCase(region)){
				list.add(pickList.getValue1());
			}			
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param region
	 * @return list of bill rounds for input region
	 * Underlying table: RABC_REGION_BILL_RND
	 */
	private ArrayList getBillRndByRegion_e(ArrayList list, String region) {
		for (int i=0; i<billRndList_e.size(); i++){
			PickList pickList = (PickList)billRndList_e.get(i);
			if (pickList.getKey().equalsIgnoreCase(region)){
				list.add(pickList.getValue1());
			}			
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param region
	 * @return list of bill rounds for input region
	 * Underlying table: RABC_REGION_BILL_RND
	 */
	private ArrayList getBillRndByRegion_mw(ArrayList list, String region) {
		for (int i=0; i<billRndList_mw.size(); i++){
			PickList pickList = (PickList)billRndList_mw.get(i);
			if (pickList.getKey().equalsIgnoreCase(region)){
				list.add(pickList.getValue1());
			}			
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param region
	 * @return list of bill rounds for input region
	 * Underlying table: RABC_REGION_BILL_RND
	 */
	private ArrayList getBillRndByRegion_sw(ArrayList list, String region) {
		for (int i=0; i<billRndList_sw.size(); i++){
			PickList pickList = (PickList)billRndList_sw.get(i);
			if (pickList.getKey().equalsIgnoreCase(region)){
				list.add(pickList.getValue1());
			}			
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param region
	 * @return list of bill rounds for input region
	 * Underlying table: RABC_REGION_BILL_RND
	 */
	private ArrayList getBillRndByRegion_c2(ArrayList list, String region) {
		for (int i=0; i<billRndList_c2.size(); i++){
			PickList pickList = (PickList)billRndList_c2.get(i);
			if (pickList.getKey().equalsIgnoreCase(region)){
				list.add(pickList.getValue1());
			}			
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param region
	 * @return list of bill rounds for input region
	 * Underlying table: RABC_REGION_BILL_RND
	 */
	private ArrayList getBillRndByRegion_se(ArrayList list, String region) {
		for (int i=0; i<billRndList_se.size(); i++){
			PickList pickList = (PickList)billRndList_se.get(i);
			if (pickList.getKey().equalsIgnoreCase(region)){
				list.add(pickList.getValue1());
			}			
		}
		return list;
	}
	
	/**
	 * @param region
	 * @return list of processes
	 * Called method that hides getting the StaticDataLoader object.
	 */
	public static ArrayList getProcesses(String region) throws IllegalArgumentException {
		ArrayList list = new ArrayList();
		if(region.trim().equals("WE")){
			return getRef(region).getProcesses_w(list);
        } else if(region.trim().equals("E")){
        	return getRef(region).getProcesses_e(list);
        } else if(region.trim().equals("MW")){
        	return getRef(region).getProcesses_mw(list);
        } else if(region.trim().equals("SW")){
        	return getRef(region).getProcesses_sw(list);
        } else if(region.trim().equals("C2")){
        	return getRef(region).getProcesses_c2(list);
        } else if(region.trim().equals("SE")){
        	return getRef(region).getProcesses_se(list);	
        } else if(region.trim().equals("EN")){
        	return getRef(region).getProcesses_ent(list);
        } else if(region.trim().equals("MB")){
        	return getRef(region).getProcesses_mb(list);
        } else {
            throw new IllegalArgumentException("Unrecognized region: " + region);
        }
	}

	/**
	 * @param list
	 * @return list of processes
	 * Underlying table: RABC_PROCESS
	 */
	private ArrayList getProcesses_mb(ArrayList list) {
		for (int i=0; i<processList_mb.size(); i++){
			list.add(((PickList)processList_mb.get(i)).getKey());
		}
		return list;
	}
	/**
	 * @param list
	 * @return list of processes
	 * Underlying table: RABC_PROCESS
	 */
	private ArrayList getProcesses_w(ArrayList list) {
		for (int i=0; i<processList_w.size(); i++){
			list.add(((PickList)processList_w.get(i)).getKey());
		}
		return list;
	}
	
	/**
	 * @param list
	 * @return list of processes
	 * Underlying table: RABC_PROCESS
	 */
	private ArrayList getProcesses_e(ArrayList list) {
		for (int i=0; i<processList_e.size(); i++){
			list.add(((PickList)processList_e.get(i)).getKey());
		}
		return list;
	}
	
	/**
	 * @param list
	 * @return list of processes
	 * Underlying table: RABC_PROCESS
	 */
	private ArrayList getProcesses_mw(ArrayList list) {
		for (int i=0; i<processList_mw.size(); i++){
			list.add(((PickList)processList_mw.get(i)).getKey());
		}
		return list;
	}
	
	/**
	 * @param list
	 * @return list of processes
	 * Underlying table: RABC_PROCESS
	 */
	private ArrayList getProcesses_sw(ArrayList list) {
		for (int i=0; i<processList_sw.size(); i++){
			list.add(((PickList)processList_sw.get(i)).getKey());
		}
		return list;
	}
	
	/**
	 * @param list
	 * @return list of processes
	 * Underlying table: RABC_PROCESS
	 */
	private ArrayList getProcesses_c2(ArrayList list) {
		for (int i=0; i<processList_c2.size(); i++){
			list.add(((PickList)processList_c2.get(i)).getKey());
		}
		return list;
	}
	
	/**
	 * @param list
	 * @return list of processes
	 * Underlying table: RABC_PROCESS
	 */
	private ArrayList getProcesses_se(ArrayList list) {
		for (int i=0; i<processList_se.size(); i++){
			list.add(((PickList)processList_se.get(i)).getKey());
		}
		return list;
	}
	
	/**
	 * @param list
	 * @return list of processes
	 * Underlying table: RABC_PROCESS
	 */
	private ArrayList getProcesses_ent(ArrayList list) {
		for (int i=0; i<processList_ent.size(); i++){
			list.add(((PickList)processList_ent.get(i)).getKey());
		}
		return list;
	}
	
	/**
	 * @param region
	 * @return list of distinct processes
	 * Called method that hides getting the StaticDataLoader object.
	 */
	public static ArrayList getDistinctProcesses(String region) throws IllegalArgumentException {
		ArrayList list = new ArrayList();
		if(region.trim().equals("WE")){
			return getRef(region).getDistinctProcesses_w(list);
        } else if(region.trim().equals("E")){
        	return getRef(region).getDistinctProcesses_e(list);
        } else if(region.trim().equals("MW")){
        	return getRef(region).getDistinctProcesses_mw(list);
        } else if(region.trim().equals("SW")){
        	return getRef(region).getDistinctProcesses_sw(list);
        } else if(region.trim().equals("C2")){
        	return getRef(region).getDistinctProcesses_c2(list);
        } else if(region.trim().equals("SE")){
        	return getRef(region).getDistinctProcesses_se(list);	
        } else if(region.trim().equals("EN")){
        	return getRef(region).getDistinctProcesses_ent(list);
        } else if(region.trim().equals("MB")){
        	return getRef(region).getDistinctProcesses_mb(list);
        }else {
            throw new IllegalArgumentException("Unrecognized region: " + region);
        }
	}
	
	/**
	 * @param list
	 * @return list of distinct processes
	 * Underlying table: RABC_PROCESS
	 */
	private ArrayList getDistinctProcesses_mb(ArrayList list) {
		for (int i=0; i<processList_mb.size(); i++){
			if (!list.contains(((PickList)processList_mb.get(i)).getKey())) {
				list.add(((PickList)processList_mb.get(i)).getKey());
			}
		}
		return list;
	}
	
	/**
	 * @param list
	 * @return list of distinct processes
	 * Underlying table: RABC_PROCESS
	 */
	private ArrayList getDistinctProcesses_w(ArrayList list) {
		for (int i=0; i<processList_w.size(); i++){
			if (!list.contains(((PickList)processList_w.get(i)).getKey())) {
				list.add(((PickList)processList_w.get(i)).getKey());
			}
		}
		return list;
	}
	
	/**
	 * @param list
	 * @return list of distinct processes
	 * Underlying table: RABC_PROCESS
	 */
	private ArrayList getDistinctProcesses_e(ArrayList list) {
		for (int i=0; i<processList_e.size(); i++){
			if (!list.contains(((PickList)processList_e.get(i)).getKey())) {
				list.add(((PickList)processList_e.get(i)).getKey());
			}
		}
		return list;
	}
	
	/**
	 * @param list
	 * @return list of distinct processes
	 * Underlying table: RABC_PROCESS
	 */
	private ArrayList getDistinctProcesses_mw(ArrayList list) {
		for (int i=0; i<processList_mw.size(); i++){
			if (!list.contains(((PickList)processList_mw.get(i)).getKey())) {
				list.add(((PickList)processList_mw.get(i)).getKey());
			}
		}
		return list;
	}
	
	/**
	 * @param list
	 * @return list of distinct processes
	 * Underlying table: RABC_PROCESS
	 */
	private ArrayList getDistinctProcesses_sw(ArrayList list) {
		for (int i=0; i<processList_sw.size(); i++){
			if (!list.contains(((PickList)processList_sw.get(i)).getKey())) {
				list.add(((PickList)processList_sw.get(i)).getKey());
			}
		}
		return list;
	}
	
	/**
	 * @param list
	 * @return list of distinct processes
	 * Underlying table: RABC_PROCESS
	 */
	private ArrayList getDistinctProcesses_c2(ArrayList list) {
		for (int i=0; i<processList_c2.size(); i++){
			if (!list.contains(((PickList)processList_c2.get(i)).getKey())) {
				list.add(((PickList)processList_c2.get(i)).getKey());
			}
		}
		return list;
	}
	
	/**
	 * @param list
	 * @return list of distinct processes
	 * Underlying table: RABC_PROCESS
	 */
	private ArrayList getDistinctProcesses_se(ArrayList list) {
		for (int i=0; i<processList_se.size(); i++){
			if (!list.contains(((PickList)processList_se.get(i)).getKey())) {
				list.add(((PickList)processList_se.get(i)).getKey());
			}
		}
		return list;
	}
	
		/**
	 * @param list
	 * @return list of distinct processes
	 * Underlying table: RABC_PROCESS
	 */
	private ArrayList getDistinctProcesses_ent(ArrayList list) {
		for (int i=0; i<processList_ent.size(); i++){
			if (!list.contains(((PickList)processList_ent.get(i)).getKey())) {
				list.add(((PickList)processList_ent.get(i)).getKey());
			}
		}
		return list;
	}
	
	/**
	 * @param process
	 * @param region
	 * @return list of control points for input process
	 * Called method that hides getting the StaticDataLoader object.
	 */
	public static ArrayList getCntrlPtByProcess(String process, String region) throws IllegalArgumentException {
		ArrayList list = new ArrayList();
		if(region.trim().equals("WE")){
			return getRef(region).getCntrlPtByProcess_w(list, process);
        } else if(region.trim().equals("E")){
        	return getRef(region).getCntrlPtByProcess_e(list, process);
        } else if(region.trim().equals("MW")){
        	return getRef(region).getCntrlPtByProcess_mw(list, process);
        } else if(region.trim().equals("SW")){
        	return getRef(region).getCntrlPtByProcess_sw(list, process);
        } else if(region.trim().equals("C2")){
        	return getRef(region).getCntrlPtByProcess_c2(list, process);
        } else if(region.trim().equals("SE")){
        	return getRef(region).getCntrlPtByProcess_se(list, process);	
        } else if(region.trim().equals("EN")){
        	return getRef(region).getCntrlPtByProcess_ent(list, process);
        } else if(region.trim().equals("MB")){
        	return getRef(region).getCntrlPtByProcess_mb(list, process);
        } else {
            throw new IllegalArgumentException("Unrecognized region: " + region);
        }
	}	
	
	/**
	 * @param list
	 * @param process
	 * @return list of control points for input process
	 * Underlying table: RABC_PROCESS
	 */
	private ArrayList getCntrlPtByProcess_mb(ArrayList list, String process) {
		for (int i=0; i<processList_mb.size(); i++){
			PickList pickList = (PickList)processList_mb.get(i);
			if (pickList.getKey().equalsIgnoreCase(process)){
				list.add(pickList.getValue1());
			}			
		}
		return list;
	}
	/**
	 * @param list
	 * @param process
	 * @return list of control points for input process
	 * Underlying table: RABC_PROCESS
	 */
	private ArrayList getCntrlPtByProcess_w(ArrayList list, String process) {
		for (int i=0; i<processList_w.size(); i++){
			PickList pickList = (PickList)processList_w.get(i);
			if (pickList.getKey().equalsIgnoreCase(process)){
				list.add(pickList.getValue1());
			}			
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param process
	 * @return list of control points for input process
	 * Underlying table: RABC_PROCESS
	 */
	private ArrayList getCntrlPtByProcess_e(ArrayList list, String process) {
		for (int i=0; i<processList_e.size(); i++){
			PickList pickList = (PickList)processList_e.get(i);
			if (pickList.getKey().equalsIgnoreCase(process)){
				list.add(pickList.getValue1());
			}			
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param process
	 * @return list of control points for input process
	 * Underlying table: RABC_PROCESS
	 */
	private ArrayList getCntrlPtByProcess_mw(ArrayList list, String process) {
		for (int i=0; i<processList_mw.size(); i++){
			PickList pickList = (PickList)processList_mw.get(i);
			if (pickList.getKey().equalsIgnoreCase(process)){
				list.add(pickList.getValue1());
			}			
		}
		return list;
	}	
	
	/**
	 * @param list
	 * @param process
	 * @return list of control points for input process
	 * Underlying table: RABC_PROCESS
	 */
	private ArrayList getCntrlPtByProcess_sw(ArrayList list, String process) {
		for (int i=0; i<processList_sw.size(); i++){
			PickList pickList = (PickList)processList_sw.get(i);
			if (pickList.getKey().equalsIgnoreCase(process)){
				list.add(pickList.getValue1());
			}			
		}
		return list;
	}	
	
	/**
	 * @param list
	 * @param process
	 * @return list of control points for input process
	 * Underlying table: RABC_PROCESS
	 */
	private ArrayList getCntrlPtByProcess_c2(ArrayList list, String process) {
		for (int i=0; i<processList_c2.size(); i++){
			PickList pickList = (PickList)processList_c2.get(i);
			if (pickList.getKey().equalsIgnoreCase(process)){
				list.add(pickList.getValue1());
			}			
		}
		return list;
	}
	
	/**
	 * @param list
	 * @param process
	 * @return list of control points for input process
	 * Underlying table: RABC_PROCESS
	 */
	private ArrayList getCntrlPtByProcess_se(ArrayList list, String process) {
		for (int i=0; i<processList_se.size(); i++){
			PickList pickList = (PickList)processList_se.get(i);
			if (pickList.getKey().equalsIgnoreCase(process)){
				list.add(pickList.getValue1());
			}			
		}
		return list;
	}
	
		/**
	 * @param list
	 * @param process
	 * @return list of control points for input process
	 * Underlying table: RABC_PROCESS
	 */
	private ArrayList getCntrlPtByProcess_ent(ArrayList list, String process) {
		for (int i=0; i<processList_ent.size(); i++){
			PickList pickList = (PickList)processList_ent.get(i);
			if (pickList.getKey().equalsIgnoreCase(process)){
				list.add(pickList.getValue1());
			}			
		}
		return list;
	}
	
	/**
	 * @param region
	 * @return String of bill rounds
	 * Called method that hides getting the StaticDataLoader object.
	 */
	public static String getBillRounds(String region){
		if(region.trim().equals("WE")){
			return getRef(region).getBillRounds_w();
        } else if(region.trim().equals("E")){
        	return getRef(region).getBillRounds_e();
        } else if(region.trim().equals("MW")){
        	return getRef(region).getBillRounds_mw();
        } else if(region.trim().equals("SW")){
        	return getRef(region).getBillRounds_sw();
        } else if(region.trim().equals("C2")){
        	return getRef(region).getBillRounds_c2();
        } else if(region.trim().equals("SE")){
        	return getRef(region).getBillRounds_se();	
        } else if(region.trim().equals("MB")){
        	return getRef(region).getBillRounds_mb();	
        } else if (region.trim().equals("EN")) {
        	return "";
		} else {
            throw new IllegalArgumentException("Unrecognized region: "+region);
        }
	}
	
	/**
	 * @param region
	 * @return String of loaded data dates
	 * Called method that hides getting the StaticDataLoader object.
	 */
	public static String getLoadedDataDatesByRegion(String region) {
		if(region.trim().equals("C2")){
			return getRef(region).getLoadedDataDates_c2();
        }else {
            return "";
        }	
	}
	
	/**
	 * @return Returns the billRounds_mb.
	 */
	private String getBillRounds_mb() {
		return billRounds_mb;
	}
	/**
	 * @return Returns the billRounds_w.
	 */
	private String getBillRounds_w() {
		return billRounds_w;
	}
	
	/**
	 * @return Returns the billRounds_e.
	 */
	private String getBillRounds_e() {
		return billRounds_e;
	}
	
	/**
	 * @return Returns the billRounds_sw.
	 */
	private String getBillRounds_sw() {
		return billRounds_sw;
	}
	
	/**
	 * @return Returns the billRounds_mw.
	 */
	private String getBillRounds_mw() {
		return billRounds_mw;
	}
	
	/**
	 * @return Returns the billRounds_c2.
	 */
	private String getBillRounds_c2() {
		return billRounds_c2;
	}
	
	/**
	 * @return Returns the billRounds_se.
	 */
	private String getBillRounds_se() {
		return billRounds_se;
	}
	
	/**
	 * @return Returns loadedDataDates
	 */
	private String getLoadedDataDates_c2() {
		return loadedDataDates_c2;
	}
	
	/**
	 * @param region
	 * @return String of bill rounds
	 * Called method that hides getting the StaticDataLoader object.
	 */
	public static String getHolidayIndicators(String region){
		if(region.trim().equals("WE")){
			return getRef(region).getHolidayIndicators_w();
        } else if(region.trim().equals("E")){
        	return getRef(region).getHolidayIndicators_e();
        } else if(region.trim().equals("MW")){
        	return getRef(region).getHolidayIndicators_mw();
        } else if(region.trim().equals("SW")){
        	return getRef(region).getHolidayIndicators_sw();
        } else if(region.trim().equals("C2")){
        	return getRef(region).getHolidayIndicators_c2();
        } else if(region.trim().equals("SE")){
        	return getRef(region).getHolidayIndicators_se();	
        } else if(region.trim().equals("EN")){
        	return "";
        } else if(region.trim().equals("MB")){
        	return getRef(region).getHolidayIndicators_mb();	
        }else {
            throw new IllegalArgumentException("Unrecognized region: "+region);
        }
	}

	/**
	 * @return Returns the holidayIndicators_w.
	 */
	private String getHolidayIndicators_mb() {
		return holidayIndicators_mb;
	}
	
	/**
	 * @return Returns the holidayIndicators_w.
	 */
	private String getHolidayIndicators_w() {
		return holidayIndicators_w;
	}
	
	/**
	 * @return Returns the holidayIndicators_e.
	 */
	private String getHolidayIndicators_e() {
		return holidayIndicators_e;
	}
	
	/**
	 * @return Returns the holidayIndicators_sw.
	 */
	private String getHolidayIndicators_sw() {
		return holidayIndicators_sw;
	}
	
	/**
	 * @return Returns the holidayIndicators_mw.
	 */
	private String getHolidayIndicators_mw() {
		return holidayIndicators_mw;
	}
	
	/**
	 * @return Returns the holidayIndicators_mw.
	 */
	private String getHolidayIndicators_c2() {
		return holidayIndicators_c2;
	}
	
	/**
	 * @return Returns the holidayIndicators_se.
	 */
	private String getHolidayIndicators_se() {
		return holidayIndicators_se;
	}
	
	
	/**
	 * @param region
	 * @return String of bill rounds
	 * Called method that hides getting the StaticDataLoader object.
	 */
	public static String getProcDates(String region){
		if(region.trim().equals("WE")){
			return getRef(region).getProcDates_w();
        } else if(region.trim().equals("E")){
        	return getRef(region).getProcDates_e();
        } else if(region.trim().equals("MW")){
        	return getRef(region).getProcDates_mw();
        } else if(region.trim().equals("SW")){
        	return getRef(region).getProcDates_sw();
        } else if(region.trim().equals("C2")){
        	return getRef(region).getProcDates_c2();
        } else if(region.trim().equals("SE")){
        	return getRef(region).getProcDates_se();	
        } else if(region.trim().equals("EN")){
        	return "";
        } else if(region.trim().equals("MB")){
        	return getRef(region).getProcDates_mb();	
        }else {
            throw new IllegalArgumentException("Unrecognized region: "+region);
        }
	}
	
	
	/**
	 * @return Returns the procDates_mb.
	 */
	private String getProcDates_mb() {
		return procDates_mb;
	}
	/**
	 * @return Returns the procDates_w.
	 */
	private String getProcDates_w() {
		return procDates_w;
	}
	
	/**
	 * @return Returns the procDates_e.
	 */
	private String getProcDates_e() {
		return procDates_e;
	}
	
	/**
	 * @return Returns the procDates_sw.
	 */
	private String getProcDates_sw() {
		return procDates_sw;
	}
	
	/**
	 * @return Returns the procDates_mw.
	 */
	private String getProcDates_mw() {
		return procDates_mw;
	}
	
	/**
	 * @return Returns the procDates_c2.
	 */
	private String getProcDates_c2() {
		return procDates_c2;
	}
	
	/**
	 * @return Returns the procDates_se.
	 */
	private String getProcDates_se() {
		return procDates_se;
	}
	
	/**
	 * @return the regionList_ent
	 */
	public static ArrayList getRegionList_ent() {
		return getRef("EN").regionList_ent;
	}
	
}
