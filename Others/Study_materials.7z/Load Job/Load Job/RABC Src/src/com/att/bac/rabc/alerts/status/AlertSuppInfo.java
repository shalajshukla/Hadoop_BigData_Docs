/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.status;

/**
 * This is a Data Object to represent RABC_ALERT_SUPP_INFO table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class AlertSuppInfo {
	private int msgNum;
	private int suppSeqNum;
	private String suppPresnName;
	private String suppPicLink;
	private int suppData;

	/**
	 * @return Returns the MsgNum.
	 */
	public int getMsgNum() {
		return msgNum;
	}
	/**
	 * @return Returns the SuppSeqNum.
	 */
	public int getSuppSeqNum() {
		return suppSeqNum;
	}
	/**
	 * @return Returns the SuppPresnName.
	 */
	public String getSuppPresnName() {
		return suppPresnName;
	}
	/**
	 * @return Returns the SuppPicLink.
	 */
	public String getSuppPicLink() {
		return suppPicLink;
	}
	/**
	 * @return Returns the SuppData.
	 */
	public int getSuppData() {
		return suppData;
	}

	/**
	 * @param MsgNum The msgNum to set.
	 */
	public void setMsgNum(int msgNum) {
		this.msgNum = msgNum;
	}
	/**
	 * @param SuppSeqNum The suppSeqNum to set.
	 */
	public void setSuppSeqNum(int suppSeqNum) {
		this.suppSeqNum = suppSeqNum;
	}
	/**
	 * @param SuppPresnName The suppPresnName to set.
	 */
	public void setSuppPresnName(String suppPresnName) {
		this.suppPresnName = suppPresnName;
	}
	/**
	 * @param SuppPicLink The suppPicLink to set.
	 */
	public void setSuppPicLink(String suppPicLink) {
		this.suppPicLink = suppPicLink;
	}
	/**
	 * @param SuppData The suppData to set.
	 */
	public void setSuppData(int suppData) {
		this.suppData = suppData;
	}
}
