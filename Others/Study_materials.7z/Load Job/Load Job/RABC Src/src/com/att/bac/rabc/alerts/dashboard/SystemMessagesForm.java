/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/

package com.att.bac.rabc.alerts.dashboard;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;

import com.att.bac.rabc.SortedForm;

/**
 * This class represents a Form Bean  for the System messages Component.
 * 
 * @author Abhilash - AC6957
 */
public class SystemMessagesForm extends SortedForm {
	private String dateType = "run";
	//private String startDate = null;
	//private String endDate = null;
	private int qryResultCt;
	private List systemMessagesList = new ArrayList();
	private SystemMessagesParameters systemMessagesParameters ;
	private String emailRecipients;
	private int pageshow;
	
	private String statusColor;
	
	private String startDate;
	private String endDate;
	
	/*
	 * Variables added for calendar page
	 */
	private String procDates;
	private String billRounds;
	private String holidayIndicators;
	private String loadedDataDates;
	
	private String cycle;
	
	/**
	 * Default constructor which sets the default sort item, sort order and previous sort item.
	 */
	public SystemMessagesForm() {
		SystemMessagesParameters systemMessagesParameters = new SystemMessagesParameters();
		this.setSystemMessagesParameters(systemMessagesParameters);
		this.setPreviousSortItem("outProcDate");
		this.setSortItem("outProcDate");
		this.setSortOrder("ASC");
	}
	/**
	 * @return Returns the systemMessagesParameters.
	 */
	public SystemMessagesParameters getSystemMessagesParameters() {
		return systemMessagesParameters;
	}
	/**
	 * @param systemMessagesParameters The systemMessagesParameters to set.
	 */
	public void setSystemMessagesParameters(
			SystemMessagesParameters systemMessagesParameters) {
		this.systemMessagesParameters = systemMessagesParameters;
	}
	/**
	 * @return Returns the alertDashboardList.
	 */
	public List getSystemMessagesList() {
		return systemMessagesList;
	}
	/**
	 * @param alertDashboard The alertDashboard to add
	 */
	public void addSystemMessages(SystemMessages systemMessages) {
		this.systemMessagesList.add(systemMessages);
	}
	/**
	 * @return Returns the qryResultCt.
	 */
	public int getQryResultCt() {
		return qryResultCt;
	}
	/**
	 * @param qryResultCt The qryResultCt to set.
	 */
	public void setQryResultCt(int qryResultCt) {
		this.qryResultCt = qryResultCt;
	}
	
	public void reset(ActionMapping mapping, HttpServletRequest request) {
		super.reset(mapping,request);
	}
	public ActionErrors validate(ActionMapping mapping, HttpServletRequest request) {
			return super.validate(mapping,request);
	}
	
	/**
	 * @return String loadedDataDates
	 */			
	public String getLoadedDataDates() {
		return loadedDataDates;
	}

	/**
	 * @param loadedDataDates String
	 */
	public void setLoadedDataDates(String loadedDataDates) {
		this.loadedDataDates = loadedDataDates;
	}
	
	/**
	 * @return Returns the dateType.
	 */
	public String getDateType() {
		return dateType;
	}
	
	/**
	 * @param dateType The dateType to set.
	 */
	public void setDateType(String dateType) {
		this.dateType = dateType;
	}
	/**
	 * @return Returns the emailRecipients.
	 */
	public String getEmailRecipients() {
		return emailRecipients;
	}
	/**
	 * @param emailRecipients The emailRecipients to set.
	 */
	public void setEmailRecipients(String emailRecipients) {
		this.emailRecipients = emailRecipients;
	}
	/**
	 * @return Returns the pageshow.
	 */
	public int getPageshow() {
		return pageshow;
	}
	/**
	 * @param pageshow The pageshow to set.
	 */
	public void setPageshow(int pageshow) {
		this.pageshow = pageshow;
	}
	/**
	 * @return Returns the statusColor.
	 */
	public String getStatusColor() {
		return statusColor;
	}
	/**
	 * @param statusColor The statusColor to set.
	 */
	public void setStatusColor(String statusColor) {
		this.statusColor = statusColor;
	}
	
	/**
	 * @return Returns the billRounds.
	 */
	public String getBillRounds() {
		return billRounds;
	}
	/**
	 * @param billRounds The billRounds to set.
	 */
	public void setBillRounds(String billRounds) {
		this.billRounds = billRounds;
	}
	/**
	 * @return Returns the holidayIndicators.
	 */
	public String getHolidayIndicators() {
		return holidayIndicators;
	}
	/**
	 * @param holidayIndicators The holidayIndicators to set.
	 */
	public void setHolidayIndicators(String holidayIndicators) {
		this.holidayIndicators = holidayIndicators;
	}
	/**
	 * @return Returns the procDates.
	 */
	public String getProcDates() {
		return procDates;
	}
	/**
	 * @param procDates The procDates to set.
	 */
	public void setProcDates(String procDates) {
		this.procDates = procDates;
	}
	
	/**
	 * @return Returns the endDate.
	 */
	public String getEndDate() {
		return endDate;
	}
	/**
	 * @param endDate The endDate to set.
	 */
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	/**
	 * @return Returns the startDate.
	 */
	public String getStartDate() {
		return startDate;
	}
	/**
	 * @param startDate The startDate to set.
	 */
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	
	/**
	 * @return Returns the cycle.
	 */
	public String getCycle() {
		return cycle;
	}
	/**
	 * @param cycle The cycle to set.
	 */
	public void setCycle(String cycle) {
		this.cycle = cycle;
	}
}
