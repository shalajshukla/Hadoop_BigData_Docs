/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.alerts.status;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;

import com.att.bac.rabc.DateUtil;

import de.laures.cewolf.DatasetProduceException;
import de.laures.cewolf.DatasetProducer;
import de.laures.cewolf.links.CategoryItemLinkGenerator;
import de.laures.cewolf.tooltips.CategoryToolTipGenerator;

/**
 * Percent Graph object which is used by the CeWolf Renderer servlet to render data into a chart. This object
 * implements the DatasetProducer interface & its produceDataset() method is invoked by the servlet to render 
 * the graph. We ensure that this object has the list of PercentGraphData objects available by the time the 
 * produceDataset() method is invoked.
 * 
 * @author Shailesh Hemdev - SH8512
 */
public class PercentGraph implements DatasetProducer, CategoryToolTipGenerator, CategoryItemLinkGenerator, Serializable {
	private static final Logger logger = Logger.getLogger(PercentGraph.class);
	private double [] percentages;
	private double [][] percentageArr;
    private String [] itemNames;
    private List percentGraphDataList = new ArrayList();
    
	/**
	 * @return Returns the percentGraphDataList.
	 */
	public List getPercentGraphDataList() {
		return percentGraphDataList;
	}

    /**
     * Method to add percentGraphData objects to the class attribute percentGraphDataList list.
     * 
     * @param percentGraphDataList
     */
    public void updateList(List percentGraphDataList) {
    	int size = percentGraphDataList.size();
    	for (int i=0;i<size;i++){
    		PercentGraphData percentGraphData = (PercentGraphData)percentGraphDataList.get(i);
    		this.percentGraphDataList.add(percentGraphData);
    	}
    }
	
    /**
     * Method to produce the graph with the following parameters:
	 * 1) Series = List of alert items + 1 additional item for total
	 * 2) Y Axis values = Percentages corresponding to each item + alertdata value for total
	 * 3) X Axis values = File sequence number if not null else Proc Date
     * 
     * @param map
     * @see de.laures.cewolf.DatasetProducer#produceDataset(java.util.Map)
     */
    public Object produceDataset(Map map) throws DatasetProduceException {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset() {
			/**
			 * @see java.lang.Object#finalize()
			 */
			protected void finalize() throws Throwable {
				super.finalize();
				logger.debug(this +" finalized.");
			}
        };
        
        for (int series = 0; series < this.getPercentGraphDataList().size(); series ++) {
        	PercentGraphData percentGraphData = (PercentGraphData)this.percentGraphDataList.get(series);
            percentages = percentGraphData.getPercentages();
            itemNames = percentGraphData.getItemNames();
            if (series == 0){
        		percentageArr = new double[this.getPercentGraphDataList().size()][percentages.length];
        	}
            
            for (int i = 0; i < percentages.length; i++) {
                double percentage = percentages[i];
                percentageArr[series][i]=percentages[i];
                String category;
                String itemName;
                
                if (itemNames[i]==null){
                	itemName = "NS";
                }else {
                	itemName = itemNames[i];
                }
                
                if (percentGraphData.getFileSeqNum()==-1){
                	if (percentGraphData.getProcDate()!=null){
                		String procDateDay = percentGraphData.getProcDate().toString().substring(3,5);
                        String procDateMonth = getDisplayMonth(percentGraphData.getProcDate().toString());
                        String procDateYear = percentGraphData.getProcDate().toString().substring(6,percentGraphData.getProcDate().toString().length());
                        category = procDateDay + "-" + procDateMonth + "-" + procDateYear;
                	}else {
                		String procDateDay = "01";
                        String procDateMonth = percentGraphData.getProcMonth().substring(0,2);
                        String procDateYear = percentGraphData.getProcMonth().substring(3,percentGraphData.getProcMonth().length());
                        
                        category = getDisplayMonth(procDateMonth + "/" + procDateDay + "/" + procDateYear)+ "-" +  procDateYear;
                	} 
                }else {
                	category = Integer.toString(percentGraphData.getFileSeqNum());
                }
               
                dataset.addValue(percentage,itemName,category);
            }
        }
        return dataset;
    }
    
    /**
     * Method to invalidate producer's data after 5 seconds. By this method the
     * producer can influence Cewolf's caching behaviour the way it wants to.
     * 
     * @param map
     * @param since
     * @see de.laures.cewolf.DatasetProducer#hasExpired(java.util.Map, java.util.Date)
     */
    public boolean hasExpired(Map map, Date since) {
    	logger.debug(getClass().getName() + "hasExpired()");
    	return (System.currentTimeMillis() - since.getTime())  > 5000;
	}
    
    /**
     * Method to return a unique ID for this DatasetProducer.
     * 
     * @see de.laures.cewolf.DatasetProducer#hasExpired(java.util.Map, java.util.Date)
     */
    public String getProducerId() {
		return "PercentGraph DatasetProducer";
	}

    /**
     * Method to return a link target for a special data item.
     * 
     * @param data
     * @param series
     * @param category
     * @see de.laures.cewolf.links.CategoryItemLinkGenerator#generateLink(java.lang.Object, int, java.lang.Object)
     */
    public String generateLink(Object data, int series, Object category) {
        return itemNames[series];
    }
    
	/**
	 * @see java.lang.Object#finalize()
	 */
	protected void finalize() throws Throwable {
		super.finalize();
		logger.debug(this + " finalized.");
	}

	/**
	 * @see de.laures.cewolf.tooltips.CategoryToolTipGenerator#generateToolTip(org.jfree.data.category.CategoryDataset, int, int)
	 */
	public String generateToolTip(CategoryDataset arg0, int series, int arg2) {
		return arg0.getColumnKey(arg2) + ":" + Double.toString(percentageArr[arg2][series]) + "%";
	}
	
	/**
	 * Factory method which returns the String to represent the month.
	 * 
	 * @param dateString
	 * @return String
	 */
	private String getDisplayMonth(String dateString){
        SimpleDateFormat tmpDateFormat = new SimpleDateFormat("MM/dd/yyyy");
        String displayMonth;

        try {
        	Date date = tmpDateFormat.parse(dateString);

    		int month = DateUtil.getMonthOfYear(date);

    		switch (month){
    			case 0:
    				displayMonth = "Jan";
    				break;
    			case 1:
    				displayMonth = "Feb";
    				break;
    			case 2:
    				displayMonth = "Mar";
    				break;
    			case 3:
    				displayMonth = "Apr";
    				break;
    			case 4:
    				displayMonth = "May";
    				break;
    			case 5:
    				displayMonth = "Jun";
    				break;
    			case 6:
    				displayMonth = "Jul";
    				break;
    			case 7:
    				displayMonth = "Aug";
    				break;
    			case 8:
    				displayMonth = "Sep";
    				break;
    			case 9:
    				displayMonth = "Oct";
    				break;
    			case 10:
    				displayMonth = "Nov";
    				break;
    			case 11:
    				displayMonth = "Dec";
    				break;
    			default:
    				displayMonth = "Jan";
    				break;
    		}

        } catch (ParseException e){
        	displayMonth = "Err";
        }

		return displayMonth;
	}

}
