/* Created by Peter Foo (pf7941) on Nov 22, 2006.
Copyright 2006-2008 AT&T Knowledge Ventures. All rights reserved. */

package com.att.bac.rabc.load.so.calnet;

import java.sql.Date;

import com.att.bac.rabc.load.calnet.CalnetDTO;

public class SvcOrdTrn extends CalnetDTO {

	public static final String STATUS_COMPLETE = "Complete";
	public static final String STATUS_ERRORED = "Errored";
	public static final String STATUS_INTERIM = "Interim";
	
	
	private Date runDate;
	private String division;
	private int cycle;
	private String agencyId;
	private String svcOrdType;
	private String svcOrdStatus;
	private int svcOrdStatusCt;
	
	
	public String getAgencyId() {
		return agencyId;
	}
	public void setAgencyId(String agencyId) {
		this.agencyId = agencyId;
	}
	public int getCycle() {
		return cycle;
	}
	public void setCycle(int cycle) {
		this.cycle = cycle;
	}
	public String getDivision() {
		return division;
	}
	public void setDivision(String division) {
		this.division = division;
	}
	public Date getRunDate() {
		return runDate;
	}
	public void setRunDate(Date runDate) {
		this.runDate = runDate;
	}
	public String getSvcOrdType() {
		return svcOrdType;
	}
	public void setSvcOrdType(String svcOrdType) {
		this.svcOrdType = svcOrdType;
	}
	public String getSvcOrdStatus() {
		return svcOrdStatus;
	}
	public void setSvcOrdStatus(String svcOrdStatus) {
		this.svcOrdStatus = svcOrdStatus;
	}
	public int getSvcOrdStatusCt() {
		return svcOrdStatusCt;
	}
	public void setSvcOrdStatusCt(int svcOrdStatusCt) {
		this.svcOrdStatusCt = svcOrdStatusCt;
	}
}
