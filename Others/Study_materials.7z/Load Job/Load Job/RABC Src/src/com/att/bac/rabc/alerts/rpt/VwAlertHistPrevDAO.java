/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.rpt;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.ArrayList;
import java.text.MessageFormat;

import org.apache.log4j.Logger;

import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.RABCException;

/**
 * This is a DAO that performs SELECT, INSERT and UPDATE on RABC_VW_ALERT_HIST_PREV table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class VwAlertHistPrevDAO {
	private static final Logger logger = Logger.getLogger(VwAlertHistPrevDAO.class);

	/**
	 * Returns the list of VwAlertHistPrev objects.
	 * 
	 * @param conn 
	 * @param failures
	 * @param args
	 * @param baseSQL
	 * @return List
	 */
	public List get(Connection conn, List failures, List args, String baseSQL) {
		List vwAlertHistPrevList = null;
		VwAlertHistPrev vwAlertHistPrev = null;
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		
		try
		{
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("VwAlertHistPrevDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			vwAlertHistPrevList = new ArrayList();
			while (rs.next()) {
				vwAlertHistPrevList.add(buildVwAlertHistPrev(rs));
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return null;
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
		
		return vwAlertHistPrevList;
	}

	/**
	 * Private method to build VwAlertHistPrev object and return it to caller.
	 * 
	 * @param rs
	 * @return VwAlertHistPrev
	 * @throws SQLException
	 */
	private VwAlertHistPrev buildVwAlertHistPrev(ResultSet rs) throws SQLException {
		VwAlertHistPrev vwAlertHistPrev = new VwAlertHistPrev();
		
		vwAlertHistPrev.setProcDate(rs.getDate("PROC_DATE"));
		vwAlertHistPrev.setPartiRefId(rs.getInt("PARTI_REF_ID"));
		vwAlertHistPrev.setAlertTrendTime(rs.getString("ALERT_TREND_TIME"));
		vwAlertHistPrev.setFileSeqNum(rs.getInt("FILE_SEQ_NUM"));
		vwAlertHistPrev.setPrevData(rs.getDouble("PREV_DATA"));
		vwAlertHistPrev.setPrevAlertItem(rs.getString("PREV_ALERT_ITEM"));
		vwAlertHistPrev.setPrevAlertKeyAt(0,rs.getString("PREV_ALERT_KEY1"));
		vwAlertHistPrev.setPrevAlertKeyAt(1,rs.getString("PREV_ALERT_KEY1"));
		vwAlertHistPrev.setPrevAlertKeyAt(2,rs.getString("PREV_ALERT_KEY1"));
		vwAlertHistPrev.setPrevAlertKeyAt(3,rs.getString("PREV_ALERT_KEY1"));
		vwAlertHistPrev.setPrevAlertKeyAt(4,rs.getString("PREV_ALERT_KEY1"));
		return vwAlertHistPrev;
	}

	/**
	 * Execute the insert or update statement on RABC_VW_ALERT_HIST_PREV table.
	 * 
	 * @param conn
	 * @param failures
	 * @param args
	 * @param baseSQL
	 */
	public void executeUpdate(Connection conn, List failures, List args, String baseSQL) {
		int rowsUpdated = 0;
		Statement stmt = null;
		String sqlStmt = null;
		
		try
		{
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("VwAlertHistPrevDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rowsUpdated = stmt.executeUpdate(sqlStmt);
			logger.debug("SQL - Execution complete."+ String.valueOf(rowsUpdated) + "  rows updated");
			
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return;
		} finally {
			SQLHelper.closeStatement(stmt, failures, logger);
		}
	}

}
