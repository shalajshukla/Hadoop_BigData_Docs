/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.rpt;

/**
 * This class represents the data object that holds the attributes required
 * to represent the qryAlertData query used in Alert Rule Report.
 * 
 * @author Nalina Pandiyan - NP5434
 */
public class QryAlertData {
	private QryAlertRule qryAlertRule = null;
	private AlertHist alertHist = null;

	/**
	 * Parameterised constructor which sets the following attribute.
	 * 
	 * @param qryAlertRule
	 * @param alertHist
	 */
	public QryAlertData(QryAlertRule qryAlertRule, AlertHist alertHist) {
		super();
		this.qryAlertRule = qryAlertRule;
		this.alertHist = alertHist;
	}
	
	/**
	 * @return Returns the alertHist.
	 */
	public AlertHist getAlertHist() {
		return alertHist;
	}

	/**
	 * @param alertHist The alertHist to set.
	 */
	public void setAlertHist(AlertHist alertHist) {
		this.alertHist = alertHist;
	}

	/**
	 * @return Returns the qryAlertRule.
	 */
	public QryAlertRule getQryAlertRule() {
		return qryAlertRule;
	}

	/**
	 * @param qryAlertRule The qryAlertRule to set.
	 */
	public void setQryAlertRule(QryAlertRule qryAlertRule) {
		this.qryAlertRule = qryAlertRule;
	}
	
	/**
	 * This method returns boolean value depend upon the qryAlertDataArg.
	 * 
	 * @param qryAlertDataArg
	 * @return boolean
	 */
	public boolean equals(QryAlertData qryAlertDataArg) {
		if ((this.qryAlertRule.equals(qryAlertDataArg.getQryAlertRule())) && 
			(this.alertHist.equals(qryAlertDataArg.getAlertHist()))) return true;
		return false;
	}
	
	/**
	 * This method concats two strings qryAlertRule and alertHist.
	 * It returns string object.
	 */
	public String toString() {
		return this.qryAlertRule.toString() + "," + this.alertHist.toString();
	}

	/**
	 * This method to get labels for qryAlertRule and alertHist.
	 * 
	 * @return String
	 */
	public String getLabels() {
		return this.qryAlertRule.getLabels() + "," + this.alertHist.getLabels();
	}
}
