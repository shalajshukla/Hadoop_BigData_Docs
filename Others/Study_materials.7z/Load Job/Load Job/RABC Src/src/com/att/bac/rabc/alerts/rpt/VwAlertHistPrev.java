/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.rpt;
import java.util.Date;

/**
 * This is a Data Object to represent RABC_VW_ALERT_HIST_PREV table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class VwAlertHistPrev {
	private Date procDate;
	private int partiRefId;
	private String alertTrendTime;
	private int fileSeqNum;
	private double prevData;
	private String prevAlertItem;
	private String[] prevAlertKey = {"","","","","",""};

	/**
	 * @return Returns the alertTrendTime.
	 */
	public String getAlertTrendTime() {
		return alertTrendTime;
	}

	/**
	 * @param alertTrendTime The alertTrendTime to set.
	 */
	public void setAlertTrendTime(String alertTrendTime) {
		this.alertTrendTime = alertTrendTime;
	}

	/**
	 * @return Returns the fileSeqNum.
	 */
	public int getFileSeqNum() {
		return fileSeqNum;
	}

	/**
	 * @param fileSeqNum The fileSeqNum to set.
	 */
	public void setFileSeqNum(int fileSeqNum) {
		this.fileSeqNum = fileSeqNum;
	}

	/**
	 * @return Returns the partiRefId.
	 */
	public int getPartiRefId() {
		return partiRefId;
	}

	/**
	 * @param partiRefId The partiRefId to set.
	 */
	public void setPartiRefId(int partiRefId) {
		this.partiRefId = partiRefId;
	}

	/**
	 * @return Returns the prevAlertItem.
	 */
	public String getPrevAlertItem() {
		return prevAlertItem;
	}

	/**
	 * @param prevAlertItem The prevAlertItem to set.
	 */
	public void setPrevAlertItem(String prevAlertItem) {
		this.prevAlertItem = prevAlertItem;
	}

	/**
	 * @return Returns the prevData.
	 */
	public double getPrevData() {
		return prevData;
	}

	/**
	 * @param prevData The prevData to set.
	 */
	public void setPrevData(double prevData) {
		this.prevData = prevData;
	}

	/**
	 * @return Returns the procDate.
	 */
	public Date getProcDate() {
		return procDate;
	}

	/**
	 * @param procDate The procDate to set.
	 */
	public void setProcDate(Date procDate) {
		this.procDate = procDate;
	}

	public String getPrevAlertKeyAt(int i) {
		return this.prevAlertKey[i];
	}
	public void setPrevAlertKeyAt(int i, String s) {
		this.prevAlertKey[i] = s;
	}
}
