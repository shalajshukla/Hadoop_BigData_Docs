package com.att.bac.rabc.load.acus.calnet;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.att.carat.util.JDBCUtil;

public class AcusFileDBloadJobTrig {

	protected static final String DIVCODE = "AC";
	public static boolean insertTrigger(
			Connection con,
			String filename,
			String fileid,
			int billRound,
			String headerMonth,
			String headerDay,
			String headerYear) 
	{

			PreparedStatement insertTriggerStatement=null;

			StringBuffer sbQuery1 = new StringBuffer();

			sbQuery1.append("INSERT INTO RABC_TRIG");
			sbQuery1.append("(FILE_NAME, ORIGINAL_FILE_NAME, DIVISION, FILE_ID, CYCLE_DAY, CYCLE_RUN_MONTH, TIME_STAMP, CYCLE_RUN_YEAR, CYCLE_RUN_DAY)");
			sbQuery1.append("VALUES(?,?,?,?,?,?,?,?,?)");

			try {

				insertTriggerStatement = con.prepareStatement(sbQuery1.toString());

				insertTriggerStatement.setString(1, filename);
				insertTriggerStatement.setString(2, filename);
				insertTriggerStatement.setString(3, DIVCODE);
				insertTriggerStatement.setString(4, fileid);
				//TODO Determine how to get the billRound 
				insertTriggerStatement.setInt(5, billRound);
//				insertTriggerStatement.setInt(5, 21);
				insertTriggerStatement.setString(6, headerMonth);
				
				insertTriggerStatement.setDate(7, new java.sql.Date(new java.util.Date().getTime()));
				
				insertTriggerStatement.setString(8, headerYear);
				insertTriggerStatement.setString(9, headerDay);
				
				insertTriggerStatement.execute();

				insertTriggerStatement.close();

			} catch (SQLException e) {
				//e.printStackTrace();
				return false;
			} catch (Exception e) {
				//e.printStackTrace();
				return false;
			} finally {
				 JDBCUtil.closeStatement(insertTriggerStatement);
			 }

			return true;

		}

}
