/*
 * Copyright  2002-2006 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.adhoc.aria.layouts;

import java.io.OutputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.text.NumberFormat;

import javax.naming.NamingException;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;

import com.att.bac.rabc.PickList;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.StaticDataLoader;
import com.att.bac.rabc.adhoc.aria.ARIAReportRABC;
import com.att.bac.rabc.adhoc.aria.AbstractAdhocAriaLayout;
import com.att.bac.rabc.adhoc.aria.IAdhocDTOIndex;
import com.att.bac.rabc.adhoc.aria.LayoutHelper;
import com.att.bac.rabc.adhoc.aria.pivot.DatedCompositeKey;
import com.att.bac.rabc.adhoc.rpt.AdhocRptDataTO;
import com.sbc.bac.aria.ARIACalculationColumn;
import com.sbc.bac.aria.ARIAColumn;
import com.sbc.bac.aria.ARIAHTMLPage13Processor;
import com.sbc.bac.aria.ARIAReportProcessor;
import com.sbc.bac.aria.ARIAUtil;


/**
 * Layout for excel report.
 * 
 * <p>
 * <hr>
 * <h3>Release History</h3>
 * <p>
 * <ul>
 * 
 * <li>jb6494 Aug 17, 2006 Created class.
 * <li>jb6494 Oct 27, 2006 AL#05: Do not show description if it is blank.
 * <li>jb6494 Mar 13, 2007 ML11 Previous data in excel report
 * 
 * </ul>
 * <p>
 * 
 */
class AdhocAriaLayoutExcel1 extends AbstractAdhocAriaLayout {

    public static Logger logger = Logger.getLogger(AdhocAriaLayoutExcel1.class);

    public static final int MAX_ROWS = 65536;

    private static final String CLASS_NAME = AdhocAriaLayoutExcel1.class.getName();

    private int rowCount;

    private int rows;


    /**
     * @param form
     * @param os
     * @param userid
     */
    public AdhocAriaLayoutExcel1(ActionForm form, OutputStream os, String userid) {
        super(form, os, userid);
    }


    /*
     * (non-Javadoc)
     * 
     * @see com.att.bac.rabc.adhoc.rpt.AbstractAdhocAriaLayout#execute(com.sbc.bac.aria.ARIAReport[],
     *      com.att.bac.rabc.adhoc.rpt.AdhocRptDataTO)
     */
    public void execute(ARIAReportRABC[] reports, AdhocRptDataTO dto) {
        if (reports == null) {
            return;
        }
        setDtoBase(dto);
        Connection connection = null;
        try {
            connection = getConnection();

            ARIAHTMLPage13Processor processor = createProcessor(os);
            processor.setPagingRenderer(null);

            for (int i = 0; i < reports.length; i++) {
                setDto(reports[i].getDto());
                setupPreviousDataTable(i);
                rowCount = getReportCount(reports[i], true);
                /*
                 * RUN THE REPORT
                 */
                logger.debug("ARIAReport execute starting...\nSQL:" + reports[i].toSQL());
                if(connection == null){
                	connection = getConnection();
                }
                int rows = reports[i].execute(connection, processor);
                logger.debug("ARIAReport execute ending (rows=" + rows + ")...");
            }
        } catch (SQLException sqle) {
            logger.fatal("SQLException", sqle);
        } catch (NamingException ne) {
            logger.fatal("NamingException ", ne);
        } catch (Exception e) {
            logger.error("execute()", e);
        } finally {
            closeConnection();
        }
    }


    /*
     * (non-Javadoc)
     * 
     * @see com.sbc.bac.aria.renderers.ARIAHTMLReportRenderer#renderBeginReport(com.sbc.bac.aria.ARIAReportProcessor)
     */
    public String renderBeginReport(ARIAReportProcessor processor) {
        StringBuffer buf = new StringBuffer(100);
        try {
            createReportFilters();
            buf.append("<html>\n");
            buf.append("<head>\n");
            buf.append("<style>\n");
            buf.append("\t.BACTable {}\n");
            buf.append("\t.BACTable TD {border: thin solid #000000; }\n");
            buf.append("\t.BACTable TH {border: thin solid #000000; text-align: center; background-color: lightgrey; font-weight: bold;}\n");
            buf.append("</style>\n");
            buf.append("</head>\n");
            buf.append("<body>\n");

            buf.append(beginTable());

            if (getDtoBase().getRptHeader1() != null) {
                buf.append(renderBeginRow(processor));
                buf.append("<td colspan=\"10\" style=\"border-style: none; font-size: 16; font-weight: bold; color: #191970;\">" + getDtoBase().getRptHeader1() + "</td>");
                buf.append(renderEndRow(processor));
            }

            if (getDtoBase().getRptHeader2() != null) {
                buf.append(renderBeginRow(processor));
                buf.append("<td colspan=\"10\" style=\"border-style: none; font-size: 12; font-weight: bold; color: #191970;\">" + getDtoBase().getRptHeader2() + "</td>");
                buf.append(renderEndRow(processor));
            }
            if (getDtoBase().getRptHeader3() != null) {
                buf.append(renderBeginRow(processor));
                buf.append("<td colspan=\"10\" style=\"border-style: none; font-size: 12; color: #191970;\">" + getDtoBase().getRptHeader3() + "</td>");
                buf.append(renderEndRow(processor));
            }

            buf.append(renderBeginRow(processor));
            buf.append(renderEndRow(processor));

            buf.append(renderBeginRow(processor));
            buf.append(addLabel("Start"));
            buf.append("<td colspan=\"10\" style=\"border-style: none; text-align: left;\">" + dto.getStartDate() + "</td>");
            buf.append(renderEndRow(processor));

            buf.append(renderBeginRow(processor));
            buf.append(addLabel("End"));
            buf.append("<td colspan=\"10\" style=\"border-style: none; text-align: left;\">" + dto.getEndDate() + "</td>");
            buf.append(renderEndRow(processor));

            // Report filters (start)

            if (getDtoBase().isHideSortKeyList()) {
                buf.append(renderBeginRow(processor));
                buf.append(addLabel(getDtoBase().getLabelSortKeyList()));
                buf.append("<td colspan=\"10\" style=\"border-style: none; text-align: left;\">" + getDtoBase().getSortKeyList() + "</td>");
                buf.append(renderEndRow(processor));
            }

            if (!getDtoBase().isHideDivDropDown() || !getDtoBase().isHideDivCheckBox()) {
                for (int i = 0; i < getDtoBase().getSelectedDivs().length; i++) {
                    String div = StaticDataLoader.getDivisionDesc(getDtoBase().getRegion(), getDtoBase().getSelectedDivs()[i]);
                    buf.append(renderBeginRow(processor));
                    buf.append(addLabel("Division"));
                    buf.append("<td colspan=\"10\" style=\"border-style: none; text-align: left;\">" + div + "</td>");
                    buf.append(renderEndRow(processor));
                }

            }

            if (!getDtoBase().isHideFileSeqNum()) {
                buf.append(renderBeginRow(processor));
                buf.append(addLabel("File Sequence Number"));
                buf.append("<td colspan=\"10\" style=\"border-style: none; text-align: left;\">" + getDtoBase().getFileSeqNumAsString() + "</td>");
                buf.append(renderEndRow(processor));
            }

            if (!getDtoBase().isHideSortKeyList2()) {
                buf.append(renderBeginRow(processor));
                buf.append(addLabel(getDtoBase().getLabelSortKeyList2()));
                buf.append("<td colspan=\"10\" style=\"border-style: none; text-align: left;\">" + getDtoBase().getSortKeyList2() + "</td>");
                buf.append(renderEndRow(processor));
            }

            if (!getDtoBase().isHideAlertRuleTiming()) {
                String excelAlertTimeValue = "";
                if (getDtoBase().getAlertTimeInd().equalsIgnoreCase("D")) {
                    if (getDtoBase().getAlertTimeValue() != -1) {
                        HashMap weekdayOptions = new HashMap();
                        weekdayOptions.put(Integer.toString(0), "All");
                        weekdayOptions.put(Integer.toString(1), "Sunday");
                        weekdayOptions.put(Integer.toString(2), "Monday");
                        weekdayOptions.put(Integer.toString(3), "Tuesday");
                        weekdayOptions.put(Integer.toString(4), "Wednesday");
                        weekdayOptions.put(Integer.toString(5), "Thursday");
                        weekdayOptions.put(Integer.toString(6), "Friday");
                        weekdayOptions.put(Integer.toString(7), "Saturday");
                        excelAlertTimeValue = weekdayOptions.get(Integer.toString(getDtoBase().getAlertTimeValue())).toString();
                    }
                    buf.append(renderBeginRow(processor));
                    buf.append(addLabel("Call Day Week"));
                    buf.append("<td colspan=\"10\" style=\"border-style: none; text-align: left;\">" + excelAlertTimeValue + "</td>");
                    buf.append(renderEndRow(processor));
                } else if (getDtoBase().getAlertTimeInd().equalsIgnoreCase("B")) {
                    if (getDtoBase().getAlertTimeValue() != -1) {
                        excelAlertTimeValue = Integer.toString(getDtoBase().getAlertTimeValue());
                    }
                    buf.append(renderBeginRow(processor));
                    buf.append(addLabel("Bill Cycle"));
                    buf.append("<td colspan=\"10\" style=\"border-style: none; text-align: left;\">" + excelAlertTimeValue + "</td>");
                    buf.append(renderEndRow(processor));
                } else {
                    buf.append(renderBeginRow(processor));
                    buf.append(addLabel("Timing"));
                    buf.append("<td colspan=\"10\" style=\"border-style: none; text-align: left;\">" + excelAlertTimeValue + "</td>");
                    buf.append(renderEndRow(processor));

                }
                if (!getDtoBase().isHideMonthYear()) {
                    buf.append(renderBeginRow(processor));
                    buf.append(addLabel("Month"));
                    buf.append("<td colspan=\"10\" style=\"border-style: none; text-align: left;\">" + ((PickList) getDtoBase().getMonthSelectOptions().get(getDtoBase().getMonthSelect())).getValue1() + "</td>");
                    buf.append(renderEndRow(processor));
                    String excelYear = "";
                    if (getDtoBase().getYearSelect() != 0) {
                        excelYear = Integer.toString(getDtoBase().getYearSelect());
                    }
                    buf.append(renderBeginRow(processor));
                    buf.append(addLabel("Year"));
                    buf.append("<td colspan=\"10\" style=\"border-style: none; text-align: left;\">" + excelYear + "</td>");
                    buf.append(renderEndRow(processor));
                }
            }

            buf.append(endTable());

            buf.append(beginTable());
            buf.append(renderBeginRow(processor));
            buf.append(addLabel("Total Records"));
            buf.append("<td colspan=\"10\" style=\"border-style: none; text-align: left;\">" + rowCount + "</td>");
            buf.append(renderEndRow(processor));
            buf.append(endTable());

            buf.append(beginTable());
            
            String subHeader = "";
            try {
    			subHeader = LayoutHelper.getSubHeader(dto, getConnection(), getSection(), logger);
    		} catch (NamingException e) {
    			logger.debug("Could not get the sub header" + e);
    		} catch (SQLException e) {
    			logger.debug("Could not get the sub header" + e);
    		} //finally{
    			//closeConnection();
    		//}
    		
    		if (!"".equals(subHeader)){
    			buf.append("<tr><td colspan='100%'><strong>");
    			buf.append(subHeader);	
    			buf.append("</strong></td></tr>");
    		}
        } catch (Exception e) {
            logger.error(CLASS_NAME, "renderBeginReport", e);
        }

        return buf.toString();
    }


    /*
     * (non-Javadoc)
     * 
     * @see com.sbc.bac.aria.renderers.ARIAHTMLRowRenderer#renderBeginRow(com.sbc.bac.aria.ARIAReportProcessor)
     */
    public String renderBeginRow(ARIAReportProcessor processor) {
        rows++;
        if (rows > MAX_ROWS) {
            logger.error("Maximum number of Excel rows <" + MAX_ROWS + "> exceeded");
            return "";
        }
        return "<tr>";
    }


    /*
     * (non-Javadoc)
     * 
     * @see com.sbc.bac.aria.renderers.ARIAHTMLColumnRenderer#renderColumn(com.sbc.bac.aria.ARIAColumn,
     *      com.sbc.bac.aria.ARIAReportProcessor, java.lang.String, boolean)
     */
    public String renderColumn(ARIAColumn column, ARIAReportProcessor processor, String value, boolean escape) {
        StringBuffer buf = new StringBuffer(100);
        String bgColor = "FFFFFF";
        boolean bold = false;
        boolean alignmentPrinted = false ; 
        String  currentValue="";       
        int columnIndex = ((IAdhocDTOIndex) column).getDtoIndex();
        if (columnIndex<0 || !isIndicatorIn((String) dto.getPresnSuppressIndList().get(columnIndex), "Y")) {
        	if (value.equals(TOTAL) || value.equals(GRAND_TOTAL)) {
                bgColor = "D8D8D8";
                bold = true;
            }

            if (value == null || value.equals("null") || value.equals("")) {
                buf.append("<td class=\"cellText mso\" ");
                buf.append(" bgColor='");
                buf.append(bgColor);
                buf.append("'>&nbsp;</td>");
            } else {
                
                buf.append("<td class=\"cellText mso\" ");
                buf.append(" bgColor='" + bgColor + "' ");
                
                if (columnIndex >= 0) {
                    if (!isIndicatorIn((String) dto.getPresnSumIndList().get(columnIndex), "N")) {
                        buf.append(" align='right' ");
                        alignmentPrinted = true ; 
                    }
                    if (isIndicatorIn((String) dto.getPresnUnitIndList().get(columnIndex), "D")) {
                        buf.append(" align='right' ");
                        alignmentPrinted = true ; 
                    }
                    if (!dto.getPresnCalcNumList().get(columnIndex).toString().equals("")) {
                        buf.append(" align='right' ");
                        alignmentPrinted = true ; 
                    }
                }
                if (!alignmentPrinted) {
                	buf.append(getAlignment(column));
                }
                
                buf.append(">");
                if (bold) {
                    buf.append("<b>");
                }

                try {
                    formatCellData(column.getName(), value, escape, columnIndex, buf);
                } catch (RABCException e) {
                    throw new IllegalArgumentException(e.getMessage());
                }

                if (bold) {
                    buf.append("</b>");
                }
                buf.append("</td>");
            }
            
            if (columnIndex >= 0) {
                if (isIndicatorIn((String) dto.getPrevDataIndList().get(columnIndex), "Y")) {
                    DatedCompositeKey datedKey = getDatedKey(processor.getRowData());
                    if (datedKey != null) {
                    	currentValue = value;
                        Map rowData = (Map) prevData.findPreviousData(datedKey, dto.getPresnTrendTime(),dto);
                        value = rowData == null ? "no data" : rowData.get(column.getName()).toString();
                      
                        buf.append("<td class=\"cellText mso\" ");
                        if (columnIndex >= 0) {
                            if (!isIndicatorIn((String) dto.getPresnSumIndList().get(columnIndex), "N")) {
                                buf.append(" align='right' ");
                            }
                            if (isIndicatorIn((String) dto.getPresnUnitIndList().get(columnIndex), "D")) {
                                buf.append(" align='right' ");
                            }
                            if (!dto.getPresnCalcNumList().get(columnIndex).toString().equals("")) {
                                buf.append(" align='right' ");
                            }
                        }
                        if (!alignmentPrinted) {
                        	buf.append(getAlignment(column));
                        }
                        buf.append(">");
                        try {
                        	if ("no data".equals(value)){
                        		buf.append(value);
                        	} else {
                        		formatCellData(column.getName(), value, escape, columnIndex, buf);
                        	}                    	
                        } catch (RABCException e) {
                            logger.error(e);
                        }                    
                        buf.append("</td>");
                    } else {
                        buf.append("<td>&nbsp;</td>");
                    }
                }
                
                
//              sb8798-added for the difference columns
              if (isIndicatorIn((String) dto.getDiffDataIndList().get(columnIndex), "Y")) {
              	DatedCompositeKey datedKey = getDatedKey(processor.getRowData());
              	
              	//difference
                  if (datedKey != null) {
                     buf.append("<td class=\"cellText mso\" ");
                     if (columnIndex >= 0) {
                         if (!isIndicatorIn((String) dto.getPresnSumIndList().get(columnIndex), "N")) {
                             buf.append(" align='right' ");
                         }
                         if (isIndicatorIn((String) dto.getPresnUnitIndList().get(columnIndex), "D")) {
                             buf.append(" align='right' ");
                         }
                         if (!dto.getPresnCalcNumList().get(columnIndex).toString().equals("")) {
                             buf.append(" align='right' ");
                         }
                     }
                     if (!alignmentPrinted) {
                     	buf.append(getAlignment(column));
                     }
                     buf.append(">");
                     try {
                     	if ("no data".equals(value)){
                     		buf.append(value);
                     	} else {
	                   	    double previous = Double.parseDouble(value);
	                	    double current= Double.parseDouble(currentValue);
	                	    double difference = current - previous;    
                     		formatCellData(column.getName(), String.valueOf(difference), escape, columnIndex, buf);
                     	}                    	
                     } catch (RABCException e) {
                         logger.error(e);
                     }                    
                     buf.append("</td>");
                     
                     
                     // absolute difference
                     buf.append("<td class=\"cellText mso\" ");
                     if (columnIndex >= 0) {
                         if (!isIndicatorIn((String) dto.getPresnSumIndList().get(columnIndex), "N")) {
                             buf.append(" align='right' ");
                         }
                         if (isIndicatorIn((String) dto.getPresnUnitIndList().get(columnIndex), "D")) {
                             buf.append(" align='right' ");
                         }
                         if (!dto.getPresnCalcNumList().get(columnIndex).toString().equals("")) {
                             buf.append(" align='right' ");
                         }
                     }
                     if (!alignmentPrinted) {
                     	buf.append(getAlignment(column));
                     }
                     buf.append(">");
                     try {
                     	if ("no data".equals(value)){
                     		buf.append(value);
                     	} else {
 	                   	    double previous = Double.parseDouble(value);
 	                	    double current= Double.parseDouble(currentValue);
 	                	    double absoluteDifference = Math.abs(current - previous);    
                     		formatCellData(column.getName(), String.valueOf(absoluteDifference), escape, columnIndex, buf);
                     	}                    	
                     } catch (RABCException e) {
                         logger.error(e);
                     }                    
                     buf.append("</td>");

                     //percentage difference
                     buf.append("<td class=\"cellText mso\" ");
                     if (columnIndex >= 0) {
                         if (!isIndicatorIn((String) dto.getPresnSumIndList().get(columnIndex), "N")) {
                             buf.append(" align='right' ");
                         }
                         if (isIndicatorIn((String) dto.getPresnUnitIndList().get(columnIndex), "D")) {
                             buf.append(" align='right' ");
                         }
                         if (!dto.getPresnCalcNumList().get(columnIndex).toString().equals("")) {
                             buf.append(" align='right' ");
                         }
                     }
                     if (!alignmentPrinted) {
                     	buf.append(getAlignment(column));
                     }
                     buf.append(">");
                     try {
                     	if ("no data".equals(value)){
                     		buf.append(value);
                     	} else {
                        	  double previous = Double.parseDouble(value);
                     	     double current= Double.parseDouble(currentValue);
                     	     double difference = current - previous;
                     		 double percentDifference = 0;
                           if (Math.abs(current) > 0){
                              	percentDifference = (difference/Math.abs(current))*100;
                           }

                           if (Math.abs(current) == 0){
	                             	buf.append("div zero");
                           } else {
                          	    formatPercentage(Double.toString(percentDifference), escape, buf);
	                             	buf.append("</td>");
                           }            
                     	}                    	
                     } catch (RABCException e) {
                         logger.error(e);
                     }                    
                     buf.append("</td>");
                     
                 } else {
                     buf.append("<td>&nbsp;</td>");
                     buf.append("<td>&nbsp;</td>");
                     buf.append("<td>&nbsp;</td>");
                 }
        }  
            }
        }

        return buf.toString();
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.sbc.bac.aria.renderers.ARIAHTMLReportRenderer#renderEndReport(com.sbc.bac.aria.ARIAReportProcessor)
     */
    public String renderEndReport(ARIAReportProcessor processor) {
        StringBuffer buf = new StringBuffer(23);
        buf.append("</table>");
        return buf.toString();
    }


    /*
     * (non-Javadoc)
     * 
     * @see com.sbc.bac.aria.renderers.ARIAHTMLRowRenderer#renderEndRow(com.sbc.bac.aria.ARIAReportProcessor)
     */
    public String renderEndRow(ARIAReportProcessor processor) {
        return "</tr>\n";
    }


    /*
     * (non-Javadoc)
     * 
     * @see com.sbc.bac.aria.renderers.ARIAHeaderRenderer#renderHeader(java.util.List)
     */
    public String renderHeader(List columns) {
        StringBuffer buf = new StringBuffer(100);
        Iterator i = columns.iterator();
        	
        while (i.hasNext()) {
            ARIAColumn element = (ARIAColumn) i.next();
            int index = ((IAdhocDTOIndex) element).getDtoIndex();

            if (index<0 || !isIndicatorIn((String) dto.getPresnSuppressIndList().get(index), "Y")) {
            	buf.append("<th class='tableHeader'>");
            	buf.append(ARIAUtil.escape(getColumnHeader(element.getName(), index)));            
                buf.append("</th>");
                if (index >= 0) {
                    if (isIndicatorIn((String) dto.getPrevDataIndList().get(index), "Y")) {
                        buf.append("<th class='tableHeader'>Previous ");
                        buf.append(ARIAUtil.escape(getColumnHeader(element.getName(), index)));                    
                        buf.append("</th>");
                    }
                    
                    if (isIndicatorIn((String) dto.getDiffDataIndList().get(index), "Y")) {
                        buf.append("<th class='tableHeader'>Difference ");
                        buf.append(ARIAUtil.escape(getColumnHeader(element.getName(), index)));
                        buf.append("</th>");
                        buf.append("<th class='tableHeader'>Absolute Difference ");
                        buf.append(ARIAUtil.escape(getColumnHeader(element.getName(), index)));
                        buf.append("</th>");
                        buf.append("<th class='tableHeader'>Percent Difference ");
                        buf.append(ARIAUtil.escape(getColumnHeader(element.getName(), index)));
                        buf.append("</th>");
                    } 
                }
            }
        }
        return buf.toString();
    }


    /**
     * Add a table data "label" for the value
     * 
     * @param value
     * @return
     */
    private String addLabel(String value) {
        if (value == null) {
            value = "";
        } else {
            value = ARIAUtil.escape(value) + ":";
        }
        return "<td style=\"border-style: none; font-weight: bold; text-align: left;\">" + value + "</td>";
    }


    /**
     * Open a table tag
     * 
     * @return
     */
    private String beginTable() {
        return "<table class=\"BACTable\">\n";
    }


    /**
     * Close a table tag
     * 
     * @return
     */
    private String endTable() {
        return "</table>\n";
    }


    /**
     * Try to determine if this should have a description column
     * 
     * @param column
     * 
     * @return
     */
    private boolean hasMouseOver(ARIAColumn column) {
        int index = ((IAdhocDTOIndex) column).getDtoIndex();
        if (index < 0) {
            return false;
        }
        
        Object o = dto.getDataMouseOverNumList().get(index);
        if (o == null) {
            return false;
        }
        if (o.toString().equals("0")) {
            return false;
        }
        return true;
    }

	private StringBuffer formatPercentage(String value, boolean escape,StringBuffer buf) throws RABCException {
        String suffix = "%";

        if (value == null) {
            buf.append("");
            return buf;
        }

        value = escape ? ARIAUtil.escape(value) : value;
        NumberFormat fmt = NumberFormat.getNumberInstance();
        fmt.setMinimumFractionDigits((value.indexOf('.') >= 0) ? 2 : 0);
        fmt.setMaximumFractionDigits(2);
        try {
            buf.append(fmt.format(Double.parseDouble(value)));
        } catch (NumberFormatException e) {
            buf.append("NaN");
        }
        buf.append(suffix);
        return buf;
    }     
}
