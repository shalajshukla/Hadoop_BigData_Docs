/* Created by Peter Foo (pf7941) on Dec 6, 2006.
Copyright 2006-2008 AT&T Knowledge Ventures. All rights reserved. */

package com.att.bac.rabc.load.usoc.calnet;

import java.sql.Date;

import com.att.bac.rabc.load.calnet.CalnetDTO;

public class DailyUSOCActivity extends CalnetDTO {

	Date runDate;
	String division;
	int cycle;
	String agencyId;
	String usoc;
	long fullChgTotCt;
	long fullChgTotAmt;
	long dsct50PctTotCt;
	long dsct50PctTotAmt;
	long dsct100PctTotCt;
	long dsct100PctTotAmt;
	long dsctOthPctTotCt;
	long dsctOthPctTotAmt;
	String usocAccsInd;
	
	public String getAgencyId() {
		return agencyId;
	}
	public void setAgencyId(String agencyId) {
		this.agencyId = agencyId;
	}
	public int getCycle() {
		return cycle;
	}
	public void setCycle(int cycle) {
		this.cycle = cycle;
	}
	public String getDivision() {
		return division;
	}
	public void setDivision(String division) {
		this.division = division;
	}
	public long getDsct100PctTotAmt() {
		return dsct100PctTotAmt;
	}
	public void setDsct100PctTotAmt(long dsct100PctTotAmt) {
		this.dsct100PctTotAmt = dsct100PctTotAmt;
	}
	public long getDsct100PctTotCt() {
		return dsct100PctTotCt;
	}
	public void setDsct100PctTotCt(long dsct100PctTotCt) {
		this.dsct100PctTotCt = dsct100PctTotCt;
	}
	public long getDsct50PctTotAmt() {
		return dsct50PctTotAmt;
	}
	public void setDsct50PctTotAmt(long dsct50PctTotAmt) {
		this.dsct50PctTotAmt = dsct50PctTotAmt;
	}
	public long getDsct50PctTotCt() {
		return dsct50PctTotCt;
	}
	public void setDsct50PctTotCt(long dsct50PctTotCt) {
		this.dsct50PctTotCt = dsct50PctTotCt;
	}
	public long getDsctOthPctTotAmt() {
		return dsctOthPctTotAmt;
	}
	public void setDsctOthPctTotAmt(long dsctOthPctTotAmt) {
		this.dsctOthPctTotAmt = dsctOthPctTotAmt;
	}
	public long getDsctOthPctTotCt() {
		return dsctOthPctTotCt;
	}
	public void setDsctOthPctTotCt(long dsctOthPctTotCt) {
		this.dsctOthPctTotCt = dsctOthPctTotCt;
	}
	public long getFullChgTotAmt() {
		return fullChgTotAmt;
	}
	public void setFullChgTotAmt(long fullChgTotAmt) {
		this.fullChgTotAmt = fullChgTotAmt;
	}
	public long getFullChgTotCt() {
		return fullChgTotCt;
	}
	public void setFullChgTotCt(long fullChgTotCt) {
		this.fullChgTotCt = fullChgTotCt;
	}
	public Date getRunDate() {
		return runDate;
	}
	public void setRunDate(Date runDate) {
		this.runDate = runDate;
	}
	public String getUsoc() {
		return usoc;
	}
	public void setUsoc(String usoc) {
		this.usoc = usoc;
	}
	public String getUsocAccsInd() {
		return usocAccsInd;
	}
	public void setUsocAccsInd(String usocAccsInd) {
		this.usocAccsInd = usocAccsInd;
	}
	
}
