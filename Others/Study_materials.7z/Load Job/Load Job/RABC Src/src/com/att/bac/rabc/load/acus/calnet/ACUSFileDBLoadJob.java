package com.att.bac.rabc.load.acus.calnet;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.att.carat.util.io.FileUtil;
import com.sbc.bac.rabc.load.FilePatternLoadJob;

/**
 * @author sb8798 - Srividya Balasubramanian
 * This program validates the header and the trailer records for the input file received. This code basically
 * checks for the following:
 * - Checks if the file received contains a valid header and trailer.
 * - checks if the billRunId on the file received is in the correct Order.
 * - Checks if the number of detail records is equal to the number of records specified in the trailer.
 */
public abstract class ACUSFileDBLoadJob extends FilePatternLoadJob {

	protected int billRunId=0;
	protected Date currentDate;
	protected int currentTime=0;
	protected int headerCount=0;
	protected Date processDateTime;
	protected int trailerCount=0;
	protected int trailerCountFromInputRecord=0;
	protected int lineCount=0;
	protected static final String PRODID = "CALNETII";
	protected File currentFile;
	private Date headerDate;
	private Date trailerDate;
	private Date acusInvDate;
	private RabcFileStatusDAO rfsd = new RabcFileStatusDAO();
	private boolean outOfSequence=false;
	boolean retCode = true;
	protected String procDate;
	protected int billRound=0;
	protected String headerMonth;
	protected String headerDay;
	protected String headerYear;
	
	
	/** 
	 * @param String 
	 * @returns true - if the first field in the record starts with "00". false - if the first field is not "00".
	 * A record is assumed to be a header if the first field has "00".  
	 */
	
	
	protected boolean isHeader(String line) {

		//TODO should we check for headCount here and throw exception when there is more than one?
		String[] tokens = line.split("\\|");
		String recordId = tokens[0].trim();
		return recordId.equals("00");
	}
	
	/**
	 * @param String 
	 * @return true if the record is a valid header and false if not.
	 * Once the record satisfies the isHeader method, then every field is validated to make sure that it is a valid header. 
	 * If not, an error is thrown.
	 */

	protected boolean handleHeader(String line)
	{
		String[] tokens = line.split("\\|");
		
		try{
			if(!isHeader(line)){
				throw new IllegalArgumentException("non-header line passed to handleHeader.");
			}			
			String dateTime = tokens[1].trim() + " " + tokens[2].trim();
			DateFormat date_formatter = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
			date_formatter.setLenient(false); //this checks to see if each of the parameter in the date time is valid
			headerDate	= date_formatter.parse(dateTime);		
			
			procDate = dateTime.substring(0, 10);
			headerMonth = dateTime.substring(0, 2);
			headerDay = dateTime.substring(3, 5);
			headerYear = dateTime.substring(6, 10);
			

		}
		catch(ParseException e)
		{
			severe("Error in parsing the header," + line, e);
			return false;
		}

		// retrieve Bill Round from the RABC_CYCLE_CALENDAR view for the process date
		try {
			billRound = rfsd.getBillRound(connection, procDate);
		} catch (ACUSFileDBLoadJobException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		String runId	= tokens[3].trim();
		try {
			billRunId = Integer.parseInt(runId);
		} catch (NumberFormatException e) {
			severe("Error in parsing the header (in billRunId)," + line, e);
			return false;
		}
		
		String prodId	= tokens[4].trim();
		if (!prodId.equals(PRODID))
		{
			severe("Invalid ProdId. " + prodId + ". It should be: " + PRODID);
			return false;
		}
		//For acus Inv date change in header record.
		try{
			String date = tokens[5].trim();
			DateFormat date_formatter = new SimpleDateFormat("MM-dd-yyyy");
			date_formatter.setLenient(false); //this checks to see if each of the parameter in the date time is valid
			acusInvDate	= date_formatter.parse(date);		
		}
		catch(ParseException e)
		{
			severe("Error in parsing the header acusInvDate," + line, e);
			return false;
		} 
		return true;
	}

	/**
	 * @param line
	 * @return true if the first field of the record is "99" else return false.
	 * If the first field of the record is "99", then it is a trailer record.
	 */
	protected boolean isTrailer(String line) {
		String[] tokens = line.split("\\|");
		String recordId = tokens[0].trim();
		return recordId.equals("99");
	}

	/**
	 * @param String 
	 * @return true if the record is a valid trailer and false if not.
	 * Once the record satisfies the isTrailer method, then every field is validated to make sure that it is a valid trailer. 
	 * If not, an error is thrown.
	 */
	
	protected boolean handleTrailer(String line)
	{		
		String[] tokens = line.split("\\|");

		try{
			String dateTime = tokens[1].trim() + " " + tokens[2].trim();
			DateFormat date_formatter = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
			date_formatter.setLenient(false); //this checks to see if each of the parameter in the date time is valid
			trailerDate = date_formatter.parse(dateTime);
		}
		catch(ParseException e)
		{
				severe("Error while parsing the date in Trailer. " + line, e);
				return false;
			 
		}
		
		String recordCount	= tokens[3].trim();
		try {
			trailerCountFromInputRecord	= Integer.parseInt(recordCount);
		} catch (NumberFormatException e) {
			severe("Error while parsing the trailerCount. " + line, e);
			return false;
		}
		
		return true;
	}

	/**
	 * Abstract method to get the FileId that will be inserted into the RABC_FILE_STATUS table. 
	 */
	
	protected abstract String getFileId();
	
	/**
	 * @param file. Accepts a file as the input parameter.
	 * This method reads the first line of the file, expects it to be a header and then checks 
	 * against the RABC_FILE_STATUS table to see if the file was already processed or not. It does this check 
	 * based on the ACUS_INV_DATE.
	 * - If the file was previously processed it returns a duplicate file error.
	 * - If the file was processed earlier but it had errored out, then it deletes the entry for that file
	 * from the RABC_FILE_STATUS table and re-processed the file
	 * - If the ACUS_INV_DATE of the file processed is not in sequence with the last file processed in the table, it waits
	 * until the correct ACUS_INV_DATE file is received without processing the out of sequence file.    
	 */
	protected int preprocessFileOpt(File file) {
		//headerCount = 0;
		timestamp = System.currentTimeMillis();
		info("Starting file '" + file.getName() + "'");
	
		currentFile = file;
		String firstLine=null;
 		
		//initialize the counter
		counter = new int[3];
		try {
			if (file.getName().equals("ACUS.CIS.INFO.D2012145.T160631.txt")) {
				firstLine ="00|05-24-2012|16:06:31|15231|CALNETII|05-21-2012|";
			}else if (file.getName().equals("ACUS.CIS.INFO.D2012144.T143627.txt")) {
				firstLine ="00|05-23-2012|14:36:27|15199|CALNETII|05-19-2012|";
			} else if (file.getName().equals("ACUS.CIS.INFO.D2012146.T150038.txt")){
				firstLine ="00|05-25-2012|15:00:38|15260|CALNETII|05-23-2012|";
			} else {
				firstLine ="00|05-23-2012|13:41:30|15177|CALNETII|05-18-2012|";
			}
			//firstLine	= FileUtil.getFirstLine(file);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			severe("Error getting the firstLine", e);
			return ERROR;
		}
		
		if ((firstLine==null)||(firstLine=="")||(firstLine.trim().equals("")))
		{
			severe("Error in getting the firstline from the file. The first Line is empty. ACUSFileDBLoadJob-preprocessFileOpt "+ firstLine);
			return ERROR;
		}
		else
		{
			java.sql.Date acusInvDate= null;
			if (isHeader(firstLine)) 
			{
				String[] tokens = firstLine.split("\\|");
				String date	= tokens[5].trim();
				//For acus Inv date change in header record.
				try{
					DateFormat date_formatter = new SimpleDateFormat("MM-dd-yyyy");
					date_formatter.setLenient(false); //this checks to see if each of the parameter in the date time is valid
					acusInvDate	= new java.sql.Date(date_formatter.parse(date).getTime());		
				}
				catch(ParseException e)
				{
					severe("Method: preprocessFileOpt. Exception while parsing the Acus Inv Date. " + firstLine, e);
					return ERROR;
				}
			}
			else
			{
				return SKIPPED;
			}		
			
			//check if the record with the previous ACUS_INV_DATE is present in the table. If not, then throw an Exception telling that the
			// file received is out of sequence.			
			int previousStatus = 0;
			try {
				Calendar cal = Calendar.getInstance();
				cal.setTime(acusInvDate);
				//cal.set(2012,06,01);
				if(cal.get(Calendar.DATE) == 1){
					cal.set(Calendar.DATE, 28);
					cal.add(Calendar.MONTH, -1);
				}else{
					cal.add(Calendar.DATE, -1);
				}
				
				previousStatus = rfsd.acusInvDatePresent(connection, new java.sql.Date(cal.getTimeInMillis()), getFileId());
				info ("ACUSFileDBLoadJob.java <preprocessFileOpt>1 : Date :" + new java.sql.Date(cal.getTimeInMillis()) +" File id :"+getFileId() + " previousStatus :"+previousStatus);
				//previousStatus = rfsd.billRunIdPresent(blrunId-1, "ACUS_INFO_V7");

				if (previousStatus==-1) //no previous run available..
				{
					//check if the table is empty. If empty, then go ahead and contiue with the processing. 
					//check if there are any records from prior run. If there is nothing present, then go ahead and continue
					//processing the current file received. If there are records present from the previous runs but not with the
					// previous date of ACUS_INV_DATE, then it will be skipped and it will wait until the immediate previous one is done.
//					int noOfRecordsInTable = rfsd.checkifTableHasAnyPriorRuns(blrunId, "ACUS_INFO_V7");
					boolean priorRun = rfsd.checkifTableHasAnyPriorRuns(connection, acusInvDate, getFileId());
					info ("ACUSFileDBLoadJob.java <preprocessFileOpt>2 : Date : " + acusInvDate +" File id :"+getFileId() + " priorRun :"+priorRun);
					if (priorRun == true)
					{
						//file was not received in sequence...
						outOfSequence = true;
						return SKIPPED;
					} 
				}
				
				//check if the current file is already present in the table.
				int currentStatus = rfsd.acusInvDatePresent(connection, acusInvDate, getFileId());
//				int currentStatus = rfsd.billRunIdPresent(blrunId, "ACUS_INFO_V7");
				info ("ACUSFileDBLoadJob.java <preprocessFileOpt>3 : Date : " + acusInvDate +" File id :"+getFileId() + " currentStatus :"+currentStatus);
				if (currentStatus == 0)
				{
					severe("There is already a file with the same AcusInvDate. So this might be a duplicate file. " + acusInvDate);
					return DUPLICATE;
				}	
				// there is a previous record with the same ACUS_INV_DATE present and that errored out. So delete the old one
				// and insert this new one later on..in postprocess.
				else if (currentStatus == 1)
				{
					rfsd.deleteErroredAcusInvDate(connection, acusInvDate, getFileId());
					try {
						connection.commit();
					} catch (SQLException e) {
						severe("ACUSFileDBLoadJobException thrown in preprocessFileOpt(ACUSFileDBLoadJob) while trying to commit a delete from RABC_FILE_STATUS", e);
						return ERROR;
					}
//					rfsd.deleteErroredBillRunId(blrunId, "ACUS_INFO_V7");
				}
				
			} catch (ACUSFileDBLoadJobException e) {
				severe("ACUSFileDBLoadJobException thrown in preprocessFileOpt(ACUSFileDBLoadJob..", e);
				return ERROR;
			}

		}

		return preprocessFile(file) ? SUCCESS : ERROR;
	}
	
	/**
	 * @param file. Accepts a file as the input parameter.
	 * This validates the qualifiers on the input file.
	 */

	protected boolean preprocessFile(File file) {

		boolean success = super.preprocessFile(file);
		headerCount = 0;
		trailerCount = 0;
		if (success) {
				try {
					String fileName = file.getName();
					String[] fileTokens = fileName.split("\\.");
					
					// convert Julian Date to Gregorian Date
					String julianDateOnFile = fileTokens[3].trim().substring(1);
					DateFormat julianDate = new SimpleDateFormat("yyyyDDD");
					Date parseJulianDate = julianDate.parse(julianDateOnFile);
					
					DateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy");
					dateFormat.setLenient(false);
					String gregorianDate = dateFormat.format(parseJulianDate);
					
					String timeOnFile = fileTokens[4].substring(1,3) + ":" + fileTokens[4].substring(3,5)+":"+fileTokens[4].substring(5,7);
					String dateTime	  = gregorianDate + " " + timeOnFile; 

					DateFormat date_formatter = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
					date_formatter.setLenient(false); //this checks to see if each of the parameter in the date time is valid
					processDateTime	= date_formatter.parse(dateTime);
					lineCount=0;
				} catch (ParseException e) {
					severe ("Error in the preprocessFile. Parse Logic problem", e);
					success=false;
				}
		}
		return success;
	}	

	/**
	 *	@param  accepts one line from the input file as its parameter.
	 *  @return an int depending on the return code. It return ERROR, DUP or SKIP.
	 *  This method, parses each line in the input file and identifies if it is a header, detail or a trailer record.
	 *  Depending on the type of the input file, it calls either the ACUS_INFO or the ACUS_BILLPAYER load job for 
	 *  processing the details records. 
	 *  This method errors out, if - 
	 *   - the header count is not equal to 1 
	 *   - there is more than one trailer 
	 *   - if the trailer count is not equal to the number of detail records.  
	 *  
	 */
	
	public int parseLine(String line) throws Exception {

		debug("line: " + line);
		// if the firstLineCheck is true, then do not do other processing. Just return true and continue reading the
		// other records.

		if ((trailerCount==1)&&(headerCount==1))
		{
//			severe("Records found after the trailer. Invalid file");
			throw new ACUSFileDBLoadJobException("Invalid file since there are records found after the trailer.." + line);
		}
		
		if (isHeader(line))
		{
			//if the isHeader is satisfied, then the record is a header.
			if (handleHeader(line))
			{
				headerCount ++;
				if (headerCount > 1)
				{
//					severe("Header Count cannot be greater than one. Not processing file.." + line);
					throw new ACUSFileDBLoadJobException("Header Count cannot be greater than one. Not processing file.." + line);			
				}
				else
				{
					//continue processing the next record since the first one is a header. We do not want to error it out
					// since there will be an entry in the RABC_FILE_STATUS when errored.
					return SKIPPED;
				}
			}
			else
			{
				throw new ACUSFileDBLoadJobException("Error in handleHeader. " + line);
			}
		}
	
		//processing of the trailer line		

		if (isTrailer(line)) 		
		{
			if (handleTrailer(line))
			{
				trailerCount++;
				if (trailerCount > 1)
				{
					severe("Trailer Count cannot be greater than one. Not processing file..");
					throw new Exception("Trailer Count cannot be greater than 1. ");			
				}
				
				if (lineCount != trailerCountFromInputRecord)
				{
					severe("Number of lines processed does not equal number in trailer ("
							+ trailerCount + ").");	
					throw new IllegalArgumentException("Number of lines processed does not equal number in trailer. ");
				}		
				
				if (!headerDate.equals(trailerDate))
				{
					severe("Header and trailer timestamps cannot be different.");
					throw new ACUSFileDBLoadJobException("Header and trailer Date/Time do not match. Header Timestamp: " + headerDate + " Trailer Timestamp: " + trailerDate);
				}
			}
			else
			{
				throw new ACUSFileDBLoadJobException("Error in handleTrailer. " + line);
			}
		}

		//Whenever a detail is processed, there should be 1 header record and 0 trailer records. There cannot be any
		// details records after the trailer.
		
		if (headerCount == 1)
		{
			if (trailerCount==0)
			{
					return processRecord(line, procDate);
			}
			else if (trailerCount>1)
			{
				severe("There should be no detail records after the trailer.");
				throw new ACUSFileDBLoadJobException("Exception in the process line. Detail record found after the header record." + line);
			} 
		}
		else if (headerCount==0)
		{
			throw new ACUSFileDBLoadJobException("There should be atleast one header in each record." + line);
		}
		
		// the only time it would come here is when it hits a successful trailer record.
		return SKIPPED;
		
		
	}

	/**
	 * Processes a record in the file.
	 * 
	 * @param line
	 * @return the status of the record
	 * @throws Exception
	 */
	protected abstract int processRecord(String line, String procDate) throws Exception;	
	

	/**
	 * @return int which returns success or failure.
	 * This method does all the post process checking. This method return an error if:
	 * - headerCount is 0 or greater than 1.
	 * - if trailer count is not equal to 1.
	 * - if there is an error while inserting to the RABC_FILE_STATUS table or the RABC_TRIG table.
	 */
	protected int postprocessFileOpt(File file, int success) {
		
		retCode = true;
		//whenever the headCount is Zero the record already has either thrown an exception it is SKIPPED. For skipped records
		// no error message is thrown. It just keep waiting...
		// outOfSequence is set to true only when the record is not in sequence. So if the record is not in sequence, the header count will be 
		//zero but we do not want to send out an email or a severe message. We will just keep looping until we get the correct sequence number record..
		
		//could not have a statement as below since this condition will be satisfied both when the headerCount is Zero and when the records are out of sequence. 
		//if ((headerCount == 0)&&(success!=SKIPPED))
		
		if(outOfSequence) 
		{
			success=SKIPPED;
			// this is done just before the call to the super class 
		   outOfSequence = false;
		}
		else
		{
			if ((success!=DUPLICATE)&&((headerCount == 0)||(headerCount > 1)))
			{
				severe("There is no header or the header is invalid for this file");
				retCode=false;
			}
//			if (headerCount > 1)
//			{
//				severe("There cannot be more than one header for a file...");
//				retCode=false;
//			}

			if ((success!=SKIPPED) && (success!=DUPLICATE))
			{
				//if there is no trailer record, we need to make sure that an error is return before the call to the postProcessfileOpt
				//since the commit to the database takes place there...
				//if a record is skipped, it may not come to trailer record yet... So we do not want to display this message..			
				if(trailerCount != 1)
				{
					severe("trailer count has to be 1 for successful processing of the file");
					//return super.postprocessFileOpt(file, success);
					success=ERROR;
				}
			}
			
		}

		//if the ret code from the super process is successful, and if the processing of all the records so far is not skipped, then
		// insert a record into the RABC_FILE_STATUs to tell the status of the file just received.
		// The call to the super class has to be before the call to the RABC_FILE_STATUS_TABLE. In case, there is an error
		// in the call to the superclass, the file status table should have that value.
		
		if (((headerCount==0)&&(success==SKIPPED))||(success==DUPLICATE))
		{
			//In case of a skipped file or a duplicate file, we need to move the file to the error folder so that we do not loop over it again and again. 
			// We do not want to write to the RABC_FILE_STATUS table. So do the super.postprocessFileOpt with Error as parameter.
			// The value of success will be unchanged.
			
			//(headerCount==0)&&(success==SKIPPED) - condition will be satisfied both when the record is out of sequence and when there is an invalid header..
			if (outOfSequence)
			{
				outOfSequence = false;
				success = super.postprocessFileOpt(file, success);
			}
			else
			{
				super.postprocessFileOpt(file, ERROR);
			}
		}
		else
		{
				success = super.postprocessFileOpt(file, success);
		}

		if (retCode)
		{
			if ((success!=SKIPPED) && (success!=DUPLICATE))
			{
				try {

					int insertStatus = -1;
					if (success==SUCCESS)
					{
						insertStatus = 0;
					}
					else if (success==ERROR)
					{
						insertStatus = 1;
					}
	
					if (insertStatus == -1)
					{
						severe("There will be no insert done to the RABC_FILE_STATUS table. Please check why status has a value of -1." );
						return ERROR;
					}
					else
					{
						int noOfbillId = rfsd.insertIntoFileStatus(connection, getFileId(), billRunId, insertStatus, lineCount, currentFile.getName(), new java.sql.Date(acusInvDate.getTime()) );					
//						int noOfbillId = rfsd.insertIntoFileStatus("ACUS_INFO_V7", billRunId, insertStatus, lineCount, currentFile.getName() );
						try {
							connection.commit();
						} catch (SQLException e) {
							severe("error in the postprocessFileOpt. Error while saving the connection after insert to RABC_FILE_STATUS table. ", e);
							
						}
						if (noOfbillId>0)
						{
							info("A record has been successfuly inserted into RABC_FILE_STATUS");
						}
	
					}
				} catch (ACUSFileDBLoadJobException ae) {

					severe("error in the postprocessFileOpt. Error trying to insert into the RABC_FILE_STATUS. ", ae);
					success = ERROR;
				}
			}
		}
		else
		{
			success=ERROR;
		}
		return success;
	}	

	/**
	 * @return return a boolean which indicate success or failure.
	 * @param accepts a file and success/failure
	 * On successful processing of the ACUS/CIS files, this method inserts a record in to the trigger table 
	 * and calls postprocessFile.
	 */
	public boolean postprocessFile(File file, boolean success) 
	{
		if (success)
		{
			if (!insertTrigger()) 
			{
				success = false;
				severe("Error in insert to the RABC_TRIG table.");
			}
		}
		return super.postprocessFile(file, success);
   }
	
	
/**
 * 
 * 
 * @return true if the insert to the RABC_TRIG is successful
 */	
	protected boolean insertTrigger() {
		if (!AcusFileDBloadJobTrig.insertTrigger(connection, currentFile.getName(), getFileId(),billRound,headerMonth, headerDay, headerYear)) {
//		if (!AcusFileDBloadJobTrig.insertTrigger(connection, currentFile.getName(), "ACUS_INFO_V7")) {
			return false;
		}
		return true;
	}	
	
}

