/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.admin;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.StringTokenizer;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.att.bac.rabc.ConnectionManager;
import com.att.bac.rabc.DataTblDdlBean;
import com.att.bac.rabc.ProgressBar;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.StaticDataLoader;
import com.att.bac.rabc.Tree;
import com.att.bac.rabc.TreeService;
import com.att.bac.rabc.View;

/**
 * Module description: 
 * 
 * This is an View Page Action class for the view definition Component. 
 *
 * @author Umesh Deole- UD7153
 */
public class ViewAction extends DispatchAction {
	private ViewService viewService = ViewService.getViewService();
	private static final Logger logger = Logger.getLogger(ViewAction.class);
	
	/**
	 * Default dispatch action method which will collect URL parameters & set it as request attributes
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @see org.apache.struts.actions.DispatchAction#unspecified(org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public ActionForward unspecified(ActionMapping mapping,ActionForm form,HttpServletRequest request, HttpServletResponse response){
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		Enumeration et = request.getParameterNames();
		while (et.hasMoreElements()){
			String paramName = (String)et.nextElement();
			String paramValue = request.getParameter(paramName);
			
			if ("viewName".equals(paramName.trim())){
				request.setAttribute("viewName",paramValue);
			}
			
			if ("dbNode".equals(paramName.trim())){
				request.setAttribute("dbNode",paramValue);
			}
			
			if ("type".equals(paramName.trim())){
				request.setAttribute("type",paramValue);
			}
			
			if ("fromPage".equals(paramName.trim())){
				request.setAttribute("fromPage",paramValue);
			}
			
			if ("tableName".equals(paramName.trim())){
				request.setAttribute("tableName",paramValue);
			}
		}
		return load(mapping,form,request,response);
	}
	
	/**
	 * Dispatch action method which does following things 
	 * 1) Check whether this is create / update action based on URL parameters
	 * 2) If its update then get the view details using qView query; else build dummy object
	 * 3) Takes the where condition i.e column select_value & replaces "(" & ")" 
	 * 4) Using the above value form the where clause
	 * 5) Set all the values in session
	 * 6) Update / Insert queries
	 * 7) Check whether view condition is not more than 300 characters
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward load(ActionMapping mapping,ActionForm form,HttpServletRequest request, HttpServletResponse response){
		ViewForm viewForm = (ViewForm) form;
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		viewForm.setDispatch("save");
		
		ActionForward forward = null ;
		Connection connection = null ;
		
		List failureList = new ArrayList();
		List args = new ArrayList();
		List viewNameList = new ArrayList();
		
		if (!viewForm.isDuplicate()){
			viewForm.setFromPage((String)request.getParameter("fromPage")) ;
		}
		
		if (request.getParameter("viewName")!=null && !(request.getParameter("viewName").equals("0")) ){
			request.setAttribute("viewName",(String)request.getParameter("viewName"));
			request.setAttribute("fromPage",(String)request.getParameter("fromPage"));
			if (!viewForm.isDuplicate()) {
				viewForm.setActionType("update");
			} 
		}else {
			
			if (request.getParameter("tableName")!=null){
				request.setAttribute("tableName",(String)request.getParameter("tableName"));
				request.setAttribute("fromPage",(String)request.getParameter("fromPage"));
			}
			viewForm.setActionType("insert");
		}
		progressBar.setProgressPercent(10);
		
		try {
			// Get the connection from the available pool
			connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));

			TreeService treeService = new TreeService();
			Tree tree = treeService.generateTree(connection, failureList, args, (String)request.getSession().getAttribute("region"));
			viewForm.setTableTree(tree);
			progressBar.setProgressPercent(30);
			
			/*
			 * Get the data node from the session. This should be passed by the calling pages
			 */
			if (viewForm.isDuplicate()) {
				
			}else if (request.getAttribute("dbNode")==null){
				viewForm.setSelDataNode("");
			}else {
				viewForm.setSelDataNode((String)request.getAttribute("dbNode"));
			}
			// Get distinct dbnode list here 
			viewForm.setDataSourceList(viewService.getDistinctDbNodeList((String)request.getSession().getAttribute("region"))); 
			progressBar.setProgressPercent(40);
			
			// if view name is duplicate then redirect to same page 
			if (viewForm.isDuplicate()) {
				View view = viewForm.getView();
				
				String viewName = view.getViewName();
				List selectValueList = new ArrayList() ;				
				view.setViewName(viewName);
				
				selectValueList = viewService.buildSelectClause(viewForm.getViewData(),viewName) ;
				progressBar.setProgressPercent(60);
				
				String tableName = (String) selectValueList.get(0);
				String selectValue = (String) selectValueList.get(1);
				
				/*
				 * Form the view Data which will be put on the form & subsequently on the 
				 */
				
				view.setTableName(tableName);
				
				if ("on".equals(viewForm.getChkPrevious()))
					view.setPrevInd("Y"); 
				else 	
					view.setPrevInd("N");
				
				progressBar.setProgressPercent(80);
				
				view.setSelectValue(selectValue);
				
				String viewData = viewService.getViewData(view.getSelectValue(),view.getTableName(),failureList);

				viewForm.setViewData(viewData);
				progressBar.setProgressPercent(90);
				
				StringTokenizer viewTokenizer = new StringTokenizer(viewForm.getViewData(),";");
				while (viewTokenizer.hasMoreTokens()) {
					viewForm.addViewData(viewTokenizer.nextToken());
		        }
			}else if (request.getAttribute("viewName")!=null && !(request.getAttribute("viewName").equals("0")) ){
				/*
				 * Get the view object; replace the view name in the object replacing the "VW_" string with ""
				 */
				args.add((String)request.getAttribute("viewName"));
				View view = viewService.getView(connection,failureList,args);
				progressBar.setProgressPercent(60);
				
				String viewName = view.getViewName();
				viewName = viewName.substring(viewName.indexOf("VW_")+3 ,viewName.length());
				view.setViewName(viewName);
				
				viewForm.setView(view);
				
				/*
				 * Get the data types for columns inside the table & set appropriate fields on the form
				 */
				String tableName = view.getTableName();
				String columnNames = "";
				String columnDataTypes = "";				
				List columnList = StaticDataLoader.getDataTblDdlByAlertProcTbl(tableName, (String)request.getSession().getAttribute("region"));
				
				for (int i= 0; i< columnList.size(); i++){
					DataTblDdlBean dataTblDdl = (DataTblDdlBean)columnList.get(i);
					if(i==0){
						columnNames =  dataTblDdl.getTblDdlName() + ",";
						columnDataTypes = dataTblDdl.getTblDdlDataType() + ",";	
					}
					else{
						columnNames = columnNames + dataTblDdl.getTblDdlName() + ",";
						columnDataTypes = columnDataTypes + dataTblDdl.getTblDdlDataType() + ",";	
					}									
				}				
				viewForm.setColumnNames(columnNames);
				viewForm.setColumnDataTypes(columnDataTypes);				
			
				progressBar.setProgressPercent(80);
				
				String prevViewName = "" ;
				/*
				 * Get the value of previous indicator & set appropriate attribute on the form
				 */
				if ("Y".equals(view.getPrevInd())){
					List prevViewArgs = new ArrayList();
					
					String str = request.getAttribute("viewName").toString() ;
					
					str = str.substring(str.length()-5) ; 
					
					if ("_PREV".equals(str)) {
						prevViewName = (String)request.getAttribute("viewName"); 
					} else {
						prevViewName = (String)request.getAttribute("viewName")+ "_PREV";
					}
					
					prevViewArgs.add(prevViewName);
					if (viewService.previousViewCheck(connection,failureList,prevViewArgs)){
						viewForm.setChkPrevious("on");
					}
				}
				progressBar.setProgressPercent(90);
				
				/*
				 * Form the view Data which will be put on the form & subsequently on the 
				 */
				String viewData = viewService.getViewData(view.getSelectValue(),view.getTableName(),failureList);
				viewForm.setViewData(viewData);
				
				StringTokenizer viewTokenizer = new StringTokenizer(viewData,";");
				while (viewTokenizer.hasMoreTokens()) {
					viewForm.addViewData(viewTokenizer.nextToken());
		        }
			}else {
				// Build dummy view object
				View view = new View();
				view.setViewName("");
				progressBar.setProgressPercent(60);
				view.setViewDesc("");
				view.setTableName("");
				progressBar.setProgressPercent(90);
				view.setPrevInd("N");
				view.setSelectValue("");
				view.setUserId("");
				viewForm.setView(view);
			}	
		} catch(SQLException sx) {
			   logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			   failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch(Exception e){
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			   SQLHelper.closeConnection(connection, failureList, logger);
		}
		progressBar.setProgressPercent(100);
		
		if (!failureList.isEmpty()){
			request.setAttribute("failures", failureList);
			forward =  mapping.findForward("error");
		}
		else {
			
			if (request.getAttribute("fromPage") == null || request.getAttribute("fromPage").equals("") ||  request.getAttribute("fromPage").equals("null") ) {
				forward =  mapping.findForward("ViewPageDefault");
			} else {
				forward =  mapping.findForward("ViewPage");
			}
		}

		return forward ;
	}
	
	/**
	 * Dispatch action method which does following things 
	 * 1) Depending on the value of actionType, do insert or update
	 * 2) in case of any errors, rollback else commit
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward save(ActionMapping mapping,ActionForm form,HttpServletRequest request, HttpServletResponse response) {
        ViewForm viewForm = (ViewForm) form;
        HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
        View view = viewForm.getView();
        ActionForward forward;
        Connection connection = null;
		boolean isDuplicate = false ; 
        List failureList = new ArrayList();
        List args = new ArrayList();
        List viewCheckArgs = new ArrayList();
        if (viewForm.getChkPrevious()==null){
        	view.setPrevInd("N");
        }else if ("on".equals(viewForm.getChkPrevious())){
        	view.setPrevInd("Y");
        }else {
        	view.setPrevInd("N");
        }
        
        args.add(view);
        args.add(viewForm.getViewData());
        args.add((String) session.getAttribute("bacUserID"));
        
        progressBar.setProgressPercent(10);
        
        /*
         * Called on save 
         */
        try {
            connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
            connection.setAutoCommit(false);

            // Marks the transaction
            if ("update".equals(viewForm.getActionType())){
            	viewService.updateView(connection, failureList, args);
            	progressBar.setProgressPercent(70);
            	viewService.updatePreviousView(connection, failureList, args);
            	progressBar.setProgressPercent(90);
            }else {
				
            	String viewName = "VW_"+view.getViewName();
            	viewCheckArgs.add(viewName) ;
            	
            	isDuplicate = viewService.viewCheck(connection , failureList , viewCheckArgs) ;
            	progressBar.setProgressPercent(50);
            	viewForm.setDuplicate(isDuplicate) ;
            	if (!isDuplicate) { 
            		viewService.insertView(connection, failureList, args);
            		progressBar.setProgressPercent(80);
            		viewService.insertPreviousView(connection, failureList, args);
            	}
            	progressBar.setProgressPercent(90);
        	 }
		} catch(SQLException sqle) {
			   logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sqle.getMessage(), sqle);
			   failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sqle));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
        } catch (Exception e) {
            logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
        } finally {
            // If update did not occur properly then failure list would not be empty; rollback the transaction
            if (!failureList.isEmpty()){
                try {
                	connection.rollback();
                }catch(SQLException sx) {
                   logger.error(RABCMessages.getMessage("ERR_SQL_ROLLBACK_EXEC") + " Exception details: " + sx.getMessage(), sx);
                   failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_ROLLBACK_EXEC"), sx));
                } 
            }else {
                // No errors; commit the transaction
                try {
                	connection.commit();
                }catch(SQLException sx) {
                	logger.error(RABCMessages.getMessage("ERR_SQL_COMMIT_EXEC") + " Exception details: " + sx.getMessage(), sx);
                	failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_COMMIT_EXEC"), sx));
                } 
            }
            SQLHelper.closeConnection(connection, failureList, logger);
        }
        progressBar.setProgressPercent(100);
        
        /*
         * Decide to which page you want to take the user to
         */                     
        if (!failureList.isEmpty()){
        	forward = mapping.findForward("error");
        }else{
             //code to save the report
        	if (isDuplicate) {
        		request.setAttribute("viewName", "VW_"+view.getViewName());
        		forward = load(mapping, form, request, response);
        	}
        	else {	
        		request.setAttribute("viewName", view.getViewName());
           		
        		request.setAttribute("fromPage",viewForm.getFromPage()) ;
        		
        		if (request.getAttribute("fromPage") == null || request.getAttribute("fromPage").equals("") ||  request.getAttribute("fromPage").equals("null") ) {
    				forward =  mapping.findForward("ViewMainPage");
    			} else {
    				forward = mapping.findForward("ViewUpdateSuccess");
    			}
        	}
        }
        return forward;
	}
	
	/**
	 * Dispatch action method is called when view is successfully inserted/updated. 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward updateSuccess(ActionMapping mapping,ActionForm form,HttpServletRequest request, HttpServletResponse response) {
		ViewForm viewForm = (ViewForm)form;
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		viewForm.setView((View)request.getAttribute("view"));
		Connection connection = null;
		ActionForward forward = null ;
		List args = new ArrayList();
		List failureList = new ArrayList();
		progressBar.setProgressPercent(10);
		
		try {
			// Get the connection from the available pool
			connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
			progressBar.setProgressPercent(30);
			String viewName = (String)request.getAttribute("viewName");
			args.add(viewName);
			progressBar.setProgressPercent(50);
			
			View view = viewService.getView(connection,failureList,args);
			progressBar.setProgressPercent(90);
        	
			if (view!=null){
				viewForm.setView(view);
			}
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		progressBar.setProgressPercent(100);
		
		if (!failureList.isEmpty()){
			request.setAttribute("failures", failureList);
			forward =  mapping.findForward("error");
		}
		else {
			forward =  mapping.findForward("ViewPage");
		}
		return forward ;
	}
	
	/**
	 * Dispatch action method executed when user clicks for inserting previous view 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 */
	public ActionForward savePreviousView(ActionMapping mapping,ActionForm form,HttpServletRequest request, HttpServletResponse response) {
        
		ViewForm viewForm = (ViewForm) form;
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
        //View view = viewForm.getView();
        ActionForward forward;
        Connection connection = null;
		boolean isDuplicatePreviousView = false ; 
        List failureList = new ArrayList();
        List args = new ArrayList();
        List previousViewCheckArgs = new ArrayList();
        String tableName = "";
        String viewName = "" ;
        progressBar.setProgressPercent(10);
        
        /*
         * Called on save 
         */
        try {
            connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
            connection.setAutoCommit(false);
            progressBar.setProgressPercent(30);
            
            if (request.getParameter("tableName")!=null){
    			request.setAttribute("tableName",(String)request.getParameter("tableName"));
            }	
            tableName = (String)request.getAttribute("tableName") ;
            
            if(tableName.length() > 22){
            	String suffix = "_PREV";
            	String prefix = "VW_";
            	String baseName = tableName;
            	if(baseName.length() > 22){
            		int index = baseName.length() - 22;
            		baseName = baseName.substring(index);
            	}
            	
            	if(baseName.startsWith("_")){
            		prefix = "VW";
            	}
            	
            	if(baseName.endsWith("_")){
            		suffix = "PREV";
            	}
            	viewName = prefix + baseName + suffix ;
            }
            else{
            	 viewName = "VW_"+ tableName + "_PREV" ;
            }
            
           
            //form the view name by taking table name 
            
            //previousViewCheckArgs.add(tableName) ;
            previousViewCheckArgs.add(viewName) ;
            	
            isDuplicatePreviousView = viewService.previousViewCheck(connection , failureList , previousViewCheckArgs) ;
            progressBar.setProgressPercent(60);
            
            viewForm.setDuplicatePreviousView(isDuplicatePreviousView) ;
            
            previousViewCheckArgs.add(tableName) ; 
            previousViewCheckArgs.add((String) session.getAttribute("bacUserID"));
            progressBar.setProgressPercent(70);
           
            //viewForm.setDuplicate(isDuplicate) ;
            if (!isDuplicatePreviousView) { 
            	viewService.insertPreviousViewForTable(connection, failureList, previousViewCheckArgs);
            }
            progressBar.setProgressPercent(90);
		} catch(SQLException sqle) {
			   logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sqle.getMessage(), sqle);
			   failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sqle));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
        } catch (Exception e) {
            logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
        } finally {
            // If update did not occur properly then failure list would not be empty; rollback the transaction
            if (!failureList.isEmpty()){
                try {
                	viewForm.setPreviousViewInsertSucc(false) ;
                	connection.rollback();
                }catch(SQLException sx) {
                   logger.error(RABCMessages.getMessage("ERR_SQL_ROLLBACK_EXEC") + " Exception details: " + sx.getMessage(), sx);
                   failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_ROLLBACK_EXEC"), sx));
                } 
            }else {
                // No errors; commit the transaction
                try {
                	connection.commit();
                	viewForm.setPreviousViewInsertSucc(true) ;	
                }catch(SQLException sx) {
                	logger.error(RABCMessages.getMessage("ERR_SQL_COMMIT_EXEC") + " Exception details: " + sx.getMessage(), sx);
                	failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_COMMIT_EXEC"), sx));
                } 
            }
            SQLHelper.closeConnection(connection, failureList, logger);
        }
        progressBar.setProgressPercent(100);
        
        /*
         * Decide to which page you want to take the user to
         */                     
        if (!failureList.isEmpty()){
        	forward = mapping.findForward("error");
        }else{
    		request.setAttribute("tableName", tableName);
             //code to save the report
			forward = load(mapping, form, request, response);
        }
        return forward;
	}
}	
