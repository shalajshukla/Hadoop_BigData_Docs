/* Created by Gaurav Bhargava (GB0741) on Dec 11, 2006.
Copyright 2006-2008 AT&T Knowledge Ventures. All rights reserved. */

package com.att.bac.rabc.load.billday.calnet;


/**
 * Data Access Object class for RABC_TOT_BLG_SUMY_AVG table. It uses RABC_TOT_BLG_SUMY
 * table to calculate the average amounts and counts per agency Id and insert the
 * resulting data into RABC_TOT_BLG_SUMY_AVG table.
 * @author GB0741
 */
public class RabcTotBlgSumyAvgDAO {

//	private static final String BLG_SUMY_AVG_QUERY = "Insert Into RABC_TOT_BLG_SUMY_AVG ("
//			+ "Select RUN_DATE, DIVISION, AGENCY_ID, Avg(ACCT_CT),Avg(CURR_MNTH_CHRG_AMT),Avg(CURR_BAL_DUE_AMT),Avg(TOLL_AMT),Avg(OCC_AMT),Avg(BOC_AMT),"
//			+ "Avg(ATT_AMT),Avg(IEC_AMT),Avg(CPUC_SRCG_AMT),Avg(FED_TAX_AMT),Avg(STATE_TAX_AMT),Avg(CITY_TAX_AMT),Avg(SRV_USFF_AMT),"
//			+ "Avg(EUCL_CHRG_AMT),Avg(BLG_SRCG_AMT),Avg(CHCFA_SRCG_AMT),Avg(CHCFB_SRCG_AMT),Avg(LFLN_SRCG_AMT),Avg(HCAP_SRCG_AMT),"
//			+ "Avg(CTF_SRCG_AMT)from RABC_TOT_BLG_SUMY where RUN_DATE= ? and DIVISION = ? group by RUN_DATE, DIVISION, AGENCY_ID)";
//
//	/**
//	 * It is used to insert the records into RABC_TOT_BLG_SUMY_AVG table.
//	 * @param connection, the DB connection to execute insert query.
//	 * @param sqlRunDate, division -> Parameters to sql query
//	 * @return boolean indicating success or failure.
//	 * @throws CalnetException
//	 */
//	protected boolean insertRecords(Connection connection, Date sqlRunDate,
//			String division) throws CalnetException {
//		boolean success = false;
//		PreparedStatement avgPrepStmt = null;
//		try {
//			avgPrepStmt = connection.prepareStatement(BLG_SUMY_AVG_QUERY);
//			avgPrepStmt.setDate(1, sqlRunDate);
//			avgPrepStmt.setString(2, division);
//			avgPrepStmt.executeUpdate();
//			success = true;
//		} catch (SQLException ex) {
//			throw new CalnetException(
//					"Error inserting values in RABC_TOT_BLG_SUMY_AVG", ex);
//		}finally{
//			JDBCUtil.closePreparedStatement(avgPrepStmt);
//		}
//		return success;
//	}
}
