/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.admin.alert.rule;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.att.bac.rabc.PickList;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.StaticDataLoader;
import com.att.bac.rabc.RABCConstantsLists;

/**
 * This is a service class to execute the logic of Alert Rule Description Main Page.
 * 
 * @author Shashank Weginwar - SW3562
 */
public class AlertRuleMainService {
	private static final Logger logger = Logger.getLogger(AlertRuleMainService.class);
	private static AlertRuleMainService alertRuleMainService;
	
	protected static final String SELECT_1 = "SELECT DISTINCT BAR.ALERT_RULE FROM RABC_ALERT_RULE BAR, RABC_PRESN_ID BPI " +
	"WHERE (ALERT_RULE_STATUS IS NULL OR ALERT_RULE_STATUS <> ''DELETED'') AND ALERT_RULE_PRESN_IND = ''Y'' " +
	"AND BAR.PRESN_ID = BPI.PRESN_ID AND (BAR.ALERT_RULE_CREATE_IND IS NULL OR BAR.ALERT_RULE_CREATE_IND <> ''S'') " +
	"ORDER BY UPPER(ALERT_RULE)";
	
	protected static final String SELECT_2 = "SELECT DISTINCT ALERT_RULE_TYPE FROM RABC_ALERT_RULE WHERE " +
	"ALERT_RULE = ''{0}''";
	
	protected static final String checkUpdatePermission = "SELECT ALERT_GRP FROM RABC_UPDATE_GRP WHERE " +
	"ALERT_GRP IN (SELECT DISTINCT ALERT_GRP FROM RABC_ALERT_GRP_USER WHERE USER_ID = UPPER(''{0}'')) AND " +
	"ALERT_RULE = ''{1}''";
	
	protected static final String checkperm = "select distinct alert_grp, funct_cd from rabc_alert_grp_funct "
											+ " where alert_grp in (select alert_grp from rabc_alert_grp_user "
											+ " where  user_id = UPPER(''{0}'')) and funct_cd = ''UA''";
	
	protected static final String currGrps = "SELECT ALERT_GRP FROM RABC_UPDATE_GRP WHERE ALERT_RULE = ''{0}'' " +
	"ORDER BY UPPER(ALERT_GRP)";
	
	/**
	 * Synchronized method to return the instance of AlertRuleMainService object.
	 * It checks the existance of the instance of AlertRuleMainService and if it does not exists
	 * then creates one instance of AlertRuleMainService and returns otherwise it returns the
	 * existing instance of AlertRuleMainService.
	 * 
	 * @return AlertRuleMainService
	 */
	public static synchronized AlertRuleMainService getAlertRuleMainService(){
		if (alertRuleMainService == null){
			alertRuleMainService = new AlertRuleMainService();
		}
		return alertRuleMainService;
	}
	
	/**
	 * Returns 1 user has create access else 0
	 * 
	 * @param connection
	 * @param failures
	 * @param arguments
	 * @return boolean
	 */
	public boolean checkNewButton(Connection connection, List failures, List arguments){
		int count = 0;
		boolean permission;
		Statement st = null;
		ResultSet rst = null;
		String sqlStmt = null;
		List args = new ArrayList();
		args.add(arguments.get(0));
		
		try {
			MessageFormat mf = new MessageFormat(checkperm);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("AlertRuleMainService.checkCreateAccess() - Executing SQL statement: "+ sqlStmt);
			st = connection.createStatement();
			rst = st.executeQuery(sqlStmt);
		
			while (rst.next()) {
				count++;
			}
			if (count > 0){
				permission = true;
			}else {
				permission = false;
			}
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return false;
		} finally {
			SQLHelper.closeResultSet(rst, failures, logger);
			SQLHelper.closeStatement(st, failures, logger);
		}		
		return permission;
	}
	
	/**
	 * Returns the string of current groups for a perticular alert rule.
	 * 
	 * @param connection
	 * @param failures
	 * @param arguments
	 * @return String
	 */
	public String getCurrGrps (Connection connection, List failures, List arguments){
		String currGroups = null;
		String selectSQL = currGrps;
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		List args = new ArrayList();
		args.add(arguments.get(0));
		
		try {
			MessageFormat mf = new MessageFormat(selectSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("AlertRuleMainService.getCurrGrps() - Executing SQL statement: "+ sqlStmt);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			
			while (rs.next()) {
				if (currGroups==null){
					currGroups = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + rs.getString("ALERT_GRP");
				}else {
					currGroups = currGroups + "<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + (rs.getString("ALERT_GRP"));
				}
			}
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return null;
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}		
		return currGroups;
	}
	
	/**
	 * Returns 1 if count is greater than 0.
	 * 
	 * @param connection
	 * @param failures
	 * @param arguments
	 * @return boolean
	 */
	public boolean checkUpdateAccess(Connection connection, List failures, List arguments){
		int count = 0;
		boolean permission;
		String selectSQL = checkUpdatePermission;
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		List args = new ArrayList();
		args.add(arguments.get(0));
		args.add(arguments.get(1));
		
		try {
			MessageFormat mf = new MessageFormat(selectSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("AlertRuleMainService.checkUpdateCount() - Executing SQL statement: "+ sqlStmt);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			
			while (rs.next()) {
				count++;
			}
			if (count > 0){
				permission = true;
			}else {
				permission = false;
			}
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return false;
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}		
		return permission;
	}
	
	/**
	 * Returns the list of db nodes.
	 * 
	 * @param region
	 * @return ArrayList
	 */
	public ArrayList getdbNodeList(String region){
		ArrayList dbNodeList = new ArrayList(); 
		List allDbNodeList = StaticDataLoader.getDBNodeList(region);
		
		if (!allDbNodeList.isEmpty()){
			int allDbNodeListSize = allDbNodeList.size();
			for (int i=0;i<allDbNodeListSize;i++){
				PickList dbNode = (PickList)allDbNodeList.get(i);
				
				if (!dbNodeList.isEmpty()){
					int dbNodeListSize = dbNodeList.size();
					for (int j=0;j<dbNodeListSize;j++){
						PickList currDbNode = (PickList)dbNodeList.get(j);
						if (!currDbNode.getKey().equalsIgnoreCase(dbNode.getKey())){
							dbNodeList.add(dbNode);
						}
					}
				}else {
					dbNodeList.add(dbNode);
				}
			}
		}
		return dbNodeList;
	}
	
	/**
	 * Returns the list of Alert Rules.
	 * 
	 * @return ArrayList
	 */
	public ArrayList getalertRuleTypeList() {
		ArrayList alertRuleTypeList = new ArrayList();
		alertRuleTypeList = RABCConstantsLists.getRABCConstantsLists().getAlertRuleTypesList();
		return alertRuleTypeList;
	} 
	
		
	/**
	 * Returns the list of Alert Rules.
	 * 
	 * @param connection
	 * @param failures
	 * @param args
	 * @return List
	 */
	public List getalertRulesList(Connection connection, List failures, List args){
		String selectSQL = SELECT_1;
		List alertRulesList = new ArrayList();
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		
		try {
			MessageFormat mf = new MessageFormat(selectSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("AlertRuleMainService.getalertRulesList() - Executing SQL statement: "+ sqlStmt);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			
			while (rs.next()) {
				alertRulesList.add(rs.getString("ALERT_RULE"));
			}
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return null;
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
		return alertRulesList;
	}
	
	/**
	 * Check for alert rule type; Tracking or Trending.
	 * Will return "Trend" or "Track" depending on alert type.
	 * 
	 * @param connection
	 * @param failures
	 * @param alertRuleName
	 * @return String
	 * @throws SQLException
	 */
	public String getAlertRuleType(Connection connection,List failures, String alertRuleName) throws SQLException{
		String alertRuleType = null;
		String selectSQL = SELECT_2;
		String trend = "Trend";
		String track = "Track";
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		
		List alertRuleList = new ArrayList();
		alertRuleList.add(alertRuleName);
		
		try {
			MessageFormat mf = new MessageFormat(selectSQL);
			sqlStmt = mf.format((String[])alertRuleList.toArray(new String[alertRuleList.size()]));
			logger.debug("AlertRuleMainService.getAlertRuleType() - Executing SQL statement: "+ sqlStmt);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			logger.debug("SQL - Execution complete.");			
			
			while(rs.next()){	
				alertRuleType = rs.getString("ALERT_RULE_TYPE");
			}
			
			if (alertRuleType.equals("TRACK")){
				return track;	
			} else {
				return trend;
			}
			
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return null;
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
	}
}
