/*
 * Created on Feb 9, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.att.bac.rabc.load.usg;

import java.io.File;
import java.net.UnknownHostException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.StringTokenizer;

import com.att.bac.rabc.util.EmcisEventLogger;
import com.att.carat.util.NetUtil;
import com.sbc.bac.rabc.load.FilePatternLoadJob;
import com.sbc.bac.rabc.load.PrepareTableForRerun;
import com.sbc.bac.rabc.load.RabcLoadJobTrig;
import com.sbc.bac.rabc.load.RetrieveStaticInfo;
import com.sbc.bac.rabc.load.StaticErrorMsgKeys;
import com.sbc.bac.rabc.load.StaticFieldKeys;

/**
 * @author pt6471
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class WNonPlannedUsageActivities extends FilePatternLoadJob {

	 private String file_pattern = null;
	 
	 private PreparedStatement usage_nonplanned_daily, usage_nonplanned_billday, insert_rcd_cls;
	 	 
	 private String division, bill_rnd, bill_rnd_dt, run_date, fileName, fileToken;
	 
	 private String backoutRecovery = null;
	 
	 private File currentFile;
	
	 private int lineCount;
	 
	 private java.sql.Date sqlrun_date;
	 
	 private boolean billDayData;
	 private int billDayCnt, dailyCnt;
	
	 private boolean nevadaBellData;
	 
	public boolean preprocess() {
		super.preprocess();

		try {
			StringBuffer sql = new StringBuffer();
					
			sql.append(" insert into RABC_USG_NONPLAN_DLY_ACTVT (RUN_DATE, DIVISION, CYCLE, USG_RCD_CLS, ACCT_TYPE_CTGY, BUS_RES_IND, TOT_MINS_OF_USE, TOT_MSG_CT, TOT_BLG_CHGS, TOT_OTHR_CHGS, TOT_ECC_SRCG, TOT_OPER_SRCG, TOT_PSSC_SRCG, TOT_LOCL_TAX, AMT_PER_UNIT) ");
			sql.append(" VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ");
			usage_nonplanned_daily = connection.prepareStatement(sql.toString());
			sql.setLength(0);
			
			sql.append(" insert into RABC_USG_NONPLAN_BILL_ACTVT (RUN_DATE, DIVISION, CYCLE, USG_RCD_CLS, BILL_RND, ACCT_TYPE_CTGY, BUS_RES_IND, TOT_MINS_OF_USE, TOT_MSG_CT, TOT_BLG_CHGS, TOT_OTHR_CHGS, TOT_ECC_SRCG, TOT_OPER_SRCG, TOT_PSSC_SRCG, TOT_LOCL_TAX, AMT_PER_UNIT, BLG_MM, BLG_YEAR) ");
			sql.append(" VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ");
			usage_nonplanned_billday = connection.prepareStatement(sql.toString());
			sql.setLength(0);

		} catch (SQLException e) {
			severe(StaticErrorMsgKeys.PREPROCESS_ERROR + e.getMessage());
			return false;
		}
		return true;
	}

	public boolean preprocessFile(File file) {
	
		boolean success = super.preprocessFile(file);
		fileName = file.getName();
		fileToken = "CN41200A";
		int fileNameLength = file.getName().length();
		billDayData = true;
		nevadaBellData = false;
		billDayCnt = 0;
		dailyCnt = 0;
		
		if (success) {
			try {
				
				if 	(file.getName().charAt(0) == StaticFieldKeys.NORTH)	
				  division = StaticFieldKeys.PACBELLNORTH;
				else if (file.getName().charAt(0) == StaticFieldKeys.SOUTH)	
				  division = StaticFieldKeys.PACBELLSOUTH;
				else 
					return false;
				
				int cycle = Integer.parseInt(file.getName().substring(3, 7));
				
				run_date = RetrieveStaticInfo.getProc_dtByCycle(connection, cycle);
				bill_rnd_dt = RetrieveStaticInfo.getbillRndDt_ByCycle(connection, cycle);
				if (run_date.equals(StaticFieldKeys.ZERO)){
					severe(StaticErrorMsgKeys.NORECORD_RABC_CYCLE_CALENDAR + cycle);
					throw new Exception();	
				}
				
				
				DateFormat df = new SimpleDateFormat("MMddyyyy");
				sqlrun_date = new java.sql.Date(df.parse(run_date).getTime());

				lineCount = 0;
				
				backoutRecovery = null;

				if (RabcLoadJobTrig.IsFileLoaded(connection, file, fileNameLength)) {
					backoutRecovery = "Y";
					String tableNm = "RABC_USG_NONPLAN_BILL_ACTVT";
					success = PrepareTableForRerun.deleteTableData(connection,tableNm,division,sqlrun_date);
					//	Both divisions NB (NEVADABELL) and PN (PACBELLNORTH) come from same file!!
					if (division == StaticFieldKeys.PACBELLNORTH)
					 	success = PrepareTableForRerun.deleteTableData(connection,tableNm,StaticFieldKeys.NEVADABELL,sqlrun_date); 
					//tableNm = "RABC_USG_NONPLAN_DLY_ACTVT";
					//success = PrepareTableForRerun.deleteTableData(connection,tableNm,division,sqlrun_date);
					
				}

			
				bill_rnd = RetrieveStaticInfo.getBillRndByCycle(connection, cycle);
				if (bill_rnd.equals(StaticFieldKeys.ZERO) || bill_rnd.equals(StaticFieldKeys.ZERO2)){
				billDayData = false;
				 //severe(StaticErrorMsgKeys.PREPROCESSFILE_ERROR+":No Bill Round");
				 //return false;
				}
				
			} catch (SQLException e) {
				success = false;
				severe(StaticErrorMsgKeys.PREPROCESSFILE_ERROR + e.getMessage());
			} catch (Exception e) {
				severe(
					StaticErrorMsgKeys.PREPROCESSFILE_ERROR
						+ StaticErrorMsgKeys.FILE_NAME_PARSING_ERROR
						+ e);
				return false;
			}
		}

		currentFile = file;
		return success;
	}

	
	
	public int parseLine(String line) throws Exception {

		lineCount++;
		
		StringTokenizer DataLine = new StringTokenizer(line, StaticFieldKeys.SEMICOLON);
		
		int cycle	  		  = Integer.parseInt(DataLine.nextToken().trim());
		int billRnd		  	  = Integer.parseInt(DataLine.nextToken().trim());
		String comyId		  = DataLine.nextToken().trim();
		String processId 	  = DataLine.nextToken().trim();
		int usgRcdCls 	  	  = Integer.parseInt(DataLine.nextToken().trim());
		String actTypeCtgy	  = DataLine.nextToken().trim();
		String busResCoinInd  = DataLine.nextToken().trim();
		double totalMinsOfUse = Double.parseDouble(DataLine.nextToken().trim());
		int totalMsgCount     = Integer.parseInt(DataLine.nextToken().trim());
		double totalBlgChgs	  = Double.parseDouble(DataLine.nextToken().trim());
		double totalOtherChgs = Double.parseDouble(DataLine.nextToken().trim());
		double totalECCSrcg	  = Double.parseDouble(DataLine.nextToken().trim());
		double totalOperSrcg  = Double.parseDouble(DataLine.nextToken().trim());
		double totalPsscSrcg  = Double.parseDouble(DataLine.nextToken().trim());
		double totalLocalTax  = Double.parseDouble(DataLine.nextToken().trim());
		double amtPerUnit	  = Double.parseDouble(DataLine.nextToken().trim());

		String resaleInd = "N";
		if (actTypeCtgy.equals("RS")) resaleInd = "Y";
		if (comyId.equals("NB")) nevadaBellData = true;
		
		try {
			
			if (billRnd == 0){
				/*
				 * Currently MVS is not sending any daily data .. so, for billRnd 0 from file .. ignore data  - Kin
				 * 
				dailyCnt++;
							
				usage_nonplanned_daily.setDate(1,sqlrun_date);
				usage_nonplanned_daily.setString(2,comyId);
				usage_nonplanned_daily.setInt(3,cycle);
				usage_nonplanned_daily.setInt(4,usgRcdCls);
				usage_nonplanned_daily.setString(5,resaleInd);		 
				usage_nonplanned_daily.setString(6,busResCoinInd);
				usage_nonplanned_daily.setDouble(7,totalMinsOfUse);
				usage_nonplanned_daily.setInt(8,totalMsgCount);
				usage_nonplanned_daily.setDouble(9,totalBlgChgs);
				usage_nonplanned_daily.setDouble(10,totalOtherChgs);
				usage_nonplanned_daily.setDouble(11,totalECCSrcg);
				usage_nonplanned_daily.setDouble(12,totalOperSrcg);
				usage_nonplanned_daily.setDouble(13,totalPsscSrcg);
				usage_nonplanned_daily.setDouble(14,totalLocalTax);
				usage_nonplanned_daily.setDouble(15,amtPerUnit);
				usage_nonplanned_daily.addBatch();
				
				if (lineCount % 1000 == 0){
					usage_nonplanned_daily.executeBatch();
				}
				*/
			}
				// Load BILL DAY DATA only if there is a BILL_RND even if file has data ( Kin - Shouldn't happen)
			else if (billDayData) {
				
				billDayCnt++;

				usage_nonplanned_billday.setDate(1,sqlrun_date);
				usage_nonplanned_billday.setString(2,comyId);			
				usage_nonplanned_billday.setInt(3,cycle);
				usage_nonplanned_billday.setInt(4,usgRcdCls);
				usage_nonplanned_billday.setInt(5,Integer.parseInt(bill_rnd));
				usage_nonplanned_billday.setString(6,resaleInd);		
				usage_nonplanned_billday.setString(7,busResCoinInd);
				usage_nonplanned_billday.setDouble(8,totalMinsOfUse);
				usage_nonplanned_billday.setInt(9,totalMsgCount);
				usage_nonplanned_billday.setDouble(10,totalBlgChgs);
				usage_nonplanned_billday.setDouble(11,totalOtherChgs);
				usage_nonplanned_billday.setDouble(12,totalECCSrcg);
				usage_nonplanned_billday.setDouble(13,totalOperSrcg);
				usage_nonplanned_billday.setDouble(14,totalPsscSrcg);
				usage_nonplanned_billday.setDouble(15,totalLocalTax);
				usage_nonplanned_billday.setDouble(16,amtPerUnit);
				usage_nonplanned_billday.setString(17,bill_rnd_dt.substring(0,2));
				usage_nonplanned_billday.setString(18,bill_rnd_dt.substring(4,8));

				usage_nonplanned_billday.addBatch();
				
				if (lineCount % 1000 == 0){
					usage_nonplanned_billday.executeBatch();
				}

				
			}

		}catch (SQLException sqle){
			severe(StaticErrorMsgKeys.INSERT_ERROR + sqle.getMessage());
			 throw new Exception("Exception is from method parseLine - DailyWUSOCActivities");
		}
		
		return SUCCESS;
	}
	
	
	public boolean postprocessFile(File file, boolean success) {
		try{
			//Log the file information to EMCIS_EVENT_LOG and EMCIS_EVENT_LOG_DETAIL
			EmcisEventLogger emcisLogger = new EmcisEventLogger();
			String event_id = "RABC_"+fileToken+"_WE";
            String host = NetUtil.getLocalHostName();
            String hostIP = NetUtil.getLocalIpAddress();
			int sequence = emcisLogger.getEMCISSequence(connection);
			emcisLogger.insertEventLog(connection, sequence, event_id, sqlrun_date, host, hostIP);
			emcisLogger.insertEventLogDetail(connection, sequence, "FileName", fileName);
		}catch (UnknownHostException e) {
            severe("Error getting EMCIS host information ", e);
        }
		if (success) {

			try {
				
				String sql = null;

				if (billDayData && billDayCnt > 0){
					usage_nonplanned_billday.executeBatch();
					sql = " INSERT INTO RABC_RCD_CLS (USG_RCD_CLS) ( SELECT USG_RCD_CLS FROM RABC_USG_NONPLAN_BILL_ACTVT WHERE usg_rcd_cls NOT IN (SELECT USG_RCD_CLS FROM rabc_rcd_cls) AND run_date = ? )";
					insert_rcd_cls = connection.prepareStatement(sql);
					insert_rcd_cls.setDate(1,sqlrun_date);
					insert_rcd_cls.executeUpdate();
				}
				
				if (dailyCnt > 0){
					usage_nonplanned_daily.executeBatch();
					sql = " INSERT INTO RABC_RCD_CLS (USG_RCD_CLS) ( SELECT USG_RCD_CLS FROM RABC_USG_NONPLAN_DLY_ACTVT WHERE usg_rcd_cls NOT IN (SELECT USG_RCD_CLS FROM rabc_rcd_cls) AND run_date = ? )";
					insert_rcd_cls = connection.prepareStatement(sql);
					insert_rcd_cls.setDate(1,sqlrun_date);
					insert_rcd_cls.executeUpdate();
				}
				
				if (!insertTrigger()) {
					severe(
						StaticErrorMsgKeys.POSTPROCESSFILE_ERROR
							+ StaticErrorMsgKeys.TIGGER_TABLE_INSERT_ERROR);
					success = false;
				}
				
			}catch (SQLException sqle){
				severe(StaticErrorMsgKeys.INSERT_ERROR + sqle.getMessage());
				success = false;
			}
			
			}
		return super.postprocessFile(file, success);
	}

	
	public boolean postprocess(boolean success) {

		try {
			
			usage_nonplanned_daily.close();
			usage_nonplanned_billday.close();
			if (insert_rcd_cls != null)
				insert_rcd_cls.close();
		
		} catch (SQLException e) {
			severe(
				StaticErrorMsgKeys.POSTPROCESS_ERROR
					+ StaticErrorMsgKeys.SQL_CLOSE_ERROR
					+ e);
			success = false;
		}

		return super.postprocess(success);
	}

	private boolean insertTrigger() {
		if (dailyCnt > 0){
		 if(!RabcLoadJobTrig.insertTrigger(connection,currentFile.getName(),"CN41ND",division,run_date,backoutRecovery,bill_rnd))
			return false;
		 
		 if (nevadaBellData)
		 	if(!RabcLoadJobTrig.insertTrigger(connection,currentFile.getName(),"CN41ND","NB",run_date,backoutRecovery,bill_rnd))
				return false;
		 }
		if (billDayData && billDayCnt > 0){
			 if(!RabcLoadJobTrig.insertTrigger(connection,currentFile.getName(),"CN41NB",division,run_date,backoutRecovery,bill_rnd))
				return false;
			 
			 if (nevadaBellData)
				 if(!RabcLoadJobTrig.insertTrigger(connection,currentFile.getName(),"CN41NB","NB",run_date,backoutRecovery,bill_rnd))
					return false;
			 }

		return true;
		
	}


}
