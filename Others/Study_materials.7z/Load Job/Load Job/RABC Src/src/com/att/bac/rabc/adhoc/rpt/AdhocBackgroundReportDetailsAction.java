package com.att.bac.rabc.adhoc.rpt;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.att.bac.rabc.ConnectionManager;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;

public class AdhocBackgroundReportDetailsAction extends DispatchAction{
	
	 public static Logger logger = Logger.getLogger(AdhocBackgroundReportDetailsAction.class);
	 
	    protected ActionForward unspecified(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
	    	return view(mapping, form, request, response);				
	    }	

		public ActionForward view(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse res) {
			AdhocBackgroundReportDetailsForm detailsForm = (AdhocBackgroundReportDetailsForm)form;
	        HttpSession session = request.getSession(true);
			String region = (String) session.getAttribute("region");
			String tableNode = (String) session.getAttribute("tableNode"); 
//			String userId = (String) session.getAttribute("bacUserID");
			Connection connection = null;
	        List failureList = new ArrayList();
	        int reportNumber=0;
	        
			if (request.getParameter("bckGrndRptNum")!=null) {
				reportNumber = Integer.parseInt(request.getParameter("bckGrndRptNum"));
				if (reportNumber==0) {
		            failureList.add(new RABCException(RABCMessages.getMessage("background report Number cannot be 0. Please check..", new String[] {"General Exception"})));
				}
			} 
			
			if (request.getParameter("reportName")!=null) {
				detailsForm.setReportName(request.getParameter("reportName"));
			}
	        
	        try {
	            connection = ConnectionManager.getConnection(region);
	            AdhocBackgroundReportDetailsDAO detailsDao = new AdhocBackgroundReportDetailsDAO();
	            detailsDao.getAdhocBackgroundReportDetails(connection, failureList, detailsForm, tableNode, reportNumber);
	            
	        } catch(Exception e) {
				logger.error(RABCMessages.getMessage("ERROR_IN_BKG_RPT", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
	            failureList.add(new RABCException(RABCMessages.getMessage("ERROR_IN_BKG_RPT", new String[] {"General Exception"}), e));
			} finally {
				SQLHelper.closeConnection(connection, failureList, logger);
			}				
			 if (!failureList.isEmpty()){
					request.setAttribute("failures", failureList);
					return mapping.findForward("error");
				} else {
					return mapping.findForward("success");
			 }
		}
	    
}
