/* Created by Prachi Chhabra (PC2774) on Dec 19, 2006.
Copyright 2006-2008 AT&T Knowledge Ventures. All rights reserved. */

package com.att.bac.rabc.load.usage.calnet;

import java.util.Date;
import com.att.bac.rabc.load.calnet.CalnetDTO;

/**
 * This class represents table RABC_BILLDAY_USG_PLAN_ACTVT. It has fields corresponding
 * to columns in the this table and provide getter & setter methods to populate the fields.
 * @author PC2774
 */
public class BillDayUsgPlanActv extends CalnetDTO{
	private Date runDate;
	private String division;
	private int cycle;
	private String agencyID;
	private int usgPlanCd;
	private double totMinsOfUse;
	private long totMsgCt;
	private double totBlgChgs;
	private double totBlgDsct;
	private long totMinsMsgAlwn;
	private double TotAmtAlwn;
	private long totNumOfAccts;
	private double amtPerUnit;
	private String busResInd;
	private String billRnd;
	private String billMm;
	private String billYear;
	/**
	 * @return Returns the agencyID.
	 */
	public String getAgencyID() {
		return agencyID;
	}
	/**
	 * @param agencyID The agencyID to set.
	 */
	public void setAgencyID(String agencyID) {
		this.agencyID = agencyID;
	}
	/**
	 * @return Returns the amtPerUnit.
	 */
	public double getAmtPerUnit() {
		return amtPerUnit;
	}
	/**
	 * @param amtPerUnit The amtPerUnit to set.
	 */
	public void setAmtPerUnit(double amtPerUnit) {
		this.amtPerUnit = amtPerUnit;
	}
	/**
	 * @return Returns the billMm.
	 */
	public String getBillMm() {
		return billMm;
	}
	/**
	 * @param billMm The billMm to set.
	 */
	public void setBillMm(String billMm) {
		this.billMm = billMm;
	}
	/**
	 * @return Returns the billRnd.
	 */
	public String getBillRnd() {
		return billRnd;
	}
	/**
	 * @param billRnd The billRnd to set.
	 */
	public void setBillRnd(String billRnd) {
		this.billRnd = billRnd;
	}
	/**
	 * @return Returns the billYear.
	 */
	public String getBillYear() {
		return billYear;
	}
	/**
	 * @param billYear The billYear to set.
	 */
	public void setBillYear(String billYear) {
		this.billYear = billYear;
	}
	/**
	 * @return Returns the busResInd.
	 */
	public String getBusResInd() {
		return busResInd;
	}
	/**
	 * @param busResInd The busResInd to set.
	 */
	public void setBusResInd(String busResInd) {
		this.busResInd = busResInd;
	}
	/**
	 * @return Returns the cycle.
	 */
	public int getCycle() {
		return cycle;
	}
	/**
	 * @param cycle The cycle to set.
	 */
	public void setCycle(int cycle) {
		this.cycle = cycle;
	}
	/**
	 * @return Returns the division.
	 */
	public String getDivision() {
		return division;
	}
	/**
	 * @param division The division to set.
	 */
	public void setDivision(String division) {
		this.division = division;
	}
	/**
	 * @return Returns the runDate.
	 */
	public Date getRunDate() {
		return runDate;
	}
	/**
	 * @param runDate The runDate to set.
	 */
	public void setRunDate(Date runDate) {
		this.runDate = runDate;
	}
	/**
	 * @return Returns the totAmtAlwn.
	 */
	public double getTotAmtAlwn() {
		return TotAmtAlwn;
	}
	/**
	 * @param totAmtAlwn The totAmtAlwn to set.
	 */
	public void setTotAmtAlwn(double totAmtAlwn) {
		TotAmtAlwn = totAmtAlwn;
	}
	/**
	 * @return Returns the totBlgChgs.
	 */
	public double getTotBlgChgs() {
		return totBlgChgs;
	}
	/**
	 * @param totBlgChgs The totBlgChgs to set.
	 */
	public void setTotBlgChgs(double totBlgChgs) {
		this.totBlgChgs = totBlgChgs;
	}
	/**
	 * @return Returns the totBlgDsct.
	 */
	public double getTotBlgDsct() {
		return totBlgDsct;
	}
	/**
	 * @param totBlgDsct The totBlgDsct to set.
	 */
	public void setTotBlgDsct(double totBlgDsct) {
		this.totBlgDsct = totBlgDsct;
	}
	/**
	 * @return Returns the totMinsMsgAlwn.
	 */
	public long getTotMinsMsgAlwn() {
		return totMinsMsgAlwn;
	}
	/**
	 * @param totMinsMsgAlwn The totMinsMsgAlwn to set.
	 */
	public void setTotMinsMsgAlwn(long totMinsMsgAlwn) {
		this.totMinsMsgAlwn = totMinsMsgAlwn;
	}
	/**
	 * @return Returns the totMinsOfUse.
	 */
	public double getTotMinsOfUse() {
		return totMinsOfUse;
	}
	/**
	 * @param totMinsOfUse The totMinsOfUse to set.
	 */
	public void setTotMinsOfUse(double totMinsOfUse) {
		this.totMinsOfUse = totMinsOfUse;
	}
	/**
	 * @return Returns the totMsgCt.
	 */
	public long getTotMsgCt() {
		return totMsgCt;
	}
	/**
	 * @param totMsgCt The totMsgCt to set.
	 */
	public void setTotMsgCt(long totMsgCt) {
		this.totMsgCt = totMsgCt;
	}
	/**
	 * @return Returns the totNumOfAccts.
	 */
	public long getTotNumOfAccts() {
		return totNumOfAccts;
	}
	/**
	 * @param totNumOfAccts The totNumOfAccts to set.
	 */
	public void setTotNumOfAccts(long totNumOfAccts) {
		this.totNumOfAccts = totNumOfAccts;
	}
	/**
	 * @return Returns the usgPlanCd.
	 */
	public int getUsgPlanCd() {
		return usgPlanCd;
	}
	/**
	 * @param usgPlanCd The usgPlanCd to set.
	 */
	public void setUsgPlanCd(int usgPlanCd) {
		this.usgPlanCd = usgPlanCd;
	}
}
