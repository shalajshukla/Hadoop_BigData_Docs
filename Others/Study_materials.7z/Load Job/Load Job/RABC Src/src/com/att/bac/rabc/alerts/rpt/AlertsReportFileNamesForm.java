/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.rpt;

import java.util.ArrayList;
import java.util.List;

import com.att.bac.rabc.PagedForm;

/**
 * This is an action form class to represent the Alert Report File Names Form for page 15.
 * 
 * @author Nalina Pandiyan - NP5434
 */
public class AlertsReportFileNamesForm extends PagedForm {
	private Integer fileSeqNum;
	private Integer partiRefId;
	private String divisionName;
	private String procDate;
	private String fileDIV;
	private String emailRecipients;
	private String dataPresent;
	private String header1;
	private String header2;
	private List fileNamesList = new ArrayList();
	private int pageshow;
	
	/**
	 * @return Returns the divisionName.
	 */
	public String getDivisionName() {
		return divisionName;
	}
	
	/**
	 * @param divisionName The divisionName to set.
	 */
	public void setDivisionName(String divisionName) {
		this.divisionName = divisionName;
	}
	
	/**
	 * @return Returns the fileSeqNum.
	 */
	public Integer getFileSeqNum() {
		return fileSeqNum;
	}
	
	/**
	 * @param fileSeqNum The fileSeqNum to set.
	 */
	public void setFileSeqNum(Integer fileSeqNum) {
		this.fileSeqNum = fileSeqNum;
	}
	
	/**
	 * @return Returns the fileSeqNum.
	 */
	public Integer getPartiRefId() {
		return partiRefId;
	}
	
	/**
	 * @param partiRefId The partiRefId to set.
	 */
	public void setPartiRefId(Integer partiRefId) {
		this.partiRefId = partiRefId;
	}
	
	/**
	 * @return Returns the fileSeqNum.
	 */
	public String getProcDate() {
		return procDate;
	}
	
	/**
	 * @param procDate The procDate to set.
	 */
	public void setProcDate(String procDate) {
		this.procDate = procDate;
	}
	
	/**
	 * @return Returns the fileNamesList.
	 */
	public List getFileNamesList() {
		return fileNamesList;
	}
	
	/**
	 * @param fileNamesList The fileNamesList to add.
	 */
	public void addFileNamesList(FileNames fileNames) {
		this.fileNamesList.add(fileNames);
	}
	
	/**
	 * @return Returns the fileDIV.
	 */
	public String getFileDIV() {
		return fileDIV;
	}
	
	/**
	 * @param fileDIV The fileDIV to set.
	 */
	public void setFileDIV(String fileDIV) {
		this.fileDIV = fileDIV;
	}
	/**
	 * @return Returns the emailRecipients.
	 */
	public String getEmailRecipients() {
		return emailRecipients;
	}

	/**
	 * @param emailRecipients The emailRecipients to set.
	 */
	public void setEmailRecipients(String emailRecipients) {
		this.emailRecipients = emailRecipients;
	}

	/**
	 * @return Returns the dataPresent.
	 */
	public String getDataPresent() {
		return dataPresent;
	}

	/**
	 * @param dataPresent The dataPresent to set.
	 */
	public void setDataPresent(String dataPresent) {
		this.dataPresent = dataPresent;
	}

	/**
	 * @return Returns the header1.
	 */
	public String getHeader1() {
		return header1;
	}

	/**
	 * @param header1 The header1 to set.
	 */
	public void setHeader1(String header1) {
		this.header1 = header1;
	}

	/**
	 * @return Returns the header2.
	 */
	public String getHeader2() {
		return header2;
	}

	/**
	 * @param header2 The header2 to set.
	 */
	public void setHeader2(String header2) {
		this.header2 = header2;
	}

	/**
	 * @return Returns the pageshow.
	 */
	public int getPageshow() {
		return pageshow;
	}

	/**
	 * @param pageshow The pageshow to set.
	 */
	public void setPageshow(int pageshow) {
		this.pageshow = pageshow;
	}
}
