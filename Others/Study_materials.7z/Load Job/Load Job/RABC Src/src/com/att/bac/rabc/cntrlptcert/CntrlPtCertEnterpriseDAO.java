//TODO component registry name to be added later
/* Component Name: 
 * Module Name: CntrlPtCertEnterpriseDAO.java
 * Created on Feb 12, 2007
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.cntrlptcert;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.att.bac.rabc.PickList;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.StaticDataLoader;
import com.att.carat.util.JDBCUtil;

/**This is a DAO that will connect to the RABC_CNTRL_PT_CERT table for SELECT, INSERT, UPDATE and DELETE queries.
 * 
 * @author gg8573
 */
public class CntrlPtCertEnterpriseDAO {
	private static final Logger logger = Logger.getLogger(CntrlPtCertEnterpriseDAO.class);

	/**
	 * Method will certify all
	 * @param conn
	 * @param cntrlPtCertForm
	 * @param startDate
	 * @param endDate
	 * @param stateDesc
	 * @param process
	 * @param certInd
	 * @param issueInd
	 * @throws RABCException
	 */
	protected static void certifyProcessAll(Connection conn, List cntrlPtCertViewList, CntrlPtCertForm cntrlPtCertForm) throws RABCException {
		Statement stmt = null;
		int rowsUpdated = 0;
		String accessRightsMessage = "";		
		List regionsList = new ArrayList();
		
		try {
			if (cntrlPtCertViewList !=null & !cntrlPtCertViewList.isEmpty()){
				int cntrlPtCertViewListSize = cntrlPtCertViewList.size();
				
				for (int i=0;i<cntrlPtCertViewListSize;i++){
					CntrlPtCertView cntrlPtCertView = (CntrlPtCertView) cntrlPtCertViewList.get(i);
					List args = new ArrayList();
					
					if ("U".equals(cntrlPtCertView.getRegionAccess())){
						String dbNode = StaticDataLoader.getDBNodeByRegion(cntrlPtCertView.getSelectedRegion());
						String updateSql = "UPDATE " + dbNode + ".RABC_CNTRL_PROCESS_CERT SET CERT_IND = ''{0}'' WHERE STATE = ''{1}'' AND " +
						"RUN_DATE = to_date(''{2}'' ,''mm/dd/yyyy'') AND PROCESS = ''{3}'' AND ISSUE_IND = ''{4}''";
						args.add("Y");
						args.add(getStateAcronym(conn, cntrlPtCertView.getStateDesc()));
						args.add(cntrlPtCertView.getRunDate());
						args.add(cntrlPtCertView.getProcess());
						args.add(cntrlPtCertView.getIssueInd());
						
						stmt = conn.createStatement();
						MessageFormat mf = new MessageFormat(updateSql);
						String sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
						logger.debug("Inside CntrlPtCertEnterpriseDAO.certifyProcessAll Executing SQL Statement..." + sqlStmt);
						rowsUpdated += stmt.executeUpdate(sqlStmt);
					}
					else{	
						String selectedRegion = getRegionDesc(cntrlPtCertForm.getRegionList(), cntrlPtCertView.getSelectedRegion());
						if(!regionsList.contains(selectedRegion)){
							regionsList.add(selectedRegion);
						}								
					}
				}//end of for loop				
			}

			if (rowsUpdated > 0)
				cntrlPtCertForm.setJSAlertMsg("cert");
			else
				cntrlPtCertForm.setJSAlertMsg("nocert");
			
			if(!regionsList.isEmpty()){
				accessRightsMessage = "Update to " + (String)regionsList.get(0);
				for(int i = 1; i < regionsList.size(); i++){
					accessRightsMessage = accessRightsMessage + ", " + (String)regionsList.get(i);
				}
				cntrlPtCertForm.setJSAlertMsg(accessRightsMessage);				
			}
			
			conn.commit();
			logger.debug("Finished row update.");
		} catch (SQLException sqle) {
			JDBCUtil.rollback(conn);
			throw new RABCException("Error in updating a process's certification using certifyProcess query: ", sqle);
		} finally {
			JDBCUtil.closeStatement(stmt);
		}
	}
	
	/**This inserts new processes for certification, including comments, in the RABC_CNTRL_PROCESS_CERT table.
	 * 
	 * @param conn  Connection passed from the Service class
	 * @param cntrlPtCertForm  Form created in the action class and passed down
	 * @throws RABCException
	 */
	protected static void insertProcess(Connection conn, CntrlPtCertForm cntrlPtCertForm, String region) throws RABCException {
		Statement stmt = null;
		Statement procDatesStmt = null;
		Statement certNumStmt = null;
		Statement stmtInserComment = null;
		ResultSet rsCertNum = null;		
		ResultSet rsProcDates = null;
		String sqlStmt = "";
		String sqlStmtInsertComment = "";
		int batchCounter = 0;
		PreparedStatement preparedStatementLock1 = null;
		PreparedStatement preparedStatementLock2 = null;
		String accessRightsMessage = "";
		
		try {
			/*
			 * Set connection's auto commit to false
			 */
			conn.setAutoCommit(false);
			
			stmt = conn.createStatement();
			stmtInserComment = conn.createStatement();
			certNumStmt = conn.createStatement();
			procDatesStmt = conn.createStatement();
			
			/*
			 * Get the list of schemas in which you want to insert
			 */
			ArrayList schemaList = new ArrayList();		
			List list  = StaticDataLoader.getDBNodeList(cntrlPtCertForm.getRegion());
			int listSize = list.size();
			for(int i = 0; i < listSize; i++){
				PickList dbNode = (PickList)list.get(i);
				if(region.equalsIgnoreCase("All")){		
					schemaList.add(dbNode);				
				}else{
					if(region.equalsIgnoreCase(dbNode.getKey())){
						schemaList.add(dbNode);
					}
				}
			}
			
			/*
			 * Start looping through the schema list
			 */
			for(int i = 0; i < schemaList.size(); i++){			
				/*
				 * Do not proceed if this user does not have update access on the particular region
				 */
				PickList dbNode = (PickList)schemaList.get(i);
				String regionName = dbNode.getKey();			
				String selectedRegionAccess = "U";
				String [] regionWiseAccessList = cntrlPtCertForm.getRegionWiseAccessList().split(";");
				for (int k=0;k<regionWiseAccessList.length;k++){
					String regionPart = regionWiseAccessList[k].split("~")[0];
					if (regionName.equals(regionPart)){
						selectedRegionAccess = regionWiseAccessList[k].split("~")[1];
						break;
					}
				}
				
				if ("U".equals(selectedRegionAccess)){
					/*
					 * Get the list of processes within a region
					 */
				    List processList = new ArrayList();
					String selectedProcess = cntrlPtCertForm.getProcess();
					if(!selectedProcess.equalsIgnoreCase("All")){
						List allProcesses = StaticDataLoader.getDistinctProcesses(regionName);
						if (allProcesses.contains(selectedProcess)){
							processList.add(selectedProcess);	
						}	
					}else{
						processList = StaticDataLoader.getDistinctProcesses(regionName);
					}
					
					
					/*
					 * Get the list of states within a region
					 */
					String selectedState = cntrlPtCertForm.getStateDesc();	
					List stateList = new ArrayList();
					if(!selectedState.equalsIgnoreCase("All")){					
						String state = getStateAcronym(conn, selectedState);
						stateList.add(state);								
					}else {
						stateList = StaticDataLoader.getStatesByRegion(regionName);				
					}

					String strDbNode = dbNode.getValue1();				
					String getProcDates = "SELECT to_char(PROC_DT, 'mm/dd/yyyy') from " + strDbNode+ ".RABC_CYCLE_CALENDAR where PROC_DT >="
											+ "to_date('"+cntrlPtCertForm.getRunDate()+"','mm/dd/yyyy') and PROC_DT <=" +
											"to_date('"+cntrlPtCertForm.getEndRunDate()+"','mm/dd/yyyy')";			
					
					logger.debug("getProcDates = " + getProcDates);
					rsProcDates = procDatesStmt.executeQuery(getProcDates);
					List procDateList = new ArrayList();
					while (rsProcDates.next()) {
						procDateList.add(rsProcDates.getString(1));					
					}
					
					/*
					 * Lock the table on which you want to make the insert
					 */
					String lockSql1 = "LOCK TABLE " + strDbNode + ".RABC_CNTRL_PROCESS_CERT IN EXCLUSIVE MODE";
					String lockSql2 = "LOCK TABLE " + strDbNode + ".RABC_CNTRL_PROC_CERT_COMMENT IN EXCLUSIVE MODE";
					preparedStatementLock1 = conn.prepareStatement(lockSql1);
					preparedStatementLock2 = conn.prepareStatement(lockSql2);
					preparedStatementLock1.execute();
					preparedStatementLock2.execute();
					
					//	Get the next value for the certification number
					String getNextCertNum = "SELECT " + strDbNode + ".EWSSEQ_CERT_NO.NEXTVAL FROM DUAL";	
					certNumStmt = conn.prepareStatement(getNextCertNum);
					
					// Outer loop for the PROC_DT(s)
					for(int j = 0; j < procDateList.size(); j++){			
						// Middle loop for the States
						for (int k = 0; k < stateList.size() ; k++ ){
							String state = (String) stateList.get(k);		
							// Inner loop for the process
							for (int l = 0; l < processList.size() ; l++ ){
								String process = (String) processList.get(l);

								rsCertNum = certNumStmt.executeQuery(getNextCertNum);
								if (rsCertNum.next()) {
									int certNum = rsCertNum.getInt(1);	
									
									//	Insert values to RABC_CNTRL_PROCESS_CERT
									String insertCntrlPtCert = "INSERT INTO " + strDbNode + ".RABC_CNTRL_PROCESS_CERT (CERT_NUM, RUN_DATE, STATE, PROCESS, CERT_IND, ISSUE_IND, USER_ID, ISSUE_REVENUE_CR, ISSUE_REVENUE_DB, ISSUE_LOST_REVENUE, TIME_STAMP)" +
															   "{0}";			
									
									String value1 = "VALUES (" + certNum + ", " + 
									 				"to_date('"+(String)procDateList.get(j)+"','mm/dd/yyyy'), " +									   
												    "'" + state + "', " +
													"'" + process + "', " +
													"'" + cntrlPtCertForm.getCertInd() + "', " +
													"'" + cntrlPtCertForm.getIssueInd() + "', " +
													"'" + cntrlPtCertForm.getLoginUserID() + "', " +
													cntrlPtCertForm.getCreditRevImpact() + ", " +
													cntrlPtCertForm.getDebitRevImpact() + ", " +
													cntrlPtCertForm.getLostRevImpact() + ", " +
													"sysdate" + ")";
									ArrayList value1List = new ArrayList();
									value1List.add(value1);
									
									MessageFormat mf = new MessageFormat(insertCntrlPtCert);
									sqlStmt = mf.format((String[])value1List.toArray(new String[value1List.size()]));
									logger.debug("Add sql batch statement for inser process = " + sqlStmt);
									stmt.addBatch(sqlStmt);	
									batchCounter++;
									
									/*
									 * Insert into Certification Comment
									 */
									if (cntrlPtCertForm.getCommentSubject() != null && !cntrlPtCertForm.getCommentSubject().trim().equals("") && 
											cntrlPtCertForm.getCommentDetail() != null && !cntrlPtCertForm.getCommentDetail().trim().equals("")) {
										String insertCntrlPtCertComment  = "INSERT INTO " +
									
													    strDbNode+
													    ".RABC_CNTRL_PROC_CERT_COMMENT " +
													    "(CERT_NUM, USER_ID, CERT_IND, TIME_STAMP, SUBJECT, CERT_COMMENT) " +
													    "{0}";			
							
										ArrayList value2List = new ArrayList();
										String value2 = "VALUES ("  + certNum + ", " + 
														"'" + cntrlPtCertForm.getLoginUserID() + "', " +
														"'" + cntrlPtCertForm.getCertInd() + "', " +
														"sysdate, " + 
														"'" + cntrlPtCertForm.getCommentSubject() + "', " +
														"'" + cntrlPtCertForm.getCommentDetail() + "')";
										
										value2List.add(value2);
										MessageFormat mf2 = new MessageFormat(insertCntrlPtCertComment);
										sqlStmtInsertComment = mf2.format((String[])value2List.toArray(new String[value2List.size()]));
										stmtInserComment.addBatch(sqlStmtInsertComment);
										batchCounter++;
									}
									cntrlPtCertForm.setJSAlertMsg("new");
									
									/*
									 * Execute the batches 
									 */
									if (batchCounter % 1000 == 0){
										int [] batchStatementsExecuted = stmt.executeBatch();
										logger.debug("Inside condition if (batchCounter % 1000 == 0) Inserted " + batchStatementsExecuted.length + " statements");
										
										stmtInserComment.executeBatch();
									}
								}							
							}//end of for loop for process
						}//end of for loop for states
					}//end of for loop for proc dates
					
					int [] batchStatementsExecuted = stmt.executeBatch();
					logger.debug("Inserted " + batchStatementsExecuted.length +  " statements");
					
					stmtInserComment.executeBatch();				
					
					preparedStatementLock1.close();
					preparedStatementLock2.close();
				}
				else{
					String regionDesc = getRegionDesc(cntrlPtCertForm.getRegionList(), regionName);
					if(accessRightsMessage.equalsIgnoreCase("")){
						accessRightsMessage = accessRightsMessage + regionDesc;
					}else{
						accessRightsMessage = accessRightsMessage + ", " + regionDesc;
					}			
				}
				
				conn.commit();
				logger.debug("Finished insert...");
			}//end of for loop for schema	
			
			if(!accessRightsMessage.equalsIgnoreCase("")){
				accessRightsMessage = "Update to " + accessRightsMessage;
				cntrlPtCertForm.setJSAlertMsg(accessRightsMessage);
			}
			
		} catch (SQLException sqle) {
			JDBCUtil.rollback(conn);
			if (sqle.getMessage().indexOf("ORA-08177")!=-1){
				cntrlPtCertForm.setJSAlertMsg("serializable");
			} else {
				throw new RABCException("Error in inserting a new control process using insertCntrlPtCert query: ", sqle);
			}
		} finally {
			JDBCUtil.closePreparedStatement(preparedStatementLock1);
			JDBCUtil.closePreparedStatement(preparedStatementLock2);
			JDBCUtil.closeResultSet(rsCertNum);
			JDBCUtil.closeResultSet(rsProcDates);			
			JDBCUtil.closeStatement(procDatesStmt);
			JDBCUtil.closeStatement(certNumStmt);
			JDBCUtil.closeStatement(stmt);
			JDBCUtil.closeStatement(stmtInserComment);
		}
	} //end of method insertProcess

	
	/**Verify that the data to be inserted does not exist in the database. This method returns 0 when there is
	 * no duplicate. A return code of 1 means that data is in the database.
	 * 
	 * @param conn  Connection passed from the Service class
	 * @param cntrlPtCertForm  Form created in the action class and passed down
	 * @return dupExists  1 indicates a duplicate, 0 indicates no duplicates
	 * @throws RABCException
	 */
	protected static int checkForDup(Connection conn, CntrlPtCertForm cntrlPtCertForm, String region) throws RABCException {
		Statement stmt = null;
		ResultSet rs = null;
		String sqlStmt = "";
		cntrlPtCertForm.setJSAlertMsg(" ");
		String verifyNoDupInsert = "";
		ArrayList whereClauseList = new ArrayList();

		ArrayList schemaList = new ArrayList();		
		List list  = StaticDataLoader.getDBNodeList(cntrlPtCertForm.getRegion());
		for(int i = 0; i < list.size(); i++){
			PickList dbNode = (PickList)list.get(i);
			if(region.equalsIgnoreCase("All")){		
				schemaList.add(dbNode.getValue1());				
			}else{
				if(region.equalsIgnoreCase(dbNode.getKey())){
					schemaList.add(dbNode.getValue1());
				}
			}
		}
		
		for(int i = 0; i < schemaList.size(); i++){			
			String strDbNode = (String) schemaList.get(i);			
			
			verifyNoDupInsert += "SELECT CERT_NUM, RUN_DATE, STATE, PROCESS, CERT_IND, ISSUE_IND, ISSUE_REVENUE_CR, ISSUE_REVENUE_DB, ISSUE_LOST_REVENUE " +
								"FROM " +
								strDbNode +
								".RABC_CNTRL_PROCESS_CERT " +
								"WHERE {" + i + "}" ;
			
			String whereClause = "";
			String runDate = cntrlPtCertForm.getRunDate();
			String endRunDate = cntrlPtCertForm.getEndRunDate();
			if(runDate == ""){
				runDate = cntrlPtCertForm.getStartDate();
			}
			if(endRunDate == ""){
				endRunDate = cntrlPtCertForm.getEndDate();
			}			
			
			if (runDate.equals(endRunDate))
				whereClause += " RUN_DATE = to_date('"+runDate+"','mm/dd/yyyy')";	
			else {
				whereClause +=" RUN_DATE >= to_date('"+runDate+"', 'mm/dd/yyyy')";
				whereClause +=" AND RUN_DATE <= to_date('"+endRunDate+"', 'mm/dd/yyyy')";
			}			
			
			//convert state description to state acronym
			if ("All".equals(cntrlPtCertForm.getStateDesc()))
				whereClause += " ";
			else
				whereClause += " AND STATE = '" + getStateAcronym(conn, cntrlPtCertForm.getStateDesc()) + "'";
			
			if ("All".equals(cntrlPtCertForm.getProcess()))
				whereClause += " ";
			else
				whereClause += " AND PROCESS = '" + cntrlPtCertForm.getProcess() + "'";

			whereClauseList.add(whereClause);
			
			if(i < (schemaList.size() - 1)){				
				verifyNoDupInsert = verifyNoDupInsert + " UNION ";
			}		
		}	
		
		int dupExists = 0;
		try {
			stmt = conn.createStatement();		
			MessageFormat mf = new MessageFormat(verifyNoDupInsert);
			sqlStmt = mf.format((String[])whereClauseList.toArray(new String[whereClauseList.size()]));		
			logger.debug("Inside CntrlPtCertEnterpriseDAO.checkForDup Executing SQL Statement..." + sqlStmt);
			rs = stmt.executeQuery(sqlStmt);	
			if (rs.next()) {   
				dupExists = 1;				
			} else {
				dupExists = 0;
			} 
		} catch (SQLException sqle) {
			throw new RABCException("Error in duplicate control process check using verifyNoDupInsert query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closeStatement(stmt);
		}
		return dupExists;
	}

	/**This selects all the states from the RABC_CRO_CD_DIVISION table and moves them to the CntrlPtCertForm bean. 
	 * The states will be used in the State pull-down input box.
	 * 
	 * @param conn  Connection passed from the Service class
	 * @param cntrlPtCertForm  Form created in the action class and passed down
	 * @throws RABCException
	 */
	protected static void getStateList(Connection conn, CntrlPtCertForm cntrlPtCertForm) throws RABCException {
		Statement stmt = null;
		ResultSet rs = null;
		String getStates = "SELECT DISTINCT STATE_DESC FROM RABC_DIVISION ORDER BY STATE_DESC";
		try {			
			stmt = conn.createStatement();
			logger.debug("Inside CntrlPtCertEnterpriseDAO.getState Executing SQL Statement..."+getStates);
			rs = stmt.executeQuery(getStates);
			while (rs.next())
				cntrlPtCertForm.setStateList(rs.getString(1)); 
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving user's access level using getUsrAccess query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closeStatement(stmt);
		}	
	}
	
	/**This selects all the processes from the RABC_PROCESS table and moves them to the CntrlPtCertForm bean.
	 * The processes will be used in the Process pull-down input box.
	 * 
	 * @param conn  Connection passed from the Service class
	 * @param cntrlPtCertForm  Form created in the action class and passed down
	 * @throws RABCException
	 */
	protected static void getProcessList(Connection conn, CntrlPtCertForm cntrlPtCertForm) throws RABCException {
		ArrayList processList = StaticDataLoader.getDistinctProcesses(cntrlPtCertForm.getRegion());
		for(int i=0; i < processList.size(); i++) {
			cntrlPtCertForm.setProcessList((String)processList.get(i));
		}		
	}
	
	/**This selects all the run date, state, process, certification ind and issue ind from the RABC_CNTRL_PROCESS_CERT table
	 * based on the selection criteria provided.
	 * 
	 * @param conn  Connection passed from the Service class
	 * @param cntrlPtCertForm  Form created in the action class and passed down
	 * @param startDate  start date from web page
	 * @param endDate  end date from web page
	 * @param stateDesc  state name
	 * @param process  process name
	 * @param certInd  certification indicator - 'Y' is certified, 'N' is not certified
	 * @param issueInd  issue indicator
	 * @throws RABCException
	 */
	protected static void getCntrlPtCertViewList(Connection conn, CntrlPtCertForm cntrlPtCertForm, String startDate, String endDate, String stateDesc, String process, String certInd, String issueInd) throws RABCException {
		Statement stmt = null;
		ResultSet rs = null;
		String sqlStmt = "";
		String getCntrlPtCertViewData = "";
		ArrayList whereClauseList = new ArrayList();
		
		ArrayList dbNodeList = StaticDataLoader.getDBNodeList(cntrlPtCertForm.getRegion());
		for(int i = 0; i < dbNodeList.size(); i++){
			PickList dbNode = (PickList)dbNodeList.get(i);
			String strDbNode = dbNode.getValue1();
			
			getCntrlPtCertViewData = getCntrlPtCertViewData + 
										"SELECT RUN_DATE, STATE, PROCESS, CERT_IND, ISSUE_IND, CERT_NUM, USER_ID " +
										"FROM " + 
										strDbNode +
										".RABC_CNTRL_PROCESS_CERT " +
										"WHERE {"+ i + "} ";
										
			String whereClause = "";
			
			//convert state description to state acronym
			String state = "";
			
			if (stateDesc.equals("All"))
				state = stateDesc;
			else
				state = getStateAcronym(conn, stateDesc);
			//build WHERE clause
			if (startDate.equals(endDate))
				whereClause += " RUN_DATE = to_date('"+startDate+"','mm/dd/yyyy')";
			else {
				whereClause +=" RUN_DATE >= to_date('"+startDate+"', 'mm/dd/yyyy')";
				whereClause +=" AND RUN_DATE <= to_date('"+endDate+"', 'mm/dd/yyyy')";
			}
			if (state.equals("All"))
				whereClause += " ";
			else
				whereClause += " AND STATE = '" + state + "'";
			if (process.equals("All"))
				whereClause += " ";
			else
				whereClause += " AND PROCESS = '" + process + "'";
			
			if (certInd.equals("A"))
				whereClause += " ";
			else
				whereClause += " AND CERT_IND = '" + certInd + "'";
			if (issueInd.equals("A"))
				whereClause += " ";
			else
				whereClause += " AND ISSUE_IND = '" + issueInd + "'";
			if (whereClause != null )
				whereClauseList.add(whereClause);
			else
				whereClauseList.add(" ");
			
			if(i < (dbNodeList.size() - 1)){
				getCntrlPtCertViewData = getCntrlPtCertViewData + " UNION ";
			}
		}
		getCntrlPtCertViewData = getCntrlPtCertViewData +  " ORDER BY RUN_DATE, STATE, PROCESS";
			
		try {
			//execute SQL statement
			stmt = conn.createStatement();
			MessageFormat mf = new MessageFormat(getCntrlPtCertViewData);
			sqlStmt = mf.format((String[])whereClauseList.toArray(new String[whereClauseList.size()]));
			logger.debug("Inside CntrlPtCertEnterpriseDAO.getCntrlPtCertViewList Executing SQL Statement..."+sqlStmt);
			rs = stmt.executeQuery(sqlStmt);
			while (rs.next())
				cntrlPtCertForm.getCntrlPtCertViewList().add(buildCntrlPtCertView(conn, rs, cntrlPtCertForm));
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving view data using getCntrlPtCertViewData query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closeStatement(stmt);
		}
	}
	
	/**This builds the CntrlPtCertView form. This form will contain data that will be displayed in the main page's 
	 * table.
	 * 
	 * @param conn  Connection passed from the Service class
	 * @param rs  The result set passed from getCntrlPtCertViewList()
	 * @param region  The region the user is in
	 * @return cntrlPtCertView  The transfer object that contains view information
	 * @throws RABCException
	 */
	private static CntrlPtCertView buildCntrlPtCertView(Connection conn, ResultSet rs, CntrlPtCertForm cntrlPtCertForm) throws RABCException {
		String selectedRegion = cntrlPtCertForm.getSelectedRegion();
		CntrlPtCertView cntrlPtCertView = new CntrlPtCertView();
		try {
			String tempDate = rs.getDate("RUN_DATE").toString();
			cntrlPtCertView.setRunDate(tempDate.substring(5,7) + "/" + tempDate.substring(8,10) + "/" + tempDate.substring(0,4));
			String state = rs.getString("STATE");
			cntrlPtCertView.setStateDesc(getStateDesc(conn, state));
			cntrlPtCertView.setProcess(rs.getString("PROCESS"));	
			cntrlPtCertView.setCertInd(rs.getString("CERT_IND"));   
			cntrlPtCertView.setIssueInd(rs.getString("ISSUE_IND"));
			cntrlPtCertView.setCertNum(rs.getInt("CERT_NUM"));
			cntrlPtCertView.setSavedUserID(rs.getString("USER_ID"));
			if(selectedRegion.equalsIgnoreCase("All")){
				String region = getRegionByState(conn, state);
				cntrlPtCertView.setSelectedRegion(region);
			}
			else{
				cntrlPtCertView.setSelectedRegion(selectedRegion);
			}
			
			/*
			 * Logic for populating the region access on the object
			 */
			String selectedRegionAccess = "U";
			String [] regionWiseAccessList = cntrlPtCertForm.getRegionWiseAccessList().split(";");
			for (int i=0;i<regionWiseAccessList.length;i++){
				String region = regionWiseAccessList[i].split("~")[0];
				if (cntrlPtCertView.getSelectedRegion().equals(region)){
					selectedRegionAccess = regionWiseAccessList[i].split("~")[1];
					break;
				}
			}
			cntrlPtCertView.setRegionAccess(selectedRegionAccess);
		} catch (SQLException sqle) {
			throw new RABCException("Error in setting up cntrlPtCertView object: ", sqle);
		}
		return cntrlPtCertView;	
	}	
		
	/**This gets the alert message revenue aounts from the RABC_ALERT_MSG table.
	 * 
	 * @param conn  Connection passed from the Service class
	 * @param cntrlPtCertForm  Form created in the action class and passed down
	 * @throws RABCException
	 */
	protected static void getAlertMsgRevenueAmts(Connection conn, CntrlPtCertForm cntrlPtCertForm, String region) throws RABCException {
		Statement stmt = null;
		ResultSet rs = null;
		String sqlStmt = "";
		
		/*
		 * Get the list of control points
		 */
		String controlPoints = getControlPoints(conn, cntrlPtCertForm);
		String runDate = cntrlPtCertForm.getRunDate();
		String endRunDate = cntrlPtCertForm.getEndRunDate();
		ArrayList whereClauseList = new ArrayList();
		String getAlertRevenue = "";		
		ArrayList schemaList = new ArrayList();		
		List list  = StaticDataLoader.getDBNodeList(cntrlPtCertForm.getRegion());
		
		/*
		 * Form the list of schemas to be used
		 */
		for(int i = 0; i < list.size(); i++){
			PickList dbNode = (PickList)list.get(i);
			if(region.equalsIgnoreCase("All")){		
				schemaList.add(dbNode);				
			}else{
				if(region.equalsIgnoreCase(dbNode.getKey())){
					schemaList.add(dbNode);
				}
			}
		}
			
		for(int i = 0; i < schemaList.size(); i++){				
			PickList dbNode = (PickList)schemaList.get(i);
			String regionName = dbNode.getKey();		
			String strDbNode = dbNode.getValue1();			
			
			String  divisions = "";		
			/*
			 * Form the divisions
			 */
			if ("All".equals(cntrlPtCertForm.getStateDesc())){					
				divisions = "(";	
				List divisionList = StaticDataLoader.getDivisionsByRegion(regionName);
				int listSize = divisionList.size();
				for (int j=0;j<listSize;j++){
					PickList pickList = (PickList)divisionList.get(j);				
					if(divisions.equalsIgnoreCase("(")){
						divisions += "'"+pickList.getKey()+"'";
					}else{
						divisions += ",'"+pickList.getKey()+"'";
					}
				}
				divisions += ")";
			} else {
				divisions  =  getDivisionsByStateDesc(conn, cntrlPtCertForm.getStateDesc());
			}
			
			getAlertRevenue = getAlertRevenue + 
									 "SELECT SUM(A.ALERT_REVENUE), SUM(A.ALERT_LOST_REVENUE) " +
									 "FROM " +
									 strDbNode +
									 ".RABC_ALERT_MSG A, "+
									 strDbNode +
									 ".RABC_CNTRL_PT_ALERT B " +
									 "WHERE A.ALERT_RULE(+) = B.ALERT_RULE {"+ i + "}";
			String whereClause = " AND B.CNTRL_PT_CD IN ";
			whereClause += controlPoints;
			whereClause += " AND A.ALERT_DATA1 IN ";
			whereClause += divisions;
			whereClause += " AND PROC_DATE >= to_date('" + runDate + "','mm/dd/yyyy')AND PROC_DATE <= to_date('"+endRunDate+"','mm/dd/yyyy')";
			
			whereClauseList.add(whereClause);
			
			if(i < (schemaList.size() - 1)){
				getAlertRevenue = getAlertRevenue + " UNION ";
			}			
		} 
		
		try {		
			stmt = conn.createStatement();		
			MessageFormat mf = new MessageFormat(getAlertRevenue);
			sqlStmt = mf.format((String[])whereClauseList.toArray(new String[whereClauseList.size()]));
			logger.debug("Inside CntrlPtCertEnterpriseDAO.getAlertMsgRevenueAmts Executing SQL Statement..."+sqlStmt);
			rs = stmt.executeQuery(sqlStmt);
			double alertMsgRevImpact = 0;
			double alertMsgLostRevImpact = 0;
			while (rs.next()) {
				alertMsgRevImpact +=  rs.getDouble(1);
				alertMsgLostRevImpact +=  rs.getDouble(2);
			}
			cntrlPtCertForm.setAlertMsgRevImpact(alertMsgRevImpact);
			cntrlPtCertForm.setAlertMsgLostRevImpact(alertMsgLostRevImpact);
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving alert message revenue amounts using getAlertRevenue query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closeStatement(stmt);
		}  
	}
	
   	/**This gets all the control points of a process.
	 * 
	 * @param conn  Connection passed from the Service class
	 * @param cntrlPtCertForm  Form created in the action class and passed down
	 * @return controlPoints  The control points to be used on the main page
	 * @throws RABCException
	 */
	protected static String getControlPoints(Connection conn, CntrlPtCertForm cntrlPtCertForm) throws RABCException {
		Statement stmt = null;
		ResultSet rs = null;
		String sqlStmt = "";
		String getControlPoints = "SELECT CNTRL_PT_CD FROM RABC_PROCESS WHERE PROCESS = {0}";
		String getControlPoints1 = "SELECT DISTINCT CNTRL_PT_CD FROM RABC_PROCESS ";
		ArrayList argsList = new ArrayList(0);
		
		if ("All".equals(cntrlPtCertForm.getProcess())){
			argsList.add("");
		}else {
			argsList.add("'"+cntrlPtCertForm.getProcess()+"'");
		}

		String controlPoints = "(";
		try {	
			stmt = conn.createStatement();		
			if ("All".equals(cntrlPtCertForm.getProcess())){
				sqlStmt = getControlPoints1;
			}else {
				MessageFormat mf = new MessageFormat(getControlPoints);
				sqlStmt = mf.format((String[])argsList.toArray(new String[argsList.size()]));			
			}	
			rs = stmt.executeQuery(sqlStmt);		
			while (rs.next()){						
				if(controlPoints.equalsIgnoreCase("(")){
					controlPoints += "'"+rs.getString("CNTRL_PT_CD")+"'";
				}else{
					controlPoints += ",'"+rs.getString("CNTRL_PT_CD")+"'";					
				}				
			}				
			controlPoints += ")";
		} catch (SQLException sqle) {
			throw new RABCException("Error in setting up WHERE clause using getControlPoints query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closeStatement(stmt);
		}
		return controlPoints;
	}
	
    /**This retrieves a state's acronym.
	 * 
	 * @param conn  Connection passed from the Service class
	 * @param stateDesc  The state name
	 * @param region  The region being accessed
	 * @return stateAcr  The 2 letter state abbreviation
	 * @throws RABCException
	 */
	protected static String getStateAcronym(Connection conn, String stateDesc) throws RABCException {
		Statement stmt = null;
		ResultSet rs = null;
		String sqlStmt = "";
		String getStateAcronym = "SELECT STATE FROM RABC_DIVISION WHERE STATE_DESC = {0}";
		ArrayList argsList = new ArrayList(0);
		argsList.add("'" + stateDesc + "'");
		String stateAcr = "";
		try {	
			stmt = conn.createStatement();		
			MessageFormat mf = new MessageFormat(getStateAcronym);
			sqlStmt = mf.format((String[])argsList.toArray(new String[argsList.size()]));	
			logger.debug("Inside CntrlPtCertEnterpriseDAO.getStateAcronym Executing SQL Statement..."+sqlStmt);
			rs = stmt.executeQuery(sqlStmt);		
			if (rs.next())
				stateAcr = rs.getString(1);
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving state abbreviation using getStateAcronym query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closeStatement(stmt);
		} 
		return stateAcr;
	}
	
	/**This retrieves a state's description.
	 * 
	 * @param conn  Connection passed from the Service class
	 * @param stateAcr  The 2 letter state abbreviation
	 * @param region  The region being accessed
	 * @return stateDesc  The state name
	 * @throws RABCException
	 */
	protected static String getStateDesc(Connection conn, String stateAcr) throws RABCException {
		Statement stmt = null;
		ResultSet rs = null;
		String sqlStmt = "";
		String getStateDesc = "SELECT STATE_DESC FROM RABC_DIVISION WHERE STATE = {0}";
		ArrayList argsList = new ArrayList(0);
		argsList.add("'" + stateAcr + "'");
		String stateDesc = "";
		try {	
			stmt = conn.createStatement();		
			MessageFormat mf = new MessageFormat(getStateDesc);
			sqlStmt = mf.format((String[])argsList.toArray(new String[argsList.size()]));	
			logger.debug("Inside CntrlPtCertEnterpriseDAO.getStateDesc Executing SQL Statement..."+sqlStmt);
			rs = stmt.executeQuery(sqlStmt);		
			if (rs.next())
				stateDesc = rs.getString(1);
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving state description using getStateDesc query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closeStatement(stmt);
		} 
		return stateDesc;
	}	
	
	/**This determines if the user has read-only or update access to the Control Process Certification page.
	 * 
	 * @param conn  Connection passed from the Service class
	 * @param cntrlPtCertForm  Form created in the action class and passed down
	 * @throws RABCException
	 */
	protected static void getUserAccess(Connection conn, CntrlPtCertForm cntrlPtCertForm) throws RABCException {
		ArrayList dbNodeList = StaticDataLoader.getDBNodeList(cntrlPtCertForm.getRegion());
		String getUsrAccess = "";
		String userID = "'" + cntrlPtCertForm.getLoginUserID().toUpperCase() + "'";
		ArrayList userIDList = new ArrayList();
		Statement stmt = null;
		ResultSet rs = null;
		String sqlStmt = "";		
		try {	
			for(int i = 0; i < dbNodeList.size(); i++){
				PickList dbNode = (PickList)dbNodeList.get(i);
				String regionNode = dbNode.getKey();
				String strDbNode = dbNode.getValue1();
				
				getUsrAccess = "SELECT A.USER_ID, B.FUNCT_CD " +
				  "FROM " + strDbNode + 
				  ".RABC_ALERT_GRP_USER A, "+ strDbNode + 
				  ".RABC_ALERT_GRP_FUNCT B " +
				  "WHERE UPPER(USER_ID) = {"+ i +"} " +
				  "  AND B.FUNCT_CD = ''US'' " +
				  "  AND A.ALERT_GRP = B.ALERT_GRP";

				userIDList.add(userID);			
				
				stmt = conn.createStatement();		
				MessageFormat mf = new MessageFormat(getUsrAccess);
				sqlStmt = mf.format((String[])userIDList.toArray(new String[userIDList.size()]));				
				logger.debug("Inside CntrlPtCertEnterpriseDAO.getUserAccess Executing SQL Statement..."+sqlStmt);
				rs = stmt.executeQuery(sqlStmt);		
				if (rs.next()){
					cntrlPtCertForm.setRegionWiseAccessList(regionNode + "~U");
				} else {
					cntrlPtCertForm.setRegionWiseAccessList(regionNode + "~R");	
				}
			}//end of for loop					
		} catch (SQLException sqle) {
				throw new RABCException("Error in retrieving user's access level using getUsrAccess query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closeStatement(stmt);
		} 
	}
	
	/**
	 * Populate the regions
	 * @param cntrlPtCertForm
	 * @throws RABCException
	 */
	protected static void getRegionList(CntrlPtCertForm cntrlPtCertForm)throws RABCException{
		ArrayList dbNodeList = StaticDataLoader.getDBNodeList(cntrlPtCertForm.getRegion());
		ArrayList regionList = StaticDataLoader.getRegionList_ent();
		if (dbNodeList.isEmpty()) {
			cntrlPtCertForm.setRegionList(regionList);
		} else {
			int dbNodeListSize = dbNodeList.size();
			int regionListSize = regionList.size();
			ArrayList sortedList = new ArrayList();
			for (int i=0;i<dbNodeListSize;i++){
				PickList dbNode = (PickList)dbNodeList.get(i);
				String regionCd = dbNode.getKey();
				for (int j=0;j<regionListSize;j++){
					PickList currRegion = (PickList)regionList.get(j);
					if (regionCd.equalsIgnoreCase(currRegion.getKey())){
						sortedList.add(currRegion);
					}
				}
			}
			cntrlPtCertForm.setRegionList(sortedList);
		}
	}
	
	/**
	 * Private method will get the region based on the State
	 * @param conn
	 * @param state
	 * @return
	 * @throws RABCException
	 */
	private static String getRegionByState(Connection conn, String state) throws RABCException{
		Statement stmt = null;
		ResultSet rs = null;
		String sqlStatement = "SELECT REGION FROM RABC_DIVISION where state = " + "'" + state + "'";
		String region = "";
		try {			
			stmt = conn.createStatement();
			logger.debug("Inside CntrlPtCertEnterpriseDAO.getState Executing SQL Statement..."+sqlStatement);
			rs = stmt.executeQuery(sqlStatement);
			while (rs.next())
				region =  rs.getString(1); 
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving user's access level using getUsrAccess query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closeStatement(stmt);
		}	
		return region;
		
	}
	
	
	/**This gets all the divisions of a stateDesc.
	 * 
	 * @param conn  Connection passed from the Service class
	 * @param stateDesc  stateDesc
	 * @return divisions  The division corrosponding to given stateDesc
	 * @throws RABCException
	 */
	private static String getDivisionsByStateDesc(Connection conn, String stateDesc) throws RABCException {
		Statement stmt = null;
		ResultSet rs = null;		
		String sqlStmt = "SELECT DISTINCT DIVISION FROM RABC_DIVISION WHERE STATE_DESC = " + "'" + stateDesc + "'";
		String divisions = "(";
		try {	
			stmt = conn.createStatement();		
			rs = stmt.executeQuery(sqlStmt);		
			while (rs.next()){
				if(divisions.equalsIgnoreCase("(")){
					divisions += "'"+rs.getString("DIVISION")+"'";
				}else{
					divisions += ",'"+rs.getString("DIVISION")+"'";					
				}				
			}				
			divisions += ")";
		} catch (SQLException sqle) {
			throw new RABCException("Error in setting up WHERE clause using getControlPoints query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closeStatement(stmt);
		}
		return divisions;
	}
	
	/**
	 * Private method will return regionDesc based on regionCode
	 * @param regionList 
	 * @param regionCode  
	 * @return regionDesc
	 */
	private static String getRegionDesc(List regionList, String regionCode){
		String regionDesc = "";		
		for(int i = 0; i < regionList.size(); i++){
			PickList pickList = (PickList) regionList.get(i);
			if(pickList.getKey().equalsIgnoreCase(regionCode)){
				regionDesc =  pickList.getValue1();
				break;
			}
		}//end of for loop
		return regionDesc;
	}	 
	
}
