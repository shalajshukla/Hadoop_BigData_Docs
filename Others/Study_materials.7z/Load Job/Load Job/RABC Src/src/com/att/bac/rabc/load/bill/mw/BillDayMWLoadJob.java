/* Created on Nov 08, 2006 by Daniel Baker (db8237). 
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 *  
 * Modification History:                                     
 * SBCUID		Date			Description                         	    	
 * ------		--------		-----------
 * KW2478		20070720		Added methods and code for Tertiary Controls Consumer Segmentation project (EAP 294611)
 * 
 */

package com.att.bac.rabc.load.bill.mw;

import java.io.File;
import java.net.UnknownHostException;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Properties;

import com.att.bac.emcis.sender.MessageSender;
import com.att.bac.emcis.sender.MessageSenderException;
import com.att.bac.rabc.util.EmcisEventLogger;
import com.att.carat.util.NetUtil;
import com.att.carat.util.JDBCUtil;
//changes done for M168 by as635b
//import com.sbc.bac.load.Application;
import com.att.carat.load.Application;
import com.sbc.bac.rabc.load.FilePatternLoadJob;
import com.sbc.bac.rabc.load.PrepareTableForRerun;
import com.sbc.bac.rabc.load.RabcLoadJobTrig;
import com.sbc.bac.rabc.load.StaticErrorMsgKeys;

/**
 * @author db8237
 * 
 * Subclass of FilePatternLoadJob, which will process a delimited file.
 */
public class BillDayMWLoadJob extends FilePatternLoadJob {
	
// Array of tables accessed by this Load Job, used during backout for reruns
	private static final String[] tableNames = {"RABC_ACCT_ZERO_BLG_SUMY", "RABC_ISG_BLG_SUMY",
		"RABC_TOP_ISG_BLG_ACCT", "RABC_TOP_ISG_ADJ_ACCT", "RABC_TOT_BLG_SUMY", "RABC_ACCT_BLG_DTL",
		"RABC_TOP_TEN_BLG_ACCT", "RABC_TOP_LPC_ACCT", "RABC_NON_PYMT_BLG_ACCT", "RABC_TOP_OCC_BLG_ACCT",
		"RABC_TOP_ADJ_BLG_ACCT", "RABC_ACCT_BLG_DTL_AVG"};
	
// SQL for accessing table RABC_ACCT_ZERO_BLG_SUMY
	private static final StringBuffer insertAcctZeroSQL = new StringBuffer("INSERT INTO RABC_ACCT_ZERO_BLG_SUMY " +
			"(RUN_DATE, DIVISION, ACCT_TYPE_CODE, ACCT_ZERO_BLG_CT, BLG_MM, BLG_YEAR, BILL_RND) " +
			"VALUES(?, ?, ?, ?, ?, ?, ?) ");
// SQL for accessing table RABC_ISG_BLG_SUMY
	private static final StringBuffer insertISGSQL = new StringBuffer("INSERT INTO RABC_ISG_BLG_SUMY " +
			"(RUN_DATE, DIVISION, CUST_TYPE, TCC_ID, CUR_BLG_AMT_DB, CUR_BLG_AMT_CR, ACCT_CT_DB, " +
			"ACCT_CT_CR, BILL_RND) " +
			"VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?) ");
// SQL for accessing table RABC_TOP_ISG_BLG_ACCT
	private static final StringBuffer insertTopISGBlgSQL = new StringBuffer("INSERT INTO RABC_TOP_ISG_BLG_ACCT " +
			"(RUN_DATE, DIVISION, TCC_ID, BTN, CUST_TYPE_CD, ACCT_FINL_IND, CURR_ISG_BLG_AMT, CURR_ISG_ADJ_AMT, BILL_RND) " +
			"VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?) ");
// SQL for accessing table RABC_TOP_ISG_ADJ_ACCT
	private static final StringBuffer insertTopISGAdjSQL = new StringBuffer("INSERT INTO RABC_TOP_ISG_ADJ_ACCT " +
			"(RUN_DATE, DIVISION, TCC_ID, BTN, CUST_TYPE_CD, ACCT_FINL_IND, CURR_ISG_BLG_AMT, CURR_ISG_ADJ_AMT, BILL_RND) " +
			"VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?) ");
// SQL for accessing table RABC_TOT_BLG_SUMY
	private static final StringBuffer insertTotBlgSQL = new StringBuffer("INSERT INTO RABC_TOT_BLG_SUMY " +
			"(RUN_DATE, DIVISION, BUS_TYPE, CUST_CT, LPC_AMT, RECUR_CHRG_AMT, ADJ_AMT_DB, ADJ_AMT_CR, " +
			"CURR_OCC_CR, CURR_OCC_DB, CURR_BLG_AMT_DB, CURR_BLG_AMT_CR, BAL_DUE_AMT, LOCAL_TOLL_AMT, " +
			"LOCAL_USG_AMT, IEC_AMT, PREV_BLG_AMT, PYMT_AMT, FED_NREG_CHRG, ST_LOC_NREG_CHRG, FED_TAXES_DB, " +
			"FED_TAXES_CR, ST_TAXES_DB, ST_TAXES_CR, LOC_TAXES_DB, LOC_TAXES_CR, FED_SRCG_AMT_DB, " +
			"FED_SRCG_AMT_CR, ST_SRCG_AMT_DB, ST_SRCG_AMT_CR, LOC_SRCG_AMT_DB, LOC_SRCG_AMT_CR, BILL_RND) " +
			"VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ");
// SQL for accessing table RABC_ACCT_BLG_DTL
	private static final StringBuffer insertAcctDtlSQL = new StringBuffer("INSERT INTO RABC_ACCT_BLG_DTL " +
			"(RUN_DATE, DIVISION, BTN, CUST_TYPE, LPC_AMT, RECUR_CHRG_AMT, ADJ_AMT_DB, ADJ_AMT_CR, " +
			"CURR_OCC_CR, CURR_OCC_DB, CURR_BLG_AMT_DB, CURR_BLG_AMT_CR, BAL_DUE_AMT, LOCAL_TOLL_AMT, " +
			"LOCAL_USG_AMT, IEC_AMT, PREV_BLG_AMT, PYMT_AMT, FED_NREG_CHRG, ST_LOC_NREG_CHRG, FED_TAXES_DB, " +
			"FED_TAXES_CR, ST_TAXES_DB, ST_TAXES_CR, LOC_TAXES_DB, LOC_TAXES_CR, FED_SRCG_AMT_DB, FED_SRCG_AMT_CR, " +
			"ST_SRCG_AMT_DB, ST_SRCG_AMT_CR, LOC_SRCG_AMT_DB, LOC_SRCG_AMT_CR, BILL_RND) " +
			"VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ");
	private static final StringBuffer selectAverageAcctDtlSQL = new StringBuffer("SELECT " +
			"DIVISION, BTN, AVG(LPC_AMT), AVG(RECUR_CHRG_AMT), AVG(ADJ_AMT_DB), AVG(ADJ_AMT_CR), " +
			"AVG(CURR_OCC_CR), AVG(CURR_OCC_DB), AVG(CURR_BLG_AMT_DB), AVG(CURR_BLG_AMT_CR), AVG(BAL_DUE_AMT), " +
			"AVG(LOCAL_TOLL_AMT), AVG(LOCAL_USG_AMT), AVG(IEC_AMT), AVG(PREV_BLG_AMT), AVG(PYMT_AMT), " +
			"AVG(FED_NREG_CHRG), AVG(ST_LOC_NREG_CHRG), AVG(FED_TAXES_DB), AVG(FED_TAXES_CR), AVG(ST_TAXES_DB), " +
			"AVG(ST_TAXES_CR), AVG(LOC_TAXES_DB), AVG(LOC_TAXES_CR), AVG(FED_SRCG_AMT_DB), AVG(FED_SRCG_AMT_CR), " +
			"AVG(ST_SRCG_AMT_DB), AVG(ST_SRCG_AMT_CR), AVG(LOC_SRCG_AMT_DB), AVG(LOC_SRCG_AMT_CR) " +
			"FROM RABC_ACCT_BLG_DTL " +
			"WHERE DIVISION = ? " +
			"GROUP BY DIVISION, BTN");
	private static final StringBuffer selectAcctDtlSQL = new StringBuffer("SELECT * FROM RABC_ACCT_BLG_DTL " +
			"WHERE RUN_DATE = ? AND DIVISION = ? AND BTN = ? ");
// SQL for accessing table RABC_TOP_TEN_BLG_ACCT
	private static final StringBuffer insertTopTenSQL = new StringBuffer("INSERT INTO RABC_TOP_TEN_BLG_ACCT " +
			"(RUN_DATE, DIVISION, BILL_RND, RANK, BTN, BAL_DUE_AMT, CUR_BLG_AMT) " +
			"VALUES(?, ?, ?, ?, ?, ?, ?) ");
// SQL for accessing table RABC_TOP_LPC_ACCT
	private static final StringBuffer insertTopLPCSQL = new StringBuffer("INSERT INTO RABC_TOP_LPC_ACCT " +
			"(RUN_DATE, DIVISION, BTN, CUST_TYPE_CD, ACCT_FINL_IND, LPC_AMT, PREV_BLG_AMT, BILL_RND) " +
			"VALUES(?, ?, ?, ?, ?, ?, ?, ?) ");
//	 SQL for accessing table RABC_NON_PYMT_BLG_ACCT
	private static final StringBuffer insertNonPymtSQL = new StringBuffer("INSERT INTO RABC_NON_PYMT_BLG_ACCT " +
			"(RUN_DATE, DIVISION, BTN, CUST_TYPE_CD, ACCT_FINL_IND, LAST_PYMT_DATE, CURR_BLG_AMT, TOT_BLG_AMT, BILL_RND) " +
			"VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?) ");
	private static final StringBuffer deleteNonPymtSQL = new StringBuffer("DELETE FROM RABC_NON_PYMT_BLG_ACCT " +
			"WHERE DIVISION = ? AND BILL_RND = ?");
// SQL for accessing table RABC_TOP_OCC_BLG_ACCT
	private static final StringBuffer insertTopOCCSQL = new StringBuffer("INSERT INTO RABC_TOP_OCC_BLG_ACCT " +
			"(RUN_DATE, DIVISION, BTN, CUST_TYPE_CD, ACCT_FINL_IND, OCC_BLG_AMT, PREV_BLG_AMT, CURR_BLG_AMT, BILL_RND) " +
			"VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?) ");
// SQL for accessing table RABC_TOP_ADJ_BLG_ACCT
	private static final StringBuffer insertTopAdjSQL = new StringBuffer("INSERT INTO RABC_TOP_ADJ_BLG_ACCT " +
			"(RUN_DATE, DIVISION, BTN, CUST_TYPE_CD, ACCT_FINL_IND, ADJ_BLG_AMT, PREV_BLG_AMT, CURR_BLG_AMT, BILL_RND) " +
			"VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?) ");
//	 SQL for accessing table RABC_ACCT_BLG_DTL_AVG
	private static final StringBuffer insertAcctDtlAvgSQL = new StringBuffer("INSERT INTO RABC_ACCT_BLG_DTL_AVG " +
			"(RUN_DATE, DIVISION, BTN, LPC_AMT_AVG, RECUR_CHRG_AMT_AVG, ADJ_AMT_DB_AVG, ADJ_AMT_CR_AVG, " +
			"CURR_OCC_CR_AVG, CURR_OCC_DB_AVG, CURR_BLG_AMT_DB_AVG, CURR_BLG_AMT_CR_AVG, BAL_DUE_AMT_AVG, " +
			"LOCAL_TOLL_AMT_AVG, LOCAL_USG_AMT_AVG, IEC_AMT_AVG, PREV_BLG_AMT_AVG, PYMT_AMT_AVG, FED_NREG_CHRG_AVG, " +
			"ST_LOC_NREG_CHRG_AVG, FED_TAXES_DB_AVG, FED_TAXES_CR_AVG, ST_TAXES_DB_AVG, ST_TAXES_CR_AVG, " +
			"LOC_TAXES_DB_AVG, LOC_TAXES_CR_AVG, FED_SRCG_AMT_DB_AVG, FED_SRCG_AMT_CR_AVG, ST_SRCG_AMT_DB_AVG, " +
			"ST_SRCG_AMT_CR_AVG, LOC_SRCG_AMT_DB_AVG, LOC_SRCG_AMT_CR_AVG) " +
			"VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ");
//	 SQL for inserting into table TCCSEG_BOSS on the Consumer Segmentation schema - new code for TC project (kjw)
	private static final StringBuffer insertBossDataSQL = new StringBuffer("INSERT INTO TCCSEG_BOSS " +
			"(DATA_CREATE_DT, BTN, REGION, SEGMENT_TYPE, DIVISION, PROCESS_GRP)" +
			"VALUES(?, upper(?), ?, ?, ?, ?) ");
//  SQL statement String for Select from TCCSEG_FILE_STATUS table
	private static final String selectFileStatusSQL = "SELECT STATUS FROM TCCSEG_FILE_STATUS " +
													  "WHERE DATA_CREATE_DT = ?" +
													  "AND JOB_ID = ?";	
//  SQL for Inserting into TCCSEG_FILE_STATUS table on the Consumer Segmentation schema - new code for TC project (kjw)
	private static final String insertFileStatusSQL = "INSERT INTO TCCSEG_FILE_STATUS " +
													  "(DATA_CREATE_DT, JOB_ID, STATUS)" +
													  "VALUES(?, ?, ?)";
//  SQL statement String for Update of TCCSEG_FILE_STATUS table
	private static final String updateFileStatusSQL = "UPDATE TCCSEG_FILE_STATUS " +
													  "SET STATUS = ?" +
													  "WHERE DATA_CREATE_DT = ? and JOB_ID = ?";
	
	private static final String deleteFileStatusSQL = "DELETE TCCSEG_FILE_STATUS " +
 	  												  "WHERE DATA_CREATE_DT = ? and JOB_ID = ?";

	// Static variable for baselining of non payments
	private static final int PYMT_BASELINE_DAYS = 90;
	// Static variable for blank value
	private static final String SPACE = " ";
	// Static variable for Day of Month to be used in determining the dataCreateDate for ACIS
//	private static final int CREATE_DAY = 5;
    private String create_day;
    private int createDay;	
// Prepared Statements
	private PreparedStatement insertAcctZero;
	private PreparedStatement insertISG;
	private PreparedStatement insertTopISGBlg;
	private PreparedStatement insertTopISGAdj;
	private PreparedStatement insertTotBlg;
	private PreparedStatement insertAcctDtl;
	private PreparedStatement selectAverageAcctDtl;
	private PreparedStatement selectAcctDtl;
	private PreparedStatement insertTopTen;
	private PreparedStatement insertTopLPC;
	private PreparedStatement insertNonPymt;
	private PreparedStatement deleteNonPymt;
	private PreparedStatement insertTopOCC;
	private PreparedStatement insertTopAdj;
	private PreparedStatement insertAcctDtlAvg;
	private PreparedStatement insertBossData;
	private PreparedStatement selectFileStatus;
	private PreparedStatement insertFileStatus;
	private PreparedStatement updateFileStatus;
	private PreparedStatement deleteFileStatus;
	
// Common variables
	private ArrayList triggers;
	private ArrayList acctDtl;
	private ArrayList nonPymt;
	private ArrayList topAdjustments;
	private File currentFile;
	private String division;
	private String processGroup;
	private Date sqlRunDate;
	private Date dataCreateDate; 
	private String runDate;
	private long billRnd;
	private boolean backupRecovery;
	private boolean trailerProcessed;
	private boolean firstRecord;
	private int lineCount;
	private long rank;
	private DateFormat MMddyy = new SimpleDateFormat("MMddyy");
	private DateFormat MMddyyyy = new SimpleDateFormat("MMddyyyy");
	private DateFormat yyyyMMdd = new SimpleDateFormat("yyyyMMdd");
	private ResultSet rs;
	private ResultSet rs2;
	private static String JOBID; 
	private String fileName, fileToken, region;

	   /* (non-Javadoc)
     * @see com.sbc.bac.load.FileDBLoadJob#configure(com.sbc.bac.load.Application, java.util.Properties)
     */
    protected boolean configure(Application application, Properties configuration) {

    	boolean result = super.configure(application, configuration);
    	if(configuration.getProperty("create_day") == null || configuration.getProperty("create_day").equals("")){
    		severe("'create_day' configuration property missing. Please specify 'create_day' in load job configuration file.");
    		result = false;
    	}else {
    		create_day = configuration.getProperty("create_day");
    		createDay = Integer.parseInt(create_day);
    	}
    	return result;
    }

    /**
     * Runs prior to processing. Sets up all necessary prepared statements.
     * 
     * @return false if an error is encountered during set up, otherwise true
     */
	public boolean preprocess() {
		super.preprocess();

		try {
			insertAcctZero = connection.prepareStatement(insertAcctZeroSQL.toString());
			insertISG = connection.prepareStatement(insertISGSQL.toString());
			insertTopISGBlg = connection.prepareStatement(insertTopISGBlgSQL.toString());
			insertTopISGAdj = connection.prepareStatement(insertTopISGAdjSQL.toString());
			insertTotBlg = connection.prepareStatement(insertTotBlgSQL.toString());
			insertAcctDtl = connection.prepareStatement(insertAcctDtlSQL.toString());
			selectAverageAcctDtl = connection.prepareStatement(selectAverageAcctDtlSQL.toString());
			selectAcctDtl = connection.prepareStatement(selectAcctDtlSQL.toString());
			insertTopTen = connection.prepareStatement(insertTopTenSQL.toString());
			insertTopLPC = connection.prepareStatement(insertTopLPCSQL.toString());
			insertNonPymt = connection.prepareStatement(insertNonPymtSQL.toString());
			deleteNonPymt = connection.prepareStatement(deleteNonPymtSQL.toString());
			insertTopOCC = connection.prepareStatement(insertTopOCCSQL.toString());
			insertTopAdj = connection.prepareStatement(insertTopAdjSQL.toString());
			insertAcctDtlAvg = connection.prepareStatement(insertAcctDtlAvgSQL.toString());
			insertBossData = connection.prepareStatement(insertBossDataSQL.toString());
			selectFileStatus = connection.prepareStatement(selectFileStatusSQL.toString());
			insertFileStatus = connection.prepareStatement(insertFileStatusSQL.toString());
			updateFileStatus = connection.prepareStatement(updateFileStatusSQL.toString());
			deleteFileStatus = connection.prepareStatement(deleteFileStatusSQL.toString());
		} catch (SQLException e) {
			severe(StaticErrorMsgKeys.PREPROCESS_ERROR + e.getMessage(), e);
			return false;
		}
		return true;
	}
	
    /**
     * Runs prior to file processing. Initializes application variables.
     * 
     * @return false if an error is encountered during initialization, otherwise true
     */
	public boolean preprocessFile(File file) {
		boolean success = super.preprocessFile(file);
		fileName = file.getName();
		fileToken = file.getName().substring(file.getName().indexOf("RA150F01"),file.getName().indexOf("RA150F01")+ 8);
		if (success) {
			try {
				region   =	file.getName().substring(0,2);
				triggers = new ArrayList();
				acctDtl = new ArrayList();
				nonPymt = new ArrayList();
				topAdjustments = new ArrayList();
				backupRecovery = false;
				trailerProcessed = false;
				firstRecord = true;
				lineCount = 0;
				rank = 0;
				division = "";
				JOBID = "MW_ACIS_x_PGxx";
				if (RabcLoadJobTrig.IsOriginalFileLoaded(connection, file, file.getName().length())) {
					backupRecovery = true;
				}
			} catch (Exception e) {
				severe(StaticErrorMsgKeys.PREPROCESSFILE_ERROR + StaticErrorMsgKeys.FILE_NAME_PARSING_ERROR + e, e);
				return false;
			}
		}
		currentFile = file;
		return success;
	}

    /**
     * Parses the most recently read line of the input file, determines what type of record it is, and passes it
     * to the appropriate routine for processing.
     * 
     * @param line
     *   The most recently read line of the input file.
     * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob
     * @throws Exception
     *   if any unhandled Exception is encountered, if the TRAILER record is not the last record on the processing file,
     *   if the HEADER record is not he first record on the processing file, and also if the DATE record does not
     *   immediately follow the HEADER record.
     */
	protected int parseLine(String line) throws Exception {
		String[] fields = line.split("[ ]*;[ ]*");
		
		if (trailerProcessed) {									// trailer must be last record on file
			throw new Exception("TRAILER was not the last record on currently processing file: " + currentFile.getName());
		}
		
		if (firstRecord) {										// header must be first record on file
			firstRecord = false;
			if ("HEADER".equalsIgnoreCase(fields[0])) {
				division = fields[2].trim();
				return SUCCESS;
			} else {
				throw new Exception("HEADER was not the first record on currently processing file: " + currentFile.getName());
			}
		}
		
		if ("TRAILER".equalsIgnoreCase(fields[0])) {
			trailerProcessed = true;
			return processTrailerRecord(fields);
		}
		
		lineCount++;											// header and trailer records are not counted
		
		if (lineCount == 1) {									// date record must be second record on file
			if ("RA15DATE".equalsIgnoreCase(fields[0]) && "01".equalsIgnoreCase(fields[1])) {
				return processDateRecord(fields);
			} else {
				throw new Exception("DATE record did not immediately follow the HEADER on currently processing file: " + currentFile.getName());
			}
		}
		
		if ("RA15CULC".equalsIgnoreCase(fields[0])) {
			if ("01".equalsIgnoreCase(fields[1])) {
				if (billRnd > 0) {
					if (!triggers.contains("MWZEROBG")) {
						triggers.add("MWZEROBG");
					}
				}
				return insertAcctZeroRecord(fields);
			}
			
			if ("02".equalsIgnoreCase(fields[1])) {
				if (billRnd > 0) {
					if (!triggers.contains("MWISGBG")) {
						triggers.add("MWISGBG");
					}
				}
				return insertISGRecord(fields);
			}
			
			if ("03".equalsIgnoreCase(fields[1])) {
				return insertTopISGBlgRecord(fields);
			}
			
			if ("04".equalsIgnoreCase(fields[1])) {
				return insertTopISGAdjRecord(fields);
			}
			
			if ("10".equalsIgnoreCase(fields[1])) {
				if (billRnd > 0) {
					if (!triggers.contains("MWTOTBG")) {
						triggers.add("MWTOTBG");
					}
				}
				return insertTotBlgRecord(fields);
			}
			
			if ("11".equalsIgnoreCase(fields[1])) {
				return insertTotBlgRecord(fields);
			}
			
			if ("12".equalsIgnoreCase(fields[1])) {
				return insertAcctDtlRecord(fields);
			}
			
			if ("13".equalsIgnoreCase(fields[1])) {
				if (insertTopTenRecord(fields) == SUCCESS) {	// If the insert to RABC_TOP_TEN_BLG_ACCT was good
					acctDtl.add(fields);						// Store for possible insertion to RABC_ACCT_BLG_DTL following batch processing
					return SUCCESS;
				} else {
					return ERROR;
				}
			}
			
			if ("14".equalsIgnoreCase(fields[1])) {
				return insertTopLPCRecord(fields);
			}

			if ("17".equalsIgnoreCase(fields[1])) {
				return insertBossData(line);
			}
			
			if ("18".equalsIgnoreCase(fields[1])) {
				return SKIPPED;
			}
			
			if ("19".equalsIgnoreCase(fields[1])) {
				// skip entirely (and do not error) records where the date is empty
				if (!"".equals(fields[5]) && !"000000".equals(fields[5]) && fields.length == 8) {
					// Skip the record if total charges is 0
					if ("".equals(fields[7]) || Double.parseDouble(fields[7]) == 0) {
						return SKIPPED;
					}
					
					// Skip the record if the LAST_PYMT_DT is after the PYMT Baseline date which RUN_DATE - 90
					if (isAfterBaselineDate(fields[5],PYMT_BASELINE_DAYS)){
						return SKIPPED;
					}
					
					// records are sorted in BTN order, but not in date order. We want to keep the record with the most 
					// recent date if multiple records are encountered for the same BTN.
					if (nonPymt.isEmpty()) {								// first record of this type?
						nonPymt.add(fields);
					} else {
						String[] oldFields = (String[]) nonPymt.get(0);
						if (oldFields[2].equalsIgnoreCase(fields[2])) {		// are the BTNs the same?
							Date oldDate = new Date(MMddyy.parse(oldFields[5]).getTime());
							Date date = new Date(MMddyy.parse(fields[5]).getTime());
							if (oldDate.before(date)) {	// replace saved record with newer, no insert
								nonPymt.clear();
								nonPymt.add(fields);
							}
						} else {
							// new BTN encountered, store new record for next compare and insert saved record 
							nonPymt.clear();
							nonPymt.add(fields);
							return insertNonPymtRecord(oldFields);
						}
					}
				}
				return SUCCESS;
			}
			
			if ("20".equalsIgnoreCase(fields[1])) {
				return insertTopOCCRecord(fields);
			}
			
			if ("21".equalsIgnoreCase(fields[1]) || "22".equalsIgnoreCase(fields[1])) {
				for (int i = 0; i < topAdjustments.size(); i++) {
					String btn = (String) topAdjustments.get(i);
					if (btn.equalsIgnoreCase(fields[2])) {	// BTN on this record was already seen on a previous record
						return SUCCESS;						// drop the record 
					}
				}
				topAdjustments.add(fields[2]);				// store BTN
				return insertTopAdjRecord(fields);
			}
		}
		
		warning(StaticErrorMsgKeys.INVAID_RECORD_TYPE + fields[0] + fields[1]);
		return ERROR;
	}
	
    /**
     * Processes the most recently read line of the input file, once it has been identified as a Date record.
     * Determines BILL_RND and RUN_DATE values for use in populating other tables throughout application.
     * 
     * @param fields
     *   an Array of the fields in the most recently read line of the input file.
     * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob
     * @throws Exception
     *   if no rows are returned from RABC_CYCLE_CALENDAR when attempting to acquire the BILL_RND and RUN_DATE
     */
	private int processDateRecord(String[] fields) throws Exception {
		try {
			StringBuffer query = new StringBuffer("" +
					"SELECT BILL_RND, PROC_DT, TO_CHAR(PROC_DT, 'yyyyMMdd') " +
					"FROM RABC_CYCLE_CALENDAR " +
					"WHERE BILL_RND_DT = TO_DATE(?,'MMddyy')");
			PreparedStatement ps = connection.prepareStatement(query.toString());

			/*
			 * Defect Fix # 57349. 5th field is added for process group which is now read into the processGroup variable. This 
			 * value if not 0 or "" will also be used as the day part of BILL_RND_DT used in the query to get the PROC_DT
			 */
			String temp = fields[2];
			
			// determine the dataCreateDate using the cycleDate from the Date record
			DateFormat date_formatter = new SimpleDateFormat("MMddyy");
			Date cycleDate = new Date(date_formatter.parse(fields[2]).getTime());
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(cycleDate);
			calendar.set(Calendar.DAY_OF_MONTH, createDay);
			dataCreateDate = new Date(calendar.getTimeInMillis());

			processGroup = fields[4].trim();
			if (!"00".equals(processGroup) && !"".equals(processGroup)){
				temp = temp.substring(0,2) + processGroup + temp.substring(4,temp.length());
			}
			
			JOBID = "MW_ACIS_" + division +"_PG" + processGroup;
			boolean success = updateTCFileStatus(dataCreateDate, JOBID, "I");
			if (!success){
				severe("Error inserting/updating the TCCSEG_FILE_STATUS table during date record processing ");
				throw new Exception("Error inserting/updating the TCCSEG_FILE_STATUS table during date record processing");				
			}			
			ps.setString(1, temp);
			
			rs = ps.executeQuery();
			
			if (rs.next()) {
				billRnd = rs.getLong(1);											// BILL_RND
				sqlRunDate = rs.getDate(2);											// PROC_DT
				runDate = rs.getString(3);											// PROC_DT as String, used in insertAcctZeroRecord()
			} else {
				severe("No rows were returned from table RABC_CYCLE_CALENDAR during date record processing, using date " + fields[2]);
				throw new Exception("No rows were returned from table RABC_CYCLE_CALENDAR during date record processing, using date " + fields[2]);
			}
		} catch (SQLException sqle) {
			severe("SQL Error encountered while attempting to acquire BILL_RND in method processDateRecord(String[] fields):" + sqle.getMessage(), sqle);
			throw new Exception("SQL Error encountered while attempting to acquire BILL_RND in method processDateRecord(String[] fields):" + sqle.getMessage(), sqle);
		}
		
		if (backupRecovery) {
			for (int i = 0; i < tableNames.length; i++) {
				if (!PrepareTableForRerun.deleteTableData(connection, tableNames[i], division, sqlRunDate)) {
					severe("Error occurred attempting to backup and recover for rerun for table: " + tableNames[i]);
					return ERROR;
				}
			}
			if (!PrepareTableForRerun.deleteBossTableData(connection, dataCreateDate, "A", division, processGroup)) {
					severe("Error occurred attempting to backup and recover for rerun for TC table: TCCSEG_BOSS");
					return ERROR;
			}
			if (!PrepareTableForRerun.deleteFileStatusTableData(connection, dataCreateDate, JOBID)) {
				severe("Error occurred attempting to backup and recover for rerun for TC table: TCCSEG_FILE_STATUS");
				return ERROR;
			}
		}
		
		return SUCCESS;
	}
	
    /**
     * Processes the most recently read line of the input file, once it has been identified as a Trailer record.
     * Validates that the number of records processed is equal to the record count on the Trailer record.
     * Header and trailer records are the only records not included in the line count.
     * 
     * @param fields
     *   an Array of the fields in the most recently read line of the input file.
     * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob
     * @throws Exception
     *   if the line count on the trailer does not match the number of lines processed
     */
	private int processTrailerRecord(String[] fields) throws Exception {
		int totalRecords = Integer.parseInt(fields[5]);
		
		if (totalRecords == lineCount) {
			return SUCCESS;
		}
		
		throw new Exception("Record count mismatch, trailer record shows " + totalRecords + ", but " + lineCount + " records exist on file " + currentFile.getName());
	}
	
    /**
     * Performs an Insert to table RABC_ACCT_ZERO_BLG_SUMY, using the data from the most recently read line
     * of the input file.
     * 
     * @param fields
     *   an Array of the fields in the most recently read line of the input file.
     * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob.
     */
	private int insertAcctZeroRecord(String[] fields) {
		try {
			insertAcctZero.setDate(1, sqlRunDate);									// RUN_DATE
			insertAcctZero.setString(2, division);									// DIVISION
			insertAcctZero.setString(3, fields[2]);							// ACCT_TYPE_CODE
			insertAcctZero.setLong(4, Long.parseLong(fields[3]) / 1000000 );		// ACCT_ZERO_BLG_CT
			insertAcctZero.setString(5, runDate.substring(4, 6));					// BLG_MM
			insertAcctZero.setString(6, runDate.substring(0, 4));					// BLG_YEAR
			insertAcctZero.setLong(7, billRnd);										// BILL_RND
			
			insertAcctZero.addBatch();
		} catch (SQLException sqle) {
			severe(StaticErrorMsgKeys.INSERT_ERROR + "from method insertAcctZeroRecord(String[] fields)" + sqle.getMessage(), sqle);
			return ERROR;
		}
		
		return SUCCESS;
	}
	
	/**
	 * Performs an Insert to table RABC_ISG_BLG_SUMY, using the data from the most recently read line
	 * of the input file.
	 * 
	 * @param fields
	 *   an Array of the fields in the most recently read line of the input file.
	 * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob.
	 */
	private int insertISGRecord(String[] fields) {
		try {
			insertISG.setDate(1, sqlRunDate);										// RUN_DATE
			insertISG.setString(2, division);										// DIVISION
			insertISG.setString(3, fields[2]);								// CUST_TYPE
			insertISG.setString(4, fields[3]);								// TCC_ID
			insertISG.setDouble(5, Double.parseDouble(fields[5]) / 100000000);		// CUR_BILLING_AMT_DB
			insertISG.setDouble(6, Double.parseDouble(fields[7]) / 100000000);		// CUR_BILLING_AMT_CR
			insertISG.setLong(7, Long.parseLong(fields[4]) / 1000000);				// ACCT_CT_DB
			insertISG.setLong(8, Long.parseLong(fields[6]) / 1000000);				// ACCT_CT_CR
			insertISG.setLong(9, billRnd);											// BILL_RND
			
			insertISG.addBatch();
		} catch (SQLException sqle) {
			severe(StaticErrorMsgKeys.INSERT_ERROR + "from method insertISGRecord(String[] fields)" + sqle.getMessage(), sqle);
			return ERROR;
		}
		
		return SUCCESS;
	}
	
	/**
	 * Performs an Insert to table RABC_TOP_ISG_BLG_ACCT, using the data from the most recently read line
	 * of the input file.
	 * 
	 * @param fields
	 *   an Array of the fields in the most recently read line of the input file.
	 * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob.
	 */
	private int insertTopISGBlgRecord(String[] fields) {
		try {
			insertTopISGBlg.setDate(1, sqlRunDate);									// RUN_DATE
			insertTopISGBlg.setString(2, division);									// DIVISION
			insertTopISGBlg.setString(3, fields[3]);							// TCC_ID
			insertTopISGBlg.setString(4, fields[2]);							// BTN
			insertTopISGBlg.setString(5, fields[4]);							// CUST_TYPE_CD
			insertTopISGBlg.setString(6, fields[5]);							// ACCT_FINAL_IND
			insertTopISGBlg.setDouble(7, Double.parseDouble(fields[6]) / 100);		// CURR_ISG_BLG_AMT
			insertTopISGBlg.setDouble(8, Double.parseDouble(fields[7]) / 100);		// CURR_ISG_ADJ_AMT
			insertTopISGBlg.setLong(9, billRnd);									// BILL_RND
			
			insertTopISGBlg.addBatch();
		} catch (SQLException sqle) {
			severe(StaticErrorMsgKeys.INSERT_ERROR + "from method insertTopISGBlgRecord(String[] fields)" + sqle.getMessage(), sqle);
			return ERROR;
		}
		
		return SUCCESS;
	}
	
	/**
	 * Performs an Insert to table RABC_TOP_ISG_ADJ_ACCT, using the data from the most recently read line
	 * of the input file.
	 * 
	 * @param fields
	 *   an Array of the fields in the most recently read line of the input file.
	 * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob.
	 */
	private int insertTopISGAdjRecord(String[] fields) {
		try {
			insertTopISGAdj.setDate(1, sqlRunDate);									// RUN_DATE
			insertTopISGAdj.setString(2, division);									// DIVISION
			insertTopISGAdj.setString(3, fields[3]);							// TCC_ID
			insertTopISGAdj.setString(4, fields[2]);							// BTN
			insertTopISGAdj.setString(5, fields[4]);							// CUST_TYPE_CD
			insertTopISGAdj.setString(6, fields[5]);							// ACCT_FINAL_IND
			insertTopISGAdj.setDouble(7, Double.parseDouble(fields[6]) / 100);		// CURR_ISG_BLG_AMT
			insertTopISGAdj.setDouble(8, Double.parseDouble(fields[7]) / 100);		// CURR_ISG_ADJ_AMT
			insertTopISGAdj.setLong(9, billRnd);									// BILL_RND
			
			insertTopISGAdj.addBatch();
		} catch (SQLException sqle) {
			severe(StaticErrorMsgKeys.INSERT_ERROR + "from method insertTopISGAdjRecord(String[] fields)" + sqle.getMessage(), sqle);
			return ERROR;
		}
		
		return SUCCESS;
	}
	
	/**
	 * Performs an Insert to table RABC_TOT_BLG_SUMY, using the data from the most recently read line
	 * of the input file.
	 * 
	 * @param fields
	 *   an Array of the fields in the most recently read line of the input file.
	 * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob.
	 */
	private int insertTotBlgRecord(String[] fields) {
		try {
			insertTotBlg.setDate(1, sqlRunDate);										// RUN_DATE
			insertTotBlg.setString(2, division);										// DIVISION
			if (fields[1].equals("10")) {
				if (fields[2].equals("B")) {
					insertTotBlg.setString(3, "BUS");									// BUS_TYPE
				} else {
					insertTotBlg.setString(3, "RES");									// BUS_TYPE
				}
			} else {
				if (fields[2].equals("B")) {
					insertTotBlg.setString(3, "FNLB");									// BUS_TYPE
				} else {
					insertTotBlg.setString(3, "FNLR");									// BUS_TYPE
				}
			}
			
			insertTotBlg.setLong(4, Long.parseLong(fields[3]) / 1000000);				// CUST_CT
			insertTotBlg.setDouble(5, Double.parseDouble(fields[4]) / 100000000);		// LPC_AMT
			insertTotBlg.setDouble(6, Double.parseDouble(fields[5]) / 100000000);		// RECUR_CHRG_AMT
			insertTotBlg.setDouble(7, Double.parseDouble(fields[6]) / 100000000);		// ADJ_AMT_DB
			insertTotBlg.setDouble(8, Double.parseDouble(fields[7]) / 100000000);		// ADJ_AMT_CR
			insertTotBlg.setDouble(9, Double.parseDouble(fields[9]) / 100000000);		// CURR_OCC_CR
			insertTotBlg.setDouble(10, Double.parseDouble(fields[8]) / 100000000);		// CURR_OCC_DB
			insertTotBlg.setDouble(11, Double.parseDouble(fields[10]) / 100000000);		// CURR_BLG_AMT_DB
			insertTotBlg.setDouble(12, Double.parseDouble(fields[11]) / 100000000);		// CURR_BLG_AMT_CR
			insertTotBlg.setDouble(13, Double.parseDouble(fields[12]) / 100000000);		// BAL_DUE_AMT
			insertTotBlg.setDouble(14, Double.parseDouble(fields[13]) / 100000000);		// LOCAL_TOLL_AMT
			insertTotBlg.setDouble(15, Double.parseDouble(fields[14]) / 100000000);		// LOCAL_USG_AMT
			insertTotBlg.setDouble(16, Double.parseDouble(fields[15]) / 100000000);		// IEC_AMT
			insertTotBlg.setDouble(17, Double.parseDouble(fields[16]) / 100000000);		// PREV_BLG_AMT
			insertTotBlg.setDouble(18, Double.parseDouble(fields[17]) / 100000000);		// PYMT_AMT
			insertTotBlg.setDouble(19, Double.parseDouble(fields[18]) / 100000000);		// FED_NREG_CHRG
			insertTotBlg.setDouble(20, Double.parseDouble(fields[19]) / 100000000);		// ST_LOC_NREG_CHRG
			insertTotBlg.setDouble(21, Double.parseDouble(fields[26]) / 100000000);		// FED_TAXES_DB
			insertTotBlg.setDouble(22, Double.parseDouble(fields[27]) / 100000000);		// FED_TAXES_CR
			insertTotBlg.setDouble(23, Double.parseDouble(fields[28]) / 100000000);		// ST_TAXES_DB
			insertTotBlg.setDouble(24, Double.parseDouble(fields[29]) / 100000000);		// ST_TAXES_CR
			insertTotBlg.setDouble(25, Double.parseDouble(fields[30]) / 100000000);		// LOC_TAXES_DB
			insertTotBlg.setDouble(26, Double.parseDouble(fields[31]) / 100000000);		// LOC_TAXES_CR
			insertTotBlg.setDouble(27, Double.parseDouble(fields[20]) / 100000000);		// FED_SRCG_AMT_DB
			insertTotBlg.setDouble(28, Double.parseDouble(fields[21]) / 100000000);		// FED_SRCG_AMT_CR
			insertTotBlg.setDouble(29, Double.parseDouble(fields[22]) / 100000000);		// ST_SRCG_AMT_DB
			insertTotBlg.setDouble(30, Double.parseDouble(fields[23]) / 100000000);		// ST_SRCG_AMT_CR
			insertTotBlg.setDouble(31, Double.parseDouble(fields[24]) / 100000000);		// LOC_SRCG_AMT_DB
			insertTotBlg.setDouble(32, Double.parseDouble(fields[25]) / 100000000);		// LOC_SRCG_AMT_CR
			insertTotBlg.setLong(33, billRnd);											// BILL_RND
		    
		    insertTotBlg.addBatch();
		} catch (SQLException sqle) {
			severe(StaticErrorMsgKeys.INSERT_ERROR + "from method insertTotBlgRecord(String[] fields)" + sqle.getMessage(), sqle);
			return ERROR;
		}
		
		return SUCCESS;
	}
	
	/**
	 * Performs an Insert to table RABC_ACCT_BLG_DTL, using the data from the most recently read line
	 * of the input file.
	 * 
	 * @param fields
	 *   an Array of the fields in the most recently read line of the input file.
	 * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob.
	 */
	private int insertAcctDtlRecord(String[] fields) {
		try {
			insertAcctDtl.setDate(1, sqlRunDate);													// RUN_DATE
			insertAcctDtl.setString(2, division);													// DIVISION
			insertAcctDtl.setString(3, fields[2]);											// BTN
			insertAcctDtl.setString(4, fields[3]);											// CUST_TYPE
			insertAcctDtl.setDouble(5, Double.parseDouble(fields[4]) / 100);						// LPC_AMT
			insertAcctDtl.setDouble(6, Double.parseDouble(fields[5]) / 100);						// RECUR_CHRG_AMT
			insertAcctDtl.setDouble(7, Double.parseDouble(fields[6]) / 100);						// ADJ_AMT_DB
			insertAcctDtl.setDouble(8, Double.parseDouble(fields[7]) / 100);						// ADJ_AMT_CR
			insertAcctDtl.setDouble(9, Double.parseDouble(fields[9]) / 100);						// CURR_OCC_CR
			insertAcctDtl.setDouble(10, Double.parseDouble(fields[8]) / 100);						// CURR_OCC_DB
			insertAcctDtl.setDouble(11, Double.parseDouble(fields[10]) / 100);						// CURR_BLG_AMT_DB
			insertAcctDtl.setDouble(12, Double.parseDouble(fields[11]) / 100);						// CURR_BLG_AMT_CR
			insertAcctDtl.setDouble(13, Double.parseDouble(fields[12]) / 100);						// BAL_DUE_AMT
			insertAcctDtl.setDouble(14, Double.parseDouble(fields[13]) / 100);						// LOCAL_TOLL_AMT
			insertAcctDtl.setDouble(15, Double.parseDouble(fields[14]) / 100);						// LOCAL_USG_AMT
			insertAcctDtl.setDouble(16, Double.parseDouble(fields[15]) / 100);						// IEC_AMT
			insertAcctDtl.setDouble(17, Double.parseDouble(fields[16]) / 100);						// PREV_BLG_AMT
			insertAcctDtl.setDouble(18, Double.parseDouble(fields[17]) / 100);						// PYMT_AMT
			insertAcctDtl.setDouble(19, Double.parseDouble(fields[18]) / 100);						// FED_NREG_CHRG
			insertAcctDtl.setDouble(20, Double.parseDouble(fields[19]) / 100);						// ST_LOC_NREG_CHRG
			insertAcctDtl.setDouble(21, Double.parseDouble(fields[26]) / 100);						// FED_TAXES_DB
			insertAcctDtl.setDouble(22, Double.parseDouble(fields[27]) / 100);						// FED_TAXES_CR
			insertAcctDtl.setDouble(23, Double.parseDouble(fields[28]) / 100);						// ST_TAXES_DB
			insertAcctDtl.setDouble(24, Double.parseDouble(fields[29]) / 100);						// ST_TAXES_CR
			insertAcctDtl.setDouble(25, Double.parseDouble(fields[30]) / 100);						// LOC_TAXES_DB
			insertAcctDtl.setDouble(26, Double.parseDouble(fields[31]) / 100);						// LOC_TAXES_CR
			insertAcctDtl.setDouble(27, Double.parseDouble(fields[20]) / 100);						// FED_SRCG_AMT_DB
			insertAcctDtl.setDouble(28, Double.parseDouble(fields[21]) / 100);						// FED_SRCG_AMT_CR
			insertAcctDtl.setDouble(29, Double.parseDouble(fields[22]) / 100);						// ST_SRCG_AMT_DB
			insertAcctDtl.setDouble(30, Double.parseDouble(fields[23]) / 100);						// ST_SRCG_AMT_CR
			insertAcctDtl.setDouble(31, Double.parseDouble(fields[24]) / 100);						// LOC_SRCG_AMT_DB
			insertAcctDtl.setDouble(32, Double.parseDouble(fields[25]) / 100);						// LOC_SRCG_AMT_CR
			insertAcctDtl.setLong(33, billRnd);														// BILL_RND
			
			insertAcctDtl.addBatch();
		} catch (SQLException sqle) {
			severe(StaticErrorMsgKeys.INSERT_ERROR + "from method insertAcctDtlRecord(String[] fields)" + sqle.getMessage(), sqle);
			return ERROR;
		}
		
		return SUCCESS;
	}
	
	/**
	 * Performs an Insert to table RABC_TOP_TEN_BLG_ACCT, using the data from the most recently read line
	 * of the input file, increasing RANK by one for each row inserted.
	 * 
	 * @param fields
	 *   an Array of the fields in the most recently read line of the input file.
	 * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob.
	 */
	private int insertTopTenRecord(String[] fields) {
		try {
			rank = rank + 1;
			insertTopTen.setDate(1, sqlRunDate);									// RUN_DATE
			insertTopTen.setString(2, division);									// DIVISION
			insertTopTen.setLong(3, billRnd);										// BILL_RND
			insertTopTen.setLong(4, rank);											// RANK
			insertTopTen.setString(5, fields[2]);							// BTN
			insertTopTen.setDouble(6, Double.parseDouble(fields[12]) / 100);		// BAL_DUE_AMT

			// CURR_BLG_AMT_DB + CURR_BLG_AMT_CR = CUR_BLG_AMT; 
			double d = Double.parseDouble(fields[10]) + Double.parseDouble(fields[11]);
			insertTopTen.setDouble(7, d/100 );									// CUR_BLG_AMT
			
			insertTopTen.addBatch();
		} catch (SQLException sqle) {
			severe(StaticErrorMsgKeys.INSERT_ERROR + "from method insertTopTenRecord(String[] fields)" + sqle.getMessage(), sqle);
			return ERROR;
		}
		
		return SUCCESS;
	}
	
	/**
	 * Performs an Insert to table RABC_TOP_LPC_ACCT, using the data from the most recently read line
	 * of the input file.
	 * 
	 * @param fields
	 *   an Array of the fields in the most recently read line of the input file.
	 * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob.
	 */
	private int insertTopLPCRecord(String[] fields) {
		try {
			insertTopLPC.setDate(1, sqlRunDate);									// RUN_DATE
			insertTopLPC.setString(2, division);									// DIVISION
			insertTopLPC.setString(3, fields[2]);							// BTN
			insertTopLPC.setString(4, fields[3]);							// CUST_TYPE_CD
			insertTopLPC.setString(5, fields[4]);							// ACCT_FINAL_IND
			insertTopLPC.setDouble(6, Double.parseDouble(fields[5]) / 100);			// LPC_AMT
			insertTopLPC.setDouble(7, Double.parseDouble(fields[6]) / 100);			// PREV_BLG_AMT
			insertTopLPC.setLong(8, billRnd);										// BILL_RND
			
			insertTopLPC.addBatch();
		} catch (SQLException sqle) {
			severe(StaticErrorMsgKeys.INSERT_ERROR + "from method insertTopLPCRecord(String[] fields)" + sqle.getMessage(), sqle);
			return ERROR;
		}
		
		return SUCCESS;
	}
	
	/**
	 * Performs an Insert to table RABC_NON_PYMT_BLG_ACCT, using the data from the most recently read line
	 * of the input file.
	 * 
	 * @param fields
	 *   an Array of the fields in the most recently read line of the input file.
	 * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob.
	 */
	private int insertNonPymtRecord(String[] fields) {
		try {
			insertNonPymt.setDate(1, sqlRunDate);											// RUN_DATE
			insertNonPymt.setString(2, division);											// DIVISION
			insertNonPymt.setString(3, fields[2]);											// BTN
			insertNonPymt.setString(4, fields[3]);											// CUST_TYPE_CD
			insertNonPymt.setString(5, fields[4]);											// ACCT_FINAL_IND
			insertNonPymt.setDate(6, new Date(MMddyy.parse(fields[5]).getTime()));			// LAST_PYMT_DATE
			insertNonPymt.setDouble(7, Double.parseDouble(fields[6]) / 100);				// CURR_BLG_AMT
			insertNonPymt.setDouble(8, Double.parseDouble(fields[7]) / 100);				// TOT_BLG_AMT
			insertNonPymt.setLong(9, billRnd);												// BILL_RND
			
			insertNonPymt.addBatch();
		} catch (SQLException sqle) {
			severe(StaticErrorMsgKeys.INSERT_ERROR + "from method insertNonPymtRecord(String[] fields)" + sqle.getMessage(), sqle);
			return ERROR;
		} catch (ParseException e) {
			severe(StaticErrorMsgKeys.PARSELINE_ERROR + "Error occurred while parsing Date in method insertNonPymtRecord(String[] fields) on file: " + e, e);
			return ERROR;
		}
		
		return SUCCESS;
	}
	
	/**
	 * Method to add days to this date. Will be used as an adjust() function to return date corresponding to 
	 * +/- no of days from this date.
	 * 
	 * @param target
	 * @param days
	 * @return DATE
	 */
	private java.util.Date doAdd(java.util.Date target, int days) {
        Calendar now = Calendar.getInstance();
        Calendar working = null;;
        working = (Calendar) now.clone();
        working.setTime(target);             
        working.add(Calendar.DAY_OF_YEAR, days);
        target.setTime(working.getTimeInMillis());
        return target;
	}

	/**
	 * The method to check the date for the passed pymtBaselineDays and lastPymt
	 * @param lastPymtDate
	 * @param pymtBaselineDays
	 * @return
	 * @throws ParseException
	 */
	public boolean isAfterBaselineDate(String lastPymtDate,int pymtBaselineDays) throws ParseException{
        boolean result = false;

        java.util.Date pymtBaselineDate = doAdd(yyyyMMdd.parse(runDate),-pymtBaselineDays);
        java.util.Date date = MMddyy.parse(lastPymtDate);
                
        if (date.compareTo(pymtBaselineDate)>=0) {
        	result = true;
         } else {
         	result = false;
        }
        
        return result;
	}

	/**
	 * Performs an Insert to table RABC_TOP_OCC_BLG_ACCT, using the data from the most recently read line
	 * of the input file.
	 * 
	 * @param fields
	 *   an Array of the fields in the most recently read line of the input file.
	 * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob.
	 */
	private int insertTopOCCRecord(String[] fields) {
		try {
			insertTopOCC.setDate(1, sqlRunDate);									// RUN_DATE
			insertTopOCC.setString(2, division);									// DIVISION
			insertTopOCC.setString(3, fields[2]);							// BTN
			insertTopOCC.setString(4, fields[3]);							// CUST_TYPE_CD
			insertTopOCC.setString(5, fields[4]);							// ACCT_FINAL_IND
			insertTopOCC.setDouble(6, Double.parseDouble(fields[5]) / 100);			// OCC_BLG_AMT
			insertTopOCC.setDouble(7, Double.parseDouble(fields[7]) / 100);			// PREV_BLG_AMT
			insertTopOCC.setDouble(8, Double.parseDouble(fields[6]) / 100);			// CURR_BLG_AMT
			insertTopOCC.setLong(9, billRnd);										// BILL_RND
			
			insertTopOCC.addBatch();
		} catch (SQLException sqle) {
			severe(StaticErrorMsgKeys.INSERT_ERROR + "from method insertTopOCCRecord(String[] fields)" + sqle.getMessage(), sqle);
			return ERROR;
		}
		
		return SUCCESS;
	}
	
	/**
	 * Performs an Insert to table RABC_TOP_ADJ_BLG_ACCT, using the data from the most recently read line
	 * of the input file.
	 * 
	 * @param fields
	 *   an Array of the fields in the most recently read line of the input file.
	 * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob.
	 */
	private int insertTopAdjRecord(String[] fields) {
		try {
			insertTopAdj.setDate(1, sqlRunDate);									// RUN_DATE
			insertTopAdj.setString(2, division);									// DIVISION
			insertTopAdj.setString(3, fields[2]);							// BTN
			insertTopAdj.setString(4, fields[3]);							// CUST_TYPE_CD
			insertTopAdj.setString(5, fields[4]);							// ACCT_FINAL_IND
			insertTopAdj.setDouble(6, Double.parseDouble(fields[5]) / 100);			// ADJ_BLG_AMT
			insertTopAdj.setDouble(7, Double.parseDouble(fields[7]) / 100);			// PREV_BLG_AMT
			insertTopAdj.setDouble(8, Double.parseDouble(fields[6]) / 100);			// CURR_BLG_AMT
			insertTopAdj.setLong(9, billRnd);										// BILL_RND
			
			insertTopAdj.addBatch();
		} catch (SQLException sqle) {
			severe(StaticErrorMsgKeys.INSERT_ERROR + "from method insertTopAdjRecord(String[] fields)" + sqle.getMessage(), sqle);
			return ERROR;
		}
		
		return SUCCESS;
	}
	
    /**
     * Performs a select against table RABC_ACCT_BLG_DTL to retrieve averages by BTN for data inserted prior to
     * this run. Then performs an insert into table RABC_ACCT_BLG_DTL_AVG, containing the retrieved averages.
     * 
     * @throws SQLException
	 *   if an SQLException is encountered while performing the database calls necessary to update the Account
	 *   Averages, then the exception is passed back, unaltered, to the calling function for handling.
     */
	private void insertAcctDtlAvgRecords() throws SQLException {
		selectAverageAcctDtl.setString(1, division);								//DIVISION
		
		rs = selectAverageAcctDtl.executeQuery();
		
		while (rs.next()) {
			insertAcctDtlAvg.setDate(1, sqlRunDate);								// RUN_DATE
			insertAcctDtlAvg.setString(2, rs.getString(1));							// DIVISION
			insertAcctDtlAvg.setString(3, rs.getString(2));							// BTN
			insertAcctDtlAvg.setString(4, rs.getString(3));							// LPC_AMT_AVG
			insertAcctDtlAvg.setDouble(5, rs.getDouble(4));							// RECUR_CHRG_AMT_AVG
			insertAcctDtlAvg.setDouble(6, rs.getDouble(5));							// ADJ_AMT_DB_AVG
			insertAcctDtlAvg.setDouble(7, rs.getDouble(6));							// ADJ_AMT_CR_AVG
			insertAcctDtlAvg.setDouble(8, rs.getDouble(7));							// CURR_OCC_CR_AVG
			insertAcctDtlAvg.setDouble(9, rs.getDouble(8));							// CURR_OCC_DB_AVG
			insertAcctDtlAvg.setDouble(10, rs.getDouble(9));						// CURR_BLG_AMT_DB_AVG
			insertAcctDtlAvg.setDouble(11, rs.getDouble(10));						// CURR_BLG_AMT_CR_AVG
			insertAcctDtlAvg.setDouble(12, rs.getDouble(11));						// BAL_DUE_AMT_AVG
			insertAcctDtlAvg.setDouble(13, rs.getDouble(12));						// LOCAL_TOLL_AMT_AVG
			insertAcctDtlAvg.setDouble(14, rs.getDouble(13));						// LOCAL_USG_AMT_AVG
			insertAcctDtlAvg.setDouble(15, rs.getDouble(14));						// IEC_AMT_AVG
			insertAcctDtlAvg.setDouble(16, rs.getDouble(15));						// PREV_BLG_AMT_AVG
			insertAcctDtlAvg.setDouble(17, rs.getDouble(16));						// PYMT_AMT_AVG
			insertAcctDtlAvg.setDouble(18, rs.getDouble(17));						// FED_NREG_CHRG_AVG
			insertAcctDtlAvg.setDouble(19, rs.getDouble(18));						// ST_LOC_NREG_CHRG_AVG
			insertAcctDtlAvg.setDouble(20, rs.getDouble(19));						// FED_TAXES_DB_AVG
			insertAcctDtlAvg.setDouble(21, rs.getDouble(20));						// FED_TAXES_CR_AVG
			insertAcctDtlAvg.setDouble(22, rs.getDouble(21));						// ST_TAXES_DB_AVG
			insertAcctDtlAvg.setDouble(23, rs.getDouble(22));						// ST_TAXES_CR_AVG
			insertAcctDtlAvg.setDouble(24, rs.getDouble(23));						// LOC_TAXES_DB_AVG
			insertAcctDtlAvg.setDouble(25, rs.getDouble(24));						// LOC_TAXES_CR_AVG
			insertAcctDtlAvg.setDouble(26, rs.getDouble(25));						// LOC_TAXES_CR_AVG
			insertAcctDtlAvg.setDouble(27, rs.getDouble(26));						// FED_SRCG_AMT_CR_AVG
			insertAcctDtlAvg.setDouble(28, rs.getDouble(27));						// ST_SRCG_AMT_DB_AVG
			insertAcctDtlAvg.setDouble(29, rs.getDouble(28));						// ST_SRCG_AMT_CR_AVG
			insertAcctDtlAvg.setDouble(30, rs.getDouble(29));						// LOC_SRCG_AMT_DB_AVG
			insertAcctDtlAvg.setDouble(31, rs.getDouble(30));						// LOC_SRCG_AMT_CR_AVG
			
			insertAcctDtlAvg.executeUpdate();
		}
	}
	
	/**
	 * Performs a Delete to table RABC_NON_PYMT_BLG_ACCT, deleting all rows based on division and the BILL_RND of the
	 * overall file.
	 * 
	 * @throws SQLException
	 *   if an SQLException is encountered while perform the batch executes, then the exception is passed back
	 *   to the calling function for handling.
	 */
	private void deleteNonPymtRecords() throws SQLException {
		deleteNonPymt.setString(1, division);									// DIVISION
		deleteNonPymt.setLong(2, billRnd);										// BILL_RND
		
		deleteNonPymt.executeUpdate();
	}
	
    /**
     * Performs selects of the TopTen BTNs against table RABC_ACCT_BLG_DTL, using row information stored in
     * ArrayList acctDtl. If the BTN was not already inserted with this run, then the row is inserted
     * to RABC_ACCT_BLG_DTL.
     * 
     * @throws SQLException
	 *   if an SQLException is encountered while performing the database calls necessary to check for duplicates
	 *   and perform necessary inserts, then the exception is passed back, unaltered, to the calling function
	 *   for handling.
     */
	private void insertAcctDtlFromTopTen() throws SQLException{
		for (int i = 0; i < acctDtl.size(); i++) {
			String[] fields = (String[]) acctDtl.get(i);
			
			selectAcctDtl.setDate(1, sqlRunDate);										// RUN_DATE
			selectAcctDtl.setString(2, division);										// DIVISION
			selectAcctDtl.setString(3, fields[2]);								// BTN
			
			rs = selectAcctDtl.executeQuery();
			
			if (!rs.next()) {
				insertAcctDtl.setDate(1, sqlRunDate);									//RUN_DATE
				insertAcctDtl.setString(2, division);									//DIVISION
				insertAcctDtl.setString(3, fields[2]);							//BTN
				insertAcctDtl.setString(4, fields[3]);							//CUST_TYPE
				insertAcctDtl.setDouble(5, Double.parseDouble(fields[4]) / 100);		//LPC_AMT
				insertAcctDtl.setDouble(6, Double.parseDouble(fields[5]) / 100);		//RECUR_CHRG_AMT
				insertAcctDtl.setDouble(7, Double.parseDouble(fields[6]) / 100);		//ADJ_AMT_DB
				insertAcctDtl.setDouble(8, Double.parseDouble(fields[7]) / 100);		//ADJ_AMT_CR
				insertAcctDtl.setDouble(9, Double.parseDouble(fields[9]) / 100);		//CURR_OCC_CR
				insertAcctDtl.setDouble(10, Double.parseDouble(fields[8]) / 100);		//CURR_OCC_DB
				insertAcctDtl.setDouble(11, Double.parseDouble(fields[10]) / 100);		//CURR_BLG_AMT_DB
				insertAcctDtl.setDouble(12, Double.parseDouble(fields[11]) / 100);		//CURR_BLG_AMT_CR
				insertAcctDtl.setDouble(13, Double.parseDouble(fields[12]) / 100);		//BAL_DUE_AMT
				insertAcctDtl.setDouble(14, Double.parseDouble(fields[13]) / 100);		//LOCAL_TOLL_AMT
				insertAcctDtl.setDouble(15, Double.parseDouble(fields[14]) / 100);		//LOCAL_USG_AMT
				insertAcctDtl.setDouble(16, Double.parseDouble(fields[15]) / 100);		//IEC_AMT
				insertAcctDtl.setDouble(17, Double.parseDouble(fields[16]) / 100);		//PREV_BLG_AMT
				insertAcctDtl.setDouble(18, Double.parseDouble(fields[17]) / 100);		//PYMT_AMT
				insertAcctDtl.setDouble(19, Double.parseDouble(fields[18]) / 100);		// FED_NREG_CHRG
				insertAcctDtl.setDouble(20, Double.parseDouble(fields[19]) / 100);		// ST_LOC_NREG_CHRG
				insertAcctDtl.setDouble(21, Double.parseDouble(fields[26]) / 100);		// FED_TAXES_DB
				insertAcctDtl.setDouble(22, Double.parseDouble(fields[27]) / 100);		// FED_TAXES_CR
				insertAcctDtl.setDouble(23, Double.parseDouble(fields[28]) / 100);		// ST_TAXES_DB
				insertAcctDtl.setDouble(24, Double.parseDouble(fields[29]) / 100);		// ST_TAXES_CR
				insertAcctDtl.setDouble(25, Double.parseDouble(fields[30]) / 100);		// LOC_TAXES_DB
				insertAcctDtl.setDouble(26, Double.parseDouble(fields[31]) / 100);		// LOC_TAXES_CR
				insertAcctDtl.setDouble(27, Double.parseDouble(fields[20]) / 100);		// FED_SRCG_AMT_DB
				insertAcctDtl.setDouble(28, Double.parseDouble(fields[21]) / 100);		// FED_SRCG_AMT_CR
				insertAcctDtl.setDouble(29, Double.parseDouble(fields[22]) / 100);		// ST_SRCG_AMT_DB
				insertAcctDtl.setDouble(30, Double.parseDouble(fields[23]) / 100);		// ST_SRCG_AMT_CR
				insertAcctDtl.setDouble(31, Double.parseDouble(fields[24]) / 100);		// LOC_SRCG_AMT_DB
				insertAcctDtl.setDouble(32, Double.parseDouble(fields[25]) / 100);		// LOC_SRCG_AMT_CR
				insertAcctDtl.setLong(33, billRnd);										//BILL_RND
				
				insertAcctDtl.executeUpdate();
			}
		}
	}
	
	/**
	 * Performs an Insert to the TCCSEG_BOSS table on the Consumer Segmentation schema using the data from the most 
	 * recently read line of the input file.
	 * 
	 * @param line
	 *   the most recently read line of the input file.
	 * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob.
	 */
	private int insertBossData(String line) {

		try {
			String[] fields = line.split("\\;",-1); 
			insertBossData.setDate(1, dataCreateDate);				// DATA_CREATE_DATE
			insertBossData.setString(2, fields[2].trim());			// BTN
			insertBossData.setString(3, "A");						// REGION  ("A" for Ameritech)
			if ("".equals(fields[5].trim())){
				insertBossData.setString(4, SPACE);					// CRM_IND - insert Space if no value is passed in
			}else {
				insertBossData.setString(4, fields[5].trim());		// CRM_IND (SEGMENT_TYPE)
			}
			insertBossData.setString(5, division);					// DIVISION 
			insertBossData.setString(6, processGroup);				// PROCESS_GRP (Process Group)

			insertBossData.addBatch();
		} catch (SQLException sqle) {
			severe(StaticErrorMsgKeys.INSERT_ERROR + "from method insertBossData(String line)" + sqle.getMessage(), sqle);
			return ERROR;
		}
		
		return SUCCESS;
	}	
	
	
	/**
	 * Performs the .executeBatch() operation on all of the appropriate PreparedStatement objects.
	 * 
	 * @throws SQLException
	 *   if an SQLException is encountered while perform the batch executes, then the exception is passed back
	 *   to the calling function for handling.
	 */
	private void performBatchExecute() throws SQLException {
		insertAcctZero.executeBatch();												// RABC_ACCT_ZERO_BLG_SUMY
		insertISG.executeBatch();													// RABC_ISG_BLG_SUMY
		insertTopISGBlg.executeBatch();												// RABC_TOP_ISG_BLG_ACCT
		insertTopISGAdj.executeBatch();												// RABC_TOP_ISG_ADJ_ACCT
		insertTotBlg.executeBatch();												// RABC_TOT_BLG_SUMY
		insertAcctDtl.executeBatch();												// RABC_ACCT_BLG_DTL
		insertTopTen.executeBatch();												// RABC_TOP_TEN_BLG_ACCT
		insertTopLPC.executeBatch();												// RABC_TOP_LPC_ACCT
		insertNonPymt.executeBatch();												// RABC_NON_PYMT_BLG_ACCT
		insertTopOCC.executeBatch();												// RABC_TOP_OCC_BLG_ACCT
		insertTopAdj.executeBatch();												// RABC_TOP_ADJ_BLG_ACCT
		insertBossData.executeBatch();												// TCCSEG_BOSS
	}

	/**
	 * Call the super to do the commit or rollback then determines whether to update the TC FILE_STATUS table
	 * to "C" (Completed) or "E" (Errored).
	 * 
	 * @param file - the current file in the process.
	 * @param success - whether file processed successfully.
	 * @return success/failure of postprocessing of the files.
	 */
	protected int postprocessFileOpt(File file, int success) {
		success = super.postprocessFileOpt(file, success);
		
		if (success == ERROR || success == SKIPPED){
			updateTCFileStatus(dataCreateDate, JOBID, "E");
		} else {
			// update the TCCSEG_FILE_STATUS to "C" (Successful Completion)
			updateTCFileStatus(dataCreateDate, JOBID, "C");
			// send a message to EMCIS to indicate the input file was processed successfully.
			String fileName = file.getName();
			String[] tokens = fileName.split("\\.");
			String emcisFileName = tokens[0].trim() + "." + tokens[1].trim() + "." + tokens[2].trim();
			info("executing sendEventMessage in postProcessFile...");
			sendEventMessage(emcisFileName, sqlRunDate, lineCount);
		}
		
		return success;
	}
	/**
	 * Processes once the input file has been completely processed. Performs final batch execution of database calls. 
	 * Inserts Triggers for each data type that was processed during this run.
	 * 
	 * @param file
	 *   the currently processing file.
	 * @param success
	 *   the success so far for the application
	 * @return success for the application.
	 */
	public boolean postprocessFile(File file, boolean success) {
		try{
			//Log the file information to EMCIS_EVENT_LOG and EMCIS_EVENT_LOG_DETAIL
			EmcisEventLogger emcisLogger = new EmcisEventLogger();
			String event_id = "RABC_"+fileToken+"_"+region;
            String host = NetUtil.getLocalHostName();
            String hostIP = NetUtil.getLocalIpAddress();
			int sequence = emcisLogger.getEMCISSequence(connection);
			emcisLogger.insertEventLog(connection, sequence, event_id, sqlRunDate, host, hostIP);
			emcisLogger.insertEventLogDetail(connection, sequence, "FileName", fileName);

		}catch (UnknownHostException e) {
            severe("Error getting EMCIS host information ", e);
        }
		if (success) {
			try {
				if (!nonPymt.isEmpty()) {	// nonPymt still contains a record to be inserted
					insertNonPymtRecord((String[]) nonPymt.get(0));		// add final nonPymtRecord to the batch
				}
				insertAcctDtlAvgRecords();	// MUST occur BEFORE execution of performBatchExecute()
				deleteNonPymtRecords();		// MUST occur BEFORE execution of performBatchExecute()
				performBatchExecute();
				insertAcctDtlFromTopTen();  // MUST occur AFTER execution of performBatchExecute()
				
				if (!insertTrigger()) {
					severe(
						StaticErrorMsgKeys.POSTPROCESSFILE_ERROR
							+ StaticErrorMsgKeys.TIGGER_TABLE_INSERT_ERROR);
					success = false;
				}
			} catch (SQLException sqle) {
				severe(StaticErrorMsgKeys.INSERT_ERROR + "from method postprocessFile(File file, boolean success)" + sqle.getMessage(), sqle);
				success = false;
			}
		}
	
		return super.postprocessFile(file, success);
	}

	/**
	 * Method used to send an event message to EMCIS Primary Control Tool to indicate file was processed successfully
	 * 
	 * @param 	filename 
	 * @param	date 
	 * @param	numOfRecordsProcessed
	 * 
	 * @return	boolean
	 * 
	 */
	public boolean sendEventMessage(String fileName, Date date, int numOfRecordsProcessed) {
		DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
		String dateString = df.format(date);
		HashMap<String, String> keyValue = new HashMap<String, String>();
		keyValue.put("Records", Integer.toString(numOfRecordsProcessed));
		try {
			MessageSender sender = new MessageSender();
			StringBuffer message = new StringBuffer();
			message.append(fileName);
			info("Sending event message: " + message);  
			sender.sendMsg(message.toString(), dateString, keyValue);
			return true;
		} catch (MessageSenderException mse) {
			severe("Error sending event message", mse);
			return false;
		}
	}


	/**
	 * Inserts Triggers for each data type that was processed during this run.
	 * 
	 * @return true if all triggers were inserted, false otherwise.
	 */
	private boolean insertTrigger() {
		String recovery = null;
		
		if (lineCount > 0) {
			if (backupRecovery) {
				recovery = "Y";
			}
			
			for (int i = 0; i < triggers.size(); i++) {
				if (!RabcLoadJobTrig.insertTrigger(connection, currentFile.getName().substring(5, currentFile.getName().length()), currentFile.getName(), (String) triggers.get(i), division, MMddyyyy.format(sqlRunDate) , recovery, Long.toString(billRnd))) {
					return false;
				}
			}
		}
		return true;
	}
	
	/**
	 * Processes at the end of the application. Closes all open PreparedStatements and ResultSets.
	 * 
	 * @param success
	 *   the success of the application thus far
	 * @return success for the application.
	 */
	public boolean postprocess(boolean success) {
		JDBCUtil.closePreparedStatement(insertAcctZero);
		JDBCUtil.closePreparedStatement(insertISG);
		JDBCUtil.closePreparedStatement(insertTopISGBlg);
		JDBCUtil.closePreparedStatement(insertTopISGAdj);
		JDBCUtil.closePreparedStatement(insertTotBlg);
		JDBCUtil.closePreparedStatement(insertAcctDtl);
		JDBCUtil.closePreparedStatement(selectAverageAcctDtl);
		JDBCUtil.closePreparedStatement(selectAcctDtl);
		JDBCUtil.closePreparedStatement(insertTopTen);
		JDBCUtil.closePreparedStatement(insertTopLPC);
		JDBCUtil.closePreparedStatement(insertNonPymt);
		JDBCUtil.closePreparedStatement(deleteNonPymt);
		JDBCUtil.closePreparedStatement(insertTopOCC);
		JDBCUtil.closePreparedStatement(insertTopAdj);
		JDBCUtil.closePreparedStatement(insertAcctDtlAvg);
		JDBCUtil.closePreparedStatement(insertBossData);
		JDBCUtil.closePreparedStatement(selectFileStatus);
		JDBCUtil.closePreparedStatement(insertFileStatus);
		JDBCUtil.closePreparedStatement(updateFileStatus);
		JDBCUtil.closePreparedStatement(deleteFileStatus);
		
		JDBCUtil.closeResultSet(rs);
		
		return super.postprocess(success);
	}
	
	/**
	 * This method checks the TCCSEG_FILE_STATUS table and determines if it needs to insert or update the 
	 * File Status for the JOBID to the passed status code.
	 *
	 * @param dataCreateDate  
	 * @param dataCreateDate   
	 * @param JOBID - "MW_ACIS_"+division+"_PG"+processGroup
	 * @param status - status of the JOBID
	 * @return true or false
	 * @throws Exception 
	 */
	protected boolean updateTCFileStatus(java.sql.Date dataCreateDate, String JOBID, String status) {
		if (dataCreateDate == null){
			return true;
		}
		boolean result = true;
		try {
			selectFileStatus.setDate(1, dataCreateDate);			// DATA_CREATE_DATE
			selectFileStatus.setString(2, JOBID);
			rs2 = selectFileStatus.executeQuery();
			if (rs2.next()) {
				result =  updateFileStatus(dataCreateDate, JOBID, status);
			} else {
				result =  insertFileStatus(dataCreateDate,JOBID, status);
			}
		} catch (SQLException sqle) {
			severe("SQL Error occured during File Status processing in method updateTCFileStatus" + sqle.getMessage(), sqle);
			return false;
		} finally {
			JDBCUtil.closeResultSet(rs2);
		}
		
		return result;

	}
	/**
	 * Inserts a row into the TCCSEG_FILE_STATUS table for the MW_ACIS+processGroup jobID with a STATUS of 
	 * the passed status 
	 * 
	 * @param dataCreateDate  
	 * @param JOBID - "MW_ACIS_"+division+"_PG"+processGroup
	 * @param status - status of the JOBID
	 * @return true or false
	 */
	protected boolean insertFileStatus(java.sql.Date dataCreateDate, String JOBID, String status) {
		try {
			insertFileStatus.setDate(1, dataCreateDate);			// DATA_CREATE_DATE
			insertFileStatus.setString(2, JOBID);
			insertFileStatus.setString(3, status);
			insertFileStatus.execute();
		} catch (SQLException sqle) {
			severe("SQL error occurred in method insertFileStatus " + sqle.getMessage(), sqle);
			return false;
		}
		
		return true;

	}
	
	/**
	 * Delete the row from the TCCSEG_FILE_STATUS table for the jobID.  This is done because update does not work  
	 * currently due to the fact that we are running this job in production and updating the TCCSEC_FILE_STATUS 
	 * table in Prototype (which is where the Tertiary Controls application is running for "production" right now.
	 * So, we delete th row then do an insert to "in effect", update the File Status
	 *  
	 * 
	 * @param dataCreateDate  
	 * @param JOBID - "MW_ACIS_"+division+"_PG"+processGroup
	 * @return true or false
	 */	
	protected boolean deleteFileStatus(java.sql.Date dataCreateDate, String JOBID) {
		try {
			
			deleteFileStatus.setDate(1, dataCreateDate);			// DATA_CREATE_DATE
			deleteFileStatus.setString(2, JOBID);
			deleteFileStatus.execute();
			connection.commit();
		} catch (SQLException sqle) {
			severe("SQL error occurred in method deleteFileStatus " + sqle.getMessage(), sqle);
			return false;
		}
		
		return true;

	}
	
	/**
	 * This method will "update" the TCCSEG_FILE_STATUS to the passed status for the MW_ACIS JobID. 
	 *
	 * @param dataCreateDate   
	 * @param JOBID - "MW_ACIS_"+division+"_PG"+processGroup
	 * @param status - status of the JOBID
	 * @return true or false
	 */
	protected boolean updateFileStatus(java.sql.Date dataCreateDate,String JOBID, String status) {
	if (deleteFileStatus(dataCreateDate, JOBID)){
			insertFileStatus( dataCreateDate,JOBID, status);
			try {
				connection.commit();
			} catch (SQLException sqle2) {
				severe("SQL Error occured during commit in method updateFileStatus" + sqle2.getMessage(), sqle2);
				return false;
			}
		}
		return true;

	}	
}