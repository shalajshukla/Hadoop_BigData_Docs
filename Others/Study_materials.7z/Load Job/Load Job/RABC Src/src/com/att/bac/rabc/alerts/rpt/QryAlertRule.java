/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.rpt;

/**
 * This class represents the data object that holds the attributes required
 * for qryAlertData query used in Alert Rule Report.
 * 
 * @author Nalina Pandiyan - NP5434
 */
public class QryAlertRule {
	private String alertRule;
	private int partiRefId;
	private String fileVerifInd;
	private String dataExtrctInd;
	private String dataCalcInd;
	private String alertRuleType;
	private String calcRule;
	private String warningInd;
	private String avgInd;
	private String alertMsgInd;
	private String alertSeqNumInd;
	private String alertTimeInd;
	private String alertDashFreshInd;
	private String alertDesc;
	private int alertKeyLvl;
	private String[] alertKeyName = {"","","","",""};
	private int alertFileCt;
	private int divisionNameKeyLvl;
	private int presnId;
	private String webid;
	private int execPresnSeqNum;
	private String fileSeqNumInd;
	private String presnDataTbl;
	private int dataKeyLvl;
	private String mainKey1Ind;

	private String[] keyDdlName = {"","","","",""};
	private String[] keyHeader = {"","","","",""};
	private String[] keyHdLinkInd = {"","","","",""};
	private int[] keyHdLinkNum = {-1,-1,-1,-1,-1};
	private String[] keyHdParmInd = {"","","","",""};
	private String[] keyDataLinkInd = {"","","","",""};
	private int[] keyDataLinkNum = {-1,-1,-1,-1,-1};
	private String[] keyParmInd = {"","","","",""};
	private String[] keyDescInd = {"","","","",""};
	private int[] keyMouseOverNum = {-1,-1,-1,-1,-1};	
	
	private String alertDataName;
	private String alertHdName;
	private String alertHdLinkInd;
	private int alertHdLinkNum;
	private String alertHdParmInd;
	private String alertDataLinkInd;
	private int alertDataLinkNum;
	private String alertParmInd;
	private String alertDescInd;
	private int alertMouseOverNum;
	private int key1Seq;
	private String totInd;
	private int calccnt;
	private int seqcnt;
	private String tblProcDateDdlName;

	private String[] keyLinkDdlName = {"","","","",""};
	private String[] keyLinkToPgm = {"","","","",""};
	private int[] keyLinkPresnId = {-1,-1,-1,-1,-1};
	private String[] keyLinkTblKeyName = {"","","","",""};
	private String[] keyLinkTblKeyData = {"","","","",""};
	private String[] keyLinkTblName = {"","","","",""};
	private int presnSeqNum;
	private String sumyPresnName;
	private String cntSumyPresnName;

	/**
	 * @return Returns the AlertRule.
	 */
	public String getAlertRule() {
		return alertRule;
	}
	/**
	 * @return Returns the PartiRefId.
	 */
	public int getPartiRefId() {
		return partiRefId;
	}
	/**
	 * @return Returns the FileVerifInd.
	 */
	public String getFileVerifInd() {
		return fileVerifInd;
	}
	/**
	 * @return Returns the DataExtrctInd.
	 */
	public String getDataExtrctInd() {
		return dataExtrctInd;
	}
	/**
	 * @return Returns the DataCalcInd.
	 */
	public String getDataCalcInd() {
		return dataCalcInd;
	}
	/**
	 * @return Returns the CalcRule.
	 */
	public String getCalcRule() {
		return calcRule;
	}
	/**
	 * @return Returns the alertRuleType.
	 */
	public String getAlertRuleType() {
		return alertRuleType;
	}
	/**
	 * @param alertRuleType The alertRuleType to set.
	 */
	public void setAlertRuleType(String alertRuleType) {
		this.alertRuleType = alertRuleType;
	}
	/**
	 * @return Returns the WarningInd.
	 */
	public String getWarningInd() {
		return warningInd;
	}
	/**
	 * @return Returns the AvgInd.
	 */
	public String getAvgInd() {
		return avgInd;
	}
	/**
	 * @return Returns the AlertMsgInd.
	 */
	public String getAlertMsgInd() {
		return alertMsgInd;
	}
	/**
	 * @return Returns the AlertSeqNumInd.
	 */
	public String getAlertSeqNumInd() {
		return alertSeqNumInd;
	}
	/**
	 * @return Returns the AlertTimeInd.
	 */
	public String getAlertTimeInd() {
		return alertTimeInd;
	}
	/**
	 * @return Returns the AlertDashFreshInd.
	 */
	public String getAlertDashFreshInd() {
		return alertDashFreshInd;
	}
	/**
	 * @return Returns the AlertDesc.
	 */
	public String getAlertDesc() {
		return alertDesc;
	}
	/**
	 * @return Returns the AlertKeyLvl.
	 */
	public int getAlertKeyLvl() {
		return alertKeyLvl;
	}
	/**
	 * @return Returns the AlertKey1Name.
	 */
	public String getAlertKeyNameAt(int i) {
		return this.alertKeyName[i];
	}
	/**
	 * @return Returns the AlertFileCt.
	 */
	public int getAlertFileCt() {
		return alertFileCt;
	}
	/**
	 * @return Returns the DivisionNameKeyLvl.
	 */
	public int getDivisionNameKeyLvl() {
		return divisionNameKeyLvl;
	}
	/**
	 * @return Returns the PresnId.
	 */
	public int getPresnId() {
		return presnId;
	}
	/**
	 * @return Returns the Webid.
	 */
	public String getWebid() {
		return webid;
	}
	/**
	 * @return Returns the ExecPresnSeqNum.
	 */
	public int getExecPresnSeqNum() {
		return execPresnSeqNum;
	}
	/**
	 * @return Returns the FileSeqNumInd.
	 */
	public String getFileSeqNumInd() {
		return fileSeqNumInd;
	}
	/**
	 * @return Returns the PresnDataTbl.
	 */
	public String getPresnDataTbl() {
		return presnDataTbl;
	}
	/**
	 * @return Returns the DataKeyLvl.
	 */
	public int getDataKeyLvl() {
		return dataKeyLvl;
	}
	/**
	 * @return Returns the Key1DdlName.
	 */
	public String getKeyDdlNameAt(int i) {
		return this.keyDdlName[i];
	}
	/**
	 * @return Returns the MainKey1Ind.
	 */
	public String getMainKey1Ind() {
		return mainKey1Ind;
	}
	/**
	 * @return Returns the Key1Header.
	 */
	public String getKeyHeaderAt(int i) {
		return this.keyHeader[i];
	}
	/**
	 * @return Returns the Key1HdLinkInd.
	 */
	public String getKeyHdLinkIndAt(int i) {
		return this.keyHdLinkInd[i];
	}
	/**
	 * @return Returns the Key1HdLinkNum.
	 */
	public int getKeyHdLinkNumAt(int i) {
		return this.keyHdLinkNum[i];
	}
	/**
	 * @return Returns the Key1HdParmInd.
	 */
	public String getKeyHdParmIndAt(int i) {
		return this.keyHdParmInd[i];
	}
	/**
	 * @return Returns the Key1DataLinkInd.
	 */
	public String getKeyDataLinkIndAt(int i) {
		return this.keyDataLinkInd[i];
	}
	/**
	 * @return Returns the Key1DataLinkNum.
	 */
	public int getKeyDataLinkNumAt(int i) {
		return this.keyDataLinkNum[i];
	}
	/**
	 * @return Returns the Key1ParmInd.
	 */
	public String getKeyParmIndAt(int i) {
		return this.keyParmInd[i];
	}
	/**
	 * @return Returns the Key1DescInd.
	 */
	public String getKeyDescIndAt(int i) {
		return this.keyDescInd[i];
	}
	/**
	 * @return Returns the Key1MouseOverNum.
	 */
	public int getKeyMouseOverNumAt(int i) {
		return this.keyMouseOverNum[i];
	}
	/**
	 * @return Returns the AlertDataName.
	 */
	public String getAlertDataName() {
		return alertDataName;
	}
	/**
	 * @return Returns the AlertHdName.
	 */
	public String getAlertHdName() {
		return alertHdName;
	}
	/**
	 * @return Returns the AlertHdLinkInd.
	 */
	public String getAlertHdLinkInd() {
		return alertHdLinkInd;
	}
	/**
	 * @return Returns the AlertHdLinkNum.
	 */
	public int getAlertHdLinkNum() {
		return alertHdLinkNum;
	}
	/**
	 * @return Returns the AlertHdParmInd.
	 */
	public String getAlertHdParmInd() {
		return alertHdParmInd;
	}
	/**
	 * @return Returns the AlertDataLinkInd.
	 */
	public String getAlertDataLinkInd() {
		return alertDataLinkInd;
	}
	/**
	 * @return Returns the AlertDataLinkNum.
	 */
	public int getAlertDataLinkNum() {
		return alertDataLinkNum;
	}
	/**
	 * @return Returns the AlertParmInd.
	 */
	public String getAlertParmInd() {
		return alertParmInd;
	}
	/**
	 * @return Returns the AlertDescInd.
	 */
	public String getAlertDescInd() {
		return alertDescInd;
	}
	/**
	 * @return Returns the AlertMouseOverNum.
	 */
	public int getAlertMouseOverNum() {
		return alertMouseOverNum;
	}
	/**
	 * @return Returns the Key1Seq.
	 */
	public int getKey1Seq() {
		return key1Seq;
	}
	/**
	 * @return Returns the TotInd.
	 */
	public String getTotInd() {
		return totInd;
	}
	/**
	 * @return Returns the Calccnt.
	 */
	public int getCalccnt() {
		return calccnt;
	}
	/**
	 * @return Returns the Seqcnt.
	 */
	public int getSeqcnt() {
		return seqcnt;
	}
	/**
	 * @return Returns the TblProcDateDdlName.
	 */
	public String getTblProcDateDdlName() {
		return tblProcDateDdlName;
	}
	/**
	 * @return Returns the Key1LinkDdlName.
	 */
	public String getKeyLinkDdlNameAt(int i) {
		return this.keyLinkDdlName[i];
	}
	/**
	 * @return Returns the Key1LinkToPgm.
	 */
	public String getKeyLinkToPgmAt(int i) {
		return this.keyLinkToPgm[i];
	}
	/**
	 * @return Returns the Key1LinkPresnId.
	 */
	public int getKeyLinkPresnIdAt(int i) {
		return this.keyLinkPresnId[i];
	}
	/**
	 * @return Returns the Key1LinkTblKeyName.
	 */
	public String getKeyLinkTblKeyNameAt(int i) {
		return this.keyLinkTblKeyName[i];
	}
	/**
	 * @return Returns the Key1LinkTblKeyData.
	 */
	public String getKeyLinkTblKeyDataAt(int i) {
		return this.keyLinkTblKeyData[i];
	}
	/**
	 * @return Returns the Key1LinkTblName.
	 */
	public String getKeyLinkTblNameAt(int i) {
		return this.keyLinkTblName[i];
	}
	/**
	 * @param AlertRule The alertRule to set.
	 */
	public void setAlertRule(String alertRule) {
		this.alertRule = alertRule;
	}
	/**
	 * @param PartiRefId The partiRefId to set.
	 */
	public void setPartiRefId(int partiRefId) {
		this.partiRefId = partiRefId;
	}
	/**
	 * @param FileVerifInd The fileVerifInd to set.
	 */
	public void setFileVerifInd(String fileVerifInd) {
		this.fileVerifInd = fileVerifInd;
	}
	/**
	 * @param DataExtrctInd The dataExtrctInd to set.
	 */
	public void setDataExtrctInd(String dataExtrctInd) {
		this.dataExtrctInd = dataExtrctInd;
	}
	/**
	 * @param DataCalcInd The dataCalcInd to set.
	 */
	public void setDataCalcInd(String dataCalcInd) {
		this.dataCalcInd = dataCalcInd;
	}
	/**
	 * @param CalcRule The calcRule to set.
	 */
	public void setCalcRule(String calcRule) {
		this.calcRule = calcRule;
	}
	/**
	 * @param WarningInd The warningInd to set.
	 */
	public void setWarningInd(String warningInd) {
		this.warningInd = warningInd;
	}
	/**
	 * @param AvgInd The avgInd to set.
	 */
	public void setAvgInd(String avgInd) {
		this.avgInd = avgInd;
	}
	/**
	 * @param AlertMsgInd The alertMsgInd to set.
	 */
	public void setAlertMsgInd(String alertMsgInd) {
		this.alertMsgInd = alertMsgInd;
	}
	/**
	 * @param AlertSeqNumInd The alertSeqNumInd to set.
	 */
	public void setAlertSeqNumInd(String alertSeqNumInd) {
		this.alertSeqNumInd = alertSeqNumInd;
	}
	/**
	 * @param AlertTimeInd The alertTimeInd to set.
	 */
	public void setAlertTimeInd(String alertTimeInd) {
		this.alertTimeInd = alertTimeInd;
	}
	/**
	 * @param AlertDashFreshInd The alertDashFreshInd to set.
	 */
	public void setAlertDashFreshInd(String alertDashFreshInd) {
		this.alertDashFreshInd = alertDashFreshInd;
	}
	/**
	 * @param AlertDesc The alertDesc to set.
	 */
	public void setAlertDesc(String alertDesc) {
		this.alertDesc = alertDesc;
	}
	/**
	 * @param AlertKeyLvl The alertKeyLvl to set.
	 */
	public void setAlertKeyLvl(int alertKeyLvl) {
		this.alertKeyLvl = alertKeyLvl;
	}
	/**
	 * @param AlertKey1Name The alertKey1Name to set.
	 */
	public void setAlertKey1NameAt(int i, String alertKey1Name) {
		this.alertKeyName[i] = alertKey1Name;
	}
	/**
	 * @param AlertFileCt The alertFileCt to set.
	 */
	public void setAlertFileCt(int alertFileCt) {
		this.alertFileCt = alertFileCt;
	}
	/**
	 * @param DivisionNameKeyLvl The divisionNameKeyLvl to set.
	 */
	public void setDivisionNameKeyLvl(int divisionNameKeyLvl) {
		this.divisionNameKeyLvl = divisionNameKeyLvl;
	}
	/**
	 * @param PresnId The presnId to set.
	 */
	public void setPresnId(int presnId) {
		this.presnId = presnId;
	}
	/**
	 * @param Webid The webid to set.
	 */
	public void setWebid(String webid) {
		this.webid = webid;
	}
	/**
	 * @param ExecPresnSeqNum The execPresnSeqNum to set.
	 */
	public void setExecPresnSeqNum(int execPresnSeqNum) {
		this.execPresnSeqNum = execPresnSeqNum;
	}
	/**
	 * @param FileSeqNumInd The fileSeqNumInd to set.
	 */
	public void setFileSeqNumInd(String fileSeqNumInd) {
		this.fileSeqNumInd = fileSeqNumInd;
	}
	/**
	 * @param PresnDataTbl The presnDataTbl to set.
	 */
	public void setPresnDataTbl(String presnDataTbl) {
		this.presnDataTbl = presnDataTbl;
	}
	/**
	 * @param DataKeyLvl The dataKeyLvl to set.
	 */
	public void setDataKeyLvl(int dataKeyLvl) {
		this.dataKeyLvl = dataKeyLvl;
	}
	/**
	 * @param Key1DdlName The key1DdlName to set.
	 */
	public void setKeyDdlNameAt(int i, String key1DdlName) {
		this.keyDdlName[i] = key1DdlName;
	}
	/**
	 * @param MainKey1Ind The mainKey1Ind to set.
	 */
	public void setMainKey1Ind(String mainKey1Ind) {
		this.mainKey1Ind = mainKey1Ind;
	}
	/**
	 * @param Key1Header The key1Header to set.
	 */
	public void setKeyHeaderAt(int i, String key1Header) {
		this.keyHeader[i] = key1Header;
	}
	/**
	 * @param Key1HdLinkInd The key1HdLinkInd to set.
	 */
	public void setKeyHdLinkIndAt(int i, String key1HdLinkInd) {
		this.keyHdLinkInd[i] = key1HdLinkInd;
	}
	/**
	 * @param Key1HdLinkNum The key1HdLinkNum to set.
	 */
	public void setKeyHdLinkNumAt(int i, int key1HdLinkNum) {
		this.keyHdLinkNum[i] = key1HdLinkNum;
	}
	/**
	 * @param Key1HdParmInd The key1HdParmInd to set.
	 */
	public void setKeyHdParmIndAt(int i, String key1HdParmInd) {
		this.keyHdParmInd[i] = key1HdParmInd;
	}
	/**
	 * @param Key1DataLinkInd The key1DataLinkInd to set.
	 */
	public void setKeyDataLinkIndAt(int i, String key1DataLinkInd) {
		this.keyDataLinkInd[i] = key1DataLinkInd;
	}
	/**
	 * @param Key1DataLinkNum The key1DataLinkNum to set.
	 */
	public void setKeyDataLinkNumAt(int i, int key1DataLinkNum) {
		this.keyDataLinkNum[i] = key1DataLinkNum;
	}
	/**
	 * @param Key1ParmInd The key1ParmInd to set.
	 */
	public void setKeyParmIndAt(int i, String key1ParmInd) {
		this.keyParmInd[i] = key1ParmInd;
	}
	/**
	 * @param Key1DescInd The key1DescInd to set.
	 */
	public void setKeyDescIndAt(int i, String key1DescInd) {
		this.keyDescInd[i] = key1DescInd;
	}
	/**
	 * @param Key1MouseOverNum The key1MouseOverNum to set.
	 */
	public void setKeyMouseOverNumAt(int i, int key1MouseOverNum) {
		this.keyMouseOverNum[i] = key1MouseOverNum;
	}
	/**
	 * @param AlertDataName The alertDataName to set.
	 */
	public void setAlertDataName(String alertDataName) {
		this.alertDataName = alertDataName;
	}
	/**
	 * @param AlertHdName The alertHdName to set.
	 */
	public void setAlertHdName(String alertHdName) {
		this.alertHdName = alertHdName;
	}
	/**
	 * @param AlertHdLinkInd The alertHdLinkInd to set.
	 */
	public void setAlertHdLinkInd(String alertHdLinkInd) {
		this.alertHdLinkInd = alertHdLinkInd;
	}
	/**
	 * @param AlertHdLinkNum The alertHdLinkNum to set.
	 */
	public void setAlertHdLinkNum(int alertHdLinkNum) {
		this.alertHdLinkNum = alertHdLinkNum;
	}
	/**
	 * @param AlertHdParmInd The alertHdParmInd to set.
	 */
	public void setAlertHdParmInd(String alertHdParmInd) {
		this.alertHdParmInd = alertHdParmInd;
	}
	/**
	 * @param AlertDataLinkInd The alertDataLinkInd to set.
	 */
	public void setAlertDataLinkInd(String alertDataLinkInd) {
		this.alertDataLinkInd = alertDataLinkInd;
	}
	/**
	 * @param AlertDataLinkNum The alertDataLinkNum to set.
	 */
	public void setAlertDataLinkNum(int alertDataLinkNum) {
		this.alertDataLinkNum = alertDataLinkNum;
	}
	/**
	 * @param AlertParmInd The alertParmInd to set.
	 */
	public void setAlertParmInd(String alertParmInd) {
		this.alertParmInd = alertParmInd;
	}
	/**
	 * @param AlertDescInd The alertDescInd to set.
	 */
	public void setAlertDescInd(String alertDescInd) {
		this.alertDescInd = alertDescInd;
	}
	/**
	 * @param AlertMouseOverNum The alertMouseOverNum to set.
	 */
	public void setAlertMouseOverNum(int alertMouseOverNum) {
		this.alertMouseOverNum = alertMouseOverNum;
	}
	/**
	 * @param Key1Seq The key1Seq to set.
	 */
	public void setKey1Seq(int key1Seq) {
		this.key1Seq = key1Seq;
	}
	/**
	 * @param TotInd The totInd to set.
	 */
	public void setTotInd(String totInd) {
		this.totInd = totInd;
	}
	/**
	 * @param Calccnt The calccnt to set.
	 */
	public void setCalccnt(int calccnt) {
		this.calccnt = calccnt;
	}
	/**
	 * @param Seqcnt The seqcnt to set.
	 */
	public void setSeqcnt(int seqcnt) {
		this.seqcnt = seqcnt;
	}
	/**
	 * @param TblProcDateDdlName The tblProcDateDdlName to set.
	 */
	public void setTblProcDateDdlName(String tblProcDateDdlName) {
		this.tblProcDateDdlName = tblProcDateDdlName;
	}
	/**
	 * @param Key1LinkDdlName The key1LinkDdlName to set.
	 */
	public void setKeyLinkDdlNameAt(int i, String key1LinkDdlName) {
		this.keyLinkDdlName[i] = key1LinkDdlName;
	}
	/**
	 * @param Key1LinkToPgm The key1LinkToPgm to set.
	 */
	public void setKeyLinkToPgmAt(int i, String key1LinkToPgm) {
		this.keyLinkToPgm[i] = key1LinkToPgm;
	}
	/**
	 * @param Key1LinkPresnId The key1LinkPresnId to set.
	 */
	public void setKeyLinkPresnIdAt(int i, int key1LinkPresnId) {
		this.keyLinkPresnId[i] = key1LinkPresnId;
	}
	/**
	 * @param Key1LinkTblKeyName The key1LinkTblKeyName to set.
	 */
	public void setKeyLinkTblKeyNameAt(int i, String key1LinkTblKeyName) {
		this.keyLinkTblKeyName[i] = key1LinkTblKeyName;
	}
	/**
	 * @param Key1LinkTblKeyData The key1LinkTblKeyData to set.
	 */
	public void setKeyLinkTblKeyDataAt(int i, String key1LinkTblKeyData) {
		this.keyLinkTblKeyData[i] = key1LinkTblKeyData;
	}
	/**
	 * @param Key1LinkTblName The key1LinkTblName to set.
	 */
	public void setKeyLinkTblNameAt(int i, String key1LinkTblName) {
		this.keyLinkTblName[i] = key1LinkTblName;
	}
	/**
	 * @return Returns the presnSeqNum.
	 */
	public int getPresnSeqNum() {
		return presnSeqNum;
	}

	/**
	 * @param presnSeqNum The presnSeqNum to set.
	 */
	public void setPresnSeqNum(int presnSeqNum) {
		this.presnSeqNum = presnSeqNum;
	}

	/**
	 * @return Returns the sumyPresnName.
	 */
	public String getSumyPresnName() {
		return sumyPresnName;
	}

	/**
	 * @param sumyPresnName The sumyPresnName to set.
	 */
	public void setSumyPresnName(String sumyPresnName) {
		this.sumyPresnName = sumyPresnName;
	}

	/**
	 * @return Returns the cntSumyPresnName.
	 */
	public String getCntSumyPresnName() {
		return cntSumyPresnName;
	}

	/**
	 * @param cntSumyPresnName The cntSumyPresnName to set.
	 */
	public void setCntSumyPresnName(String cntSumyPresnName) {
		this.cntSumyPresnName = cntSumyPresnName;
	}

	/**
	 * This method compares the string with passed qryAlertRuleArg.
	 * 
	 * @param qryAlertRuleArg
	 * @return boolean
	 */
	public boolean equals(QryAlertRule qryAlertRuleArg) {
		if ((qryAlertRuleArg.getAlertRule() != null) && (!this.alertRule.equals(qryAlertRuleArg.getAlertRule()))) return false;
		if (this.partiRefId != qryAlertRuleArg.getPartiRefId()) return false;
		if ((qryAlertRuleArg.getFileVerifInd() != null) && (!this.fileVerifInd.equals(qryAlertRuleArg.getFileVerifInd()))) return false;
		if ((qryAlertRuleArg.getDataExtrctInd() != null) && (!this.dataExtrctInd.equals(qryAlertRuleArg.getDataExtrctInd()))) return false;
		if ((qryAlertRuleArg.getDataCalcInd() != null) && (!this.dataCalcInd.equals(qryAlertRuleArg.getDataCalcInd()))) return false;
		if ((qryAlertRuleArg.getCalcRule() != null) && (!this.calcRule.equals(qryAlertRuleArg.getCalcRule()))) return false;
		if ((qryAlertRuleArg.getWarningInd() != null) && (!this.warningInd.equals(qryAlertRuleArg.getWarningInd()))) return false;
		if ((qryAlertRuleArg.getAvgInd() != null) && (!this.avgInd.equals(qryAlertRuleArg.getAvgInd()))) return false;
		if ((qryAlertRuleArg.getAlertMsgInd() != null) && (!this.alertMsgInd.equals(qryAlertRuleArg.getAlertMsgInd()))) return false;
		if ((qryAlertRuleArg.getAlertSeqNumInd() != null) && (!this.alertSeqNumInd.equals(qryAlertRuleArg.getAlertSeqNumInd()))) return false;
		if ((qryAlertRuleArg.getAlertTimeInd() != null) && (!this.alertTimeInd.equals(qryAlertRuleArg.getAlertTimeInd()))) return false;
		if ((qryAlertRuleArg.getAlertDashFreshInd() != null) && (!this.alertDashFreshInd.equals(qryAlertRuleArg.getAlertDashFreshInd()))) return false;
		if ((qryAlertRuleArg.getAlertDesc() != null) && (!this.alertDesc.equals(qryAlertRuleArg.getAlertDesc()))) return false;
		if (this.alertKeyLvl != qryAlertRuleArg.getAlertKeyLvl()) return false;
		if (this.alertFileCt != qryAlertRuleArg.getAlertFileCt()) return false;
		if (this.divisionNameKeyLvl != qryAlertRuleArg.getDivisionNameKeyLvl()) return false;
		if (this.presnId != qryAlertRuleArg.getPresnId()) return false;
		if ((qryAlertRuleArg.getWebid() != null) && (!this.webid.equals(qryAlertRuleArg.getWebid()))) return false;
		if (this.execPresnSeqNum != qryAlertRuleArg.getExecPresnSeqNum()) return false;
		if ((qryAlertRuleArg.getFileSeqNumInd() != null) && (!this.fileSeqNumInd.equals(qryAlertRuleArg.getFileSeqNumInd()))) return false;
		if ((qryAlertRuleArg.getPresnDataTbl() != null) && (!this.presnDataTbl.equals(qryAlertRuleArg.getPresnDataTbl()))) return false;
		if (this.dataKeyLvl != qryAlertRuleArg.getDataKeyLvl()) return false;
		if ((qryAlertRuleArg.getMainKey1Ind() != null) && (!this.mainKey1Ind.equals(qryAlertRuleArg.getMainKey1Ind()))) return false;
		if ((qryAlertRuleArg.getAlertDataName() != null) && (!this.alertDataName.equals(qryAlertRuleArg.getAlertDataName()))) return false;
		if ((qryAlertRuleArg.getAlertHdName() != null) && (!this.alertHdName.equals(qryAlertRuleArg.getAlertHdName()))) return false;
		if ((qryAlertRuleArg.getAlertHdLinkInd() != null) && (!this.alertHdLinkInd.equals(qryAlertRuleArg.getAlertHdLinkInd()))) return false;
		if (this.alertHdLinkNum != qryAlertRuleArg.getAlertHdLinkNum()) return false;
		if ((qryAlertRuleArg.getAlertHdParmInd() != null) && (!this.alertHdParmInd.equals(qryAlertRuleArg.getAlertHdParmInd()))) return false;
		if ((qryAlertRuleArg.getAlertDataLinkInd() != null) && (!this.alertDataLinkInd.equals(qryAlertRuleArg.getAlertDataLinkInd()))) return false;
		if (this.alertDataLinkNum != qryAlertRuleArg.getAlertDataLinkNum()) return false;
		if ((qryAlertRuleArg.getAlertParmInd() != null) && (!this.alertParmInd.equals(qryAlertRuleArg.getAlertParmInd()))) return false;
		if ((qryAlertRuleArg.getAlertDescInd() != null) && (!this.alertDescInd.equals(qryAlertRuleArg.getAlertDescInd()))) return false;
		if (this.alertMouseOverNum != qryAlertRuleArg.getAlertMouseOverNum()) return false;
		if (this.key1Seq != qryAlertRuleArg.getKey1Seq()) return false;
		if ((qryAlertRuleArg.getTotInd() != null) && (!this.totInd.equals(qryAlertRuleArg.getTotInd()))) return false;
		if (this.calccnt != qryAlertRuleArg.getCalccnt()) return false;
		if (this.seqcnt != qryAlertRuleArg.getSeqcnt()) return false;
		if ((qryAlertRuleArg.getTblProcDateDdlName() != null) && (!this.tblProcDateDdlName.equals(qryAlertRuleArg.getTblProcDateDdlName()))) return false;
		if (this.presnSeqNum != qryAlertRuleArg.getPresnSeqNum()) return false;
		if ((qryAlertRuleArg.getSumyPresnName() != null) && (!this.sumyPresnName.equals(qryAlertRuleArg.getSumyPresnName()))) return false;
		if ((qryAlertRuleArg.getCntSumyPresnName() != null) && (!this.cntSumyPresnName.equals(qryAlertRuleArg.getCntSumyPresnName()))) return false;
		if ((qryAlertRuleArg.getAlertKeyNameAt(0) != null) && (!this.alertKeyName[0].equals(qryAlertRuleArg.getAlertKeyNameAt(0)))) return false;
		if ((qryAlertRuleArg.getAlertKeyNameAt(1) != null) && (!this.alertKeyName[1].equals(qryAlertRuleArg.getAlertKeyNameAt(1)))) return false;
		if ((qryAlertRuleArg.getAlertKeyNameAt(2) != null) && (!this.alertKeyName[2].equals(qryAlertRuleArg.getAlertKeyNameAt(2)))) return false;
		if ((qryAlertRuleArg.getAlertKeyNameAt(3) != null) && (!this.alertKeyName[3].equals(qryAlertRuleArg.getAlertKeyNameAt(3)))) return false;
		if ((qryAlertRuleArg.getAlertKeyNameAt(4) != null) && (!this.alertKeyName[4].equals(qryAlertRuleArg.getAlertKeyNameAt(4)))) return false;
		if ((qryAlertRuleArg.getKeyDdlNameAt(0) != null) && (!this.keyDdlName[0].equals(qryAlertRuleArg.getKeyDdlNameAt(0)))) return false;
		if ((qryAlertRuleArg.getKeyDdlNameAt(1) != null) && (!this.keyDdlName[1].equals(qryAlertRuleArg.getKeyDdlNameAt(1)))) return false;
		if ((qryAlertRuleArg.getKeyDdlNameAt(2) != null) && (!this.keyDdlName[2].equals(qryAlertRuleArg.getKeyDdlNameAt(2)))) return false;
		if ((qryAlertRuleArg.getKeyDdlNameAt(3) != null) && (!this.keyDdlName[3].equals(qryAlertRuleArg.getKeyDdlNameAt(3)))) return false;
		if ((qryAlertRuleArg.getKeyDdlNameAt(4) != null) && (!this.keyDdlName[4].equals(qryAlertRuleArg.getKeyDdlNameAt(4)))) return false;
		if ((qryAlertRuleArg.getKeyHeaderAt(0) != null) && (!this.keyHeader[0].equals(qryAlertRuleArg.getKeyHeaderAt(0)))) return false;
		if ((qryAlertRuleArg.getKeyHeaderAt(1) != null) && (!this.keyHeader[1].equals(qryAlertRuleArg.getKeyHeaderAt(1)))) return false;
		if ((qryAlertRuleArg.getKeyHeaderAt(2) != null) && (!this.keyHeader[2].equals(qryAlertRuleArg.getKeyHeaderAt(2)))) return false;
		if ((qryAlertRuleArg.getKeyHeaderAt(3) != null) && (!this.keyHeader[3].equals(qryAlertRuleArg.getKeyHeaderAt(3)))) return false;
		if ((qryAlertRuleArg.getKeyHeaderAt(4) != null) && (!this.keyHeader[4].equals(qryAlertRuleArg.getKeyHeaderAt(4)))) return false;
		if ((qryAlertRuleArg.getKeyHdLinkIndAt(0) != null) && (!this.keyHdLinkInd[0].equals(qryAlertRuleArg.getKeyHdLinkIndAt(0)))) return false;
		if ((qryAlertRuleArg.getKeyHdLinkIndAt(1) != null) && (!this.keyHdLinkInd[1].equals(qryAlertRuleArg.getKeyHdLinkIndAt(1)))) return false;
		if ((qryAlertRuleArg.getKeyHdLinkIndAt(2) != null) && (!this.keyHdLinkInd[2].equals(qryAlertRuleArg.getKeyHdLinkIndAt(2)))) return false;
		if ((qryAlertRuleArg.getKeyHdLinkIndAt(3) != null) && (!this.keyHdLinkInd[3].equals(qryAlertRuleArg.getKeyHdLinkIndAt(3)))) return false;
		if ((qryAlertRuleArg.getKeyHdLinkIndAt(4) != null) && (!this.keyHdLinkInd[4].equals(qryAlertRuleArg.getKeyHdLinkIndAt(4)))) return false;
		if (this.keyHdLinkNum[0] != qryAlertRuleArg.getKeyHdLinkNumAt(0)) return false;
		if (this.keyHdLinkNum[1] != qryAlertRuleArg.getKeyHdLinkNumAt(1)) return false;
		if (this.keyHdLinkNum[2] != qryAlertRuleArg.getKeyHdLinkNumAt(2)) return false;
		if (this.keyHdLinkNum[3] != qryAlertRuleArg.getKeyHdLinkNumAt(3)) return false;
		if (this.keyHdLinkNum[4] != qryAlertRuleArg.getKeyHdLinkNumAt(4)) return false;
		if ((qryAlertRuleArg.getKeyHdParmIndAt(0) != null) && (!this.keyHdParmInd[0].equals(qryAlertRuleArg.getKeyHdParmIndAt(0)))) return false;
		if ((qryAlertRuleArg.getKeyHdParmIndAt(1) != null) && (!this.keyHdParmInd[1].equals(qryAlertRuleArg.getKeyHdParmIndAt(1)))) return false;
		if ((qryAlertRuleArg.getKeyHdParmIndAt(2) != null) && (!this.keyHdParmInd[2].equals(qryAlertRuleArg.getKeyHdParmIndAt(2)))) return false;
		if ((qryAlertRuleArg.getKeyHdParmIndAt(3) != null) && (!this.keyHdParmInd[3].equals(qryAlertRuleArg.getKeyHdParmIndAt(3)))) return false;
		if ((qryAlertRuleArg.getKeyHdParmIndAt(4) != null) && (!this.keyHdParmInd[4].equals(qryAlertRuleArg.getKeyHdParmIndAt(4)))) return false;
		if ((qryAlertRuleArg.getKeyDataLinkIndAt(0) != null) && (!this.keyDataLinkInd[0].equals(qryAlertRuleArg.getKeyDataLinkIndAt(0)))) return false;
		if ((qryAlertRuleArg.getKeyDataLinkIndAt(1) != null) && (!this.keyDataLinkInd[1].equals(qryAlertRuleArg.getKeyDataLinkIndAt(1)))) return false;
		if ((qryAlertRuleArg.getKeyDataLinkIndAt(2) != null) && (!this.keyDataLinkInd[2].equals(qryAlertRuleArg.getKeyDataLinkIndAt(2)))) return false;
		if ((qryAlertRuleArg.getKeyDataLinkIndAt(3) != null) && (!this.keyDataLinkInd[3].equals(qryAlertRuleArg.getKeyDataLinkIndAt(3)))) return false;
		if ((qryAlertRuleArg.getKeyDataLinkIndAt(4) != null) && (!this.keyDataLinkInd[4].equals(qryAlertRuleArg.getKeyDataLinkIndAt(4)))) return false;
		if (this.keyDataLinkNum[0] != qryAlertRuleArg.getKeyDataLinkNumAt(0)) return false;
		if (this.keyDataLinkNum[1] != qryAlertRuleArg.getKeyDataLinkNumAt(1)) return false;
		if (this.keyDataLinkNum[2] != qryAlertRuleArg.getKeyDataLinkNumAt(2)) return false;
		if (this.keyDataLinkNum[3] != qryAlertRuleArg.getKeyDataLinkNumAt(3)) return false;
		if (this.keyDataLinkNum[4] != qryAlertRuleArg.getKeyDataLinkNumAt(4)) return false;
		if ((qryAlertRuleArg.getKeyParmIndAt(0) != null) && (!this.keyParmInd[0].equals(qryAlertRuleArg.getKeyParmIndAt(0)))) return false;
		if ((qryAlertRuleArg.getKeyParmIndAt(1) != null) && (!this.keyParmInd[1].equals(qryAlertRuleArg.getKeyParmIndAt(1)))) return false;
		if ((qryAlertRuleArg.getKeyParmIndAt(2) != null) && (!this.keyParmInd[2].equals(qryAlertRuleArg.getKeyParmIndAt(2)))) return false;
		if ((qryAlertRuleArg.getKeyParmIndAt(3) != null) && (!this.keyParmInd[3].equals(qryAlertRuleArg.getKeyParmIndAt(3)))) return false;
		if ((qryAlertRuleArg.getKeyParmIndAt(4) != null) && (!this.keyParmInd[4].equals(qryAlertRuleArg.getKeyParmIndAt(4)))) return false;
		if ((qryAlertRuleArg.getKeyDescIndAt(0) != null) && (!this.keyDescInd[0].equals(qryAlertRuleArg.getKeyDescIndAt(0)))) return false;
		if ((qryAlertRuleArg.getKeyDescIndAt(1) != null) && (!this.keyDescInd[1].equals(qryAlertRuleArg.getKeyDescIndAt(1)))) return false;
		if ((qryAlertRuleArg.getKeyDescIndAt(2) != null) && (!this.keyDescInd[2].equals(qryAlertRuleArg.getKeyDescIndAt(2)))) return false;
		if ((qryAlertRuleArg.getKeyDescIndAt(3) != null) && (!this.keyDescInd[3].equals(qryAlertRuleArg.getKeyDescIndAt(3)))) return false;
		if ((qryAlertRuleArg.getKeyDescIndAt(4) != null) && (!this.keyDescInd[4].equals(qryAlertRuleArg.getKeyDescIndAt(4)))) return false;
		if (this.keyMouseOverNum[0] != qryAlertRuleArg.getKeyMouseOverNumAt(0)) return false;
		if (this.keyMouseOverNum[1] != qryAlertRuleArg.getKeyMouseOverNumAt(1)) return false;
		if (this.keyMouseOverNum[2] != qryAlertRuleArg.getKeyMouseOverNumAt(2)) return false;
		if (this.keyMouseOverNum[3] != qryAlertRuleArg.getKeyMouseOverNumAt(3)) return false;
		if (this.keyMouseOverNum[4] != qryAlertRuleArg.getKeyMouseOverNumAt(4)) return false;
		if ((qryAlertRuleArg.getKeyLinkDdlNameAt(0) != null) && (!this.keyLinkDdlName[0].equals(qryAlertRuleArg.getKeyLinkDdlNameAt(0)))) return false;
		if ((qryAlertRuleArg.getKeyLinkDdlNameAt(1) != null) && (!this.keyLinkDdlName[1].equals(qryAlertRuleArg.getKeyLinkDdlNameAt(1)))) return false;
		if ((qryAlertRuleArg.getKeyLinkDdlNameAt(2) != null) && (!this.keyLinkDdlName[2].equals(qryAlertRuleArg.getKeyLinkDdlNameAt(2)))) return false;
		if ((qryAlertRuleArg.getKeyLinkDdlNameAt(3) != null) && (!this.keyLinkDdlName[3].equals(qryAlertRuleArg.getKeyLinkDdlNameAt(3)))) return false;
		if ((qryAlertRuleArg.getKeyLinkDdlNameAt(4) != null) && (!this.keyLinkDdlName[4].equals(qryAlertRuleArg.getKeyLinkDdlNameAt(4)))) return false;
		if ((qryAlertRuleArg.getKeyLinkToPgmAt(0) != null) && (!this.keyLinkToPgm[0].equals(qryAlertRuleArg.getKeyLinkToPgmAt(0)))) return false;
		if ((qryAlertRuleArg.getKeyLinkToPgmAt(1) != null) && (!this.keyLinkToPgm[1].equals(qryAlertRuleArg.getKeyLinkToPgmAt(1)))) return false;
		if ((qryAlertRuleArg.getKeyLinkToPgmAt(2) != null) && (!this.keyLinkToPgm[2].equals(qryAlertRuleArg.getKeyLinkToPgmAt(2)))) return false;
		if ((qryAlertRuleArg.getKeyLinkToPgmAt(3) != null) && (!this.keyLinkToPgm[3].equals(qryAlertRuleArg.getKeyLinkToPgmAt(3)))) return false;
		if ((qryAlertRuleArg.getKeyLinkToPgmAt(4) != null) && (!this.keyLinkToPgm[4].equals(qryAlertRuleArg.getKeyLinkToPgmAt(4)))) return false;
		if (this.keyLinkPresnId[0] != qryAlertRuleArg.getKeyLinkPresnIdAt(0)) return false;
		if (this.keyLinkPresnId[1] != qryAlertRuleArg.getKeyLinkPresnIdAt(1)) return false;
		if (this.keyLinkPresnId[2] != qryAlertRuleArg.getKeyLinkPresnIdAt(2)) return false;
		if (this.keyLinkPresnId[3] != qryAlertRuleArg.getKeyLinkPresnIdAt(3)) return false;
		if (this.keyLinkPresnId[4] != qryAlertRuleArg.getKeyLinkPresnIdAt(4)) return false;
		if ((qryAlertRuleArg.getKeyLinkTblKeyNameAt(0) != null) && (!this.keyLinkTblKeyName[0].equals(qryAlertRuleArg.getKeyLinkTblKeyNameAt(0)))) return false;
		if ((qryAlertRuleArg.getKeyLinkTblKeyNameAt(1) != null) && (!this.keyLinkTblKeyName[1].equals(qryAlertRuleArg.getKeyLinkTblKeyNameAt(1)))) return false;
		if ((qryAlertRuleArg.getKeyLinkTblKeyNameAt(2) != null) && (!this.keyLinkTblKeyName[2].equals(qryAlertRuleArg.getKeyLinkTblKeyNameAt(2)))) return false;
		if ((qryAlertRuleArg.getKeyLinkTblKeyNameAt(3) != null) && (!this.keyLinkTblKeyName[3].equals(qryAlertRuleArg.getKeyLinkTblKeyNameAt(3)))) return false;
		if ((qryAlertRuleArg.getKeyLinkTblKeyNameAt(4) != null) && (!this.keyLinkTblKeyName[4].equals(qryAlertRuleArg.getKeyLinkTblKeyNameAt(4)))) return false;
		if ((qryAlertRuleArg.getKeyLinkTblKeyDataAt(0) != null) && (!this.keyLinkTblKeyData[0].equals(qryAlertRuleArg.getKeyLinkTblKeyDataAt(0)))) return false;
		if ((qryAlertRuleArg.getKeyLinkTblKeyDataAt(1) != null) && (!this.keyLinkTblKeyData[1].equals(qryAlertRuleArg.getKeyLinkTblKeyDataAt(1)))) return false;
		if ((qryAlertRuleArg.getKeyLinkTblKeyDataAt(2) != null) && (!this.keyLinkTblKeyData[2].equals(qryAlertRuleArg.getKeyLinkTblKeyDataAt(2)))) return false;
		if ((qryAlertRuleArg.getKeyLinkTblKeyDataAt(3) != null) && (!this.keyLinkTblKeyData[3].equals(qryAlertRuleArg.getKeyLinkTblKeyDataAt(3)))) return false;
		if ((qryAlertRuleArg.getKeyLinkTblKeyDataAt(4) != null) && (!this.keyLinkTblKeyData[4].equals(qryAlertRuleArg.getKeyLinkTblKeyDataAt(4)))) return false;
		if ((qryAlertRuleArg.getKeyLinkTblNameAt(0) != null) && (!this.keyLinkTblName[0].equals(qryAlertRuleArg.getKeyLinkTblNameAt(0)))) return false;
		if ((qryAlertRuleArg.getKeyLinkTblNameAt(1) != null) && (!this.keyLinkTblName[1].equals(qryAlertRuleArg.getKeyLinkTblNameAt(1)))) return false;
		if ((qryAlertRuleArg.getKeyLinkTblNameAt(2) != null) && (!this.keyLinkTblName[2].equals(qryAlertRuleArg.getKeyLinkTblNameAt(2)))) return false;
		if ((qryAlertRuleArg.getKeyLinkTblNameAt(3) != null) && (!this.keyLinkTblName[3].equals(qryAlertRuleArg.getKeyLinkTblNameAt(3)))) return false;
		if ((qryAlertRuleArg.getKeyLinkTblNameAt(4) != null) && (!this.keyLinkTblName[4].equals(qryAlertRuleArg.getKeyLinkTblNameAt(4)))) return false;
		return true;
	}
	
	/**
	 * This method to get labels for the tmpStrBuf.
	 * 
	 * @return String
	 */
	public String getLabels() {
		StringBuffer tmpStrBuf = new StringBuffer();
		
		tmpStrBuf.append("alertRule");
		tmpStrBuf.append(",");
		tmpStrBuf.append("partiRefId");
		tmpStrBuf.append(",");
		tmpStrBuf.append("fileVerifInd");
		tmpStrBuf.append(",");
		tmpStrBuf.append("dataExtrctInd");
		tmpStrBuf.append(",");
		tmpStrBuf.append("dataCalcInd");
		tmpStrBuf.append(",");
		tmpStrBuf.append("calcRule");
		tmpStrBuf.append(",");
		tmpStrBuf.append("warningInd");
		tmpStrBuf.append(",");
		tmpStrBuf.append("avgInd");
		tmpStrBuf.append(",");
		tmpStrBuf.append("alertMsgInd");
		tmpStrBuf.append(",");
		tmpStrBuf.append("alertSeqNumInd");
		tmpStrBuf.append(",");
		tmpStrBuf.append("alertTimeInd");
		tmpStrBuf.append(",");
		tmpStrBuf.append("alertDashFreshInd");
		tmpStrBuf.append(",");
		tmpStrBuf.append("alertDesc");
		tmpStrBuf.append(",");
		tmpStrBuf.append("alertKeyLvl");
		tmpStrBuf.append(",");
		tmpStrBuf.append("alertKeyName_1");
		tmpStrBuf.append(",");
		tmpStrBuf.append("alertKeyName_2");
		tmpStrBuf.append(",");
		tmpStrBuf.append("alertKeyName_3");
		tmpStrBuf.append(",");
		tmpStrBuf.append("alertKeyName_4");
		tmpStrBuf.append(",");
		tmpStrBuf.append("alertKeyName_5");
		tmpStrBuf.append(",");
		tmpStrBuf.append("alertFileCt");
		tmpStrBuf.append(",");
		tmpStrBuf.append("divisionNameKeyLvl");
		tmpStrBuf.append(",");
		tmpStrBuf.append("presnId");
		tmpStrBuf.append(",");
		tmpStrBuf.append("webid");
		tmpStrBuf.append(",");
		tmpStrBuf.append("execPresnSeqNum");
		tmpStrBuf.append(",");
		tmpStrBuf.append("fileSeqNumInd");
		tmpStrBuf.append(",");
		tmpStrBuf.append("presnDataTbl");
		tmpStrBuf.append(",");
		tmpStrBuf.append("dataKeyLvl");
		tmpStrBuf.append(",");
		tmpStrBuf.append("mainKey1Ind");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyDdlName_1");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyDdlName_2");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyDdlName_3");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyDdlName_4");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyDdlName_5");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyHeader_1");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyHeader_2");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyHeader_3");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyHeader_4");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyHeader_5");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyHdLinkInd_1");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyHdLinkInd_2");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyHdLinkInd_3");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyHdLinkInd_4");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyHdLinkInd_5");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyHdLinkNum_1");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyHdLinkNum_2");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyHdLinkNum_3");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyHdLinkNum_4");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyHdLinkNum_5");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyHdParmInd_1");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyHdParmInd_2");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyHdParmInd_3");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyHdParmInd_4");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyHdParmInd_5");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyDataLinkInd_1");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyDataLinkInd_2");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyDataLinkInd_3");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyDataLinkInd_4");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyDataLinkInd_5");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyDataLinkNum_1");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyDataLinkNum_2");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyDataLinkNum_3");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyDataLinkNum_4");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyDataLinkNum_5");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyParmInd_1");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyParmInd_2");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyParmInd_3");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyParmInd_4");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyParmInd_5");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyDescInd_1");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyDescInd_2");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyDescInd_3");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyDescInd_4");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyDescInd_5");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyMouseOverNum_1");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyMouseOverNum_2");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyMouseOverNum_3");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyMouseOverNum_4");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyMouseOverNum_5");	
		tmpStrBuf.append(",");
		tmpStrBuf.append("alertDataName");
		tmpStrBuf.append(",");
		tmpStrBuf.append("alertHdName");
		tmpStrBuf.append(",");
		tmpStrBuf.append("alertHdLinkInd");
		tmpStrBuf.append(",");
		tmpStrBuf.append("alertHdLinkNum");
		tmpStrBuf.append(",");
		tmpStrBuf.append("alertHdParmInd");
		tmpStrBuf.append(",");
		tmpStrBuf.append("alertDataLinkInd");
		tmpStrBuf.append(",");
		tmpStrBuf.append("alertDataLinkNum");
		tmpStrBuf.append(",");
		tmpStrBuf.append("alertParmInd");
		tmpStrBuf.append(",");
		tmpStrBuf.append("alertDescInd");
		tmpStrBuf.append(",");
		tmpStrBuf.append("alertMouseOverNum");
		tmpStrBuf.append(",");
		tmpStrBuf.append("key1Seq");
		tmpStrBuf.append(",");
		tmpStrBuf.append("totInd");
		tmpStrBuf.append(",");
		tmpStrBuf.append("calccnt");
		tmpStrBuf.append(",");
		tmpStrBuf.append("seqcnt");
		tmpStrBuf.append(",");
		tmpStrBuf.append("tblProcDateDdlName");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyLinkDdlName_1");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyLinkDdlName_2");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyLinkDdlName_3");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyLinkDdlName_4");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyLinkDdlName_5");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyLinkToPgm_1");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyLinkToPgm_2");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyLinkToPgm_3");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyLinkToPgm_4");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyLinkToPgm_5");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyLinkPresnId_1");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyLinkPresnId_2");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyLinkPresnId_3");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyLinkPresnId_4");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyLinkPresnId_5");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyLinkTblKeyName_1");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyLinkTblKeyName_2");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyLinkTblKeyName_3");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyLinkTblKeyName_4");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyLinkTblKeyName_5");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyLinkTblKeyData_1");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyLinkTblKeyData_2");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyLinkTblKeyData_3");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyLinkTblKeyData_4");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyLinkTblKeyData_5");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyLinkTblName_1");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyLinkTblName_2");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyLinkTblName_3");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyLinkTblName_4");
		tmpStrBuf.append(",");
		tmpStrBuf.append("keyLinkTblName_5");
		tmpStrBuf.append(",");
		tmpStrBuf.append("presnSeqNum");
		tmpStrBuf.append(",");
		tmpStrBuf.append("sumyPresnName");
		tmpStrBuf.append(",");
		tmpStrBuf.append("cntSumyPresnName");

		return tmpStrBuf.toString();
	}
	
	/**
	 * This method returns comma separated value of each attribute.
	 */
	public String toString() {
		// returns comma separated value of each attribute
		StringBuffer tmpStrBuf = new StringBuffer();
		tmpStrBuf.append((alertRule==null?"":this.alertRule));
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.partiRefId);
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.fileVerifInd==null?"":this.fileVerifInd));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.dataExtrctInd==null?"":this.dataExtrctInd));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.dataCalcInd==null?"":this.dataCalcInd));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.calcRule==null?"":this.calcRule));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.warningInd==null?"":this.warningInd));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.avgInd==null?"":this.avgInd));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.alertMsgInd==null?"":this.alertMsgInd));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.alertSeqNumInd==null?"":this.alertSeqNumInd));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.alertTimeInd==null?"":this.alertTimeInd));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.alertDashFreshInd==null?"":this.alertDashFreshInd));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.alertDesc==null?"":this.alertDesc));
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.alertKeyLvl);
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.alertKeyName[0]==null?"":this.alertKeyName[0]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.alertKeyName[1]==null?"":this.alertKeyName[1]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.alertKeyName[2]==null?"":this.alertKeyName[2]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.alertKeyName[3]==null?"":this.alertKeyName[3]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.alertKeyName[4]==null?"":this.alertKeyName[4]));
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.alertFileCt);
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.divisionNameKeyLvl);
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.presnId);
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.webid==null?"":this.webid));
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.execPresnSeqNum);
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.fileSeqNumInd==null?"":this.fileSeqNumInd));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.presnDataTbl==null?"":this.presnDataTbl));
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.dataKeyLvl);
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.mainKey1Ind==null?"":this.mainKey1Ind));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyDdlName[0]==null?"":this.keyDdlName[0]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyDdlName[1]==null?"":this.keyDdlName[1]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyDdlName[2]==null?"":this.keyDdlName[2]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyDdlName[3]==null?"":this.keyDdlName[3]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyDdlName[4]==null?"":this.keyDdlName[4]));
		tmpStrBuf.append(","); 
		tmpStrBuf.append((this.keyHeader[0]==null?"":this.keyHeader[0]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyHeader[1]==null?"":this.keyHeader[1]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyHeader[2]==null?"":this.keyHeader[2]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyHeader[3]==null?"":this.keyHeader[3]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyHeader[4]==null?"":this.keyHeader[4]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyHdLinkInd[0]==null?"":this.keyHdLinkInd[0]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyHdLinkInd[1]==null?"":this.keyHdLinkInd[1]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyHdLinkInd[2]==null?"":this.keyHdLinkInd[2]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyHdLinkInd[3]==null?"":this.keyHdLinkInd[3]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyHdLinkInd[4]==null?"":this.keyHdLinkInd[4]));
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.keyHdLinkNum[0]);
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.keyHdLinkNum[1]);
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.keyHdLinkNum[2]);
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.keyHdLinkNum[3]);
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.keyHdLinkNum[4]);
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyHdParmInd[0]==null?"":this.keyHdParmInd[0]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyHdParmInd[1]==null?"":this.keyHdParmInd[1]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyHdParmInd[2]==null?"":this.keyHdParmInd[2]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyHdParmInd[3]==null?"":this.keyHdParmInd[3]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyHdParmInd[4]==null?"":this.keyHdParmInd[4]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyDataLinkInd[0]==null?"":this.keyDataLinkInd[0]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyDataLinkInd[1]==null?"":this.keyDataLinkInd[1]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyDataLinkInd[2]==null?"":this.keyDataLinkInd[2]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyDataLinkInd[3]==null?"":this.keyDataLinkInd[3]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyDataLinkInd[4]==null?"":this.keyDataLinkInd[4]));
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.keyDataLinkNum[0]);
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.keyDataLinkNum[1]);
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.keyDataLinkNum[2]);
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.keyDataLinkNum[3]);
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.keyDataLinkNum[4]);
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyParmInd[0]==null?"":this.keyParmInd[0]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyParmInd[1]==null?"":this.keyParmInd[1]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyParmInd[2]==null?"":this.keyParmInd[2]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyParmInd[3]==null?"":this.keyParmInd[3]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyParmInd[4]==null?"":this.keyParmInd[4]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyDescInd[0]==null?"":this.keyDescInd[0]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyDescInd[1]==null?"":this.keyDescInd[1]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyDescInd[2]==null?"":this.keyDescInd[2]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyDescInd[3]==null?"":this.keyDescInd[3]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyDescInd[4]==null?"":this.keyDescInd[4]));
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.keyMouseOverNum[0]);
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.keyMouseOverNum[1]);
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.keyMouseOverNum[2]);
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.keyMouseOverNum[3]);
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.keyMouseOverNum[4]);
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.alertDataName==null?"":this.alertDataName));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.alertHdName==null?"":this.alertHdName));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.alertHdLinkInd==null?"":this.alertHdLinkInd));
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.alertHdLinkNum);
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.alertHdParmInd==null?"":this.alertHdParmInd));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.alertDataLinkInd==null?"":this.alertDataLinkInd));
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.alertDataLinkNum);
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.alertParmInd==null?"":this.alertParmInd));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.alertDescInd==null?"":this.alertDescInd));
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.alertMouseOverNum);
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.key1Seq);
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.totInd==null?"":this.totInd));
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.calccnt);
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.seqcnt);
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.tblProcDateDdlName==null?"":this.tblProcDateDdlName));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyLinkDdlName[0]==null?"":this.keyLinkDdlName[0]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyLinkDdlName[1]==null?"":this.keyLinkDdlName[1]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyLinkDdlName[2]==null?"":this.keyLinkDdlName[2]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyLinkDdlName[3]==null?"":this.keyLinkDdlName[3]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyLinkDdlName[4]==null?"":this.keyLinkDdlName[4]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyLinkToPgm[0]==null?"":this.keyLinkToPgm[0]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyLinkToPgm[1]==null?"":this.keyLinkToPgm[1]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyLinkToPgm[2]==null?"":this.keyLinkToPgm[2]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyLinkToPgm[3]==null?"":this.keyLinkToPgm[3]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyLinkToPgm[4]==null?"":this.keyLinkToPgm[4]));
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.keyLinkPresnId[0]);
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.keyLinkPresnId[1]);
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.keyLinkPresnId[2]);
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.keyLinkPresnId[3]);
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.keyLinkPresnId[4]);
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyLinkTblKeyName[0]==null?"":this.keyLinkTblKeyName[0]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyLinkTblKeyName[1]==null?"":this.keyLinkTblKeyName[1]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyLinkTblKeyName[2]==null?"":this.keyLinkTblKeyName[2]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyLinkTblKeyName[3]==null?"":this.keyLinkTblKeyName[3]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyLinkTblKeyName[4]==null?"":this.keyLinkTblKeyName[4]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyLinkTblKeyData[0]==null?"":this.keyLinkTblKeyData[0]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyLinkTblKeyData[1]==null?"":this.keyLinkTblKeyData[1]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyLinkTblKeyData[2]==null?"":this.keyLinkTblKeyData[2]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyLinkTblKeyData[3]==null?"":this.keyLinkTblKeyData[3]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyLinkTblKeyData[4]==null?"":this.keyLinkTblKeyData[4]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyLinkTblName[0]==null?"":this.keyLinkTblName[0]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyLinkTblName[1]==null?"":this.keyLinkTblName[1]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyLinkTblName[2]==null?"":this.keyLinkTblName[2]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyLinkTblName[3]==null?"":this.keyLinkTblName[3]));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.keyLinkTblName[4]==null?"":this.keyLinkTblName[4]));
		tmpStrBuf.append(",");
		tmpStrBuf.append(this.presnSeqNum);
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.sumyPresnName==null?"":this.sumyPresnName));
		tmpStrBuf.append(",");
		tmpStrBuf.append((this.cntSumyPresnName==null?"":this.cntSumyPresnName));
		
		return tmpStrBuf.toString();
	}
	
}
