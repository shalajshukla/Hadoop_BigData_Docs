/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import org.apache.log4j.Logger;

/**
 * This is an utility class for holding the common methods to be used
 * to clean the database resources.
 * 
 * @author Vijay Dubey - VD3159
 */
public class SQLHelper {
	/**
	 * Method to close the Connection object and logs error if any in closing the connection.
	 * 
	 * @param connection Connection object to be closed.
	 * @param failureList List object to hold the list of RABC exceptions.
	 * @param logger Logger object to log the error in log file.
	 */
	public static void closeConnection(Connection connection, List failureList, Logger logger) {
		if (connection != null) {
			try {
				connection.close();
			} catch(SQLException sx) {
				logger.error("Error in closing the connection. Exception details: " + sx.getMessage(), sx);
				failureList.add(new RABCException(RABCMessages.getMessage("Error in closing the connection"), sx));
			}
		}
	}
	
	/**
	 * Method to close the Statemrnt object and logs error if any in closing the statement.
	 * 
	 * @param stmt Statement object to be closed.
	 * @param failureList List object to hold the list of RABC exceptions.
	 * @param logger Logger object to log the error in log file.
	 */
	public static void closeStatement(Statement stmt, List failureList, Logger logger) {
		if (stmt != null) {
			try {
				stmt.close();
			} catch(SQLException sx) {
				logger.error("Error in closing the statement. Exception details: " + sx.getMessage(), sx);
				failureList.add(new RABCException(RABCMessages.getMessage("Error in closing the statement"), sx));
			}
		}
	}
	
	/**
	 * Method to close the ResultSet object and logs error if any in closing the result set.
	 * 
	 * @param rs ResultSet object to be closed.
	 * @param failureList List object to hold the list of RABC exceptions.
	 * @param logger Logger object to log the error in log file.
	 */
	public static void closeResultSet(ResultSet rs, List failureList, Logger logger) {
		if (rs != null) {
			try {
				rs.close();	
			} catch(SQLException sx) {
				logger.error("Error in closing the result set. Exception details: " + sx.getMessage(), sx);
				failureList.add(new RABCException(RABCMessages.getMessage("Error in closing the result set"), sx));
			}
		}
	}
}
