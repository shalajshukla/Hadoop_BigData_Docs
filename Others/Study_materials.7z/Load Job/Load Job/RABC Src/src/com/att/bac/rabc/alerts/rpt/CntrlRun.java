/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.rpt;
import java.util.Date;

/**
 * This is a Data Object to represent RABC_CNTRL_RUN table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class CntrlRun {
	private Date procDate;
	private int fileSeqNum;
	private String alertRule;
	private String key1;
	private String key2;
	private String severeLvlInd;
	private Date alertRuleRunDt;
	private int numFiles;

	/**
	 * @return Returns the ProcDate.
	 */
	public Date getProcDate() {
		return procDate;
	}
	/**
	 * @return Returns the FileSeqNum.
	 */
	public int getFileSeqNum() {
		return fileSeqNum;
	}
	/**
	 * @return Returns the AlertRule.
	 */
	public String getAlertRule() {
		return alertRule;
	}
	/**
	 * @return Returns the Key1.
	 */
	public String getKey1() {
		return key1;
	}
	/**
	 * @return Returns the Key2.
	 */
	public String getKey2() {
		return key2;
	}
	/**
	 * @return Returns the SevereLvlInd.
	 */
	public String getSevereLvlInd() {
		return severeLvlInd;
	}
	/**
	 * @return Returns the AlertRuleRunDt.
	 */
	public Date getAlertRuleRunDt() {
		return alertRuleRunDt;
	}
	/**
	 * @return Returns the NumFiles.
	 */
	public int getNumFiles() {
		return numFiles;
	}

	/**
	 * @param ProcDate The procDate to set.
	 */
	public void setProcDate(Date procDate) {
		this.procDate = procDate;
	}
	/**
	 * @param FileSeqNum The fileSeqNum to set.
	 */
	public void setFileSeqNum(int fileSeqNum) {
		this.fileSeqNum = fileSeqNum;
	}
	/**
	 * @param AlertRule The alertRule to set.
	 */
	public void setAlertRule(String alertRule) {
		this.alertRule = alertRule;
	}
	/**
	 * @param Key1 The key1 to set.
	 */
	public void setKey1(String key1) {
		this.key1 = key1;
	}
	/**
	 * @param Key2 The key2 to set.
	 */
	public void setKey2(String key2) {
		this.key2 = key2;
	}
	/**
	 * @param SevereLvlInd The severeLvlInd to set.
	 */
	public void setSevereLvlInd(String severeLvlInd) {
		this.severeLvlInd = severeLvlInd;
	}
	/**
	 * @param AlertRuleRunDt The alertRuleRunDt to set.
	 */
	public void setAlertRuleRunDt(Date alertRuleRunDt) {
		this.alertRuleRunDt = alertRuleRunDt;
	}
	/**
	 * @param NumFiles The numFiles to set.
	 */
	public void setNumFiles(int numFiles) {
		this.numFiles = numFiles;
	}
}
