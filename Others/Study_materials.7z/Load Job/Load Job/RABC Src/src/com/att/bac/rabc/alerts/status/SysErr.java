/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.status;

/**
 * This is a Data Object to represent RABC_SYS_ERR_CD table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class SysErr {
	private int sysErrCd;
	private String sysErrCdDesc;

	/**
	 * @return Returns the SysErrCd.
	 */
	public int getSysErrCd() {
		return sysErrCd;
	}
	/**
	 * @return Returns the SysErrCdDesc.
	 */
	public String getSysErrCdDesc() {
		return sysErrCdDesc;
	}

	/**
	 * @param SysErrCd The sysErrCd to set.
	 */
	public void setSysErrCd(int sysErrCd) {
		this.sysErrCd = sysErrCd;
	}
	/**
	 * @param SysErrCdDesc The sysErrCdDesc to set.
	 */
	public void setSysErrCdDesc(String sysErrCdDesc) {
		this.sysErrCdDesc = sysErrCdDesc;
	}
}
