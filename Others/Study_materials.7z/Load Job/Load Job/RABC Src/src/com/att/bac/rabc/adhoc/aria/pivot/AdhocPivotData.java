/*
 * Copyright  2002-2007 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.adhoc.aria.pivot;

import java.text.ParseException;

import com.sbc.bac.rabc.load.HashCodeUtil;

public class AdhocPivotData implements Comparable {
	private int noOfKeyColumns;
	private int noOfDataColumns;
	private String [] keyColumnNames;
	private String [] keyColumnValues;
	private int [] keyColumnIndexes;
	private String [] dataColumnHeaderNames;
	private String [] billRndArr;
	private String [] dataColumnNames;
	private int [] dataColumnIndexes;
	private double [][] dataColumnValues;
	private int sortKeyIndex = 0;
	private int sortOrder = 1;
	
	/**
	 * Constructor to create the pivot data
	 * @param noOfKeyColumns
	 * @param noOfDataColumns
	 */
	public AdhocPivotData(int noOfKeyColumns, int noOfDataColumns){
		this.noOfKeyColumns = noOfKeyColumns;
		this.noOfDataColumns = noOfDataColumns;
	}
	
	/**
	 * @return the dataColumnHeaderNames
	 */
	public String[] getDataColumnHeaderNames() {
		return dataColumnHeaderNames;
	}
	/**
	 * @param dataColumnHeaderNames the dataColumnHeaderNames to set
	 */
	public void setDataColumnHeaderNames(String[] dataColumnHeaderNames) {
		this.dataColumnHeaderNames = dataColumnHeaderNames;
	}
	/**
	 * @return the dataColumnIndexes
	 */
	public int[] getDataColumnIndexes() {
		return dataColumnIndexes;
	}
	/**
	 * @param dataColumnIndexes the dataColumnIndexes to set
	 */
	public void setDataColumnIndexes(int[] dataColumnIndexes) {
		this.dataColumnIndexes = dataColumnIndexes;
	}
	/**
	 * @return the dataColumnNames
	 */
	public String[] getDataColumnNames() {
		return dataColumnNames;
	}
	/**
	 * @param dataColumnNames the dataColumnNames to set
	 */
	public void setDataColumnNames(String[] dataColumnNames) {
		this.dataColumnNames = dataColumnNames;
	}
	/**
	 * @return the dataColumnValues
	 */
	public double[][] getDataColumnValues() {
		return dataColumnValues;
	}
	/**
	 * @param dataColumnValues the dataColumnValues to set
	 */
	public void setDataColumnValues(double[][] dataColumnValues) {
		this.dataColumnValues = dataColumnValues;
	}
	/**
	 * @return the keyColumnIndexes
	 */
	public int[] getKeyColumnIndexes() {
		return keyColumnIndexes;
	}
	/**
	 * @param keyColumnIndexes the keyColumnIndexes to set
	 */
	public void setKeyColumnIndexes(int[] keyColumnIndexes) {
		this.keyColumnIndexes = keyColumnIndexes;
	}
	/**
	 * @return the keyColumnNames
	 */
	public String[] getKeyColumnNames() {
		return keyColumnNames;
	}
	/**
	 * @param keyColumnNames the keyColumnNames to set
	 */
	public void setKeyColumnNames(String[] keyColumnNames) {
		this.keyColumnNames = keyColumnNames;
	}
	/**
	 * @return the keyColumnValues
	 */
	public String[] getKeyColumnValues() {
		return keyColumnValues;
	}
	/**
	 * @param keyColumnValues the keyColumnValues to set
	 */
	public void setKeyColumnValues(String[] keyColumnValues) {
		this.keyColumnValues = keyColumnValues;
	}
	/**
	 * @return the noOfDataColumns
	 */
	public int getNoOfDataColumns() {
		return noOfDataColumns;
	}
	/**
	 * @param noOfDataColumns the noOfDataColumns to set
	 */
	public void setNoOfDataColumns(int noOfDataColumns) {
		this.noOfDataColumns = noOfDataColumns;
	}
	/**
	 * @return the noOfKeyColumns
	 */
	public int getNoOfKeyColumns() {
		return noOfKeyColumns;
	}
	/**
	 * @param noOfKeyColumns the noOfKeyColumns to set
	 */
	public void setNoOfKeyColumns(int noOfKeyColumns) {
		this.noOfKeyColumns = noOfKeyColumns;
	}

	/**
	 * @return the sortKeyIndex
	 */
	public int getSortKeyIndex() {
		return sortKeyIndex;
	}

	/**
	 * @param sortKeyIndex the sortKeyIndex to set
	 */
	public void setSortKeyIndex(int sortKeyIndex) {
		this.sortKeyIndex = sortKeyIndex;
	}

	/**
	 * @return the sortOrder
	 */
	public int getSortOrder() {
		return sortOrder;
	}

	/**
	 * @param sortOrder the sortOrder to set
	 */
	public void setSortOrder(int sortOrder) {
		this.sortOrder = sortOrder;
	}

	/**
	 * @return the billRndArr
	 */
	public String[] getBillRndArr() {
		return billRndArr;
	}

	/**
	 * @param billRndArr the billRndArr to set
	 */
	public void setBillRndArr(String[] billRndArr) {
		this.billRndArr = billRndArr;
	}

	/**
	 * Equals method overridden for this object so that it can be stored in a hash map where the key 
	 * would be combination of all the key column values. These include actual keys for adhoc report + the non calculable columns
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object o) {
		// Do a quick check for an identical object reference
	    if (this == o) {
	      return true;
	    }
	    if (!(o instanceof AdhocPivotData)) {
	    	return false;
	    } else {
	    	if (this.getKeyColumnValues()== null){
	    		return false;
	    	} else if (((AdhocPivotData)o).getKeyColumnValues()==null) {
	    		return false;
	    	} else if (this.getKeyColumnValues().length != ((AdhocPivotData)o).getKeyColumnValues().length){
	    		return false;
	    	} else {
	    		boolean isEqual = true;
	    		String [] keyValues = ((AdhocPivotData)o).getKeyColumnValues();
	    		for (int i=0;i<this.getKeyColumnValues().length;i++){
	    			if (keyValues[i]==null && !this.getKeyColumnValues()[i].equals(keyValues[i])){
	    				isEqual = false;
	    				break;
	    			}else if (!keyValues[i].equals(this.getKeyColumnValues()[i])){
	    				isEqual = false;
	    				break;
	    			}
	    		}
	    		return isEqual;
	    	}
	    }
	}
	
	/**
	 * Hash code method overridden for this object to categorize this object in sets 
	 * so that the hash collections can search this object efficiently.
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		int hashCode = HashCodeUtil.SEED;
		for (int i=0;i<keyColumnValues.length;i++){
			hashCode = HashCodeUtil.hash( hashCode, keyColumnValues[i]);
		}
	    return hashCode;
	}

	/**
	 * Method added to keep the objects in sorted manner
	 */
	public int compareTo(Object o) {
		if (o instanceof AdhocPivotData){
			AdhocPivotData adhocPivotData = (AdhocPivotData)o;
			
			// Get the index of the sorted column
			int sortIndex = 0;
			for (int i=0;i<adhocPivotData.getKeyColumnIndexes().length;i++) {
				if (adhocPivotData.getKeyColumnIndexes()[i]==adhocPivotData.getSortKeyIndex()){
					sortIndex = i;
					break;
				}
			}
			
			if (this.getSortKeyIndex()!= adhocPivotData.getSortKeyIndex()){
				return 0;
			} else if (checkIfNumber(this.getKeyColumnValues()[sortIndex],adhocPivotData.getKeyColumnValues()[sortIndex])) {
				long value1 = Long.parseLong(this.getKeyColumnValues()[sortIndex]);
				long value2 = Long.parseLong(adhocPivotData.getKeyColumnValues()[sortIndex]);
				if (value1 < value2){
					if (this.getSortOrder()==1){
						return -1;
					} else {
						return 1;
					}
				} else if (value1 > value2) {
					if (this.getSortOrder()==1){
						return 1;
					} else {
						return -1;
					}
				} else if (this.hashCode()==adhocPivotData.hashCode()){
					return 0;
				} else if (this.hashCode()> adhocPivotData.hashCode()){
					return 1;
				} else {
					return -1;
				}
			} else if (this.getKeyColumnValues()[sortIndex].compareTo(adhocPivotData.getKeyColumnValues()[sortIndex])<0){
				if (this.getSortOrder()==1){
					return -1;
				} else {
					return 1;
				}
			} else if (this.getKeyColumnValues()[sortIndex].compareTo(adhocPivotData.getKeyColumnValues()[sortIndex])>0){
				if (this.getSortOrder()==1){
					return 1;
				} else {
					return -1;
				}
			} else if (this.hashCode()==adhocPivotData.hashCode()){
				return 0;
			} else if (this.hashCode()> adhocPivotData.hashCode()){
				return 1;
			} else {
				return -1;
			}
		} else {
			return 0;
		}
	}
	
	/**
	 * Private method will check whether 
	 * @param value1
	 * @param value2
	 * @return
	 */
	private boolean checkIfNumber(String value1, String value2){
		boolean result = false;
		double number = Double.NEGATIVE_INFINITY;
		try {
			number = Double.parseDouble(value1.trim());
			number = Double.parseDouble(value2.trim());
			result = true;
		}catch (NumberFormatException ne){
			result = false;
		}
		
		if (number == Double.NEGATIVE_INFINITY) {
			result = false;
		}

		return result;
	}
}
