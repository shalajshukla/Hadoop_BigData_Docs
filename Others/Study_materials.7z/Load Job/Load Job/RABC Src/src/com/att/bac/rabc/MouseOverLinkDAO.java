/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

/**
 * This is a DAO that performs SELECT, INSERT and UPDATE on RABC_MOUSE_OVER_LINK table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class MouseOverLinkDAO {
	private static final Logger logger = Logger.getLogger(MouseOverLinkDAO.class);

	/**
	 * Returns the list of MouseOverLink objects.
	 * 
	 * @param conn 
	 * @param failures
	 * @param args
	 * @param baseSQL
	 * @return List
	 */
	public List get(Connection conn, List failures, List args, String baseSQL) {
		List mouseOverLinkList = null;
		MouseOverLink mouseOverLink = null;
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		
		try
		{
			logger.debug("Processing SELECT from RABC_MOUSE_OVER_LINK table....");
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("MouseOverLinkDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			logger.debug("SQL - Execution complete.");
			mouseOverLinkList = new ArrayList();
			while (rs.next()) {
				mouseOverLinkList.add(buildMouseOverLink(rs));
			}
			
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return null;
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
		
		return mouseOverLinkList;
	}

	/**
	 * Private method to build MouseOverLink object and return it to caller.
	 * 
	 * @param rs
	 * @return MouseOverLink
	 * @throws SQLException
	 */
	private MouseOverLink buildMouseOverLink(ResultSet rs) throws SQLException {
		MouseOverLink mouseOverLink = new MouseOverLink();
		
		mouseOverLink.setPresnId(rs.getInt("PRESN_ID"));
		mouseOverLink.setWebid(rs.getString("WEBID"));
		mouseOverLink.setExecPresnSeqNum(rs.getInt("EXEC_PRESN_SEQ_NUM"));
		mouseOverLink.setMouseOverNum(rs.getInt("MOUSE_OVER_NUM"));
		mouseOverLink.setLinkTblKeyName(rs.getString("LINK_TBL_KEY_NAME"));
		mouseOverLink.setLinkTblKeyData(rs.getString("LINK_TBL_KEY_DATA"));
		mouseOverLink.setLinkTblName(rs.getString("LINK_TBL_NAME"));
		return mouseOverLink;
	}

	/**
	 * Execute the insert or update statement on RABC_MOUSE_OVER_LINK table.
	 * 
	 * @param conn
	 * @param failures
	 * @param args
	 * @param baseSQL
	 */
	public void executeUpdate(Connection conn, List failures, List args, String baseSQL) {
		int rowsUpdated = 0;
		Statement stmt = null;
		String sqlStmt = null;
		
		try
		{
			logger.debug("Processing executeUpdate on RABC_MOUSE_OVER_LINK table....");
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("MouseOverLinkDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rowsUpdated = stmt.executeUpdate(sqlStmt);
			logger.debug("SQL - Execution complete."+ String.valueOf(rowsUpdated) + "  rows updated");
			
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return;
		} finally {
			SQLHelper.closeStatement(stmt, failures, logger);
		}
	}

}
