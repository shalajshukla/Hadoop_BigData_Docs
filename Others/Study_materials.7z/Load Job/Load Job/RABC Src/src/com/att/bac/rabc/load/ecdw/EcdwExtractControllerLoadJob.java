/*------------------------------------------------------------------------------
Modification History
� 2002-2011 AT&T Intellectual Property. All rights reserved.
Date		Version		Author			Description
----------	-----------	--------------- ----------------------------------------
12-02-2010	0.1			ss1644			initial Draft
------------------------------------------------------------------------------*/
package com.att.bac.rabc.load.ecdw;
//------------------------------------------------------------------------------
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Properties;

import org.apache.log4j.Logger;
//changes for M168 by as635b
import com.att.carat.load.Application;
import com.att.carat.load.DBLoadJob;
//import com.sbc.bac.load.Application;
//import com.sbc.bac.load.DBLoadJob;
//------------------------------------------------------------------------------
/**
 * This class implement the functionality of schedule load job, the configure
 * method read the properties file and store the value of keys in variables
 * and the action method implements the actual business logic, which is being
 * called at specified time in property file
 */
public class EcdwExtractControllerLoadJob extends DBLoadJob {
	//--------------------------------------------------------------------------
	/**
	 * variable to store the current time when this class in instantiate
	 */
	private Calendar 
		runtime 			= 	Calendar.getInstance ();
	/**
	 * variable to store the logger to log the events.
	 */
	private static Logger 
		logger 				= 	Logger.getLogger (EcdwExtractControllerLoadJob.class);
	/**
	 * variable to store the interval of job like Daily,Weekly,Monthly etc.
	 */
	private String interval;
	/**
	 * variable to store the date format for this load job
	 */
	private SimpleDateFormat dateFormat 	= new SimpleDateFormat("HH:mm");
	/**
	 * If this variable is true the job will run without checking run date.  
	 * This can only be used in development testing.  It must be false when 
	 * the job is actually used or it will run continuously.
	 */
	private boolean skipCheck 			= false;
	/**
	 * variable to store the instance of EcdwExtractControllerDAO class.
	 */
	private EcdwExtractControllerDAO extrctCntrlDailyDao;
	//--------------------------------------------------------------------------
	/**
	 * Reads ecdwExtractDaily.cfg configuration file and sets appropriate private 
	 * control variables.
	 * 
	 * @param	p_application 	The Application object
	 * @param	p_configuration	configuration file properties
	 * @return <code>true</code> if execution was successful <code> false 
	 * otherwise
	 */
	protected boolean configure (Application p_application, Properties 	p_configuration) {
		String 		l_time			= null;
		String 		l_day_of_month	= null;
		boolean 	l_result 		= false;

		l_result	= super.configure(p_application, p_configuration);
		extrctCntrlDailyDao = new EcdwExtractControllerDAO (p_configuration);
		Calendar now = Calendar.getInstance();
				
		if (l_result) {
			try {
				l_time = p_configuration.getProperty("runTime");
				l_day_of_month = p_configuration.getProperty("dayOfMonth");
				if (l_time == null) {
					severe("Time or day of month cannot be null");
					return false;
				}
				
				
				interval = p_configuration.getProperty ("interval") == null 
							? 	null
							:	p_configuration.getProperty("interval").trim ();
				if(interval==null || (!"daily".equalsIgnoreCase(interval)
						&&!"weekly".equalsIgnoreCase(interval)
						&&!"monthly".equalsIgnoreCase(interval))
				) {
					logger.error ("Interval value not valid. Choices: daily, weekly, monthly");
					return false;
				}
				runtime.setTime(dateFormat.parse (l_time));
				runtime.set(Calendar.YEAR, now.get(Calendar.YEAR));
				runtime.set(Calendar.MONTH, now.get(Calendar.MONTH));
				
				if ("daily".equalsIgnoreCase (interval)){
					runtime.set (
						Calendar.DAY_OF_MONTH
					, 	now.get(Calendar.DAY_OF_MONTH)
					);
				} else if ("weekly".equalsIgnoreCase(interval)) {
					int dayOfWeek = Integer.parseInt (
										p_configuration.getProperty("dayOfWeek")
									);
					if (dayOfWeek < 1 || dayOfWeek > 7) {
						severe("Day of week must be between 1 and 7");
						return false;
					}
					runtime.set (
						Calendar.DAY_OF_MONTH
					, 	now.get(Calendar.DAY_OF_MONTH)
					);
					while (runtime.get (Calendar.DAY_OF_WEEK)!= dayOfWeek) {
						runtime.add(Calendar.DATE, 1);
					}
				} else {
					runtime.set (
						Calendar.DAY_OF_MONTH
					, 	Integer.parseInt(l_day_of_month)
					);
				}
				if(now.after(runtime))  {
					if(interval.toUpperCase().equals("DAILY")) {
						runtime.add(Calendar.DATE, 1);
					} else if (interval.toUpperCase().equals("WEEKLY")) {
						runtime.add(Calendar.DATE, 7);
					} else if (interval.toUpperCase().equals("MONTHLY")) {
						runtime.add(Calendar.MONTH, 1);
					}	
				}
			}catch (ParseException pe) {
				severe (
					"Unable to parse time entry from configuration file"
				, 	pe
				);
				return false;
			}
		}
		
		info("Job is scheduled to run again "+runtime.getTime());
		skipCheck = asBoolean (	
						p_configuration.getProperty (
							"skip_check"
						, 	"false"
						)
					);
		return l_result;
	}
	//--------------------------------------------------------------------------
	/**
     * Utility method, transform Y/N to boolean
     * 
     * @param p_value	value to be transformed
     * @return true or false
     */
    private static boolean asBoolean (
    	String p_value
    ) {
        return (p_value.equalsIgnoreCase("true")) ? true : false;
    }
    //--------------------------------------------------------------------------
	/**
	 * This method checks to see if the current time 
	 * is after the currently scheduled runtime.
	 * 
	 * @return now.after(runtime)  
	 * the boolean that tells the load process if it is time to process 
	 * data or not.
	 */
	protected boolean check() {
		
        if (skipCheck) {
            return true;
        }
        
		Calendar l_now = Calendar.getInstance();
		return l_now.after(runtime);
	}
	//--------------------------------------------------------------------------
	/**
	 * extract the data for different MID and create a Text files, called at 
	 * specified time in ecdwExtractDaily.cfg file
	 * 
	 * @return boolean Flag if execution was successful
	 */

	protected boolean action () {
		boolean l_success 	= false;
		try {
			l_success = 	extrctCntrlDailyDao.extractMD20610Data (
								connection
							);
			} catch (Exception e) {
				severe("Error Inserting records in File For MD 20610 " + e.getMessage(), e);
				l_success = false;
			}
			try {
			l_success = 	extrctCntrlDailyDao.extractMD20615Data (
								connection
							);
			} catch (Exception e) {
				severe("Error Inserting records in File For MD 20615" + e.getMessage(), e);
				l_success = false;
			}
			try {
			l_success = 	extrctCntrlDailyDao.extractMD20620Data (
								connection
							);
			} catch (Exception e) {
				severe("Error Inserting records in File For MD 20620" + e.getMessage(), e);
				l_success = false;
			}
			try {
			l_success = 	extrctCntrlDailyDao.extractMD20625Data (
								connection
							);
			} catch (Exception e) {
				severe("Error Inserting records in File For MD 20625" + e.getMessage(), e);
				l_success = false;
			}
		
		return l_success;
	}
	//--------------------------------------------------------------------------
	/**
	 * This method being called once the action is complete, and this method
	 * set the run time to run the job again.
	 * @param p_success  the value returned by the action method
	 * @return  return the success or failure
	 */
	protected boolean postprocess (
		boolean p_success
	) {
		boolean 	l_success	= false;
		l_success = super.postprocess(p_success);
		if (l_success) {
			if("daily".equalsIgnoreCase (interval)) {
				runtime.add(Calendar.DATE, 1);
			} else if ("weekly".equalsIgnoreCase(interval)) {
				runtime.add(Calendar.DATE, 7);
			} else if ("monthly".equalsIgnoreCase(interval)) {
				runtime.add(Calendar.MONTH, 1);
			}
		    info("Job is scheduled to run again "+ runtime.getTime());
		}
		return l_success;
	}
	//--------------------------------------------------------------------------
}
//------------------------------------------------------------------------------
//
//	End of file
//
//------------------------------------------------------------------------------
