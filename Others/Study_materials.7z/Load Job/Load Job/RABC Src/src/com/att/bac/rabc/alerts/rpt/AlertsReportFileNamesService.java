/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.rpt;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.att.bac.rabc.ExcelReport;
import com.att.bac.rabc.MyDate;
import com.att.bac.rabc.ProgressBar;
import com.att.bac.rabc.RABCConstantsLists;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;

/**
 * This class represents the Service which handles processing of 
 * various requests for AlertsReportFileNamesService for page 15.
 * 
 * @author Nalina Pandiyan - NP5434
 */
public class AlertsReportFileNamesService {
	private static final Logger logger = Logger.getLogger(AlertsReportFileNamesService.class);
	private static final String MMDDYYYY_FORMAT = "MM/dd/yyyy";
	public static final String DEFAULT_LABEL_RESOURCES = "com.att.bac.rabc.LabelResources";
	private static ResourceBundle labelProperties;
	
	public static String qryFileNames= "select FILE_NAME FileName, TIME_STAMP ODRLoadDate, FILE_ID FileId, DIVISION DivisionName " +
			"from RABC_TRIG where 1=1 {0} and FILE_SEQ_NUM = to_number(''{1}'') and upper(FILE_NAME) != ''BACINSERT'' {2} order by TIME_STAMP";
	
	private final static String getDefaultLineCount = "SELECT LINE_CT FROM RABC_USER_DEFAULT_RPT_LINE WHERE USER_ID = ''{0}''";
	
	/**
	 * This method is used to configure the label resources properties file.
	 * 
	 */
	public AlertsReportFileNamesService() {
		try {
			labelProperties = ResourceBundle.getBundle(DEFAULT_LABEL_RESOURCES);
		} catch (MissingResourceException e) {
			logger.error("Unable to configure properties file. Exception details: " + e.getMessage(), e);
		}
	}

	/**
	 * This is a method to get the label for the passed key.
	 * 
	 * @param key
	 * @return String
	 */
	public static String getLabel(String key) {
		try {
			return labelProperties.getString(key);
		} catch (MissingResourceException e) {
			logger.error("Unable to configure properties file. Exception details: " + e.getMessage(), e);
			return null;
		}
	}
	
	/**
	 * This method is used to return the list for process view request.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param headers
	 * @return List
	 */
	public List processViewRequest(Connection connection, List failureList,List args, List headers) {
		List fileNamesList = executeFileNamesListQry(connection,failureList,args);
		headers.add(getLabel("alertReport.label.fileNameList"));
		headers.add(getLabel("alertReport.label.seqNumber") + ":" +args.get(1) + "            " + getLabel("alertReport.label.divisionNameHeader") + ":"+ args.get(3));
		return fileNamesList;
	}
	
	/**
	 * This is a method to handel the request for generating
	 * the excel report of AlertsReportFileNamesService. 
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param report
	 * @param progressBar
	 * @return List
	 */
	public List processCreateReportRequest(Connection connection, List failureList,List args, ExcelReport report, ProgressBar progressBar) {
		List fileNamesList = executeFileNamesListQry(connection,failureList,args);
		progressBar.setProgressPercent(50);
		prepareExcelReport(failureList, fileNamesList, args, report);
		progressBar.setProgressPercent(80);
		return fileNamesList;
	}

	/**
	 * This method executes qryFileNames query and returns a list.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return List
	 */
	public List executeFileNamesListQry(Connection connection, List failureList,List args){
		List fileNamesList = new ArrayList();
		Statement stmt = null;
		ResultSet rs = null;
		String qryFileNamesStmt = prepareFileNamesQuery(args,failureList);
		try {
			logger.debug("Executing qryFileNames query .... "+qryFileNamesStmt);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qryFileNamesStmt);
			if (rs != null) {
				while (rs.next()) {
					FileNames fileNames = buildFileNamesList(rs);
					fileNamesList.add(fileNames);
				}
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryFileNamesStmt}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryFileNamesStmt}), sx));
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		
		return fileNamesList;

	}
	
	/**
	 * This method prepares FileNamesQuery for the passed arguments.
	 * 
	 * @param arguments
	 * @param failureList
	 * @return String
	 */
	private String prepareFileNamesQuery(List arguments, List failureList){
		String args_0 = "";
		String args_1 = "";
		String args_2 = "";
		String qryStmt = "";
		//checking file DIV
		try{
			
			if(arguments.get(3)==null){
				args_0 = " and DIVISION IS NULL" ; 
			}else{
				args_0 = " and DIVISION = '" + arguments.get(3).toString()+"'";
			}
			
			args_1 = arguments.get(1).toString();
			
			if((arguments.get(2)!=null) && !(arguments.get(2).toString().equals(""))){
				MyDate procDate= new MyDate(arguments.get(2).toString(), MMDDYYYY_FORMAT);
				procDate.doAdd(-90);
				args_2 = " and TIME_STAMP >= to_date('" + procDate+"','mm/dd/yyyy')";
				procDate.doAdd(90);
				args_2 += "  and TIME_STAMP <= to_date('" + procDate+"','mm/dd/yyyy')";
			}
			
			MessageFormat mf = new MessageFormat(qryFileNames);
			qryStmt = mf.format(new String[]{args_0, args_1, args_2});
			
			logger.debug("qryFileNamesStmt......" + qryStmt);
			
		}catch(ParseException ex){
			logger.error(RABCMessages.getMessage("prepareFileNamesQuery", new String[] {qryStmt}) + " Exception details: " + ex.getMessage(), ex);
			failureList.add(new RABCException(RABCMessages.getMessage("prepareFileNamesQuery", new String[] {qryStmt}), ex));
			return null;
		}
		return qryStmt;
	}
	
	/**
	 * This method is used to build FileNamesList.
	 * 
	 * @param rs
	 * @return FileNames
	 * @throws SQLException
	 */
	private FileNames buildFileNamesList(ResultSet rs) throws SQLException{
		FileNames fileNames = new FileNames();
		
		fileNames.setFileName(rs.getString("FileName"));
		fileNames.setFileCreationDate(rs.getDate("ODRLoadDate"));
		fileNames.setFileId(rs.getString("FileId"));
		fileNames.setDivisionName(rs.getString("DivisionName"));
		return fileNames;
	}

	/**
	 * This method is used to prepare excel report.
	 * 
	 * @param failureList
	 * @param fileNamesList
	 * @param args
	 * @param report
	 */
	private void prepareExcelReport(List failureList, List fileNamesList, List args, ExcelReport report) {
		try {
			report.addRaw("<html xmlns:x=urn:schemas-microsoft-com:office:excel>");
			report.addRaw("<head>");
			report.addRaw("<title>RABC Plus Control Alert Details Report</title>");
			report.addRaw("<style>.xl33{ mso-number-format:'\\##\\,\\##\\##0\\.00';}");
			report.addRaw(" @page{margin:.5in .25in .5in .25in;mso-header-margin:.5in;mso-footer-margin:.5in;mso-page-orientation:landscape;} table{color:black;font-family:Arial} </style>");
			report.addRaw("</head>");
			report.addRaw("<body>");
			report.addRaw("<font face=Arial>");
			report.addRaw("<font size=+2 color=navy><b>File Names List<BR></font>");
			report.addRaw("<font size=+1 color=navy>Sequence Number:  " + ((Integer)args.get(1)).toString());
			report.addRaw(" Division Name: " + (String)args.get(3) + "<br>");
			report.addRaw("<table width=80% cellpadding=3 cellspacing=0 border=1>");
			report.addRaw("<tr align=center>");
			report.addRaw("<TD nowrap align=center valign=middle>" + getLabel("alertReport.label.fileType") + "</TD>");
			report.addRaw("<TD nowrap align=center valign=middle>" + getLabel("alertReport.label.divisionName") + "</TD>");
			report.addRaw("<TD nowrap align=center valign=middle>" + getLabel("alertReport.label.fileName") + "</TD>");
			report.addRaw("<TD nowrap align=center valign=middle>" + getLabel("alertReport.label.fileCreationDate") + "</TD>");
			report.addRaw("</TR>");
			report.flush();
			
			int size= fileNamesList.size();
			
			for(int i=0;i<size;i++){
				report.flush();
				FileNames fileNames = (FileNames) fileNamesList.get(i);
				if (i%2 == 0) {
					report.addRaw("<TR  nowrap bgcolor=\"#cee6fd\">");
				}else{
					report.addRaw("<TR  nowrap bgcolor=\"##ffffff\">");
				}
				report.addRaw("<TD nowrap align=center>"+(fileNames.getFileId()==null?"":fileNames.getFileId())+"</TD>");
				report.addRaw("<TD nowrap align=center>"+(fileNames.getDivisionName()==null?"":fileNames.getDivisionName())+"</TD>");
				report.addRaw("<TD nowrap align=center>"+(fileNames.getFileName()==null?"":fileNames.getFileName())+"</TD>");
				if (fileNames.getFileCreationDate() != null) {
					report.addRaw("<TD nowrap align=center>"+fileNames.getFileCreationDate().toString()+" " + fileNames.getFileCreationDate().getHHMMSS()+"</TD>");
				} else {
					report.addRaw("<TD nowrap align=center> </TD>");
				}
				report.addRaw("</TR>");
			}
			
			if (size ==0) {
				report.addRaw("<TR align=right bgcolor=cee6fd> <td align=center colspan=10><b>"+getLabel("alertReport.label.noneFound")+"</b></td></TR>");
			}
			report.addRaw("</TABLE>");
			report.addRaw("</font>");
			report.addRaw("</body>");
			report.addRaw("</html>");
			report.flush();
			
		} catch (IOException e) {
			logger.error(RABCMessages.getMessage("ERR_CREATE_ALERT_REPORT", null) + " Exception details: " + e.getMessage(), e);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CREATE_ALERT_REPORT", null) + " Exception details: " + e.getMessage(), e));		
		}
	}

	/**
	 * Method to return the default line count.
	 * 
	 * @param connection
	 * @param failureList
	 * @param userId
	 * @return int
	 */
	protected int getDefaultLineCount(Connection connection, List failureList, String userId) {
		int defaultLineCount = 0;
		String selectSQL = getDefaultLineCount;
		List args = new ArrayList();
		args.add(userId);
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		try{
			MessageFormat mf = new MessageFormat(selectSQL);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			if (rs != null && rs.next()) {
				defaultLineCount = rs.getInt(1);
			} else {
				defaultLineCount = RABCConstantsLists.getRABCConstantsLists().getPageSize();
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		
		return defaultLineCount;
	}
}
