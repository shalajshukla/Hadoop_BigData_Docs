/* Project: BAC_RABC_TOMCAT
 * File: ExcelReport.java
 * Package: com.att.bac.rabc
 * Created on Apr 5, 2005 by gj7832
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

/*
 * Modification History:                                     
 * SBCUID		Date			Description                         	    	
 * ------		--------		-----------
 * PD2951		20060224		Updated for RABC, EAP 556010  
 */

package com.att.bac.rabc;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.sql.Date;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.Format;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;

public class ExcelReport {
	public static final int MAX_ROWS = 65536;
    private final Format defaultDateFormat = new SimpleDateFormat("MM/dd/yyyy");
    private final Format defaultTimeFormat = new SimpleDateFormat("HH:mm:ss");
    private final Format defaultCurrencyFormat = NumberFormat.getCurrencyInstance();
    
    private BufferedWriter out = null;
    private int rows = 0;
    
    public ExcelReport(OutputStream out) {
        this.out = new BufferedWriter(new OutputStreamWriter(out));
    }
    
    public ExcelReport beginReport() throws IOException {
	    out.write("<html>\n");
	    out.write("<head>\n");
	    out.write("<style>\n");
	    out.write("\t.BACTable {}\n");
	    out.write("\t.BACTable TD {border: thin solid #000000; text-align: left;}\n");
	    out.write("\t.BACTable TH {border: thin solid #000000; text-align: center; background-color: lightgrey; font-weight: bold;}\n");
	    out.write("</style>\n");
	    out.write("</head>\n");
	    out.write("<body>\n");
	    
	    return this;
	}
    
    public ExcelReport beginTable() throws IOException {
        out.write("<table class=\"BACTable\">\n");
        return this;
    }
    
    public ExcelReport endTable() throws IOException {
        out.write("</table>\n");
        return this;
    }
    
	public ExcelReport endReport() throws IOException {
	    out.write("</body>");
	    out.write("</html>");
	    out.close();
	    return this;
	}

	public ExcelReport beginRow() throws IOException {
	    rows++;
	    if(rows>MAX_ROWS){
	        throw new IOException("Maximum number of Excel rows <"+MAX_ROWS+"> exceeded");
	    }
	    out.write("<tr>");
	    return this;
	}
        
	public ExcelReport endRow() throws IOException {
	    out.write("</tr>\n");
	    return this;
	}	
	 
	public ExcelReport addCriteriaRow(String label, int criteria) throws IOException {
	    beginRow().addLabel(label).addCriteria(criteria).endRow();
	    return this;
	}
	
	public ExcelReport addCriteriaRow(String label, String criteria) throws IOException {
	    beginRow().addLabel(label).addCriteria(criteria).endRow();
	    return this;
	}
	
	public ExcelReport addCriteriaRow(String label, Date criteria) throws IOException {
	    beginRow().addLabel(label).addCriteria(criteria).endRow();
	    return this;
	}
	
	public ExcelReport addColumn(String[] array, String delimiter) throws IOException {
	    StringBuffer buf = new StringBuffer();
	    if(array!=null){
	        for(int i=0; i<array.length; i++){
	            buf.append(array[i]);
	            if(i<array.length-1) buf.append(delimiter);
	    	}
	    }
	    addColumn(buf.toString());
	    return this;
	}
	
	public ExcelReport addRptHeaderLine1(String title) throws IOException {
	    out.write("<td colspan=\"10\" style=\"border-style: none; font-size: 16; font-weight: bold; color: #191970;\">"+escape(title)+"</td>");
	    return this;
	}
    
	public ExcelReport addRptHeaderLine2(String title) throws IOException {
	    out.write("<td colspan=\"10\" style=\"border-style: none; font-size: 12; font-weight: bold; color: #191970;\">"+escape(title)+"</td>");
	    return this;
	}

	public ExcelReport addRptHeaderLine3(String title) throws IOException {
	    out.write("<td colspan=\"10\" style=\"border-style: none; font-size: 12; color: #191970;\">"+escape(title)+"</td>");
	    return this;
	}
	
	public ExcelReport addLabel(String value) throws IOException {
	    out.write("<td style=\"border-style: none; font-weight: bold;\">"+escape(value)+":</td>");
	    return this;
	}
        
	public ExcelReport addCriteria(String value) throws IOException {
	    out.write("<td colspan=\"10\" style=\"border-style: none;\">"+escape(value)+"</td>");
	    return this;
	}
    
	public ExcelReport addCriteria(String[] array, String delimiter) throws IOException {
	    StringBuffer buf = new StringBuffer();
	    if(array!=null){
	        for(int i=0; i<array.length; i++){
	            buf.append(array[i]);
	            if(i<array.length-1) buf.append(delimiter);
	    	}
	    }
	    addCriteria(buf.toString());
	    return this;
	}
	
	public ExcelReport addCriteria(int value) throws IOException {
	    out.write("<td colspan=\"10\" style=\"border-style: none;\">"+value+"</td>");
	    return this;
	}
    
	public ExcelReport addCriteria(Date value) throws IOException {
	    if(value==null){
	        out.write("<td colspan=\"10\" style=\"border-style: none;\"></td>");
	    } else {
	        out.write("<td colspan=\"10\" style=\"border-style: none;\">"+defaultDateFormat.format(value)+"</td>");
	    }
	    return this;
	}
	
	public ExcelReport addRaw(String value) throws IOException {
	    out.write(value);
	    return this;
	}
        
	public ExcelReport addHeader(String value) throws IOException {
	    out.write("<th>"+escape(value)+"</th>");
	    return this;
	}
        
	public ExcelReport addColumn(String value, boolean escape) throws IOException {
	    //For Showing null value columns in GREY Color.
	    if(value==null||value.equals("null")||value.equals("")){
	        out.write("<td></td>"); //Nulls should be blank
	    } else {
	        out.write("<td>"+(escape?escape(value):value)+"</td>");
	    }
	    return this;
	}

	public ExcelReport addColumn(String value, String bgColor, boolean isBold, String align) throws IOException {
		if(value==null||value.equals("null")||value.equals("")){
	        out.write("<td bgColor='" + bgColor + "'></td>"); //Nulls should be blank
	    } else {
	    	StringBuffer outBuffer = new StringBuffer();
	        outBuffer.append("<td");
	        outBuffer.append(" bgColor='" + bgColor + "'");
	        outBuffer.append(" align='" + align + "'");
	        outBuffer.append(" style=mso-number-format:\\@ >");
	        if (isBold){
	        	outBuffer.append("<b>");
	        }
	        outBuffer.append(escape(value));
	        if (isBold){
	        	outBuffer.append("</b>");
	        }	        
	        outBuffer.append("</td>");
	        out.write(outBuffer.toString());
	    }
		return this;
	}
	
	public ExcelReport addColumn(double value) throws IOException {
	    out.write("<td>"+value+"</td>");
	    return this;
	}
	
	public ExcelReport addColumn(int value) throws IOException {
	    out.write("<td>"+value+"</td>");
	    return this;
	}
	
	public ExcelReport addColumn(String value) throws IOException {
	    //change done by AC6952 for checking null value String on sept-08-2005
	    if(value != null){
	        addColumn(value,true);
	    }else{
	        addColumn("null",true);
	    }
	    return this;
	}
	
	public ExcelReport addCurrency(double value) throws IOException {
	    addCurrency(new Double(value));
	    return this;
	}
	
	public HashMap numberFormats = new HashMap();
	public ExcelReport addNumber(Double value, String format) throws IOException {
	    if(value==null){
	        addColumn("null");
	    } else {
	        NumberFormat formatObject = (NumberFormat)numberFormats.get(format);
	        if(formatObject==null){
	            formatObject = new DecimalFormat(format);
	            numberFormats.put(format,formatObject);
	        }
	        addColumn(formatObject.format(value),false);
	    }
	    return this;
	    
	}
	
	public ExcelReport addCurrency(Double value) throws IOException {
	    String s = value==null?"":defaultCurrencyFormat.format(value);
	    addColumn(s,false);
	    return this;
	}
	
	public ExcelReport addColumn(Double value) throws IOException {
	    addColumn(value==null?"null":value.toString(),false);
	    return this;
	}

	public ExcelReport addColumn(Integer value) throws IOException {
	    addColumn(value==null?"null":value.toString(),false);
	    return this;
	}

	public ExcelReport addColumn(Date value) throws IOException {
	    if(value==null){
	        addColumn("null");
	    } else {
	        addColumn(defaultDateFormat.format(value),false);
	    }
	    return this;
	}

	private HashMap dateFormats = new HashMap();
	public ExcelReport addColumn(Date value, String format) throws IOException {
	    if(value==null){
	        addColumn("null");
	    } else {
	        SimpleDateFormat formatObject = (SimpleDateFormat)dateFormats.get(format);
	        if(formatObject==null){
	            formatObject = new SimpleDateFormat(format);
	            dateFormats.put(format,formatObject);
	        }
	        addColumn(formatObject.format(value),false);
	    }
	    return this;
	}
	
	public ExcelReport addColumn(Timestamp value) throws IOException {
	    if(value==null){
	        addColumn("null");
	    } else {
	        addColumn(defaultDateFormat.format(value)+" "+defaultTimeFormat.format(value),false);
	    }
	    return this;
	}
    	
	public static String escape(String string) {
	    if(string==null) return null;
	    StringBuffer sb = new StringBuffer(string.length());
	    boolean lastWasBlankChar = false;
	    char c;
	    for (int i = 0; i < string.length(); i++) {
	        c = string.charAt(i);
	        if (c == ' ') {
	            if (lastWasBlankChar) {
	                lastWasBlankChar = false;
	                sb.append("&nbsp;");
	            } else {
	                lastWasBlankChar = true;
	                sb.append(' ');
	            }
	        } else {
	            lastWasBlankChar = false;
	            // HTML Special Chars
	            if (c == '"'){
	                sb.append("&quot;");
	            } else if (c == '&'){
	                sb.append("&amp;");
	            } else if (c == '<'){
	                sb.append("&lt;");
	            } else if (c == '>'){
	                sb.append("&gt;");
	            } else if (c == '\n'){
	                sb.append("<br/>");
	            } else {
	                int ci = 0xffff & c;
	                if (ci < 160){ //7 Bit
	                    sb.append(c);
	                } else { // unicode
	                    sb.append("&#");
	                    sb.append(new Integer(ci).toString());
	                    sb.append(';');
	                }
	            }
	        }
	    }
	    return sb.toString();
	}
	
	/**
	 * Added by offshore.
	 */
	public void addBreak() throws IOException {
        out.write("<br>");
    }
	/**
	 * Added by offshore.
	 */
	public void flush() throws IOException {
		this.out.flush();
	}
}
