/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.dashboard;

/**
 * This class represents the data object that holds the attributes required
 * to represent the AlertRule Revenue.
 * 
 * @author Sandhya Chinala - SC3837
 */
public class AlertRuleRevenue {
	
	private String head;
	private double credit;
	private double debit;
	private double unrecoverableRevenue;
	
	/**
	 * @return Returns the head.
	 */
	public String getHead() {
		return head;
	}
	/**
	 * @param head The head to set.
	 */
	public void setHead(String head) {
		this.head = head;
	}
	/**
	 * @return Returns the credit.
	 */
	public double getCredit() {
		return credit;
	}
	/**
	 * @param credit The credit to set.
	 */
	public void setCredit(double credit) {
		this.credit = credit;
	}
	/**
	 * @return Returns the debit.
	 */
	public double getDebit() {
		return debit;
	}
	/**
	 * @param debit The debit to set.
	 */
	public void setDebit(double debit) {
		this.debit = debit;
	}
	/**
	 * @return Returns the unrecoverableRevenue.
	 */
	public double getUnrecoverableRevenue() {
		return unrecoverableRevenue;
	}
	/**
	 * @param unrecoverableRevenue The unrecoverableRevenue to set.
	 */
	public void setUnrecoverableRevenue(double unrecoverableRevenue) {
		this.unrecoverableRevenue = unrecoverableRevenue;
	}
}
