/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc;

/**
 * This is a Data Object to represent RABC_CNTRL_PT_TRANS table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class CntrlPtTrans {
	private String cntrlPtCode;
	private String cntrlPtDesc;
	private int presnSeqNum;

	/**
	 * @return Returns the CntrlPtCode.
	 */
	public String getCntrlPtCode() {
		return cntrlPtCode;
	}
	/**
	 * @return Returns the CntrlPtDesc.
	 */
	public String getCntrlPtDesc() {
		return cntrlPtDesc;
	}
	/**
	 * @return Returns the PresnSeqNum.
	 */
	public int getPresnSeqNum() {
		return presnSeqNum;
	}

	/**
	 * @param CntrlPtCode The cntrlPtCode to set.
	 */
	public void setCntrlPtCode(String cntrlPtCode) {
		this.cntrlPtCode = cntrlPtCode;
	}
	/**
	 * @param CntrlPtDesc The cntrlPtDesc to set.
	 */
	public void setCntrlPtDesc(String cntrlPtDesc) {
		this.cntrlPtDesc = cntrlPtDesc;
	}
	/**
	 * @param PresnSeqNum The presnSeqNum to set.
	 */
	public void setPresnSeqNum(int presnSeqNum) {
		this.presnSeqNum = presnSeqNum;
	}
}
