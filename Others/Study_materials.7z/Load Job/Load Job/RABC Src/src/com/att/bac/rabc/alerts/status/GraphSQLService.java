/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.alerts.status;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.att.bac.rabc.ExtrctTblDef;
import com.att.bac.rabc.ExtrctTblDefDAO;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.admin.alert.rule.AlertRule;
import com.att.bac.rabc.admin.alert.rule.AlertRuleDAO;

/**
 * This is a sql service class to execute the sql queries pertaining to the graph and to 
 * return the result to the service class. 
 * This class acts as a super class for the DataGraphSQLService and PercentGraphSQLService.
 * 
 * @author Shailesh Hemdev - SH8512
 */
public class GraphSQLService {
	private static final Logger logger = Logger.getLogger(GraphSQLService.class);
	
	private static final String qryPartiRefId = "Select parti_ref_id from rabc_alert_rule where alert_rule = ''{0}''";
	
	private static final String getAlertRule = "SELECT ALERT_RULE, PARTI_REF_ID, PRESN_ID, " +
	"FILE_VERIF_IND, DATA_EXTRCT_IND, DATA_CALC_IND, CALC_RULE, WARNING_IND, AVG_IND, ALERT_MSG_IND, " +
	"ALERT_SEQ_NUM_IND, ALERT_TIME_IND, ALERT_DASH_FRESH_IND, ALERT_DESC, ALERT_EXEC_DATE, ALERT_KEY_LVL, " +
	"ALERT_KEY1_NAME, ALERT_KEY2_NAME, ALERT_KEY3_NAME, ALERT_KEY4_NAME, ALERT_KEY5_NAME, ALERT_FILE_CT, " +
	"ASOC_FILE_ID, ALERT_RULE_PRESN_IND, DIVISION_NAME_KEY_LVL, DB_NODE_ID, ALERT_RULE_STATUS, EFF_DATE, " +
	"STD_TYPE, ALERT_EXEMPT_IND, USER_ID, TIME_STAMP, ALERT_DATA_KEEP, ALERT_RULE_TYPE, ALERT_MNTH_EXEC_DAY, ALERT_MNTH_EXEC_BILL_RND FROM RABC_ALERT_RULE WHERE ALERT_RULE = ''{0}''";
	
	private static final String qryExtrData = "Select PARTI_REF_ID, EXTRCT_KEY_LVL, KEY1_NAME, KEY2_NAME,KEY3_NAME,KEY4_NAME,KEY5_NAME, " 
											+ "EXTRCT_ITEM_NAME, EXTRCT_DATA_CT, EXTRCT_DATA_LEFT_CT, EXTRCT_DATA_RIGHT_CT, "
											+ "EXTRCT_DATA1_NAME, EXTRCT_DATA2_NAME, EXTRCT_DATA3_NAME, EXTRCT_DATA4_NAME, EXTRCT_DATA5_NAME, "
											+ "EXTRCT_DATA6_NAME, EXTRCT_DATA7_NAME, EXTRCT_DATA8_NAME, EXTRCT_DATA9_NAME, EXTRCT_DATA10_NAME, "
											+ "EXTRCT_DATA11_NAME, EXTRCT_DATA12_NAME, EXTRCT_DATA13_NAME, EXTRCT_DATA14_NAME, EXTRCT_DATA15_NAME "
											+ "from rabc_extrct_tbl_def where parti_ref_id= {0} and extrct_item_name = ''{1}''";
	
	protected static final String qryExtrDataTrend = "Select PARTI_REF_ID, EXTRCT_KEY_LVL, KEY1_NAME, KEY2_NAME,KEY3_NAME,KEY4_NAME,KEY5_NAME, " 
		+ "EXTRCT_ITEM_NAME, EXTRCT_DATA_CT, EXTRCT_DATA_LEFT_CT, EXTRCT_DATA_RIGHT_CT, "
		+ "EXTRCT_DATA1_NAME, EXTRCT_DATA2_NAME, EXTRCT_DATA3_NAME, EXTRCT_DATA4_NAME, EXTRCT_DATA5_NAME, "
		+ "EXTRCT_DATA6_NAME, EXTRCT_DATA7_NAME, EXTRCT_DATA8_NAME, EXTRCT_DATA9_NAME, EXTRCT_DATA10_NAME, "
		+ "EXTRCT_DATA11_NAME, EXTRCT_DATA12_NAME, EXTRCT_DATA13_NAME, EXTRCT_DATA14_NAME, EXTRCT_DATA15_NAME "
		+ "from rabc_extrct_tbl_def where parti_ref_id= {0} ";
	
	private static final String negIndicatorCheck = "select * from rabc_extrct_build_rule where parti_ref_id = {0} " 
													+ "and extrct_item_name = ''{1}'' and (extrct_item1_calc_ind = ''Y'' or extrct_item2_calc_ind = ''Y'' "
													+ "or extrct_item3_calc_ind = ''Y'' or extrct_item4_calc_ind = ''Y'' or extrct_item5_calc_ind = ''Y'' "
													+ "or extrct_item6_calc_ind = ''Y'' or extrct_item7_calc_ind = ''Y'' or extrct_item8_calc_ind = ''Y'' "
													+ "or extrct_item9_calc_ind = ''Y'')";
	
	private static final String chkAlertRule = getAlertRule;
	
	protected static final String trackFileDtlQuery = "select ALERT_RULE, FILE_ID, ALERT_ITEM_NAME, ALERT_ITEM_IND, " +
	"ALERT_DATE_IND, ALERT_ITEM_EXTRCT_TBL, PARTI_REF_ID, ALERT_ITEM_KEY_LVL, ALERT_ITEM_KEY1_NAME, " +
	"ALERT_ITEM_KEY2_NAME, ALERT_ITEM_KEY3_NAME, ALERT_ITEM_KEY4_NAME, ALERT_ITEM_KEY5_NAME, ALERT_ITEM_DATA_CT, " +
	"ALERT_ITEM1_DDL_NAME, ALERT_ITEM1_SUM_IND, ALERT_ITEM2_DDL_NAME, ALERT_ITEM2_SUM_IND, ALERT_ITEM3_DDL_NAME, " +
	"ALERT_ITEM3_SUM_IND, ALERT_ITEM4_DDL_NAME, ALERT_ITEM4_SUM_IND, ALERT_ITEM5_DDL_NAME, ALERT_ITEM5_SUM_IND, "+  
	"ALERT_ITEM6_DDL_NAME, ALERT_ITEM6_SUM_IND, ALERT_ITEM7_DDL_NAME, ALERT_ITEM7_SUM_IND, ALERT_ITEM8_DDL_NAME, " +
	"ALERT_ITEM8_SUM_IND, ALERT_ITEM9_DDL_NAME, ALERT_ITEM9_SUM_IND, ALERT_ITEM10_DDL_NAME, ALERT_ITEM10_SUM_IND, " +
	"ALERT_ITEM11_DDL_NAME, ALERT_ITEM11_SUM_IND, ALERT_ITEM12_DDL_NAME, ALERT_ITEM12_SUM_IND, ALERT_ITEM13_DDL_NAME, " +
	"ALERT_ITEM13_SUM_IND, ALERT_ITEM14_DDL_NAME, ALERT_ITEM14_SUM_IND, ALERT_ITEM15_DDL_NAME, ALERT_ITEM15_SUM_IND, " +
	"VIEW_NAME, ALERT_ITEM_ORD, ALERT_ITEM1_DDL_NAME_IND, ALERT_ITEM2_DDL_NAME_IND, ALERT_ITEM3_DDL_NAME_IND, " +
	"ALERT_ITEM4_DDL_NAME_IND, ALERT_ITEM5_DDL_NAME_IND, ALERT_ITEM6_DDL_NAME_IND, ALERT_ITEM7_DDL_NAME_IND, " +
	"ALERT_ITEM8_DDL_NAME_IND, ALERT_ITEM9_DDL_NAME_IND, ALERT_ITEM10_DDL_NAME_IND, ALERT_ITEM11_DDL_NAME_IND, " +
	"ALERT_ITEM12_DDL_NAME_IND, ALERT_ITEM13_DDL_NAME_IND, ALERT_ITEM14_DDL_NAME_IND, ALERT_ITEM15_DDL_NAME_IND " +
	"FROM RABC_TRACK_FILE_DTL WHERE ALERT_RULE = ''{0}'' ORDER BY ALERT_ITEM_ORD";
	
	protected static final String alertRuleQuery = "SELECT ALERT_RULE, PARTI_REF_ID, PRESN_ID, " +
	"FILE_VERIF_IND, DATA_EXTRCT_IND, DATA_CALC_IND, CALC_RULE, WARNING_IND, AVG_IND, ALERT_MSG_IND, " +
	"ALERT_SEQ_NUM_IND, ALERT_TIME_IND, ALERT_DASH_FRESH_IND, ALERT_DESC, ALERT_EXEC_DATE, ALERT_KEY_LVL, " +
	"ALERT_KEY1_NAME, ALERT_KEY2_NAME, ALERT_KEY3_NAME, ALERT_KEY4_NAME, ALERT_KEY5_NAME, ALERT_FILE_CT, " +
	"ASOC_FILE_ID, ALERT_RULE_PRESN_IND, DIVISION_NAME_KEY_LVL, DB_NODE_ID, ALERT_RULE_STATUS, EFF_DATE, " +
	"STD_TYPE, ALERT_EXEMPT_IND, USER_ID, TIME_STAMP, ALERT_DATA_KEEP, ALERT_RULE_TYPE, ALERT_MNTH_EXEC_DAY, ALERT_MNTH_EXEC_BILL_RND FROM RABC_ALERT_RULE WHERE PRESN_ID = ''{0}''";
	
	private static final String qryKeyLvl_1 = "Select division_name_key_lvl from rabc_alert_rule where parti_ref_id = {0} ";
	private static final String qryKeyLvl_2 = "Select division_name_key_lvl from rabc_alert_rule where alert_rule = ''{0}'' ";
	private static final String qryKeyLvl_3 = "Select division_name_key_lvl from rabc_presn_id where presn_id = {0} ";

	private GraphParameters graphParameters;
	
	/**
	 * Constructor for the GraphSQLService class.
	 * 
	 * @param graphParameters
	 */
	public GraphSQLService(GraphParameters graphParameters) {
		this.setGraphParameters(graphParameters);
	}
	
	/**
	 * @return Returns the graphParameters.
	 */
	public GraphParameters getGraphParameters() {
		return graphParameters;
	}
	
	/**
	 * @param graphParameters The graphParameters to set.
	 */
	public void setGraphParameters(GraphParameters graphParameters) {
		this.graphParameters = graphParameters;
	}
	
	/**
	 * Method to return the Alert Rule details.
	 * 
	 * @param connection
	 * @param failures
	 * @param args
	 * @return AlertRule
	 */
	protected AlertRule getAlertRule(Connection connection, List failures, List args){
		AlertRuleDAO alertRuleDAO = new AlertRuleDAO();
		AlertRule alertRule = null;
		List alertRuleList = alertRuleDAO.get(connection,failures,args,getAlertRule);
		
		if (!alertRuleList.isEmpty()){
			alertRule = (AlertRule) alertRuleList.get(0);
		}
		
		return alertRule;
	}
	
	/**
	 * A method common to data & percent graphs checking the divisionKeyLevel and 
	 * based on it retrieving the list of key values.
	 * 
	 * @param connection
	 * @param failures
	 * @param graphParameters
	 * @return int
	 */
	protected int getDivisioNameKeyLvl(Connection connection, List failures, GraphParameters graphParameters){
		int divisioNameKeyLvl=0;
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		
		List arguments = new ArrayList();

		if (graphParameters.getPartiRefId()!=-1 ||graphParameters.getPresnId()!=-1 || graphParameters.getAlertrule()!=null ){
			if (graphParameters.getPartiRefId()!=-1 ||graphParameters.getAlertrule()!=null ){
				if (graphParameters.getAlertrule()!=null){
					arguments.add(graphParameters.getAlertrule());
					prepareStatement = qryKeyLvl_2;
				}else {
					arguments.add(Integer.toString(graphParameters.getPartiRefId()));
					prepareStatement = qryKeyLvl_1;
				}
			} else {
				arguments.add(Integer.toString(graphParameters.getPresnId()));
				prepareStatement = qryKeyLvl_3;
			}	
		}

		if (prepareStatement!=null){
			try {
				MessageFormat mf = new MessageFormat(prepareStatement);
				prepareStatement = mf.format((String[])arguments.toArray(new String[arguments.size()]));
				stmt = connection.createStatement();
				rs = stmt.executeQuery(prepareStatement);
				
				while(rs.next()){
					divisioNameKeyLvl = rs.getInt("division_name_key_lvl");
					break;
				}
			} catch (SQLException sx) {
				logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
				failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
			} finally {
				SQLHelper.closeResultSet(rs, failures, logger);
				SQLHelper.closeStatement(stmt, failures, logger);
			}
		}
		
		return divisioNameKeyLvl;
	}
	
	/**
	 * The method will be invoked in case the left data count = 0 in which case we will compare values in each of the 
	 * EXTRCT_DATA<i>_NAME fields where i=1 to 15 with the alert item name. Where it matches we will strip the "_NAME"
	 * portion from the field name & return the first 12 or 13 characters (depending upon the value of i)
	 * This value will be the column name whose values need to be derived from the rabc_extrct_sumy_data table.
	 * 
	 * @param extrctTblDef
	 * @return String
	 */
	private String getTExtrctDataItem(ExtrctTblDef extrctTblDef) {
		return "";
	}
	
	/**
	 * Method will query the RABC_EXTRCT_TBL_DEF table to carry the first checks pertaining to number of 
	 * items for the alert rule & their respective DDL definitions.
	 * 
	 * @param graphParameters
	 * @param connection
	 * @param failureList
	 * @return List
	 */
	public List getExtrctTblDefList(GraphParameters graphParameters, Connection connection, List failureList){
		ExtrctTblDefDAO extrctTblDefDAO = new ExtrctTblDefDAO();
		List args = new ArrayList();
		args.add(Integer.toString(graphParameters.getPartiRefId()));
		args.add(graphParameters.getAlertItem());
		
		List extrctTblDefList = extrctTblDefDAO.get(connection,failureList, args,qryExtrData);
		
		return extrctTblDefList;
	}
	
	/**
	 * Method to check whether negInd check is enabled for any of the file items for this alert item.
	 * 
	 * @param graphParameters
	 * @param connection
	 * @param failureList
	 * @return boolean
	 */
	protected boolean isPercentGraphRequired(GraphParameters graphParameters, Connection connection, List failureList){
		boolean required = false;
		
		String prepareStatement = negIndicatorCheck;
		Statement stmt = null;
		ResultSet rs = null;
		
		List args = new ArrayList();

		if (graphParameters.getPartiRefId()!=-1 && graphParameters.getAlertItem()!=null ){
			args.add(Integer.toString(graphParameters.getPartiRefId()));
			args.add(graphParameters.getAlertItem());
			
			try {
				MessageFormat mf = new MessageFormat(prepareStatement);
				prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
				stmt = connection.createStatement();
				rs = stmt.executeQuery(prepareStatement);
				
				while(rs.next()){
					required = true;
					break;
				}
			} catch (SQLException sx) {
				logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
				failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
			} finally {
				SQLHelper.closeResultSet(rs, failureList, logger);
				SQLHelper.closeStatement(stmt, failureList, logger);
			}
		}

		return required;
	}
}
