/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.admin;

/**
 * This is a Data Object to represent RABC_ALERT_GRP_FUNCT table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class AlertGroupFunct {
	private String alertGrp;
	private String functCd;
	
	/**
	 * @return Returns the alertGrp.
	 */
	public String getAlertGrp() {
		return alertGrp;
	}
	/**
	 * @param alertGrp The alertGrp to set.
	 */
	public void setAlertGrp(String alertGrp) {
		this.alertGrp = alertGrp;
	}
	/**
	 * @return Returns the fuctCd.
	 */
	public String getFunctCd() {
		return functCd;
	}
	/**
	 * @param fuctCd The fuctCd to set.
	 */
	public void setFunctCd(String fuctCd) {
		this.functCd = fuctCd;
	}
}
