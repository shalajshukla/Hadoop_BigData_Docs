package com.att.bac.rabc.load.billday.calnet;

import java.util.Date;

import com.att.bac.rabc.load.calnet.CalnetDTO;

public class RabcTotBlgSumyAvg extends CalnetDTO {
	private Date runDate;
	private String division;
	private String agencyID;
	private int acctCtAvg;
	private double currMnthChrgAmtAvg;
	private double currBalDueAmtAvg;
	private double tollAmtAvg;
	private double occAmtAvg;
	private double bocAmtAvg;
	private double attAmtAvg;
	private double iecAmtAvg;
	private double cpucSrcgAmtAvg;
	private double fedTaxAmtAvg;
	private double stateTaxAmtAvg;
	private double cityTaxAmtAvg;
	private double srvUsffAmtAvg;
	private double euclChgAmtAvg;
	private double blgSrcgAmtAvg;
	private double chcfaSrcgAmtAvg;
	private double chcfbSrcgAmtAvg;
	private double lflnSrcgAmtAvg;
	private double hcapSrcgAmtAvg;
	private double ctfSrcgAmtAvg;


	public void setDivision(String division){
		this.division = division;
	}
	public String getDivision(){
		return division;
	}
	public void setRunDate(Date runDate){
		this.runDate = runDate;
	}
	public Date getRunDate(){
		return runDate;
	}
	public void setAgencyId(String agencyID){
		this.agencyID = agencyID;
	}
	public String getAgencyId(){
		return agencyID;
	}
	public void setAcctCtAvg(int acctCt){
		this.acctCtAvg = acctCt;
	}
	public int getAcctCtAvg(){
		return acctCtAvg;
	}
	public void setCurrMnthChrgAmtAvg(double currMnthBlgAmt){
		this.currMnthChrgAmtAvg = currMnthBlgAmt;
	}
	public double getCurrMnthChrgAmtAvg(){
		return currMnthChrgAmtAvg;
	}
	public void setCurrBalDueAmtAvg(double currBalDueAmt){
		this.currBalDueAmtAvg = currBalDueAmt;
	}
	public double getCurrBalDueAmtAvg(){
		return currBalDueAmtAvg;
	}
	public void setTollAmtAvg(double tollAmt){
		this.tollAmtAvg = tollAmt;
	}
	public double getTollAmtAvg(){
		return tollAmtAvg;
	}
	public void setOccAmtAvg(double occAmt){
		this.occAmtAvg = occAmt;
	}
	public double getOccAmtAvg(){
		return occAmtAvg;
	}
	public void setBocAmtAvg(double bocAmt){
		this.bocAmtAvg = bocAmt;
	}
	public double getBocAmtAvg(){
		return bocAmtAvg;
	}
	public void setAttAmtAvg(double attAmt){
		this.attAmtAvg = attAmt;
	}
	public double getAttAmtAvg(){
		return attAmtAvg;
	}
	public void setIecAmtAvg(double iecAmt){
		this.iecAmtAvg = iecAmt;
	}
	public double getIecAmtAvg(){
		return iecAmtAvg;
	}
	public void setCpucSrcgAmtAvg(double cpucSrcgAmt){
		this.cpucSrcgAmtAvg = cpucSrcgAmt;
	}
	public double getCpucSrcgAmtAvg(){
		return cpucSrcgAmtAvg;
	}
	public void setFedTaxAmtAvg(double fedTaxAmt){
		this.fedTaxAmtAvg = fedTaxAmt;
	}
	public double getFedTaxAmtAvg(){
		return fedTaxAmtAvg;
	}
	public void setStateTaxAmtAvg(double stateTaxAmt){
		this.stateTaxAmtAvg = stateTaxAmt;
	}
	public double getStateTaxAmtAvg(){
		return stateTaxAmtAvg;
	}
	public void setCityTaxAmtAvg(double cityTaxAmt){
		this.cityTaxAmtAvg = cityTaxAmt;
	}
	public double getCityTaxAmtAvg(){
		return cityTaxAmtAvg;
	}
	public void setSrvUsffAmtAvg(double srvUsffAmt){
		this.srvUsffAmtAvg = srvUsffAmt;
	}
	public double getSrvUsffAmtAvg(){
		return srvUsffAmtAvg;
	}
	public void setEuclChgAmtAvg(double euclChgAmt){
		this.euclChgAmtAvg = euclChgAmt;
	}
	public double getEuclChgAmtAvg(){
		return euclChgAmtAvg;
	}
	public void setBlgSrcgAmtAvg(double blgSrcgAmt){
		this.blgSrcgAmtAvg = blgSrcgAmt;
	}
	public double getBlgSrcgAmtAvg(){
		return blgSrcgAmtAvg;
	}
	public void setChcfaSrcgAmtAvg(double chcfaSrcgAmt){
		this.chcfaSrcgAmtAvg = chcfaSrcgAmt;
	}
	public double getChcfaSrcgAmtAvg(){
		return chcfaSrcgAmtAvg;
	}
	public void setChcfbSrcgAmtAvg(double chcfbSrcgAmt){
		this.chcfbSrcgAmtAvg = chcfbSrcgAmt;
	}
	public double getChcfbSrcgAmtAvg(){
		return chcfbSrcgAmtAvg;
	}
	public void setLflnSrcgAmtAvg(double lflnSrcgAmt){
		this.lflnSrcgAmtAvg = lflnSrcgAmt;
	}
	public double getLflnSrcgAmtAvg(){
		return lflnSrcgAmtAvg;
	}
	public void setHcapSrcgAmtAvg(double hcapSrcgAmt){
		this.hcapSrcgAmtAvg = hcapSrcgAmt;
	}
	public double getHcapSrcgAmtAvg(){
		return hcapSrcgAmtAvg;
	}
	public void setCtfSrcgAmtAvg(double ctfSrcgAmt){
		this.ctfSrcgAmtAvg = ctfSrcgAmt;
	}
	public double getCtfSrcgAmtAvg(){
		return ctfSrcgAmtAvg;
	}
}