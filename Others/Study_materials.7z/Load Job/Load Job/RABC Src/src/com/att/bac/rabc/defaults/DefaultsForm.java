/* Component Name: RABCPPG01204
 * Module Name: DefaultsForm.java
 * Created on Jul 17, 2006
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.defaults;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.apache.struts.Globals;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import org.apache.struts.util.MessageResources;

/**This is the struts Form class for the User Defaults process.  The purpose of this bean class
 * is to hold data to be presented in the web page Defaults.jsp.
 * 
 * @author js3175
 */
public class DefaultsForm extends ActionForm {
	private static final Logger logger = Logger.getLogger(DefaultsForm.class);
	private static final long serialVersionUID = 0L;
	
	private String dispatch = "";
	private String region = "";
	private String userId = "";
	private String notification= "";
	private int severity = 0;
	
	//Alert Threshold Maintenance Page
	private ArrayList divisions = new ArrayList();
	private String selectedDivision = "";
	private String lineCount = "";
	
	//This method is called by the container.	
	public ActionErrors validate(ActionMapping mapping, HttpServletRequest req ){
		ActionErrors errors = new ActionErrors();
		MessageResources resources = (MessageResources)req.getAttribute(Globals.MESSAGES_KEY);

		//Check for data item. If it doesn't exist goback to previous page.
		if (this.userId == null || this.userId.trim().equals("")) {
			ActionMessage error = new ActionMessage("error.admin.alert.exempt.requiredfield", resources.getMessage("label.admin.alert.exempt.slctdAlrtRule"));
			errors.add(ActionMessages.GLOBAL_MESSAGE, error);
		}
		logger.debug("Finished processing in DefaultsForm.validate");
		return errors;
	}
	
	//This method is called by the container.
	public void reset(ActionMapping mapping, HttpServletRequest request) {
		logger.debug("Finished processing in DefaultsForm.reset");
	}

	/**
	 * @return Returns the dispatch.
	 */
	public String getDispatch() {
		return dispatch;
	}

	/**
	 * @param dispatch The dispatch to set.
	 */
	public void setDispatch(String dispatch) {
		this.dispatch = dispatch;
	}

	/**
	 * @return Returns the region.
	 */
	public String getRegion() {
		return region;
	}

	/**
	 * @param region The region to set.
	 */
	public void setRegion(String region) {
		this.region = region;
	}

	/**
	 * @return Returns the userId.
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId The userId to set.
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @return Returns the lineCount.
	 */
	public String getLineCount() {
		return lineCount;
	}

	/**
	 * @param lineCount The lineCount to set.
	 */
	public void setLineCount(String lineCount) {
		this.lineCount = lineCount;
	}

	/**
	 * @return Returns the division.
	 */
	public ArrayList getDivisions() {
		return divisions;
	}

	/**
	 * @param division The division to set.
	 */
	public void setDivisions(ArrayList divisions) {
		this.divisions = divisions;
	}

	/**
	 * @return Returns the selectedDivision.
	 */
	public String getSelectedDivision() {
		return selectedDivision;
	}

	/**
	 * @param selectedDivision The selectedDivision to set.
	 */
	public void setSelectedDivision(String selectedDivision) {
		this.selectedDivision = selectedDivision;
	}
	
	public String getNotification() {
		return notification;
	}

	public void setNotification(String notification) {
		this.notification = notification;
	}
	public int getSeverity() {
		return severity;
	}

	public void setSeverity(int severity) {
		this.severity = severity;
	}

}
