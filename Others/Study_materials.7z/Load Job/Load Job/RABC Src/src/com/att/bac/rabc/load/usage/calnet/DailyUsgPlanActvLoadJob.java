/* Created by Prachi Chhabra (PC2774) on Dec 19, 2006.
Copyright 2006-2008 AT&T Knowledge Ventures. All rights reserved. */

package com.att.bac.rabc.load.usage.calnet;

import java.io.File;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import com.att.bac.rabc.load.calnet.CalnetException;
import com.att.bac.rabc.load.calnet.CalnetLoadJob;
import com.att.bac.rabc.util.EmcisEventLogger;
import com.att.carat.util.NetUtil;
import com.sbc.bac.rabc.load.StaticErrorMsgKeys;

/**
 * This class reads the data from files whose name fits the pattern:
 * WE.[JI].C[0-9]{4}.XT32DPLN.* . It gets the files from input folder name specified
 * in DailyUsgPlanActv.cfg file. It parses the file line by line and inserts the records into the
 * RABC_DAILY_USG_PLAN_ACTVT table.
 * @author PC2774
 */
public class DailyUsgPlanActvLoadJob extends CalnetLoadJob {

	List dailyUsgPlanActv = null;
	private static final int CONST_HUNDRED_THOUSAND = 1000000;
	private static final int CONST_MILLION = 1000000;
	private String fileName, region;
	 /**
	 * @return ID of the file being processed
	 */
	public String getFileId() {
		return "XT32DPLN";
	}

	/**
	 * @return Table Name for inserting the records.
	 */
	public String getTable() {
		return "RABC_DAILY_USG_PLAN_ACTVT";
	}

	/**
	 * Initiailizes the list to hold data transfer objects. It parses the filename to set the
	 * values for region, division, cycle, run date, bill round date and bill round.
	 *
	 * @param file object representing the file to be processed
	 */
	public boolean preprocessFile(File file){
		fileName = file.getName();
		region   =	file.getName().substring(0,2);
		dailyUsgPlanActv = new ArrayList();
		return super.preprocessFile(file);
	}

	/**
	 * Processes a single record from the load file. A line contains fields that are
	 * semicolon delimited in the following format:<FileId>;<AgencyId>;<Cycle>;<UsageCtgy>;
	 * <Division>;<ProcessID>;<PlanCode>;<AcctTypeCtgy>;<CMDSClassSrvCtgy>;<blank>;<TotalMinsOfUse>;
	 * <TotMsgCt>;<TotBlgChgs>;<TotBlgDiscount>;<TotMinOrCtAlwn>;<TotAmtAlwn>;<TotNumAccts>;
	 * <AmtPerUnit>
	 *
	 * @param file object representing load file
	 * @param success boolean indicating success or failure of previous action
	 * @return boolean indicating success or failure
	 * @exception Exception Throws exception if there is an error in parsing the fields.
	 */
	protected int processRecord(String line) throws Exception {
		int success;

		DailyUsgPlanActv actv = new DailyUsgPlanActv();
		try {
			String[] tokens = line.split(";");
			actv.setRunDate(sqlRunDate);
			actv.setDivision(division);
			actv.setCycle(cycle);
			actv.setAgencyID(tokens[1].trim());
			actv.setUsgPlanCd(Integer.parseInt(tokens[6].trim()));
			actv.setBusResInd(tokens[8].trim());
			actv.setTotMinsOfUse(Double.parseDouble(tokens[10].trim())/CONST_MILLION);
			actv.setTotMsgCt(Long.parseLong(tokens[11].trim())/CONST_MILLION);
			actv.setTotBlgChgs(Double.parseDouble(tokens[12].trim())/CONST_MILLION);
			actv.setTotBlgDsct(Double.parseDouble(tokens[13].trim())/CONST_MILLION);
			actv.setTotMinsMsgAlwn(Long.parseLong(tokens[14].trim())/CONST_MILLION);
			actv.setTotAmtAlwn(Double.parseDouble(tokens[15].trim())/CONST_MILLION);
			actv.setTotNumOfAccts(Long.parseLong(tokens[16].trim())/CONST_HUNDRED_THOUSAND);
			actv.setAmtPerUnit(Double.parseDouble(tokens[17].trim())/CONST_MILLION);
			dailyUsgPlanActv.add(actv);
			lineCount++;
			success = SUCCESS;
		}
		catch (Exception ex) {
			severe(StaticErrorMsgKeys.PARSELINE_ERROR + " Agency: " + actv.getAgencyID() + ex.getMessage(), ex);
			success = ERROR;
		}
		return success;
	}

	/**
	 * Calls the DAO to load the DailyUsgPlanActv objects into RABC_DAILY_USG_PLAN_ACTVT table.
	 * Calls postprocessFile method of base class in the end.
	 *
	 * @param file object representing load file
	 * @param success boolean indicating success or failure of previous action
	 * @return boolean indicating success or failure
	 */
	public boolean postprocessFile(File file, boolean success) {
		try{
			//Log the file information to EMCIS_EVENT_LOG and EMCIS_EVENT_LOG_DETAIL
			EmcisEventLogger emcisLogger = new EmcisEventLogger();
			String event_id = "RABC_"+getFileId()+"_"+region;
            String host = NetUtil.getLocalHostName();
            String hostIP = NetUtil.getLocalIpAddress();
			int sequence = emcisLogger.getEMCISSequence(connection);
			emcisLogger.insertEventLog(connection, sequence, event_id, sqlRunDate, host, hostIP);
			emcisLogger.insertEventLogDetail(connection, sequence, "FileName", fileName);

		}catch (UnknownHostException e) {
            severe("Error getting EMCIS host information ", e);
        }
		if(success){
			DailyUsgPlanActvDAO dao = new DailyUsgPlanActvDAO();
			try{
				success = dao.insertBatchOfRecords(connection, dailyUsgPlanActv, 1000);
			}catch(CalnetException ex){
				severe(ex.getMessage(), ex);
				success = false;
			}
		}
		dailyUsgPlanActv = null;
		return super.postprocessFile(file, success);
	}
}


