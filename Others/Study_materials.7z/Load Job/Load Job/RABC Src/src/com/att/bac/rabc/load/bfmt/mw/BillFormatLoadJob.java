/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/

package com.att.bac.rabc.load.bfmt.mw;

import java.io.File;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import com.att.bac.rabc.util.EmcisEventLogger;
import com.att.carat.util.NetUtil;
import com.sbc.bac.rabc.load.FilePatternLoadJob;
import com.sbc.bac.rabc.load.PrepareTableForRerun;
import com.sbc.bac.rabc.load.RabcLoadJobTrig;
import com.sbc.bac.rabc.load.StaticErrorMsgKeys;
import com.sbc.bac.rabc.load.StaticFieldKeys;

/**
 * This is a Load job which loads Bill Media and BPI data for MW region into the following tables:
 * RABC_BILL_PRT_SUMY
 * RABC_BPI_BLG_SUMY
 * 
 * @author Shailesh Hemdev - SH8512
 */
public class BillFormatLoadJob extends FilePatternLoadJob {
	/*
	 * Varables to represent the date formats
	 */
	private static final SimpleDateFormat MMDDYY_FORMAT 	= new SimpleDateFormat("MMddyy");
	private static final SimpleDateFormat MMDDYYYY_FORMAT	= new SimpleDateFormat("MMddyyyy");
	
	/*
	 * Variables to represent the table names.
	 */
	private static final String RABC_BILL_PRT_SUMY 		= "RABC_BILL_PRT_SUMY";
	private static final String RABC_BPI 				= "RABC_BPI_BLG_SUMY";
	private static final String RABC_TOP_BPI_BLG_ACCT 	= "RABC_TOP_BPI_BLG_ACCT";
	private static final String RABC_TOP_PYMT_ACCT		= "RABC_TOP_PYMT_ACCT";
	private static final String RABC_TRIG 				= "RABC_TRIG";
	
	/*
	 * Variables to represent the file ids to be inserted in RABC_TRIG table.
	 */
	private static final String BILL_PRT_SUMY_FILE_ID 	= "MWBLGFMT";
	private static final String BPI_FILE_ID 			= "MWBLGBPI";
	private static final String TOP_BPI_FILE_ID 		= ""; // TODO 
	private static final String TOP_PYMT_FILE_ID 		= ""; // TODO 
	
	/*
	 * Variables to represent the prepared statements
	 */
	private PreparedStatement insertBillMedia;
	private PreparedStatement insertBPI;
	private PreparedStatement insertTopBPI;
	private PreparedStatement insertTopPymt;
	
	/*
	 * Global variables
	 */
	private String runDate;
	private java.sql.Date sqlRunDate;
	private String division;
	private String billRound;
	private int recordCount;
	private int bfmtBatchCounter;
	private int bpiBatchCounter;
	private int topBpiBatchCounter;
	private int topPymtBatchCounter;
	private String backoutRecovery = null;
	private File currentFile;
	private String fieldSeperator = StaticFieldKeys.SEMICOLON;
	private String fileName, fileToken, region;
	
	/*
	 * HashMap variables to contain the groups for various tables.
	 */
	private HashMap billMediaMap;
	private HashMap bpiMap;
	
	/*
	 * boolean variables indicating whether trigger to be inserted for that file id.
	 */
	boolean isBfmt;
	boolean isBpi;
	boolean isTopBpi;
	boolean isTopPymt;
	
	/*
	 * boolean variables indicating whether the file to be processed or not.
	 */
	boolean isHeaderExists;
	boolean isTrailerExists;
	boolean isDateRecordExists;
	boolean isRecordCountMatches;
	
	/**
	 * Overriding preprocess() method. 
	 * It is executed prior to processing the load job.
	 * Forms the actual prepared statements which need to be fired on to the database.
	 * 
	 * @see com.sbc.bac.load.LoadJob#preprocess()
	 */
	public boolean preprocess() {
		boolean success = super.preprocess();

		if (success) {
			try {
				insertBillMedia = connection.prepareStatement("  INSERT INTO RABC_BILL_PRT_SUMY (RUN_DATE, DIVISION,DOC_CD, BUS_TYPE, DOC_COPY_CT, BILL_RND) VALUES(?, ?, ?, ?, ?, ?) ");
				insertBPI		= connection.prepareStatement("  INSERT INTO RABC_BPI_BLG_SUMY (RUN_DATE, DIVISION, BILL_RND, BUS_TYPE, EBAT_IND , BPI_ACCT_CT_DB, BPI_BLG_AMT_DB, BPI_ACCT_CT_CR, BPI_BLG_AMT_CR) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?) ");
				insertTopBPI	= connection.prepareStatement("  INSERT INTO RABC_TOP_BPI_BLG_ACCT (RUN_DATE, DIVISION, BTN, BUS_TYPE, ACCT_STATUS , BPI_CURR_BLG_AMT) VALUES(?, ?, ?, ?, ?, ?) ");
				insertTopPymt	= connection.prepareStatement("  INSERT INTO RABC_TOP_PYMT_ACCT (RUN_DATE, DIVISION, BTN, CUST_TYPE_CD, ACCT_FINL_IND , PYMT_AMT, PREV_BLG_AMT, CURR_BLG_AMT, BILL_RND) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?) ");
			} catch (SQLException e) {
				severe(StaticErrorMsgKeys.PREPROCESS_ERROR + e.getMessage(), e);
				success = false;
			}
		}
		
		return success;
	}
	
	/**
	 * Overriding preprocessFile(file) method.
	 * It is executed prior to processing the file to be loaded.
	 * It includes the following steps:
	 * 	1) Marks the backoutRecovery flag to "Y" if this file has already been processed earlier.
	 * 	2) Initializes the global variables with default values.
	 * 
	 * @see com.sbc.bac.load.FileDBLoadJob#preprocessFile(java.io.File)
	 */	
	public boolean preprocessFile(File file) {
		boolean success = super.preprocessFile(file);
		fileName = file.getName();
		fileToken = file.getName().substring(file.getName().indexOf("RA130F01"),file.getName().indexOf("RA130F01")+ 8);
		region   =	file.getName().substring(0,2);
		if (success) {
			try {
				/*
				 * Check whether this file has been processed before and if yes,
				 * mark the backoutRecovery flag to "Y".
				 */
				if (RabcLoadJobTrig.IsOriginalFileLoaded(connection, file, file.getName().length())) {
					backoutRecovery = "Y";
				}
			} catch (Exception e) {
				severe(StaticErrorMsgKeys.PREPROCESSFILE_ERROR + e.getMessage(), e);
				success = false;
			}
		}
		
		/*
		 * Initialize the global variables with default values.
		 */
		currentFile = file;
		recordCount = 0;
		isHeaderExists = false;
		isTrailerExists = false;
		isDateRecordExists=false;
		isRecordCountMatches = false;
		billMediaMap = new HashMap();
		bpiMap = new HashMap();
		isBfmt = false;
		isBpi = false;
		isTopBpi = false;
		isTopPymt = false;
		bfmtBatchCounter = 0;
		bpiBatchCounter = 0;
		topBpiBatchCounter = 0;
		topPymtBatchCounter = 0;
		
		return success;
	}
	
	/**
	 * Overriding parseLine(line) method.
	 * It accepts a single line and checks whether it is header, trailer, date or detail record.
	 * Depending upon the record type, it calls the respective internal private methods to process the line.
	 * 
	 * @see com.sbc.bac.load.FileDBLoadJob#parseLine(java.lang.String)
	 */
	protected int parseLine(String line) throws Exception {
		boolean status = true;
		String recordIndicator = getRecordType(line);
		
		if ("HEADER".equalsIgnoreCase(recordIndicator)) {
			isHeaderExists = true;
			status = processHeader(line);
		} else if ("DATE".equalsIgnoreCase(recordIndicator)) {
			if (!isHeaderExists) {
				throw new Exception("Either header record is not present in the file or it is not the first record.");
			} else {
				isDateRecordExists= true;
				recordCount++;
				status = processCycleRecord(line);
			}
		} else if ("TRAILER".equalsIgnoreCase(recordIndicator)) {
			if (!isHeaderExists) {
				throw new Exception("Either header record is not present in the file or it is not the first record.");
			}else if (!isDateRecordExists){
				throw new Exception("Either date record is not present in the file or it is not the second record.");
			}else {
				isTrailerExists = true;
				status = processTrailer(line);
			}
		} else if ("BillMedia".equalsIgnoreCase(recordIndicator)) {
			if (!isHeaderExists) {
				throw new Exception("Either header record is not present in the file or it is not the first record.");
			} else if (!isDateRecordExists) {
				throw new Exception("Either date record is not present in the file or it is not the second record.");
			} else if (isTrailerExists) {
				throw new Exception("Trailer record is not the last record.");
			} else {
				recordCount++;
				isBfmt = true;
				status = processBillMedia(line);
			}
		} else if ("BPI".equalsIgnoreCase(recordIndicator)) {
			if (!isHeaderExists) {
				throw new Exception("Either header record is not present in the file or it is not the first record.");
			} else if (!isDateRecordExists) {
				throw new Exception("Either date record is not present in the file or it is not the second record.");
			} else if (isTrailerExists) {
				throw new Exception("Trailer record is not the last record.");
			} else {
				recordCount++;
				isBpi = true;
				status = processBPI(line);
			}
		} else if ("TOPBPI".equalsIgnoreCase(recordIndicator)) {
			if (!isHeaderExists) {
				throw new Exception("Either header record is not present in the file or it is not the first record.");
			} else if (!isDateRecordExists) {
				throw new Exception("Either date record is not present in the file or it is not the second record.");
			} else if (isTrailerExists) {
				throw new Exception("Trailer record is not the last record.");
			} else {
				recordCount++;
				status = processTopBPI(line);
			}
		}else if ("TOPPYMT".equalsIgnoreCase(recordIndicator)) {
			if (!isHeaderExists) {
				throw new Exception("Either header record is not present in the file or it is not the first record.");
			} else if (!isDateRecordExists) {
				throw new Exception("Either date record is not present in the file or it is not the second record.");
			} else if (isTrailerExists) {
				throw new Exception("Trailer record is not the last record.");
			} else {
				recordCount++;
				status = processTopPymt(line);
			}
		}else {
			recordCount++;
			status = false;
		}
		
		if (status) {
			return SUCCESS;
		} else {
			return ERROR;
		}
	}
	
	/**
	 * Private method to return the record type of the line to be processed.
	 * 
	 * @param line
	 * @return String
	 * @throws Exception
	 */
	private String getRecordType(String line) throws Exception {
		String recordType = null;
		
		String [] lineFields 	= line.split(fieldSeperator);
		String firstField		= lineFields[0].trim();
		String secondField		= lineFields[1].trim();
		
		if ("HEADER".equals(firstField)) {
			recordType = "HEADER";
		} else if ("TRAILER".equals(firstField)) {
			recordType = "TRAILER";
		} else if ("RA13DATE".equals(firstField)) {
			recordType = "DATE";
		} else if ("RA13BILL".equals(firstField)) {
			if ("01".equals(secondField)) {
				recordType = "BillMedia";
			} else if ("02".equals(secondField)) {
				recordType = "BPI";
			}else if ("03".equals(secondField)) {
				recordType = "TOPBPI";
			}else if ("04".equals(secondField)) {
				recordType = "TOPPYMT";
			}
		}
		
		return recordType;
	}

	/**
	 * Private method to process the header record.
	 * 
	 * @param line
	 * @return boolean
	 * @throws Exception
	 */
	private boolean processHeader(String line) throws Exception {
		boolean success = false;
		
		String [] lineFields = line.split(fieldSeperator);
		
		/*
		 * Populate the instance variable for division.
		 */
		if (lineFields.length > 2) {
			division = lineFields[2].trim();
			success = true;
		}
		
		return success;
	}
	
	/**
	 * Private method to process the trailer record.
	 * It checks that whether the total number of records (excluding header and trailer records)
	 * in the file is eqaul to the count in the trailer record or not.
	 *  
	 * @param line
	 * @return boolean
	 * @throws Exception
	 */
	private boolean processTrailer(String line) throws Exception {
		boolean success = false;
		int trailerCount = 0;
		
		String [] lineFields = line.split(fieldSeperator);
		
		if (lineFields.length > 5) {
			trailerCount = Integer.parseInt(lineFields[5].trim());
			success = true;
		}
		
		if (success) {
			if (trailerCount == recordCount) {
				isRecordCountMatches = true;
			}
		}
		
		return success;
	}
	
	/**
	 * Private method to process the date record. It does the following steps:
	 * 	1) Retrieves the cycle date from the date record.
	 * 	2) Deletes the records matching with the date and division retrieved form the file from the tables 
	 * 	   RABC_BILL_PRT_SUMY and RABC_BPI_BLG_SUMY if the backoutRecovery flag is "Y", 
	 * 	   i.e. this file has already been processed earlier.
	 * 
	 * @param line
	 * @return boolean
	 * @throws Exception
	 */
	private boolean processCycleRecord(String line) throws Exception {
		boolean success = false;
		
		String [] lineFields = line.split(fieldSeperator);
		
		/*
		 * Populate the instance variable for runDate.
		 * Defect Fix # 57349. 5th field is added for process group which is now read into the bill round variable. This 
		 * value if not 0 or "" will also be used as the day part of BILL_RND_DT used in the query to get the PROC_DT
		 */
		if (lineFields.length >= 4) {
			runDate = lineFields[2].trim();
			billRound = lineFields[4].trim(); 
			if ("00".equals(billRound) || "".equals(billRound.trim())) {
				billRound = "0";
			}else {
				runDate = runDate.substring(0,2) + billRound + runDate.substring(4,runDate.length());
			}
			
			success = true;
		}
		
		if (success) {
			runDate = MMDDYYYY_FORMAT.format(MMDDYY_FORMAT.parse(runDate));
			
			String procDt = null;
			String runDatequery = "SELECT TO_CHAR(PROC_DT,'MMDDYYYY') PROC_DT FROM RABC_CYCLE_CALENDAR WHERE BILL_RND_DT = to_date('" + runDate + "','MMddyyyy')";
			procDt	= getRunDate(connection, runDatequery);
			
			if (procDt == null) {
				throw new Exception("The cycle date " + runDate + " does not exist in RABC_CYCLE_CALENDAR table.");
			}else {
				runDate = procDt;
			}
			
			sqlRunDate = new java.sql.Date(MMDDYYYY_FORMAT.parse(runDate).getTime());
			
			if ("Y".equals(backoutRecovery)){
				if (!PrepareTableForRerun.deleteTableData(connection, RABC_BILL_PRT_SUMY, division, sqlRunDate)) {
					throw new Exception("Error occurred attempting to backup and recover for rerun for table: " + RABC_BILL_PRT_SUMY);
				}
				if (!PrepareTableForRerun.deleteTableData(connection, RABC_BPI, division, sqlRunDate)) {
					throw new Exception("Error occurred attempting to backup and recover for rerun for table: " + RABC_BPI);
				}
				if (!PrepareTableForRerun.deleteTableData(connection, RABC_TOP_BPI_BLG_ACCT, division, sqlRunDate)) {
					throw new Exception("Error occurred attempting to backup and recover for rerun for table: " + RABC_TOP_BPI_BLG_ACCT);
				}
				if (!PrepareTableForRerun.deleteTableData(connection, RABC_TOP_PYMT_ACCT, division, sqlRunDate)) {
					throw new Exception("Error occurred attempting to backup and recover for rerun for table: " + RABC_TOP_PYMT_ACCT);
				}
			}
		}
		
		return success;
	}
	
	/**
	 * Private method to process the records for the rule number '01' of rule 'RA13BILL'.
	 * It does the following steps:
	 * 	1) Retrieves the fields from the line.
	 * 	2) Creates the objects of BillFormat type.
	 * 	3) Populates the hash map with those objects.
	 * 
	 * @param line
	 * @return boolean
	 * @throws Exception
	 */
	private boolean processBillMedia(String line) throws Exception {
		boolean success = false;
		
		String [] lineFields = line.split(fieldSeperator);
		
		if (lineFields.length == 9) {
			success = true;
			
			String recordType		= lineFields[0].trim();
			String seqNumber 		= lineFields[1].trim();
			String custType			= lineFields[2].trim();
			String internetBill		= lineFields[3].trim();
			String offlineBill		= lineFields[4].trim();
			String cdromBill		= lineFields[5].trim();
			String paperBill		= lineFields[6].trim();
			String noPaperBill		= lineFields[7].trim();	
			String summaryBill		= lineFields[8].trim();
			
			/*
			 * Form the BUS_TYPE based on the logic
			 */
			String busType =getBusType(custType);
			
			/*
			 * Form the counts for various types of media
			 */
			long internetBillCount 	= Long.parseLong(internetBill.substring(0, internetBill.length()-6));
			long offlineBillCount	= Long.parseLong(offlineBill.substring(0, offlineBill.length()-6));
			long cdromBillCount		= Long.parseLong(cdromBill.substring(0, cdromBill.length()-6));
			long paperBillCount		= Long.parseLong(paperBill.substring(0, paperBill.length()-6));
			long noPaperBillCount	= Long.parseLong(noPaperBill.substring(0, noPaperBill.length()-6));	
			long summaryBillCount	= Long.parseLong(summaryBill.substring(0, summaryBill.length()-6));
			
			BillMedia billMedia = null;
			BillMedia objRef	= null;
			long docCopyCt = 0;
			/*
			 * Check for internet bill - form the bill media object and check for its presence in the map. 
			 * If found then increment the count else set the count to 1 and put the object back in the map.
			 */
			billMedia	= new BillMedia();
			billMedia.setRunDate(MMDDYYYY_FORMAT.parse(runDate));
			billMedia.setDivision(division);
			billMedia.setBillRound(Integer.parseInt(billRound));
			billMedia.setBusType(busType);
			billMedia.setDocCd("I");
			
			objRef = (BillMedia) billMediaMap.get(billMedia); 
			if (objRef != null){
				docCopyCt = objRef.getDocCopyCt() + internetBillCount;
				objRef.setDocCopyCt(docCopyCt);
				billMediaMap.put(objRef,objRef);
			} else {
				billMedia.setDocCopyCt(internetBillCount);
				billMediaMap.put(billMedia,billMedia);
			}

			
			/*
			 * Check for offline bill - form the bill media object and check for its presence in the map. 
			 * If found then increment the count else set the count to 1 and put the object back in the map.
			 */
			billMedia = null;
			objRef	= null;
			billMedia	= new BillMedia();
			billMedia.setRunDate(MMDDYYYY_FORMAT.parse(runDate));
			billMedia.setDivision(division);
			billMedia.setBillRound(Integer.parseInt(billRound));
			billMedia.setBusType(busType);
			billMedia.setDocCd("O"); // Changed from value in variable offlineBill to hard coded 'O' as per e mail on 9/11
			
			objRef = (BillMedia) billMediaMap.get(billMedia); 
			if (objRef != null){
				docCopyCt = objRef.getDocCopyCt() + offlineBillCount;
				objRef.setDocCopyCt(docCopyCt);
				billMediaMap.put(objRef,objRef);
			} else {
				billMedia.setDocCopyCt(offlineBillCount);
				billMediaMap.put(billMedia,billMedia);
			}
			
			/*
			 * Check for CDROM bill - form the bill media object and check for its presence in the map. 
			 * If found then increment the count else set the count to 1 and put the object back in the map.
			 */
			billMedia = null;
			objRef	= null;
			billMedia	= new BillMedia();
			billMedia.setRunDate(MMDDYYYY_FORMAT.parse(runDate));
			billMedia.setDivision(division);
			billMedia.setBillRound(Integer.parseInt(billRound));
			billMedia.setBusType(busType);
			billMedia.setDocCd("C");// Changed from value in variable cdromBill to hard coded 'C' as per e mail on 9/11
			
			objRef = (BillMedia) billMediaMap.get(billMedia); 
			if (objRef != null){
				docCopyCt = objRef.getDocCopyCt() + cdromBillCount;
				objRef.setDocCopyCt(docCopyCt);
				billMediaMap.put(objRef,objRef);
			} else {
				billMedia.setDocCopyCt(cdromBillCount);
				billMediaMap.put(billMedia,billMedia);
			}

			/*
			 * Check for paper bill - form the bill media object and check for its presence in the map. 
			 * If found then increment the count else set the count to 1 and put the object back in the map.
			 */
			billMedia = null;
			objRef	= null;
			billMedia	= new BillMedia();
			billMedia.setRunDate(MMDDYYYY_FORMAT.parse(runDate));
			billMedia.setDivision(division);
			billMedia.setBillRound(Integer.parseInt(billRound));
			billMedia.setBusType(busType);
			billMedia.setDocCd("P");
			
			objRef = (BillMedia) billMediaMap.get(billMedia); 
			if (objRef != null){
				docCopyCt = objRef.getDocCopyCt() + paperBillCount;
				objRef.setDocCopyCt(docCopyCt);
				billMediaMap.put(objRef,objRef);
			} else {
				billMedia.setDocCopyCt(paperBillCount);
				billMediaMap.put(billMedia,billMedia);
			}
			
			/*
			 * Check for no paper bill - form the bill media object and check for its presence in the map. 
			 * If found then increment the count else set the count to 1 and put the object back in the map.
			 */
			billMedia = null;
			objRef	= null;
			billMedia	= new BillMedia();
			billMedia.setRunDate(MMDDYYYY_FORMAT.parse(runDate));
			billMedia.setDivision(division);
			billMedia.setBillRound(Integer.parseInt(billRound));
			billMedia.setBusType(busType);
			billMedia.setDocCd("N");
			
			objRef = (BillMedia) billMediaMap.get(billMedia); 
			if (objRef != null){
				docCopyCt = objRef.getDocCopyCt() + noPaperBillCount;
				objRef.setDocCopyCt(docCopyCt);
				billMediaMap.put(objRef,objRef);
			} else {
				billMedia.setDocCopyCt(noPaperBillCount);
				billMediaMap.put(billMedia,billMedia);
			}
			
			/*
			 * Check for summary bill - form the bill media object and check for its presence in the map. 
			 * If found then increment the count else set the count to 1 and put the object back in the map.
			 */
			billMedia = null;
			objRef	= null;
			billMedia	= new BillMedia();
			billMedia.setRunDate(MMDDYYYY_FORMAT.parse(runDate));
			billMedia.setDivision(division);
			billMedia.setBillRound(Integer.parseInt(billRound));
			billMedia.setBusType(busType);
			billMedia.setDocCd("S");
			
			objRef = (BillMedia) billMediaMap.get(billMedia); 
			if (objRef != null){
				docCopyCt = objRef.getDocCopyCt() + summaryBillCount;
				objRef.setDocCopyCt(docCopyCt);
				billMediaMap.put(objRef,objRef);
			} else {
				billMedia.setDocCopyCt(summaryBillCount);
				billMediaMap.put(billMedia,billMedia);
			}
		}
		
		return success;
	}
	
	/**
	 * Private method to process the records for the rule number '02' and '03' of rule 'RA13BILL'.
	 * It does the following steps:
	 * 	1) Retrieves the fields from the line.
	 * 	2) Does conversion of data from String to appropriate data types as well as interpretation for amount.
	 * 	3) Creates the objects of Bpi type.
	 * 	3) Populates the hash map with those objects.
	 * 
	 * @param line
	 * @return boolean
	 * @throws Exception
	 */
	private boolean processBPI(String line) throws Exception {
		boolean success = false;
		
		String [] lineFields = line.split(fieldSeperator);
		String busType = null;
		
		if (lineFields.length == 8) {
			success = true;
			
			String recordType			= lineFields[0].trim();
			String seqNumber 			= lineFields[1].trim();
			String custType				= lineFields[2].trim();
			String ebatIndicator		= lineFields[3].trim();
			String totalAccountsDbCt	= lineFields[4].trim();
			String totalAccountsDbAmt	= lineFields[5].trim();
			String totalAccountsCrCt	= lineFields[6].trim();
			String totalAccountsCrAmt	= lineFields[7].trim();
			
			// Calculate the Business type
			busType =getBusType(custType);
			
			/*
			 * Format the total count and total amount
			 */
			long bpiAccountDbCt			= Long.parseLong(totalAccountsDbCt.substring(0, totalAccountsDbCt.length()-6));
			double bpiAccountDbAmt		= Double.parseDouble(totalAccountsDbAmt.substring(0, totalAccountsDbAmt.length()-6) + "." + totalAccountsDbAmt.substring(totalAccountsDbAmt.length()-6));
			long bpiAccountCrCt			= Long.parseLong(totalAccountsCrCt.substring(0, totalAccountsCrCt.length()-6));
			double bpiAccountCrAmt		= Double.parseDouble(totalAccountsCrAmt.substring(0, totalAccountsCrAmt.length()-6) + "." + totalAccountsCrAmt.substring(totalAccountsCrAmt.length()-6));
			
			/*
			 * Create object to check for presense - apply grouping logic
			 */
			Bpi bpi = new Bpi();
			bpi.setRunDate(MMDDYYYY_FORMAT.parse(runDate));
			bpi.setDivision(division);
			bpi.setBillRound(Integer.parseInt(billRound));
			bpi.setBusType(busType);
			bpi.setEBATInd(ebatIndicator);
			
			Bpi objRef = (Bpi) bpiMap.get(bpi);
			if (objRef != null){
				bpiAccountDbCt += objRef.getBpiAcctCtDb();
				bpiAccountDbAmt += objRef.getBpiBlgAmtDb();
				bpiAccountCrCt += objRef.getBpiAcctCtCr();
				bpiAccountCrAmt += objRef.getBpiBlgAmtCr();
				objRef.setBpiAcctCtDb(bpiAccountDbCt);
				objRef.setBpiBlgAmtDb(bpiAccountDbAmt);
				objRef.setBpiAcctCtCr(bpiAccountCrCt);
				objRef.setBpiBlgAmtCr(bpiAccountCrAmt);
				bpiMap.put(objRef, objRef);
			} else {
				bpi.setBpiAcctCtDb(bpiAccountDbCt);
				bpi.setBpiBlgAmtDb(bpiAccountDbAmt);
				bpi.setBpiAcctCtCr(bpiAccountCrCt);
				bpi.setBpiBlgAmtCr(bpiAccountCrAmt);
				bpiMap.put(bpi, bpi);
			}
		}
		
		return success;
	}
	
	/**
	 * Private method to process Rule 03 in Bill Format file @RA130
	 * @param line
	 * @return
	 * @throws Exception
	 */
	private boolean processTopBPI(String line) throws Exception {
		boolean success = false;
		
		String [] lineFields = line.split(fieldSeperator);
		String busType = null;
		
		if (lineFields.length == 6) {
			success = true;
			
			String recordType			= lineFields[0].trim();
			String seqNumber 			= lineFields[1].trim();
			String btn					= lineFields[2].trim();
			String accountStatus		= lineFields[3].trim();
			String custType				= lineFields[4].trim();
			String currentCharges		= lineFields[5].trim();
			
			// Calculate the Business type
			busType =getBusType(custType);
			
			double currCharges			= Double.parseDouble(currentCharges)/100 ;
			
			topBpiBatchCounter++;
			insertTopBPI.setDate(1,sqlRunDate);
			insertTopBPI.setString(2, division);
			insertTopBPI.setString(3,btn);
			insertTopBPI.setString(4,busType);
			insertTopBPI.setString(5,accountStatus);
			insertTopBPI.setDouble(6,currCharges);
			insertTopBPI.addBatch();
				
			if (topBpiBatchCounter % 1000 == 0){
				insertTopBPI.executeBatch();
			}
			isTopBpi					= true;
		}
		
		return success;
	}
	
	private boolean processTopPymt(String line) throws Exception {
		boolean success = false;
		
		String [] lineFields = line.split(fieldSeperator);
		String busType = null;
		
		if (lineFields.length == 8) {
			success = true;
			
			String recordType			= lineFields[0].trim();
			String seqNumber 			= lineFields[1].trim();
			String btn					= lineFields[2].trim();
			String accountStatus		= lineFields[3].trim();
			String custType				= lineFields[4].trim();
			String payments				= lineFields[5].trim();
			String previousBillAmt		= lineFields[6].trim();
			String currentCharges		= lineFields[7].trim();
			
			// Calculate the Business type
			busType =getBusType(custType);
			
			double pymtAmt				= Double.parseDouble(payments)/100;
			double prevBlgAmt			= Double.parseDouble(previousBillAmt)/100;
			double currBlgAmt			= Double.parseDouble(currentCharges)/100;
			
			topPymtBatchCounter++;
			insertTopPymt.setDate(1,sqlRunDate);
			insertTopPymt.setString(2, division);
			insertTopPymt.setString(3,btn);
			insertTopPymt.setString(4,custType);
			insertTopPymt.setString(5,accountStatus);
			insertTopPymt.setDouble(6,pymtAmt);
			insertTopPymt.setDouble(7,prevBlgAmt);
			insertTopPymt.setDouble(8,currBlgAmt);
			insertTopPymt.setInt(9,Integer.parseInt(billRound));
			insertTopPymt.addBatch();
				
			if (topPymtBatchCounter % 1000 == 0){
				insertTopPymt.executeBatch();
			}
			
			isTopPymt					= true;
		}
		
		return success;
	}
	
	/**
	 * Overriding postProcessFile(file, success) method.
	 * It is executed post to processing the file to be loaded.
	 * It includes the following steps:
	 * 	1) It checks whether the header and trailer records exists and 
	 * 	   whether the total number of records (excluding header and trailer records)
	 * 	   in the file is eqaul to the count in the trailer record.
	 * 	   If it is then prcoceeds to next step else return false.
	 * 	2) Loop through the map billMediaMap & bpiMap and insert entries 
	 * 	   into RABC_BILL_PRT_SUMY & RABC_BPI_BLG_SUMYtable.
	 * 	3) Makes the entries into RABC_TRIG table.
	 * 
	 * @see com.sbc.bac.load.FileDBLoadJob#postprocessFile(java.io.File, boolean)
	 */
	public boolean postprocessFile(File file, boolean success) {
		try{
			//Log the file information to EMCIS_EVENT_LOG and EMCIS_EVENT_LOG_DETAIL
			EmcisEventLogger emcisLogger = new EmcisEventLogger();
			String event_id = "RABC_"+fileToken+"_"+region;
            String host = NetUtil.getLocalHostName();
            String hostIP = NetUtil.getLocalIpAddress();
			int sequence = emcisLogger.getEMCISSequence(connection);
			emcisLogger.insertEventLog(connection, sequence, event_id, sqlRunDate, host, hostIP);
			emcisLogger.insertEventLogDetail(connection, sequence, "FileName", fileName);

		}catch (UnknownHostException e) {
            severe("Error getting EMCIS host information ", e);
        }
		if (success) {
			if (!isTrailerExists) {
				severe("Trailer record is not present in the file.");
				success = false;
			} else if (!isRecordCountMatches) {
				severe("Total number of records in the file is not eqaul to the count in the trailer record.");
				success = false;
			} else {
				try {
					/*
					 * Iterate through the entire hash map and insert entries into the RABC_BILL_PRT_SUMY table
					 */
					Set billMediaSet			= billMediaMap.keySet();
					Iterator billMediaIterator 	= billMediaSet.iterator();
					
					while (billMediaIterator.hasNext()){
						bfmtBatchCounter++;
						BillMedia billMedia	 = (BillMedia) billMediaIterator.next();
						
						insertBillMedia.setDate(1,sqlRunDate);
						insertBillMedia.setString(2, division);
						insertBillMedia.setString(3,billMedia.getDocCd());
						insertBillMedia.setString(4,billMedia.getBusType());
						insertBillMedia.setLong(5,billMedia.getDocCopyCt());
						insertBillMedia.setInt(6,billMedia.getBillRound());
						insertBillMedia.addBatch();
						
						if (bfmtBatchCounter % 1000 == 0){
							insertBillMedia.executeBatch();
						}
					}
					
					/*
					 * Execute the batch after all entries in map are processed
					 */
					insertBillMedia.executeBatch();
					
					/*
					 * Iterate through the entire hash map and insert entries into the RABC_BPI_BLG_SUMY table
					 */
					Set bpiSet				= bpiMap.keySet();
					Iterator bpiIterator 	= bpiSet.iterator();
					
					while (bpiIterator.hasNext()){
						bpiBatchCounter++;
						Bpi bpi	 = (Bpi) bpiIterator.next();
						insertBPI.setDate(1,sqlRunDate);
						insertBPI.setString(2, division);
						insertBPI.setInt(3, bpi.getBillRound());
						insertBPI.setString(4, bpi.getBusType());
						insertBPI.setString(5, bpi.getEBATInd());
						insertBPI.setLong(6, bpi.getBpiAcctCtDb());
						insertBPI.setDouble(7, bpi.getBpiBlgAmtDb());
						insertBPI.setLong(8, bpi.getBpiAcctCtCr());
						insertBPI.setDouble(9, bpi.getBpiBlgAmtCr());
						insertBPI.addBatch();
						
						if (bpiBatchCounter % 1000 == 0){
							insertBPI.executeBatch();
						}
					}
					
					/*
					 * Execute the batch after all entries in map are processed
					 */
					insertBPI.executeBatch();
					
					/*
					 * Execute the batch after all entries are processed
					 */
					insertTopBPI.executeBatch();
					
					/*
					 * Execute the batch after all entries are processed
					 */
					insertTopPymt.executeBatch();
					
					/*
					 * Call the private method to make the entries into RABC_TRIG table
					 */
					if (!insertTrigger()) {
						success = false;
					}	
				} catch (SQLException sqle){
					severe(StaticErrorMsgKeys.INSERT_ERROR + sqle.getMessage(), sqle);
					success = false;
				}
			}
		}
		
		return super.postprocessFile(file, success);
	}
	
	/**
	 * Private method to return the business type based on only the customer type
	 * @param custType
	 * @return
	 */
	private String getBusType(String custType){
		if ("R".equals(custType)){
			return "RES";
		}else {
			return "BUS";
		}
	}
	
	/**
	 * Private method to return the run date for the passed query.
	 * 
	 * @param connection
	 * @param query
	 * @return String
	 */
	private String getRunDate(Connection connection, String query) throws SQLException {
		String runDate = null;
		
		Statement statement = null;
		ResultSet rs = null;

		statement = connection.createStatement();
		rs = statement.executeQuery(query);
		if (rs != null && rs.next()) {
			runDate = rs.getString("PROC_DT");
		}

		rs.close();
		statement.close();
		
    	return runDate;
	}
	
	/**
	 * This is a method to insert entry into RABC_TRIG table
	 * 
	 * @return boolean
	 */
	private boolean insertTrigger() {
		/*
		 * Check whether there were any trn record inserted, if yes then insert into trigger
		 */
		if (isBfmt) {
			if(!RabcLoadJobTrig.insertTrigger(connection, currentFile.getName().substring(5, currentFile.getName().length()), currentFile.getName(), BILL_PRT_SUMY_FILE_ID, division, runDate , backoutRecovery, billRound, RABC_TRIG)) {
				return false;	
			}
		}
		
		/*
		 * Check whether there were any err record inserted, if yes then insert into trigger
		 */
		if (isBpi) {
			if(!RabcLoadJobTrig.insertTrigger(connection, currentFile.getName().substring(5, currentFile.getName().length()), currentFile.getName(), BPI_FILE_ID, division, runDate , backoutRecovery, billRound, RABC_TRIG)) {
				return false;	
			}
		}
		
		// TODO Triggers to be added for the new tables
		
		return true;
	}

	/**
	 * Overriding postProcess(success) method.
	 * It is executed post to processing the load job.
	 * It includes the following steps:
	 * 	1) Closes statements that were opened for this load job.
	 * 
	 * @see com.sbc.bac.load.LoadJob#postprocess(boolean)
	 */
	public boolean postprocess(boolean success) {
		try {
			insertBillMedia.close();
			insertBPI.close();
		} catch (SQLException e) {
			severe(StaticErrorMsgKeys.POSTPROCESS_ERROR + StaticErrorMsgKeys.SQL_CLOSE_ERROR + e.getMessage(), e);
			success = false;
		}
		
		return super.postprocess(success);
	}
}
