/* Created by Peter Foo (pf7941) on Dec 6, 2006.
 Copyright 2006-2008 AT&T Knowledge Ventures. All rights reserved. */

package com.att.bac.rabc.load.calnet;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import com.att.carat.util.JDBCUtil;

/**
 * An abstract class for CALNET-2 Load Job data access objects.
 * @author pf7941
 *
 */
public abstract class CalnetDAO {

	/**
	 * Inserts the elements of the dataTransferObjectList into a table in batch mode.
	 * 
	 * @param dataTransferObjectList -
	 *            List of data transfer objects
	 * @param batchSize -
	 *            batch size
	 * @return boolean indicating success or failure
	 * @throws SOCalnetException
	 */
	public boolean insertBatchOfRecords(Connection conn, List dataTransferObjectList, int batchSize)
			throws CalnetException {
		boolean success;

		// If the list is null or size is 0, return false
		if (dataTransferObjectList == null || dataTransferObjectList.size() == 0) {
			success = true;
		}
		else {
			success = false;
			int remainder = dataTransferObjectList.size() % batchSize;

			// calculate the no of batches
			int noOfBatches = dataTransferObjectList.size() / batchSize;
			int startIndex = 0;
			int endIndex = 0;
			PreparedStatement pstmt = null;
			try {
				pstmt = conn.prepareStatement(getInsertSql());
				for (int i = 0; i < noOfBatches; i++) {
					startIndex = i * batchSize;
					endIndex = (i * batchSize) + batchSize;
					success = insertRecords(dataTransferObjectList.subList(startIndex, endIndex), pstmt);
					if (!success) {
						break;
					}
				}
				if (remainder != 0) {
					success = insertRecords(dataTransferObjectList.subList(endIndex, endIndex + remainder), pstmt);
				}
			}
			catch (SQLException e) {
				throw new CalnetException("SQL Exception occurred. startIndex = " + startIndex + ", endIndex = "
						+ endIndex + ", number of records = " + dataTransferObjectList.size() + ", insertSql = "
						+ getInsertSql(), e);
			}
			finally {
				JDBCUtil.closePreparedStatement(pstmt);
			}
		}
		return success;
	}

	/**
	 * This method sets the parameters of the PreparedStatement object to the properties of the
	 * objects in the list. Each set of parameters is then added to the PreparedStatement's object's
	 * batch of commands. The batch is then executed.
	 * 
	 * @param list
	 * @param pstmt
	 * @return true
	 * @throws CalnetException
	 */
	protected boolean insertRecords(List list, PreparedStatement pstmt) throws CalnetException {
		int i = 0;
		try {
			for (; i < list.size(); i++) {
				CalnetDTO dataTransferObject = (CalnetDTO) list.get(i);
				setValues(pstmt, dataTransferObject);
				pstmt.addBatch();
			}
			pstmt.executeBatch();
		}
		catch (SQLException e) {
			throw new CalnetException("SQL Exception occurred after processing element " + i + " of the list.", e);
		}
		return true;
	}

	/**
	 * Sets the parameters of the PreparedStatement object to the properties of the
	 * dataTransferObject.
	 * @param pstmt
	 * @param dataTransferObject
	 * @throws CalnetException
	 */
	protected abstract void setValues(PreparedStatement pstmt, CalnetDTO dataTransferObject) throws CalnetException;

	/**
	 * Returns the insert statement used to insert a record into a table.
	 * @return
	 */
	protected abstract String getInsertSql();
}
