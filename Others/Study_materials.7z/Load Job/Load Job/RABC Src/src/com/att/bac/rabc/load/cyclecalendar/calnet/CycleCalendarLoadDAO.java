package com.att.bac.rabc.load.cyclecalendar.calnet;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;

import com.att.bac.util.JDBCUtil;

/**
 * This is a Data Access Object(DAO) class which interact with database and
 * insert records for CALNET 2 in AUDINV_CYCLE table.
 * 
 * @author kb629p
 */
public class CycleCalendarLoadDAO {
	
	private Logger logger = Logger.getLogger(CycleCalendarLoadDAO.class);
	
	/**
	 * Insert West File data in AUDINV_CYCLE table.
	 * 
	 * To Avoid duplication of records, firstly data is deleted from table according to PROC_DT column and then whole file data is inserted.
	 * 
	 *  @return DB insert status
	 * */
	public boolean recordInsertion(Connection connection, List<CycleCalendarData> recordList) {
		boolean success = true;
		String deleteQuery = null;
		String insertQuery = null;
		CycleCalendarData cycleCalData = null;
		PreparedStatement delPrepStmt = null;
		PreparedStatement insPrepStmt = null;

		try {
			deleteQuery= "delete from AUDINV_CYCLE WHERE PROC_DT >= to_date(?,'mm/dd/yyyy')";
			insertQuery = "insert into AUDINV_CYCLE(CYCLE, BILL_RND, PROC_DT, BILL_RND_DT) values(to_number(?), to_number(?), to_date(?,'mm/dd/yyyy'), to_date(?,'mm/dd/yyyy'))";
			delPrepStmt = connection.prepareStatement(deleteQuery);
			insPrepStmt = connection.prepareStatement(insertQuery);
			
			CycleCalendarData cycleCalendarData = recordList.get(0); 
			String firstDate = cycleCalendarData.getProcDate();
			delPrepStmt.setString(1, firstDate);
			delPrepStmt.executeUpdate();
			
			for(int i=0;i<recordList.size();i++) {
				cycleCalData = recordList.get(i);
				insPrepStmt.setString(1, cycleCalData.getCycle());
				insPrepStmt.setString(2, cycleCalData.getBillRound());
				insPrepStmt.setString(3, cycleCalData.getProcDate());
				insPrepStmt.setString(4, cycleCalData.getBillRoundDate());
				insPrepStmt.addBatch();
				if(i%1000 == 0) 
					insPrepStmt.executeBatch();
			}
			insPrepStmt.executeBatch();
		} catch (SQLException sqlErr) {
			 logger.error("Error while insertion of CYCLE CALENDAR Records:"+sqlErr);
			 success = false;
		} finally {
			JDBCUtil.closeStatement(delPrepStmt);
			JDBCUtil.closeStatement(insPrepStmt);			
		}  
		return success;
	}

}
