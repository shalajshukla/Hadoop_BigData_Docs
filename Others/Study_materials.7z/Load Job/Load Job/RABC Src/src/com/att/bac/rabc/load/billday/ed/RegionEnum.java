package com.att.bac.rabc.load.billday.ed;

public enum RegionEnum {
	MW, 
	SW,
	W;
}
