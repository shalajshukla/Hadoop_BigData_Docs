/* Component Name: RABCPPG00596
 * Module Name: CntrlPtCertComment.java
 * Created on Mar 20, 2006
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.cntrlptcert;

import java.util.Date;

import com.att.bac.rabc.HashCodeUtil;

/**This is a transfer object for the view.  It contains data from the table and the 
 * CntrlPtCertService.java class populates it into the form.
 * 
 * @author ml2195
 */
public class CntrlPtCertView {
	private int    certNum;
	private String runDate;
	private String stateDesc;
	private String process;
	private String certInd;
	private String issueInd;
	private String savedUserID;
	private double creditRevImpact;
	private double debitRevImpact;
	private double lostRevImpact;
	private Date   timeStamp;
	private String selectedRegion;
	private String regionAccess;

	/**
	 * class constructor
	 */
	public CntrlPtCertView()
	{
		certNum = 0;
		runDate = "";
		stateDesc= "";
		process = "";
		certInd = "";
		issueInd = "";
		savedUserID = "";
		creditRevImpact = 0;
		debitRevImpact = 0;
		lostRevImpact = 0;
		timeStamp = new Date();	
	}
	
	/**
	 * @return Returns the CertNum.
	 */
	public int getCertNum() {
		return certNum;
	}
	
	/**
	 * @return Returns the RunDate.
	 */
	public String getRunDate() {
		return runDate;
	}
	
	/**
	 * @return Returns the Division.
	 */
	public String getStateDesc() {
		return stateDesc;
	}
	
	/**
	 * @return Returns the Process.
	 */
	public String getProcess() {
		return process;
	}
	
	/**
	 * @return Returns the CertInd.
	 */
	public String getCertInd() {
		return certInd;
	}
	
	/**
	 * @return Returns the IssueInd.
	 */
	public String getIssueInd() {
		return issueInd;
	}
	
	/**
	 * @return Returns the UserId.
	 */
	public String getSavedUserID() {
		return savedUserID;
	}
	
	/**
	 * @return Returns the CreditRevImpact.
	 */
	public double getCreditRevImpact() {
		return creditRevImpact;
	}
	
	/**
	 * @return Returns the DebitRevImpact.
	 */
	public double getDebitRevImpact() {
		return debitRevImpact;
	}
	
	/**
	 * @return Returns the IssueLostRevenue.
	 */
	public double getLostRevImpact() {
		return lostRevImpact;
	}
	
	/**
	 * @return Returns the TimeStamp.
	 */
	public Date getTimeStamp() {
		return timeStamp;		
	}

	/**
	 * @param Set CertNum
	 */
	public void setCertNum(int certNum) {
		this.certNum = certNum;
	}
	
	/**
	 * @param Set RunDate
	 */
	public void setRunDate(String runDate) {
		this.runDate = runDate;
	}
	
	/**
	 * @param Set Division
	 */
	public void setStateDesc(String stateDesc) {
		this.stateDesc = stateDesc;
	}
	
	/**
	 * @param Set Process
	 */
	public void setProcess(String process) {
		this.process = process;
	}
	
	/**
	 * @param Set CertInd
	 */
	public void setCertInd(String certInd) {
		this.certInd = certInd;
	}
	
	/**
	 * @param Set IssueInd 
	 */
	public void setIssueInd(String issueInd) {
		this.issueInd = issueInd;
	}
	
	/**
	 * @param Set UserId
	 */
	public void setSavedUserID(String userID) {
		this.savedUserID = userID;
	}
	
	/**
	 * @param Set CreditRevImpact
	 */
	public void setCreditRevImpact(double creditRevImpact) {
		this.creditRevImpact = creditRevImpact;
	}
	/**
	 * @param Set DebitRevImpact 
	 */
	public void setDebitRevImpact(double debitRevImpact) {
		this.debitRevImpact = debitRevImpact;
	}
	
	/**
	 * @param Set LostRevImpact
	 */
	public void setLostRevImpact(double lostRevImpact) {
		this.lostRevImpact = lostRevImpact;
	}
	
	/**
	 * @param Set TimeStamp 
	 */
	public void setTimeStamp(Date timeStamp) {
		this.timeStamp = timeStamp;
	}
	/**
	 * @return Returns the selectedRegion.
	 */
	public String getSelectedRegion() {
		return selectedRegion;
	}
	/**
	 * @param selectedRegion The selectedRegion to set.
	 */
	public void setSelectedRegion(String selectedRegion) {
		this.selectedRegion = selectedRegion;
	}
	
	/**
	 * Equals method overridden for this object so that it can be stored in a hash map where the key 
	 * would be combination of the following 4 attributes:
	 * Region
	 * Run date
	 * State
	 * Process
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object o) {
		// Do a quick check for an identical object reference
	    if (this == o) {
	      return true;
	    }
	    if (!(o instanceof CntrlPtCertView)) {
	    	return false;
	    } else {
			if (((CntrlPtCertView)o).getRunDate() == this.getRunDate()
				&& ((CntrlPtCertView)o).getSelectedRegion().equalsIgnoreCase(this.getSelectedRegion())
				&& ((CntrlPtCertView)o).getStateDesc().equalsIgnoreCase(this.getStateDesc())	
				&& ((CntrlPtCertView)o).getProcess().equalsIgnoreCase(this.getProcess())
				) {
				return true;
			} else {
				return false;
			}
	    }
	}
	
	/**
	 * Hash code method overridden for this object to categorize this object in sets 
	 * so that the hash collections can search this object efficiently.
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		int hashCode = HashCodeUtil.SEED;
		hashCode = HashCodeUtil.hash( hashCode, this.getSelectedRegion());
		hashCode = HashCodeUtil.hash( hashCode, this.getRunDate());
		hashCode = HashCodeUtil.hash( hashCode, this.getStateDesc());
		hashCode = HashCodeUtil.hash( hashCode, this.getProcess());
	    return hashCode;
	}

	/**
	 * @return the regionAccess
	 */
	public String getRegionAccess() {
		return regionAccess;
	}

	/**
	 * @param regionAccess the regionAccess to set
	 */
	public void setRegionAccess(String regionAccess) {
		this.regionAccess = regionAccess;
	}
}
