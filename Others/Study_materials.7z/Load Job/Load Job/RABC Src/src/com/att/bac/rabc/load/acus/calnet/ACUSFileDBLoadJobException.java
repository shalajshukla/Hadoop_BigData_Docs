package com.att.bac.rabc.load.acus.calnet;

public class ACUSFileDBLoadJobException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5392413331733431594L;

	public ACUSFileDBLoadJobException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ACUSFileDBLoadJobException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ACUSFileDBLoadJobException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public ACUSFileDBLoadJobException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
