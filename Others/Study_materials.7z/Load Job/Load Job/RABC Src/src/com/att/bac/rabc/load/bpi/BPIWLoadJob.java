/*
 * Created on Feb 3, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.att.bac.rabc.load.bpi;

import java.io.File;
import java.net.UnknownHostException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.StringTokenizer;

import com.att.bac.rabc.util.EmcisEventLogger;
import com.att.bac.util.NetUtil;
import com.sbc.bac.rabc.load.FilePatternLoadJob;
import com.sbc.bac.rabc.load.PrepareTableForRerun;
import com.sbc.bac.rabc.load.RabcLoadJobTrig;
import com.sbc.bac.rabc.load.RetrieveStaticInfo;
import com.sbc.bac.rabc.load.StaticErrorMsgKeys;
import com.sbc.bac.rabc.load.StaticFieldKeys;

/**
 * @author pt6471
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class BPIWLoadJob extends FilePatternLoadJob {
	// private static final String FILEPATTERN = "WE.[CI].C[0-9][0-9]*.XT20BPIB.*";    
	 
	 private PreparedStatement insert_xt20bpib;
	 private String division, region, bill_rnd, bill_rnd_dt, run_date, div, fileName, fileToken;
	 
	 private String backoutRecovery = null;
	 
	 private HashMap crocd_division;
	 
	 
	 private File currentFile;
	 
	 private String saveOrderType;
	
	 private int cycle, lineCount;
	 
	 private java.sql.Date sqlrun_date;
	 
	 private boolean nevadaBellData, billdayFile;
	 
	public boolean preprocess() {
		super.preprocess();

		try {
			StringBuffer sql = new StringBuffer();
			sql.append("  insert into RABC_BPI_ACCT_BLG (DIVISION, RUN_DATE, TCC_ID, BTN, CUR_BLG_AMT, ADJUST_AMT, BLG_MM, BLG_YEAR, BILL_RND) ");
			sql.append("  VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?) ");
			insert_xt20bpib = connection.prepareStatement(sql.toString());
			sql.setLength(0);
			
		} catch (SQLException e) {
			severe(StaticErrorMsgKeys.PREPROCESS_ERROR + e.getMessage());
			return false;
		}
		return true;
	}

	public boolean preprocessFile(File file) {
		boolean success = super.preprocessFile(file);
		fileName = file.getName();
		fileToken = file.getName().substring(file.getName().indexOf("XT20BPIB"),file.getName().indexOf("XT20BPIB")+ 8);
		
		nevadaBellData = false;
		billdayFile = true;
		
		if (success) {
			try {
				region   =	file.getName().substring(0,2);
				
				if 	(file.getName().charAt(3) == StaticFieldKeys.C)	
				  division = StaticFieldKeys.PACBELLNORTH;
				else if (file.getName().charAt(3) == StaticFieldKeys.I)	
				  division = StaticFieldKeys.PACBELLSOUTH;
				else 
					return false;
				
				cycle = Integer.parseInt(file.getName().substring(6, 10));
				
				run_date = RetrieveStaticInfo.getProc_dtByCycle(connection, cycle);
				bill_rnd_dt = RetrieveStaticInfo.getbillRndDt_ByCycle(connection, cycle);
				if (run_date.equals(StaticFieldKeys.ZERO)){
					severe(StaticErrorMsgKeys.NORECORD_RABC_CYCLE_CALENDAR + cycle);
					throw new Exception();	
				}
				
				
				DateFormat df = new SimpleDateFormat("MMddyyyy");
				sqlrun_date = new java.sql.Date(df.parse(run_date).getTime());

				lineCount = 0;
				
				String tableNm = "RABC_BPI_ACCT_BLG";
				backoutRecovery = null;

				if (RabcLoadJobTrig.IsFileLoaded(connection, file)) {
					backoutRecovery = "Y";
					success = PrepareTableForRerun.deleteTableData(connection,tableNm,division,sqlrun_date);
					//	Both divisions NB (NEVADABELL) and PN (PACBELLNORTH) come from same file!!
					if (division == StaticFieldKeys.PACBELLNORTH)
					 	success = PrepareTableForRerun.deleteTableData(connection,tableNm,StaticFieldKeys.NEVADABELL,sqlrun_date);
				}


				
			} catch (Exception e) {
				severe(
					StaticErrorMsgKeys.PREPROCESSFILE_ERROR
						+ StaticErrorMsgKeys.FILE_NAME_PARSING_ERROR
						+ e);
				return false;
			}
		}

		try {
			crocd_division  = RetrieveStaticInfo.getCrocd_Divsion(connection,region.trim());
			
			bill_rnd = RetrieveStaticInfo.getBillRndByCycle(connection, cycle);
			if (bill_rnd.equals(StaticFieldKeys.ZERO) || bill_rnd.equals(StaticFieldKeys.ZERO2)){
			 //severe(StaticErrorMsgKeys.PREPROCESSFILE_ERROR+":No Bill Round");
			 //return false;
				billdayFile = false;
			}

		} catch (SQLException e) {
			success = false;
			severe(StaticErrorMsgKeys.PREPROCESSFILE_ERROR + e.getMessage());
		}

		currentFile = file;
		return success;
	}

	
	
	public int parseLine(String line) throws Exception {
		boolean status;

		status = process20XTDOCC(line);
		
		return SUCCESS;
	}
	
	
	private boolean process20XTDOCC (String line) throws Exception {
		
		lineCount++;
		
		StringTokenizer DataLine = new StringTokenizer(line, StaticFieldKeys.SEMICOLON);
		String recordId		 = DataLine.nextToken().trim();
		String btnCCGrp 	 = DataLine.nextToken().trim();
		String tccID		 = DataLine.nextToken().trim();
		String croCode		 = DataLine.nextToken().trim();
		String blankVal		 = DataLine.nextToken().trim();
		double currBillingAmt = Double.parseDouble(DataLine.nextToken().trim())/1000000;  // devide by 1000000, since Mainframe data V999999 position ..
		double adjAmt	  	 = Double.parseDouble(DataLine.nextToken().trim())/1000000;
		
		String div  = (String) crocd_division.get(croCode);
		
		if (div == null){
	          severe(StaticErrorMsgKeys.NORECORD_RABC_CRO_CD_DIVISION + croCode);
			  throw new Exception(" No CRO CODE MATCH in job BPIWLoadJob");	
			}else if ( div.equals(StaticFieldKeys.NEVADABELL)) {
				nevadaBellData = true;
			}
		
		try {
			insert_xt20bpib.setString(1,div);		
			insert_xt20bpib.setDate(2,sqlrun_date);
			insert_xt20bpib.setString(3,tccID);
			insert_xt20bpib.setString(4,btnCCGrp);
			insert_xt20bpib.setDouble(5,currBillingAmt);
			insert_xt20bpib.setDouble(6,adjAmt);
			insert_xt20bpib.setString(7,bill_rnd_dt.substring(0,2));
			insert_xt20bpib.setString(8,bill_rnd_dt.substring(4,8));
			insert_xt20bpib.setInt(9,Integer.parseInt(bill_rnd));
			
			insert_xt20bpib.addBatch();
			
			if (lineCount % 1000 == 0){
				insert_xt20bpib.executeBatch();
			}
			
			
		}catch (SQLException sqle){
			severe(StaticErrorMsgKeys.INSERT_ERROR + sqle.getMessage());
			 throw new Exception("Exception is from method process20XTDOCC");
		}
		
		return true;
	}
	
		
	
	
	public boolean postprocessFile(File file, boolean success) {
		try{
			//Log the file information to EMCIS_EVENT_LOG and EMCIS_EVENT_LOG_DETAIL
			EmcisEventLogger emcisLogger = new EmcisEventLogger();
			String event_id = "RABC_"+fileToken+"_"+region;
            String host = NetUtil.getLocalHostName();
            String hostIP = NetUtil.getLocalIpAddress();
			int sequence = emcisLogger.getEMCISSequence(connection);
			emcisLogger.insertEventLog(connection, sequence, event_id, sqlrun_date, host, hostIP);
			emcisLogger.insertEventLogDetail(connection, sequence, "FileName", fileName);
			
		}catch (UnknownHostException e) {
            severe("Error getting EMCIS host information ", e);
        }

		if (success) {

			try {
				insert_xt20bpib.executeBatch();
		
				if (billdayFile)
				if (!insertTrigger()) {
					severe(
						StaticErrorMsgKeys.POSTPROCESSFILE_ERROR
							+ StaticErrorMsgKeys.TIGGER_TABLE_INSERT_ERROR);
					success = false;
				}
				
			}catch (SQLException sqle){
				severe(StaticErrorMsgKeys.INSERT_ERROR + sqle.getMessage());
				success = false;
			}
			
			}
		return super.postprocessFile(file, success);
	}

	
	public boolean postprocess(boolean success) {

		try {
			
			insert_xt20bpib.close();
		
		} catch (SQLException e) {
			severe(
				StaticErrorMsgKeys.POSTPROCESS_ERROR
					+ StaticErrorMsgKeys.SQL_CLOSE_ERROR
					+ e);
			success = false;
		}

		return super.postprocess(success);
	}

	private boolean insertTrigger() {

		 if(!RabcLoadJobTrig.insertTrigger(connection,currentFile.getName(),"XT20BPIB",division,run_date, backoutRecovery,bill_rnd))
			return false;	
		 
		 if (nevadaBellData)
		 	if(!RabcLoadJobTrig.insertTrigger(connection,currentFile.getName(),"XT20BPIB","NB",run_date, backoutRecovery,bill_rnd))
				return false;
		 
		return true;
		
	}
	
	
}
