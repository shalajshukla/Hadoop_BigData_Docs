package com.att.bac.rabc.adhoc.rpt;

import java.util.ArrayList;

import com.att.bac.rabc.SortedForm;

public class AdhocBackgroundReportDetailsForm extends SortedForm{

	private static final long serialVersionUID = 6130279808528296579L;
	private String reportName;
	private ArrayList<String> columnNamesList = new ArrayList<String>();
	private ArrayList<String> columnValuesList = new ArrayList<String>();
	private String notes;
	
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public String getReportName() {
		return reportName;
	}
	public void setReportName(String reportName) {
		this.reportName = reportName;
	}
	public ArrayList<String> getColumnNamesList() {
		return columnNamesList;
	}
	public void setColumnNamesList(ArrayList<String> columnNamesList) {
		this.columnNamesList = columnNamesList;
	}
	public ArrayList<String> getColumnValuesList() {
		return columnValuesList;
	}
	public void setColumnValuesList(ArrayList<String> columnValuesList) {
		this.columnValuesList = columnValuesList;
	}
	  
}
