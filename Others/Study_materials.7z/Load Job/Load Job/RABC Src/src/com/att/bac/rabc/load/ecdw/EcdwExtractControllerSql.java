/*------------------------------------------------------------------------------
Modification History
� 2002-2011 AT&T Intellectual Property. All rights reserved.
Date		Version		Author			Description
----------	-----------	--------------- ----------------------------------------
12-02-2010	0.1			ss1644			initial Draft
------------------------------------------------------------------------------*/
package com.att.bac.rabc.load.ecdw;
//------------------------------------------------------------------------------
/**
 * The interface to contain the extraction queries for MID 20610,20615,
 * 20620 and 20625
 */
public interface EcdwExtractControllerSql {
	
	//--------------------------------------------------------------------------
	/**
	 * query to extract the data from eCDW for MID 20620
	 */
	public static String 
				GET_MD20620_DATA = "Select "+
									"'20620' as mid,  "+
									"current_date (FORMAT 'YYYYMMDD') (char (8)) as run_id,  "+
									"'EDW' as pe,  "+
									"'EW' as leg,  "+
									"SUBSTR(CAST(CAST(current_date - (DATE '2009-01-01') AS INTEGER FORMAT '999999') as char(6)),5,2) as run_seq_nbr,  "+
									"a.src_bl_stmnt_id as bill_statement_id,   "+
									"a.acct_id as bill_arrangement_id,   "+
									"a.doc_id as document_id,   "+
									"a.src_bl_inv_id as bill_invoice_id,   "+
									"a.bl_stmnt_create_dt as bill_stmnt_created_dt,  "+
									"a.bl_pmt_due_dt as bill_payment_due_dt,  "+
									"a.leg_inv_nbr as legal_invoice_nbr,  "+
									"a.bl_cyc_dt as cycle_seq_nbr,  "+
									"a.rebl_run_bl_cnt as rebill_run_count,   "+
									"TRIM(a.amt_due_hndl_cd) as amount_due_handling_cd,  "+
									"TRIM(a.bl_pmt_mthd_cd) as payment_method_cd,   "+
									"a.prev_bal_amt as previous_balance_amt,  "+
									"a.tot_actvt_amt as tot_finance_activity_amt,  "+
									"a.tot_due_amt,  "+
									"a.src_crtn_dt_tm	(char(19)) as creation_ts,   "+
									"a.updt_dt_tm 	(char(19)) as last_update_ts,   "+
									"a.load_dt_tm (char(19)) as dw_load_ts,   "+
									"b.inv_prd_covrg_start_dt (char(10)) as invc_prod_cov_strt_dt,   "+
									"b.inv_prd_covrg_end_dt (char(10)) as invc_prod_cov_end_dt,   "+
									"b.bl_inv_type_cd as billing_invc_type_cd,    "+
									"b.tax_itmzd_ind as tax_itemized_ind,   "+
									"b.crnc_type_cd as currency_type_cd,  "+
									"b.tot_inv_amt as total_invc_amt,   "+
									"b.tot_tax_inv_amt as total_tax_invc_amt,   "+
									"b.lst_updt_dt_tm (char(19)) as invoice_last_update_ts,  "+
									"d.acct_nbr as customer_id,   "+
									"j.bl_cyc_cd as bill_cycle_cd,  "+
									"d.load_dt_tm (char(19)) as cust_load_ts,   "+
									"f.loc_addr_stprov_cd as account_state_cd   "+
									"from  "+
									"EDWVIEWS.bl_stmnt_ltsp a,   "+
									"EDWVIEWS.bl_inv_ltsp b,   "+
									"EDWVIEWS.acct_non_wirls_extd c,   "+
									"EDWAFFLVIEWS.vacct_non_wirls d,   "+
									"EDWVIEWS.ACCT_ADDR_HIST e,   "+
									"EDWVIEWS.loc_addr f,    "+
									"EDWVIEWS.acct_subsrptn_trans g,  "+
									"EDWAFFLVIEWS.vsubsrptn_non_wirls h,   "+
									"EDWVIEWS.subsrptn_type_avt i,  "+
									"EDWVIEWS.bl_cyc_avt j   "+
									"where  "+
									"a.bl_cyc_id = b.bl_cyc_id and   "+
									"a.acct_id = b.acct_id and   "+
									"b.acct_id = c.acct_id and   "+
									"c.acct_id = d.acct_id and   "+
									"d.acct_id = e.acct_id and  "+
									"e.addr_id = f.addr_id and  "+
									"d.acct_id =g.acct_id and  "+
									"g.srv_accs_id = h.srv_accs_id and  "+
									"h.subsrptn_type_cd  = i.subsrptn_type_cd and  "+
									"j.bl_cyc_id =a.bl_cyc_id and  "+
									"e.NM_ADDR_ROL_CD = 'bn' and  "+
									"i.subsrptn_type_titl in ('C1','C2') and   "+
									"i.bill_sys_geo_id ='24' and  "+
									"a.load_dt_tm = current_date - 7  "+
									"group by  6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34  "
									
	;
	//--------------------------------------------------------------------------
	/**
	 * query to extract the data from eCDW for MID 20620
	 */
	public static String 
				GET_MD20620_CONTROL = "select  "+
									"'C' as ctrl,  "+
									"'20620' as mid,  "+
									"current_date (FORMAT 'YYYYMMDD') (char (8)) as run_id,  "+
									"'EDW' as pe,  "+
									"'EW' as leg,  "+
									"SUBSTR(CAST(CAST( current_date - (DATE '2009-01-01') AS INTEGER FORMAT '999999') as char(6)),5,2) as run_seq_nbr,  "+
									"CAST(CAST( current_date - (DATE '2009-01-01') AS INTEGER FORMAT '999999') as char(6)) as seq_nbr,  "+
									"null,   "+
									"null,   "+
									"null,   "+
									"null,   "+
									"null,   "+
									"null,   "+
									"null,   "+
									"null,   "+
									"null,   "+
									"'',   "+
									"'',   "+
									"null,   "+
									"null,   "+
									"null,   "+
									"'',   "+
									"'',   "+
									"'',   "+
									"'',   "+
									"'',   "+
									"'',   "+
									"'',   "+
									"'',   "+
									"null,   "+
									"null,   "+
									"'',   "+
									"'',   "+
									"'',   "+
									"'',   "+
									"'',   "+
									"count(*) from (   "+
									"select  "+
									"a.src_bl_stmnt_id as bill_statement_id,   "+
									"a.acct_id as bill_arrangement_id,   "+
									"a.doc_id as document_id,   "+
									"a.src_bl_inv_id as bill_invoice_id,   "+
									"a.bl_stmnt_create_dt as bill_stmnt_created_dt,  "+
									"a.bl_pmt_due_dt as bill_payment_due_dt,  "+
									"a.leg_inv_nbr as legal_invoice_nbr,  "+
									"a.bl_cyc_dt as cycle_seq_nbr,  "+
									"a.rebl_run_bl_cnt as rebill_run_count,   "+
									"a.amt_due_hndl_cd as amount_due_handling_cd,  "+
									"a.bl_pmt_mthd_cd as payment_method_cd,   "+
									"a.prev_bal_amt as previous_balance_amt,  "+
									"a.tot_actvt_amt as tot_finance_activity_amt,  "+
									"a.tot_due_amt,  "+
									"a.src_crtn_dt_tm	(char(19)) as creation_ts,   "+
									"a.updt_dt_tm 	(char(19)) as last_update_ts,   "+
									"a.load_dt_tm (char(19)) as dw_load_ts,   "+
									"b.inv_prd_covrg_start_dt (char(10)) as invc_prod_cov_strt_dt,   "+
									"b.inv_prd_covrg_end_dt (char(10)) as invc_prod_cov_end_dt,   "+
									"b.bl_inv_type_cd as billing_invc_type_cd,    "+
									"b.tax_itmzd_ind as tax_itemized_ind,   "+
									"b.crnc_type_cd as currency_type_cd,  "+
									"b.tot_inv_amt as total_invc_amt,   "+
									"b.tot_tax_inv_amt as total_tax_invc_amt,   "+
									"b.lst_updt_dt_tm (char(19)) as invoice_last_update_ts,  "+
									"d.acct_nbr as customer_id,   "+
									"j.bl_cyc_cd as bill_cycle_cd,  "+
									"d.load_dt_tm (char(19)) as cust_load_ts,   "+
									"f.loc_addr_stprov_cd as account_state_cd  "+
									"from  "+
									"EDWVIEWS.bl_stmnt_ltsp a,   "+
									"EDWVIEWS.bl_inv_ltsp b,   "+
									"EDWVIEWS.acct_non_wirls_extd c,   "+
									"EDWAFFLVIEWS.vacct_non_wirls d,   "+
									"EDWVIEWS.ACCT_ADDR_HIST e,   "+
									"EDWVIEWS.loc_addr f,    "+
									"EDWVIEWS.acct_subsrptn_trans g,  "+
									"EDWAFFLVIEWS.vsubsrptn_non_wirls h,   "+
									"EDWVIEWS.subsrptn_type_avt i,  "+
									"EDWVIEWS.bl_cyc_avt j   "+
									"where  "+
									"a.bl_cyc_id = b.bl_cyc_id and   "+
									"a.acct_id = b.acct_id and   "+
									"b.acct_id = c.acct_id and   "+
									"c.acct_id = d.acct_id and   "+
									"d.acct_id = e.acct_id and  "+
									"e.addr_id = f.addr_id and  "+
									"d.acct_id =g.acct_id and  "+
									"g.srv_accs_id = h.srv_accs_id and  "+
									"h.subsrptn_type_cd  = i.subsrptn_type_cd and  "+
									"j.bl_cyc_id =a.bl_cyc_id and  "+
									"e.NM_ADDR_ROL_CD = 'bn' and  "+
									"i.subsrptn_type_titl in ('C1','C2') and   "+
									"i.bill_sys_geo_id ='24' and  "+
									"a.load_dt_tm = current_date - 7  "+
									"group by  1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29  "+
									") as \"Count\"  "
	;
	//--------------------------------------------------------------------------
	/**
	 * query to extract the data from eCDW for MID 20610
	 */
	public static String 
		GET_MD20610_DATA 		= 	"select  " +
									"'20610' as mid,  "+
									"current_date (FORMAT 'YYYYMMDD') (char (8)) as run_id,  "+
									"'BID' as pe,  "+
									"'EW' as leg,  "+
									"SUBSTR(CAST(CAST( current_date - (DATE '2009-01-01') AS INTEGER FORMAT '999999') as char(6)),5,2) as run_seq_nbr,  "+
									"a.acct_id,  "+
									"a.bill_mkt_geo_id,  "+
									"a.acct_nbr,  "+
									"a.curr_acct_sts_cd,  "+
									"a.rvnu_acctg_offc_nbr,  "+
									"a.fcly_lble_mobl_nbr,  "+
									"a.lblty_type_cd,  "+
									"a.uvrs_ind,  "+
									"a.uvrs_enrlmt_dt,  "+
									"a.acct_type_cd,  "+
									"a.acct_sub_type_cd,  "+
									"a.ent_acct_type_cd,  "+
									"a.ent_curr_acct_sts_cd,  "+
									"a.actv_mobl_qnty,  "+
									"a.acct_orgnl_srv_dt,  "+
									"a.bus_size_cd,  "+
									"a.bus_type_cd,  "+
									"a.zero_bal_ind,  "+
									"a.bl_media_cd,  "+
									"a.enblr_ind,  "+
									"a.load_dt_ts	(char(19)),  "+
									"a.updt_dt_ts	(char(19)),  "+
									"b.ldlne_lblty_nbr,  "+
									"b.cmbnd_acct_eff_dt,  "+
									"b.ldlne_seq_nbr,  "+
									"b.ldlne_btn,  "+
									"b.ldlne_cust_cd,  "+
									"b.actvtn_dt,  "+
									"b.cmbnd_acct_sts_cd,  "+
									"CASE  "+
									"  WHEN b.cmbnd_acct_end_dt = (DATE '9999-12-31') THEN NULL  "+
									"  ELSE b.cmbnd_acct_end_dt  "+
									"  END as combined_acct_end_dt,  "+
									"b.bus_resd_cd,  "+
									"b.cmbnd_acct_sts_rsn_cd,  "+
									"b.dry_loop_ind,  "+
									"b.ldlne_bus_cnsmr_cd,  "+
									"b.ldlne_bl_period,  "+
									"b.corp_blng_nbr  "+
									"from  "+
									"edwviews.acct a,  "+
									"edwviews.cmbnd_acct_hist b  "+
									"where  "+
									"a.bill_sys_geo_id=2 and  "+
									"a.acct_id=b.acct_id and  "+
									"/*a.load_dt_ts >= TIMESTAMP '2009-11-13 00:00:00' and  "+
									"a.load_dt_ts < TIMESTAMP '2009-11-14 00:00:00'*/  "+
									"/* a.load_dt_ts > date '2010-03-02' and */  "+
									"a.load_dt_ts = current_date - 7    "

	;
	//--------------------------------------------------------------------------
	/**
	 * query to extract the data from eCDW for MID 20610
	 */
	public static String 
		GET_MD20610_CONTROL 	= 	"select  "+
									"'C' as ctrl,  "+
									"'20610' as mid,  "+
									"current_date (FORMAT 'YYYYMMDD') (char (8)) as run_id,  "+
									"'BID' as pe,  "+
									"'EW' as leg,  "+
									"SUBSTR(CAST(CAST( current_date - (DATE '2009-01-01') AS INTEGER FORMAT '999999') as char(6)),5,2) as run_seq_nbr,  "+
									"CAST(CAST( current_date - (DATE '2009-01-01') AS INTEGER FORMAT '999999') as char(6)) as seq_nbr,  "+
									"null, null, '', '', '', null, '', '', null, '',  "+
									"'', '', '', null, null, '', '', '', '', '',  "+
									"'', '', '', null, null, '', '', null, '', null,  "+
									"'', '', '', '', '', '',  "+
									"count(*) from ( select  "+
									"a.acct_id,  "+
									"a.bill_mkt_geo_id,  "+
									"a.acct_nbr,  "+
									"a.curr_acct_sts_cd,  "+
									"a.rvnu_acctg_offc_nbr,  "+
									"a.fcly_lble_mobl_nbr,  "+
									"a.lblty_type_cd,  "+
									"a.uvrs_ind,  "+
									"a.uvrs_enrlmt_dt,  "+
									"a.acct_type_cd,  "+
									"a.acct_sub_type_cd,  "+
									"a.ent_acct_type_cd,  "+
									"a.ent_curr_acct_sts_cd,  "+
									"a.actv_mobl_qnty,  "+
									"a.acct_orgnl_srv_dt,  "+
									"a.bus_size_cd,  "+
									"a.bus_type_cd,  "+
									"a.zero_bal_ind,  "+
									"a.bl_media_cd,  "+
									"a.enblr_ind,  "+
									"a.load_dt_ts	(char(19)),  "+
									"a.updt_dt_ts	(char(19)),  "+
									"b.ldlne_lblty_nbr,  "+
									"b.cmbnd_acct_eff_dt,  "+
									"b.ldlne_seq_nbr,  "+
									"b.ldlne_btn,  "+
									"b.ldlne_cust_cd,  "+
									"b.actvtn_dt,  "+
									"b.cmbnd_acct_sts_cd,  "+
									"b.bus_resd_cd,  "+
									"b.cmbnd_acct_sts_rsn_cd,  "+
									"b.dry_loop_ind,  "+
									"b.ldlne_bus_cnsmr_cd,  "+
									"b.ldlne_bl_period,  "+
									"b.corp_blng_nbr  "+
									"from  "+
									"edwviews.acct a,  "+
									"edwviews.cmbnd_acct_hist b  "+
									"where  "+
									"a.bill_sys_geo_id=2 and  "+
									"a.acct_id=b.acct_id and  "+
									" /* a.load_dt_ts > date '2010-03-02' and */  "+
									"a.load_dt_ts = current_date - 7   "+
									" ) as \"Count\"  "
	;
	//--------------------------------------------------------------------------
	/**
	 * query to extract the data from eCDW for MID 20615
	 */
	public static String 
		GET_MD20615_DATA 		= 	"select  "+
									"'20615' as mid,  "+
									"current_date (FORMAT 'YYYYMMDD') (char (8)) as run_id,  "+
									"'BID' as pe,  "+
									"'EW' as leg,  "+
									"SUBSTR(CAST(CAST( current_date - (DATE '2009-01-01') AS INTEGER FORMAT '999999') as char(6)),5,2) as run_seq_nbr,  "+
									"a.acct_id,  "+
									"a.bl_cyc_dt,  "+
									"a.bill_mkt_geo_id,  "+
									"a.bl_confirm_ind,  "+
									"a.bl_confirm_dt,  "+
									"a.bl_cyc_id,  "+
									"a.tot_bal_due_amt,  "+
									"b.acct_type_cd,  "+
									"b.uvrs_ind,  "+
									"b.acct_nbr,  "+
									"b.curr_acct_sts_cd,  "+
									"b.updt_dt_d,  "+
									"c.ldlne_lblty_nbr,  "+
									"c.ldlne_btn,  "+
									"c.ldlne_cust_cd,  "+
									"c.cmbnd_acct_eff_dt,  "+
									"c.actvtn_dt,  "+
									"c.cmbnd_acct_sts_cd,  "+
									"TRIM(g.bl_cyc_cd),  "+
									"TRIM(g.bl_cyc_clos_day),  "+
									"CASE WHEN c.cmbnd_acct_end_dt = (DATE '9999-12-31') THEN NULL   "+
									"ELSE c.cmbnd_acct_end_dt   "+
									"END as combined_acct_end_dt  "+
									"from edwviews.bl_stmnt a,  "+
									"edwviews.acct b,  "+
									"edwviews.cmbnd_acct_hist c,  "+
									"edwviews.bl_cyc_avt g  "+
									"where a.bl_cyc_id = g.bl_cyc_id   "+
									"and a.bill_mkt_geo_id = g.bill_mkt_geo_id   "+
									"and a.acct_id = b.acct_id   "+
									"and a.acct_id = c.acct_id   "+
									"and (c.cmbnd_acct_eff_dt<= a.bl_cyc_dt and a.bl_cyc_dt <= c.cmbnd_acct_end_dt)   "+
									"and a.bl_cyc_dt = current_date - 7    "
	;
	//--------------------------------------------------------------------------
	/**
	 * query to extract the data from eCDW for MID 20615
	 */
	public static String 
		GET_MD20615_CONTROL		= 	"select 'C' as ctrl,  "+
									"'20615' as mid,  "+
									"current_date (FORMAT 'YYYYMMDD') (char (8)) as run_id,  "+
									"'BID' as pe,   "+
									"'EW' as leg,  "+
									"SUBSTR(CAST(CAST( current_date - (DATE '2009-01-01') AS INTEGER FORMAT '999999') as char(6)),5,2) as run_seq_nbr,  "+
									"CAST(CAST( current_date - (DATE '2009-01-01') AS INTEGER FORMAT '999999') as char(6)) as seq_nbr,  "+
									"null, null, null, '', null, null, null, '', '', '', '', null, '', '', '', null, null, '', '','',null, "+
									"count(*) from ( select "+
									"a.acct_id,  "+
									"a.bl_cyc_dt,  "+
									"a.bill_mkt_geo_id,  "+
									"a.bl_confirm_ind,  "+
									"a.bl_confirm_dt,  "+
									"a.bl_cyc_id,  "+
									"a.tot_bal_due_amt,  "+
									"b.acct_type_cd,  "+
									"b.uvrs_ind,  "+
									"b.acct_nbr,  "+
									"b.curr_acct_sts_cd,  "+
									"b.updt_dt_d,  "+
									"c.ldlne_lblty_nbr,  "+
									"c.ldlne_btn,  "+
									"c.ldlne_cust_cd,  "+
									"c.cmbnd_acct_eff_dt,  "+
									"c.actvtn_dt,  "+
									"c.cmbnd_acct_sts_cd,  "+
									"g.bl_cyc_cd,  "+
									"g.bl_cyc_clos_day,  "+
									"c.cmbnd_acct_end_dt   "+
									"from edwviews.bl_stmnt a,  "+
									"edwviews.acct b,  "+
									"edwviews.cmbnd_acct_hist c,  "+
									"edwviews.bl_cyc_avt g  "+
									"where a.bl_cyc_id = g.bl_cyc_id   "+
									"and a.bill_mkt_geo_id = g.bill_mkt_geo_id   "+
									"and a.acct_id = b.acct_id   "+
									"and a.acct_id = c.acct_id   "+
									"and (c.cmbnd_acct_eff_dt<= a.bl_cyc_dt and a.bl_cyc_dt <= c.cmbnd_acct_end_dt)   "+
									"and a.bl_cyc_dt = current_date - 7   "+
									") as \"Count\" "
	;
	//--------------------------------------------------------------------------
	/**
	 * query to extract the data from eCDW for MID 20625
	 */
	public static String 
		GET_MD20625_DATA		 = 	"select  "+
									"'20625' as mid,  "+
									"current_date (FORMAT 'YYYYMMDD') (char (8)) as run_id,  "+
									"'BID' as pe,  "+
									"'EW' as leg,  "+
									"SUBSTR(CAST(CAST( current_date - (DATE '2009-01-01') AS INTEGER FORMAT '999999') as char(6)),5,2) as run_seq_nbr,  "+
									"a.bl_cyc_dt,  "+
									"a.bl_cyc_id,  "+
									"TRIM(CASE  "+
									"     WHEN b.rvnu_acctg_offc_nbr in ('035','036','044','046','047','048','051','053','054','056',  "+
									"                                    '059','062','063','180','186','187','188','189','191','195',  "+
									"                                    '197','198','314','315','316','317','318','319','322','340') and  "+
									"          uvrs_ind = 'Y'  "+
									"       THEN 'SE-U'  "+
									"     WHEN b.rvnu_acctg_offc_nbr in ('035','036','044','046','047','048','051','053','054','056',  "+
									"                                    '059','062','063','180','186','187','188','189','191','195',  "+
									"                                    '197','198','314','315','316','317','318','319','322','340') and  "+
									"          uvrs_ind = 'N'  "+
									"       THEN 'SE'  "+
									"     WHEN b.rvnu_acctg_offc_nbr in ('080','082','088','090','096','098','980') and  "+
									"          uvrs_ind = 'Y'  "+
									"       THEN 'MW-U'  "+
									"     WHEN b.rvnu_acctg_offc_nbr in ('080','082','088','090','096','098','980') and  "+
									"          uvrs_ind = 'N'  "+
									"       THEN 'MW'  "+
									"     WHEN b.rvnu_acctg_offc_nbr in ('140','147','148','149','151','152','156','157','177') and  "+
									"          uvrs_ind = 'Y'  "+
									"       THEN 'SW-U'  "+
									"     WHEN b.rvnu_acctg_offc_nbr in ('140','147','148','149','151','152','156','157','177') and  "+
									"          uvrs_ind = 'N'  "+
									"       THEN 'SW'  "+
									"     WHEN b.rvnu_acctg_offc_nbr in ('066','158','159','160','164','167','182','183','184') and  "+
									"          uvrs_ind = 'Y'  "+
									"       THEN 'W-CA-U'  "+
									"     WHEN b.rvnu_acctg_offc_nbr in ('066','158','159','160','164','167','182','183','184') and  "+
									"          uvrs_ind = 'N'  "+
									"       THEN 'W-CA'  "+
									"     WHEN b.rvnu_acctg_offc_nbr in ('176') and uvrs_ind = 'Y'  "+
									"       THEN 'W-NV-U'  "+
									"     WHEN b.rvnu_acctg_offc_nbr in ('176') and uvrs_ind = 'N'  "+
									"       THEN 'W-NV'  "+
									"     WHEN b.rvnu_acctg_offc_nbr in ('020') and uvrs_ind = 'Y'  "+
									"       THEN 'East U'  "+
									"     WHEN b.rvnu_acctg_offc_nbr in ('020') and uvrs_ind = 'N'  "+
									"       THEN 'East'  "+
									"     WHEN b.rvnu_acctg_offc_nbr in ('820') and uvrs_ind = 'Y'  "+
									"       THEN 'E-WDBRY-U'  "+
									"     WHEN b.rvnu_acctg_offc_nbr in ('820') and uvrs_ind = 'N'  "+
									"       THEN 'E-WDBRY'  "+
									"     WHEN b.rvnu_acctg_offc_nbr is null and uvrs_ind = 'Y'  "+
									"       THEN 'UNSPCFD-U'  "+
									"     WHEN b.rvnu_acctg_offc_nbr is null and uvrs_ind = 'N'  "+
									"       THEN 'No RAO'  "+
									"     ELSE 'UNMAPPED'  "+
									"     END (NAMED biller_info) (CHAR (9))),  "+
									"b.uvrs_ind,  "+
									"c.bus_resd_cd,  "+
									"c.dry_loop_ind,  "+
									"e.featr_rvnu_titl,  "+
									"f.actvt_type_cd,  "+
									"TRIM(g.bl_cyc_cd),  "+
									"TRIM(g.bl_cyc_clos_day),  "+
									"sum(a.actvt_amt),  "+
									"sum(a.actvt_qty)  "+
									"from  "+
									"edwviews.bl_stmnt_actvt a  "+
									"left join edwviews.acct b  "+
									"  on a.acct_id = b.acct_id and  "+
									"     b.curr_acct_sts_cd = 'O'  "+
									"left join edwviews.cmbnd_acct_hist c  "+
									"  on b.acct_id = c.acct_id and  "+
									"     c.cmbnd_acct_sts_cd = 'A'  "+
									"inner join edwviews.featr_rvnu_cd_avt e  "+
									"  on a.featr_rvnu_id=e.featr_rvnu_id  "+
									"inner join edwviews.bl_cyc_avt g  "+
									"  on a.bl_cyc_id = g.bl_cyc_id  "+
									"  and  "+
									"  a.bill_mkt_geo_id = g.bill_mkt_geo_id  "+
									"inner join edwviews.actvt_type_avt f  "+
									"  on a.actvt_type_id=f.actvt_type_id  "+
									"where (bal_impct_cd = 'b' and  "+
									"       a.bl_confirm_ind= 'y' and  "+
									"   /*    a.bl_cyc_dt > date '2010-02-28' and */  "+
									"       a.bl_cyc_dt = current_date - 7  and   "+
									"       (c.cmbnd_acct_eff_dt <= a.bl_cyc_dt and  "+
									"        a.bl_cyc_dt <= c.cmbnd_acct_end_dt)) and  "+
									"      b.rvnu_acctg_offc_nbr is not null  "+
									"group by  "+
									"a.bl_cyc_dt,  "+
									"a.bl_cyc_id,  "+
									"e.featr_rvnu_titl,  "+
									"f.actvt_type_cd,  "+
									"c.dry_loop_ind,  "+
									"b.uvrs_ind,  "+
									"c.bus_resd_cd,  "+
									"g.bl_cyc_cd,  "+
									"g.bl_cyc_clos_day,  "+
									"biller_info,  "+
									"mid,  "+
									"run_id,  "+
									"pe,  "+
									"leg,  "+
									"run_seq_nbr  "
	;
	//--------------------------------------------------------------------------
	/**
	 * query to extract the data from eCDW for MID 20625
	 */
	public static String 
		GET_MD20625_CONTROL		 = 	"select  "+
									"'C' as ctrl,  "+
									"'20625' as mid,  "+
									"current_date (FORMAT 'YYYYMMDD') (char (8)) as run_id,  "+
									"'BID' as pe,  "+
									"'EW' as leg,  "+
									"SUBSTR(CAST(CAST( current_date - (DATE '2009-01-01') AS INTEGER FORMAT '999999') as char(6)),5,2) as run_seq_nbr,  "+
									"CAST(CAST( current_date - (DATE '2009-01-01') AS INTEGER FORMAT '999999') as char(6)) as seq_nbr,  "+
									"null, null, '', '', '', '', '', '','1','1',null, null,  "+
									"count(*) from   "+
									"(   "+
									"select  "+
									"TRIM('' (char(1))) as ctrl,  "+
									"'20625' as mid,  "+
									"current_date (FORMAT 'YYYYMMDD') (char (8)) as run_id,  "+
									"'BID' as pe,  "+
									"'EW' as leg,  "+
									"a.bl_cyc_dt,  "+
									"a.bl_cyc_id,  "+
									"TRIM(CASE  "+
									"     WHEN b.rvnu_acctg_offc_nbr in ('035','036','044','046','047','048','051','053','054','056',  "+
									"                                    '059','062','063','180','186','187','188','189','191','195',  "+
									"                                    '197','198','314','315','316','317','318','319','322','340') and  "+
									"          uvrs_ind = 'Y'  "+
									"       THEN 'SE-U'  "+
									"     WHEN b.rvnu_acctg_offc_nbr in ('035','036','044','046','047','048','051','053','054','056',  "+
									"                                    '059','062','063','180','186','187','188','189','191','195',  "+
									"                                    '197','198','314','315','316','317','318','319','322','340') and  "+
									"          uvrs_ind = 'N'  "+
									"       THEN 'SE'  "+
									"     WHEN b.rvnu_acctg_offc_nbr in ('080','082','088','090','096','098','980') and  "+
									"          uvrs_ind = 'Y'  "+
									"       THEN 'MW-U'  "+
									"     WHEN b.rvnu_acctg_offc_nbr in ('080','082','088','090','096','098','980') and  "+
									"          uvrs_ind = 'N'  "+
									"       THEN 'MW'  "+
									"     WHEN b.rvnu_acctg_offc_nbr in ('140','147','148','149','151','152','156','157','177') and  "+
									"          uvrs_ind = 'Y'  "+
									"       THEN 'SW-U'  "+
									"     WHEN b.rvnu_acctg_offc_nbr in ('140','147','148','149','151','152','156','157','177') and  "+
									"          uvrs_ind = 'N'  "+
									"       THEN 'SW'  "+
									"     WHEN b.rvnu_acctg_offc_nbr in ('066','158','159','160','164','167','182','183','184') and  "+
									"          uvrs_ind = 'Y'  "+
									"       THEN 'W-CA-U'  "+
									"     WHEN b.rvnu_acctg_offc_nbr in ('066','158','159','160','164','167','182','183','184') and  "+
									"          uvrs_ind = 'N'  "+
									"       THEN 'W-CA'  "+
									"     WHEN b.rvnu_acctg_offc_nbr in ('176') and uvrs_ind = 'Y'  "+
									"       THEN 'W-NV-U'  "+
									"     WHEN b.rvnu_acctg_offc_nbr in ('176') and uvrs_ind = 'N'  "+
									"       THEN 'W-NV'  "+
									"     WHEN b.rvnu_acctg_offc_nbr in ('020') and uvrs_ind = 'Y'  "+
									"       THEN 'East U'  "+
									"     WHEN b.rvnu_acctg_offc_nbr in ('020') and uvrs_ind = 'N'  "+
									"       THEN 'East'  "+
									"     WHEN b.rvnu_acctg_offc_nbr in ('820') and uvrs_ind = 'Y'  "+
									"       THEN 'E-WDBRY-U'  "+
									"     WHEN b.rvnu_acctg_offc_nbr in ('820') and uvrs_ind = 'N'  "+
									"       THEN 'E-WDBRY'  "+
									"     WHEN b.rvnu_acctg_offc_nbr is null and uvrs_ind = 'Y'  "+
									"       THEN 'UNSPCFD-U'  "+
									"     WHEN b.rvnu_acctg_offc_nbr is null and uvrs_ind = 'N'  "+
									"       THEN 'No RAO'  "+
									"     ELSE 'UNMAPPED'  "+
									"     END   "+
									"     (NAMED biller_info) (CHAR (9)) ) as blrinfo,  "+
									"b.uvrs_ind,  "+
									"c.bus_resd_cd,  "+
									"c.dry_loop_ind,  "+
									"e.featr_rvnu_titl,  "+
									"f.actvt_type_cd,  "+
									"g.bl_cyc_cd,  "+
									"g.bl_cyc_clos_day,  "+
									"null as \"Count\"  "+
									"from  "+
									"edwviews.bl_stmnt_actvt a  "+
									"left join edwviews.acct b  "+
									"  on a.acct_id = b.acct_id and  "+
									"     b.curr_acct_sts_cd = 'O'  "+
									"left join edwviews.cmbnd_acct_hist c  "+
									"  on b.acct_id = c.acct_id and  "+
									"     c.cmbnd_acct_sts_cd = 'A'  "+
									"inner join edwviews.featr_rvnu_cd_avt e  "+
									"  on a.featr_rvnu_id=e.featr_rvnu_id  "+
									"inner join edwviews.bl_cyc_avt g  "+
									"  on a.bl_cyc_id = g.bl_cyc_id  "+
									"  and  "+
									"  a.bill_mkt_geo_id = g.bill_mkt_geo_id  "+
									"inner join edwviews.actvt_type_avt f  "+
									"  on a.actvt_type_id=f.actvt_type_id  "+
									"where (bal_impct_cd = 'b' and  "+
									"       a.bl_confirm_ind= 'y' and  "+
									"     /*  a.bl_cyc_dt > date '2010-02-28' and */  "+
									"       a.bl_cyc_dt = current_date - 7  and  "+
									"       (c.cmbnd_acct_eff_dt<= a.bl_cyc_dt and  "+
									"        a.bl_cyc_dt <= c.cmbnd_acct_end_dt)) and  "+
									"      b.rvnu_acctg_offc_nbr is not null  "+
									"group by  "+
									"a.bl_cyc_dt,  "+
									"a.bl_cyc_id,  "+
									"e.featr_rvnu_titl,  "+
									"f.actvt_type_cd,  "+
									"c.dry_loop_ind,  "+
									"b.uvrs_ind,  "+
									"c.bus_resd_cd,  "+
									"g.bl_cyc_cd,  "+
									"g.bl_cyc_clos_day,  "+
									"biller_info,  "+
									"ctrl,  "+
									"mid,  "+
									"run_id,  "+
									"pe,  "+
									"leg  "+
									" ) as \"Count\"  "
	;
	//--------------------------------------------------------------------------
}
//------------------------------------------------------------------------------
//
//	End of file
//
//------------------------------------------------------------------------------
