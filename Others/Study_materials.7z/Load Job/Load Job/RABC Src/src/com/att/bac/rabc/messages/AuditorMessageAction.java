/*
 * Created on Feb 23, 2006 by Peter Foo (pf7941) Copyright 2006-2008 AT&T
 * Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.messages;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.att.bac.rabc.ConnectionManager;
import com.att.carat.util.JDBCUtil;



public class AuditorMessageAction extends DispatchAction {

    public static Logger logger = Logger.getLogger(AuditorMessageAction.class);

    public ActionForward check(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        Connection connection = null;
        String id = null;
       String result = "no";
        PrintWriter out = null;
        AuditorMessageDAO auditorMessageDAO = new AuditorMessageDAO();
        AuditorMessageForm amForm = (AuditorMessageForm) form;
        try {
            out = response.getWriter();
            connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
            id = (String)request.getSession().getAttribute("bacUserID");
            String tableNode =(String)request.getSession().getAttribute("tableNode");
            boolean hasUnreadMessages = auditorMessageDAO.hasUnreadMessages(connection, id, tableNode);
            if ((id != null) && hasUnreadMessages){
 				result = "yes";
            }
            out.print(result);
            
            // If the session should have timed out by now, then destroy the
            // session. 
            // Invalidate the session by setting the max inactive interval to 0
            // seconds.
            if (amForm.isEndSession()) {
                logger.debug("The session's maximum inactive interval has been reached. Session should end.");
                request.getSession().setMaxInactiveInterval(0);
            }
            		
        }
        catch (SQLException e) {
            logger.error("Error getting connection: ", e);
            out.print("error");
            return mapping.findForward("error");
        }
        catch (NamingException ne) {
            logger.error("Error getting datasource: ", ne);
            out.print("error");
            return mapping.findForward("error");
        }
        catch (IOException ie) {
            logger.error("Error getting PrintWriter: ", ie);
            out.print("error");
           
            return mapping.findForward("error");
        }catch(Exception e){
        	//logger.error("Error getting connection: ", e);
            
            auditorMessageDAO.getError(e);
            //return mapping.findForward("getError");
        }
        finally {
            JDBCUtil.closeConnection(connection);
        }

        return null;
    }

    public ActionForward popUp(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        Connection connection = null;
        String id = null;
        String markAsRead = null;
		AuditorMessage[] messages= null;
        String tempMessagesString = null;
        AuditorMessageDAO auditorMessageDAO = new AuditorMessageDAO();
         //   System.out.println("in popup");
        try {
            connection =ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
            id = (String) request.getSession().getAttribute("bacUserID"); 
            String tableNode =(String)request.getSession().getAttribute("tableNode");
            markAsRead = request.getParameter("markAsRead"); 	//handled in veiwauditor

            if (markAsRead == null) { 
                messages = auditorMessageDAO.getUnreadMessages(connection, id,tableNode);
                request.setAttribute("messages", messages);
            }
            else {
               messages = auditorMessageDAO.getUnreadMessages(connection, id,tableNode); 

///*TODO
// * MAY NEED TO REVIST TO REMOVE FOR LOOP LATER.  DO WE NEED SOME KIND OF MESSAGE ID here?
// */
            	for (int i = 0; i < messages.length; i++) {
                	auditorMessageDAO.updateStatus(connection,id, messages[i].getStatus(), tableNode);
                }
            }

        }
        catch (SQLException e) {
            logger.error("Error getting datasource: ", e);
            return mapping.findForward("getError");
        }
        catch (NamingException e) {
            logger.error("Error getting datasource: ", e);
            return mapping.findForward("error");
        }
        catch (AuditorMessageException e) {
            logger.error("Error getting unread auditor messages: ", e);
            return mapping.findForward("error");//ActionUtil.forwardToErrorPage(mapping, request, e);
        }
        finally {
            JDBCUtil.closeConnection(connection);
        }
        return mapping.findForward("success");
    }
    
   
}
