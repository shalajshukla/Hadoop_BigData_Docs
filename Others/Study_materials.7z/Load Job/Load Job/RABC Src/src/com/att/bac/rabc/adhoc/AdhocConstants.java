/*
 * Copyright  2002-2006 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.adhoc;

/**
 * Constants used in Adhoc reports.
 * 
 * <p>
 * <hr>
 * <h3>Release History</h3>
 * <p>
 * <ul>
 * 
 * <li>jb6494 Nov 21, 2006 Created class.
 * 
 * </ul>
 * <p>
 * 
 */
public interface AdhocConstants {

    public static final String TREND_TIME_DAILY = "D";

    public static final String TREND_TIME_MONTHLY = "M";

    public static final String TREND_TIME_BILL_ROUND = "B";

    public static final String TREND_TIME_YEARLY = "Y";

    public static final String TREND_TIME_NONE = null;

    public static final String DATE_FORMAT_MMDDYYYY = "MM/dd/yyyy";

    public static final String GRAND_TOTAL = "Grand Total";

    public static final String SIX_MONTH_TOTALS = "6 Month Totals";

    public static final String TOTAL = "Total";
}
