/*
 * Copyright  2002-2006 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.adhoc.rpt.generator;

/**
 * Simple class to provide information about a calculation as defined by a data source.
 * 
 * <p>
 * <hr>
 * <h3>Release History</h3>
 * <p>
 * <ul>
 * 
 * <li>jb6494 Nov 6, 2006 Created class.
 * <li>jb6494 Mar 13, 2007 ML18 Calculations on views
 * 
 * </ul>
 * <p>
 * 
 */
public class Calculation {
	private String presnCalcName;
	
    private String algebraicFormula = "";

    private String displayFormula = "";

    private boolean divisionUsed;

    private String formula = "";

    private int precision;

    private String calcElemSQLFormula = "";

    /**
     * Returns a generic formula like A+B+C
     * 
     * @return
     */
    public String getAlgebraicFormula() {
        return algebraicFormula;
    }


    public String getDisplayFormula() {
        return displayFormula;
    }


    /**
     * Returns a precise formula that can be directly run in SQL.
     * 
     * @return
     */
    public String getFormula() {
        return formula;
    }


    /**
     * Returns the number of decimal points
     * 
     * @return Returns the precision.
     */
    public int getPrecision() {
        return precision;
    }

    /**
	 * @return the presnCalcName
	 */
	public String getPresnCalcName() {
		return presnCalcName;
	}

	/**
	 * @param presnCalcName the presnCalcName to set
	 */
	public void setPresnCalcName(String presnCalcName) {
		this.presnCalcName = presnCalcName;
	}


	/**
     * @return
     */
    public boolean isDivisionUsed() {
        return divisionUsed;
    }


    /**
     * @param algebraicFormula
     */
    public void setAlgebraicFormula(String algebraicFormula) {
        this.algebraicFormula = algebraicFormula;
    }


    /**
     * @param displayFormula
     */
    public void setDisplayFormula(String displayFormula) {
        this.displayFormula = displayFormula;
    }


    /**
     * @param divisionUsed
     */
    public void setDivisionUsed(boolean divisionUsed) {
        this.divisionUsed = divisionUsed;
    }


    /**
     * Set the division used indicator based on a string value that should only be a character of Y or N.
     * 
     * @param divUsed
     */
    public void setDivisionUsed(String divUsed) {
        if (divUsed == null) {
            setDivisionUsed(false);
            return;
        }
        setDivisionUsed((divUsed.charAt(0) == 'Y'));
    }


    /**
     * @param formula
     */
    public void setFormula(String formula) {
        if (formula == null) {
            formula = "";
        }
        this.formula = formula.toUpperCase();
    }


    /**
     * @param precision The precision to set.
     */
    public void setPrecision(int precision) {
        this.precision = precision;
    }


    /**
     * Set the precision based on an incoming string.
     * 
     * @param decimals
     */
    public void setPrecision(String decimals) {
        if (decimals == null) {
            setPrecision(0);
        }
        try {
            setPrecision(Integer.parseInt(decimals));
        } catch (NumberFormatException e) {
            setPrecision(0);
        }
    }


	/**
	 * @return the calcElemSQLFormula
	 */
	public String getCalcElemSQLFormula() {
		return calcElemSQLFormula;
	}


	/**
	 * @param calcElemSQLFormula the calcElemSQLFormula to set
	 */
	public void setCalcElemSQLFormula(String calcElemSQLFormula) {
		this.calcElemSQLFormula = calcElemSQLFormula;
	}

}
