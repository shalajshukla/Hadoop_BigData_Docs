/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
/*------------------------------------------------------------------------------
Modification History

Date		Version		Author			Description
----------	-----------	--------------- ----------------------------------------
12-02-2010	1.0			ss1644			Changes done for Q-FIX-11-01
										1. Added isCountItem parameter in formatRABCNumber method 
------------------------------------------------------------------------------*/

package com.att.bac.rabc.alerts.rpt;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.text.MessageFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
//import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;

import com.att.bac.rabc.MouseOverLink;
import com.att.bac.rabc.MouseOverLinkDAO;
import com.att.bac.rabc.MyDate;
import com.att.bac.rabc.RABCConstantsLists;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.ReflectionUtils;
import com.att.bac.rabc.StaticDataLoader;
import com.att.bac.rabc.alerts.rpt.AlertsReportSQLService.AlertRuleInfoStruct;
import com.att.bac.rabc.SQLHelper;

/**
 * This class represents the Service class which handles processing of 
 * various requests and has buisness logic related to AlertsReportViewService
 * for PAGE 11 and PAGE 14.
 * 
 * @author Nalina Pandiyan - NP5434
 */
public class AlertsReportViewService {
	private static final Logger logger = Logger.getLogger(AlertsReportViewService.class);
	
	private Connection connection = null;
	private List failureList = null;
	private AlertReportParameters alertReportParameters = null;
	private AlertReportView alertReportView = null;
	
	private List qryAlertDataList = new ArrayList();
	private List notCompleteFilesQryList = new ArrayList();
	private List notCompleteFilesQry1List = new ArrayList();
	private List previousDataList = new ArrayList();
	private List qryAlertMsgList = new ArrayList();
	private HashMap alertRuleMap = new HashMap();
	
	private List qryMouseOverLinks = null;

	private final static String qryMouseOverLinksSQL = "select PRESN_ID, WEBID, EXEC_PRESN_SEQ_NUM, MOUSE_OVER_NUM, LINK_TBL_KEY_NAME, LINK_TBL_KEY_DATA, LINK_TBL_NAME from RABC_MOUSE_OVER_LINK where presn_id IN ({0}) and webid = ''{1}'' and exec_presn_seq_num IN ({2}) ORDER BY PRESN_Id, MOUSE_OVER_NUM";
	private final static String qryGenericSQL = "select {0} from {1} where {2} = ''{3}'' ";
	
	
	private final static String qryTables = "rabc_alert_rule,rabc_alert_hist,rabc_alert_rule_presn_rule,rabc_alert_msg";
	private final static int FILE_DATE_IND = 1;
	private final static int ALERT_RULE_IND = 2; 
	private final static int SEQ_NUMBER_IND = 3;
	private final static int DATA_ITEM_IND = 4;
	private final static int ACTUAL_DATA_IND = 5; 
	private final static int ALERT_RESULT_IND = 6;
	private final static int PREV_DATA_IND = 7; 
	private final static int ACTUAL_VAR_IND = 8;
	private final static int AVERAGE_IND = 9;
	private final static int LOW_THRESHOLD_IND = 10;
	private final static int HIGH_THRESHOLD_IND = 11;
	private final static int STATUS_IND = 12;
	private final static int BILL_RND = 13;

	private final static String DATA_PAGE="rabc_trck_data_page.cfm";
	private final static String PAGE_14 = "RABCPSF00014";
	private static final String PAGE_11 = "RABCPSF00011";
	
	private int alertKeyLvl = 0;
	private int divisionNameKeyLvl = 0;
	private int presnId = 0;
	private int partiRefId = 0;
	private int AlertKeyLvl = 0;
	private String qsAlertRule="";
	private String qsPartiRefId="";
	private String qsPresnId="";
	private String qsPresnIdAsString="";
	private String qsFileSeqNum="";
	private String qsStartDate="";
	private String qsProcDate="";
	private String qsEndDate="";
	private String qsDivisionName="";
	private String qsKey1Val="";
	private String qsKey2Val="";
	private String qsKey3Val="";
	private String qsKey4Val="";
	private String qsKey5Val="";
	private String qsKeyValAll="";
	private String qsAKey1Val="";
	private String qsAKey2Val="";
	private String qsAKey3Val="";
	private String qsAKey4Val="";
	private String qsAKey5Val="";
	private String qsAKeyValAll="";
	private String qsAlertItem="";
	private String qsAlertTrendTime="";
	private String qsAlertTrendTimeInd="";
	private String qsGraphParam="";
	private String qsSelectedAlertRule = "";
	private String qsSelectedProcDate = "";
	private String qsSelectedDataItem = "";
	private String qsSelectedDivision = "";
	private String qsSelectedKey2 = "";
	private String qsSelectedKey3 = "";
	private String qsSelectedKey4 = "";
	private String qsSelectedKey5 = "";
	private String qsSelectedTrendTime = "";
	private String qsAverage = "";
	private String qsJsessionid = "";

	/**
	 * This method is used to return the object of AlertsReportViewService class.
	 * 
	 * @return AlertsReportViewService
	 */
	public static AlertsReportViewService getAlertsReportViewService() {
		return new AlertsReportViewService();
	}

	/**
	 * @return Returns the qryAlertDataList.
	 */
	public List getQryAlertDataList() {
		return qryAlertDataList;
	}

	/**
	 * @return Returns the notCompleteFilesQry1List.
	 */
	public List getNotCompleteFilesQry1List() {
		return notCompleteFilesQry1List;
	}

	/**
	 * @return Returns the notCompleteFilesQryList.
	 */
	public List getNotCompleteFilesQryList() {
		return notCompleteFilesQryList;
	}

	/**
	 * @return Returns the previousDataList.
	 */
	public List getPreviousDataList() {
		return previousDataList;
	}

	/**
	 * @return Returns the qryAlertMsgList.
	 */
	public List getQryAlertMsgList() {
		return qryAlertMsgList;
	}
	/**
	 * @param alertReportParameters The alertReportParameters to set.
	 */
	public void setAlertReportParameters(AlertReportParameters alertReportParameters) {
		this.alertReportParameters = alertReportParameters;
	}

	/**
	 * @return Returns the alertReportParameters.
	 */
	public AlertReportParameters getAlertReportParameters() {
		return alertReportParameters;
	}
	/**
	 * @param connection The connection to set.
	 */
	public void setConnection(Connection connection) {
		this.connection = connection;
	}

	/**
	 * @param failureList The failureList to set.
	 */
	public void setFailureList(List failureList) {
		this.failureList = failureList;
	}

	/**
	 * @param alertReportView The alertReportView to set.
	 */
	public void setAlertReportView(AlertReportView alertReportView) {
		this.alertReportView = alertReportView;
	}

	/**
	 * @return Returns the alertRuleMap.
	 */
	public HashMap getAlertRuleMap() {
		return alertRuleMap;
	}

	/**
	 * This method prepares UniqueKeyCols and OtherList.
	 * 
	 * @return int
	 */
	public int prepareAlertReportView() {
		//prepareUniqueKeyColsAndOtherList();
		//dumpQryAlertData();
		buildMouseOverLinks();
		buildOtherColumnList();
		if (!failureList.isEmpty()) return 0;
		return processQryAlertData();	
	}

	/**
	 * This method dumps QryAlertData.
	 */
	private void dumpQryAlertData() {
		String reportName = "qryAlertData.csv" ;
		File file[]  = new File[1];
		int i = 0;
		int size = qryAlertDataList.size();
		String newLine = "\n";
		QryAlertData qryAlertData = null;
		if (size == 0) return;
		try {
			file[0] = new File(reportName);
			OutputStream fos = new FileOutputStream(file[0]);
			qryAlertData = (QryAlertData) qryAlertDataList.get(0);
			
			fos.write(qryAlertData.getLabels().getBytes());
			fos.write(newLine.getBytes());
			fos.flush();
			for(i = 0; i < size; i ++) {
				qryAlertData = (QryAlertData) qryAlertDataList.get(i);
				fos.write(qryAlertData.toString().getBytes());
				fos.write(newLine.getBytes());
				fos.flush();
			}
			fos.flush();
			fos.close();
		} catch (IOException ioe) {
			logger.error("Parse Exception. Exception details: " + ioe.getMessage(), ioe);
		}
	}

	/**
	 * This method builds Other Column List and
	 * adds data columns for alert rule.
	 */
	private void buildOtherColumnList() {
		String alertRule = null;
		Set set = null; 
		Iterator iter = null; 
		AlertsReportSQLService.AlertRuleInfoStruct alertRuleInfo = null;

		logger.debug("Preparing other columns ...");
		set = alertRuleMap.keySet();
		iter = set.iterator();
		while(iter.hasNext()) {			
			alertRule = (String) iter.next();
			alertRuleInfo = (AlertsReportSQLService.AlertRuleInfoStruct) alertRuleMap.get(alertRule);
			logger.debug("Add data columns for alert rule - " + alertRule);
			if (alertRuleInfo.columns != null) {
				if (alertReportParameters.getWebPageId().equals(PAGE_14)) {
					// always display sequence number
					alertRuleInfo.columns.add(new Integer(SEQ_NUMBER_IND));
					// always display alert rule column
					alertRuleInfo.columns.add(new Integer(ALERT_RULE_IND));
					// always display file date for page 14
					alertRuleInfo.columns.add(new Integer(FILE_DATE_IND));
				} else {
					// Page 11
					if (alertReportParameters.getEndDate() != null)  {
						alertRuleInfo.columns.add(new Integer(FILE_DATE_IND));
					}
					if (alertReportParameters.getRelatedAlertInd().equals("Y")) {
						alertRuleInfo.columns.add(new Integer(ALERT_RULE_IND));
					}
					if (alertRuleInfo.seqCnt > 0) {
						alertRuleInfo.columns.add(new Integer(SEQ_NUMBER_IND));
					}
					
					alertRuleInfo.columns.add(new Integer(BILL_RND));
				}
				alertRuleInfo.columns.add(new Integer(DATA_ITEM_IND));
				if (alertRuleInfo.calcCnt > 0) {
					alertRuleInfo.columns.add(new Integer(ACTUAL_DATA_IND));
				}
				alertRuleInfo.columns.add(new Integer(ALERT_RESULT_IND));
				if ((alertRuleInfo.seqCnt < alertRuleInfo.totCnt) && (alertReportParameters.getEndDate() == null)) {
					alertRuleInfo.columns.add(new Integer(PREV_DATA_IND));
				}
				alertRuleInfo.columns.add(new Integer(ACTUAL_VAR_IND));
				alertRuleInfo.columns.add(new Integer(AVERAGE_IND));
				alertRuleInfo.columns.add(new Integer(LOW_THRESHOLD_IND));
				alertRuleInfo.columns.add(new Integer(HIGH_THRESHOLD_IND));
				if (alertReportParameters.getWebPageId().equals(PAGE_14)) {
					// Page 14 always display status column
					alertRuleInfo.columns.add(new Integer(STATUS_IND));
				} else {
					if (alertRuleInfo.totInd != 'Y') {
						alertRuleInfo.columns.add(new Integer(STATUS_IND));
					}
				}
				alertRuleMap.put(alertRule, alertRuleInfo);
			}
		} // end of while loop
	}
	/**
	 * This method prepares qryMouseOverLinks SQL statment.
	 */
	private void buildMouseOverLinks() {
		MessageFormat mf = null;

		logger.debug("Preparing qryMouseOverLinksSQL SQL statment ....");
		List args = new ArrayList();
		String arg = "";
		
		if ((alertReportParameters.getExecPresnSeqNums().length() == 0) || (alertReportParameters.getPresnIds().length() == 0)) {
			qryMouseOverLinks = new ArrayList();
			return;
		}
		args.add(alertReportParameters.getPresnIds());
		args.add(alertReportParameters.getWebPageId());
		args.add(alertReportParameters.getExecPresnSeqNums());
		
		MouseOverLinkDAO mouseOverLinkDAO = new MouseOverLinkDAO();
		qryMouseOverLinks = mouseOverLinkDAO.get(connection, failureList, args, qryMouseOverLinksSQL);
	}

	/**
	 * This method processes QryAlertData which handles different parameters.
	 * 
	 * @return int
	 */
	private int processQryAlertData() {
		QryAlertRule qryAlertRule = null;
		AlertHist alertHist = null;
		
		AlertData alertData = null;
		AlertsReportSQLService.MultiColumnStruct multiColumnStruct = null;
		AlertsReportSQLService.AlertRuleInfoStruct alertRuleInfo = null;
		
		// variables for controlling display
		boolean displayKey = true;
		boolean displaySeqNum = true;
		boolean displayFileDate = false;
		boolean displayAlertRule = false;

		// current values
		MyDate curFileDate = new MyDate();
		MyDate procDate = null;
		String curFileSeqNum = "";
		String curAlertRule = "";
		
		// section counter
		int secCnt=0;
		boolean bIncSecCnt = false;
		boolean bTotAlertRule = false;
		boolean bNewAlertRule = false;

		// Establish variables for Key1 / Account Name actions --->
		String key1Value = "";			// key1 value ==> Account Name or some other key value. L_key1Value
		boolean newKey1Value = false;	// boolean to identifiy when key1 value changes	
		boolean isDivisionName = false;	// boolean to identify when key1 value is an Account name L_newKey1Value

		String lsCurKeyValues = "";
		String lsCurKeyCols = "";
		String lsTestKeyValues = "";
		String lsTestKeyCols = "";
		boolean bNewKeyValue = false;
		boolean bNewKeyCol = false;
		boolean bNewKey1 = false;
		boolean bFirstTblTag = true;
		
		AlertRow alertRow = null;
		AlertCell alertCell = null;
		String thisBgClr;
		String thisClass;
		String thisStatus;
		String thisMsgNum;
		int alertMsgIndex = -1;
		AlertMsg alertMsg = null;
		boolean changedCnt;
		//String altRowClr = "##CCFFFF";  
		String altRowClr = "#cee6fd";
		String totRowClr = "#cccccc";  
		String stdRowClr = "#ffffff";
		String rowClr;
		boolean firstTime = true;
		int qFileSeqNum = 0;
		int divisionCount = 0;
		String thisKeyValue= " ";
		String thisDataLink = "";
		String thisMouseOver="";
		String thisKeyDataLinkInd="N";
		String thisHtmlTitle="";
		String tblCol = "";
		String tblKey = "";
		String tblName = "";
		String hrefString = "";
		String hrefImageString = "";
		String dataParams = "";
		String alertRuleLabel = null;
		String key1Label = null;
		int totalRows = 0;
		int nbrOfRows = 0;
		alertRuleLabel = AlertsGenFilterTemplate.getLabel("alertReport.label.alertRule");
		key1Label = AlertsGenFilterTemplate.getLabel("alertReport.label.key1Header");
		
		String highestStatusColumnHeaderColor = "#0059B3";
			
		if (alertReportParameters.getDivisionList() != null)
			divisionCount = alertReportParameters.getDivisionList().size();
		
		for(int i=0; i < qryAlertDataList.size(); i++) {
			boolean isCtField = false;
			qryAlertRule = ((QryAlertData) qryAlertDataList.get(i)).getQryAlertRule();
			alertHist = ((QryAlertData) qryAlertDataList.get(i)).getAlertHist();			

			//alertReportView = new AlertReportView();
			thisBgClr = "";
			thisClass = "DataLink";
			thisStatus = " ";
			thisMsgNum = "";
			if ( alertReportParameters.getWebPageId().equals(PAGE_14)) {
				// this is ensure that record does not get bypassed, since request is for page 14
				if (alertReportParameters.getSevereLvl().intValue() != -1) {
					alertReportParameters.setSevereLvl(new Integer(-1));
				}
			} else {
				// page 11
				alertMsgIndex = checkStatusAndMessages(qryAlertRule.getAlertRule(), qryAlertRule.getFileSeqNumInd(), alertHist);
			}
			//<!--- 1.  If navigated to SF11 from other than the Alert Dashboard, the SevereLvl parm will not exist  --->	
			//<!---		so show all records.  --->
			//<!--- 2.  If navigated to SF11 from the Alert Dashboard No Issue value, the SevereLvl parm will be zero --->
			//<!---		meaning display only those records which do not have an associated warning.  If we have found --->
			//<!---		a match (meaning there is a warning associated with this record), bypass this record.  --->						
			
			if ((alertReportParameters.getSevereLvl().intValue() == -1) ||  
				((alertReportParameters.getSevereLvl().intValue() == 0) && (alertMsgIndex == -1))) {
				// reset new section indicator
				bIncSecCnt=false;
				
				// other variables
				newKey1Value=false;
				bNewAlertRule=false;
				
				// variables used within this loop
				lsTestKeyValues = "";
				bNewKeyValue = false;
				bNewKeyCol = false;
				bNewKey1 = false;
				if (!qryAlertRule.getAlertRule().equals(curAlertRule)) {
					curAlertRule = qryAlertRule.getAlertRule();
					if (alertReportParameters.getRelatedAlertInd().equalsIgnoreCase("Y")) {
						alertRuleInfo = getAlertRuleInfoStruct(qryAlertRule.getAlertRule());
					} else {
						alertRuleInfo = (AlertRuleInfoStruct) alertRuleMap.get(qryAlertRule.getAlertRule());
					}					
					bNewAlertRule = true;
					isDivisionName = false;
					if (qryAlertRule.getDivisionNameKeyLvl() > 0) {
						isDivisionName = true;
						divisionNameKeyLvl = qryAlertRule.getDivisionNameKeyLvl();						
					}
				}
				// build list of key cols and key values
				lsTestKeyValues = "";
				lsTestKeyCols="";
				List multiColumnList = alertRuleInfo.multiColumnList;
				if (multiColumnList != null) {
					for(int j=0; j < multiColumnList.size(); j++) {
						multiColumnStruct = (AlertsReportSQLService.MultiColumnStruct) multiColumnList.get(j);
						lsTestKeyCols = lsTestKeyCols + qryAlertRule.getKeyHeaderAt(multiColumnStruct.keyNum - 1);
						if ((alertHist.getAlertKeyAt(multiColumnStruct.keyNum - 1) != null) && (alertHist.getAlertKeyAt(multiColumnStruct.keyNum - 1).equals(""))) {
							lsTestKeyValues = lsTestKeyValues + " ";
						} else {
							if (alertHist.getAlertKeyAt(multiColumnStruct.keyNum - 1) == null) {
								lsTestKeyValues = lsTestKeyValues + " ";
							} else {
								lsTestKeyValues = lsTestKeyValues + alertHist.getAlertKeyAt(multiColumnStruct.keyNum - 1);							
							}
						}
					} // end of j loop					
				}
				
				// <!--- check to see if list of current keys match with keys in previous record --->
				// <!--- key columns --->
				if (!lsTestKeyCols.equals(lsCurKeyCols)) {
					bNewKeyCol = true;
					lsCurKeyCols = lsTestKeyCols;
				}
				// <!--- key values --->
				if (!lsTestKeyValues.equals(lsCurKeyValues)) {
					bNewKeyValue = true;
					lsCurKeyValues = lsTestKeyValues;
				}
				// <!--- Determine if a new table needs to be created, or an existing one closed --->
				// Manage table headings - BEGIN
				if (qryAlertRule.getKey1Seq() == 3) {
					if (alertReportParameters.getWebPageId().equals(PAGE_14)) {
						// page 14
						if (bNewAlertRule) {
							if (!bFirstTblTag) {
								if (alertData != null) {
									alertData.setNbrOfColumns(new Integer(alertData.getColumnNames().size()));
									alertData.setNbrOfRows(new Integer(nbrOfRows));
									alertReportView.getAlertDataList().add(alertData);
									nbrOfRows = 0;
								}
								alertData = null;
							}
							// add columns
							alertData = new AlertData();
							alertReportView.getDivisions().add(new AlertReportDivision(alertHist.getAlertKeyAt(0)));
							displayColumns(alertRuleInfo, alertData, qryAlertRule);								
						}						
					} else {
						// page 11
						if (qryAlertRule.getTotInd().equals("Y")) {
							// page 11
							if (!bTotAlertRule) {
								bTotAlertRule = true;
								if (!bFirstTblTag) {
									if (alertData != null) {
										alertData.setNbrOfColumns(new Integer(alertData.getColumnNames().size()));
										alertData.setNbrOfRows(new Integer(nbrOfRows));
										alertReportView.getAlertDataList().add(alertData);
										nbrOfRows = 0;
									}
									alertData = null;
								}
								// add columns
								alertData = new AlertData();
								alertReportView.getDivisions().add(new AlertReportDivision(alertHist.getAlertKeyAt(0)));
								displayColumns(alertRuleInfo, alertData, qryAlertRule);
							}													
						} else {
							if (firstTime) {
								firstTime = false;
								// add columns
								alertData = new AlertData();
								alertReportView.getDivisions().add(new AlertReportDivision(alertHist.getAlertKeyAt(0)));
								displayColumns(alertRuleInfo, alertData, qryAlertRule);
							}						
						}
					}
				} else {
					if ((!alertHist.getAlertKeyAt(0).equals("")) && (!alertHist.getAlertKeyAt(0).equals(key1Value))) {
						if (!bFirstTblTag) {
							// close old table
							if (alertData != null) {
								alertData.setNbrOfColumns(new Integer(alertData.getColumnNames().size()));
								alertData.setNbrOfRows(new Integer(nbrOfRows));
								alertReportView.getAlertDataList().add(alertData);
								nbrOfRows = 0;
							}
						}
						key1Value = alertHist.getAlertKeyAt(0);
						newKey1Value = true;
					}
					if (newKey1Value) {
						// show Account Name
						// Add columns Heading
						alertData = new AlertData();
						if (alertReportParameters.getWebPageId().equals(PAGE_14)) {
							alertData.setKey1Label(key1Label);
							alertData.setKey1Value(key1Value);		
							if ("DIVISION".equalsIgnoreCase(key1Label)){
								alertData.setKey1Label("Division");
								alertData.setKey1FullDesc(RABCConstantsLists.getRABCConstantsLists().getText(StaticDataLoader.getDivisionDesc(alertReportParameters.getRegion(),key1Value), false));
							}else {
								alertData.setKey1FullDesc(key1Value);
							}
						} else {
							// page 11
							if ((alertRuleInfo.divisionNameKeyLvl == 1) && 
								((divisionCount > 1) || ((alertReportParameters.getDivisionName().equals("ALL")) && (divisionCount > 2)))) {
								alertData.setKey1Label(qryAlertRule.getKeyHeaderAt(0));
								alertData.setKey1Value(key1Value);
								if ("DIVISION".equalsIgnoreCase(alertData.getKey1Label())){
									alertData.setKey1Label("Division");
									alertData.setKey1FullDesc(RABCConstantsLists.getRABCConstantsLists().getText(StaticDataLoader.getDivisionDesc(alertReportParameters.getRegion(),key1Value), false));
								}else {
									alertData.setKey1FullDesc(key1Value);
								}
							}							
						}
						if (alertReportParameters.getCntrlPtCd().length() != 0) {
							alertData.setAlertRuleLabel(alertRuleLabel);
							alertData.setAlertRule(curAlertRule);
						}
						alertReportView.addDivisions(new AlertReportDivision(alertHist.getAlertKeyAt(0).toString()));
						displayColumns(alertRuleInfo, alertData, qryAlertRule);
					}
					if (alertReportParameters.getCntrlPtCd().length() != 0) {
						if ((bNewAlertRule) && (!newKey1Value)) {
							if (alertData != null) {
								alertData.setNbrOfColumns(new Integer(alertData.getColumnNames().size()));
								alertData.setNbrOfRows(new Integer(nbrOfRows));
								alertReportView.getAlertDataList().add(alertData);
								nbrOfRows = 0;
							}

							alertData = new AlertData();
							alertData.setAlertRuleLabel(alertRuleLabel);
							alertData.setAlertRule(curAlertRule);							
							displayColumns(alertRuleInfo, alertData, qryAlertRule);							
						}
					}
				}
				//Manage table headings - END 

				// <!--- ***** BEGIN: Manage Display Options ******************************** --->
				if (qryAlertRule.getKey1Seq() == 3) {
					if ((alertReportParameters.getWebPageId().equals(PAGE_14)) || (qryAlertRule.getTotInd().equals("Y"))) {
						displayKey = true;
						displayAlertRule = true;
						displayFileDate = true;
						displaySeqNum = true;
						qFileSeqNum = alertHist.getFileSeqNum();
						secCnt=-1;
						procDate = new MyDate(alertHist.getProcDate());
						if ((alertReportParameters.getEndDate() != null) &&
							(procDate.compareTo(curFileDate) != 0)) {
							curFileDate = procDate;
							displayFileDate = true;
						}						
					}
				} else {
					if ((newKey1Value) || (bNewKeyCol) || (bNewKeyValue) || ((bNewAlertRule) && (alertReportParameters.getRelatedAlertInd().equals("Y")))) {
						// New Key1 / account name ==> reset list of keys
						lsCurKeyValues=lsTestKeyValues;						
						// Set new data to dynamic variables --->
						curAlertRule = qryAlertRule.getAlertRule();
						curFileDate = new MyDate(alertHist.getProcDate());
						qFileSeqNum = alertHist.getFileSeqNum();
									
						// set display variables ==> all true --->
						displayKey = true;
						displayAlertRule = true;
						displayFileDate = true;
						displaySeqNum = true;
						if (alertReportParameters.getWebPageId().equals(PAGE_14)) {
							if ((newKey1Value) || (secCnt == -1)) {
								secCnt = 1;
							} else {
								secCnt = secCnt + 1;
							}
						} else {
							// Page 11
							if (qryAlertRule.getTotInd().equals("Y")) {
								secCnt = -1;
							} else {
								if ((newKey1Value) || (secCnt == -1)) {
									secCnt = 1;
								} else {
									secCnt = secCnt + 1;
								}
							}
						}
					} else {
						// set default display values to true to show keys all the time
						displayKey = true;
						displayAlertRule = true;
						displayFileDate = true;
						displaySeqNum = true;
						changedCnt = false;
						// <!--- check for new File Date (i.e., Proc_Date), if it is being displayed --->
						procDate = new MyDate(alertHist.getProcDate());
						if ((alertReportParameters.getEndDate() != null) &&
							(procDate.compareTo(curFileDate) != 0)) {
							curFileDate = new MyDate(alertHist.getProcDate());
							displayFileDate = true;
							displayKey=true;
							displayAlertRule=true;
							displaySeqNum=true;
						
							//<!--- row/section color needs to change --->
							bIncSecCnt=true;
						}
						// <!--- check for new sequence number, if it is being displayed --->
						if ((alertReportParameters.getSeqCnt() > 0) && (alertHist.getFileSeqNum() != qFileSeqNum)) {
							qFileSeqNum = alertHist.getFileSeqNum();
							displaySeqNum = true;
							displayKey=true;
							//<!--- row/section color needs to change --->
							bIncSecCnt=true;
							if (alertReportParameters.getRelatedAlertInd().equals("Y")) {
								displayAlertRule=true;
							}
							if (alertReportParameters.getEndDate() != null) {
								curFileDate = new MyDate(alertHist.getProcDate());
								displayFileDate=true;
							}							
						}
						// <!--- END - Check All Other Values --->
						// <!--- Increase Section counters here --->
						if (bIncSecCnt) {
							if (qryAlertRule.getTotInd().equals("Y")) {
								secCnt = -1;
							} else {
								if (secCnt == -1) {
									secCnt = 1;
								} else {
									secCnt = secCnt + 1;
								}
							}
						}
					}
				}
				// query Strings
				qsAlertRule="alertRule=" + (qryAlertRule.getAlertRule() == null? "":urlEncodedFormat(qryAlertRule.getAlertRule()));
				qsPartiRefId="partiRefId=" + qryAlertRule.getPartiRefId() ;
				qsPresnId="presnId=" + qryAlertRule.getPresnId();
				qsPresnIdAsString="presnIdAsString=" + qryAlertRule.getPresnId();
				qsFileSeqNum="fileSeqNum=" + alertHist.getFileSeqNum();
				
				qsStartDate="startDate=" + alertReportParameters.getStartDate().toString();
				qsProcDate="procDate=" + new MyDate(alertHist.getProcDate()).toString();  
				qsEndDate="endDate=" + (alertReportParameters.getEndDate()==null?"":alertReportParameters.getEndDate().toString());
				qsDivisionName="divisionName=";
			
				if( isDivisionName ) qsDivisionName="divisionName=" + alertHist.getAlertKeyAt(divisionNameKeyLvl-1);
				qsKey1Val="key1=" + (alertHist.getAlertKeyAt(0) == null?"":alertHist.getAlertKeyAt(0));
				qsKey2Val="key2=" + (alertHist.getAlertKeyAt(1) == null?"":alertHist.getAlertKeyAt(1));
				qsKey3Val="key3=" + (alertHist.getAlertKeyAt(2) == null?"":alertHist.getAlertKeyAt(2));
				qsKey4Val="key4=" + (alertHist.getAlertKeyAt(3) == null?"":alertHist.getAlertKeyAt(3));
				qsKey5Val="key5=" + (alertHist.getAlertKeyAt(4) == null?"":alertHist.getAlertKeyAt(4));
				qsKeyValAll=qsKey1Val + "&" + qsKey2Val + "&" + qsKey3Val + "&" + qsKey4Val + "&" + qsKey5Val;
				qsAKey1Val="aKey1=" + (alertHist.getAlertKeyAt(0) == null?"":alertHist.getAlertKeyAt(0));
				qsAKey2Val="aKey2=" + (alertHist.getAlertKeyAt(1) == null?"":alertHist.getAlertKeyAt(1));
				qsAKey3Val="aKey3=" + (alertHist.getAlertKeyAt(2) == null?"":alertHist.getAlertKeyAt(2));
				qsAKey4Val="aKey4=" + (alertHist.getAlertKeyAt(3) == null?"":alertHist.getAlertKeyAt(3));
				qsAKey5Val="aKey5=" + (alertHist.getAlertKeyAt(4) == null?"":alertHist.getAlertKeyAt(4));
				qsAKeyValAll=qsAKey1Val + "&" + qsAKey2Val + "&" + qsAKey3Val + "&" + qsAKey4Val + "&" + qsAKey5Val;
				qsAlertItem="alertItem=" + (alertHist.getAlertItem()==null?"":urlEncodedFormat(alertHist.getAlertItem()));
				qsAlertTrendTime="alertTimeValue=" + ((alertHist.getAlertTrendTime()==null || "M".equals(qryAlertRule.getAlertTimeInd()))?"" :urlEncodedFormat(alertHist.getAlertTrendTime()));
				qsAlertTrendTimeInd="alertTimeInd=" + ((qryAlertRule.getAlertTimeInd()==null || "M".equals(qryAlertRule.getAlertTimeInd())) ?"":qryAlertRule.getAlertTimeInd());
				if(alertHist.getFileSeqNum()!=0){
					qsGraphParam = qsFileSeqNum + "&" + qsKeyValAll + "&" + qsAKeyValAll + 
								"&" + qsPartiRefId + "&" + qsAlertItem + "&" + qsAlertTrendTime + "&" + qsAlertTrendTimeInd + 
								"&" + qsProcDate + "&extractDateName=PROC_DATE&tableName=RABC_ALERT_HIST&"+"PartiRefId=" + qryAlertRule.getPartiRefId()+
								"&alertrule=" + (qryAlertRule.getAlertRule() == null? "":urlEncodedFormat(qryAlertRule.getAlertRule()))+
								"&ProcDate=" + new MyDate(alertHist.getProcDate()).toString();
				}else{
					qsGraphParam = qsKeyValAll + "&" + qsAKeyValAll + 
					"&" + qsPartiRefId + "&" + qsAlertItem + "&" + qsAlertTrendTime + "&" + qsAlertTrendTimeInd + 
					"&" + qsProcDate + "&extractDateName=PROC_DATE&tableName=RABC_ALERT_HIST&"+"PartiRefId=" + qryAlertRule.getPartiRefId()+
					"&alertrule=" + (qryAlertRule.getAlertRule() == null? "":urlEncodedFormat(qryAlertRule.getAlertRule()))+
					"&ProcDate=" + new MyDate(alertHist.getProcDate()).toString();
				}
				qsSelectedAlertRule = "selectedAlertRule=" + (qryAlertRule.getAlertRule() == null? "":urlEncodedFormat(qryAlertRule.getAlertRule()));
				qsSelectedProcDate = "selectedProcDate=" + (alertHist.getProcDate()==null?"":urlEncodedFormat(new MyDate(alertHist.getProcDate()).toString()));
				qsSelectedDataItem = "selectedDataItem=" + (alertHist.getAlertItem()==null?"":urlEncodedFormat(alertHist.getAlertItem()));
				qsSelectedDivision = "selectedDivision=" + (alertHist.getAlertKeyAt(0) == null?"":alertHist.getAlertKeyAt(0));
				qsSelectedKey2 = "selectedKey2=" + (alertHist.getAlertKeyAt(1) == null?"":alertHist.getAlertKeyAt(1));
				qsSelectedKey3 = "selectedKey3=" + (alertHist.getAlertKeyAt(2) == null?"":alertHist.getAlertKeyAt(2));
				qsSelectedKey4 = "selectedKey4=" + (alertHist.getAlertKeyAt(3) == null?"":alertHist.getAlertKeyAt(3));
				qsSelectedKey5 = "selectedKey5=" + (alertHist.getAlertKeyAt(4) == null?"":alertHist.getAlertKeyAt(4));
				qsSelectedTrendTime = "selectedTrendTime=" + (alertHist.getAlertTrendTime()==null?"":urlEncodedFormat(alertHist.getAlertTrendTime()));
				qsAverage = "average=" + formatAverage(alertHist.getAlertAvg(),2);
				qsJsessionid = "jsessionid=" + alertReportParameters.getSessionId();
				
				alertRow = new AlertRow();
				rowClr = stdRowClr;
				if (secCnt == -1) {
					rowClr = totRowClr;
				} else {
					if ((secCnt % 2) == 0) {
						rowClr = altRowClr;
					}
				}
				alertRow.setRowColor(rowClr);
				thisKeyValue= " ";
				thisDataLink = "";
				thisMouseOver="";
				thisKeyDataLinkInd="N";
				thisHtmlTitle="";
				tblCol = "";
				tblKey = "";
				tblName = "";
				hrefString = "";
				hrefImageString = "";
				dataParams = "";
				// <!--- Key --->
				if (displayKey) {
					displayKey(alertRuleInfo, qryAlertRule, alertHist, alertRow, rowClr, alertMsgIndex);
				} else {
					for(int k = 0; k < alertRuleInfo.nbrOfKeyCols; k++)
						alertCell = new AlertCell();
						alertCell.setBgColor(rowClr);
						alertCell.setExcelDataType("T");
						alertRow.addColumnData(alertCell);
				}
				// display other column data
				for(int n = alertRuleInfo.nbrOfKeyCols; n < alertRuleInfo.columns.size(); n++) {
					switch (((Integer)alertRuleInfo.columns.get(n)).intValue()) {
						case FILE_DATE_IND:
							// <!--- File Date --->
							alertCell = new AlertCell();
							alertCell.setExcelDataType("N");
							alertCell.setBgColor(rowClr);
							if (displayFileDate) {
								procDate = new MyDate(alertHist.getProcDate());
								alertCell.setValue(procDate.toString());
							}
							alertRow.addColumnData(alertCell);
							break;
						case ALERT_RULE_IND:
							// <!--- Alert Rule --->
							alertCell = new AlertCell();
							alertCell.setExcelDataType("N");
							alertCell.setBgColor(rowClr);
							if (displayAlertRule) {
								alertCell.setValue(qryAlertRule.getAlertRule());
								alertCell.setTitle(qryAlertRule.getAlertDesc());
							}
							alertRow.addColumnData(alertCell);
							break;
						case SEQ_NUMBER_IND:
							// <!--- Sequence Number --->
							String FileDiv = "";
							if ((displaySeqNum) && (qFileSeqNum != 0)) {
								if (qryAlertRule.getDivisionNameKeyLvl() > 1 && qryAlertRule.getDivisionNameKeyLvl() < 6 ) {
									if (!(alertHist.getAlertKeyAt(qryAlertRule.getDivisionNameKeyLvl())).equals("")) {
										FileDiv = alertHist.getAlertKeyAt(qryAlertRule.getDivisionNameKeyLvl());
									} else 
										FileDiv = "";
								}
								// href
								hrefString = "AlertTrckMainSeqPage.do?" + qsPartiRefId + "&"+ qsFileSeqNum + "&" + qsProcDate+"&" + qsDivisionName + "&popup="+(alertReportParameters.getPopup()?"Y":"N");
								thisHtmlTitle = "View sequence number alert details report";
								hrefImageString = "javascript:popWin(15,'" + qsPartiRefId + "&" + qsFileSeqNum + "&" + qsDivisionName + "&" + qsProcDate + "&fileDIV=" + FileDiv + "');"; 
								alertCell = new AlertCell();
								alertCell.setExcelDataType("T");
								alertCell.setValue(new Integer(qFileSeqNum).toString());
								alertCell.setTitle(thisHtmlTitle);
								alertCell.setImageSrc("db1.gif");
								alertCell.setBgColor(rowClr);
								alertCell.setHref(hrefString);
								alertCell.setHrefForImage(hrefImageString);
								alertCell.setAddlnTitle(thisHtmlTitle);
								alertRow.addColumnData(alertCell);
							}
							break;
						case DATA_ITEM_IND:
							// <!--- Data Item --->
							alertCell = new AlertCell();
							alertCell.setValue(alertHist.getAlertItem());
							alertCell.setExcelDataType("T");
							if (alertHist.getAlertItem().endsWith("CT") || alertHist.getAlertItem().endsWith("QTY") 
									|| alertHist.getAlertItem().endsWith("COUNT")){
								isCtField = true;
							}
							alertCell.setBgColor(rowClr);
							alertCell.setNowrap("nowrap");
							if (!alertReportParameters.getWebPageId().equals(PAGE_14)) {
								String indicator = CheckInNotCompleteFilesQry(alertHist);
								if (indicator == null) indicator = "";
								alertCell.setAddlnTitle("Alert exists for other data items for this file.");
								alertCell.setAddlnValue(indicator);
							}
							if (alertReportParameters.getWebPageId().equals(PAGE_11)) {
								hrefString = "javascript:popWin(16,'AdminAlertThreshold.do;" + qsJsessionid + "?dispatch=adminAlertThresholdDetailPopup&" + qsSelectedAlertRule + "&" + qsSelectedDataItem + "&" + qsSelectedDivision + "&" + qsSelectedProcDate + "&" + qsSelectedKey2 + "&" + qsSelectedKey2 + "&" + qsSelectedKey3 + "&" + qsSelectedKey4 + "&" + qsSelectedKey5 + "&" + qsSelectedTrendTime + "&" + qsAverage + "&thresholdLevel=Key&popUpPage=1');";
								alertCell.setHref(hrefString);
							}
							alertCell.setAlign("left");
							alertRow.addColumnData(alertCell);
							break;
						case BILL_RND:
							// <!--- Bill Cycle--->
							if ("B".equals(qryAlertRule.getAlertTimeInd())) {
								alertCell = new AlertCell();
								alertCell.setExcelDataType("N");
								alertCell.setValue(alertHist.getAlertTrendTime());
								alertCell.setBgColor(rowClr);
								alertCell.setNowrap("nowrap");
								alertCell.setAlign("right");
								alertRow.addColumnData(alertCell);
							}
							break;
						case ACTUAL_DATA_IND:
							// <!--- Actual Data --->
							hrefImageString = "javascript:popWin(1,'"+ urlEncodedFormat(qsGraphParam) + "&Header=Actual Data&itemDDlName=ALERT_ACTUAL_DATA');";
							String value = "";
							if (Math.abs(alertHist.getAlertActualData()) < 100) {
								value = formatRABCNumber(alertHist.getAlertActualData(), 2, null, isCtField);
							} else {
								if (isCtField){
									value = formatRABCNumber(Math.round(alertHist.getAlertActualData()), 0, null, isCtField);
								} else {
									value = formatRABCNumber(Math.round(alertHist.getAlertActualData()), 2, null, isCtField);
								}
							}
							//value = Long.toString(Math.round(alertHist.getAlertActualData()));
							alertCell = new AlertCell();
							alertCell.setExcelDataType("N");
							alertCell.setValue(value);
							alertCell.setImageSrc("graph.gif");
							alertCell.setBgColor(rowClr);
							alertCell.setHrefForImage(hrefImageString);
							alertCell.setAddlnTitle("View Graph");
							alertCell.setAlign("right");
							alertCell.setNowrap("nowrap");
							alertRow.addColumnData(alertCell);
							break;
						case ALERT_RESULT_IND:
							// <!--- Alert Result / Current Data --->
							//thisDataLink="AdhocRpt.do";
							alertCell = new AlertCell();
							alertCell.setExcelDataType("N");
							if(alertHist.getFileSeqNum()!=0){
								dataParams = qsProcDate+"&"+qsPresnIdAsString+"&"+qsKeyValAll+"&"+qsFileSeqNum+"&sortkeylist="+alertReportParameters.getKeysAt(1);
							}else{
								dataParams = qsProcDate+"&"+qsPresnIdAsString+"&"+qsKeyValAll+"&sortkeylist="+alertReportParameters.getKeysAt(1);
							}
							if (qryAlertRule.getAlertRuleType().equals("TRACK")) {
								dataParams = qsAlertTrendTime+"&"+qsAlertTrendTimeInd+"&"+qsProcDate+"&"+qsPresnId+"&"+qsPresnIdAsString+"&"+qsAlertRule+"&"+qsPartiRefId+"&"+qsDivisionName+"&"+qsKeyValAll+"&"+qsFileSeqNum+"&CurrentDataLink=Y";
								thisDataLink = "AlertTrckDataPage.do";
								hrefString = thisDataLink + "?" + dataParams + "&popup="+(alertReportParameters.getPopup()?"Y":"N");
								alertCell.setHref(hrefString);
							}
							hrefImageString = "javascript:popWin(1,'"+ urlEncodedFormat(qsAlertRule)+"&"+urlEncodedFormat(qsGraphParam)+"&Header=Alert Result&itemDDlName=ALERT_DATA');";
							if (isCtField){
								alertCell.setValue(formatRABCNumber(alertHist.getAlertData(), 0, qryAlertRule.getCalcRule(), isCtField));
							} else {
								alertCell.setValue(formatRABCNumber(alertHist.getAlertData(), 2, qryAlertRule.getCalcRule(), isCtField));
							}
							alertCell.setImageSrc("graph.gif");
							alertCell.setBgColor(rowClr);
							alertCell.setHrefForImage(hrefImageString);
							alertCell.setAddlnTitle("View Graph");
							alertCell.setAlign("right");
							alertCell.setNowrap("nowrap");
							alertRow.addColumnData(alertCell);
							break;
						case PREV_DATA_IND:
							// <!--- Previous Data --->
							alertCell = new AlertCell();
							alertCell.setExcelDataType("N");
							alertCell.setBgColor(rowClr);
							alertCell.setAlign("right");
							alertCell.setNowrap("nowrap");
							if (alertReportParameters.getWebPageId().equals(PAGE_11)) {
								alertCell.setValue(getPreviousData(qFileSeqNum, qryAlertRule, alertHist, isCtField));
							}
							alertRow.addColumnData(alertCell);
							break;
						case ACTUAL_VAR_IND:
							// <!--- Actual Variance --->
							alertCell = new AlertCell();
							alertCell.setExcelDataType("N");
							alertCell.setBgColor(rowClr);
							alertCell.setAlign("right");
							alertCell.setNowrap("nowrap");
							if ((qryAlertRule.getCalcRule() != null) && (qryAlertRule.getCalcRule().equals("T"))) {
								if (isCtField){
									alertCell.setValue(formatRABCNumber(alertHist.getVariancePct(), 0, qryAlertRule.getCalcRule(), isCtField));
								} else {
									alertCell.setValue(formatRABCNumber(alertHist.getVariancePct(), 2, qryAlertRule.getCalcRule(), isCtField));
								}
							} else{
								if (isCtField){
									alertCell.setValue(formatRABCNumber(alertHist.getVarianceData(), 0, qryAlertRule.getCalcRule(), isCtField));
								} else {
									alertCell.setValue(formatRABCNumber(alertHist.getVarianceData(), 2, qryAlertRule.getCalcRule(), isCtField));
								}
							}
							alertRow.addColumnData(alertCell);
							break;
						case AVERAGE_IND:
							// <!--- Average --->
							alertCell = new AlertCell();
							alertCell.setExcelDataType("N");
							if (isCtField){
								alertCell.setValue(formatRABCNumber(alertHist.getAlertAvg(), 0, qryAlertRule.getCalcRule(), isCtField));
							} else {
								alertCell.setValue(formatRABCNumber(alertHist.getAlertAvg(), 2, qryAlertRule.getCalcRule(), isCtField));
							}
							alertCell.setBgColor(rowClr);
							alertCell.setAlign("right");
							alertCell.setNowrap("nowrap");
							alertRow.addColumnData(alertCell);
							break;
						case LOW_THRESHOLD_IND:
							// <!--- Low Threshold --->
							alertCell = new AlertCell();
							alertCell.setExcelDataType("N");
							if (isCtField){
								alertCell.setValue(formatRABCNumber(alertHist.getAlertLow(), 0, qryAlertRule.getCalcRule(), isCtField));
							} else {
								alertCell.setValue(formatRABCNumber(alertHist.getAlertLow(), 2, qryAlertRule.getCalcRule(), isCtField));
							}	
							alertCell.setBgColor(rowClr);
							alertCell.setAlign("right");
							alertCell.setNowrap("nowrap");
							alertRow.addColumnData(alertCell);
							break;
						case HIGH_THRESHOLD_IND:
							// <!--- High Threshold --->
							alertCell = new AlertCell();
							alertCell.setExcelDataType("N");
							if (isCtField){
								alertCell.setValue(formatRABCNumber(alertHist.getAlertHigh(), 0, qryAlertRule.getCalcRule(), isCtField));
							} else {
								alertCell.setValue(formatRABCNumber(alertHist.getAlertHigh(), 2, qryAlertRule.getCalcRule(), isCtField));
							}
							alertCell.setBgColor(rowClr);
							alertCell.setAlign("right");
							alertCell.setNowrap("nowrap");
							alertRow.addColumnData(alertCell);
							break;
						case STATUS_IND:
							// <!--- Status --->
							alertCell = new AlertCell();
							alertCell.setExcelDataType("T");
							alertCell.setAlign("left");
							if (alertMsgIndex == - 1) {
								thisBgClr = rowClr;
								thisClass = "DataLink";
								alertCell.setValue(" ");
								alertCell.setBgColor(rowClr);	
							} else  {
								alertMsg = (AlertMsg) qryAlertMsgList.get(alertMsgIndex);								
								if (alertMsg.getMsgNum() == 0) {
									alertCell.setValue(" ");
									alertCell.setBgColor(rowClr);
								} else {
									thisMsgNum = new Integer(alertMsg.getMsgNum()).toString();
									thisBgClr = rowClr;
									thisClass = "DataLink";
									if ((alertMsg.getAlertStatus().equals("Warning"))) {
										thisBgClr = "red";  
										thisClass = "statusLink";
										highestStatusColumnHeaderColor = "Red";
									}
									
									if ((alertMsg.getAlertStatus().equals("Closed"))) {
										thisBgClr = rowClr;  
										thisClass = "";
										if (!"Red".equals(highestStatusColumnHeaderColor) && !"##ff9900".equals(highestStatusColumnHeaderColor) && !"##ffff00".equals(highestStatusColumnHeaderColor) ){
											highestStatusColumnHeaderColor = "#0059B3";
										}
									}
									if ((!alertMsg.getAlertStatus().equals("Closed")) && (!alertMsg.getAlertStatus().equals("Warning")) && (alertMsg.getAlertSevereLvlInd().equals("1"))) {
										thisBgClr = "red";  
										thisClass = "statusLink";
										highestStatusColumnHeaderColor = "Red";
									}
									if ((alertMsg.getAlertStatus().equals("Closed")) && (!alertMsg.getAlertStatus().equals("Warning")) && (alertMsg.getAlertSevereLvlInd().equals("2"))) {
										thisBgClr = "##ff9900";  
										thisClass = "statusLink";
										if (!"Red".equals(highestStatusColumnHeaderColor)){
											highestStatusColumnHeaderColor = "##ff9900";
										}
									}
									if ((alertMsg.getAlertStatus().equals("Closed")) && (!alertMsg.getAlertStatus().equals("Warning")) && (alertMsg.getAlertSevereLvlInd().equals("3"))) {
										thisBgClr = "##ffff00";  
										thisClass = "statusLink";
										if (!"Red".equals(highestStatusColumnHeaderColor) && !"##ff9900".equals(highestStatusColumnHeaderColor)){
											highestStatusColumnHeaderColor = "##ffff00";
										}
									}
									
									hrefString ="javascript:popWin(7,'msgno="+ thisMsgNum +"&fromPage="+alertReportParameters.getWebPageId();
									if (alertReportParameters.getOpnrStartDate() != null) {
										hrefString = hrefString + "&opnr_start="+alertReportParameters.getOpnrStartDate().toString();
									}
									if (alertReportParameters.getOpnrEndDate() != null) {
										hrefString = hrefString + "&opnr_end="+alertReportParameters.getOpnrEndDate().toString();						
									}
									if (alertReportParameters.getAlertGrp() != null) {
										hrefString = hrefString + "&alertgrp="+alertReportParameters.getAlertGrp();						
									}
									if (alertReportParameters.getPrevSortOrder() != null) {
										hrefString = hrefString + "&prevsortorder="+alertReportParameters.getPrevSortOrder();						
									}
									if (alertReportParameters.getPrevSortBy() != null) {
										hrefString = hrefString + "&prevsortby="+alertReportParameters.getPrevSortBy();						
									}
									if (alertReportParameters.getSortOrder() != null) {
										hrefString = hrefString + "&sortorder="+alertReportParameters.getSortOrder();						
									}
									if (alertReportParameters.getSortBy() != null) {
										hrefString = hrefString + "&sortby="+alertReportParameters.getSortBy();						
									}
									hrefString = hrefString + "');"; 
									alertCell.setValue(alertMsg.getAlertStatus());
									alertCell.setTitle("Update Alert");
									alertCell.setBgColor(thisBgClr);
									alertCell.setThisClass(thisClass);
									alertCell.setHref(hrefString);
								}
							}
							alertRow.addColumnData(alertCell);
							break;
						default:
							logger.warn("Not Supported Column found, column Name = " + (String)alertRuleInfo.columns.get(n));
							break;
					}
				}
				alertData.addAlertRow(alertRow);
				nbrOfRows++;
				totalRows++;
				bFirstTblTag = false;
			} // ((alertReportParameters.getSession().getSevereLvl() != null)
		} // end of i loop
		if (alertData != null) {
			alertData.setNbrOfColumns(new Integer(alertData.getColumnNames().size()));
			alertData.setNbrOfRows(new Integer(nbrOfRows));
			alertReportView.getAlertDataList().add(alertData);
			this.getAlertReportParameters().setStatusColumnHeaderBgColor(highestStatusColumnHeaderColor);			
		}
		return totalRows;
	}

	/**
	 * This method sets the parameters which are required to display the alert keys. 
	 * 
	 * @param alertRuleInfo
	 * @param qryAlertRule
	 * @param alertHist
	 * @param alertRow
	 * @param rowClr
	 * @param alertMsgIndex
	 */
	private void displayKey(AlertsReportSQLService.AlertRuleInfoStruct alertRuleInfo, QryAlertRule qryAlertRule, AlertHist alertHist, AlertRow alertRow, String rowClr, int alertMsgIndex) {
   	    AlertsReportSQLService.MultiColumnStruct multiColumnStruct = null;
		String thisKeyValue= " ";
		String thisDataLink = "";
		String thisMouseOver="";
		String thisKeyDataLinkInd="N";
		String thisHtmlTitle="";
		String tblCol = "";
		String tblKey = "";
		String tblName = "";
		String hrefString = "";
		String hrefImageString = "";
		String dataParams = "";
		List multiColumnList = null; 
		boolean mouseOverLinkFound = false;
		AlertMsg alertMsg = null;
		AlertCell alertCell = null;
		
		for(int k = 0; k < alertRuleInfo.nbrOfKeyCols; k++) {
			thisKeyValue= " ";
			thisDataLink = "";
			thisMouseOver="";
			thisKeyDataLinkInd="N";
			thisHtmlTitle="";
			multiColumnList = (List) alertRuleInfo.multiColumnList;
			 
			if (multiColumnList != null) {
				for(int j=0; j < multiColumnList.size(); j++) {
					multiColumnStruct = (AlertsReportSQLService.MultiColumnStruct) multiColumnList.get(j);
					if (multiColumnStruct.keyColPos == k + 1) {
						// key Column Exist for this rule
						thisKeyValue = alertHist.getAlertKeyAt(multiColumnStruct.keyNum - 1);
						if (thisKeyValue.equals("")) thisKeyValue = " ";
						thisDataLink = qryAlertRule.getKeyLinkToPgmAt(multiColumnStruct.keyNum - 1);
						if ((qryAlertRule.getKeyDescIndAt(multiColumnStruct.keyNum - 1)!=null) && (qryAlertRule.getKeyDescIndAt(multiColumnStruct.keyNum - 1).equals("Y"))) {
							if (qryTables.indexOf(qryAlertRule.getKeyLinkTblNameAt(multiColumnStruct.keyNum - 1)) != -1) {
								tblCol = qryAlertRule.getKeyLinkTblKeyDataAt(multiColumnStruct.keyNum - 1);
								tblKey = qryAlertRule.getKeyLinkTblKeyNameAt(multiColumnStruct.keyNum - 1);
								if (thisKeyValue.equals(tblKey)) {
									mouseOverLinkFound = false;
									thisMouseOver = "";
									try {
										Field fld = QryAlertRule.class.getDeclaredField(tblCol);
										thisMouseOver = (String) ReflectionUtils.getFieldValue(fld, qryAlertRule);
										mouseOverLinkFound = true;
									} catch (Exception e) {
										logger.warn("TblCol = " + tblCol + " not found in QryAlertRule", e); 
									}
									if (!mouseOverLinkFound) {
										try {
											Field fld = AlertHist.class.getDeclaredField(tblCol);
											thisMouseOver = (String) ReflectionUtils.getFieldValue(fld, alertHist);
											mouseOverLinkFound = true;
										} catch (Exception e) {
											logger.warn("TblCol = " + tblCol + " not found in AlertHist", e);
										}											
									}
									if ((!mouseOverLinkFound) && (alertMsgIndex > -1)) {
										try {
											alertMsg = (AlertMsg) qryAlertMsgList.get(alertMsgIndex);												
											Field fld = AlertMsg.class.getDeclaredField(tblCol);
											thisMouseOver = (String) ReflectionUtils.getFieldValue(fld, alertMsg);
											mouseOverLinkFound = true;
										} catch (Exception e) {
											logger.warn("TblCol = " + tblCol + " not found in AlertMsg", e);
										}											
									}
								}									
							} else {
								// not found in qry tables
								for(int m=0; m < qryMouseOverLinks.size(); m++) {
									MouseOverLink mouseOverLink = (MouseOverLink) qryMouseOverLinks.get(m);
									if ((mouseOverLink.getPresnId() == qryAlertRule.getPresnId()) && 
										(mouseOverLink.getMouseOverNum() == qryAlertRule.getKeyMouseOverNumAt(multiColumnStruct.keyNum - 1))) {
										tblCol = mouseOverLink.getLinkTblKeyData();
										tblName = mouseOverLink.getLinkTblName(); 
										tblKey = mouseOverLink.getLinkTblKeyName();
										thisMouseOver = getThisMouseOver(tblName, tblCol, tblKey, thisKeyValue);
									}
								} // end if m loop
							}
							thisHtmlTitle = thisMouseOver;
						}
						thisKeyDataLinkInd = qryAlertRule.getKeyDataLinkIndAt(multiColumnStruct.keyNum - 1);
					}
					hrefString = "";
					if ((thisKeyDataLinkInd != null) && (thisDataLink != null)) {
						if ((thisKeyDataLinkInd.equals("Y")) && (!thisDataLink.equals(""))) {
							dataParams = qsProcDate + "&" + qsPresnId + "&" + qsPresnIdAsString + "&" + qsPartiRefId + "&" + qsAlertRule + "&" + qsFileSeqNum + "&" + qsKeyValAll + "&" + "ClickLevel=" + new Integer(k+1).toString();
							if (thisDataLink.equals(DATA_PAGE)) {
								dataParams = qsAlertTrendTime+"&"+qsAlertTrendTimeInd+"&"+qsProcDate+"&"+qsPresnId+"&"+qsAlertRule+"&"+qsPartiRefId+"&"+qsDivisionName+"&"+qsKeyValAll+"&currentDataLink=N";									
							} 
							// to be remmoved later being
							if (thisDataLink.equals("RABC_TRCK_DATA_PAGE.CFM")) {
								thisDataLink = "AlertTrckDataPage.do";
							}
							// end
							hrefString = thisDataLink + "?" + dataParams + "&popup="+(alertReportParameters.getPopup()?"Y":"N"); 
						}							
					}
				} // end of j loop					
			}
			alertCell = new AlertCell();
			alertCell.setValue(thisKeyValue);
			if ("BUS_TYPE".equalsIgnoreCase( (String) alertRuleInfo.columns.get(k))){
				alertCell.setAlign("left");
			}
			alertCell.setTitle(thisHtmlTitle);
			alertCell.setBgColor(rowClr);
			alertCell.setHref(hrefString);
			alertRow.addColumnData(alertCell);
		} // end of k loop
	}

	/**
	 * This method to get the PreviousData for the passed qFileSeqNum, qryAlertRule and alertHist attributes.
	 * 
	 * @param qFileSeqNum
	 * @param qryAlertRule
	 * @param alertHist
	 * @param isCountItem if the alert item is a count item
	 * @return String
	 */
	private String getPreviousData(int qFileSeqNum, QryAlertRule qryAlertRule, AlertHist alertHist, boolean isCountItem) {
		VwAlertHistPrev vwAlertHistPrev = null;
		for(int i = 0; i < previousDataList.size(); i++) {
			vwAlertHistPrev = (VwAlertHistPrev) previousDataList.get(i);
			if  ((qryAlertRule.getPartiRefId() == vwAlertHistPrev.getPartiRefId()) &&  
				(alertHist.getProcDate().compareTo(vwAlertHistPrev.getProcDate()) == 0) &&
				(alertHist.getAlertTrendTime().equals(vwAlertHistPrev.getAlertTrendTime())) &&
				(alertHist.getAlertItem().equals(vwAlertHistPrev.getPrevAlertItem())) &&
				((qryAlertRule.getAlertTimeInd()!= null)&& ((qryAlertRule.getAlertTimeInd().equals("W")) || 
				 (qryAlertRule.getAlertTimeInd().equals("W")) || 
				 (qryAlertRule.getAlertTimeInd().equals("M")) || 
				 (qryAlertRule.getAlertTimeInd().equals("B")))) &&
				(qFileSeqNum != 0) && 
				((alertHist.getAlertKeyAt(0)!=null) && alertHist.getAlertKeyAt(0).equals(vwAlertHistPrev.getPrevAlertKeyAt(0))) &&
				((alertHist.getAlertKeyAt(1)!=null) && alertHist.getAlertKeyAt(1).equals(vwAlertHistPrev.getPrevAlertKeyAt(1))) &&
				((alertHist.getAlertKeyAt(2)!=null) && alertHist.getAlertKeyAt(2).equals(vwAlertHistPrev.getPrevAlertKeyAt(2))) &&
				((alertHist.getAlertKeyAt(3)!=null) && alertHist.getAlertKeyAt(3).equals(vwAlertHistPrev.getPrevAlertKeyAt(3))) &&
				((alertHist.getAlertKeyAt(4)!=null) && alertHist.getAlertKeyAt(4).equals(vwAlertHistPrev.getPrevAlertKeyAt(4)))) {
				if (vwAlertHistPrev.getPrevData() != -1) {
					return formatRABCNumber(vwAlertHistPrev.getPrevData(), 2, qryAlertRule.getCalcRule(), isCountItem);
				}
			}
		}
		return "";
	}

		/**
	 * This method sets the format for RABCNumber.
	 * 
	 * @param data
	 * @param nbrOfDec
	 * @param calcRule
	 * @param isCountItem	if the alert item is a count item
	 * @return String
	 */
	private String formatRABCNumber(double data, int nbrOfDec, String calcRule, boolean isCountItem) {
		String value = "";
		String format = "";
		
		if (isCountItem || (calcRule != null) && (calcRule.equals("T")) ) {
		 format = ",##0";
		} else {
			format = "$ ,##0";
		}
		for (int i = 0; i < nbrOfDec; i++) {
			if (i == 0) format = format + ".";
			format = format + "0";
		}
		NumberFormat formatter = new DecimalFormat(format);
		value = formatter.format(data);
		if ((calcRule != null) && (calcRule.equals("T"))) {
			return value + "%";
		}
		
		return value;
	}
	/**
	 * Additional method to format w/o commas
	 * @param data
	 * @param nbrOfDec
	 * @return
	 */
	private String formatAverage(double data, int nbrOfDec) {
		String value = "";
		
		String format = "##0";
		for (int i = 0; i < nbrOfDec; i++) {
			if (i == 0) format = format + ".";
			format = format + "0";
		}
		NumberFormat formatter = new DecimalFormat(format);
		value = formatter.format(data);
		
		return value;
	}

	/**
	 * This method sets the urlEncodedFormat.
	 * 
	 * @param s
	 * @return String
	 */
	private String urlEncodedFormat(String s) {
		if (s == null) return null;
		try {
			return URLEncoder.encode(s, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			return null;
		}
	}

	/**
	 * This method is used to check the status and messages for all alert rule.
	 * 
	 * @param alertRule
	 * @param fileSeqNumInd
	 * @param alertHist
	 * @return int
	 */
	private int checkStatusAndMessages(String alertRule, String fileSeqNumInd, AlertHist alertHist) {
		AlertMsg alertMsg = null;
		boolean matched = false;
		for(int i=0; i < qryAlertMsgList.size(); i++) {
			alertMsg = (AlertMsg) qryAlertMsgList.get(i);
			matched = true;

			if (!alertRule.equals(alertMsg.getAlertRule())) matched = false;
			if ((alertHist.getProcDate() != null) && (alertMsg.getProcDate() != null)) {
				if (alertHist.getProcDate().compareTo(alertMsg.getProcDate()) != 0) matched = false;
			} else {
				if ((alertHist.getProcDate() == null) && (alertMsg.getProcDate() == null)) {
					// do nothing
				} else {
					matched = false;
				}
			}
			if ((alertHist.getAlertKeyAt(0)!=null) && !alertHist.getAlertKeyAt(0).equals(alertMsg.getAlertDataAt(0))) matched = false;
			if ((alertHist.getAlertKeyAt(1)!=null) && !alertHist.getAlertKeyAt(1).equals(alertMsg.getAlertDataAt(1))) matched = false;
			if ((alertHist.getAlertKeyAt(2)!=null) && !alertHist.getAlertKeyAt(2).equals(alertMsg.getAlertDataAt(2))) matched = false;
			if ((alertHist.getAlertKeyAt(3)!=null) && !alertHist.getAlertKeyAt(3).equals(alertMsg.getAlertDataAt(3))) matched = false;
			if ((alertHist.getAlertKeyAt(4)!=null) && !alertHist.getAlertKeyAt(4).equals(alertMsg.getAlertDataAt(4))) matched = false;
			if (!alertHist.getAlertItem().equals(alertMsg.getAlertItem())) matched = false;

			if (matched) {
				if (fileSeqNumInd!=null && fileSeqNumInd.equals("Y")) {
					if (alertHist.getFileSeqNum() != alertMsg.getFileSeqNum()) {
						return -1;
					}
				}				
				return i;
			}
		}
		return -1;
	}

	/**
	 * This method sets the parameters which are required to display the Columns. 
	 * 
	 * @param alertRuleInfo
	 * @param alertData
	 * @param qryAlertRule
	 */
	private void displayColumns(AlertsReportSQLService.AlertRuleInfoStruct alertRuleInfo, AlertData alertData, QryAlertRule qryAlertRule) {
		int k = 0;
		int size = 0;
				
		// add key Columns
		size = alertRuleInfo.columns.size();
		for (k = 0; k < size; k++) {
			if (k < alertRuleInfo.nbrOfKeyCols) {
				String keyColumnName = (String)alertRuleInfo.columns.get(k);
				if ("DIVISION".equalsIgnoreCase(keyColumnName)){
					alertData.addColumnName("Division");
				}else if ("CYCLE".equalsIgnoreCase(keyColumnName)){
					alertData.addColumnName("Cycle");
				}else {
					alertData.addColumnName(RABCConstantsLists.getRABCConstantsLists().getText1((String)alertRuleInfo.columns.get(k), false));
				}
			} else {
				switch (((Integer)alertRuleInfo.columns.get(k)).intValue()) {
					case FILE_DATE_IND:
						// <!--- File Date --->
						alertData.addColumnName(AlertsGenFilterTemplate.getLabel("alertReport.label.fileDate"));
						break;
					case ALERT_RULE_IND:
						// <!--- Alert Rule --->
						alertData.addColumnName(AlertsGenFilterTemplate.getLabel("alertReport.label.alertRule"));
						break;
					case SEQ_NUMBER_IND:
						// <!--- Sequence Number --->
						alertData.addColumnName(AlertsGenFilterTemplate.getLabel("alertReport.label.seqNumber"));
						break;
					case DATA_ITEM_IND:
						// <!--- Data Item --->
						alertData.addColumnName(AlertsGenFilterTemplate.getLabel("alertReport.label.dataItem"));
						break;
					case ACTUAL_DATA_IND:
						// <!--- Actual Data --->
						alertData.addColumnName(AlertsGenFilterTemplate.getLabel("alertReport.label.actualData"));
						break;
					case ALERT_RESULT_IND:
						// <!--- Alert Result / Current Data --->
						alertData.addColumnName(AlertsGenFilterTemplate.getLabel("alertReport.label.alertResult"));
						break;
					case PREV_DATA_IND:
						// <!--- Previous Data --->
						alertData.addColumnName(AlertsGenFilterTemplate.getLabel("alertReport.label.prevData"));
						break;
					case ACTUAL_VAR_IND:
						// <!--- Actual Variance --->
						alertData.addColumnName(AlertsGenFilterTemplate.getLabel("alertReport.label.actualVariance"));
						break;
					case AVERAGE_IND:
						// <!--- Average --->
						alertData.addColumnName(AlertsGenFilterTemplate.getLabel("alertReport.label.average"));
						break;
					case LOW_THRESHOLD_IND:
						// <!--- Low Threshold --->
						alertData.addColumnName(AlertsGenFilterTemplate.getLabel("alertReport.label.lowThreshold"));
						break;
					case HIGH_THRESHOLD_IND:
						// <!--- High Threshold --->
						alertData.addColumnName(AlertsGenFilterTemplate.getLabel("alertReport.label.highThreshold"));
						break;
					case STATUS_IND:
						// <!--- Status --->
						alertData.addColumnName(AlertsGenFilterTemplate.getLabel("alertReport.label.status"));						
						break;
					case BILL_RND:
						// <!--- Bill Cycle--->
						if ("B".equals(qryAlertRule.getAlertTimeInd())) {
							if (alertReportParameters!=null) {
								if ("MW".equals(alertReportParameters.getRegion())){
									alertData.addColumnName(AlertsGenFilterTemplate.getLabel("alertReport.label.processGroup"));
								}else {
									alertData.addColumnName(AlertsGenFilterTemplate.getLabel("alertReport.label.billCycle"));
								}
							}else {
								alertData.addColumnName(AlertsGenFilterTemplate.getLabel("alertReport.label.billCycle"));
							}
						}					
						break;
					default:
						logger.warn("Not Supported Column found, column Name = " + (String)alertRuleInfo.columns.get(k));
						break;
				}
			}
		}
	}

	/**
	 * This method sets the parameters which are required to CheckInNotCompleteFilesQry. 
	 * 
	 * @param alertHist
	 * @return String
	 */
	public String CheckInNotCompleteFilesQry(AlertHist alertHist) {
		int count = 0;
		
		if (notCompleteFilesQryList.isEmpty()) return null;
		for(int i=0; i < notCompleteFilesQryList.size(); i++) {
			AlertsReportSQLService.NotCompleteFilesQryStruct notCompleteFilesQryStruct = (AlertsReportSQLService.NotCompleteFilesQryStruct) notCompleteFilesQryList.get(i);
			if ((alertHist.getProcDate().compareTo(notCompleteFilesQryStruct.procDate) == 0) && 
				(alertHist.getFileSeqNum() == notCompleteFilesQryStruct.fileSeqNum) && 
				(alertHist.getAlertKeyAt(0).equals(notCompleteFilesQryStruct.alertKey[0])) && 
				(alertHist.getAlertKeyAt(1).equals(notCompleteFilesQryStruct.alertKey[1])) && 
				(alertHist.getAlertKeyAt(2).equals(notCompleteFilesQryStruct.alertKey[2])) && 
				(alertHist.getAlertKeyAt(3).equals(notCompleteFilesQryStruct.alertKey[3])) && 
				(alertHist.getAlertKeyAt(4).equals(notCompleteFilesQryStruct.alertKey[4]))) {
				count = 0;
				for(int j=0; j < notCompleteFilesQry1List.size(); j++) {
					AlertsReportSQLService.NotCompleteFilesQryStruct notCompleteFilesQry1Struct = (AlertsReportSQLService.NotCompleteFilesQryStruct) notCompleteFilesQry1List.get(j);
					if ((alertHist.getProcDate().compareTo(notCompleteFilesQry1Struct.procDate) == 0) && 
						(alertHist.getFileSeqNum() == notCompleteFilesQry1Struct.fileSeqNum) && 
						(alertHist.getAlertKeyAt(0).equals(notCompleteFilesQry1Struct.alertKey[0])) && 
						(alertHist.getAlertKeyAt(1).equals(notCompleteFilesQry1Struct.alertKey[1])) && 
						(alertHist.getAlertKeyAt(2).equals(notCompleteFilesQry1Struct.alertKey[2])) && 
						(alertHist.getAlertKeyAt(3).equals(notCompleteFilesQry1Struct.alertKey[3])) && 
						(alertHist.getAlertKeyAt(4).equals(notCompleteFilesQry1Struct.alertKey[4])) &&
						(!alertHist.getAlertItem().equals(notCompleteFilesQry1Struct.alertItem))) {
						count = count + 1;
						if (count >= 2) return "A";
					}
				}
			}
		}
		
		return null;
	}

	/**
	 * This method executes query for Mouse Over Links with table Name.
	 * It prepares qryGenericSQL statement. 
	 * 
	 * @param tblName
	 * @param tblCol
	 * @param tblKey
	 * @param keyValue
	 * @return String
	 */
	public String getThisMouseOver(String tblName, String tblCol, String tblKey, String keyValue) {
		Statement stmt = null;
		ResultSet rs = null;
		String returnValue = null;
		String qryGenericSQLStmt = null;
		
		if ("DIVISION".equalsIgnoreCase(tblKey)){
			returnValue = StaticDataLoader.getDivisionDesc(alertReportParameters.getRegion(),keyValue);
			returnValue = RABCConstantsLists.getRABCConstantsLists().getText(returnValue, true);
		}else {
			try {
				logger.debug("Executing query for Mouse Over Links with table Name = " + tblName + ", Column Name = " + tblCol + ", key = " + tblKey + " ....");
				logger.debug("Preparing qryGenericSQL statement");
				MessageFormat mf = new MessageFormat(qryGenericSQL);
				qryGenericSQLStmt = mf.format(new String[]{tblCol, tblName, tblKey, keyValue});
				logger.debug("qryGenericSQL statement = " + qryGenericSQLStmt);
				// execute notCompleteFilesQry SQL
				stmt = connection.createStatement();
				rs = stmt.executeQuery(qryGenericSQLStmt);
				if (rs != null) {
					while (rs.next()) {								
						returnValue = rs.getString(1);
						break;
					}
				}
			} catch (SQLException sx) {
				logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryGenericSQLStmt}) + " Exception details: " + sx.getMessage(), sx);
				failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryGenericSQLStmt}), sx));
				return null;
			} finally {
				SQLHelper.closeResultSet(rs, failureList, logger);
				SQLHelper.closeStatement(stmt, failureList, logger);
			}
		}
		return returnValue;
	}

	/**
	 * This method is used to get AlertRuleInfoStruct.
	 * 
	 * @param alertRule
	 * @return AlertRuleInfoStruct
	 */
	private AlertRuleInfoStruct getAlertRuleInfoStruct(String alertRule){
		AlertsReportSQLService.AlertRuleInfoStruct alertRuleInfo = null;
		Set set = null; 
		Iterator iter = null; 
		String currAlertRule = null;
		int i = 0;
		int size = 0;
		alertRule = "'" + alertRule + "'";
		set = alertRuleMap.keySet();
		iter = set.iterator();
		while(iter.hasNext()) {			
			currAlertRule = (String) iter.next();
			alertRuleInfo = (AlertRuleInfoStruct) alertRuleMap.get(currAlertRule);
			String relatedAlertRules = alertRuleInfo.alertRules;
			StringTokenizer tokens = new StringTokenizer(relatedAlertRules.substring(1),",");
			while (tokens.hasMoreTokens()){
				String currRule = tokens.nextToken();
				if (currRule.equals(alertRule)){
					return alertRuleInfo;
				}
			}
		}
		return null;
	}
	
	/*private class NotCompleteFilesQryStruct {
		int fileSeqNum;
		Date procDate;
		String[] alertKey = {"","","","",""};
		String alertItem;
	}*/
}
