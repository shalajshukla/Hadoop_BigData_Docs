/*
 * Module description: 
 * This bean contains a record from RABC_DATA_TBL_DDL table 
 *
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 *
 * Modification History:                                     
 * SBCUID		Date			Description                         	    	
 * ------		--------		-----------
 * PD2951		20051229		Initial version for EAP 556010
 * VD3159		20060731		To implement the column name description change.  
 */
package com.att.bac.rabc;

public class DataTblDdlBean {
	
	private String alertProcTbl = null;
	private String tblProcDateDdlName = null;
	private String tblBillRndDdlName = null;
	private int tblDdlKeyLvl = 0;
	private String tblDdlKey1Name = null;
	private String tblDdlKey2Name = null;
	private String tblDdlKey3Name = null;
	private String tblDdlKey4Name = null;
	private String tblDdlKey5Name = null;
	private String tblDdlName = null;
	private String tblBillRndDdlMon = null;
	private String tblBillRndDdlYear = null;
	private String tblDdlDataType = null;
	private String tblSubsysId = null;
	private String tblFileSeqNumDdlName = null;
	private String tblDdlPrescsnFormatType = null;
	private String tblDdlNameDesc = null;

	public DataTblDdlBean(String alertProcTbl,
						  String tblProcDateDdlName,
						  String tblBillRndDdlName,
						  int tblDdlKeyLvl,
						  String tblDdlKey1Name,
						  String tblDdlKey2Name,
						  String tblDdlKey3Name,
						  String tblDdlKey4Name,
						  String tblDdlKey5Name,
						  String tblDdlName,
						  String tblBillRndDdlMon,
						  String tblBillRndDdlYear,
						  String tblDdlDataType,
						  String tblSubsysId,
						  String tblFileSeqNumDdlName,
						  String tblDdlPrescsnFormatType,
						  String tblDdlNameDesc){
		this.alertProcTbl = alertProcTbl; 
		this.tblProcDateDdlName = tblProcDateDdlName;
		this.tblBillRndDdlName = tblBillRndDdlName;
		this.tblDdlKeyLvl = tblDdlKeyLvl;
		this.tblDdlKey1Name = tblDdlKey1Name;
		this.tblDdlKey2Name = tblDdlKey2Name;
		this.tblDdlKey3Name = tblDdlKey3Name;
		this.tblDdlKey4Name = tblDdlKey4Name;
		this.tblDdlKey5Name = tblDdlKey5Name;
		this.tblDdlName = tblDdlName;
		this.tblBillRndDdlMon = tblBillRndDdlMon;
		this.tblBillRndDdlYear = tblBillRndDdlYear;
		this.tblDdlDataType = tblDdlDataType;
		this.tblSubsysId = tblSubsysId;
		this.tblFileSeqNumDdlName = tblFileSeqNumDdlName;
		this.tblDdlPrescsnFormatType = tblDdlPrescsnFormatType;
		this.tblDdlNameDesc = tblDdlNameDesc;
	}

	public String getAlertProcTbl() {
		return alertProcTbl;
	}
	public String getTblBillRndDdlMon() {
		return tblBillRndDdlMon;
	}
	public String getTblBillRndDdlName() {
		return tblBillRndDdlName;
	}
	public String getTblBillRndDdlYear() {
		return tblBillRndDdlYear;
	}
	public String getTblDdlDataType() {
		return tblDdlDataType;
	}
	public String getTblDdlKey1Name() {
		return tblDdlKey1Name;
	}
	public String getTblDdlKey2Name() {
		return tblDdlKey2Name;
	}
	public String getTblDdlKey3Name() {
		return tblDdlKey3Name;
	}
	public String getTblDdlKey4Name() {
		return tblDdlKey4Name;
	}
	public String getTblDdlKey5Name() {
		return tblDdlKey5Name;
	}
	public int getTblDdlKeyLvl() {
		return tblDdlKeyLvl;
	}
	public String getTblDdlName() {
		return tblDdlName;
	}
	public String getTblDdlPrescsnFormatType() {
		return tblDdlPrescsnFormatType;
	}
	public String getTblFileSeqNumDdlName() {
		return tblFileSeqNumDdlName;
	}
	public String getTblProcDateDdlName() {
		return tblProcDateDdlName;
	}
	public String getTblSubsysId() {
		return tblSubsysId;
	}	
	public String getTblDdlNameDesc() {
		return tblDdlNameDesc;
	}
}
