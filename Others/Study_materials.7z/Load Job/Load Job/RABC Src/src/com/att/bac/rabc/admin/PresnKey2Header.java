/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.admin;

/**
 * This is a Data Object to represent RABC_PRESN_KEY2_HEADER table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class PresnKey2Header {
	private int presnId;
	private String webid;
	private int execPresnSeqNum;
	private String key2Value;
	private String mainKey2LineHeader;

	/**
	 * @return Returns the PresnId.
	 */
	public int getPresnId() {
		return presnId;
	}
	/**
	 * @return Returns the Webid.
	 */
	public String getWebid() {
		return webid;
	}
	/**
	 * @return Returns the ExecPresnSeqNum.
	 */
	public int getExecPresnSeqNum() {
		return execPresnSeqNum;
	}
	/**
	 * @return Returns the Key2Value.
	 */
	public String getKey2Value() {
		return key2Value;
	}
	/**
	 * @return Returns the MainKey2LineHeader.
	 */
	public String getMainKey2LineHeader() {
		return mainKey2LineHeader;
	}

	/**
	 * @param PresnId The presnId to set.
	 */
	public void setPresnId(int presnId) {
		this.presnId = presnId;
	}
	/**
	 * @param Webid The webid to set.
	 */
	public void setWebid(String webid) {
		this.webid = webid;
	}
	/**
	 * @param ExecPresnSeqNum The execPresnSeqNum to set.
	 */
	public void setExecPresnSeqNum(int execPresnSeqNum) {
		this.execPresnSeqNum = execPresnSeqNum;
	}
	/**
	 * @param Key2Value The key2Value to set.
	 */
	public void setKey2Value(String key2Value) {
		this.key2Value = key2Value;
	}
	/**
	 * @param MainKey2LineHeader The mainKey2LineHeader to set.
	 */
	public void setMainKey2LineHeader(String mainKey2LineHeader) {
		this.mainKey2LineHeader = mainKey2LineHeader;
	}
}
