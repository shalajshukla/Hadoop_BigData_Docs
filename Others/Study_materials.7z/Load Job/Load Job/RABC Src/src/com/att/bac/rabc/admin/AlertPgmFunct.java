/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.admin;

/**
 * This is a Data Object to represent RABC_ALERT_PGM_FUNCT table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class AlertPgmFunct {
	private String pgmId;
	private String pgmDesc;
	private String functCd;
	private String alertGrpType;

	/**
	 * @return Returns the alertGrpType.
	 */
	public String getAlertGrpType() {
		return alertGrpType;
	}
	/**
	 * @param alertGrpType The alertGrpType to set.
	 */
	public void setAlertGrpType(String alertGrpType) {
		this.alertGrpType = alertGrpType;
	}
	/**
	 * @return Returns the functCd.
	 */
	public String getFunctCd() {
		return functCd;
	}
	/**
	 * @param functCd The functCd to set.
	 */
	public void setFunctCd(String functCd) {
		this.functCd = functCd;
	}
	/**
	 * @return Returns the pgmDesc.
	 */
	public String getPgmDesc() {
		return pgmDesc;
	}
	/**
	 * @param pgmDesc The pgmDesc to set.
	 */
	public void setPgmDesc(String pgmDesc) {
		this.pgmDesc = pgmDesc;
	}
	/**
	 * @return Returns the pgmId.
	 */
	public String getPgmId() {
		return pgmId;
	}
	/**
	 * @param pgmId The pgmId to set.
	 */
	public void setPgmId(String pgmId) {
		this.pgmId = pgmId;
	}
}
