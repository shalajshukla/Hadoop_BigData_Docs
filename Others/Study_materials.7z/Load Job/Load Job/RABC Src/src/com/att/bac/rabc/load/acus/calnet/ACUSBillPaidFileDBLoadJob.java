package com.att.bac.rabc.load.acus.calnet;

import java.io.File;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import com.att.carat.util.JDBCUtil;

/**
 * @author pb3879 - Patric Bowlin
 *
 */
public class ACUSBillPaidFileDBLoadJob extends ACUSFileDBLoadJob{

//	 prepared statement String for the Insert into the RABC_ACUS_BILL_PAYER table
	private static final String INSERT_QUERY = "INSERT INTO RABC_ACUS_BILL_PAYER " +
        									"(DATA_CREATE_DT, ACUS_BILL_PAYER_ACCT, ACUS_INV_DT, ACUS_INV_PD_AMT) " +
        									"VALUES " +
        									"( ?, UPPER(?), ?, ?)";


private PreparedStatement insertDetail;
private static final int BATCH_SIZE = 5000;
private int infoRecordCounter = 0;
private static java.util.Date dataCreateDate;
//private static final Date currentDt = new Date(new java.util.Date().getTime());

/**
 * Inserts a row into the RABC_ACUS_BILL_PAYER table using the BillPaidBeen 
 * 
 * @param detail the BillPaidBean to insert.
 * @param procDate - contains the date from the header record to be inserted into DATA_CREATE_DATE.
 * @return SUCCESS or ERROR
 * @throws SQLException
 * @throws ParseException 
 */

	protected int insertInfoRecord(BillPaidBean detail, String procDate) throws SQLException, ParseException {

	try {
//		insertDetail.setDate(1, currentDt);
		DateFormat sdf = new SimpleDateFormat("MM-dd-yyyy");
		dataCreateDate	= sdf.parse(procDate);		
		insertDetail.setDate(1,new Date(dataCreateDate.getTime()));
		insertDetail.setString(2, detail.getBillPayerAccount() );	
		insertDetail.setDate(3, new Date( detail.getAcusInvoiceDate().getTime()));	
		insertDetail.setString(4, detail.getPaidAmount());	
		
		// increment the lineCount to be used for comparison against the Trailer Record Count in superclass 		lineCount++;
		lineCount++;
		
		// increment the infoRecordCounter for comparison against the Batch Size 
		infoRecordCounter++;
		
		insertDetail.addBatch();
		
		// check to see if we are ready to insert a batch into the table 		
		if (infoRecordCounter == BATCH_SIZE)
		{
			insertDetail.executeBatch();
			infoRecordCounter =0;
		}

		return SUCCESS;
		
	} catch (SQLException e) {
		severe("insert into RABC_ACUS_BILL_PAYER table failed with an SQLException "+e, e);
		throw e;
	}
}
	
	/**
	 * Determine if the input File is valid.  Create prepared statement for the Insert if the File is valid. 
	 * 
	 * @return true or false
	 * @throws SQLException
	 */

	protected boolean preprocessFile(File file) {

		boolean success = super.preprocessFile(file);

		if (!success) {
			return false;
		}
		try {
			insertDetail = connection.prepareStatement(INSERT_QUERY);
		} catch (SQLException e) {
			// TODO Log an error here.  Do we need to return false here?
			severe("prepareStatement for RABC_ACUS_BILL_PAYER table failed with an SQLException "+e, e);
			return false;
		}
		return success;
	}
	
	/**
	 * Close the insertDetail preparedStatement. Return boolean to the superclass.
	 * 
	 * @return true or false
	 * @throws SQLException
	 */
	public boolean postprocessFile(File file, boolean success) {
		//TODO If we try to close the prepared statement and it is already closed, is that a problem?

		if (!success){
			return super.postprocessFile(file, success);
		}
		
		try {
			// if more records to process, perform the last executeBatch to insert them
			if (infoRecordCounter > 0)
			{
				insertDetail.executeBatch();
			}
		} catch (SQLException e) {
			severe("postprocessFile insert into RABC_ACUS_BILL_PAYER table failed with an SQLException "+e, e);
			success = false;
		}finally{
			//close off the preparedstatement once done.
			JDBCUtil.closeStatement(insertDetail);
		}

		return super.postprocessFile(file, success);
	}	

/**
 * Handles the parsing of a line from the ACUS.CIS.INFO flat file.  
 * 
 * @param line - a String in the CIS Info Detail Record Layout.
 * @param procDate - contains the date from the header record to be inserted into DATA_CREATE_DATE.
 * @return SUCCESS or ERROR 
 * @throws ParseException 
 * @throws SQLException
 */

	protected int processRecord(String line, String procDate) throws SQLException, ParseException {

		try {
			// parse the input CIS Info Detail record
			BillPaidBean detail = BillPaidBean.valueOf(line);
			return insertInfoRecord(detail, procDate);

		} catch (SQLException e) {
			severe("insert into RABC_ACUS_BILL_PAYER table failed with an SQLException "+line, e);
			throw e;
		} catch (ParseException e) {
			severe("BillPaidBeen failed due to ParseException "+line ,e);
			throw e;
		}
	}

/**
 * Returns the filename being processed.  
 * 
 * @return name of file being processed
 */

	public String getFileId(){
	    	return "BILLPD.AMT";
	}
	    
}
