/* Created by Peter Foo (pf7941) on Dec 6, 2006.
Copyright 2006-2008 AT&T Knowledge Ventures. All rights reserved. */

package com.att.bac.rabc.load.usoc.calnet;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.att.bac.rabc.load.calnet.CalnetDAO;
import com.att.bac.rabc.load.calnet.CalnetDTO;
import com.att.bac.rabc.load.calnet.CalnetException;


/**
 * Data access object for the RABC_DAILY_USOC_ACTVT table.
 * @author pf7941
 *
 */
public class DailyUSOCActivityDAO extends CalnetDAO {

	public String INSERT_SQL = "INSERT INTO RABC_DAILY_USOC_ACTVT VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

	/* (non-Javadoc)
	 * @see com.att.bac.rabc.load.calnet.CalnetDAO#setValues(java.sql.PreparedStatement, com.att.bac.rabc.load.calnet.CalnetDTO)
	 */
	public void setValues(PreparedStatement pstmt, CalnetDTO dataTransferObject) throws CalnetException {
		DailyUSOCActivity dailyUSOCActivity = (DailyUSOCActivity) dataTransferObject;
		try {
			pstmt.setDate(1, dailyUSOCActivity.getRunDate());
			pstmt.setString(2, dailyUSOCActivity.getDivision());
			pstmt.setInt(3, dailyUSOCActivity.getCycle());
			pstmt.setString(4, dailyUSOCActivity.getAgencyId());
			pstmt.setString(5, dailyUSOCActivity.getUsoc());
			pstmt.setLong(6, dailyUSOCActivity.getFullChgTotCt());
			pstmt.setLong(7, dailyUSOCActivity.getFullChgTotAmt());
			pstmt.setLong(8, dailyUSOCActivity.getDsct50PctTotCt());
			pstmt.setLong(9, dailyUSOCActivity.getDsct50PctTotAmt());
			pstmt.setLong(10, dailyUSOCActivity.getDsct100PctTotCt());
			pstmt.setLong(11, dailyUSOCActivity.getDsct100PctTotAmt());
			pstmt.setLong(12, dailyUSOCActivity.getDsctOthPctTotCt());
			pstmt.setLong(13, dailyUSOCActivity.getDsctOthPctTotAmt());
			pstmt.setString(14, dailyUSOCActivity.getUsocAccsInd());
		}
		catch (SQLException e) {
			throw new CalnetException("Error occurred while setting values for PreparedStatement.", e);
		}
	}

	/* (non-Javadoc)
	 * @see com.att.bac.rabc.load.calnet.CalnetDAO#getInsertSql()
	 */
	protected String getInsertSql() {
		return INSERT_SQL;
	}
	
}
