/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/

package com.att.bac.rabc.admin.adhoc.rpt;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.att.bac.rabc.PresnId;
import com.att.bac.rabc.ProgressBar;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;

/**
 * Module description: 
 * 
 * This is a Service class used for adhoc report scheduler. 
 *
 * @author Anup Thomas - AT1862
 */
public class AdhocReportScheduleService {
	private static final Logger logger = Logger.getLogger(AdhocReportScheduleService.class);
	private static AdhocReportScheduleService adhocReportScheduleService;
	
	/*
	 * Variables to represent the sql statements.
	 */
	private static final String qRptList ="SELECT presn_id,rpt_time_ind,rpt_time"
										+ ",sched_rpt_num,eff_dt,exec_num_days,rpt_type,rollup_ind,division "
										+ " FROM rabc_sched_rpt	WHERE presn_id ={1}"
										+ " ORDER BY eff_dt ";
	
	private static final  String qEmailTo= "SELECT user_id,sched_rpt_num,presn_id "
										+  "FROM rabc_sched_rpt_user WHERE "  
										+ " presn_id={1} AND sched_rpt_num = {2}";
	
	private static final String  getMaxSchedRptNum = "SELECT  MAX(sched_rpt_num) FROM	rabc_sched_rpt";
	
	private static final String insSchedRpt =  "INSERT INTO rabc_sched_rpt(presn_id,rpt_time_ind"
											+ ",rpt_time,sched_rpt_num,exec_num_days"
											+ ",rpt_type,eff_dt,division)" 
											+ " VALUES(''{0}'',''{1}''"
											+ ",''{2}'',''{3}'',''{4}''"
											+ ",''{5}'',to_date(''{6}'',''mm/dd/yyyy''),''{8}'')";
	
	private static final String updSchedRpt=  "UPDATE rabc_sched_rpt set rpt_time_ind=''{1}''"
											+ ",rpt_time=''{2}'',exec_num_days=''{4}''"
											+ ",rpt_type=''{5}'',eff_dt=to_date(''{6}'',''mm/dd/yyyy''),division=''{8}'' "
											+ " WHERE presn_id=''{0}'' AND sched_rpt_num=''{7}''";
	
	private static final String delEmailList=  "DELETE FROM rabc_sched_rpt_user "
											 + "WHERE presn_id=''{0}'' AND sched_rpt_num=''{1}''";
	
	private static final String insEmailList = "INSERT INTO rabc_sched_rpt_user" 
											 + " (presn_id,sched_rpt_num,user_id)"
											 + " VALUES(''{0}'',''{1}'',''{2}'')";
	
	private static final String delSchedRpt = "DELETE FROM rabc_sched_rpt WHERE sched_rpt_num=''{0}'' ";
	
	private static final String delSchedUserRpt = "DELETE FROM rabc_sched_rpt_user WHERE sched_rpt_num=''{0}'' ";
	
	/**
	 * Synchronized method to ensure that there is a single instance of this class created & used for all instances
	 * of action. It is ensured that there are no data members in the class
	 * 
	 * @return AdhocReportScheduleService
	 */
	public static synchronized AdhocReportScheduleService getAdhocReportScheduleService (){
		if (adhocReportScheduleService == null){
			adhocReportScheduleService = new AdhocReportScheduleService();
		}	
		return adhocReportScheduleService;
	}
	
	/**
	 * This method is used to get the adhoc report scheduler list for the given presn id from the rabc_sched_rpt table
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param region
	 * @return List
	 */
	public List getAdhocReportScheduleList(Connection connection, List failureList,List args,String region){
		/*
		 * Get the schedRpt objects for the given presn id from the rabc_sched_rpt table
		 */
		List  adhocReportScheduleList = new ArrayList();
		SchedRptDAO  schedRptDAO = new SchedRptDAO();
		List schedRptList = new ArrayList();
		schedRptList = schedRptDAO.get(connection,failureList,args,qRptList);
		
		/*
		 * Get the list of adhoc reports (presntations) from the rabc_presn_id table
		 */
		List emailArgs = args;
		AdhocReportDefinitionService  adhocReportDefinitionService = AdhocReportDefinitionService.getAdhocReportDefinitionService();
		List presnIdList =  adhocReportDefinitionService.getPresenDetails(connection,failureList,args) ;
		
		PresnId presnId = (PresnId)presnIdList.get(0);
		String reportName = presnId.getPresnIdDesc();
		int schedRptListSize = schedRptList.size();
		
		for (int i=0;i<schedRptListSize;i++){
			SchedRpt schedRpt = (SchedRpt) schedRptList.get(i);
			emailArgs.add(Integer.toString(schedRpt.getSchedRptNum()));
			
			AdhocReportSchedule adhocReportSchedule = new AdhocReportSchedule(region);
			adhocReportSchedule.setReportName(reportName);
			adhocReportSchedule.setSchedRptNum(Integer.toString(schedRpt.getSchedRptNum()));
			adhocReportSchedule.setDays(Integer.toString(schedRpt.getExecNumDays()));
			adhocReportSchedule.setEmailTo(getEmailList(connection,failureList,emailArgs));
			adhocReportSchedule.setFrequency(schedRpt.getRptTimeInd());
			if ((schedRpt.getDivision()==null)||("".equals(schedRpt.getDivision()))){
				adhocReportSchedule.setDivision("ALL");
			}else{
				adhocReportSchedule.setDivision(schedRpt.getDivision());
			}
			int rptTime=schedRpt.getRptTime();
			
			String rptTimeString = Integer.toString(rptTime); 
			if (schedRpt.getRptTimeInd().equals("B")){
				String RunDay = rptTimeString.substring(rptTimeString.length()-2,rptTimeString.length());
				String cycleCode="";
				if (rptTimeString.length()==4){
					cycleCode = rptTimeString.substring(0,2);
				}else{
					cycleCode = rptTimeString.substring(0,1);
				}
				
				adhocReportSchedule.setFrequencyDataRunDay(RunDay);
				adhocReportSchedule.setFrequencyDataCycleCode(cycleCode);	
			}else if(schedRpt.getRptTimeInd().equals("W")){
				adhocReportSchedule.setFrequencyDataWeekly(rptTimeString);
			}else if(schedRpt.getRptTimeInd().equals("M")){
				adhocReportSchedule.setFrequencyDataMonthly(rptTimeString);
			}else if(schedRpt.getRptTimeInd().equals("Y")){
				adhocReportSchedule.setFrequencyDataYearly(rptTimeString);
				String yearDataMonth;
				String yearDataYear;
				yearDataYear = rptTimeString.substring(rptTimeString.length()-2,rptTimeString.length());
				if (rptTimeString.length()==4){
					yearDataMonth = rptTimeString.substring(0,2);
				}else{
					yearDataMonth = rptTimeString.substring(0,1);
				}
				adhocReportSchedule.setFrequencyDataYearlyMonth(yearDataMonth);
				adhocReportSchedule.setFrequencyDataYearlyYear(yearDataYear);
			}
			
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy");
			adhocReportSchedule.setStartDate(simpleDateFormat.format(schedRpt.getEffDt()));
			
			if ("D".equals(schedRpt.getRptType()) || "B".equals(schedRpt.getRptType())){
				adhocReportSchedule.setSaveToDisk("Y");
			}
			
			adhocReportScheduleList.add(adhocReportSchedule);
			emailArgs.remove(2);
		}
	
		return(adhocReportScheduleList);
	}
	
	/**
	 * This Method is used to get the list of users to whom the give schedule needs to notify
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return String
	 */
	private String getEmailList(Connection connection,List failureList,List args){	
		String emailString = "";
		SchedRptUserDAO  schedRptUserDAO = new SchedRptUserDAO();
		List schedRptUserList =  new ArrayList();
		schedRptUserList = schedRptUserDAO.get(connection,failureList,args,qEmailTo);
		if (schedRptUserList!=null){
			int schedRptUserListSize = schedRptUserList.size();
			for (int i=0;i<schedRptUserListSize;i++){
				SchedRptUser schedRptUser = (SchedRptUser)schedRptUserList.get(i);
				if ("".equals(emailString)){
					emailString = schedRptUser.getUserId();
				}else{
					emailString = emailString+","+ schedRptUser.getUserId();
				}
			}
		}
		return emailString;
	}

	/**
	 * This method is used to add the given schedule to the rabc_sched_rpt table
	 * @param connection
	 * @param failureList
	 * @param adhocReportSchedule
	 * @param progressBar
	 */
	public void addSchedule(Connection connection , List failureList,AdhocReportSchedule adhocReportSchedule,ProgressBar progressBar){
		int maxSchedRptNum = getMaxSchedRptNum(connection,failureList);
		progressBar.setProgressPercent(50);
		maxSchedRptNum = maxSchedRptNum+1;
		List arguments = new ArrayList();

		arguments.add(Integer.toString(adhocReportSchedule.getPresnId()));
		arguments.add(adhocReportSchedule.getFrequency());
		String frequencyData ="";
		if (adhocReportSchedule.getFrequency().equals("B")){
			frequencyData=adhocReportSchedule.getFrequencyDataCycleCode()+adhocReportSchedule.getFrequencyDataRunDay();
		}else if (adhocReportSchedule.getFrequency().equals("W")){
			frequencyData=adhocReportSchedule.getFrequencyDataWeekly();
		}else if (adhocReportSchedule.getFrequency().equals("M")){
			frequencyData=adhocReportSchedule.getFrequencyDataMonthly();
		}else if (adhocReportSchedule.getFrequency().equals("Y")){
			
			frequencyData=adhocReportSchedule.getFrequencyDataYearly().replaceAll("/","");
		}
		progressBar.setProgressPercent(60);
		
		arguments.add(frequencyData);
		arguments.add(Integer.toString(maxSchedRptNum));
		arguments.add(adhocReportSchedule.getDays());
		if ("Y".equals(adhocReportSchedule.getSaveToDisk())){
			if (adhocReportSchedule.getEmailTo().length()>0){
				arguments.add("B");
			}else{
				arguments.add("D");
			}
		}else{
			arguments.add("E");
		}
		progressBar.setProgressPercent(70);
		arguments.add(adhocReportSchedule.getStartDate());
		arguments.add(adhocReportSchedule.getSchedRptNum());
		arguments.add(adhocReportSchedule.getDivision());
		
		SchedRptDAO schedRptDAO = new SchedRptDAO();
		
		if ("0".equals(adhocReportSchedule.getSchedRptNum())){
			schedRptDAO.executeUpdate(connection,failureList,arguments,insSchedRpt);
			progressBar.setProgressPercent(80);
			saveEmailList(connection,failureList,adhocReportSchedule.getPresnId(),maxSchedRptNum,adhocReportSchedule.getEmailTo());
			progressBar.setProgressPercent(90);
		}else{
			schedRptDAO.executeUpdate(connection,failureList,arguments,updSchedRpt);
			progressBar.setProgressPercent(80);
			saveEmailList(connection,failureList,adhocReportSchedule.getPresnId(),Integer.parseInt(adhocReportSchedule.getSchedRptNum()),adhocReportSchedule.getEmailTo());
			progressBar.setProgressPercent(90);
		}
	}
	
	/**
	 * This method is used to save the list of users to whom the given schedule needs to notify to the rabc_sched_rpt_user table
	 * @param connection
	 * @param failureList
	 * @param presnId
	 * @param schedRptNum
	 * @param emailTo
	 */
	private void saveEmailList(Connection connection,List failureList,int presnId,int schedRptNum,String emailTo){
		List emailInsArgs = new ArrayList();
		List emailDelArgs = new ArrayList();
		String[] userIdArray;
		
		emailInsArgs.add(Integer.toString(presnId));
		emailInsArgs.add(Integer.toString(schedRptNum));
		
		emailDelArgs.add(Integer.toString(presnId));
		emailDelArgs.add(Integer.toString(schedRptNum));
		
		userIdArray = emailTo.split(",");
		
		int userIdArraySize = userIdArray.length;
		
		SchedRptUserDAO schedRptUserDAO = new SchedRptUserDAO();
		schedRptUserDAO.executeUpdate(connection,failureList,emailDelArgs,delEmailList);
		
		for (int i=0;i<userIdArraySize;i++){
			emailInsArgs.add(userIdArray[i]);
			schedRptUserDAO.executeUpdate(connection,failureList,emailInsArgs,insEmailList);
			emailInsArgs.remove(2);
		}
	}
	
	/**
	 * This method is used delete the given schedule from the rabc_sched_rpt table
	 * @param connection
	 * @param failureList
	 * @param selectedScheduleId
	 * @param progressBar
	 */
	public void deleteSchedule(Connection connection,List failureList,String selectedScheduleId,ProgressBar progressBar){
		List delArgs = new ArrayList();
		delArgs.add(selectedScheduleId);
		SchedRptDAO  schedRptDAO = new SchedRptDAO();
		SchedRptUserDAO schedRptUserDAO = new SchedRptUserDAO();
		progressBar.setProgressPercent(40);
		
		schedRptDAO.executeUpdate(connection,failureList,delArgs,delSchedRpt);
		progressBar.setProgressPercent(70);
		schedRptUserDAO.executeUpdate(connection,failureList,delArgs,delSchedUserRpt);
		progressBar.setProgressPercent(90);
	}
	
	/**
	 * This method is used to get the maximum scheduler number 
	 * @param connection
	 * @param failureList
	 * @return int
	 */
	private int getMaxSchedRptNum(Connection connection,List failureList){
		int maxSchedRptNum=0;
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		List args = new ArrayList();
		try {
			MessageFormat mf = new MessageFormat(getMaxSchedRptNum);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			
			while(rs.next()){
				maxSchedRptNum = rs.getInt(1);
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		return (maxSchedRptNum);
	}
}
