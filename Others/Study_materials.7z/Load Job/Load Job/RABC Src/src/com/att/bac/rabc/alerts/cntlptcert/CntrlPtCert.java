/*
 * Module description:
 * This is a Data Object for RABC_CNTRL_PT_CERT table for 
 * 
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 * 
 * Modification History:
 * SBCUID        Date            Description
 * ------        --------        -----------
 * VD3159        20060124        Initial Version for EAP 556010
 * 
*/
package com.att.bac.rabc.alerts.cntlptcert;
import java.util.Date;

/**
 * CntrlPtCert is java representation for RABC_CNTRL_PT_CERT table
 *
 */
public class CntrlPtCert {
	private int certNum;
	private Date runDate;
	private String division;
	private String cntrlPtCode;
	private String certInd;
	private String issueInd;
	private String userId;
	private int issueRevenueCr;
	private int issueRevenueDb;
	private int issueLostRevenue;
	private Date timeStamp;

	/**
	 * @return Returns the CertNum.
	 */
	public int getCertNum() {
		return certNum;
	}
	/**
	 * @return Returns the RunDate.
	 */
	public Date getRunDate() {
		return runDate;
	}
	/**
	 * @return Returns the Division.
	 */
	public String getDivision() {
		return division;
	}
	/**
	 * @return Returns the CntrlPtCode.
	 */
	public String getCntrlPtCode() {
		return cntrlPtCode;
	}
	/**
	 * @return Returns the CertInd.
	 */
	public String getCertInd() {
		return certInd;
	}
	/**
	 * @return Returns the IssueInd.
	 */
	public String getIssueInd() {
		return issueInd;
	}
	/**
	 * @return Returns the UserId.
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @return Returns the IssueRevenueCr.
	 */
	public int getIssueRevenueCr() {
		return issueRevenueCr;
	}
	/**
	 * @return Returns the IssueRevenueDb.
	 */
	public int getIssueRevenueDb() {
		return issueRevenueDb;
	}
	/**
	 * @return Returns the IssueLostRevenue.
	 */
	public int getIssueLostRevenue() {
		return issueLostRevenue;
	}
	/**
	 * @return Returns the TimeStamp.
	 */
	public Date getTimeStamp() {
		return timeStamp;
	}

	/**
	 * @param CertNum The certNum to set.
	 */
	public void setCertNum(int certNum) {
		this.certNum = certNum;
	}
	/**
	 * @param RunDate The runDate to set.
	 */
	public void setRunDate(Date runDate) {
		this.runDate = runDate;
	}
	/**
	 * @param Division The division to set.
	 */
	public void setDivision(String division) {
		this.division = division;
	}
	/**
	 * @param CntrlPtCode The cntrlPtCode to set.
	 */
	public void setCntrlPtCode(String cntrlPtCode) {
		this.cntrlPtCode = cntrlPtCode;
	}
	/**
	 * @param CertInd The certInd to set.
	 */
	public void setCertInd(String certInd) {
		this.certInd = certInd;
	}
	/**
	 * @param IssueInd The issueInd to set.
	 */
	public void setIssueInd(String issueInd) {
		this.issueInd = issueInd;
	}
	/**
	 * @param UserId The userId to set.
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	/**
	 * @param IssueRevenueCr The issueRevenueCr to set.
	 */
	public void setIssueRevenueCr(int issueRevenueCr) {
		this.issueRevenueCr = issueRevenueCr;
	}
	/**
	 * @param IssueRevenueDb The issueRevenueDb to set.
	 */
	public void setIssueRevenueDb(int issueRevenueDb) {
		this.issueRevenueDb = issueRevenueDb;
	}
	/**
	 * @param IssueLostRevenue The issueLostRevenue to set.
	 */
	public void setIssueLostRevenue(int issueLostRevenue) {
		this.issueLostRevenue = issueLostRevenue;
	}
	/**
	 * @param TimeStamp The timeStamp to set.
	 */
	public void setTimeStamp(Date timeStamp) {
		this.timeStamp = timeStamp;
	}
}
