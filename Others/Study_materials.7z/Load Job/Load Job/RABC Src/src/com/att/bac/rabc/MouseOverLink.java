/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc;
/**
 * This is a Data Object to represent RABC_MOUSE_OVER_LINK table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class MouseOverLink {
	private int presnId;
	private String webid;
	private int execPresnSeqNum;
	private int mouseOverNum;
	private String linkTblKeyName;
	private String linkTblKeyData;
	private String linkTblName;

	/**
	 * @return Returns the PresnId.
	 */
	public int getPresnId() {
		return presnId;
	}
	/**
	 * @return Returns the Webid.
	 */
	public String getWebid() {
		return webid;
	}
	/**
	 * @return Returns the ExecPresnSeqNum.
	 */
	public int getExecPresnSeqNum() {
		return execPresnSeqNum;
	}
	/**
	 * @return Returns the MouseOverNum.
	 */
	public int getMouseOverNum() {
		return mouseOverNum;
	}
	/**
	 * @return Returns the LinkTblKeyName.
	 */
	public String getLinkTblKeyName() {
		return linkTblKeyName;
	}
	/**
	 * @return Returns the LinkTblKeyData.
	 */
	public String getLinkTblKeyData() {
		return linkTblKeyData;
	}
	/**
	 * @return Returns the LinkTblName.
	 */
	public String getLinkTblName() {
		return linkTblName;
	}

	/**
	 * @param PresnId The presnId to set.
	 */
	public void setPresnId(int presnId) {
		this.presnId = presnId;
	}
	/**
	 * @param Webid The webid to set.
	 */
	public void setWebid(String webid) {
		this.webid = webid;
	}
	/**
	 * @param ExecPresnSeqNum The execPresnSeqNum to set.
	 */
	public void setExecPresnSeqNum(int execPresnSeqNum) {
		this.execPresnSeqNum = execPresnSeqNum;
	}
	/**
	 * @param MouseOverNum The mouseOverNum to set.
	 */
	public void setMouseOverNum(int mouseOverNum) {
		this.mouseOverNum = mouseOverNum;
	}
	/**
	 * @param LinkTblKeyName The linkTblKeyName to set.
	 */
	public void setLinkTblKeyName(String linkTblKeyName) {
		this.linkTblKeyName = linkTblKeyName;
	}
	/**
	 * @param LinkTblKeyData The linkTblKeyData to set.
	 */
	public void setLinkTblKeyData(String linkTblKeyData) {
		this.linkTblKeyData = linkTblKeyData;
	}
	/**
	 * @param LinkTblName The linkTblName to set.
	 */
	public void setLinkTblName(String linkTblName) {
		this.linkTblName = linkTblName;
	}
}
