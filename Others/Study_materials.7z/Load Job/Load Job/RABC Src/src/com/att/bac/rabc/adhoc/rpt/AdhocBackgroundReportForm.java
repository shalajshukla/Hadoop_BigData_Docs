package com.att.bac.rabc.adhoc.rpt;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.att.bac.rabc.PickList;
import com.att.bac.rabc.SortedForm;

public class AdhocBackgroundReportForm extends SortedForm{

	private static final long serialVersionUID = -8294769493377746922L;
	/**Logger reference to log4j logger*/
    public static Logger logger = Logger.getLogger(AdhocBackgroundReportForm.class);
    private String fileStartDate;
    private String fileEndDate;
    
    private List<AdhocBackgroundReport> adhocBackgroundReportList = new ArrayList<AdhocBackgroundReport>();
    private int totalBackgroundReports;
    
	private String reportName;
	private List<PickList> reportNameList = new ArrayList<PickList>();
    
	private String[] userName;
	private List<PickList> userNameList = new ArrayList<PickList>();

	private String[] status_cd;
	private List<PickList> statusesList = new ArrayList<PickList>();

	private int pageshow;
	
	private int pageSize;
	
	private String message;
	
	//coma separated list of all the reports that have been selected for deleted.
	private String checkedReports;
	
	
	public AdhocBackgroundReportForm() {
		this.setPreviousSortItem("sub_rpt_tm");
		this.setSortItem("sub_rpt_tm");
		this.setSortOrder("DESC");
	}

	public int getPageshow() {
		return pageshow;
	}

	public void setPageshow(int pageshow) {
		this.pageshow = pageshow;
	}

	public String getFileStartDate() {
		return fileStartDate;
	}

	public void setFileStartDate(String fileStartDate) {
		this.fileStartDate = fileStartDate;
	}

	public String getFileEndDate() {
		return fileEndDate;
	}

	public void setFileEndDate(String fileEndDate) {
		this.fileEndDate = fileEndDate;
	}

	/**
	 * @return Returns the processPoint.
	 */
	public String getReportName() {
		return reportName;
	}
	/**
	 * @param processPoint The processPoint to set.
	 */
	public void setReportName(String reportName) {
		this.reportName = reportName;
	}
	/**
	 * @return Returns the processPointList.
	 */
	public List<PickList> getReportNameList() {
		return reportNameList;
	}
	/**
	 * @param processPoint The processPoint to add.
	 */
	public void addReportName(PickList reportName) {
		this.reportNameList.add(reportName);
	}

	public List<PickList> getUserNameList() {
		return userNameList;
	}
	
	public void addUserName(PickList userName) {
		this.userNameList.add(userName);
	}
	

	public List<PickList> getStatusesList() {
		return statusesList;
	}
		
	public void addStatuses(PickList status_cd) {
		this.statusesList.add(status_cd);
	}
	
	
	public List<AdhocBackgroundReport> getAdhocBackgroundReportList() {
		return adhocBackgroundReportList;
	}
	/**
	 * @param alertReportDetailList The alertReportDetailList to add.
	 */
	public void addAdhocBackgroundReportDetail(AdhocBackgroundReport adhocBackgroundReport) {
		this.adhocBackgroundReportList.add(adhocBackgroundReport);
	}

	public String[] getUserName() {
		return userName;
	}

	public void setUserName(String[] userName) {
		this.userName = userName;
	}

	public String[] getStatus_cd() {
		return status_cd;
	}

	public void setStatus_cd(String[] status_cd) {
		this.status_cd = status_cd;
	}

	public int getTotalBackgroundReports() {
		return totalBackgroundReports;
	}

	public void setTotalBackgroundReports(int totalBackgroundReports) {
		this.totalBackgroundReports = totalBackgroundReports;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getCheckedReports() {
		return checkedReports;
	}

	public void setCheckedReports(String checkedReports) {
		this.checkedReports = checkedReports;
	}	

}
