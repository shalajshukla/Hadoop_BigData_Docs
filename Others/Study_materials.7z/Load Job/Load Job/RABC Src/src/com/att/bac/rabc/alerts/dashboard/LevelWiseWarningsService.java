/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/

package com.att.bac.rabc.alerts.dashboard;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;

/**
 * This class represents the Service that holds the Level Wise Warnings List.
 * 
 * @author Sandhya Chinala - SC3837
 */
public class LevelWiseWarningsService {
	private static final Logger logger = Logger.getLogger(LevelWiseWarningsService.class);
	private static LevelWiseWarningsService levelWiseWarningsService;
	
	/**
	 * Synchronized method to return the instance of LevelWiseWarningsService object.
	 * It checks the existance of the instance of LevelWiseWarningsService and if it does not exists
	 * then creates one instance of LevelWiseWarningsService and returns otherwise it returns the
	 * existing instance of LevelWiseWarningsService.
	 * 
	 * @return LevelWiseWarningsService
	 */
	public static synchronized LevelWiseWarningsService getLevelWiseWarningsService(){
		if (levelWiseWarningsService == null) {
			levelWiseWarningsService = new LevelWiseWarningsService();
		}
		return levelWiseWarningsService;
	}
	
	public List getLevelWiseWarningList(Connection connection, List failureList, List args, String userId){
		List levelWiseWarningList = new ArrayList();
		LevelWiseWarnings highLevelWiseWarnings = new LevelWiseWarnings();
		LevelWiseWarnings mediumLevelWiseWarnings = new LevelWiseWarnings();
		LevelWiseWarnings lowLevelWiseWarnings = new LevelWiseWarnings();
		LevelWiseWarnings noneLevelWiseWarnings = new LevelWiseWarnings();
		LevelWiseWarnings notRunLevelWiseWarnings = new LevelWiseWarnings();
		LevelWiseWarnings warningStatusWiseWarnings = new LevelWiseWarnings();
		LevelWiseWarnings pendingStatusWiseWarnings = new LevelWiseWarnings();
		LevelWiseWarnings closedStatusWiseWarnings = new LevelWiseWarnings();
		int size = 0;
		
		/*
		 * Construct level wise warning for Tier 3
		 */
		List highLevelList = DivisionWiseAlertSummaryService.getDivisionWiseAlertSummaryService().getHighLevel(connection,failureList,args,userId);
		if (!failureList.isEmpty()) {
			return null;
		}
		if (highLevelList != null) {
			for (int i=0;i<highLevelList.size();i++){
				highLevelWiseWarnings.addDivisionWiseAlertSummary((DivisionWiseAlertSummary)highLevelList.get(i));
			}
		}
		levelWiseWarningList.add(highLevelWiseWarnings);
	
		/*
		 * Construct level wise warning for Tier 2
		 */
		List mediumLevelList = DivisionWiseAlertSummaryService.getDivisionWiseAlertSummaryService().getMediumLevel(connection,failureList,args,userId);
		if (!failureList.isEmpty()) {
			return null;
		}
		if (mediumLevelList != null) {
			for (int i=0;i<mediumLevelList.size();i++){
				mediumLevelWiseWarnings.addDivisionWiseAlertSummary((DivisionWiseAlertSummary)mediumLevelList.get(i));
			}
		}
		levelWiseWarningList.add(mediumLevelWiseWarnings);
		
		/*
		 * Construct level wise warning for Tier 1
		 */
		List lowLevelList = DivisionWiseAlertSummaryService.getDivisionWiseAlertSummaryService().getLowLevel(connection,failureList,args, userId);
		if (!failureList.isEmpty()) {
			return null;
		}
		if (lowLevelList != null) {
			for (int i=0;i<lowLevelList.size();i++){
				lowLevelWiseWarnings.addDivisionWiseAlertSummary((DivisionWiseAlertSummary)lowLevelList.get(i));
			}
		}
		levelWiseWarningList.add(lowLevelWiseWarnings);
		
		/*
		 * Construct level wise warning for None
		 */
		List noneList = DivisionWiseAlertSummaryService.getDivisionWiseAlertSummaryService().getNoIssueCnt(connection,failureList,args,userId);
		if (!failureList.isEmpty()) {
			return null;
		}
		if (noneList != null) {
			for (int i=0;i<noneList.size();i++){
				noneLevelWiseWarnings.addDivisionWiseAlertSummary((DivisionWiseAlertSummary)noneList.get(i));
			}
		}
		levelWiseWarningList.add(noneLevelWiseWarnings);
	 	
		/*
		 * Construct level wise warning for Not Run
		 */
		String dashboardType = (String) args.get(4);
		if (dashboardType.equals("3")){
			List notRunList = DivisionWiseAlertSummaryService.getDivisionWiseAlertSummaryService().getNotRun(connection,failureList,args);
			if (!failureList.isEmpty()) {
				return null;
			}
			if (notRunList != null) {
				for (int i=0;i<notRunList.size();i++){
					notRunLevelWiseWarnings.addDivisionWiseAlertSummary((DivisionWiseAlertSummary)notRunList.get(i));
				}
			}
			levelWiseWarningList.add(notRunLevelWiseWarnings);
		}
		
		/*
		 * Construct level wise warning for Warning Status
		 */
		List warningStatusList = DivisionWiseAlertSummaryService.getDivisionWiseAlertSummaryService().getWarningStatus(connection,failureList,args,userId);
		if (!failureList.isEmpty()) {
			return null;
		}
		if (warningStatusList != null) {
			size = warningStatusList.size();
			for (int i=0;i<size;i++){
				warningStatusWiseWarnings.addDivisionWiseAlertSummary((DivisionWiseAlertSummary)warningStatusList.get(i));
			}
		}
		levelWiseWarningList.add(warningStatusWiseWarnings);
		
		/*
		 * Construct level wise warning for Pending Status
		 */
		List pendingStatusList = DivisionWiseAlertSummaryService.getDivisionWiseAlertSummaryService().getPendingStatus(connection,failureList,args,userId);
		if (!failureList.isEmpty()) {
			return null;
		}
		if (pendingStatusList != null) {
			size = pendingStatusList.size();
			for (int i=0;i<size;i++){
				pendingStatusWiseWarnings.addDivisionWiseAlertSummary((DivisionWiseAlertSummary)pendingStatusList.get(i));
			}
		}
		levelWiseWarningList.add(pendingStatusWiseWarnings);
		
		/*
		 * Construct level wise warning for Closed Status
		 */
		List closedStatusList = DivisionWiseAlertSummaryService.getDivisionWiseAlertSummaryService().getClosedStatus(connection,failureList,args,userId);
		if (!failureList.isEmpty()) {
			return null;
		}
		if (closedStatusList != null) {
			size = closedStatusList.size();
			for (int i=0;i<size;i++){
				closedStatusWiseWarnings.addDivisionWiseAlertSummary((DivisionWiseAlertSummary)closedStatusList.get(i));
			}
		}
		levelWiseWarningList.add(closedStatusWiseWarnings);
		
		return levelWiseWarningList;
	}
}
