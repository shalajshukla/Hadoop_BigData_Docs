package com.att.bac.rabc.billprintcontrols;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DateFormat;
//import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;
//import java.util.StringTokenizer;
//changes for M168 by as635b
//import com.sbc.bac.load.Application;
import com.att.carat.load.Application;
//import com.sbc.bac.load.FileDBLoadJob;
import com.att.carat.load.LoadJob;
import com.att.carat.load.MultipleConnectionApplication;
import com.att.carat.load.enums.ProcessResult;
import com.att.carat.load.enums.Result;
//import com.sbc.bac.load.LoadJob;
//import com.sbc.bac.load.MultipleConnectionApplication;
//import com.sbc.bac.load.enums.ProcessResult;
//import com.sbc.bac.load.enums.Result;
import com.sbc.bac.rabc.load.RabcLoadJobTrig;
import com.sbc.bac.rabc.load.StaticErrorMsgKeys;

public class RabcBcamLoad extends LoadJob {
	public static final String BCAM_FILE_ID = "md51457.s90.";
	private static final String SOUTHWEST_REGION = "SW";
	private static final String MIDWEST_REGION = "MW";
	private static final String WEST_REGION = "WE";
	private static final String SOUTHEAST_REGION = "SE";
	private static final String MOSS_SOUTHWEST_CRIS_NL_REGION = "S";
	private static final String MOSS_MIDWEST_REGION = "A";
	private static final String MOSS_WEST_REGION = "P";
	private static final String MOSS_SOUTHEAST_REGION = "B";
	private static final String PROD_TYPE_BILLS = "Bills";
	private static final int MID_LENGTH = 5;
	private static final int PROCESS_DATE_LENGTH = 8;
	private static final int PROCESSING_ENTITY_LENGTH = 3;
	private static final int LEG_LENGTH = 2;
	private static final int SEQ_NUMBER_LENGTH = 2;
	private static final int REGION_LENGTH = 2;
	private static final int DIVISION_LENGTH = 1;
	private static final int PROD_TYPE_LENGTH = 10;
	private static final int TOT_NUM_BILLS_LENGTH = 10;
	private PreparedStatement insert_bcam_SW;
	private PreparedStatement insert_bcam_MW;
	private PreparedStatement insert_bcam_WE;
	private PreparedStatement insert_bcam_SE;
	private static final int BATCH_SIZE = 5000;
	private int infoRecordCounterSW = 0;
	private int infoRecordCounterMW = 0;
	private int infoRecordCounterWE = 0;
	private int infoRecordCounterSE = 0;
	private int lineCount;
	private ArrayList<String> swTriggers = new ArrayList<String>();
	private ArrayList<String> mwTriggers = new ArrayList<String>();
	private ArrayList<String> weTriggers = new ArrayList<String>();
	private ArrayList<String> seTriggers = new ArrayList<String>();
	private File currentFile;
	private String runDate = "";
	private boolean fileAlreadyLoaded = false;
	// BCAM sourced file: md51457.s90.08-14-08.04-04-25.0195
	private static final FileFilter BCAM_FILTER= new FileFilter(){public boolean accept(File pathname){
		return pathname.getName().startsWith(BCAM_FILE_ID);
		//return pathname.getName().matches(AccountDetailBean.FILE_NAME_PATTERN);
	}};
	
	// create a Hashtable to maintain the mapping of MOSS regions to RABC regions
	protected static HashMap<String, String> REGION_MAP = new HashMap<String, String>();
	static {
		REGION_MAP.put("P", "WE"); // P denotes West
		REGION_MAP.put("X", "WE"); // X denotes West CABS
		REGION_MAP.put("WE", "WE"); // in case the input file has WE
		REGION_MAP.put("A", "MW");  // A denotes MW
		REGION_MAP.put("Z", "MW"); // Z denotes MW CABS
		REGION_MAP.put("MW", "MW"); // in case the input file has MW
		REGION_MAP.put("S", "SW"); // S denotes SW CRIS (NL)
		REGION_MAP.put("Y", "SW"); // Y denotes SW CABS
		REGION_MAP.put("SW", "SW"); // in case the input file has SW
		
		REGION_MAP.put("B", "SE"); // S denotes SE CRIS (NL)
		//REGION_MAP.put("Y", "SW"); // Y denotes SW CABS
		REGION_MAP.put("SE", "SE"); // in case the input file has SW
	}
	
	// create Hashtables to maintain the mapping of MOSS divisions to RABC divisions
	protected static HashMap<String, String> WEST_DIVISION_MAP = new HashMap<String, String>();
	protected static HashMap<String, String> MW_DIVISION_MAP = new HashMap<String, String>();
	// MOSS to RABC division mapping for West Region
	static {
		WEST_DIVISION_MAP.put("F","PN"); // Northern California
		WEST_DIVISION_MAP.put("S","PS"); // Southern California
        WEST_DIVISION_MAP.put("V","NB"); // Nevada
        
        WEST_DIVISION_MAP.put("PN","PN"); // Northern California, in case input file has PN
		WEST_DIVISION_MAP.put("PS","PS"); // Southern California, in case input file has PS
        WEST_DIVISION_MAP.put("NB","NB"); // Nevada, in case input file has NB
	}
	// MOSS to RABC division mapping for MW Region
	static {
		MW_DIVISION_MAP.put("Q","L"); // Illinois
		MW_DIVISION_MAP.put("M","M"); // Michigan
		MW_DIVISION_MAP.put("G","N"); // Indiana
		MW_DIVISION_MAP.put("E","W"); // Wisconsin
		MW_DIVISION_MAP.put("J","O"); // Ohio
	
		MW_DIVISION_MAP.put("L","L"); // Illinois
		MW_DIVISION_MAP.put("N","N"); // Indiana
		MW_DIVISION_MAP.put("W","W"); // Wisconsin
		MW_DIVISION_MAP.put("O","O"); // Ohio
	}
	
	protected static HashMap<String, String> SE_DIVISION_MAP = new HashMap<String, String>();
	// MOSS to RABC division mapping for SE Region
	static {
		SE_DIVISION_MAP.put("A","A"); // Alabama
		SE_DIVISION_MAP.put("K","K"); // kentuky
		SE_DIVISION_MAP.put("L","L"); // Lousiaana
		SE_DIVISION_MAP.put("M","M"); // Mississipi
		SE_DIVISION_MAP.put("O","O"); // Atlanta
		SE_DIVISION_MAP.put("L","L"); // Illinois
		SE_DIVISION_MAP.put("P","P"); // Macon
		SE_DIVISION_MAP.put("Q","Q"); // Mimai
		SE_DIVISION_MAP.put("R","R"); // FortLaudedale
		SE_DIVISION_MAP.put("T","T"); // Tennesse
		SE_DIVISION_MAP.put("W","W"); // South carolina
		SE_DIVISION_MAP.put("X","X"); // Noth carolina
		SE_DIVISION_MAP.put("Y","Y"); // Jacksonville
	}
	
	
	
	// Division codes are the same for MOSS and RABC in SW Region. Therefore no mapping is being provided for the SW region.
	
	protected static final int SUCCESS = Result.SUCCESS.toInt();
	protected static final int SKIPPED = Result.SKIPPED.toInt();
	protected static final int ERROR = Result.ERROR.toInt();
	protected static final int DUPLICATE = ProcessResult.DUPLICATE.toInt();
	protected static int EMPTY_FILE = ProcessResult.EMPTY_FILE.toInt();
	protected MultipleConnectionApplication multiApplication = null;
	protected String notify_users;
	protected File	source_directory;
	protected File	archive_directory;
	protected File	error_directory;
	protected Connection ORAconnection = null;
	protected Connection oraConnectionSW = null;
	protected Connection oraConnectionMW = null;
	protected Connection oraConnectionW = null;
	protected Connection oraConnectionSE = null;
	protected int	counter[];
	
	public static String INSERT_RABC_BCAM() {
		StringBuffer sb = new StringBuffer();
		sb.append("INSERT INTO RABC_BCAM(RUN_DATE, REGION, DIVISION, PROD_TYPE, TOT_NUM_BILLS)");
		sb.append(" VALUES(?,?,?,?,?)");
		return sb.toString();
	}
	
	protected boolean configure(Application application, Properties properties) {
		boolean success = super.configure(application, properties);
		if (!success) 
			return false;
		
		if (success) {
			try {
				this.multiApplication = (MultipleConnectionApplication) application;
			}
			catch (Exception e) {
				severe("Invalid application class: " + application.getClass().getName()
						+ ". Please use a MultipleConnectionApplication");
			}
		}
		
		// Read the source directory name, archive directory name and error directory name from config file
		String source_directory_path = properties.getProperty("source_directory");
		String archive_directory_path = properties.getProperty("archive_directory");
		String error_directory_path = properties.getProperty("error_directory");
	
		if (source_directory_path == null || source_directory_path.equals("") ||
				archive_directory_path == null || archive_directory_path.equals("") ||
				error_directory_path == null || error_directory_path.equals("")) {
			severe("Directory parameters missing");
			return false;
		}
			
		source_directory = new File(properties.getProperty("source_directory"));
		archive_directory = new File(properties.getProperty("archive_directory"));
		error_directory = new File(properties.getProperty("error_directory"));
	
		//System.out.println("Source dir.:" + source_directory);
		return success;
	}

	public boolean preprocess() {
		boolean success = super.preprocess();
		if(success){
			try {
				insert_bcam_SW = oraConnectionSW.prepareStatement(INSERT_RABC_BCAM());
				insert_bcam_MW = oraConnectionMW.prepareStatement(INSERT_RABC_BCAM());
				insert_bcam_WE = oraConnectionW.prepareStatement(INSERT_RABC_BCAM());
				insert_bcam_SE = oraConnectionSE.prepareStatement(INSERT_RABC_BCAM());
			} catch (SQLException e) {
				severe("Exception while creating prepareStatement "+e, e );
				success = false;
			}
		}
		return success;
	}
	
	protected boolean check() {
		
		boolean result = false;
		
		File files[] = source_directory.listFiles(BCAM_FILTER);
		if (files != null && files.length > 0) // Are there any BCAM sourced files from MOSS to process
			result = true;
		
		try{
			if (oraConnectionSW == null || oraConnectionSW.isClosed())
				oraConnectionSW = multiApplication.getConnection("ORACLE_SW");
			
			if (oraConnectionMW == null || oraConnectionMW.isClosed())
				oraConnectionMW = multiApplication.getConnection("ORACLE_MW");
            
			if (oraConnectionW == null || oraConnectionW.isClosed())
				oraConnectionW = multiApplication.getConnection("ORACLE_W");
			
			if (oraConnectionSE == null || oraConnectionSE.isClosed())
				oraConnectionSE = multiApplication.getConnection("ORACLE_SE");
		} catch (java.lang.Exception e) {
			severe("Exception in Check() process", e);
			//String body = "RabcBcamLoad check error in RABC - "+e.getMessage();
			//Email.sendEmail(getAdmin_address(), "RABC - Failure in RabcBcamLoad check()", body);
			result = false;
			return result;
		} finally {
		}
		
		return result;
	}
	
	/**
	 * To process this load job we must process each file individually.
	 * 
	 * @return success/failure of processing of the files.
	 * @see LoadJob#action()
	 */
	
	protected boolean action() {
		File files[] = source_directory.listFiles(BCAM_FILTER);
		//System.out.println("Number of BCAM files:" + files.length);
		boolean result = true;
		for (int index = 0; index < files.length; index++)
			result &= processFile(files[index]);
		
		return result;
	}
	
	/**
	 * For the current file preform any preprocessing, then open the file reading it one line at a time which each line being parsed by the abstract method parseLine. Once all of the lines have been processed we execute the postprocess method and exit.
	 * 
	 * @param file - the current file in the process.
	 * @return success/failure of processing of the current file.
	 */
	
	protected boolean processFile(File file) {
		int success = preprocessFileOpt(file);
		
		// Process the file only if it has not already been processed
		if (success == SUCCESS && !fileAlreadyLoaded) {
			BufferedReader reader = null;
			
			try {
				reader = new BufferedReader(new FileReader(file));
			} catch (FileNotFoundException e) {
				severe("FileNotFoundException - " + e.toString());
				return true;
			}
			
			try {
				String line = reader.readLine();
				while (line != null) {
					if (line.length() != 0) counter[parseLine(line)]++;
					line = reader.readLine();
				}
			} catch (IOException e) {
				severe("file error occured - line " + (counter[0] + counter[1] + counter[2]) + " - " + e.toString(),e);
				success = ERROR;
			} catch (SQLException e) {
				severe("database error occured - line " + (counter[0] + counter[1] + counter[2]) + " - " + e.toString(),e);
				success = ERROR;
			} catch (Exception e) {
				severe("error occured - line " + (counter[0] + counter[1] + counter[2]) + " - " + e.toString(),e);
				success = ERROR;
			} finally {
				try {
					if (reader != null) reader.close();
				} catch (IOException e) {
					severe("error closing file - " + e.toString());
				}
				reader = null;
			}
		}
		
		success = postprocessFileOpt(file, success);
		
		return (success == SUCCESS || success == SKIPPED || success == EMPTY_FILE);
	}

	/**
	 * Do anything we need to on a file basis before we actually start loading the file such as setup a timer and counters.
	 * 
	 * @param file - the current file in the process.
	 * @return success/failure of preprocessing of the files.
	 */
	
	protected int preprocessFileOpt(File file) {
		timestamp = System.currentTimeMillis();
		info("Starting file '" + file.getName() + "'");
		counter = new int[3];
		
		return preprocessFile(file) ? SUCCESS : ERROR;
	}
	
	/**
	 * Do anything we need to on a file basis after we finish loading a file.
	 * This load job commits/rollsback each file individually.
	 * Any file commited gets moved to the archive directory, while any rolledback goes to the error directory.
	 * 
	 * @param file - the current file in the process.
	 * @param success - whether file processed successfully.
	 * @return success/failure of postprocessing of the files.
	 */
	
	protected int postprocessFileOpt(File file, int success) {
		boolean temp = postprocessFile(file, success == SUCCESS);
		if (success == SUCCESS && temp == false) {
			success = ERROR;
		}
		
		File destination = null;
		
		if (success == SUCCESS) {
			info("Finished file '" + file.getName() + "' / time elapsed = " + (System.currentTimeMillis() - timestamp) + "ms / lines processed = " + counter[SUCCESS] + " / lines skipped = " + counter[SKIPPED] + " / lines per second = " + (int) ((counter[SUCCESS] * 1.0 / ((System.currentTimeMillis() - timestamp) * 0.001))));

			try {
				oraConnectionSW.commit();
				oraConnectionMW.commit();
				oraConnectionW.commit();
				oraConnectionSE.commit();
			} catch (SQLException e) {
				severe("Commit failed, exception: " + e.toString());
				success = ERROR;
			}
			
			destination = archive_directory;
		} 
		else if(success == EMPTY_FILE) {
			info("Finished empty file '" + file.getName() + "' / time elapsed = " + (System.currentTimeMillis() - timestamp) + "ms / lines processed = " + counter[SUCCESS] + " / lines skipped = " + counter[SKIPPED] + " / lines per second = " + (int) ((counter[SUCCESS] * 1.0 / ((System.currentTimeMillis() - timestamp) * 0.001))));
			try {
				oraConnectionSW.commit();
				oraConnectionMW.commit();
				oraConnectionW.commit();
				oraConnectionSE.commit();
			} catch (SQLException e) {
				severe("Commit failed, exception: " + e.toString());
				success = ERROR;
			}

			destination = archive_directory;
		}
		else if (success == SKIPPED) {
			info("Skipped file '" + file.getName() + "'");
			try {
				oraConnectionSW.rollback();
				oraConnectionMW.rollback();
				oraConnectionW.rollback();
				oraConnectionSE.rollback();
			} catch (SQLException e) {
				severe("Rollback failed, exception: " + e.toString());
				success = ERROR;
			}
		} else if (success == ERROR) {
			severe("Errored out file '" + file.getName() + "'");
			try {
				oraConnectionSW.rollback();
				oraConnectionMW.rollback();
				oraConnectionW.rollback();
				oraConnectionSE.rollback();
			} catch (SQLException e) {
				severe("Rollback failed, exception: " + e.toString());
			}

			destination = error_directory;
		}
		
		if (destination != null) {
			destination = new File(destination, file.getName() + fileSubfix(file));
			if (destination.exists())
				destination.delete();
			if (!file.renameTo(destination))
				severe("File rename failed for file '" + file.getPath() + "' to '" + destination.getPath() + "'");
		}
		
		return success;
	}
	
	/**
	 * For files without changing names we can add a suffix to the file name when moving them to the archive or error directory. This method specifies the subfix.
	 * 
	 * @param file - the current file in the process.
	 * @return a String containing the subfix of the file, if any.
	 */
	
	protected String fileSubfix(File file) {
		return "";
	}
	
	public boolean postprocess(boolean success) {	
		// close all preparedStatements ..
		try {
			insert_bcam_SW.close();
			insert_bcam_MW.close();
			insert_bcam_WE.close();
			insert_bcam_SE.close();
		} catch (SQLException e) {
			severe(StaticErrorMsgKeys.POSTPROCESS_ERROR + e.getMessage());
			success = false;
		}
	
		success = super.postprocess(success);
	
		return success;
	}
	
	public boolean preprocessFile(File file) {
		boolean success = true;
		//success = super.preprocessFile(file); 
		swTriggers = new ArrayList<String>();
		mwTriggers = new ArrayList<String>();
		weTriggers = new ArrayList<String>();
		seTriggers = new ArrayList<String>();
		lineCount = 0;
		currentFile = file;
		
		fileAlreadyLoaded = false;
		if ((RabcLoadJobTrig.IsFileLoaded(oraConnectionSW, file, file.getName().length())) || (RabcLoadJobTrig.IsFileLoaded(oraConnectionMW, file, file.getName().length())) || (RabcLoadJobTrig.IsFileLoaded(oraConnectionW, file, file.getName().length())) || (RabcLoadJobTrig.IsFileLoaded(oraConnectionSE, file, file.getName().length()))    ){
		//if ((RabcLoadJobTrig.IsFileLoaded(oraConnectionSE, file, file.getName().length()))){
		//System.out.println("RabcBCAMLoad: File has already been loaded:" + file.getName());
			fileAlreadyLoaded = true;
		}
		
		return success;
	}
	
	public boolean postprocessFile(File file, boolean success) {
		
		try {
			// if more records to process, perform the last executeBatch to insert them
			if (infoRecordCounterSW > 0)
			{
				insert_bcam_SW.executeBatch();
				infoRecordCounterSW = 0;
			}
			if (infoRecordCounterMW > 0)
			{
				insert_bcam_MW.executeBatch();
				infoRecordCounterMW = 0;
			}
			if (infoRecordCounterWE > 0)
			{
				insert_bcam_WE.executeBatch();
				infoRecordCounterWE = 0;
			}
			if (infoRecordCounterSE > 0)
			{
				insert_bcam_SE.executeBatch();
				infoRecordCounterSE = 0;
			}
		} catch (SQLException e) {
			severe("postprocessFile insert into RABC_BCAM table failed with an SQLException "+e, e);
			success = false;
		}
		
		// Insert trigger only if file has not already been processed before.
		if (success && !fileAlreadyLoaded) {
			if (!insertTrigger()) {
				severe(StaticErrorMsgKeys.POSTPROCESSFILE_ERROR + StaticErrorMsgKeys.TIGGER_TABLE_INSERT_ERROR);
				success = false;
			}
		}
		
		return true;
	}

	/**
	 * Inserts Triggers for each data type that was processed during this run.
	 * 
	 * @return true if all triggers were inserted, false otherwise.
	 */
	private boolean insertTrigger() {
		
		if (lineCount > 0) {
			for (int i = 0; i < swTriggers.size(); i++) {
				//if (!RabcLoadJobTrig.insertTrigger(oraConnectionSW, currentFile.getName().substring(5, currentFile.getName().length()), currentFile.getName(), (String) swTriggers.get(i), runDate, "00")) {
				if (!RabcLoadJobTrig.insertTrigger(oraConnectionSW, currentFile.getName(), currentFile.getName().substring(0, 11), (String) swTriggers.get(i), runDate, "00")) {
					return false;
				}
			}
			for (int i = 0; i < mwTriggers.size(); i++) {
				if (!RabcLoadJobTrig.insertTrigger(oraConnectionMW, currentFile.getName(), currentFile.getName().substring(0, 11), (String) mwTriggers.get(i), runDate, "00")) {
					return false;
				}
			}
			for (int i = 0; i < weTriggers.size(); i++) {
				if (!RabcLoadJobTrig.insertTrigger(oraConnectionW, currentFile.getName(), currentFile.getName().substring(0, 11), (String) weTriggers.get(i), runDate, "00")) {
					return false;
				}
			}
			for (int i = 0; i < seTriggers.size(); i++) {
				if (!RabcLoadJobTrig.insertTriggerSE(oraConnectionSE, currentFile.getName(), currentFile.getName().substring(0, 11), (String) seTriggers.get(i), runDate, "00")) {
					return false;
				}
			}
		}
		return true;
	}
	
	//@Override
	protected int parseLine(String line) throws Exception {

		try{
		
			//StringTokenizer SummaryLine = 	new StringTokenizer(line, StaticFieldKeys.SEMICOLON);
			int beginIndex = 0;
			int endIndex = 0;
		
			lineCount++;
			
			//String Record_Id = SummaryLine.nextToken().trim(); //1
			beginIndex = 0;
			endIndex = MID_LENGTH;
			String record_Id = line.substring(beginIndex, endIndex);
		
			// The record has no delimiters. Extract each field based on its length
			
			//String processDate = SummaryLine.nextToken().trim().substring(1);//2
			//String processDate = SummaryLine.nextToken().trim(); //2
			beginIndex = MID_LENGTH;
			endIndex = MID_LENGTH + PROCESS_DATE_LENGTH;
			String processDate = line.substring(beginIndex, endIndex);
			if 	((processDate == null) ||(processDate.length() == 0))
			{
				severe(StaticErrorMsgKeys.INVAID_RECORD_TYPE + record_Id);
				throw new Exception();
			}
			
			DateFormat df = new SimpleDateFormat("yyyyMMdd");
			java.sql.Date formattedDate = new java.sql.Date(df.parse(processDate).getTime());
			
			// Set runDate for inserting into the RABC_TRIG table
			DateFormat rdf = new SimpleDateFormat("MMddyyyy");
			runDate = rdf.format(df.parse(processDate).getTime());
			
			// Extract PE
			//String procEntity = SummaryLine.nextToken().trim(); //3
			beginIndex = MID_LENGTH + PROCESS_DATE_LENGTH;
			endIndex = MID_LENGTH + PROCESS_DATE_LENGTH + PROCESSING_ENTITY_LENGTH;
			String procEntity = line.substring(beginIndex, endIndex);
			
			// Extract LEG
			//String leg = SummaryLine.nextToken().trim(); //4
			beginIndex = MID_LENGTH + PROCESS_DATE_LENGTH + PROCESSING_ENTITY_LENGTH;
			endIndex = MID_LENGTH + PROCESS_DATE_LENGTH + PROCESSING_ENTITY_LENGTH + LEG_LENGTH;
			String leg = line.substring(beginIndex, endIndex);
			if (leg == null){
				//severe(StaticErrorMsgKeys.NORECORD_RABC_CRO_CD_DIVISION + leg);
				throw new Exception();	
			}
			
			//String seqNum = SummaryLine.nextToken().trim(); //5
			beginIndex = MID_LENGTH + PROCESS_DATE_LENGTH + PROCESSING_ENTITY_LENGTH + LEG_LENGTH;
			endIndex = MID_LENGTH + PROCESS_DATE_LENGTH + PROCESSING_ENTITY_LENGTH + LEG_LENGTH + SEQ_NUMBER_LENGTH;
			String seqNum = line.substring(beginIndex, endIndex);
			
			//String region = SummaryLine.nextToken().trim(); //6
			beginIndex = MID_LENGTH + PROCESS_DATE_LENGTH + PROCESSING_ENTITY_LENGTH + LEG_LENGTH + SEQ_NUMBER_LENGTH;
			endIndex = MID_LENGTH + PROCESS_DATE_LENGTH + PROCESSING_ENTITY_LENGTH + LEG_LENGTH + SEQ_NUMBER_LENGTH + REGION_LENGTH;
			String region = line.substring(beginIndex, endIndex);
			if ((region == null) || (region.equals(""))) {
				severe(StaticErrorMsgKeys.PARSELINE_ERROR + "Region is null");
				throw new Exception();
			}
			
			// Skip data for regions other than P (West), A (MW) and S (SW-CRIS(NL))
			String mossRegion = region.trim();
			if (!mossRegion.equalsIgnoreCase(MOSS_SOUTHWEST_CRIS_NL_REGION) && !mossRegion.equalsIgnoreCase(MOSS_MIDWEST_REGION) && !mossRegion.equalsIgnoreCase(MOSS_WEST_REGION)&& !mossRegion.equalsIgnoreCase(MOSS_SOUTHEAST_REGION)
					&& !mossRegion.equalsIgnoreCase(SOUTHWEST_REGION) && !mossRegion.equalsIgnoreCase(MIDWEST_REGION) && !mossRegion.equalsIgnoreCase(WEST_REGION) && !mossRegion.equalsIgnoreCase(SOUTHEAST_REGION) ) {
				info("parseLine encountered invalid Region, '" + mossRegion + "', Skipping the record");
				return SUCCESS;
			}
			// Map MOSS region to RABC region
			String rabcRegion = "";
			rabcRegion = REGION_MAP.get(region.trim());
			
			// String division = SummaryLine.nextToken().trim(); //7
			beginIndex = MID_LENGTH + PROCESS_DATE_LENGTH + PROCESSING_ENTITY_LENGTH + LEG_LENGTH + SEQ_NUMBER_LENGTH + REGION_LENGTH;
			endIndex = MID_LENGTH + PROCESS_DATE_LENGTH + PROCESSING_ENTITY_LENGTH + LEG_LENGTH + SEQ_NUMBER_LENGTH + REGION_LENGTH + DIVISION_LENGTH;
			String division = line.substring(beginIndex, endIndex);
			if (division == null) {
				severe(StaticErrorMsgKeys.PARSELINE_ERROR + "Division is null");
				throw new Exception();
			}
			// Map MOSS division to RABC division
			String rabcDivision = "";
			if (division != null && !division.trim().equals("")) {
				if (rabcRegion.equalsIgnoreCase(MIDWEST_REGION)) {
					rabcDivision = MW_DIVISION_MAP.get(division.trim());
				} else if (rabcRegion.equalsIgnoreCase(WEST_REGION)) {
					rabcDivision = WEST_DIVISION_MAP.get(division.trim());
				} else if (rabcRegion.equalsIgnoreCase(SOUTHEAST_REGION)) {
					rabcDivision = SE_DIVISION_MAP.get(division.trim());
				}else {
					rabcDivision = division.trim();
				}
			}
			
			//String prodType = SummaryLine.nextToken().trim(); //8
			beginIndex = MID_LENGTH + PROCESS_DATE_LENGTH + PROCESSING_ENTITY_LENGTH + LEG_LENGTH + SEQ_NUMBER_LENGTH + REGION_LENGTH + DIVISION_LENGTH;
			endIndex = MID_LENGTH + PROCESS_DATE_LENGTH + PROCESSING_ENTITY_LENGTH + LEG_LENGTH + SEQ_NUMBER_LENGTH + REGION_LENGTH + DIVISION_LENGTH + PROD_TYPE_LENGTH;
			String prodType = line.substring(beginIndex, endIndex);
			
			// Only consider records with Prod Type of Bills, skip the rest
			if ((prodType != null) && (!prodType.trim().equalsIgnoreCase(PROD_TYPE_BILLS))) {
				info("parseLine encountered Prod Type other than " + PROD_TYPE_BILLS + ", Skipping the record");
				return SUCCESS;
			}
			
			//String totNumBills = SummaryLine.nextToken().trim(); //9
			beginIndex = MID_LENGTH + PROCESS_DATE_LENGTH + PROCESSING_ENTITY_LENGTH + LEG_LENGTH + SEQ_NUMBER_LENGTH + REGION_LENGTH + DIVISION_LENGTH + PROD_TYPE_LENGTH;
			endIndex = MID_LENGTH + PROCESS_DATE_LENGTH + PROCESSING_ENTITY_LENGTH + LEG_LENGTH + SEQ_NUMBER_LENGTH + REGION_LENGTH + DIVISION_LENGTH + PROD_TYPE_LENGTH + TOT_NUM_BILLS_LENGTH;
			String totNumBills = line.substring(beginIndex, endIndex);
		
			// Use the appropriate PreparedStatement, based on the region
			if (rabcRegion.equalsIgnoreCase(SOUTHWEST_REGION)) {
				addStmtToBatch(insert_bcam_SW, formattedDate, rabcRegion, rabcDivision, prodType, totNumBills);
				// increment the infoRecordCounter for comparison against the Batch Size
				infoRecordCounterSW++;
			} else if (rabcRegion.equalsIgnoreCase(MIDWEST_REGION)) {
				addStmtToBatch(insert_bcam_MW, formattedDate, rabcRegion, rabcDivision, prodType, totNumBills);
				// increment the infoRecordCounter for comparison against the Batch Size
				infoRecordCounterMW++;
			} else if (rabcRegion.equalsIgnoreCase(WEST_REGION)) {
				addStmtToBatch(insert_bcam_WE, formattedDate, rabcRegion, rabcDivision, prodType, totNumBills);
				// increment the infoRecordCounter for comparison against the Batch Size
				infoRecordCounterWE++;
			}else if (rabcRegion.equalsIgnoreCase(SOUTHEAST_REGION)) {
				if( !rabcDivision.equals("") ){
				addStmtToBatch(insert_bcam_SE, formattedDate, rabcRegion, rabcDivision, prodType, totNumBills);
				// increment the infoRecordCounter for comparison against the Batch Size
				infoRecordCounterSE++;
				}
			}
			
			info("BCAM:Record to be inserted: Process Date: " + processDate + ", Region: "+ rabcRegion + ", Divsion:" + rabcDivision + ", ProdType: " + prodType + ", Tot#Bills:" + totNumBills);
			
			// check to see if we are ready to insert a batch into the table 		
			if (infoRecordCounterSW == BATCH_SIZE)
			{
				insert_bcam_SW.executeBatch();
				infoRecordCounterSW = 0;
			}
			
			// check to see if we are ready to insert a batch into the table 		
			if (infoRecordCounterMW == BATCH_SIZE)
			{
				insert_bcam_MW.executeBatch();
				infoRecordCounterMW = 0;
			}
			
			// check to see if we are ready to insert a batch into the table 		
			if (infoRecordCounterWE == BATCH_SIZE)
			{
				insert_bcam_WE.executeBatch();
				infoRecordCounterWE = 0;
			}
			
			// check to see if we are ready to insert a batch into the table 		
			if (infoRecordCounterSE == BATCH_SIZE)
			{
				insert_bcam_SE.executeBatch();
				infoRecordCounterSE = 0;
			}
			
			// commenting out the single record insert execution.
			//insert_bcam.execute();
		
			if (rabcRegion.equalsIgnoreCase(SOUTHWEST_REGION)) {
				if (!swTriggers.contains(rabcDivision.trim())) {
					swTriggers.add(rabcDivision.trim());
				}
			} else if (rabcRegion.equalsIgnoreCase(MIDWEST_REGION)) {
				if (!mwTriggers.contains(rabcDivision.trim())) {
					mwTriggers.add(rabcDivision.trim());
				}
			} else if (rabcRegion.equalsIgnoreCase(WEST_REGION)) {
				if (!weTriggers.contains(rabcDivision.trim())) {
					weTriggers.add(rabcDivision.trim());
				}
			}else if (rabcRegion.equalsIgnoreCase(SOUTHEAST_REGION)) {
				if (!seTriggers.contains(rabcDivision.trim())) {
					if (!rabcDivision.trim().equals("")){
					seTriggers.add(rabcDivision.trim());
					}
				}
			}
		
		}catch(SQLException e){
			severe(StaticErrorMsgKeys.PARSELINE_ERROR + e.toString());
			throw new SQLException();	
		
		}catch (Exception e) {
			severe(StaticErrorMsgKeys.PARSELINE_ERROR + e.toString());
			throw new Exception();	
		}
		
		return SUCCESS;
	}
	
	protected void addStmtToBatch(PreparedStatement insert_bcam_stmt, java.sql.Date formattedDate, String region, String division, String prodType, String totNumBills) throws SQLException {
		insert_bcam_stmt.setDate(1, formattedDate);
		//insert_bill_print.setDate  (2, sqlrun_date);
		insert_bcam_stmt.setString(2, region);
		insert_bcam_stmt.setString(3, division);
		insert_bcam_stmt.setString(4, prodType);
		insert_bcam_stmt.setString(5, totNumBills);
		
		insert_bcam_stmt.addBatch();
		
	}

}
