/*
 * Copyright  2002-2006 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.adhoc.aria.pivot;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Stack;


/**
 * Description of class
 * 
 * <p>
 * <hr>
 * <h3>Release History</h3>
 * <p>
 * <ul>
 * 
 * <li>jb6494 Nov 30, 2006 Created class.
 * 
 * </ul>
 * <p>
 * 
 */
public class CompositeKey {

    public static final int MAX_KEYS = 5;
    private int numKeys;
    protected List keys = new ArrayList();


    /**
     * Constructor
     */
    public CompositeKey() {
        super();
        numKeys = MAX_KEYS;
    }


    /**
     * @param o
     */
    public void addKey(Object o) {
        if (keys.size() < numKeys) {
            keys.add(o);
        } else {
            throw new IllegalStateException("Maximum key limit exceeded");
        }
    }


    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }

        if (!(obj instanceof CompositeKey)) {
            return false;
        }

        CompositeKey o1 = (CompositeKey) obj;

        return keys.equals(o1.keys);
    }


    /**
     * @param index
     * @return
     */
    public Object getKey(int index) {
        if ((index < 0) || (index > numKeys - 1)) {
            throw new IllegalArgumentException(index + " is an invalid index.");
        }

        if (index >= keys.size()) {
            return null;
        }

        return keys.get(index);
    }


    /*
     * (non-Javadoc)
     * 
     * @see java.util.List#isEmpty()
     */
    public boolean isEmpty() {
        return keys.isEmpty();
    }


    /**
     * Determines if an inner break has occurred.
     * 
     * @param prevRow
     * @return
     */
    public boolean isInnerBreak(CompositeKey prevRow) {
        return !equals(prevRow, 0, 4);
    }


    /**
     * Determines if an outer break has occurred.
     * 
     * @param prevRow
     * @return
     */
    public boolean isOuterBreak(CompositeKey prevRow) {
        return !equals(prevRow, 0, 0);
    }


    /*
     * (non-Javadoc)
     * 
     * @see java.util.List#iterator()
     */
    public Iterator iterator() {
        return keys.iterator();
    }


    /**
     * Convenience method to get all the keys as a stack
     * 
     * @return
     */
    public Stack keysAsStack() {
        Stack stack = new Stack();
        for (int i = numKeys - 1; i >= 0; i--) {
            if (keys.get(i) != null) {
                stack.push(keys.get(i));
            }
        }
        return stack;
    }


    /*
     * (non-Javadoc)
     * 
     * @see java.util.List#size()
     */
    public int size() {
        return keys.size();
    }


    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    public String toString() {
        StringBuffer buf = new StringBuffer(100);
        buf.append('[');
        for (int i = 0; i < keys.size(); i++) {
            buf.append(keys.get(i));
            if (i < keys.size() - 1) {
                buf.append(", ");
            }
        }
        buf.append(']');
        return buf.toString();
    }


    /**
     * Determine if keys in the range are equal to the object.
     * 
     * @param obj
     * @param fromIndex
     * @param toIndex
     * @return
     */
    private boolean equals(Object obj, int fromIndex, int toIndex) {
        if (obj == null) {
            return false;
        }
        if (obj instanceof CompositeKey) {
            CompositeKey o1 = (CompositeKey) obj;
            boolean b = true;

            // check to see if everything is null
            for (int i = fromIndex; i <= toIndex; i++) {
                b &= o1.getKey(i) == null ? o1.getKey(i) == null : false;
            }
            if (b) {
                return true;
            }

            // test each key
            b = true;
            for (int i = fromIndex; i <= toIndex; i++) {
                if (o1.getKey(i) == null) {
                    b &= getKey(i) == null;
                } else {
                    b &= o1.getKey(i).equals(getKey(i));
                }
            }
            return b;
        }
        return false;
    }


	/**
	 * @return the numKeys
	 */
	public int getNumKeys() {
		return numKeys;
	}


	/**
	 * @param numKeys the numKeys to set
	 */
	public void setNumKeys(int numKeys) {
		this.numKeys = numKeys;
	}
}
