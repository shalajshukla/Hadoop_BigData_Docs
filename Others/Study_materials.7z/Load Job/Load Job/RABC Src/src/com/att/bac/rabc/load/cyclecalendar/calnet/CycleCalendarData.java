package com.att.bac.rabc.load.cyclecalendar.calnet;

/**
 * This component contains the getter/ setter methods for the fields used by
 * CALNET 2 CycleCalendarLoadJob
 * 
 * @author kb629p
 */
public class CycleCalendarData {
	private String cycle = null;
	private String billRound = null;
	private String procDate = null;
	private String billRoundDate = null;

	public String getCycle() {
		return cycle;
	}

	public void setCycle(String cycle) {
		this.cycle = cycle;
	}

	public String getBillRound() {
		return billRound;
	}

	public void setBillRound(String billRound) {
		this.billRound = billRound;
	}

	public String getProcDate() {
		return procDate;
	}

	public void setProcDate(String procDate) {
		this.procDate = procDate;
	}

	public String getBillRoundDate() {
		return billRoundDate;
	}

	public void setBillRoundDate(String billRoundDate) {
		this.billRoundDate = billRoundDate;
	}

}
