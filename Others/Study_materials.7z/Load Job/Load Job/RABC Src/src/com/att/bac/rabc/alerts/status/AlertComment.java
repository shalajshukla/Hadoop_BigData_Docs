/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.status;

import com.att.bac.rabc.MyDate;

/**
 * This is a Data Object to represent RABC_ALERT_COMMENT table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class AlertComment {
	private int msgNum;
	private int asocMsgNum;
	private String asocTimeStamp;
	private String msgComment;
	private String commentUserId;
	private MyDate timeStamp;

	/**
	 * @return Returns the MsgNum.
	 */
	public int getMsgNum() {
		return msgNum;
	}
	/**
	 * @return Returns the AsocMsgNum.
	 */
	public int getAsocMsgNum() {
		return asocMsgNum;
	}
	/**
	 * @return Returns the AsocTimeStamp.
	 */
	public String getAsocTimeStamp() {
		return asocTimeStamp;
	}
	/**
	 * @return Returns the MsgComment.
	 */
	public String getMsgComment() {
		return msgComment;
	}
	/**
	 * @return Returns the CommentUserId.
	 */
	public String getCommentUserId() {
		return commentUserId;
	}
	/**
	 * @return Returns the TimeStamp.
	 */
	public MyDate getTimeStamp() {
		return timeStamp;
	}

	/**
	 * @param MsgNum The msgNum to set.
	 */
	public void setMsgNum(int msgNum) {
		this.msgNum = msgNum;
	}
	/**
	 * @param AsocMsgNum The asocMsgNum to set.
	 */
	public void setAsocMsgNum(int asocMsgNum) {
		this.asocMsgNum = asocMsgNum;
	}
	/**
	 * @param AsocTimeStamp The asocTimeStamp to set.
	 */
	public void setAsocTimeStamp(String asocTimeStamp) {
		this.asocTimeStamp = asocTimeStamp;
	}
	/**
	 * @param MsgComment The msgComment to set.
	 */
	public void setMsgComment(String msgComment) {
		this.msgComment = msgComment;
	}
	/**
	 * @param CommentUserId The commentUserId to set.
	 */
	public void setCommentUserId(String commentUserId) {
		this.commentUserId = commentUserId;
	}
	/**
	 * @param TimeStamp The timeStamp to set.
	 */
	public void setTimeStamp(MyDate timeStamp) {
		this.timeStamp = timeStamp;
	}
}
