/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.admin.adhoc.rpt;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.att.bac.rabc.PickList;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;

/**
 * This is a service class to provide the business logic. The methods in this class are called by the
 * action class. They internaly calls the DAO classes to do the required manipulation and returns the 
 * result to the action class. This paricular service class serves the business logic to populate the
 * Alert Report Selection Criteria page and Alert Report Detail page.
 * 
 * @author Anup Thomas - AT1862
 */
public class RabcUsersService {
	
	private static final Logger logger = Logger.getLogger(RabcUsersService.class);
	
	/*
	 * Variables to represent the sql statements.
	 */
	public static final String qUsers="SELECT 	DISTINCT TRIM(UPPER(u.user_id)) AS userid, UPPER(u.user_name) AS  user_name"	
									+" FROM 	rabc_user u, rabc_alert_grp_user a "
									+" WHERE	a.user_id = u.user_id	ORDER BY userid";
	
	
	/**
	 * This methos is used to get the RABC user list
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return List
	 */
	public List getRabcUsersList(Connection connection,List failureList,List args){
		List rabcUsersList = new ArrayList();
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		try {
			MessageFormat mf = new MessageFormat(qUsers);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("RABC Users - Executing SQL statement: "+ sqlStmt);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			if (rs != null) {
				while (rs.next()) {
					rabcUsersList.add(new PickList(rs.getString("user_name"),rs.getString("userid")));	
				}
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return null;
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		
		return (rabcUsersList);
	}
}
