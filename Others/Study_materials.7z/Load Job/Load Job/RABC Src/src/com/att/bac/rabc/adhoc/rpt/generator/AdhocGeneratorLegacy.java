/*
 * Copyright  2002-2006 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.adhoc.rpt.generator;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.naming.NamingException;

import org.apache.log4j.Logger;

import com.att.bac.rabc.ConnectionManager;
import com.att.bac.rabc.DataTblDdlBean;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.StaticDataLoader;
import com.att.bac.rabc.adhoc.rpt.AdhocRptDAO;
import com.att.bac.rabc.adhoc.rpt.AdhocRptDataTO;
import com.att.bac.rabc.adhoc.rpt.AdhocRptUtil;
import com.att.carat.util.JDBCUtil;


/**
 * This will isolate the old code which is currently still used to perform the "business rules" since no one knows what
 * they are.
 * 
 * <p>
 * <hr>
 * <h3>Release History</h3>
 * <p>
 * <ul>
 * 
 * <li>jb6494 Aug 29, 2006 Created class.
 * <li>jb6494 Jan 19, 2006 Fixed silly date substringing problem.
 * <li>jb6494 Mar 09, 2007 ML#09 View criteria not being added correctly.
 * <li>jb6494 Mar 13, 2007 ML18 Calculations on views
 * <li>jb6494 Mar 15, 2007 ML22 corrected silly use of collection method
 * 
 * </ul>
 * <p>
 * 
 */
final class AdhocGeneratorLegacy {
    public static Logger logger = Logger.getLogger(AdhocGeneratorLegacy.class);

    private static final String BASE_DATE = "01/01/2005";

    private static final String BILL_ROUND = "B";

    private static final String DATEFORMAT = "MM/dd/yyyy";

    private static final String EMPTY_STRING = "";

    private static final String MONTHLY = "M";

    private static final String NO = "N";

    private static final String QRY_GET_COLUMNS = "SELECT DATA_DDL_NAME " + ",DATA_TBL " + ",VIEW_NAME " + ",PRESN_CALC_NUM " + ",PREV_DATA_IND " + ",PRESN_UNIT_IND " + ",PRESN_SUM_IND " + ",PARTI_REF_ID " + ",DIFF_DATA_IND " + "FROM RABC_PRESN_ELEM_VIEW " + "WHERE PRESN_ID = ? " + "AND WEBID = ? " + "AND EXEC_PRESN_SEQ_NUM = ? " + "AND VIEW_NAME = ? ";

    private static final String QRY_GET_KEY_COLUMNS = "SELECT KEY1_DDL_NAME " + ",KEY2_DDL_NAME " + ",KEY3_DDL_NAME " + ",KEY4_DDL_NAME " + ",KEY5_DDL_NAME " + ",PRESN_DATA_TBL " + ",FILE_SEQ_NUM_IND " + "FROM RABC_PRESN_RULE_VIEW " + "WHERE PRESN_ID = ? " + "AND WEBID = ? " + "AND EXEC_PRESN_SEQ_NUM = ? " + "AND PRESN_DATA_TBL = ? ";

    private static final String QRY_GET_VIEW_NAME = "SELECT SELECT_VALUE " + "FROM RABC_VIEW " + "WHERE VIEW_NAME = ? ";

    private static final String SYSTEM = "SYSTEM";

    private static final String YES = "Y";

    private List aliasNamesTablesList = new ArrayList();

    private List aliasProcDatesList = new ArrayList();

    private List billMonthList = new ArrayList();

    private List billYearList = new ArrayList();

    private int calcNumCount = 0;

    public List conditionClauseList = new ArrayList();

    private String fromDt = null;

    private String keyColumnsFileSeqNumInd = null;

    private String keyColumnsKey1DdlName = null;

    private String keyColumnsKey2DdlName = null;

    private String keyColumnsKey3DdlName = null;

    private String keyColumnsKey4DdlName = null;

    private String keyColumnsKey5DdlName = null;

    private String keyColumnsPresnDataTbl = null;

    private List keyTblXList = new ArrayList();

    private String modABillRnd = null;

    private List modAElemPrevIndList = new ArrayList();
    
    private List modAElemDiffIndList = new ArrayList();

    private List modAElemTableNameList = new ArrayList();

    private List modAElemViewNameList = new ArrayList();

    private List modAKey1DdlNameList = new ArrayList();

    private List modAKey2DdlNameList = new ArrayList();

    private List modAKey3DdlNameList = new ArrayList();

    private List modAKey4DdlNameList = new ArrayList();

    private List modAKey5DdlNameList = new ArrayList();

    private List modAPresnCalcNumList = new ArrayList();

    private List modAPresnSumIndList = new ArrayList();

    private List modAPresnUnitIndList = new ArrayList();

    private String modAProcDates = null;

    private List modATablesNamesList = new ArrayList();

    private List modColumnsasoracleList = new ArrayList();

    private List modColumnstablesList = new ArrayList();

    private List modColumnstoextractList = new ArrayList();

    private int modDivNameKeyLvl = -1;

    private String modFileSeqNumInd = null;

    private List modKeysrow1columnsList = new ArrayList();

    private List modKeysrow1tablesList = new ArrayList();

    private List modKeysrow2columnsList = new ArrayList();

    private List modKeysrow2tablesList = new ArrayList();

    private String modPresnTblName = null;

    private String modTablenames = null;

    private String nameBillCycle = null;

    private String nameBillMonth = null;

    private String nameBillYear = null;

    private List procDatesList = new ArrayList();

    private String toDt = null;

    private List whereClauseList = new ArrayList();

    List orderByClauseList = new ArrayList();

    List selectClauseList = new ArrayList();

    List viewNameUniqList = new ArrayList();

    String viewTbl = null;


    /**
     * Create a table.column result
     * 
     * @param table
     * @param column
     * @return
     */
    private static String dot(String table, String column) {
        return table.trim() + "." + column.trim();
    }


    public String getBillRoundName() {
        return modABillRnd;
    }


    /**
     * Get the sort order suffix
     * 
     * @param dto
     * @param x
     * @return
     */
    private static String getOrderCode(AdhocRptDataTO dto, int x) {
        String orderInd = EMPTY_STRING;
        if (!dto.getPresnOrdIndList().get(x).toString().equals(EMPTY_STRING)) {
            if (dto.getPresnOrdIndList().get(x).toString().equalsIgnoreCase("A")) {
                orderInd = "ASC";
            } else if (dto.getPresnOrdIndList().get(x).toString().equalsIgnoreCase("D")) {
                orderInd = "DESC";
            }
        }
        return orderInd;
    }


    /**
     * Isolate silly condition checking
     * 
     * @param haystack
     * @param needle
     * @return
     */
    private static boolean isNotNullNE(String haystack, String needle) {
        if (haystack == null) {
            return false;
        }
        return !haystack.trim().equalsIgnoreCase(needle);
    }


    /**
     * Consolidate calls to static loader
     * 
     * @param table
     * @return
     */
    private static boolean isRABCTbl(String table, String region) {
        return (StaticDataLoader.getDataTblDdlByAlertProcTbl(SYSTEM, table, region).size() > 0 ? true : false);
    }


    /**
     * @param dto
     * @param tblViewIndex
     * @throws RABCException
     */
    public void getTblFromView(AdhocRptDataTO dto, int tblViewIndex) throws RABCException {
        viewTbl = new AdhocRptDAO().getTableNameFromView(dto, (String) viewNameUniqList.get(tblViewIndex));
        if (viewTbl.length() == 0) {
            viewTbl = (String) viewNameUniqList.get(tblViewIndex);
        }
    }


    /**
     * Helper to combine where elements
     * 
     * @return
     */
    public String getWhereClause() {
        StringBuffer buf = new StringBuffer(100);
        Iterator i = whereClauseList.iterator();
        while (i.hasNext()) {
            buf.append((String) i.next());
            if (i.hasNext()) {
                buf.append(" and ");
            }
        }
        return buf.toString();
    }


    /**
     * @param adhocRptDataTO
     */
    public void initBillRound1(AdhocRptDataTO adhocRptDataTO) {
        ArrayList billRoundData = StaticDataLoader.getDataTblDdlByAlertProcTbl(modPresnTblName, adhocRptDataTO.getRegion());
        if (billRoundData.size() > 0) {
            DataTblDdlBean bean = (DataTblDdlBean) (billRoundData.get(0));
            nameBillCycle = bean.getTblBillRndDdlName() == null ? EMPTY_STRING : bean.getTblBillRndDdlName().trim();
            if ((bean.getTblBillRndDdlMon() == null || bean.getTblBillRndDdlMon().trim().equals(EMPTY_STRING)) && (bean.getTblBillRndDdlYear() == null || bean.getTblBillRndDdlYear().trim().equals(EMPTY_STRING))) {
                adhocRptDataTO.setProcDateInd("F");
            } else {
                nameBillMonth = bean.getTblBillRndDdlMon() == null ? EMPTY_STRING : bean.getTblBillRndDdlMon().trim();
                nameBillYear = bean.getTblBillRndDdlYear() == null ? EMPTY_STRING : bean.getTblBillRndDdlYear().trim();
                adhocRptDataTO.setProcDateInd("P");
            }
        }
        modATablesNamesList = AdhocRptUtil.stringToArrayList(modTablenames, ",");
        if (adhocRptDataTO.getProcDateInd().equalsIgnoreCase("P")) {
            for (int i = 0; i < modATablesNamesList.size(); i++) {
                DataTblDdlBean bean = (DataTblDdlBean) StaticDataLoader.getDataTblDdlByAlertProcTbl((String) modATablesNamesList.get(i), adhocRptDataTO.getRegion()).get(0);
                billMonthList.add(i, bean.getTblBillRndDdlMon());
                billYearList.add(i, bean.getTblBillRndDdlYear());
            }
        } else if (adhocRptDataTO.getProcDateInd().equalsIgnoreCase("F")) {
            for (int i = 0; i < modATablesNamesList.size(); i++) {
                DataTblDdlBean bean = (DataTblDdlBean) StaticDataLoader.getDataTblDdlByAlertProcTbl((String) modATablesNamesList.get(i), adhocRptDataTO.getRegion()).get(0);
                procDatesList.add(i, bean.getTblProcDateDdlName());
            }
            if (isNotNullNE(adhocRptDataTO.getAliasNames(), EMPTY_STRING)) {
                aliasNamesTablesList = AdhocRptUtil.stringToArrayList(adhocRptDataTO.getTableNames(), ",");
                for (int i = 0; i < aliasNamesTablesList.size(); i++) {
                    DataTblDdlBean bean = (DataTblDdlBean) StaticDataLoader.getDataTblDdlByAlertProcTbl((String) aliasNamesTablesList.get(i), adhocRptDataTO.getRegion()).get(0);
                    aliasProcDatesList.add(i, bean.getTblProcDateDdlName());
                }
            }
        }
    }


    /**
     * @param adhocRptDataTO
     * @throws RABCException
     */
    public void initBillRound2(AdhocRptDataTO adhocRptDataTO) throws RABCException {
        ArrayList billRoundData = StaticDataLoader.getDataTblDdlByAlertProcTbl(modPresnTblName, adhocRptDataTO.getRegion());
        if (billRoundData.size() > 0) {
            DataTblDdlBean bean = (DataTblDdlBean) (billRoundData.get(0));
            if ((bean.getTblBillRndDdlMon() == null || bean.getTblBillRndDdlMon().trim().equals(EMPTY_STRING)) && (bean.getTblBillRndDdlYear() == null || bean.getTblBillRndDdlYear().trim().equals(EMPTY_STRING)) && (bean.getTblProcDateDdlName() == null || bean.getTblProcDateDdlName().trim().equals(EMPTY_STRING))) {
                throw new RABCException("Error : Table RABC_DATA_TBL_DDL is incorrect, cannot find either date or bill cycle column");
            }
            nameBillMonth = bean.getTblBillRndDdlMon();
            nameBillYear = bean.getTblBillRndDdlYear();
            nameBillCycle = bean.getTblBillRndDdlName();
        }
        modATablesNamesList = AdhocRptUtil.stringToArrayList(modTablenames, ",");
        for (int i = 0; i < modATablesNamesList.size(); i++) {
            DataTblDdlBean bean = (DataTblDdlBean) StaticDataLoader.getDataTblDdlByAlertProcTbl((String) modATablesNamesList.get(i), adhocRptDataTO.getRegion()).get(0);
            billMonthList.add(i, bean.getTblBillRndDdlMon());
            billYearList.add(i, bean.getTblBillRndDdlYear());
        }
    }


    /**
     * @param adhocRptDataTO
     * @param loopCount
     * @throws RABCException
     */
    public void initKeyColumns(AdhocRptDataTO adhocRptDataTO, int loopCount) throws RABCException {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = ConnectionManager.getConnection(adhocRptDataTO.getRegion());
            ps = conn.prepareStatement(QRY_GET_KEY_COLUMNS); // this query returns 1 row only
            ps.setInt(1, adhocRptDataTO.getPresnId());
            ps.setString(2, adhocRptDataTO.getWebId());
            ps.setInt(3, ((Integer) (adhocRptDataTO.getDistExecPresnSeqNumList().get(loopCount))).intValue());
            ps.setString(4, viewTbl);
            rs = ps.executeQuery();
            if (rs.next()) {
                keyColumnsKey1DdlName = rs.getString(1) == null ? EMPTY_STRING : rs.getString(1).trim();
                keyColumnsKey2DdlName = rs.getString(2) == null ? EMPTY_STRING : rs.getString(2).trim();
                keyColumnsKey3DdlName = rs.getString(3) == null ? EMPTY_STRING : rs.getString(3).trim();
                keyColumnsKey4DdlName = rs.getString(4) == null ? EMPTY_STRING : rs.getString(4).trim();
                keyColumnsKey5DdlName = rs.getString(5) == null ? EMPTY_STRING : rs.getString(5).trim();
                keyColumnsPresnDataTbl = rs.getString(6) == null ? EMPTY_STRING : rs.getString(6).trim();
                keyColumnsFileSeqNumInd = rs.getString(7) == null ? EMPTY_STRING : rs.getString(7).trim();
            }
        } catch (SQLException sqle) {
            throw new RABCException("Error in retrieving key column information", sqle);
        } catch (NamingException ne) {
            throw new RABCException("NamingException ", ne);
        } finally {
            JDBCUtil.closeResultSet(rs);
            JDBCUtil.closePreparedStatement(ps);
            JDBCUtil.closeConnection(conn);
        }
    }


    /**
     * @param adhocRptDataTO
     */
    public void initNotBillRound(AdhocRptDataTO adhocRptDataTO) {
        modATablesNamesList = AdhocRptUtil.stringToArrayList(modTablenames, ",");
        for (int i = 0; i < modATablesNamesList.size(); i++) {
            DataTblDdlBean bean = (DataTblDdlBean) StaticDataLoader.getDataTblDdlByAlertProcTbl((String) modATablesNamesList.get(i), adhocRptDataTO.getRegion()).get(0);
            procDatesList.add(i, bean.getTblProcDateDdlName());
        }
        if (isNotNullNE(adhocRptDataTO.getAliasNames(), EMPTY_STRING)) {
            aliasNamesTablesList = AdhocRptUtil.stringToArrayList(adhocRptDataTO.getTableNames(), ",");
            for (int i = 0; i < aliasNamesTablesList.size(); i++) {
                ArrayList table = StaticDataLoader.getDataTblDdlByAlertProcTbl((String) aliasNamesTablesList.get(i), adhocRptDataTO.getRegion());
                if (table.size() > 0) {
                    DataTblDdlBean bean = (DataTblDdlBean) table.get(0);
                    aliasProcDatesList.add(bean.getTblProcDateDdlName());
                }
            }
        }
    }


    /**
     */
    public void initSqlArrays() {
        selectClauseList.clear();
        whereClauseList.clear();
        orderByClauseList.clear();
    }


    /**
     * @param adhocRptDataTO
     */
    public void setColumnsTabAsOracle(AdhocRptDataTO adhocRptDataTO) {
        StringBuffer buffer = new StringBuffer();
        for (int i = 0; i < adhocRptDataTO.getColumnsAsOracleList().size(); i++) {
            if (adhocRptDataTO.getPresnCalcNumList().get(i).equals(EMPTY_STRING)) {
                buffer.append(adhocRptDataTO.getViewNameList().get(i) + "." + adhocRptDataTO.getColumnsAsOracleList().get(i));
                if (i < adhocRptDataTO.getColumnsAsOracleList().size() - 1) {
                    buffer.append(",");
                }
            } else {
                buffer.append("JUNK_CALC_ORACLE,");
            }
        }
        // columnsTabAsOracle = buffer.toString();
    }


    /**
     * @param adhocRptDataTO
     */
    public void setVariables(AdhocRptDataTO adhocRptDataTO) {
        modPresnTblName = viewTbl;
        modDivNameKeyLvl = adhocRptDataTO.getDivNameKeyLvl();

        logger.debug("***** viewTbl=" + viewTbl);
        logger.debug("***** region=" + adhocRptDataTO.getRegion());
        logger.debug("***** DataTblDdlBean=" + StaticDataLoader.getDataTblDdlByAlertProcTbl(viewTbl, adhocRptDataTO.getRegion()));

        modAProcDates = ((DataTblDdlBean) (StaticDataLoader.getDataTblDdlByAlertProcTbl(viewTbl, adhocRptDataTO.getRegion()).get(0))).getTblProcDateDdlName();
        modABillRnd = ((DataTblDdlBean) (StaticDataLoader.getDataTblDdlByAlertProcTbl(viewTbl, adhocRptDataTO.getRegion()).get(0))).getTblBillRndDdlName();
        modTablenames = EMPTY_STRING;

        modColumnstoextractList.clear();
        modColumnsasoracleList.clear();
        modKeysrow1columnsList.clear();
        modKeysrow2columnsList.clear();
        modKeysrow1tablesList.clear();
        modKeysrow2tablesList.clear();
        modAPresnUnitIndList.clear();
        modAPresnSumIndList.clear();
        modAElemTableNameList.clear();
        modAElemViewNameList.clear();
        modAElemPrevIndList.clear();
        modAElemDiffIndList.clear();
        modAPresnCalcNumList.clear();
        modAKey1DdlNameList.clear();
        modAKey2DdlNameList.clear();
        modAKey3DdlNameList.clear();
        modAKey4DdlNameList.clear();
        modAKey5DdlNameList.clear();
        modColumnstablesList.clear();
    }


    /**
     * @param adhocRptDataTO
     */
    public void setViewNameUniqList(AdhocRptDataTO adhocRptDataTO) {
        for (int i = 0; i < adhocRptDataTO.getViewNameList().size(); i++) {
            if (adhocRptDataTO.getPresnCalcNumList().get(i).equals(EMPTY_STRING)) {
                if (!viewNameUniqList.contains(adhocRptDataTO.getViewNameList().get(i))) {
                    viewNameUniqList.add(adhocRptDataTO.getViewNameList().get(i));
                }
            }
        }
    }


    /**
     * @param adhocRptDataTO
     * @param loopCount
     * @throws RABCException
     */
    public void updateMainSelectClause(AdhocRptDataTO adhocRptDataTO, int loopCount) throws RABCException {
        int calcNumCount = 0;
        String temp1 = EMPTY_STRING;
        // String calcFormula = null;

        for (int i = 0; i < adhocRptDataTO.getViewNameList().size(); i++) { // <cfloop list="#L_VIEW_NAME_ORI#"
            if (!adhocRptDataTO.getPresnCalcNumList().get(i).equals(EMPTY_STRING)) {
                boolean isOneOfThese = isCalcOneOfThese(adhocRptDataTO, loopCount, adhocRptDataTO.getPresnCalcNumList().get(i).toString());
                if (isOneOfThese) {
                    if (temp1.equals(EMPTY_STRING)) {
                        temp1 = adhocRptDataTO.getViewNameList().get(i).toString(); // vw_name
                        calcNumCount++;
                    } else {
                        if (!temp1.equalsIgnoreCase(adhocRptDataTO.getViewNameList().get(i).toString())) {
                            temp1 = adhocRptDataTO.getViewNameList().get(i).toString();
                            calcNumCount = 0;
                            calcNumCount++;
                        } else {
                            calcNumCount++;
                        }
                    }
                } else {
                }
            }
        }
    }


    /**
     * @param tblViewIndex
     */
    public void updateModArrays1(int tblViewIndex) {
        String modColName = null;
        for (int x = 1; x <= 5; x++) {
            switch (x) {
                case 1:
                    modColName = keyColumnsKey1DdlName;
                    break;
                case 2:
                    modColName = keyColumnsKey2DdlName;
                    break;
                case 3:
                    modColName = keyColumnsKey3DdlName;
                    break;
                case 4:
                    modColName = keyColumnsKey4DdlName;
                    break;
                case 5:
                    modColName = keyColumnsKey5DdlName;
            }
            if (isNotNullNE(modColName, EMPTY_STRING)) {
                int nextArrayValue = modColumnstoextractList.size();
                int nextArrayValueAsSuffix = nextArrayValue + 1;
                modColumnstoextractList.add(nextArrayValue, modColName);
                modColumnsasoracleList.add(nextArrayValue, "K" + nextArrayValueAsSuffix + modColName);

                ((ArrayList) keyTblXList.get(tblViewIndex)).add("K" + nextArrayValueAsSuffix + modColName);
                modAPresnUnitIndList.add(nextArrayValue, EMPTY_STRING);
                modAPresnSumIndList.add(nextArrayValue, NO);
                modKeysrow1columnsList.add(nextArrayValue, modColName);
                modKeysrow1tablesList.add(nextArrayValue, viewNameUniqList.get(tblViewIndex));
                modColumnstablesList.add(nextArrayValue, keyColumnsPresnDataTbl);
                modAPresnCalcNumList.add(nextArrayValue, EMPTY_STRING);
            }
            if ((isNotNullNE(modColName, EMPTY_STRING)) && (isNotNullNE((String) viewNameUniqList.get(tblViewIndex), EMPTY_STRING))) {
                switch (x) {
                    case 1:
                        modAKey1DdlNameList.add(((String) viewNameUniqList.get(tblViewIndex)).trim() + "." + modColName);
                        break;
                    case 2:
                        modAKey2DdlNameList.add(((String) viewNameUniqList.get(tblViewIndex)).trim() + "." + modColName);
                        break;
                    case 3:
                        modAKey3DdlNameList.add(((String) viewNameUniqList.get(tblViewIndex)).trim() + "." + modColName);
                        break;
                    case 4:
                        modAKey4DdlNameList.add(((String) viewNameUniqList.get(tblViewIndex)).trim() + "." + modColName);
                        break;
                    case 5:
                        modAKey5DdlNameList.add(((String) viewNameUniqList.get(tblViewIndex)).trim() + "." + modColName);
                        break;
                }
            }
        }
    }


    /**
     * @param adhocRptDataTO
     * @param loopCount
     * @param tblViewIndex
     * @throws RABCException
     */
    public void updateModArrays2(AdhocRptDataTO adhocRptDataTO, int loopCount, int tblViewIndex) throws RABCException {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = ConnectionManager.getConnection(adhocRptDataTO.getRegion());
            ps = conn.prepareStatement(QRY_GET_COLUMNS);
            ps.setInt(1, adhocRptDataTO.getPresnId());
            ps.setString(2, adhocRptDataTO.getWebId());
            ps.setInt(3, ((Integer) (adhocRptDataTO.getDistExecPresnSeqNumList().get(loopCount))).intValue());
            ps.setString(4, (String) viewNameUniqList.get(tblViewIndex));
            rs = ps.executeQuery();
            while (rs.next()) {
                String columnsDataDdlName = rs.getString("DATA_DDL_NAME") == null ? EMPTY_STRING : rs.getString("DATA_DDL_NAME").trim();
                String columnsDataTbl = rs.getString("DATA_TBL") == null ? EMPTY_STRING : rs.getString("DATA_TBL").trim();
                String columnsViewName = rs.getString("VIEW_NAME") == null ? EMPTY_STRING : rs.getString("VIEW_NAME").trim();
                String columnsPresnCalcNum = rs.getString("PRESN_CALC_NUM") == null ? EMPTY_STRING : rs.getString("PRESN_CALC_NUM").trim();
                String columnsPrevDataInd = rs.getString("PREV_DATA_IND") == null ? EMPTY_STRING : rs.getString("PREV_DATA_IND").trim();
                String columnsPresnUnitInd = rs.getString("PRESN_UNIT_IND") == null ? EMPTY_STRING : rs.getString("PRESN_UNIT_IND").trim();
                String columnsPresnSumInd = rs.getString("PRESN_SUM_IND") == null ? EMPTY_STRING : rs.getString("PRESN_SUM_IND").trim();
                String columnsDiffDataInd = rs.getString("DIFF_DATA_IND") == null ? EMPTY_STRING : rs.getString("DIFF_DATA_IND").trim();                
                if (!columnsDataDdlName.equals(EMPTY_STRING)) {
                    if (columnsPresnCalcNum.equals(EMPTY_STRING)) {
                        int theValue = modColumnstoextractList.size();
                        modColumnstoextractList.add(theValue, columnsDataDdlName);
                        for (int listIndex = 0; listIndex < viewNameUniqList.size(); listIndex++) {
                            if (viewNameUniqList.get(listIndex).toString().equalsIgnoreCase(viewNameUniqList.get(tblViewIndex).toString())) {
                                int pos = adhocRptDataTO.getColumnsAsOracleList().indexOf(columnsDataDdlName);
                                if (pos != -1) {
                                    modColumnsasoracleList.add(theValue, adhocRptDataTO.getColumnsAsOracleList().get(pos));
                                }
                            }
                        }
                        modAPresnUnitIndList.add(theValue, columnsPresnUnitInd);
                        modAPresnSumIndList.add(theValue, columnsPresnSumInd);
                        modAElemTableNameList.add(columnsDataTbl);
                        modAElemViewNameList.add(columnsViewName);
                        modAElemPrevIndList.add(columnsPrevDataInd);
                        modColumnstablesList.add(columnsDataTbl);
                        modAPresnCalcNumList.add(EMPTY_STRING);
                        modAElemDiffIndList.add(columnsDiffDataInd);
                    } else {
                       // boolean isOneOfThese = isCalcOneOfThese(adhocRptDataTO, loopCount, columnsPresnCalcNum);
                        calcNumCount++;
                        int theValue = modColumnstoextractList.size();
                        modColumnstoextractList.add(theValue, "CALC" + calcNumCount);
                        modColumnsasoracleList.add(theValue, "CALC" + calcNumCount);
                        modAPresnUnitIndList.add(theValue, columnsPresnUnitInd);
                        modAPresnSumIndList.add(theValue, columnsPresnSumInd);
                        modAElemTableNameList.add(columnsDataTbl);
                        modAElemViewNameList.add(columnsViewName);
                        modAElemPrevIndList.add(columnsPrevDataInd);
                        modAElemDiffIndList.add(columnsDiffDataInd);
                        modColumnstablesList.add(columnsDataTbl);
                        modAPresnCalcNumList.add(new Integer(columnsPresnCalcNum));
                    }
                }
            }
        } catch (SQLException sqle) {
            throw new RABCException("Error in retrieving column information", sqle);
        } catch (NamingException ne) {
            throw new RABCException("NamingException ", ne);
        } finally {
            JDBCUtil.closeResultSet(rs);
            JDBCUtil.closePreparedStatement(ps);
            JDBCUtil.closeConnection(conn);
        }
    }


    /**
     * Used in multiple places
     * 
     * @param adhocRptDataTO
     * @param loopCount
     * @param columnsPresnCalcNum
     * @return
     * @throws RABCException
     */
    private boolean isCalcOneOfThese(AdhocRptDataTO adhocRptDataTO, int loopCount, String columnsPresnCalcNum) throws RABCException {
        Calculation calc = new AdhocRptDAO().getCalcElem(adhocRptDataTO, columnsPresnCalcNum, loopCount);
        boolean isOneOfThese = calc.getFormula().indexOf("AVG(") != -1;
        isOneOfThese |= calc.getFormula().indexOf("MAX(") != -1;
        isOneOfThese |= calc.getFormula().indexOf("MIN(") != -1;
        isOneOfThese |= calc.getFormula().indexOf("COUNT(") != -1;
        return isOneOfThese;
    }

    /**
     * @param dto
     * @param tblCount
     */
    public void updateOrderByClause(AdhocRptDataTO dto, int tblCount) {
        boolean orderByCols = false;
        for (int x = 0; x < dto.getPresnOrdIndList().size(); x++) {
            if (!dto.getPresnOrdIndList().get(x).toString().equals(EMPTY_STRING)) {
                orderByCols = true;
                break;
            }
        }

        if (orderByCols) {
            if (!dto.getAlertTimeInd().equals(EMPTY_STRING) && dto.getAlertTimeValue() == 0) {
                if (isRABCTbl(dto.getPresnTblName(), dto.getRegion())) {
                    orderByClauseList.add("TABLE1.alert_trend_time");
                }
            }
            // first order by the columns, then the file process date, then the file_seq_num and then the keys
            int numberOfKeys = dto.getKeysRow1ColumnsList().size();
            // first order by the columns which have sorting selected, then order by the rest of the columns
            for (int x = numberOfKeys; x < dto.getColumnsToExtractList().size(); x++) {
                String orderInd = getOrderCode(dto, x);
                if (dto.getPresnSumIndList().get(x).toString().equalsIgnoreCase(NO)) {
                    if (dto.getColumnsToExtractList().get(x).toString().equalsIgnoreCase("EXTRCT_ITEM") || dto.getColumnsToExtractList().get(x).toString().equalsIgnoreCase("ALERT_ITEM")) {
                        orderByClauseList.add(dto.getColumnsTablesList().get(x) + "." + dto.getColumnsAsOracleList().get(x) + " Desc");
                    }
                }
                if (!dto.getPresnOrdIndList().get(x).toString().equals(EMPTY_STRING)) {
                    orderByClauseList.add(dto.getColumnsTablesList().get(x) + "." + dto.getColumnsAsOracleList().get(x) + " " + orderInd);
                }
            }
            // order by the rest of the columns which do not have the order indicator
            for (int x = numberOfKeys; x < dto.getColumnsToExtractList().size(); x++) {
                if (dto.getPresnOrdIndList().get(x).toString().equals(EMPTY_STRING)) {
                    orderByClauseList.add(dto.getColumnsTablesList().get(x) + "." + dto.getColumnsAsOracleList().get(x));
                }
            }
            sortByForBillRoundDateIndOfPAndMonthly(dto, tblCount);
            // if the 'Call Day Week' selected is equal to 'All'
            if ((dto.getPresnTrendTime().equalsIgnoreCase(MONTHLY) && dto.getNoProcDate().equalsIgnoreCase(NO)) || (dto.getPresnTrendTime().equalsIgnoreCase(YES) && dto.getNoProcDate().equalsIgnoreCase(NO)) || dto.getNoProcDate().equalsIgnoreCase(NO)) {
                if (dto.getAlertTimeValue() == 0) {
                    orderByClauseList.add("WEEKDAY");
                }
            }
            // file seq num
            if (dto.getFileSeqNumInd().equalsIgnoreCase(YES)) {
                orderByClauseList.add("to_number(decode(TABLE1.file_seq_num,'no data',0,TABLE1.file_seq_num))");
            }
            // keys
            for (int x = 0; x < dto.getKeysRow1ColumnsList().size(); x++) {
                orderByClauseList.add(dto.getColumnsTablesList().get(x) + "." + dto.getColumnsAsOracleList().get(x));
            }
        } else {
            // first order by the file process date, then the file_seq_num and then by the keys and the cols
            if (!dto.getAlertTimeInd().equals(EMPTY_STRING) && dto.getAlertTimeValue() == 0) {
                if (isRABCTbl(dto.getPresnTblName(), dto.getRegion())) {
                    orderByClauseList.add("TABLE1.alert_trend_time");
                }
            }
            sortByForBillRoundDateIndOfPAndMonthly(dto, tblCount);
            // if the 'Call Day Week' selected is equal to 'All'
            if ((dto.getPresnTrendTime().equalsIgnoreCase(MONTHLY) && dto.getNoProcDate().equalsIgnoreCase(NO)) || (dto.getPresnTrendTime().equalsIgnoreCase(YES) && dto.getNoProcDate().equalsIgnoreCase(NO)) || dto.getNoProcDate().equalsIgnoreCase(NO)) {
                if (dto.getAlertTimeValue() == 0) {
                    orderByClauseList.add("WEEKDAY");
                }
            }
            // file seq num
            if (dto.getFileSeqNumInd().equalsIgnoreCase(YES)) {
                orderByClauseList.add("to_number(decode(TABLE1.file_seq_num,'no data',0,TABLE1.file_seq_num))");
            }
            // keys
            for (int x = 0; x < dto.getKeysRow1ColumnsList().size(); x++) {
                orderByClauseList.add(dto.getColumnsTablesList().get(x) + "." + dto.getColumnsAsOracleList().get(x));
            }
            int columnsIndex = dto.getKeysRow1ColumnsList().size(); // <CFSET ColumnsIndex =

            // columns
            for (int x = columnsIndex; x < dto.getColumnsToExtractList().size(); x++) {
                if (dto.getPresnSumIndList().get(x).toString().equalsIgnoreCase(NO)) {
                    if (dto.getColumnsToExtractList().get(x).toString().equalsIgnoreCase("EXTRCT_ITEM") || dto.getColumnsToExtractList().get(x).toString().equalsIgnoreCase("ALERT_ITEM")) {
                        orderByClauseList.add(dto.getColumnsTablesList().get(x) + "." + dto.getColumnsAsOracleList().get(x) + " Desc");
                    }
                }
                String orderInd = EMPTY_STRING;
                if (!dto.getPresnOrdIndList().get(x).toString().equals(EMPTY_STRING)) {
                    if (dto.getPresnOrdIndList().get(x).toString().equalsIgnoreCase("A")) {
                        orderInd = "ASC";
                    } else if (dto.getPresnOrdIndList().get(x).toString().equalsIgnoreCase("D")) {
                        orderInd = "DESC";
                    }
                }
                orderByClauseList.add(dto.getColumnsTablesList().get(x) + "." + dto.getColumnsAsOracleList().get(x) + " " + orderInd);
            }
        }
    }


    /**
     * @param dto
     * @param tblCount
     */
    private void sortByForBillRoundDateIndOfPAndMonthly(AdhocRptDataTO dto, int tblCount) {
    	String table = (String) dto.getColumnsTablesList().get(tblCount);

        if (dto.isProcDateUsed(tblCount)) {
            orderByClauseList.add(dot(table, "PROC_DATE"));
            return;
        }

        orderByClauseList.add(dot(table, dto.getProcYearField(tblCount)));
        orderByClauseList.add(dot(table, dto.getProcMonthField(tblCount)));
    }


    /**
     * @param adhocRptDataTO
     */
    public void updateOtherConditions(AdhocRptDataTO adhocRptDataTO) {
        ArrayList tempList = AdhocRptUtil.stringToArrayList(adhocRptDataTO.getTableNames(), ",");

        if (adhocRptDataTO.isRecCountFlag()) { // <CFIF QRY_PRESNRULE.RECORDCOUNT GT 1>
            if (viewNameUniqList.get(0).toString().equalsIgnoreCase("RABC_EXTRCT_SUMY_DATA") && viewNameUniqList.get(1).toString().equalsIgnoreCase("RABC_CALC_ALERT_DATA")) {
                conditionClauseList.add("TABLE1.EXTRCT_ITEM = TABLE2.ALERT_ITEM(+)");
                int alertCount = 0;
                for (int indexValue = 0; indexValue < viewNameUniqList.size(); indexValue++) {
                    if (tempList.get(indexValue).toString().equalsIgnoreCase("RABC_EXTRCT_SUMY_DATA")) {
                        alertCount++;
                        if (alertCount > 1) {
                            int tableSuffix = indexValue + 1;
                            conditionClauseList.add("TABLE" + tableSuffix + ".EXTRCT_ITEM = TABLE2.ALERT_ITEM");
                        }
                    }
                }
            } else if (viewNameUniqList.get(1).toString().equalsIgnoreCase("RABC_EXTRCT_SUMY_DATA") && viewNameUniqList.get(0).toString().equalsIgnoreCase("RABC_CALC_ALERT_DATA")) {
                conditionClauseList.add("TABLE1.ALERT_ITEM = TABLE2.EXTRCT_ITEM(+)");
                int alertCount = 0;
                for (int indexValue = 0; indexValue < viewNameUniqList.size(); indexValue++) {
                    if (tempList.get(indexValue).toString().equalsIgnoreCase("RABC_EXTRCT_SUMY_DATA")) {
                        alertCount++;
                        if (alertCount > 1) {
                            int tableSuffix = indexValue + 1;
                            conditionClauseList.add("TABLE2.ALERT_ITEM = TABLE" + tableSuffix + ".EXTRCT_ITEM");
                        }
                    }
                }
            }
        }

        for (int indexValue = 0; indexValue < viewNameUniqList.size(); indexValue++) {
            if (viewNameUniqList.get(indexValue).toString().equalsIgnoreCase("RABC_EXTRCT_SUMY_DATA")) {
                int tableSuffix = indexValue + 1;
                String insWhereClause = "TABLE" + tableSuffix + ".PRESN_CD" + " IN ('A', 'B')";
                int count = 0;
                for (int x = 0; x < conditionClauseList.size(); x++) {
                    if (conditionClauseList.get(x).toString().equalsIgnoreCase(insWhereClause)) {
                        count++;
                    }
                }
                if (count < 1) {
                    conditionClauseList.add(insWhereClause);
                }
            }
        }
    }


    /**
     * @param adhocRptDataTO
     * @param tblViewIndex
     */
    public void updateSelectArray1(AdhocRptDataTO adhocRptDataTO, int tblViewIndex) {
        String presnTrendTime = adhocRptDataTO.getPresnTrendTime().trim().toUpperCase();
        String table = (String) viewNameUniqList.get(tblViewIndex);

        if (table.startsWith("VW_")) {
            table = viewTbl;
        }

        /*
         * 11/15/2006
         * 
         * 
         * KC(12:57:20): procDateInd=P what is this indicator mean? Does it mean the table contain Run-date that the
         * program doesn't not have to build the MMDDYYYY. you can just get it directly from run-date <br>MikeB(13:10:44):
         * i don't know. I'll have to look at the code KC(13:12:27): the logic you send me only apply to table which
         * does not have run-date. but have MM column,YY column MikeB(13:15:17): It is P if the following is false:
         * (tblBillRndDdlMon = null OR "") AND (tblBillRndDdlYear=null or "") KC(13:16:17): Yes, that mean the table
         * does not have MM and YY column, you can directly use the proc-dt column KC(13:16:44): you do not need to
         * format the date MikeB(13:17:10): so if there is something in the billRndDdlMon & Year we don't use it?
         * KC(13:20:02): NO if the proc-dt exist, always use proc-dt, if proc-date not exist,then check the
         * billRndDdlMon if available and It is a bill rnd report. if available use it to format the date, if even the
         * billRndDdlMon not available you do not have a report MikeB(13:20:38): Is this for any type of report or just
         * presnTrendTime=B? KC(13:22:28): Yes apply to all other report. I forget the monthly report beside bill day,
         * if Monthly report, the MMYYYY be used too. For daily report you do not have bill rnd to format the date
         * anywhere. MikeB(13:22:49): ok. thanks
         * 
         * 
         */
        boolean procDateExists = adhocRptDataTO.getNoProcDate().trim().toUpperCase().equals(NO);

        /*
         * BILL_ROUND w/o proc_date
         */
        if (!procDateExists && presnTrendTime.equals(BILL_ROUND)) {
            String billRound = ((DataTblDdlBean) StaticDataLoader.getDataTblDdlByAlertProcTbl(table, adhocRptDataTO.getRegion()).get(0)).getTblBillRndDdlName();
            if (adhocRptDataTO.getMonthSelect()!=0 && adhocRptDataTO.getYearSelect()!=0 && adhocRptDataTO.getPresnModel()==1){
            	selectClauseList.add("TO_CHAR(TO_DATE(" + dot(table, nameBillMonth) + "||'/'||" + dot(table, billRound) + "||'/'||" + dot(table, nameBillYear) + ",'MM/DD/YYYY'),'MM/YYYY') proc_date");
                selectClauseList.add("TO_CHAR(TO_DATE(" + dot(table, nameBillYear) + "||" + dot(table, nameBillMonth) + "||" + dot(table, billRound) + ",'YYYYMMDD'),'MM/YYYY') TEMP_PROC_DATE");
                adhocRptDataTO.setProcDateFormat("MM/YYYY");
            } else {
            	selectClauseList.add("TO_DATE(" + dot(table, nameBillMonth) + "||'/'||" + dot(table, billRound) + "||'/'||" + dot(table, nameBillYear) + ",'MM/DD/YYYY') proc_date");
                selectClauseList.add("TO_DATE(" + dot(table, nameBillYear) + "||" + dot(table, nameBillMonth) + "||" + dot(table, billRound) + ",'YYYYMMDD') TEMP_PROC_DATE");
                adhocRptDataTO.setProcDateFormat("MM/DD/YYYY");
            }
            
            selectClauseList.add(dot(table, nameBillMonth) + " proc_" + nameBillMonth);
            selectClauseList.add(dot(table, nameBillYear) + " proc_" + nameBillYear);
            /*
             * MONTHLY w/o proc_date
             */
        } else if (!procDateExists && presnTrendTime.equals(MONTHLY)) {
            selectClauseList.add("TO_DATE(" + dot(table, nameBillMonth) + "||'/'||" + dot(table, nameBillYear) + ",'MM/YYYY') proc_date");
            selectClauseList.add("TO_DATE(" + dot(table, nameBillYear) + "||" + dot(table, nameBillMonth) + ",'YYYYMM') TEMP_PROC_DATE");
            selectClauseList.add(dot(table, nameBillMonth) + " proc_" + nameBillMonth);
            selectClauseList.add(dot(table, nameBillYear) + " proc_" + nameBillYear);
            adhocRptDataTO.setProcDateFormat("MM/YYYY");
            /*
             * YEARLY w/o proc_date
             */
        } else if (presnTrendTime.equals("Y") && !procDateExists) {
            selectClauseList.add(dot(table, nameBillYear) + " proc_date");
            adhocRptDataTO.setProcDateFormat("YYYY");
            /*
             * BILL_ROUND w/proc_date
             */
        } else if (presnTrendTime.equals(BILL_ROUND)) {
        	if (adhocRptDataTO.getMonthSelect()!=0 && adhocRptDataTO.getYearSelect()!=0 && adhocRptDataTO.getPresnModel()==1){
        		// selectClauseList.add("TO_CHAR(" + dot(table, modAProcDates) + ",'MON-YY') PROC_DATE");
        		String mth = null;
        		if (adhocRptDataTO.getMonthSelect() < 10) {
        			mth = "0" + adhocRptDataTO.getMonthSelect();
        		} else {
        			mth = Integer.toString(adhocRptDataTO.getMonthSelect());
        		}
        		selectClauseList.add("'" + mth + "/" + adhocRptDataTO.getYearSelect()+ "' PROC_DATE");
        		adhocRptDataTO.setProcDateFormat("STRING"); 
        	} else {
        		selectClauseList.add(dot(table, modAProcDates) + " PROC_DATE");
        		adhocRptDataTO.setProcDateFormat("DATE"); 
        	}
            if (adhocRptDataTO.getAlertTimeValue() == 0) {
                selectClauseList.add("to_char(" + dot(table, modAProcDates) + ",'D') WEEKDAY");
            }
            /*
             * MONTHY w/proc_date
             */
        } else if (presnTrendTime.equals(MONTHLY) && procDateExists) {
            
        	if (adhocRptDataTO.getPresnModel() == 3 ) { // This condition is put especailly for layout 3. 
        		selectClauseList.add("to_date(" + dot(table, modAProcDates) + ", 'DD-MON-YYYY') PROC_DATE");
        	} else {
        		selectClauseList.add("to_char(" + dot(table, modAProcDates) + ", 'yyyymm') PROC_DATE");
        	}
        	
            if (adhocRptDataTO.getAlertTimeValue() == 0) {
                selectClauseList.add("to_char(" + dot(table, modAProcDates) + ",'D') WEEKDAY");
            }
            adhocRptDataTO.setProcDateFormat("YYYYMM");
            /*
             * YEARLY w/proc_date
             */
        } else if (presnTrendTime.equals("Y") && procDateExists) {
            selectClauseList.add("to_char(" + dot(table, modAProcDates) + ", 'yyyy')  proc_date");
            if (adhocRptDataTO.getAlertTimeValue() == 0) {
                selectClauseList.add("to_char(" + dot(table, modAProcDates) + ",'D') WEEKDAY");
            }
            adhocRptDataTO.setProcDateFormat("YYYY");
            /*
             * Proc date exists, not bill_round, monthly, or yearly
             */
        } else if (procDateExists) {
            if (keyColumnsFileSeqNumInd.trim().equals(YES) && tblViewIndex == 0) {
            	if (adhocRptDataTO.getMonthSelect()!=0 && adhocRptDataTO.getYearSelect()!=0 && adhocRptDataTO.getPresnModel()==1){
            		selectClauseList.add("*MIN(to_char(" + dot(table, modAProcDates) + ",'mm/yyyy'))  PROC_DATE");
            		adhocRptDataTO.setProcDateFormat("MM/YYYY");
            	} else {
            		selectClauseList.add("*MIN(to_char(" + dot(table, modAProcDates) + ", 'yyyymmdd'))  PROC_DATE");
            		adhocRptDataTO.setProcDateFormat("YYYYMMDD");
            	}
            } else if (keyColumnsFileSeqNumInd.trim().equals(YES) && tblViewIndex > 0) {
                // do nothing
            } else {
            	if (adhocRptDataTO.getMonthSelect()!=0 && adhocRptDataTO.getYearSelect()!=0 && adhocRptDataTO.getPresnModel()==1){
            		selectClauseList.add("to_char(" + dot(table, modAProcDates) + ",'mm/yyyy')  PROC_DATE");
            		adhocRptDataTO.setProcDateFormat("MM/YYYY");
            	} else {
            		selectClauseList.add("to_char(" + dot(table, modAProcDates) + ", 'yyyymmdd')  PROC_DATE");
            		adhocRptDataTO.setProcDateFormat("YYYYMMDD");
            	}
                // selectClauseList.add(dot(table, modAProcDates) + " PROC_DATE_SEQ_NUM");
            }
            if (adhocRptDataTO.getAlertTimeValue() == 0) {
                selectClauseList.add("to_char(" + dot(table, modAProcDates) + ",'D') WEEKDAY");
            }
            /*
             * Proc date exists, not bill_round, monthly, or yearly
             */
        } else if (!procDateExists) {
            selectClauseList.add("to_char(" + dot(table, nameBillYear) + ")||'/'||to_char(" + dot(table, nameBillMonth) + ") PROC_DATE");
            selectClauseList.add("to_char(" + dot(table, nameBillYear) + ")||to_char(" + dot(table, nameBillMonth) + ") PROC_DATE");
            selectClauseList.add("to_char(" + dot(table, nameBillMonth) + ") proc_" + nameBillMonth);
            selectClauseList.add("to_char(" + dot(table, nameBillYear) + ") proc_" + nameBillYear);
            adhocRptDataTO.setProcDateFormat("STRING");
        }

        /*
         * Alert trend time is 0
         */
        if (adhocRptDataTO.getAlertTimeValue() == 0 && isRABCTbl(table, adhocRptDataTO.getRegion())) {
            selectClauseList.add("alert_trend_time");
        }

        // this list will be contained in each cell of keyTblXList to create
        // a 2D array
        ArrayList keyTblYList = new ArrayList();

        int tableSuffix = tblViewIndex + 1;
        keyTblYList.add(0, "TABLE" + tableSuffix);
        keyTblYList.add(1, "PROC_DATE");
        keyTblXList.add(tblViewIndex, keyTblYList);
        if (keyColumnsFileSeqNumInd.trim().equals(YES)) {
            modFileSeqNumInd = YES;
            if (isRABCTbl(modPresnTblName, adhocRptDataTO.getRegion())) {
                selectClauseList.add("Decode(" + table + ".file_seq_num,null,'no data'," + table + ".file_seq_num) file_seq_num");
            } else {
                selectClauseList.add("Decode(" + table + ".seq_num,null,'no data'," + table + ".seq_num) file_seq_num");
            }
        } else {
            modFileSeqNumInd = NO;
        }
    }


    /**
     * @param adhocRptDataTO
     * @param loopCount
     * @param tblViewIndex
     * @throws RABCException
     */
    public void updateSelectArray2(AdhocRptDataTO adhocRptDataTO, int loopCount, int tblViewIndex) throws RABCException {
        calcNumCount = 0;
        for (int x = 0; x < modColumnstoextractList.size(); x++) {
            String table = (String) viewNameUniqList.get(tblViewIndex);
            if (table.startsWith("VW_")) {
                table = viewTbl;
            }
            if (modAPresnUnitIndList.get(x).toString().trim().equalsIgnoreCase("T")) {
                selectClauseList.add("Decode(" + dot(table, (String) modColumnstoextractList.get(x)) + ",null,'no data',to_char(" + dot(table, (String) modColumnstoextractList.get(x)) + ", 'mm/dd/yyyy'))  " + modColumnsasoracleList.get(x));
            } else if (modAPresnSumIndList.get(x).toString().trim().equalsIgnoreCase(NO)) {
                if (modAPresnCalcNumList.get(x).toString().trim().equalsIgnoreCase(EMPTY_STRING)) {
                    selectClauseList.add(dot(table, (String) modColumnstoextractList.get(x)) + "  " + modColumnsasoracleList.get(x));
                } else {
                    boolean isOneOfThese = isCalcOneOfThese(adhocRptDataTO, loopCount, modAPresnCalcNumList.get(x).toString().trim());
                    calcNumCount++;
                    Calculation calc = new AdhocRptDAO().getCalcElem(adhocRptDataTO, modAPresnCalcNumList.get(x).toString().trim(), loopCount);

                    String formula = calc.getDisplayFormula() ;
                    
                    if (formula.indexOf("/") != -1 ) {
                    	formula =calc.getCalcElemSQLFormula() ;
                    }
                    if (formula.indexOf("VW_") != -1 ) {
                    	String subString = formula.substring(formula.indexOf("VW_"), formula.indexOf(".")) ;
                    	formula = formula.replaceAll(subString, table) ;
                    }
                    selectClauseList.add(calc.getPresnCalcName().trim() + "  CALC" + calcNumCount + "~" + formula);
                }
            } else {
                selectClauseList.add("*SUM " + dot(table, (String) modColumnstoextractList.get(x)) + " " + modColumnsasoracleList.get(x));
            }
        }
    }


    /**
     * @param tblViewIndex
     */
    public void updateSelectArray3(int tblViewIndex) {
        String table = (String) viewNameUniqList.get(tblViewIndex);
        if (table.startsWith("VW_")) {
            table = viewTbl;
        }

        if (viewNameUniqList.get(tblViewIndex).toString().trim().equalsIgnoreCase("RABC_CALC_ALERT_DATA")) {
            selectClauseList.add(dot(table, "ALERT_ITEM ALERT_ITEM"));
        }
        if (viewNameUniqList.get(tblViewIndex).toString().trim().equalsIgnoreCase("RABC_EXTRCT_SUMY_DATA")) {
            selectClauseList.add("RABC_EXTRCT_SUMY_DATA.PRESN_CD PRESN_CD");
        }
    }


    /**
     * @param adhocRptDataTO
     * @param loopCount
     * @param tblViewIndex
     * @throws RABCException
     */
    /**
     * @param dto
     * @param loopCount
     * @param tblViewIndex
     * @throws RABCException
     */
    public void updateWhereArray(AdhocRptDataTO dto, int loopCount, int tblViewIndex) throws RABCException {
        String table = (String) viewNameUniqList.get(tblViewIndex);
        if (table.startsWith("VW_")) {
            table = viewTbl;
        }

        if (keyColumnsFileSeqNumInd.equalsIgnoreCase(YES)) {
            if (isRABCTbl(modPresnTblName, dto.getRegion())) {
                if (dto.getFileSeqNum() != -1) {
                    whereClauseList.add(table + ".file_seq_num = " + dto.getFileSeqNum());
                }
            } else {
                if (!(Integer.toString(dto.getFileSeqNum()).trim().equals(EMPTY_STRING))) {
                    whereClauseList.add(table + ".seq_num = " + dto.getFileSeqNum());
                }
            }

        }

        if (isNotNullNE(dto.getDivisionName(), EMPTY_STRING) && modDivNameKeyLvl > 0 && modKeysrow1columnsList.size() >= modDivNameKeyLvl && !modKeysrow1columnsList.get(modDivNameKeyLvl - 1).toString().trim().equals(EMPTY_STRING) && !dto.getDivisionName1().trim().equals(EMPTY_STRING)) {
            whereClauseList.add(modKeysrow1tablesList.get(modDivNameKeyLvl - 1) + "." + modKeysrow1columnsList.get(modDivNameKeyLvl - 1) + "  in (" + dto.getDivisionName1() + ")");
        }

        boolean isDate = false;

        if (modKeysrow1columnsList.size() > 0 && modDivNameKeyLvl != 1) {
            if (isNotNullNE(dto.getSortKeyList(), EMPTY_STRING)) {
                try {
                    Integer.parseInt(dto.getSortKeyList().substring(6, 10));
                    if (dto.getSortKeyList().substring(2, 3).equals("/") && dto.getSortKeyList().substring(5, 6).equals("/")) {
                        isDate = true;
                    }
                } catch (NumberFormatException nmfe) {
                } catch (StringIndexOutOfBoundsException iobe) {
                }
                if (isDate) {
                    whereClauseList.add(modAKey1DdlNameList.get(0) + "=" + "TO_DATE('" + dto.getSortKeyList() + "','MM/DD/YYYY')");
                } else {
                    whereClauseList.add("Trim(UPPER" + "(" + modAKey1DdlNameList.get(0) + "))" + "=" + "'" + dto.getSortKeyList().toUpperCase() + "'");
                }
            }
        }

        isDate = false;

        if (modAKey2DdlNameList.size() > 0) {
            if (isNotNullNE(dto.getSortKeyList2(), EMPTY_STRING)) {
                try {
                    Integer.parseInt(dto.getSortKeyList2().substring(6, 10));
                    if (dto.getSortKeyList2().substring(2, 3).equals("/") && dto.getSortKeyList2().substring(5, 6).equals("/")) {
                        isDate = true;
                    }
                } catch (NumberFormatException nmfe) {
                } catch (StringIndexOutOfBoundsException iobe) {
                }
                if (isDate) {
                    whereClauseList.add(modAKey2DdlNameList.get(0) + "=" + "TO_DATE('" + dto.getSortKeyList2() + "','MM/DD/YYYY')");
                } else {
                    whereClauseList.add("Trim(UPPER" + "(" + modAKey2DdlNameList.get(0) + "))" + "=" + "'" + dto.getSortKeyList2().toUpperCase() + "'");
                }
            }
        }

        if (isNotNullNE(dto.getStartDate(), EMPTY_STRING) && isNotNullNE(dto.getEndDate(), EMPTY_STRING)) {
            if ((dto.getPresnTrendTime().trim().equalsIgnoreCase(BILL_ROUND) && dto.getProcDateInd().trim().equalsIgnoreCase("P")) || (dto.getNoProcDate().trim().equalsIgnoreCase(YES) && !dto.getPresnTrendTime().trim().equalsIgnoreCase(YES))) {
                whereClauseList.add(table + ".run_date >= to_date('" + dto.getStartDate() + "', 'MM/DD/YYYY')");
                whereClauseList.add(table + ".run_date <= to_date('" + dto.getEndDate() + "', 'MM/DD/YYYY')");
                if (dto.getAlertTimeValue() > 0) {
                    whereClauseList.add(table + "." + nameBillCycle + " = " + dto.getAlertTimeValue());
                }
            } else if (dto.getNoProcDate().trim().equalsIgnoreCase(YES) && dto.getPresnTrendTime().trim().equalsIgnoreCase(YES)) {
                whereClauseList.add("to_char(" + table + "." + nameBillYear + ") >= " + dto.getStartDate().substring(6, 10));
                whereClauseList.add("to_char(" + table + "." + nameBillYear + ") <= " + dto.getEndDate().substring(6, 10));
                if (dto.getAlertTimeValue() > 0) {
                    whereClauseList.add(table + "." + nameBillCycle + " = " + dto.getAlertTimeValue());
                }
            } else if (dto.getPresnTrendTime().trim().equalsIgnoreCase(BILL_ROUND) || dto.getPresnTrendTime().trim().equalsIgnoreCase(MONTHLY)) {
                if (dto.getPresnTrendTime().trim().equalsIgnoreCase(BILL_ROUND)) {
                    SimpleDateFormat sdfmt = new SimpleDateFormat(DATEFORMAT);
                    Date datea = null, dateb = null;
                    try {
                        datea = sdfmt.parse(dto.getStartDate());
                        dateb = sdfmt.parse(dto.getEndDate());
                        fromDt = dateToOracleFormat(datea);
                        toDt = dateToOracleFormat(dateb);

                    } catch (ParseException pe) {
                        throw new RABCException("Error in parsing string to date", pe);
                    }
                } else {
                    setFromDtToDT(dto);
                }

                if (AdhocRptUtil.isBefore(dto.getStartDate(), BASE_DATE) && dto.getPresnModel() != 4) {
                    whereClauseList.add("((" + table + "." + modAProcDates + " between TO_DATE('" + fromDt + "','DD-Mon-YY') and TO_DATE('" + toDt + "','DD-Mon-YY')) or " + table + "." + modAProcDates + " is null)");
                } else {
                    whereClauseList.add("((" + table + "." + modAProcDates + " between TO_DATE('" + fromDt + "','DD-Mon-YY') and TO_DATE('" + toDt + "','DD-Mon-YY')) and " + table + "." + modAProcDates + " is not null)");
                }
                if (dto.getPresnTrendTime().trim().equalsIgnoreCase(MONTHLY) && dto.getAlertTimeValue() > 0) {
                    if (!dto.getAlertTimeInd().trim().equalsIgnoreCase(BILL_ROUND)) {
                        whereClauseList.add("to_char(" + table + "." + modAProcDates + ",'D') = " + dto.getAlertTimeValue());
                    } else {
                        whereClauseList.add("trim(" + table + "." + modABillRnd + ") = '" + dto.getAlertTimeValue() + "'"); // 556010
                    }
                }
                if (dto.getPresnTrendTime().trim().equalsIgnoreCase(BILL_ROUND) && dto.getAlertTimeValue() > 0) {
                    whereClauseList.add("" + table + "." + nameBillCycle + " = " + dto.getAlertTimeValue());
                }
            } else if (dto.getPresnTrendTime().trim().equalsIgnoreCase(YES)) {
                if (AdhocRptUtil.isBefore(dto.getStartDate(), BASE_DATE) && dto.getPresnModel() != 4) {
                    whereClauseList.add("((to_char(" + table + "." + modAProcDates + ",'YYYY') >= " + dto.getStartDate().substring(6, 10) + " and to_char(" + table + "." + modAProcDates + ",'YYYY') <= " + dto.getEndDate().substring(6, 10) + ") or " + table + "." + modAProcDates + " is null)");
                } else {
                    whereClauseList.add("((to_char(" + table + "." + modAProcDates + ",'YYYY') >= " + dto.getStartDate().substring(6, 10) + " and to_char(" + table + "." + modAProcDates + ",'YYYY') <= " + dto.getEndDate().substring(6, 10) + ") and " + table + "." + modAProcDates + " is not null)");
                }
                if (dto.getAlertTimeValue() > 0) {
                    if (!dto.getAlertTimeInd().trim().equalsIgnoreCase(BILL_ROUND)) { // 556010
                        whereClauseList.add("to_char(" + table + "." + modAProcDates + ",'D') = " + dto.getAlertTimeValue());
                    } else {
                        whereClauseList.add("trim(" + table + "." + modABillRnd + ") = '" + dto.getAlertTimeValue() + "'");
                    }
                }
            } else {
                if (modFileSeqNumInd.equalsIgnoreCase(YES) && tblViewIndex == 0) {
                    if (AdhocRptUtil.isBefore(dto.getStartDate(), BASE_DATE) && dto.getPresnModel() != 4) {
                        whereClauseList.add("((" + table + "." + modAProcDates + " between to_date('" + dto.getStartDate() + "','MM/DD/YYYY') and to_date('" + dto.getEndDate() + "','MM/DD/YYYY')) or " + table + "." + modAProcDates + " is null)");
                    } else {
                        whereClauseList.add("((" + table + "." + modAProcDates + " between to_date('" + dto.getStartDate() + "','MM/DD/YYYY') and to_date('" + dto.getEndDate() + "','MM/DD/YYYY')) and " + table + "." + modAProcDates + " is not null)");
                    }
                } else if (modFileSeqNumInd.equalsIgnoreCase(YES) && tblViewIndex > 0) {
                    String fileStartDate = AdhocRptUtil.addDate(dto.getStartDate(), -5);
                    String fileEndDate = AdhocRptUtil.addDate(dto.getEndDate(), 5);
                    if (AdhocRptUtil.isBefore(fileStartDate, BASE_DATE) && dto.getPresnModel() != 4) {
                        whereClauseList.add("((" + table + "." + modAProcDates + " between to_date('" + fileStartDate + "','MM/DD/YYYY') and to_date('" + fileEndDate + "','MM/DD/YYYY')) or " + table + "." + modAProcDates + " is null)");
                    } else {
                        whereClauseList.add("((" + table + "." + modAProcDates + " between to_date('" + fileStartDate + "','MM/DD/YYYY') and to_date('" + fileEndDate + "','MM/DD/YYYY')) and " + table + "." + modAProcDates + " is not null)");
                    }
                } else {
                    if (AdhocRptUtil.isBefore(dto.getStartDate(), BASE_DATE) && dto.getPresnModel() != 4) {
                        whereClauseList.add("((" + table + "." + modAProcDates + " between to_date('" + dto.getStartDate() + "','MM/DD/YYYY') and to_date('" + dto.getEndDate() + "','MM/DD/YYYY')) or " + table + "." + modAProcDates + " is null)");
                    } else {
                        whereClauseList.add("((" + table + "." + modAProcDates + " between to_date('" + dto.getStartDate() + "','MM/DD/YYYY') and to_date('" + dto.getEndDate() + "','MM/DD/YYYY')) and " + table + "." + modAProcDates + " is not null)");
                    }
                }
                if (dto.getAlertTimeValue() > 0) {
                    if (!dto.getAlertTimeInd().trim().equalsIgnoreCase(BILL_ROUND)) { // 556010
                        whereClauseList.add("to_char(" + table + "." + modAProcDates + ",'D') = " + dto.getAlertTimeValue());
                    } else {
                        whereClauseList.add("trim(" + table + "." + modABillRnd + ") = '" + dto.getAlertTimeValue() + "'");
                    }
                }
            }
        } else if (isNotNullNE(dto.getStartDate(), EMPTY_STRING)) {
            if ((dto.getPresnTrendTime().trim().equalsIgnoreCase(BILL_ROUND) && dto.getProcDateInd().trim().equalsIgnoreCase("P")) || (dto.getNoProcDate().trim().equalsIgnoreCase(YES) && !dto.getPresnTrendTime().trim().equalsIgnoreCase(YES))) {
                whereClauseList.add("" + table + "." + nameBillMonth + " = " + dto.getStartDate().substring(3, 5));
                whereClauseList.add("" + table + "." + nameBillYear + " = " + dto.getStartDate().substring(6, 10));
                if (dto.getAlertTimeValue() > 0) {
                    whereClauseList.add("" + table + "." + nameBillCycle + " = " + dto.getAlertTimeValue());
                }
            } else if (dto.getPresnTrendTime().trim().equalsIgnoreCase(BILL_ROUND) || dto.getPresnTrendTime().trim().equalsIgnoreCase(MONTHLY)) {
                setFromDtToDT(dto);
                whereClauseList.add("to_char(" + table + "." + modAProcDates + ",'Mon-YY') = '" + fromDt.substring(3, 9) + "'");
                if (dto.getPresnTrendTime().trim().equalsIgnoreCase(MONTHLY) && dto.getAlertTimeValue() > 0) {
                    if (!dto.getAlertTimeInd().trim().equalsIgnoreCase(BILL_ROUND)) { // 556010
                        whereClauseList.add("to_char(" + table + "." + modAProcDates + ",'D') = " + dto.getAlertTimeValue());
                    } else {
                        whereClauseList.add("trim(" + table + "." + modABillRnd + ") = '" + dto.getAlertTimeValue() + "'");
                    }
                }
            } else if (dto.getNoProcDate().trim().equalsIgnoreCase(YES) && dto.getPresnTrendTime().trim().equalsIgnoreCase(YES)) {
                whereClauseList.add("to_char(" + table + "." + modAProcDates + ",'YYYY') = " + dto.getStartDate().substring(6, 10));
                if (dto.getAlertTimeValue() > 0) {
                    if (!dto.getAlertTimeInd().trim().equalsIgnoreCase(BILL_ROUND)) { // 556010
                        whereClauseList.add("to_char(" + table + "." + modAProcDates + ",'D') = " + dto.getAlertTimeValue());
                    } else {
                        whereClauseList.add("trim(" + table + "." + modABillRnd + ") = '" + dto.getAlertTimeValue() + "'");
                    }
                }
            } else if (dto.getPresnTrendTime().trim().equalsIgnoreCase(YES)) {
                whereClauseList.add("to_char(" + table + "." + modAProcDates + ",'YYYY') = " + dto.getStartDate().substring(6, 10));
                if (dto.getAlertTimeValue() > 0) {
                    if (!dto.getAlertTimeInd().trim().equalsIgnoreCase(BILL_ROUND)) { // 556010
                        whereClauseList.add("to_char(" + table + "." + modAProcDates + ",'D') = " + dto.getAlertTimeValue());
                    } else {
                        whereClauseList.add("trim(" + table + "." + modABillRnd + ") = '" + dto.getAlertTimeValue() + "'");
                    }
                }
            } else {
                whereClauseList.add("" + table + "." + modAProcDates + " = to_date('" + dto.getStartDate() + "','MM/DD/YYYY')");
                if (dto.getAlertTimeValue() > 0) {
                    if (!dto.getAlertTimeInd().trim().equalsIgnoreCase(BILL_ROUND)) { // 556010
                        whereClauseList.add("to_char(" + table + "." + modAProcDates + ",'D') = " + dto.getAlertTimeValue());
                    } else {
                        whereClauseList.add("trim(" + table + "." + modABillRnd + ") = '" + dto.getAlertTimeValue() + "'");
                    }
                }
            }
        }

        if (modKeysrow1columnsList.size() > 0 && modKeysrow2columnsList.size() > 0) {
            for (int x = 0; x < modKeysrow1columnsList.size(); x++) {
                if (isNotNullNE((String) modKeysrow1columnsList.get(x), EMPTY_STRING) && isNotNullNE((String) modKeysrow2columnsList.get(x), EMPTY_STRING) && isNotNullNE((String) modKeysrow1tablesList.get(x), EMPTY_STRING) && isNotNullNE((String) modKeysrow2tablesList.get(x), EMPTY_STRING)) {
                    if (!modKeysrow1tablesList.get(x).toString().trim().equalsIgnoreCase(modKeysrow2tablesList.get(x).toString().trim())) {
                        whereClauseList.add(modKeysrow1tablesList.get(x) + "." + modKeysrow1columnsList.get(x) + " = " + modKeysrow2tablesList.get(x) + "." + modKeysrow2columnsList.get(x));
                    }
                }
            }
        }

        if (!Integer.toString(dto.getAlertTimeValue()).trim().equals(EMPTY_STRING) && !dto.getAlertTimeInd().trim().equals(EMPTY_STRING) && dto.getAlertTimeValue() > 0) {
            if (isRABCTbl(modPresnTblName, dto.getRegion())) {
                whereClauseList.add(table + ".alert_trend_time = '" + dto.getAlertTimeValue() + "'");
            }
        }

        /*
         * New method called to add a clause in where construct so as to check that the bill round or alert trend time
         * values do not include 0 or NULL
         */
        if ("B".equals(dto.getPresnTrendTime())){
        	updateWhereArray(dto, table);
        }
        
        StringBuffer whereClause1Buffer = new StringBuffer();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = ConnectionManager.getConnection(dto.getRegion());
            ps = conn.prepareStatement(QRY_GET_COLUMNS);
            ps.setInt(1, dto.getPresnId());
            ps.setString(2, dto.getWebId());
            ps.setInt(3, ((Integer) (dto.getDistExecPresnSeqNumList().get(loopCount))).intValue());
            ps.setString(4, table);
            rs = ps.executeQuery();
            int rowCount = 0;
            while (rs.next()) {
                rowCount++;
                if (rowCount == 1) {
                    String columnsDataTbl = rs.getString("DATA_TBL") == null ? EMPTY_STRING : rs.getString("DATA_TBL").trim();
                    String columnsViewName = rs.getString("VIEW_NAME") == null ? EMPTY_STRING : rs.getString("VIEW_NAME").trim();
                    String columnsPartiRefId = rs.getString("PARTI_REF_ID") == null ? EMPTY_STRING : rs.getString("PARTI_REF_ID").trim();
                    if (!columnsPartiRefId.equals(EMPTY_STRING) && !columnsDataTbl.equals(EMPTY_STRING)) {
                        String partiRefIdField = columnsViewName + ".PARTI_REF_ID=" + columnsPartiRefId;
                        if (whereClause1Buffer.indexOf(partiRefIdField) == -1) {
                            if (whereClause1Buffer.toString().equals(EMPTY_STRING)) {
                                whereClause1Buffer.append(partiRefIdField);
                            } else {
                                whereClause1Buffer.append("," + partiRefIdField);
                            }
                        }
                    }
                }
            }
        } catch (SQLException sqle) {
            throw new RABCException("Error in retrieving column information", sqle);
        } catch (NamingException ne) {
            throw new RABCException("NamingException ", ne);
        } finally {
            JDBCUtil.closeResultSet(rs);
            JDBCUtil.closePreparedStatement(ps);
            JDBCUtil.closeConnection(conn);
        }

        ArrayList whereClause1List = AdhocRptUtil.stringToArrayList(whereClause1Buffer.toString(), ",");
        for (int i = 0; i < whereClause1List.size(); i++) {
            whereClauseList.add(whereClause1List.get(i));
        }

        int fromValue = modKeysrow1columnsList.size();// + 1; <-- changed this because of ML#09
        for (int x = fromValue; x < modColumnstoextractList.size(); x++) {
            if (!table.toString().trim().equals(EMPTY_STRING)) {
                String viewName = viewNameUniqList.get(tblViewIndex).toString().trim();
                qryViewName(viewName, table.toString(), dto.getRegion());
            }
        }
    }

    /**
     * Private method called in case of Bill day reports 
     * @param dto
     * @throws RABCException
     */
    private void updateWhereArray(AdhocRptDataTO dto, String table) throws RABCException {   	
    	if ("on".equals(dto.getBillRoundCheck())){
			List dataTblDdlList = StaticDataLoader.getDataTblDdlByAlertProcTbl(table, dto.getRegion());
			if (dataTblDdlList!=null && !dataTblDdlList.isEmpty()){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblDdlList.get(0);
				String billRndColName = dataTblDdlBean.getTblBillRndDdlName();
				if (billRndColName!=null && !"".equals(billRndColName)){
					whereClauseList.add(table + "." + billRndColName + " IN (SELECT DISTINCT BILL_RND FROM RABC_CYCLE_CALENDAR WHERE BILL_RND IS NOT NULL AND BILL_RND <> 0)");
				}
			}
    	}
    }

    /**
     * @param tblView
     * @throws RABCException
     */
    private void qryViewName(String tblView, String realTableName, String region) throws RABCException {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = ConnectionManager.getConnection(region);
            ps = conn.prepareStatement(QRY_GET_VIEW_NAME);
            ps.setString(1, tblView);
            rs = ps.executeQuery();
            while (rs.next()) {
                String selectValue = rs.getString(1) == null ? EMPTY_STRING : rs.getString(1).trim();
                if (!selectValue.equals(EMPTY_STRING)) {
                    int count = 0;
                    for (int indexValue = 0; indexValue < whereClauseList.size(); indexValue++) {
                        if (whereClauseList.get(indexValue).toString().equalsIgnoreCase(selectValue)) {
                            count++;
                        }
                    }
                    if (count < 1) {
                        while (selectValue.indexOf(tblView) >= 0) {
                            int index = selectValue.indexOf(tblView);
                            selectValue = selectValue.substring(0, index) + realTableName + selectValue.substring(index + tblView.length());
                        }
                        whereClauseList.add(selectValue);
                    }
                }
            }
        } catch (SQLException sqle) {
            throw new RABCException("Error in retrieving view name", sqle);
        } catch (NamingException ne) {
            throw new RABCException("NamingException ", ne);
        } finally {
            JDBCUtil.closeResultSet(rs);
            JDBCUtil.closePreparedStatement(ps);
            JDBCUtil.closeConnection(conn);
        }
    }


    /**
     * @param adhocRptDataTO
     * @throws RABCException
     */
    private void setFromDtToDT(AdhocRptDataTO adhocRptDataTO) throws RABCException {
        SimpleDateFormat sdf = new SimpleDateFormat(DATEFORMAT);
        Date date1 = null, date2 = null;
        try {
            date1 = sdf.parse(adhocRptDataTO.getStartDate());
            date2 = sdf.parse(adhocRptDataTO.getEndDate());

            Calendar cal = Calendar.getInstance();
            cal.setTime(date1);
            cal.set(Calendar.DAY_OF_MONTH, 1);
            fromDt = dateToOracleFormat(date1);

            cal.setTime(date2);
            cal.set(Calendar.DAY_OF_MONTH, AdhocRptUtil.getDaysInMonth(adhocRptDataTO.getEndDate(), DATEFORMAT));
            toDt = dateToOracleFormat(date2);
        } catch (ParseException pe) {
            throw new RABCException("Error in parsing string to date", pe);
        }
    }


    /**
     * Isolated method to handle correction to ill-conceived date formatting issue.
     * 
     * @param d
     * @return
     */
    private String dateToOracleFormat(Date d) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yy");
        return sdf.format(d);
    }
}
