/*
 * Copyright  2002-2006 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.adhoc.aria;

import com.att.bac.rabc.adhoc.rpt.AdhocRptDataTO;
import com.sbc.bac.aria.ARIAReport;


/**
 * Description of class
 * 
 * <p>
 * <hr>
 * <h3>Release History</h3>
 * <p>
 * <ul>
 * 
 * <li>jb6494 Dec 13, 2006 Created class.
 * 
 * </ul>
 * <p>
 * 
 */
public class ARIAReportRABC extends ARIAReport {
    private AdhocRptDataTO dto;


    /**
     * Create report
     */
    public ARIAReportRABC() {
        super(false);
    }


    /**
     * @return Returns the dto.
     */
    public AdhocRptDataTO getDto() {
        return dto;
    }


    /**
     * @param dto The dto to set.
     */
    public void setDto(AdhocRptDataTO dto) {
        this.dto = dto;
    }

}
