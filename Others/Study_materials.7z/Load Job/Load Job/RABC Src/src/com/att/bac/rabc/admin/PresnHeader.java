/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.admin;

/**
 * This is a Data Object to represent RABC_PRESN_HEADER table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class PresnHeader {
	private int presnId;
	private String webid;
	private String header1;
	private String header2;
	private String header3;
	private String presnDateInd;

	/**
	 * @return Returns the PresnId.
	 */
	public int getPresnId() {
		return presnId;
	}
	/**
	 * @return Returns the Webid.
	 */
	public String getWebid() {
		return webid;
	}
	/**
	 * @return Returns the Header1.
	 */
	public String getHeader1() {
		return header1;
	}
	/**
	 * @return Returns the Header2.
	 */
	public String getHeader2() {
		return header2;
	}
	/**
	 * @return Returns the Header3.
	 */
	public String getHeader3() {
		return header3;
	}
	/**
	 * @return Returns the PresnDateInd.
	 */
	public String getPresnDateInd() {
		return presnDateInd;
	}

	/**
	 * @param PresnId The presnId to set.
	 */
	public void setPresnId(int presnId) {
		this.presnId = presnId;
	}
	/**
	 * @param Webid The webid to set.
	 */
	public void setWebid(String webid) {
		this.webid = webid;
	}
	/**
	 * @param Header1 The header1 to set.
	 */
	public void setHeader1(String header1) {
		this.header1 = header1;
	}
	/**
	 * @param Header2 The header2 to set.
	 */
	public void setHeader2(String header2) {
		this.header2 = header2;
	}
	/**
	 * @param Header3 The header3 to set.
	 */
	public void setHeader3(String header3) {
		this.header3 = header3;
	}
	/**
	 * @param PresnDateInd The presnDateInd to set.
	 */
	public void setPresnDateInd(String presnDateInd) {
		this.presnDateInd = presnDateInd;
	}
}
