/*
 * Module description: 
 * Load job for SO control point in case of SW region.
 * 
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 *
 * Modification History:                                     
 * SBCUID		Date			Description                         	    	
 * ------		--------		-----------
 * UD7153		20060817		Initial version for EAP 556013  
 */
package com.att.bac.rabc.load.so.sw;

public class AgeData {

	private String mktInd ; 
	private int AGE_3_DAY_CT = 0;
	private int AGE_7_DAY_CT = 0;
	private int AGE_14_DAY_CT  = 0;
	private int AGE_GT_14_DAY_CT  = 0;
	
	//default value for hashcode return value
	private static final int DEFAULT	= 03;
	
	/**
	 * @return Returns the mktInd.
	 */
	public String getMktInd() {
		return mktInd;
	}
	/**
	 * @param mktInd The mktInd to set.
	 */
	public void setMktInd(String mktInd) {
		this.mktInd = mktInd;
	}
	
	/**
	 * @return Returns the aGE_14_DAY_CT.
	 */
	public int getAGE_14_DAY_CT() {
		return AGE_14_DAY_CT;
	}
	/**
	 * @param age_14_day_ct The aGE_14_DAY_CT to set.
	 */
	public void setAGE_14_DAY_CT(int age_14_day_ct) {
		AGE_14_DAY_CT = age_14_day_ct;
	}
	/**
	 * @return Returns the aGE_3_DAY_CT.
	 */
	public int getAGE_3_DAY_CT() {
		return AGE_3_DAY_CT;
	}
	/**
	 * @param age_3_day_ct The aGE_3_DAY_CT to set.
	 */
	public void setAGE_3_DAY_CT(int age_3_day_ct) {
		AGE_3_DAY_CT = age_3_day_ct;
	}
	/**
	 * @return Returns the aGE_7_DAY_CT.
	 */
	public int getAGE_7_DAY_CT() {
		return AGE_7_DAY_CT;
	}
	/**
	 * @param age_7_day_ct The aGE_7_DAY_CT to set.
	 */
	public void setAGE_7_DAY_CT(int age_7_day_ct) {
		AGE_7_DAY_CT = age_7_day_ct;
	}
	/**
	 * @return Returns the aGE_GT_14_DAY_CT.
	 */
	public int getAGE_GT_14_DAY_CT() {
		return AGE_GT_14_DAY_CT;
	}
	/**
	 * @param age_gt_14_day_ct The aGE_GT_14_DAY_CT to set.
	 */
	public void setAGE_GT_14_DAY_CT(int age_gt_14_day_ct) {
		AGE_GT_14_DAY_CT = age_gt_14_day_ct;
	}
	
	public boolean equals(Object o) {
		if ((o instanceof AgeData) 
				&& ((AgeData)o).getMktInd().equalsIgnoreCase(this.getMktInd())	
			) 
		{
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * Hash code method used for categorizing the objects in sets so that the hash collections can search efficiently
	 */
	public int hashCode() {
		if (mktInd !=null) 
			return Integer.parseInt(mktInd);
	
		return DEFAULT;
	}

	
}
