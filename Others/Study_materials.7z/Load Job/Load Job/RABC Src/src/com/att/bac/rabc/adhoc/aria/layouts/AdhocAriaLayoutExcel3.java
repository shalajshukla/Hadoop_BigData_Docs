/*
 * Copyright  2002-2006 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.adhoc.aria.layouts;

import java.io.OutputStream;

import org.apache.struts.action.ActionForm;


/**
 * Excel version of layout 3. Essentially, it is the same as excel-1 at the time of this classes creation. It is assumed
 * that further modifications will be needed at a later date.
 * 
 * <p>
 * <hr>
 * <h3>Release History</h3>
 * <p>
 * <ul>
 * 
 * <li>jb6494 Sep 19, 2006 Created class.
 * 
 * </ul>
 * <p>
 * 
 */
public class AdhocAriaLayoutExcel3 extends AdhocAriaLayoutExcel1 {

    /**
     * Constructor
     * 
     * @param form
     * @param os
     * @param userid
     */
    public AdhocAriaLayoutExcel3(ActionForm form, OutputStream os, String userid) {
        super(form, os, userid);
    }

}
