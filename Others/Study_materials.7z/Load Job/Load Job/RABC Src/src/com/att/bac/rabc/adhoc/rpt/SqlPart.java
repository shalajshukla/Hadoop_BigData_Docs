package com.att.bac.rabc.adhoc.rpt;


/**
 * Data structure to hold two sql parts.
 * 
 * @see {@link AdhocBackgroundReportDAO}
 * 
 * @author jb6494
 * 
 */
public class SqlPart {
    public String sql;

    public String previousSql;
}
