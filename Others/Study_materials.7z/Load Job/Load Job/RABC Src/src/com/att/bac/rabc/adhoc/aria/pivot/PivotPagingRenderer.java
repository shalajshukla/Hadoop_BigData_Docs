/*
 * Copyright  2002-2005 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.adhoc.aria.pivot;

import com.sbc.bac.aria.ARIAPaging;

public interface PivotPagingRenderer {
    /**
     * Return HTML to render paging controls for the user
     * 
     * @param paging
     * @return
     */
    String renderPaging(ARIAPaging paging);
}
