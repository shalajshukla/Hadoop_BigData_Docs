/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.rpt;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.ArrayList;
import java.text.MessageFormat;

import org.apache.log4j.Logger;

import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.RABCException;

/**
 * This is a DAO that performs SELECT, INSERT and UPDATE on RABC_CNTRL_RUN table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class CntrlRunDAO {
	private static final Logger logger = Logger.getLogger(CntrlRunDAO.class);

	/**
	 * Returns the list of CntrlRun objects.
	 * 
	 * @param conn 
	 * @param failures
	 * @param args
	 * @param baseSQL
	 * @return List
	 */
	public List get(Connection conn, List failures, List args, String baseSQL) {
		List cntrlRunList = null;
		CntrlRun cntrlRun = null;
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		
		try
		{
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("CntrlRunDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			cntrlRunList = new ArrayList();
			while (rs.next()) {
				cntrlRunList.add(buildCntrlRun(rs));
			}
			
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return null;
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
		
		return cntrlRunList;
	}

	/**
	 * Private method to build CntrlRun object and return it to caller.
	 * 
	 * @param rs
	 * @return CntrlRun
	 * @throws SQLException
	 */
	private CntrlRun buildCntrlRun(ResultSet rs) throws SQLException {
		CntrlRun cntrlRun = new CntrlRun();
		
		cntrlRun.setProcDate(rs.getDate("PROC_DATE"));
		cntrlRun.setFileSeqNum(rs.getInt("FILE_SEQ_NUM"));
		cntrlRun.setAlertRule(rs.getString("ALERT_RULE"));
		cntrlRun.setKey1(rs.getString("KEY1"));
		cntrlRun.setKey2(rs.getString("KEY2"));
		cntrlRun.setSevereLvlInd(rs.getString("SEVERE_LVL_IND"));
		cntrlRun.setAlertRuleRunDt(rs.getDate("ALERT_RULE_RUN_DT"));
		cntrlRun.setNumFiles(rs.getInt("NUM_FILES"));
		return cntrlRun;
	}

	/**
	 * Execute the insert or update statement on RABC_CNTRL_RUN table.
	 * 
	 * @param conn
	 * @param failures
	 * @param args
	 * @param baseSQL
	 */
	public void executeUpdate(Connection conn, List failures, List args, String baseSQL) {
		int rowsUpdated = 0;
		Statement stmt = null;
		String sqlStmt = null;
		
		try
		{
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("CntrlRunDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rowsUpdated = stmt.executeUpdate(sqlStmt);
			logger.debug("SQL - Execution complete."+ String.valueOf(rowsUpdated) + "  rows updated");
			
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return;
		} finally {
			SQLHelper.closeStatement(stmt, failures, logger);
		}
	}

}
