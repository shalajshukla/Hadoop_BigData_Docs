/* Created by Gaurav Bhargava (GB0741) on Dec 19, 2006.
Copyright 2006-2008 AT&T Knowledge Ventures. All rights reserved. */

package com.att.bac.rabc.load.usage.calnet;

import java.util.Date;
import com.att.bac.rabc.load.calnet.CalnetDTO;

/**
 * This class represents table RABC_BILLDAY_USG_NONPLAN_ACTVT. It has fields corresponding
 * to columns in the this table and provide getter & setter methods to populate the fields.
 * @author GB0741
 */
public class RabcBillDayUsgNonPlan extends CalnetDTO{
	private Date runDate;
	private String division;
	private int cycle;
	private String agencyID;
	private int usgRcdCls;
	private String busResInd;
	private double totMinsOfUse;
	private long totMsgCt;
	private double totBlgChgs;
	private double totOthrChgs;
	private double totEccSrcg;
	private double totOperSrcg;
	private double totPsscSrcg;
	private double totLoclTax;
	private double amtPerUnit;
	private String billRnd;
	private String billMm;
	private String billYear;

	/**
	 * @return Returns the agencyID.
	 */
	public String getAgencyID() {
		return agencyID;
	}
	/**
	 * @param agencyID The agencyID to set.
	 */
	public void setAgencyID(String agencyID) {
		this.agencyID = agencyID;
	}
	/**
	 * @return Returns the amtPerUnit.
	 */
	public double getAmtPerUnit() {
		return amtPerUnit;
	}
	/**
	 * @param amtPerUnit The amtPerUnit to set.
	 */
	public void setAmtPerUnit(double amtPerUnit) {
		this.amtPerUnit = amtPerUnit;
	}
	/**
	 * @return Returns the billMm.
	 */
	public String getBillMm() {
		return billMm;
	}
	/**
	 * @param billMm The billMm to set.
	 */
	public void setBillMm(String billMm) {
		this.billMm = billMm;
	}
	/**
	 * @return Returns the billRnd.
	 */
	public String getBillRnd() {
		return billRnd;
	}
	/**
	 * @param billRnd The billRnd to set.
	 */
	public void setBillRnd(String billRnd) {
		this.billRnd = billRnd;
	}
	/**
	 * @return Returns the billYear.
	 */
	public String getBillYear() {
		return billYear;
	}
	/**
	 * @param billYear The billYear to set.
	 */
	public void setBillYear(String billYear) {
		this.billYear = billYear;
	}
	/**
	 * @return Returns the busResInd.
	 */
	public String getBusResInd() {
		return busResInd;
	}
	/**
	 * @param busResInd The busResInd to set.
	 */
	public void setBusResInd(String busResInd) {
		this.busResInd = busResInd;
	}
	/**
	 * @return Returns the cycle.
	 */
	public int getCycle() {
		return cycle;
	}
	/**
	 * @param cycle The cycle to set.
	 */
	public void setCycle(int cycle) {
		this.cycle = cycle;
	}
	/**
	 * @return Returns the division.
	 */
	public String getDivision() {
		return division;
	}
	/**
	 * @param division The division to set.
	 */
	public void setDivision(String division) {
		this.division = division;
	}
	/**
	 * @return Returns the runDate.
	 */
	public Date getRunDate() {
		return runDate;
	}
	/**
	 * @param runDate The runDate to set.
	 */
	public void setRunDate(Date runDate) {
		this.runDate = runDate;
	}
	/**
	 * @return Returns the totBlgChgs.
	 */
	public double getTotBlgChgs() {
		return totBlgChgs;
	}
	/**
	 * @param totBlgChgs The totBlgChgs to set.
	 */
	public void setTotBlgChgs(double totBlgChgs) {
		this.totBlgChgs = totBlgChgs;
	}
	/**
	 * @return Returns the totEccSrcg.
	 */
	public double getTotEccSrcg() {
		return totEccSrcg;
	}
	/**
	 * @param totEccSrcg The totEccSrcg to set.
	 */
	public void setTotEccSrcg(double totEccSrcg) {
		this.totEccSrcg = totEccSrcg;
	}
	/**
	 * @return Returns the totLoclTax.
	 */
	public double getTotLoclTax() {
		return totLoclTax;
	}
	/**
	 * @param totLoclTax The totLoclTax to set.
	 */
	public void setTotLoclTax(double totLoclTax) {
		this.totLoclTax = totLoclTax;
	}
	/**
	 * @return Returns the totMinsOfUse.
	 */
	public double getTotMinsOfUse() {
		return totMinsOfUse;
	}
	/**
	 * @param totMinsOfUse The totMinsOfUse to set.
	 */
	public void setTotMinsOfUse(double totMinsOfUse) {
		this.totMinsOfUse = totMinsOfUse;
	}
	/**
	 * @return Returns the totMsgCT.
	 */
	public long getTotMsgCt() {
		return totMsgCt;
	}
	/**
	 * @param totMsgCT The totMsgCT to set.
	 */
	public void setTotMsgCt(long totMsgCt) {
		this.totMsgCt = totMsgCt;
	}
	/**
	 * @return Returns the totOperSrcg.
	 */
	public double getTotOperSrcg() {
		return totOperSrcg;
	}
	/**
	 * @param totOperSrcg The totOperSrcg to set.
	 */
	public void setTotOperSrcg(double totOperSrcg) {
		this.totOperSrcg = totOperSrcg;
	}
	/**
	 * @return Returns the totOthrChgs.
	 */
	public double getTotOthrChgs() {
		return totOthrChgs;
	}
	/**
	 * @param totOthrChgs The totOthrChgs to set.
	 */
	public void setTotOthrChgs(double totOthrChgs) {
		this.totOthrChgs = totOthrChgs;
	}
	/**
	 * @return Returns the totPsscSrcg.
	 */
	public double getTotPsscSrcg() {
		return totPsscSrcg;
	}
	/**
	 * @param totPsscSrcg The totPsscSrcg to set.
	 */
	public void setTotPsscSrcg(double totPsscSrcg) {
		this.totPsscSrcg = totPsscSrcg;
	}
	/**
	 * @return Returns the usgRcdCls.
	 */
	public int getUsgRcdCls() {
		return usgRcdCls;
	}
	/**
	 * @param usgRcdCls The usgRcdCls to set.
	 */
	public void setUsgRcdCls(int usgRcdCls) {
		this.usgRcdCls = usgRcdCls;
	}
}
