/* Created by Gaurav Bhargava (GB0741) on Dec 11, 2006.
Copyright 2006-2008 AT&T Knowledge Ventures. All rights reserved. */

package com.att.bac.rabc.load.billday.calnet;

import java.util.Date;

import com.att.bac.rabc.load.calnet.CalnetDTO;

/**
 * This class represents table RABC_TOT_BLG_SUMY. It has fields corresponding
 * to columns in the this table and provide getter & setter methods to populate
 * the fields.
 * @author GB0741
 * @version $Revision: 1.4 $
 */
public class RabcTotBlgSumy extends CalnetDTO {
	private Date runDate;
	private String division;
	private int cycle;
	private String agencyID;
	private long acctCt;
	private double currMnthChrgAmt;
	private double currBalDueAmt;
	private double tollAmt;
	private double occAmt;
	private double bocAmt;
	private double attAmt;
	private double iecAmt;
	private double cpucSrcgAmt;
	private double fedTaxAmt;
	private double cityTaxAmt;
	private double stateTaxAmt;
	private double srvUsffAmt;
	private double euclChrgAmt;
	private double blgSrcgAmt;
	private double chcfaSrcgAmt;
	private double chcfbSrcgAmt;
	private double lflnSrcgAmt;
	private double hcapSrcgAmt;
	private double ctfSrcgAmt;
	private String billRnd;
	private String billMm;
	private String billYear;
	private double sdUndergrdSrcgAmt;

	/**
	 * @return Returns the acctCt.
	 */
	public long getAcctCt() {
		return acctCt;
	}
	/**
	 * @param acctCt The acctCt to set.
	 */
	public void setAcctCt(long acctCt) {
		this.acctCt = acctCt;
	}
	/**
	 * @return Returns the agencyID.
	 */
	public String getAgencyID() {
		return agencyID;
	}
	/**
	 * @param agencyID The agencyID to set.
	 */
	public void setAgencyID(String agencyID) {
		this.agencyID = agencyID;
	}
	/**
	 * @return Returns the attAmt.
	 */
	public double getAttAmt() {
		return attAmt;
	}
	/**
	 * @param attAmt The attAmt to set.
	 */
	public void setAttAmt(double attAmt) {
		this.attAmt = attAmt;
	}
	/**
	 * @return Returns the billMm.
	 */
	public String getBillMm() {
		return billMm;
	}
	/**
	 * @param billMm The billMm to set.
	 */
	public void setBillMm(String billMm) {
		this.billMm = billMm;
	}
	/**
	 * @return Returns the billRnd.
	 */
	public String getBillRnd() {
		return billRnd;
	}
	/**
	 * @param billRnd The billRnd to set.
	 */
	public void setBillRnd(String billRnd) {
		this.billRnd = billRnd;
	}
	/**
	 * @return Returns the billYear.
	 */
	public String getBillYear() {
		return billYear;
	}
	/**
	 * @param billYear The billYear to set.
	 */
	public void setBillYear(String billYear) {
		this.billYear = billYear;
	}
	/**
	 * @return Returns the blgSrcgAmt.
	 */
	public double getBlgSrcgAmt() {
		return blgSrcgAmt;
	}
	/**
	 * @param blgSrcgAmt The blgSrcgAmt to set.
	 */
	public void setBlgSrcgAmt(double blgSrcgAmt) {
		this.blgSrcgAmt = blgSrcgAmt;
	}
	/**
	 * @return Returns the bocAmt.
	 */
	public double getBocAmt() {
		return bocAmt;
	}
	/**
	 * @param bocAmt The bocAmt to set.
	 */
	public void setBocAmt(double bocAmt) {
		this.bocAmt = bocAmt;
	}
	/**
	 * @return Returns the chcfaSrcgAmt.
	 */
	public double getChcfaSrcgAmt() {
		return chcfaSrcgAmt;
	}
	/**
	 * @param chcfaSrcgAmt The chcfaSrcgAmt to set.
	 */
	public void setChcfaSrcgAmt(double chcfaSrcgAmt) {
		this.chcfaSrcgAmt = chcfaSrcgAmt;
	}
	/**
	 * @return Returns the chcfbSrcgAmt.
	 */
	public double getChcfbSrcgAmt() {
		return chcfbSrcgAmt;
	}
	/**
	 * @param chcfbSrcgAmt The chcfbSrcgAmt to set.
	 */
	public void setChcfbSrcgAmt(double chcfbSrcgAmt) {
		this.chcfbSrcgAmt = chcfbSrcgAmt;
	}
	/**
	 * @return Returns the cityTaxAmt.
	 */
	public double getCityTaxAmt() {
		return cityTaxAmt;
	}
	/**
	 * @param cityTaxAmt The cityTaxAmt to set.
	 */
	public void setCityTaxAmt(double cityTaxAmt) {
		this.cityTaxAmt = cityTaxAmt;
	}
	/**
	 * @return Returns the cpucSrcgAmt.
	 */
	public double getCpucSrcgAmt() {
		return cpucSrcgAmt;
	}
	/**
	 * @param cpucSrcgAmt The cpucSrcgAmt to set.
	 */
	public void setCpucSrcgAmt(double cpucSrcgAmt) {
		this.cpucSrcgAmt = cpucSrcgAmt;
	}
	/**
	 * @return Returns the ctfSrcgAmt.
	 */
	public double getCtfSrcgAmt() {
		return ctfSrcgAmt;
	}
	/**
	 * @param ctfSrcgAmt The ctfSrcgAmt to set.
	 */
	public void setCtfSrcgAmt(double ctfSrcgAmt) {
		this.ctfSrcgAmt = ctfSrcgAmt;
	}
	/**
	 * @return Returns the currBalDueAmt.
	 */
	public double getCurrBalDueAmt() {
		return currBalDueAmt;
	}
	/**
	 * @param currBalDueAmt The currBalDueAmt to set.
	 */
	public void setCurrBalDueAmt(double currBalDueAmt) {
		this.currBalDueAmt = currBalDueAmt;
	}
	/**
	 * @return Returns the currMnthChrgAmt.
	 */
	public double getCurrMnthChrgAmt() {
		return currMnthChrgAmt;
	}
	/**
	 * @param currMnthChrgAmt The currMnthChrgAmt to set.
	 */
	public void setCurrMnthChrgAmt(double currMnthChrgAmt) {
		this.currMnthChrgAmt = currMnthChrgAmt;
	}
	/**
	 * @return Returns the cycle.
	 */
	public int getCycle() {
		return cycle;
	}
	/**
	 * @param cycle The cycle to set.
	 */
	public void setCycle(int cycle) {
		this.cycle = cycle;
	}
	/**
	 * @return Returns the division.
	 */
	public String getDivision() {
		return division;
	}
	/**
	 * @param division The division to set.
	 */
	public void setDivision(String division) {
		this.division = division;
	}
	/**
	 * @return Returns the euclChrgAmt.
	 */
	public double getEuclChrgAmt() {
		return euclChrgAmt;
	}
	/**
	 * @param euclChrgAmt The euclChrgAmt to set.
	 */
	public void setEuclChrgAmt(double euclChrgAmt) {
		this.euclChrgAmt = euclChrgAmt;
	}
	/**
	 * @return Returns the fedTaxAmt.
	 */
	public double getFedTaxAmt() {
		return fedTaxAmt;
	}
	/**
	 * @param fedTaxAmt The fedTaxAmt to set.
	 */
	public void setFedTaxAmt(double fedTaxAmt) {
		this.fedTaxAmt = fedTaxAmt;
	}
	/**
	 * @return Returns the hcapSrcgAmt.
	 */
	public double getHcapSrcgAmt() {
		return hcapSrcgAmt;
	}
	/**
	 * @param hcapSrcgAmt The hcapSrcgAmt to set.
	 */
	public void setHcapSrcgAmt(double hcapSrcgAmt) {
		this.hcapSrcgAmt = hcapSrcgAmt;
	}
	/**
	 * @return Returns the iecAmt.
	 */
	public double getIecAmt() {
		return iecAmt;
	}
	/**
	 * @param iecAmt The iecAmt to set.
	 */
	public void setIecAmt(double iecAmt) {
		this.iecAmt = iecAmt;
	}
	/**
	 * @return Returns the lflnSrcgAmt.
	 */
	public double getLflnSrcgAmt() {
		return lflnSrcgAmt;
	}
	/**
	 * @param lflnSrcgAmt The lflnSrcgAmt to set.
	 */
	public void setLflnSrcgAmt(double lflnSrcgAmt) {
		this.lflnSrcgAmt = lflnSrcgAmt;
	}
	/**
	 * @return Returns the occAmt.
	 */
	public double getOccAmt() {
		return occAmt;
	}
	/**
	 * @param occAmt The occAmt to set.
	 */
	public void setOccAmt(double occAmt) {
		this.occAmt = occAmt;
	}
	/**
	 * @return Returns the runDate.
	 */
	public Date getRunDate() {
		return runDate;
	}
	/**
	 * @param runDate The runDate to set.
	 */
	public void setRunDate(Date runDate) {
		this.runDate = runDate;
	}
	/**
	 * @return Returns the srvUsffAmt.
	 */
	public double getSrvUsffAmt() {
		return srvUsffAmt;
	}
	/**
	 * @param srvUsffAmt The srvUsffAmt to set.
	 */
	public void setSrvUsffAmt(double srvUsffAmt) {
		this.srvUsffAmt = srvUsffAmt;
	}
	/**
	 * @return Returns the stateTaxAmt.
	 */
	public double getStateTaxAmt() {
		return stateTaxAmt;
	}
	/**
	 * @param stateTaxAmt The stateTaxAmt to set.
	 */
	public void setStateTaxAmt(double stateTaxAmt) {
		this.stateTaxAmt = stateTaxAmt;
	}
	/**
	 * @return Returns the tollAmt.
	 */
	public double getTollAmt() {
		return tollAmt;
	}
	/**
	 * @param tollAmt The tollAmt to set.
	 */
	public void setTollAmt(double tollAmt) {
		this.tollAmt = tollAmt;
	}
	/**
	 * Method getSdUndergrdSrcgAmt.
	 * @return sandiago underground surcharge amount
	 */
	public double getSdUndergrdSrcgAmt()
		{
			return sdUndergrdSrcgAmt;
		}
	/**
	 * Method setSdUndergrdSrcgAmt. The sandiago underground surcharge amount to set.
	 * @param sdUndergrdSrcgAmt double
	 */
	public void setSdUndergrdSrcgAmt(double sdUndergrdSrcgAmt)
		{
			this.sdUndergrdSrcgAmt = sdUndergrdSrcgAmt;
		}
}


