/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.admin.adhoc.rpt;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.att.bac.rabc.ConnectionManager;
import com.att.bac.rabc.PickList;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;

/**
 * Module description: 
 * 
 * This is an Action class for Alert Groups pop up feature
 *
 * @author Anup Thomas - AT1862
 */
public class AlertGroupsAction extends DispatchAction{
	private static final Logger logger = Logger.getLogger(AlertGroupsAction.class);
	AlertGroupsService  alertGroupsService = AlertGroupsService.getAlertGroupsService();
	
	/**
	 * Default dispatch action method to call loadAlertGroups method.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @see org.apache.struts.actions.DispatchAction#unspecified(org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public ActionForward unspecified(ActionMapping mapping,ActionForm form,HttpServletRequest request, HttpServletResponse response)  {
		return loadAlertGroups(mapping,form,request,response);
	}
	
	/**
	 * Dispatch action method to handle the request to load the alert groups in pop-up window.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward loadAlertGroups(ActionMapping mapping,ActionForm form,HttpServletRequest request, HttpServletResponse response)  {
		ActionForward forward = null ;
		AlertGroupsForm alertGroupsForm = (AlertGroupsForm) form;
		Connection connection = null ;
		List failureList = new ArrayList();
		List args = new ArrayList();
		
		try {
			connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
			List alertGroupList = new ArrayList();
			alertGroupList = alertGroupsService.getAlertGroupList(connection,failureList,args);
			if (!alertGroupList.isEmpty()){
				int alertGroupListSize = alertGroupList.size();
				for (int i=0;i<alertGroupListSize;i++){
					PickList alertGroup = (PickList)alertGroupList.get(i);
					alertGroupsForm.addAlertGroup(alertGroup);
				}	
			}
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch(Exception e){
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
	        failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
	        forward = mapping.findForward("error");
		} finally {
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		
		if (!failureList.isEmpty()){
			request.setAttribute("failures",failureList);
			forward = mapping.findForward("error");
		}else {
			forward = mapping.findForward("AlertGroups");
		}
		return forward ;
	}
}
