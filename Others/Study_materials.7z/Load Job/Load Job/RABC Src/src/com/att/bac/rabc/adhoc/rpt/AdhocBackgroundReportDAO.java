package com.att.bac.rabc.adhoc.rpt;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import org.apache.log4j.Logger;

import com.att.bac.rabc.ConnectionManager;
import com.att.bac.rabc.PickList;
import com.att.bac.rabc.RABCConstantsLists;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;
import com.att.carat.util.JDBCUtil;

public class AdhocBackgroundReportDAO {
	
	private static final Logger logger = Logger.getLogger(AdhocBackgroundReportDAO.class);
	private String selectSql = "SELECT * FROM ( "+
								" select rownum rn, T.BKGRND_RPT_NBR, T.ID, T.NAME, T.SUB_RPT_TM, T.USER_ID, T.STATUS_CD from (" +
								" SELECT DISTINCT BKGRND_RPT_NBR, RPT.PRESN_ID as ID, presn.PRESN_ID_DESC as  NAME,  SUB_RPT_TM, USER_ID, STATUS_CD ";
	
	public List<PickList> getReportName_List(Connection connection, List failureList, String tableNode) {
		
		String sql = " SELECT DISTINCT RPT.PRESN_ID as ID, presn.PRESN_ID_DESC as  NAME "+
					 " FROM RABC_BKGRND_RPT RPT, RABC_PRESN_ID presn " +
					 " where RPT.PRESN_ID = presn.PRESN_ID and RPT.STATUS_CD NOT IN ('Deleted','Aged')";
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		ArrayList<PickList> reportName_List  	 = new ArrayList<PickList>();
		 try {
			ps = connection.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()){
				reportName_List.add(new PickList(rs.getString("ID"),rs.getString("NAME")));
			}
		 } catch (SQLException sx) {
				logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sql}) + " Exception details: " + sx.getMessage(), sx);
				failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sql}), sx));
		} finally{
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(ps, failureList, logger);
		}
		return reportName_List;
	}
public String getReportName(Connection connection, List failureList, String tableNode, int id) {
		
		String sql = " SELECT DISTINCT RPT.PRESN_ID as ID, presn.PRESN_ID_DESC as  NAME "+
					 " FROM RABC_BKGRND_RPT RPT, RABC_PRESN_ID presn " +
					 " where RPT.PRESN_ID = presn.PRESN_ID and RPT.STATUS_CD NOT IN ('Deleted','Aged')"
					 +" and presn.PRESN_ID= "+id;
		
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		String  reportName="";
		 try {
			ps = connection.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()){
				reportName=rs.getString("NAME");
			}
		 } catch (SQLException sx) {
				logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sql}) + " Exception details: " + sx.getMessage(), sx);
				failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sql}), sx));
		} finally{
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(ps, failureList, logger);
		}
		return reportName;
	}

	public List<PickList> getUsers_list(Connection connection, List failureList, String tableNode) {
		String sql = " SELECT DISTINCT RPT.USER_ID as USER_ID "+
					 " FROM RABC_BKGRND_RPT RPT "+
					 " where RPT.STATUS_CD NOT IN ('Deleted','Aged')";
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		ArrayList<PickList> users_list  	 = new ArrayList<PickList>();
		 try {
			ps = connection.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()){
				users_list.add(new PickList(rs.getString("USER_ID"), rs.getString("USER_ID"))); 
			}
		 } catch (SQLException sx) {
				logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sql}) + " Exception details: " + sx.getMessage(), sx);
				failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sql}), sx));
		} finally{
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(ps, failureList, logger);
		}
		return users_list;
	}	


	public List<PickList> getStatuses_list(Connection connection, List failureList, String tableNode) {
		String sql = " SELECT DISTINCT RPT.STATUS_CD as STATUS_CD"+
					 " FROM RABC_BKGRND_RPT RPT " +
					 " where RPT.STATUS_CD NOT IN ('Deleted','Aged')";
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		ArrayList<PickList> statuses_list  	 = new ArrayList<PickList>();
		
		 try {
			ps = connection.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()){
				statuses_list.add(new PickList(rs.getString("STATUS_CD"), rs.getString("STATUS_CD")));
			}
		 } catch (SQLException sx) {
				logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sql}) + " Exception details: " + sx.getMessage(), sx);
				failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sql}), sx));
		} finally{
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(ps, failureList, logger);
		}
		return statuses_list;
	}	
	

	public List<AdhocBackgroundReport> getAdhocBackgroundReportsList(Connection connection, List failureList, AdhocBackgroundReportForm adhocBackgroundReportForm, String tableNode,  int id) {
		String whereClause = buildWhereClause(adhocBackgroundReportForm, id);

		//String whereClause = buildWhereClause(adhocBackgroundReportForm);
		String sql="";
		if(id!=0)
		sql = selectSql + " FROM RABC_BKGRND_RPT RPT, RABC_PRESN_ID presn " +
		//						 " where RPT.PRESN_ID = presn.PRESN_ID and presn.presn_id=" +id+ " and RPT.STATUS_CD NOT IN ('Deleted','Aged') " + whereClause;
		 " where RPT.PRESN_ID = presn.PRESN_ID and presn.presn_id=" +id+ " and RPT.STATUS_CD NOT IN ('Deleted','Aged') " + whereClause;

		else
			 sql = selectSql + " FROM RABC_BKGRND_RPT RPT, RABC_PRESN_ID presn " +
			 " where RPT.PRESN_ID = presn.PRESN_ID  and RPT.STATUS_CD NOT IN ('Deleted','Aged') " + whereClause;

		//order by Clause
		String sortItem = adhocBackgroundReportForm.getSortItem();
		String sortOrder = adhocBackgroundReportForm.getSortOrder();
		if ((sortItem != null) && !("".equals(sortItem))) {
			sql += " order by " + sortItem + " " + sortOrder;
		}
		
		// the start and end counter will vary depending on which page is selected.
		int startCounter=0;
    	int endCounter=0;
    	int page = adhocBackgroundReportForm.getPage();
    	int pageSize = adhocBackgroundReportForm.getPageSize();
    	
		if (page>0)
		{
	    	startCounter = (page - 1) * pageSize + 1;
			endCounter = page * pageSize;
		}	
		
		sql += " ) T ) t  where t.rn between " + startCounter + " and " + endCounter;
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		ArrayList<AdhocBackgroundReport> adhocBackgroundReportList  	 = new ArrayList<AdhocBackgroundReport>();
		
		 try {
			ps = connection.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()){
				AdhocBackgroundReport adhocBackgroundReport = new AdhocBackgroundReport();
				adhocBackgroundReport.setBckGrndRptNum(rs.getInt("BKGRND_RPT_NBR"));
				adhocBackgroundReport.setPresnId(rs.getInt("ID"));
				adhocBackgroundReport.setReportName(rs.getString("NAME"));
				adhocBackgroundReport.setRptTimeSub(rs.getDate("SUB_RPT_TM"));
				adhocBackgroundReport.setUserId(rs.getString("USER_ID"));
				adhocBackgroundReport.setStatus_cd(rs.getString("STATUS_CD"));
				adhocBackgroundReportForm.addAdhocBackgroundReportDetail(adhocBackgroundReport);
			}
		 } catch (SQLException sx) {
				logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sql}) + " Exception details: " + sx.getMessage(), sx);
				failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sql}), sx));
		} finally{
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(ps, failureList, logger);
		}
		return adhocBackgroundReportList;
	}
	
	//public String buildWhereClause(AdhocBackgroundReportForm adhocBackgroundReportForm) {
		public String buildWhereClause(AdhocBackgroundReportForm adhocBackgroundReportForm, int id) {

		String whereClause="";
		if (adhocBackgroundReportForm.getReportName()!=null && !adhocBackgroundReportForm.getReportName().equals("")) {
		//	whereClause = whereClause + " AND RPT.PRESN_ID = "+adhocBackgroundReportForm.getReportName();
			whereClause = whereClause + " AND RPT.PRESN_ID = "+ id;//adhocBackgroundReportForm.getReportName();

		}

		if (adhocBackgroundReportForm.getStatus_cd()!=null && adhocBackgroundReportForm.getStatus_cd().length>0){
			whereClause = whereClause + " AND RPT.STATUS_CD IN ("+toSQLList(adhocBackgroundReportForm.getStatus_cd(), false)+")";
		}
		
		if (adhocBackgroundReportForm.getUserName()!=null && adhocBackgroundReportForm.getUserName().length>0){
			whereClause = whereClause + " AND RPT.USER_ID IN ("+toSQLList(adhocBackgroundReportForm.getUserName(), false)+")";
		}

		if (adhocBackgroundReportForm.getFileStartDate()!=null && !adhocBackgroundReportForm.getFileStartDate().equals("")) {		
			whereClause = whereClause + " AND RPT.sub_rpt_tm >= to_date('"+adhocBackgroundReportForm.getFileStartDate()+"','mm/dd/yyyy')";
		}
		
		if (adhocBackgroundReportForm.getFileEndDate()!=null && !adhocBackgroundReportForm.getFileEndDate().equals("")) {		
			whereClause = whereClause + " AND RPT.sub_rpt_tm <= to_date('"+adhocBackgroundReportForm.getFileEndDate()+"','mm/dd/yyyy')";
		}
		
		return whereClause;
		
	}

	 public String toSQLList(Object[] objects, boolean force_upper) {
	     String output = "";
	     for (int i = 0; i < objects.length; i++) {
	         output += (force_upper ? "upper('" : "'") + objects[i] + (force_upper ? "')," : "',");
	     }
	     if (output.length() > 0)
	         output = output.substring(0, output.length() - 1);

	     return output;
	 }	

	public int deleteBkGrndReport(Connection connection, List failureList, String tableNode, String reportNum) {
		String sql = " UPDATE RABC_BKGRND_RPT " +
					 " SET STATUS_CD = 'Deleted' " +
					 " where BKGRND_RPT_NBR  in ("+reportNum+")";
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		int results=0;
		 try {
			ps = connection.prepareStatement(sql);
			results = ps.executeUpdate();
            connection.commit();
	            
		 } catch (SQLException sx) {
				logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sql}) + " Exception details: " + sx.getMessage(), sx);
				failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sql}), sx));
		} finally{
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(ps, failureList, logger);
		}
		
		return results;
	}		
	

	
    public String getReportFile(Connection c, List failureList, String tableNode, int reportID) {
        ResultSet rs = null;
        PreparedStatement ps = null;
        String fileName = "";
        String sql = " select FILE_NAME, start_date FROM RABC_BKGRND_RPT where BKGRND_RPT_NBR = ? ";
        try {
            ps = c.prepareStatement(sql);
            ps.setInt(1, reportID);
            rs = ps.executeQuery();
            if (rs.next()) {
            	fileName =  rs.getString("FILE_NAME");
            }
	   	 } catch (SQLException sx) {
				logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sql}) + " Exception details: " + sx.getMessage(), sx);
				failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sql}), sx));
		} finally{
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(ps, failureList, logger);
	    }
		return fileName;
    }
    
	//public int getTotalAdhocBackgroundReports(Connection connection, List failureList, AdhocBackgroundReportForm adhocBackgroundReportForm, String tableNode) {
	public int getTotalAdhocBackgroundReports(Connection connection, List failureList, AdhocBackgroundReportForm adhocBackgroundReportForm, String tableNode, int id) {

		
		String whereClause = buildWhereClause(adhocBackgroundReportForm, id);
		String sql = " SELECT count(*)"+
		 " FROM RABC_BKGRND_RPT RPT"+
		 " where STATUS_CD NOT IN ('Deleted','Aged') " + whereClause;
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		int totalCount=0;
		
		 try {
			ps = connection.prepareStatement(sql);
			rs = ps.executeQuery();
			if (rs.next()){
				totalCount = rs.getInt(1);
			}
		 } catch (SQLException sx) {
				logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sql}) + " Exception details: " + sx.getMessage(), sx);
				failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sql}), sx));
		} finally{
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(ps, failureList, logger);
		}
		return totalCount;
	}
    
	protected int getDefaultLineCount(Connection connection, List failureList, String tableNode, String userId) {
		int defaultLineCount = 0;
		String selectSQL = "SELECT LINE_CT FROM RABC_USER_DEFAULT_RPT_LINE WHERE USER_ID = ''{0}''";
		List args = new ArrayList();
		args.add(userId);
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		try{
			MessageFormat mf = new MessageFormat(selectSQL);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			if (rs != null && rs.next()) {
				defaultLineCount = rs.getInt(1);
			} else {
				defaultLineCount = RABCConstantsLists.getRABCConstantsLists().getPageSize();
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		
		return defaultLineCount;
	}	
	
	public String getFileName(AdhocRptForm f, AdhocRptDataTO adhocRptDataTO, String userid, String region, String tableNode) throws RABCException {
		    String reportName = null;
		    String fileName =null;
		    SimpleDateFormat sdft = new SimpleDateFormat("MMddyyyyHHmmss");
		    
		   /* if ((region!=null) && !(region.equals(""))&&(tableNode!=null) && !(tableNode.equals(""))) {
		        reportName = AdhocRptDAO.getPresnDesc(f, tableNode);
		    } */
		
		    if (reportName!=null && !reportName.equals("")) {
		    	fileName = reportName+"_Control_data_history_report_" + userid + "_" + sdft.format(new java.util.Date()) + ".xls";
		    }else {
		    	fileName = "Control_data_history_report_" + userid + "_" + sdft.format(new java.util.Date()) + ".xls";
		    }    
		    return fileName;
	}

    
    /**
     * This method is used to get the next value of dash ID  
     * @param connection used to connect to database
     * @return dash ID value
     */
    public int getId(AdhocRptDataTO adhocRptDataTO) throws RABCException {
        String sql = "select RABC_BKGRND_RPT_MSG_NO.NEXTVAL from DUAL";
        String ps = null;
        Connection conn = null;
        List<String> args = new ArrayList();
        Statement stmt = null;
		ResultSet rs = null;
		int rptNum = 0;
        try {
			MessageFormat mf = new MessageFormat(sql);
            conn = ConnectionManager.getConnection(adhocRptDataTO.getRegion());
			ps = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = conn.createStatement();
			rs = stmt.executeQuery(ps);
            if (rs.next()) {
                rptNum =  rs.getInt(1);
            } else {
                throw new IllegalStateException("Query returned no results: " + sql);
            }
        } catch (SQLException sx) {
            throw new RABCException("SQL Exception", sx);
        } catch (NamingException ne) {
            throw new RABCException("Naming Exception", ne);
        } finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closeStatement(stmt);
	        JDBCUtil.closeConnection(conn);			
		}
		return rptNum;
    }	
    
    public boolean checkForDuplicateBkgroundInfo(AdhocRptDataTO adhocRptDataTO, String userid) throws RABCException {
    	Connection  conn = null;
    	boolean duplicateCriteria = false;
    	 try
		{
			conn = ConnectionManager.getConnection(adhocRptDataTO.getRegion());
	    	int noOfRows = queryForDuplicateCriteria(adhocRptDataTO,userid,conn);
	    	if (noOfRows > 0) {
	    		duplicateCriteria = true;
	    	}
			
        } catch (SQLException sqle) {
            throw new RABCException("Error in saveBkgrndRptKeys", sqle);
        } catch (NamingException ne) {
            throw new RABCException("NamingException ", ne);
        } finally {
        	JDBCUtil.closeConnection(conn);
        }
        return duplicateCriteria;
    }
    
    public int queryForDuplicateCriteria(AdhocRptDataTO adhocRptDataTO, String userid, Connection conn) throws RABCException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        int i=0;
        String selectBkgrndRpt = "SELECT count(*) as count from RABC_BKGRND_RPT " +
        						 "where PRESN_ID = ? " +
        		                 "AND START_DATE = ? " +
        		                 "AND END_DATE = ? " + 
        		                 "AND nvl(DIVISION_CD, '0') = ? " +
        		   				 "AND nvl(RPT_TIME_IND, '0') = ? " +
        		   				 "AND RPT_MONTH = ? " +
        		   				 "AND RPT_YEAR = ? " +
        		   				 "AND nvl(CYCLE_BILLED, '0') = ? " + 
        		   				 "AND USER_ID = ? " +
        		   				 "AND STATUS_CD in ('Submitted','Processing','Completed','Notify')";
        		    
        try {
            ps = conn.prepareStatement(selectBkgrndRpt);
            ps.setInt(1, adhocRptDataTO.getPresnId()); 
           	String month = adhocRptDataTO.getStartDate().trim().substring(0, 2);
			String day = adhocRptDataTO.getStartDate().trim().substring(3, 5);
			String year = adhocRptDataTO.getStartDate().trim().substring(6);			
            ps.setDate(2, Date.valueOf(year + "-" + month + "-" + day));
            
        	month = adhocRptDataTO.getEndDate().trim().substring(0, 2);
			day = adhocRptDataTO.getEndDate().trim().substring(3, 5);
			year = adhocRptDataTO.getEndDate().trim().substring(6);            
            ps.setDate(3, Date.valueOf(year + "-" + month + "-" + day));
          
            if (adhocRptDataTO.getDivisionName()==null || adhocRptDataTO.getDivisionName().equals("")){
            	ps.setString(4, "0");
            } else {
            	ps.setString(4, adhocRptDataTO.getDivisionName());
            }
            String timeInd;
            if (adhocRptDataTO.getAlertTimeInd().equals("")){
            	timeInd = "0";  
            }else{
            	timeInd = adhocRptDataTO.getAlertTimeInd();            	 
            }
            ps.setString(5, timeInd);            
            ps.setInt(6, adhocRptDataTO.getMonthSelect()); 
            ps.setInt(7, adhocRptDataTO.getYearSelect());
            
            if (adhocRptDataTO.getBillRoundCheck()!=null && adhocRptDataTO.getBillRoundCheck().equalsIgnoreCase("on")) {
            	ps.setString(8, "Y"); //cycle billed
            }	else {	
            	ps.setString(8, "0"); //cycle billed
            }
            ps.setString(9, userid);  
            rs = ps.executeQuery();
            if (rs != null && rs.next()) {
				i = rs.getInt(1);
			} 
         
        } catch (SQLException sqle) {
            throw new RABCException("Error in saveBkgrndRpt", sqle);
        } finally {
            JDBCUtil.closeResultSet(rs);
            JDBCUtil.closePreparedStatement(ps);
        }
        return i;
    }    
    public void saveBackgroundInfo(AdhocRptDataTO adhocRptDataTO, int id, String notes, String userid, String fileName, ArrayList<String> previousSQLList) throws RABCException {
    	Connection  conn = null;
    	 try
		{
			conn = ConnectionManager.getConnection(adhocRptDataTO.getRegion());
	    	int i = saveBkgrndRpt(adhocRptDataTO, id, notes, userid, fileName, conn);
	    	if (i>0) {
		    	saveBkgrndRptKeys(adhocRptDataTO, id, conn);
		    	saveBackgroundSql(adhocRptDataTO, id, conn, previousSQLList);
	    	}
	    	conn.commit();
			
        } catch (SQLException sqle) {
            throw new RABCException("Error in saveBkgrndRptKeys", sqle);
        } catch (NamingException ne) {
            throw new RABCException("NamingException ", ne);
        } finally {
        	JDBCUtil.closeConnection(conn);
        }
    }

    
    public void saveBackgroundSql(AdhocRptDataTO adhocRptDataTO, int id, Connection conn, ArrayList<String> prevSQLList) throws RABCException {
        PreparedStatement ps = null;
        ResultSet rs = null;
  
        String insertBkgrndRpt = "INSERT INTO RABC_BKGRND_RPT_SQL ( BKGRND_RPT_NBR, SECTION_NBR, seq_nbr, GENERATED_SQL, PREV_GENERATED_SQL) " + 
        		   				 " VALUES ( ?, ?, ?, ?, ?)";
        		    
        try {
            ps = conn.prepareStatement(insertBkgrndRpt);
            for (int i = 0; i < adhocRptDataTO.getDistExecPresnSeqNumList().size(); i++) {
                String sql = (String) adhocRptDataTO.getGeneratedSQL().get(i);
                String pSql = prevSQLList.get(i);

                List<SqlPart> parts = sliceSql(sql, pSql);

                int seq = 1;
                for (SqlPart p : parts) {
//                    ps = conn.prepareStatement(insertBkgrndRpt);
                    ps.setInt(1, id);
                    ps.setInt(2, (Integer) adhocRptDataTO.getDistExecPresnSeqNumList().get(i));
                    ps.setInt(3, seq++);
                    ps.setString(4, p.sql);
                    ps.setString(5, p.previousSql);
                    //ps.executeUpdate();
                    //ps.close();
                    ps.addBatch();
                }
                ps.executeBatch();

            }
        } catch (SQLException sqle) {
            throw new RABCException("Error in saveBkgrndRptKeys", sqle);
        }catch (Exception ex) {
        	throw new RABCException("Exception in saveBkgrndRptKeys", ex);
        } finally {
            JDBCUtil.closeResultSet(rs);
            JDBCUtil.closePreparedStatement(ps);
        }
    }
    
    
    /**
     * Break the SQL statements into 4000 byte parts
     * 
     * @param sql
     * @param pSql
     * @return
     */
    private List<SqlPart> sliceSql(String sql, String pSql) {
        List<SqlPart> results = new ArrayList<SqlPart>();

        while ((sql.length() > 4000) || (pSql.length() > 4000)) {
            SqlPart p = new SqlPart();
            p.sql = sql.substring(0, Math.min(4000, sql.length()));
            p.previousSql = pSql.substring(0, Math.min(4000, pSql.length()));
            results.add(p);

            sql = sql.substring(Math.min(4000, sql.length()));
            pSql = pSql.substring(Math.min(4000, pSql.length()));
        }

        SqlPart p = new SqlPart();
        p.sql = sql;
        p.previousSql = pSql;
        results.add(p);

        return results;
    }
    
    
    public void saveBkgrndRptKeys(AdhocRptDataTO adhocRptDataTO, int id, Connection conn) throws RABCException {
        PreparedStatement ps = null;
        ResultSet rs = null;
  
        String insertBkgrndRpt = "INSERT INTO RABC_BKGRND_RPT_KEYS ( BKGRND_RPT_NBR, KEY_NBR, KEY_HEADER_TXT, KEY_TXT) " + 
        		   				 " VALUES ( ?, ?, ?, ?)";
        		    
        try {
            ps = conn.prepareStatement(insertBkgrndRpt);          

            String key1 = "";
            if (adhocRptDataTO.getKeysRow1ColumnsList().size() > 0 && adhocRptDataTO.getDivNameKeyLvl() != 1) {
            	key1 = adhocRptDataTO.getSortKeyList();
            }
            
            if (adhocRptDataTO.getDivNameKeyLvl() == 1 || adhocRptDataTO.getDivNameKeyLvl() == 2) {
            	key1 = adhocRptDataTO.getDivisionName();
            }
            if (!key1.equals("")) {
	            ps.setInt(1, id);
	            ps.setInt(2, 1);
	            ps.setString(3, (String)adhocRptDataTO.getColumnsHeadersList().get(0));
	            ps.setString(4, key1);
	            ps.executeUpdate();
            }
            //since there will only be 2 keys displayed on the selection page, we will only set the first 2 keys
            String key2="";
            if (adhocRptDataTO.getDataKeyLvl() > 1 && adhocRptDataTO.getDivNameKeyLvl() != 2) {
            	key2 = adhocRptDataTO.getSortKeyList2();
            }
            if (!key2.equals("")) {
	            ps.setInt(1, id);
	            ps.setInt(2, 2); //set the key nbr
	            ps.setString(3, (String)adhocRptDataTO.getColumnsHeadersList().get(1));
	            ps.setString(4, key2);
	            ps.executeUpdate();
            }
        } catch (SQLException sqle) {
            throw new RABCException("Error in saveBkgrndRptKeys", sqle);
        } finally {
            JDBCUtil.closeResultSet(rs);
            JDBCUtil.closePreparedStatement(ps);
        }
    }    
       
    public int saveBkgrndRpt(AdhocRptDataTO adhocRptDataTO, int id, String notes, String userid, String fileName, Connection conn) throws RABCException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        int i=0;
        String insertBkgrndRpt = "INSERT INTO RABC_BKGRND_RPT ( PRESN_ID, BKGRND_RPT_NBR, SUB_RPT_TM, " + 
        		   				 " PRESN_TREND_TIME, START_DATE, END_DATE, " + 
        		   				 " DIVISION_CD, KEY_LVL_NBR, RPT_TIME_IND, " +
        		   				 " RPT_TIME, RPT_MONTH, RPT_YEAR, CYCLE_BILLED, " + 
        		   				 " USER_ID, STATUS_CD, " + 
        		   				 " NOTES_TXT, FILE_NAME )"+
        		   				 " VALUES ( ?, ?, SYSDATE, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        		    
        try {
            ps = conn.prepareStatement(insertBkgrndRpt);
            ps.setInt(1, adhocRptDataTO.getPresnId());
            ps.setInt(2, id);
            ps.setString(3, adhocRptDataTO.getPresnTrendTime());
            
        	String month = adhocRptDataTO.getStartDate().trim().substring(0, 2);
			String day = adhocRptDataTO.getStartDate().trim().substring(3, 5);
			String year = adhocRptDataTO.getStartDate().trim().substring(6);          
			
            ps.setDate(4, Date.valueOf(year + "-" + month + "-" + day));
        	month = adhocRptDataTO.getEndDate().trim().substring(0, 2);
			day = adhocRptDataTO.getEndDate().trim().substring(3, 5);
			year = adhocRptDataTO.getEndDate().trim().substring(6);            
            ps.setDate(5, Date.valueOf(year + "-" + month + "-" + day));
            
            ps.setString(6, adhocRptDataTO.getDivisionName());
            ps.setInt(7, adhocRptDataTO.getDataKeyLvl()); //check this
            ps.setString(8, adhocRptDataTO.getAlertTimeInd()); //check
            ps.setInt(9, adhocRptDataTO.getAlertTimeValue());
            ps.setInt(10, adhocRptDataTO.getMonthSelect()); 
            ps.setInt(11, adhocRptDataTO.getYearSelect());
            
            if (adhocRptDataTO.getBillRoundCheck()!=null && adhocRptDataTO.getBillRoundCheck().equalsIgnoreCase("on")) {
            	ps.setString(12, "Y"); //cycle billed
            }	else {	
            	ps.setString(12, ""); //cycle billed
            }

            ps.setString(13, userid);
            
            ps.setString(14, "Submitted");//status
            if (notes==null) {
            	notes="";
            }
            ps.setString(15, notes);
            ps.setString(16, fileName); //filename

            i = ps.executeUpdate();
        } catch (SQLException sqle) {
            throw new RABCException("Error in saveBkgrndRpt", sqle);
        } finally {
            JDBCUtil.closeResultSet(rs);
            JDBCUtil.closePreparedStatement(ps);
        }
        return i;
    }    
    
}
