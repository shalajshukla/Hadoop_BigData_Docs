/* Project: BAC_RABC_TOMCAT
 * File: NoCacheFilter.java
 * Package: com.sbc.bac.rabc
 * Created on Feb 20, 2006 by John Scola
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

public class NoCacheFilter extends Object implements Filter {
    public static Logger  logger = Logger.getLogger(NoCacheFilter.class);
    
    public void destroy() {
    }
    
    public void init(FilterConfig config) throws ServletException {
    }
    
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        if(logger.isDebugEnabled()){
            logger.debug("Servicing: "+((HttpServletRequest)request).getRequestURI());
        }
        
        if(((HttpServletRequest)request).getRequestURI().endsWith(".do")){
	        HttpServletResponse httpresponse = (HttpServletResponse)response;
	        httpresponse.setHeader("Pragma","public");
	        httpresponse.setHeader("Cache-Control","max-age=0");
	        if(logger.isDebugEnabled()){
	            logger.debug("Not caching "+((HttpServletRequest)request).getRequestURI()+" ("+response.getContentType()+")");
	        }
        }
        
        chain.doFilter(request,response);
    }
}
