/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.dashboard;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.att.bac.rabc.ConnectionManager;
import com.att.bac.rabc.ProgressBar;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;

/**
 * This class represents the Action that to generate the AlertRuleRevenue Detail Page. 
 * 
 * @author Sandhya Chinala - SC3837
 */
public class AlertRuleRevenueAction {
	public static Logger  logger = Logger.getLogger(AlertDashboardAction.class);
	private AlertRuleRevenueService alertRuleRevenueService = AlertRuleRevenueService.getAlertRuleRevenueService();

	/**
	 * This is default action method.
	 * This method will return the revenueAlerts action.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward unspecified(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		AlertDashboardForm alertDashboardForm = (AlertDashboardForm) form ;
		return revenueAlerts(mapping,form,request,response);
	}
	
	/**
	 * This is an Action method that is responsible to generate the Alert Revenue Detail Page.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward revenueAlerts(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)  {
		AlertDashboardForm alertDashboardForm = (AlertDashboardForm) form ;
		List failureList = new ArrayList();
		Connection connection = null;
		int counter = 0;
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		List args = listArguments(alertDashboardForm);		
		try {
			/*
			 * Get the connection from the available pool
			 */
			connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
			progressBar.setProgressPercent(progressBar.getPercent() + 10);
			
			String cycle = "";
			List cycleCalendarList = alertRuleRevenueService.getCycleCalendarList(connection,failureList,args);
			if (cycleCalendarList != null && cycleCalendarList.size() != 0) {
				if (cycleCalendarList.size() == 1) {
					cycle = "Cycle : " + cycleCalendarList.get(0);
				} else {
					cycle = "Cycle : " + cycleCalendarList.get(0) + " - "
							+ cycleCalendarList.get(cycleCalendarList.size()-1);
				}
			}
			alertDashboardForm.setCycle(cycle);
			progressBar.setProgressPercent(progressBar.getPercent() + 10);
			
			/*
			 * Construct the Logic for table 1
			 */
			List alertRuleRevenueList = alertRuleRevenueService.getAlertRuleRevenueList(connection,failureList,args,progressBar, request.getSession().getAttribute("region").toString(),alertDashboardForm.getDateOption());
			alertDashboardForm.getAlertRuleRevenueList().clear();
			if (alertRuleRevenueList != null) {
				int alertRuleRevenueListSize = alertRuleRevenueList.size();
				for(counter=0; counter<alertRuleRevenueListSize; counter++) {
					alertDashboardForm.addAlertRuleRevenue((AlertRuleRevenue)alertRuleRevenueList.get(counter));
				}
			}
			/*
			 * Construct a Logic for table 2
			 */
			if (!request.getSession().getAttribute("region").toString().equals("C2")) {
				List alertRuleInvestigationsList = alertRuleRevenueService.getAlertRuleInvestigationsList(connection,failureList,args,progressBar);
				alertDashboardForm.getAlertRuleInvestigationsList().clear();
				if (alertRuleInvestigationsList != null) {
					int alertRuleInvestigationsListSize = alertRuleInvestigationsList.size();
					for(counter=0; counter<alertRuleInvestigationsListSize; counter++) {
						alertDashboardForm.addAlertRuleInvestigations((AlertRuleInvestigations)alertRuleInvestigationsList.get(counter));
					}
				}
			} else {
				progressBar.setProgressPercent(progressBar.getPercent() + 20);
			}
			/*
			 * Construct a Logic for table 3
			 */
			List alertRuleWarningsList = alertRuleRevenueService.getAlertRuleWarningsList(connection,failureList,args,progressBar,alertDashboardForm.getDateOption());
			alertDashboardForm.getAlertRuleWarningsList().clear();
			if (alertRuleWarningsList != null) {
				int alertRuleWarningsListSize = alertRuleWarningsList.size();
				for(counter=0; counter<alertRuleWarningsListSize; counter++) {
					alertDashboardForm.addAlertRuleWarnings((AlertRuleWarnings)alertRuleWarningsList.get(counter));
				}
			}
		} catch(SQLException sx) {
			   logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage());
			   failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage());
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage());
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		
		progressBar.setProgressPercent(10);
		if (!failureList.isEmpty()){
			request.setAttribute("failures", failureList);
			return mapping.findForward("error");
		} else {
			return mapping.findForward("AlertRuleRevenue");
		}
	}
	
	/**
	 * Private internal method to return the arguments list.
	 * 
	 * @param alertDashboardForm
	 * @return List
	 */
	private List listArguments(AlertDashboardForm alertDashboardForm) {
    	List args = new ArrayList();
    	
    	String startDate = alertDashboardForm.getStartDate();
		String endDate = alertDashboardForm.getEndDate();
		String alertDate = alertDashboardForm.getAlertDate(); //To be discussed
		String cntrlPt = alertDashboardForm.getCntrlPt();
		String alertRule = alertDashboardForm.getAlertRule();
		
		args.add(0, startDate);
		args.add(1, endDate);
		args.add(2, alertDate);
		args.add(3, cntrlPt);
		args.add(4, alertRule);
		
    	return args;
    }
}
