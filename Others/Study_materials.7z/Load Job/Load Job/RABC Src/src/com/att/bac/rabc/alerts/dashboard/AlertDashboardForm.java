/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/

package com.att.bac.rabc.alerts.dashboard;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;

import com.att.bac.rabc.SortedForm;

/**
 * This class represents the Form Bean for the Dashboard Component.
 * 
 * @author Sandhya Chinala - SC3837
 */
public class AlertDashboardForm extends SortedForm {
	private static final String CONTROLPOINTSUMMARY ="2";
	private static final String ALERTDASHBOARD = "3";
	private static final String SYSTEMMESSAGES ="6";
	
	private String dashboardType = CONTROLPOINTSUMMARY;
	private String reportType ;
	private String dateOption = "run";
	private String startDate;
	private String endDate;
	private String alertDate;
	private List alertDashboardList;
	private List alertRuleRevenueList;
	private int alertRuleRevenueListCount;
	private List alertRuleInvestigationsList;
	private int alertRuleInvestigationsListCount;
	private List alertRuleWarningsList;
	private int alertRuleWarningsListCount;
	private String cycle;
	private String process;
	private String cntrlPt;
	private String cntrlPtDesc;
	private String alertRule;
	private int countTier3;
	private int countTier2;
	private int countTier1;
	private int countNone;
	private int countWarningStatus;
	private int countPendingStatus;
	private int countClosedStatus;
	private int totalRecords;
	private String cameFromPage;
	private String fromStartDate;
	private String fromEndDate;
	private String displayHead;
	private String displayHeader;
	private String emailRecipients;
	private int pageshow;
	private String saveBackground="N";
	private String rmiError="N";
	
	/*
	 * Variables added for calendar page
	 */
	private String procDates;
	private String billRounds;
	private String holidayIndicators;
	private String loadedDataDates;
	
	private int totalWarnings;
	private int totalSysMsg;
	
	/**
	 * Default constructor which sets the default sort item, sort order, previous sort item, alertDashboardList,
	 * alertRuleInvestigationsList, alertRuleRevenueList and alertRuleWarningsList.
	 */
	public AlertDashboardForm() {
		this.setPreviousSortItem("severe_lvl_high_ct");
		this.setSortItem("severe_lvl_high_ct");
		this.setSortOrder("ASC");
		this.alertDashboardList = new ArrayList();
		this.alertRuleInvestigationsList = new ArrayList();
		this.alertRuleRevenueList = new ArrayList();
		this.alertRuleWarningsList = new ArrayList();
	}
	
	
	/**
	 * @return String loadedDataDates
	 */			
	public String getLoadedDataDates() {
		return loadedDataDates;
	}

	/**
	 * @param loadedDataDates String
	 */
	public void setLoadedDataDates(String loadedDataDates) {
		this.loadedDataDates = loadedDataDates;
	}



	/**
	 * @return Returns the dashboardType.
	 */
	public String getDashboardType() {
		return dashboardType;
	}
	/**
	 * @param dashboardType The dashboardType to set.
	 */
	public void setDashboardType(String dashboardType) {
		this.dashboardType = dashboardType;
	}
	/**
	 * @return Returns the dateOption.
	 */
	public String getDateOption() {
		return dateOption;
	}
	/**
	 * @param dateOption The dateOption to set.
	 */
	public void setDateOption(String dateOption) {
		this.dateOption = dateOption;
	}
	/**
	 * @return Returns the endDate.
	 */
	public String getEndDate() {
		return endDate;
	}
	/**
	 * @param endDate The endDate to set.
	 */
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	/**
	 * @return Returns the startdate.
	 */
	public String getStartDate() {
		return startDate;
	}
	/**
	 * @param startdate The startdate to set.
	 */
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	
	/**
	 * @return Returns the alertDate.
	 */
	public String getAlertDate() {
		return alertDate;
	}
	/**
	 * @param alertDate The alertDate to set.
	 */
	public void setAlertDate(String alertDate) {
		this.alertDate = alertDate;
	}
	/**
	 * @return Returns the alertDashboardList.
	 */
	public List getAlertDashboardList() {
		return alertDashboardList;
	}
	/**
	 * @param alertDashboard The alertDashboard to add
	 */
	public void addAlertDashboard(AlertDashboard alertDashboard) {
		this.alertDashboardList.add(alertDashboard);
	}
	
	/**
	 * @return Returns the alertRuleRevenueList.
	 */
	public List getAlertRuleRevenueList() {
		return alertRuleRevenueList;
	}
	/**
	 * @param alertRuleRevenue The alertRuleRevenue to add
	 */
	public void addAlertRuleRevenue(AlertRuleRevenue alertRuleRevenue) {
		this.alertRuleRevenueList.add(alertRuleRevenue);
	}
	/**
	 * @return Returns the alertRuleInvestigationsList.
	 */
	public List getAlertRuleInvestigationsList() {
		return alertRuleInvestigationsList;
	}
	/**
	 * @param alertRuleInvestigations The alertRuleInvestigations to add
	 */
	public void addAlertRuleInvestigations(AlertRuleInvestigations alertRuleInvestigations) {
		this.alertRuleInvestigationsList.add(alertRuleInvestigations);
	}
	/**
	 * @return Returns the alertRuleWarningsList.
	 */
	public List getAlertRuleWarningsList() {
		return alertRuleWarningsList;
	}
	/**
	 * @param alertRuleWarnings The alertRuleWarnings to add
	 */
	public void addAlertRuleWarnings(AlertRuleWarnings alertRuleWarnings) {
		this.alertRuleWarningsList.add(alertRuleWarnings);
	}
	/**
	 * @return Returns the cycle.
	 */
	public String getCycle() {
		return cycle;
	}
	/**
	 * @param cycle The cycle to add.
	 */
	public void setCycle(String cycle) {
		this.cycle = cycle;
	}
	/**
	 * @return Returns the displayHead.
	 */
	public String getDisplayHead() {
		return displayHead;
	}
	/**
	 * @param displayHead The displayHead to set.
	 */
	public void setDisplayHead(String displayHead) {
		this.displayHead = displayHead;
	}
	
	/**
	 * @return Returns the displayHeader.
	 */
	public String getDisplayHeader() {
		return displayHeader;
	}
	/**
	 * @param displayHeader The displayHeader to set.
	 */
	public void setDisplayHeader(String displayHeader) {
		this.displayHeader = displayHeader;
	}
	
	/**
	 * @return Returns the cntrlPt.
	 */
	public String getCntrlPt() {
		return cntrlPt;
	}
	/**
	 * @param cntrlPt The cntrlPt to set.
	 */
	public void setCntrlPt(String cntrlPt) {
		this.cntrlPt = cntrlPt;
	}
	
	/**
	 * @return Returns the cntrlPtDesc.
	 */
	public String getCntrlPtDesc() {
		return cntrlPtDesc;
	}
	/**
	 * @param cntrlPtDesc The cntrlPtDesc to set.
	 */
	public void setCntrlPtDesc(String cntrlPtDesc) {
		this.cntrlPtDesc = cntrlPtDesc;
	}
	/**
	 * @return Returns the alertRule.
	 */
	public String getAlertRule() {
		return alertRule;
	}
	/**
	 * @param alertRule The alertRule to set.
	 */
	public void setAlertRule(String alertRule) {
		this.alertRule = alertRule;
	}
	/**
	 * @return Returns the cameFromPage.
	 */
	public String getCameFromPage() {
		return cameFromPage;
	}
	/**
	 * @param cameFromPage The cameFromPage to set.
	 */
	public void setCameFromPage(String cameFromPage) {
		this.cameFromPage = cameFromPage;
	}
	public void reset(ActionMapping mapping, HttpServletRequest request) {
		super.reset(mapping,request);
	}
	public ActionErrors validate(ActionMapping mapping, HttpServletRequest request) {
			return super.validate(mapping,request);
	}
	/**
	 * @return Returns the emailRecipients.
	 */
	public String getEmailRecipients() {
		return emailRecipients;
	}
	/**
	 * @param emailRecipients The emailRecipients to set.
	 */
	public void setEmailRecipients(String emailRecipients) {
		this.emailRecipients = emailRecipients;
	}
	
	/**
	 * @return Returns the reportType.
	 */
	public String getReportType() {
		return reportType;
	}
	/**
	 * @param reportType The reportType to set.
	 */
	public void setReportType(String reportType) {
		this.reportType = reportType;
	}
	/**
	 * @return Returns the countTier1.
	 */
	public int getCountTier1() {
		return countTier1;
	}
	/**
	 * @param countTier1 The countTier1 to set.
	 */
	public void setCountTier1(int countTier1) {
		this.countTier1 = countTier1;
	}
	/**
	 * @return Returns the countTier2.
	 */
	public int getCountTier2() {
		return countTier2;
	}
	/**
	 * @param countTier2 The countTier2 to set.
	 */
	public void setCountTier2(int countTier2) {
		this.countTier2 = countTier2;
	}
	/**
	 * @return Returns the countTier3.
	 */
	public int getCountTier3() {
		return countTier3;
	}
	/**
	 * @param countTier3 The countTier3 to set.
	 */
	public void setCountTier3(int countTier3) {
		this.countTier3 = countTier3;
	}
	/**
	 * @return Returns the countNone.
	 */
	public int getCountNone() {
		return countNone;
	}
	/**
	 * @param countNone The countNone to set.
	 */
	public void setCountNone(int countNone) {
		this.countNone = countNone;
	}
	/**
	 * @return Returns the totalRecords.
	 */
	public int getTotalRecords() {
		return totalRecords;
	}
	/**
	 * @param totalRecords The totalRecords to set.
	 */
	public void setTotalRecords(int totalRecords) {
		this.totalRecords = totalRecords;
	}
	/**
	 * @return Returns the pageshow.
	 */
	public int getPageshow() {
		return pageshow;
	}
	/**
	 * @param pageshow The pageshow to set.
	 */
	public void setPageshow(int pageshow) {
		this.pageshow = pageshow;
	}
	/**
	 * @return Returns the countClosedStatus.
	 */
	public int getCountClosedStatus() {
		return countClosedStatus;
	}
	/**
	 * @param countClosedStatus The countClosedStatus to set.
	 */
	public void setCountClosedStatus(int countClosedStatus) {
		this.countClosedStatus = countClosedStatus;
	}
	/**
	 * @return Returns the countPendingStatus.
	 */
	public int getCountPendingStatus() {
		return countPendingStatus;
	}
	/**
	 * @param countPendingStatus The countPendingStatus to set.
	 */
	public void setCountPendingStatus(int countPendingStatus) {
		this.countPendingStatus = countPendingStatus;
	}
	/**
	 * @return Returns the countWarningStatus.
	 */
	public int getCountWarningStatus() {
		return countWarningStatus;
	}
	/**
	 * @param countWarningStatus The countWarningStatus to set.
	 */
	public void setCountWarningStatus(int countWarningStatus) {
		this.countWarningStatus = countWarningStatus;
	}
	/**
	 * @return Returns the fromEndDate.
	 */
	public String getFromEndDate() {
		return fromEndDate;
	}
	/**
	 * @param fromEndDate The fromEndDate to set.
	 */
	public void setFromEndDate(String fromEndDate) {
		this.fromEndDate = fromEndDate;
	}
	/**
	 * @return Returns the fromStartDate.
	 */
	public String getFromStartDate() {
		return fromStartDate;
	}
	/**
	 * @param fromStartDate The fromStartDate to set.
	 */
	public void setFromStartDate(String fromStartDate) {
		this.fromStartDate = fromStartDate;
	}
	/**
	 * @return Returns the process.
	 */
	public String getProcess() {
		return process;
	}
	/**
	 * @param process The process to set.
	 */
	public void setProcess(String process) {
		this.process = process;
	}
	
	/**
	 * @return Returns the alertRuleInvestigationsListCount.
	 */
	public int getAlertRuleInvestigationsListCount() {
		return alertRuleInvestigationsListCount;
	}
	/**
	 * @param alertRuleInvestigationsListCount The alertRuleInvestigationsListCount to set.
	 */
	public void setAlertRuleInvestigationsListCount(
			int alertRuleInvestigationsListCount) {
		this.alertRuleInvestigationsListCount = alertRuleInvestigationsListCount;
	}
	/**
	 * @return Returns the alertRuleRevenueListCount.
	 */
	public int getAlertRuleRevenueListCount() {
		return alertRuleRevenueListCount;
	}
	/**
	 * @param alertRuleRevenueListCount The alertRuleRevenueListCount to set.
	 */
	public void setAlertRuleRevenueListCount(int alertRuleRevenueListCount) {
		this.alertRuleRevenueListCount = alertRuleRevenueListCount;
	}
	/**
	 * @return Returns the alertRuleWarningsListCount.
	 */
	public int getAlertRuleWarningsListCount() {
		return alertRuleWarningsListCount;
	}
	/**
	 * @param alertRuleWarningsListCount The alertRuleWarningsListCount to set.
	 */
	public void setAlertRuleWarningsListCount(int alertRuleWarningsListCount) {
		this.alertRuleWarningsListCount = alertRuleWarningsListCount;
	}
	
	/**
	 * @return Returns the billRounds.
	 */
	public String getBillRounds() {
		return billRounds;
	}
	/**
	 * @param billRounds The billRounds to set.
	 */
	public void setBillRounds(String billRounds) {
		this.billRounds = billRounds;
	}
	/**
	 * @return Returns the holidayIndicators.
	 */
	public String getHolidayIndicators() {
		return holidayIndicators;
	}
	/**
	 * @param holidayIndicators The holidayIndicators to set.
	 */
	public void setHolidayIndicators(String holidayIndicators) {
		this.holidayIndicators = holidayIndicators;
	}
	/**
	 * @return Returns the procDates.
	 */
	public String getProcDates() {
		return procDates;
	}
	/**
	 * @param procDates The procDates to set.
	 */
	public void setProcDates(String procDates) {
		this.procDates = procDates;
	}
	/**
	 * @return Returns the totalSysMsg.
	 */
	public int getTotalSysMsg() {
		return totalSysMsg;
	}
	/**
	 * @param totalSysMsg The totalSysMsg to set.
	 */
	public void setTotalSysMsg(int totalSysMsg) {
		this.totalSysMsg = totalSysMsg;
	}
	/**
	 * @return Returns the totalWarnings.
	 */
	public int getTotalWarnings() {
		return totalWarnings;
	}
	/**
	 * @param totalWarnings The totalWarnings to set.
	 */
	public void setTotalWarnings(int totalWarnings) {
		this.totalWarnings = totalWarnings;
	}


	public String getSaveBackground() {
		return saveBackground;
	}


	public void setSaveBackground(String saveBackground) {
		this.saveBackground = saveBackground;
	}


	public String getRmiError() {
		return rmiError;
	}


	public void setRmiError(String rmiError) {
		this.rmiError = rmiError;
	}
}
