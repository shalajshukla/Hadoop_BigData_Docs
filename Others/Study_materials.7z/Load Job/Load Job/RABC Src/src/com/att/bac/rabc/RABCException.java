/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is an exception class specific to RABC project.
 * 
 * @author Vijay Dubey - VD3159
 */
public class RABCException extends Exception {
	private List  errorDetailsList;
	private List errorCauseDetailsList;
	
	/**
	 * Default Constructor.
	 */
	public RABCException() {
		super();
		this.errorDetailsList = new ArrayList();
		this.errorCauseDetailsList = new ArrayList();
	}
	
	/**
	 * Constructor with a String message.
	 * 
	 * @param message
	 */
	public RABCException(String message) {
		super(message);
		this.errorDetailsList = new ArrayList();
		this.errorCauseDetailsList = new ArrayList();
	}
	
	/**
	 * Constructor with a String message & actual exception.
	 * 
	 * @param message
	 * @param e
	 */
	public RABCException(String message, Exception e) {
		super(message, e);
		this.errorDetailsList = new ArrayList();
		this.errorCauseDetailsList = new ArrayList();
	}
	
	/**
	 * Method to return the list of details of the error. It adds the details of the error in the list
	 * with each element being object of type PickList.
	 * 
	 * @return List
	 */
	public List getErrorDetailsList(){
		if(this!=null){
			this.errorDetailsList.add(new PickList(this.getClass().getName()+":"+this.getMessage(),this.getClass().getName()+":"+this.getMessage()));

			StackTraceElement[] trace = this.getStackTrace();
			for(int i=0; i<trace.length; i++){
				this.errorDetailsList.add(new PickList(this.getClass().getName(),"	at "+trace[i].toString()));
			}
		}

		return errorDetailsList;
	}
	
	/**
	 * Method to return the list of details of the error cause. It adds the details of the cause [its stack trace] in 
	 * the list with each element being object of type PickList.
	 * 
	 * @return List
	 */
	public List getErrorCauseDetailsList(){
		if(this!=null){
			Throwable cause =this.getCause();
			
			while(cause!=null){
				this.errorCauseDetailsList.add(new PickList("caused by "+cause.getClass()+":"+cause.getMessage(),"caused by "+cause.getClass()+":"+cause.getMessage()));
				StackTraceElement[] trace = cause.getStackTrace();
				for(int i=0; i<trace.length; i++){
					this.errorCauseDetailsList.add(new PickList(cause.getClass().getName(),"	at "+trace[i].toString()));
				}
				cause = cause.getCause();
			}
		}
		
		return errorCauseDetailsList;
	}

}
