/*
 * Copyright  2002-2006 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.adhoc.aria.pivot;

import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.att.bac.rabc.adhoc.AdhocConstants;
import com.att.bac.rabc.adhoc.rpt.AdhocRptDataTO;
import com.att.bac.rabc.adhoc.rpt.AdhocRptUtil;


/**
 * Maintains a lookup map for finding previous data.
 * 
 * <p>
 * <hr>
 * <h3>Release History</h3>
 * <p>
 * <ul>
 * 
 * <li>jb6494 Nov 30, 2006 Created class.
 * 
 * </ul>
 * <p>
 * 
 */
public class PreviousDataLookup implements AdhocConstants {

    private Map map = new HashMap();


    /**
     * @param key
     * @return
     */
    public boolean containsKey(DatedCompositeKey key) {
        return map.containsKey(key);
    }


    /**
     * Get the Value matching key
     * 
     * @param key
     * @return
     */
    // Made required changes for issue #M5, PMT M169. 
    public Object get(DatedCompositeKey key, DatedCompositeKey key1) {
//    	System.out.println("temp value set as argument to map"+  key );
//    	System.out.println("old Key"+  key1 );
    	
    	if(null!=map.get(key1)){
    		AdhocRptDataTO a= (AdhocRptDataTO)map.get(key1);
    		
    	}else{
    		System.out.println("Problem");
    	}
        return map.get(key);
    }
    // End changes for issue #M5, PMT M169. 

    /**
     * @return
     */
    public boolean isEmpty() {
        return map.isEmpty();
    }


    /**
     * @param key
     * @param value
     * @return
     */
    public Object put(DatedCompositeKey key, Object value) {
           return map.put(key, value);
    }


    /**
     * @param key
     * @return
     */
    public Object remove(DatedCompositeKey key) {
        return map.remove(key);
    }


    /**
     * @return
     */
    public int size() {
        return map.size();
    }


    /**
     * @param current
     * @param trendTime
     * @return
     */
    public Object findPreviousData(DatedCompositeKey current, String trendTime, AdhocRptDataTO dto) {
        DatedCompositeKey temp = current.createClone();
        DatedCompositeKey temp1 = current.createClone();
        
        if (dto.getPresnTrendTime() == null || "".equals(dto.getPresnTrendTime())){
        	Object prevData = null;
        	int counter = 0;
        	Date fileDate = temp.getDate();
        	
        	while (prevData == null && counter < 100){
        		counter++;
        		if (dto.getPresnModel()==1 && (dto.getMonthSelect()!=0 || dto.getYearSelect()!=0) ){
        			Calendar cal = Calendar.getInstance();
        	        cal.setTime(fileDate);
        	        cal.add(Calendar.MONTH, -1);
        	        fileDate = cal.getTime();
        		} else {
        			fileDate = AdhocRptUtil.getPreviousDate(fileDate);
        		}
        		temp.setDate(fileDate);
        	    //prevData = get(temp); 
        		// Made required changes for issue #M5, PMT M169. 
        		prevData = get(temp,temp1); 
        	}
        	return prevData;
        } else {
           	temp.setDate(AdhocRptUtil.getPreviousDate(temp.getDate(), trendTime, dto,true));
           //return get(temp);
         // Made required changes for issue #M5, PMT M169. 
           	return get(temp,temp1);
        }
    }


    /**
     * Return all the values
     * 
     * @return
     */
    public Collection values() {
        return map.values();
    }


    /**
     * Return all the keys
     * 
     * @return
     */
    public Set keySet() {
        return map.keySet();
    }
}
