/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.status;

/**
 * This is a Data Object to represent RABC_ROOT_CATGY_CD table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class RootCategory {
	private String rootCatgyCd;
	private String rootCatgyCdDesc;

	/**
	 * @return Returns the RootCatgyCd.
	 */
	public String getRootCatgyCd() {
		return rootCatgyCd;
	}
	/**
	 * @return Returns the RootCatgyCdDesc.
	 */
	public String getRootCatgyCdDesc() {
		return rootCatgyCdDesc;
	}

	/**
	 * @param RootCatgyCd The rootCatgyCd to set.
	 */
	public void setRootCatgyCd(String rootCatgyCd) {
		this.rootCatgyCd = rootCatgyCd;
	}
	/**
	 * @param RootCatgyCdDesc The rootCatgyCdDesc to set.
	 */
	public void setRootCatgyCdDesc(String rootCatgyCdDesc) {
		this.rootCatgyCdDesc = rootCatgyCdDesc;
	}
}
