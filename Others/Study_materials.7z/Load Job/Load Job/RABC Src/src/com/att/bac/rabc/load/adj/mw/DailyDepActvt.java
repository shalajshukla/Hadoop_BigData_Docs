/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.load.adj.mw;

import java.util.Date;

import com.sbc.bac.rabc.load.HashCodeUtil;

/**
 * This is a class representing entries in RABC_DAILY_DEP_ACTVT table.
 * 
 * @author Shailesh Hemdev - SH8512
 */
public class DailyDepActvt {
	private Date runDate;
	private String division;
	private String mktInd;
	private long depCt;
	
	/**
	 * @return Returns the depCt.
	 */
	public long getDepCt() {
		return depCt;
	}
	/**
	 * @param depCt The depCt to set.
	 */
	public void setDepCt(long depCt) {
		this.depCt = depCt;
	}
	/**
	 * @return Returns the division.
	 */
	public String getDivision() {
		return division;
	}
	/**
	 * @param division The division to set.
	 */
	public void setDivision(String division) {
		this.division = division;
	}
	/**
	 * @return Returns the mktInd.
	 */
	public String getMktInd() {
		return mktInd;
	}
	/**
	 * @param mktInd The mktInd to set.
	 */
	public void setMktInd(String mktInd) {
		this.mktInd = mktInd;
	}
	/**
	 * @return Returns the runDate.
	 */
	public Date getRunDate() {
		return runDate;
	}
	/**
	 * @param runDate The runDate to set.
	 */
	public void setRunDate(Date runDate) {
		this.runDate = runDate;
	}
	
	/**
	 * Equals method overridden for this object so that it can be stored in a hash map where the key 
	 * would be combination of the following 3 attributes:
	 * Run date
	 * Division
	 * Market Indicator
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object o) {
		// Do a quick check for an identical object reference
	    if (this == o) {
	      return true;
	    }
	    if (!(o instanceof DailyDepActvt)) {
	    	return false;
	    } else {
	    	if (((DailyDepActvt)o).getRunDate().getTime() == this.getRunDate().getTime()
				&& ((DailyDepActvt)o).getDivision().equalsIgnoreCase(this.getDivision())
				&& ((DailyDepActvt)o).getMktInd().equalsIgnoreCase(this.getMktInd())	
				) {
	    		return true;
	    	} else {
	    		return false;
	    	}
	    }
	}
	
	/**
	 * Hash code method overridden for this object to categorize this object in sets 
	 * so that the hash collections can search this object efficiently.
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		int hashCode = HashCodeUtil.SEED;
		hashCode = HashCodeUtil.hash( hashCode, this.getMktInd());
		return hashCode;
	}
}
