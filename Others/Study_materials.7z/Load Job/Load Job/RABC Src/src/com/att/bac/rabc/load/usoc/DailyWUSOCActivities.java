/*
 * Created on Feb 8, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.att.bac.rabc.load.usoc;

import java.io.File;
import java.net.UnknownHostException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.StringTokenizer;

import com.att.bac.rabc.util.EmcisEventLogger;
import com.att.carat.util.NetUtil;
import com.sbc.bac.rabc.load.FilePatternLoadJob;
import com.sbc.bac.rabc.load.PrepareTableForRerun;
import com.sbc.bac.rabc.load.RabcLoadJobTrig;
import com.sbc.bac.rabc.load.RetrieveStaticInfo;
import com.sbc.bac.rabc.load.StaticErrorMsgKeys;
import com.sbc.bac.rabc.load.StaticFieldKeys;

/**
 * @author pt6471
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class DailyWUSOCActivities extends FilePatternLoadJob {
	
	 //private static final String FILEPATTERN = "[CI].C[0-9][0-9]*.CN16100B.*";
	 
	 private PreparedStatement insert_cn161_daily, insert_usoc, delete_dup_usoc;
	 private String division, bill_rnd, run_date, fileName, fileToken;
	 
	 private String backoutRecovery = null;
	 
	 private File currentFile;
	 
	 private String saveOrderType;
	
	 private int cycle, lineCount;
	 
	 private java.sql.Date sqlrun_date;
	 
	 private boolean nevadaBellData;
	 
	 public boolean preprocess() {
		super.preprocess();

		try {
			StringBuffer sql = new StringBuffer();
			sql.append("  insert into RABC_DAILY_USOC_ACTVT (DIVISION, RUN_DATE, CYCLE, USOC, FULL_CHG_TOT_CT, FULL_CHG_TOT_AMT, DSCT_50_PCT_TOT_CT, DSCT_50_PCT_TOT_AMT, DSCT_100_PCT_TOT_CT, DSCT_100_PCT_TOT_AMT, DSCT_OTH_PCT_TOT_CT, DSCT_OTH_PCT_TOT_AMT, USOC_ACCS_IND) ");
			sql.append("  VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ");
			insert_cn161_daily = connection.prepareStatement(sql.toString());
			sql.setLength(0);
			
			insert_usoc = connection.prepareStatement(" insert into RABC_USOC(USOC, USOC_DESC) VALUES(?, ?)");
			
		} catch (SQLException e) {
			severe(StaticErrorMsgKeys.PREPROCESS_ERROR + e.getMessage());
			return false;
		}
		return true;
	}

	public boolean preprocessFile(File file) {
		boolean success = super.preprocessFile(file);
		fileName = file.getName();
		fileToken = "CN16100B";
		nevadaBellData = false;

		int fileNameLength = file.getName().length();
		
		if (success) {
			try {
				
				if 	(file.getName().charAt(0) == StaticFieldKeys.C)	
				  division = StaticFieldKeys.PACBELLNORTH;
				else if (file.getName().charAt(0) == StaticFieldKeys.I)	
				  division = StaticFieldKeys.PACBELLSOUTH;
				else 
					return false;
				
				cycle = Integer.parseInt(file.getName().substring(3, 7));
				
				run_date = RetrieveStaticInfo.getProc_dtByCycle(connection, cycle);
				if (run_date.equals(StaticFieldKeys.ZERO)){
					severe(StaticErrorMsgKeys.NORECORD_RABC_CYCLE_CALENDAR + cycle);
					throw new Exception();	
				}
				
				
				DateFormat df = new SimpleDateFormat("MMddyyyy");
				sqlrun_date = new java.sql.Date(df.parse(run_date).getTime());

				lineCount = 0;
				
				backoutRecovery = null;

				if (RabcLoadJobTrig.IsFileLoaded(connection, file, fileNameLength)) {
					backoutRecovery = "Y";
					String tableNm = "RABC_DAILY_USOC_ACTVT";
					success = PrepareTableForRerun.deleteTableData(connection,tableNm,division,sqlrun_date);
					//	Both divisions NB (NEVADABELL) and PN (PACBELLNORTH) come from same file!!
					if (division == StaticFieldKeys.PACBELLNORTH)
					 	success = PrepareTableForRerun.deleteTableData(connection,tableNm,StaticFieldKeys.NEVADABELL,sqlrun_date);
				}
				
			} catch (Exception e) {
				severe(
					StaticErrorMsgKeys.PREPROCESSFILE_ERROR
						+ StaticErrorMsgKeys.FILE_NAME_PARSING_ERROR
						+ e);
				return false;
			}
		}

		try {
			bill_rnd = RetrieveStaticInfo.getBillRndByCycle(connection, cycle);
			/*
			if (bill_rnd.equals(StaticFieldKeys.ZERO) || bill_rnd.equals(StaticFieldKeys.ZERO2)){
			 severe(StaticErrorMsgKeys.PREPROCESSFILE_ERROR+":No Bill Round");
			 return false;
			}
			*/

		} catch (SQLException e) {
			success = false;
			severe(StaticErrorMsgKeys.PREPROCESSFILE_ERROR + e.getMessage());
		}

		currentFile = file;
		return success;
	}

	
	
	public int parseLine(String line) throws Exception {

		lineCount++;
		
		StringTokenizer DataLine = new StringTokenizer(line, StaticFieldKeys.SEMICOLON);
		
		int numberOfTokens = DataLine.countTokens();
		
		String companyID 	  = DataLine.nextToken().trim();
		String usoc			  = DataLine.nextToken().trim();
		int cn161BCycle		  = Integer.parseInt(DataLine.nextToken().trim());
		String billRnd		  = DataLine.nextToken().trim();
		int usocYear		  = Integer.parseInt(DataLine.nextToken().trim());
		int usocMonth		  = Integer.parseInt(DataLine.nextToken().trim());
		int monthlyQuantity1  = Integer.parseInt(DataLine.nextToken().trim());
		double monthlyAmt1	  = Double.parseDouble(DataLine.nextToken().trim())/1000;
		int monthlyQuantity2  = Integer.parseInt(DataLine.nextToken().trim());
		double monthlyAmt2	  = Double.parseDouble(DataLine.nextToken().trim())/1000;
		int monthlyQuantity3  = Integer.parseInt(DataLine.nextToken().trim());
		double monthlyAmt3	  = Double.parseDouble(DataLine.nextToken().trim())/1000;
		int monthlyQuantity4  = Integer.parseInt(DataLine.nextToken().trim());
		double monthlyAmt4	  = Double.parseDouble(DataLine.nextToken().trim())/1000;
		String usocAccessibleInd  = DataLine.nextToken().trim();
		String usoc_desc = null;
		if (numberOfTokens > 15)
			usoc_desc = DataLine.nextToken().trim();
		
		if (companyID.equals("NB")) nevadaBellData = true;
		
		try {

			// If division is NB read from the dataline, populate this, else the division which is read from the file 
            if(companyID.equals("NB")){
                  insert_cn161_daily.setString(1,"NB");
            } else{
                  insert_cn161_daily.setString(1,division);
            }
			insert_cn161_daily.setDate(2,sqlrun_date);
			insert_cn161_daily.setInt(3,cn161BCycle);
			insert_cn161_daily.setString(4,usoc);
			insert_cn161_daily.setInt(5,monthlyQuantity1);
			insert_cn161_daily.setDouble(6,monthlyAmt1);
			insert_cn161_daily.setInt(7,monthlyQuantity2);
			insert_cn161_daily.setDouble(8,monthlyAmt2);
			insert_cn161_daily.setInt(9,monthlyQuantity3);
			insert_cn161_daily.setDouble(10,monthlyAmt3);
			insert_cn161_daily.setInt(11,monthlyQuantity4);
			insert_cn161_daily.setDouble(12,monthlyAmt4);
			insert_cn161_daily.setString(13,usocAccessibleInd);
			insert_cn161_daily.addBatch();
			
			insert_usoc.setString(1,usoc);
			insert_usoc.setString(2,usoc_desc);
			insert_usoc.addBatch();
			
			if (lineCount % 1000 == 0){
				insert_cn161_daily.executeBatch();
				insert_usoc.executeBatch();
			}

		}catch (SQLException sqle){
			severe(StaticErrorMsgKeys.INSERT_ERROR + sqle.getMessage());
			 throw new Exception("Exception is from method parseLine - DailyWUSOCActivities");
		}
		
		return SUCCESS;
	}
	
	
	public boolean postprocessFile(File file, boolean success) {
		try{				
			//Log the file information to EMCIS_EVENT_LOG and EMCIS_EVENT_LOG_DETAIL
			EmcisEventLogger emcisLogger = new EmcisEventLogger();
			String event_id = "RABC_"+fileToken+"_WE";
            String host = NetUtil.getLocalHostName();
            String hostIP = NetUtil.getLocalIpAddress();
			int sequence = emcisLogger.getEMCISSequence(connection);
			emcisLogger.insertEventLog(connection, sequence, event_id, sqlrun_date, host, hostIP);
			emcisLogger.insertEventLogDetail(connection, sequence, "FileName", fileName);
		}catch (UnknownHostException e) {
            severe("Error getting EMCIS host information ", e);
        }
		if (success) {

			try {
				insert_cn161_daily.executeBatch();
				insert_usoc.executeBatch();
				
				delete_dup_usoc = connection.prepareStatement(" DELETE FROM RABC_USOC a WHERE a.ROWID < (SELECT MAX (b.ROWID) FROM RABC_USOC b WHERE a.USOC = b.USOC) ");
				int delCnt = delete_dup_usoc.executeUpdate();
				if (delCnt>0)
						info("deleted duplicate USOC Cnt from RABC_USOC : " + delCnt);
		
				if (!insertTrigger()) {
					severe(
						StaticErrorMsgKeys.POSTPROCESSFILE_ERROR
							+ StaticErrorMsgKeys.TIGGER_TABLE_INSERT_ERROR);
					success = false;
				}
				
			}catch (SQLException sqle){
				severe(StaticErrorMsgKeys.INSERT_ERROR + sqle.getMessage());
				success = false;
			}
			
			}
		return super.postprocessFile(file, success);
	}

	
	public boolean postprocess(boolean success) {

		try {
			
			insert_cn161_daily.close();
			insert_usoc.close();
			delete_dup_usoc.close();
		
		} catch (SQLException e) {
			severe(
				StaticErrorMsgKeys.POSTPROCESS_ERROR
					+ StaticErrorMsgKeys.SQL_CLOSE_ERROR
					+ e);
			success = false;
		}

		return super.postprocess(success);
	}

	private boolean insertTrigger() {

		 if(!RabcLoadJobTrig.insertTrigger(connection,currentFile.getName(),"CN16100B",division,run_date,backoutRecovery,bill_rnd))
			return false;	
		 
		 if (nevadaBellData)
		 	if(!RabcLoadJobTrig.insertTrigger(connection,currentFile.getName(),"CN16100B",StaticFieldKeys.NEVADABELL,run_date,backoutRecovery,bill_rnd))
				return false;
		 	
		return true;
		
	}

}
