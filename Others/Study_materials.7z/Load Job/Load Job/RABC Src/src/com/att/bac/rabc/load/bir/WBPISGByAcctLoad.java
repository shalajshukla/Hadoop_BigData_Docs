/*
 * Created on Feb 24, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.att.bac.rabc.load.bir;

import java.io.File;
import java.net.UnknownHostException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.StringTokenizer;

import com.att.bac.rabc.util.EmcisEventLogger;
import com.att.carat.util.NetUtil;
import com.sbc.bac.rabc.load.FilePatternLoadJob;
import com.sbc.bac.rabc.load.PrepareTableForRerun;
import com.sbc.bac.rabc.load.RabcLoadJobTrig;
import com.sbc.bac.rabc.load.RetrieveStaticInfo;
import com.sbc.bac.rabc.load.StaticErrorMsgKeys;
import com.sbc.bac.rabc.load.StaticFieldKeys;

/**
 * @author pt6471
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class WBPISGByAcctLoad extends FilePatternLoadJob {
	
	// private static final String FILEPATTERN = "WE.[CI].C[0-9][0-9]*.X21B.*";	For XT21ISGA
	
	 private PreparedStatement insert_xt21isga;
	 private String division, bill_rnd, bill_rnd_dt, run_date, btnCCGrp, fileName;
	 
	 private String region;
	 private String backoutRecovery = null;
	 
	 private HashMap crocd_division;
	 
	 private File currentFile;
	 
	 private String fileToken;
	
	 private int cycle, lineCount;
	 
	 private java.sql.Date sqlrun_date;
	 
	 private boolean nevadaBellData, billdayFile;
	 
	 
	public boolean preprocess() {
		super.preprocess();

		try {
			StringBuffer sql = new StringBuffer();
			sql.append("  insert into RABC_TOP100_ISG_ACCT_DTL (DIVISION, RUN_DATE, TCC_ID, BTN, CUR_BLG_AMT, BLG_MM, BLG_YEAR, BILL_RND) ");
			sql.append("  VALUES(?, ?, ?, ?, ?, ?, ?, ?) ");
			insert_xt21isga = connection.prepareStatement(sql.toString());
			sql.setLength(0);

		} catch (SQLException e) {
			severe(StaticErrorMsgKeys.PREPROCESS_ERROR + e.getMessage());
			return false;
		}
		return true;
	}

	public boolean preprocessFile(File file) {
		boolean success = super.preprocessFile(file);
		fileName = file.getName();
		fileToken = file.getName().substring(file.getName().indexOf("XT21ISGA"),file.getName().indexOf("XT21ISGA")+ 8);
		
		nevadaBellData = false;
		billdayFile = true;

		if (success) {
			try {
				
				region   =	file.getName().substring(0,2);
				
				if 	(file.getName().charAt(3) == StaticFieldKeys.C)	
				  division = StaticFieldKeys.PACBELLNORTH;
				else if (file.getName().charAt(3) == StaticFieldKeys.I)	
				  division = StaticFieldKeys.PACBELLSOUTH;
				else 
					return false;
				
				cycle = Integer.parseInt(file.getName().substring(6, 10));
				
				run_date = RetrieveStaticInfo.getProc_dtByCycle(connection, cycle);
				bill_rnd_dt = RetrieveStaticInfo.getbillRndDt_ByCycle(connection, cycle);
				if (run_date.equals(StaticFieldKeys.ZERO)){
					severe(StaticErrorMsgKeys.NORECORD_RABC_CYCLE_CALENDAR + cycle);
					throw new Exception();	
				}
				
				
				DateFormat df = new SimpleDateFormat("MMddyyyy");
				sqlrun_date = new java.sql.Date(df.parse(run_date).getTime());

				lineCount = 0;
				
				String tableNm = "RABC_TOP100_ISG_ACCT_DTL";
				backoutRecovery = null;

				if (RabcLoadJobTrig.IsFileLoaded(connection, file)) {
					backoutRecovery = "Y";
					success = PrepareTableForRerun.deleteTableData(connection,tableNm,division,sqlrun_date);
					//	Both divisions NB (NEVADABELL) and PN (PACBELLNORTH) come from same file!!
					if (division == StaticFieldKeys.PACBELLNORTH)
					 	success = PrepareTableForRerun.deleteTableData(connection,tableNm,StaticFieldKeys.NEVADABELL,sqlrun_date);
				}


				
			} catch (Exception e) {
				severe(
					StaticErrorMsgKeys.PREPROCESSFILE_ERROR
						+ StaticErrorMsgKeys.FILE_NAME_PARSING_ERROR
						+ e);
				return false;
			}
		}

		try {

			crocd_division  = RetrieveStaticInfo.getCrocd_Divsion(connection,region.trim());
				
			bill_rnd = RetrieveStaticInfo.getBillRndByCycle(connection, cycle).trim();
			if (bill_rnd.equals(StaticFieldKeys.ZERO) || bill_rnd.equals(StaticFieldKeys.ZERO2)){
			 //severe(StaticErrorMsgKeys.PREPROCESSFILE_ERROR+":No Bill Round");
			 //return false;
				billdayFile = false;
			}

		} catch (SQLException e) {
			success = false;
			severe(StaticErrorMsgKeys.PREPROCESSFILE_ERROR + e.getMessage());
		}

		currentFile = file;
		return success;
	}

	
	
	public int parseLine(String line) throws Exception {
		boolean status;

			status = process21xtISGA(line);

			return SUCCESS;
	}
	
	

	private boolean process21xtISGA(String line ) throws Exception {
		
		lineCount++;
		
		StringTokenizer DataLine = new StringTokenizer(line, StaticFieldKeys.SEMICOLON);

		String tccId		= DataLine.nextToken().trim();
		String btnCCGrp		= DataLine.nextToken().trim();
		double rev_adj_amt 	= Double.parseDouble(DataLine.nextToken().trim());
		String  croCode  	= DataLine.nextToken().trim();

		String div  = (String) crocd_division.get(croCode);
		if (div == null){
	          severe(StaticErrorMsgKeys.NORECORD_RABC_CRO_CD_DIVISION + croCode);
			  throw new Exception(" No CRO CODE MATCH in job BIRWLoadJob");	
			}else if ( div.equals(StaticFieldKeys.NEVADABELL)) {
				nevadaBellData = true;
			}
		
		try {
			insert_xt21isga.setString(1,div);		
			insert_xt21isga.setDate(2,sqlrun_date);
			insert_xt21isga.setString(3,tccId);
			insert_xt21isga.setString(4,btnCCGrp);
			insert_xt21isga.setDouble(5,rev_adj_amt);
			insert_xt21isga.setString(6,bill_rnd_dt.substring(0,2));
			insert_xt21isga.setString(7,bill_rnd_dt.substring(4,8));
			insert_xt21isga.setInt(8,Integer.parseInt(bill_rnd));
		
			insert_xt21isga.addBatch();
			
			if (lineCount % 1000 == 0){
				insert_xt21isga.executeBatch();
			}
			
		}catch (SQLException sqle){
			severe(StaticErrorMsgKeys.INSERT_ERROR + sqle.getMessage());
			 throw new Exception("Exception is from method process21xtSODS");
		}
		
		
		return true;
		
	}
	
	
	
	
	public boolean postprocessFile(File file, boolean success) {
		try{
			//Log the file information to EMCIS_EVENT_LOG and EMCIS_EVENT_LOG_DETAIL
			EmcisEventLogger emcisLogger = new EmcisEventLogger();
			String event_id = "RABC_"+fileToken+"_"+region;
            String host = NetUtil.getLocalHostName();
            String hostIP = NetUtil.getLocalIpAddress();
			int sequence = emcisLogger.getEMCISSequence(connection);
			emcisLogger.insertEventLog(connection, sequence, event_id, sqlrun_date, host, hostIP);
			emcisLogger.insertEventLogDetail(connection, sequence, "FileName", fileName);

		}catch (UnknownHostException e) {
            severe("Error getting EMCIS host information ", e);
        }

		if (success) {

			try {
			
				insert_xt21isga.executeBatch();
			
			if (billdayFile)
			if (!insertTrigger()) {
				severe(
					StaticErrorMsgKeys.POSTPROCESSFILE_ERROR
						+ StaticErrorMsgKeys.TIGGER_TABLE_INSERT_ERROR);
				success = false;
			}
			
			
			}catch (SQLException sqle){
				severe(StaticErrorMsgKeys.INSERT_ERROR + sqle.getMessage());
				success = false;
			}
			
		}
		return super.postprocessFile(file, success);
	}

	
	public boolean postprocess(boolean success) {

		try {
			
			insert_xt21isga.close(); 

		} catch (SQLException e) {
			severe(
				StaticErrorMsgKeys.POSTPROCESS_ERROR
					+ StaticErrorMsgKeys.SQL_CLOSE_ERROR
					+ e);
			success = false;
		}

		return super.postprocess(success);
	}

	private boolean insertTrigger() {

		 if(!RabcLoadJobTrig.insertTrigger(connection,currentFile.getName(),fileToken,division,run_date, backoutRecovery,bill_rnd))
			return false;
		 
		 if (nevadaBellData)
		 	if(!RabcLoadJobTrig.insertTrigger(connection,currentFile.getName(),fileToken,"NB",run_date, backoutRecovery,bill_rnd))
				return false;
		
		return true;
		
	}

}
