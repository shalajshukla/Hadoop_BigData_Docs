/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/

package com.att.bac.rabc.alerts.dashboard;

import java.util.List;

/**
 * This class represents the data object that holds the attributes required
 * to represent division wise alert summary. 
 * 
 * @author Sandhya Chinala - SC3837
 */
public class DivisionWiseAlertSummary {
	private String dashboardKey;  //Control Pint or Alert Rule
	private String divisionCode;
	private String divisionDesc;
	private int count;
	private List fileDateWiseAlertSummaryList;
	
	/**
	 * @return Returns the count.
	 */
	public int getCount() {
		return count;
	}
	/**
	 * @param count The count to set.
	 */
	public void setCount(int count) {
		this.count = count;
	}
	/**
	 * @return Returns the divisionCode.
	 */
	public String getDivisionCode() {
		return divisionCode;
	}
	/**
	 * @param divisionCode The divisionCode to set.
	 */
	public void setDivisionCode(String divisionCode) {
		this.divisionCode = divisionCode;
	}
	/**
	 * @return Returns the divisionDesc.
	 */
	public String getDivisionDesc() {
		return divisionDesc;
	}
	/**
	 * @param divisionDesc The divisionDesc to set.
	 */
	public void setDivisionDesc(String divisionDesc) {
		this.divisionDesc = divisionDesc;
	}
	/**
	 * @return Returns the dashboardKey.
	 */
	public String getDashboardKey() {
		return dashboardKey;
	}
	/**
	 * @param dashboardKey The dashboardKey to set.
	 */
	public void setDashboardKey(String dashboardKey) {
		this.dashboardKey = dashboardKey;
	}

	/**
	 * @return Returns the fileDateWiseAlertSummaryList.
	 */
	public List getFileDateWiseAlertSummaryList() {
		return fileDateWiseAlertSummaryList;
	}
	/**
	 * @param fileDateWiseAlertSummaryList The fileDateWiseAlertSummaryList to set.
	 */
	public void setFileDateWiseAlertSummaryList(
			List fileDateWiseAlertSummaryList) {
		this.fileDateWiseAlertSummaryList = fileDateWiseAlertSummaryList;
	}
}
