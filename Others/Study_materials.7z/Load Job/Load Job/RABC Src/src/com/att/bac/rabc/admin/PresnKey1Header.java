/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.admin;

/**
 * This is a Data Object to represent RABC_PRESN_KEY1_HEADER table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class PresnKey1Header {
	private int presnId;
	private String webid;
	private int execPresnSeqNum;
	private String key1Value;
	private String mainKey1LineHeader;

	/**
	 * @return Returns the PresnId.
	 */
	public int getPresnId() {
		return presnId;
	}
	/**
	 * @return Returns the Webid.
	 */
	public String getWebid() {
		return webid;
	}
	/**
	 * @return Returns the ExecPresnSeqNum.
	 */
	public int getExecPresnSeqNum() {
		return execPresnSeqNum;
	}
	/**
	 * @return Returns the Key1Value.
	 */
	public String getKey1Value() {
		return key1Value;
	}
	/**
	 * @return Returns the MainKey1LineHeader.
	 */
	public String getMainKey1LineHeader() {
		return mainKey1LineHeader;
	}

	/**
	 * @param PresnId The presnId to set.
	 */
	public void setPresnId(int presnId) {
		this.presnId = presnId;
	}
	/**
	 * @param Webid The webid to set.
	 */
	public void setWebid(String webid) {
		this.webid = webid;
	}
	/**
	 * @param ExecPresnSeqNum The execPresnSeqNum to set.
	 */
	public void setExecPresnSeqNum(int execPresnSeqNum) {
		this.execPresnSeqNum = execPresnSeqNum;
	}
	/**
	 * @param Key1Value The key1Value to set.
	 */
	public void setKey1Value(String key1Value) {
		this.key1Value = key1Value;
	}
	/**
	 * @param MainKey1LineHeader The mainKey1LineHeader to set.
	 */
	public void setMainKey1LineHeader(String mainKey1LineHeader) {
		this.mainKey1LineHeader = mainKey1LineHeader;
	}
}
