/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.admin.adhoc.rpt;

import org.apache.struts.action.ActionForm;

/**
 * Module description: 
 * 
 * This is a adhoc report deletion page Form Bean.
 *
 * @author Anup Thomas - AT1862
 */
public class AdhocReportDeleteForm extends ActionForm {
	/*
	 * Variables to represent the fields on Adhoc Report Main page.
	 */
	private AdhocReportDefinition adhocReportDefinition;
	private String rptType;	
	private String alertGrp;
	private String dataNode;
	private String dispatch = null;
	private String presnId;
	private String hasDeletePermission; 

	/**
	 * @return Returns the hasDeletePermission.
	 */
	public String getHasDeletePermission() {
		return hasDeletePermission;
	}
	/**
	 * @param hasDeletePermission The hasDeletePermission to set.
	 */
	public void setHasDeletePermission(String hasDeletePermission) {
		this.hasDeletePermission = hasDeletePermission;
	}
	/**
	 * @return Returns the presnId.
	 */
	public String getPresnId() {
		return presnId;
	}
	/**
	 * @param presnId The presnId to set.
	 */
	public void setPresnId(String presnId) {
		this.presnId = presnId;
	}
	/**
	 * @return Returns the dispatch.
	 */
	public String getDispatch() {
		return dispatch;
	}
	/**
	 * @param dispatch The dispatch to set.
	 */
	public void setDispatch(String dispatch) {
		this.dispatch = dispatch;
	}
	/**
	 * @return Returns the alertGrp.
	 */
	public String getAlertGrp() {
		return alertGrp;
	}
	/**
	 * @param alertGrp The alertGrp to set.
	 */
	public void setAlertGrp(String alertGrp) {
		this.alertGrp = alertGrp;
	}
	/**
	 * @return Returns the dataNode.
	 */
	public String getDataNode() {
		return dataNode;
	}
	/**
	 * @param dataNode The dataNode to set.
	 */
	public void setDataNode(String dataNode) {
		this.dataNode = dataNode;
	}
	
	/**
	 * @return Returns the rptType.
	 */
	public String getRptType() {
		return rptType;
	}
	/**
	 * @param rptType The rptType to set.
	 */
	public void setRptType(String rptType) {
		this.rptType = rptType;
	}
	/**
	 * @return Returns the adhocReportDefinition.
	 */
	public AdhocReportDefinition getAdhocReportDefinition() {
		return adhocReportDefinition;
	}
	/**
	 * @param adhocReportDefinition The adhocReportDefinition to set.
	 */
	public void setAdhocReportDefinition(
			AdhocReportDefinition adhocReportDefinition) {
		this.adhocReportDefinition = adhocReportDefinition;
	}
}
