/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.alerts.status;

import java.util.Map;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import de.laures.cewolf.ChartPostProcessor;

/**
 * This is a utility class used for processing prior to rendering a line graph.
 * 
 * @author Shailesh Hemdev - SH8512
 */
public class GraphPostProcessor implements ChartPostProcessor {
	/**
	 * Method to process prior to rendering a line graph.
	 * 
	 * @param chart
	 * @param map
	 * @see de.laures.cewolf.ChartPostProcessor#processChart(java.lang.Object, java.util.Map)
	 */
	public void processChart(Object chart, Map map){
		JFreeChart jchart = (JFreeChart) chart;
		LineAndShapeRenderer lineAndShapeRenderer = new LineAndShapeRenderer();
		jchart.getCategoryPlot().setRenderer(lineAndShapeRenderer);
		jchart.getCategoryPlot().getDomainAxis().setTickLabelsVisible(false);
		jchart.getCategoryPlot().setRangeGridlinesVisible(true);
		jchart.getCategoryPlot().setDomainGridlinesVisible(true);
	}
}
