/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.admin.alert.rule;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.FastArrayList;
import org.apache.struts.action.ActionForm;

import com.att.bac.rabc.PickList;
import com.att.bac.rabc.RABCConstantsLists;
import com.att.bac.rabc.Tree;

/**
 * This is a Form Bean for Alert Rule Definition (All 3 steps).
 * 
 * @author Shashank Weginwar - SW3562
 */
public class AlertRuleDefinitionForm extends ActionForm {
	private static final String LEFT = "left";
	private static final String RIGHT = "right";
	private String dispatch;
	private String actionType = "UPDATE";
	private int stepNo;
	private List addToList = new ArrayList();
	private String [] leftFields;
	private String [] rightFields;
	private Tree tableTree;
	private String data;
	private String selectedAlertTypes;
	private List alertTypeOptionsList = new ArrayList();
	private int deleteIndex;
	private List alertKeyLevelList = new ArrayList();
	private String type;
	private String chkGW;
	private String checkFsq;
	private String checkTiming;
	private String alertRules;
	private AlertRuleDefinition alertRuleDefinition;
	private String checkSave = "0";
	private int relatedAlertsFlag = 1;
	private String existingData;
	private String reportLink;
	private List reportLinkList;
	//Variables added for calendar page.
	private String procDates;
	private String billRounds;
	private String holidayIndicators;
	private String loadedDataDates;
	private String billRndTables;
	private String alertUnit;
	private String selectedAlertRule;

	
	/**
	 * Default constructor.
	 */
	public AlertRuleDefinitionForm(){
		this.addToList.add(LEFT);
		this.addToList.add(RIGHT);
		this.alertKeyLevelList = RABCConstantsLists.getRABCConstantsLists().getKeyLevelList();
		this.alertTypeOptionsList = RABCConstantsLists.getRABCConstantsLists().getAlertTypeListForTrend();
		//this.reportLinkList = new ArrayList();
		//GG8573-- Added for testing concurrent modification exception
		this.reportLinkList = new FastArrayList();		
		this.billRndTables = "";
		this.alertUnit = "none";
	}
	
	/**
	 * @return String loadedDataDates
	 */			
	public String getLoadedDataDates() {
		return loadedDataDates;
	}

	/**
	 * @param loadedDataDates String
	 */
	public void setLoadedDataDates(String loadedDataDates) {
		this.loadedDataDates = loadedDataDates;
	}
	
	/**
	 * @return Returns the checkSave.
	 */
	public String getCheckSave() {
		return checkSave;
	}
	/**
	 * @param checkSave The checkSave to set.
	 */
	public void setCheckSave(String checkSave) {
		this.checkSave = checkSave;
	}
	/**
	 * @param alertTypeOptionsList The alertTypeOptionsList to set.
	 */
	public void setAlertTypeOptionsList(List alertTypeOptionsList) {
		this.alertTypeOptionsList = alertTypeOptionsList;
	}
	/**
	 * @return Returns the optionsList.
	 */
	public List getAlertTypeOptionsList() {
		return alertTypeOptionsList;
	}
	/**
	 * @return Returns the selectedAlertTypes.
	 */
	public String getSelectedAlertTypes() {
		return selectedAlertTypes;
	}
	/**
	 * @param selectedAlertTypes The selectedAlertTypes to set.
	 */
	public void setSelectedAlertTypes(String selectedAlertTypes) {
		this.selectedAlertTypes = selectedAlertTypes;
	}
	/**
	 * @return Returns the actionType.
	 */
	public String getActionType() {
		return actionType;
	}
	/**
	 * @param actionType The actionType to set.
	 */
	public void setActionType(String actionType) {
		this.actionType = actionType;
	}
	/**
	 * 
	 * @return Returns the addToList.
	 */
	public List getAddToList() {
		return addToList;
	}
	/**
	 * @param addToList The addToList to set.
	 */
	public void setAddToList(List addToList) {
		this.addToList = addToList;
	}
	/**
	 * @return Returns the alertKeyLevelList.
	 */
	public List getAlertKeyLevelList() {
		return alertKeyLevelList;
	}
	/**
	 * @param alertKeyLevelList The alertKeyLevelList to set.
	 */
	public void setAlertKeyLevelList(List alertKeyLevelList) {
		this.alertKeyLevelList = alertKeyLevelList;
	}
	/**
	 * @return Returns the alertRuleDefinition.
	 */
	public AlertRuleDefinition getAlertRuleDefinition() {
		return alertRuleDefinition;
	}
	/**
	 * @param alertRuleDefinition The alertRuleDefinition to set.
	 */
	public void setAlertRuleDefinition(AlertRuleDefinition alertRuleDefinition) {
		this.alertRuleDefinition = alertRuleDefinition;
	}
	/**
	 * @return Returns the dispatch.
	 */
	public String getDispatch() {
		return dispatch;
	}
	/**
	 * @param dispatch The dispatch to set.
	 */
	public void setDispatch(String dispatch) {
		this.dispatch = dispatch;
	}
	/**
	 * @return Returns the leftFields.
	 */
	public String[] getLeftFields() {
		return leftFields;
	}
	/**
	 * @param leftFields The leftFields to set.
	 */
	public void setLeftFields(String[] leftFields) {
		this.leftFields = leftFields;
	}
	/**
	 * @return Returns the rightFields.
	 */
	public String[] getRightFields() {
		return rightFields;
	}
	/**
	 * @param rightFields The rightFields to set.
	 */
	public void setRightFields(String[] rightFields) {
		this.rightFields = rightFields;
	}
	/**
	 * @return Returns the stepNo.
	 */
	public int getStepNo() {
		return stepNo;
	}
	/**
	 * @param stepNo The stepNo to set.
	 */
	public void setStepNo(int stepNo) {
		this.stepNo = stepNo;
	}
	/**
	 * @return Returns the tree.
	 */
	public Tree getTableTree() {
		return tableTree;
	}
	/**
	 * @param tree The tree to set.
	 */
	public void setTableTree(Tree tableTree) {
		this.tableTree = tableTree;
	}
	/**
	 * @return Returns the data.
	 */
	public String getData() {
		return data;
	}
	/**
	 * @param data The data to set.
	 */
	public void setData(String data) {
		this.data = data;
	}
	/**
	 * @return Returns the deleteIndex.
	 */
	public int getDeleteIndex() {
		return deleteIndex;
	}
	/**
	 * @param deleteIndex The deleteIndex to set.
	 */
	public void setDeleteIndex(int deleteIndex) {
		this.deleteIndex = deleteIndex;
	}
	/**
	 * @return Returns the type.
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type The type to set.
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * @return Returns the chkGW.
	 */
	public String getChkGW() {
		return chkGW;
	}
	/**
	 * @param chkGW The chkGW to set.
	 */
	public void setChkGW(String chkGW) {
		this.chkGW = chkGW;
	}
	/**
	 * @return Returns the checkFsq.
	 */
	public String getCheckFsq() {
		return checkFsq;
	}
	/**
	 * @param checkFsq The checkFsq to set.
	 */
	public void setCheckFsq(String checkFsq) {
		this.checkFsq = checkFsq;
	}
	/**
	 * @return Returns the checkTiming.
	 */
	public String getCheckTiming() {
		return checkTiming;
	}
	/**
	 * @param checkTiming The checkTiming to set.
	 */
	public void setCheckTiming(String checkTiming) {
		this.checkTiming = checkTiming;
	}
	/**
	 * @return Returns the alertRules.
	 */
	public String getAlertRules() {
		return alertRules;
	}
	/**
	 * @param alertRules The alertRules to set.
	 */
	public void setAlertRules(String alertRules) {
		this.alertRules = alertRules;
	}
	/**
	 * @return Returns the relatedAlertsFlag.
	 */
	public int getRelatedAlertsFlag() {
		return relatedAlertsFlag;
	}
	/**
	 * @param relatedAlertsFlag The relatedAlertsFlag to set.
	 */
	public void setRelatedAlertsFlag(int relatedAlertsFlag) {
		this.relatedAlertsFlag = relatedAlertsFlag;
	}
	/**
	 * @return Returns the existingData.
	 */
	public String getExistingData() {
		return existingData;
	}
	/**
	 * @param existingData The existingData to set.
	 */
	public void setExistingData(String existingData) {
		this.existingData = existingData;
	}
	/**
	 * @return Returns the reportLink.
	 */
	public String getReportLink() {
		return reportLink;
	}
	/**
	 * @param reportLink The reportLink to set.
	 */
	public void setReportLink(String reportLink) {
		this.reportLink = reportLink;
	}
	/**
	 * @return Returns the reportLinkList.
	 */
	public List getReportLinkList() {
		return reportLinkList;
	}
	/**
	 * @param reportLink The reportLink to add.
	 */
	public void addReportLink(PickList reportLink) {
		this.reportLinkList.add(reportLink);
	}
	
	/**
	 * @return Returns the billRounds.
	 */
	public String getBillRounds() {
		return billRounds;
	}
	/**
	 * @param billRounds The billRounds to set.
	 */
	public void setBillRounds(String billRounds) {
		this.billRounds = billRounds;
	}
	/**
	 * @return Returns the holidayIndicators.
	 */
	public String getHolidayIndicators() {
		return holidayIndicators;
	}
	/**
	 * @param holidayIndicators The holidayIndicators to set.
	 */
	public void setHolidayIndicators(String holidayIndicators) {
		this.holidayIndicators = holidayIndicators;
	}
	/**
	 * @return Returns the procDates.
	 */
	public String getProcDates() {
		return procDates;
	}
	/**
	 * @param procDates The procDates to set.
	 */
	public void setProcDates(String procDates) {
		this.procDates = procDates;
	}

	/**
	 * @return Returns the billRndTables.
	 */
	public String getBillRndTables() {
		return billRndTables;
	}
	/**
	 * @param billRndTables The billRndTables to set.
	 */
	public void setBillRndTables(String billRndTables) {
		this.billRndTables = billRndTables;
	}

	/**
	 * @return the alertUnit
	 */
	public String getAlertUnit() {
		return alertUnit;
	}

	/**
	 * @param alertUnit the alertUnit to set
	 */
	public void setAlertUnit(String alertUnit) {
		this.alertUnit = alertUnit;
	}

	public String getSelectedAlertRule() {
		return selectedAlertRule;
	}

	public void setSelectedAlertRule(String selectAlertRule) {
		this.selectedAlertRule = selectAlertRule;
	}
}
