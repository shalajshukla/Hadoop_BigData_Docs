package com.att.bac.rabc.load.rbs;

import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

import com.att.bac.rabc.util.EmcisEventLogger;
import com.att.carat.util.NetUtil;
import com.att.carat.util.Email;
import com.att.carat.util.JDBCUtil;
import com.sbc.bac.rabc.load.CheckDB2Extract;
import com.sbc.bac.rabc.load.RabcLoadJobTrig;


/*
 * Extract USOC data from DB2 table from MVS and load it into RABC tale . 
 *
 * This job will extract DB2 table data into RABC_RBS_USOC_DTL table by running query from RABC_DATA_EXTRCT_QUERY
 * table. This table holds the extraction query .. Run is controlled by FILE ID. File ID for scheduled jobs are defined in 
 * RABC_DATA_EXTRCT_SCHEDULE. which is the primary key  for table RABC_DATA_EXTRCT_QUERY .. 
 *
 */

public class MWrbsUSOCExchDtlJob extends CheckDB2Extract {
    private static final int RECUR_CHRG_AMT = 8;
    private static final int RECUR_CREDIT_AMT = 12;
    private static final int NON_RECUR_CHRG_AMT = 26;
    private static final int NON_RECUR_CREDIT_AMT = 28;
    private static final String EXCHANGE_SQL = "" //
        + " SELECT DISTINCT EXCHANGE, "//
        + "                 atn_npa||atn_nxx key "//        
        + " FROM            bartp6$$.gobbtnus "//
        + " WHERE           run_type = '0' "//
        + " AND             bill_date = ? "//
        + " AND             state_id = ? "//
        + " AND             pg = ? ";

    private PreparedStatement insertDB2Extracts = null;

    private static final long DAY_IN_MILLI_SEC = 86400 * 1000;

    private Date billDate;

    private String division, billRnd;

    private Map<String, String> exchangeMap;


    /*
     * (non-Javadoc)
     * 
     * @see com.sbc.bac.rabc.load.CheckDB2Extract#preprocess()
     */
    protected boolean preprocess() {

        boolean success = super.preprocess();
        if (success) {
            try {

                insertDB2Extracts = ORAconnection.prepareStatement(""//
                    + " INSERT INTO RABC_RBS_EXCH_DTL "//
                    + " ( RUN_DATE, DIVISION, BILL_RND, USOC, BUS_TYPE, RECUR_CHRG_AMT, RECUR_CHRG_QTY, "//
                    + " RECUR_CREDIT_AMT, RECUR_CREDIT_QTY, NON_RECUR_CHRG_AMT, NON_RECUR_CHRG_QTY, "//
                    + " NON_RECUR_CREDIT_AMT, NON_RECUR_CREDIT_QTY, DSCT_AMT, exch_cd )" //
                    + " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ");

            } catch (SQLException e) {
                severe("Exception while creating statements " + e, e);
                success = false;
            }
        }
        return success;
    }


    /*
     * (non-Javadoc)
     * 
     * @see com.att.carat.load.LoadJob#action()
     */
    @SuppressWarnings("deprecation")
    protected boolean action() {

        ResultSet scheduledJobs = null;
        boolean status = true;
        boolean returnStatus = true;

        try {

            // get check SQL and extract SQL for given file ID.
            getExtractQry.setString(1, getFile_id());
            scheduledJobs = getExtractQry.executeQuery();
            if (!scheduledJobs.next())
                return false;

            String sourceTable = scheduledJobs.getString("EXTRCT_TO_TBL");
            String checkSQL = scheduledJobs.getString("CHECK_QUERY");
            String insertSQL = scheduledJobs.getString("EXTRACT_QUERY");

            // check if schedule job is ready to run. If YES, then extract the schedule and loop thru per division
            if (isScheduledRun()) {
                setScheduledRun(false);

                getExtractSchedule.setString(1, getFile_id());
                scheduledJobs = getExtractSchedule.executeQuery();

                while (scheduledJobs.next()) {

                    // Why to convert between DIVISION & STATE?
                    // Because, division ( like I for INdiana ) used in RABC, state Like IN is used in MVS .. Since
                    // this conversion don't match with DIVISION table need to keep a hash map ref.

                    division = scheduledJobs.getString("DIVISION");
                    String state = DIVISION_MAP.get(scheduledJobs.getString("DIVISION")).toString();
                    billRnd = scheduledJobs.getString("BILL_RND");
                    if (billRnd.length() == 1)
                        billRnd = "0" + billRnd;
                    // billDate = scheduledJobs.getDate("BILL_RND_DT");
                    billDate = getBillroundDate(scheduledJobs.getDate("BILL_RND_DT"), billRnd);

                    String extractTimeInd = scheduledJobs.getString("EXTRCT_TIME_IND");
                    Date procDt = scheduledJobs.getDate("PROC_DT");

                    boolean skip_load = false;

                    status = db2TableCheck(state, billDate, billRnd, checkSQL);
                    status &= populateExchangeMap(DB2connection, state, billDate, billRnd);
                    status &= processScheduledExtract(state, billDate, billRnd, sourceTable, insertSQL);

                    // If this job still failing to extract data because of any reason schedule for next run and
                    // fire a mail to Recipients from config.
                    if (System.currentTimeMillis() - billDate.getTime() > 5 * DAY_IN_MILLI_SEC && !status) {
                        updateSchedule(extractTimeInd, procDt, billRnd, division);
                        Email.sendEmail(notify_users, "DB2 extraction SKIPPED for DIVISION >> " + division + " for FILEID - " + getFile_id(), " Please Investigate MW ACIS/CAMPS contact -- "
                            + billDate.toString());
                        info("DB2 extraction SKIPPED for DIVISION >> " + division + " for FILEID - " + getFile_id());
                        sendAlertMessage(getFile_id(), division, billDate, "skipping DB2 data load to TBL: RABC_RBS_USOC_DTL");
                        skip_load = true;
                    } else
                        status = status && updateSchedule(extractTimeInd, procDt, billRnd, division);

                    if (skip_load)
                        insertExtractCompLog(division, billDate, billRnd, getFile_id(), sourceTable, skip_load);
                    else
                        status = status && insertExtractCompLog(division, billDate, billRnd, getFile_id(), sourceTable, skip_load);

                    status = status && insertTrigger();
                }
            }

            // check if for the given FILEID any of the loads need to rerun to extract data ..
            if (isRerunInd()) {
                setRerunInd(false);

                getRerunLog.setString(1, getFile_id());
                scheduledJobs = getRerunLog.executeQuery();

                while (scheduledJobs.next()) {
                    division = scheduledJobs.getString("DIVISION");
                    String state = DIVISION_MAP.get(scheduledJobs.getString("DIVISION")).toString();
                    billDate = scheduledJobs.getDate("RUN_DATE");
                    billRnd = scheduledJobs.getString("BILL_RND");
                    status = db2TableCheck(state, billDate, billRnd, checkSQL);
                    status = status && deleteRerunData(division, billDate, billRnd, sourceTable);
                    status = status && populateExchangeMap(DB2connection, state, billDate, billRnd);
                    status = status && processScheduledExtract(state, billDate, billRnd, sourceTable, insertSQL);
                    status = status && insertTrigger();
                    // reset rerun INDICATOR to NULL once rerun completed.
                    if (status) {
                        updateRerunLog.setString(1, getFile_id());
                        updateRerunLog.setDate(2, billDate);
                        updateRerunLog.setString(3, division);
                        updateRerunLog.executeUpdate();
                    }

                }

            }

        } catch (SQLException e) {
            severe("Exception in Action process " + e, e);
            returnStatus = false;
        } catch (ParseException e) {
            warning("Parse exception"+ e);
        } finally {
            JDBCUtil.closeResultSet(scheduledJobs);
        }

        return returnStatus;
    }


    /**
     * @param db2connection
     * @param billRnd
     * @param billDate
     * @param state
     */
    private boolean populateExchangeMap(Connection db2connection, String state, Date billDate, String billRnd) {
        boolean ok = true;
        exchangeMap = new HashMap<String, String>();
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = db2connection.prepareStatement(EXCHANGE_SQL);
            ps.setDate(1, billDate);
            ps.setString(2, state);
            ps.setString(3, billRnd);
            rs = ps.executeQuery();
            while (rs.next()) {
                exchangeMap.put(rs.getString("key"), rs.getString("exchange"));
            }
        } catch (SQLException e) {
            ok = false;
            severe("Error populating exchangeMap"+ e);
        } finally {
            JDBCUtil.closeResultSet(rs);
            JDBCUtil.closePreparedStatement(ps);
        }
        return ok;
    }


    /**
     * @param state
     * @param billDate
     * @param billRnd
     * @param checkSQL
     * @return
     */
    private boolean db2TableCheck(String state, Date billDate, String billRnd, String checkSQL) {

        boolean status = false;
        ResultSet db2Check = null;
        PreparedStatement checkForDB2Data = null;

        try {

            checkForDB2Data = DB2connection.prepareStatement(checkSQL);

            checkForDB2Data.setDate(1, billDate);
            checkForDB2Data.setString(2, state);
            checkForDB2Data.setString(3, billRnd);
            checkForDB2Data.setDate(4, billDate);
            checkForDB2Data.setString(5, state);
            checkForDB2Data.setString(6, billRnd);

            db2Check = checkForDB2Data.executeQuery();

            // check for DB2 table(s) already loaded with RUN_DATE data..
            // removed the check for CNT2 ( table:GOBBTAS3 )which is a DISCOUNT info. Which may or may not have values
            // in it
            if (db2Check.next())
                // if (db2Check.getInt("CNT1") > 0 && db2Check.getInt("CNT2") > 0) {
                if (db2Check.getInt("CNT1") > 0) {
                    status = true;
                }
        } catch (SQLException e) {
            severe("Exception while processing ResultSet " + e, e);
            return false;
        } finally {
            JDBCUtil.closeResultSet(db2Check);
            JDBCUtil.closePreparedStatement(checkForDB2Data);
        }

        return status;
    }


    /**
     * @param state
     * @param billDate
     * @param billRnd
     * @param sourceTable
     * @param insertSQL
     * @return
     */
    private boolean processScheduledExtract(String state, Date billDate, String billRnd, String sourceTable, String insertSQL) {

        ResultSet rs = null;
        PreparedStatement db2Extract = null;

        try {
            // db2Extract = DB2connection.prepareStatement(config.getProperty(sourceTable));
            db2Extract = DB2connection.prepareStatement(insertSQL);

            db2Extract.setDate(1, billDate);
            db2Extract.setString(2, state);
            db2Extract.setString(3, billRnd);
            db2Extract.setDate(4, billDate);
            db2Extract.setString(5, state);
            db2Extract.setString(6, billRnd);

            rs = db2Extract.executeQuery();

            int recordCnt = 0;
//            String key = null;
//            String prevUsocpgbus = null;
            

//            MWrbsUSOCData usocData = new MWrbsUSOCData();

            while (rs.next()) {
                recordCnt++;

                insertDB2Extracts.setDate(1, rs.getDate("BILL_DATE"));
                insertDB2Extracts.setString(2, DIVISION_MAP.get(rs.getString("STATE_ID")).toString());
                insertDB2Extracts.setInt(3, Integer.parseInt(rs.getString("PG")));
                insertDB2Extracts.setString(4, rs.getString("USOC").trim());
                insertDB2Extracts.setString(5, rs.getString("BUS_TYPE"));
                insertDB2Extracts.setDouble(14, rs.getDouble("DSCT_AMT"));
                insertDB2Extracts.setString(15, exchangeMap.get(rs.getString("exchangeKey")));
                
                int cat = rs.getInt("OCC_CATEGORY");
                double amt = rs.getDouble("BILLED_AMT_BY_CAT");
                int qty = rs.getInt("QUANTITY_BY_CAT");
                switch(cat) {
                    case RECUR_CHRG_AMT:
                        insertDB2Extracts.setDouble(6, amt);
                        insertDB2Extracts.setInt(7, qty);
                        insertDB2Extracts.setDouble(8, 0);
                        insertDB2Extracts.setInt(9, 0);
                        insertDB2Extracts.setDouble(10, 0);
                        insertDB2Extracts.setInt(11, 0);
                        insertDB2Extracts.setDouble(12, 0);
                        insertDB2Extracts.setInt(13, 0);
                        break;
                    case RECUR_CREDIT_AMT:
                        insertDB2Extracts.setDouble(6, 0);
                        insertDB2Extracts.setInt(7, 0);
                        insertDB2Extracts.setDouble(8, amt);
                        insertDB2Extracts.setInt(9, qty);
                        insertDB2Extracts.setDouble(10, 0);
                        insertDB2Extracts.setInt(11, 0);
                        insertDB2Extracts.setDouble(12, 0);
                        insertDB2Extracts.setInt(13, 0);
                        break;
                    case NON_RECUR_CHRG_AMT:
                        insertDB2Extracts.setDouble(6, 0);
                        insertDB2Extracts.setInt(7, 0);
                        insertDB2Extracts.setDouble(8, 0);
                        insertDB2Extracts.setInt(9, 0);
                        insertDB2Extracts.setDouble(10, amt);
                        insertDB2Extracts.setInt(11, qty);
                        insertDB2Extracts.setDouble(12, 0);
                        insertDB2Extracts.setInt(13, 0);
                        break;
                    case NON_RECUR_CREDIT_AMT:
                        insertDB2Extracts.setDouble(6, 0);
                        insertDB2Extracts.setInt(7, 0);
                        insertDB2Extracts.setDouble(8, 0);
                        insertDB2Extracts.setInt(9, 0);
                        insertDB2Extracts.setDouble(10, 0);
                        insertDB2Extracts.setInt(11, 0);
                        insertDB2Extracts.setDouble(12, amt);
                        insertDB2Extracts.setInt(13, qty);
                        break;
                    default:
                         severe("OCC_CATEGORY unknown: " + cat);
                }
                
                insertDB2Extracts.addBatch();

                if (recordCnt % 1000 == 0) {
                    insertDB2Extracts.executeBatch();
                }
            }
                
            if (recordCnt > 0) {
                insertDB2Extracts.executeBatch();
            }

            info(" number of records processed on: " + billDate.toString() + " for table - " + sourceTable + " - for STATE << " + state + " >> " + recordCnt);
                
            
//                
//                
//                
//                
//                
//                
//                key = rs.getString("USOC").trim() + rs.getString("PG").trim() + rs.getString("BUS_TYPE").trim() + rs.getString("exchangeKey").trim();
//
//                if (prevUsocpgbus == null) {
//                    prevUsocpgbus = key;
//                    usocData.setBillDate(rs.getDate("BILL_DATE"));
//                    usocData.setStateId(DIVISION_MAP.get(rs.getString("STATE_ID")).toString());
//                    usocData.setProcessGroup(Integer.parseInt(rs.getString("PG")));
//                    usocData.setUsoc(rs.getString("USOC").trim());
//                    usocData.setBusType(rs.getString("BUS_TYPE"));
//                    usocData.setDiscountAmt(rs.getDouble("DSCT_AMT"));
//                    usocData.setExchCD(exchangeMap.get(rs.getString("exchangeKey")));
//                } else if (!prevUsocpgbus.equals(key)) {
//                    insertDB2Extracts.setDate(1, usocData.getBillDate());
//                    insertDB2Extracts.setString(2, usocData.getStateId());
//                    insertDB2Extracts.setInt(3, usocData.getProcessGroup());
//                    insertDB2Extracts.setString(4, usocData.getUsoc());
//                    insertDB2Extracts.setString(5, usocData.getBusType());
//                    insertDB2Extracts.setDouble(14, usocData.getDiscountAmt());
//                    insertDB2Extracts.setDouble(6, usocData.getBilled_amt(RECUR_CHRG_AMT));
//                    insertDB2Extracts.setInt(7, usocData.getBilled_qty(RECUR_CHRG_AMT));
//                    insertDB2Extracts.setDouble(8, usocData.getBilled_amt(RECUR_CREDIT_AMT));
//                    insertDB2Extracts.setInt(9, usocData.getBilled_qty(RECUR_CREDIT_AMT));
//                    insertDB2Extracts.setDouble(10, usocData.getBilled_amt(NON_RECUR_CHRG_AMT));
//                    insertDB2Extracts.setInt(11, usocData.getBilled_qty(NON_RECUR_CHRG_AMT));
//                    insertDB2Extracts.setDouble(12, usocData.getBilled_amt(NON_RECUR_CREDIT_AMT));
//                    insertDB2Extracts.setInt(13, usocData.getBilled_qty(NON_RECUR_CREDIT_AMT));
//                    insertDB2Extracts.setString(15, usocData.getExchCD());
//                    insertDB2Extracts.addBatch();
//
//                    if (recordCnt % 1000 == 0) {
//                        insertDB2Extracts.executeBatch();
//                    }
//                    prevUsocpgbus = key;
//                    usocData = new MWrbsUSOCData();
//                    usocData.setBillDate(rs.getDate("BILL_DATE"));
//                    usocData.setStateId(DIVISION_MAP.get(rs.getString("STATE_ID")).toString());
//                    usocData.setProcessGroup(Integer.parseInt(rs.getString("PG")));
//                    usocData.setUsoc(rs.getString("USOC").trim());
//                    usocData.setBusType(rs.getString("BUS_TYPE"));
//                    usocData.setDiscountAmt(rs.getDouble("DSCT_AMT"));
//                    usocData.setExchCD(exchangeMap.get(rs.getString("exchangeKey")));
//                }
//                usocData.setBilled_amt_qty(rs.getInt("OCC_CATEGORY"), rs.getDouble("BILLED_AMT_BY_CAT"), rs.getInt("QUANTITY_BY_CAT"));
//            }
//
//            if (prevUsocpgbus != null) {
//
//                insertDB2Extracts.setDate(1, usocData.getBillDate());
//                insertDB2Extracts.setString(2, usocData.getStateId());
//                insertDB2Extracts.setInt(3, usocData.getProcessGroup());
//                insertDB2Extracts.setString(4, usocData.getUsoc());
//                insertDB2Extracts.setString(5, usocData.getBusType());
//                insertDB2Extracts.setDouble(14, usocData.getDiscountAmt());
//                insertDB2Extracts.setDouble(6, usocData.getBilled_amt(RECUR_CHRG_AMT));
//                insertDB2Extracts.setInt(7, usocData.getBilled_qty(RECUR_CHRG_AMT));
//                insertDB2Extracts.setDouble(8, usocData.getBilled_amt(RECUR_CREDIT_AMT));
//                insertDB2Extracts.setInt(9, usocData.getBilled_qty(RECUR_CREDIT_AMT));
//                insertDB2Extracts.setDouble(10, usocData.getBilled_amt(NON_RECUR_CHRG_AMT));
//                insertDB2Extracts.setInt(11, usocData.getBilled_qty(NON_RECUR_CHRG_AMT));
//                insertDB2Extracts.setDouble(12, usocData.getBilled_amt(NON_RECUR_CREDIT_AMT));
//                insertDB2Extracts.setInt(13, usocData.getBilled_qty(NON_RECUR_CREDIT_AMT));
//                insertDB2Extracts.setString(15, usocData.getExchCD());
//
//                insertDB2Extracts.addBatch();
//
//            }
//
//            if (recordCnt > 0) {
//                insertDB2Extracts.executeBatch();
//            }
//
//            info(" number of records processed on: " + billDate.toString() + " for table - " + sourceTable + " - for STATE << " + state + " >> " + recordCnt);

        } catch (SQLException e) {
            severe("Exception while processing ResultSet " + e, e);
            return false;
        } finally {
            JDBCUtil.closePreparedStatement(db2Extract);
            JDBCUtil.closeResultSet(rs);
        }

        return true;

    }


    // insert Trigger to RABC_TRIG table.
    private boolean insertTrigger() {
        DateFormat df = new SimpleDateFormat("MMddyyyy");
        String run_date = df.format(billDate);
        SimpleDateFormat sdf_for_Time = new SimpleDateFormat("HHmmss");
        SimpleDateFormat sdf_for_Date = new SimpleDateFormat("yyyyDDD");

        String file_name = getFile_id() + ".D" + sdf_for_Date.format(new java.util.Date().getTime()) + ".T" + sdf_for_Time.format(new java.util.Date().getTime()) + ".TXT";

        if (!RabcLoadJobTrig.insertTrigger(ORAconnection, file_name, getFile_id(), division, run_date, null, billRnd))
            return false;

        return true;

    }


    /*
     * (non-Javadoc)
     * 
     * @see com.sbc.bac.rabc.load.CheckDB2Extract#postprocess(boolean)
     */
    protected boolean postprocess(boolean success) {
        JDBCUtil.closePreparedStatement(insertDB2Extracts);
        
        try{
			//Log the file information to EMCIS_EVENT_LOG and EMCIS_EVENT_LOG_DETAIL
			EmcisEventLogger emcisLogger = new EmcisEventLogger();
			String event_id = "RABC_RBSXDTL_MW";
            String host = NetUtil.getLocalHostName();
            String hostIP = NetUtil.getLocalIpAddress();
			int sequence = emcisLogger.getEMCISSequence(ORAconnection);
			emcisLogger.insertEventLog(ORAconnection, sequence, event_id, billDate, host, hostIP);
			emcisLogger.insertEventLogDetail(ORAconnection, sequence, "DB", "RBS-"+new java.sql.Date(new java.util.Date().getTime()));
		}catch (UnknownHostException e) {
            severe("Error getting EMCIS host information ", e);
        }
        success = super.postprocess(success);
        return success;
    }

}
