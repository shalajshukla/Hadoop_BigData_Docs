package com.att.bac.rabc.load.sw;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import com.att.carat.util.Email;
import com.att.carat.util.JDBCUtil;
import com.sbc.bac.rabc.load.CheckEDWExtract;
import com.sbc.bac.rabc.load.RabcLoadJobTrig;

public class SWMoBLTtaxDtlJob  extends CheckEDWExtract{

	private PreparedStatement selectEDW = null;
	private PreparedStatement insertEDWExtracts = null;
	private PreparedStatement insertEDWExtractsMOB = null;
	private static final long DAY_IN_MILLI_SEC = 86400*1000;
	
//	private Date billDate;
	private Date procDt;
//	private String sBillDate;
	private String division, billRnd;
	 	
	protected boolean preprocess(){
		
		boolean success = super.preprocess();
		if(success){
			try {
				insertEDWExtracts = ORAconnection.prepareStatement(" INSERT INTO  RABC_ACCT_MO_BLT_DTL  " +
						" ( RUN_DATE, DIVISION, BTN, BILL_RND, CUST_TYPE_CD, TAR_CD, ENTITY_CD, BLT_TAX_AMNT, TAX_EXMPT_CD) " +
						" VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?) ");
				
				insertEDWExtractsMOB = ORAconnection.prepareStatement(" INSERT INTO  RABC_ACCT_MO_BLT_DTL_LD  " +
						" ( RUN_DATE, DIVISION, BTN, BILL_RND, CUST_TYPE_CD, TAR_CD, ENTITY_CD, BLT_TAX_AMNT, TAX_EXMPT_CD) " +
						" VALUES (TRUNC(SYSDATE-1), ?, ?, ?, ?, ?, ?, ?, ?) ");
				
				 selectEDW = EDWconnection.prepareStatement("select  J.BAN, sum(financial_activity_amt) AMOUNT, "+
						 " j.dw_load_dt, btn_npa_cd ||  btn_nxx_cd ||btn_line_nbr || btn_customer_cd  BTN , "+
						 " customer_type,TAX_EXEMPTION_CD "+
						 " from    LD_access_views.VCLF001_JOURNAL J , LD_access_views.VCCR137_TAX_TYPE T, "+ 
						 " LD_ACCESS_VIEWS.VSLC007_BILLING_ACCOUNT A "+
						 " where "+ 
						 " tax_type_nm = 'MUNICIPAL GROSS RECEIPTS SURCHARGE' "+
						 " and    state_cd = 'MO' "+  
						
						 " and    state_tax_geographical_cd = '26' "+ 
						 " and    tax_type_cd = '51' "+ 
						 " and    tax_authority_cd = '3' "+ 
						 " and "+ 
						 " (DEBITED_TAX_AUTHORITY_CD = 2 "+ 
						 " or    DEBITED_TAX_AUTHORITY_CD = 3 "+ 
						 " or "+ 
						 " CREDITED_TAX_AUTHORITY_CD = 2 "+ 
						 " or    CREDITED_TAX_AUTHORITY_CD = 3) "+ 
						 " AND "+ 
						 " (CREDITED_TAX_TYPE_STATE_GEO_CD = 0826 "+ 
						 " or  DEBITED_TAX_TYPE_STATE_GEO_CD = 0826) "+ 
						                            
						 " and A.BAN = J.BAN  "+
						 " and "+ 
						 "  j.dw_load_dt= cast(current_date-1  as date format 'mmddyyyy') "+  
						 " group by J.BAN, j.dw_load_dt, btn_npa_cd ||  btn_nxx_cd ||btn_line_nbr || btn_customer_cd , "+ 
						 " j.dw_load_dt,customer_type,TAX_EXEMPTION_CD ");
				
				
			} catch (SQLException e) {
				severe("Exception while creating statements "+e, e);
				success = false;
			}
		}
			return success;
	}
	

	protected boolean action() {

		ResultSet scheduledJobs = null;
		ResultSet extractScheduledJobs = null;
		ResultSet rerunScheduledJobs = null;
		boolean status = true;
		boolean statusMOB = true;
		boolean returnStatus = true;

		try {

			
			//code addition for new extract MO BLT
			
			statusMOB = getEDWData();
			if(statusMOB)
			{
				//do summarization and top 5 bottom 5
				 summarizeMoBltData();
				 processTopBottomFiveMoBltData();
				 insertTrigger(false);
			}
			
			
			// get check SQL and extract SQL for given file ID.  			
			getExtractQry.setString(1,getFile_id());
			scheduledJobs = getExtractQry.executeQuery();
			if (!scheduledJobs.next())
				return false;
				
			String sourceTable = scheduledJobs.getString("EXTRCT_TO_TBL");
			String checkSQL = scheduledJobs.getString("CHECK_QUERY");
			String extractSQL = scheduledJobs.getString("EXTRACT_QUERY");
			
			// check if schedule job is ready to run.  If YES, then extract the schedule and loop thru per division			
			if (isScheduledRun()) {
				setScheduledRun(false);
				
				getExtractSchedule.setString(1,getFile_id());
				extractScheduledJobs = getExtractSchedule.executeQuery();

				while (extractScheduledJobs.next()){

					// Why to convert between DIVISION & STATE? 	
					// Because, division ( like I for INdiana ) used in RABC, state Like IN is used in MVS .. Since 
					// this conversion don't match with DIVISION table need to keep a hash map ref.

					division = extractScheduledJobs.getString("DIVISION");
					//String state = DIVISION_MAP.get(scheduledJobs.getString("DIVISION")).toString();
					billRnd = extractScheduledJobs.getString("BILL_RND");
					if (billRnd.length() == 1)
						billRnd = "0"+billRnd;
					String sBillDate = extractScheduledJobs.getString("BILL_RND_DT");
					sBillDate = sBillDate.substring(0, 4) + sBillDate.substring(5, 7) + sBillDate.substring(8,10); 
					Date billDate = extractScheduledJobs.getDate("BILL_RND_DT"); 
//					billDate = getBillroundDate(scheduledJobs.getDate("BILL_RND_DT"), billRnd);
					  
					String extractTimeInd = extractScheduledJobs.getString("EXTRCT_TIME_IND");
					procDt = extractScheduledJobs.getDate("PROC_DT");
					
					boolean skip_load = false;
					
					status = edwTableCheck(division, sBillDate,billRnd, checkSQL);
					
					status = status && processScheduledExtract(division, sBillDate, billRnd, sourceTable, extractSQL, procDt);
					
					if (status && "RABC_ACCT_MO_BLT_DTL".equalsIgnoreCase(sourceTable)) {
						//do summarization and top 5 bottom 5
						 summarizeMoBltData(division, procDt, billRnd);
						 processTopBottomFiveMoBltData(division, procDt, billRnd);
					}
					
					// If this job still failing to extract data because of any reason schedule for next run and 
					// fire a mail to Recipients from config.
					if (System.currentTimeMillis() - billDate.getTime() > 5 * DAY_IN_MILLI_SEC && !status){
						updateSchedule(extractTimeInd, procDt, billRnd, division);
						Email.sendEmail(notify_users, "EDW extraction SKIPPED for DIVISION >> " + division + " for FILEID - " + getFile_id() , " Please Investigate SW MOBLT contact -- " + billDate.toString());
						info ("EDW extraction SKIPPED for DIVISION >> " + division + " for FILEID - " + getFile_id());
						sendAlertMessage(getFile_id(), division, billDate,"skipping EDW data load to TBL: RABC_ACCT_MO_BLT_DTL");
						skip_load = true;
					}
					else 
						status =  status && updateSchedule(extractTimeInd, procDt, billRnd, division);
					
					if (skip_load)
							insertExtractCompLog(division, procDt, billRnd, getFile_id(), sourceTable, skip_load);
					else 
							status = status && insertExtractCompLog(division, procDt, billRnd, getFile_id(), sourceTable, skip_load);
					
					status = status && insertTrigger(true);
				}
			}

			// check if for the given FILEID any of the loads need to rerun to extract data ..
			if (isRerunInd()){
				setRerunInd(false);
				
				getRerunLog.setString(1,getFile_id());
				rerunScheduledJobs = getRerunLog.executeQuery();
				
				while(rerunScheduledJobs.next()){
					division = rerunScheduledJobs.getString("DIVISION");
					//String state = DIVISION_MAP.get(scheduledJobs.getString("DIVISION")).toString();
//					String procDt = scheduledJobs.getString("RUN_DATE");
//					procDt = procDt.substring(0, 4) + procDt.substring(5, 7) + procDt.substring(8,10); 
					Date procDate = rerunScheduledJobs.getDate("RUN_DATE"); 
					procDt=procDate;
					billRnd = rerunScheduledJobs.getString("BILL_RND");

					String sBillDate = getBillDate(procDate); 
					status = edwTableCheck(division, sBillDate, billRnd, checkSQL);
					status = status && deleteRerunData(division, procDate, billRnd, sourceTable);
					status = status && processScheduledExtract(division, sBillDate, billRnd, sourceTable, extractSQL, procDate);
					if (status && "RABC_ACCT_MO_BLT_DTL".equalsIgnoreCase(sourceTable)) {
						//do summarization and top 5 bottom 5
						 deleteRerunData(division, procDate, billRnd, "rabc_mo_blt_sumy");
						 summarizeMoBltData(division, procDate, billRnd);
						 deleteRerunData(division, procDate, billRnd, "rabc_top_five_mo_blt");
						 processTopBottomFiveMoBltData(division, procDate, billRnd);
					}
					status = status && insertTrigger(true);
					//reset rerun INDICATOR to NULL once rerun completed.
					if(status){
						updateRerunLog.setString(1, getFile_id());
						updateRerunLog.setDate(2,procDate);
						updateRerunLog.setString(3, division);
						updateRerunLog.executeUpdate();
					}
					
				}
				
			}

			
				
		} catch (SQLException e) {
			severe("Exception in Action process "+e, e);
			returnStatus = false;
		} finally {
			JDBCUtil.closeResultSet(scheduledJobs);
			JDBCUtil.closeResultSet(extractScheduledJobs);
			JDBCUtil.closeResultSet(rerunScheduledJobs);
		}
		
		return returnStatus;
	}

	private String getBillDate(Date procDate) {
		ResultSet rs = null;
		PreparedStatement ps = null;
		String billDt=null;
		String selectSql = "SELECT BILL_RND_DT from RABC_CYCLE_CALENDAR where PROC_DT = ? ";
		try {
			ps = ORAconnection.prepareStatement(selectSql);
			ps.setDate(1, procDate);
			rs = ps.executeQuery();
			if (rs.next()) {
				billDt = rs.getString("BILL_RND_DT");
			}
			billDt = billDt.substring(0, 4) + billDt.substring(5, 7) + billDt.substring(8,10); 
			
		}  catch (SQLException e) {
			severe("Exception while processing ResultSet "+e, e);
		}finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
		return billDt;
	}
	
	private boolean edwTableCheck(String division, String billDate,String billRnd, String checkSQL){
		
		boolean status = false;
		ResultSet edwCheck = null;
		PreparedStatement checkForEDWData = null;
		
		try {
			
			checkForEDWData = EDWconnection.prepareStatement(checkSQL);
			
			checkForEDWData.setString(1,billRnd);
			checkForEDWData.setString(2,division);
			checkForEDWData.setString(3,billDate);
			
			
			edwCheck = checkForEDWData.executeQuery();

			// check for edw table(s) already loaded with RUN_DATE data..
//			 removed the check for CNT2 ( table:GOBBTAS3 )which is a DISCOUNT info. Which may or may not have values in it
			if (edwCheck.next())
				//if (edwCheck.getInt("CNT1") > 0 && edwCheck.getInt("CNT2") > 0) {
				if (edwCheck.getInt(1) > 0 ) {					
					status = true;
				}
		}  catch (SQLException e) {
			severe("Exception while processing ResultSet "+e, e);
			return false;
		}finally {
			JDBCUtil.closeResultSet(edwCheck);
			JDBCUtil.closePreparedStatement(checkForEDWData);
		}
		
		return status;
	}
	
	private boolean processScheduledExtract(String division, String sBillDate, String billRnd, String sourceTable, String insertSQL, Date procDt){
		
	
		ResultSet edwExtractedData = null;
		PreparedStatement edwExtract = null;
		
		try {
			//edwExtract = EDWConnection.prepareStatement(config.getProperty(sourceTable));
			edwExtract = EDWconnection.prepareStatement(insertSQL);
			edwExtract.setString(1,billRnd);
			edwExtract.setString(2,division);
			edwExtract.setString(3,sBillDate);
			
			edwExtractedData = edwExtract.executeQuery();
			
			int recordCnt = 0;
			
			while (edwExtractedData.next()){
				recordCnt++;

				//RUN_DATE, DIVISION, BTN, BILL_RND, CUST_TYPE_CD, TAR_CD, ENTITY_CD, BLT_TAX_AMNT
				//cycle dt = proc date
//					insertEDWExtracts.setDate(1,edwExtractedData.getDate("CYCLE_DT"));
					insertEDWExtracts.setDate(1,procDt);
					insertEDWExtracts.setString(2,division);
					insertEDWExtracts.setString(3,edwExtractedData.getString("NPA")+edwExtractedData.getString("NXX")+edwExtractedData.getString("LINE"));
					insertEDWExtracts.setString(4,billRnd);
					insertEDWExtracts.setString(5,edwExtractedData.getString("cust_type"));
					insertEDWExtracts.setString(6,edwExtractedData.getString("TAX_AREA_CODE"));
					insertEDWExtracts.setString(7,edwExtractedData.getString("ENTITY_CD"));
					insertEDWExtracts.setDouble(8,edwExtractedData.getDouble("BILLED_AMT"));
					insertEDWExtracts.setString(9,edwExtractedData.getString("TAX_EXMPT_CD"));
					insertEDWExtracts.addBatch();
					
					if (recordCnt % 1000 == 0) {
						insertEDWExtracts.executeBatch();
					}
			}

			if (recordCnt > 0)
				insertEDWExtracts.executeBatch();
			
			info (" number of records processed for bill rnd date: " + sBillDate + " for table - " + sourceTable + " - for DIVISION << " + division + " >> " + recordCnt);
			
		} catch (SQLException e) {
			severe("Exception while processing ResultSet "+e, e);
			return false;
		}finally {
			JDBCUtil.closePreparedStatement(edwExtract);
			JDBCUtil.closeResultSet(edwExtractedData);
		}
		
		return true;		
		
	}

	private void processTopBottomFiveMoBltData(String division, Date procDate, String billRnd){
		String topBottomSQL = "INSERT INTO rabc_top_five_mo_blt " +
								"            (run_date, division, btn, bill_rnd, cust_type_cd, tar_cd, " +
								"             entity_cd, blt_tax_amnt, ranking) " +
								"   (SELECT run_date, division, btn, bill_rnd, cust_type_cd, tar_cd, entity_cd, " +
								"           blt_tax_amnt, " +
								"           ROW_NUMBER () OVER (PARTITION BY run_date, division, bill_rnd, cust_type_cd, tar_cd, entity_cd ORDER BY blt_tax_amnt DESC) " +
								"                                                                      ranking " +
								"      FROM (SELECT run_date, division, btn, bill_rnd, cust_type_cd, tar_cd, " +
								"                   entity_cd, blt_tax_amnt                   " +
								"              FROM (SELECT run_date, division, btn, bill_rnd, cust_type_cd, " +
								"                           tar_cd, entity_cd, blt_tax_amnt, " +
								"                           ROW_NUMBER () OVER (PARTITION BY run_date, division, bill_rnd, cust_type_cd, tar_cd, entity_cd ORDER BY blt_tax_amnt DESC) " +
								"                                                                        srlno " +
								"                      FROM rabc_acct_mo_blt_dtl where bill_rnd = ? and run_date = ? and division = ? ) " +
								"             WHERE srlno <= 5 " +
								"            UNION " +
								"            SELECT run_date, division, btn, bill_rnd, cust_type_cd, tar_cd, " +
								"                   entity_cd, blt_tax_amnt                " +
								"              FROM (SELECT run_date, division, btn, bill_rnd, cust_type_cd, " +
								"                           tar_cd, entity_cd, blt_tax_amnt, " +
								"                           ROW_NUMBER () OVER (PARTITION BY run_date, division, bill_rnd, cust_type_cd, tar_cd, entity_cd ORDER BY blt_tax_amnt ASC) " +
								"                                                                        srlno " +
								"                      FROM rabc_acct_mo_blt_dtl where bill_rnd = ? and run_date = ? and division = ? ) " +
								"             WHERE srlno <= 5)) ";

		PreparedStatement pstmt = null;
		try
		{
			pstmt = ORAconnection.prepareStatement(topBottomSQL);
			pstmt.setInt(1, Integer.parseInt(billRnd));
			pstmt.setDate(2, procDate);
			pstmt.setString(3, division);
			pstmt.setInt(4, Integer.parseInt(billRnd));
			pstmt.setDate(5, procDate);
			pstmt.setString(6, division);
			int rowsInserted = pstmt.executeUpdate();
			info("Data has been extracted for the top and bottom five into rabc_top_five_mo_blt table for Division " + division + " bill round of " + billRnd + " and for proc date: " + procDate+ " and rows inserted are : " + rowsInserted);
		} catch (SQLException e)
		{
			severe("Exception while fetching and inserting top and bottom five : "+e, e);
		}finally {
			JDBCUtil.closePreparedStatement(pstmt);
		}
	}

	
	
	private void summarizeMoBltData(String division, Date procDate, String billRnd){
		String summarizeSQL = "insert into rabc_mo_blt_sumy(run_date, division, bill_rnd, cust_type_cd, tar_cd, entity_cd, blt_tax_amnt)  " +
				"					(select run_date, division, bill_rnd, cust_type_cd, tar_cd, entity_cd, sum(blt_tax_amnt) blt_tax_amnt from " +
				"							rabc_Acct_mo_blt_DTL where bill_rnd = ? and run_date = ? and division = ? " +
				"									group by run_date, division, bill_rnd, cust_type_cd, tar_cd, entity_cd)";
		PreparedStatement pstmt = null;
		try
		{
			pstmt = ORAconnection.prepareStatement(summarizeSQL);
			pstmt.setString(1, billRnd);
			pstmt.setDate(2, procDate);
			pstmt.setString(3, division);
			int rowsInserted = pstmt.executeUpdate();
			info("Data has been summarized into rabc_mo_blt_sumy table for Division " + division + " bill round of " + billRnd + " and for proc date: " + procDate + " and rows inserted are : " + rowsInserted);
		} catch (SQLException e)
		{
			severe("Exception while summarization"+e, e);
		}finally {
			JDBCUtil.closePreparedStatement(pstmt);
		}
	}
	
	
	// insert Trigger to RABC_TRIG table.
	private boolean insertTrigger(boolean flag) {
		DateFormat df = new SimpleDateFormat("MMddyyyy");
		SimpleDateFormat sdf_for_Time = new SimpleDateFormat("HHmmss");
		SimpleDateFormat sdf_for_Date = new SimpleDateFormat("yyyyDDD");
		String file_name = getFile_id() + ".D" +  sdf_for_Date.format(new java.util.Date().getTime()) + 
		".T" + sdf_for_Time.format(new java.util.Date().getTime()) + ".TXT"; 
		if(flag){
			String run_date = df.format(procDt);
			if(!RabcLoadJobTrig.insertTrigger(ORAconnection, file_name, getFile_id(), division, run_date, null, billRnd))
			return false;
		}
		else
		{
			
			Calendar today = Calendar.getInstance();   
			// Subtract 1 day   
			today.add(Calendar.DATE, -1);   
			// Make an SQL Date out of that   
			java.sql.Date yesterday = new java.sql.Date(today.getTimeInMillis()); 
			String run_date = df.format(yesterday.getTime());
			if(!RabcLoadJobTrig.insertTrigger(ORAconnection, file_name, getFile_id(), "C", run_date))
			return false;
		}
		return true;
		
	}
	
	protected boolean postprocess(boolean success) {
		// close all preparedStatements ..
		JDBCUtil.closePreparedStatement(insertEDWExtracts);
		JDBCUtil.closePreparedStatement(insertEDWExtractsMOB);
		JDBCUtil.closePreparedStatement(selectEDW);
		success = super.postprocess(success);
		return success;
	}
	 // A new Extract from EDW 
    protected boolean getEDWData() {
    	ResultSet edwExtractedData = null;		
		try {
			edwExtractedData = selectEDW.executeQuery();
			int recordCnt = 0;
			while (edwExtractedData.next()){
				recordCnt++;

				//RUN_DATE, DIVISION, BTN, BILL_RND, CUST_TYPE_CD, TAR_CD, ENTITY_CD, BLT_TAX_AMNT

					insertEDWExtractsMOB.setString(1,getDivision_mob());
					insertEDWExtractsMOB.setString(2,edwExtractedData.getString("BTN"));
					insertEDWExtractsMOB.setString(3,null);
					insertEDWExtractsMOB.setString(4,edwExtractedData.getString("customer_type"));
					insertEDWExtractsMOB.setString(5,getTar_code_mob());
					insertEDWExtractsMOB.setString(6,getEntity_code_mob());
					insertEDWExtractsMOB.setDouble(7,edwExtractedData.getDouble("AMOUNT"));
					if(edwExtractedData.getString("TAX_EXEMPTION_CD") !=null && !(edwExtractedData.getString("TAX_EXEMPTION_CD").equals("")))
						insertEDWExtractsMOB.setString(8,(edwExtractedData.getString("TAX_EXEMPTION_CD")).substring(0,1));
					else
						insertEDWExtractsMOB.setString(8,null);
					insertEDWExtractsMOB.addBatch();
					
					if (recordCnt % 1000 == 0) {
						insertEDWExtractsMOB.executeBatch();
					}
			}

			if (recordCnt > 0)
				insertEDWExtractsMOB.executeBatch();
			
			info (" number of records processed for today are  >> " + recordCnt);
			
		} catch (SQLException e) {
			severe("Exception while processing ResultSet "+e, e);
			return false;
		}finally {
			JDBCUtil.closeResultSet(edwExtractedData);
		}
		
		return true;		
		
	}

  //summarization of new extract records
	private void summarizeMoBltData(){
		String summarizeSQL = "insert into rabc_mo_blt_sumy_ld(run_date, division, bill_rnd, cust_type_cd, tar_cd, entity_cd, blt_tax_amnt)  " +
				"					(select run_date, division, bill_rnd, cust_type_cd, tar_cd, entity_cd, sum(blt_tax_amnt) blt_tax_amnt from " +
				"							rabc_Acct_mo_blt_DTL_LD where run_date = TRUNC(SYSDATE-1) " +
				"									group by run_date, division, bill_rnd, cust_type_cd, tar_cd, entity_cd )";
		PreparedStatement pstmt = null;
		try
		{
			pstmt = ORAconnection.prepareStatement(summarizeSQL);
			int rowsInserted = pstmt.executeUpdate();
			info("Data has been summarized into rabc_mo_blt_sumy_ld table for Division C and rows inserted are : " + rowsInserted);
		} catch (SQLException e)
		{
			severe("Exception while summarization"+e, e);
		}finally {
			JDBCUtil.closePreparedStatement(pstmt);
		}
	}
	
	
	
	// processing top bottom 5 mobility rows for new extract 
	private void processTopBottomFiveMoBltData(){
		String topBottomSQL = "INSERT INTO rabc_top_five_mo_blt_ld " +
								"            (run_date, division, btn, bill_rnd, cust_type_cd, tar_cd, " +
								"             entity_cd, blt_tax_amnt, ranking) " +
								"   (SELECT run_date, division, btn, bill_rnd, cust_type_cd, tar_cd, entity_cd, " +
								"           blt_tax_amnt, " +
								"           ROW_NUMBER () OVER (PARTITION BY SYSDATE-1, cust_type_cd ORDER BY blt_tax_amnt DESC) " +
								"                                                                      ranking " +
								"      FROM (SELECT run_date, division, btn, bill_rnd, cust_type_cd, tar_cd, " +
								"                   entity_cd, blt_tax_amnt                   " +
								"              FROM (SELECT run_date, division, btn, bill_rnd, cust_type_cd, " +
								"                           tar_cd, entity_cd, blt_tax_amnt, " +
								"                           ROW_NUMBER () OVER (PARTITION BY SYSDATE-1, cust_type_cd ORDER BY blt_tax_amnt DESC) " +
								"                                                                        srlno " +
								"                      FROM rabc_acct_mo_blt_dtl_ld where  run_date = trunc(SYSDATE-1)  ) " +
								"             WHERE srlno <= 5 " +
								"            UNION " +
								"            SELECT run_date, division, btn, bill_rnd, cust_type_cd, tar_cd, " +
								"                   entity_cd, blt_tax_amnt                " +
								"              FROM (SELECT run_date, division, btn, bill_rnd, cust_type_cd, " +
								"                           tar_cd, entity_cd, blt_tax_amnt, " +
								"                           ROW_NUMBER () OVER (PARTITION BY SYSDATE-1,  cust_type_cd ORDER BY blt_tax_amnt ASC) " +
								"                                                                        srlno " +
								"                      FROM rabc_acct_mo_blt_dtl_ld where run_date = trunc(SYSDATE-1) ) " +
								"             WHERE srlno <= 5)) ";

		PreparedStatement pstmt = null;
		try
		{
			pstmt = ORAconnection.prepareStatement(topBottomSQL);
			
			int rowsInserted = pstmt.executeUpdate();
			info("Data has been extracted for the top and bottom five into rabc_top_five_mo_blt_ld table and rows inserted are : " + rowsInserted);
		} catch (SQLException e)
		{
			severe("Exception while fetching and inserting top and bottom five : "+e, e);
		}finally {
			JDBCUtil.closePreparedStatement(pstmt);
		}
	}
}
