/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/

package com.att.bac.rabc.alerts.dashboard;

import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.att.bac.rabc.ConnectionManager;
import com.att.bac.rabc.DateUtil;
import com.att.bac.rabc.ExcelReport;
import com.att.bac.rabc.ProgressBar;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.StaticDataLoader;
import com.att.carat.util.email.EmailFactory;
import com.att.carat.util.io.FileIO;

/**
 * This is an action class that controls the actions required to populate 
 * the Dashboard Component.
 * 
 * @author Sandhya Chinala - SC3837
 */
public class AlertDashboardAction extends DispatchAction {
	public static Logger logger = Logger.getLogger(AlertDashboardAction.class);
	private AlertDashboardService alertDashboardService = AlertDashboardService.getAlertDashboardService();
	private AlertRuleRevenueService alertRuleRevenueService = AlertRuleRevenueService.getAlertRuleRevenueService();
	private SystemMessagesService systemMessagesService = SystemMessagesService.getSystemMessagesService();

	/**
	 * This is a default dispatch action method to handel the request for the Dashboard Component.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @see org.apache.struts.actions.DispatchAction#unspecified(org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public ActionForward unspecified(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		AlertDashboardForm alertDashboardForm = (AlertDashboardForm)form;
		List failureList = new ArrayList();
		Connection connection = null;
		HttpSession session = request.getSession(true);
		String region = (String) session.getAttribute("region");
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		
		try {
			connection = ConnectionManager.getConnection(region);
			Date todayDate = new Date(System.currentTimeMillis());
			Date yesterdayDate = alertDashboardService.getPreviousDay(connection, failureList, todayDate);
			if (yesterdayDate == null) {
				yesterdayDate = DateUtil.getPreviousDay(new Date(System.currentTimeMillis()));
			}
			alertDashboardForm.setStartDate(dateFormat.format(yesterdayDate));
			alertDashboardForm.setEndDate(dateFormat.format(todayDate));
			alertDashboardForm.setDisplayHead("range");
			alertDashboardForm.setDateOption("run");
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		
		if (!failureList.isEmpty()){
			request.setAttribute("failures", failureList);
			return mapping.findForward("error");
		} else {
			return view(mapping, alertDashboardForm, request, response);
		}
		
	}
	
	/**
	 * This is a Dispatch Action method to populate the Alert Dashboard.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param res
	 * @return ActionForward
	 */
	public ActionForward view(ActionMapping mapping, ActionForm form,HttpServletRequest request, HttpServletResponse res) {
		AlertDashboardForm alertDashboardForm = (AlertDashboardForm)form;
		List failureList = new ArrayList();
		Connection connection = null;
		int counter = 0;
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		String userId = (String) session.getAttribute("bacUserID");
		String region = (String) session.getAttribute("region");
		int defaultLineCount = 0;
		
		/*
		 * Update calendar attributes
		 */
		alertDashboardForm.setBillRounds(StaticDataLoader.getBillRounds(region));
		alertDashboardForm.setProcDates(StaticDataLoader.getProcDates(region));
		alertDashboardForm.setHolidayIndicators(StaticDataLoader.getHolidayIndicators(region));
		alertDashboardForm.setLoadedDataDates(StaticDataLoader.getLoadedDataDatesByRegion(region));
		
		/*
		 * Code to set the display header.
		 */
		setDisplayHeader(alertDashboardForm);
		
		try {
			/*
			 * Get the connection from the available pool
			 */
			connection = ConnectionManager.getConnection(region);
			
			/*
			 * Code to get the default line count. 
			 */
			defaultLineCount = alertDashboardService.getDefaultLineCount(connection, failureList, userId);
			progressBar.setProgressPercent(progressBar.getPercent() + 10);

			/*
			 * Call private method listArguments(alertDashboardForm) to add the form parameters
			 * in an array list.
			 */
			List args = listArguments(alertDashboardForm, defaultLineCount, region);
			
			/*
			 * Code to prepare a string that contains the first cycle and the last cycle.
			 * This calls the service class to get the list of cycles for for the entered 
			 * file start date and file end date.
			 */
			setCycle(alertDashboardForm, connection, failureList, args);
			
			/*
			 * Code to get the total count of high, medium, low and none severity alerts.
			 */
			setTotals(alertDashboardForm,connection,failureList,args, userId);
			progressBar.setProgressPercent(progressBar.getPercent() + 10);
			
			/*
			 * Code for paging.
			 * Call the private method setPaging(alertDashboardForm, connection, failureList, args) to set the current page
			 * and total no. of pages of the report.
			 */
			setPaging(alertDashboardForm, connection, failureList, args, userId);
						
			/*
			 * Reset the args list with current page and total no. of pages.
			 */
			args.add(10, new Integer(alertDashboardForm.getPage()));
	    	args.add(11, new Integer(alertDashboardForm.getPages()));
	    	
	    	/*
			 * Put the criterias selected into session.
			 * This will be used when after updating the status of alert, user returns to the same page.
			 */
			Hashtable options = getCriteria(alertDashboardForm);
			session.setAttribute("dashboardOptions", options);
			progressBar.setProgressPercent(progressBar.getPercent() + 10);
			
	    	/*
			 * Code to create the list of alert dashboard objects.
			 * This calls the service class to get the list of dashboard objects.
			 */
			List alertDashboardList = alertDashboardService.getAlertDashboardList(connection, failureList, args, progressBar,userId);
			alertDashboardForm.getAlertDashboardList().clear();
			if (alertDashboardList != null) {
				int alertDashboardListSize = alertDashboardList.size();
				AlertDashboard alertDashboard = null;
				for(counter = 0; counter < alertDashboardListSize ; counter++) {
					alertDashboard = (AlertDashboard) alertDashboardList.get(counter);
					alertDashboardForm.addAlertDashboard(alertDashboard);
				}
			}
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		
		progressBar.setProgressPercent(100);
		
		/*
		 * Code to forward the request to control point summary dashboard or alert dashboard
		 * in case of no failure or to Error page in another case.
		 */
		if (!failureList.isEmpty()){
			request.setAttribute("failures", failureList);
			return mapping.findForward("error");
		} else {
			/*
			 * Forward the request depending upon dashbord type.
			 */
			if (alertDashboardForm.getDashboardType().equals("2")){
				return mapping.findForward("ControlPointSummary");
			} else {
				return mapping.findForward("AlertSummary");
			}
		}
	}

	/**
	 * This is a Dispatch Action method to populate the Alert Dashboard for yesterday. 	 
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward yesterday(ActionMapping mapping, ActionForm form,HttpServletRequest request, HttpServletResponse response)   {
		AlertDashboardForm alertDashboardForm = (AlertDashboardForm)form;
		List failureList = new ArrayList();
		Connection connection = null;
		HttpSession session = request.getSession(true);
		String region = (String) session.getAttribute("region");
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		
		try {
			connection = ConnectionManager.getConnection(region);
			Date todayDate = new Date(System.currentTimeMillis());
			Date yesterdayDate = alertDashboardService.getPreviousDay(connection, failureList, todayDate);
			if (yesterdayDate == null) {
				yesterdayDate = DateUtil.getPreviousDay(new Date(System.currentTimeMillis()));
			}
			alertDashboardForm.setDisplayHead("prev");
			alertDashboardForm.setStartDate(dateFormat.format(yesterdayDate));
			alertDashboardForm.setEndDate("");
			alertDashboardForm.setDateOption("run");
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		}catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		
		if (!failureList.isEmpty()){
			request.setAttribute("failures", failureList);
			return mapping.findForward("error");
		} else {
			return view(mapping, alertDashboardForm, request, response);
		}
	}
	
	/**
	 * This is a Dispatch Action method to populate the Alert Dashboard for today.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward today(ActionMapping mapping, ActionForm form,HttpServletRequest request, HttpServletResponse response) {
		AlertDashboardForm alertDashboardForm = (AlertDashboardForm)form;
		List failureList = new ArrayList();
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date defaultDate = new Date(System.currentTimeMillis());
		try {
			alertDashboardForm.setDisplayHead("curr");
			alertDashboardForm.setStartDate(dateFormat.format(defaultDate));
			alertDashboardForm.setEndDate("");
			alertDashboardForm.setDateOption("run");
		} catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		}
		return view(mapping, alertDashboardForm, request, response);
	}

	/**
	 * This is a Dispatch Action method to populate the Alert Dashboard for one day prior to start date.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward minus(ActionMapping mapping, ActionForm form,HttpServletRequest request, HttpServletResponse response)   {
		AlertDashboardForm alertDashboardForm = (AlertDashboardForm)form;
		List failureList = new ArrayList();
		Date startDate = null;
		Date previousDate = null;
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		
		try {
			startDate = dateFormat.parse(alertDashboardForm.getStartDate());
			previousDate = DateUtil.getPreviousDay(startDate);
			alertDashboardForm.setDisplayHead("decr");
			alertDashboardForm.setStartDate(dateFormat.format(previousDate));
			alertDashboardForm.setEndDate("");
			alertDashboardForm.setDateOption("run");
		} catch(ParseException px) {
			logger.error("Parse exception. Exception details: " + px.getMessage(), px);
			failureList.add(new RABCException("Parse exception. Exception details: " + px.getMessage(), px));
		} catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		}
		
		if (!failureList.isEmpty()){
			request.setAttribute("failures", failureList);
			return mapping.findForward("error");
		} else {
			return view(mapping, alertDashboardForm, request, response);
		}
	}

	/**
	 * This is a Dispatch Action method to populate the Alert Dashboard for one day after start date.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward plus(ActionMapping mapping, ActionForm form,HttpServletRequest request, HttpServletResponse response)   {
		AlertDashboardForm alertDashboardForm = (AlertDashboardForm)form;
		List failureList = new ArrayList();
		Calendar calendar = Calendar.getInstance();
		Date startDate = null;
		Date nextDate = null;
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		
		try {
			startDate = dateFormat.parse(alertDashboardForm.getStartDate());
			calendar.setTime(startDate);
			calendar.add(Calendar.DAY_OF_YEAR, 1);
			nextDate = new Date(calendar.getTimeInMillis());
			alertDashboardForm.setDisplayHead("incr");
			alertDashboardForm.setStartDate(dateFormat.format(nextDate));
			alertDashboardForm.setEndDate("");
			alertDashboardForm.setDateOption("run");
		} catch(ParseException px) {
			logger.error("Parse exception. Exception details: " + px.getMessage(), px);
			failureList.add(new RABCException("Parse exception. Exception details: " + px.getMessage(), px));
		} catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		}
		
		if (!failureList.isEmpty()){
			request.setAttribute("failures", failureList);
			return mapping.findForward("error");
		} else {
			return view(mapping, alertDashboardForm, request, response);
		}
	}
	
	/**
	 * This is a Dispatch Action method to generate the excel report of Alert Dashboard.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward createReport(ActionMapping mapping, ActionForm form,HttpServletRequest request, HttpServletResponse response)   {
		AlertDashboardForm alertDashboardForm = (AlertDashboardForm) form;
		Connection connection = null;
		List failureList = new ArrayList();
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		String userId = (String) session.getAttribute("bacUserID");
		String region = (String) session.getAttribute("region");
		String reportPath = null;
		ExcelReport report = null;
		List args = null;
		
		try {
			connection = ConnectionManager.getConnection(region);
			String displayHead = alertDashboardForm.getDisplayHead();
			if ((alertDashboardForm.getReportType().equals("cntrlPnt")) 
					|| (alertDashboardForm.getReportType().equals("dashboard"))) {
				reportPath = "Alert_Dashboard_Report_" + userId + ".xls";
				response.setContentType("application/msexcel");
		        response.setHeader("Content-Disposition","attachment; filename="+reportPath);
		        report = new  ExcelReport(response.getOutputStream());
		        args = listArguments(alertDashboardForm, 0, region);
		        progressBar.setProgressPercent(progressBar.getPercent() + 10);
				alertDashboardService.getExcelReport(connection, failureList, args, displayHead, report, progressBar, userId);	
			} else if(alertDashboardForm.getReportType().equals("revenue")) {
				reportPath = "Alert_Rule_Revenue_Report_" + userId + ".xls";
				response.setContentType("application/msexcel");
		        response.setHeader("Content-Disposition","attachment; filename="+reportPath);
		        report = new  ExcelReport(response.getOutputStream());
				args = listArgumentsForAlertRevenueService(alertDashboardForm, region);	
				progressBar.setProgressPercent(progressBar.getPercent() + 10);
				alertRuleRevenueService.getExcelReport(connection, failureList, args, report, progressBar, alertDashboardForm.getDateOption());
			}
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch(IOException ioe) {
			logger.error(RABCMessages.getMessage("ERR_IO_EXEC", new String[] {"IO Exception while creating dashboard report. "}) + " Exception details: " + ioe.getMessage(), ioe);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_IO_EXEC", new String[] {"IO Exception while creating dashboard report."}), ioe));
		} catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		progressBar.setProgressPercent(100);
		if (!failureList.isEmpty()) {
			request.setAttribute("failures",failureList);
			return mapping.findForward("error");
		} else {
			return null;
		}
	}
	
	/**
	 * This is a Dispatch Action method to send the email with attached excel report of Alert Dashboard.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward emailReport(ActionMapping mapping, ActionForm form,HttpServletRequest request, HttpServletResponse response)   {
		AlertDashboardForm alertDashboardForm = (AlertDashboardForm) form;
		Connection connection = null;
		List failureList = new ArrayList();
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		String userId = (String) session.getAttribute("bacUserID");
		String region = (String) session.getAttribute("region");
		String reportName = null;
		String reportPath = null;
		ExcelReport report = null;
		List args = null;
		FileIO fio=new FileIO();
 		FileOutputStream fos = null;
 		String emailRecipients = null;
 		String [] emailRecipientsArray = null;
 		
 		try {
 			connection = ConnectionManager.getConnection(region);
 			String displayHead = alertDashboardForm.getDisplayHead();
 			emailRecipients = alertDashboardForm.getEmailRecipients();
			emailRecipientsArray = emailRecipients.split(",");
			int totalEmailRecipients = emailRecipientsArray.length;
			int counter = 0;
   // pb3879 added to create correct subject line.  Added to second arguement for email.
			Context initContext = new InitialContext();
            String spServer = initContext.lookup("java:/comp/env/saved_report_server").toString();
            String fromEnvironment = initContext.lookup("java:/comp/env/application_env").toString();
            String rootFolder = initContext.lookup("java:/comp/env/saved_report_folder").toString();
            String spUser = initContext.lookup("java:/comp/env/saved_report_user").toString();
            String spPasswd = initContext.lookup("java:/comp/env/saved_report_passwd").toString();
            String smbUrl = "smb://" + spUser + ":" + spPasswd + "@" + spServer + "/" + rootFolder ;
            
 			if( (alertDashboardForm.getReportType().equals("cntrlPnt")) || (alertDashboardForm.getReportType().equals("dashboard")) ){
				reportName = "Alert_Dashboard_Report";
				reportPath = "Alert_Dashboard_Report_" + userId + ".xls";
				fio = new FileIO(smbUrl,reportPath);
	 			report = new  ExcelReport(fio.createOutputStream());
	 			//file[0] = new File(reportPath);	 		
	 			//fos = new FileOutputStream(file[0]);
	 			//report = new  ExcelReport(fos);
	 			args = listArguments(alertDashboardForm, 0, region);
	 			progressBar.setProgressPercent(progressBar.getPercent() + 10);
	 			alertDashboardService.getExcelReport(connection,failureList, args, displayHead, report, progressBar, userId);
 			} else if(alertDashboardForm.getReportType().equals("revenue")){
				reportName = "Alert_Rule_Revenue_Report";
				reportPath = "Alert_Rule_Revenue_Report_" + userId + ".xls";
				fio = new FileIO(smbUrl,reportPath);
	 			report = new  ExcelReport(fio.createOutputStream());
				//file[0] = new File(reportPath);	 		
	 			//fos = new FileOutputStream(file[0]);
	 			//report = new  ExcelReport(fos);
	 			args = listArgumentsForAlertRevenueService(alertDashboardForm, region);
	 			progressBar.setProgressPercent(progressBar.getPercent() + 10);
				alertRuleRevenueService.getExcelReport(connection, failureList, args, report, progressBar,alertDashboardForm.getDateOption());
			}
 			//emailRecipients = alertDashboardForm.getEmailRecipients();
			//emailRecipientsArray = emailRecipients.split(",");
			//int totalEmailRecipients = emailRecipientsArray.length;
			//int counter = 0;
 			for(counter = 0; counter < totalEmailRecipients; counter++  ) {
				EmailFactory.sendEmail(emailRecipientsArray[counter]+"@att.com", "RABC (" + fromEnvironment + " - " + spServer + ") " + reportName, "Please find the enclosed RABC Report - " + reportPath, false, fio);
			}
			//for(counter = 0; counter < totalEmailRecipients; counter++  ) {
			//	Email.sendEmail(emailRecipientsArray[counter]+"@att.com", reportName, "Please find the enclosed RABC Report - " + reportPath, false, file);
			//}
 			//file[0].delete();
 		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch(IOException ioe) {
			logger.error(RABCMessages.getMessage("ERR_IO_EXEC", new String[] {"IO Exception while e mailing dashboard report. "}) + " Exception details: " + ioe.getMessage(), ioe);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_IO_EXEC", new String[] {"IO Exception while e mailing dashboard report."}), ioe));
		} catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		progressBar.setProgressPercent(100);
		if (!failureList.isEmpty()) {
			request.setAttribute("failures",failureList);
			return mapping.findForward("error");
		} else {
			return view(mapping,form,request,response);
		}
	}
	
	/**
	 * This is an action method to handel the request for first page of Alert Dashboard.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward first(ActionMapping mapping, ActionForm form, 
	 		HttpServletRequest request, HttpServletResponse response) {
		return view(mapping, form, request, response);
	}
		
	/**
	 * This is an action method to handel the request for previous page of Alert Dashboard.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward previous(ActionMapping mapping, ActionForm form,
	 		HttpServletRequest request, HttpServletResponse response) {
		return view(mapping, form, request, response);
	}
	
	/**
	 * This is an action method to handel the request for next page of Alert Dashboard.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward next(ActionMapping mapping, ActionForm form, 
	 		HttpServletRequest request, HttpServletResponse response) {
	 	return view(mapping, form, request, response);
	}
	
	/**
	 * This is an action method to handel the request for last page of Alert Dashboard.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward last(ActionMapping mapping, ActionForm form, 
    		HttpServletRequest request, HttpServletResponse response) {
	 	return view(mapping, form, request, response);
	}
    
	/**
	 * This is an action method to handel the request for specific page of Alert Dashboard.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward pagelist(ActionMapping mapping, ActionForm form, 
    		HttpServletRequest request, HttpServletResponse response) {
	 	return view(mapping, form, request, response);
	}
    
	/**
	 * This is an action method to handel the request for sorting the current page of Alert Dashboard
	 * depending upon sort criteria.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward sort(ActionMapping mapping, ActionForm form, 
	 		HttpServletRequest request, HttpServletResponse response) {
	 	return view(mapping, form, request, response);
	}
	
	/**
	 * This is a Dispatch Action method to forward the System messages action
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward systemMessages(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {
		AlertDashboardForm alertDashboardForm = (AlertDashboardForm)form;
		List failureList = new ArrayList();
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		SystemMessagesParameters systemMessagesParameters = new SystemMessagesParameters();
		try {
			// Set relevant attributes from form to above object
			if (alertDashboardForm.getDashboardType().equals("2")) {
				systemMessagesParameters.setWebPageId("RABCPSF00002");
			} else if (alertDashboardForm.getDashboardType().equals("3")) {
				systemMessagesParameters.setWebPageId("RABCPSF00003");
				systemMessagesParameters.setControlPoint(alertDashboardForm.getCntrlPt());
			}
			systemMessagesParameters.setStartDate(alertDashboardForm.getStartDate());
			systemMessagesParameters.setEndDate(alertDashboardForm.getEndDate());
			systemMessagesParameters.setDateType(alertDashboardForm.getDateOption());
			request.setAttribute("systemMessagesParameters",systemMessagesParameters);
		} catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		}
		
		return mapping.findForward("SystemMessages");
	}
	
	/**
	 * This is a Dispatch Action method to generate the revenue alerts page
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward revenueAlerts(ActionMapping mapping, ActionForm form,HttpServletRequest request, HttpServletResponse response)   {
		AlertDashboardForm alertDashboardForm = (AlertDashboardForm)form;
		List failureList = new ArrayList();
		Connection connection = null;
		int counter = 0;
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		String region = (String) session.getAttribute("region");
		
		List args = listArgumentsForAlertRevenueService(alertDashboardForm, region);
		
		/*
		 * Update calendar attributes
		 */
		alertDashboardForm.setBillRounds(StaticDataLoader.getBillRounds(region));
		alertDashboardForm.setProcDates(StaticDataLoader.getProcDates(region));
		alertDashboardForm.setHolidayIndicators(StaticDataLoader.getHolidayIndicators(region));
		alertDashboardForm.setLoadedDataDates(StaticDataLoader.getLoadedDataDatesByRegion(region));
		try {
			/*
			 * Get the connection from the available pool
			 */
			connection = ConnectionManager.getConnection(region);
			progressBar.setProgressPercent(progressBar.getPercent() + 10);
			
			/*
			 * Code to prepare a string that contains the first cycle and the last cycle.
			 * This calls the service class to get the list of cycles for for the entered 
			 * file start date and file end date.
			 */
			setCycleForAlertRevenue(alertDashboardForm, connection, failureList, args);
			progressBar.setProgressPercent(progressBar.getPercent() + 10);
			
			/*
			 * Construct a Logic for table 1
			 */
			List alertRuleRevenueList = alertRuleRevenueService.getAlertRuleRevenueList(connection, failureList, args, progressBar, (String) session.getAttribute("region"),alertDashboardForm.getDateOption());
			alertDashboardForm.getAlertRuleRevenueList().clear();
			if (alertRuleRevenueList != null) {
				int alertRuleRevenueListSize = alertRuleRevenueList.size();
				for(counter=0; counter<alertRuleRevenueListSize; counter++) {
					alertDashboardForm.addAlertRuleRevenue((AlertRuleRevenue)alertRuleRevenueList.get(counter));
				}
				alertDashboardForm.setAlertRuleRevenueListCount(alertRuleRevenueListSize);
			}
			/*
			 * Construct a Logic for table 2
			 */
			if (!region.equals("C2")) {
				List alertRuleInvestigationsList = alertRuleRevenueService.getAlertRuleInvestigationsList(connection, failureList, args, progressBar);
				alertDashboardForm.getAlertRuleInvestigationsList().clear();
				if (alertRuleInvestigationsList != null) {
					int alertRuleInvestigationsListSize = alertRuleInvestigationsList.size();
					for(counter=0; counter<alertRuleInvestigationsListSize; counter++) {
						alertDashboardForm.addAlertRuleInvestigations((AlertRuleInvestigations)alertRuleInvestigationsList.get(counter));
					}
					alertDashboardForm.setAlertRuleInvestigationsListCount(alertRuleInvestigationsListSize);
				}
			} else {
				progressBar.setProgressPercent(progressBar.getPercent() + 20);
			}
			/*
			 * Construct a Logic for table 3
			 */
			List alertRuleWarningsList = alertRuleRevenueService.getAlertRuleWarningsList(connection, failureList, args, progressBar,alertDashboardForm.getDateOption());
			alertDashboardForm.getAlertRuleWarningsList().clear();
			if (alertRuleWarningsList != null) {
				int alertRuleWarningsListSize = alertRuleWarningsList.size();
				AlertRuleWarnings alertRuleWarnings = null;
				for(counter=0; counter<alertRuleWarningsListSize; counter++) {
					alertRuleWarnings = (AlertRuleWarnings)alertRuleWarningsList.get(counter);
					alertDashboardForm.addAlertRuleWarnings(alertRuleWarnings);
				}
				alertDashboardForm.setAlertRuleWarningsListCount(alertRuleWarningsListSize);
			}
		} catch(SQLException sx) {
			   logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			   failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		progressBar.setProgressPercent(100);
		if (!failureList.isEmpty()){
			request.setAttribute("failures", failureList);
			return mapping.findForward("error");
		} else {
			return mapping.findForward("AlertRuleRevenue");
		}
	}
	
	/**
	 * This is a Dispatch Action method to return to Alert Dashboard page after upadating the status of alert.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward returnView(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {
		AlertDashboardForm alertDashboardForm = (AlertDashboardForm) form;
		List failureList = new ArrayList();
		HttpSession session = request.getSession(true);
		
		try {
			/*
			 * Get the criterias selected form session.
			 */
			Hashtable options = (Hashtable) session.getAttribute("dashboardOptions");
			alertDashboardForm.setStartDate((String) options.get("startDate"));
			alertDashboardForm.setEndDate((String) options.get("endDate"));
			alertDashboardForm.setDateOption((String) options.get("dateOption"));
			alertDashboardForm.setCntrlPt((String) options.get("cntrlPt"));
			alertDashboardForm.setDashboardType((String) options.get("dashboardType"));
			alertDashboardForm.setDisplayHead((String) options.get("displayHead"));
			alertDashboardForm.setSortItem((String) options.get("sortItem"));
			alertDashboardForm.setSortOrder((String) options.get("sortOrder"));
			alertDashboardForm.setPage(((Integer) options.get("page")).intValue());
		} catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		}
		
		return view(mapping, alertDashboardForm, request, response);
	}

	/**
	 * Private method to set the display header.
	 * 
	 * @param alertDashboardForm
	 */
	private void setDisplayHeader(AlertDashboardForm alertDashboardForm) {
		Date currentDate = new Date(System.currentTimeMillis());
		Date yestDate = DateUtil.getPreviousDay(currentDate);
		String startDate = alertDashboardForm.getStartDate();
		String displayHead = alertDashboardForm.getDisplayHead();
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		
		if ("curr".equalsIgnoreCase(displayHead) || "incr".equalsIgnoreCase(displayHead)) {
			if(startDate.equals(dateFormat.format(currentDate))){
				alertDashboardForm.setDisplayHeader("Current Day Alerts");
			} else if(startDate.equals(dateFormat.format(yestDate))){
				alertDashboardForm.setDisplayHeader("Previous Day Alerts");
			} else {
				alertDashboardForm.setDisplayHeader("");
			}
		} else if ("prev".equalsIgnoreCase(displayHead) || "decr".equalsIgnoreCase(displayHead)) {
			if(startDate.equals(dateFormat.format(yestDate))){
				alertDashboardForm.setDisplayHeader("Previous Day Alerts");
			} else {
				alertDashboardForm.setDisplayHeader("");
			}
		}
	}

	/**
	 * This is a method which set the cycle depending on the list of cycles obtained for the given dates
	 * 
	 * @param alertDashboardForm
	 * @param connection
	 * @param failureList
	 * @param args 
	 */
	private void setCycle(AlertDashboardForm alertDashboardForm, Connection connection, List failureList, List args){
		String cycle = "";
		String region = (String) args.get(9);
		if ("WE".equalsIgnoreCase(region) || "C2".equalsIgnoreCase(region)) {
			List cycleList = alertDashboardService.getCycleCalendarList(connection, failureList, args);
			if (cycleList != null) {
				int cycleListSize = cycleList.size();
				if (cycleListSize > 0) {
					if (cycleListSize == 1) {
						cycle = ((new StringBuffer())
							.append(((Integer)cycleList.get(0)).toString()))
							.toString();
					} else {
						cycle = ((new StringBuffer())
							.append(((Integer)cycleList.get(0)).toString())
							.append(" - ")
							.append(((Integer)cycleList.get(cycleListSize-1)).toString()))
							.toString();
					}
				} else {
					cycle = "";
				}
			} else {
				cycle = "";
			}
		}
		alertDashboardForm.setCycle(cycle);
	}
	
	/**
	 * Private method to set the total for tier 1,2,3 & none
	 * 
	 * @param alertDashboardForm
	 * @param connection
	 * @param failureList
	 * @param args 
	 */
	private void setTotals(AlertDashboardForm alertDashboardForm, Connection connection, List failureList, List args, String userId){
		List totalList = new ArrayList();
		List totalClosedList = new ArrayList();
		
		List argsForSysMsg = new ArrayList();
		SystemMessagesParameters systemMessagesParameters = new SystemMessagesParameters();
		int totalSysMsg = 0;
		
		totalList = alertDashboardService.getTotalList(connection, failureList, args,userId);
		totalClosedList = alertDashboardService.getTotalClosedList(connection, failureList, args,userId);
		if ((totalList != null) && (totalList.size() > 0)) {
			alertDashboardForm.setCountTier3(((Integer)totalList.get(0)).intValue());
			alertDashboardForm.setCountTier2(((Integer)totalList.get(1)).intValue());
			alertDashboardForm.setCountTier1(((Integer)totalList.get(2)).intValue());
			alertDashboardForm.setCountNone(((Integer)totalList.get(3)).intValue());
			alertDashboardForm.setCountWarningStatus(((Integer)totalList.get(4)).intValue());
			alertDashboardForm.setCountPendingStatus(((Integer)totalList.get(5)).intValue());
			alertDashboardForm.setCountClosedStatus(((Integer)totalClosedList.get(0)).intValue());
		}
		alertDashboardForm.setTotalWarnings(alertDashboardForm.getCountWarningStatus() 
				+ alertDashboardForm.getCountPendingStatus()
				+ alertDashboardForm.getCountClosedStatus());
		
		/*
		 * Code to get the total system messages.
		 */
		if (alertDashboardForm.getDashboardType().equals("2")) {
			systemMessagesParameters.setWebPageId("RABCPSF00002");
		} else if (alertDashboardForm.getDashboardType().equals("3")) {
			systemMessagesParameters.setWebPageId("RABCPSF00003");
			systemMessagesParameters.setControlPoint(alertDashboardForm.getCntrlPt());
		}
		systemMessagesParameters.setStartDate(alertDashboardForm.getStartDate());
		systemMessagesParameters.setEndDate(alertDashboardForm.getEndDate());
		systemMessagesParameters.setDateType(alertDashboardForm.getDateOption());
		argsForSysMsg.add(0, "");
		argsForSysMsg.add(1, "");
		argsForSysMsg.add(2, "");
		argsForSysMsg.add(3, new Integer(0));
		argsForSysMsg.add(4, new Integer(0));
		argsForSysMsg.add(5, new Integer(0));
		totalSysMsg = systemMessagesService.getTotalMessages(systemMessagesParameters, connection, failureList, argsForSysMsg);
		alertDashboardForm.setTotalSysMsg(totalSysMsg);
	}

	/**
	 * Private internal method to return the list of arguments.
	 * 
	 * @param alertDashboardForm
	 * @param defaultLineCount
	 * @param region
	 * @return List
	 */
	private List listArguments(AlertDashboardForm alertDashboardForm, int defaultLineCount, String region) {
    	List args = new ArrayList();
    	
    	String startDate = alertDashboardForm.getStartDate();
		String endDate = alertDashboardForm.getEndDate();
		String dashboardType = alertDashboardForm.getDashboardType();
		String dateOption = alertDashboardForm.getDateOption();
		String cntrlPt = alertDashboardForm.getCntrlPt();
		String sortItem = alertDashboardForm.getSortItem();
		String sortOrder = alertDashboardForm.getSortOrder();
		String dispatch = alertDashboardForm.getDispatch();
		int page = alertDashboardForm.getPage();
		int pages = alertDashboardForm.getPages();
		
		args.add(0, startDate);
		args.add(1, endDate);
		args.add(2, dateOption);
		args.add(3, cntrlPt);
		args.add(4, dashboardType);
		args.add(5, sortItem);
		args.add(6, sortOrder);
		args.add(7, dispatch);
		args.add(8, new Integer(defaultLineCount));
		args.add(9, region);
		args.add(10, new Integer(page));
    	args.add(11, new Integer(pages));
	
		return args;
    }
    
	/**
	 * Private internal method to return the arguments list for AlertRevenueService.
	 * 
	 * @param alertDashboardForm
	 * @param region
	 * @return List
	 */
	private List listArgumentsForAlertRevenueService(AlertDashboardForm alertDashboardForm, String region) {
    	List args = new ArrayList();
    	
    	String startDate = alertDashboardForm.getStartDate();
		String endDate = alertDashboardForm.getEndDate();
		String alertDate = alertDashboardForm.getAlertDate();
		String alertRule = alertDashboardForm.getAlertRule();
		String processPoint = alertDashboardForm.getProcess();
		
		args.add(0, startDate);
		args.add(1, endDate);
		args.add(2, alertDate);
		args.add(3, alertRule);
		args.add(4, processPoint);
		args.add(5, region);
		
    	return args;
    }
    
	/**
	 * Method to set the cycle depending on the list of cycles obtained for the given dates for alert revenue page
	 * 
	 * @param alertDashboardForm
	 * @param connection
	 * @param failureList
	 * @param args
	 */
	private void setCycleForAlertRevenue(AlertDashboardForm alertDashboardForm, Connection connection, List failureList, List args){
		String cycle = "";
		String region = (String) args.get(5);
		if ("WE".equalsIgnoreCase(region) || "C2".equalsIgnoreCase(region)) {
			List cycleList = alertRuleRevenueService.getCycleCalendarList(connection, failureList, args);
			if (cycleList != null) {
				int cycleListSize = cycleList.size();
				if (cycleListSize > 0) {
					if (cycleListSize == 1) {
						cycle = ((new StringBuffer())
							.append(((Integer)cycleList.get(0)).toString()))
							.toString();
					} else {
						cycle = ((new StringBuffer())
							.append(((Integer)cycleList.get(0)).toString())
							.append(" - ")
							.append(((Integer)cycleList.get(cycleListSize-1)).toString()))
							.toString();
					}
				} else {
					cycle = "";
				}
			} else {
				cycle = "";
			}
		} 
		alertDashboardForm.setCycle(cycle);
	}

	/**
	 * A method to set the current page and total no. of pages of the report.
	 * 
	 * @param alertDashboardForm
	 * @param connection
	 * @param failureList
	 * @param args
	 */
	private void setPaging(AlertDashboardForm alertDashboardForm, Connection connection,List failureList, List args, String userId) {
		String dashboardType = alertDashboardForm.getDashboardType();
		int totalDashboards = 0;
		
		/*
		 * Call the service class to get the total count of dashboard objects.
		 */
		if ("2".equals(dashboardType)) {
			totalDashboards = alertDashboardService.getTotalCntrlPts(connection, failureList, args);
		} else {
			totalDashboards = alertDashboardService.getTotalAlertRules(connection, failureList, args,userId);
		}
		/*int pageSize = ((Integer) args.get(8)).intValue();
		int pages = totalDashboards / pageSize;
		int temp = totalDashboards % pageSize;
		if ( temp > 0)
			pages++;*/
		int pages = 1;
		alertDashboardForm.setPages(pages);
		alertDashboardForm.setTotalRecords(totalDashboards);
		
		String dispatch = alertDashboardForm.getDispatch();
		if ("first".equals(dispatch)) {
			alertDashboardForm.setPage(1);
		} else if ("last".equals(dispatch)) {
			alertDashboardForm.setPage(alertDashboardForm.getPages());
		} else if ("previous".equals(dispatch)) {
        	if (alertDashboardForm.getPage() != 1) {
        		alertDashboardForm.setPage(alertDashboardForm.getPage() - 1);
        	}
        } else if ("next".equals(dispatch)) {
        	if (alertDashboardForm.getPage() != alertDashboardForm.getPages()) {
        		alertDashboardForm.setPage(alertDashboardForm.getPage() + 1);
        	}
        } else if ("pagelist".equals(dispatch)) {
        	if (alertDashboardForm.getPageshow() != 0) {
        		alertDashboardForm.setPage(alertDashboardForm.getPageshow());
        	} else {
        		alertDashboardForm.setPage(1);
        	}
        } else if ("sort".equals(dispatch)) {
        	alertDashboardForm.setPage(alertDashboardForm.getPage());
        } else if ("returnView".equals(dispatch)) {
        	alertDashboardForm.setPage(alertDashboardForm.getPage());
        } else {
        	alertDashboardForm.setPage(1);
        }
	}
	
	/**
	 * A private method to return a hashtable that contains the criterias.
	 * 
	 * @param alertDashboardForm
	 * @return Hashtable
	 */
	private Hashtable getCriteria(AlertDashboardForm alertDashboardForm) {
		Hashtable options = new Hashtable();
    	
		if (alertDashboardForm.getStartDate() != null) {
			options.put("startDate", alertDashboardForm.getStartDate());
		}
		if (alertDashboardForm.getEndDate() != null) {
			options.put("endDate", alertDashboardForm.getEndDate());
		}
		if (alertDashboardForm.getDateOption() != null) {
			options.put("dateOption", alertDashboardForm.getDateOption());
		}
		if (alertDashboardForm.getCntrlPt() != null) {
			options.put("cntrlPt", alertDashboardForm.getCntrlPt());
		}
		if (alertDashboardForm.getDashboardType() != null) {
			options.put("dashboardType", alertDashboardForm.getDashboardType());
		}
		if (alertDashboardForm.getDisplayHead() != null) {
			options.put("displayHead", alertDashboardForm.getDisplayHead());
		}
		if (alertDashboardForm.getSortItem() != null) {
			options.put("sortItem", alertDashboardForm.getSortItem());
		}
		if (alertDashboardForm.getSortOrder() != null) {
			options.put("sortOrder", alertDashboardForm.getSortOrder());
		}
		options.put("page", new Integer(alertDashboardForm.getPage()));

		return options;
	}
}
