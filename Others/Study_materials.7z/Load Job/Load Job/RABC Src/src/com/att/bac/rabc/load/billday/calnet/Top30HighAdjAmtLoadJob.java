/* Created by Prachi Chhabra (PC2774) on Dec 8, 2006.
Copyright 2006-2008 AT&T Knowledge Ventures. All rights reserved. */

package com.att.bac.rabc.load.billday.calnet;

import java.io.File;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import com.att.bac.rabc.load.calnet.CalnetException;
import com.att.bac.rabc.load.calnet.CalnetLoadJob;
import com.att.bac.rabc.util.EmcisEventLogger;
import com.att.carat.util.NetUtil;
import com.sbc.bac.rabc.load.StaticErrorMsgKeys;

/**
 * This class reads the data from files whose name fits the pattern:
 * WE.[CI].C[0-9]{4}.XT31ADJT.*. It gets the files from input folder name specified
 * in Top30HighAdjAmt.cfg file. It parses the file line by line and inserts the records into the
 * RABC_TOP_ADJ_BLG_ACCTS table.
 * @author PC2774
 */
	public class Top30HighAdjAmtLoadJob extends CalnetLoadJob {

	List rabcTopAdjBlgAccts = null;
	
	private String fileName, region;
	private static final int CONST_MILLION = 1000000;

	/**
	 * @return ID of the file being processed
	 */
	public String getFileId() {
		return "XT31ADJT";
	}

	/**
	 * @return Table Name for inserting the records.
	 */
	public String getTable() {
		return "RABC_TOP_ADJ_BLG_ACCTS";
	}

	/**
	 * Initiailizes the list to hold data transfer objects. It parses the filename to set the
	 * values for region, division, cycle, run date, bill round date and bill round.
	 *
	 * @param file object representing the file to be processed
	 */
	public boolean preprocessFile(File file){
		fileName = file.getName();
		region   =	file.getName().substring(0,2);
		rabcTopAdjBlgAccts = new ArrayList();
		return super.preprocessFile(file);
	}

	/**
	 * Processes a single record from the load file. A line contains fields that are
	 * semicolon (;) delimited.
	 *
	 * @param line record from load file
	 * @return int indicating the return status as Success or Error
	 * @throws  Exception Throws exception if there is an error in parsing the fields.
	 */
	protected int processRecord(String line) throws Exception {
		int success;

		RabcTopAdjBlgAcct acct = new RabcTopAdjBlgAcct();
		try {
			String[] tokens = line.split(";");
			acct.setRunDate(sqlRunDate);
			acct.setDivision(division);
			acct.setCycle(cycle);
			acct.setAgencyID(tokens[9].trim());
			acct.setBtn(tokens[3].trim() + tokens[4].trim() + tokens[5].trim());
			acct.setAdjAmt(Double.parseDouble(tokens[11].trim()) / CONST_MILLION);
			acct.setPrevBlgAmt(Double.parseDouble(tokens[12].trim()) / CONST_MILLION);
			acct.setCurrMnthChrgAmt(Double.parseDouble(tokens[13].trim()) / CONST_MILLION);
			acct.setCurrBalDueAmt(Double.parseDouble(tokens[14].trim()) / CONST_MILLION);
			acct.setBillRnd(billRnd);
			acct.setBillMm(billRndDate.substring(0,2));
			acct.setBillYear(billRndDate.substring(4,8));
			rabcTopAdjBlgAccts.add(acct);
			lineCount++;
			success = SUCCESS;
		}
		catch (Exception ex) {
			severe(StaticErrorMsgKeys.PARSELINE_ERROR + " BTN " + acct.getBtn() + ex.getMessage(), ex);
			success = ERROR;
		}
		return success;
	}

	/**
	 * Inserts the processed data into RABC_TOP_ADJ_BLG_ACCTS table.
	 * Calls postprocessFile method of base class in the end.
	 *
	 * @param file object representing load file
	 * @param success boolean indicating success or failure of previous action
	 * @return boolean indicating success or failure
	 */
	public boolean postprocessFile(File file, boolean success) {
		try{
			//Log the file information to EMCIS_EVENT_LOG and EMCIS_EVENT_LOG_DETAIL
			EmcisEventLogger emcisLogger = new EmcisEventLogger();
			String event_id = "RABC_"+getFileId()+"_"+region;
            String host = NetUtil.getLocalHostName();
            String hostIP = NetUtil.getLocalIpAddress();
			int sequence = emcisLogger.getEMCISSequence(connection);
			emcisLogger.insertEventLog(connection, sequence, event_id, sqlRunDate, host, hostIP);
			emcisLogger.insertEventLogDetail(connection, sequence, "FileName", fileName);

		}catch (UnknownHostException e) {
            severe("Error getting EMCIS host information ", e);
        }
		if(success){
			RabcTopAdjBlgAcctsDAO dao = new RabcTopAdjBlgAcctsDAO();
			try{
				success = dao.insertBatchOfRecords(connection, rabcTopAdjBlgAccts, 1000);
			}catch(CalnetException ex){
				severe(ex.getMessage(), ex);
				success = false;
			}
		}
		rabcTopAdjBlgAccts = null;
		return super.postprocessFile(file, success);
	}
}
