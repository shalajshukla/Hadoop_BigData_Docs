/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

/**
 * This is a DAO that performs SELECT, INSERT and UPDATE on RABC_WEB_DATA_LINK table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class WebDataLinkDAO {
	private static final Logger logger = Logger.getLogger(WebDataLinkDAO.class);

	/**
	 * Returns the list of WebDataLink objects.
	 * 
	 * @param conn 
	 * @param failures
	 * @param args
	 * @param baseSQL
	 * @return List
	 */
	public List get(Connection conn, List failures, List args, String baseSQL) {
		List webDataLinkList = null;
		WebDataLink webDataLink = null;
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		
		try
		{
			logger.debug("Processing SELECT from RABC_WEB_DATA_LINK table....");
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("WebDataLinkDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			logger.debug("SQL - Execution complete.");
			webDataLinkList = new ArrayList();
			while (rs.next()) {
				webDataLinkList.add(buildWebDataLink(rs));
			}
			
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return null;
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
		
		return webDataLinkList;
	}

	/**
	 * Private method to build WebDataLink object and return it to caller.
	 * 
	 * @param rs
	 * @return WebDataLink
	 * @throws SQLException
	 */
	private WebDataLink buildWebDataLink(ResultSet rs) throws SQLException {
		WebDataLink webDataLink = new WebDataLink();
		
		webDataLink.setPresnId(rs.getInt("PRESN_ID"));
		webDataLink.setWebid(rs.getString("WEBID"));
		webDataLink.setExecPresnSeqNum(rs.getInt("EXEC_PRESN_SEQ_NUM"));
		webDataLink.setLinkNum(rs.getInt("LINK_NUM"));
		webDataLink.setLinkDdlName(rs.getString("LINK_DDL_NAME"));
		webDataLink.setLinkToPgm(rs.getString("LINK_TO_PGM"));
		webDataLink.setLinkPresnId(rs.getInt("LINK_PRESN_ID"));
		webDataLink.setLinkNumParm(rs.getInt("LINK_NUM_PARM"));
		webDataLink.setLinkParm1(rs.getString("LINK_PARM1"));
		webDataLink.setLinkParm2(rs.getString("LINK_PARM2"));
		webDataLink.setLinkParm3(rs.getString("LINK_PARM3"));
		webDataLink.setLinkParm4(rs.getString("LINK_PARM4"));
		webDataLink.setLinkParm5(rs.getString("LINK_PARM5"));
		webDataLink.setLinkParm6(rs.getString("LINK_PARM6"));
		webDataLink.setLinkParm7(rs.getString("LINK_PARM7"));
		webDataLink.setLinkParm8(rs.getString("LINK_PARM8"));
		webDataLink.setLinkParm9(rs.getString("LINK_PARM9"));
		webDataLink.setLinkParm10(rs.getString("LINK_PARM10"));
		webDataLink.setLinkParm11(rs.getString("LINK_PARM11"));
		webDataLink.setLinkParm12(rs.getString("LINK_PARM12"));
		return webDataLink;
	}

	/**
	 * Execute the insert or update statement on RABC_WEB_DATA_LINK table.
	 * 
	 * @param conn
	 * @param failures
	 * @param args
	 * @param baseSQL
	 */
	public void executeUpdate(Connection conn, List failures, List args, String baseSQL) {
		int rowsUpdated = 0;
		Statement stmt = null;
		String sqlStmt = null;
		
		try
		{
			logger.debug("Processing executeUpdate on RABC_WEB_DATA_LINK table....");
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("WebDataLinkDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rowsUpdated = stmt.executeUpdate(sqlStmt);
			logger.debug("SQL - Execution complete."+ String.valueOf(rowsUpdated) + "  rows updated");
			
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage());
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return;
		} finally {
			SQLHelper.closeStatement(stmt, failures, logger);
		}
	}

}
