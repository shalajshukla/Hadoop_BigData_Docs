/*
 * Copyright  2002-2006 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.adhoc.aria.pivot;

public class DataCell implements Comparable {
    private int column;

    private boolean innerBreakBeforeWrite = false;

    private DatedCompositeKey key;

    private boolean outerBreakBeforeWrite = false;

    private boolean previousData = false;

    private int row;

    private Object value;


    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
    public int compareTo(Object o) {
        if (this == o) {
            return 0;
        }

        DataCell o1 = (DataCell) o;

        if (getRow() != o1.getRow()) {
            return getRow() - o1.getRow();
        }

        return getColumn() - o1.getColumn();
    }


    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    public boolean equals(Object obj) {
        if (!(obj instanceof DataCell)) {
            return false;
        }
        DataCell o = (DataCell) obj;
        return (o.getColumn() == getColumn()) && (o.getRow() == getRow());
    }


    /**
     * @return Returns the column.
     */
    public int getColumn() {
        return column;
    }


    /**
     * @return Returns the key.
     */
    public DatedCompositeKey getKey() {
        return key;
    }


    /**
     * @return Returns the row.
     */
    public int getRow() {
        return row;
    }


    /**
     * @return Returns the value.
     */
    public Object getValue() {
        return value;
    }


    /**
     * Is a break of any kind set for this cell
     * 
     * @return
     */
    public boolean isBreak() {
        return isInnerBreakBeforeWrite() | isOuterBreakBeforeWrite();
    }


    /**
     * @return Returns the innerBreakBeforeWrite.
     */
    public boolean isInnerBreakBeforeWrite() {
        return innerBreakBeforeWrite;
    }


    /**
     * @return Returns the outerBreakBeforeWrite.
     */
    public boolean isOuterBreakBeforeWrite() {
        return outerBreakBeforeWrite;
    }


    public boolean isPreviousData() {
        return previousData;
    }


    /**
     * @param column The column to set.
     */
    public void setColumn(int column) {
        this.column = column;
    }


    /**
     * @param key
     */
    public void setDatedCompositeKey(DatedCompositeKey key) {
        this.key = key;
    }


    /**
     * @param innerBreakBeforeWrite The innerBreakBeforeWrite to set.
     */
    public void setInnerBreakBeforeWrite(boolean innerBreakBeforeWrite) {
        this.innerBreakBeforeWrite = innerBreakBeforeWrite;
    }


    /**
     * @param outerBreakBeforeWrite The outerBreakBeforeWrite to set.
     */
    public void setOuterBreakBeforeWrite(boolean outerBreakBeforeWrite) {
        this.outerBreakBeforeWrite = outerBreakBeforeWrite;
    }


    public void setPreviousData(boolean previousData) {
        this.previousData = previousData;
    }


    /**
     * @param row The row to set.
     */
    public void setRow(int row) {
        this.row = row;
    }


    /**
     * @param value The value to set.
     */
    public void setValue(Object value) {
        this.value = value;
    }
}
