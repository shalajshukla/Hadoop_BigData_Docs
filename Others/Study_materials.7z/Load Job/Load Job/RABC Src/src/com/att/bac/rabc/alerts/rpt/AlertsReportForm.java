/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/

 package com.att.bac.rabc.alerts.rpt;

 import java.util.ArrayList;
import java.util.List;

import com.att.bac.rabc.PagedForm;

/**
 * This is an action form class to represent the Alert Report Form for page 11.
 * 
 * @author Nalina Pandiyan - NP5434
 */
 public class AlertsReportForm extends PagedForm {
 	private String cntrlPtCd;
 	private String cntrlPtDesc;
 	private String alertRule;
 	private String startDate;
 	private String endDate;
 	private String divisionName; // selected division Name
 	private Integer fileSeqNum;
 	private String relatedAlertInd;

 	// Header attributes on the JSP page
 	private String header1;
 	private String header2;
 	private String header3;

 	// Filter attributes on the JSP page
 	// The following attributes controls display of filter on the JSP page 
 	private String divisionNameLabel;
 	private List divisionList = null; // Holds alertReportDivision objects
 	private String key1Label;
 	private String key1; // This to display Key1 as text box on JSP page
 	private String key2Label;
 	private String key2; // This to display Key2 as text box on JSP page
 	
 	private Integer partiRefId;
 	private Integer presnId;
 	private String webPageId;
 	private Integer divisionNameKeyLvl; 
 	private Integer severeLvl;
 	private String emailRecipients;

 	// additional for Page 12
 	private String procDate;
 	private String alertTimeInd;
 	private String alertTimeValue;
 	private String alertTimeValueWD;
 	private String alertTimeValueBR;
 	private ArrayList alertTimeIndOptions = new ArrayList();
 	private ArrayList alertTimeValueOptions = new ArrayList();
 	private ArrayList alertTimeValueOptionsWD = new ArrayList();
 	private ArrayList alertTimeValueOptionsBR = new ArrayList();
 	private String styleAlertTimeValue;
 	private String styleAlertTimeValueWD;
 	private String styleAlertTimeValueBR;
 	
 	private String key3;
 	private String key4;
 	private String key5;
 	private String currentDataLink;
 	private String alertRules;
 	private String presnIds;
 	
 	private String dataPresent;
 	private AlertReportView alertReportView = null;
 	private String popup;
 	private int pageshow;
 	private int selectedButton; // 1 means Next data, 2 means Previous data, otherwise -1
 	private String statusColumnHeaderBgColor = "#0059B3";
 	
 	private String timeStampInd = null;
 	
 	private String alertItem;
	private List alertItemOptions = new ArrayList();
	private String cycles="";
	
	/*
	 * Phase II changes
	 */
	private String key3Label = null;	//to filter the page 11 and 14 on key3 (phase II change)
	
	/*
	 * Variables added for calendar page
	 */
	private String procDates;
	private String billRounds;
	private String holidayIndicators;
	private String loadedDataDates;
	
	private String  alertRuleTimingIndicator = "";
 	
	/**
 	 *Default constructor which sets the default divisionList and selectedButton attributes.
 	 */
 	public AlertsReportForm() {
 		this.divisionList = new ArrayList();
 		this.selectedButton = -1;
 	}

	/**
	 * @return String cycles
	 */
	public String getCycles() {
		return cycles;
	}

	/**
	 * @param cycles String
	 */
	public void setCycles(String cycles) {
		this.cycles = cycles;
	}
	
	/**
	 * @return String loadedDataDates
	 */			
	public String getLoadedDataDates() {
		return loadedDataDates;
	}

	/**
	 * @param loadedDataDates String
	 */
	public void setLoadedDataDates(String loadedDataDates) {
		this.loadedDataDates = loadedDataDates;
	}
	
 	/**
 	 * @return Returns the dataPresent.
 	 */
 	public String getDataPresent() {
 		return this.dataPresent;
 	}
 	/**
 	 * @param dataPresent The dataPresent to set.
 	 */
 	public void setDataPresent(String dataPresent) {
 		this.dataPresent = dataPresent;
 	}
 	/**
 	 * @return Returns the emailRecipients.
 	 */
 	public String getEmailRecipients() {
 		return emailRecipients;
 	}
 	/**
 	 * @return Returns the alertReportView.
 	 */
 	public AlertReportView getAlertReportView() {
 		return alertReportView;
 	}

 	/**
 	 * @param alertReportView The alertReportView to set.
 	 */
 	public void setAlertReportView(AlertReportView alertReportView) {
 		this.alertReportView = alertReportView;
 	}

 	/**
 	 * @return Returns the alertRule.
 	 */
 	public String getAlertRule() {
 		return alertRule;
 	}

 	/**
 	 * @param alertRule The alertRule to set.
 	 */
 	public void setAlertRule(String alertRule) {
 		this.alertRule = alertRule;
 	}

 	/**
 	 * @return Returns the divisionName.
 	 */
 	public String getDivisionName() {
 		return divisionName;
 	}

 	/**
 	 * @param divisionName The divisionName to set.
 	 */
 	public void setDivisionName(String divisionName) {
 		this.divisionName = divisionName;
 	}

 	/**
 	 * @return Returns the divisionNameLabel.
 	 */
 	public String getDivisionNameLabel() {
 		return divisionNameLabel;
 	}

 	/**
 	 * @param divisionNameLabel The divisionNameLabel to set.
 	 */
 	public void setDivisionNameLabel(String divisionNameLabel) {
 		this.divisionNameLabel = divisionNameLabel;
 	}

 	/**
 	 * @return Returns the endDate.
 	 */
 	public String getEndDate() {
 		return endDate;
 	}

 	/**
 	 * @param endDate The endDate to set.
 	 */
 	public void setEndDate(String endDate) {
 		this.endDate = endDate;
 	}

 	/**
 	 * @return Returns the fileSeqNum.
 	 */
 	public Integer getFileSeqNum() {
 		return fileSeqNum;
 	}

 	/**
 	 * @param fileSeqNum The fileSeqNum to set.
 	 */
 	public void setFileSeqNum(Integer fileSeqNum) {
 		this.fileSeqNum = fileSeqNum;
 	}

 	/**
 	 * @return Returns the header1.
 	 */
 	public String getHeader1() {
 		return header1;
 	}

 	/**
 	 * @param header1 The header1 to set.
 	 */
 	public void setHeader1(String header1) {
 		this.header1 = header1;
 	}

 	/**
 	 * @return Returns the header2.
 	 */
 	public String getHeader2() {
 		return header2;
 	}

 	/**
 	 * @param header2 The header2 to set.
 	 */
 	public void setHeader2(String header2) {
 		this.header2 = header2;
 	}

 	/**
 	 * @return Returns the header3.
 	 */
 	public String getHeader3() {
 		return header3;
 	}

 	/**
 	 * @param header3 The header3 to set.
 	 */
 	public void setHeader3(String header3) {
 		this.header3 = header3;
 	}

 	/**
 	 * @return Returns the key1.
 	 */
 	public String getKey1() {
 		return key1;
 	}

 	/**
 	 * @param key1 The key1 to set.
 	 */
 	public void setKey1(String key1) {
 		this.key1 = key1;
 	}

 	/**
 	 * @return Returns the key1Header.
 	 */
 	public String getKey1Label() {
 		return key1Label;
 	}

 	/**
 	 * @param key1Label The key1Label to set.
 	 */
 	public void setKey1Label(String key1Label) {
 		this.key1Label = key1Label;
 	}

 	/**
 	 * @return Returns the key2.
 	 */
 	public String getKey2() {
 		return key2;
 	}

 	/**
 	 * @param key2 The key2 to set.
 	 */
 	public void setKey2(String key2) {
 		this.key2 = key2;
 	}

 	/**
 	 * @return Returns the key2Label.
 	 */
 	public String getKey2Label() {
 		return key2Label;
 	}

 	/**
 	 * @param key2Label The key2Label to set.
 	 */
 	public void setKey2Label(String key2Label) {
 		this.key2Label = key2Label;
 	}

 	/**
 	 * @return Returns the relatedAlertInd.
 	 */
 	public String getRelatedAlertInd() {
 		return relatedAlertInd;
 	}

 	/**
 	 * @param relatedAlertInd The relatedAlertInd to set.
 	 */
 	public void setRelatedAlertInd(String relatedAlertInd) {
 		this.relatedAlertInd = relatedAlertInd;
 	}

 	/**
 	 * @return Returns the startDate.
 	 */
 	public String getStartDate() {
 		return startDate;
 	}

 	/**
 	 * @param startDate The startDate to set.
 	 */
 	public void setStartDate(String startDate) {
 		this.startDate = startDate;
 	}

 	/**
 	 * @param emailRecipients The emailRecipients to set.
 	 */
 	public void setEmailRecipients(String emailList) {
 		this.emailRecipients = emailList;
 	}

 	/**
 	 * @return Returns the divisionList.
 	 */
 	public List getDivisionList() {
 		return divisionList;
 	}
 	/**
 	 * @param divisionList The divisionList to set.
 	 */
 	public void setDivisionList(List divisionList) {
 		this.divisionList = divisionList;
 	}
 	/**
 	 * @return Returns the partiRefId.
 	 */
 	public Integer getPartiRefId() {
 		return partiRefId;
 	}
 	/**
 	 * @param partiRefId The partiRefId to set.
 	 */
 	public void setPartiRefId(Integer partiRefId) {
 		this.partiRefId = partiRefId;
 	}
 	/**
 	 * @return Returns the presnId.
 	 */
 	public Integer getPresnId() {
 		return presnId;
 	}
 	/**
 	 * @param presnId The presnId to set.
 	 */
 	public void setPresnId(Integer presnId) {
 		this.presnId = presnId;
 	}
 	/**
 	 * @return Returns the webPageId.
 	 */
 	public String getWebPageId() {
 		return webPageId;
 	}

 	/**
 	 * @param webPageId The webPageId to set.
 	 */
 	public void setWebPageId(String webPageId) {
 		this.webPageId = webPageId;
 	}
 	/**
 	 * @return Returns the divisionNameKeyLvl.
 	 */
 	public Integer getDivisionNameKeyLvl() {
 		return divisionNameKeyLvl;
 	}

 	/**
 	 * @param divisionNameKeyLvl The divisionNameKeyLvl to set.
 	 */
 	public void setDivisionNameKeyLvl(Integer divisionNameKeyLvl) {
 		this.divisionNameKeyLvl = divisionNameKeyLvl;
 	}

 	/**
 	 * @return Returns the alertTimeInd.
 	 */
 	public String getAlertTimeInd() {
 		return alertTimeInd;
 	}

 	/**
 	 * @param alertTimeInd The alertTimeInd to set.
 	 */
 	public void setAlertTimeInd(String alertTimeInd) {
 		this.alertTimeInd = alertTimeInd;
 	}

 	/**
 	 * @return Returns the alertTimeValue.
 	 */
 	public String getAlertTimeValue() {
 		return alertTimeValue;
 	}

 	/**
 	 * @param alertTimeValue The alertTimeValue to set.
 	 */
 	public void setAlertTimeValue(String alertTimeValue) {
 		this.alertTimeValue = alertTimeValue;
 	}

 	/**
 	 * @return Returns the currentDataLink.
 	 */
 	public String getCurrentDataLink() {
 		return currentDataLink;
 	}

 	/**
 	 * @param currentDataLink The currentDataLink to set.
 	 */
 	public void setCurrentDataLink(String currentDataLink) {
 		this.currentDataLink = currentDataLink;
 	}

 	/**
 	 * @return Returns the key3.
 	 */
 	public String getKey3() {
 		return key3;
 	}

 	/**
 	 * @param key3 The key3 to set.
 	 */
 	public void setKey3(String key3) {
 		this.key3 = key3;
 	}

 	/**
 	 * @return Returns the key4.
 	 */
 	public String getKey4() {
 		return key4;
 	}

 	/**
 	 * @param key4 The key4 to set.
 	 */
 	public void setKey4(String key4) {
 		this.key4 = key4;
 	}

 	/**
 	 * @return Returns the key5.
 	 */
 	public String getKey5() {
 		return key5;
 	}

 	/**
 	 * @param key5 The key5 to set.
 	 */
 	public void setKey5(String key5) {
 		this.key5 = key5;
 	}

 	/**
 	 * @return Returns the procDate.
 	 */
 	public String getProcDate() {
 		return procDate;
 	}

 	/**
 	 * @param procDate The procDate to set.
 	 */
 	public void setProcDate(String procDate) {
 		this.procDate = procDate;
 	}

 	/**
 	 * @return Returns the popup.
 	 */
 	public String getPopup() {
 		return popup;
 	}
 	
 	/**
 	 * @param popup The popup to set.
 	 */
 	public void setPopup(String popup) {
 		this.popup = popup;
 	}
 	/**
 	 * @return Returns the cntrlPtCd.
 	 */
 	public String getCntrlPtCd() {
 		return cntrlPtCd;
 	}

 	/**
 	 * @param cntrlPtCd The cntrlPtCd to set.
 	 */
 	public void setCntrlPtCd(String cntrlPtCd) {
 		this.cntrlPtCd = cntrlPtCd;
 	}
 	/**
 	 * @return Returns the pageshow.
 	 */
 	public int getPageshow() {
 		return pageshow;
 	}

 	/**
 	 * @param pageshow The pageshow to set.
 	 */
 	public void setPageshow(int pageshow) {
 		this.pageshow = pageshow;
 	}

 	/**
 	 * @return Returns the severeLvl.
 	 */
 	public Integer getSevereLvl() {
 		return severeLvl;
 	}

 	/**
 	 * @param severeLvl The severeLvl to set.
 	 */
 	public void setSevereLvl(Integer severeLvl) {
 		this.severeLvl = severeLvl;
 	}
 	/**
 	 * @return Returns the selectedButton.
 	 */
 	public int getSelectedButton() {
 		return selectedButton;
 	}

 	/**
 	 * @param selectedButton The selectedButton to set.
 	 */
 	public void setSelectedButton(int selectedButton) {
 		this.selectedButton = selectedButton;
 	}

 	/**
 	 * @return Returns the alertRules.
 	 */
 	public String getAlertRules() {
 		return alertRules;
 	}

 	/**
 	 * @param alertRules The alertRules to set.
 	 */
 	public void setAlertRules(String alertRules) {
 		this.alertRules = alertRules;
 	}

 	/**
 	 * @return Returns the presnIds.
 	 */
 	public String getPresnIds() {
 		return presnIds;
 	}

 	/**
 	 * @param presnIds The presnIds to set.
 	 */
 	public void setPresnIds(String presnIds) {
 		this.presnIds = presnIds;
 	}
 	
 	/**
 	 * @return Returns the alertTimeValueBR.
 	 */
 	public String getAlertTimeValueBR() {
 		return alertTimeValueBR;
 	}
 	/**
 	 * @param alertTimeValueBR The alertTimeValueBR to set.
 	 */
 	public void setAlertTimeValueBR(String alertTimeValueBR) {
 		this.alertTimeValueBR = alertTimeValueBR;
 	}
 	/**
 	 * @return Returns the alertTimeValueOptions.
 	 */
 	public ArrayList getAlertTimeValueOptions() {
 		return alertTimeValueOptions;
 	}
 	/**
 	 * @param alertTimeValueOptions The alertTimeValueOptions to set.
 	 */
 	public void setAlertTimeValueOptions(ArrayList alertTimeValueOptions) {
 		this.alertTimeValueOptions = alertTimeValueOptions;
 	}
 	/**
 	 * @return Returns the alertTimeValueOptionsBR.
 	 */
 	public ArrayList getAlertTimeValueOptionsBR() {
 		return alertTimeValueOptionsBR;
 	}
 	/**
 	 * @param alertTimeValueOptionsBR The alertTimeValueOptionsBR to set.
 	 */
 	public void setAlertTimeValueOptionsBR(ArrayList alertTimeValueOptionsBR) {
 		this.alertTimeValueOptionsBR = alertTimeValueOptionsBR;
 	}
 	/**
 	 * @return Returns the alertTimeValueOptionsWD.
 	 */
 	public ArrayList getAlertTimeValueOptionsWD() {
 		return alertTimeValueOptionsWD;
 	}
 	/**
 	 * @param alertTimeValueOptionsWD The alertTimeValueOptionsWD to set.
 	 */
 	public void setAlertTimeValueOptionsWD(ArrayList alertTimeValueOptionsWD) {
 		this.alertTimeValueOptionsWD = alertTimeValueOptionsWD;
 	}
 	/**
 	 * @return Returns the alertTimeValueWD.
 	 */
 	public String getAlertTimeValueWD() {
 		return alertTimeValueWD;
 	}
 	/**
 	 * @param alertTimeValueWD The alertTimeValueWD to set.
 	 */
 	public void setAlertTimeValueWD(String alertTimeValueWD) {
 		this.alertTimeValueWD = alertTimeValueWD;
 	}
 		
 	/**
 	 * @return Returns the alertTimeIndOptions.
 	 */
 	public ArrayList getAlertTimeIndOptions() {
 		return alertTimeIndOptions;
 	}
 	/**
 	 * @param alertTimeIndOptions The alertTimeIndOptions to set.
 	 */
 	public void setAlertTimeIndOptions(ArrayList alertTimeIndOptions) {
 		this.alertTimeIndOptions = alertTimeIndOptions;
 	}
 		
 	/**
 	 * @return Returns the styleAlertTimeValue.
 	 */
 	public String getStyleAlertTimeValue() {
 		return styleAlertTimeValue;
 	}
 	/**
 	 * @param styleAlertTimeValue The styleAlertTimeValue to set.
 	 */
 	public void setStyleAlertTimeValue(String styleAlertTimeValue) {
 		this.styleAlertTimeValue = styleAlertTimeValue;
 	}
 	/**
 	 * @return Returns the styleAlertTimeValueBR.
 	 */
 	public String getStyleAlertTimeValueBR() {
 		return styleAlertTimeValueBR;
 	}
 	/**
 	 * @param styleAlertTimeValueBR The styleAlertTimeValueBR to set.
 	 */
 	public void setStyleAlertTimeValueBR(String styleAlertTimeValueBR) {
 		this.styleAlertTimeValueBR = styleAlertTimeValueBR;
 	}
 	/**
 	 * @return Returns the styleAlertTimeValueWD.
 	 */
 	public String getStyleAlertTimeValueWD() {
 		return styleAlertTimeValueWD;
 	}
 	/**
 	 * @param styleAlertTimeValueWD The styleAlertTimeValueWD to set.
 	 */
 	public void setStyleAlertTimeValueWD(String styleAlertTimeValueWD) {
 		this.styleAlertTimeValueWD = styleAlertTimeValueWD;
 	}
 	/**
 	 * @return Returns the cntrlPtDesc.
 	 */
 	public String getCntrlPtDesc() {
 		return cntrlPtDesc;
 	}
 	/**
 	 * @param cntrlPtDesc The cntrlPtDesc to set.
 	 */
 	public void setCntrlPtDesc(String cntrlPtDesc) {
 		this.cntrlPtDesc = cntrlPtDesc;
 	}
 	/**
 	 * @return Returns the statusColumnHeaderBgColor.
 	 */
 	public String getStatusColumnHeaderBgColor() {
 		return statusColumnHeaderBgColor;
 	}
 	/**
 	 * @param statusColumnHeaderBgColor The statusColumnHeaderBgColor to set.
 	 */
 	public void setStatusColumnHeaderBgColor(String statusColumnHeaderBgColor) {
 		this.statusColumnHeaderBgColor = statusColumnHeaderBgColor;
 	}
 	
	/**
	 * @return Returns the timeStampInd.
	 */
	public String getTimeStampInd() {
		return timeStampInd;
	}
	/**
	 * @param timeStampInd The timeStampInd to set.
	 */
	public void setTimeStampInd(String timeStampInd) {
		this.timeStampInd = timeStampInd;
	}
	
	/**
	 * @return Returns the alertItem.
	 */
	public String getAlertItem() {
		return alertItem;
	}
	/**
	 * @param alertItem The alertItem to set.
	 */
	public void setAlertItem(String alertItem) {
		this.alertItem = alertItem;
	}
	/**
	 * @return Returns the alertItemOptions.
	 */
	public List getAlertItemOptions() {
		return alertItemOptions;
	}
	/**
	 * @param alertItemOptions The alertItemOptions to set.
	 */
	public void setAlertItemOptions(List alertItemOptions) {
		this.alertItemOptions = alertItemOptions;
	}
	/**
	 * @return Returns the key3Label.
	 */
	public String getKey3Label() {
		return key3Label;
	}
	/**
	 * @param key3Label The key3Label to set.
	 */
	public void setKey3Label(String key3Label) {
		this.key3Label = key3Label;
	}
	
	/**
	 * @return Returns the billRounds.
	 */
	public String getBillRounds() {
		return billRounds;
	}
	/**
	 * @param billRounds The billRounds to set.
	 */
	public void setBillRounds(String billRounds) {
		this.billRounds = billRounds;
	}
	/**
	 * @return Returns the holidayIndicators.
	 */
	public String getHolidayIndicators() {
		return holidayIndicators;
	}
	/**
	 * @param holidayIndicators The holidayIndicators to set.
	 */
	public void setHolidayIndicators(String holidayIndicators) {
		this.holidayIndicators = holidayIndicators;
	}
	/**
	 * @return Returns the procDates.
	 */
	public String getProcDates() {
		return procDates;
	}
	/**
	 * @param procDates The procDates to set.
	 */
	public void setProcDates(String procDates) {
		this.procDates = procDates;
	}

	/**
	 * @return the alertRuleTimingIndicator
	 */
	public String getAlertRuleTimingIndicator() {
		return alertRuleTimingIndicator;
	}

	/**
	 * @param alertRuleTimingIndicator the alertRuleTimingIndicator to set
	 */
	public void setAlertRuleTimingIndicator(String alertRuleTimingIndicator) {
		this.alertRuleTimingIndicator = alertRuleTimingIndicator;
	}
 }
