/* Created by Gaurav Bhargava (GB0741) on Dec 19, 2006.
Copyright 2006-2008 AT&T Knowledge Ventures. All rights reserved. */

package com.att.bac.rabc.load.usage.calnet;

import java.io.File;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import com.att.bac.rabc.load.calnet.CalnetException;
import com.att.bac.rabc.load.calnet.CalnetLoadJob;
import com.att.bac.rabc.util.EmcisEventLogger;
import com.att.carat.util.NetUtil;
import com.sbc.bac.rabc.load.StaticErrorMsgKeys;

/**
 * This class reads the data from files whose name fits the pattern:
 * WE.[JI].C[0-9]{4}.XT32DUSG.*. It gets the files from input folder name specified
 * in DailyNonPlan.cfg file. It parses the file line by line and inserts the records into the
 * RABC_DAILY_USG_NONPLAN_ACTVT table.
 * @author GB0741
 */
public class DailyUsgNonPlanLoadJob extends CalnetLoadJob{

	List rabcDailyUsgNonPlan = null;
	private static final int DENOMINATOR = 1000000;
	private static final int DENOMINATOR_BIG = 1000000;
	private String fileName, region;
	/**
	 * @return ID of the file being processed
	 */
	public String getFileId() {
		return "XT32DUSG";
	}

	/**
	 * @return Table Name for inserting the records.
	 */
	public String getTable() {
		return "RABC_DAILY_USG_NONPLAN_ACTVT";
	}

	/**
	 * Initiailizes the list to hold data transfer objects. It parses the filename to set the
	 * values for region, division, cycle, run date, bill round date and bill round.
	 *
	 * @param file object representing the file to be processed
	 */
	public boolean preprocessFile(File file){
		fileName = file.getName();
		region   =	file.getName().substring(0,2);
		rabcDailyUsgNonPlan = new ArrayList();
		return super.preprocessFile(file);
	}

	/**
	 * Processes a single record from the load file. A line contains fields that are
	 * semicolon delimited in the format: <FileId>;<AgencyId>;<Cycle>;<UsageCtgy>;<Division>;
	 * <ProcessId>;<UsgRcdCls>;<AcctTypeCtgy>;<BusResInd>;<blank>;<TotMinsOfUse>;<TotMsgCt>;
	 * <TotBlgChgs>;<TotOthrChgs>;<TotEccSurcharge>;<TotOperSurcharge>;<TotPsscSurcharge>;
	 * <TotLocalTax>;<AmountPerUnit>
	 *
	 * @param line record from load file
	 * @return int indicating the return status as Success or Error
	 * @throws Exception Throws exception if there is an error in parsing the fields.
	 */
	protected int processRecord(String line) throws Exception {
		int success;
		RabcDailyUsgNonPlan dailyNonPlan = new RabcDailyUsgNonPlan();
		try{
			String[] tokens = line.split(";");

			dailyNonPlan.setRunDate(sqlRunDate);
			dailyNonPlan.setDivision(division);
			dailyNonPlan.setCycle(cycle);
			dailyNonPlan.setAgencyID(tokens[1].trim());
			dailyNonPlan.setUsgRcdCls(Integer.parseInt(tokens[6].trim()));
			dailyNonPlan.setBusResInd(tokens[8].trim());
			dailyNonPlan.setTotMinsOfUse(Double.parseDouble(tokens[10].trim())/DENOMINATOR);
			dailyNonPlan.setTotMsgCt(Long.parseLong(tokens[11].trim())/DENOMINATOR);
			dailyNonPlan.setTotBlgChgs(Double.parseDouble(tokens[12].trim())/DENOMINATOR);
			dailyNonPlan.setTotOthrChgs(Double.parseDouble(tokens[13].trim())/DENOMINATOR);
			dailyNonPlan.setTotEccSrcg(Double.parseDouble(tokens[14].trim())/DENOMINATOR);
			dailyNonPlan.setTotOperSrcg(Double.parseDouble(tokens[15].trim())/DENOMINATOR);
			dailyNonPlan.setTotPsscSrcg(Double.parseDouble(tokens[16].trim())/DENOMINATOR);
			dailyNonPlan.setTotLoclTax(Double.parseDouble(tokens[17].trim())/DENOMINATOR);
			dailyNonPlan.setAmtPerUnit(Double.parseDouble(tokens[18].trim())/DENOMINATOR_BIG);
			rabcDailyUsgNonPlan.add(dailyNonPlan);
			lineCount++;
			success = SUCCESS;
		}catch(Exception ex){
			severe(StaticErrorMsgKeys.PARSELINE_ERROR + " Agency ID " + dailyNonPlan.getAgencyID() + ex.getMessage(), ex);
			success = ERROR;
		}
	return success;
}

	/**
	 * Inserts the processed data into RABC_DAILY_USG_NONPLAN_ACTVT table.
	 * Calls postprocessFile method of base class in the end.
	 *
	 * @param file object representing load file
	 * @param success boolean indicating success or failure of previous action
	 * @return boolean indicating success or failure
	 */
	public boolean postprocessFile(File file, boolean success) {
		try{
			//Log the file information to EMCIS_EVENT_LOG and EMCIS_EVENT_LOG_DETAIL
			EmcisEventLogger emcisLogger = new EmcisEventLogger();
			String event_id = "RABC_"+getFileId()+"_"+region;
            String host = NetUtil.getLocalHostName();
            String hostIP = NetUtil.getLocalIpAddress();
			int sequence = emcisLogger.getEMCISSequence(connection);
			emcisLogger.insertEventLog(connection, sequence, event_id, sqlRunDate, host, hostIP);
			emcisLogger.insertEventLogDetail(connection, sequence, "FileName", fileName);

		}catch (UnknownHostException e) {
            severe("Error getting EMCIS host information ", e);
        }
		if(success){
			RabcDailyUsgNonPlanDAO dao = new RabcDailyUsgNonPlanDAO();
			try{
				success = dao.insertBatchOfRecords(connection, rabcDailyUsgNonPlan, 1000);
			}catch(CalnetException ex){
				severe(ex.getMessage(), ex);
				success = false;
			}
		}
		rabcDailyUsgNonPlan = null;
		return super.postprocessFile(file, success);
	}
}
