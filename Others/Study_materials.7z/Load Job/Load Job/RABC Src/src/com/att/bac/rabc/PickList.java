/*
 * � 2002-2007 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc;

import java.io.Serializable;


/**
 * This bean implements a key value pair.
 * 
 * <p>
 * <hr>
 * <h3>Release History</h3>
 * <p>
 * <ul>
 * 
 * <li>PD2951 20051229 Initial version for EAP 556010
 * <li>jb6494 Mar 5, 2007 Made class serializable.
 * 
 * </ul>
 * <p>
 * 
 */
public class PickList implements Serializable {

    private String key = null;

    private String value1 = null;

    private String value2 = null;

    private String value3 = null;


    /**
     * @param key
     * @param value
     */
    public PickList(String key, String value) {
        this(key, value, null, null);
    }


    /**
     * @param key
     * @param value1
     * @param value2
     */
    public PickList(String key, String value1, String value2) {
        this(key, value1, value2, null);
    }


    /**
     * @param key
     * @param value1
     * @param value2
     * @param value3
     */
    public PickList(String key, String value1, String value2, String value3) {
        this.key = key;
        this.value1 = value1;
        this.value2 = value2;
        this.value3 = value3;
    }


    /**
     * @return
     */
    public String getKey() {
        return key;
    }


    /**
     * @return
     */
    public String getValue1() {
        return value1;
    }


    /**
     * @return
     */
    public String getValue2() {
        return value2;
    }


    /**
     * @return
     */
    public String getValue3() {
        return value3;
    }
}
