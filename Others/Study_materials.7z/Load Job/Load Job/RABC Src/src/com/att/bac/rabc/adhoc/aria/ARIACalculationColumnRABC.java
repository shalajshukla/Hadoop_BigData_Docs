/*
 * Copyright  2002-2006 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.adhoc.aria;

import com.att.bac.rabc.adhoc.rpt.generator.Calculation;
import com.sbc.bac.aria.ARIACalculationColumn;
import com.sbc.bac.aria.ARIADataPoint;
import com.sbc.bac.aria.ARIAReport;


/**
 * Custom column to keep track of dto indexs
 * 
 * <p>
 * <hr>
 * <h3>Release History</h3>
 * <p>
 * <ul>
 * 
 * <li>jb6494 Aug 11, 2006 Created class.
 * <li>jb6494 Mar 15, 2007 ML22 - fixed issue with table0.point0 being used in translation
 * 
 * </ul>
 * <p>
 * 
 */
public class ARIACalculationColumnRABC extends ARIACalculationColumn implements IAdhocDTOIndex {

    private Calculation calculation;

    private int dtoIndex;


    public ARIACalculationColumnRABC(String name, Calculation calc, ARIAReport report, int dtoIndex) {
        super(name, calc.getFormula(), report);
        this.dtoIndex = dtoIndex;
        calculation = calc;
    }


    /**
     * @return Returns the calculation.
     */
    public Calculation getCalculationObject() {
        return calculation;
    }


    /*
     * (non-Javadoc)
     * 
     * @see com.att.bac.rabc.adhoc.aria.IAdhocDTOIndex#getDtoIndex()
     */
    public int getDtoIndex() {
        return dtoIndex;
    }


    /**
     * @param calculation The calculation to set.
     */
    public void setCalculationObject(Calculation calculation) {
        this.calculation = calculation;
    }


    /**
     * @param dtoIndex The dtoIndex to set.
     */
    public void setDtoIndex(int dtoIndex) {
        this.dtoIndex = dtoIndex;
    }


    /**
     * Overridden to deal with a difference in how ARIA should be done and how it has been done in RABC. The issue is
     * that the column name being setup in RABC includes the table name. So, the default implementation of this method
     * resulted in a return value of <table>.<table>.<column>
     * 
     * @see com.sbc.bac.aria.ARIACalculationColumn#getQualifiedName(com.sbc.bac.aria.ARIADataPoint)
     */
    protected String getQualifiedName(ARIADataPoint dp) {
        if (dp.getColumn().equals("1")) {
            return "___ignore this garbage___";
        }
        return dp.getColumn();
    }

}
