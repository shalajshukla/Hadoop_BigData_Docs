/*
 * Module description: 
 * Load job for SO control point in case of SW region.
 * 
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 *
 * Modification History:                                     
 * SBCUID		Date			Description                         	    	
 * ------		--------		-----------
 * UD7153		20060817		Initial version for EAP 556013  
 */
package com.att.bac.rabc.load.so.sw;

public class SummaryData {

	private String mktInd ; 
	private String svcOrdType ; 
	private long SVC_ORD_INPUT_CT = 0 ; 
	private long SVC_ORD_CMPL_CT = 0 ;
	private long SVC_ORD_INTERIM_CT = 0 ;
	private long SVC_ORD_ERR_CT = 0 ;

	//default value for hashcode return value
	private static final int DEFAULT	= 03;
	
	/**
	 * @return Returns the mktInd.
	 */
	public String getMktInd() {
		return mktInd;
	}
	/**
	 * @param mktInd The mktInd to set.
	 */
	public void setMktInd(String mktInd) {
		this.mktInd = mktInd;
	}
	/**
	 * @return Returns the svcOrdType.
	 */
	public String getSvcOrdType() {
		return svcOrdType;
	}
	/**
	 * @param svcOrdType The svcOrdType to set.
	 */
	public void setSvcOrdType(String svcOrdType) {
		this.svcOrdType = svcOrdType;
	}
	/**
	 * @return Returns the sVC_ORD_CMPL_CT.
	 */
	public long getSVC_ORD_CMPL_CT() {
		return SVC_ORD_CMPL_CT;
	}
	/**
	 * @param svc_ord_cmpl_ct The sVC_ORD_CMPL_CT to set.
	 */
	public void setSVC_ORD_CMPL_CT(long svc_ord_cmpl_ct) {
		SVC_ORD_CMPL_CT = svc_ord_cmpl_ct;
	}
	/**
	 * @return Returns the sVC_ORD_INPUT_CT.
	 */
	public long getSVC_ORD_INPUT_CT() {
		return SVC_ORD_INPUT_CT;
	}
	/**
	 * @param svc_ord_input_ct The sVC_ORD_INPUT_CT to set.
	 */
	public void setSVC_ORD_INPUT_CT(long svc_ord_input_ct) {
		SVC_ORD_INPUT_CT = svc_ord_input_ct;
	}
	/**
	 * @return Returns the sVC_ORD_INTERIM_CT.
	 */
	public long getSVC_ORD_INTERIM_CT() {
		return SVC_ORD_INTERIM_CT;
	}
	/**
	 * @param svc_ord_interim_ct The sVC_ORD_INTERIM_CT to set.
	 */
	public void setSVC_ORD_INTERIM_CT(long svc_ord_interim_ct) {
		SVC_ORD_INTERIM_CT = svc_ord_interim_ct;
	}
	/**
	 * @return Returns the sVC_ORD_ERR_CT.
	 */
	public long getSVC_ORD_ERR_CT() {
		return SVC_ORD_ERR_CT;
	}
	/**
	 * @param svc_ord_err_ct The sVC_ORD_ERR_CT to set.
	 */
	public void setSVC_ORD_ERR_CT(long svc_ord_err_ct) {
		SVC_ORD_ERR_CT = svc_ord_err_ct;
	}
	
	public boolean equals(Object o) {
		if ((o instanceof SummaryData) 
				&& ((SummaryData)o).getMktInd().equalsIgnoreCase(this.getMktInd())
				&& ((SummaryData)o).getSvcOrdType().equalsIgnoreCase(this.getSvcOrdType())
				) 
		{
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * Hash code method used for categorizing the objects in sets so that the hash collections can search efficiently
	 */
	public int hashCode() {
		if (mktInd !=null) 
			return Integer.parseInt(mktInd);
	
		return DEFAULT;
	}
	
}
