/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.admin;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;

/**
 * This is a DAO that performs SELECT, INSERT and UPDATE on RABC_PRESN_HEADER table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class PresnHeaderDAO {
	private static final Logger logger = Logger.getLogger(PresnHeaderDAO .class);

	/**
	 * Returns the list of PresnHeader objects.
	 * 
	 * @param conn 
	 * @param failures
	 * @param args
	 * @param baseSQL
	 * @return List
	 */
	public List get(Connection conn, List failures, List args, String baseSQL) {
		List presnHeaderList = null;
		PresnHeader presnHeader = null;
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		
		try
		{
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("PresnHeaderDAO  - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			presnHeaderList = new ArrayList();
			while (rs.next()) {
				presnHeaderList.add(buildPresnHeader(rs));
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return null;
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
		
		return presnHeaderList;
	}

	/**
	 * Private method to build PresnHeader object and return it to caller.
	 * 
	 * @param rs
	 * @return PresnHeader
	 * @throws SQLException
	 */
	private PresnHeader buildPresnHeader(ResultSet rs) throws SQLException {
		PresnHeader presnHeader = new PresnHeader();
		
		presnHeader.setPresnId(rs.getInt("PRESN_ID"));
		presnHeader.setWebid(rs.getString("WEBID"));
		presnHeader.setHeader1(rs.getString("HEADER1"));
		presnHeader.setHeader2(rs.getString("HEADER2"));
		presnHeader.setHeader3(rs.getString("HEADER3"));
		presnHeader.setPresnDateInd(rs.getString("PRESN_DATE_IND"));
		return presnHeader;
	}

	/**
	 * Execute the insert or update statement on RABC_PRESN_HEADER  table.
	 * 
	 * @param conn
	 * @param failures
	 * @param args
	 * @param baseSQL
	 */
	public void executeUpdate(Connection conn, List failures, List args, String baseSQL) {
		int rowsUpdated = 0;
		Statement stmt = null;
		String sqlStmt = null;
		
		try
		{
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("PresnHeaderDAO  - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rowsUpdated = stmt.executeUpdate(sqlStmt);
			logger.debug("SQL - Execution complete."+ String.valueOf(rowsUpdated) + "  rows updated");
			
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return;
		} finally {
			SQLHelper.closeStatement(stmt, failures, logger);
		}
	}

}
