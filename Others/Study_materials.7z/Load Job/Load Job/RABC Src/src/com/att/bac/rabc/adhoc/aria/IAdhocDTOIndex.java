/*
 * Copyright  2002-2006 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.adhoc.aria;

/**
 * Interface to indicate that a RABC column under ARIA has access to it's index in the DTO arrays.
 * 
 * <p>
 * <hr>
 * <h3>Release History</h3>
 * <p>
 * <ul>
 * 
 * <li>jb6494 Aug 11, 2006 Created class.
 * 
 * </ul>
 * <p>
 * 
 */
public interface IAdhocDTOIndex {

    /**
     * Get the index to the AdhocRptDataTO object.
     * 
     * @return
     */
    int getDtoIndex();
}
