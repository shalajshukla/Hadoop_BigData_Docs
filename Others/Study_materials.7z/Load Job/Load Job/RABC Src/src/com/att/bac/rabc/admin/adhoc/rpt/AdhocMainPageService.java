/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.admin.adhoc.rpt;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;

import com.att.bac.rabc.PickList;
import com.att.bac.rabc.PresnId;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.admin.AlertGroupFunctDAO;
import com.att.bac.rabc.admin.AlertGroupUser;
import com.att.bac.rabc.admin.AlertGroupUserDAO;
/**
 * Module description: 
 * 
 * This is a service class to provide the business logic. The methods in this class are called by the
 * action class. They internaly calls the DAO classes to do the required manipulation and returns the 
 * result to the action class. This paricular service class that holds the adhoc report name List.
 *                              
 * @author Anup Thomas - AT1862
 */
public class AdhocMainPageService {
	private static final Logger logger = Logger.getLogger(AdhocMainPageService.class);
	private static AdhocMainPageService adhocMainPageService;

	/*
	 * Variables to represent the sql statements.
	 */
	protected static final String getPresnName = " SELECT DISTINCT PRESN_ID, PRESN_NAME, ASSOC_PARENT_ID,SUB_ASSOC_PARENT_ID "
           			+ " FROM RABC_MENU_INDEX WHERE PRESN_ID IN (SELECT PRESN_ID FROM RABC_PRESN_ID WHERE UPPER (ADHOC_RPT_STATUS) = ''ACTIVE'' " 
           			+ " AND UPPER (ADHOC_RPT_IND) = ''Y'') AND PRESN_TYPE = ''P'' AND PRESN_LVL = 3 AND PRESN_NAME IS NOT NULL "
           			+ " ORDER BY ASSOC_PARENT_ID,SUB_ASSOC_PARENT_ID, UPPER (PRESN_NAME) ASC " ;
	
	protected static final String getReportCategories = "SELECT PRESN_NAME, PRESN_SEQ_NUM FROM RABC_MENU_INDEX WHERE PRESN_TYPE = ''P'' AND " 
													+ "PRESN_LVL = 1 ORDER BY PRESN_SEQ_NUM" ;
	
	protected static final String getUserDirectories = "SELECT   PRESN_NAME, PRESN_SEQ_NUM FROM RABC_MENU_INDEX WHERE PRESN_TYPE = ''P'' "
													+ " AND PRESN_LVL = 2 AND (    UPPER (PRESN_NAME) <> ''ALERT REPORTS''"
													+ " AND UPPER (PRESN_NAME) <> ''ADHOC REPORTS'') ORDER BY PRESN_SEQ_NUM";
	
	private static final String alertGrpUser="SELECT A.ALERT_GRP,B.USER_ID FROM RABC_ALERT_GRP A ,RABC_ALERT_GRP_USER B WHERE UPPER(B.USER_ID)=UPPER(''{0}'') AND A.ALERT_GRP = B.ALERT_GRP";
	
	private static final String alertGrpFunct = "SELECT	ALERT_GRP,FUNCT_CD FROM	RABC_ALERT_GRP_FUNCT WHERE FUNCT_CD=''{1}'' AND UPPER(ALERT_GRP)=UPPER(''{2}'')";
	
	protected static final String checkUpdatePermission = "SELECT ALERT_GRP FROM RABC_UPDATE_GRP WHERE " +
	"ALERT_GRP IN (SELECT DISTINCT ALERT_GRP FROM RABC_ALERT_GRP_USER WHERE USER_ID = UPPER(''{0}'')) AND " +
	"PRESN_ID = ''{1}''";
	
	protected static final String currGrps = "SELECT ALERT_GRP FROM RABC_UPDATE_GRP WHERE PRESN_ID = ''{0}'' " +
	"ORDER BY UPPER(ALERT_GRP)";
	
	/**
	 * Synchronized method to create only 1 instance of AdhocMainPageService
	 * 
	 * @return AdhocMainPageService
	 */
	public static synchronized AdhocMainPageService getAdhocMainPageService(){
		if (adhocMainPageService == null){
			adhocMainPageService = new AdhocMainPageService();
		}	
		return adhocMainPageService;
	}
	
	/**
	 * This method interacts with presnIdDAO and prepares list of the presnId objects.  
	 * @param connection
	 * @param failures
	 * @param args
	 * @return List
	 */
	public List getReportNameList(Connection connection, List failureList, List args) {
		List completeList = new ArrayList();
		/*
		 * Get the list of report categories
		 */
		List categoryList = getReportCategoryList(connection,failureList,args);
		/*
		 * Get the list of user directories
		 */
		List userDirectoryList = getUserDirectoryList(connection,failureList,args);
		
		/*
		 * Get the list of reports
		 */
		List reportList = getReportList(connection,failureList,args);
		
		/*
		 * Loop through the list of categories
		 */
		int categoryListSize = categoryList.size();
		int reportListSize = reportList.size();
		int userDirectoryListSize = userDirectoryList.size();
		
		/*
		 * Form list of sequence numbers for user directories 
		 */
		List userDirectorySeqNumList = new ArrayList();
		for (int i=0;i<userDirectoryListSize;i++) {
			PickList userDir = (PickList)userDirectoryList.get(i);
			userDirectorySeqNumList.add(userDir.getValue1());
		}
		
		for (int i=0;i<categoryListSize;i++){
			PickList reportCategory = (PickList)categoryList.get(i);
			String seqNum = reportCategory.getValue1();
			PresnId catPresnId = new PresnId();
			catPresnId.setPresnId(-1);
			catPresnId.setPresnIdDesc(reportCategory.getKey());
			completeList.add(catPresnId);
			
			if ("4".equals(seqNum)){
				// First add the reports which are not in any user directory
				for (int j=0;j<reportListSize;j++){
					PickList report = (PickList)reportList.get(j);
					if (!userDirectorySeqNumList.contains(report.getValue3())){
						if (seqNum.equals(report.getValue2())){
							PresnId presnId = new PresnId();
							presnId.setPresnId(Integer.parseInt(report.getKey()));
							presnId.setPresnIdDesc(report.getValue1());
							completeList.add(presnId);
						}
					}
				}
				
				// Now add the respective reports
				for (int k=0;k<userDirectoryListSize;k++) {
					PickList userDir = (PickList)userDirectoryList.get(k);
					PresnId dirPresnId = new PresnId();
					dirPresnId.setPresnId(-2);
					dirPresnId.setPresnIdDesc(userDir.getKey());
					completeList.add(dirPresnId);
					
					for (int j=0;j<reportListSize;j++){
						PickList report = (PickList)reportList.get(j);
						
						if (userDir.getValue1().equals(report.getValue3())){
							PresnId presnId = new PresnId();
							presnId.setPresnId(Integer.parseInt(report.getKey()));
							presnId.setPresnIdDesc(report.getValue1());
							completeList.add(presnId);
						}
					}
				}
			} else {
				for (int j=0;j<reportListSize;j++){
					PickList report = (PickList)reportList.get(j);
					if (seqNum.equals(report.getValue2())){
						PresnId presnId = new PresnId();
						presnId.setPresnId(Integer.parseInt(report.getKey()));
						presnId.setPresnIdDesc(report.getValue1());
						completeList.add(presnId);
					}
				}
			}
		}
		
		return completeList;
	 }	
	
	/**
	 * Private method to return list of valid reports
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return
	 */
	private List getReportList(Connection connection, List failureList, List args){
		String selectSQL = getPresnName;
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		List presnIdList = new ArrayList();
		PickList presnId = null ;
		try	{
			MessageFormat mf = new MessageFormat(selectSQL);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			
			while(rs.next()){
				presnId = buildReports(rs);
				presnIdList.add(presnId);
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
			return null;
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		return presnIdList ; 
	}
	
	/**
	 * Return list of report categories
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return
	 */
	private List getReportCategoryList(Connection connection, List failureList, List args){
		String selectSQL = getReportCategories;
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		List categoryList = new ArrayList();
		try	{
			MessageFormat mf = new MessageFormat(selectSQL);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			
			while(rs.next()){
				categoryList.add(new PickList(rs.getString("PRESN_NAME"),rs.getString("PRESN_SEQ_NUM")));
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
			return null;
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		return categoryList ; 
	}
	
	/**
	 * Returns list of user directories
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return
	 */
	private List getUserDirectoryList(Connection connection, List failureList, List args){
		String selectSQL = getUserDirectories;
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		List userDirectoryList = new ArrayList();
		try	{
			MessageFormat mf = new MessageFormat(selectSQL);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			
			while(rs.next()){
				userDirectoryList.add(new PickList(rs.getString("PRESN_NAME"),rs.getString("PRESN_SEQ_NUM")));
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
			return null;
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		return userDirectoryList ; 
	}

	/**
	 * It is a private method to build PresnId objects from current record and returns it
	 * @param rs
	 * @return PresnId
	 */
	private PickList buildReports(ResultSet rs) throws SQLException {
		PickList report = new PickList(rs.getString("PRESN_ID"),rs.getString("PRESN_NAME"),rs.getString("ASSOC_PARENT_ID"),rs.getString("SUB_ASSOC_PARENT_ID"));
		return report;
	}

	/**
	 * This method interacts with AlertGroupUserDAO and finds that user has the permission for update or not.  
	 * @param connection
	 * @param args
	 * @param failures
	 * @return true/false 
	 */
	public boolean getPermissionAdhocReport(Connection connection, List args,List failureList) {
		boolean hasPermission = false ;
		//args[0] is logged in user id 
		//args[1] is function id , like "UR" for update report  
		//find out  to which group  the user belongs 
		
		AlertGroupUserDAO alertGroupUserDAO = new AlertGroupUserDAO();
		List alertGroupUserList = new ArrayList(); 
		alertGroupUserList = alertGroupUserDAO.get(connection,failureList,args,alertGrpUser);
		
		if (alertGroupUserList!=null){
			int alertGroupUserListSize=alertGroupUserList.size();
			if (alertGroupUserListSize>0){
				for (int i=0;i<alertGroupUserListSize;i++){
					
					AlertGroupUser alertGroupUser = (AlertGroupUser)alertGroupUserList.get(i);
					String userGroup = alertGroupUser.getAlertGrp();
					args.add(userGroup);
					//find whether the user has the permission to do the operation 
					AlertGroupFunctDAO alertGroupFunctDAO  = new AlertGroupFunctDAO();  
					List alertGroupFunctList  = alertGroupFunctDAO.get(connection,failureList,args,alertGrpFunct);
					if (alertGroupFunctList!=null){
						int alertGroupFunctListSize = alertGroupFunctList.size();
							
						if (alertGroupFunctListSize>0){
							hasPermission = true ;
							break;
						}
					}
					//remove the argument from the list , so that it add to the position 2
					//in the next iteration
					args.remove(2);
				}	
			}
		}
		return hasPermission;
	}
	
	/**
	 * This method checks the update access for user. Returns 1 if count is greater than 0.
	 * @param connection
	 * @param failures
	 * @param arguments
	 * @return true/false
	 */
	public boolean checkUpdateAccess(Connection connection, List failures, List arguments){
		int count = 0;
		boolean permission;
		String selectSQL = checkUpdatePermission;
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		List args = new ArrayList();
		args.add(arguments.get(0));
		args.add(arguments.get(1));
		
		try {
			MessageFormat mf = new MessageFormat(selectSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("AdhocMainPageService.checkUpdateCount() - Executing SQL statement: "+ sqlStmt);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			
			while (rs.next()) {
				count++;
			}
			if (count > 0){
				permission = true;
			}else {
				permission = false;
			}
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return false;
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}		
		return permission;
	}
	
	/**
	 * This method is used to get for a perticular presn id. 
	 * @param connection
	 * @param failures
	 * @param arguments
	 * @return String
	 */
	public String getCurrGrps (Connection connection, List failures, List arguments) {
		String currGroups = null;
		String selectSQL = currGrps;
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		List args = new ArrayList();
		args.add(arguments.get(0));
		
		try {
			MessageFormat mf = new MessageFormat(selectSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("AdhocMainPageService.getCurrGrps() - Executing SQL statement: "+ sqlStmt);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			
			while (rs.next()) {
				if (currGroups==null){
					currGroups = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + rs.getString("ALERT_GRP");
				}else {
					currGroups = currGroups + "<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + (rs.getString("ALERT_GRP"));
				}
			}
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return null;
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}		
		return currGroups;
	}
}
