/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc;
import java.util.Date;

/**
 * This is a Data Object to represent RABC_VIEW table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class View {
	private String viewName;
	private String tableName;
	private String viewDesc;
	private String selectValue;
	private String prevInd;
	private String userId;
	private Date timeStamp;
	
	/**
	 * @return Returns the viewName.
	 */
	public String getViewName() {
		return viewName;
	}
	/**
	 * @param viewName The viewName to set.
	 */
	public void setViewName(String viewName) {
		this.viewName = viewName;
	}
	
	/**
	 * @return Returns the TableName.
	 */
	public String getTableName() {
		return tableName;
	}
	/**
	 * @return Returns the ViewDesc.
	 */
	public String getViewDesc() {
		return viewDesc;
	}
	/**
	 * @return Returns the SelectValue.
	 */
	public String getSelectValue() {
		return selectValue;
	}
	/**
	 * @return Returns the PrevInd.
	 */
	public String getPrevInd() {
		return prevInd;
	}
	/**
	 * @return Returns the UserId.
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @return Returns the TimeStamp.
	 */
	public Date getTimeStamp() {
		return timeStamp;
	}

	/**
	 * @param TableName The tableName to set.
	 */
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	/**
	 * @param ViewDesc The viewDesc to set.
	 */
	public void setViewDesc(String viewDesc) {
		this.viewDesc = viewDesc;
	}
	/**
	 * @param SelectValue The selectValue to set.
	 */
	public void setSelectValue(String selectValue) {
		this.selectValue = selectValue;
	}
	/**
	 * @param PrevInd The prevInd to set.
	 */
	public void setPrevInd(String prevInd) {
		this.prevInd = prevInd;
	}
	/**
	 * @param UserId The userId to set.
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	/**
	 * @param TimeStamp The timeStamp to set.
	 */
	public void setTimeStamp(Date timeStamp) {
		this.timeStamp = timeStamp;
	}
}
