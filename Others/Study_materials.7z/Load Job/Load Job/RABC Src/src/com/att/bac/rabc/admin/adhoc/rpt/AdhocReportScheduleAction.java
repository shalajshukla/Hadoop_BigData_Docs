/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.admin.adhoc.rpt;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.att.bac.rabc.ConnectionManager;
import com.att.bac.rabc.PickList;
import com.att.bac.rabc.PresnId;
import com.att.bac.rabc.ProgressBar;
import com.att.bac.rabc.RABCConstantsLists;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.StaticDataLoader;

/**
 * Module description: 
 * 
 * This is adhoc report schedule action class 
 * @author AT1862 - anup Thomas
 */
public class AdhocReportScheduleAction extends DispatchAction {
	private static final Logger logger = Logger.getLogger(AdhocReportDefinitionAction.class);
	AdhocReportScheduleService adhocReportScheduleService = AdhocReportScheduleService.getAdhocReportScheduleService();
	
	/**
	 * Default dispatch action method to handle the request for Adhoc Report navigation.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @see org.apache.struts.actions.DispatchAction#unspecified(org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public ActionForward unspecified(ActionMapping mapping,ActionForm form,HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		ProgressBar progressBar = new ProgressBar(session);
		return loadSchedule(mapping,form,request,response);
	}
	
	/**
	 * Dispatch action method which will load the scheduler entries for the selected presn_id.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * 
	 */
	public ActionForward loadSchedule(ActionMapping mapping,ActionForm form,HttpServletRequest request, HttpServletResponse response) {
		ActionForward forward = null ;
		AdhocReportScheduleForm adhocReportScheduleForm = (AdhocReportScheduleForm) form;
		setFormFields(adhocReportScheduleForm, (String)request.getSession().getAttribute("region"));
		HttpSession session = request.getSession();
		ProgressBar progressBar = new ProgressBar(session);

		Connection connection = null ;
		List failureList = new ArrayList();
		List args = new ArrayList();
		
		progressBar.setProgressPercent(10);
		
		/*
		 * Add the user id & presn_id for report obtained from session to the argument list & pass to the 
		 * service class layer to get the 
		 */
		String userId = null;
		String presnId = null;
		if (request.getSession().getAttribute("bacUserID")!=null){
			userId = (String)request.getSession().getAttribute("bacUserID");
		}
		if (request.getAttribute("presnId")!=null){
			presnId = (String)request.getAttribute("presnId");
		}
		if (presnId==null && adhocReportScheduleForm.getPresnId()!=0){
			presnId = Integer.toString(adhocReportScheduleForm.getPresnId());
		}
		
		if (presnId==null || userId==null){
			logger.error("Request attributes (either PresnId or User id )not obtained");

			forward = mapping.findForward("error");
		}else {
			args.add(userId) ;
			args.add(presnId);
			
			List adhocReportScheduleList = new ArrayList();
			
			/*
			 * Default forward is to the scheduler page
			 */
			forward =  mapping.findForward("AdhocReportSchedule");

			try {
				connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
				progressBar.setProgressPercent(20);
				
				/*
				 * Call the private method to set the option list for 
				 */
				populateAdhocReportScheduleOptionValues(connection,failureList,adhocReportScheduleForm);
				progressBar.setProgressPercent(40);
				
				AdhocReportDefinitionService   adhocReportDefinitionService = new AdhocReportDefinitionService();
				//find whether the user has the permission to save report scheduler 
				List permissionArgs = new ArrayList();
				permissionArgs.add((String)request.getSession().getAttribute("bacUserID")) ;
				permissionArgs.add("UR") ;
				String hasPermission  = adhocReportDefinitionService.getPermissionAdhocReport(connection,permissionArgs,failureList);
				progressBar.setProgressPercent(60);
				adhocReportScheduleForm.setHasPermissionToSave(hasPermission);
				
				if (presnId!=null){
					adhocReportScheduleList = adhocReportScheduleService.getAdhocReportScheduleList(connection,failureList,args,(String)request.getSession().getAttribute("region"));
					if (!adhocReportScheduleList.isEmpty()){
						int adhocReportScheduleListSize = adhocReportScheduleList.size();
						for (int i=0;i<adhocReportScheduleListSize;i++){
							AdhocReportSchedule adhocReportSchedule = (AdhocReportSchedule) adhocReportScheduleList.get(i);
							adhocReportScheduleForm.addAdhocReportSchedule(adhocReportSchedule);
						}
					}
					progressBar.setProgressPercent(80);
					
					//set the report type to the  adhocReportScheduleForm
					List presnIdList =  adhocReportDefinitionService.getPresenDetails(connection,failureList,args) ;
					PresnId presnIdObj = (PresnId)presnIdList.get(0);
					
					adhocReportScheduleForm.setRptType(presnIdObj.getPresnTrendTime());
					adhocReportScheduleForm.setPresnId(Integer.parseInt(presnId));
				}
				progressBar.setProgressPercent(90);
			} catch(SQLException sx) {
				logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
				failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
			} catch(NamingException ne) {
				logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
				failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
			} catch(Exception e) {
				logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
		        failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
			} finally {
				SQLHelper.closeConnection(connection, failureList, logger);
			}
		}
		progressBar.setProgressPercent(100);

		if (!failureList.isEmpty()){
			request.setAttribute("failures",failureList);
			forward = mapping.findForward("error");
		}
		
		return forward ;
	}

	/**
	 * Dispatch action method to save the scheduler entries for the selected presn_id.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward saveSchedule(ActionMapping mapping,ActionForm form,HttpServletRequest request, HttpServletResponse response)  {
		ActionForward forward = null ;
		AdhocReportScheduleForm adhocReportScheduleForm = (AdhocReportScheduleForm) form;
		setFormFields(adhocReportScheduleForm, (String)request.getSession().getAttribute("region"));
		HttpSession session = request.getSession();
		ProgressBar progressBar = new ProgressBar(session);
		List failureList = new ArrayList();
		Connection connection = null ;
		progressBar.setProgressPercent(10);
		
		try {
			connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
			progressBar.setProgressPercent(20);
			connection.setAutoCommit(false);
			AdhocReportSchedule adhocReportSchedule = getAdhocReportSchedule(failureList,adhocReportScheduleForm,(String)request.getSession().getAttribute("region"));
			progressBar.setProgressPercent(30);
			adhocReportScheduleService.addSchedule(connection,failureList,adhocReportSchedule,progressBar);
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		}  catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
	        failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			if (!failureList.isEmpty()){
				try {
					connection.rollback();
				}catch(SQLException sx) {
				   logger.error(RABCMessages.getMessage("ERR_SQL_ROLLBACK_EXEC") + " Exception details: " + sx.getMessage(), sx);
				   failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_ROLLBACK_EXEC"), sx));
				} 
			}else {
				// No errors; commit the transaction
				try {
					connection.commit();
				}catch(SQLException sx) {
				   logger.error(RABCMessages.getMessage("ERR_SQL_COMMIT_EXEC") + " Exception details: " + sx.getMessage(), sx);
				   failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_COMMIT_EXEC"), sx));
				} 
			}
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		progressBar.setProgressPercent(100);
		
		if (!failureList.isEmpty()){
			request.setAttribute("failures",failureList);
			forward = mapping.findForward("error");
			return forward ;
		}else {
			return loadSchedule(mapping,adhocReportScheduleForm,request,response);
		}	
	}
	
	/**
	 * Dispatch action method to delete the scheduler entries for the selected presn_id.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward deleteSchedule(ActionMapping mapping,ActionForm form,HttpServletRequest request, HttpServletResponse response) {
		ActionForward forward = null ;
		AdhocReportScheduleForm adhocReportScheduleForm = (AdhocReportScheduleForm) form;
		setFormFields(adhocReportScheduleForm, (String)request.getSession().getAttribute("region"));
		HttpSession session = request.getSession();
		ProgressBar progressBar = new ProgressBar(session);
		List failureList = new ArrayList();	
		Connection connection = null ;
		progressBar.setProgressPercent(10);
		
		try {
			connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
			progressBar.setProgressPercent(20);
			connection.setAutoCommit(false);
			progressBar.setProgressPercent(30);
			//we are using differnt form variables for insert and update . 
			//AdhocReportSchedule adhocReportSchedule = getAdhocReportScheduleForEdit(failureList,adhocReportScheduleForm);
			adhocReportScheduleService.deleteSchedule(connection,failureList,adhocReportScheduleForm.getSelectedScheduleId(),progressBar);
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
	        failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			if (!failureList.isEmpty()){
				try {
					connection.rollback();
				}catch(SQLException sx) {
				   logger.error(RABCMessages.getMessage("ERR_SQL_ROLLBACK_EXEC") + " Exception details: " + sx.getMessage(), sx);
				   failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_ROLLBACK_EXEC"), sx));
				} 
			}else {
				// No errors; commit the transaction
				try {
					connection.commit();
				}catch(SQLException sx) {
				   logger.error(RABCMessages.getMessage("ERR_SQL_COMMIT_EXEC") + " Exception details: " + sx.getMessage(), sx);
				   failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_COMMIT_EXEC"), sx));
				} 
			}
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		progressBar.setProgressPercent(100);
		
		if (!failureList.isEmpty()){
			if (isSerialiZableErrorOccured(failureList)){
				return loadSchedule(mapping,adhocReportScheduleForm,request,response);
			}else{
				request.setAttribute("failures",failureList);
				return mapping.findForward("error");
			}
		}else {
			return loadSchedule(mapping,adhocReportScheduleForm,request,response);
		}
	}
	
	/**
	 * Private method to check serializable error occured or not. 
	 * 
	 * @param failureList
	 * @return true/false
	 */
	private boolean isSerialiZableErrorOccured(List failureList) {
		boolean serialiZableErrorOccured = false;
		RABCException rex = null;
		List errorCauseDetailsList = null;
		PickList errorCauseDetails = null;
		
		int failureListSize = failureList.size();
		
		for (int i=0; i<failureListSize; i++) {
			rex = (RABCException) failureList.get(i);
			errorCauseDetailsList = rex.getErrorCauseDetailsList();
			if (errorCauseDetailsList != null) {
				int errorCauseDetailsListSize = errorCauseDetailsList.size();
				for (int j=0; j<errorCauseDetailsListSize; j++) {
					errorCauseDetails = (PickList) errorCauseDetailsList.get(j);
					if ((errorCauseDetails.getValue1().indexOf("ORA-08177") != -1)&&(failureListSize==1)) {
						serialiZableErrorOccured = true;
					}
				}
			}
		}
		
		return serialiZableErrorOccured;
	}

	/**
	 * Dispatch action method to update the scheduler entries for the selected presn_id.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward updateSchedule(ActionMapping mapping,ActionForm form,HttpServletRequest request, HttpServletResponse response) {
		ActionForward forward = null ;
		AdhocReportScheduleForm adhocReportScheduleForm = (AdhocReportScheduleForm) form;
		setFormFields(adhocReportScheduleForm, (String)request.getSession().getAttribute("region"));
		HttpSession session = request.getSession();
		ProgressBar progressBar = new ProgressBar(session);
		List failureList = new ArrayList();		
		Connection connection = null ;
		progressBar.setProgressPercent(10);
		
		try {
			connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
			progressBar.setProgressPercent(20);
			connection.setAutoCommit(false);
			//we are using differnt form variables for insert and update . 
			AdhocReportSchedule adhocReportSchedule = getAdhocReportScheduleForEdit(failureList,adhocReportScheduleForm,(String)request.getSession().getAttribute("region"));
			progressBar.setProgressPercent(30);
			adhocReportScheduleService.addSchedule(connection,failureList,adhocReportSchedule,progressBar);
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch(Exception e){
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
	        failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			if (!failureList.isEmpty()){
				try {
					connection.rollback();
				}catch(SQLException sx) {
				   logger.error(RABCMessages.getMessage("ERR_SQL_ROLLBACK_EXEC") + " Exception details: " + sx.getMessage(), sx);
				   failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_ROLLBACK_EXEC"), sx));
				} 
			}else {
				// No errors; commit the transaction
				try {
					connection.commit();
				}catch(SQLException sx) {
				   logger.error(RABCMessages.getMessage("ERR_SQL_COMMIT_EXEC") + " Exception details: " + sx.getMessage(), sx);
				   failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_COMMIT_EXEC"), sx));
				} 
			}
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		progressBar.setProgressPercent(100);
		
		if (!failureList.isEmpty()){
			request.setAttribute("failures",failureList);
			forward = mapping.findForward("error");
			return forward ;
		}else {
			return loadSchedule(mapping,adhocReportScheduleForm,request,response);
		}
	}
	
	/**
	 * This is a private method, will be called to set the default values in the form variables for adding new schedule entries
	 * @param connection
	 * @param failureList
	 * @param adhocReportScheduleForm
	 */
	private void populateAdhocReportScheduleOptionValues(Connection connection,List failureList,
			AdhocReportScheduleForm adhocReportScheduleForm){
		AdhocMainPageService adhocMainPageService = new AdhocMainPageService();
		List args = new ArrayList();
		/* 
		 * Get the existing adhoc reports and store them in arraylist
		 */
		adhocReportScheduleForm.getReportNameList().clear();
		List presnIdlist = adhocMainPageService.getReportNameList(connection,failureList,args) ;
		if (!presnIdlist.isEmpty()){
			int presnIdlistSize = presnIdlist.size();
			for (int i=0;i<presnIdlistSize;i++){
				PresnId presnId = (PresnId)presnIdlist.get(i);
				adhocReportScheduleForm.addReportName(presnId);
			}
		}
		
		/*
		 * Default values for the various attributes
		 */
		adhocReportScheduleForm.setDays("");
		adhocReportScheduleForm.setEmailTo("");
		adhocReportScheduleForm.setFrequency("");
		adhocReportScheduleForm.setFrequencyDataCycleCode("");
		adhocReportScheduleForm.setFrequencyDataMonthly("");
		adhocReportScheduleForm.setFrequencyDataRunDay("");
		adhocReportScheduleForm.setFrequencyDataWeekly("");
		adhocReportScheduleForm.setFrequencyDataYearly("");
		adhocReportScheduleForm.setSaveToDisk("");
		adhocReportScheduleForm.setStartDate("");	
		adhocReportScheduleForm.setHasPermissionToSave("N");
	}
	
	/**
	 * This is a utility method that returns an object of type AdhocReportSchedule setting its attributes using the variables
	 * obtained from the form. This object will then be passed to the service layer to carry out the insert
	 * operations.
	 * 
	 * @param failureList
	 * @param adhocReportScheduleForm
	 * @param region
	 * @return AdhocReportSchedule
	 */
	private AdhocReportSchedule getAdhocReportSchedule(List failureList,AdhocReportScheduleForm adhocReportScheduleForm,String region){	
		AdhocReportSchedule adhocReportSchedule = new AdhocReportSchedule(region);
		
		adhocReportSchedule.setDays(adhocReportScheduleForm.getDays());
		adhocReportSchedule.setEmailTo(adhocReportScheduleForm.getEmailTo());
		adhocReportSchedule.setFrequency(adhocReportScheduleForm.getFrequency());
		//adhocReportSchedule.setFrequencyData(adhocReportScheduleForm.getFrequencyData());
		adhocReportSchedule.setPresnId(adhocReportScheduleForm.getPresnId());
		adhocReportSchedule.setStartDate(adhocReportScheduleForm.getStartDate());
		String frequencyData="";
		if (adhocReportScheduleForm.getFrequency().equals("W")){
			adhocReportSchedule.setFrequencyDataWeekly(adhocReportScheduleForm.getFrequencyDataWeekly());
		}else if (adhocReportScheduleForm.getFrequency().equals("M")){
			adhocReportSchedule.setFrequencyDataMonthly(adhocReportScheduleForm.getFrequencyDataMonthly());
		}else if (adhocReportScheduleForm.getFrequency().equals("Y")){
			frequencyData=adhocReportScheduleForm.getFrequencyDataYearly();
			adhocReportSchedule.setFrequencyDataYearly(frequencyData);
		}else if (adhocReportScheduleForm.getFrequency().equals("B")){
			adhocReportSchedule.setFrequencyDataRunDay(adhocReportScheduleForm.getFrequencyDataRunDay());
			adhocReportSchedule.setFrequencyDataCycleCode(adhocReportScheduleForm.getFrequencyDataCycleCode());
		}
		adhocReportSchedule.setSchedRptNum(adhocReportScheduleForm.getSelectedScheduleId());
		adhocReportSchedule.setSaveToDisk(adhocReportScheduleForm.getSaveToDisk());
		adhocReportSchedule.setDivision(adhocReportScheduleForm.getDivision());

		return (adhocReportSchedule);
	}

	/**
	 * This is a utility method that returns an object of type AdhocReportSchedule setting its attributes using the variables
	 * obtained from the form. This object will then be passed to the service layer to carry out the update / delete
	 * operations
	 * 
	 * @param failureList
	 * @param adhocReportScheduleForm
	 * @param region
	 * @return AdhocReportSchedule
	 */
	private AdhocReportSchedule getAdhocReportScheduleForEdit(List failureList,AdhocReportScheduleForm adhocReportScheduleForm,String region){
		AdhocReportSchedule adhocReportSchedule = new AdhocReportSchedule(region);
		
		adhocReportSchedule.setDays(adhocReportScheduleForm.getDaysEdit());
		adhocReportSchedule.setEmailTo(adhocReportScheduleForm.getEmailToEdit());
		adhocReportSchedule.setFrequency(adhocReportScheduleForm.getFrequencyEdit());
		
		adhocReportSchedule.setPresnId(adhocReportScheduleForm.getPresnId());
		adhocReportSchedule.setStartDate(adhocReportScheduleForm.getStartDateEdit());
		String frequencyData="";
		if (adhocReportScheduleForm.getFrequencyEdit().equals("W")){
			adhocReportSchedule.setFrequencyDataWeekly(adhocReportScheduleForm.getFrequencyDataWeeklyEdit());
		}else if (adhocReportScheduleForm.getFrequencyEdit().equals("M")){
			adhocReportSchedule.setFrequencyDataMonthly(adhocReportScheduleForm.getFrequencyDataMonthlyEdit());
		}else if (adhocReportScheduleForm.getFrequencyEdit().equals("Y")){
			frequencyData=adhocReportScheduleForm.getFrequencyDataYearlyEdit();
			adhocReportSchedule.setFrequencyDataYearly(frequencyData);
		}else if (adhocReportScheduleForm.getFrequencyEdit().equals("B")){
			adhocReportSchedule.setFrequencyDataRunDay(adhocReportScheduleForm.getFrequencyDataRunDayEdit());
			adhocReportSchedule.setFrequencyDataCycleCode(adhocReportScheduleForm.getFrequencyDataCycleCodeEdit());
		}
		adhocReportSchedule.setSchedRptNum(adhocReportScheduleForm.getSelectedScheduleId());
		adhocReportSchedule.setSaveToDisk(adhocReportScheduleForm.getSaveToDiskEdit());
		adhocReportSchedule.setDivision(adhocReportScheduleForm.getDivisionEdit());
		return (adhocReportSchedule);
	}
	 
	/**
	 * Private method to intialize certain parameters of form.
	 * @param adhocReportScheduleForm
	 * @param region
	 * 
	 */
	private void setFormFields(AdhocReportScheduleForm adhocReportScheduleForm, String region) {
	 	adhocReportScheduleForm.setAdhocReportScheduleList(new ArrayList());
		adhocReportScheduleForm.setReportNameList(new ArrayList());
		
		adhocReportScheduleForm.setFrequencyList(new ArrayList());
		List frequencyList = RABCConstantsLists.getRABCConstantsLists().getAdhocSchedulerFrequencyList(region);
		if (!frequencyList.isEmpty()){
			int frequencyListSize = frequencyList.size();
			for (int i=0;i<frequencyListSize;i++){
				PickList frequency = (PickList)frequencyList.get(i);
				adhocReportScheduleForm.addFrequency(frequency);
			}
		}
		
		adhocReportScheduleForm.setFrequencyDataWeeklyList(new ArrayList());
		List frequencyDataWeeklyList = RABCConstantsLists.getRABCConstantsLists().getAdhocSchedulerWeekDaysList();
		if (!frequencyDataWeeklyList.isEmpty()){
			int frequencyDataWeeklyListSize = frequencyDataWeeklyList.size();
			for (int i=0;i<frequencyDataWeeklyListSize;i++){
				PickList frequencyDataWeekly= (PickList)frequencyDataWeeklyList.get(i);
				adhocReportScheduleForm.addFrequencyDataWeekly(frequencyDataWeekly);
			}
		}
		
		adhocReportScheduleForm.setFrequencyDataMonthlyList(new ArrayList());
		List frequencyDataMonthlyList = RABCConstantsLists.getRABCConstantsLists().getAdhocSchedulerMonthDaysList();
		if (!frequencyDataMonthlyList.isEmpty()){
			int frequencyDataMonthlySize = frequencyDataMonthlyList.size();
			for (int i=0;i<frequencyDataMonthlySize;i++){
				PickList frequencyDataMonthly= (PickList)frequencyDataMonthlyList.get(i);
				adhocReportScheduleForm.addFrequencyDataMonthly(frequencyDataMonthly);
			}
		}
		
		adhocReportScheduleForm.setFrequencyDataCycleCodeList(new ArrayList());
		List frequencyDataCycleCodeList = StaticDataLoader.getBillRndByRegion(region);
		//List frequencyDataCycleCodeList = RABCConstantsLists.getRABCConstantsLists().getAdhocSchedulerCycleCodeList();
		if (!frequencyDataCycleCodeList.isEmpty()){
			int frequencyDataCycleCodeListSize = frequencyDataCycleCodeList.size();
			for (int i=0;i<frequencyDataCycleCodeListSize;i++){
				String cycleCode = (String)frequencyDataCycleCodeList.get(i);
				PickList frequencyDataCycleCode= new PickList(cycleCode, cycleCode);
				adhocReportScheduleForm.addFrequencyDataCycleCode(frequencyDataCycleCode);
			}
		}
		
		adhocReportScheduleForm.setFrequencyDataRunDayList(new ArrayList());
		List frequencyDataRunDayList = RABCConstantsLists.getRABCConstantsLists().getAdhocSchedulerRunDayList();
		if (!frequencyDataRunDayList.isEmpty()){
			int frequencyDataRunDayListSize = frequencyDataRunDayList.size();
			for (int i=0;i<frequencyDataRunDayListSize;i++){
				PickList frequencyDataRunDay= (PickList)frequencyDataRunDayList.get(i);
				adhocReportScheduleForm.addFrequencyDataRunDay(frequencyDataRunDay);
			}
		}	
		
		adhocReportScheduleForm.setDivisionList(StaticDataLoader.getDivisionsByRegion(region));
		
		/*
		 * Update calendar attributes
		 */
		adhocReportScheduleForm.setBillRounds(StaticDataLoader.getBillRounds(region));
		adhocReportScheduleForm.setProcDates(StaticDataLoader.getProcDates(region));
		adhocReportScheduleForm.setHolidayIndicators(StaticDataLoader.getHolidayIndicators(region));
		adhocReportScheduleForm.setLoadedDataDates(StaticDataLoader.getLoadedDataDatesByRegion(region));
	}
}
