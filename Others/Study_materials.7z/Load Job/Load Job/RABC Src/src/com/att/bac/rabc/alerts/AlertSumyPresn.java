/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts;

/**
 * This is a Data Object to represent RABC_ALERT_SUMY_PRESN table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class AlertSumyPresn {
	private String sumyPresnName;
	private String alertRule;
	private String webid;
	private int presnSeqNum;
	private String totInd;
	private int asocPresnId;

	/**
	 * @return Returns the SumyPresnName.
	 */
	public String getSumyPresnName() {
		return sumyPresnName;
	}
	/**
	 * @return Returns the AlertRule.
	 */
	public String getAlertRule() {
		return alertRule;
	}
	/**
	 * @return Returns the Webid.
	 */
	public String getWebid() {
		return webid;
	}
	/**
	 * @return Returns the PresnSeqNum.
	 */
	public int getPresnSeqNum() {
		return presnSeqNum;
	}
	/**
	 * @return Returns the TotInd.
	 */
	public String getTotInd() {
		return totInd;
	}
	/**
	 * @return Returns the AsocPresnId.
	 */
	public int getAsocPresnId() {
		return asocPresnId;
	}

	/**
	 * @param SumyPresnName The sumyPresnName to set.
	 */
	public void setSumyPresnName(String sumyPresnName) {
		this.sumyPresnName = sumyPresnName;
	}
	/**
	 * @param AlertRule The alertRule to set.
	 */
	public void setAlertRule(String alertRule) {
		this.alertRule = alertRule;
	}
	/**
	 * @param Webid The webid to set.
	 */
	public void setWebid(String webid) {
		this.webid = webid;
	}
	/**
	 * @param PresnSeqNum The presnSeqNum to set.
	 */
	public void setPresnSeqNum(int presnSeqNum) {
		this.presnSeqNum = presnSeqNum;
	}
	/**
	 * @param TotInd The totInd to set.
	 */
	public void setTotInd(String totInd) {
		this.totInd = totInd;
	}
	/**
	 * @param AsocPresnId The asocPresnId to set.
	 */
	public void setAsocPresnId(int asocPresnId) {
		this.asocPresnId = asocPresnId;
	}
}
