/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.admin.alert.rule;

/**
 * This is a Data Object to represent RABC_EXTRCT_BUILD_RULE table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class ExtractBuildRule {
	private int partiRefId;
	private String extrctType;
	private String extrctRndupInd;
	private String extrctItemName;
	private String extrctToTbl;
	private String fileItem1Name;
	private String extrctItem1Name;
	private String fileItem2Name;
	private String extrctItem2Name;
	private String fileItem3Name;
	private String extrctItem3Name;
	private String fileItem4Name;
	private String extrctItem4Name;
	private String fileItem5Name;
	private String extrctItem5Name;
	private String fileItem6Name;
	private String extrctItem6Name;
	private String fileItem7Name;
	private String extrctItem7Name;
	private String fileItem8Name;
	private String extrctItem8Name;
	private String fileItem9Name;
	private String extrctItem9Name;
	private String extrctItem1CalcInd;
	private String extrctItem2CalcInd;
	private String extrctItem3CalcInd;
	private String extrctItem4CalcInd;
	private String extrctItem5CalcInd;
	private String extrctItem6CalcInd;
	private String extrctItem7CalcInd;
	private String extrctItem8CalcInd;
	private String extrctItem9CalcInd;

	/**
	 * @return Returns the PartiRefId.
	 */
	public int getPartiRefId() {
		return partiRefId;
	}
	/**
	 * @return Returns the ExtrctType.
	 */
	public String getExtrctType() {
		return extrctType;
	}
	/**
	 * @return Returns the ExtrctRndupInd.
	 */
	public String getExtrctRndupInd() {
		return extrctRndupInd;
	}
	/**
	 * @return Returns the ExtrctItemName.
	 */
	public String getExtrctItemName() {
		return extrctItemName;
	}
	/**
	 * @return Returns the ExtrctToTbl.
	 */
	public String getExtrctToTbl() {
		return extrctToTbl;
	}
	/**
	 * @return Returns the FileItem1Name.
	 */
	public String getFileItem1Name() {
		return fileItem1Name;
	}
	/**
	 * @return Returns the ExtrctItem1Name.
	 */
	public String getExtrctItem1Name() {
		return extrctItem1Name;
	}
	/**
	 * @return Returns the FileItem2Name.
	 */
	public String getFileItem2Name() {
		return fileItem2Name;
	}
	/**
	 * @return Returns the ExtrctItem2Name.
	 */
	public String getExtrctItem2Name() {
		return extrctItem2Name;
	}
	/**
	 * @return Returns the FileItem3Name.
	 */
	public String getFileItem3Name() {
		return fileItem3Name;
	}
	/**
	 * @return Returns the ExtrctItem3Name.
	 */
	public String getExtrctItem3Name() {
		return extrctItem3Name;
	}
	/**
	 * @return Returns the FileItem4Name.
	 */
	public String getFileItem4Name() {
		return fileItem4Name;
	}
	/**
	 * @return Returns the ExtrctItem4Name.
	 */
	public String getExtrctItem4Name() {
		return extrctItem4Name;
	}
	/**
	 * @return Returns the FileItem5Name.
	 */
	public String getFileItem5Name() {
		return fileItem5Name;
	}
	/**
	 * @return Returns the ExtrctItem5Name.
	 */
	public String getExtrctItem5Name() {
		return extrctItem5Name;
	}
	/**
	 * @return Returns the FileItem6Name.
	 */
	public String getFileItem6Name() {
		return fileItem6Name;
	}
	/**
	 * @return Returns the ExtrctItem6Name.
	 */
	public String getExtrctItem6Name() {
		return extrctItem6Name;
	}
	/**
	 * @return Returns the FileItem7Name.
	 */
	public String getFileItem7Name() {
		return fileItem7Name;
	}
	/**
	 * @return Returns the ExtrctItem7Name.
	 */
	public String getExtrctItem7Name() {
		return extrctItem7Name;
	}
	/**
	 * @return Returns the FileItem8Name.
	 */
	public String getFileItem8Name() {
		return fileItem8Name;
	}
	/**
	 * @return Returns the ExtrctItem8Name.
	 */
	public String getExtrctItem8Name() {
		return extrctItem8Name;
	}
	/**
	 * @return Returns the FileItem9Name.
	 */
	public String getFileItem9Name() {
		return fileItem9Name;
	}
	/**
	 * @return Returns the ExtrctItem9Name.
	 */
	public String getExtrctItem9Name() {
		return extrctItem9Name;
	}
	/**
	 * @return Returns the ExtrctItem1CalcInd.
	 */
	public String getExtrctItem1CalcInd() {
		return extrctItem1CalcInd;
	}
	/**
	 * @return Returns the ExtrctItem2CalcInd.
	 */
	public String getExtrctItem2CalcInd() {
		return extrctItem2CalcInd;
	}
	/**
	 * @return Returns the ExtrctItem3CalcInd.
	 */
	public String getExtrctItem3CalcInd() {
		return extrctItem3CalcInd;
	}
	/**
	 * @return Returns the ExtrctItem4CalcInd.
	 */
	public String getExtrctItem4CalcInd() {
		return extrctItem4CalcInd;
	}
	/**
	 * @return Returns the ExtrctItem5CalcInd.
	 */
	public String getExtrctItem5CalcInd() {
		return extrctItem5CalcInd;
	}
	/**
	 * @return Returns the ExtrctItem6CalcInd.
	 */
	public String getExtrctItem6CalcInd() {
		return extrctItem6CalcInd;
	}
	/**
	 * @return Returns the ExtrctItem7CalcInd.
	 */
	public String getExtrctItem7CalcInd() {
		return extrctItem7CalcInd;
	}
	/**
	 * @return Returns the ExtrctItem8CalcInd.
	 */
	public String getExtrctItem8CalcInd() {
		return extrctItem8CalcInd;
	}
	/**
	 * @return Returns the ExtrctItem9CalcInd.
	 */
	public String getExtrctItem9CalcInd() {
		return extrctItem9CalcInd;
	}

	/**
	 * @param PartiRefId The partiRefId to set.
	 */
	public void setPartiRefId(int partiRefId) {
		this.partiRefId = partiRefId;
	}
	/**
	 * @param ExtrctType The extrctType to set.
	 */
	public void setExtrctType(String extrctType) {
		this.extrctType = extrctType;
	}
	/**
	 * @param ExtrctRndupInd The extrctRndupInd to set.
	 */
	public void setExtrctRndupInd(String extrctRndupInd) {
		this.extrctRndupInd = extrctRndupInd;
	}
	/**
	 * @param ExtrctItemName The extrctItemName to set.
	 */
	public void setExtrctItemName(String extrctItemName) {
		this.extrctItemName = extrctItemName;
	}
	/**
	 * @param ExtrctToTbl The extrctToTbl to set.
	 */
	public void setExtrctToTbl(String extrctToTbl) {
		this.extrctToTbl = extrctToTbl;
	}
	/**
	 * @param FileItem1Name The fileItem1Name to set.
	 */
	public void setFileItem1Name(String fileItem1Name) {
		this.fileItem1Name = fileItem1Name;
	}
	/**
	 * @param ExtrctItem1Name The extrctItem1Name to set.
	 */
	public void setExtrctItem1Name(String extrctItem1Name) {
		this.extrctItem1Name = extrctItem1Name;
	}
	/**
	 * @param FileItem2Name The fileItem2Name to set.
	 */
	public void setFileItem2Name(String fileItem2Name) {
		this.fileItem2Name = fileItem2Name;
	}
	/**
	 * @param ExtrctItem2Name The extrctItem2Name to set.
	 */
	public void setExtrctItem2Name(String extrctItem2Name) {
		this.extrctItem2Name = extrctItem2Name;
	}
	/**
	 * @param FileItem3Name The fileItem3Name to set.
	 */
	public void setFileItem3Name(String fileItem3Name) {
		this.fileItem3Name = fileItem3Name;
	}
	/**
	 * @param ExtrctItem3Name The extrctItem3Name to set.
	 */
	public void setExtrctItem3Name(String extrctItem3Name) {
		this.extrctItem3Name = extrctItem3Name;
	}
	/**
	 * @param FileItem4Name The fileItem4Name to set.
	 */
	public void setFileItem4Name(String fileItem4Name) {
		this.fileItem4Name = fileItem4Name;
	}
	/**
	 * @param ExtrctItem4Name The extrctItem4Name to set.
	 */
	public void setExtrctItem4Name(String extrctItem4Name) {
		this.extrctItem4Name = extrctItem4Name;
	}
	/**
	 * @param FileItem5Name The fileItem5Name to set.
	 */
	public void setFileItem5Name(String fileItem5Name) {
		this.fileItem5Name = fileItem5Name;
	}
	/**
	 * @param ExtrctItem5Name The extrctItem5Name to set.
	 */
	public void setExtrctItem5Name(String extrctItem5Name) {
		this.extrctItem5Name = extrctItem5Name;
	}
	/**
	 * @param FileItem6Name The fileItem6Name to set.
	 */
	public void setFileItem6Name(String fileItem6Name) {
		this.fileItem6Name = fileItem6Name;
	}
	/**
	 * @param ExtrctItem6Name The extrctItem6Name to set.
	 */
	public void setExtrctItem6Name(String extrctItem6Name) {
		this.extrctItem6Name = extrctItem6Name;
	}
	/**
	 * @param FileItem7Name The fileItem7Name to set.
	 */
	public void setFileItem7Name(String fileItem7Name) {
		this.fileItem7Name = fileItem7Name;
	}
	/**
	 * @param ExtrctItem7Name The extrctItem7Name to set.
	 */
	public void setExtrctItem7Name(String extrctItem7Name) {
		this.extrctItem7Name = extrctItem7Name;
	}
	/**
	 * @param FileItem8Name The fileItem8Name to set.
	 */
	public void setFileItem8Name(String fileItem8Name) {
		this.fileItem8Name = fileItem8Name;
	}
	/**
	 * @param ExtrctItem8Name The extrctItem8Name to set.
	 */
	public void setExtrctItem8Name(String extrctItem8Name) {
		this.extrctItem8Name = extrctItem8Name;
	}
	/**
	 * @param FileItem9Name The fileItem9Name to set.
	 */
	public void setFileItem9Name(String fileItem9Name) {
		this.fileItem9Name = fileItem9Name;
	}
	/**
	 * @param ExtrctItem9Name The extrctItem9Name to set.
	 */
	public void setExtrctItem9Name(String extrctItem9Name) {
		this.extrctItem9Name = extrctItem9Name;
	}
	/**
	 * @param ExtrctItem1CalcInd The extrctItem1CalcInd to set.
	 */
	public void setExtrctItem1CalcInd(String extrctItem1CalcInd) {
		this.extrctItem1CalcInd = extrctItem1CalcInd;
	}
	/**
	 * @param ExtrctItem2CalcInd The extrctItem2CalcInd to set.
	 */
	public void setExtrctItem2CalcInd(String extrctItem2CalcInd) {
		this.extrctItem2CalcInd = extrctItem2CalcInd;
	}
	/**
	 * @param ExtrctItem3CalcInd The extrctItem3CalcInd to set.
	 */
	public void setExtrctItem3CalcInd(String extrctItem3CalcInd) {
		this.extrctItem3CalcInd = extrctItem3CalcInd;
	}
	/**
	 * @param ExtrctItem4CalcInd The extrctItem4CalcInd to set.
	 */
	public void setExtrctItem4CalcInd(String extrctItem4CalcInd) {
		this.extrctItem4CalcInd = extrctItem4CalcInd;
	}
	/**
	 * @param ExtrctItem5CalcInd The extrctItem5CalcInd to set.
	 */
	public void setExtrctItem5CalcInd(String extrctItem5CalcInd) {
		this.extrctItem5CalcInd = extrctItem5CalcInd;
	}
	/**
	 * @param ExtrctItem6CalcInd The extrctItem6CalcInd to set.
	 */
	public void setExtrctItem6CalcInd(String extrctItem6CalcInd) {
		this.extrctItem6CalcInd = extrctItem6CalcInd;
	}
	/**
	 * @param ExtrctItem7CalcInd The extrctItem7CalcInd to set.
	 */
	public void setExtrctItem7CalcInd(String extrctItem7CalcInd) {
		this.extrctItem7CalcInd = extrctItem7CalcInd;
	}
	/**
	 * @param ExtrctItem8CalcInd The extrctItem8CalcInd to set.
	 */
	public void setExtrctItem8CalcInd(String extrctItem8CalcInd) {
		this.extrctItem8CalcInd = extrctItem8CalcInd;
	}
	/**
	 * @param ExtrctItem9CalcInd The extrctItem9CalcInd to set.
	 */
	public void setExtrctItem9CalcInd(String extrctItem9CalcInd) {
		this.extrctItem9CalcInd = extrctItem9CalcInd;
	}
}
