/*
 * Copyright  2002-2006 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.adhoc.aria.layouts;

import java.io.OutputStream;

import com.att.bac.rabc.adhoc.AdhocConstants;
import com.att.bac.rabc.adhoc.aria.AbstractAdhocAriaLayout;
import com.att.bac.rabc.adhoc.aria.AbstractAriaLayoutPivot;
import com.att.bac.rabc.adhoc.rpt.AdhocRptForm;


/**
 * Factory to create an appropriate layout for adhoc reporting under the ARIA product.
 * 
 * <p>
 * <hr>
 * <h3>Release History</h3>
 * <p>
 * <ul>
 * 
 * <li>jb6494 Aug 17, 2006 Created class.
 * 
 * </ul>
 * <p>
 * 
 */
public final class AdhocAriaLayoutFactory implements AdhocConstants {

    private AdhocAriaLayoutFactory() {
    }


    /**
     * Get the layout based on the "model" for layouts 1 & 3
     * 
     * @param layoutModel
     * @param presnTrendTime
     * @param form
     * @param os
     * @param userid
     * @return
     */
    public static AbstractAdhocAriaLayout getLayout(int layoutModel, String presnTrendTime, AdhocRptForm form, OutputStream os, String userid) {
        switch (layoutModel) {
            case 1:
                return new AdhocAriaLayout1(form, os, userid);
            case 3:
                return new AdhocAriaLayout3(form, os, userid);
            default:
                return null;
        }
    }

    /**
     * Get the layout based on the "model" for layouts 2 & 4
     * @param layoutModel
     * @param presnTrendTime
     * @param form
     * @param os
     * @param userid
     * @return
     */
    public static AbstractAriaLayoutPivot getPivotLayout(int layoutModel, String presnTrendTime, AdhocRptForm form, OutputStream os, String userid) {
        switch (layoutModel) {
            case 2:
                return new AdhocPivotLayout2(form, os, userid);
            case 4:
                return new AdhocPivotLayout4(form, os, userid);
            default:
                return null;
        }
    }

    /**
     * Return an Excel report layout for layouts 2 & 4
     * 
     * @param layoutModel
     * @param presnTrendTime
     * @param form
     * @param os
     * @param userid
     * 
     * @return
     */
    public static AbstractAriaLayoutPivot getPivotExcelLayout(int layoutModel, String presnTrendTime, AdhocRptForm form, OutputStream os, String userid) {
        switch (layoutModel) {
        	case 2:
        		return new AdhocPivotLayoutExcel2(form, os, userid);
        	case 4:
        		return new AdhocPivotLayoutExcel4(form, os, userid);
        	default:
        		return null;
        }
    }

    /**
     * Return an Excel report layout for layouts 1 & 3
     * 
     * @param layoutModel
     * @param presnTrendTime
     * @param form
     * @param os
     * @param userid
     * 
     * @return
     */
    public static AbstractAdhocAriaLayout getExcelLayout(int layoutModel, String presnTrendTime, AdhocRptForm form, OutputStream os, String userid) {
        switch (layoutModel) {
            case 1:
                return new AdhocAriaLayoutExcel1(form, os, userid);
            case 3:
                return new AdhocAriaLayoutExcel3(form, os, userid);
            default:
                return null;
        }
    }
}
