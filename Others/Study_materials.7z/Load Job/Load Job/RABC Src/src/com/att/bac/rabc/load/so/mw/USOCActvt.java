/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.load.so.mw;

import java.util.Date;

import com.sbc.bac.rabc.load.HashCodeUtil;

/**
 * This is a data object representing entries in RABC_DAILY_NONCIR_USOC_ACTVT and RABC_DAILY_CIR_USOC_ACTVT tables.
 * 
 * @author Shailesh Hemdev - SH8512
 */
public class USOCActvt {
	private Date runDate;
	private String division;
	private String ruleNumber;
	private String soType;
	private String busType;
	private String usoc;
	private long usocCt;
	private double usocAmt;
	//Object to hold value of exchange code rb2163
	private String exchCD;
		
	/**
	 * @return Returns the division.
	 */
	public String getDivision() {
		return division;
	}
	/**
	 * @param division The division to set.
	 */
	public void setDivision(String division) {
		this.division = division;
	}

	/**
	 * @return Returns the runDate.
	 */
	public Date getRunDate() {
		return runDate;
	}
	/**
	 * @param runDate The runDate to set.
	 */
	public void setRunDate(Date runDate) {
		this.runDate = runDate;
	}
	/**
	 * @return Returns the usoc.
	 */
	public String getUsoc() {
		return usoc;
	}
	/**
	 * @param usoc The usoc to set.
	 */
	public void setUsoc(String usoc) {
		this.usoc = usoc;
	}
	/**
	 * @return Returns the usocAmt.
	 */
	public double getUsocAmt() {
		return usocAmt;
	}
	
	/**
	 * @return Returns the usocCt.
	 */
	public long getUsocCt() {
		return usocCt;
	}
	/**
	 * @param usocCt The usocCt to set.
	 */
	public void setUsocCt(long usocCt) {
		this.usocCt = usocCt;
	}
	/**
	 * @param usocAmt The usocAmt to set.
	 */
	public void setUsocAmt(double usocAmt) {
		this.usocAmt = usocAmt;
	}
	
	/**
	 * @return Returns the busType.
	 */
	public String getBusType() {
		return busType;
	}
	
	/**
	 * @param busType The busType to set.
	 */
	public void setBusType(String busType) {
		this.busType = busType;
	}
	
	/**
	 * @return Returns the Exchange Code
	 */
	public String getExchCD() {
		return exchCD;
	}
	/**
	 * @param exchCD The Exchange Code to set.
	 */
	public void setExchCD(String exchCD) {
		this.exchCD = exchCD;
	}
	/**
	 * Equals method overridden for this object so that it can be stored in a hash map where the key 
	 * would be combination of the following 4 attributes:
	 * Run date
	 * Division
	 * Business type
	 * USOC
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object o) {
//		 Do a quick check for an identical object reference
	    if (this == o) {
	      return true;
	    }
	    if (!(o instanceof USOCActvt)) {
	    	return false;
	    } else {
	    	if (((USOCActvt)o).getRunDate().getTime() == this.getRunDate().getTime()
					&& ((USOCActvt)o).getDivision().equalsIgnoreCase(this.getDivision())
					&& ((USOCActvt)o).getBusType().equalsIgnoreCase(this.getBusType())	
					&& ((USOCActvt)o).getUsoc().equalsIgnoreCase(this.getUsoc())
					) 
			{
				return true;
			} else {
				return false;
			}
	    }
	}
	
	/**
	 * Hash code method overridden for this object to categorize this object in sets 
	 * so that the hash collections can search this object efficiently.
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		int hashCode = HashCodeUtil.SEED;
		hashCode = HashCodeUtil.hash( hashCode, this.getBusType());
		hashCode = HashCodeUtil.hash( hashCode, this.getUsoc());
	    return hashCode;
	}
	public String getSoType() {
		return soType;
	}
	public void setSoType(String soType) {
		this.soType = soType;
	}
	public String getRuleNumber() {
		return ruleNumber;
	}
	public void setRuleNumber(String ruleNumber) {
		this.ruleNumber = ruleNumber;
	}
}
