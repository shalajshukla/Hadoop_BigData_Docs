/* Component Name: RABCPPG00540
 * Module Name: SidemenuList.java
 * Created on Mar 10, 2006
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.sidemenu;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import org.apache.log4j.Logger;

import com.att.bac.rabc.ConnectionManager;
import com.att.bac.rabc.RABCException;
import com.att.carat.util.JDBCUtil;

/**This class is called by the JSP include controlpts_sidemenu.jsp to create both the Alerts tree and the Reports
 * tree in the side menu.  Data for control points or reports selected from these trees is populated in the class
 * SidemenuForm.java and the class SidemenuAction.java uses this form data to populate either page 11 or page 13
 * in the body window.
 * 
 * @author pt6471
 */
public class SidemenuList {
	private static final Logger logger = Logger.getLogger(SidemenuList.class);
	
	private static final String getDefaultDivision = "SELECT DIVISION FROM RABC_USER_DEFAULT_DIVISION WHERE USER_ID = ''{0}''";
	
	/**This is the method called by the JSP include controlpts_sidemenu.jsp.  It establishes the connection
	 * and calls methods to create the side menu nodes.  Any exceptions created are thrown back to the JSP
	 * include controlpts_sidemenu.jsp to be handled there.
	 * 
	 * @param region  the region the user is operating in.
	 * @return root  the MenuNode object that contains all the branches of the Reports and Alerts trees.
	 */
	public static MenuNode getSidemenuList(String region) throws RABCException {
		Connection conn = null;
		logger.debug("Starting to generate the side menu trees...");
		try {
			conn = ConnectionManager.getConnection(region);
			MenuNode root = new MenuNode(null,"RABC MENU",null,0, false,"M");
            addReports(root, conn);
            addAlerts(root, conn);
            logger.debug("Finished generating the side menu trees.");
            return root;
		} catch(SQLException sqle){
			throw new RABCException("SQL exception in creating a connection: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
            JDBCUtil.closeConnection(conn);
        }
	}
	
	/**This is the method called by SidemenuList.getSidemenuList() and adds the Alerts nodes to the Alerts 
	 * tree.  Data in these nodes is used to create page 11 reports.  Any exceptions created are thrown 
	 * back to SidemenuList.getSidemenuList().
	 * 
	 * @param root  the MenuNode object that contains all the branches of the Reports and Alerts trees.
	 * @param conn  the connection created in getSidemenuList.
	 */
    private static void addAlerts(MenuNode root, Connection conn) throws RABCException {
    	logger.debug("Starting to generate the Alerts tree...");
        PreparedStatement ps = null;
        ResultSet rs = null;
    	String alertsNodesSQL = "SELECT m.presn_type, m.presn_name, m.presn_id, m.presn_lvl, m.assoc_parent_id, m.presn_seq_num, m.sub_assoc_parent_id, m.alert_rule, r.alert_rule, r.parti_ref_id, c.cntrl_pt_cd, c.CNTRL_PT_DESC " +
        						"FROM rabc_menu_index m, rabc_alert_rule r, " +
        						"    (SELECT DISTINCT A.cntrl_pt_cd, A.alert_rule, B.CNTRL_PT_DESC, A.PRESN_SEQ_NUM " +
        						"     FROM rabc_cntrl_pt_alert A, RABC_CNTRL_PT_TRANS B " +
        						"     WHERE A.cntrl_pt_cd = B.CNTRL_PT_CODE " +
        						"     ORDER BY A.PRESN_SEQ_NUM) c " +
        						"WHERE m.presn_type='A' " +
        						"  AND (m.presn_lvl = 1 OR upper(r.alert_rule_status) = 'ACTIVE') " +
        						"  AND m.presn_id=r.presn_id(+) " +
        						"  AND m.alert_rule=c.alert_rule(+) " +
        						"ORDER BY m.presn_lvl, m.assoc_parent_id, m.presn_seq_num";
        try {
            ps = conn.prepareStatement(alertsNodesSQL);
            rs = ps.executeQuery();
            MenuNode reports = new MenuNode(root,"Alerts",null,0, false,"A");
            while(rs.next()){
                String name = rs.getString("PRESN_NAME");
                int level = rs.getInt("presn_lvl");
                int sequence = rs.getInt("presn_seq_num");
                int parentId = rs.getInt("assoc_parent_id");
                int subParentId = rs.getInt("sub_assoc_parent_id");
                String controlPoint = rs.getString("cntrl_pt_cd");
                int partiRefId = rs.getInt("parti_ref_id");
                String controlPointDesc = rs.getString("CNTRL_PT_DESC");
                if(level==1){
                    new MenuNode(reports,name,Integer.toString(sequence),partiRefId, false,"A");
                } else if(level==2){
                    MenuNode parent = reports.getChild(Integer.toString(parentId));
                    if(parent==null){
                    	throw new RABCException("No parent found at level 2 with id of " + parentId);
                	} else {
	                    if(controlPoint==null){
	                        new MenuNode(parent,name,Integer.toString(sequence),partiRefId, true,"A");
	                    } else {
	                        MenuNode cpMenu = parent.getChild(controlPoint);
	                        if(cpMenu==null){
	                            cpMenu = new MenuNode(parent,controlPointDesc,controlPoint,0, true,"A");
	                        }
		                    new MenuNode(cpMenu,name,Integer.toString(sequence),partiRefId, true,"A");	                        	
	                    }
                	}
                } else if(level==3){
                    MenuNode grandparent = reports.getChild(Integer.toString(parentId));
                    if(grandparent==null){
                        throw new RABCException("No grandparent found at level 3 with id of " + parentId);
                    } else {
                        if(controlPoint==null){
                            MenuNode parent = grandparent.getChild(Integer.toString(subParentId));
                            new MenuNode(parent,name,Integer.toString(sequence),partiRefId, false,"A");
                        } else {
                            MenuNode cpMenu = grandparent.getChild(controlPoint);
                            if(cpMenu==null){
                                throw new RABCException("No controlpoint '" + controlPoint + "' found for level three rule " + name);
                            } else {
                                MenuNode parent = cpMenu.getChild(Integer.toString(subParentId));
                                if(parent==null){
                                    throw new RABCException("No parent '" + subParentId + "' found under control point '" + controlPoint + "' for level three rule " + name);
                                } else {
                                    new MenuNode(parent,name,Integer.toString(sequence),partiRefId, true,"A");
                                }
                            }
                        }
                    }
                } else {
                    throw new RABCException("Level " + level + " is not supported");
                }
            }
        } catch (SQLException sqle) {
        	throw new RABCException ("Error in retrieving the nodes for the alerts tree using alertsNodesSQL query: ", sqle);
    	} finally {
            JDBCUtil.closeResultSet(rs);
            JDBCUtil.closePreparedStatement(ps);
        }
    }
    
	/**This is the method called by SidemenuList.getSidemenuList() and adds the Reports nodes to the Reports 
	 * tree.  Data in these nodes is used to create page 13 reports.  Any exceptions created are thrown 
	 * back to SidemenuList.getSidemenuList().
	 * 
	 * @param root  the MenuNode object that contains all the branches of the Reports and Alerts trees.
	 * @param conn  the connection created in getSidemenuList.
	 */
    private static void addReports(MenuNode root, Connection conn) throws RABCException {
    	logger.debug("Starting to generate the Reports tree...");
        PreparedStatement ps = null;
        ResultSet rs = null;
        String reportsNodesSQL = "SELECT DISTINCT a.* " +
        						 "FROM rabc_menu_index a, rabc_presn_id b " +
        						 "WHERE a.PRESN_TYPE = 'P' " +
        						 "  AND (a.presn_lvl < 3 OR upper(b.adhoc_rpt_status) = 'ACTIVE') " +
        						 "  AND a.presn_id = b.presn_id(+) " +
        						 "ORDER BY presn_type, presn_lvl, assoc_parent_id, nvl(sub_assoc_parent_id,0), presn_seq_num,upper(PRESN_NAME)";
        try {
            ps = conn.prepareStatement(reportsNodesSQL);
            rs = ps.executeQuery();
            MenuNode reports = new MenuNode(root,"Reports",null,0, false,"P");
            while(rs.next()){
                String name = rs.getString("PRESN_NAME");
                int level = rs.getInt("presn_lvl");
                int sequence = rs.getInt("presn_seq_num");
                int parentId = rs.getInt("assoc_parent_id");
                int subParentId = rs.getInt("sub_assoc_parent_id");
                int presentationId = rs.getInt("presn_id");
                if(level==1){
                    new MenuNode(reports,name,Integer.toString(sequence),presentationId, false,"P");
                } else if(level==2){
                    MenuNode parent = reports.getChild(Integer.toString(parentId));
                    if(parent==null){
                        throw new RABCException("No parent found at level 2 with id of " + parentId);
                    } else {
                        new MenuNode(parent,name,Integer.toString(sequence),presentationId, false,"P");
                    }
                } else if(level==3){
                    MenuNode grandparent = reports.getChild(Integer.toString(parentId));
                    if(grandparent==null){
                        throw new RABCException("No grandparent found at level 3 with id of " + parentId);
                    } else {
                        MenuNode parent = grandparent.getChild(Integer.toString(subParentId));
                        new MenuNode(parent,name,Integer.toString(sequence),presentationId, true,"P");
                    }
                } else {
                    throw new RABCException("Level " + level + " is not supported");
                }
            }
        } catch (SQLException sqle) {
        	throw new RABCException ("Error in retrieving the nodes for the reports tree using reportsNodesSQL query: ", sqle);
    	} finally {
    		JDBCUtil.closeResultSet(rs);
            JDBCUtil.closePreparedStatement(ps);
        }
    }
    
    /**
	 * Get the default division
	 * @param connection
	 * @param failureList
	 * @param userId
	 * @return
     * @throws RABCException 
	 */
	public static String getDefaultDivision(String region, String userId) throws RABCException {
		Connection conn = null;
		String defaultDivision = "";
		String selectSQL = getDefaultDivision;
		List args = new ArrayList();
		args.add(userId);
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		try{
			conn = ConnectionManager.getConnection(region);
			MessageFormat mf = new MessageFormat(selectSQL);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = conn.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			if (rs != null && rs.next()) {
				defaultDivision = rs.getString(1);
			} 
		} catch (SQLException sqle) {
			throw new RABCException ("Error in retrieving the default division: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
            JDBCUtil.closeConnection(conn);
			JDBCUtil.closeResultSet(rs);
            JDBCUtil.closeStatement(stmt);
		}
		
		return defaultDivision;
	}
}
