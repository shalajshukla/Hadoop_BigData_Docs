/* 
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.admin.adhoc.rpt;

import org.apache.struts.action.ActionForm;
import com.att.bac.rabc.Tree;

/**
 * Module description: 
 * 
 * This is a adhoc report definition page Form Bean.
 *                              
 * @author Anup Thomas - AT1862
 */
public class AdhocReportDefinitionForm extends ActionForm {
	/*
	 * Variables to represent the fields on Adhoc Report Main page.
	 */
	private String stepNumber;
	private String dispatch = null;
	private Tree tableTree = null;
	private String data = null;
	private AdhocReportDefinition adhocReportDefinition = null;
	private boolean isDuplicateReportName = false;
	private String operation;//new,update,copy
	private String delRptId;
	private String saveEnabled="N";
	private String fileSequenceIndicator;
	private String billRndTableStr; 
	//we are using fileSequenceIndicator in the form level because , nested tag
	//is showing problem in the uncheck of checkbox 
	
	/**
	 * @return Returns the fileSequenceIndicator.
	 */
	public String getFileSequenceIndicator() {
		return fileSequenceIndicator;
	}
	/**
	 * @param fileSequenceIndicator The fileSequenceIndicator to set.
	 */
	public void setFileSequenceIndicator(String fileSequenceIndicator) {
		this.fileSequenceIndicator = fileSequenceIndicator;
	}
	/**
	 * @return Returns the saveEnabled.
	 */
	public String getSaveEnabled() {
		return saveEnabled;
	}
	/**
	 * @param saveEnabled The saveEnabled to set.
	 */
	public void setSaveEnabled(String saveEnabled) {
		this.saveEnabled = saveEnabled;
	}
	/**
	 * @return Returns the delRptId.
	 */
	public String getDelRptId() {
		return delRptId;
	}
	/**
	 * @param delRptId The delRptId to set.
	 */
	public void setDelRptId(String delRptId) {
		this.delRptId = delRptId;
	}
	/**
	 * @return Returns the operation.
	 */
	public String getOperation() {
		return operation;
	}
	/**
	 * @param operation The operation to set.
	 */
	public void setOperation(String operation) {
		this.operation = operation;
	}
	/**
	 * @return Returns the isDuplicateReportName.
	 */
	public boolean isDuplicateReportName() {
		return isDuplicateReportName;
	}
	/**
	 * @param isDuplicateReportName The isDuplicateReportName to set.
	 */
	public void setDuplicateReportName(boolean isDuplicateReportName) {
		this.isDuplicateReportName = isDuplicateReportName;
	}
	/**
	 * @return Returns the data.
	 */
	public String getData() {
		return data;
	}
	/**
	 * @param data The data to set.
	 */
	public void setData(String data) {
		this.data = data;
	}
	/**
	 * @return Returns the stepNumber.
	 */
	public String getStepNumber() {
		return stepNumber;
	}
	/**
	 * @param stepNumber The stepNumber to set.
	 */
	public void setStepNumber(String stepNumber) {
		this.stepNumber = stepNumber;
	}
	/**
	 * @return Returns the adhocReportDefinition.
	 */
	public AdhocReportDefinition getAdhocReportDefinition() {
		return adhocReportDefinition;
	}
	/**
	 * @param adhocReportDefinition The adhocReportDefinition to set.
	 */
	public void setAdhocReportDefinition(
			AdhocReportDefinition adhocReportDefinition) {
		this.adhocReportDefinition = adhocReportDefinition;
	}
	
	/**
	 * @return Returns the dispatch.
	 */
	public String getDispatch() {
		return dispatch;
	}
	/**
	 * @param dispatch The dispatch to set.
	 */
	public void setDispatch(String dispatch) {
		this.dispatch = dispatch;
	}
	/**
	 * @return Returns the tableTree.
	 */
	public Tree getTableTree() {
		return tableTree;
	}
	/**
	 * @param tableTree The tableTree to set.
	 */
	public void setTableTree(Tree tableTree) {
		this.tableTree = tableTree;
	}
	/**
	 * @return the billRndTableStr
	 */
	public String getBillRndTableStr() {
		return billRndTableStr;
	}
	/**
	 * @param billRndTableStr the billRndTableStr to set
	 */
	public void setBillRndTableStr(String billRndTableStr) {
		this.billRndTableStr = billRndTableStr;
	}
}
