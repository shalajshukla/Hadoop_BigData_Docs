package com.att.bac.rabc.adhoc.rpt;

import java.sql.Date;

public class AdhocBackgroundReport {

	private int presnId;
	private int bckGrndRptNum;
	private String reportName;
	private Date rptTimeSub;
	private String userId;
	private String status_cd;
	
	public int getPresnId() {
		return presnId;
	}
	public void setPresnId(int presnId) {
		this.presnId = presnId;
	}
	public String getReportName() {
		return reportName;
	}
	public void setReportName(String reportName) {
		this.reportName = reportName;
	}
	public Date getRptTimeSub() {
		return rptTimeSub;
	}
	public void setRptTimeSub(Date rptTimeSub) {
		this.rptTimeSub = rptTimeSub;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getStatus_cd() {
		return status_cd;
	}
	public void setStatus_cd(String status_cd) {
		this.status_cd = status_cd;
	}

	public int getBckGrndRptNum() {
		return bckGrndRptNum;
	}
	public void setBckGrndRptNum(int bckGrndRptNum) {
		this.bckGrndRptNum = bckGrndRptNum;
	}

}
