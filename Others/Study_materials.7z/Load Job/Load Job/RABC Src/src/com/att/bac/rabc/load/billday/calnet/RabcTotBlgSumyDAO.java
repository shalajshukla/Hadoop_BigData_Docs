/* Created by Gaurav Bhargava (GB0741) on Dec 11, 2006.
Copyright 2006-2008 AT&T Knowledge Ventures. All rights reserved. */

package com.att.bac.rabc.load.billday.calnet;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.att.bac.rabc.load.calnet.CalnetDAO;
import com.att.bac.rabc.load.calnet.CalnetDTO;
import com.att.bac.rabc.load.calnet.CalnetException;

/**
 * Data Access Object class for RABC_TOT_BLG_SUMY table.
 * It is used to perform database operation on this table.
 * @author GB0741
 */
public class RabcTotBlgSumyDAO extends CalnetDAO {

	private static final String INSERT_SQL = "INSERT INTO RABC_TOT_BLG_SUMY(RUN_DATE,DIVISION,CYCLE,"
		+ "AGENCY_ID,ACCT_CT,CURR_MNTH_CHRG_AMT,CURR_BAL_DUE_AMT,TOLL_AMT,OCC_AMT,BOC_AMT,"
		+ "ATT_AMT,IEC_AMT,CPUC_SRCG_AMT,FED_TAX_AMT,CITY_TAX_AMT,STATE_TAX_AMT,SRV_USFF_AMT,"
		+ "EUCL_CHRG_AMT,BLG_SRCG_AMT,CHCFA_SRCG_AMT,CHCFB_SRCG_AMT,LFLN_SRCG_AMT,HCAP_SRCG_AMT,"
		+ "CTF_SRCG_AMT,BILL_RND,BILL_MM,BILL_YEAR,SD_UNDERGRD_SRCG_AMT) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,"
		+ "?,?,?,?,?,?,?,?,?,?,?)";

	/**
	 * Returns the insert statement used to insert a record into RABC_TOT_BLG_SUMY
	 * table.
	 * @return Returns the insert statement
	 */
	protected String getInsertSql() {
		return INSERT_SQL;
	}

	/**
	 * Reads the field values from passed DTO object and sets as corresponding
	 * parameters of the PreparedStatement
	 * @param pstmt - PreparedStatement object for setting the parameters.
	 * @param dataTransferObject - CalnetDTO for reading the field values.
	 * @throws CalnetException Throws exception when there is an error in setting
	 * the parameter.
	 */
	protected void setValues(PreparedStatement pstmt, CalnetDTO dataTransferObject)
			throws CalnetException {
		RabcTotBlgSumy summ = (RabcTotBlgSumy) dataTransferObject;
		try {
			pstmt.setDate(1, new Date(summ.getRunDate().getTime()));
			pstmt.setString(2, summ.getDivision());
			pstmt.setDouble(3, summ.getCycle());
			pstmt.setString(4, summ.getAgencyID());
			pstmt.setLong(5, summ.getAcctCt());
			pstmt.setDouble(6, summ.getCurrMnthChrgAmt());
			pstmt.setDouble(7, summ.getCurrBalDueAmt());
			pstmt.setDouble(8, summ.getTollAmt());
			pstmt.setDouble(9, summ.getOccAmt());
			pstmt.setDouble(10, summ.getBocAmt());
			pstmt.setDouble(11, summ.getAttAmt());
			pstmt.setDouble(12, summ.getIecAmt());
			pstmt.setDouble(13, summ.getCpucSrcgAmt());
			pstmt.setDouble(14, summ.getFedTaxAmt());
			pstmt.setDouble(15, summ.getCityTaxAmt());
			pstmt.setDouble(16, summ.getStateTaxAmt());
			pstmt.setDouble(17, summ.getSrvUsffAmt());
			pstmt.setDouble(18, summ.getEuclChrgAmt());
			pstmt.setDouble(19, summ.getBlgSrcgAmt());
			pstmt.setDouble(20, summ.getChcfaSrcgAmt());
			pstmt.setDouble(21, summ.getChcfbSrcgAmt());
			pstmt.setDouble(22, summ.getLflnSrcgAmt());
			pstmt.setDouble(23, summ.getHcapSrcgAmt());
			pstmt.setDouble(24, summ.getCtfSrcgAmt());
			pstmt.setString(25, summ.getBillRnd());
			pstmt.setString(26, summ.getBillMm().trim());
			pstmt.setString(27, summ.getBillYear());
			pstmt.setDouble(28, summ.getSdUndergrdSrcgAmt());

		} catch (SQLException ex) {
			throw new CalnetException(
					"Error setting values in prepared statement: AgencyID "
							+ summ.getAgencyID() + ex.getMessage(), ex);
		}
	}
}
