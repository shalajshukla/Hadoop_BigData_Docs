/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc;

import javax.servlet.http.HttpSession;

/**
 * This is a class to hold the attributes to represent the progress of the request.
 * 
 * @author Vijay Dubey - VD3159
 */
public class ProgressBar {
	private int percent;
	private HttpSession session;
	
	
	/**
	 * Constructor which accepts HttpSession session object
	 * It sets the default values of percent and session.
	 * 
	 * @param session
	 */
	public ProgressBar(HttpSession session) {
		this.percent = 0;
		this.session = session;
		this.session.setAttribute("progressPercent", new Integer(0));
	}
	
	/**
	 * @return Returns the percent.
	 */
	public int getPercent() {
		return percent;
	}
	/**
	 * @param percent The percent to set.
	 */
	public void setPercent(int percent) {
		this.percent = percent;
	}
	/**
	 * @return Returns the session.
	 */
	public HttpSession getSession() {
		return session;
	}
	/**
	 * @param session The session to set.
	 */
	public void setSession(HttpSession session) {
		this.session = session;
	}
	
	/**
	 * @param percent The percent to set as session attribute.
	 */
	public void setProgressPercent(int percent) {
		this.percent = percent;
		this.session.setAttribute("progressPercent", new Integer(percent));
	}
}
