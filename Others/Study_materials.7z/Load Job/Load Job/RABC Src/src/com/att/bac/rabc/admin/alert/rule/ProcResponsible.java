/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.admin.alert.rule;

/**
 * This is a Data Object to represent RABC_PROC_RESPONSIBLE table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class ProcResponsible {
	private String alertRule;
	private String roleCd;
	private String alertGrp;

	/**
	 * @return Returns the AlertRule.
	 */
	public String getAlertRule() {
		return alertRule;
	}
	/**
	 * @return Returns the RoleCd.
	 */
	public String getRoleCd() {
		return roleCd;
	}
	/**
	 * @return Returns the AlertGrp.
	 */
	public String getAlertGrp() {
		return alertGrp;
	}

	/**
	 * @param AlertRule The alertRule to set.
	 */
	public void setAlertRule(String alertRule) {
		this.alertRule = alertRule;
	}
	/**
	 * @param RoleCd The roleCd to set.
	 */
	public void setRoleCd(String roleCd) {
		this.roleCd = roleCd;
	}
	/**
	 * @param AlertGrp The alertGrp to set.
	 */
	public void setAlertGrp(String alertGrp) {
		this.alertGrp = alertGrp;
	}
}
