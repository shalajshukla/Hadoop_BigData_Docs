package com.att.bac.rabc.load.occ.sw;

import java.util.Date;

import com.sbc.bac.rabc.load.HashCodeUtil;

public class DailyOCCSWData {
	//RUN_DATE, DIVISION, FILE_ID, BUS_TYPE, OCC_CD, OCC_TYPE, ECBR_IND, OCC_CT_CR, OCC_AMT_CR, OCC_CT_DB, OCC_AMT_DB
	private Date runDate;
	private String division; 
	private String fileId;
	private String bus_type;
	private String occCd;
	private String occType;
	private String ecbrInd;
	
	private double occCreditAmt;
	private long occCreditCnt;
	private double occChargeAmt;
	private long occChargeCnt;

	/**
	 * @return Returns the bus_type.
	 */
	public String getBus_type() {
		return bus_type;
	}
	/**
	 * @param bus_type The bus_type to set.
	 */
	public void setBus_type(String bus_type) {
		this.bus_type = bus_type;
	}
	/**
	 * @return Returns the division.
	 */
	public String getDivision() {
		return division;
	}
	/**
	 * @param division The division to set.
	 */
	public void setDivision(String division) {
		this.division = division;
	}
	/**
	 * @return Returns the ecbrInd.
	 */
	public String getEcbrInd() {
		return ecbrInd;
	}
	/**
	 * @param ecbrInd The ecbrInd to set.
	 */
	public void setEcbrInd(String ecbrInd) {
		this.ecbrInd = ecbrInd;
	}
	/**
	 * @return Returns the fileId.
	 */
	public String getFileId() {
		return fileId;
	}
	/**
	 * @param fileId The fileId to set.
	 */
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	/**
	 * @return Returns the occCd.
	 */
	public String getOccCd() {
		return occCd;
	}
	/**
	 * @param occCd The occCd to set.
	 */
	public void setOccCd(String occCd) {
		this.occCd = occCd;
	}
	/**
	 * @return Returns the occChargeAmt.
	 */
	public double getOccChargeAmt() {
		return occChargeAmt;
	}
	/**
	 * @param occChargeAmt The occChargeAmt to set.
	 */
	public void setOccChargeAmt(double occChargeAmt) {
		this.occChargeAmt = occChargeAmt;
	}
	/**
	 * @return Returns the occChargeCnt.
	 */
	public long getOccChargeCnt() {
		return occChargeCnt;
	}
	/**
	 * @param occChargeCnt The occChargeCnt to set.
	 */
	public void setOccChargeCnt(long occChargeCnt) {
		this.occChargeCnt = occChargeCnt;
	}
	/**
	 * @return Returns the occCreditAmt.
	 */
	public double getOccCreditAmt() {
		return occCreditAmt;
	}
	/**
	 * @param occCreditAmt The occCreditAmt to set.
	 */
	public void setOccCreditAmt(double occCreditAmt) {
		this.occCreditAmt = occCreditAmt;
	}
	/**
	 * @return Returns the occCreditCnt.
	 */
	public long getOccCreditCnt() {
		return occCreditCnt;
	}
	/**
	 * @param occCreditCnt The occCreditCnt to set.
	 */
	public void setOccCreditCnt(long occCreditCnt) {
		this.occCreditCnt = occCreditCnt;
	}
	/**
	 * @return Returns the occType.
	 */
	public String getOccType() {
		return occType;
	}
	/**
	 * @param occType The occType to set.
	 */
	public void setOccType(String occType) {
		this.occType = occType;
	}
	/**
	 * @return Returns the runDate.
	 */
	public Date getRunDate() {
		return runDate;
	}
	/**
	 * @param runDate The runDate to set.
	 */
	public void setRunDate(Date runDate) {
		this.runDate = runDate;
	}
	/**
	 * Equals method overridden for this object so that it can be stored in a hash map where the key 
	 * would be combination of the following 6 attributes:
	 * Run date
	 * Division
	 * File Id
	 * EBCR Indicator
	 * Business type
	 * OCC Type
	 * OCC Code
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object o) {
		// Do a quick check for an identical object reference
	    if (this == o) {
	      return true;
	    }
	    if (!(o instanceof DailyOCCSWData)) {
	    	return false;
	    } else {
			if (((DailyOCCSWData)o).getRunDate().getTime() == this.getRunDate().getTime()
				&& ((DailyOCCSWData)o).getDivision().equalsIgnoreCase(this.getDivision())
				&& ((DailyOCCSWData)o).getFileId().equalsIgnoreCase(this.getFileId())
				&& ((DailyOCCSWData)o).getEcbrInd().equalsIgnoreCase(this.getEcbrInd())
				&& ((DailyOCCSWData)o).getBus_type().equalsIgnoreCase(this.getBus_type())
				&& ((DailyOCCSWData)o).getOccType().equalsIgnoreCase(this.getOccType())
				&& ((DailyOCCSWData)o).getOccCd().equalsIgnoreCase(this.getOccCd())
				) {
				return true;
			} else {
				return false;
			}
	    }
	}
	
	/**
	 * Hash code method overridden for this object to categorize this object in sets 
	 * so that the hash collections can search this object efficiently.
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		int hashCode = HashCodeUtil.SEED;
		hashCode = HashCodeUtil.hash( hashCode, this.getFileId());
		hashCode = HashCodeUtil.hash( hashCode, this.getBus_type());
		hashCode = HashCodeUtil.hash( hashCode, this.getOccType());
		hashCode = HashCodeUtil.hash( hashCode, this.getEcbrInd());
	    return hashCode;
	}
}
