/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.log4j.Logger;

/**
 * This is a singleton class that loads all constant data.
 * 
 * @author Umesh Deole - UD7153
 */
public class RABCConstantsLists {
	private static final Logger logger = Logger.getLogger(RABCConstantsLists.class);
	private static RABCConstantsLists ref;
	private ArrayList alertRuleTypesList = new ArrayList();
	private ArrayList alertRuleTimingListForTracking = new ArrayList();
	private ArrayList alertRuleTimingListForTrending = new ArrayList();
	private ArrayList alertRuleTimingListForTrackingMW = new ArrayList();
	private ArrayList alertRuleTimingListForTrendingMW = new ArrayList();
	private ArrayList statusAlertRuleTimingList = new ArrayList();
	private ArrayList statusAlertRuleTimingListMW = new ArrayList();
	private ArrayList adhocReportTimingList = new ArrayList();
	private ArrayList adhocReportTimingListMW = new ArrayList();
	private ArrayList adhocSchedulerFrequencyList = new ArrayList();
	private ArrayList adhocSchedulerFrequencyListMW = new ArrayList();
	private ArrayList averageTypeList = new ArrayList();
	private ArrayList keyLevelList = new ArrayList();
	private ArrayList layoutTypeList = new ArrayList();
	private ArrayList alertSeverityList = new ArrayList();
	private ArrayList alertStatusList = new ArrayList();
	private ArrayList alertUpdateStatusList = new ArrayList();
	private ArrayList adhocSortList = new ArrayList();
	private ArrayList adhocUnitList = new ArrayList();
	private ArrayList alertUnitList = new ArrayList();
	private ArrayList alertTypeListForTrack = new ArrayList();
	private ArrayList alertTypeListForTrend = new ArrayList();
	private ArrayList adhocReportDurationTimingList = new ArrayList();
	private ArrayList adhocKeyLevelList = new ArrayList();
	private ArrayList adhocSchedulerWeekDaysList = new ArrayList();
    private ArrayList adhocSchedulerMonthDaysList = new ArrayList();
    private ArrayList adhocSchedulerCycleCodeList = new ArrayList();
    private ArrayList adhocSchedulerRunDayList = new ArrayList();
    private static int pageSize = 25;
    private static int adhocDataSetSize = 4;
    private HashMap abbreviationsMap = new HashMap();
    private ArrayList alertRuleMonthlyTimingTypeList = new ArrayList();
    private ArrayList alertRuleMonthlyTimingTypeListMW = new ArrayList();
    private ArrayList monthDayOptions = new ArrayList();
    private ArrayList monthOptions = new ArrayList();
    
    /**
	 * Synchronized method to return the instance of RABCConstantsLists object.
	 * It checks the existance of the instance of RABCConstantsLists and if it does not exists
	 * then creates one instance of RABCConstantsLists and returns otherwise it returns the
	 * existing instance of RABCConstantsLists.
	 * 
	 * @return RABCConstantsLists
	 */
	public static synchronized RABCConstantsLists getRABCConstantsLists(){
		if (ref == null){
			ref = new RABCConstantsLists();
			ref.loadConstantLists();
		}	
		return ref;
	}
	
	/**
	 * Private method to populate the various lists and maps.
	 */
	private void loadConstantLists(){
		loadAlertRuleTypes();
		loadAlertRuleTimingsForTracking();
		loadAlertRuleTimingsForTrending();
		loadAlertRuleMonthlyTimingTypes();
		loadMonthDaysList();
		loadAdhocReportTimings();
		loadAdhocSchedulerFrequencies();
		loadAverageTypes();
		loadKeyLevels();
		loadLayoutTypes();
		loadAlertSeverities();
		loadAlertStatuses();
		loadStatusAlertRuleTimings();
		loadAlertUpdateStatus();
		loadAdhocSorts();
		loadAdhocUnits();
		loadAlertUnits();
		loadAlertTypesForTrack();
		loadAlertTypesForTrend();
		loadAdhocReportDurationTimings() ;
		loadAdhocKeyLevels();
		loadAdhocSchedulerWeekDaysList();
        loadAdhocSchedulerMonthDaysList();
        loadAdhocSchedulerCycleCodeList();
        loadAdhocSchedulerRunDayList();
        loadPageSize();
        loadAbbreviationsMap();
        loadMonthOptionsList();
	}
	
	/**
	 * Method to load the Alert rule types into an ArrayList of PickList objects, where
	 * for each PickList, key = Type, value1 = index value and value2 = null   
	 */
	private void loadAlertRuleTypes(){
		alertRuleTypesList.add(new PickList("Tracking","1"));
		alertRuleTypesList.add(new PickList("Trending","2"));		
	}
	
	/**
	 * Method to return the list of Alert Rule Types.
	 * 
	 * @return ArrayList
	 */
	public ArrayList getAlertRuleTypesList(){
		return alertRuleTypesList;
	}
	
	/**
	 * Method to load the Tracking Alert rule timings into an ArrayList of PickList objects, where
	 * for each PickList, key = Timing, value1 = Index value and value2 = null  
	 */
	private void loadAlertRuleTimingsForTracking(){
		alertRuleTimingListForTracking.add(new PickList("Record","S"));
		alertRuleTimingListForTracking.add(new PickList("Bill Cycle","B"));		
		alertRuleTimingListForTracking.add(new PickList("Call Day Week","D"));
		alertRuleTimingListForTracking.add(new PickList("Monthly","M"));
		
		alertRuleTimingListForTrackingMW.add(new PickList("Record","S"));
		alertRuleTimingListForTrackingMW.add(new PickList("Process Group","B"));		
		alertRuleTimingListForTrackingMW.add(new PickList("Call Day Week","D"));
		alertRuleTimingListForTrackingMW.add(new PickList("Monthly","M"));
	}
	
	/**
	 * Method to load the type lis in case of Monthly timing option
	 */
	private void loadAlertRuleMonthlyTimingTypes(){
		alertRuleMonthlyTimingTypeList.add(new PickList("Day","D"));
		alertRuleMonthlyTimingTypeList.add(new PickList("Bill Round","B"));		
		
		alertRuleMonthlyTimingTypeListMW.add(new PickList("Day","D"));
		alertRuleMonthlyTimingTypeListMW.add(new PickList("Process Group","B"));		
	}
	
	/**
	 * Method to return the list of Tracking Alert rule timings.
	 * 
	 * @return ArrayList
	 */
	public ArrayList getAlertRuleTimingListForTracking(String region){
		if ("MW".equals(region)){
			return alertRuleTimingListForTrackingMW;
		}else {
			return alertRuleTimingListForTracking;
		}
	}
	
	/**
	 * Method to return the list of Trending Alert rule timings.
	 * 
	 * @return ArrayList
	 */
	public ArrayList getAlertRuleTimingListForTrending(String region){
		if ("MW".equals(region)){
			return alertRuleTimingListForTrendingMW;
		}else {
			return alertRuleTimingListForTrending;
		}	
	}
	
	/**
	 * Method to return the list of Monthly timing types.
	 * 
	 * @return ArrayList
	 */
	public ArrayList getAlertRuleMonthlyTimingTypesList(String region){
		if ("MW".equals(region)){
			return alertRuleMonthlyTimingTypeListMW;
		}else {
			return alertRuleMonthlyTimingTypeList;
		}	
	}
	
	/**
	 * Method to load the Trending Alert rule timings into an ArrayList of PickList objects, where
	 * for each PickList, key = Timing, value1 = Index value and value2 = null  
	 */
	private void loadAlertRuleTimingsForTrending(){
		alertRuleTimingListForTrending.add(new PickList("Record","S"));
		alertRuleTimingListForTrending.add(new PickList("Bill Cycle","B"));		
		alertRuleTimingListForTrending.add(new PickList("Call Day Week","D"));
		alertRuleTimingListForTrending.add(new PickList("Monthly","M"));
		
		alertRuleTimingListForTrendingMW.add(new PickList("Record","S"));
		alertRuleTimingListForTrendingMW.add(new PickList("Process Group","B"));		
		alertRuleTimingListForTrendingMW.add(new PickList("Call Day Week","D"));
		alertRuleTimingListForTrendingMW.add(new PickList("Monthly","M"));
	}
	
	/**
	 * Method to load the Alert rule timings for alert status module into an ArrayList of PickList objects, where
	 * for each PickList, key = Timing, value1 = Index value and value2 = null  
	 */
	private void loadStatusAlertRuleTimings(){
		statusAlertRuleTimingList.add(new PickList("Bill Cycle","B"));		
		statusAlertRuleTimingList.add(new PickList("Call Day Week","D"));
		statusAlertRuleTimingList.add(new PickList("Record","R"));
		
		statusAlertRuleTimingListMW.add(new PickList("Process Group","B"));		
		statusAlertRuleTimingListMW.add(new PickList("Call Day Week","D"));
		statusAlertRuleTimingListMW.add(new PickList("Record","R"));
	}
	
	
	/**
	 * Method to return the list of Alert rule timings.
	 * 
	 * @return ArrayList
	 */
	public ArrayList getStatusAlertRuleTimingList(String region){
		if ("MW".equals(region)){
			return statusAlertRuleTimingListMW;
		}else {
			return statusAlertRuleTimingList;
		}
	}
	
	/**
	 * Method to load the Adhoc report timings into an ArrayList of PickList objects, where
	 * for each PickList, key = Timing, value1 = Index value and value2 = null  
	 */
	private void loadAdhocReportTimings(){
		adhocReportTimingList.add(new PickList("Daily","D"));
		adhocReportTimingList.add(new PickList("Monthly","M"));		
		adhocReportTimingList.add(new PickList("Bill Day","B"));
		adhocReportTimingList.add(new PickList("Yearly","Y"));
		adhocReportTimingList.add(new PickList("Record","S"));
		
		adhocReportTimingListMW.add(new PickList("Daily","D"));
		adhocReportTimingListMW.add(new PickList("Monthly","M"));		
		adhocReportTimingListMW.add(new PickList("Process Group","B"));
		adhocReportTimingListMW.add(new PickList("Yearly","Y"));
		adhocReportTimingListMW.add(new PickList("Record","S"));
	}
	
	/**
	 * Method to return the list of Adhoc report timings.
	 * 
	 * @return ArrayList
	 */
	public ArrayList getAdhocReportTimingList(String region){
		if ("MW".equals(region)){
			return adhocReportTimingListMW;
		}else {
			return adhocReportTimingList;
		}
		
	}
	
	/**
	 * Method to load the Adhoc scheduler frequencies into an ArrayList of PickList objects, where
	 * for each PickList, key = Frequency name, value1 = Frequency value and value2 = null
	 */
	private void loadAdhocSchedulerFrequencies(){
		adhocSchedulerFrequencyList.add(new PickList("Daily", "D"));
        adhocSchedulerFrequencyList.add(new PickList("Weekly", "W"));              
        adhocSchedulerFrequencyList.add(new PickList("Monthly", "M"));
        adhocSchedulerFrequencyList.add(new PickList("Yearly", "Y"));
        adhocSchedulerFrequencyList.add(new PickList("Bill Rnd", "B"));
        
        adhocSchedulerFrequencyListMW.add(new PickList("Daily", "D"));
        adhocSchedulerFrequencyListMW.add(new PickList("Weekly", "W"));              
        adhocSchedulerFrequencyListMW.add(new PickList("Monthly", "M"));
        adhocSchedulerFrequencyListMW.add(new PickList("Yearly", "Y"));
        adhocSchedulerFrequencyListMW.add(new PickList("Process Group", "B"));
	}
	
	/**
	 * Method to return the list of Adhoc scheduler frequencies.
	 * 
	 * @return ArrayList
	 */
	public ArrayList getAdhocSchedulerFrequencyList(String region){
		if ("MW".equals(region)){
			return adhocSchedulerFrequencyListMW;
		}else {
			return adhocSchedulerFrequencyList;
		}
	}
	
	/**
	 * Method to load the Alert Rule average types from into an ArrayList of PickList objects, where
	 * for each PickList, key = Average Type, value1 = Average type value and value2 = null
	 */
	private void loadAverageTypes(){
		averageTypeList.add(new PickList("Straight Average","1"));
		averageTypeList.add(new PickList("Drop High/Low","2"));	
	}
	
	/**
	 * Method to return the list of Alert Rule average types.
	 * 
	 * @return ArrayList
	 */
	public ArrayList getAverageTypeList(){
		return averageTypeList;
	}
	
	/**
	 * Method load the Alert Rule key levels into an ArrayList of PickList objects, where
	 * for each PickList, key = Key Level, value1 = Key level value and value2 = null
	 */
	private void loadKeyLevels(){
		keyLevelList.add(new PickList("1","1"));
		keyLevelList.add(new PickList("2","2"));
		keyLevelList.add(new PickList("3","3"));
		keyLevelList.add(new PickList("4","4"));
		keyLevelList.add(new PickList("5","5"));
	}
	
	/**
	 * Method to return the list of Alert Rule key levels.
	 * 
	 * @return ArrayList
	 */
	public ArrayList getKeyLevelList(){
		return keyLevelList;
	}
	
	/**
	 * Method to load the Adhoc report layout types into an ArrayList of PickList objects, where
	 * for each PickList, key = Layout name, value1 = Layout value and value2 = null
	 */
	private void loadLayoutTypes(){
		layoutTypeList.add(new PickList("Ad Hoc Screen 1","1"));
		layoutTypeList.add(new PickList("Ad Hoc Screen 2","2"));
		layoutTypeList.add(new PickList("Ad Hoc Screen 3","3"));
		layoutTypeList.add(new PickList("Ad Hoc Screen 4","4"));
	}
	
	/**
	 * Method to return the list of Adhoc report layout types.
	 * 
	 * @return ArrayList
	 */
	public ArrayList getLayoutTypeList(){
		return layoutTypeList;
	}
	
	/**
	 * Method to load the Alert severity types from into an ArrayList of PickList objects, where
	 * for each PickList, key = severity, value1 = key and value2 = null
	 */
	private void loadAlertSeverities(){
		alertSeverityList.add(new PickList("High","1"));
		alertSeverityList.add(new PickList("Medium","2"));
		alertSeverityList.add(new PickList("Low","3"));
	}
	
	/**
	 * Method to return the list of Alert severity types.
	 * 
	 * @return ArrayList
	 */
	public ArrayList getAlertSeverityList(){
		return alertSeverityList;
	}
	
	/**
	 * Method to load the Alert rule statuses into an ArrayList of PickList objects, where
	 * for each PickList, key = alert status, value1 = alert status and value2 = null
	 */
	private void loadAlertStatuses(){
		alertStatusList.add(new PickList("Warning","Warning"));
		alertStatusList.add(new PickList("Pending","Pending"));
		alertStatusList.add(new PickList("Closed","Closed"));		
	}
	
	/**
	 * Method to return the list of Alert rule statuses.
	 * 
	 * @return ArrayList
	 */
	public ArrayList getAlertStatusList(){
		return alertStatusList;
	}
	
	/**
	 * Method load the Alert rule status for status update page into an ArrayList of PickList objects, where
	 * for each PickList, key = alert status, value1 = alert status value and value2 = null
	 */
	private void loadAlertUpdateStatus(){
		alertUpdateStatusList.add(new PickList("Warning","Warning"));
		alertUpdateStatusList.add(new PickList("Pending","Pending"));
		alertUpdateStatusList.add(new PickList("Closed","Closed"));
	}
	
	/**
	 * Method to return the list of Alert rule status for status update page.
	 * 
	 * @return ArrayList
	 */
	public ArrayList getAlertUpdateStatusList(){
		return alertUpdateStatusList;
	}
	
	/**
	 * Method to load the Adhoc SortList into an ArrayList of PickList objects, where
	 * for each PickList, key = sort list, value1 = sort list value and value2 = null
	 */
	private void loadAdhocSorts(){
		adhocSortList.add(new PickList("none","null"));
		adhocSortList.add(new PickList("Asc","A"));
		adhocSortList.add(new PickList("Desc","D"));
	}
	
	/**
	 * Method to return the list of Adhoc SortList.
	 * 
	 * @return ArrayList
	 */
	public ArrayList getAdhocSortList(){
		return adhocSortList;
	}
	
	/**
	 * Method to load the Adhoc Units into an ArrayList of PickList objects, where
	 * for each PickList, key = adhoc unit, value1 = adhoc unit value and value2 = null
	 */
	private void loadAdhocUnits(){
		adhocUnitList.add(new PickList("none","null"));
		adhocUnitList.add(new PickList("%","P"));
		adhocUnitList.add(new PickList("$ ","D"));
	}
	
	/**
	 * Method to return the list of Adhoc Units.
	 * 
	 * @return ArrayList
	 */
	public ArrayList getAdhocUnitList(){
		return adhocUnitList;
	}
	
	/**
	 * Method to load the Alert Units into an ArrayList of PickList objects, where
	 * for each PickList, key = alert unit, value1 = alert unit value and value2 = null
	 */
	private void loadAlertUnits(){
		alertUnitList.add(new PickList("none","none"));
		alertUnitList.add(new PickList("%","P"));
		alertUnitList.add(new PickList("$ ","D"));
	}
	
	/**
	 * Method to return the list of Alert Units.
	 * 
	 * @return ArrayList
	 */
	public ArrayList getAlertUnitList(){
		return alertUnitList;
	}
	
	/**
	 * Method to load the Alert types For Tracking Rule.
	 */
	private void loadAlertTypesForTrack(){
		alertTypeListForTrack.add(new PickList("Within H/L","1"));
		alertTypeListForTrack.add(new PickList("<= H","2"));
		alertTypeListForTrack.add(new PickList(">= L","3"));
		alertTypeListForTrack.add(new PickList("Equal H","4"));
	}
	
	/**
	 * Method to return the list of Alert types For Tracking Rule.
	 * 
	 * @return ArrayList
	 */
	public ArrayList getAlertTypeListForTrack(){
		return alertTypeListForTrack;
	}
	
	/**
	 * Method to load the Alert types For Trending Rule.
	 */
	private void loadAlertTypesForTrend(){
		alertTypeListForTrend.add(new PickList("Within H/L","1"));
		alertTypeListForTrend.add(new PickList("<= H","2"));
        alertTypeListForTrend.add(new PickList(">= L","3"));
        alertTypeListForTrend.add(new PickList("Equal H","4"));
	}
	
	/**
	 * Method to return the list of Alert types For Trending Rule.
	 * 
	 * @return ArrayList
	 */
	public ArrayList getAlertTypeListForTrend(){
		return alertTypeListForTrend;
	}
	
	/**
	 * Method to load the Ad hoc report duration timings into an ArrayList of PickList objects, where
	 * for each PickList, key = Timing, value1 = Timing value and value2 = null  
	 */
	private void loadAdhocReportDurationTimings(){
		adhocReportDurationTimingList.add(new PickList("Bi-Monthly","B"));
		adhocReportDurationTimingList.add(new PickList("Quarterly","Q"));
		adhocReportDurationTimingList.add(new PickList("Half-Yearly","H"));
		adhocReportDurationTimingList.add(new PickList("Yearly","Y"));
	}
	
	/**
	 * Method to return the list of Ad hoc report duration timings.
	 * 
	 * @return ArrayList
	 */
	public ArrayList getAdhocReportDurationTimingList(){
		return adhocReportDurationTimingList;
	}
	
	/**
	 * Method to load the Adhoc Report key levels into an ArrayList of PickList objects, where
	 * for each PickList, key = Key Level, value1 = Key level value and value2 = null
	 */
	private void loadAdhocKeyLevels(){
		adhocKeyLevelList.add(new PickList("0","0"));
		adhocKeyLevelList.add(new PickList("1","1"));
		adhocKeyLevelList.add(new PickList("2","2"));
		adhocKeyLevelList.add(new PickList("3","3"));
		adhocKeyLevelList.add(new PickList("4","4"));
		adhocKeyLevelList.add(new PickList("5","5"));
	}
	
	/**
	 * Method to return the list of Adhoc Report key levels.
	 * 
	 * @return ArrayList
	 */
	public ArrayList getAdhocKeyLevelList(){
		return adhocKeyLevelList;
	}
	
	/**
	 * Method to load the Adhoc Report schedular week days into an ArrayList of PickList objects, where
	 * for each PickList, key = week day, value1 = week day value and value2 = null
	 */
	private void loadAdhocSchedulerWeekDaysList() {
        adhocSchedulerWeekDaysList.add(new PickList("Sunday","1"));
        adhocSchedulerWeekDaysList.add(new PickList("Monday","2"));
        adhocSchedulerWeekDaysList.add(new PickList("Tuesday","3"));
        adhocSchedulerWeekDaysList.add(new PickList("Wednesday","4"));
        adhocSchedulerWeekDaysList.add(new PickList("Thursday","5"));
        adhocSchedulerWeekDaysList.add(new PickList("Friday","6"));
        adhocSchedulerWeekDaysList.add(new PickList("Saturday","7"));
    }
    
	/**
	 * Method to return the list of Adhoc Report schedular week days.
	 * 
	 * @return ArrayList
	 */
	public ArrayList getAdhocSchedulerWeekDaysList() {
    	return adhocSchedulerWeekDaysList;
    }
    
	/**
	 * Method to load the Adhoc Report schedular month days into an ArrayList of PickList objects, where
	 * for each PickList, key = month day, value1 = month day and value2 = null
	 */
	private void loadAdhocSchedulerMonthDaysList() {
        for (int i=1;i<=31;i++) {
        	adhocSchedulerMonthDaysList.add(new PickList(Integer.toString(i),Integer.toString(i)));
        }
    }

	/**
	 * Method to return the list of Adhoc Report schedular month days.
	 * 
	 * @return ArrayList
	 */
	public ArrayList getAdhocSchedulerMonthDaysList() {
		return adhocSchedulerMonthDaysList;
	}

	/**
	 * Method to load the Adhoc Report schedular cycle codes into an ArrayList of PickList objects, where
	 * for each PickList, key = cycle code, value1 = cycle code value and value2 = null
	 */
	private void loadAdhocSchedulerCycleCodeList(){
        adhocSchedulerCycleCodeList.add(new PickList("Cycle Code","0"));
        adhocSchedulerCycleCodeList.add(new PickList("All","99"));
        for (int i=1;i<=12;i++) {
        	adhocSchedulerCycleCodeList.add(new PickList(Integer.toString(i),Integer.toString(i)));
        }
	}

	/**
	 * Method to return the list of Adhoc Report schedular cycle codes.
	 * 
	 * @return ArrayList
	 */
	public ArrayList getAdhocSchedulerCycleCodeList() {
        return adhocSchedulerCycleCodeList;
	}

	/**
	 * Method to load the Adhoc Report schedular run days into an ArrayList of PickList objects, where
	 * for each PickList, key = run day, value1 = run day and value2 = null
	 */
	private void loadAdhocSchedulerRunDayList() {
        for (int i=1;i<=31;i++) {
			if (i<10) {
				adhocSchedulerRunDayList.add(new PickList(Integer.toString(i),"0"+Integer.toString(i)));
			} else {
				adhocSchedulerRunDayList.add(new PickList(Integer.toString(i),Integer.toString(i)));
			}
        }
	}

	/**
	 * Method to return the list of Adhoc Report schedular run days.
	 * 
	 * @return ArrayList
	 */
	public ArrayList getAdhocSchedulerRunDayList(){
        return adhocSchedulerRunDayList;
	}
	
	/**
	 * Will load days of months available as options
	 */
	private void loadMonthDaysList() {
		for (int i=1;i<=31;i++) {
			if (i<10) {
				monthDayOptions.add(new PickList(Integer.toString(i),"0"+Integer.toString(i)));
			} else {
				monthDayOptions.add(new PickList(Integer.toString(i),Integer.toString(i)));
			}
        }
	}
	
	/**
	 * @return Returns the monthDayOptions.
	 */
	public ArrayList getMonthDayOptions() {
		return monthDayOptions;
	}
	
	/**
	 * Method will load options into the month drop down
	 */
	private void loadMonthOptionsList(){
		monthOptions.add(new PickList(Integer.toString(1), "January"));
		monthOptions.add(new PickList(Integer.toString(2), "February"));
		monthOptions.add(new PickList(Integer.toString(3), "March"));
		monthOptions.add(new PickList(Integer.toString(4), "April"));
		monthOptions.add(new PickList(Integer.toString(5), "May"));
		monthOptions.add(new PickList(Integer.toString(6), "June"));
		monthOptions.add(new PickList(Integer.toString(7), "July"));
		monthOptions.add(new PickList(Integer.toString(8), "August"));
		monthOptions.add(new PickList(Integer.toString(9), "September"));
		monthOptions.add(new PickList(Integer.toString(10), "October"));
		monthOptions.add(new PickList(Integer.toString(11), "November"));
		monthOptions.add(new PickList(Integer.toString(12), "December"));
	}
	
	/**
	 * @return the monthOptions
	 */
	public ArrayList getMonthOptions() {
		return monthOptions;
	}
	
	/**
	 * Method to load the value of default page size.
	 * It looks up the page size in environment entries and sets to the pageSize attribute.
	 */
	private void loadPageSize() {
		Context context;
		try {
			context = (Context) new InitialContext().lookup("java:/comp/env/");
			pageSize = ((Integer) context.lookup("pageSize")).intValue();
			adhocDataSetSize = ((Integer) context.lookup("adhocDataSetSize")).intValue();
		} catch (NamingException nx) {
			logger.error("Unable to get the Page Size from environment entry.", nx);
		}
	}

	/**
	 * Method to return the value of default page size.
	 * 
	 * @return int
	 */
	public int getPageSize(){
        return pageSize;
	}

	/**
	 * @return the adhocDataSetSize
	 */
	public int getAdhocDataSetSize() {
		return adhocDataSetSize;
	}

	/**
	 * Method to load the list of abbreviations and acronymns in a Hash Map.
	 */
	private void loadAbbreviationsMap(){
		abbreviationsMap.put("USG", new PickList("Usg.", "Usage"));
		abbreviationsMap.put("BPP", new PickList("BPP", "Billing Pilot Project"));
		abbreviationsMap.put("ACCT", new PickList("Acct.", "Account"));
		abbreviationsMap.put("TRAN", new PickList("Tran.", "Transaction"));
		abbreviationsMap.put("USOC", new PickList("USOC", "Universal Service Order Code"));
		abbreviationsMap.put("OCC", new PickList("OCC", "Other Charges & Credits"));
		abbreviationsMap.put("SO", new PickList("SO", "Service Order"));
		abbreviationsMap.put("Bpp.", new PickList("BPP", "Bill Pilot Project"));
		abbreviationsMap.put("SUMY", new PickList("Sumy", "Summarization"));
		abbreviationsMap.put("BILLDAY", new PickList("Bill Day", "Bill Day"));
		abbreviationsMap.put("Billday", new PickList("Bill Day", "Bill Day"));
		abbreviationsMap.put("Calif", new PickList("California", "California"));
		abbreviationsMap.put("BUS_TYPE", new PickList("Business Type", "Business Type"));
		abbreviationsMap.put("Surcharge Amt", new PickList("Surcharge Amt.", "Surcharge Amount"));
		abbreviationsMap.put("ICBS", new PickList("ICBS", "Inter-Carrier Billing Service"));
		abbreviationsMap.put("BLG", new PickList("Blg", "Billing"));
		abbreviationsMap.put("ACTVT", new PickList("Actvt", "Activity"));
		abbreviationsMap.put("ADJ", new PickList("Adj", "Adjustment"));
		abbreviationsMap.put("MSG", new PickList("Msg", "Message"));
		abbreviationsMap.put("PYMT", new PickList("Pymt", "Payment"));
		abbreviationsMap.put("DEP", new PickList("Dep", "Deposit"));
		abbreviationsMap.put("ISG", new PickList("Isg", "Information Services Group"));
		abbreviationsMap.put("SVC", new PickList("Svc", "Service"));
		abbreviationsMap.put("ORD", new PickList("Ord", "Order"));
		abbreviationsMap.put("INFO", new PickList("Info", "Information"));
		abbreviationsMap.put("RABC", new PickList("Rabc", "Revenue Assurance Billing Controls"));
		abbreviationsMap.put("ERR", new PickList("Err", "Error"));
		abbreviationsMap.put("TRN", new PickList("Trn", "Transaction"));
		abbreviationsMap.put("COMP", new PickList("Comp", "Component"));
		abbreviationsMap.put("OCC_TYPE", new PickList("Occ type", "Occ type"));
	}

	/**
	 * Method to whether the passed string value is abbreviation or not.
	 * 
	 * @param str
	 * @return boolean
	 */
	private boolean isAbbreviation(String str) {
		if (abbreviationsMap.containsKey(str)) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * Method to return the abbreviation value of passed string.
	 * 
	 * @param abbreviation
	 * @return String
	 */
	private String getAbbreviation(String abbreviation) {
		return ((PickList) abbreviationsMap.get(abbreviation)).getKey();
	}
	
	/**
	 * Method to return the abbreviation description of passed string.
	 * 
	 * @param abbreviation
	 * @return String
	 */
	private String getAbbreviationDesc(String abbreviation) {
		return ((PickList) abbreviationsMap.get(abbreviation)).getValue1();
	}
	
	/**
	 * Method to return the string in propper case of passed string.
	 * 
	 * @param str
	 * @return String
	 */
	private String getProperCase(String str) {
		String properCase = null;
		if ((str != null) && (str.length() > 0)) {
			properCase = str.substring(0, 1).toUpperCase() + str.substring(1).toLowerCase();
		}
		return properCase;
	}
	
	/**
	 * Method to return the text for passed string after manipulation.
	 * 
	 * @param str
	 * @param mouseOver
	 * @return String
	 */
	public String getText(String str, boolean mouseOver) {
		String text = null;
		if ((str != null) && (str.length() > 0)) {
			if (isAbbreviation(str)) {
				if (mouseOver) {
					text = getAbbreviationDesc(str);
				} else {
					text = getAbbreviation(str);
				}
			} else {
				StringBuffer textBuffer = new StringBuffer();
				String[] strArray = str.split(" ");
				int length = strArray.length;
				String word = null;
				for (int i = 0; i < length; i++) {
					word = strArray[i];
					if (isAbbreviation(word)) {
						if (i == length-1) {
							if (mouseOver) {
								textBuffer.append(getAbbreviationDesc(word));
							} else {
								textBuffer.append(getAbbreviation(word));
							}
						} else {
							if (mouseOver) {
								textBuffer.append(getAbbreviationDesc(word)).append(" ");
							} else {
								textBuffer.append(getAbbreviation(word)).append(" ");
							}
						}
					} else {
						if (i == length-1) {
							textBuffer.append(getProperCase(word));
						} else {
							textBuffer.append(getProperCase(word)).append(" ");
						}
					}
				}
				text = textBuffer.toString();
			}
		}
		return text;
	}
	
	/**
	 * Method to return the text for passed string after manipulation.
	 * 
	 * @param str
	 * @param mouseOver
	 * @return String
	 */
	public String getText1(String str, boolean mouseOver) {
		String text = null;
		if ((str != null) && (str.length() > 0)) {
			if (isAbbreviation(str)) {
				if (mouseOver) {
					text = getAbbreviationDesc(str);
				} else {
					text = getAbbreviation(str);
				}
			} else {
				StringBuffer textBuffer = new StringBuffer();
				String[] strArray = str.split(" ");
				int length = strArray.length;
				String word = null;
				for (int i = 0; i < length; i++) {
					word = strArray[i];
					if (isAbbreviation(word)) {
						if (i == length-1) {
							if (mouseOver) {
								textBuffer.append(getAbbreviationDesc(word));
							} else {
								textBuffer.append(getAbbreviation(word));
							}
						} else {
							if (mouseOver) {
								textBuffer.append(getAbbreviationDesc(word)).append(" ");
							} else {
								textBuffer.append(getAbbreviation(word)).append(" ");
							}
						}
					} else {
						if (i == length-1) {
							textBuffer.append(word);
						} else {
							textBuffer.append(word).append(" ");
						}
					}
				}
				text = textBuffer.toString();
			}
		}
		return text;
	}
	
	/**
	 * This method sets the format for RABCNumber.
	 * 
	 * @param data
	 * @param nbrOfDec
	 * @param calcRule
	 * @return String
	 */
	public String formatRABCNumber(double data, int nbrOfDec, String calcRule) {
		String value = "";
		
		String format = ",##0";
		for (int i = 0; i < nbrOfDec; i++) {
			if (i == 0) format = format + ".";
			format = format + "0";
		}
		NumberFormat formatter = new DecimalFormat(format);
		value = formatter.format(data);
		if ((calcRule != null) && (calcRule.equals("T"))) {
			return value + "%";
		}
		
		return value;
	}
}
