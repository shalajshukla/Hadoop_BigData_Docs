/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.ArrayList;
import java.text.MessageFormat;

import org.apache.log4j.Logger;

import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.RABCException;

/**
 * This is a DAO that performs SELECT, INSERT and UPDATE on RABC_ALERT_RULE_PRESN_ELEM table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class AlertRulePresnElemDAO {
	private static final Logger logger = Logger.getLogger(AlertRulePresnElemDAO.class);

	/**
	 * Returns the list of AlertRulePresnElem objects.
	 * 
	 * @param conn 
	 * @param failures
	 * @param args
	 * @param baseSQL
	 * @return List
	 */
	public List get(Connection conn, List failures, List args, String baseSQL) {
		List alertRulePresnElemList = null;
		AlertRulePresnElem alertRulePresnElem = null;
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		
		try
		{
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("AlertRulePresnElemDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			alertRulePresnElemList = new ArrayList();
			while (rs.next()) {
				alertRulePresnElemList.add(buildAlertRulePresnElem(rs));
			}
			
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return null;
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
		
		return alertRulePresnElemList;
	}

	/**
	 * Private method to build AlertRulePresnElem object and return it to caller.
	 * 
	 * @param rs
	 * @return AlertRulePresnElem
	 * @throws SQLException
	 */
	private AlertRulePresnElem buildAlertRulePresnElem(ResultSet rs) throws SQLException {
		AlertRulePresnElem alertRulePresnElem = new AlertRulePresnElem();
		
		alertRulePresnElem.setPresnId(rs.getInt("PRESN_ID"));
		alertRulePresnElem.setWebid(rs.getString("WEBID"));
		alertRulePresnElem.setExecPresnSeqNum(rs.getInt("EXEC_PRESN_SEQ_NUM"));
		alertRulePresnElem.setPresnSeqNum(rs.getInt("PRESN_SEQ_NUM"));
		alertRulePresnElem.setPresnName(rs.getString("PRESN_NAME"));
		alertRulePresnElem.setDataTbl(rs.getString("DATA_TBL"));
		alertRulePresnElem.setPartiRefId(rs.getInt("PARTI_REF_ID"));
		alertRulePresnElem.setDataDdlName(rs.getString("DATA_DDL_NAME"));
		alertRulePresnElem.setHeaderLinkInd(rs.getString("HEADER_LINK_IND"));
		alertRulePresnElem.setHeaderLinkNum(rs.getInt("HEADER_LINK_NUM"));
		alertRulePresnElem.setHeaderDescInd(rs.getString("HEADER_DESC_IND"));
		alertRulePresnElem.setHeaderMouseOverNum(rs.getInt("HEADER_MOUSE_OVER_NUM"));
		alertRulePresnElem.setDataLinkInd(rs.getString("DATA_LINK_IND"));
		alertRulePresnElem.setDataLinkNum(rs.getInt("DATA_LINK_NUM"));
		alertRulePresnElem.setDataDescInd(rs.getString("DATA_DESC_IND"));
		alertRulePresnElem.setDataMouseOverNum(rs.getInt("DATA_MOUSE_OVER_NUM"));
		alertRulePresnElem.setGraphPresnInd(rs.getString("GRAPH_PRESN_IND"));
		alertRulePresnElem.setPresnElemTotInd(rs.getString("PRESN_ELEM_TOT_IND"));
		alertRulePresnElem.setPresnUnitInd(rs.getString("PRESN_UNIT_IND"));
		alertRulePresnElem.setPresnSumInd(rs.getString("PRESN_SUM_IND"));
		alertRulePresnElem.setDatabaseNode(rs.getString("DATABASE_NODE"));
		alertRulePresnElem.setPresnCalcNum(rs.getInt("PRESN_CALC_NUM"));
		alertRulePresnElem.setPresnSuppressInd(rs.getString("PRESN_SUPPRESS_IND"));
		alertRulePresnElem.setPrevDataInd(rs.getString("PREV_DATA_IND"));
		alertRulePresnElem.setViewName(rs.getString("VIEW_NAME"));
		alertRulePresnElem.setPresnOrdInd(rs.getString("PRESN_ORD_IND"));
		alertRulePresnElem.setPresnFormatCode(rs.getString("PRESN_FORMAT_CODE"));
		alertRulePresnElem.setDiffDataInd(rs.getString("DIFF_DATA_IND"));
		return alertRulePresnElem;
	}

	/**
	 * Execute the insert or update statement on RABC_ALERT_RULE_PRESN_ELEM table.
	 * 
	 * @param conn
	 * @param failures
	 * @param args
	 * @param baseSQL
	 */
	public void executeUpdate(Connection conn, List failures, List args, String baseSQL) {
		int rowsUpdated = 0;
		Statement stmt = null;
		String sqlStmt = null;
		
		try
		{
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("AlertRulePresnElemDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rowsUpdated = stmt.executeUpdate(sqlStmt);
			logger.debug("SQL - Execution complete."+ String.valueOf(rowsUpdated) + "  rows updated");
			
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return;
		} finally {
			SQLHelper.closeStatement(stmt, failures, logger);
		}
	}

}
