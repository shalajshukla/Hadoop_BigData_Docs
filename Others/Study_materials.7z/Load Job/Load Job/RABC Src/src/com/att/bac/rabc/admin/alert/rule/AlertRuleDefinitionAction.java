/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.admin.alert.rule;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.att.bac.rabc.ConnectionManager;
import com.att.bac.rabc.DataTblDdlBean;
import com.att.bac.rabc.PickList;
import com.att.bac.rabc.ProgressBar;
import com.att.bac.rabc.RABCConstantsLists;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.StaticDataLoader;
import com.att.bac.rabc.Tree;

/**
 * This is a Action Class for Alert Rule Definition (All 3 steps).
 * 
 * @author Shashank Weginwar - SW3562
 */
public class AlertRuleDefinitionAction extends DispatchAction{
	public static Logger  logger = Logger.getLogger(AlertRuleDefinitionAction.class);
	AlertRuleDefinitionService  alertRuleDefinitionService = AlertRuleDefinitionService.getAlertRuleDefinitionService();
	AlertRuleDefinitionUpdateService  alertRuleDefinitionUpdateService = AlertRuleDefinitionUpdateService.getAlertRuleUpdateService();
	AlertRuleDefinitionSaveService  alertRuleDefinitionSaveService = AlertRuleDefinitionSaveService.getAlertRuleDefinitionSaveService();
	
	/**
	 * Logic for the default action.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @see org.apache.struts.actions.DispatchAction#unspecified(org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public ActionForward unspecified(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		AlertRuleDefinitionForm  alertRuleDefinitionForm = (AlertRuleDefinitionForm) form;
		HttpSession session = request.getSession(false);
		ProgressBar progressBar = new ProgressBar(session);

		return define(mapping,alertRuleDefinitionForm,request, response);
	}
	
	/**
	 * This method is called when the user clicks on define on the main page.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward define(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		AlertRuleDefinitionForm  alertRuleDefinitionForm = (AlertRuleDefinitionForm) form;
		HttpSession session = request.getSession(false);
		ProgressBar progressBar = new ProgressBar(session);
		reset(alertRuleDefinitionForm);
		alertRuleDefinitionForm.setActionType("NEW");
		
		/*
		 * Collect the parameters such as data source & type of alert rule from the request 
		 * 
		 */
		AlertRuleDefinition alertRuleDefinition = new AlertRuleDefinition((String)request.getSession().getAttribute("region"));
		
		List dataTblDdlBeanList = StaticDataLoader.getDataTblDdlForBillRndNotNull((String)request.getSession().getAttribute("region"));
		if (!dataTblDdlBeanList.isEmpty()){
			String billRndTables = "";
			int dataTblDdlBeanListSize = dataTblDdlBeanList.size();
			for (int k=0;k<dataTblDdlBeanListSize;k++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblDdlBeanList.get(k);
				if (k==0){
					billRndTables = dataTblDdlBean.getAlertProcTbl();
				}else {
					billRndTables += ";" + dataTblDdlBean.getAlertProcTbl();
				}
			}
			
			alertRuleDefinitionForm.setBillRndTables(billRndTables);
		}
		
		if (request.getAttribute("dataSource")!=null){
			List dbNodeList = StaticDataLoader.getDBNodeByID((String)request.getAttribute("dataSource"), (String)request.getSession().getAttribute("region"));
			if (!dbNodeList.isEmpty()){
				PickList dbNode = (PickList)dbNodeList.get(0);
				alertRuleDefinition.setDbNodeId((String)request.getAttribute("dataSource"));
				alertRuleDefinition.setDataSource(dbNode.getValue1()); //put description here
			}
		}
		
		if (request.getAttribute("alertRuleType")!=null){
			alertRuleDefinition.setAlertRuleType((String)request.getAttribute("alertRuleType"));
		}
		
		alertRuleDefinitionForm.setAlertRuleDefinition(alertRuleDefinition);
		
		return load(mapping,alertRuleDefinitionForm,request, response);
	}
	
	/**
	 * This method is called when the user selects an alert rule & clicks on update Alert Rule method.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward update(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		AlertRuleDefinitionForm  alertRuleDefinitionForm = (AlertRuleDefinitionForm) form;
		HttpSession session = request.getSession(false);
		ProgressBar progressBar = new ProgressBar(session);
		reset(alertRuleDefinitionForm);
		alertRuleDefinitionForm.setActionType("UPDATE");

		/*
		 * Collect the parameters such as data source & alert rule [key] from the request if the 
		 * 
		 */
		AlertRuleDefinition alertRuleDefinition = new AlertRuleDefinition((String)request.getSession().getAttribute("region"));
		
		List dataTblDdlBeanList = StaticDataLoader.getDataTblDdlForBillRndNotNull((String)request.getSession().getAttribute("region"));
		if (!dataTblDdlBeanList.isEmpty()){
			String billRndTables = "";
			int dataTblDdlBeanListSize = dataTblDdlBeanList.size();
			for (int k=0;k<dataTblDdlBeanListSize;k++){
				DataTblDdlBean dataTblDdlBean = (DataTblDdlBean)dataTblDdlBeanList.get(k);
				if (k==0){
					billRndTables = dataTblDdlBean.getAlertProcTbl();
				}else {
					billRndTables += ";" + dataTblDdlBean.getAlertProcTbl();
				}
			}
			
			alertRuleDefinitionForm.setBillRndTables(billRndTables);
		}
		
		if (request.getAttribute("dataSource")!=null){
			List dbNodeList = StaticDataLoader.getDBNodeByID((String)request.getAttribute("dataSource"), (String)request.getSession().getAttribute("region"));
			if (!dbNodeList.isEmpty()){
				PickList dbNode = (PickList)dbNodeList.get(0);
				alertRuleDefinition.setDbNodeId((String)request.getAttribute("dataSource"));
				alertRuleDefinition.setDataSource(dbNode.getValue1()); //put description here
			}
		}

		if (request.getAttribute("alertRule")!=null){
			alertRuleDefinition.setAlertRule((String)request.getAttribute("alertRule"));
		}
		alertRuleDefinitionForm.setAlertTypeOptionsList(RABCConstantsLists.getRABCConstantsLists().getAlertTypeListForTrend());
		alertRuleDefinitionForm.setAlertRuleDefinition(alertRuleDefinition);

		return load(mapping,alertRuleDefinitionForm,request, response);
	}
	
	/**
	 * Logic for the load action.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward load(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response){
		AlertRuleDefinitionForm  alertRuleDefinitionForm = (AlertRuleDefinitionForm) form;
		AlertRuleDefinition alertRuleDefinition = alertRuleDefinitionForm.getAlertRuleDefinition();
		Connection connection = null;
		HttpSession session = request.getSession(false);
		ProgressBar progressBar = new ProgressBar(session);
		Tree tableTree;
		
		/*
		 * Update calendar attributes
		 */
		alertRuleDefinitionForm.setBillRounds(StaticDataLoader.getBillRounds((String)request.getSession().getAttribute("region")));
		alertRuleDefinitionForm.setProcDates(StaticDataLoader.getProcDates((String)request.getSession().getAttribute("region")));
		alertRuleDefinitionForm.setHolidayIndicators(StaticDataLoader.getHolidayIndicators((String)request.getSession().getAttribute("region")));
		alertRuleDefinitionForm.setLoadedDataDates(StaticDataLoader.getLoadedDataDatesByRegion((String)request.getSession().getAttribute("region")));
		/*
		 * Initialize lists of arguments as well as failures
		 */
		List failureList = new ArrayList();
		List args = new ArrayList();
		
		try{
			connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
			progressBar.setProgressPercent(10);
			/*
			 * Check whether this is update or new action depending upon which the object will get populated
			 */
			if (alertRuleDefinition.getAlertRule()==null){
				if (session.getAttribute("bacUserID")!=null){
					args.add((String)session.getAttribute("bacUserID"));
				}else {
					throw new IllegalStateException("Unable to get user ID from session");
				}
				alertRuleDefinition = alertRuleDefinitionService.buildNew(connection, failureList, args, alertRuleDefinition, progressBar);
			}else {
				args.add(alertRuleDefinition.getAlertRule());
				if (session.getAttribute("bacUserID")!=null){
					args.add((String)session.getAttribute("bacUserID"));
				}else {
					throw new IllegalStateException("Unable to get user ID from session");
				}

				// get above from the session
				alertRuleDefinition = alertRuleDefinitionService.getAlertRuleDefinition(connection,failureList, args, progressBar, (String)request.getSession().getAttribute("region"));
				
				if ("UPDATE".equals(alertRuleDefinitionForm.getActionType())){
					/*
					 * Setting the options for related alert rules
					 */
					List relatedAlertRulesOptions = new ArrayList();
					relatedAlertRulesOptions = AlertItemService.getAlertItemService().getRelatedAlerts(connection,failureList,alertRuleDefinition,(String)request.getSession().getAttribute("region"));
					alertRuleDefinition.getRelatedAlertRulesList().clear();
					for (int i=0;i<relatedAlertRulesOptions.size();i++){
						alertRuleDefinition.addRelatedAlertRulesList((String)relatedAlertRulesOptions.get(i));
					}
					//relatedAlertRulesOptions.clear();
				}
			}
			progressBar.setProgressPercent(60);
			
			AlertRuleTreeService treeService = new AlertRuleTreeService();
			tableTree = treeService.generateTree(connection,failureList,args,(String)request.getSession().getAttribute("region"));
			alertRuleDefinitionForm.setTableTree(tableTree);
			
			alertRuleDefinitionForm.setAlertRuleDefinition(alertRuleDefinition);
			progressBar.setProgressPercent(70);
			
			/*
			 * Code to populate reportLinkList from alertRuleDefinition object
			 */
			alertRuleDefinitionForm.getReportLinkList().clear();
			if (!alertRuleDefinition.getReportLinkOptionsList().isEmpty()){
				int reportLinkListSize = alertRuleDefinition.getReportLinkOptionsList().size();
				for (int j=0;j<reportLinkListSize;j++){
					alertRuleDefinitionForm.addReportLink((PickList)alertRuleDefinition.getReportLinkOptionsList().get(j));
				}
			}
			alertRuleDefinitionForm.setReportLink(null);
			alertRuleDefinitionForm.setAlertUnit("none");
			
			progressBar.setProgressPercent(80);
			if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
				alertRuleDefinitionForm.setData(alertRuleDefinitionService.getData(alertRuleDefinition));
			}else {
				alertRuleDefinitionForm.setData(alertRuleDefinitionService.getData(alertRuleDefinition.getAlertItemList()));
			}
			progressBar.setProgressPercent(90);
			// Set the existing list of alert rules
			alertRuleDefinitionForm.setAlertRules(alertRuleDefinitionService.getAlertRules(connection,failureList));
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch(Exception e){
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}) + " Exception details: " + e.getMessage(), e);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		progressBar.setProgressPercent(100);
		if (!failureList.isEmpty()){
			request.setAttribute("failures", failureList);
			return mapping.findForward("error");
		} else {
			if ("Trend".equals(alertRuleDefinition.getAlertRuleType()) || "2".equals(alertRuleDefinition.getAlertRuleType())){
				return mapping.findForward("AlertRuleTrendingStep1");
			}else {
				return mapping.findForward("AlertRuleTrackingStep1");
			}
		}
	}
	
	/**
	 * Logic for Next action.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward next(ActionMapping mapping,ActionForm form,HttpServletRequest request,HttpServletResponse response){
		AlertRuleDefinitionForm  alertRuleDefinitionForm = (AlertRuleDefinitionForm) form;
		HttpSession session = request.getSession(false);
		ProgressBar progressBar = new ProgressBar(session);
		AlertRuleDefinition alertRuleDefinition = alertRuleDefinitionForm.getAlertRuleDefinition();
		alertRuleDefinition = checkClearSupplementTypes(alertRuleDefinition);
		if ("Track".equals(alertRuleDefinition.getAlertRuleType()) || "1".equals(alertRuleDefinition.getAlertRuleType())) {
			alertRuleDefinition = alertRuleDefinitionService.updateAlertItems(alertRuleDefinition);
		}
		progressBar.setProgressPercent(10);
		/*
		 * Initialize lists of arguments as well as failures
		 */
		List failureList = new ArrayList();
		List args = new ArrayList();
		args.add(alertRuleDefinitionForm.getData());
		Connection connection = null;
		
		try{
			connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
			
			/*
			 * Steps required to set some options, etc - No updates to object required here except in case of step 2 & 3
			 * where you might need to append to/ delete the list attributes of AlertRuleDefinitionStep2Row or AlertKey
			 */	
			if ("NEW".equals(alertRuleDefinitionForm.getActionType())){
				alertRuleDefinition = alertRuleDefinitionService.updateAlertRuleDefinition(connection, alertRuleDefinition,failureList, args, (String)request.getSession().getAttribute("region"));
				progressBar.setProgressPercent(20);
				if (alertRuleDefinition.getAlertItemList().isEmpty()){
					AlertItem alertItem = AlertItemService.getAlertItemService().addAlertItem(connection, failureList, alertRuleDefinition.getLHSColumnsList(), alertRuleDefinition.getRHSColumnsList(), (String)request.getSession().getAttribute("region"));
					alertRuleDefinition.addAlertItem(alertItem);
				}
				progressBar.setProgressPercent(30);
				
				AlertItemService.getAlertItemService().updateSupplementTypeOptions(alertRuleDefinition);
				alertRuleDefinitionForm.setAlertRuleDefinition(alertRuleDefinition);
				progressBar.setProgressPercent(40);
				
				if (alertRuleDefinitionService.checkFsq(alertRuleDefinition.getLHSColumnsList(), (String)request.getSession().getAttribute("region")) || alertRuleDefinitionService.checkFsq(alertRuleDefinition.getRHSColumnsList(), (String)request.getSession().getAttribute("region"))){
					alertRuleDefinitionForm.setCheckFsq("1");
				}
				
				if (alertRuleDefinitionService.checkTime(alertRuleDefinition.getLHSColumnsList(),alertRuleDefinition.getAlertRuleTiming(), (String)request.getSession().getAttribute("region")) || alertRuleDefinitionService.checkTime(alertRuleDefinition.getRHSColumnsList(),alertRuleDefinition.getAlertRuleTiming(), (String)request.getSession().getAttribute("region"))){
					alertRuleDefinitionForm.setCheckTiming("1");
				}
				progressBar.setProgressPercent(60);
				/*
				 * Setting the options for related alert rules
				 */
				List relatedAlertRulesOptions = new ArrayList();
				relatedAlertRulesOptions = AlertItemService.getAlertItemService().getRelatedAlerts(connection,failureList,alertRuleDefinition,(String)request.getSession().getAttribute("region"));
				alertRuleDefinition.getRelatedAlertRulesList().clear();
				for (int i=0;i<relatedAlertRulesOptions.size();i++){
					alertRuleDefinition.addRelatedAlertRulesList((String)relatedAlertRulesOptions.get(i));
				}
				progressBar.setProgressPercent(80);
				
				//setDefaults(alertRuleDefinitionForm,alertRuleDefinition);
			}
			
			if("UPDATE".equals(alertRuleDefinitionForm.getActionType()) && ("Trend".equals(alertRuleDefinition.getAlertRuleType()) || "2".equals(alertRuleDefinition.getAlertRuleType()))){
				alertRuleDefinition = alertRuleDefinitionService.updateAlertRuleDefinition(connection, alertRuleDefinition, failureList, args, (String)request.getSession().getAttribute("region"));
				progressBar.setProgressPercent(30);
				if (alertRuleDefinition.getAlertItemList().isEmpty()){
					AlertItem alertItem = AlertItemService.getAlertItemService().addAlertItem(connection, failureList, alertRuleDefinition.getLHSColumnsList(), alertRuleDefinition.getRHSColumnsList(), (String)request.getSession().getAttribute("region"));
					alertRuleDefinition.addAlertItem(alertItem);
				}
				progressBar.setProgressPercent(60);
				AlertItemService.getAlertItemService().updateSupplementTypeOptions(alertRuleDefinition);
				alertRuleDefinitionForm.setAlertRuleDefinition(alertRuleDefinition);
				progressBar.setProgressPercent(80);
			}
			progressBar.setProgressPercent(90);
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}) + " Exception details: " + e.getMessage(), e);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		progressBar.setProgressPercent(100);
		
		if (!failureList.isEmpty()){
			request.setAttribute("failures", failureList);
			return mapping.findForward("error");
		}else {
			if ("Trend".equals(alertRuleDefinition.getAlertRuleType()) || "2".equals(alertRuleDefinition.getAlertRuleType())){
				if (alertRuleDefinitionForm.getStepNo()==1){
					if (("on".equals(alertRuleDefinition.getFileSequenceIndicator()) && "1".equals(alertRuleDefinitionForm.getCheckFsq())) || "1".equals(alertRuleDefinitionForm.getCheckTiming()) ){
						return mapping.findForward("AlertRuleTrendingStep1");
					}else {
						return mapping.findForward("AlertRuleTrendingStep2");
					}	
				}else {
					return mapping.findForward("AlertRuleTrendingStep1");
				}
			}else {
				if (alertRuleDefinitionForm.getStepNo()==1){
					if (("on".equals(alertRuleDefinition.getFileSequenceIndicator()) && "1".equals(alertRuleDefinitionForm.getCheckFsq())) || "1".equals(alertRuleDefinitionForm.getCheckTiming()) ){
						return mapping.findForward("AlertRuleTrackingStep1");
					}else {
						return mapping.findForward("AlertRuleTrackingStep2");
					}
				}else if (alertRuleDefinitionForm.getStepNo()==2){
					return mapping.findForward("AlertRuleTrackingStep3");
				}else {
					return mapping.findForward("AlertRuleTrackingStep1");
				}
			}
		}
	}
	
	/**
	 * Logic for Back action. 
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward back(ActionMapping mapping,ActionForm form,HttpServletRequest request,HttpServletResponse response){
		AlertRuleDefinitionForm  alertRuleDefinitionForm = (AlertRuleDefinitionForm) form;
		HttpSession session = request.getSession(false);
		ProgressBar progressBar = new ProgressBar(session);
		AlertRuleDefinition alertRuleDefinition = alertRuleDefinitionForm.getAlertRuleDefinition();
		alertRuleDefinition = checkClearSupplementTypes(alertRuleDefinition);
		
		if(alertRuleDefinitionForm.getRelatedAlertsFlag() == 0){
			alertRuleDefinition.setSelectedRelatedAlertRules(null);
		}
		progressBar.setProgressPercent(10);
		
		/*
		 * Initialize lists of arguments as well as failures
		 */
		List failureList = new ArrayList();
		List args = new ArrayList();
		args.add("");
		
		progressBar.setProgressPercent(40);
		
		/*
		 * Steps required to set some options, etc - No updates to object required here except in case of step 2 & 3
		 * where you might need to append to/ delete the list attributes of AlertRuleDefinitionStep2Row or AlertKey
		 * Delegate this work to the service class
		 */
		AlertItemService.getAlertItemService().updateSupplementTypeOptions(alertRuleDefinition);
		progressBar.setProgressPercent(90);
		
		progressBar.setProgressPercent(100);
		
		if (!failureList.isEmpty()){
			request.setAttribute("failures", failureList);
			return mapping.findForward("error");
		} else {
			if ("Trend".equals(alertRuleDefinition.getAlertRuleType()) || "2".equals(alertRuleDefinition.getAlertRuleType())){
				if (alertRuleDefinitionForm.getStepNo()==2){
					return mapping.findForward("AlertRuleTrendingStep1");
				}else {
					return mapping.findForward("AlertRuleTrendingStep1");
				}
			}else {
				if (alertRuleDefinitionForm.getStepNo()==3){
					return mapping.findForward("AlertRuleTrackingStep2");
				}else if (alertRuleDefinitionForm.getStepNo()==2){
					return mapping.findForward("AlertRuleTrackingStep1");
				}else {
					return mapping.findForward("AlertRuleTrackingStep1");
				}
			}	
		}
	}
	
	/**
	 * Logic for Add Alert Item action
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward addAlertItem(ActionMapping mapping,ActionForm form,HttpServletRequest request,HttpServletResponse response){
		AlertRuleDefinitionForm  alertRuleDefinitionForm = (AlertRuleDefinitionForm) form;
		HttpSession session = request.getSession(false);
		ProgressBar progressBar = new ProgressBar(session);
		AlertRuleDefinition alertRuleDefinition = alertRuleDefinitionForm.getAlertRuleDefinition();
		alertRuleDefinition = checkClearSupplementTypes(alertRuleDefinition);
		progressBar.setProgressPercent(10);
		
		/*
		 * Initialize lists of arguments as well as failures
		 */
		List failureList = new ArrayList();
		List args = new ArrayList();
		args.add("");
		
		Connection connection = null;

		try {
			connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
			progressBar.setProgressPercent(40);
			
			AlertItem alertItem = AlertItemService.getAlertItemService().addAlertItem(connection, failureList, alertRuleDefinition.getLHSColumnsList(), alertRuleDefinition.getRHSColumnsList(), (String)request.getSession().getAttribute("region"));
			progressBar.setProgressPercent(60);
			alertRuleDefinition.addAlertItem(alertItem);
			AlertItemService.getAlertItemService().updateSupplementTypeOptions(alertRuleDefinition);
			progressBar.setProgressPercent(80);
			alertRuleDefinitionForm.setAlertRuleDefinition(alertRuleDefinition);
			progressBar.setProgressPercent(90);
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}) + " Exception details: " + e.getMessage(), e);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		progressBar.setProgressPercent(100);
		
		/*
		 * Find out where to forward based on current step no
		 */
		if (!failureList.isEmpty()){
			request.setAttribute("failures", failureList);
			return mapping.findForward("error");
		} else {
			return mapping.findForward("AlertRuleTrackingStep2");
		}
	}
	
	/**
	 * Logic for Add Alert Item action
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward deleteAlertItem(ActionMapping mapping,ActionForm form,HttpServletRequest request,HttpServletResponse response){
		AlertRuleDefinitionForm  alertRuleDefinitionForm = (AlertRuleDefinitionForm) form;
		HttpSession session = request.getSession(false);
		ProgressBar progressBar = new ProgressBar(session);
		AlertRuleDefinition alertRuleDefinition = alertRuleDefinitionForm.getAlertRuleDefinition();
		alertRuleDefinition = checkClearSupplementTypes(alertRuleDefinition);
		progressBar.setProgressPercent(10);
		
		/*
		 * Initialize lists of arguments as well as failures
		 */
		List failureList = new ArrayList();
		
		int deleteIndex=alertRuleDefinitionForm.getDeleteIndex();
		progressBar.setProgressPercent(40);
		alertRuleDefinition = AlertItemService.getAlertItemService().deleteAlertItem(alertRuleDefinition,deleteIndex);
		progressBar.setProgressPercent(80);
		AlertItemService.getAlertItemService().updateSupplementTypeOptions(alertRuleDefinition);
		
		progressBar.setProgressPercent(100);
		
		if (!failureList.isEmpty()){
			request.setAttribute("failures", failureList);
			return mapping.findForward("error");
		}
		
		/*
		 * Find out where to forward based on current step no
		 */
		return mapping.findForward("AlertRuleTrackingStep2");
	}
	
	/**
	 * Logic for Save action.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward save(ActionMapping mapping,ActionForm form,HttpServletRequest request,HttpServletResponse response){
		AlertRuleDefinitionForm  alertRuleDefinitionForm = (AlertRuleDefinitionForm) form;
		HttpSession session = request.getSession(false);
		ProgressBar progressBar = new ProgressBar(session);
		AlertRuleDefinition alertRuleDefinition = alertRuleDefinitionForm.getAlertRuleDefinition();
		
		if ("2".equals(alertRuleDefinition.getAlertRuleType()) || "Trend".equals(alertRuleDefinition.getAlertRuleType()) ){
			alertRuleDefinition = checkClearSupplementTypes(alertRuleDefinition);
		}
		
		if(alertRuleDefinitionForm.getRelatedAlertsFlag() == 0){
			alertRuleDefinition.setSelectedRelatedAlertRules(null);
		}
		progressBar.setProgressPercent(10);
		
		ActionForward forward;
		Connection connection = null;
		List failureList = new ArrayList();
		List args = new ArrayList();
		args.add(session.getAttribute("bacUserID"));
		args.add(alertRuleDefinition.getAlertGroups());
		args.add(alertRuleDefinition.getSelectedRelatedAlertRules());
		
		if ("1".equals(alertRuleDefinition.getAlertRuleType()) || "Track".equals(alertRuleDefinition.getAlertRuleType()) ){
			alertRuleDefinition.setAlertRuleType("Track");
		}else{
			alertRuleDefinition.setAlertRuleType("Trend");
		}
		//Check whether it is insert or update  	
		try {
			connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
			connection.setAutoCommit(false);
			boolean success = false;
			// Marks the transaction
			
			if ("UPDATE".equals(alertRuleDefinitionForm.getActionType())){
				success = AlertRuleDefinitionUpdateService.getAlertRuleUpdateService().updateTrendAndTrackRule(connection, failureList, args, alertRuleDefinition, progressBar, (String)request.getSession().getAttribute("region"));
			}else {
				if (alertRuleDefinitionSaveService.checkDuplicateSave(connection, failureList, args, alertRuleDefinition)){
					alertRuleDefinitionForm.setCheckSave("1");
				}else {
					alertRuleDefinitionForm.setCheckSave("0");
					success = AlertRuleDefinitionSaveService.getAlertRuleDefinitionSaveService().insert(connection, failureList, args, alertRuleDefinition, progressBar, (String)request.getSession().getAttribute("region"));
				}
			}
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			// If update did not occur properly then failure list would not be empty; rollback the transaction
			if (!failureList.isEmpty()){
				try {
					connection.rollback();
				}catch(SQLException sx) {
				   logger.error(RABCMessages.getMessage("ERR_SQL_ROLLBACK_EXEC") + " Exception details: " + sx.getMessage());
				   failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_ROLLBACK_EXEC"), sx));
				} 
			} else {
				// No errors; commit the transaction
				try {
					connection.commit();
				}catch(SQLException sx) {
				   logger.error(RABCMessages.getMessage("ERR_SQL_COMMIT_EXEC") + " Exception details: " + sx.getMessage());
				   failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_COMMIT_EXEC"), sx));
				} 
			}
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		progressBar.setProgressPercent(100);
		
		/*
		 * Decide to which page you want to take the user to
		 */		
		if (!failureList.isEmpty()){
			request.setAttribute("failures", failureList);
			return mapping.findForward("error");
		}else{
			if ("1".equals(alertRuleDefinitionForm.getCheckSave())){
				if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
					forward = mapping.findForward("AlertRuleTrackingStep3");
				}else {
					forward = mapping.findForward("AlertRuleTrendingStep2");
				}
			}else if ("UPDATE".equals(alertRuleDefinitionForm.getActionType())){
				request.setAttribute("successMessage","Alert rule:" + alertRuleDefinition.getAlertRule() + " updated successfully");
				forward = mapping.findForward("AlertRuleSave");
			}else {
				request.setAttribute("successMessage","Alert rule:" + alertRuleDefinition.getAlertRule() + " created successfully");
				forward = mapping.findForward("AlertRuleSave");
			}
		}
		
		return forward;
	}
	
	/**
	 * Logic for Threshold action.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward threshold(ActionMapping mapping,ActionForm form,HttpServletRequest request,HttpServletResponse response){
		AlertRuleDefinitionForm  alertRuleDefinitionForm = (AlertRuleDefinitionForm) form;
		HttpSession session = request.getSession(false);
		ProgressBar progressBar = new ProgressBar(session);
		AlertRuleDefinition alertRuleDefinition = alertRuleDefinitionForm.getAlertRuleDefinition();
		if ("2".equals(alertRuleDefinition.getAlertRuleType()) || "Trend".equals(alertRuleDefinition.getAlertRuleType()) ){
			alertRuleDefinition = checkClearSupplementTypes(alertRuleDefinition);
		}
		if(alertRuleDefinitionForm.getRelatedAlertsFlag() == 0){
			alertRuleDefinition.setSelectedRelatedAlertRules(null);
		}
		ActionForward forward;
		ActionForward newForward = new ActionForward();
		Connection connection = null;
		List failureList = new ArrayList();
		List args = new ArrayList();
		args.add(session.getAttribute("bacUserID"));
		args.add(alertRuleDefinition.getAlertGroups());
		args.add(alertRuleDefinition.getSelectedRelatedAlertRules());
		
		alertRuleDefinitionForm.setSelectedAlertRule(alertRuleDefinition.getAlertRule());
		
		
		if ("1".equals(alertRuleDefinition.getAlertRuleType())|| "Track".equals(alertRuleDefinition.getAlertRuleType())){
			alertRuleDefinition.setAlertRuleType("Track");
		}else{
			alertRuleDefinition.setAlertRuleType("Trend");
		}
		progressBar.setProgressPercent(20);
		
		/*
		 * Check whether it is insert or update  	
		 */  
		try {
			connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
			connection.setAutoCommit(false);
			boolean success = false;
		
			// Marks the transaction
			if ("UPDATE".equals(alertRuleDefinitionForm.getActionType())){
				success = AlertRuleDefinitionUpdateService.getAlertRuleUpdateService().updateTrendAndTrackRule(connection, failureList, args, alertRuleDefinition, progressBar, (String)request.getSession().getAttribute("region"));
			} else {
				if (alertRuleDefinitionSaveService.checkDuplicateSave(connection, failureList, args, alertRuleDefinition)){
					alertRuleDefinitionForm.setCheckSave("1");
				} else {
					alertRuleDefinitionForm.setCheckSave("0");
					success = AlertRuleDefinitionSaveService.getAlertRuleDefinitionSaveService().insert(connection, failureList, args, alertRuleDefinition, progressBar, (String)request.getSession().getAttribute("region"));
				}
			}
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch (Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			// If update did not occur properly then failure list would not be empty; rollback the transaction
			if (!failureList.isEmpty()){
				try {
					connection.rollback();
				}catch(SQLException sx) {
				   logger.error(RABCMessages.getMessage("ERR_SQL_ROLLBACK_EXEC") + " Exception details: " + sx.getMessage());
				   failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_ROLLBACK_EXEC"), sx));
				} 
			}else {
				// No errors; commit the transaction
				try {
					connection.commit();
				}catch(SQLException sx) {
				   logger.error(RABCMessages.getMessage("ERR_SQL_COMMIT_EXEC") + " Exception details: " + sx.getMessage());
				   failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_COMMIT_EXEC"), sx));
				} 
			}
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		progressBar.setProgressPercent(100);
		
		/*
		 * Decide to which page you want to take the user to
		 */			
		if (!failureList.isEmpty()){
			request.setAttribute("failures", failureList);
			return mapping.findForward("error");
		}else{
			if ("1".equals(alertRuleDefinitionForm.getCheckSave())){
				if ("Track".equals(alertRuleDefinition.getAlertRuleType())){
					forward = mapping.findForward("AlertRuleTrackingStep3");
				}else {
					forward = mapping.findForward("AlertRuleTrendingStep2");
				}
			}else if ("UPDATE".equals(alertRuleDefinitionForm.getActionType())){
				request.setAttribute("successMessage","Alert rule:" + alertRuleDefinition.getAlertRule() + " updated successfully");
				forward = mapping.findForward("AlertRuleThreshold");
				//passes alertRuleName to threshold update page. The alert rule will be selected in the drop down.
				newForward.setName(forward.getName());
				String redirectPath="/AdminAlertThreshold.do?dispatch=unspecified&selectedAlertRule=" + alertRuleDefinition.getAlertRule();
				newForward.setPath(redirectPath);
				newForward.setRedirect(true);
			}else {
				request.setAttribute("successMessage","Alert rule:" + alertRuleDefinition.getAlertRule() + " created successfully");
				forward = mapping.findForward("AlertRuleThreshold");
				//passes alertRuleName to threshold update page. The alert rule will be selected in the drop down.
				newForward.setName(forward.getName());
				String redirectPath="/AdminAlertThreshold.do?dispatch=unspecified&selectedAlertRule=" + alertRuleDefinition.getAlertRule();
				newForward.setPath(redirectPath);
				newForward.setRedirect(true);
				
			}
		}
		if(newForward!=null){
			return newForward;
		}else{
		return forward;
		}
	}
	
    /**
     * This method is called when the user makes any changes to the views.
     * 
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return ActionForward
     */
    public ActionForward reloadTable(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        AlertRuleDefinitionForm  alertRuleDefinitionForm = (AlertRuleDefinitionForm) form;
        AlertRuleDefinition alertRuleDefinition = alertRuleDefinitionForm.getAlertRuleDefinition();
        Connection connection = null;
        HttpSession session = null;
        Tree tableTree;
        
        /*
         * Initialize lists of arguments as well as failures
         */
        List failureList = new ArrayList();
        List args = new ArrayList();
        session = request.getSession(true);
        try{
            connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
            AlertRuleTreeService treeService = new AlertRuleTreeService();
            tableTree = treeService.generateTree(connection,failureList,args,(String)request.getSession().getAttribute("region"));
            alertRuleDefinitionForm.setTableTree(tableTree);
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
        } catch(Exception e) {
        	logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}) + " Exception details: " + e.getMessage(), e);
        	failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
        } finally {
        	SQLHelper.closeConnection(connection, failureList, logger);
        }
        
        if (!failureList.isEmpty()){
        	request.setAttribute("failures", failureList);
            return mapping.findForward("error");
        } else {
            if ("Trend".equals(alertRuleDefinition.getAlertRuleType()) || "2".equals(alertRuleDefinition.getAlertRuleType())){
                return mapping.findForward("AlertRuleTrendingStep1");
            } else {
                return mapping.findForward("AlertRuleTrackingStep1");
            }
        }
    }
	
	/**
	 * Private method to reset values
	 * 
	 * @param alertRuleDefinitionForm
	 */
	private void reset(AlertRuleDefinitionForm alertRuleDefinitionForm){
		alertRuleDefinitionForm.setCheckFsq(null);
		alertRuleDefinitionForm.setCheckTiming(null);
	}
	
	/**
	 * Method added to clear the supplement types if they are not existent.
	 * 
	 * @param alertRuleDefinition
	 * @return AlertRuleDefinition
	 */
	private AlertRuleDefinition checkClearSupplementTypes(AlertRuleDefinition alertRuleDefinition){
	 	String clearSupplementTypeFlag = alertRuleDefinition.getClearSupplementaryItemFlag();
	 	int itemCount = 0;
	 	List newAlertItemList = new ArrayList();
	 	
	 	if (clearSupplementTypeFlag!=null){
	 		StringTokenizer suppTokenizer = new StringTokenizer(clearSupplementTypeFlag,";");
	 		
	 		while (suppTokenizer.hasMoreTokens()){
	 			String currFlag = suppTokenizer.nextToken();
	 			AlertItem alertItem = (AlertItem)alertRuleDefinition.getAlertItemList().get(itemCount);
	 			SupplementType currItemSuppType = alertItem.getSupplementType();
	 			
	 			if ("Y".equals(currFlag)){
	 				currItemSuppType.setSelectedSupplementType(new String[0]);
	 				alertItem.setSupplementType(currItemSuppType);
	 			}
	 			
	 			newAlertItemList.add(alertItem);
	 			itemCount++;
	 		}
	 		
	 		alertRuleDefinition.getAlertItemList().clear();
		 	int newAlertItemListSize = newAlertItemList.size();
		 	for (int i=0;i<newAlertItemListSize;i++){
		 		AlertItem alertItem = (AlertItem)newAlertItemList.get(i);
		 		alertRuleDefinition.addAlertItem(alertItem);
		 	}
	 	}
	 	return alertRuleDefinition;
	 }
}
