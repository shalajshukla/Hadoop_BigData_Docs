/*
 * Copyright  2002-2006 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.adhoc.aria;

import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.NamingException;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;

import com.att.bac.rabc.ConnectionManager;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.adhoc.AdhocConstants;
import com.att.bac.rabc.adhoc.aria.pivot.DatedCompositeKey;
import com.att.bac.rabc.adhoc.aria.pivot.PreviousDataLookup;
import com.att.bac.rabc.adhoc.rpt.AdhocRptDataTO;
import com.att.bac.rabc.defaults.DefaultsDAO;
import com.att.carat.util.JDBCUtil;
import com.sbc.bac.aria.ARIAColumn;
import com.sbc.bac.aria.ARIAHTMLPage13Processor;
import com.sbc.bac.aria.ARIAPaging;
import com.sbc.bac.aria.ARIAReport;
import com.sbc.bac.aria.ARIAReportException;
import com.sbc.bac.aria.RowElement;
import com.sbc.bac.aria.renderers.ARIAHTMLColumnRenderer;
import com.sbc.bac.aria.renderers.ARIAHTMLPagingRenderer;
import com.sbc.bac.aria.renderers.ARIAHTMLReportRenderer;
import com.sbc.bac.aria.renderers.ARIAHTMLRowRenderer;
import com.sbc.bac.aria.renderers.ARIAHeaderRenderer;


/**
 * Base class for creating ARIA layout reports for RABC
 * <p>
 * This class contains several methods from the AdhocRptDataFormatter class which has been deprecated.
 * 
 * <p>
 * <hr>
 * <h3>Release History</h3>
 * <p>
 * <ul>
 * 
 * <li>jb6494 Aug 1, 2006 Created class.
 * <li>jb6494 Mar 13, 2007 ML11 Previous data in excel report
 * <li>jb6494 Mar 13, 2007 ML18 Calculations on views
 * <li>jb6494 Mar 14, 2007 ML12 Corrected urlstring in graph
 * <li>jb6494 Mar 14, 2007 ML21 Trapped number format errors and replaced with "NaN"
 * <li>Jb6494 Mar 19, 2007 ML24 Moved formatWithLink to layout 1 (only use)
 * <li>jb6494 Mar 20, 2007 ML#09: Fix mouseover
 * <li>jb6494 Mar 21, 2007 Kin: wanted url changed for link
 * <li>jb6494 Mar 22, 2007 ML24 hacked timestamp if missing
 * <li>JB6494 Mar 23, 2007 Emergency fix.  Mouse over method was failing if null or empty string value passed to it.
 * 
 * </ul>
 * <p>
 * 
 */
public abstract class AbstractAdhocAriaLayout implements ARIAHeaderRenderer, ARIAHTMLColumnRenderer, ARIAHTMLPagingRenderer, ARIAHTMLReportRenderer, ARIAHTMLRowRenderer, AdhocConstants {
    public static Logger logger = Logger.getLogger(AbstractAdhocAriaLayout.class);

    private static HashMap weekdayOptions = null;
    private Connection connection;
    private AdhocRptDataTO dtoBase;
    private int section;
    protected AdhocRptDataTO dto;
    protected ActionForm form;
    protected OutputStream os;
    protected String userid;
    protected PreviousDataLookup prevData;

    /**
     * Constructor
     * 
     * @param form
     * @param os
     * @param userid
     */
    public AbstractAdhocAriaLayout(ActionForm form, OutputStream os, String userid) {
        super();
        this.form = form;
        this.os = os;
        this.userid = userid;
    }


    /**
     * Run the report with paging
     * 
     * @param reports
     * @param dto
     * @throws Exception
     */
    public abstract void execute(ARIAReportRABC[] reports, AdhocRptDataTO dto) throws Exception;


    /*
     * (non-Javadoc)
     * 
     * @see com.sbc.bac.aria.renderers.ARIAHTMLPagingRenderer#renderPaging(com.sbc.bac.aria.ARIAPaging)
     */
    public String renderPaging(ARIAPaging paging) {
    	return LayoutHelper.getPaging(paging);
    }

    /**
     * Get or create a connection. If the connection exists it will use it, otherwise it will create one.
     * 
     * @return
     * @throws SQLException
     * @throws NamingException
     */
    protected Connection getConnection() throws NamingException, SQLException {
    	if (connection == null) {
            connection = ConnectionManager.getConnection(dtoBase.getRegion());
            logger.info("ADHOC REPORTS: Creating connection");
        }
        
        return connection;
    }
    
    /**
     * Close the connection
     */
    protected void closeConnection() {
    	 JDBCUtil.closeConnection(connection);
 	     logger.info("ADHOC REPORTS: Closing connection");
    }


    /**
     * Create an Aria processor and assign renderers
     * 
     * @param os
     * @return
     */
    protected ARIAHTMLPage13Processor createProcessor(OutputStream os) {
        ARIAHTMLPage13Processor processor = new ARIAHTMLPage13Processor(os);
        processor.setReportRenderer(this);
        processor.setRowRenderer(this);
        processor.setColumnFormatter(this);
        processor.setHeaderRenderer(this);
        processor.setPagingRenderer(this);
        processor.setSubTotalLabel(TOTAL);
        processor.setGrandTotalLabel(GRAND_TOTAL);
        processor.setShowPaging(ARIAHTMLPage13Processor.PAGING_AT_TOP);
        return processor;
    }


    /**
     * Funny method to create headers. This info is used in the JSP.
     * <p>
     * Legacy
     * 
     * @throws RABCException
     */
    protected void createReportFilters() throws RABCException {
    	dtoBase = LayoutHelper.createReportFilters(dtoBase, weekdayOptions);
    }

    /**
     * Create a TD tag with the style provided. If the DTO unit indicator is N, P, or D then right align. The tag is
     * appended to the supplied StringBuffer.
     * 
     * @param style
     * @param colIndex
     * @param buf
     */
    protected void createTD(String style, int colIndex, StringBuffer buf) {
        buf = LayoutHelper.createTD(style, colIndex, buf, dto);
    }


    /**
     * format the presentation of the cell
     * 
     * @param columnName
     * @param value
     * @param escape
     * @param elementIndex
     * @param buf
     * @throws RABCException
     */
    protected void formatCellData(String columnName, String value, boolean escape, int elementIndex, StringBuffer buf) throws RABCException {
        buf = LayoutHelper.formatCellData(columnName, value, escape, elementIndex, buf, dto, logger, getSection());
    }


    /**
     * Icky date formatting.
     * 
     * @param inputDate
     * @return
     * @throws ParseException
     */
    protected String formatDateForDisplay(String inputDate) throws ParseException {
        return LayoutHelper.formatDateForDisplay(inputDate, dto);
    }


    /**
     * Determine the alignment based on the output pattern.
     * 
     * @param column
     * @return
     */
    protected String getAlignment(ARIAColumn column) {
        if (column.getOutputPattern() == null) {
            return "align='center'";
        }

        if (column.getOutputPattern().indexOf('#') != -1) {
            return "align='right'";
        }
        return "align='center'";
    }

    /**
     * Construct a composite key with date
     * 
     * @param column
     * @param processor
     * @return
     */
//    protected DatedCompositeKey getDatedKey(Map rowData) {
//       return LayoutHelper.getDatedKey(rowData, dto);
//    }
    protected DatedCompositeKey getDatedKey(List<RowElement> rowElement) {
        return LayoutHelper.getDatedKey(rowElement, dto);
     }

    /**
     * Get the base DTO. This is the real one that interacts with the jsp.
     * 
     * @return
     */
    protected AdhocRptDataTO getDtoBase() {
        return dtoBase;
    }


    /**
     * Create the graph href url
     * 
     * @param columnName
     * @param rowMap
     * @param tableIndex
     * @return
     * @throws ParseException
     * @throws UnsupportedEncodingException
     */
    protected String getGraphUrl(String columnName, List<RowElement> rowMap, int tableIndex) throws ParseException, UnsupportedEncodingException {
        return LayoutHelper.getGraphUrl(columnName, rowMap, tableIndex, dto);
    }

    /**
     * Gets the param key info for links.
     * <p>
     * Legacy
     * 
     * @param dto
     * @param arrayIndex
     * @param columnsAsOracleValueList
     * @return
     */
    protected String getKeyStructString(AdhocRptDataTO dto, List<RowElement> rowMap, int arrayIndex) {
       return LayoutHelper.getKeyStructString(dto, rowMap, arrayIndex);
    }


    /**
     * Inappropriately located method to get mouse over description. This should really be in the DAO.
     * 
     * @param tableIndex
     * @param mouseKey
     * @param value TODO
     * @return
     * @throws RABCException
     */
    protected String getMouseOverDescription(int tableIndex, String mouseKey, String value) {
        return LayoutHelper.getMouseOverDescription(tableIndex, mouseKey, value, dto, dtoBase, connection, logger);
    }


    /**
     * Get the report count.
     * <p>
     * Should not be in this class.
     * 
     * @param report
     * @return
     * @throws ARIAReportException
     */
    protected int getReportCount(ARIAReport report, boolean excludeSubTotals) throws ARIAReportException {

        String originalSQL = report.toSQL();
        boolean hasRollup = (originalSQL.indexOf(TOTAL) != -1) || (originalSQL.indexOf(GRAND_TOTAL) != -1);

        String name = "\"" + ((ARIAColumn) report.getColumns().get(0)).getName() + "\"";

        StringBuffer sql = new StringBuffer(100);
        sql.append("SELECT COUNT(");
        sql.append(name);
        sql.append(") FROM (");
        sql.append(originalSQL);
        sql.append(")");
        if (hasRollup & excludeSubTotals) {
            sql.append(" WHERE (");
            sql.append(name);
            sql.append("<> '");
            sql.append(TOTAL);
            sql.append("') and (");
            sql.append(name);
            sql.append("<> '");
            sql.append(GRAND_TOTAL);
            sql.append("')");
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            logger.debug(sql);
            ps = getConnection().prepareStatement(sql.toString());
            rs = ps.executeQuery();
            rs.next();
            return rs.getInt(1);
        } catch (Exception e) {
            logger.error("GetReportCount", e);
            return 0;
        } finally {
            JDBCUtil.closeResultSet(rs);
            JDBCUtil.closePreparedStatement(ps);
        }
    }


    /**
     * Determine the rows per page. If not found, defaults to 25.
     * 
     * @return
     * @throws RABCException
     * @throws SQLException
     * @throws NamingException
     */
    protected int getRowsPerPage() throws RABCException, NamingException, SQLException {
        try {
            return Integer.parseInt(DefaultsDAO.getLineCountChoice(getConnection(), userid));
        } catch (NumberFormatException e) {
            return 25;
        }
    }


    /**
     * Get the current section number
     * 
     * @return
     */
    protected int getSection() {
        return section;
    }


    /**
     * Get the link url.
     * 
     * @param columnName
     * @param rowMap
     * @param tableIndex
     * @param value
     * @return
     * @throws ParseException
     * @throws RABCException
     * @throws SQLException
     * @throws UnsupportedEncodingException
     */
    protected String getUrl(String columnName, List<RowElement> rowMap, int tableIndex, String value) throws NamingException,ParseException, RABCException, SQLException, UnsupportedEncodingException {
        return LayoutHelper.getUrl(columnName, rowMap, tableIndex, value, dto, dtoBase, getConnection(), logger);
    }


    /**
     * determine if the column is a date
     * 
     * @param columnName
     * @return
     */
    protected boolean isDateHeader(String columnName) {
        return LayoutHelper.isDateHeader(columnName);
    }


    /**
     * Test the character indicator to see if it contains the value specified. If the indicator is null it will return
     * false.
     * <p>
     * example: isIndicatorIn(myInd, "YN") = true if the indicator is either 'Y' or 'N'
     * 
     * @param ind
     * @param test
     * @return
     */
    protected boolean isIndicatorIn(String ind, String test) {
        return LayoutHelper.isIndicatorIn(ind, test);
    }


    /**
     * Expand possible date conversions
     * 
     * @param dateString
     * @return
     */
    protected Date parseDate(String dateString) {
        return LayoutHelper.parseDate(dateString);
    }


    /**
     * Search the row map for a value. This is case insensitive.
     * 
     * @param rowMap
     * @param key
     * @return
     */
    protected Object searchRowMap(Map rowMap, String key) {
        return LayoutHelper.searchRowMap(rowMap, key);
    }


    /**
     * Set the DTO object
     * 
     * @param dto
     */
    protected void setDto(AdhocRptDataTO dto) {
        this.dto = dto;
    }


    /**
     * Set the base DTO.This is the real one that interacts with the jsp.
     * 
     * @param dto
     */
    protected void setDtoBase(AdhocRptDataTO dto) {
        dtoBase = dto;
        if (dto == null) {
            dto = dtoBase;
        }
    }


    /**
     * Set the current section number
     * 
     * @param section
     */
    protected void setSection(int section) {
        this.section = section;
    }


    /**
     * Append the proper parameters to graph links.
     * 
     * @param dto
     * @param displayDate
     * @param graphAlertTimeValue
     * @param url
     */
    void appendAlertTimeToGraphURL(AdhocRptDataTO dto, List<RowElement> rowMap, String displayDate, int graphAlertTimeValue, StringBuffer url) {
        url = LayoutHelper.appendAlertTimeToGraphURL(dto, rowMap, displayDate, graphAlertTimeValue, url);
    }


    /**
     * If previous data exists, setup the table for it.
     * 
     * @param report
     * @throws ARIAReportException
     * @throws NamingException
     * @throws SQLException
     * @throws ARIAReportException
     * @throws NamingException
     * @throws SQLException
     * @throws RABCException
     */
    protected void setupPreviousDataTable(int section) throws SQLException, NamingException, ARIAReportException, RABCException {
    	prevData = LayoutHelper.setupPreviousDataTable(section, dto, dtoBase, prevData, getConnection(), logger);
    }
    
    /**
     * 
     * @param header
     * @param index
     * @return
     */
    public String getColumnHeader(String header, int index) {
        return LayoutHelper.getColumnHeader(header, index, dto);
    }
    
    /**
	 * This method returns the string for urlEncodedFormat.
	 * 
	 * @param s
	 * @return String
	 */
	public String urlEncodedFormat(String s) {
		if (s == null) return null;
		try {
			return URLEncoder.encode(s, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			return null;
		}
	}
}