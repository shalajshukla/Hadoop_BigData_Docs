/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.adhoc.rpt.generator;

import org.apache.log4j.Logger;

import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.adhoc.aria.ARIAReportRABC;
import com.att.bac.rabc.adhoc.aria.ARIASimpleColumnRABC;
import com.att.bac.rabc.adhoc.rpt.AdhocRptDAO;
import com.att.bac.rabc.adhoc.rpt.AdhocRptDataTO;
import com.sbc.bac.aria.ARIADataPoint;
import com.sbc.bac.aria.ARIAFunction;
import com.sbc.bac.aria.ARIASort;
import com.sbc.bac.aria.ARIASource;


/**
 * Generate an ARIA Report. Based off of AdhocRptQueryGenerator (deprecated now).
 * 
 * <p>
 * <hr>
 * <h3>Release History</h3>
 * <p>
 * <ul>
 * 
 * <li>jb6494 Aug 01, 2006 Created class.
 * <li>jb6494 Oct 16, 2006 Added sorting to outer query.
 * 
 * </ul>
 * <p>
 * 
 */
public class AdhocRptQueryGeneratorLayout1 extends AbstractAdhocGenerator {
    static final Logger logger = Logger.getLogger(AdhocRptQueryGeneratorLayout1.class);


    /**
     * Create the query for the report
     * 
     * @param dto
     * @param sectionIndex
     * @return
     * @throws RABCException
     */
    public ARIAReportRABC generateQuery(AdhocRptDataTO dto, int sectionIndex) throws RABCException {
        getLegacy().setViewNameUniqList(dto);
        getLegacy().setColumnsTabAsOracle(dto);

        // Create the aria report. false because we aren't teradata
        report = new ARIAReportRABC();

        int size = getLegacy().viewNameUniqList.size();
        for (int i = 0; i < size; i++) {
            getLegacy().initSqlArrays();
            getLegacy().getTblFromView(dto, i);
            getLegacy().setVariables(dto);
            if (isNotNullEQ(dto.getPresnTrendTime(), BILL_ROUND)) {
                getLegacy().initBillRound1(dto);
            } else if (isNotNullEQ(dto.getNoProcDate(), NO)) {
                getLegacy().initNotBillRound(dto);
            } else if (isNotNullEQ(dto.getNoProcDate(), YES)) {
                getLegacy().initBillRound2(dto);
            }
            getLegacy().initKeyColumns(dto, sectionIndex);
            getLegacy().updateSelectArray1(dto, i);
            getLegacy().updateModArrays1(i);
            getLegacy().updateModArrays2(dto, sectionIndex, i);
            getLegacy().updateSelectArray2(dto, sectionIndex, i);
            getLegacy().updateSelectArray3(i);
            getLegacy().updateWhereArray(dto, sectionIndex, i);
            buildAriaSource(dto);
        }

        getLegacy().updateMainSelectClause(dto, sectionIndex);
        if (size > 1) {
            getLegacy().updateOtherConditions(dto);
        }
        getLegacy().updateOrderByClause(dto, size);

        addARIAColumns(dto, sectionIndex);
        addARIAOrderBy(dto, sectionIndex);
        addJoins(report, getKeyCount(dto));

        debugARIAReport();

        return report;
    }


    /**
     * @param dto
     * @param loopCount
     */
    protected void addARIAOrderBy(AdhocRptDataTO dto, int loopCount) {
    	if (dto.getMonthSelect()== 0 && dto.getYearSelect()==0){
    		addUserSort(dto);
    	}
 
        for (int i = 0; i < getLegacy().orderByClauseList.size(); i++) {
            String element = (String) getLegacy().orderByClauseList.get(i);
            String sortString = "";
            ARIASort sort = ARIASort.ASC;

            int space = element.trim().indexOf(' ');
            if (space != -1) {
                sortString = element.substring(space).trim();
                element = element.substring(0, space);
            }

            if (sortString.equalsIgnoreCase("ASC")) {
                sort = ARIASort.ASC;
            }

            if (sortString.equalsIgnoreCase("DESC")) {
                sort = ARIASort.DESC;
            }

            ARIADataPoint dp = getDP(dto, i, element);
            if ((dp != null) && (sort != null)) {
                dp.getSource().addSort(dp, sort);

                // if we aren't doing a subtotal then try to sort. If we are, we must rely on the
                // rollup/decode results to order the data.
                if (!dto.hasSubTotaling() && dto.getMonthSelect()== 0 && dto.getYearSelect()==0) {
                    report.addSort(dp, sort);
                }
            }

        }
    }


    /**
     * @param dto
     * @param loopCount
     * @throws RABCException
     */
    protected void addARIAColumns(AdhocRptDataTO dto, int loopCount) throws RABCException {

        if (dto.hasSubTotaling()) {
            report.addColumn(createSubTotalColumn(dto, loopCount));
        } else if (dto.getMonthSelect()!= 0 || dto.getYearSelect()!=0) {
        	report.addColumn(createSubTotalColumn(dto, loopCount));
        } else {
            report.addColumn(new ARIASimpleColumnRABC(getDP(dto, 0, "PROC_DATE"), "File Date", null, "MM/dd/yyyy", -2));
        }

        if (dto.getFileSeqNumInd().equalsIgnoreCase(YES)) {
            report.addColumn(new ARIASimpleColumnRABC(getDP(dto, 0, "file_seq_num"), "Sequence Number", null, -1));
        }

        if (dto.hasSubTotaling() || (dto.getMonthSelect()!=0 || dto.getYearSelect()!=0)) {
            getDP(dto, 0, "PROC_DATE").setSubTotalOrder(1);
            if (dto.getFileSeqNumInd().equalsIgnoreCase(YES)) {
                getDP(dto, 0, "file_seq_num").setSubTotalOrder(2);
            }
        }

        for (int i = 0; i < dto.getColumnsAsOracleList().size(); i++) {
            String element = (String) dto.getColumnsAsOracleList().get(i);
            element = element.trim();
            //if (!dto.getPresnSuppressIndList().get(i).toString().equalsIgnoreCase(YES)) {
                String outputPattern = null;
                if (dto.getPresnFormatList().get(i).toString().equalsIgnoreCase("D")) {
                    outputPattern = "MM/DD/YYYY";
                }
                
                ARIADataPoint dp = null;
                
                if (!EMPTY_STRING.equals(dto.getPresnCalcNumList().get(i).toString())) {
                    int calcNum = Integer.parseInt(dto.getPresnCalcNumList().get(i).toString());
                    Calculation calc = new AdhocRptDAO().getCalcElem(dto, calcNum, loopCount);
                    element = calc.getPresnCalcName();
                    // dp = getDP(dto, i, calc.getPresnCalcName());
                    // report.addColumn(createCalculationColumn(dto, calcNum, loopCount, i,calc, dp));
                } 

                dp = getDP(dto, i, element);
                report.addColumn(new ARIASimpleColumnRABC(dp, getColumnHeader(dto, i), null, outputPattern, i));

                if (dto.getMonthSelect()==0 && dto.getYearSelect()==0){
                	setDataPointSubTotal(dto, dp, i);
                } else {
                	if (!"-1".equals((String)dto.getPartiRefIdList().get(i)) && !EMPTY_STRING.equals((String)dto.getPartiRefIdList().get(i)) && "ALERT DATA".equalsIgnoreCase(getColumnHeader(dto, i))) {
                		dp.setSubTotalOrder(0);
                	} else {
                		dp.setSubTotalOrder(i+2);
                	}
                }
            //}
        }

    }


    /**
     * @param dto
     * @param index
     */
    protected void buildAriaSource(AdhocRptDataTO dto) {
        ARIASource source = createAriaSource(dto);

        for (int i = 0; i < getLegacy().selectClauseList.size(); i++) {
            String element = (String) getLegacy().selectClauseList.get(i);
            int lastSpace = element.lastIndexOf(' ');
            
            String givenName = null;
            if (lastSpace!=-1 && element.substring(lastSpace, element.length()).indexOf("CALC")!=-1) {
                givenName = element.substring(0,lastSpace).trim();
                int lastTilda = element.lastIndexOf('~');
                String calcFormula = element.substring(lastTilda + 1, element.length());
                //M148 : Calculation Fix: If calculation Formula contains / then put avg else put sum
                if(calcFormula.indexOf('/') != -1){
                	element = "*AVG " + calcFormula + " ";
                }else{
                	element = "*SUM " + calcFormula + " ";
                }
                lastSpace = element.lastIndexOf(' ');
            } else {
            	givenName = dot(getLegacy().viewTbl, element.substring(lastSpace + 1));
            }
            
            element = element.substring(0, lastSpace).trim();

            // if there is an embedded function it needs to be deciphered.
            // AVG MAX MIN COUNT SUM are translated to ARIAFunctions
            // trunc to_char ?
            ARIAFunction function = null;
            if (element.startsWith("*")) {
                if (element.toUpperCase().startsWith("*SUM")) {
                    element = element.substring(5);
                    function = ARIAFunction.inlinePlus(ARIAFunction.SUM);
                }
                if (element.toUpperCase().startsWith("*AVG")) {
                    element = element.substring(5);
                    function = ARIAFunction.inlinePlus(ARIAFunction.AVG);
                }
                if (element.toUpperCase().startsWith("*MIN")) {
                    element = element.substring(5, element.length() - 2);
                    function = ARIAFunction.inlinePlus(ARIAFunction.MIN);
                }
            }

            ARIADataPoint dp = source.createData(element, function);
            addDataPointReference(givenName, dp);
        }
    }
}
