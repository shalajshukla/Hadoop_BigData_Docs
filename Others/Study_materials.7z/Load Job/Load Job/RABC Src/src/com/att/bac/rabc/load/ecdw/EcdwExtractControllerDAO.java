/*------------------------------------------------------------------------------
Modification History
� 2002-2011 AT&T Intellectual Property. All rights reserved.
Date		Version		Author			Description
----------	-----------	--------------- ----------------------------------------
12-02-2010	0.1			ss1644			initial Draft
------------------------------------------------------------------------------*/
package com.att.bac.rabc.load.ecdw;
//------------------------------------------------------------------------------
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Properties;

import com.att.carat.util.JDBCUtil;
//------------------------------------------------------------------------------
/**
 * This class is used for Extracting the data from ECDW and create Text files for
 * following Measurement IDs 
 * <ul>
 * <li>20610</li>
 * <li>20615</li>
 * <li>20620</li>
 * <li>20625</li>
 * </ul>
 * @author ss1644
 * @version 0.01
 * @see EcdwExtractControllerLoadJob
 */
public class EcdwExtractControllerDAO implements EcdwExtractControllerSql {
	/**
	 * Variable to hold the value of destination directory where the file is
	 * to be created 
	 */
	private String fileTransferPath;
	/**
	 * Constructor to instantiate the class
	 * @param p_configuration configuration properties
	 */
	EcdwExtractControllerDAO (Properties p_configuration ) {
		fileTransferPath = 	p_configuration.getProperty (
								"file_transfer_location"
							);
	}
	//--------------------------------------------------------------------------
	/**
	 * This method extract the data from ECDW and create Text file for MID
	 * 20610
	 * @param	p_connection		teradata connection
	 * @return true if the extraction is successful and file created successfully
	 * else false
	 * @throws 	EcdwExtractControllerException in case some exception occurs 
	 * during operation
	 */
	protected boolean extractMD20610Data (Connection p_connection)
	throws EcdwExtractControllerException {
		
		 PreparedStatement 		l_pstmt 				= null;
		 ResultSet 				l_rs 					= null;
		 BufferedWriter 		l_buffer_writer 		= null;
		 SimpleDateFormat 		l_date_format 			= null;
		 Calendar 				l_current_date 			= null;
		 String 				l_date 					= null;
		 String					l_file_name				= null;
		 
		try {
			l_date_format 			= 	new SimpleDateFormat("yyyy-MM-dd");
			l_current_date 			= 	Calendar.getInstance ();
			l_date 					= 	l_date_format.format (l_current_date.getTime());
				
			l_pstmt = p_connection.prepareStatement (GET_MD20610_DATA);
			l_rs = l_pstmt.executeQuery();
			l_file_name		= fileTransferPath + "MD20610_" + l_date + ".txt";
			l_buffer_writer 	= 	new BufferedWriter (
									new FileWriter(l_file_name)
								);
			while (l_rs.next()) {
				l_buffer_writer.write (
					NullValueSubstitution(l_rs.getString(1)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(2)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(3)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(4)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(5)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(6)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(7)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(8)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(9)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(10)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(11)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(12)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(13)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(14)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(15)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(16)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(17)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(18)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(19)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(20)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(21)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(22)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(23)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(24)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(25)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(26)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(27)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(28)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(29)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(30)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(31)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(32)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(33)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(34)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(35)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(36)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(37)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(38)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(39)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(40)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(41)) + ","
				);
				l_buffer_writer.newLine();

			}
			l_pstmt = p_connection.prepareStatement (GET_MD20610_CONTROL);
			l_rs = l_pstmt.executeQuery();
			
			if (l_rs.next()) {
				l_buffer_writer.write (
					NullValueSubstitution(l_rs.getString(1)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(2)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(3)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(4)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(5)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(6)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(7)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(8)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(9)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(10)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(11)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(12)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(13)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(14)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(15)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(16)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(17)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(18)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(19)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(20)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(21)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(22)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(23)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(24)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(25)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(26)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(27)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(28)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(29)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(30)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(31)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(32)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(33)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(34)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(35)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(36)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(37)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(38)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(39)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(40)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(41)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(42)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(43)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(44))
				);
			}
			
		} catch (SQLException sqe) {
			throw new EcdwExtractControllerException (
				"Exception occurred in Executing query", sqe
			);
		} catch (FileNotFoundException ex) {
			 throw new EcdwExtractControllerException (
				"File not found Exception occurred" ,ex
			);
        } catch (IOException ex) {
        	throw new EcdwExtractControllerException (
        		"IO Exception occurred" ,ex
        	);
        } catch(Exception e){
        	throw new EcdwExtractControllerException (
        		"General exception occurred" ,e
        	);
		} finally {
			JDBCUtil.closeResultSet(l_rs);
			JDBCUtil.closePreparedStatement(l_pstmt);
			try {
                if (l_buffer_writer != null) {
                    l_buffer_writer.flush();
                    l_buffer_writer.close();
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
		}
		return true;
		
	}
	//--------------------------------------------------------------------------
	/**
	 * This method extract the data from ECDW and create Text file for MID
	 * 20615
	 * @param	connection		teradata connection
	 * @return true if the extraction is successful and file created successfully
	 * else false
	 * @throws 	EcdwExtractControllerException in case some exception occurs 
	 * during operation
	 */
	protected boolean extractMD20615Data (Connection connection)
	throws EcdwExtractControllerException {
		 PreparedStatement 		l_pstmt 				= null;
		 ResultSet 				l_rs 					= null;
		 BufferedWriter 		l_buffer_writer 		= null;
		 SimpleDateFormat 		l_date_format 			= null;
		 Calendar 				l_current_date 			= null;
		 String 				l_date 					= null;
		 String					l_file_name				= null;
		 
		try {
			l_date_format 			= 	new SimpleDateFormat("yyyy-MM-dd");
			l_current_date 			= 	Calendar.getInstance ();
			l_date 					= 	l_date_format.format (l_current_date.getTime());
			
			l_pstmt = connection.prepareStatement (GET_MD20615_DATA);
			l_rs = l_pstmt.executeQuery();
			l_file_name		=	fileTransferPath + "MD20615_" + l_date + ".txt";
			l_buffer_writer 	= 	new BufferedWriter (
									new FileWriter(l_file_name)
								);
			while (l_rs.next()) {
				l_buffer_writer.write (
					NullValueSubstitution(l_rs.getString(1)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(2)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(3)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(4)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(5)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(6)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(7)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(8)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(9)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(10)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(11)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(12)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(13)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(14)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(15)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(16)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(17)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(18)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(19)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(20)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(21)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(22)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(23)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(24)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(25)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(26)) + ","
				);
				l_buffer_writer.newLine();

			}
			l_pstmt = connection.prepareStatement (GET_MD20615_CONTROL);
			l_rs = l_pstmt.executeQuery();
			
			if (l_rs.next()) {
				l_buffer_writer.write (
					NullValueSubstitution(l_rs.getString(1)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(2)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(3)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(4)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(5)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(6)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(7)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(8)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(9)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(10)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(11)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(12)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(13)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(14)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(15)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(16)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(17)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(18)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(19)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(20)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(21)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(22)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(23)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(24)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(25)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(26)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(27)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(28)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(29))
				);

			}
		} catch (SQLException sqe) {
			throw new EcdwExtractControllerException (
				"Exception occurred in Executing query", sqe
			);
		} catch (FileNotFoundException ex) {
			 throw new EcdwExtractControllerException (
				"File not found Exception occurred" ,ex
			);
        } catch (IOException ex) {
        	throw new EcdwExtractControllerException (
        		"IO Exception occurred" ,ex
        	);
        } catch(Exception e){
        	throw new EcdwExtractControllerException (
        		"General exception occurred" ,e
        	);
		} finally {
			JDBCUtil.closeResultSet(l_rs);
			JDBCUtil.closePreparedStatement(l_pstmt);
			try {
                if (l_buffer_writer != null) {
                    l_buffer_writer.flush();
                    l_buffer_writer.close();
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
		}
		return true;
		
	}
	//--------------------------------------------------------------------------
	/**
	 * This method extract the data from ECDW and create Text file for MID
	 * 20620
	 * @param	p_connection		teradata connection
	 * @return true if the extraction is successful and file created successfully
	 * else false
	 * @throws 	EcdwExtractControllerException in case some exception occurs 
	 * during operation
	 */
	protected boolean extractMD20620Data (Connection p_connection) 
	throws EcdwExtractControllerException {
		 PreparedStatement 		l_pstmt 				= null;
		 ResultSet 				l_rs 					= null;
		 BufferedWriter 		l_buffer_writer 		= null;
		 SimpleDateFormat 		l_date_format 			= null;
		 Calendar 				l_current_date 			= null;
		 String 				l_date 					= null;
		 String					l_file_name				= null;
		 
		try {
			l_date_format 			= 	new SimpleDateFormat("yyyy-MM-dd");
			l_current_date 			= 	Calendar.getInstance ();
			l_date 					= 	l_date_format.format (l_current_date.getTime());
			
			l_pstmt = p_connection.prepareStatement (GET_MD20620_DATA);
			l_rs = l_pstmt.executeQuery();
			l_file_name = fileTransferPath + "MD20620_" + l_date + ".txt";
			l_buffer_writer = 	new BufferedWriter (
									new FileWriter (l_file_name)
								);
			while (l_rs.next ()) {
				l_buffer_writer.write (
					NullValueSubstitution(l_rs.getString(1)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(2)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(3)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(4)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(5)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(6)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(7)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(8)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(9)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(10)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(11)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(12)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(13)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(14)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(15)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(16)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(17)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(18)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(19)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(20)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(21)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(22)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(23)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(24)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(25)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(26)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(27)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(28)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(29)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(30)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(31)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(32)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(33)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(34)) + ","
				);

				l_buffer_writer.newLine();

			}
			l_pstmt = p_connection.prepareStatement (GET_MD20620_CONTROL);
			l_rs = l_pstmt.executeQuery();

			if (l_rs.next ()) {
				l_buffer_writer.write (
					NullValueSubstitution(l_rs.getString(1)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(2)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(3)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(4)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(5)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(6)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(7)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(8)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(9)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(10)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(11)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(12)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(13)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(14)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(15)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(16)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(17)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(18)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(19)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(20)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(21)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(22)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(23)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(24)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(25)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(26)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(27)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(28)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(29)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(30)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(31)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(32)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(33)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(34)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(35)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(36)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(37))
				);
				
			}
		} catch (SQLException sqe) {
			throw new EcdwExtractControllerException (
				"Exception occurred in Executing query", sqe
			);
		} catch (FileNotFoundException ex) {
			 throw new EcdwExtractControllerException (
				"File not found Exception occurred" ,ex
			);
        } catch (IOException ex) {
        	throw new EcdwExtractControllerException (
        		"IO Exception occurred" ,ex
        	);
        } catch(Exception e){
        	throw new EcdwExtractControllerException (
        		"General exception occurred" ,e
        	);
		} finally {
			JDBCUtil.closeResultSet(l_rs);
			JDBCUtil.closePreparedStatement(l_pstmt);
			try {
                if (l_buffer_writer != null) {
                    l_buffer_writer.flush();
                    l_buffer_writer.close();
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
		}
		return true;
	}
	//--------------------------------------------------------------------------
	/**
	 * This method extract the data from ECDW and create Text file for MID
	 * 20625
	 * @param	connection		teradata connection
	 * @return true if the extraction is successful and file created successfully
	 * else false
	 * @throws 	EcdwExtractControllerException in case some exception occurs 
	 * during operation
	 */
	protected boolean extractMD20625Data (Connection connection)
	throws EcdwExtractControllerException {
		 PreparedStatement 		l_pstmt 				= null;
		 ResultSet 				l_rs 					= null;
		 BufferedWriter 		l_buffer_writer 		= null;
		 SimpleDateFormat 		l_date_format 			= null;
		 Calendar 				l_current_date 			= null;
		 String 				l_date 					= null;
		 String					l_file_name				= null;
		 
		try {
			l_date_format 			= 	new SimpleDateFormat("yyyy-MM-dd");
			l_current_date 			= 	Calendar.getInstance ();
			l_date 					= 	l_date_format.format (l_current_date.getTime());
			
			l_pstmt = connection.prepareStatement (GET_MD20625_DATA);
			l_rs = l_pstmt.executeQuery();
			l_file_name		=	fileTransferPath + "MD20625_" + l_date + ".txt";
			l_buffer_writer 	= 	new BufferedWriter (
									new FileWriter(l_file_name)
								);
			while (l_rs.next()) {
				l_buffer_writer.write (
					NullValueSubstitution(l_rs.getString(1)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(2)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(3)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(4)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(5)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(6)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(7)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(8)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(9)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(10)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(11)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(12)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(13)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(14)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(15)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(16)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(17)) + ","
				);
	
				l_buffer_writer.newLine();

			}
			l_pstmt = connection.prepareStatement (GET_MD20625_CONTROL);
			l_rs = l_pstmt.executeQuery();
	
			if (l_rs.next()) {
				l_buffer_writer.write (
					NullValueSubstitution(l_rs.getString(1)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(2)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(3)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(4)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(5)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(6)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(7)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(8)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(9)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(10)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(11)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(12)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(13)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(14)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(15)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(16)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(17)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(18)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(19)) + ","
				);
				l_buffer_writer.write(
					NullValueSubstitution(l_rs.getString(20))
				);
	
			}
		} catch (SQLException sqe) {
			throw new EcdwExtractControllerException (
				"Exception occurred in Executing query", sqe
			);
		} catch (FileNotFoundException ex) {
			 throw new EcdwExtractControllerException (
				"File not found Exception occurred" ,ex
			);
        } catch (IOException ex) {
        	throw new EcdwExtractControllerException (
        		"IO Exception occurred" ,ex
        	);
        } catch(Exception e){
        	throw new EcdwExtractControllerException (
        		"General exception occurred" ,e
        	);
		} finally {
			JDBCUtil.closeResultSet(l_rs);
			JDBCUtil.closePreparedStatement(l_pstmt);
			try {
                if (l_buffer_writer != null) {
                    l_buffer_writer.flush();
                    l_buffer_writer.close();
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
		}
		return true;
		
	}
	//--------------------------------------------------------------------------
	/**
	 * Method to replace null value to space
	 * @param	p_value value to be checked
	 * @return the new value
	 */
	protected static String NullValueSubstitution (String p_value) {
		return p_value == null ? "" : p_value;
	}
	//--------------------------------------------------------------------------
}
//------------------------------------------------------------------------------
//
//	End of file
//
//------------------------------------------------------------------------------