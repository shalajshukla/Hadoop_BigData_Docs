package com.att.bac.rabc.load.rbs;

import java.sql.Date;
import java.util.HashMap;

public class MWrbsSumyData {
	
	private double ZERO=0.0;
	private HashMap billAMtByCategory = new HashMap();
	private Date billDate;
	private String stateId;
	private int processGroup;
	private double balanceDueAmt;
	private double prevBillingAmt;
	private double currChargeAmt;
	private double paymentAmt;
	private double adjAmt;
	private double latePaymentAmt;
	private double discountAmt;
	
	

	

	public double getBilled_amt(int occCategory) {
		if (billAMtByCategory.get(new Integer(occCategory)) != null)
			return ((Double)billAMtByCategory.get(new Integer(occCategory))).doubleValue();
		else 
			return ZERO; 
	}

	public void setBilled_amt(int occCategory, double billed_amt) {
		billAMtByCategory.put(new Integer(occCategory), new Double (billed_amt));
	}

	/**
	 * @return Returns the adjAmt.
	 */
	public double getAdjAmt() {
		return adjAmt;
	}

	/**
	 * @param adjAmt The adjAmt to set.
	 */
	public void setAdjAmt(double adjAmt) {
		this.adjAmt = adjAmt;
	}

	/**
	 * @return Returns the balanceDueAmt.
	 */
	public double getBalanceDueAmt() {
		return balanceDueAmt;
	}

	/**
	 * @param balanceDueAmt The balanceDueAmt to set.
	 */
	public void setBalanceDueAmt(double balanceDueAmt) {
		this.balanceDueAmt = balanceDueAmt;
	}

	/**
	 * @return Returns the billDate.
	 */
	public Date getBillDate() {
		return billDate;
	}

	/**
	 * @param billDate The billDate to set.
	 */
	public void setBillDate(Date billDate) {
		this.billDate = billDate;
	}

	/**
	 * @return Returns the currChargeAmt.
	 */
	public double getCurrChargeAmt() {
		return currChargeAmt;
	}

	/**
	 * @param currChargeAmt The currChargeAmt to set.
	 */
	public void setCurrChargeAmt(double currChargeAmt) {
		this.currChargeAmt = currChargeAmt;
	}

	/**
	 * @return Returns the discountAmt.
	 */
	public double getDiscountAmt() {
		return discountAmt;
	}

	/**
	 * @param discountAmt The discountAmt to set.
	 */
	public void setDiscountAmt(double discountAmt) {
		this.discountAmt = discountAmt;
	}

	/**
	 * @return Returns the latePaymentAmt.
	 */
	public double getLatePaymentAmt() {
		return latePaymentAmt;
	}

	/**
	 * @param latePaymentAmt The latePaymentAmt to set.
	 */
	public void setLatePaymentAmt(double latePaymentAmt) {
		this.latePaymentAmt = latePaymentAmt;
	}

	/**
	 * @return Returns the paymentAmt.
	 */
	public double getPaymentAmt() {
		return paymentAmt;
	}

	/**
	 * @param paymentAmt The paymentAmt to set.
	 */
	public void setPaymentAmt(double paymentAmt) {
		this.paymentAmt = paymentAmt;
	}

	/**
	 * @return Returns the prevBillingAmt.
	 */
	public double getPrevBillingAmt() {
		return prevBillingAmt;
	}

	/**
	 * @param prevBillingAmt The prevBillingAmt to set.
	 */
	public void setPrevBillingAmt(double prevBillingAmt) {
		this.prevBillingAmt = prevBillingAmt;
	}

	/**
	 * @return Returns the stateId.
	 */
	public String getStateId() {
		return stateId;
	}

	/**
	 * @param stateId The stateId to set.
	 */
	public void setStateId(String stateId) {
		this.stateId = stateId;
	}

	/**
	 * @return Returns the processGroup.
	 */
	public int getProcessGroup() {
		return processGroup;
	}

	/**
	 * @param processGroup The processGroup to set.
	 */
	public void setProcessGroup(int processGroup) {
		this.processGroup = processGroup;
	}
	

}
