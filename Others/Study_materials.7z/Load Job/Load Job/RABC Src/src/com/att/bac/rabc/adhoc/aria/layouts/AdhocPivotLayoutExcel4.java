package com.att.bac.rabc.adhoc.aria.layouts;

import java.io.OutputStream;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;

import com.att.bac.rabc.PickList;
import com.att.bac.rabc.StaticDataLoader;
import com.att.bac.rabc.adhoc.aria.LayoutHelper;
import com.att.bac.rabc.adhoc.aria.pivot.Page13PivotHTMLProcessor;
import com.sbc.bac.aria.ARIAReportProcessor;
import com.sbc.bac.aria.ARIAUtil;

public class AdhocPivotLayoutExcel4 extends AdhocPivotLayout4 {
	 public static Logger logger = Logger.getLogger(AdhocPivotLayoutExcel2.class);
	 private static final String CLASS_NAME = AdhocPivotLayoutExcel2.class.getName();
	    
	/**
	 * Default constructor
	 * @param form
	 * @param os
	 * @param userid
	 */
	public AdhocPivotLayoutExcel4(ActionForm form, OutputStream os, String userid) {
		super(form, os, userid);
	}
	
	/**
	 * Method to begin the report
	 */
	public String renderBeginReport(ARIAReportProcessor processor) {
		StringBuffer buf = new StringBuffer(100);
		Page13PivotHTMLProcessor proc = (Page13PivotHTMLProcessor) processor;
		
		try {
			if (proc.getSectionNo()==0){
				createReportFilters();
			    buf.append("<html>\n");
			    buf.append("<head>\n");
			    buf.append("<style>\n");
			    buf.append("\t.BACTable {}\n");
			    buf.append("\t.BACTable TD {border: thin solid #000000; text-align: left;}\n");
			    buf.append("\t.BACTable TH {border: thin solid #000000; text-align: center; background-color: lightgrey; font-weight: bold;}\n");
			    buf.append("</style>\n");
			    buf.append("</head>\n");
			    buf.append("<body>\n");
			
			    buf.append(LayoutHelper.beginExcelTable());

			    if (getDtoBase().getRptHeader1() != null) {
	               buf.append(LayoutHelper.renderBeginExcelRow(processor));
	               buf.append("<td colspan=\"10\" style=\"border-style: none; font-size: 16; font-weight: bold; color: #191970;\">" + ARIAUtil.escape(getDtoBase().getRptHeader1()) + "</td>");
	               buf.append(LayoutHelper.renderEndExcelRow(processor));
			    }

		        if (getDtoBase().getRptHeader2() != null) {
		        	buf.append(LayoutHelper.renderBeginExcelRow(processor));
		        	buf.append("<td colspan=\"10\" style=\"border-style: none; font-size: 12; font-weight: bold; color: #191970;\">" + ARIAUtil.escape(getDtoBase().getRptHeader2()) + "</td>");
		            buf.append(LayoutHelper.renderEndExcelRow(processor));
		        }
		           
		        if (getDtoBase().getRptHeader3() != null) {
		        	buf.append(LayoutHelper.renderBeginExcelRow(processor));
		            buf.append("<td colspan=\"10\" style=\"border-style: none; font-size: 12; color: #191970;\">" + ARIAUtil.escape(getDtoBase().getRptHeader3()) + "</td>");
		            buf.append(LayoutHelper.renderEndExcelRow(processor));
		        }

		       buf.append(LayoutHelper.renderBeginExcelRow(processor));
	           buf.append(LayoutHelper.renderEndExcelRow(processor));

	           buf.append(LayoutHelper.renderBeginExcelRow(processor));
	           buf.append(LayoutHelper.addExcelLabel("Start"));
	           buf.append("<td colspan=\"10\" style=\"border-style: none;\">" + dto.getStartDate() + "</td>");
	           buf.append(LayoutHelper.renderEndExcelRow(processor));

	           buf.append(LayoutHelper.renderBeginExcelRow(processor));
	           buf.append(LayoutHelper.addExcelLabel("End"));
	           buf.append("<td colspan=\"10\" style=\"border-style: none;\">" + dto.getEndDate() + "</td>");
	           buf.append(LayoutHelper.renderEndExcelRow(processor));

	           // Report filters (start)
	           if (getDtoBase().isHideSortKeyList()) {
	        	   buf.append(LayoutHelper.renderBeginExcelRow(processor));
	               buf.append(LayoutHelper.addExcelLabel(getDtoBase().getLabelSortKeyList()));
	               buf.append("<td colspan=\"10\" style=\"border-style: none;\">" + getDtoBase().getSortKeyList() + "</td>");
	               buf.append(LayoutHelper.renderEndExcelRow(processor));
	           }

	           if (!getDtoBase().isHideDivDropDown() || !getDtoBase().isHideDivCheckBox()) {
	               for (int i = 0; i < getDtoBase().getSelectedDivs().length; i++) {
	                   String div = StaticDataLoader.getDivisionDesc(getDtoBase().getRegion(), getDtoBase().getSelectedDivs()[i]);
	                   buf.append(LayoutHelper.renderBeginExcelRow(processor));
	                   buf.append(LayoutHelper.addExcelLabel("Division"));
	                   buf.append("<td colspan=\"10\" style=\"border-style: none;\">" + div + "</td>");
	                   buf.append(LayoutHelper.renderEndExcelRow(processor));
	               }
	           }

	           if (!getDtoBase().isHideFileSeqNum()) {
	        	   buf.append(LayoutHelper.renderBeginExcelRow(processor));
	               buf.append(LayoutHelper.addExcelLabel("File Sequence Number"));
	               buf.append("<td colspan=\"10\" style=\"border-style: none;\">" + getDtoBase().getFileSeqNumAsString() + "</td>");
	               buf.append(LayoutHelper.renderEndExcelRow(processor));
	           }

	           if (!getDtoBase().isHideSortKeyList2()) {
	        	   buf.append(LayoutHelper.renderBeginExcelRow(processor));
	               buf.append(LayoutHelper.addExcelLabel(getDtoBase().getLabelSortKeyList2()));
	               buf.append("<td colspan=\"10\" style=\"border-style: none;\">" + getDtoBase().getSortKeyList2() + "</td>");
	               buf.append(LayoutHelper.renderEndExcelRow(processor));
	           }

	           if (!getDtoBase().isHideAlertRuleTiming()) {
	               String excelAlertTimeValue = "";
	               if (getDtoBase().getAlertTimeInd().equalsIgnoreCase("D")) {
	                   if (getDtoBase().getAlertTimeValue() != -1) {
	                       HashMap weekdayOptions = new HashMap();
	                       weekdayOptions.put(Integer.toString(0), "All");
	                       weekdayOptions.put(Integer.toString(1), "Sunday");
	                       weekdayOptions.put(Integer.toString(2), "Monday");
	                       weekdayOptions.put(Integer.toString(3), "Tuesday");
	                       weekdayOptions.put(Integer.toString(4), "Wednesday");
	                       weekdayOptions.put(Integer.toString(5), "Thursday");
	                       weekdayOptions.put(Integer.toString(6), "Friday");
	                       weekdayOptions.put(Integer.toString(7), "Saturday");
	                       excelAlertTimeValue = weekdayOptions.get(Integer.toString(getDtoBase().getAlertTimeValue())).toString();
	                   }
	                   buf.append(LayoutHelper.renderBeginExcelRow(processor));
	                   buf.append(LayoutHelper.addExcelLabel("Call Day Week"));
	                   buf.append("<td colspan=\"10\" style=\"border-style: none;\">" + excelAlertTimeValue + "</td>");
	                   buf.append(LayoutHelper.renderEndExcelRow(processor));
	               } else if (getDtoBase().getAlertTimeInd().equalsIgnoreCase("B")) {
	                   if (getDtoBase().getAlertTimeValue() != -1) {
	                       excelAlertTimeValue = Integer.toString(getDtoBase().getAlertTimeValue());
	                   }
	                   buf.append(LayoutHelper.renderBeginExcelRow(processor));
	                   buf.append(LayoutHelper.addExcelLabel("Bill Cycle"));
	                   buf.append("<td colspan=\"10\" style=\"border-style: none;\">" + excelAlertTimeValue + "</td>");
	                   buf.append(LayoutHelper.renderEndExcelRow(processor));
	               } else {
	            	   buf.append(LayoutHelper.renderBeginExcelRow(processor));
	                   buf.append(LayoutHelper.addExcelLabel("Timing"));
	                   buf.append("<td colspan=\"10\" style=\"border-style: none;\">" + excelAlertTimeValue + "</td>");
	                   buf.append(LayoutHelper.renderEndExcelRow(processor));
	               }
	               
	               if (!getDtoBase().isHideMonthYear()) {
	            	   buf.append(LayoutHelper.renderBeginExcelRow(processor));
	                   buf.append(LayoutHelper.addExcelLabel("Month"));
	                   buf.append("<td colspan=\"10\" style=\"border-style: none;\">" + ((PickList) getDtoBase().getMonthSelectOptions().get(getDtoBase().getMonthSelect())).getValue1() + "</td>");
	                   buf.append(LayoutHelper.renderEndExcelRow(processor));
	                   String excelYear = "";
	                   if (getDtoBase().getYearSelect() != 0) {
	                       excelYear = Integer.toString(getDtoBase().getYearSelect());
	                   }
	                   buf.append(LayoutHelper.renderBeginExcelRow(processor));
	                   buf.append(LayoutHelper.addExcelLabel("Year"));
	                   buf.append("<td colspan=\"10\" style=\"border-style: none;\">" + excelYear + "</td>");
	                   buf.append(LayoutHelper.renderEndExcelRow(processor));
	               }
	           }

		       buf.append(LayoutHelper.endExcelTable());
			}
			
			buf.append(LayoutHelper.beginExcelTable());
			buf.append(LayoutHelper.renderBeginExcelRow(processor));
			if ( dto.getDistExecPresnSeqNumList().size() > 1) {
				buf.append(LayoutHelper.addExcelLabel("Total Data Sets (Section " + (proc.getSectionNo()+1) + ")"));
            } else {
            	buf.append(LayoutHelper.addExcelLabel("Total Data Sets"));
            }
			buf.append("<td colspan=\"10\" style=\"border-style: none;\">" + getTotalDataSets() + "</td>");
			buf.append(LayoutHelper.renderEndExcelRow(processor));
			buf.append(LayoutHelper.endExcelTable());
       } catch (Exception e) {
           logger.error(CLASS_NAME, "renderBeginReport", e);
       }
	        
       return buf.toString();
	}
	
	/**
	 * @return the isOutputExcel
	 */
	public boolean isOutputExcel() {
		return true;
	}
}
