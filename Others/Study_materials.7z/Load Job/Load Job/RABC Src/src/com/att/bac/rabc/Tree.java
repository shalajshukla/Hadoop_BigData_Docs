/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc;

import java.util.ArrayList;
import java.util.List;

/**
 * This is a data object which represents the tree to be display on the pages.
 * 
 * @author Vijay Dubey - VD3159
 */
public class Tree {
	private List treeNodeList;
	private String treeType; 
	/*
	 * Can have the following values 
	 * 1) "1" => COMPLETE TREE WITH ALL FEATURES
	 * 2) "2" => WITH ONLY TABLE FEATURE
	 * 3) "3" => WITH TABLE + CREATE VIEW
	 * 4) "4" => WITH TABLE + CREATE VIEW + CREATE CALCULATION FEATURES
	 */
	
	/**
	 * Default constructor.
	 */
	public Tree() {
		this.treeType = "3"; // Default will have all table + create view features
		this.treeNodeList = new ArrayList();
	}
	
	/**
	 * @return Returns the treeType.
	 */
	public String getTreeType() {
		return treeType;
	}
	/**
	 * @param treeType The treeType to set.
	 */
	public void setTreeType(String treeType) {
		this.treeType = treeType;
	}
	/**
	 * @return Returns the treeNodeList.
	 */
	public List getTreeNodeList() {
		return treeNodeList;
	}
	/**
	 * @param nodeList The treeNode to add.
	 */
	public void addNode(TreeNode treeNode) {
		this.treeNodeList.add(treeNode) ;
	}
}
