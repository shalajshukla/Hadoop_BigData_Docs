/* Created by GB0741 on Nov 06, 2007.
   Copyright 2008 AT&T Knowledge Ventures. All rights reserved. 
*/
package com.att.bac.rabc.load.calnet.telcoacus;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import com.att.carat.util.JDBCUtil;

/**
 * This component is DAO for CrisAcusLoadJob, CrisAcusReportLoadJob. This includes methods to find bill amount 
 * discrepancies and btn discrepancies in cris acus records and inserts these into database. This also includes methods to
 * select these records from database tables and also populates CrisAcus.
 * RABC_ACCT_BLG_DTL CRIS, RABC_ACUS_CIS_INFO and RABC_CRIS_ACUS_DSCRPNCY tables are accessed in this component.
 *
 */
public class CrisAcusDAO{
	
	/**
	 * This method compares the bill amounts of cris acus records in tables RABC_ACCT_BLG_DTL and RABC_ACUS_CIS_INFO based on certain conditions.
	 * Found discrepancies are insertted in table RABC_CRIS_ACUS_DSCRPNCY.
	 * @param connection
	 * @param acusDays
	 * @return
	 * @throws CrisAcusException
	 */
	public boolean populateBillAmtRecords(Connection connection, String acusDays) throws CrisAcusException {
		boolean success = false;
		Statement stmt = null;
		String	insertQuery =
			" INSERT INTO RABC_CRIS_ACUS_DSCRPNCY (CRIS_BTN, " +
				" CRIS_CURR_MNTH_CHRG_AMT, " +
				" CRIS_BILL_RND, " +
				" CRIS_BILL_MM, " +
				" CRIS_YEAR, " +
				" ACUS_BTN, " +
				" ACUS_PROV_RECEIVED_AMT, " +
				" ACUS_PROV_BILL_RND, " +
				" ACUS_PROV_INV_MM, " +
				" ACUS_PROV_INV_YEAR, " +
				" DATA_EXTRACT_DT) " +
					
				" (SELECT  CRIS.BTN, " +
					" CRIS.CURR_MNTH_CHRG_AMT + CRIS.ADJ_AMT, " +
					" CRIS.BILL_RND, " +
					" CRIS.BILL_MM, " +
					" CRIS.BILL_YEAR, " +
					" ACUS.BP_BTN, " +
					" ACUS.CIS_PROV_RECEIVED_AMT, " +
					" CRIS.BILL_RND, " +
					" CRIS.BILL_MM, " +
					" CRIS.BILL_YEAR, " +
					" trunc(SYSDATE-1)  " +
						" FROM RABC_ACCT_BLG_DTL CRIS, RABC_ACUS_CIS_INFO ACUS " +
							" WHERE (SYSDATE - ACUS.PROV_INV_DT) < " + acusDays +
								" AND CRIS.BILL_RND <> 0 " +
								" AND to_date(CRIS.BILL_MM || '-' || decode(CRIS.BILL_RND,0,1,CRIS.BILL_RND) || '-' || CRIS.BILL_YEAR, 'MM-DD-YYYY') = ACUS.PROV_INV_DT  " +
								" AND CRIS.BTN = ACUS.BP_BTN " +
								" AND ACUS.PROV_NM = 'CRIS'  " +
								" AND (CRIS.CURR_MNTH_CHRG_AMT + CRIS.ADJ_AMT) <> ACUS.CIS_PROV_RECEIVED_AMT )";
		try{
			stmt = connection.createStatement();
			stmt.executeUpdate(insertQuery);
			success = true;
		}
		catch (SQLException sqle)	{
		throw new CrisAcusException("Error occurred while inserting bill amount discrepancy data in RABC_CRIS_ACUS_DSCRPNCY.", sqle);
	   }finally {
		JDBCUtil.closeStatement(stmt);
		}
	   return success;
	}

	/**
	 * This method compares the btn values of cris acus records in tables RABC_ACCT_BLG_DTL 
	 * and RABC_ACUS_CIS_INFO based on certain conditions.
	 * Found discrepancies are insertted in table RABC_CRIS_ACUS_DSCRPNCY.
	 * @param connection
	 * @param acusDays
	 * @param crisFromDays
	 * @param crisToDays
	 * @return
	 * @throws CrisAcusException
	 */
	public boolean populateBtnRecords(Connection connection, String acusDays, String crisFromDays, String crisToDays ) throws CrisAcusException {
		boolean success = false;
		Statement stmt = null;
		String	insertQuery =
			" INSERT INTO RABC_CRIS_ACUS_DSCRPNCY (" +
				" CRIS_BTN, " +
				" CRIS_CURR_MNTH_CHRG_AMT, " +
				" CRIS_BILL_RND, " +
				" CRIS_BILL_MM, " +
				" CRIS_YEAR, " +
				" DATA_EXTRACT_DT) " +
					
				" (SELECT  CRIS.BTN, " + 
					" CRIS.CURR_MNTH_CHRG_AMT, " + 
					" CRIS.BILL_RND,  " +
					" CRIS.BILL_MM,  " +
					" CRIS.BILL_YEAR,  " +
					" trunc(SYSDATE-1)  " +
						" FROM RABC_ACCT_BLG_DTL CRIS " + 
							" WHERE  " +
								" SYSDATE - to_date(CRIS.BILL_MM || '-' || decode(CRIS.BILL_RND,0,1,CRIS.BILL_RND) || '-' || CRIS.BILL_YEAR, 'MM-DD-YYYY') > " +crisFromDays + 
								" AND SYSDATE - to_date(CRIS.BILL_MM || '-' || decode(CRIS.BILL_RND,0,1,CRIS.BILL_RND) || '-' || CRIS.BILL_YEAR, 'MM-DD-YYYY') < " +crisToDays +
								" AND CRIS.BILL_RND <> 0 " +
								" AND NOT EXISTS  " +
								" (SELECT 1 FROM RABC_ACUS_CIS_INFO ACUS WHERE " + 
								" SYSDATE - ACUS.PROV_INV_DT < " + acusDays +
								" AND ACUS.PROV_NM = 'CRIS' " +
								" AND to_date(CRIS.BILL_MM || '-' || decode(CRIS.BILL_RND,0,1,CRIS.BILL_RND) || '-' || CRIS.BILL_YEAR, 'MM-DD-YYYY') = ACUS.PROV_INV_DT " +
								" AND CRIS.BTN = ACUS.BP_BTN ))" ;
			try{
			stmt = connection.createStatement();
			stmt.executeUpdate(insertQuery);
			success = true;
		}
		catch (SQLException sqle)	{
		throw new CrisAcusException("Error occurred while inserting BTN discrepancy data in RABC_CRIS_ACUS_DSCRPNCY.", sqle);
	   }finally {
		JDBCUtil.closeStatement(stmt);
		}
	   return success;
	}
	
	/**
	 * This method return list of bill amount discrepancy records fetched from RABC_CRIS_ACUS_DSCRPNCY table
	 * @param connection
	 * @return
	 * @throws CrisAcusException
	 */
	public List<CrisAcus> billAmtRecords(Connection connection) throws CrisAcusException {
		PreparedStatement stmt = null;
		ResultSet rs = null;
 		List<CrisAcus> records = new ArrayList<CrisAcus>();

		String	selectQuery =
					" SELECT " +
						" CRIS_BTN, " +
						" CRIS_CURR_MNTH_CHRG_AMT, " +
						" CRIS_BILL_RND, " +
						" CRIS_BILL_MM, " +
						" CRIS_YEAR, " +
						" ACUS_BTN, " +
						" ACUS_PROV_RECEIVED_AMT, " +
						" ACUS_PROV_BILL_RND, " +
						" ACUS_PROV_INV_MM, " +
						" ACUS_PROV_INV_YEAR, " +
						" DATA_EXTRACT_DT " +
							" FROM RABC_CRIS_ACUS_DSCRPNCY " +
								" WHERE ACUS_BTN is not null " +
									" AND DATA_EXTRACT_DT = trunc(sysdate-1)";
		try{
			stmt = connection.prepareStatement(selectQuery);
			rs = stmt.executeQuery();
			while (rs.next()) {
				records.add(createCrisAcus(rs));
			}
	        return records;
		}
		catch (SQLException sqle)	{
			throw new CrisAcusException("Error occurred while fetching BillAmount discrepancy data from RABC_CRIS_ACUS_DSCRPNCY.", sqle);
	   }finally {
			JDBCUtil.closeStatement(stmt);
			JDBCUtil.closeResultSet(rs);
		}
	}


 	/**
 	 * This method return list of btn discrepancy records fetched from RABC_CRIS_ACUS_DSCRPNCY table 
 	 * @param connection
 	 * @return
 	 * @throws Exception
 	 */
 	public List<CrisAcus> btnRecords(Connection connection) throws CrisAcusException {
		PreparedStatement stmt = null;
		ResultSet rs = null;
		List<CrisAcus> records = new ArrayList<CrisAcus>();

		String	selectQuery =
					" SELECT " +
						" CRIS_BTN, " +
						" CRIS_CURR_MNTH_CHRG_AMT, " +
						" CRIS_BILL_RND, " +
						" CRIS_BILL_MM, " +
						" CRIS_YEAR, " +
						" ACUS_BTN, " +
						" ACUS_PROV_RECEIVED_AMT, " +
						" ACUS_PROV_BILL_RND, " +
						" ACUS_PROV_INV_MM, " +
						" ACUS_PROV_INV_YEAR, " +
						" DATA_EXTRACT_DT " +
							" FROM RABC_CRIS_ACUS_DSCRPNCY " +
								" WHERE ACUS_BTN is null " +
									" AND DATA_EXTRACT_DT = trunc(sysdate-1)";
			try{
				stmt = connection.prepareStatement(selectQuery);
				rs = stmt.executeQuery();
				while (rs.next()) {
					records.add(createCrisAcus(rs));
				}
	        return records;
		}
		catch (SQLException sqle){
			throw new CrisAcusException("Error occurred while fetching BTN discrepancy data from RABC_CRIS_ACUS_DSCRPNCY.", sqle);
	   }finally {
			JDBCUtil.closeStatement(stmt);
			JDBCUtil.closeResultSet(rs);
	   }
	}
 	
 	/**
 	 * This method creates CrisAcus
 	 * @param rs
 	 * @return
 	 * @throws SQLException
 	 */
 	private CrisAcus createCrisAcus(ResultSet rs) throws SQLException{
	    CrisAcus crisAcus = new CrisAcus();
	   	crisAcus.setCrisBtn(rs.getString("CRIS_BTN"));
    	crisAcus.setCrisBillAmt(rs.getString("CRIS_CURR_MNTH_CHRG_AMT"));
    	crisAcus.setCrisBillRnd(rs.getString("CRIS_BILL_RND"));
    	crisAcus.setCrisBillMm(rs.getString("CRIS_BILL_MM"));
    	crisAcus.setCrisYear(rs.getString("CRIS_YEAR"));
    	crisAcus.setAcusBtn(rs.getString("ACUS_BTN"));
    	crisAcus.setAcusReceivedAmt(rs.getString("ACUS_PROV_RECEIVED_AMT"));
    	crisAcus.setAcusBillRnd(rs.getString("ACUS_PROV_BILL_RND"));
    	crisAcus.setAcusBillMm(rs.getString("ACUS_PROV_INV_MM"));
    	crisAcus.setAcusYear(rs.getString("ACUS_PROV_INV_YEAR"));
    	crisAcus.setDataExtractDt(rs.getDate("DATA_EXTRACT_DT"));
    	return crisAcus;
 	}
 	
	/**
 	 * This method return the string email address(es) of the recipient(s) to whom reports are e-mailed 
 	 * @param connection
 	 * @return
 	 * @throws Exception
 	 */
 	public String[] getRecipientId(Connection connection) throws CrisAcusException {
		PreparedStatement stmt = null;
		ResultSet rs = null;
        Vector<String> recipientId = new Vector<String>();
		String	selectQuery = " SELECT EMAIL_ADD FROM RABC_CALNET2_EMAIL_NM ";
						
		try{
			stmt = connection.prepareStatement(selectQuery);
			rs = stmt.executeQuery();
			// add available email addresses to vector
			while(rs.next()) {
				recipientId.add(rs.getString("EMAIL_ADD"));
			}
		}
		catch (SQLException sqle) {
			throw new CrisAcusException("Error getting email address(es) of recipient(s) to whom reports are to be sent.", sqle);
	   }finally {
			JDBCUtil.closeStatement(stmt);
			JDBCUtil.closeResultSet(rs);
	   }
       return (String[]) recipientId.toArray(new String[recipientId.size()]);	   
	}
}
