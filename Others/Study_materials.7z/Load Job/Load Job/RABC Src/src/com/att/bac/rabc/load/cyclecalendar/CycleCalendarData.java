package com.att.bac.rabc.load.cyclecalendar;

/**
 * This component contains the getter/ setter methods for the fields used by
 * RABC CycleCalendarWestLoadJob, CycleCalendarMidWestLoadJob,
 * CycleCalendarSouthWestLoadJob and CycleCalendarSouthEastLoadJob
 * 
 * @author kb629p
 */

public class CycleCalendarData {
	private String cycle = null;
	private String billRnd = null;
	private String procDate = null;
	private String billRndDate = null;
	private String procDateIndicator = null;

	public String getCycle() {
		return cycle;
	}

	public void setCycle(String cycle) {
		this.cycle = cycle;
	}

	public String getBillRnd() {
		return billRnd;
	}

	public void setBillRnd(String billRnd) {
		this.billRnd = billRnd;
	}

	public String getProcDate() {
		return procDate;
	}

	public void setProcDate(String procDate) {
		this.procDate = procDate;
	}

	public String getBillRndDate() {
		return billRndDate;
	}

	public void setBillRndDate(String billRndDate) {
		this.billRndDate = billRndDate;
	}

	public String getProcDateIndicator() {
		return procDateIndicator;
	}

	public void setProcDateIndicator(String procDateIndicator) {
		this.procDateIndicator = procDateIndicator;
	}

}
