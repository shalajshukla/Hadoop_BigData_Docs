package com.att.bac.rabc.load.calnet.telcoacus;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Properties;

//changes done for M168 by as635b
//import com.sbc.bac.load.Application;
//import com.sbc.bac.load.DBLoadJob;
//import com.sbc.bac.load.TimedLoadJob;
import com.att.carat.load.Application;
import com.att.carat.load.DBLoadJob;
import com.att.carat.load.TimedLoadJob;

/**
 * 
 * @author sb8798
 * This archive load job does the following:
 * (i) It will move data that is more than 3 months old (specified in the config file) from the  
 *     RABC_CRIS_ACUS_DSCRPNCY table to the RABC_CRIS_ACUS_DSCRPNCY_ARCH 
 *     table.  The DATA_EXTRACT_DATE date will be used to determine 
 *     the age of the records.
 *     
 * (ii) it will remove any data older than 12 months old (specified in the config file)
 *       from the RABC_CRIS_ACUS_DSCRPNCY_ARCH table. The age of the data 
 *       records can be determined by utilizing the DATA_EXTRACT_DATE date in the 
 *       RABC_CRIS_ACUS_DSCRPNCY_ARCH table.  
 
 */
public class ArchiveLoadJob extends DBLoadJob {

	private Calendar runtime = Calendar.getInstance();
	private Calendar now = Calendar.getInstance();
	private SimpleDateFormat df = new SimpleDateFormat("HH:mm");
	private String interval="";
	private int minData = 0;
	private int maxData = 0;
	private boolean skipCheck = false;
		
	
	private ArchiveLoadJobDAO alj = new ArchiveLoadJobDAO();
	
	/**
	 * Configures parent and prints out next run time
	 * 
	 * @param application - application object.
	 * @param configuration - properties object with configuration info.
	 * @return success/failure of configuration.
	 * @see TimedLoadJob#configure(Application, Properties, int)
	 */
	protected boolean configure(Application application, Properties configuration) {
		boolean success=super.configure(application, configuration);
		if (success) {
			try {
				String time = configuration.getProperty("runtime");
				String dayOfMonth = configuration.getProperty("day");
				String minDataDays = configuration.getProperty("archive_minDays");
				String maxDataDays = configuration.getProperty("archive_maxDays");
				interval = configuration.getProperty("interval");
				
				if (minDataDays==null || maxDataDays==null)
				{
					severe("archive_minDays or archive_maxDays cannot be null");
					return false;
				}
				
				minData = Integer.parseInt(minDataDays);
				maxData = Integer.parseInt(maxDataDays);
				
				if (time == null || dayOfMonth==null) {
					severe("Time or day of month cannot be null");
					return false;
				}
				if (!interval.toUpperCase().equals("DAILY") && !interval.toUpperCase().equals("MONTHLY") && !interval.toUpperCase().equals("WEEKLY")){
					severe("Interval in configuration file must be monthly, weekly or daily");
					return false;
				}
				runtime.setTime(df.parse(time));
				runtime.set(Calendar.YEAR, now.get(Calendar.YEAR));
				runtime.set(Calendar.MONTH, now.get(Calendar.MONTH));
				if  (interval.toUpperCase().equals("WEEKLY")) {
					int dayOfWeek = Integer.parseInt(configuration.getProperty("day_of_week"));
					if (dayOfWeek<1 || dayOfWeek>7) {
						severe("Day of week must be between 1 and 7");
						return false;
					}
					runtime.set(Calendar.DAY_OF_MONTH, now.get(Calendar.DAY_OF_MONTH));
					while (runtime.get(Calendar.DAY_OF_WEEK)!=dayOfWeek) {
						runtime.add(Calendar.DATE, 1);
					}
				} else if (interval.toUpperCase().equals("DAILY")){
					runtime.set(Calendar.DAY_OF_MONTH, now.get(Calendar.DAY_OF_MONTH));
				} else {
					runtime.set(Calendar.DAY_OF_MONTH, Integer.parseInt(dayOfMonth));
				}
				if(now.after(runtime))  {
					if(interval.toUpperCase().equals("DAILY")) {
						runtime.add(Calendar.DATE, 1);
					} else if (interval.toUpperCase().equals("WEEKLY")) {
						runtime.add(Calendar.DATE, 7);
					} else if (interval.toUpperCase().equals("MONTHLY")) {
						runtime.add(Calendar.MONTH, 1);
					}	
				}
			} catch (ParseException pe) {
				severe("Unable to parse time entry from configuration file", pe);
				return false;
			}
		}
		info("Job is scheduled to run again "+runtime.getTime());
        skipCheck = asBoolean(configuration.getProperty("skip_check", "false"));
		return success;
	}

    /**
     * Util method, transform Y/N to boolean
     * 
     * @param b
     * @return
     */
    private static boolean asBoolean(String s) {
        return (s.equalsIgnoreCase("true")) ? true : false;
    }
    
	/**This method checks to see if the current time is after the currently scheduled runtime.
	 * 
	 * @return now.after(runtime)  the boolean that tells the load process if it is time to process data or not.
	 */
	protected boolean check() {
		
        if (skipCheck) {
            return true;
        }
        
		Calendar now = Calendar.getInstance();
		return now.after(runtime);
	}
	
	/**
	 * @Override
	 * This method performs the main functionality of the loadjob. It calls
	 * the ArchiveLoadJobDAO to execute the queries. 
	 */
	
	protected boolean action() {
		
		boolean success = false;

		try {
			//delete data from the archive table that is older than 12 months
			success = alj.deleteOldDataFromAchiveTable(connection,maxData);
			//archive data > 4 months (120 days) 
			success = alj.selectAndInsertDataToBeArchivedFromDscrpncy(connection, minData);
			// delete those data from the Discrepancy table
			success = alj.deleteDataFromDscrpncy(connection, minData);
			info("suucess: " + success);
			
		} catch (Exception exc) {
			severe("Error Inserting records into database" + exc.getMessage(), exc);
			success = false;
		}

		return success;
	}

	/**
	 * Calls super.postprocess, logs when job is scheduled to run again
	 * 
	 * @param success - success/failure of the processing.
	 * @return true if postprocessing was successful, false otherwise
	 * @see TimedLoadJob#postprocess(boolean)
	 */
	protected boolean postprocess(boolean success) {
		//Close statements
		success = super.postprocess(success);
		if (success) {
			if(interval.toUpperCase().equals("DAILY")) {
				runtime.add(Calendar.DATE, 1);
			} else if (interval.toUpperCase().equals("WEEKLY")) {
				runtime.add(Calendar.DATE, 7);
			} else if (interval.toUpperCase().equals("MONTHLY")) {
				runtime.add(Calendar.MONTH, 1);
			}
		    info("Job is scheduled to run again "+runtime.getTime());
		}
		return success;
	}	

}
