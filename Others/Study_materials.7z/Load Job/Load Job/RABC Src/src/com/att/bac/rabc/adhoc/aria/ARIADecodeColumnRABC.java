/*
 * Copyright  2002-2006 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.adhoc.aria;

import com.sbc.bac.aria.ARIADecodeColumn;


/**
 * Custom column to keep track of dto indexs
 * 
 * <p>
 * <hr>
 * <h3>Release History</h3>
 * <p>
 * <ul>
 * 
 * <li>jb6494 Aug 11, 2006 Created class.
 * 
 * </ul>
 * <p>
 * 
 */
public class ARIADecodeColumnRABC extends ARIADecodeColumn implements IAdhocDTOIndex {

    private int dtoIndex;


    /**
     * Constructor
     * 
     * @param name
     * @param strFormat
     */
    public ARIADecodeColumnRABC(String name, String strFormat, int dtoIndex) {
        super(name, strFormat);
        this.dtoIndex = dtoIndex;
    }


    /**
     * Constructor
     * 
     * @param name
     * @param strFormat
     * @param outputPattern
     */
    public ARIADecodeColumnRABC(String name, String strFormat, String outputPattern, int dtoIndex) {
        super(name, strFormat, outputPattern);
        this.dtoIndex = dtoIndex;
    }


    /*
     * (non-Javadoc)
     * 
     * @see com.att.bac.rabc.adhoc.aria.IAdhocDTOIndex#getDtoIndex()
     */
    public int getDtoIndex() {
        return dtoIndex;
    }

}
