/*------------------------------------------------------------------------------
Modification History
� 2002-2011 AT&T Intellectual Property. All rights reserved.
Date		Version		Author			Description
----------	-----------	--------------- ----------------------------------------
12-02-2010	0.1			ss1644			initial Draft
------------------------------------------------------------------------------*/
package com.att.bac.rabc.load.ecdw;
//------------------------------------------------------------------------------
/**
 * The class EcdwExtractControllerException is a form of Throwable 
 * that indicates conditions that a reasonable application might want to catch. 
 */
public class EcdwExtractControllerException extends Exception {
	//--------------------------------------------------------------------------
	private static final long 
		serialVersionUID 			= -5130503249085834334L
	;
	//--------------------------------------------------------------------------
	/**
	 * Constructs a new exception with null as its detail message
	 */
	public EcdwExtractControllerException () {
        super();
    }
	//--------------------------------------------------------------------------
    /**
     * Constructs a new exception with the specified detail message
     * @param message	 the detail message
     */
    public EcdwExtractControllerException (String message) {
        super(message);
    }
    //--------------------------------------------------------------------------
    /**
     * Constructs a new exception with the specified cause and a detail 
     * message of (cause==null ? null : cause.toString()) 
     * @param cause  the cause
     */
    public EcdwExtractControllerException (Throwable cause) {
        super (cause);
    }
    //--------------------------------------------------------------------------
    /**
     * Constructs a new exception with the specified detail message and cause
     * @param message	the detail message 
     * @param cause  	the cause.
     */
    public EcdwExtractControllerException (String message, Throwable cause) {
        super(message, cause);
    }
    //--------------------------------------------------------------------------
}
//------------------------------------------------------------------------------
//
//	End of file
//
//------------------------------------------------------------------------------

