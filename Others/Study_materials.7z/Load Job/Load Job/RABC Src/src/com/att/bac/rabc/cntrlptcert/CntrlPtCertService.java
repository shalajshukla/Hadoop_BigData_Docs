/* Component Name: RABCPPG00597
 * Module Name: CntrlPtCertService.java
 * Created on Nov 3, 2006
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.cntrlptcert;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.naming.NamingException;

import org.apache.log4j.Logger;

import com.att.bac.rabc.ConnectionManager;
import com.att.bac.rabc.RABCException;
import com.att.carat.util.JDBCUtil;

/**This is the facade class for the Control Process Certification process.  The purpose of this class 
 * is to handle the business logic and populate the CntrlPtCertForm.java class with data gathered from the
 * CntrlPtCertDAO.java class.
 * 
 * @author js3175
 */
public class CntrlPtCertService {
	private static final Logger logger = Logger.getLogger(CntrlPtCertService.class);
	
	/**This is the method called to access the DAO to set up the JSP page CntrlPtCertMain.jsp when
	 * the user first enters the process.
	 * 
	 * @param cntrlPtCertForm  a blank CntrlPtCertForm with userId & region populated
	 * @return cntrlPtCertForm  a CntrlPtCertForm with data populated from the DAO
	 */
	protected static CntrlPtCertForm unspecified(CntrlPtCertForm cntrlPtCertForm) throws RABCException{
		logger.debug("Starting process CntrlPtCertService.unspecified.");
		Connection conn = null;		
		try {			
			String region = cntrlPtCertForm.getRegion();
			if(cntrlPtCertForm.getRegion().equals("EN")){
				region = cntrlPtCertForm.getSelectedRegion();
				CntrlPtCertEnterpriseDAO.getRegionList(cntrlPtCertForm);
			}			
			
			if(region.equalsIgnoreCase("All")){
				conn = ConnectionManager.getConnection("EN");			
				
				CntrlPtCertEnterpriseDAO.getUserAccess(conn, cntrlPtCertForm);				
				CntrlPtCertEnterpriseDAO.getStateList(conn, cntrlPtCertForm);
				CntrlPtCertEnterpriseDAO.getProcessList(conn, cntrlPtCertForm);
				cntrlPtCertForm.setCertInd("A");
				cntrlPtCertForm.setIssueInd("A");
				cntrlPtCertForm.setJSAlertMsg(" ");
				logger.debug("Finished process CntrlPtCertService.unspecified(All).");
			}else {
				conn = ConnectionManager.getConnection(region);	
				
				CntrlPtCertDAO.getUserAccess(conn, cntrlPtCertForm);
				CntrlPtCertDAO.getStateList(conn, cntrlPtCertForm);
				CntrlPtCertDAO.getProcessList(conn, cntrlPtCertForm);
				cntrlPtCertForm.setCertInd("A");
				cntrlPtCertForm.setIssueInd("A");
				cntrlPtCertForm.setJSAlertMsg(" ");
				logger.debug("Finished process CntrlPtCertService.unspecified.");				
			}			
		} catch (SQLException sqle) {
			throw new RABCException("SQL exception in creating a connection: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return cntrlPtCertForm;
	}
	
	/**This is the method called to access the DAO to set up the JSP page CntrlPtCertMain.jsp when
	 * the "View" button is clicked.
	 * 
	 * @param cntrlPtCertForm  a blank CntrlPtCertForm with userId & region populated
	 * @return cntrlPtCertForm  a CntrlPtCertForm with data populated from the DAO
	 */
	protected static CntrlPtCertForm cntrlPtCertView(CntrlPtCertForm cntrlPtCertForm) throws RABCException{
		logger.debug("Starting process CntrlPtCertService.cntrlPtCertView.");
		Connection conn = null;
		try {			
			String region = cntrlPtCertForm.getRegion();
			if(cntrlPtCertForm.getRegion().equals("EN")){
				region = cntrlPtCertForm.getSelectedRegion();
				CntrlPtCertEnterpriseDAO.getRegionList(cntrlPtCertForm);
			}
			
			if(region.equalsIgnoreCase("All")){
				conn = ConnectionManager.getConnection("EN");
				
				CntrlPtCertEnterpriseDAO.getStateList(conn, cntrlPtCertForm);
				CntrlPtCertEnterpriseDAO.getProcessList(conn, cntrlPtCertForm);
				CntrlPtCertEnterpriseDAO.getUserAccess(conn, cntrlPtCertForm);	
				
				//retrieve control processes from database based on selection criteria
				CntrlPtCertEnterpriseDAO.getCntrlPtCertViewList(conn, cntrlPtCertForm, cntrlPtCertForm.getStartDate(), cntrlPtCertForm.getEndDate(), cntrlPtCertForm.getStateDesc(), cntrlPtCertForm.getProcess(), cntrlPtCertForm.getCertInd(), cntrlPtCertForm.getIssueInd());
				cntrlPtCertForm.setJSAlertMsg(" ");
				logger.debug("Finished process CntrlPtCertService.cntrlPtCertView(All).");
			}else {
				conn = ConnectionManager.getConnection(region);			
				
				CntrlPtCertDAO.getStateList(conn, cntrlPtCertForm);
				CntrlPtCertDAO.getProcessList(conn, cntrlPtCertForm);
				
				//retrieve control processes from database based on selection criteria
				CntrlPtCertDAO.getCntrlPtCertViewList(conn, cntrlPtCertForm, cntrlPtCertForm.getStartDate(), cntrlPtCertForm.getEndDate(), cntrlPtCertForm.getStateDesc(), cntrlPtCertForm.getProcess(), cntrlPtCertForm.getCertInd(), cntrlPtCertForm.getIssueInd());
				cntrlPtCertForm.setJSAlertMsg(" ");
				logger.debug("Finished process CntrlPtCertService.cntrlPtCertView.");
			}			
			
		} catch (SQLException sqle) {
			throw new RABCException("SQL exception in creating a connection: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return cntrlPtCertForm;
	}
	
	/**This is the method called to access the DAO to certify a process then set up the JSP page 
	 * CntrlPtCertMain.jsp when the "Certify" button is clicked.
	 * 
	 * @param cntrlPtCertForm  a blank CntrlPtCertForm with userId & region populated
	 * @return cntrlPtCertForm  a CntrlPtCertForm with data populated from the DAO
	 */
	protected static CntrlPtCertForm cntrlPtCertCertify(CntrlPtCertForm cntrlPtCertForm) throws RABCException {
		logger.debug("Starting process CntrlPtCertService.cntrlPtCertCertify.");
		Connection conn = null;
		try {
			String region = cntrlPtCertForm.getRegion();
			if(cntrlPtCertForm.getRegion().equals("EN")){			
				region = cntrlPtCertForm.getSelectedRegion();
				CntrlPtCertEnterpriseDAO.getRegionList(cntrlPtCertForm);
			}
				
			conn = ConnectionManager.getConnection(region);				
				
			//Certify control processes based on selection criteria
			CntrlPtCertDAO.certifyProcess(conn, cntrlPtCertForm, cntrlPtCertForm.getStartDate(), cntrlPtCertForm.getEndDate(), cntrlPtCertForm.getStateDesc(), cntrlPtCertForm.getProcess(), cntrlPtCertForm.getCertInd(), cntrlPtCertForm.getIssueInd());
			conn.commit();

			//Retrieve control processes from database where cert ind = "Y" 
			cntrlPtCertForm.setCertInd("Y");
			
			// Now update the view using Enterprise connection
			CntrlPtCertDAO.getStateList(conn, cntrlPtCertForm);
			CntrlPtCertDAO.getProcessList(conn, cntrlPtCertForm);
			CntrlPtCertDAO.getCntrlPtCertViewList(conn, cntrlPtCertForm, cntrlPtCertForm.getStartDate(), cntrlPtCertForm.getEndDate(), cntrlPtCertForm.getStateDesc(), cntrlPtCertForm.getProcess(), cntrlPtCertForm.getCertInd(), cntrlPtCertForm.getIssueInd());

			logger.debug("Finished process CntrlPtCertService.cntrlPtCertCertify.");
		} catch (SQLException sqle) {
			throw new RABCException("SQL exception in creating a connection or committing transaction: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return cntrlPtCertForm;
	}
	
	/**
	 * This method will be used to perform CertifyAll option
	 * @param cntrlPtCertForm
	 * @return
	 * @throws RABCException
	 */
	protected static CntrlPtCertForm cntrlPtCertCertifyAll(CntrlPtCertForm cntrlPtCertForm, List cntrlPtCertViewList) throws RABCException {
		logger.debug("Starting process CntrlPtCertService.cntrlPtCertCertifyAll.");
		Connection conn = null;
		try {
			String region = cntrlPtCertForm.getRegion();
			if(cntrlPtCertForm.getRegion().equals("EN")){			
				region = cntrlPtCertForm.getSelectedRegion();
				CntrlPtCertEnterpriseDAO.getRegionList(cntrlPtCertForm);
			}
			
			if(region.equalsIgnoreCase("All")){
				conn = ConnectionManager.getConnection("EN");
				
				CntrlPtCertEnterpriseDAO.getStateList(conn, cntrlPtCertForm);
				CntrlPtCertEnterpriseDAO.getProcessList(conn, cntrlPtCertForm);
				CntrlPtCertEnterpriseDAO.getUserAccess(conn, cntrlPtCertForm);	
				
				//Certify control processes based on selection criteria
				CntrlPtCertEnterpriseDAO.certifyProcessAll(conn, cntrlPtCertViewList, cntrlPtCertForm);
				conn.commit();
				
				//Retrieve control processes from database where cert ind = "Y" 
				cntrlPtCertForm.setCertInd("Y");
				CntrlPtCertEnterpriseDAO.getCntrlPtCertViewList(conn, cntrlPtCertForm, cntrlPtCertForm.getStartDate(), cntrlPtCertForm.getEndDate(), cntrlPtCertForm.getStateDesc(), cntrlPtCertForm.getProcess(), cntrlPtCertForm.getCertInd(), cntrlPtCertForm.getIssueInd());	
				logger.debug("Finished process CntrlPtCertService.cntrlPtCertCertify(All).");
			} else{			
				conn = ConnectionManager.getConnection(region);				
				
				CntrlPtCertDAO.getStateList(conn, cntrlPtCertForm);
				CntrlPtCertDAO.getProcessList(conn, cntrlPtCertForm);
				
				//Certify control processes based on selection criteria
				CntrlPtCertDAO.certifyProcessAll(conn, cntrlPtCertViewList, cntrlPtCertForm);
				conn.commit();
				
				//Retrieve control processes from database where cert ind = "Y" 
				cntrlPtCertForm.setCertInd("Y");
				CntrlPtCertDAO.getCntrlPtCertViewList(conn, cntrlPtCertForm, cntrlPtCertForm.getStartDate(), cntrlPtCertForm.getEndDate(), cntrlPtCertForm.getStateDesc(), cntrlPtCertForm.getProcess(), cntrlPtCertForm.getCertInd(), cntrlPtCertForm.getIssueInd());	
				logger.debug("Finished process CntrlPtCertService.cntrlPtCertCertify.");
			}
		} catch (SQLException sqle) {
			throw new RABCException("SQL exception in creating a connection or committing transaction: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return cntrlPtCertForm;
	}
	
	/**This is the method called to access the DAO to either add a control process certification if it
	 * doesn't exist or update an existing one.
	 * 
	 * @param cntrlPtCertForm  a blank CntrlPtCertForm with userId & region populated
	 * @return cntrlPtCertForm  a CntrlPtCertForm with data populated from the DAO
	 */
	protected static CntrlPtCertForm cntrlPtCertAdd(CntrlPtCertForm cntrlPtCertForm) throws RABCException {
		logger.debug("Starting process CntrlPtCertService.cntrlPtCertAdd.");
		Connection conn = null;
		try {
			String region = cntrlPtCertForm.getRegion();
			if(cntrlPtCertForm.getRegion().equals("EN")){			
				region = cntrlPtCertForm.getSelectedRegion();	
				CntrlPtCertEnterpriseDAO.getRegionList(cntrlPtCertForm);
			}			
			
			//Check if the request is for multi region or multidays or both go to enterprise add page
			if(region.equalsIgnoreCase("All")){
				conn = ConnectionManager.getConnection("EN");				
			    /*
			     * No need to check for duplicate and go to update page in case of all region
			     * Set run date. All other fields are already set.
			     */
				if (cntrlPtCertForm.getRunDate() == ""){
					cntrlPtCertForm.setRunDate(cntrlPtCertForm.getStartDate());
				}
				if (cntrlPtCertForm.getEndRunDate() == ""){
					cntrlPtCertForm.setEndRunDate(cntrlPtCertForm.getEndDate());
				}
				
				//Set StateDesc to All in case of enterprise add page with selected region All
				cntrlPtCertForm.setStateDesc("All");
				
				CntrlPtCertEnterpriseDAO.getStateList(conn, cntrlPtCertForm);
				CntrlPtCertEnterpriseDAO.getProcessList(conn, cntrlPtCertForm);			
				CntrlPtCertEnterpriseDAO.getAlertMsgRevenueAmts(conn, cntrlPtCertForm, region);				
				cntrlPtCertForm.setDispatch("cntrlPtCertAdd");		
				cntrlPtCertForm.setJSAlertMsg(" ");
				CntrlPtCertEnterpriseDAO.getUserAccess(conn, cntrlPtCertForm);				
				
				logger.debug("Finished process CntrlPtCertService.cntrlPtCertAdd(All).");
			} else if (cntrlPtCertForm.getRegion().equals("EN")&& (!cntrlPtCertForm.getStartDate().equals(cntrlPtCertForm.getEndDate()))){
				conn = ConnectionManager.getConnection(region);			
			    /*
			     * No need to check for duplicate and go to update page in case of all region
			     * Set run date. All other fields are already set.
			     */
				if (cntrlPtCertForm.getRunDate() == ""){
					cntrlPtCertForm.setRunDate(cntrlPtCertForm.getStartDate());
				}
				if (cntrlPtCertForm.getEndRunDate() == ""){
					cntrlPtCertForm.setEndRunDate(cntrlPtCertForm.getEndDate());
				}					
				
				CntrlPtCertDAO.getStateList(conn, cntrlPtCertForm);
				CntrlPtCertDAO.getProcessList(conn, cntrlPtCertForm);			
				CntrlPtCertDAO.getAlertMsgRevenueAmts(conn, cntrlPtCertForm);				
				cntrlPtCertForm.setDispatch("cntrlPtCertAdd");		
				cntrlPtCertForm.setJSAlertMsg(" ");
				CntrlPtCertDAO.getUserAccess(conn, cntrlPtCertForm);		
			} else {			
				conn = ConnectionManager.getConnection(region);
				
				if (CntrlPtCertDAO.checkForDup(conn, cntrlPtCertForm) == 0) {
					/*
					 * No duplicate are found in the database, go to the Detail page in Add mode
					 * Set run date. All other fields are already set.
					 */
					if (cntrlPtCertForm.getRunDate() == ""){
						cntrlPtCertForm.setRunDate(cntrlPtCertForm.getStartDate());
						cntrlPtCertForm.setEndRunDate(cntrlPtCertForm.getStartDate());
					}
					CntrlPtCertDAO.getStateList(conn, cntrlPtCertForm);
					CntrlPtCertDAO.getProcessList(conn, cntrlPtCertForm);					
					CntrlPtCertDAO.getAlertMsgRevenueAmts(conn, cntrlPtCertForm);
					CntrlPtCertDAO.getCntrlPtCertCommentList(conn, cntrlPtCertForm);
					cntrlPtCertForm.setDispatch("cntrlPtCertAdd");		
					cntrlPtCertForm.setJSAlertMsg(" ");
					CntrlPtCertDAO.getUserAccess(conn, cntrlPtCertForm);
				} else {
					//Duplicate is found in the database, go to the Detail page in Update mode
					cntrlPtCertForm.setTempCertInd(cntrlPtCertForm.getCertInd());
					cntrlPtCertForm.setTempIssueInd(cntrlPtCertForm.getIssueInd());	
					CntrlPtCertDAO.getRevenueAmts(conn, cntrlPtCertForm);
					cntrlPtCertForm.setTempCreditRevImpact(cntrlPtCertForm.getCreditRevImpact());
					cntrlPtCertForm.setTempDebitRevImpact(cntrlPtCertForm.getDebitRevImpact());
					cntrlPtCertForm.setTempLostRevImpact(cntrlPtCertForm.getLostRevImpact());
					CntrlPtCertDAO.getCntrlPtCertCommentList(conn, cntrlPtCertForm);
					cntrlPtCertForm.setDispatch("cntrlPtCertDetails");
					cntrlPtCertForm.setJSAlertMsg("dup");
					CntrlPtCertDAO.getUserAccess(conn, cntrlPtCertForm);
				}
				logger.debug("Finished process CntrlPtCertService.cntrlPtCertAdd.");
			}
		} catch (SQLException sqle) {
			throw new RABCException("SQL exception in creating a connection: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return cntrlPtCertForm;
	}
	
	/**This is the method called to access the DAO to retrieve information that will be displayed on the details
	 * page.
	 * 
	 * @param cntrlPtCertForm  a blank CntrlPtCertForm with userId & region populated
	 * @return cntrlPtCertForm  a CntrlPtCertForm with data populated from the DAO
	 */
	protected static CntrlPtCertForm cntrlPtCertDetails(CntrlPtCertForm cntrlPtCertForm) throws RABCException {
		logger.debug("Starting process CntrlPtCertService.cntrlPtCertDetails.");
		Connection conn = null;
		try {		
			String region = cntrlPtCertForm.getRegion();
			if(cntrlPtCertForm.getRegion().equals("EN")){
				region = cntrlPtCertForm.getSelectedRegion();				
			}			
			
			/* There is no need to check for 'All' option in selected region as information displayed ondetails page
			 * is applicable to one record in view table displayed on main page.
			 */
			conn = ConnectionManager.getConnection(region);				
			cntrlPtCertForm.setTempCertInd(cntrlPtCertForm.getCertInd());
			cntrlPtCertForm.setTempIssueInd(cntrlPtCertForm.getIssueInd());	
			CntrlPtCertDAO.getUserAccess(conn, cntrlPtCertForm);
			CntrlPtCertDAO.getRevenueAmts(conn, cntrlPtCertForm);
			cntrlPtCertForm.setTempCreditRevImpact(cntrlPtCertForm.getCreditRevImpact());
			cntrlPtCertForm.setTempDebitRevImpact(cntrlPtCertForm.getDebitRevImpact());
			cntrlPtCertForm.setTempLostRevImpact(cntrlPtCertForm.getLostRevImpact());
			CntrlPtCertDAO.getCntrlPtCertCommentList(conn, cntrlPtCertForm);
			cntrlPtCertForm.setJSAlertMsg(" ");
			logger.debug("Finished process CntrlPtCertService.cntrlPtCertDetails.");			
		} catch (SQLException sqle) {
			throw new RABCException("SQL exception in creating a connection: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return cntrlPtCertForm;
	}	
	
	
	/**This is the method called to access the DAO to insert or update Control Process Certification data.
	 * 
	 * @param cntrlPtCertForm  a blank CntrlPtCertForm with userId & region populated
	 * @return cntrlPtCertForm  a CntrlPtCertForm with data populated from the DAO
	 */
	protected static CntrlPtCertForm cntrlPtCertInsert(CntrlPtCertForm cntrlPtCertForm) throws RABCException {
		logger.debug("Starting process CntrlPtCertService.cntrlPtCertInsert.");
		Connection conn = null;
		try {
			String region = cntrlPtCertForm.getRegion();
			if(cntrlPtCertForm.getRegion().equals("EN")){
				region = cntrlPtCertForm.getSelectedRegion();
				CntrlPtCertEnterpriseDAO.getRegionList(cntrlPtCertForm);
			}
			
		    //Check if the request is for multi region or multidays or both add multiple rows
			if(region.equalsIgnoreCase("All")){
				conn = ConnectionManager.getConnection("EN");	
				
				//Set run date. All other fields are already set.
				if (cntrlPtCertForm.getRunDate() == ""){
					cntrlPtCertForm.setRunDate(cntrlPtCertForm.getStartDate());
				}
				if (cntrlPtCertForm.getEndRunDate() == ""){
					cntrlPtCertForm.setEndRunDate(cntrlPtCertForm.getEndDate());
				}			
				
				if (CntrlPtCertEnterpriseDAO.checkForDup(conn, cntrlPtCertForm, region) == 0) {
					//No duplicate found. Insert new data into database and go to the Main page.
					CntrlPtCertEnterpriseDAO.getUserAccess(conn, cntrlPtCertForm);
					CntrlPtCertEnterpriseDAO.getStateList(conn, cntrlPtCertForm);
					CntrlPtCertEnterpriseDAO.getProcessList(conn, cntrlPtCertForm);
					//1. Insert process values to RABC_CNTRL_PROCESS_CERT and 2. Insert comments values to RABC_CNTRL_PROC_CERT_COMMENT
					CntrlPtCertEnterpriseDAO.insertProcess(conn, cntrlPtCertForm, region);
					//Insert values to RABC_CNTRL_PROC_CERT_COMMENT
								        
					// initialize cntrlPtCertForm main page fields
					cntrlPtCertForm.setStartDate("");
					cntrlPtCertForm.setEndDate("");
					cntrlPtCertForm.setStateDesc("");
					cntrlPtCertForm.setProcess("");
					cntrlPtCertForm.setCertInd("A");
					cntrlPtCertForm.setIssueInd("A");				
					cntrlPtCertForm.setForwardType("CntrlPtCertMain");
				} else {
					//Duplicate is found in the database. 					
					CntrlPtCertEnterpriseDAO.getUserAccess(conn, cntrlPtCertForm);	
					CntrlPtCertEnterpriseDAO.getStateList(conn, cntrlPtCertForm);
					CntrlPtCertEnterpriseDAO.getProcessList(conn, cntrlPtCertForm);
					CntrlPtCertEnterpriseDAO.getAlertMsgRevenueAmts(conn, cntrlPtCertForm, region);										
					cntrlPtCertForm.setDispatch("cntrlPtCertAdd");
					cntrlPtCertForm.setJSAlertMsg("dupent");
					CntrlPtCertEnterpriseDAO.getUserAccess(conn, cntrlPtCertForm); 
					cntrlPtCertForm.setForwardType("CntrlPtCertDetl");
				}
				logger.debug("Finished process CntrlPtCertService.cntrlPtCertInsert.");
			} else if (cntrlPtCertForm.getRegion().equals("EN")&& (!cntrlPtCertForm.getRunDate().equals(cntrlPtCertForm.getEndRunDate()))) {
				conn = ConnectionManager.getConnection(region);
				if (CntrlPtCertEnterpriseDAO.checkForDup(conn, cntrlPtCertForm, region) == 0) {
					//	No duplicate found. Insert new data into database and go to the Main page.
					CntrlPtCertDAO.getUserAccess(conn, cntrlPtCertForm);
					CntrlPtCertDAO.getStateList(conn, cntrlPtCertForm);
					CntrlPtCertDAO.getProcessList(conn, cntrlPtCertForm);
					//1. Insert process values to RABC_CNTRL_PROCESS_CERT and 2. Insert comments values to RABC_CNTRL_PROC_CERT_COMMENT
					CntrlPtCertEnterpriseDAO.insertProcess(conn, cntrlPtCertForm, region);
					//Insert values to RABC_CNTRL_PROC_CERT_COMMENT
								        
					// initialize cntrlPtCertForm main page fields
					cntrlPtCertForm.setStartDate("");
					cntrlPtCertForm.setEndDate("");
					cntrlPtCertForm.setStateDesc("");
					cntrlPtCertForm.setProcess("");
					cntrlPtCertForm.setCertInd("A");
					cntrlPtCertForm.setIssueInd("A");				
					cntrlPtCertForm.setForwardType("CntrlPtCertMain");

				} else {
					CntrlPtCertDAO.getUserAccess(conn, cntrlPtCertForm);
					CntrlPtCertDAO.getStateList(conn, cntrlPtCertForm);
					CntrlPtCertDAO.getProcessList(conn, cntrlPtCertForm);
					CntrlPtCertEnterpriseDAO.getAlertMsgRevenueAmts(conn, cntrlPtCertForm, region);
					cntrlPtCertForm.setDispatch("cntrlPtCertAdd");
					cntrlPtCertForm.setJSAlertMsg("dupent");
					CntrlPtCertDAO.getUserAccess(conn, cntrlPtCertForm);
					cntrlPtCertForm.setForwardType("CntrlPtCertDetl");		
				}
				logger.debug("Finished process CntrlPtCertService.cntrlPtCertInsert.");
			} else {
				conn = ConnectionManager.getConnection(region);
				
				if (CntrlPtCertDAO.checkForDup(conn, cntrlPtCertForm) == 0) {
					//No duplicate found. Insert new data into database and go to the Main page.
					CntrlPtCertDAO.getUserAccess(conn, cntrlPtCertForm);
					CntrlPtCertDAO.insertProcess(conn, cntrlPtCertForm);
					//Insert values to RABC_CNTRL_PROC_CERT_COMMENT
					if (cntrlPtCertForm.getCommentSubject() != null && !cntrlPtCertForm.getCommentSubject().trim().equals("") && cntrlPtCertForm.getCommentDetail() != null && !cntrlPtCertForm.getCommentDetail().trim().equals("")){
						CntrlPtCertDAO.insertComments(conn, cntrlPtCertForm);
					}
					conn.commit();										        
					// initialize cntrlPtCertForm main page fields
					cntrlPtCertForm.setStartDate("");
					cntrlPtCertForm.setEndDate("");
					cntrlPtCertForm.setStateDesc("");
					cntrlPtCertForm.setProcess("");
					cntrlPtCertForm.setCertInd("A");
					cntrlPtCertForm.setIssueInd("A");
					CntrlPtCertDAO.getStateList(conn, cntrlPtCertForm);
					CntrlPtCertDAO.getProcessList(conn, cntrlPtCertForm);
					cntrlPtCertForm.setForwardType("CntrlPtCertMain");
				} else {
					//Duplicate is found in the database. Go to the Detail page in Update mode.
					cntrlPtCertForm.setTempCertInd(cntrlPtCertForm.getCertInd());
					cntrlPtCertForm.setTempIssueInd(cntrlPtCertForm.getIssueInd());	
					CntrlPtCertDAO.getRevenueAmts(conn, cntrlPtCertForm);
					cntrlPtCertForm.setTempCreditRevImpact(cntrlPtCertForm.getCreditRevImpact());
					cntrlPtCertForm.setTempDebitRevImpact(cntrlPtCertForm.getDebitRevImpact());
					cntrlPtCertForm.setTempLostRevImpact(cntrlPtCertForm.getLostRevImpact());
					CntrlPtCertDAO.getCntrlPtCertCommentList(conn, cntrlPtCertForm);
					cntrlPtCertForm.setDispatch("cntrlPtCertDetails");
					cntrlPtCertForm.setJSAlertMsg("dup");
					CntrlPtCertDAO.getUserAccess(conn, cntrlPtCertForm);
					cntrlPtCertForm.setForwardType("CntrlPtCertDetl");
				}
				logger.debug("Finished process CntrlPtCertService.cntrlPtCertInsert.");
			}
			
		} catch (SQLException sqle) {
			throw new RABCException("SQL exception in creating a connection or committing the transaction: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return cntrlPtCertForm;
	}
	
	/**This is the method called to access the DAO to update process data and then send the user back to the 
	 * main Control Process Certification page.
	 * 
	 * @param cntrlPtCertForm  a blank CntrlPtCertForm with userId & region populated
	 * @return cntrlPtCertForm  a CntrlPtCertForm with data populated from the DAO
	 */
	protected static CntrlPtCertForm cntrlPtCertUpdate(CntrlPtCertForm cntrlPtCertForm) throws RABCException {
		logger.debug("Starting process CntrlPtCertService.cntrlPtCertUpdate.");
		Connection conn = null;
		try {
			String region = cntrlPtCertForm.getRegion();
			if(cntrlPtCertForm.getRegion().equals("EN")){
				region = cntrlPtCertForm.getSelectedRegion();
				CntrlPtCertEnterpriseDAO.getRegionList(cntrlPtCertForm);
			}
			
			/* There is no need to check for 'All' option in selected region as information displayed ondetails page
			 * is applicable to one record in view table displayed on main page.
			 */	
			conn = ConnectionManager.getConnection(region);	
			
			CntrlPtCertDAO.getUserAccess(conn, cntrlPtCertForm);
			CntrlPtCertDAO.updateProcess(conn, cntrlPtCertForm);
			
			//Insert values to RABC_CNTRL_PROC_CERT_COMMENT
			if (cntrlPtCertForm.getCommentSubject() != null && !cntrlPtCertForm.getCommentSubject().trim().equals("") && cntrlPtCertForm.getCommentDetail() != null && !cntrlPtCertForm.getCommentDetail().trim().equals(""))
				CntrlPtCertDAO.insertComments(conn, cntrlPtCertForm);
			conn.commit();
			
			// initialize cntrlPtCertForm main page fields
			cntrlPtCertForm.setStartDate("");
			cntrlPtCertForm.setEndDate("");
			cntrlPtCertForm.setStateDesc("");
			cntrlPtCertForm.setProcess("");
			cntrlPtCertForm.setCertInd("A");
			cntrlPtCertForm.setIssueInd("A");
			CntrlPtCertDAO.getStateList(conn, cntrlPtCertForm);
			CntrlPtCertDAO.getProcessList(conn, cntrlPtCertForm);
			logger.debug("Finished process CntrlPtCertService.cntrlPtCertUpdate.");			
		} catch (SQLException sqle) {
			throw new RABCException("SQL exception in creating a connection or committing the transaction: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return cntrlPtCertForm;
	}
	
	/**This is the method called to access the DAO to retrieve data when doing a "hard" reset.
	 * 
	 * @param cntrlPtCertForm  a blank CntrlPtCertForm with userId & region populated
	 * @return cntrlPtCertForm  a CntrlPtCertForm with data populated from the DAO
	 */
	protected static CntrlPtCertForm cntrlPtCertHardReset(CntrlPtCertForm cntrlPtCertForm) throws RABCException {
		logger.debug("Starting process CntrlPtCertService.cntrlPtCertHardReset.");
		Connection conn = null;
		try {
			String region = cntrlPtCertForm.getRegion();
			if(cntrlPtCertForm.getRegion().equals("EN")){
				region = cntrlPtCertForm.getSelectedRegion();
				CntrlPtCertEnterpriseDAO.getRegionList(cntrlPtCertForm);
			}
			
			if(region.equalsIgnoreCase("All")) {
				conn = ConnectionManager.getConnection("EN");				
				
				cntrlPtCertForm.setSelectedRegion("All");
				cntrlPtCertForm.setRunDate(cntrlPtCertForm.getStartDate());
				cntrlPtCertForm.setEndRunDate(cntrlPtCertForm.getEndDate());
				cntrlPtCertForm.setStateDesc("All");
				cntrlPtCertForm.setProcess("All");
				cntrlPtCertForm.setCertInd("N");
				cntrlPtCertForm.setIssueInd("N");
				cntrlPtCertForm.setCreditRevImpact(0);
				cntrlPtCertForm.setDebitRevImpact(0);
				cntrlPtCertForm.setLostRevImpact(0);
				cntrlPtCertForm.setCommentSubject("");
				cntrlPtCertForm.setCommentDetail("");
				cntrlPtCertForm.setJSAlertMsg(" ");
				CntrlPtCertEnterpriseDAO.getStateList(conn, cntrlPtCertForm);
				CntrlPtCertEnterpriseDAO.getProcessList(conn, cntrlPtCertForm);
				CntrlPtCertEnterpriseDAO.getAlertMsgRevenueAmts(conn, cntrlPtCertForm, region);			
				CntrlPtCertEnterpriseDAO.getUserAccess(conn, cntrlPtCertForm);	
				logger.debug("Finished process CntrlPtCertService.cntrlPtCertHardReset(Multi Region).");
			} else if (cntrlPtCertForm.getRegion().equals("EN")&& (!cntrlPtCertForm.getRunDate().equals(cntrlPtCertForm.getEndRunDate()))) {
				conn = ConnectionManager.getConnection(region);				
				
				cntrlPtCertForm.setSelectedRegion(region);
				cntrlPtCertForm.setRunDate(cntrlPtCertForm.getStartDate());
				cntrlPtCertForm.setEndRunDate(cntrlPtCertForm.getEndDate());
				cntrlPtCertForm.setStateDesc("All");
				cntrlPtCertForm.setProcess("All");
				cntrlPtCertForm.setCertInd("N");
				cntrlPtCertForm.setIssueInd("N");
				cntrlPtCertForm.setCreditRevImpact(0);
				cntrlPtCertForm.setDebitRevImpact(0);
				cntrlPtCertForm.setLostRevImpact(0);
				cntrlPtCertForm.setCommentSubject("");
				cntrlPtCertForm.setCommentDetail("");
				cntrlPtCertForm.setJSAlertMsg(" ");
				CntrlPtCertDAO.getStateList(conn, cntrlPtCertForm);
				CntrlPtCertDAO.getProcessList(conn, cntrlPtCertForm);
				CntrlPtCertDAO.getAlertMsgRevenueAmts(conn, cntrlPtCertForm);			
				logger.debug("Finished process CntrlPtCertService.cntrlPtCertHardReset(Multi Days).");
			} else {			
				conn = ConnectionManager.getConnection(region);	
				
				cntrlPtCertForm.setRunDate(cntrlPtCertForm.getStartDate());
				cntrlPtCertForm.setEndRunDate(cntrlPtCertForm.getStartDate());
				cntrlPtCertForm.setStateDesc("All");
				cntrlPtCertForm.setProcess("All");
				cntrlPtCertForm.setCertInd("N");
				cntrlPtCertForm.setIssueInd("N");
				cntrlPtCertForm.setCreditRevImpact(0);
				cntrlPtCertForm.setDebitRevImpact(0);
				cntrlPtCertForm.setLostRevImpact(0);
				cntrlPtCertForm.setCommentSubject("");
				cntrlPtCertForm.setCommentDetail("");
				cntrlPtCertForm.setJSAlertMsg(" ");
				CntrlPtCertDAO.getStateList(conn, cntrlPtCertForm);
				CntrlPtCertDAO.getProcessList(conn, cntrlPtCertForm);
				CntrlPtCertDAO.getAlertMsgRevenueAmts(conn, cntrlPtCertForm);
				CntrlPtCertDAO.getCntrlPtCertCommentList(conn, cntrlPtCertForm);
				logger.debug("Finished process CntrlPtCertService.cntrlPtCertHardReset.");
			}
		} catch (SQLException sqle) {
			throw new RABCException("SQL exception in creating a connection: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return cntrlPtCertForm;
	}
	
	/**This is the method called to access the DAO to retrieve data when doing a "soft" reset.
	 * 
	 * @param cntrlPtCertForm  a blank CntrlPtCertForm with userId & region populated
	 * @return cntrlPtCertForm  a CntrlPtCertForm with data populated from the DAO
	 */
	protected static CntrlPtCertForm cntrlPtCertSoftReset(CntrlPtCertForm cntrlPtCertForm) throws RABCException {
		logger.debug("Starting process CntrlPtCertService.cntrlPtCertSoftReset.");
		Connection conn = null;
		try {
			String region = cntrlPtCertForm.getRegion();
			if(cntrlPtCertForm.getRegion().equals("EN")){
				region = cntrlPtCertForm.getSelectedRegion();
				CntrlPtCertEnterpriseDAO.getRegionList(cntrlPtCertForm);
			}
			
			/* There is no need to check for 'All' option in selected region as information displayed on details page
			 * is applicable to one record in view table displayed on main page.
			 */	
			conn = ConnectionManager.getConnection(region);	
			
			CntrlPtCertDAO.getAlertMsgRevenueAmts(conn, cntrlPtCertForm);		
			CntrlPtCertDAO.getCntrlPtCertCommentList(conn, cntrlPtCertForm);
			cntrlPtCertForm.setCertInd(cntrlPtCertForm.getTempCertInd());
			cntrlPtCertForm.setIssueInd(cntrlPtCertForm.getTempIssueInd());
			cntrlPtCertForm.setCreditRevImpact(cntrlPtCertForm.getTempCreditRevImpact());
			cntrlPtCertForm.setDebitRevImpact(cntrlPtCertForm.getTempDebitRevImpact());
			cntrlPtCertForm.setLostRevImpact(cntrlPtCertForm.getTempLostRevImpact());
			cntrlPtCertForm.setCommentSubject("");
			cntrlPtCertForm.setCommentDetail("");
			cntrlPtCertForm.setJSAlertMsg(" ");
			logger.debug("Finished process CntrlPtCertService.cntrlPtCertSoftReset.");		
		} catch (SQLException sqle) {
			throw new RABCException("SQL exception in creating a connection: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return cntrlPtCertForm;
	}
	
	/**This is the method called to access the DAO to reset the page if the "cancel" button is pressed.
	 * 
	 * @param cntrlPtCertForm  a blank CntrlPtCertForm with userId & region populated
	 * @return cntrlPtCertForm  a CntrlPtCertForm with data populated from the DAO
	 */
	protected static CntrlPtCertForm cntrlPtCertCancel(CntrlPtCertForm cntrlPtCertForm) throws RABCException {
		logger.debug("Starting process CntrlPtCertService.cntrlPtCertCancel.");
		Connection conn = null;
		try {
			String region = cntrlPtCertForm.getRegion();
			if(cntrlPtCertForm.getRegion().equals("EN")){
				region = cntrlPtCertForm.getSelectedRegion();
				CntrlPtCertEnterpriseDAO.getRegionList(cntrlPtCertForm);
			}
			
			if(region.equalsIgnoreCase("All")){
				conn = ConnectionManager.getConnection("EN");	
				
				cntrlPtCertForm.setStartDate("");
				cntrlPtCertForm.setEndDate("");
				cntrlPtCertForm.setStateDesc("");
				cntrlPtCertForm.setProcess("");
				cntrlPtCertForm.setCertInd("A");
				cntrlPtCertForm.setIssueInd("A");
				cntrlPtCertForm.setJSAlertMsg(" ");
				CntrlPtCertEnterpriseDAO.getStateList(conn, cntrlPtCertForm);
				CntrlPtCertEnterpriseDAO.getProcessList(conn, cntrlPtCertForm);
				CntrlPtCertEnterpriseDAO.getUserAccess(conn, cntrlPtCertForm);			
				logger.debug("Finished process CntrlPtCertService.cntrlPtCertCancel(All).");
			}
			else{
				conn = ConnectionManager.getConnection(region);
				
				cntrlPtCertForm.setStartDate("");
				cntrlPtCertForm.setEndDate("");
				cntrlPtCertForm.setStateDesc("");
				cntrlPtCertForm.setProcess("");
				cntrlPtCertForm.setCertInd("A");
				cntrlPtCertForm.setIssueInd("A");
				cntrlPtCertForm.setJSAlertMsg(" ");
				CntrlPtCertDAO.getStateList(conn, cntrlPtCertForm);
				CntrlPtCertDAO.getProcessList(conn, cntrlPtCertForm);
				CntrlPtCertDAO.getUserAccess(conn, cntrlPtCertForm);
				logger.debug("Finished process CntrlPtCertService.cntrlPtCertCancel.");
			}
		} catch (SQLException sqle) {
			throw new RABCException("SQL exception in creating a connection: ", sqle);
		} catch (NamingException ne) {
			throw new RABCException("Naming exception in creating a connection: ", ne);
		} finally {
			JDBCUtil.closeConnection(conn);
		}
		return cntrlPtCertForm;
	}
}
