/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.rpt;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.text.MessageFormat;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.att.bac.rabc.PickList;
import com.att.bac.rabc.RABCConstantsLists;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.StaticDataLoader;
import com.att.bac.rabc.WebHeaderLink;
import com.att.bac.rabc.WebHeaderLinkDAO;

/**
 * This class represents the data object that holds the attributes required
 * to represent the general filter shown on alert report page.
 * 
 * @author Nalina Pandiyan - NP5434
 */
public class AlertsGenFilterTemplate {
	private static final Logger logger = Logger.getLogger(AlertsGenFilterTemplate.class);
	public static final String DEFAULT_LABEL_RESOURCES = "com.att.bac.rabc.LabelResources";
	private static ResourceBundle labelProperties;
	private final static String PAGE_14 = "RABCPSF00014";
	private static final String PAGE_12 = "RABCPSF00012";
	
	private AlertReportParameters alertReportParameters = null;
	private Connection connection = null;
	private List failureList = null;
	private AlertReportView alertReportView = null;
	private HashMap alertRuleMap = null;
	private List qrySevereLvlIndList = null;
	private List alertKey1List = new ArrayList();

	private final static String qryHeader = "SELECT distinct * FROM  rabc_alert_rule_presn_rule  WHERE presn_id in ({0}) and webid = ''{1}''";
	private final static String qrySevereLvlInd = "SELECT h.alert_key1, h.alert_key2,h.alert_key3,h.alert_key4,h.alert_key5," +
													" h.alert_item,h.alert_data,h.alert_actual_data,	h.proc_date,h.file_seq_num FROM  rabc_alert_hist h {0} " +
													" WHERE h.parti_ref_id in ( {1} )  and h.PRESN_CD IN (''A'', ''B'') and h.proc_date >= {2} and " +
													" h.proc_date <= {3}  {4} Minus	 SELECT  h.alert_key1, h.alert_key2,h.alert_key3, h.alert_key4, " +
													" h.alert_key5, h.alert_item, h.alert_data, h.alert_actual_data, h.proc_date, h.file_seq_num	FROM " +
													" rabc_alert_hist h,rabc_alert_msg m	 WHERE  h.parti_ref_id in ({5}) and h.PRESN_CD IN (''A'', ''B'') and " +
													" m.alert_rule = ''{6}'' and m.alert_item= h.alert_item and ((h.file_seq_num = m.file_seq_num ) or " +
													" (h.file_seq_num is null and  m.file_seq_num is null)) and h.alert_key1 = m.alert_data1 and " +
													" h.alert_actual_data = m.alert_actual and h.alert_data = m.alert_data and h.proc_date >= {7}" +
													" and h.proc_date <= {8} and h.proc_date=m.proc_date "; 
	private final static String qryDivisionNamesList = "SELECT distinct {0} as divisionNames FROM  rabc_alert_hist h,rabc_division an WHERE h.parti_ref_id in ({1}) " +
														" and h.PRESN_CD IN (''A'',''B'') {2} and {3} = an.division " ;
	private final static String qryKey1List = "SELECT distinct alert_key1 FROM  rabc_alert_hist h WHERE h.parti_ref_id in {0} and h.PRESN_CD IN (''A'', ''B'') {1} ";
	
	private final static String qryTopHeaderLinks = "SELECT PRESN_ID, WEBID, SEQ_NUM,upper(LINK_PRESN_NAME)  LINK_PRESN_NAME, LINK_TO_PGM, LINK_PRESN_ID FROM RABC_WEB_HEADER_LINK " +
													"WHERE webid = ''{0}'' AND (PRESN_ID = {1} OR PRESN_ID IS NULL) " +   
													"ORDER BY SEQ_NUM";
	private final static String qryHeaderText = " SELECT * FROM RABC_PRESN_HEADER WHERE {0} AND WEBID = ''{1}'' ";

	/**
	 * This method is used as a template - use to configure the label resources properties file.
	 */
	public AlertsGenFilterTemplate() {
		try {
			labelProperties = ResourceBundle.getBundle(DEFAULT_LABEL_RESOURCES);
		} catch (MissingResourceException e) {
			logger.error("Unable to configure properties file. Exception details: " + e.getMessage(), e);
		}
	}

	/**
	 * This is a method to get the label for the passed key.
	 * 
	 * @param key
	 * @return String
	 */
	public static String getLabel(String key) {
		try {
			return labelProperties.getString(key);
		} catch (MissingResourceException e) {
			logger.error("Unable to configure properties file. Exception details: " + e.getMessage(), e);
			return null;
		}
	}

	/**
	 * This method is used to return the object of AlertsGenFilterTemplate class.
	 * 
	 * @return AlertsGenFilterTemplate
	 */
	public static AlertsGenFilterTemplate getAlertsGenFilterTemplate() {
		return new AlertsGenFilterTemplate();
	}

	
	
	/**
	 * @param alertReportParameters The alertReportParameters to set.
	 */
	public void setAlertReportParameters(AlertReportParameters alertReportParameters) {
		this.alertReportParameters = alertReportParameters;
	}

	/**
	 * @param connection The connection to set.
	 */
	public void setConnection(Connection connection) {
		this.connection = connection;
	}

	/**
	 * @param failureList The failureList to set.
	 */
	public void setFailureList(List failureList) {
		this.failureList = failureList;
	}

	/**
	 * @param alertReportView The alertReportView to set.
	 */
	public void setAlertReportView(AlertReportView alertReportView) {
		this.alertReportView = alertReportView;
	}

	/**
	 * @param alertRuleMap The alertRuleMap to set.
	 */
	public void setAlertRuleMap(HashMap alertRuleMap) {
		this.alertRuleMap = alertRuleMap;
	}

	/**
	 * This method establishes filter from each alert rule.
	 */
	public void setGeneralFilter() {
		Set set = null; 
		Iterator iter = null; 
		AlertsReportSQLService.AlertRuleInfoStruct alertRuleInfo = null;
		AlertsGenFilterTemplate.AlertRuleInfoStruct genAlertRuleInfo = null;
		AlertReportDivision alertReportDivision = null;
		String divisions = null;
		String division = null;
		String divisionDesc = null;
		String selectedDivision = null;
		List divisionNameList = null;
		
		String region = alertReportParameters.getRegion();
		
		int index = 0;
		
		logger.debug("Establishing filter from each alert rule ...");
		if (alertReportParameters.getWebPageId().equals(PAGE_12)) {
			genAlertRuleInfo = build();
			processFilter(genAlertRuleInfo, region);
		} else {
			set = alertRuleMap.keySet();
			iter = set.iterator();
			while(iter.hasNext()) {			
				alertRuleInfo = (AlertsReportSQLService.AlertRuleInfoStruct) alertRuleMap.get((String)iter.next());
				logger.debug("Establishing filter for alert rule = " + alertRuleInfo.alertRule);
				genAlertRuleInfo = build(alertRuleInfo);
				processFilter(genAlertRuleInfo, region);
				if (!failureList.isEmpty()) return;
			}
		}
		alertReportDivision = new AlertReportDivision("Show All", "Show All", false);
		if (alertReportParameters.getDivisionName().equals("ALL")){
			alertReportDivision.setSelected(new Boolean(true));
		} 
		divisionNameList = new ArrayList();
		divisionNameList.add(alertReportDivision);

		selectedDivision = alertReportParameters.getDivisionName() + " ";		
		divisions = alertReportParameters.getDivisions();
		while (divisions.length() > 0) {
			division = divisions;

			index = divisions.indexOf(",");
			if (index != -1) {				
				division = divisions.substring(0, index);
			}
			divisionDesc = StaticDataLoader.getDivisionDesc(region, division);
			divisionDesc = RABCConstantsLists.getRABCConstantsLists().getText(divisionDesc, false);
			alertReportDivision = new AlertReportDivision(division, divisionDesc, false);
			if (selectedDivision.indexOf(division + " ") != -1){
				alertReportDivision.setSelected(new Boolean(true));
			}
			divisionNameList.add(alertReportDivision);
			if (index == -1) {
				divisions = "";
			} else {
				divisions = divisions.substring(index + 1);
			}
		}
		alertReportParameters.setDivisionList(divisionNameList);
	}
	/**
	 * This is a private method to return genAlertRuleInfo.
	 * 
	 * @param alertRuleInfo
	 * @return genAlertRuleInfo
	 */
	private AlertsGenFilterTemplate.AlertRuleInfoStruct build(AlertsReportSQLService.AlertRuleInfoStruct alertRuleInfo) {
		AlertsGenFilterTemplate.AlertRuleInfoStruct genAlertRuleInfo = new AlertsGenFilterTemplate.AlertRuleInfoStruct();
		genAlertRuleInfo.multiColumnList = null;
		genAlertRuleInfo.columns = null;
		genAlertRuleInfo.nbrOfKeyCols = alertRuleInfo.nbrOfKeyCols;
		genAlertRuleInfo.calcCnt = alertRuleInfo.calcCnt;
		genAlertRuleInfo.seqCnt = alertRuleInfo.seqCnt;
		genAlertRuleInfo.totCnt = alertRuleInfo.totCnt;
		genAlertRuleInfo.presnId = alertRuleInfo.presnId;
		genAlertRuleInfo.partiRefId = alertRuleInfo.partiRefId; 
		genAlertRuleInfo.alertKeyLvl = alertRuleInfo.alertKeyLvl; 
		genAlertRuleInfo.divisionNameKeyLvl = alertRuleInfo.divisionNameKeyLvl;
		genAlertRuleInfo.alertRule = new String(alertRuleInfo.alertRule);
		genAlertRuleInfo.partiRefIds = new String(alertRuleInfo.partiRefIds);
		genAlertRuleInfo.alertRules = new String(alertRuleInfo.alertRules);
		genAlertRuleInfo.sumyPresnNames = null;
		return genAlertRuleInfo;
	}

	/**
	 * Private method to return genAlertRuleInfo.
	 * 
	 * @return genAlertRuleInfo
	 */
	private AlertsGenFilterTemplate.AlertRuleInfoStruct build() {
		AlertsGenFilterTemplate.AlertRuleInfoStruct genAlertRuleInfo = new AlertsGenFilterTemplate.AlertRuleInfoStruct();
		genAlertRuleInfo.multiColumnList = null;
		genAlertRuleInfo.columns = null;
		genAlertRuleInfo.nbrOfKeyCols = alertReportParameters.getNbrOfKeys();
		genAlertRuleInfo.calcCnt = alertReportParameters.getCalcCnt();
		genAlertRuleInfo.seqCnt = alertReportParameters.getSeqCnt();
		genAlertRuleInfo.totCnt = alertReportParameters.getTotCnt();
		genAlertRuleInfo.presnId = alertReportParameters.getPresnId().intValue();
		genAlertRuleInfo.partiRefId = alertReportParameters.getPartiRefId().intValue(); 
		genAlertRuleInfo.alertKeyLvl = alertReportParameters.getAlertKeyLvl().intValue(); 
		genAlertRuleInfo.divisionNameKeyLvl = alertReportParameters.getDivisionNameKeyLvl().intValue();
		genAlertRuleInfo.alertRule = new String(alertReportParameters.getAlertRule());
		genAlertRuleInfo.partiRefIds = new String("," + alertReportParameters.getPartiRefIds());
		genAlertRuleInfo.alertRules = new String("," + alertReportParameters.getAlertRules());
		genAlertRuleInfo.sumyPresnNames = null;
		return genAlertRuleInfo;
	}

	/**
	 * This method is used to process the filter for each alert rule.
	 * 
	 * @param alertRuleInfo
	 * @param region
	 */
	private void processFilter(AlertsGenFilterTemplate.AlertRuleInfoStruct alertRuleInfo, String region) {
		AlertRulePresenRuleDAO alertRulePresenRuleDAO = new AlertRulePresenRuleDAO();
		AlertRulePresenRule alertRulePresenRule = null;
		List args = new ArrayList();

		List alertKeyList = null;
		List key1List = null;
		String key1Label;
		int i =0;
		int size = 0;
		
		/*if ((alertReportParameters.getSevereLvl() != null) && alertReportParameters.getSevereLvl().intValue() == 0) {
			String qrySevereLvlInd = prepareQrySevereLvlIndSQL(alertRuleInfo);
			qrySevereLvlIndList = executeSevereLvlIndQry(alertRuleInfo, qrySevereLvlInd);
			if (!failureList.isEmpty()) return;
		}*/
		
		if (alertRuleInfo.divisionNameKeyLvl > 0) {
			/*if ((alertReportParameters.getSevereLvl()!= null) && alertReportParameters.getSevereLvl().intValue() == 0) {
				// execute divisionNameListQry based on severe_lvl_ind_query
				alertKeyList = alertKey1List;
			} else {
				// execute divisionNameListQry
			   alertKeyList  = executeDivisionNameListQry(alertRuleInfo);				
			}*/
			alertKeyList = StaticDataLoader.getDivisionsByRegion(alertReportParameters.getRegion());
		}
		if (!failureList.isEmpty()) return;

		if (alertRuleInfo.divisionNameKeyLvl > 1) {
			if ((alertReportParameters.getSevereLvl()!=null) && alertReportParameters.getSevereLvl().intValue() != 0) {
				// execute Key1ListQry
				key1List = executeKey1ListQry(alertRuleInfo);
			} else {
				// execute Key1ListQry based on severe_lvl_ind_query
				key1List = prepareDivisionNameListQry();
			}
			if (key1List.size() > alertReportParameters.getKey1NameCount()) {
				alertReportParameters.setKey1NameCount(key1List.size());
			}
		}
		size = 0;
		if (alertKeyList != null) {
			size = alertKeyList.size();
		}
		for(i=0;i<size;i++) {
			alertReportParameters.addDivision(((PickList) alertKeyList.get(i)).getKey());
		}

		// execute HeaderQry
		// if already set, then return
		if ((alertReportParameters.getDivisionNameLabel() != null) && (alertReportParameters.getKey1Label() != null)) return;
		
		alertRulePresenRuleDAO = new AlertRulePresenRuleDAO();
		alertRulePresenRule = null;
		args = new ArrayList();
		args.add(new Integer(alertRuleInfo.presnId).toString());
		args.add(alertReportParameters.getWebPageId());
		List alertRulePresenRuleList =  alertRulePresenRuleDAO.get(connection, failureList, args, qryHeader);
		if (!failureList.isEmpty()) return;
		if (!alertRulePresenRuleList.isEmpty()) {
			alertRulePresenRule = (AlertRulePresenRule) alertRulePresenRuleList.get(0);
			// divisionNameLabel
			if (alertRuleInfo.divisionNameKeyLvl > 0) {
				alertReportParameters.setDivisionNameLabel(RABCConstantsLists.getRABCConstantsLists().getText(new String(alertRulePresenRule.getKeyHeaderAt(alertRuleInfo.divisionNameKeyLvl -1)), false));
				if (alertReportParameters.getDivisionNameLabel().equals("")) {
					alertReportParameters.setDivisionNameLabel(getLabel("alertReport.label.divisionNameHeader"));
				}
			}
			// key1Label
			if (alertRuleInfo.divisionNameKeyLvl > 1) {
				key1Label = alertRulePresenRule.getKeyHeaderAt(0);
				if (key1Label.equals("")) key1Label = getLabel("alertReport.label.key1Header");
				alertReportParameters.setKey1Label(new String(""));
				if (key1List.size() > 0) {
					alertReportParameters.setKey1Label(RABCConstantsLists.getRABCConstantsLists().getText1(key1Label, false));
				}
			}
			
			//key2Label
			if((alertReportParameters.getCntrlPtCd()==null) || (alertReportParameters.getCntrlPtCd()!=null && alertReportParameters.getCntrlPtCd().equals(""))){
				if ((alertReportParameters.getAlertKeyLvl() != null) && (alertReportParameters.getAlertKeyLvl().intValue() > 1)) {
					alertReportParameters.setKey2Label(RABCConstantsLists.getRABCConstantsLists().getText1(new String(alertRulePresenRule.getKeyHeaderAt(1)), false));
				}
			}
			
			//key3Label --- Added to filter the page 11 and 14 on key3 (phase II change)
			if((alertReportParameters.getCntrlPtCd()==null) || (alertReportParameters.getCntrlPtCd()!=null && alertReportParameters.getCntrlPtCd().equals(""))){
				if ((alertReportParameters.getAlertKeyLvl() != null) && (alertReportParameters.getAlertKeyLvl().intValue() > 2)) {
					alertReportParameters.setKey3Label(RABCConstantsLists.getRABCConstantsLists().getText1(new String(alertRulePresenRule.getKeyHeaderAt(2)), false));
				}
			}
		}
	}

	/**
	 * Prepares the list of all division names and returns a list. 
	 * 
	 * @return List
	 */
	private List prepareDivisionNameListQry() {
		List newAlertKey1List = new ArrayList();
		String division = null;
		String divisionDesc = null;
		String region = alertReportParameters.getRegion();
		for(int i=0; i < alertKey1List.size(); i++) {
			division = (String)alertKey1List.get(i);
			divisionDesc = StaticDataLoader.getDivisionDesc(region, division);
			newAlertKey1List.add(new AlertReportDivision(division, divisionDesc, false));
		}
		return newAlertKey1List;
	}

	/**
	 * This method prepares the qrySeverLvlIndsql query.
	 * 
	 * @param alertRuleInfo
	 * @return String
	 */
	private String prepareQrySevereLvlIndSQL(AlertsGenFilterTemplate.AlertRuleInfoStruct alertRuleInfo) {
		String qrySevereLvlStmt=null;
		try {
			logger.debug("Processing qrySeverLvlInd query ....");
			//init(alertReportParameters);
			String args_0="";
			String args_1="";
			if ((alertReportParameters.getTimeStampInd() != null) &&  (alertReportParameters.getTimeStampInd().length() != 0)) {
				args_0 = ",rabc_cntrl_run  c"; 
			}
			if (alertReportParameters.getTimeStampInd() != null) {
				if(!alertReportParameters.getTimeStampInd().equalsIgnoreCase("NO")){
					args_1= "AND c.alert_rule_run_dt = ''" + alertReportParameters.getTimeStampInd() + "''";
				}
				args_1 += " AND c.alert_rule in (" + alertRuleInfo.alertRules.substring(1) +") " +
						" AND c.proc_date = h.proc_date ";
				
				if(alertReportParameters.getRelatedAlertInd().equals("Y")){
					args_1 += "AND c.severe_lvl_ind in ('0','N') "; 
				}else{
					args_1 += "AND c.severe_lvl_ind = '0' ";
				}
				args_1 += "AND (h.file_seq_num = c.file_seq_num or (h.file_seq_num IS NULL AND c.file_seq_num IS NULL)) ";
				if (alertRuleInfo.divisionNameKeyLvl > 0 ){
					if(alertReportParameters.getRelatedAlertInd().equals("Y")){
						args_1 += "AND ((c.key1 = h.alert_key" + alertRuleInfo.divisionNameKeyLvl +" or c.key1 is null)";
					}else{
						args_1 += "AND c.key1 = h.alert_key" + alertRuleInfo.divisionNameKeyLvl;
					}
				}else{
					args_1 +="AND c.key1 is null ";
				}
			}

			String partiRefIds = alertRuleInfo.partiRefIds.substring(1);
			
			MessageFormat mf = new MessageFormat(qrySevereLvlInd);
			qrySevereLvlStmt = mf.format(new String[] {args_0,
														partiRefIds,
														"to_date('"+alertReportParameters.getStartDate().toString()+"','mm/dd/yyyy')",
														"to_date('"+alertReportParameters.getEndDate().toString()+"','mm/dd/yyyy')",
														args_1,
														partiRefIds,
														alertRuleInfo.alertRule,
														"to_date('"+alertReportParameters.getStartDate().toString()+"','mm/dd/yyyy')",
														"to_date('"+alertReportParameters.getEndDate().toString()+"','mm/dd/yyyy')"});
		}catch(Exception e){
			logger.error(RABCMessages.getMessage("ERR_GENERAL", null) + " Exception details: " + e.getMessage());
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_GENERAL", null), e));
			return null;			
		}
		return qrySevereLvlStmt;
	}

	/**
	 * This method executes SevereLvlIndQry query.
	 * 
	 * @param alertRuleInfo
	 * @param qrySevereLvlStmt
	 * @return List
	 */
	private List executeSevereLvlIndQry(AlertsGenFilterTemplate.AlertRuleInfoStruct alertRuleInfo, String qrySevereLvlStmt) {
		List severeLvlIndList = new ArrayList();
		Statement stmt = null;
		ResultSet rs = null;
		try {
			logger.debug("Executing SevereLvlIndQry query .... " + qrySevereLvlStmt);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qrySevereLvlStmt);
			logger.debug("SQL - Execution complete.");			
		} catch (SQLException sx) {
			closeStatement(stmt);
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qrySevereLvlStmt}) + " Exception details: " + sx.getMessage());
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qrySevereLvlStmt}), sx));
		}
		if (rs == null) {
			// result set null
			logger.debug("Found zero records for qrySevereLvl ....");			
			closeStatement(stmt);
			return severeLvlIndList;
		}
		try
		{
			SevereLvlIndQry severeLvlIndQry = null; 
			while (rs.next()) {
				severeLvlIndQry = (SevereLvlIndQry) buildSevereLvlIndList(rs);
				severeLvlIndList.add(severeLvlIndQry);
				int index = (alertRuleInfo.divisionNameKeyLvl<=0?0:alertRuleInfo.divisionNameKeyLvl-1);
				if (notFoundInAlertKey1List(severeLvlIndQry.alertKey[index])) {
					alertKey1List.add((String)severeLvlIndQry.alertKey[index]);
				}
			}			
		} catch (SQLException sx) {
			closeStatement(stmt);
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qrySevereLvlStmt}) + " Exception details: " + sx.getMessage());
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qrySevereLvlStmt}), sx));
			return severeLvlIndList;
		}
		closeStatement(stmt);
		return severeLvlIndList;
	}

	/**
	 * Method executes the division names and returns the list. 
	 * 
	 * @param alertRuleInfo
	 * @return List
	 */
	public List executeDivisionNameListQry(AlertsGenFilterTemplate.AlertRuleInfoStruct alertRuleInfo) {
		List divisionNameList = new ArrayList();
		String division = null;
		String whereCondition =  prepareWhereCondition();
		Statement stmt = null;
		ResultSet rs = null;
		MessageFormat mf= new MessageFormat(qryDivisionNamesList);
		int index = (alertRuleInfo.divisionNameKeyLvl<=0?1:alertRuleInfo.divisionNameKeyLvl);

		String qryDivisionNamesListStmt = mf.format(new String[] {"h.alert_Key"+index,
																	alertRuleInfo.partiRefIds.substring(1),
																	whereCondition,
																	"h.alert_Key"+index});
		try {
			logger.debug("Executing qryDivisionNamesListStmt query .... " + qryDivisionNamesListStmt);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qryDivisionNamesListStmt);
			logger.debug("SQL - Execution complete.");			
		} catch (SQLException sx) {
			closeStatement(stmt);
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryDivisionNamesListStmt}) + " Exception details: " + sx.getMessage());
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryDivisionNamesListStmt}), sx));
		}
		if (rs == null) {
			// result set null
			logger.debug("Found zero records for qryDivisionNamesList ....");			
			closeStatement(stmt);
			return divisionNameList;
		}
		try
		{
			while (rs.next()) {
				division = rs.getString("DIVISIONNAMES");
				if (division != null)
					divisionNameList.add(division);
			}			
			logger.debug("Found zero records for qryDivisonNamesList ...." + divisionNameList);
		} catch (SQLException sx) {
			closeStatement(stmt);
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryDivisionNamesListStmt}) + " Exception details: " + sx.getMessage());
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryDivisionNamesListStmt}), sx));
			return divisionNameList;
		}
		
		return divisionNameList;
	}
	
	/**
	 * Method to return the list of exeute key1 list query.
	 * 
	 * @param alertRuleInfo
	 * @return List
	 */
	public List executeKey1ListQry(AlertsGenFilterTemplate.AlertRuleInfoStruct alertRuleInfo) {
		List key1List = new ArrayList();
		String whereCondition =  prepareWhereCondition();
		Statement stmt = null;
		ResultSet rs = null;

		MessageFormat mf= new MessageFormat(qryKey1List);
		String qryKey1ListStmt = mf.format(new String[] {alertRuleInfo.partiRefIds.substring(1), whereCondition});
		try {
			logger.debug("Executing qryKey1ListStmt query .... " + qryKey1ListStmt);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qryKey1ListStmt);
			logger.debug("SQL - Execution complete.");			
		} catch (SQLException sx) {
			closeStatement(stmt);
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryKey1ListStmt}) + " Exception details: " + sx.getMessage());
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryKey1ListStmt}), sx));
		}
		if (rs == null) {
			// result set null
			logger.debug("Found zero records for qryKey1ListStmt ....");			
			closeStatement(stmt);
			return key1List;
		}
		try
		{
 			while (rs.next()) {
				Key1ListQry key1ListQry = new Key1ListQry();
				key1ListQry.alertKey1 = rs.getString(1);
				key1List.add(key1ListQry);
			}			
		} catch (SQLException sx) {
			closeStatement(stmt);
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryKey1ListStmt}) + " Exception details: " + sx.getMessage());
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryKey1ListStmt}), sx));
			return key1List;
		}
		closeStatement(stmt);
		return key1List;
	}

	/**
	 * Method to return boolean value if alertKey is not found in alert key1 list.
	 * 
	 * @param alertKey
	 * @return boolean
	 */
	private boolean notFoundInAlertKey1List(String alertKey) {
		for(int i = 0; i < alertKey1List.size(); i++) {
			if (alertKey.equals((String)alertKey1List.get(i))) return false;
		}
		return true;
	}

	/**
	 * Method to return the severe level Ind list.
	 * 
	 * @param rs
	 * @return SevereLvlIndQry
	 * @throws SQLException
	 */
	private SevereLvlIndQry buildSevereLvlIndList(ResultSet rs) throws SQLException {
		SevereLvlIndQry severeLvlIndQry= new SevereLvlIndQry();
		severeLvlIndQry.alertKey[0] = rs.getString(1);
		severeLvlIndQry.alertKey[1] = rs.getString(2);
		severeLvlIndQry.alertKey[2] = rs.getString(3);
		severeLvlIndQry.alertKey[3] = rs.getString(4);
		severeLvlIndQry.alertKey[4] = rs.getString(5);
		severeLvlIndQry.alertItem = rs.getString(6);
		severeLvlIndQry.alertData = rs.getString(7);
		severeLvlIndQry.alertActualData = rs.getString(8);
		severeLvlIndQry.procDate = rs.getDate(9);
		severeLvlIndQry.fileSeqNum = rs.getInt(10);
		return severeLvlIndQry;
	}

	/**
	 * Method to return a string for preparing a where condition.
	 * 
	 * @return String
	 */
	public String prepareWhereCondition() {
		String whereCondition = "";
		if((alertReportParameters.getFileSeqNum()!=null) && (alertReportParameters.getFileSeqNum().intValue() != -1)){
			if((alertReportParameters.getRelatedAlertInd()!=null) && alertReportParameters.getRelatedAlertInd().equals("YES")){
				whereCondition += "and h.file_seq_num= "+alertReportParameters.getFileSeqNum();
			}
		}
		if (alertReportParameters.getStartDate()!=null){
			whereCondition += " and h.proc_date >= to_date('"+alertReportParameters.getStartDate().toString()+"','mm/dd/yyyy')";
		}
		if (alertReportParameters.getEndDate()!=null) {
			whereCondition += " and h.proc_date <=  to_date('"+alertReportParameters.getEndDate().toString()+"','mm/dd/yyyy')";
		}
		return whereCondition;
	}
	
	/**
	 * Method handles the list of the standard buttons.
	 */
	public void addStandardButtons() {
		WebHeaderLinkDAO webHeaderLinkDAO = new WebHeaderLinkDAO();
		WebHeaderLink webHeaderLink = null;
		List webHeaderLinkList = null;
		List args = new ArrayList();
		List stdButtonsList = new ArrayList();
		boolean showButton;
		
		if (alertReportParameters.getWebPageId().equals(PAGE_14)) {
			showButton = false;
		} else {
			showButton = true;
			if (alertReportParameters.getMinDate() == null) {
				alertReportParameters.setHidePrev(true);
			} else {
				if (alertReportParameters.getMinDate().compareTo(alertReportParameters.getStartDate()) >= 0){
					alertReportParameters.setHidePrev(true);
				}
			}
			if (alertReportParameters.getMaxDate() == null) {
				alertReportParameters.setHideNext(true);
			} else {
				if (alertReportParameters.getMaxDate().compareTo(alertReportParameters.getEndDate()) <= 0){
					alertReportParameters.setHideNext(true);
				}
			}
//			if (alertReportParameters.getStartDate().compareTo(alertReportParameters.getEndDate()) != 0) {
//				if (alertReportParameters.getEndDate().toString().length() == 0)
//					showButton = false;
//				else 
//					showButton = true;
//			}			
		}
		
		args.add(alertReportParameters.getWebPageId());
		args.add(alertReportParameters.getPresnId().toString());
		webHeaderLinkList = webHeaderLinkDAO.get(connection, failureList, args, qryTopHeaderLinks);	
		
		if ((alertReportParameters.getCntrlPtCd().length() != 0)) {
			alertReportParameters.setRelatedAlertInd("NA");
		}
		
		if (!failureList.isEmpty()) return;
		for (int i = 0; i < webHeaderLinkList.size(); i++) {
			webHeaderLink = (WebHeaderLink) webHeaderLinkList.get(i);
			if (webHeaderLink.getLinkPresnName().equals("PREVIOUS DATA")) {
				if ((showButton) && (!alertReportParameters.isHidePrev())) {
					if (!stdButtonsList.contains(webHeaderLink.getLinkPresnName())) {
						stdButtonsList.add(webHeaderLink.getLinkPresnName());
					}
				}
			}
			if (webHeaderLink.getLinkPresnName().equals("NEXT DATA")) {
				if ((showButton) && (!alertReportParameters.isHideNext())) {
					if (!stdButtonsList.contains(webHeaderLink.getLinkPresnName())) {
						stdButtonsList.add(webHeaderLink.getLinkPresnName());
					}
				}
			}
			if (webHeaderLink.getLinkPresnName().equals("VIEW REPORT")) {
				if (!stdButtonsList.contains(webHeaderLink.getLinkPresnName())) {
					stdButtonsList.add(webHeaderLink.getLinkPresnName());
				}
			}
			if (webHeaderLink.getLinkPresnName().equals("CREATE REPORT")) {
				if (!stdButtonsList.contains(webHeaderLink.getLinkPresnName())) {
					stdButtonsList.add(webHeaderLink.getLinkPresnName());
				}
			}
			if (webHeaderLink.getLinkPresnName().equals("EMAIL REPORT")) {
				if (!stdButtonsList.contains(webHeaderLink.getLinkPresnName())) {
					stdButtonsList.add(webHeaderLink.getLinkPresnName());
				}
			}
		}
		alertReportView.setStandardButtons(stdButtonsList);
	}

	/**
	 * Method to set the header text for passed region.
	 * 
	 * @param region
	 */
	public void setHeaderText(String region) {
		List headerTextList = new ArrayList();
		String arg_0="";
		Statement stmt = null;
		ResultSet rs = null;
		String header3 = null;
		int ind = 0;
		
		if ((alertReportParameters.getPresnId() != null) && (alertReportParameters.getPresnId().intValue() !=  0)) {
			arg_0 = "PRESN_ID = "+alertReportParameters.getPresnId(); 
		} else {
			arg_0 = "PRESN_ID IS NULL ";
		}
		MessageFormat mf= new MessageFormat(qryHeaderText);
		String qryHeaderTextListStmt = mf.format(new String[] {arg_0, alertReportParameters.getWebPageId()});
		try {
			logger.debug("Executing qryHeaderTextListStmt query .... "+qryHeaderTextListStmt);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qryHeaderTextListStmt);
			logger.debug("SQL - Execution complete.");			
		} catch (SQLException sx) {
			closeStatement(stmt);
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryHeaderTextListStmt}) + " Exception details: " + sx.getMessage());
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryHeaderTextListStmt}), sx));
			return;
		}
		 
		try
		{
			if (rs.getFetchSize() == 0) {
				// execute the same qry by changing where clause
				arg_0 = "PRESN_ID IS NULL ";
				qryHeaderTextListStmt = mf.format(new String[] {arg_0, alertReportParameters.getWebPageId()});
				try {
					logger.debug("Executing qryHeaderTextListStmt query .... "+qryHeaderTextListStmt);
					rs = stmt.executeQuery(qryHeaderTextListStmt);
					logger.debug("SQL - Execution complete.");			
				} catch (SQLException sx) {
					closeStatement(stmt);
					logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryHeaderTextListStmt}) + " Exception details: " + sx.getMessage());
					failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryHeaderTextListStmt}), sx));
					return;
				}			
			}
			if (rs.getFetchSize() == 0) {
				logger.warn("Zero records found in RABC_PRESN_HEADER table...");
				closeStatement(stmt);
				return;
			}

			while (rs.next()) {
				alertReportParameters.setHeader1(rs.getString("HEADER1"));
				if (alertReportParameters.getCntrlPtCd().length() != 0) {
					String cntrlPtCd = alertReportParameters.getCntrlPtCd();
					String cntrlPtDesc = RABCConstantsLists.getRABCConstantsLists().getText(((PickList) StaticDataLoader.getCntrlPtByCode(cntrlPtCd, region).get(0)).getValue1(), false);
					header3 = "<b>" + getLabel("alertReport.label.controlPoint") + ":</b> " + cntrlPtDesc;
					alertReportParameters.setHeader2(header3);
					header3 = "<b>For:</b> " + alertReportParameters.getStartDate().toString();
					if (alertReportParameters.getStartDate().compareTo(alertReportParameters.getEndDate()) != 0) {
						header3 = header3 + " - " + alertReportParameters.getEndDate().toString();
					}
				} else { 
					header3 = rs.getString("HEADER2");
					int index = header3.indexOf(":");
					if (index != -1) {
						header3 = "<b>" + header3.substring(0, index).trim() + ":</b> " +  header3.substring(index + 1).trim();
					}
					alertReportParameters.setHeader2(header3);
					ind = rs.getInt("PRESN_DATE_IND");
					header3 = rs.getString("HEADER3");
					if (ind == 1) {
						header3 =  "<b>" + header3 + " For:</b> " + alertReportParameters.getStartDate().toString();
						if (alertReportParameters.getStartDate().compareTo(alertReportParameters.getEndDate()) != 0) {
							header3 = header3 + " - " + alertReportParameters.getEndDate().toString();
						}
					}
					if (ind == 2) {
						header3 =  "<b>" + header3 + " As Of:</b> " + alertReportParameters.getStartDate().toString();
					}
					if (alertReportParameters.getWebPageId().equals(PAGE_14)) {
						header3 = header3 + " " + alertReportParameters.getFileSeqNum().toString();
					}
				}
				alertReportParameters.setHeader3(header3);
				return;
			}			
			logger.debug("Found zero records for headerTextList  ...."+headerTextList);
		} catch (SQLException sx) {
			closeStatement(stmt);
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryHeaderTextListStmt}) + " Exception details: " + sx.getMessage());
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryHeaderTextListStmt}), sx));
			return;
		}
		closeStatement(stmt);
	}
	
	/**
	 * Method to process the view size for passed total rows.
	 * 
	 * @param totalRows
	 */
	public void processViewSize(int totalRows) {		
		int pageSize = 0;
		int page = 0;
		int pages = 0;
		int startIndex = 0;
		int endIndex = 0;
		int curIndex = 0;
		int rowIndex = 0;
		int tableSize = 0;
		int rowSize = 0;
		int i = 0;
		int nbrOfRows = 0;
		AlertData alertData = null;
		AlertRow alertRow = null;
		List alertDataList = null;
		List rows = null;
		
		pageSize = RABCConstantsLists.getRABCConstantsLists().getPageSize();
		if ((totalRows <= pageSize) || (pageSize == 0)) {
			alertReportParameters.setPages(0); // don't show page related buttons
			return;
		}

		logger.debug("Processing rows as per page size = "+pageSize);
		pages = totalRows / pageSize;
		if ((totalRows % pageSize) != 0) {
			pages++;
		}
		alertReportParameters.setPages(pages);
		page = alertReportParameters.getPage();
		alertReportParameters.setPageshow(page);
		startIndex = ((page - 1) * pageSize) + 1;
		endIndex = ((page - 1) * pageSize) + 1 + pageSize;

		logger.debug("Retaining rows with startIndex = " + startIndex + " endIndex = " + endIndex);
		curIndex = 1;
		alertDataList = alertReportView.getAlertDataList();
		tableSize = alertDataList.size();
		i = 0;
		
		for(curIndex = 1; curIndex <= totalRows; curIndex++) {
			if (rows == null) {
				alertData = (AlertData) alertDataList.get(i);
				nbrOfRows = alertData.getNbrOfRows().intValue(); 
				rows = alertData.getRows();
				rowSize = nbrOfRows;
				rowIndex = 1;
			}
			alertRow = (AlertRow) rows.get(rowIndex-1);
			if (curIndex < startIndex) {
				logger.debug("Removing row for index < startIndex.");
				alertRow.setShowRow(0); // do not show
				rows.set(rowIndex - 1, alertRow);
				nbrOfRows--;
				if (rowIndex == rowSize) {
					alertData.setNbrOfRows(new Integer(nbrOfRows));
					alertDataList.set(i, alertData);
					logger.debug("Reading next table.");
					rows = null;
					i++;
				}
				rowIndex++;
			}
			if ((curIndex >= startIndex) && (curIndex < endIndex)) {
				if (rowIndex == rowSize) {
					alertData.setNbrOfRows(new Integer(nbrOfRows));
					alertDataList.set(i, alertData);
					logger.debug("Reading next table.");
					rows = null;
					i++;
				}
				rowIndex++;
			}
			if (curIndex >= endIndex) {
				logger.debug("Removing row for index >= endIndex.");
				alertRow.setShowRow(0); // do not show
				rows.set(rowIndex - 1, alertRow);
				nbrOfRows--;
				if (rowIndex == rowSize) {
					alertData.setNbrOfRows(new Integer(nbrOfRows));
					alertDataList.set(i, alertData);
					logger.debug("Reading next table.");
					rows = null;
					i++;
				}
				rowIndex++;
			}
			logger.debug("curIndex = " + curIndex + " rowSize = " + rowSize + " rowIndex = " + rowIndex + " nbrOfRows = " + nbrOfRows);

		}
//		logger.debug("Deleting empty tables.");
//		i = 0;
//		while (i < tableSize) {
//			alertData = (AlertData) alertDataList.get(i);
//			rows = alertData.getRows();
//			rowSize = rows.size();
//			logger.debug("i = " + i + " rowSize = " + rowSize);
//			if (rowSize == 0) {
//				logger.debug("Removing table.");
//				alertDataList.remove(i);
//				tableSize--;
//			} else {
//				i++;
//			}
//			logger.debug("i = " + i + " tableSize = " + tableSize);
//		}
	}

	/**
	 * Private method which closes statement and logger error if any as warning.
	 * 
	 * @param stmt
	 */
	private void closeStatement(Statement stmt) {
		try
		{
			if (stmt != null) {
				stmt.close();
			}
		} catch(SQLException sx) {
			logger.warn("AlertReportService - Closing SQL Statement results in this error: " + sx.getMessage());
		}
	}
	
	/**
	 * Private method used to handle the SevereLvlIndQry.
	 */
	private class SevereLvlIndQry {
		int fileSeqNum;
		Date procDate;
		String[] alertKey = {"","","","",""};
		String alertItem;
		String alertData;
		String alertActualData;
	}
	
	/**
	 * Private method handles handle the alert key.
	 */
	private class Key1ListQry {
		String alertKey1;
	}

	/**
	 * This class handles the alert rule information structure.
	 */
	protected class AlertRuleInfoStruct {
		List multiColumnList = null;
		List columns = null;
		int nbrOfKeyCols = 0;
		int calcCnt = 0;
		int seqCnt = 0;
		int totCnt = 0;
		char totInd;
		int presnId = 0;
		int partiRefId = 0; 
		int alertKeyLvl = 0; 
		int divisionNameKeyLvl = -1;
		String alertRule = null;
		String partiRefIds = null;
		String alertRules = null;
		String sumyPresnNames = null;
	}
	
}
