/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.alerts.status;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.MyDate;
import com.att.bac.rabc.ProgressBar;
import com.att.bac.rabc.RABCConstantsLists;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.admin.AlertGroupFunct;
import com.att.bac.rabc.admin.AlertGroupFunctDAO;
import com.att.bac.rabc.admin.AlertGroupUser;
import com.att.bac.rabc.admin.AlertGroupUserDAO;
import com.att.bac.rabc.admin.AlertPgmFunct;
import com.att.bac.rabc.admin.AlertPgmFunctDAO;
import com.att.bac.rabc.admin.UpdateGrp;
import com.att.bac.rabc.admin.UpdateGrpDAO;

/**
 * This is a service class to provide the business logic. The methods in this class are called by the
 * action class. They internaly calls the DAO classes to do the required manipulation and returns the 
 * result to the action class. This paricular service class serves the business logic to populate the
 * Alert Status Update page, Alert Comments History page and to update the status of alerts.
 * 
 * @author Vijay Dubey - VD3159
 */
public class AlertStatusService {
	private static final Logger logger = Logger.getLogger(AlertStatusService.class);
	private static AlertStatusService alertStatusService;
	
	/*
	 * Variables to represent the sql statements.
	 */
	private final String getRootCatgyCd = "select distinct root_catgy_cd, "
		+ "root_catgy_cd_desc "
		+ "from rabc_root_catgy_cd "
		+ "order by root_catgy_cd, root_catgy_cd_desc";
	
	private final String qryCriteria = "select bams.alert_rule outAlertRule, "
		+ "bams.msg_num outMsgNo, "
		+ "bams.proc_date outProcDate, "
		+ "bams.alert_data1 as outKey1, "
		+ "bams.alert_data2 as outKey2, "
		+ "bams.alert_data3 as outKey3, "
		+ "bams.alert_data4 as outKey4, "
		+ "bams.alert_data5 as outKey5, "
		+ "bams.file_seq_num outFileSeqNum, "
		+ "bams.alert_actual outActualData, "
		+ "bams.alert_pct outPctVariance, "
		+ "bams.alert_status outAlertStatus, "
		+ "bams.alert_severe_lvl_ind outAlertSevereLvlInd, "
		+ "bams.alert_supp_ind supp_info_ind, "
		+ "bams.alert_grp outAlertGroup, "
		+ "bams.alert_revenue outAlertRevenue, "
		+ "bams.alert_root_cause outAlertRootCause, "
		+ "bams.alert_rule_run_dt outAlertRunDt, "
		+ "bams.alert_item outAlertItem, "
		+ "bams.alert_lost_revenue outLostRevenue, "
		+ "bd.division_desc as divisionDesc "
		+ "{0} "
		+ "from	rabc_alert_msg bams, rabc_division bd "
		+ "{1} "
		+ "where msg_num in ( {2} ) "
		+ "and bams.alert_data1 = bd.division "
		+ "{3} ";
	
	private final String qrySuppInfo = "select distinct msg_num, supp_seq_num, supp_presn_name, supp_pic_link, supp_data  "
		+ "from rabc_alert_supp_info "
		+ "where supp_presn_name is not null "
		+ "and msg_num in ( {0} )";
	
	private final String qryRootCauseCtgy = "select msg_num, alert_root_catgy_cd "
		+ "from rabc_warn_cd "
		+ "where msg_num in ( {0} ) "
		+ "order by msg_num, alert_root_catgy_cd";
	
	private final String qRuleGroups = "select distinct alert_rule, alert_grp, presn_id "
		+ "from rabc_update_grp "
		+ "where alert_rule in ( ''{0}'' ) "
		+ "order by alert_rule, alert_grp";
	
	private final String qryCommentHistory = "select distinct comment_user_id, "
		+ "asoc_time_stamp, time_stamp, msg_comment, msg_num, asoc_msg_num "
		+ "from rabc_alert_comment " 
		+ "where msg_num in ({0}) "
		+ "{1}";
	
	private final String qry_GetFunctCodes = "select pgm_id, pgm_desc, funct_cd, alert_grp_type "
		+ "from RABC_ALERT_PGM_FUNCT "
		+ "where pgm_id = ''RABCPPG00038''";
	
	private final String qry_GetAlertGrps = "select distinct alert_grp, funct_cd "
		+ "from RABC_ALERT_GRP_FUNCT "
		+ "where funct_cd in ({0})";
	
	private final String qry_CheckUser = "select alert_grp, user_id "
		+ "from RABC_ALERT_GRP_USER "
		+ "where alert_grp in ({0}) "
		+ "and user_id = ''{1}''";
	
	private final String qry_GetReturnList = "select distinct alert_rule, alert_grp, presn_id "
		+ "from RABC_UPDATE_GRP "
		+ "where alert_grp in ({0})";
	
	private final String update_count = "Update rabc_dash_presn "
		+ "set {0} {1} "
		+ "where alert_rule = ''{2}'' "
		+ "{3} {4} {5}";
	
	private final String delete_comments = "delete from rabc_warn_cd "
		+ "where msg_num in ({0})";
	
	private final String update_alert_sts = "Update rabc_alert_msg "
		+ "set time_stamp = sysdate "
		+ ",alert_user_id = ''{0}'' "
		+ "{1} {2} {3} {4} "
		+ "where msg_num = {5} ";
	
	private final String update_comment = "Insert into rabc_alert_comment "
		+ "values ({0}, null, null, ''{1}'', ''{2}'', sysdate)";
	
	private final String update_warn_cd = "Insert into rabc_warn_cd "
		+ "values ({0}, ''{1}'')";
	
	
	/**
	 * Synchronized method to return the instance of AlertStatusService object.
	 * It checks the existance of the instance of AlertStatusService and if it does not exists
	 * then creates one instance of AlertStatusService and returns otherwise it returns the
	 * existing instance of AlertStatusService.
	 * 
	 * @return AlertStatusService
	 */
	protected static synchronized AlertStatusService getAlertStatusService(){
		if (alertStatusService == null) {
			alertStatusService = new AlertStatusService();
		}
		return alertStatusService;
	}
	
	/**
	 * Method to return the list of Alert Status.
	 * It calls the RABCConstantsLists class to get the list of Alert Status.
	 * 
	 * @return List
	 */
	protected List getAlertStatusList() {
		List alertStatusList = new ArrayList();
		alertStatusList = RABCConstantsLists.getRABCConstantsLists().getAlertUpdateStatusList();	
		return alertStatusList;
	}
	
	/**
	 * Method to return the list of Root Cause Categories.
	 * It calls the RootCategoryDAO class to get the list of Root Cause Categories.
	 * 
	 * @param connection
	 * @param failureList
	 * @return List
	 */
	protected List getRootCauseCategoryList(Connection connection, List failureList) {
		List tempRootCauseCategoryList = new ArrayList();
		List rootCauseCategoryList = new ArrayList();
		RootCategory rootCategory = null;
		String query = getRootCatgyCd;
		List args = new ArrayList();
		
		tempRootCauseCategoryList = new RootCategoryDAO().get(connection, failureList, args, query);
		if (!failureList.isEmpty()) {
			return null;
		}
		if (tempRootCauseCategoryList != null) {
			int counter = 0;
			int tempRootCauseCategoryListSize = tempRootCauseCategoryList.size();
			for(counter = 0; counter < tempRootCauseCategoryListSize; counter++) {
				rootCategory = (RootCategory) tempRootCauseCategoryList.get(counter);
				rootCategory.setRootCatgyCdDesc(rootCategory.getRootCatgyCd() + " - " + rootCategory.getRootCatgyCdDesc());
				rootCauseCategoryList.add(rootCategory);
			}
		}
		
		return rootCauseCategoryList;
	}
	
	/**
	 * Method to return the list of AlertReportDetail objects.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param progressBar
	 * @return List
	 */
	protected List getAlertReportDetailList(Connection connection, List failureList, 
			List args, ProgressBar progressBar) {
		
		String fromPage = (String) args.get(1);
		
		/*
		 * Call private method populateAlertArgsList(args) to populate the list of arguments to execute 
		 * the query to get the list of alert report detail objects.
		 */
		List alertArgs = populateAlertArgsList(args);
		
		/*
		 * Call the private method getAlertList(connection, failureList, alertArgs, fromPage) to
		 * return the list of alert report detail objects.
		 */
		List alertReportDetailList = getAlertList(connection, failureList, alertArgs, fromPage);
		if (!failureList.isEmpty()) {
			return null;
		}
		progressBar.setProgressPercent(20);
		if (alertReportDetailList != null) {
			int alertListSize = alertReportDetailList.size();
			if (alertListSize == 1) {
				HashMap msgNumWiseRootCatgyCdMap = getMsgNnmWiseRootCatgyCd(connection, failureList, args);
				if (!failureList.isEmpty()) {
					return null;
				}
				progressBar.setProgressPercent(30);
				HashMap alertRuleWiseAlertGroupsMap = getAlertRuleWiseAlertGroups(connection, failureList, ((AlertReportDetail)alertReportDetailList.get(0)).getAlertRule());
				if (!failureList.isEmpty()) {
					return null;
				}
				progressBar.setProgressPercent(40);
				if ("Y".equals(((AlertReportDetail)alertReportDetailList.get(0)).getAlertSuppInd())) {
					HashMap msgNnmWiseSuppDataMap = getMsgNnmWiseSuppData(connection, failureList, args);
					if (!failureList.isEmpty()) {
						return null;
					}
					/*
					 * Call the private method to update the list of alert report detail objects 
					 * using the hashmaps.
					 */
					alertReportDetailList = updateAlertReportDetailList(alertReportDetailList, 
							msgNumWiseRootCatgyCdMap, alertRuleWiseAlertGroupsMap, msgNnmWiseSuppDataMap);
				} else {
					alertReportDetailList = updateAlertReportDetailList(alertReportDetailList, 
							msgNumWiseRootCatgyCdMap, alertRuleWiseAlertGroupsMap, null);
				}
				progressBar.setProgressPercent(50);
			}
		}
		
		return alertReportDetailList;
	}
	
	/**
	 * Private method to return a list of arguments to be used to execute the sql query to get 
	 * the list of AlertReportDetail objects.
	 * 
	 * @param args
	 * @return List
	 */
	private List populateAlertArgsList(List args) {
    	List alertArgs = new ArrayList();
    	String msgNo = (String) args.get(0);
    	String fromPage = (String) args.get(1);
    	if ("RABCPSF00006".equals(fromPage)) {
    		alertArgs.add(", bams.alert_sys_err_cd outError, bsec.sys_err_cd_desc outErrorCdDesc ");
    		alertArgs.add(", rabc_sys_err_cd bsec ");
    	} else {
    		alertArgs.add("");
    		alertArgs.add("");
    	}
    	alertArgs.add(msgNo);
    	if ("RABCPSF00006".equals(fromPage)) {
    		alertArgs.add("and bams.alert_sys_err_cd = bsec.sys_err_cd ");
    	} else {
    		alertArgs.add("");
    	}
		
    	return alertArgs;
    }
    
	/**
	 * Private method to return the list of alertReportDetail objects. All attributes of
	 * these objects will not be set in here.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param fromPage
	 * @return List
	 */
	private List getAlertList(Connection connection, List failureList, List args, String fromPage){
		List alertReportDetailList = new ArrayList();
		AlertReportDetail alertReportDetail = null;
		String selectSQL = qryCriteria;
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		
		try{
			MessageFormat mf = new MessageFormat(selectSQL);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("To get Alert List - Executing SQL statement: "+ prepareStatement);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			if (rs != null) {
				while(rs.next()){
					/*
					 * Call the private method  buildAlertReportDetail(rs, fromPage) to build the
					 * AlertReportDetail object.
					 */
					alertReportDetail = buildAlertReportDetail(rs, fromPage);
					alertReportDetailList.add(alertReportDetail);
				}
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
			return null;
		} finally{
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		
		return alertReportDetailList;
	}
	
	/**
	 * Private method to return the AlertReportDetail object. It accepts the result set and set the
	 * attributes of AlertReportDetail object by getting the values from the result set.
	 * 
	 * @param rs
	 * @param fromPage
	 * @return AlertReportDetail
	 * @throws SQLException
	 */
	private AlertReportDetail buildAlertReportDetail(ResultSet rs, String fromPage) throws SQLException {
		AlertReportDetail alertReportDetail = new AlertReportDetail();
		
		alertReportDetail.setAlertRule(rs.getString("outAlertRule"));
		alertReportDetail.setMsgNo(rs.getInt("outMsgNo"));
		Date procDate = rs.getDate("outProcDate");
		if (procDate != null) {
			alertReportDetail.setProcDate(new MyDate(procDate));
		}
		alertReportDetail.setAlertData1(rs.getString("outKey1"));
		alertReportDetail.setAlertData2(rs.getString("outKey2"));
		alertReportDetail.setAlertData3(rs.getString("outKey3"));
		alertReportDetail.setAlertData4(rs.getString("outKey4"));
		alertReportDetail.setAlertData5(rs.getString("outKey5"));
		String outFileSeqNum = rs.getString("outFileSeqNum");
		if (outFileSeqNum != null) {
			alertReportDetail.setFileSeqNum(new Integer(outFileSeqNum));
		} else {
			alertReportDetail.setFileSeqNum(null);
		}
		String outAlertActual = rs.getString("outActualData");
		if (outAlertActual != null) {
			alertReportDetail.setAlertActual(new Double(outAlertActual));
		} else {
			alertReportDetail.setAlertActual(null);
		}
		String outVariance = rs.getString("outPctVariance");
		if (outVariance != null) {
			alertReportDetail.setAlertPct(new Double(outVariance));
		} else {
			alertReportDetail.setAlertPct(null);
		}
		alertReportDetail.setAlertStatus(rs.getString("outAlertStatus"));
		alertReportDetail.setAlertSeverityLevelInd(rs.getString("outAlertSevereLvlInd"));
		alertReportDetail.setAlertSuppInd(rs.getString("supp_info_ind"));
		String outRevenueImpact = rs.getString("outAlertRevenue");
		if (outRevenueImpact != null) {
			alertReportDetail.setAlertRevenue(new Double(outRevenueImpact));
		} else {
			alertReportDetail.setAlertRevenue(null);
		}
		alertReportDetail.setAlertRootCause(rs.getString("outAlertRootCause"));
		Date alertRuleRunDate = rs.getDate("outAlertRunDt");
		if (alertRuleRunDate != null) {
			alertReportDetail.setAlertRuleRunDate(new MyDate(alertRuleRunDate));
		}
		alertReportDetail.setAlertItem(rs.getString("outAlertItem"));
		if ("RABCPSF00006".equals(fromPage)) {
			alertReportDetail.setAlertSysErrCd(rs.getInt("outError"));
			alertReportDetail.setAlertSysErrDesc(rs.getString("outErrorCdDesc"));
		}
		String outLostRevenue = rs.getString("outLostRevenue");
		if (outLostRevenue != null) {
			alertReportDetail.setAlertLostRevenue(new Double(outLostRevenue));
		} else {
			alertReportDetail.setAlertLostRevenue(null);
		}
		alertReportDetail.setDivisionDesc(rs.getString("divisionDesc"));
		
		return alertReportDetail;
	}
	
	/**
	 * Private method to return a hashmap of message number wise list of suplement data.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return HashMap
	 */
	private HashMap getMsgNnmWiseSuppData(Connection connection, List failureList, List args){
		HashMap msgNumWiseSuppDataMap = new HashMap();
		String selectSQL = qrySuppInfo;
		List suppArgs = new ArrayList();
		suppArgs.add(((String)args.get(0)));
		int currentMsgNo = 0;
		int previousMsgNo = 0;
		AlertSuppInfo alertSuppInfo = null;
		List suppInfoList = new ArrayList();
		
		List totalSuppInfoList = new AlertSuppInfoDAO().get(connection, failureList, args, selectSQL);
		if (!failureList.isEmpty()) {
			return null;
		}
		if (totalSuppInfoList != null) {
			int counter = 0;
			int totalSuppInfoListSize = totalSuppInfoList.size();
			for (counter=0; counter<totalSuppInfoListSize; counter++) {
				alertSuppInfo = (AlertSuppInfo) totalSuppInfoList.get(counter);
				currentMsgNo = alertSuppInfo.getMsgNum();
				if ((suppInfoList.size() > 0) && (currentMsgNo != previousMsgNo)) {
					msgNumWiseSuppDataMap.put(new Integer(previousMsgNo), suppInfoList);
					suppInfoList = new ArrayList();
				}
				suppInfoList.add(alertSuppInfo);
				previousMsgNo = currentMsgNo;
			}
			msgNumWiseSuppDataMap.put(new Integer(previousMsgNo), suppInfoList);
		}
		
		return msgNumWiseSuppDataMap;
	}
	
	/**
	 * Private method to return a hashmap of message number wise root category codes.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return HashMap
	 */
	private HashMap getMsgNnmWiseRootCatgyCd(Connection connection, List failureList, List args){
		HashMap msgNumWiseRootCatgyCdMap = new HashMap();
		List rootCtgyCdList = new ArrayList();
		String selectSQL = qryRootCauseCtgy;
		List rootArgs = new ArrayList();
		rootArgs.add(((String)args.get(0)));
		int currentMsgNo = 0;
		int previousMsgNo = 0;
		String rootCtgy = null;
		List rootCtgyList = new ArrayList();

		rootCtgyCdList = new WarningDAO().get(connection, failureList, rootArgs, selectSQL);
		if (!failureList.isEmpty()) {
			return null;
		}
		if (rootCtgyCdList != null) {
			int counter = 0;
			int rootCtgyCdListSize = rootCtgyCdList.size();
			for (counter=0; counter<rootCtgyCdListSize; counter++) {
				currentMsgNo = ((Warning) rootCtgyCdList.get(counter)).getMsgNum();
				rootCtgy = ((Warning) rootCtgyCdList.get(counter)).getAlertRootCatgyCd();
				if (rootCtgyList.size()>0 && currentMsgNo != previousMsgNo) {
					msgNumWiseRootCatgyCdMap.put(new Integer(previousMsgNo), rootCtgyList);
					rootCtgyList = new ArrayList();
				}
				rootCtgyList.add(rootCtgy);
				previousMsgNo = currentMsgNo;
			}
			msgNumWiseRootCatgyCdMap.put(new Integer(previousMsgNo), rootCtgyList);
		}
		
		return msgNumWiseRootCatgyCdMap;
	}
	
	/**
	 * Private method to return a hashmap of alert rule wise alert groups.
	 * @param connection
	 * @param failureList
	 * @param alertRule
	 * @return HashMap
	 */
	private HashMap getAlertRuleWiseAlertGroups(Connection connection, List failureList, String alertRule){
		HashMap alertRuleWiseAlertGroupsMap = new HashMap();
		String selectSQL = qRuleGroups;
		List args = new ArrayList();
		args.add(alertRule);
		String currentAlertRule = null;
		String previousAlertRule = null;
		String alertGroup = null;
		List alertGroupList = new ArrayList();
		
		List allAlertGroupList = new UpdateGrpDAO().get(connection, failureList, args, selectSQL);
		if (!failureList.isEmpty()) {
			return null;
		}
		if (allAlertGroupList != null) {
			int counter = 0;
			int allAlertGroupListSize = allAlertGroupList.size();
			for (counter = 0; counter < allAlertGroupListSize; counter++) {
				currentAlertRule = ((UpdateGrp) allAlertGroupList.get(counter)).getAlertRule();
				alertGroup = ((UpdateGrp) allAlertGroupList.get(counter)).getAlertGrp();
				if ((alertGroupList.size() > 0) && (!currentAlertRule.equals(previousAlertRule))) {
					alertRuleWiseAlertGroupsMap.put(previousAlertRule, alertGroupList);
					alertGroupList = new ArrayList();
				}
				alertGroupList.add(alertGroup);
				previousAlertRule = currentAlertRule;
			}
			alertRuleWiseAlertGroupsMap.put(previousAlertRule, alertGroupList);
		}
		
		return alertRuleWiseAlertGroupsMap;
	}
	
	/**
	 * Private method to return the updated list of the AlertReportDetail objects by the hash maps 
	 * msgNumWiseRootCatgyCdMap, alertRuleWiseAlertGroupsMap and msgNnmWiseSuppDataMap.
	 * 
	 * @param alertReportDetailList
	 * @param msgNumWiseRootCatgyCdMap
	 * @param alertRuleWiseAlertGroupsMap
	 * @param msgNnmWiseSuppDataMap
	 * @return List
	 */
	private List updateAlertReportDetailList(List alertReportDetailList, HashMap msgNumWiseRootCatgyCdMap, 
			HashMap alertRuleWiseAlertGroupsMap, HashMap msgNnmWiseSuppDataMap) {
		List newAlertReportDetailList = new ArrayList();
		AlertReportDetail alertReportDetail = null;

		for (int i=0; i<alertReportDetailList.size(); i++) {
			alertReportDetail = (AlertReportDetail)alertReportDetailList.get(i);
			int msgNum = alertReportDetail.getMsgNo();
			if (msgNumWiseRootCatgyCdMap.containsKey(new Integer(msgNum))) {
				List rootCtgyList = (List) msgNumWiseRootCatgyCdMap.get(new Integer(msgNum));
				for (int j=0; j<rootCtgyList.size(); j++) {
					alertReportDetail.addAlertRootCatgy((String)rootCtgyList.get(j));
				}
			}
			
			String alertRule = alertReportDetail.getAlertRule();
			if (alertRuleWiseAlertGroupsMap.containsKey(alertRule)) {
				List alertGroupList = (List) alertRuleWiseAlertGroupsMap.get(alertRule);
				for (int k=0; k<alertGroupList.size(); k++) {
					alertReportDetail.addAlertGroup((String)alertGroupList.get(k));
				}
			}
			
			if (msgNnmWiseSuppDataMap != null) {
				if (msgNnmWiseSuppDataMap.containsKey(new Integer(msgNum))) {
					List suppInfoList = (List) msgNnmWiseSuppDataMap.get(new Integer(msgNum));
					if (suppInfoList != null) {
						for (int l=0; l<suppInfoList.size(); l++) {
							alertReportDetail.addAlertSuppInfo((AlertSuppInfo) suppInfoList.get(l));
						}
						alertReportDetail.setKeyRow(1);
					}
				}
			}
			
			newAlertReportDetailList.add(alertReportDetail);
		}
		
		return newAlertReportDetailList;
	}
	
	/**
	 * Method to return the list of AlertComment objects for the selected alerts.
	 * 
	 * @param connection
	 * @param alertReportDetailList
	 * @param failureList
	 * @param sortItem
	 * @param sortOrder
	 * @return List
	 */
	protected List getAlertCommentList(Connection connection, List alertReportDetailList, 
			List failureList, String sortItem, String sortOrder) {
		List alertCommentList = new ArrayList();
		String query = qryCommentHistory;
		List args = new ArrayList();
		
		/*
		 * Call the private method getMsgNums(alertReportDetailList) to get a string that contains
		 * all the distinct message nos. seperated by comma of the list of alert report detail objects.
		 */
		String messageNumbers = getMsgNums(alertReportDetailList);
		if (messageNumbers.equals("")) {
			messageNumbers = "''";
		} else {
			messageNumbers = messageNumbers.substring(0, messageNumbers.length()-1);
		}
		args.add(messageNumbers);
		if ((sortItem != null) && !("".equals(sortItem))) {
			args.add("order by " + sortItem + " " + sortOrder);
		} else {
			args.add("");
		}
		
		alertCommentList = new AlertCommentDAO().get(connection, failureList, args, query);
		if (!failureList.isEmpty()) {
			return null;
		}
		
		return alertCommentList;
	}
	
	/**
	 * Private method to return the string having all the message numbers of selected alerts seperated by comma.
	 * 
	 * @param alertReportDetailList
	 * @return String
	 */
	private String getMsgNums(List alertReportDetailList) {
	     String result = "";
	     StringBuffer resultBuffer = new StringBuffer();
	     if (alertReportDetailList != null) {
		     for(int i=0; i<alertReportDetailList.size(); i++) {
		        if(resultBuffer.indexOf(new Integer(((AlertReportDetail)alertReportDetailList.get(i)).getMsgNo()).toString()) == -1) { 
			     	resultBuffer.append('\'').append(((AlertReportDetail)alertReportDetailList.get(i)).getMsgNo()).append('\'').append(',');
		        }
		     }
	     }    
	     result = resultBuffer.toString();
	     return result;
	}
	
	/**
	 * Method to return the update access of the logged in user for selected alerts . 
	 * If user has the access to update the selected alerts it returns 'Y' else it returns 'N'.
	 * 
	 * @param connection
	 * @param alertReportDetailList
	 * @param userId
	 * @param failureList
	 * @return String
	 */
	protected String getUpdateAccess(Connection connection, List alertReportDetailList, 
			String userId, List failureList) {
		String updateAccess = "N";
		String functCodes = null;
		String alertGrpTypes = null;
		String alertGrps = null;
		String userAlertGrps = null;
		String alertRule = null;
		String presnId = null;
		int i = 0;
		int size = 0;
		StringBuffer resultBuffer = null;
		
		/*
		 * Code to create an arry list that contains the alert rules of selected list of 
		 * AlertReportDetail objects.
		 */
		List alertRuleList = new ArrayList();
		if (alertReportDetailList != null) {
			size = alertReportDetailList.size();
			if (size > 0) {
				alertRuleList.add(((AlertReportDetail) alertReportDetailList.get(i)).getAlertRule());
			}
		}
		
		/*
		 * Code to create a string of function codes seperated by comma.
		 */
		List functionCodes = getFunctionCodes(connection, failureList);
		if (functionCodes != null) {
			size = functionCodes.size();
			if (size > 0) {
				resultBuffer = new StringBuffer();
				for (i=0; i<size; i++) {
					if (i == size-1) {
						resultBuffer.append('\'').append(((AlertPgmFunct)functionCodes.get(i)).getFunctCd()).append('\'');
						alertGrpTypes = ((AlertPgmFunct)functionCodes.get(i)).getAlertGrpType();
					} else {
						resultBuffer.append('\'').append(((AlertPgmFunct)functionCodes.get(i)).getFunctCd()).append('\'').append(',');
					}
				}
				functCodes = resultBuffer.toString();
			}
		}
		
		/*
		 * Code to create a string of alert groups seperated by comma.
		 */
		List alertGroups = getAlertGroups(connection, functCodes, failureList);
		if (alertGroups != null) {
			size = alertGroups.size();
			if (size > 0) {
				resultBuffer = new StringBuffer();
				for (i=0; i<size; i++) {
					if (i == size-1) {
						resultBuffer.append('\'').append(((AlertGroupFunct)alertGroups.get(i)).getAlertGrp()).append('\'');
					} else {
						resultBuffer.append('\'').append(((AlertGroupFunct)alertGroups.get(i)).getAlertGrp()).append('\'').append(',');
					}
				}
				alertGrps = resultBuffer.toString();
			}
		}
		
		/*
		 * Code to create a string of user alert groups seperated by comma.
		 * This will be used to get the list of user alert rules.
		 * Then by using this list, the access update of the user will be decided.
		 */
		List userAlertGroups = getUserAlertGroups(connection, alertGrps, userId, failureList);
		if (userAlertGroups != null) {
			size = userAlertGroups.size();
			if (size > 0) {
				resultBuffer = new StringBuffer();
				for (i=0; i<size; i++) {
					if (i == size-1) {
						resultBuffer.append('\'').append(((AlertGroupUser)userAlertGroups.get(i)).getAlertGrp()).append('\'');
					} else {
						resultBuffer.append('\'').append(((AlertGroupUser)userAlertGroups.get(i)).getAlertGrp()).append('\'').append(',');
					}
				}
				userAlertGrps = resultBuffer.toString();
				
				List userAlertRules = getUserAlertRules(connection, userAlertGrps, failureList);
				if (userAlertRules != null) {
					size = userAlertRules.size();
					if (size > 0) {
						for (i=0; i<size; i++) {
							if (alertGrpTypes != null) {
								if (alertGrpTypes.equals("A")) {
									alertRule = ((UpdateGrp)userAlertRules.get(i)).getAlertRule();
									if (alertRuleList.contains(alertRule)) {
										updateAccess = "Y";
										break;
									}
								} else {
									presnId = (new Integer(((UpdateGrp)userAlertRules.get(i)).getPresnId())).toString();
									if (alertRuleList.contains(presnId)) {
										updateAccess = "Y";
										break;
									}
								}
							}
						}
					}
				}
			}
		}
		return updateAccess;
	}
	
	/**
	 * Private method to return the list of fuction codes.
	 * 
	 * @param connection
	 * @param failureList
	 * @return List
	 */
	private List getFunctionCodes(Connection connection, List failureList) {
		List functionCodes = new ArrayList();
		String query = qry_GetFunctCodes;
		List args = new ArrayList();
		
		functionCodes = new AlertPgmFunctDAO().get(connection, failureList, args, query);
		if (!failureList.isEmpty()) {
			return null;
		}
		
		return functionCodes;
	}
	
	/**
	 * Private method to return the list of alert groups for the passed of function codes.
	 * 
	 * @param connection
	 * @param functCodes
	 * @param failureList
	 * @return List
	 */
	private List getAlertGroups(Connection connection, String functCodes, List failureList) {
		List alertGroups = new ArrayList();
		String query = qry_GetAlertGrps;
		List args = new ArrayList();
		if (functCodes != null) {
			args.add(functCodes);
		} else {
			args.add("''");
		}
		
		alertGroups = new AlertGroupFunctDAO().get(connection, failureList, args, query);
		if (!failureList.isEmpty()) {
			return null;
		}
		
		return alertGroups;
	}
	
	/**
	 * Private method to return the list of alert groups for logged in user id.
	 * 
	 * @param connection
	 * @param alertGroups
	 * @param userId
	 * @param failureList
	 * @return List
	 */
	private List getUserAlertGroups(Connection connection, String alertGroups, String userId, List failureList) {
		List userAlertGrps = new ArrayList();
		String query = qry_CheckUser;
		List args = new ArrayList();
		if (alertGroups != null) {
			args.add(alertGroups);
		} else {
			args.add("''");
		}
		args.add(userId);
		
		userAlertGrps = new AlertGroupUserDAO().get(connection, failureList, args, query);
		if (!failureList.isEmpty()) {
			return null;
		}
		
		return userAlertGrps;
	}
	
	/**
	 * Private method to return the list of alert rules for passed alert groups.
	 * 
	 * @param connection
	 * @param userAlertGroups
	 * @param failureList
	 * @return List
	 */
	private List getUserAlertRules(Connection connection, String userAlertGroups, List failureList) {
		List userAlertRules = new ArrayList();
		String query = qry_GetReturnList;
		List args = new ArrayList();
		if (userAlertGroups != null) {
			args.add(userAlertGroups);
		} else {
			args.add("''");
		}
		
		userAlertRules = new UpdateGrpDAO().get(connection, failureList, args, query);
		if (!failureList.isEmpty()) {
			return null;
		}
		
		return userAlertRules;
	}
	
	/**
	 * Method to update the tables with the user's input for selected alerts.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param alertReportDetailList
	 * @param progressBar
	 */
	protected void updateAlerts(Connection connection, List failureList, List args, 
			List alertReportDetailList, ProgressBar progressBar) {
		if (alertReportDetailList != null) {
			/*
			 * Call private method to update the rabc_dash_presn table for 
			 * each alerts selected.
			 */
			updateDashPresn(connection, failureList, args, alertReportDetailList);
			progressBar.setProgressPercent(30);
			
			/*
			 * Call private method to delete the records from rabc_warn_cd table
			 * where the message nos. in the selected alerts.
			 */
			deleteFromWarnCd(connection, failureList, alertReportDetailList);
			progressBar.setProgressPercent(40);
			
			/*
			 * Call private method to update the rabc_alert_msg table for
			 * each alerts selected.
			 */
			updateAlertMsg(connection, failureList, args, alertReportDetailList);
			progressBar.setProgressPercent(60);
			
			/*
			 * Call private method to insert the alert comments into 
			 * rabc_alert_comment table for each alerts selected.
			 */
			insertAlertComment(connection, failureList, args, alertReportDetailList);
			progressBar.setProgressPercent(70);
			
			/*
			 * Call private method to insert the records into rabc_warn_cd table
			 * for each alerts selected.
			 */
			insertWarnCd(connection, failureList, args, alertReportDetailList);
			progressBar.setProgressPercent(80);
		}
	}
	
	/**
	 * Private method to update the rabc_dash_presn table with user's input for selected alerts.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param alertReportDetailList
	 */
	private void updateDashPresn(Connection connection, List failureList, List args, List alertReportDetailList) {
		String selectSQL = update_count;
		List argsSql = null;
		MessageFormat mf = new MessageFormat(selectSQL);
		String prepareStatement = null;
		Statement stmt = null;
		String alertStatus = null;
		String alertSevereLvlInd = null;
		String alertRule = null;
		MyDate procDate = null;
		MyDate alertRuleRunDate = null;
		String division = null;
		int alertReportDetailListSize = alertReportDetailList.size();
		
		String formAlertStatus = (String) args.get(1);
		
		try {
			stmt = connection.createStatement();
			if ("CLOSED".equalsIgnoreCase(formAlertStatus)) {
				stmt = connection.createStatement();
				for (int i=0; i<alertReportDetailListSize; i++) {
					alertStatus = ((AlertReportDetail) alertReportDetailList.get(i)).getAlertStatus();
					alertSevereLvlInd = ((AlertReportDetail) alertReportDetailList.get(i)).getAlertSeverityLevelInd();
					alertRule = ((AlertReportDetail) alertReportDetailList.get(i)).getAlertRule();
					procDate = ((AlertReportDetail) alertReportDetailList.get(i)).getProcDate();
					alertRuleRunDate = ((AlertReportDetail) alertReportDetailList.get(i)).getAlertRuleRunDate();
					division = ((AlertReportDetail) alertReportDetailList.get(i)).getAlertData1();
					if (!"S".equals(alertSevereLvlInd)) {
						if (!"CLOSED".equalsIgnoreCase(alertStatus)) {
							argsSql = new ArrayList();
							if ("1".equals(alertSevereLvlInd)) {
								argsSql.add("severe_lvl_high_ct = severe_lvl_high_ct - 1,");
							} else if ("2".equals(alertSevereLvlInd)) {
								argsSql.add("severe_lvl_mid_ct = severe_lvl_mid_ct - 1,");
							} else if ("3".equals(alertSevereLvlInd)) {
								argsSql.add("severe_lvl_low_ct = severe_lvl_low_ct - 1,");
							} else {
								argsSql.add("");
							}
							if ("WARNING".equalsIgnoreCase(alertStatus)) {
								argsSql.add("warn_ct = warn_ct - 1, clsd_ct = clsd_ct + 1");
							} else if ("PENDING".equalsIgnoreCase(alertStatus)) {
								argsSql.add("pend_ct = pend_ct - 1, clsd_ct = clsd_ct + 1");
							} else {
								argsSql.add("");
							}
							argsSql.add(alertRule);
							if (procDate != null) {
								argsSql.add("and proc_date = to_date('" + procDate.toString() + "', 'mm/dd/yyyy')");
							} else {
								argsSql.add("");
							}
							if (alertRuleRunDate != null) {
								argsSql.add("and alert_rule_run_dt = to_date('" + alertRuleRunDate.toString() + "', 'mm/dd/yyyy')");
							} else {
								argsSql.add("");
							}
							if (division == null || "".equals(division)) {
								argsSql.add("and alert_key1 is null");
							} else {
								argsSql.add("and alert_key1 = '" + division + "'");
							}
							prepareStatement = mf.format((String[])argsSql.toArray(new String[argsSql.size()]));
							stmt.addBatch(prepareStatement);
						}
					}
				}
				stmt.executeBatch();
			} else if ("WARNING".equalsIgnoreCase(formAlertStatus)) {
				stmt = connection.createStatement();
				for (int i=0; i<alertReportDetailListSize; i++) {
					alertStatus = ((AlertReportDetail) alertReportDetailList.get(i)).getAlertStatus();
					alertSevereLvlInd = ((AlertReportDetail) alertReportDetailList.get(i)).getAlertSeverityLevelInd();
					alertRule = ((AlertReportDetail) alertReportDetailList.get(i)).getAlertRule();
					procDate = ((AlertReportDetail) alertReportDetailList.get(i)).getProcDate();
					alertRuleRunDate = ((AlertReportDetail) alertReportDetailList.get(i)).getAlertRuleRunDate();
					division = ((AlertReportDetail) alertReportDetailList.get(i)).getAlertData1();
					if (!"S".equals(alertSevereLvlInd)) {
						if (!"WARNING".equalsIgnoreCase(alertStatus)) {
							argsSql = new ArrayList();
							if ("CLOSED".equalsIgnoreCase(alertStatus)) {
								if ("1".equals(alertSevereLvlInd)) {
									argsSql.add("severe_lvl_high_ct = severe_lvl_high_ct + 1,");
								} else if ("2".equals(alertSevereLvlInd)) {
									argsSql.add("severe_lvl_mid_ct = severe_lvl_mid_ct + 1,");
								} else if ("3".equals(alertSevereLvlInd)) {
									argsSql.add("severe_lvl_low_ct = severe_lvl_low_ct + 1,");
								} else {
									argsSql.add("");
								}
							} else {
								argsSql.add("");
							}
							if ("PENDING".equalsIgnoreCase(alertStatus)) {
								argsSql.add("pend_ct = pend_ct - 1, warn_ct = warn_ct + 1");
							} else if ("CLOSED".equalsIgnoreCase(alertStatus)) {
								argsSql.add("clsd_ct = clsd_ct - 1, warn_ct = warn_ct + 1");
							} else {
								argsSql.add("");
							}
							argsSql.add(alertRule);
							if (procDate != null) {
								argsSql.add("and proc_date = to_date('" + procDate.toString() + "', 'mm/dd/yyyy')");
							} else {
								argsSql.add("");
							}
							if (alertRuleRunDate != null) {
								argsSql.add("and alert_rule_run_dt = to_date('" + alertRuleRunDate.toString() + "', 'mm/dd/yyyy')");
							} else {
								argsSql.add("");
							}
							if (division == null || "".equals(division)) {
								argsSql.add("and alert_key1 is null");
							} else {
								argsSql.add("and alert_key1 = '" + division + "'");
							}
							prepareStatement = mf.format((String[])argsSql.toArray(new String[argsSql.size()]));
							stmt.addBatch(prepareStatement);
						}
					}
				}
				stmt.executeBatch();
			} else if ("PENDING".equalsIgnoreCase(formAlertStatus)) {
				stmt = connection.createStatement();
				for (int i=0; i<alertReportDetailListSize; i++) {
					alertStatus = ((AlertReportDetail) alertReportDetailList.get(i)).getAlertStatus();
					alertSevereLvlInd = ((AlertReportDetail) alertReportDetailList.get(i)).getAlertSeverityLevelInd();
					alertRule = ((AlertReportDetail) alertReportDetailList.get(i)).getAlertRule();
					procDate = ((AlertReportDetail) alertReportDetailList.get(i)).getProcDate();
					alertRuleRunDate = ((AlertReportDetail) alertReportDetailList.get(i)).getAlertRuleRunDate();
					division = ((AlertReportDetail) alertReportDetailList.get(i)).getAlertData1();
					if (!"S".equals(alertSevereLvlInd)) {
						if (!"PENDING".equalsIgnoreCase(alertStatus)) {
							argsSql = new ArrayList();
							if ("CLOSED".equalsIgnoreCase(alertStatus)) {
								if ("1".equals(alertSevereLvlInd)) {
									argsSql.add("severe_lvl_high_ct = severe_lvl_high_ct + 1,");
								} else if ("2".equals(alertSevereLvlInd)) {
									argsSql.add("severe_lvl_mid_ct = severe_lvl_mid_ct + 1,");
								} else if ("3".equals(alertSevereLvlInd)) {
									argsSql.add("severe_lvl_low_ct = severe_lvl_low_ct + 1,");
								} else {
									argsSql.add("");
								}
							} else {
								argsSql.add("");
							}
							if ("WARNING".equalsIgnoreCase(alertStatus)) {
								argsSql.add("pend_ct = pend_ct + 1, warn_ct = warn_ct - 1");
							} else if ("CLOSED".equalsIgnoreCase(alertStatus)) {
								argsSql.add("pend_ct = pend_ct + 1, clsd_ct = clsd_ct - 1");
							} else {
								argsSql.add("");
							}
							argsSql.add(alertRule);
							if (procDate != null) {
								argsSql.add("and proc_date = to_date('" + procDate.toString() + "', 'mm/dd/yyyy')");
							} else {
								argsSql.add("");
							}
							if (alertRuleRunDate != null) {
								argsSql.add("and alert_rule_run_dt = to_date('" + alertRuleRunDate.toString() + "', 'mm/dd/yyyy')");
							} else {
								argsSql.add("");
							}
							if (division == null || "".equals(division)) {
								argsSql.add("and alert_key1 is null");
							} else {
								argsSql.add("and alert_key1 = '" + division + "'");
							}
							prepareStatement = mf.format((String[])argsSql.toArray(new String[argsSql.size()]));
							stmt.addBatch(prepareStatement);
						}
					}
				}
				stmt.executeBatch();
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
		} finally{
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
	}
	
	/**
	 * Private method to delete records from rabc_warn_cd table for selected alerts.
	 * 
	 * @param connection
	 * @param failureList
	 * @param alertReportDetailList
	 */
	private void deleteFromWarnCd(Connection connection, List failureList, List alertReportDetailList) {
		String messageNumbers = getMsgNums(alertReportDetailList);
		if (messageNumbers.equals("")) {
			messageNumbers = "''";
		} else {
			messageNumbers = messageNumbers.substring(0, messageNumbers.length()-1);
		}
		
		String selectSQL = delete_comments;
		List argsSql = new ArrayList();
		argsSql.add(messageNumbers);
		
		String prepareStatement = null;
		Statement stmt = null;
		
		try{
			MessageFormat mf = new MessageFormat(selectSQL);
			prepareStatement = mf.format((String[])argsSql.toArray(new String[argsSql.size()]));
			stmt = connection.createStatement();
			stmt.executeUpdate(prepareStatement);
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
		} finally{
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
	}
		
	/**
	 * Private method to update the rabc_alert_msg table with user's input for selected alerts.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param alertReportDetailList
	 */
	private void updateAlertMsg(Connection connection, List failureList, List args, List alertReportDetailList) {
		String selectSQL = update_alert_sts;
		List argsSql = null;
		MessageFormat mf = new MessageFormat(selectSQL);
		String prepareStatement = null;
		Statement stmt = null;
		
		String alertStatus = null;
		Double revenueImpactValue = null;
		Double lostRevenueImpactValue = null;
		String rootCause = null;
		int msgNo = 0;
		
		String userId = (String) args.get(0);
		String formAlertStatus = (String) args.get(1);
		String formRevenueImpactValue = (String) args.get(2);
		String[] formRootCauseCategories = (String[]) args.get(3);
		String formRootCause = (String) args.get(4);
		String formComments = (String) args.get(5);
		String formLostRevenueImpactValue = (String) args.get(6);
		
		int alertReportDetailListSize = alertReportDetailList.size();

		try {
			stmt = connection.createStatement();
			for (int i=0; i<alertReportDetailListSize; i++) {
				argsSql = new ArrayList();
				alertStatus = ((AlertReportDetail) alertReportDetailList.get(i)).getAlertStatus();
				revenueImpactValue = ((AlertReportDetail) alertReportDetailList.get(i)).getAlertRevenue();
				lostRevenueImpactValue = ((AlertReportDetail) alertReportDetailList.get(i)).getAlertLostRevenue();
				rootCause = ((AlertReportDetail) alertReportDetailList.get(i)).getAlertRootCause();
				msgNo = ((AlertReportDetail) alertReportDetailList.get(i)).getMsgNo();
				if ((formAlertStatus != null && !formAlertStatus.equals("") && !formAlertStatus.equals(alertStatus))
						|| (formRevenueImpactValue != null && !formRevenueImpactValue.equals(revenueImpactValue))
						|| (formLostRevenueImpactValue != null && !formLostRevenueImpactValue.equals(lostRevenueImpactValue))
						|| (formRootCause != null && !formRootCause.equals(rootCause))
						|| (formRootCauseCategories != null && formRootCauseCategories.length > 0)
						|| (formComments != null && !formComments.equals(""))) {
					argsSql.add(userId);
					if (formAlertStatus != null && !formAlertStatus.equals("") && !formAlertStatus.equals(alertStatus)) {
						argsSql.add(",alert_status = '" + formAlertStatus + "'");
					} else {
						argsSql.add("");
					}
					if ((formRevenueImpactValue != null) && (!formRevenueImpactValue.equals("")) && (!formRevenueImpactValue.equals(revenueImpactValue))) {
						double formRevenueImpactValue1 = (new Double(formRevenueImpactValue.trim())).doubleValue();
						argsSql.add(",alert_revenue = " + formRevenueImpactValue1 + " ");
					} else if ((formRevenueImpactValue == null) || (formRevenueImpactValue.equals(""))) {
						argsSql.add(",alert_revenue = null ");
					} else {
						argsSql.add("");
					}
					if ((formLostRevenueImpactValue != null) && (!formLostRevenueImpactValue.equals("")) && (!formLostRevenueImpactValue.equals(lostRevenueImpactValue))) {
						double formLostRevenueImpactValue1 = (new Double(formLostRevenueImpactValue.trim())).doubleValue();
						argsSql.add(",alert_lost_revenue = " + formLostRevenueImpactValue1 + " ");
					} else if ((formLostRevenueImpactValue == null) || (formLostRevenueImpactValue.equals(""))) {
						argsSql.add(",alert_lost_revenue = null ");
					} else {
						argsSql.add("");
					}
					if (formRootCause != null && !formRootCause.equals(rootCause)) {
						argsSql.add(",alert_root_cause = '" + formRootCause + "'");
					} else {
						argsSql.add("");
					}
					argsSql.add((new Integer(msgNo)).toString());
					prepareStatement = mf.format((String[])argsSql.toArray(new String[argsSql.size()]));
					stmt.addBatch(prepareStatement);
				}
			}
			stmt.executeBatch();
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
		} finally{
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
	}
	
	/**
	 * Private method to insert user's comment into rabc_alert_comment table for selected alerts.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param alertReportDetailList
	 */
	private void insertAlertComment(Connection connection, List failureList, List args, List alertReportDetailList) {
		String selectSQL = update_comment;
		List argsSql = null;
		MessageFormat mf = new MessageFormat(selectSQL);
		String prepareStatement = null;
		Statement stmt = null;
		int msgNo = 0;
		String userId = (String) args.get(0);
		String formComments = (String) args.get(5);
		int alertReportDetailListSize = alertReportDetailList.size();
		try {
			stmt = connection.createStatement();
			for (int i=0; i<alertReportDetailListSize; i++) {
				msgNo = ((AlertReportDetail) alertReportDetailList.get(i)).getMsgNo();
				if (formComments != null && !formComments.equals("")) {
					argsSql = new ArrayList();
					argsSql.add((new Integer(msgNo)).toString());
					argsSql.add(formComments);
					argsSql.add(userId);
					prepareStatement = mf.format((String[])argsSql.toArray(new String[argsSql.size()]));
					stmt.addBatch(prepareStatement);
				}
			}
			stmt.executeBatch();
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
		} finally{
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
	}
	
	/**
	 * Private method to insert records into rabc_warn_cd table with user's input for selected alerts.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param alertReportDetailList
	 */
	private void insertWarnCd(Connection connection, List failureList, List args, List alertReportDetailList) {
		String selectSQL = update_warn_cd;
		List argsSql = null;
		MessageFormat mf = new MessageFormat(selectSQL);
		String prepareStatement = null;
		Statement stmt = null;
		int msgNo = 0;
		String[] formRootCauseCategories = (String[]) args.get(3);
		int alertReportDetailListSize = alertReportDetailList.size();
		try {
			stmt = connection.createStatement();
			for (int i=0; i<alertReportDetailListSize; i++) {
				msgNo = ((AlertReportDetail) alertReportDetailList.get(i)).getMsgNo();
				if (formRootCauseCategories != null) {
					int formRootCauseCategoriesLength = formRootCauseCategories.length;
					for (int j=0; j<formRootCauseCategoriesLength; j++) {
						argsSql = new ArrayList();
						argsSql.add((new Integer(msgNo)).toString());
						argsSql.add(formRootCauseCategories[j]);
						prepareStatement = mf.format((String[])argsSql.toArray(new String[argsSql.size()]));
						stmt.addBatch(prepareStatement);
					}
				}
			}
			stmt.executeBatch();
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
		} finally{
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
	}
}
