package com.att.bac.rabc.load.calnet;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import com.sbc.bac.rabc.load.StaticFieldKeys;

public class CalnetLoadUtil {
	public static final DateFormat DATE_FORMAT = new SimpleDateFormat("MMddyyyy");
	
	private CalnetLoadUtil(){
		//no need to instaniate this.
	}
	

	/**
	 * pulls the cycle code from a CALNET-2 format file name
	 * @param fileName assumes a standard CALNET-2 Filename format.
	 * @return the cycle number as an int.
	 */
	public static int getCycle(String fileName){
		return Integer.parseInt(fileName.substring(6, 10));
	}
	/**
	 * pulls the cycle code from a CALNET-2 format file name
	 * @param calnet2file - assumes file with a standard CALNET-2 Filename format.
	 * @return the cycle number as an int.
	 */
	public static int getCycle(File calnet2file){
		return getCycle(calnet2file.getName());
	}
	
	
	/**
	 * pulls the division from a CALNET-2 format file name. 
	 * @param fileName - assumes a standard CALNET-2 Filename format.
	 * @return either a division code, or null if not appropriate.
	 */
	public static String getDivision(String fileName){
		if (fileName.charAt(3) == StaticFieldKeys.C)
			return StaticFieldKeys.PACBELLNORTH;
		else if (fileName.charAt(3) == StaticFieldKeys.I)
			return StaticFieldKeys.PACBELLSOUTH;
		return null;
	}
	
	/**
	 * pulls the division from a CALNET-2 format file name. 
	 * @param calnet2file - assumes file with a standard CALNET-2 Filename format.
	 * @return either a division code, or null if not appropriate.
	 */
	public static String getDivision(File calnet2file){
		return getDivision(calnet2file.getName());
	}
	
	/**
	 * pulls the file id from a CALNET-2 format file name.  
	 * @param fileName - assumes file with a standard CALNET-2 Filename format.
	 * @return the eight letter file id
	 */
	public static String getFileId(String fileName){
		return fileName.substring(11,19);
	}
	/**
	 * pulls the file id from a CALNET-2 format file name.  
	 * @param calnet2file - assumes file with a standard CALNET-2 Filename format.
	 * @return the eight letter file id
	 */
	public static String getFileId(File calnet2file){
		return getFileId(calnet2file.getName());
	}
	
	/**
	 * pulls the region code from a CALNET-2 format file name.  
	 * @param fileName - assumes a standard CALNET-2 Filename format.
	 * @return the two letter region code
	 */
	public static String getRegion(String fileName){
		return fileName.substring(0, 2);
	}
	
	
	/**
	 * pulls the region code from a CALNET-2 format file name.  
	 * @param calnet2file - assumes file with a standard CALNET-2 Filename format.
	 * @return the two letter region code
	 */
	public static String getRegion(File calnet2file){
		return getRegion(calnet2file.getName());
	}
	
	
	/**
	 * Determines whether a line in the file is the header record.
	 * 
	 * @param line
	 * @return
	 */
	public static boolean isHeader(String line) {
		return line.startsWith("HEADER");
	}
	
	/**
	 * Determines whether a line in the file is the trailer record.
	 * 
	 * @param line
	 * @return
	 */
	public static boolean isTrailer(String line) {
		return line.startsWith("TRAILER");
	}
}
