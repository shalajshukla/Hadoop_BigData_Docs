/* Component Name: RABCPPG01203
 * Module Name: DefaultsDAO.java
 * Created on Jul 17, 2006
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.defaults;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.att.bac.rabc.RABCException;
import com.att.carat.util.JDBCUtil;

/**This is the Data Access Object class for the User Defaults process.  The purpose of this class
 * is to interact with the database to get data, insert data, or delete data.  All exceptions are
 * thrown back to the action class.
 * 
 * @author js3175
 */
public class DefaultsDAO {
	private static final Logger logger = Logger.getLogger(DefaultsDAO.class);
	
	/**This static method is called by the action class to get the user's division choice depending
	 * upon the region the user is running RABC in.  This value is used to show what division will be
	 * displayed in a report.
	 * 
	 * @param conn  the connection created in the action class
	 * @param userId  the userId of the user
	 * @return divChoice  the user's current division choice
	 */
	public static String getDivisionChoice(Connection conn, String userId) throws RABCException {
		logger.debug("Starting DefaultsDAO.getDivisionChoice");
		PreparedStatement ps = null;
		ResultSet rs = null;
		String divChoice = "";
		String getDivChoice = "SELECT DIVISION " +
		  					  "FROM RABC_USER_DEFAULT_DIVISION " +
		  					  "WHERE USER_ID = ?";
		try {
			ps = conn.prepareStatement(getDivChoice);
			ps.setString(1, userId);
			rs = ps.executeQuery();
			if (rs.next() && rs.getString("DIVISION") != null){
				divChoice = rs.getString("DIVISION");
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving division using getDivChoice query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
		logger.debug("Finished DefaultsDAO.getDivisionChoice");
		return divChoice.trim();
	}
	
	/**This static method is called by the action class to get the user's line count choice depending
	 * upon the region the user is running RABC in.  This value is used to show how many lines will be
	 * displayed on a report page.
	 * 
	 * @param conn  the connection created in the action class
	 * @param userId  the userId of the user
	 * @return lineCt  the user's current line count choice
	 */
	public static String getLineCountChoice(Connection conn, String userId) throws RABCException {
		logger.debug("Starting DefaultsDAO.getLineCountChoice");
		PreparedStatement ps = null;
		ResultSet rs = null;
		String lineCt = "";
		String getLCChoice = "SELECT LINE_CT " +
		  					  "FROM RABC_USER_DEFAULT_RPT_LINE " +
		  					  "WHERE USER_ID = ?";
		try {
			ps = conn.prepareStatement(getLCChoice);
			ps.setString(1, userId);
			rs = ps.executeQuery();
			if (rs.next()){
				lineCt = Integer.toString(rs.getInt("LINE_CT"));
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving line count using getLCChoice query: ", sqle);
		} catch (NumberFormatException nfe) {
			throw new RABCException("Error in converting line number: ", nfe);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
		logger.debug("Finished DefaultsDAO.getLineCountChoice");
		return lineCt.trim();
	}
	

	/**This static method is called by the action class to get the user's choice to disable or enable the warning 
	 * email notifications.
	 *  
	 * @param conn  the connection created in the action class
	 * @param userId  the userId of the user
	 * @return lineCt  the user's current email notification choice
	 */
	public static Defaults getDisableSeverityValues(Connection conn, String userId, String tableNode) throws RABCException {
		logger.debug("Starting DefaultsDAO.getDisableEmailNotifyChoice");
		PreparedStatement ps = null;
		ResultSet rs = null;
		String notifyChoice = "";
		int severity=0 ; 
		Defaults defaults; 
		String getLCChoice = "SELECT DISABLE_EMAIL_IND, MIN_SEV_LVL  " +
		"FROM RABC_USER_DEFAULT_EMAIL " +
		"WHERE USER_ID = ?";
		try {
			ps = conn.prepareStatement(getLCChoice);
			ps.setString(1, userId);
			rs = ps.executeQuery();
			if (rs.next()){
				notifyChoice = rs.getString("DISABLE_EMAIL_IND");
				severity= rs.getInt("MIN_SEV_LVL");
				if(notifyChoice==null){
					notifyChoice="N";
				}
				
			}
			defaults = new Defaults(notifyChoice,severity);
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving disable indicator using getDENChoice query: ", sqle);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
		logger.debug("Finished DefaultsDAO.getDisableEmailNotifyChoice");
//		if(notifyChoice.equalsIgnoreCase("N"))
//		return severity.trim(); 
//		else 
			return defaults;//notifyChoice.trim();
	}
	
	/**This static method is called by the action class to get the user's choice for the minimum warning severity level
	 * of email sent.
	 *  
	 * @param conn  the connection created in the action class
	 * @param userId  the userId of the user
	 * @return sevlvl  the user's minimum warning severity level choice
	 */
	public static int getWarningSevChoice(Connection conn, String userId, String tableNode) throws RABCException {
		logger.debug("Starting DefaultsDAO.getWarningSevChoice");
		PreparedStatement ps = null;
		ResultSet rs = null;
		int sevlvl=0 ;
		String getLCChoice = "SELECT MIN_SEV_LVL " +
		  					  "FROM RABC_USER_DEFAULT_EMAIL " +
		  					  "WHERE USER_ID = ?";
		try {
			ps = conn.prepareStatement(getLCChoice);
			ps.setString(1, userId);
			rs = ps.executeQuery();
			if (rs.next()){
				sevlvl = rs.getInt("MIN_SEV_LVL");
			}
		} catch (SQLException sqle) {
			throw new RABCException("Error in retrieving severity choice using getWSChoice query: ", sqle);
		} catch (NumberFormatException nfe) {
				JDBCUtil.rollback(conn);
				throw new RABCException("Error in retrieving severity choice: ", nfe);
		} finally {
			JDBCUtil.closeResultSet(rs);
			JDBCUtil.closePreparedStatement(ps);
		}
		logger.debug("Finished DefaultsDAO.getWarningSevChoice");
		return sevlvl;
	}
	
	
	/**This static method is called by the action class to delete the user's division choice from
	 * the database.
	 * 
	 * @param conn  the connection created in the action class
	 * @param userId  the userId of the user
	 */
	protected static void deleteDivisionChoice(Connection conn, String userId) throws RABCException {
		logger.debug("Starting DefaultsDAO.deleteDivisionChoice");
		PreparedStatement ps = null;
		String delDivChoice = "DELETE FROM RABC_USER_DEFAULT_DIVISION " +
		  					  "WHERE USER_ID = ?";
		try {
			ps = conn.prepareStatement(delDivChoice);
			ps.setString(1, userId);
			ps.execute();
			logger.debug("Finished DefaultsDAO.deleteDivisionChoice");
		} catch (SQLException sqle) {
			JDBCUtil.rollback(conn);
			throw new RABCException("Error in deleting division using delDivChoice query: ", sqle);
		} finally {
			JDBCUtil.closePreparedStatement(ps);
		}
	}
	
	/**This static method is called by the action class to delete the user's line count choice from
	 * the database.
	 * 
	 * @param conn  the connection created in the action class
	 * @param userId  the userId of the user
	 */
	protected static void deleteLineCountChoice(Connection conn, String userId) throws RABCException {
		logger.debug("Starting DefaultsDAO.deleteLineCountChoice");
		PreparedStatement ps = null;
		String delLCChoice = "DELETE FROM RABC_USER_DEFAULT_RPT_LINE " +
		  					 "WHERE USER_ID = ?";
		try {
			ps = conn.prepareStatement(delLCChoice);
			ps.setString(1, userId);
			ps.execute();
			logger.debug("Finished DefaultsDAO.deleteLineCountChoice");
		} catch (SQLException sqle) {
			JDBCUtil.rollback(conn);
			throw new RABCException("Error in deleting line count using delLCChoice query: ", sqle);
		} finally {
			JDBCUtil.closePreparedStatement(ps);
		}
	}
	

	/**This static method is called by the action class to delete the user's choice to enable or 
	 * disable email warning notifications  and the minimum severity level from the database.
	 * 
	 * @param conn  the connection created in the action class
	 * @param userId  the userId of the user
	 */
	protected static void deleteSevChoice(Connection conn, String userId, String tableNode) throws RABCException {
		logger.debug("Starting DefaultsDAO.deleteNotifySevChoice");
		PreparedStatement ps = null;
		String delNSChoice = "DELETE FROM RABC_USER_DEFAULT_EMAIL " +
		"WHERE USER_ID = ? ";
		try {
			ps = conn.prepareStatement(delNSChoice);
			ps.setString(1, userId);
			ps.execute();
			logger.debug("Finished DefaultsDAO.deleteNotifySevChoice");
		} catch (SQLException sqle) {
			JDBCUtil.rollback(conn);
			throw new RABCException("Error in deleting line count using delNSChoice query: ", sqle);
		} finally {
			JDBCUtil.closePreparedStatement(ps);
		}
	}
	
	/**This static method is called by the action class to insert the user's new division choice into
	 * the database.
	 * 
	 * @param conn  the connection created in the action class
	 * @param userId  the userId of the user
	 * @param division  the updated division value
	 */
	protected static void insertDivisionChoice(Connection conn, String userId, String division) throws RABCException {
		logger.debug("Starting DefaultsDAO.insertDivisionChoice");
		PreparedStatement ps = null;
		String insDivChoice = "INSERT INTO RABC_USER_DEFAULT_DIVISION (USER_ID, DIVISION) " +
		  					  "VALUES (?,?)";
		try {
			ps = conn.prepareStatement(insDivChoice);
			ps.setString(1, userId);
			ps.setString(2, division);
			ps.execute();
			logger.debug("Finished DefaultsDAO.insertDivisionChoice");
		} catch (SQLException sqle) {
			JDBCUtil.rollback(conn);
			throw new RABCException("Error in inserting division using insDivChoice query: ", sqle);
		} finally {
			JDBCUtil.closePreparedStatement(ps);
		}
	}
	
	/**This static method is called by the action class to insert the user's new line count choice into
	 * the database.
	 * 
	 * @param conn  the connection created in the action class
	 * @param userId  the userId of the user
	 * @param lineCount  the updated line count value
	 */
	protected static void insertLineCountChoice(Connection conn, String userId, String lineCount) throws RABCException {
		logger.debug("Starting DefaultsDAO.insertLineCountChoice");
		PreparedStatement ps = null;
		String insLCChoice = "INSERT INTO RABC_USER_DEFAULT_RPT_LINE (USER_ID, LINE_CT) " +
		  					 "VALUES (?,?)";
		try {
			ps = conn.prepareStatement(insLCChoice);
			ps.setString(1, userId);
			ps.setInt(2, Integer.parseInt(lineCount));
			ps.execute();
			logger.debug("Finished DefaultsDAO.insertLineCountChoice");
		} catch (SQLException sqle) {
			JDBCUtil.rollback(conn);
			throw new RABCException("Error in inserting line count using insLCChoice query: ", sqle);
		} catch (NumberFormatException nfe) {
			JDBCUtil.rollback(conn);
			throw new RABCException("Error in converting line number: ", nfe);
		} finally {
			JDBCUtil.closePreparedStatement(ps);
		}
	}
	
	/**This static method is called by the action class to insert the user's choice for disabling warning 
	 * email notifications into the database.
	 * 
	 * @param conn  the connection created in the action class
	 * @param userId  the userId of the user
	 * @param lineCount  the updated line count value
	 */
	protected static void updateDisableEmailNotifyChoice(Connection conn, String tableNode, String notify, int sev, String userId ) throws RABCException {
		logger.debug("Starting DefaultsDAO.insertDisableEmailNotifyChoice");
		PreparedStatement ps = null;
		String checkId = checkUserId(conn, tableNode, userId);
		String updateDENChoice="";
		if((checkId.equalsIgnoreCase(""))||(checkId.equalsIgnoreCase(null))){
			updateDENChoice = "INSERT INTO RABC_USER_DEFAULT_EMAIL (USER_ID, DISABLE_EMAIL_IND,MIN_SEV_LVL) " +
			"VALUES (?,?,?)";

			try {
				ps = conn.prepareStatement(updateDENChoice);
				ps.setString(1, userId);
				ps.setString(2, notify);
				ps.setInt(3,sev);
				ps.execute();
				logger.debug("Finished update in  DefaultsDAO.updateDisableEmailNotifyChoice");
			} catch (SQLException sqle) {
				JDBCUtil.rollback(conn);
				throw new RABCException("Error in updating userId and disable settings using updateDENChoice query: ", sqle);
			} catch (NumberFormatException nfe) {
				JDBCUtil.rollback(conn);
				throw new RABCException("Error in converting line number: ", nfe);
			} finally {
				JDBCUtil.closePreparedStatement(ps);
			}
		}else{

			updateDENChoice = "UPDATE RABC_USER_DEFAULT_EMAIL SET DISABLE_EMAIL_IND=(?), MIN_SEV_LVL=(?) WHERE USER_ID = (?)";
			try {
				ps = conn.prepareStatement(updateDENChoice);
				
					ps.setString(1, notify);
				if(notify.equalsIgnoreCase("Y")){
					ps.setInt(2, 0);
				}else{
					ps.setString(1, "N");
					ps.setInt(2, sev);
				}
				ps.setString(3, userId);
				ps.execute();
				logger.debug("Finished insert in DefaultsDAO.updateDisableEmailNotifyChoice");
			} catch (SQLException sqle) {
				JDBCUtil.rollback(conn);
				throw new RABCException("Error in inserting userId and disable settings using updateDENChoice query: ", sqle);
			} finally {
				JDBCUtil.closePreparedStatement(ps);
			}
		}
	}


	/**This static method is called by the action class to search for the user id in the *_user_default_email 
	 * table in the the database.
	 * 
	 * @param conn  the connection created in the action class
	 * @param userId  the userId of the user
	 * @param lineCount  the updated line count value
	 */
	protected static String checkUserId(Connection conn, String tableNode, String userId) throws RABCException {
		logger.debug("Starting DefaultsDAO.insertWarningSevChoice");
		PreparedStatement ps = null;
		ResultSet rs = null;
		String checkUserId = "select user_id from rabc_user_default_email where user_id= '"+ userId+"'";
		String id = "";

		try {
			ps = conn.prepareStatement(checkUserId);
			rs = ps.executeQuery();
			if(rs.next())
			{
				id = rs.getString("USER_ID");
			}
			logger.debug("Finished DefaultsDAO.checkUserId");
		} catch (SQLException sqle) {
			JDBCUtil.rollback(conn);
			throw new RABCException("Error in checking for user_id using checkUserId query: ", sqle);
		} catch (NumberFormatException nfe) {
			JDBCUtil.rollback(conn);
			throw new RABCException("Error in checking for user_id: ", nfe);
		} finally {
			JDBCUtil.closePreparedStatement(ps);
		}
		return id;
	}

}
