/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.admin.alert.rule;

/**
 * This is a Data Object to represent RABC_ALERT_PROC table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class AlertProc {
	private String alertRule;
	private String alertType;
	private String alertItemDdlName;
	private String alertItemDdlData;
	private String alertItemAvgName;
	private String alertProcTbl;
	private String alertProcAvgTbl;
	private String alertCreateInd;
	private String alertMsgSuppDataInd;
	private String alertThrshldDfltInd;
	private int alertCalcNum;
	private int alertTblSelNum;
	private int partiRefId;

	/**
	 * @return Returns the AlertRule.
	 */
	public String getAlertRule() {
		return alertRule;
	}
	/**
	 * @return Returns the AlertType.
	 */
	public String getAlertType() {
		return alertType;
	}
	/**
	 * @return Returns the AlertItemDdlName.
	 */
	public String getAlertItemDdlName() {
		return alertItemDdlName;
	}
	/**
	 * @return Returns the AlertItemDdlData.
	 */
	public String getAlertItemDdlData() {
		return alertItemDdlData;
	}
	/**
	 * @return Returns the AlertItemAvgName.
	 */
	public String getAlertItemAvgName() {
		return alertItemAvgName;
	}
	/**
	 * @return Returns the AlertProcTbl.
	 */
	public String getAlertProcTbl() {
		return alertProcTbl;
	}
	/**
	 * @return Returns the AlertProcAvgTbl.
	 */
	public String getAlertProcAvgTbl() {
		return alertProcAvgTbl;
	}
	/**
	 * @return Returns the AlertCreateInd.
	 */
	public String getAlertCreateInd() {
		return alertCreateInd;
	}
	/**
	 * @return Returns the AlertMsgSuppDataInd.
	 */
	public String getAlertMsgSuppDataInd() {
		return alertMsgSuppDataInd;
	}
	/**
	 * @return Returns the AlertThrshldDfltInd.
	 */
	public String getAlertThrshldDfltInd() {
		return alertThrshldDfltInd;
	}
	/**
	 * @return Returns the AlertCalcNum.
	 */
	public int getAlertCalcNum() {
		return alertCalcNum;
	}
	/**
	 * @return Returns the AlertTblSelNum.
	 */
	public int getAlertTblSelNum() {
		return alertTblSelNum;
	}
	/**
	 * @return Returns the PartiRefId.
	 */
	public int getPartiRefId() {
		return partiRefId;
	}

	/**
	 * @param AlertRule The alertRule to set.
	 */
	public void setAlertRule(String alertRule) {
		this.alertRule = alertRule;
	}
	/**
	 * @param AlertType The alertType to set.
	 */
	public void setAlertType(String alertType) {
		this.alertType = alertType;
	}
	/**
	 * @param AlertItemDdlName The alertItemDdlName to set.
	 */
	public void setAlertItemDdlName(String alertItemDdlName) {
		this.alertItemDdlName = alertItemDdlName;
	}
	/**
	 * @param AlertItemDdlData The alertItemDdlData to set.
	 */
	public void setAlertItemDdlData(String alertItemDdlData) {
		this.alertItemDdlData = alertItemDdlData;
	}
	/**
	 * @param AlertItemAvgName The alertItemAvgName to set.
	 */
	public void setAlertItemAvgName(String alertItemAvgName) {
		this.alertItemAvgName = alertItemAvgName;
	}
	/**
	 * @param AlertProcTbl The alertProcTbl to set.
	 */
	public void setAlertProcTbl(String alertProcTbl) {
		this.alertProcTbl = alertProcTbl;
	}
	/**
	 * @param AlertProcAvgTbl The alertProcAvgTbl to set.
	 */
	public void setAlertProcAvgTbl(String alertProcAvgTbl) {
		this.alertProcAvgTbl = alertProcAvgTbl;
	}
	/**
	 * @param AlertCreateInd The alertCreateInd to set.
	 */
	public void setAlertCreateInd(String alertCreateInd) {
		this.alertCreateInd = alertCreateInd;
	}
	/**
	 * @param AlertMsgSuppDataInd The alertMsgSuppDataInd to set.
	 */
	public void setAlertMsgSuppDataInd(String alertMsgSuppDataInd) {
		this.alertMsgSuppDataInd = alertMsgSuppDataInd;
	}
	/**
	 * @param AlertThrshldDfltInd The alertThrshldDfltInd to set.
	 */
	public void setAlertThrshldDfltInd(String alertThrshldDfltInd) {
		this.alertThrshldDfltInd = alertThrshldDfltInd;
	}
	/**
	 * @param AlertCalcNum The alertCalcNum to set.
	 */
	public void setAlertCalcNum(int alertCalcNum) {
		this.alertCalcNum = alertCalcNum;
	}
	/**
	 * @param AlertTblSelNum The alertTblSelNum to set.
	 */
	public void setAlertTblSelNum(int alertTblSelNum) {
		this.alertTblSelNum = alertTblSelNum;
	}
	/**
	 * @param PartiRefId The partiRefId to set.
	 */
	public void setPartiRefId(int partiRefId) {
		this.partiRefId = partiRefId;
	}
}
