/*
 * Module description: 
 * Load job for OCC control point in case of SW region.
 * 
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 *
 * Modification History:                                     
 * SBCUID		Date			Description                         	    	
 * ------		--------		-----------
 * VD3159		20060816		Initial version for EAP 556013  
 * SH8512		20070125		Modification as part of Live Defect 57335
 */

package com.att.bac.rabc.load.occ.sw;

import java.io.File;
import java.net.UnknownHostException;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import com.att.bac.rabc.util.EmcisEventLogger;
import com.att.bac.util.NetUtil;
import com.att.carat.util.JDBCUtil;
import com.sbc.bac.rabc.load.FilePatternLoadJob;
import com.sbc.bac.rabc.load.PrepareTableForRerun;
import com.sbc.bac.rabc.load.RabcLoadJobTrig;
import com.sbc.bac.rabc.load.RetrieveStaticInfo;
import com.sbc.bac.rabc.load.StaticErrorMsgKeys;
import com.sbc.bac.rabc.load.StaticFieldKeys;

public class DailyOCCSWLoadJob extends FilePatternLoadJob {
	/*
	 *  Prepared statements
	 */
	private PreparedStatement insertRDOASW;
	
	/*
	 * Common variables
	 */
	private String division, runDate;
	private Date sqlRunDate;
	private String backupRecovery = null; 
	private DateFormat df = new SimpleDateFormat("yyyyD");
	private File currentFile;
	private int lineCount = 0;
	private String fieldSeperator = StaticFieldKeys.SEMICOLON;
	
	private int actvtBatchCounter;
	
	private String fileName, fileToken, region;
	/*
	 * HashMap variables to contain the groups for various tables.
	 */
	private HashMap occActvtMap;
	
	/*
	 * boolean variables indicating whether trigger to be inserted for that file id.
	 */
	boolean isDailyOccActvt;
	
	/**
	 * Method will run prior processing of the file. Here we will form the actual INSERT statements 
	 * which need to be fired on to the database.
	 */
	public boolean preprocess() {
		super.preprocess();

		try {
			StringBuffer sql = new StringBuffer();
			sql.append("INSERT INTO RABC_DAILY_OCC_ACTVT (RUN_DATE, DIVISION, FILE_ID, BUS_TYPE, OCC_CD, OCC_TYPE, ECBR_IND, OCC_CT_CR, OCC_AMT_CR, OCC_CT_DB, OCC_AMT_DB) ");
			sql.append("VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ");
			insertRDOASW = connection.prepareStatement(sql.toString());
			
		} catch (SQLException e) {
			severe(StaticErrorMsgKeys.PREPROCESS_ERROR + e.getMessage());
			return false;
		}
		return true;
	}
	
	/**
	 * Method will run prior to actual processing of the file.
	 */
	public boolean preprocessFile(File file) {
		boolean success = super.preprocessFile(file);
		fileToken = file.getName().substring(file.getName().indexOf("RA110F01"),file.getName().indexOf("RA110F01")+ 8);
		fileName = file.getName();
		region   =	file.getName().substring(0,2);
		if (success) {
			try {
				/*
				 * Check whether this file has been run before & if yes mark the backoutRecovery flag to "Y"
				 */
				lineCount = 0;

				backupRecovery = null;

				if (RabcLoadJobTrig.IsOriginalFileLoaded(connection, file,file.getName().length())) {
					backupRecovery = "Y";
				}
			} catch (Exception e) {
				severe(StaticErrorMsgKeys.PREPROCESSFILE_ERROR + StaticErrorMsgKeys.FILE_NAME_PARSING_ERROR + e);
				return false;
			}
		}
		
		currentFile = file;
		occActvtMap = new HashMap();
		isDailyOccActvt = false;
		actvtBatchCounter = 0;
		
		return success;
	}

	/**
	 * Method will parse the line.
	 */
	protected int parseLine(String line) throws Exception {
		boolean status=true;
		if (line.indexOf(";")==-1){
			return SKIPPED;
		}
		
		String recortType = getRecordType(line);
		if ("H".equals(recortType)) {
			status = processHeaderRecord(line);
		} else if ("T".equals(recortType)) {
			status = processTrailerRecord(line);
		} else if ("D".equals(recortType)) {
			status = processDateRecord(line);
		} else {
			int retCode = processDetailRecord(line);
			if (retCode == SUCCESS || retCode == SKIPPED)
				status = true;
			else
				status = false;
		}
		
		if (status) 
			return SUCCESS;
		else
			return ERROR;
	}
	
	private String getRecordType(String line) {
		String recordType = null;
		int index = line.indexOf(";");
		String firstField = line.substring(0, index).trim();
		if ("HEADER".equals(firstField)) {
			recordType = "H";
		} else if ("TRAILER".equals(firstField)) {
			recordType = "T";
		} else if ("RA11DATE".equals(firstField)) {
			recordType = "D";
		} else {
			recordType = "X";
		}
		return recordType;
	}
	
	private boolean processDateRecord(String line)  throws Exception {
		//RA11OCCS;07;YYYYDDD;
		boolean success = true;
		String[] lineFields = line.split(fieldSeperator);

		runDate = lineFields[2].trim();
		
		sqlRunDate = new java.sql.Date(df.parse(runDate).getTime());

		// check if the file is a rerun. If so, cleanup tables before process ..
		String tableName = "RABC_DAILY_OCC_ACTVT";
		if ("Y".equals(backupRecovery)){
			success = PrepareTableForRerun.deleteTableData(connection,tableName,division,sqlRunDate);
		}
		
		return success;
	}
		
	
	private boolean processHeaderRecord(String line) throws Exception {
		boolean success = true;
		String[] lineFields = line.split(fieldSeperator);
		division = lineFields[2].trim();
		return success;
	}
	
	/**
	 * 
	 * @param line
	 * @return
	 * @throws Exception
	 */
	private int processDetailRecord(String line) throws Exception {
		lineCount++;
		
		String[] lineFields = line.split(fieldSeperator);
		int sequenceNbr = Integer.parseInt(lineFields[1].trim());

		String fileId = null;
		if (sequenceNbr == 1)
			fileId = "CN50";
		else if (sequenceNbr == 10)
			fileId = "BN40";
		else 
			return SKIPPED;
		
		String busType = null;
		String occRecCd = lineFields[2].trim();
		if ("".equals(occRecCd)){
			occRecCd = " ";
		}
		
		String custType = lineFields[3].trim();
		String wrInd = lineFields[4].trim();
		//it will be retail if blank
		if (wrInd.equals("")){
			wrInd="R";
		}
		String occType = lineFields[5].trim();
		if ("".equals(occType)){
			occType = " ";
		}
		
		String ecbrInd = lineFields[6].trim();
		if ("".equals(ecbrInd)){
			ecbrInd = "N";
		}
		String crbrInd = lineFields[7].trim();
		long totalCount		= Long.parseLong(lineFields[8].trim())/1000000;
		double totalAmount	= Double.parseDouble(lineFields[9].toString().trim())/1000000;
		
		/* If the CR/DB indicator value is space, check the data value. If the data value is less than zero (- ve) than it will be credit.
		   If the data value is greater than (+ve) or equal to zero  then it will be debit.
       */
		
		if ("".equals(crbrInd)||!crbrInd.matches("[12]")){
			if(totalAmount >= 0){
				crbrInd = "1";
			} else {
				crbrInd = "2";
			}
		}
					
		
		if ("".equals(custType) || custType.substring(0,1).equals("1")){
			if (wrInd.substring(0,1).equals("W")){
				busType = "RRES";
			} else { 
				busType = "RES";
			}
		} else {
			if (wrInd.substring(0,1).equals("W")){
				busType = "RBUS";
			} else { 
				busType = "BUS";
			}
		}
		
		DailyOCCSWData occActvt = new DailyOCCSWData();
		occActvt.setRunDate(df.parse(runDate));
		occActvt.setDivision(division);
		occActvt.setBus_type(busType);
		occActvt.setEcbrInd(ecbrInd);
		occActvt.setFileId(fileId);
		occActvt.setOccCd(occRecCd);
		occActvt.setOccType(occType);
		
		
		/*
		 * Check whether the object of DailyOccActvt type is present in the hash map
		 */
		DailyOCCSWData actvtObjRef = null;
		actvtObjRef = (DailyOCCSWData) occActvtMap.get(occActvt);
		
		if (actvtObjRef != null) {
			if (crbrInd.equals("1")){
				long newOccCtDb		= actvtObjRef.getOccChargeCnt() + totalCount;
				double newOccAmtDb	= actvtObjRef.getOccChargeAmt() + totalAmount;
				actvtObjRef.setOccChargeCnt(newOccCtDb);
				actvtObjRef.setOccChargeAmt(newOccAmtDb);
			}else {
				long newOccCtDb		= actvtObjRef.getOccCreditCnt() + totalCount;
				double newOccAmtDb	= actvtObjRef.getOccCreditAmt() + totalAmount;
				actvtObjRef.setOccCreditCnt(newOccCtDb);
				actvtObjRef.setOccCreditAmt(newOccAmtDb);
			}
			occActvtMap.put(actvtObjRef, actvtObjRef);
		} else {
			if (crbrInd.equals("1")){
				occActvt.setOccChargeCnt(totalCount);
				occActvt.setOccChargeAmt(totalAmount);
			}else {
				occActvt.setOccCreditCnt(totalCount);
				occActvt.setOccCreditAmt(totalAmount);
			}
			occActvtMap.put(occActvt, occActvt);
		}
		
		return SUCCESS;
	}
	
	private boolean processTrailerRecord(String line) {
		String[] lineFields = line.split(fieldSeperator);
		int totalRecords = Integer.parseInt(lineFields[5]);
		
		if (totalRecords == lineCount) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * Method will run post to actual processing of the file.
	 */
	public boolean postprocessFile(File file, boolean success) {
		try{

			//Log the file information to EMCIS_EVENT_LOG and EMCIS_EVENT_LOG_DETAIL
			EmcisEventLogger emcisLogger = new EmcisEventLogger();
			String event_id = "RABC_"+fileToken+"_"+region;
            String host = NetUtil.getLocalHostName();
            String hostIP = NetUtil.getLocalIpAddress();
			int sequence = emcisLogger.getEMCISSequence(connection);
			emcisLogger.insertEventLog(connection, sequence, event_id, sqlRunDate, host, hostIP);
			emcisLogger.insertEventLogDetail(connection, sequence, "FileName", fileName);

		}catch (UnknownHostException e) {
            severe("Error getting EMCIS host information ", e);
        }
		if (success) {
			/*
			 * Iterate through the entire map occActvtMap and insert entries into the RABC_DAILY_OCC_ACTVT table
			 */
			Set occActvtSet			= occActvtMap.keySet();
			Iterator occActvtIterator = occActvtSet.iterator();
			
			try {
				while (occActvtIterator.hasNext()) {
					DailyOCCSWData occActvt = (DailyOCCSWData) occActvtIterator.next();
					// RUN_DATE, DIVISION, FILE_ID, BUS_TYPE, OCC_CD, OCC_TYPE, ECBR_IND, OCC_CT_CR, OCC_AMT_CR, OCC_CT_DB, OCC_AMT_DB
					insertRDOASW.setDate(1, sqlRunDate);			//RUN_DATE
					insertRDOASW.setString(2, division);			//DIVISION
					insertRDOASW.setString(3, occActvt.getFileId());	//FILE_ID
					insertRDOASW.setString(4, occActvt.getBus_type());//BUS_TYPE
					insertRDOASW.setString(5, occActvt.getOccCd());	//OCC_CD
					insertRDOASW.setString(6, occActvt.getOccType());	//OCC_TYPE
					insertRDOASW.setString(7, occActvt.getEcbrInd());
					insertRDOASW.setLong(8, occActvt.getOccCreditCnt());
					insertRDOASW.setDouble(9, occActvt.getOccCreditAmt());
					insertRDOASW.setLong(10, occActvt.getOccChargeCnt());
					insertRDOASW.setDouble(11, occActvt.getOccChargeAmt());

					insertRDOASW.addBatch();
					actvtBatchCounter++;
					
					if (actvtBatchCounter % 1000 == 0) {
						insertRDOASW.executeBatch();
					}
					isDailyOccActvt = true;
				}
				
				insertRDOASW.executeBatch();
				
				if (!insertTrigger()) {
					severe(
						StaticErrorMsgKeys.POSTPROCESSFILE_ERROR
							+ StaticErrorMsgKeys.TIGGER_TABLE_INSERT_ERROR);
					success = false;
				}
			}catch (SQLException sqle){
				severe(StaticErrorMsgKeys.INSERT_ERROR + sqle.getMessage());
				success = false;
			}
		}
		return super.postprocessFile(file, success);
	}
	
	private boolean insertTrigger() {
		if (lineCount > 0 && isDailyOccActvt) {
			try {
				String query 	= "SELECT to_char(BILL_RND,'00') FROM RABC_CYCLE_CALENDAR WHERE PROC_DT = to_date('" + sqlRunDate.toString() + "','yyyy-mm-dd')";
				String billRnd	= RetrieveStaticInfo.getBillRnd(connection,query);
				if ("0".equals(billRnd) || "00".equals(billRnd) || "".equals(billRnd.trim())){
					billRnd = "0";
				}
				DateFormat df = new SimpleDateFormat("MMddyyyy");
				
				if(!RabcLoadJobTrig.insertTrigger(connection,currentFile.getName().substring(5,currentFile.getName().length()),currentFile.getName(),"SWOCCCD",division, sqlRunDate.toString().substring(5,7)+sqlRunDate.toString().substring(8,10)+sqlRunDate.toString().substring(0,4) , backupRecovery,billRnd)){
					return false;	
				}
			} catch (Exception e) {
				severe(StaticErrorMsgKeys.POSTPROCESSFILE_ERROR + StaticErrorMsgKeys.NORECORD_RABC_CYCLE_CALENDAR + e);
				return false;
			}
		}
		return true;
		
	}
	
	public boolean postprocess(boolean success) {

		JDBCUtil.closePreparedStatement(insertRDOASW);
	
		return super.postprocess(success);
	}

}
