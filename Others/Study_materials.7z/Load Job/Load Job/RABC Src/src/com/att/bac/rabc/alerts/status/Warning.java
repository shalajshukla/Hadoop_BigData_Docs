/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.status;

/**
 * This is a Data Object to represent RABC_WARN_CD table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class Warning {
	private int msgNum;
	private String alertRootCatgyCd;

	/**
	 * @return Returns the MsgNum.
	 */
	public int getMsgNum() {
		return msgNum;
	}
	/**
	 * @return Returns the AlertRootCatgyCd.
	 */
	public String getAlertRootCatgyCd() {
		return alertRootCatgyCd;
	}

	/**
	 * @param MsgNum The msgNum to set.
	 */
	public void setMsgNum(int msgNum) {
		this.msgNum = msgNum;
	}
	/**
	 * @param AlertRootCatgyCd The alertRootCatgyCd to set.
	 */
	public void setAlertRootCatgyCd(String alertRootCatgyCd) {
		this.alertRootCatgyCd = alertRootCatgyCd;
	}
}
