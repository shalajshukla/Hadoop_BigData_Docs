/*
 * Copyright  2002-2006 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.adhoc.rpt.generator;

import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.adhoc.rpt.AdhocRptDataTO;


/**
 * Factory that creates an appropriate AbstractAdhocGenerator
 * 
 * <p>
 * <hr>
 * <h3>Release History</h3>
 * <p>
 * <ul>
 * 
 * <li>jb6494 Aug 29, 2006 Created class.
 * 
 * </ul>
 * <p>
 * 
 */
public final class AdhocGeneratorFactory extends AdhocRptQueryGeneratorLayout1 {

    /**
     * Create a default AdhocGeneratorFactory
     */
    private AdhocGeneratorFactory() {
        super();
    }


    /**
     * Create an appropriate genrerator
     * 
     * @param dto
     * @return
     * @throws RABCException
     */
    public static AbstractAdhocGenerator createGenerator(AdhocRptDataTO dto) throws RABCException {
        switch (dto.getPresnModel()) {
            case 1:
                return new AdhocRptQueryGeneratorLayout1();
            case 2:
                return new AdhocRptQueryGeneratorLayout2();
            case 3:
            	return new AdhocRptQueryGeneratorLayout3();
                //return new AdhocRptQueryGeneratorLayout1();
            case 4:
                return new AdhocRptQueryGeneratorLayout4();

            default:
                if (dto == null) {
                    throw new RABCException("Could not create AdhocGenerator, dto=null");
                }
                throw new RABCException("Could not create AdhocGenerator, presnModel=" + dto.getPresnModel());
        }
    }
}
