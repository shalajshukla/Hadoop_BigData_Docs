/* Created by Gaurav Bhargava (GB0741) on Dec 8, 2006.
Copyright 2006-2008 AT&T Knowledge Ventures. All rights reserved. */

package com.att.bac.rabc.load.so.calnet;

import java.io.File;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import com.att.bac.rabc.load.calnet.CalnetException;
import com.att.bac.rabc.load.calnet.CalnetLoadJob;
import com.att.bac.rabc.util.EmcisEventLogger;
import com.att.carat.util.NetUtil;
import com.sbc.bac.rabc.load.PrepareTableForRerun;
import com.sbc.bac.rabc.load.StaticErrorMsgKeys;

/**
 * This class reads the data from files whose name fits the pattern:
 * WE.[CI].C[0-9]{4}.XT33ERRS.* . It gets the files from input folder name specified
 * in SOErrCodeCount.cfg file. It parses the file line by line and inserts the records
 * into the RABC_SVC_ORD_Info and RABC_SVC_ORD_AGE table.
 * @author GB0741
 */
public class SvcOrdInfoLoadJob extends CalnetLoadJob {
	List rabcSvcOrdInfos = null;
	
	private String fileName, region;

	/**
	 * @return ID of the file being processed
	 */
	public String getFileId() {
	return "XT33ERRS";
	}

	/**
	 * @return Table Name for inserting the records.
	 */
	public String getTable() {
		return "RABC_SVC_ORD_INFO";
	}

	/**
	 * @return Table Name for inserting the records.
	 */
	public String getAgeTable() {
		return "RABC_SVC_ORD_AGE";
	}

	/**
	 * Initiailizes the list to hold data transfer objects. It parses the filename to
	 * set the values for region, division, cycle, run date, bill round date and
	 * bill round.
	 * @param file object representing the file to be processed
	 */
	public boolean preprocessFile(File file){
		fileName = file.getName();
		region   =	file.getName().substring(0,2);
		rabcSvcOrdInfos = new ArrayList();
		return super.preprocessFile(file);
	}

	/**
	 * Processes a single record from the load file. A line contains fields that are
	 * semicolon delimited in the format: <FileId>;<AgencyId>;<SvcOrdNumber>;
	 * <CreateCycleNumber>
	 *
	 * @param line record from load file
	 * @return int indicating the return status as Success or Error
	 * @throws Exception Throws exception if there is an error in parsing the fields.
	 */
	protected int processRecord(String line) throws Exception {
		int success;

		RabcSvcOrdInfo info = new RabcSvcOrdInfo();
		try{
			String[] tokens = line.split(";");
			info.setRunDate(sqlRunDate);
			info.setDivision(division);
			info.setCycle(cycle);
			info.setAgencyID(tokens[1].trim());
			info.setSvcOrd(tokens[2].trim());
			info.setAgeCycle(cycle - Integer.parseInt(tokens[3].trim()) + 1);
			info.setCreateCycle(Integer.parseInt(tokens[3].trim()));
			rabcSvcOrdInfos.add(info);
			success = SUCCESS;
			lineCount++;
		}catch(Exception ex){
			severe(StaticErrorMsgKeys.PARSELINE_ERROR + " SVC_ORD " + info.getSvcOrd() + ex.getMessage(), ex);
			success = ERROR;
		}
		return success;
	}

	/**
	 * Inserts the processed data into RABC_SVC_ORD_INFO and RABC_SVC_ORD_AGE tables.
	 * Calls postprocessFile method of base class in the end.
	 * @param file object representing load file
	 * @param success boolean indicating success or failure of previous action
	 * @return boolean indicating success or failure
	 */
	public boolean postprocessFile(File file, boolean success) {
		try{
			//Log the file information to EMCIS_EVENT_LOG and EMCIS_EVENT_LOG_DETAIL
			EmcisEventLogger emcisLogger = new EmcisEventLogger();
			String event_id = "RABC_"+getFileId()+"_"+region;
            String host = NetUtil.getLocalHostName();
            String hostIP = NetUtil.getLocalIpAddress();
			int sequence = emcisLogger.getEMCISSequence(connection);
			emcisLogger.insertEventLog(connection, sequence, event_id, sqlRunDate, host, hostIP);
			emcisLogger.insertEventLogDetail(connection, sequence, "FileName", fileName);

		}catch (UnknownHostException e) {
            severe("Error getting EMCIS host information ", e);
        }
		
		if(success){
			RabcSvcOrdInfoDAO rabcSvcOrdInfoDAO = new RabcSvcOrdInfoDAO();
			RabcSvcOrdAgeDAO rabcSvcOrdAgeDAO = new RabcSvcOrdAgeDAO();

			try{
				success = rabcSvcOrdInfoDAO.insertBatchOfRecords(connection, rabcSvcOrdInfos, 1000);
				if (success)
					success = rabcSvcOrdAgeDAO.insertRecords(connection, sqlRunDate, division);

			}catch(CalnetException ex){
				severe(ex.getMessage(), ex);
				success = false;
			}
			catch(Exception ex){
				severe(ex.getMessage(), ex);
				success = false;
			}
		}
		rabcSvcOrdInfos = null;
		return super.postprocessFile(file, success);
	}

	/**
	 * If the data for file being processed has already been loaded then this mehod is
	 * called to delete the records from tables affected by the Job based on division
	 * and run date.
	 * @return success boolean indicating success or failure of previous action
	 */
	protected boolean deleteTable() {
		boolean success;
		backoutRecovery = "Y";
		success = PrepareTableForRerun.deleteTableData(connection, getTable(), division, sqlRunDate);
		if(success)
			success = PrepareTableForRerun.deleteTableData(connection, getAgeTable(), division, sqlRunDate);
		return success;
	}
}
