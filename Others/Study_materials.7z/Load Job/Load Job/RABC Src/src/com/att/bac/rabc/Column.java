/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc;

import java.util.ArrayList;
import java.util.List;

/**
 * This is a column data object class which has attributes of column that we need to pass to the tree related 
 * pages. This is a composite object with attributes required for different functionalities. Attributes not 
 * required will be kept null by the module using it.
 * 
 * @author Vijay Dubey - VD3159
 */
public class Column {
	private String columnTBLDDLName; // for the column DDL name
	private String columnTBLDataType; // for the column DDL data type
	private String columnAlertProcTBL; // for the source table of the column
	private String columnTBLDDLPRESCSNFormatType; // for presentation format type
	private String columnViewName;  // for the view name of the column
	private String nodeType; // to indicate that this node is a column
	private String allowUpdate = "Y"; // will enable giving disable / enable access on the JSP
	private List dropdownList = new ArrayList(); // List of columns available per row
	private String negIndicator; // To indicate the DATA_CALC_IND
	private String columnDescription;//Added for column description.
	private String dropdownValue ; // Attribute will contain value in attribute columnTBLDDLName and type with ~ as descriptor
	
	/**
	 * Default constructor
	 */
	public Column(){}
	
	/**
	 * 2 argument constructor;column name + allowUpdate flag
	 */
	public Column(String columnName, String allowUpdate){
		this.columnTBLDDLName = columnName;
		this.allowUpdate = allowUpdate;
	}
	
	/**
	 * 3 argument constructor;column name,allowUpdate flag & dropdown list 
	 */
	public Column(String columnName, String allowUpdate, List dropdownList){
		this.columnTBLDDLName = columnName;
		this.allowUpdate = allowUpdate;
		
		for (int i=0;i<dropdownList.size();i++){
			this.dropdownList.add((Column)dropdownList.get(i));
		}
	}

	/**
	 * Standard constructor
	 */
	public Column(DataTblDdlBean dataTblDdlBean){
		this.columnAlertProcTBL = dataTblDdlBean.getAlertProcTbl();
		this.columnTBLDDLName = dataTblDdlBean.getTblDdlName();
		this.columnTBLDataType = dataTblDdlBean.getTblDdlDataType();
		this.columnTBLDDLPRESCSNFormatType = dataTblDdlBean.getTblDdlPrescsnFormatType();
		this.columnDescription = dataTblDdlBean.getTblDdlNameDesc();//Added for column description.
		this.nodeType = "COLUMN";
	}
	
	/**
	 * @return Returns the columnViewName.
	 */
	public String getColumnViewName() {
		return columnViewName;
	}
	/**
	 * @param columnViewName The columnViewName to set.
	 */
	public void setColumnViewName(String columnViewName) {
		this.columnViewName = columnViewName;
	}
	/**
	 * @return Returns the dropdownList.
	 */
	public List getDropdownList() {
		return dropdownList;
	}
	/**
	 * @param dropdownList The dropdownList to set.
	 */
	public void addDropdown(Column column) {
		this.dropdownList.add(column);
	}
	/**
	 * @return Returns the allowUpdate.
	 */
	public String getAllowUpdate() {
		return allowUpdate;
	}
	/**
	 * @param allowUpdate The allowUpdate to set.
	 */
	public void setAllowUpdate(String allowUpdate) {
		this.allowUpdate = allowUpdate;
	}
	/**
	 * @return Returns the columnAlertProcTBL.
	 */
	public String getColumnAlertProcTBL() {
		return columnAlertProcTBL;
	}
	/**
	 * @param columnAlertProcTBL The columnAlertProcTBL to set.
	 */
	public void setColumnAlertProcTBL(String columnAlertProcTBL) {
		this.columnAlertProcTBL = columnAlertProcTBL;
	}
	/**
	 * @return Returns the columnTBLDataType.
	 */
	public String getColumnTBLDataType() {
		return columnTBLDataType;
	}
	/**
	 * @param columnTBLDataType The columnTBLDataType to set.
	 */
	public void setColumnTBLDataType(String columnTBLDataType) {
		this.columnTBLDataType = columnTBLDataType;
	}
	/**
	 * @return Returns the columnTBLDDLName.
	 */
	public String getColumnTBLDDLName() {
		return columnTBLDDLName;
	}
	/**
	 * @param columnTBLDDLName The columnTBLDDLName to set.
	 */
	public void setColumnTBLDDLName(String columnTBLDDLName) {
		this.columnTBLDDLName = columnTBLDDLName;
	}
	/**
	 * @return Returns the columnTBLDDLPRESCSNFormatType.
	 */
	public String getColumnTBLDDLPRESCSNFormatType() {
		return columnTBLDDLPRESCSNFormatType;
	}
	/**
	 * @param columnTBLDDLPRESCSNFormatType The columnTBLDDLPRESCSNFormatType to set.
	 */
	public void setColumnTBLDDLPRESCSNFormatType(
			String columnTBLDDLPRESCSNFormatType) {
		this.columnTBLDDLPRESCSNFormatType = columnTBLDDLPRESCSNFormatType;
	}
	/**
	 * @return Returns the nodeType.
	 */
	public String getNodeType() {
		return nodeType;
	}
	/**
	 * @param nodeType The nodeType to set.
	 */
	public void setNodeType(String nodeType) {
		this.nodeType = nodeType;
	}
	
	/**
	 * @return Returns the negIndicator.
	 */
	public String getNegIndicator() {
		return negIndicator;
	}
	/**
	 * @param negIndicator The negIndicator to set.
	 */
	public void setNegIndicator(String negIndicator) {
		this.negIndicator = negIndicator;
	}
	
	/**
	 * @return Returns the columnDescription.
	 */
	public String getColumnDescription() {
		return columnDescription;
	}
	
	/**
	 * @param columnDescription The columnDescription to set.
	 */
	public void setColumnDescription(String columnDescription) {
		this.columnDescription = columnDescription;
	}
	
	/**
	 * @return Returns the dropdownValue.
	 */
	public String getDropdownValue() {
		return dropdownValue;
	}
	/**
	 * @param dropdownValue The dropdownValue to set.
	 */
	public void setDropdownValue(String dropdownValue) {
		this.dropdownValue = dropdownValue;
	}
}
