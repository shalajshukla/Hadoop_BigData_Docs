/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.admin;

/**
 * This is a Data Object to represent RABC_UPDATE_GRP table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class UpdateGrp {
	private String alertRule;
	private String alertGrp;
	private int presnId;

	/**
	 * @return Returns the AlertRule.
	 */
	public String getAlertRule() {
		return alertRule;
	}
	/**
	 * @return Returns the AlertGrp.
	 */
	public String getAlertGrp() {
		return alertGrp;
	}
	/**
	 * @return Returns the PresnId.
	 */
	public int getPresnId() {
		return presnId;
	}

	/**
	 * @param AlertRule The alertRule to set.
	 */
	public void setAlertRule(String alertRule) {
		this.alertRule = alertRule;
	}
	/**
	 * @param AlertGrp The alertGrp to set.
	 */
	public void setAlertGrp(String alertGrp) {
		this.alertGrp = alertGrp;
	}
	/**
	 * @param PresnId The presnId to set.
	 */
	public void setPresnId(int presnId) {
		this.presnId = presnId;
	}
}
