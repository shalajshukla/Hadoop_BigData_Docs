/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.rpt;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.att.bac.rabc.ConnectionManager;
import com.att.bac.rabc.ExcelReport;
import com.att.bac.rabc.MyDate;
import com.att.bac.rabc.ProgressBar;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.StaticDataLoader;
import com.att.carat.util.email.EmailFactory;

/**
 * This is an action class that handles the
 * various action requested for page 14 (alert report sequence action). 
 * 
 * @author Nalina Pandiyan - NP5434
 */
public class AlertsReportSeqAction extends DispatchAction {
	private static final Logger logger = Logger.getLogger(AlertsReportSeqAction.class);	
	private static final String MMDDYYYY_FORMAT = "MM/dd/yyyy";
	private static final String PAGE_14 = "RABCPSF00014";
	
	public ActionForward unspecified(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		AlertsReportForm alertsReportForm = (AlertsReportForm) form;
		List failures = new ArrayList();
		Connection connection = null;
		String page = "error";
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		String region = (String)session.getAttribute("region");
		
		try {
			if (request.getMethod().equals("GET")) {
				//Get the connection from the available pool
				connection = ConnectionManager.getConnection(region);
				AlertReportParameters alertReportParameters = buildAlertReportParametersFromURL(form, request, failures, connection);
				progressBar.setProgressPercent(10);
				
				if (failures.isEmpty()) {				
					AlertReportView alertReportView = AlertsReportService.getAlertsReportService().processViewRequest(connection, failures, alertReportParameters, progressBar);
					if (failures.isEmpty()) {
						setFormFields(alertsReportForm,alertReportParameters,alertReportView);
						page = "AlertTrckMainSeqPage";
						if (alertReportParameters.getPopup()) {
							page = "AlertTrckMainSeqPagePopup";
						}
					}
				}
			} else {
				logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"Incorrect GET method found by AlertReportAction"}));
				failures.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"Incorrect GET method found by AlertReportAction"}), new Exception("")));
			}
		} catch (SQLException e) {
			logger.error(RABCMessages.getMessage("ERR_GET_ALERT_REPORT", null) + " Exception details: " + e.getMessage(), e);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_GET_ALERT_REPORT", null) + " Exception details: " + e.getMessage(), e));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failures.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failures, logger);
		}
		progressBar.setProgressPercent(100);
		
		if (!failures.isEmpty()) {				
			request.setAttribute("failures", failures);
		}
		
		return mapping.findForward(page);
	}
	
	/**
	 * This is an action method to handel the request for generating the excel report of AlertsReportSeqAction. 
	 * It executes click on Create Report button.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward createReport(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		AlertsReportForm alertsReportForm = (AlertsReportForm) form;
		List failures = new ArrayList();
		Connection connection = null;
		String page = "error";
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		String region = (String)session.getAttribute("region");
		
		try {
			String reportName = (String)request.getSession().getAttribute("bacUserID") + "page_14.xls" ;
			File file[]  = new File[1];
			file[0] = new File(reportName);
			OutputStream fos = new FileOutputStream(file[0]);
			
			ExcelReport report = new  ExcelReport(fos);
			
			connection = ConnectionManager.getConnection(region);
			AlertReportParameters alertReportParameters = buildAlertReportParametersFromFORM(alertsReportForm, request, failures, connection);
			progressBar.setProgressPercent(10);
			AlertReportView alertReportView = AlertsReportService.getAlertsReportService().processCreateReportRequest(connection, failures, alertReportParameters, report, progressBar);
			report.flush();
			fos.close();
			if (failures.isEmpty()){
				InputStream fis = new FileInputStream(reportName);
				ServletOutputStream out = response.getOutputStream();
				response.setContentType("application/msexcel");
				response.setHeader("Content-Disposition","attachment; filename=ExcelReport.xls");

				byte[] buf = new byte[1024];
				int len;
				while ((len = fis.read(buf)) > 0) {
					out.write(buf, 0, len);
				}
				fis.close();
				file[0].delete();
				page = null;
			}
		} catch (SQLException e) {
			logger.error(RABCMessages.getMessage("ERR_GET_ALERT_REPORT", null) + " Exception details: " + e.getMessage(), e);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_GET_ALERT_REPORT", null) + " Exception details: " + e.getMessage(), e));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch(IOException ioe) {
			logger.error(RABCMessages.getMessage("ERR_IO_EXEC", new String[] {"IO Exception while creating Page 14 report. "}) + " Exception details: " + ioe.getMessage(), ioe);
            failures.add(new RABCException(RABCMessages.getMessage("ERR_IO_EXEC", new String[] {"IO Exception while creating Page 14 report."}), ioe));
		} catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failures.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failures, logger);
		}
		progressBar.setProgressPercent(100);
		
		if (page == null) return null;
		
		if (!failures.isEmpty()) {				
			request.setAttribute("failures", failures);
		}
		
		return mapping.findForward(page);		
	}
	
	/**
	 * This is an action method to execute click on Email Report button for AlertsReportSeqAction. 
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward emailReport(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		AlertsReportForm alertsReportForm = (AlertsReportForm) form;
		List failures = new ArrayList();
		Connection connection = null;
		String page = "error";
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		String region = (String)session.getAttribute("region");
		
		try {
			connection = ConnectionManager.getConnection(region);
			AlertReportParameters alertReportParameters = buildAlertReportParametersFromFORM(alertsReportForm, request, failures, connection);
			progressBar.setProgressPercent(10);
			String emailRecipients = alertsReportForm.getEmailRecipients();
			String [] emailRecipientsArray = emailRecipients.split(",");
			int totalEmailRecipients = emailRecipientsArray.length;
			int counter = 0;
			//String toAddress = alertsReportForm.getEmailRecipients().replaceAll(",","@att.com,");
			String reportName = (String)request.getSession().getAttribute("bacUserID")+"page_14.xls" ;
			File file[]  = new File[1];
			file[0] = new File(reportName);

			FileOutputStream fos = new FileOutputStream(file[0]);
			ExcelReport report = new  ExcelReport(fos);
			AlertReportView alertReportView = AlertsReportService.getAlertsReportService().processCreateReportRequest(connection, failures, alertReportParameters, report, progressBar);
			report.flush();
			fos.close();
			if (failures.isEmpty()){
				// pb3879 added to create correct subject line.  Added to second arguement for email.
	            Context initContext = new InitialContext();
	            String spServer = initContext.lookup("java:/comp/env/saved_report_server").toString();
	            String fromEnvironment = initContext.lookup("java:/comp/env/application_env").toString();
	            for(counter = 0; counter < totalEmailRecipients; counter++  ) {
	            	boolean s =	EmailFactory.sendEmail(emailRecipientsArray[counter]+"@att.com", "RABC (" + fromEnvironment + " - " + spServer + ") - Control Alert Details by Sequence Number " + reportName, "Please find attached document for details", false, file);
				}
				//boolean s = EmailFactory.sendEmail( toAddress, "RABC (" + fromEnvironment + " - " + spServer + ") - Control Alert Details by Sequence Number " + reportName, "Please find attached document for details", false, file);

				//boolean s = Email.sendEmail( toAddress, "RABC - Control Alert Details by Sequence Number ", "Please find attached document for details", false, file);

				file[0].delete();
				session.setAttribute("reportPath", reportName);
				setFormFields(alertsReportForm, alertReportParameters, alertReportView);
				page = "AlertTrckMainSeqPage";
				if (alertReportParameters.getPopup()) {
					page = "AlertTrckMainSeqPagePopup";
				}
			}
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch(IOException ioe) {
			logger.error(RABCMessages.getMessage("ERR_IO_EXEC", new String[] {"IO Exception while e mailing Page 14 report. "}) + " Exception details: " + ioe.getMessage(), ioe);
            failures.add(new RABCException(RABCMessages.getMessage("ERR_IO_EXEC", new String[] {"IO Exception while e mailing Page 14 report."}), ioe));
		} catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failures.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failures, logger);
		}
		progressBar.setProgressPercent(100);
		
		if (!failures.isEmpty()) {				
			request.setAttribute("failures", failures);
		}
		
		return mapping.findForward(page);
	}
	
	/**
	 * This is an action method to handel the request for first page of AlertsReportSeqAction.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward first(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		AlertsReportForm alertsReportForm = (AlertsReportForm) form;
		alertsReportForm.setPage(1);
		return processRequest(mapping, alertsReportForm, request);
	}

	/**
	 * This is an action method to handel the request for previous page of AlertsReportSeqAction.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward previous(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		AlertsReportForm alertsReportForm = (AlertsReportForm) form;
		alertsReportForm.setPage(alertsReportForm.getPage() - 1);
		return processRequest(mapping, alertsReportForm, request);
	}

	/**
	 * This is an action method to handel the request for next page of AlertsReportSeqAction.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward next(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		AlertsReportForm alertsReportForm = (AlertsReportForm) form;
		alertsReportForm.setPage(alertsReportForm.getPage() + 1);
		return processRequest(mapping, alertsReportForm, request);
	}

	/**
	 * This is an action method to handel the request for last page of AlertsReportSeqAction.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward last(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		AlertsReportForm alertsReportForm = (AlertsReportForm) form;
		alertsReportForm.setPage(alertsReportForm.getPages());
		return processRequest(mapping, alertsReportForm, request);
	}

	/**
	 * This is an action method to handel the request for specific page of AlertsReportSeqAction.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward pagelist(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		AlertsReportForm alertsReportForm = (AlertsReportForm) form;
		alertsReportForm.setPage(alertsReportForm.getPageshow());
		return processRequest(mapping, alertsReportForm, request);
	}

	/**
	 * This is an action method to process the request for AlertsReportSeqAction.
	 * 
	 * @param mapping
	 * @param alertsReportForm
	 * @param request
	 * @return ActionForward
	 */
	public ActionForward processRequest(ActionMapping mapping, AlertsReportForm alertsReportForm, HttpServletRequest request) {
		List failures = new ArrayList();
		Connection connection = null;
		String page = "error";
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		String region = (String)session.getAttribute("region");
		
		try {
			connection = ConnectionManager.getConnection(region);
			AlertReportParameters alertReportParameters = buildAlertReportParametersFromFORM(alertsReportForm, request, failures, connection);
			progressBar.setProgressPercent(10);
			AlertReportView alertReportView = AlertsReportService.getAlertsReportService().processViewRequest(connection, failures, alertReportParameters, progressBar);
			
			if (failures.isEmpty()){
				setFormFields(alertsReportForm,alertReportParameters,alertReportView);
				page = "AlertTrckMainSeqPage";
				if (alertReportParameters.getPopup()) {
					page = "AlertTrckMainSeqPagePopup";
				}
			}
		} catch (SQLException e) {
			logger.error(RABCMessages.getMessage("ERR_GET_ALERT_REPORT", null) + " Exception details: " + e.getMessage(), e);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_GET_ALERT_REPORT", null) + " Exception details: " + e.getMessage(), e));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failures.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failures, logger);
		}
		progressBar.setProgressPercent(100);
		
		if (!failures.isEmpty()) {				
			request.setAttribute("failures", failures);
		}
		
		return mapping.findForward(page);
	}

	/**
	 * This method is used to build alertReportParameters from URL query strings.
	 * 
	 * @param form
	 * @param request
	 * @param failures
	 * @param connection
	 * @return AlertReportParameters
	 */
	private AlertReportParameters buildAlertReportParametersFromURL(ActionForm form, HttpServletRequest request, List failures, Connection connection) {
		AlertReportParameters alertReportParameters = new AlertReportParameters(PAGE_14);
		String value = "";
		String userId = (String)((HttpSession)request.getSession()).getAttribute("bacUserID");
		try {
			// Get URL parameters
			if (request.getParameter("procDate") != null) {
				if (!((String)request.getParameter("procDate")).equals("")) {
					alertReportParameters.setProcDate(new MyDate((String)request.getParameter("procDate"), MMDDYYYY_FORMAT));
				}
			} 
			if (request.getParameter("fileSeqNum") != null) {
				if (((String) request.getParameter("fileSeqNum")).equals("")) {
					alertReportParameters.setFileSeqNum(new Integer(-1));
				} else {
					alertReportParameters.setFileSeqNum(new Integer((String) request.getParameter("fileSeqNum")));
				}
			} 
			if (request.getParameter("partiRefId") != null) {
				alertReportParameters.setPartiRefId(new Integer((String)request.getParameter("partiRefId")));
			} 
			if (request.getParameter("divisionName") != null && !request.getParameter("divisionName").equals("")) {
				// division Name defined in URL queries
				alertReportParameters.setDivisionName(new String((String) request.getParameter("divisionName")));
			} else {
				// Set the difault division name.
				String defaultDivision = AlertsReportService.getAlertsReportService().getDefaultDivision(connection, failures, userId);
				alertReportParameters.setDivisionName(defaultDivision);
			}
			
			if (request.getParameter("key1") != null) {
				alertReportParameters.setKeysAt(0, new String((String)request.getParameter("key1")).toUpperCase());
			} else {
				alertReportParameters.setKeysAt(0, new String(""));
			}
			
			if (request.getParameter("key2") != null) {
				alertReportParameters.setKeysAt(1, new String((String)request.getParameter("key2")).toUpperCase());
			} else {
				alertReportParameters.setKeysAt(1, new String(""));
			}
			
			if (request.getParameter("key3") != null) {
				alertReportParameters.setKeysAt(2, new String((String)request.getParameter("key3")).toUpperCase());
			} else {
				alertReportParameters.setKeysAt(2, new String(""));
			}
			
			if (request.getParameter("key4") != null) {
				alertReportParameters.setKeysAt(3, new String((String)request.getParameter("key4")).toUpperCase());
			} else {
				alertReportParameters.setKeysAt(3, new String(""));
			}
			
			if (request.getParameter("key5") != null) {
				alertReportParameters.setKeysAt(4, new String((String)request.getParameter("key5")).toUpperCase());
			} else {
				alertReportParameters.setKeysAt(4, new String(""));
			}
			
			alertReportParameters.setPopup(false);
			if(request.getParameter("popup") != null) {
				value = request.getParameter("popup");				

				if (value.equals("Y")) 
					alertReportParameters.setPopup(true);
			}
			
			alertReportParameters.setSevereLvl(new Integer(-1));
			
			alertReportParameters.setRegion((String)((HttpSession)request.getSession()).getAttribute("region"));
			
			/*
			 * Code to get the default line count and set it into alertReportParameters object. 
			 */
			int defaultLineCount = AlertsReportService.getAlertsReportService().getDefaultLineCount(connection, failures, userId);
			alertReportParameters.setPageSize(defaultLineCount);
			
		} catch (ParseException e) {
			logger.error("Parse Exception. Exception details: " + e.getMessage(), e);
			failures.add(new RABCException("Parse Exception. Exception details: " + e.getMessage(), e));
			return null;
		}
		return alertReportParameters;
	}
	
	/**
	 * This method is used to build alertReportParameters from FORM.
	 * 
	 * @param form
	 * @param request
	 * @param failures
	 * @param connection
	 * @return AlertReportParameters
	 */
	private AlertReportParameters buildAlertReportParametersFromFORM(ActionForm form, HttpServletRequest request, List failures, Connection connection) {
		AlertReportParameters alertReportParameters = new AlertReportParameters(PAGE_14);
		String value = "";	
		String userId = (String)((HttpSession)request.getSession()).getAttribute("bacUserID");
		AlertsReportForm alertsReportForm = (AlertsReportForm) form;
		try {
			alertReportParameters.setAlertRule(alertsReportForm.getAlertRule());
			alertReportParameters.setStartDate(new MyDate(alertsReportForm.getStartDate(),MMDDYYYY_FORMAT));
			alertReportParameters.setEndDate(new MyDate(alertsReportForm.getEndDate(),MMDDYYYY_FORMAT));
			if (alertsReportForm.getDivisionName() != null && !alertsReportForm.getDivisionName().equals("")) {
				alertReportParameters.setDivisionName(alertsReportForm.getDivisionName());
			} else {
				//Set the difault division name.
				String defaultDivision = AlertsReportService.getAlertsReportService().getDefaultDivision(connection, failures, userId);
				alertReportParameters.setDivisionName(defaultDivision);
			}
			alertReportParameters.setKeysAt(0,alertsReportForm.getKey1());
			alertReportParameters.setKeysAt(1,alertsReportForm.getKey2());
			alertReportParameters.setKeysAt(2,alertsReportForm.getKey3());
			alertReportParameters.setKeysAt(3,alertsReportForm.getKey4());
			alertReportParameters.setKeysAt(4,alertsReportForm.getKey5());
			alertReportParameters.setRelatedAlertInd(alertsReportForm.getRelatedAlertInd());
			alertReportParameters.setDivisionNameKeyLvl(alertsReportForm.getDivisionNameKeyLvl());	
			alertReportParameters.setFileSeqNum(alertsReportForm.getFileSeqNum());
			alertReportParameters.setSevereLvl(alertsReportForm.getSevereLvl());
			alertReportParameters.setPartiRefId(alertsReportForm.getPartiRefId());
			alertReportParameters.setPresnId(alertsReportForm.getPresnId());
			alertReportParameters.setPopup(false);
			if (alertsReportForm.getPopup().equals("Y"))
				alertReportParameters.setPopup(true);
			
			alertReportParameters.setPage(alertsReportForm.getPage());
			alertReportParameters.setPages(alertsReportForm.getPages());
			alertReportParameters.setPageshow(alertsReportForm.getPageshow());
			
			alertReportParameters.setRegion((String)((HttpSession)request.getSession()).getAttribute("region"));
			
			/*
			 * Code to get the default line count and set it into alertReportParameters object. 
			 */
			int defaultLineCount = AlertsReportService.getAlertsReportService().getDefaultLineCount(connection, failures, userId);
			alertReportParameters.setPageSize(defaultLineCount);
			
		} catch (ParseException e) {
			logger.error("Parse Exception. Exception details: " + e.getMessage(), e);
			failures.add(new RABCException("Parse Exception. Exception details: " + e.getMessage(), e));
			return null;
		}
		return alertReportParameters;
	}

	/**
	 * Private method which sets the form attributes.
	 * 
	 * @param alertsReportForm
	 * @param alertReportParameters
	 * @param alertReportView
	 */
	private void setFormFields(AlertsReportForm alertsReportForm, AlertReportParameters alertReportParameters, AlertReportView alertReportView) {		
		alertsReportForm.setAlertRule(alertReportParameters.getAlertRule());
		alertsReportForm.setStartDate(alertReportParameters.getStartDate().toString());
		if (alertReportParameters.getEndDate() != null)
			alertsReportForm.setEndDate(alertReportParameters.getEndDate().toString());
		alertsReportForm.setDivisionName(alertReportParameters.getDivisionName());
		alertsReportForm.setKey1(alertReportParameters.getKeysAt(0));
		alertsReportForm.setKey2(alertReportParameters.getKeysAt(1));
		alertsReportForm.setKey3(alertReportParameters.getKeysAt(2));
		alertsReportForm.setKey4(alertReportParameters.getKeysAt(3));
		alertsReportForm.setKey5(alertReportParameters.getKeysAt(4));
		alertsReportForm.setRelatedAlertInd(alertReportParameters.getRelatedAlertInd());
		alertsReportForm.setPartiRefId(alertReportParameters.getPartiRefId());
		alertsReportForm.setPresnId(alertReportParameters.getPresnId());
		
		alertsReportForm.setFileSeqNum(alertReportParameters.getFileSeqNum());
		alertsReportForm.setKey1Label(alertReportParameters.getKey1Label());
		alertsReportForm.setKey2Label(alertReportParameters.getKey2Label());
		alertsReportForm.setKey3Label(alertReportParameters.getKey3Label());
		alertsReportForm.setDivisionNameLabel(alertReportParameters.getDivisionNameLabel());
		alertsReportForm.setHeader1(alertReportParameters.getHeader1());
		alertsReportForm.setHeader2(alertReportParameters.getHeader2());
		alertsReportForm.setHeader3(alertReportParameters.getHeader3());
		alertsReportForm.setDataPresent(alertReportParameters.getDataPresent());
		
		alertsReportForm.setWebPageId(alertReportParameters.getWebPageId());
		alertsReportForm.setAlertReportView(alertReportView);
		alertsReportForm.setDivisionList(alertReportParameters.getDivisionList());
		alertsReportForm.setPopup("N");
		if (alertReportParameters.getPopup())
			alertsReportForm.setPopup("Y");

		alertsReportForm.setPage(alertsReportForm.getPage());
		alertsReportForm.setPages(alertsReportForm.getPages());
		alertsReportForm.setPageshow(alertsReportForm.getPageshow());
		
		/*
		 * Update calendar attributes
		 */
		alertsReportForm.setBillRounds(StaticDataLoader.getBillRounds(alertReportParameters.getRegion()));
		alertsReportForm.setProcDates(StaticDataLoader.getProcDates(alertReportParameters.getRegion()));
		alertsReportForm.setHolidayIndicators(StaticDataLoader.getHolidayIndicators(alertReportParameters.getRegion()));
		alertsReportForm.setLoadedDataDates(StaticDataLoader.getLoadedDataDatesByRegion(alertReportParameters.getRegion()));
	}
}
