/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.status;
import java.util.Date;

/**
 * This is a Data Object to represent RABC_DASH_PRESN table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class DashPresn {
	private Date procDate;
	private String alertRule;
	private Date alertRuleRunDt;
	private int numOfRun;
	private int severeLvlHighCt;
	private int severeLvlMidCt;
	private int severeLvlLowCt;
	private int severeLvlNoIssueCt;
	private String alertKey1;
	private int pendCt;
	private int clsdCt;
	private int warnCt;

	/**
	 * @return Returns the ProcDate.
	 */
	public Date getProcDate() {
		return procDate;
	}
	/**
	 * @return Returns the AlertRule.
	 */
	public String getAlertRule() {
		return alertRule;
	}
	/**
	 * @return Returns the AlertRuleRunDt.
	 */
	public Date getAlertRuleRunDt() {
		return alertRuleRunDt;
	}
	/**
	 * @return Returns the NumOfRun.
	 */
	public int getNumOfRun() {
		return numOfRun;
	}
	/**
	 * @return Returns the SevereLvlHighCt.
	 */
	public int getSevereLvlHighCt() {
		return severeLvlHighCt;
	}
	/**
	 * @return Returns the SevereLvlMidCt.
	 */
	public int getSevereLvlMidCt() {
		return severeLvlMidCt;
	}
	/**
	 * @return Returns the SevereLvlLowCt.
	 */
	public int getSevereLvlLowCt() {
		return severeLvlLowCt;
	}
	/**
	 * @return Returns the SevereLvlNoIssueCt.
	 */
	public int getSevereLvlNoIssueCt() {
		return severeLvlNoIssueCt;
	}
	/**
	 * @return Returns the AlertKey1.
	 */
	public String getAlertKey1() {
		return alertKey1;
	}
	/**
	 * @return Returns the PendCt.
	 */
	public int getPendCt() {
		return pendCt;
	}
	/**
	 * @return Returns the ClsdCt.
	 */
	public int getClsdCt() {
		return clsdCt;
	}
	/**
	 * @return Returns the WarnCt.
	 */
	public int getWarnCt() {
		return warnCt;
	}

	/**
	 * @param ProcDate The procDate to set.
	 */
	public void setProcDate(Date procDate) {
		this.procDate = procDate;
	}
	/**
	 * @param AlertRule The alertRule to set.
	 */
	public void setAlertRule(String alertRule) {
		this.alertRule = alertRule;
	}
	/**
	 * @param AlertRuleRunDt The alertRuleRunDt to set.
	 */
	public void setAlertRuleRunDt(Date alertRuleRunDt) {
		this.alertRuleRunDt = alertRuleRunDt;
	}
	/**
	 * @param NumOfRun The numOfRun to set.
	 */
	public void setNumOfRun(int numOfRun) {
		this.numOfRun = numOfRun;
	}
	/**
	 * @param SevereLvlHighCt The severeLvlHighCt to set.
	 */
	public void setSevereLvlHighCt(int severeLvlHighCt) {
		this.severeLvlHighCt = severeLvlHighCt;
	}
	/**
	 * @param SevereLvlMidCt The severeLvlMidCt to set.
	 */
	public void setSevereLvlMidCt(int severeLvlMidCt) {
		this.severeLvlMidCt = severeLvlMidCt;
	}
	/**
	 * @param SevereLvlLowCt The severeLvlLowCt to set.
	 */
	public void setSevereLvlLowCt(int severeLvlLowCt) {
		this.severeLvlLowCt = severeLvlLowCt;
	}
	/**
	 * @param SevereLvlNoIssueCt The severeLvlNoIssueCt to set.
	 */
	public void setSevereLvlNoIssueCt(int severeLvlNoIssueCt) {
		this.severeLvlNoIssueCt = severeLvlNoIssueCt;
	}
	/**
	 * @param AlertKey1 The alertKey1 to set.
	 */
	public void setAlertKey1(String alertKey1) {
		this.alertKey1 = alertKey1;
	}
	/**
	 * @param PendCt The pendCt to set.
	 */
	public void setPendCt(int pendCt) {
		this.pendCt = pendCt;
	}
	/**
	 * @param ClsdCt The clsdCt to set.
	 */
	public void setClsdCt(int clsdCt) {
		this.clsdCt = clsdCt;
	}
	/**
	 * @param WarnCt The warnCt to set.
	 */
	public void setWarnCt(int warnCt) {
		this.warnCt = warnCt;
	}
}
