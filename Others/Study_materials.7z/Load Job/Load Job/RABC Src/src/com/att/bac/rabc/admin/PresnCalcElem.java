/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.admin;
/**
 * This is a Data Object to represent RABC_PRESN_CALC_ELEM table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class PresnCalcElem {
	private String presnCalcName;
	private int presnCalcNum;
	private String calcElemFormula;
	private String calcElemUserView;
	private String calcDivInd;
	private String calcElemDisplay;
	private String calcDisplayElem;
	private String presnFormatCode;
	private String calcTbl ; 
	private String calcElemSqlFormula ;

	/**
	 * @return Returns the PresnCalcName.
	 */
	public String getPresnCalcName() {
		return presnCalcName;
	}
	/**
	 * @return Returns the PresnCalcNum.
	 */
	public int getPresnCalcNum() {
		return presnCalcNum;
	}
	/**
	 * @return Returns the CalcElemFormula.
	 */
	public String getCalcElemFormula() {
		return calcElemFormula;
	}
	/**
	 * @return Returns the CalcElemUserView.
	 */
	public String getCalcElemUserView() {
		return calcElemUserView;
	}
	/**
	 * @return Returns the CalcDivInd.
	 */
	public String getCalcDivInd() {
		return calcDivInd;
	}
	/**
	 * @return Returns the CalcElemDisplay.
	 */
	public String getCalcElemDisplay() {
		return calcElemDisplay;
	}
	/**
	 * @return Returns the CalcDisplayElem.
	 */
	public String getCalcDisplayElem() {
		return calcDisplayElem;
	}
	/**
	 * @return Returns the PresnFormatCode.
	 */
	public String getPresnFormatCode() {
		return presnFormatCode;
	}

	/**
	 * @param PresnCalcName The presnCalcName to set.
	 */
	public void setPresnCalcName(String presnCalcName) {
		this.presnCalcName = presnCalcName;
	}
	/**
	 * @param PresnCalcNum The presnCalcNum to set.
	 */
	public void setPresnCalcNum(int presnCalcNum) {
		this.presnCalcNum = presnCalcNum;
	}
	/**
	 * @param CalcElemFormula The calcElemFormula to set.
	 */
	public void setCalcElemFormula(String calcElemFormula) {
		this.calcElemFormula = calcElemFormula;
	}
	/**
	 * @param CalcElemUserView The calcElemUserView to set.
	 */
	public void setCalcElemUserView(String calcElemUserView) {
		this.calcElemUserView = calcElemUserView;
	}
	/**
	 * @param CalcDivInd The calcDivInd to set.
	 */
	public void setCalcDivInd(String calcDivInd) {
		this.calcDivInd = calcDivInd;
	}
	/**
	 * @param CalcElemDisplay The calcElemDisplay to set.
	 */
	public void setCalcElemDisplay(String calcElemDisplay) {
		this.calcElemDisplay = calcElemDisplay;
	}
	/**
	 * @param CalcDisplayElem The calcDisplayElem to set.
	 */
	public void setCalcDisplayElem(String calcDisplayElem) {
		this.calcDisplayElem = calcDisplayElem;
	}
	/**
	 * @param PresnFormatCode The presnFormatCode to set.
	 */
	public void setPresnFormatCode(String presnFormatCode) {
		this.presnFormatCode = presnFormatCode;
	}
	/**
	 * @return Returns the calcElemSqlFormula.
	 */
	public String getCalcElemSqlFormula() {
		return calcElemSqlFormula;
	}
	/**
	 * @param calcElemSqlFormula The calcElemSqlFormula to set.
	 */
	public void setCalcElemSqlFormula(String calcElemSqlFormula) {
		this.calcElemSqlFormula = calcElemSqlFormula;
	}
	/**
	 * @return Returns the calcTbl.
	 */
	public String getCalcTbl() {
		return calcTbl;
	}
	/**
	 * @param calcTbl The calcTbl to set.
	 */
	public void setCalcTbl(String calcTbl) {
		this.calcTbl = calcTbl;
	}
}
