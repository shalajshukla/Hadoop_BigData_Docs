/* Created on Feb 22, 2006
 * Copyright 2006-2008 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.messages;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import org.apache.log4j.Logger;

import com.att.carat.util.JDBCUtil;

/**
 * @author pf7941
 *  
 */
public class AuditorMessageDAO {

    public static final int ASC = 0;
    public static final int DESC = 1;
    private static final String[] SORT_ORDERS = { "ASC", "DESC" };
    private static final String[] SORT_ITEMS = { "MSG_ID", "TIME_STAMP", "AUDITOR" };
     
    public static Logger logger = Logger.getLogger(AuditorMessageAction.class);

    public void updateStatus(Connection connection, String id, String status, String tableNode){
    	
    	String sql ="update RABC_BKGRND_RPT set status_cd = ? where status_cd =? and user_id = ?" ;
    	PreparedStatement ps  = null;
    		try {
    			ps =  connection.prepareStatement(sql);
    			if(status.equalsIgnoreCase("Notify")){
    			 ps.setString(1, "Complete");
    			     			 
    			}else if(status.equalsIgnoreCase("Notify Error")){
    				 ps.setString(1, "Error");
    			}
    			ps.setString(2, status);
    			ps.setString(3, id);
    			
    			ps.executeUpdate();
    			connection.commit();
		} catch (SQLException e) {
			RuntimeException rte = new RuntimeException(e.toString() + " - sql = " + sql);
            rte.initCause(e);
            throw rte;
		
		} finally {
			JDBCUtil.closePreparedStatement(ps);
		}
    	}
    
   
    public AuditorMessage[] getUnreadMessages(Connection connection, String id, String tableNode) throws AuditorMessageException {
        return getUnreadMessages( connection,id,tableNode,ASC);
    }

    public AuditorMessage[] getUnreadMessages(Connection connection, String id, String tableNode , int sort_order)
            throws AuditorMessageException {
        String sql = "select b.presn_id_desc,c.presn_id, c.status_cd  "+
					"from RABC_BKGRND_RPT c, RABC_presn_id b "+ 
					"where c.presn_id = b.presn_id " +
					"and c.user_id ='"+id+"' " +
					"and (c.STATUS_CD ='Notify Error' "+
					"or c.status_cd ='Notify') order by c.STATUS_CD asc";
 
        return getMessages(connection,sql);
    }

    public boolean hasUnreadMessages(Connection connection, String id, String tableNode) {
        String sql = "select c.presn_id, c.status_cd, b.presn_id_desc "+
        			"from RABC_BKGRND_RPT c, RABC_presn_id b "+ 
        			"where c.presn_id = b.presn_id " +
        			"and c.user_id ='"+id+"' " +
        			"and (c.STATUS_CD ='Notify Error' "+
        			"or c.status_cd ='Notify')"; 
        return hasResult(connection, sql);
    }

    private boolean hasResult(Connection connection, String sql) {
        PreparedStatement statement = null;
        ResultSet rs = null;
        boolean result = false;
        try {
            statement = connection.prepareStatement(sql);
            rs = statement.executeQuery(sql);
            result = rs.next();
            connection.commit();
        }
        catch (SQLException e) {
            RuntimeException rte = new RuntimeException(e.toString() + " - sql = " + sql);
            rte.initCause(e);
            throw rte;
        }
        finally {
            JDBCUtil.closeResultSet(rs);
            JDBCUtil.closeStatement(statement);
        }

        return result;
    }

   public AuditorMessage[] getMessages(Connection connection, String sql) {
        Vector result = new Vector();

        PreparedStatement statement = null;
        ResultSet rs = null;
        try {
            statement = connection.prepareStatement(sql);
            rs = statement.executeQuery(sql);
            while (rs.next()) {
                result.add(createMessage(rs));
            }
            connection.commit();
        }
        catch (Exception e) {
            RuntimeException rte = new RuntimeException(e.toString() + " - sql = " + sql);
            rte.initCause(e);
            throw rte;
        }
        finally {
            JDBCUtil.closeResultSet(rs);
            JDBCUtil.closeStatement(statement);
        }

        return (AuditorMessage[]) result.toArray(new AuditorMessage[0]);
    }

    private AuditorMessage createMessage(ResultSet rs) throws SQLException {
    	String message="";
    	String tblName = rs.getString("PRESN_ID_DESC");
        String status = rs.getString("STATUS_CD");
        if(status.equalsIgnoreCase("Notify")){
    		message =  "Report "+tblName+" has finished processing.";
    	}else if(status.equalsIgnoreCase("Notify Error")){
    		message = "There was an error in processing the "+tblName+" report. Please use the </td></tr> " +
    				"<td></td><td>Technical Support link on the bottom of the menu to notify the CARAT team.";
    	}

        AuditorMessage msg = new AuditorMessage(tblName, message, status);
        return msg;
    }
    public Logger getError(Exception e){
    	
    	logger.error("Auditor message check request failed. Message checking has been halted. " + e);
    	return logger;
    }
}
