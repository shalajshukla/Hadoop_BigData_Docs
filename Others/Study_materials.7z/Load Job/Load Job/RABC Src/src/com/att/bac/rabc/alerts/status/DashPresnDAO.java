/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.status;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.ArrayList;
import java.text.MessageFormat;

import org.apache.log4j.Logger;

import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.RABCException;

/**
 * This is a DAO that performs SELECT, INSERT and UPDATE on RABC_DASH_PRESN table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class DashPresnDAO {
	private static final Logger logger = Logger.getLogger(DashPresnDAO.class);

	/**
	 * Returns the list of DashPresn objects.
	 * 
	 * @param conn 
	 * @param failures
	 * @param args
	 * @param baseSQL
	 * @return List
	 */
	public List get(Connection conn, List failures, List args, String baseSQL) {
		List dashPresnList = null;
		DashPresn dashPresn = null;
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		
		try
		{
			logger.debug("Processing SELECT from RABC_DASH_PRESN table....");
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("DashPresnDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			logger.debug("SQL - Execution complete.");
			dashPresnList = new ArrayList();
			while (rs.next()) {
				dashPresnList.add(buildDashPresn(rs));
			}
			
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return null;
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
		
		return dashPresnList;
	}

	/**
	 * Private method to build DashPresn object and return it to caller.
	 * 
	 * @param rs
	 * @return DashPresn
	 * @throws SQLException
	 */
	private DashPresn buildDashPresn(ResultSet rs) throws SQLException {
		DashPresn dashPresn = new DashPresn();
		
		dashPresn.setProcDate(rs.getDate("PROC_DATE"));
		dashPresn.setAlertRule(rs.getString("ALERT_RULE"));
		dashPresn.setAlertRuleRunDt(rs.getDate("ALERT_RULE_RUN_DT"));
		dashPresn.setNumOfRun(rs.getInt("NUM_OF_RUN"));
		dashPresn.setSevereLvlHighCt(rs.getInt("SEVERE_LVL_HIGH_CT"));
		dashPresn.setSevereLvlMidCt(rs.getInt("SEVERE_LVL_MID_CT"));
		dashPresn.setSevereLvlLowCt(rs.getInt("SEVERE_LVL_LOW_CT"));
		dashPresn.setSevereLvlNoIssueCt(rs.getInt("SEVERE_LVL_NO_ISSUE_CT"));
		dashPresn.setAlertKey1(rs.getString("ALERT_KEY1"));
		dashPresn.setPendCt(rs.getInt("PEND_CT"));
		dashPresn.setClsdCt(rs.getInt("CLSD_CT"));
		dashPresn.setWarnCt(rs.getInt("WARN_CT"));
		return dashPresn;
	}

	/**
	 * Execute the insert or update statement on RABC_DASH_PRESN table.
	 * 
	 * @param conn
	 * @param failures
	 * @param args
	 * @param baseSQL
	 */
	public void executeUpdate(Connection conn, List failures, List args, String baseSQL) {
		int rowsUpdated = 0;
		Statement stmt = null;
		String sqlStmt = null;
		
		try
		{
			logger.debug("Processing executeUpdate on RABC_DASH_PRESN table....");
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("DashPresnDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rowsUpdated = stmt.executeUpdate(sqlStmt);
			logger.debug("SQL - Execution complete."+ String.valueOf(rowsUpdated) + "  rows updated");
			
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return;
		} finally {
			SQLHelper.closeStatement(stmt, failures, logger);
		}
	}

}
