/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

/**
 * This is a reflection utility class.
 * 
 * @author Nalina Pandiyan - NP5434
 */
public class ReflectionUtils {

	/**
	 * Method to return the boolean which states that whether the class is of simple type.
	 * 
	 * @param clazz
	 * @return boolean
	 */
	public static boolean isSimpleType(Class clazz) {
		return (boolean.class.equals(clazz) || Boolean.class.equals(clazz) 
				|| byte.class.equals(clazz) || Byte.class.equals(clazz) 
				|| short.class.equals(clazz) || Short.class.equals(clazz) 
				|| int.class.equals(clazz) || Integer.class.equals(clazz) 
				|| long.class.equals(clazz) || Long.class.equals(clazz) 
				|| float.class.equals(clazz) || Float.class.equals(clazz) 
				|| double.class.equals(clazz) || Double.class.equals(clazz) 
				|| char.class.equals(clazz) || Character.class.equals(clazz) 
				|| String.class.equals(clazz) || Date.class.equals(clazz) 
				|| java.sql.Date.class.equals(clazz));
	}

	/**
	 * Method to return the boolean which states that whether the class is of collection type.
	 * @param clazz
	 * @return boolean
	 */
	public static boolean isCollection(Class clazz) {
		return Collection.class.isAssignableFrom(clazz);
	}

	/**
	 * Method to return the list of fields of the class.
	 * 
	 * @param clazz
	 * @return Field[]
	 */
	public static Field[] getAllFieldsForClass(Class clazz) {
		List fields = new ArrayList();
		if (clazz != null) {
			while (!Object.class.equals(clazz)) {
				fields.addAll(Arrays.asList(clazz.getDeclaredFields()));
				clazz = clazz.getSuperclass();
			}
		}
		return (Field[])fields.toArray(new Field[fields.size()]);
	}

	/**
	 * Method to return the value of a field of a class.
	 * 
	 * @param field
	 * @param javaBeanCompliantObject
	 * @return Object
	 * @throws SecurityException
	 * @throws NoSuchMethodException
	 * @throws IllegalArgumentException
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 */
	public static Object getFieldValue(Field field, Object javaBeanCompliantObject) 
			throws SecurityException, NoSuchMethodException, IllegalArgumentException, 
			IllegalAccessException, InvocationTargetException {
		Object fieldValue = null;
		if (javaBeanCompliantObject != null && field != null) {
			Class clazz = javaBeanCompliantObject.getClass();
			String getterName = createGetterName(field);
			Method method = clazz.getMethod(getterName, new Class[0]);
			fieldValue = method.invoke(javaBeanCompliantObject, new Object[0]);
		}
		return fieldValue;
	}

	/**
	 * Method to return the getter name of the field.
	 * 
	 * @param field
	 * @return String
	 */
	public static String createGetterName(Field field) {
		String getterName = null;
		if (field != null) {
			String getterPrefix = "get";
			if (isBooleanField(field)) {
				getterPrefix = "is";
			}
			String name = field.getName();
			char[] nameAsChars = name.toCharArray();
			nameAsChars[0] = Character.toUpperCase(nameAsChars[0]);
			getterName = getterPrefix + String.valueOf(nameAsChars);
		}
		return getterName;
	}

	/**
	 * Method to return boolean value which states that whether the field is boolean.
	 * 
	 * @param field
	 * @return boolean
	 */
	public static boolean isBooleanField(Field field) {
		return (boolean.class.equals(field.getType()) || Boolean.class.equals(field.getType()));
	}

	/**
	 * Method to return the boolean value which states that whether the field is populated.
	 * 
	 * @param fieldType
	 * @param fieldValue
	 * @return boolean
	 */
	public static boolean isPopulated(Class fieldType, Object fieldValue) {
		boolean isPopulated = false;
		if (ReflectionUtils.isCollection(fieldType)) {
			Collection collection = (Collection)fieldValue;
			isPopulated = (collection != null) && (collection.size() > 0);
		} else if (String.class.equals(fieldType)) {
			String string = (String)fieldValue;
			isPopulated = (string != null) && (!string.equals(""));
		} else {
			isPopulated = fieldValue != null;
		}

		return isPopulated;
	}

	/**
	 * Method to return the boolean value which states that whether the field is populated.
	 * 
	 * @param fieldValue
	 * @return boolean
	 */
	public static boolean isPopulated(Object fieldValue) {
		if (fieldValue == null) {
			return false;
		} else {
			return isPopulated(fieldValue.getClass(), fieldValue);
		}
	}
	
	/**
	 * Method the value of a field for a path.
	 * 
	 * @param collectionsPathStack
	 * @param objectValue
	 * @param path
	 * @return Object
	 * @throws NoSuchFieldException
	 * @throws SecurityException
	 * @throws IllegalArgumentException
	 * @throws NoSuchMethodException
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 */
	public static Object getFieldValueForPath(List collectionsPathStack, Object objectValue, String path) 
			throws NoSuchFieldException, SecurityException, IllegalArgumentException, 
			NoSuchMethodException, IllegalAccessException, InvocationTargetException {
		Object fieldValue = null;
		if (objectValue != null) {

			String nameOfFieldInThisClass = getNextFieldNameFromPath(path);
			String remainingPath = getRemainingFieldPath(path);
			Class clazz = objectValue.getClass();
			Field field = getField(clazz, nameOfFieldInThisClass);
			fieldValue = ReflectionUtils.getFieldValue(field, objectValue);

			if (!"".equals(remainingPath)) {
				if (isCollection(field.getType())) {
					fieldValue = getCorrectObjectFromCollection(collectionsPathStack, fieldValue);
				}
				fieldValue = getFieldValueForPath(collectionsPathStack, fieldValue, remainingPath);
			}
		}
		return fieldValue;
	}

	/**
	 * Method the value of a field for a path.
	 * 
	 * @param objectValue
	 * @param path
	 * @return Object
	 * @throws SecurityException
	 * @throws IllegalArgumentException
	 * @throws NoSuchFieldException
	 * @throws NoSuchMethodException
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 */
	public static Object getFieldValueForPath(Object objectValue, String path) 
			throws SecurityException, IllegalArgumentException, NoSuchFieldException, 
			NoSuchMethodException, IllegalAccessException, InvocationTargetException {
		return ReflectionUtils.getFieldValueForPath(Collections.EMPTY_LIST, objectValue, path);
	}

	/**
	 * Method to return the correct object from the collection.
	 * 
	 * @param collectionsPathStack
	 * @param fieldValue
	 * @return Object
	 */
	private static Object getCorrectObjectFromCollection(List collectionsPathStack, Object fieldValue) {
		Iterator it = ((Collection)fieldValue).iterator();
		while (it.hasNext()) {
			Object nextObject = it.next();
			if (collectionsPathStack.size() > 0) {
				if (nextObject.equals(collectionsPathStack.get(0))) {
					fieldValue = nextObject;
					collectionsPathStack.remove(fieldValue);
				}
			}
		}
		return fieldValue;
	}

	/**
	 * Return the field for a given field name.
	 * 
	 * @param clazz
	 * @param fieldName
	 * @return Field
	 * @throws SecurityException
	 * @throws NoSuchFieldException
	 */
	private static Field getField(Class clazz, String fieldName) throws SecurityException, NoSuchFieldException {
		while (!Object.class.equals(clazz)) {
			try {
				return clazz.getDeclaredField(fieldName);
			} catch (NoSuchFieldException notFound) {
				if (Object.class.equals(clazz)) {
					throw notFound;				
				}
				clazz = clazz.getSuperclass();
			}
		}
		return null;
	}

	/**
	 * Method to return the next field name for a path.
	 * 
	 * @param path
	 * @return String
	 */
	private static String getNextFieldNameFromPath(String path) {
		String name = path;
		if (path.indexOf(".") >= 0) {
			name = path.substring(0, path.indexOf("."));
		}
		return name;
	}

	/**
	 * Method to return the remaining path other than next field for a path.
	 * 
	 * @param path
	 * @return String
	 */
	private static String getRemainingFieldPath(String path) {
		String remainingPath = "";
		int indexOfDot = path.indexOf(".");
		if (indexOfDot >= 0 && indexOfDot < path.length()) {
			remainingPath = path.substring(indexOfDot + 1);
		}
		return remainingPath;
	}
}
