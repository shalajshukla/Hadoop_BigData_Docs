package com.att.bac.rabc.defaults;

public class Defaults {
	String notifcation="";
	int severity=0;
	
	public Defaults(String notifcation, int severity) {
		
		this.notifcation = notifcation;
		this.severity = severity;
	}

	public String getNotifcation() {
		return notifcation;
	}

	public void setNotifcation(String notifcation) {
		this.notifcation = notifcation;
	}

	public int getSeverity() {
		return severity;
	}

	public void setSeverity(int severity) {
		this.severity = severity;
	}
	

}
