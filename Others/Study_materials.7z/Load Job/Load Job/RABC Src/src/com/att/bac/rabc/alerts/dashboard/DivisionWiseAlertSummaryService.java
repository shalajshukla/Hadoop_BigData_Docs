/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/

package com.att.bac.rabc.alerts.dashboard;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.att.bac.rabc.MyDate;
import com.att.bac.rabc.RABCConstantsLists;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;

/**
 * This class represents the Service that holds the Divisionwise Alert Summary List.
 * 
 * @author Sandhya Chinala - SC3837
 */
public class DivisionWiseAlertSummaryService {
	private static final Logger logger = Logger.getLogger(DivisionWiseAlertSummaryService.class);
	private static DivisionWiseAlertSummaryService divisionWiseAlertSummaryService;

	protected static final String get_alerts_high_2 = "SELECT c.cntrl_pt_code, division, division_desc, "
		+ "sum(severe_lvl_high_ct) severe_lvl_high_ct "
		+ "FROM rabc_dash_presn a, rabc_division b, rabc_cntrl_pt_trans c, rabc_cntrl_pt_alert d, rabc_alert_rule e "
		+ "WHERE a.alert_key1 = b.division "
		+ "AND a.alert_rule = d.alert_rule "
		+ "AND d.alert_rule = e.alert_rule "
		+ "AND UPPER(e.alert_rule_status) = ''ACTIVE'' "
		+ "AND c.cntrl_pt_code = d.cntrl_pt_cd "
		+ "AND c.cntrl_pt_code IN ({0}) "
		+ "{1} "
		+ "AND severe_lvl_high_ct > 0 "
		+ "and e.ALERT_RULE in (select a.ALERT_RULE from RABC_UPDATE_GRP a, RABC_ALERT_GRP_USER b where a.ALERT_GRP = b.ALERT_GRP and b.USER_ID = ''{2}'') "
		+ "GROUP BY c.cntrl_pt_code, division, division_desc "
		+ "ORDER BY c.cntrl_pt_code, division";

	protected static final String get_alerts_mid_2 = "SELECT c.cntrl_pt_code, division, division_desc, "
		+ "sum(severe_lvl_mid_ct) severe_lvl_mid_ct "
		+ "FROM rabc_dash_presn a, rabc_division b, rabc_cntrl_pt_trans c, rabc_cntrl_pt_alert d, rabc_alert_rule e "
		+ "WHERE a.alert_key1 = b.division "
		+ "AND a.alert_rule = d.alert_rule "
		+ "AND d.alert_rule = e.alert_rule "
		+ "AND UPPER(e.alert_rule_status) = ''ACTIVE'' "
		+ "AND c.cntrl_pt_code = d.cntrl_pt_cd "
		+ "AND c.cntrl_pt_code IN ({0}) "
		+ "{1} "
		+ "AND severe_lvl_mid_ct > 0 "
		+ "and e.ALERT_RULE in (select a.ALERT_RULE from RABC_UPDATE_GRP a, RABC_ALERT_GRP_USER b where a.ALERT_GRP = b.ALERT_GRP and b.USER_ID = ''{2}'') "
		+ "GROUP BY c.cntrl_pt_code, division, division_desc "
		+ "ORDER BY c.cntrl_pt_code, division";

	protected static final String get_alerts_low_2 = "SELECT c.cntrl_pt_code, division, division_desc, "
		+ "sum(severe_lvl_low_ct) severe_lvl_low_ct "
		+ "FROM rabc_dash_presn a, rabc_division b, rabc_cntrl_pt_trans c, rabc_cntrl_pt_alert d, rabc_alert_rule e "
		+ "WHERE a.alert_key1 = b.division "
		+ "AND a.alert_rule = d.alert_rule "
		+ "AND d.alert_rule = e.alert_rule "
		+ "AND UPPER(e.alert_rule_status) = ''ACTIVE'' "
		+ "AND c.cntrl_pt_code = d.cntrl_pt_cd "
		+ "AND c.cntrl_pt_code IN ({0}) "
		+ "{1} "
		+ "AND severe_lvl_low_ct > 0 "
		+ "and e.ALERT_RULE in (select a.ALERT_RULE from RABC_UPDATE_GRP a, RABC_ALERT_GRP_USER b where a.ALERT_GRP = b.ALERT_GRP and b.USER_ID = ''{2}'') "
		+ "GROUP BY c.cntrl_pt_code, division, division_desc "
		+ "ORDER BY c.cntrl_pt_code, division";

	protected static final String get_alerts_no_issue_2 = "SELECT c.cntrl_pt_code, division, division_desc, "
		+ "sum(severe_lvl_no_issue_ct) severe_lvl_no_issue_ct "
		+ "FROM rabc_dash_presn a, rabc_division b, rabc_cntrl_pt_trans c, rabc_cntrl_pt_alert d, rabc_alert_rule e "
		+ "WHERE a.alert_key1 = b.division "
		+ "AND a.alert_rule = d.alert_rule "
		+ "AND d.alert_rule = e.alert_rule "
		+ "AND UPPER(e.alert_rule_status) = ''ACTIVE'' "
		+ "AND c.cntrl_pt_code = d.cntrl_pt_cd "
		+ "AND c.cntrl_pt_code IN ({0}) "
		+ "{1} "
		+ "AND severe_lvl_no_issue_ct > 0 "
		+ "and e.ALERT_RULE in (select a.ALERT_RULE from RABC_UPDATE_GRP a, RABC_ALERT_GRP_USER b where a.ALERT_GRP = b.ALERT_GRP and b.USER_ID = ''{2}'') "
		+ "GROUP BY c.cntrl_pt_code, division, division_desc "
		+ "ORDER BY c.cntrl_pt_code, division";
	
	protected static final String get_alerts_no_issue_2_1 = "SELECT c.cntrl_pt_code, division, division_desc, proc_date, "
		+ "sum(severe_lvl_no_issue_ct) severe_lvl_no_issue_ct "
		+ "FROM rabc_dash_presn a, rabc_division b, rabc_cntrl_pt_trans c, rabc_cntrl_pt_alert d, rabc_alert_rule e "
		+ "WHERE a.alert_key1 = b.division "
		+ "AND a.alert_rule = d.alert_rule "
		+ "AND d.alert_rule = e.alert_rule "
		+ "AND UPPER(e.alert_rule_status) = ''ACTIVE'' "
		+ "AND c.cntrl_pt_code = d.cntrl_pt_cd "
		+ "AND c.cntrl_pt_code IN ({0}) "
		+ "{1} "
		+ "AND severe_lvl_no_issue_ct > 0 "
		+ "and e.ALERT_RULE in (select a.ALERT_RULE from RABC_UPDATE_GRP a, RABC_ALERT_GRP_USER b where a.ALERT_GRP = b.ALERT_GRP and b.USER_ID = ''{2}'') "
		+ "GROUP BY c.cntrl_pt_code, division, division_desc, proc_date "
		+ "ORDER BY c.cntrl_pt_code, division, proc_date";
	
	protected static final String get_alerts_warning_2 = "SELECT c.cntrl_pt_code, division, division_desc, "
		+ "sum(warn_ct) warn_ct "
		+ "FROM rabc_dash_presn a, rabc_division b, rabc_cntrl_pt_trans c, rabc_cntrl_pt_alert d, rabc_alert_rule e "
		+ "WHERE a.alert_key1 = b.division "
		+ "AND a.alert_rule = d.alert_rule "
		+ "AND d.alert_rule = e.alert_rule "
		+ "AND UPPER(e.alert_rule_status) = ''ACTIVE'' "
		+ "AND c.cntrl_pt_code = d.cntrl_pt_cd "
		+ "AND c.cntrl_pt_code IN ({0}) "
		+ "{1} "
		+ "AND warn_ct > 0 "
		+ "and e.ALERT_RULE in (select a.ALERT_RULE from RABC_UPDATE_GRP a, RABC_ALERT_GRP_USER b where a.ALERT_GRP = b.ALERT_GRP and b.USER_ID = ''{2}'') "
		+ "GROUP BY c.cntrl_pt_code, division, division_desc "
		+ "ORDER BY c.cntrl_pt_code, division";
	
	protected static final String get_alerts_pending_2 = "SELECT c.cntrl_pt_code, division, division_desc, "
		+ "sum(pend_ct) pend_ct "
		+ "FROM rabc_dash_presn a, rabc_division b, rabc_cntrl_pt_trans c, rabc_cntrl_pt_alert d, rabc_alert_rule e "
		+ "WHERE a.alert_key1 = b.division "
		+ "AND a.alert_rule = d.alert_rule "
		+ "AND d.alert_rule = e.alert_rule "
		+ "AND UPPER(e.alert_rule_status) = ''ACTIVE'' "
		+ "AND c.cntrl_pt_code = d.cntrl_pt_cd "
		+ "AND c.cntrl_pt_code IN ({0}) "
		+ "{1} "
		+ "AND pend_ct > 0 "
		+ "and e.ALERT_RULE in (select a.ALERT_RULE from RABC_UPDATE_GRP a, RABC_ALERT_GRP_USER b where a.ALERT_GRP = b.ALERT_GRP and b.USER_ID = ''{2}'') "
		+ "GROUP BY c.cntrl_pt_code, division, division_desc "
		+ "ORDER BY c.cntrl_pt_code, division";
	
	protected static final String get_alerts_closed_2 = "SELECT c.cntrl_pt_code, division, division_desc, "
		+ "sum(clsd_ct) clsd_ct "
		+ "FROM rabc_dash_presn a, rabc_division b, rabc_cntrl_pt_trans c, rabc_cntrl_pt_alert d, rabc_alert_rule e "
		+ "WHERE a.alert_key1 = b.division "
		+ "AND a.alert_rule = d.alert_rule "
		+ "AND d.alert_rule = e.alert_rule "
		+ "AND UPPER(e.alert_rule_status) = ''ACTIVE'' "
		+ "AND c.cntrl_pt_code = d.cntrl_pt_cd "
		+ "AND c.cntrl_pt_code IN ({0}) "
		+ "{1} "
		+ "AND clsd_ct > 0 "
		+ "and e.ALERT_RULE in (select a.ALERT_RULE from RABC_UPDATE_GRP a, RABC_ALERT_GRP_USER b where a.ALERT_GRP = b.ALERT_GRP and b.USER_ID = ''{2}'') "
		+ "GROUP BY c.cntrl_pt_code, division, division_desc "
		+ "ORDER BY c.cntrl_pt_code, division";

	protected static final String get_alerts_high_3 = "SELECT c.alert_rule, division, division_desc, "
		+ "sum(severe_lvl_high_ct) severe_lvl_high_ct "
		+ "FROM	rabc_dash_presn a, rabc_division b, rabc_cntrl_pt_alert c "
		+ "WHERE a.alert_key1 = b.division "
		+ "AND a.alert_rule = c.alert_rule "
		+ "AND cntrl_pt_cd = ''{0}'' "
		+ "AND c.alert_rule IN ({1}) "
		+ "{2} "
		+ "AND b.division = a.alert_key1 "
		+ "AND severe_lvl_high_ct > 0 "
		+ "and a.ALERT_RULE in (select a.ALERT_RULE from RABC_UPDATE_GRP a, RABC_ALERT_GRP_USER b where a.ALERT_GRP = b.ALERT_GRP and b.USER_ID = ''{3}'') "
		+ "GROUP BY c.alert_rule, division, division_desc "
		+ "ORDER BY c.alert_rule, division";

	protected static final String get_alerts_mid_3 = "SELECT c.alert_rule, division, division_desc, "
		+ "sum(severe_lvl_mid_ct) severe_lvl_mid_ct "
		+ "FROM	rabc_dash_presn a, rabc_division b, rabc_cntrl_pt_alert c "
		+ "WHERE a.alert_key1 = b.division "
		+ "AND a.alert_rule = c.alert_rule "
		+ "AND cntrl_pt_cd = ''{0}'' "
		+ "AND c.alert_rule IN ({1}) "
		+ "{2} "
		+ "AND b.division = a.alert_key1 "
		+ "AND severe_lvl_mid_ct > 0 "
		+ "and a.ALERT_RULE in (select a.ALERT_RULE from RABC_UPDATE_GRP a, RABC_ALERT_GRP_USER b where a.ALERT_GRP = b.ALERT_GRP and b.USER_ID = ''{3}'') "
		+ "GROUP BY c.alert_rule, division, division_desc "
		+ "ORDER BY c.alert_rule, division";

	protected static final String get_alerts_low_3 = "SELECT c.alert_rule, division, division_desc, "
		+ "sum(severe_lvl_low_ct) severe_lvl_low_ct "
		+ "FROM	rabc_dash_presn a, rabc_division b, rabc_cntrl_pt_alert c "
		+ "WHERE a.alert_key1 = b.division "
		+ "AND a.alert_rule = c.alert_rule "
		+ "AND cntrl_pt_cd = ''{0}'' "
		+ "AND c.alert_rule IN ({1}) "
		+ "{2} "
		+ "AND b.division = a.alert_key1 "
		+ "AND severe_lvl_low_ct > 0 "
		+ "and a.ALERT_RULE in (select a.ALERT_RULE from RABC_UPDATE_GRP a, RABC_ALERT_GRP_USER b where a.ALERT_GRP = b.ALERT_GRP and b.USER_ID = ''{3}'') "
		+ "GROUP BY c.alert_rule, division, division_desc "
		+ "ORDER BY c.alert_rule, division";

	protected static final String get_alerts_no_issue_3 = "SELECT c.alert_rule, division, division_desc, "
		+ "sum(severe_lvl_no_issue_ct) severe_lvl_no_issue_ct "
		+ "FROM	rabc_dash_presn a, rabc_division b, rabc_cntrl_pt_alert c "
		+ "WHERE a.alert_key1 = b.division "
		+ "AND a.alert_rule = c.alert_rule "
		+ "AND cntrl_pt_cd = ''{0}'' "
		+ "AND c.alert_rule IN ({1}) "
		+ "{2} "
		+ "AND b.division = a.alert_key1 "
		+ "AND severe_lvl_no_issue_ct > 0 "
		+ "and a.ALERT_RULE in (select a.ALERT_RULE from RABC_UPDATE_GRP a, RABC_ALERT_GRP_USER b where a.ALERT_GRP = b.ALERT_GRP and b.USER_ID = ''{3}'') "
		+ "GROUP BY c.alert_rule, division, division_desc "
		+ "ORDER BY c.alert_rule, division";
	
	protected static final String get_alerts_no_issue_3_1 = "SELECT c.alert_rule, division, division_desc, proc_date, "
		+ "sum(severe_lvl_no_issue_ct) severe_lvl_no_issue_ct "
		+ "FROM	rabc_dash_presn a, rabc_division b, rabc_cntrl_pt_alert c "
		+ "WHERE a.alert_key1 = b.division "
		+ "AND a.alert_rule = c.alert_rule "
		+ "AND cntrl_pt_cd = ''{0}'' "
		+ "AND c.alert_rule IN ({1}) "
		+ "{2} "
		+ "AND b.division = a.alert_key1 "
		+ "AND severe_lvl_no_issue_ct > 0 "
		+ "and a.ALERT_RULE in (select a.ALERT_RULE from RABC_UPDATE_GRP a, RABC_ALERT_GRP_USER b where a.ALERT_GRP = b.ALERT_GRP and b.USER_ID = ''{3}'') "
		+ "GROUP BY c.alert_rule, division, division_desc, proc_date "
		+ "ORDER BY c.alert_rule, division, proc_date";

	protected static final String get_NotRun_3 = "{0}";
	
	protected static final String get_alerts_warning_3 = "SELECT c.alert_rule, division, division_desc, "
		+ "sum(warn_ct) warn_ct "
		+ "FROM	rabc_dash_presn a, rabc_division b, rabc_cntrl_pt_alert c "
		+ "WHERE a.alert_key1 = b.division "
		+ "AND a.alert_rule = c.alert_rule "
		+ "AND cntrl_pt_cd = ''{0}'' "
		+ "AND c.alert_rule IN ({1}) "
		+ "{2} "
		+ "AND b.division = a.alert_key1 "
		+ "AND warn_ct > 0 "
		+ "and a.ALERT_RULE in (select a.ALERT_RULE from RABC_UPDATE_GRP a, RABC_ALERT_GRP_USER b where a.ALERT_GRP = b.ALERT_GRP and b.USER_ID = ''{3}'') "
		+ "GROUP BY c.alert_rule, division, division_desc "
		+ "ORDER BY c.alert_rule, division";

	protected static final String get_alerts_pending_3 = "SELECT c.alert_rule, division, division_desc, "
		+ "sum(pend_ct) pend_ct "
		+ "FROM	rabc_dash_presn a, rabc_division b, rabc_cntrl_pt_alert c "
		+ "WHERE a.alert_key1 = b.division "
		+ "AND a.alert_rule = c.alert_rule "
		+ "AND cntrl_pt_cd = ''{0}'' "
		+ "AND c.alert_rule IN ({1}) "
		+ "{2} "
		+ "AND b.division = a.alert_key1 "
		+ "AND pend_ct > 0 "
		+ "and a.ALERT_RULE in (select a.ALERT_RULE from RABC_UPDATE_GRP a, RABC_ALERT_GRP_USER b where a.ALERT_GRP = b.ALERT_GRP and b.USER_ID = ''{3}'') "
		+ "GROUP BY c.alert_rule, division, division_desc "
		+ "ORDER BY c.alert_rule, division";
	
	/**
	 * Comment for <code>get_alerts_closed_3</code>
	 */
	/**
	 * Comment for <code>get_alerts_closed_3</code>
	 */
	protected static final String get_alerts_closed_3 = "SELECT c.alert_rule, division, division_desc, "
		+ "sum(clsd_ct) clsd_ct "
		+ "FROM	rabc_dash_presn a, rabc_division b, rabc_cntrl_pt_alert c "
		+ "WHERE a.alert_key1 = b.division "
		+ "AND a.alert_rule = c.alert_rule "
		+ "AND cntrl_pt_cd = ''{0}'' "
		+ "AND c.alert_rule IN ({1}) "
		+ "{2} "
		+ "AND b.division = a.alert_key1 "
		+ "AND clsd_ct > 0 "
		+ "and a.ALERT_RULE in (select a.ALERT_RULE from RABC_UPDATE_GRP a, RABC_ALERT_GRP_USER b where a.ALERT_GRP = b.ALERT_GRP and b.USER_ID = ''{3}'') "
		+ "GROUP BY c.alert_rule, division, division_desc "
		+ "ORDER BY c.alert_rule, division";

	/**
	 * This is method for getting the DivisionWiseAlertSummaryService Object
	 * 
	 * @return DivisionWiseAlertSummaryService
	 */
	public static DivisionWiseAlertSummaryService getDivisionWiseAlertSummaryService(){
		if (divisionWiseAlertSummaryService == null) {
			divisionWiseAlertSummaryService = new DivisionWiseAlertSummaryService();
		}
		return divisionWiseAlertSummaryService;
	}

	/**
	 * This is method for constructing the Tier3 Object.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return List
	 */
	public List getHighLevel(Connection connection, List failureList, List args, String userId){
		List highLevelArgsList = new ArrayList();
		String highLevelArgs = null;
		String startDate =(String) args.get(0);
		String endDate = (String) args.get(1);
		String dateOption =(String) args.get(2);
		String cntrlPtCode = (String) args.get(3);
		String dashboardType = (String) args.get(4);
		Calendar calendar = Calendar.getInstance();
		Date date2 = null;
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		
		try {
			if (endDate == null || "".equals(endDate)) {
				calendar.setTime(dateFormat.parse(startDate));
				calendar.add(Calendar.DAY_OF_YEAR, 1);
				date2 = new Date(calendar.getTimeInMillis());
				highLevelArgs = " AND	alert_rule_run_dt >= to_date('" + startDate + "','MM/dd/yyyy')";
				highLevelArgs += " AND	alert_rule_run_dt < to_date('" + dateFormat.format(date2) + "','MM/dd/yyyy')";
			} else if  (dateOption.equals("file")){
				highLevelArgs = " AND	proc_date >= to_date('" + startDate + "','MM/dd/yyyy')";
				highLevelArgs += " AND	proc_date <= to_date('" + endDate + "','MM/dd/yyyy')";	
			} else {
				highLevelArgs = " AND	alert_rule_run_dt >= to_date('" + startDate + "','MM/dd/yyyy')";
				highLevelArgs += " AND	alert_rule_run_dt <= to_date('" + endDate + "','MM/dd/yyyy')";
			}
			if (dashboardType.equals("2")) {
				highLevelArgsList.add(args.get(5));
				if (highLevelArgs != null) {
					highLevelArgsList.add(highLevelArgs);
				} else {
					highLevelArgsList.add("");
				}
				highLevelArgsList.add(userId);
				return getDivisionWiseSummaryList(connection, failureList, highLevelArgsList, get_alerts_high_2);
			} else {
				highLevelArgsList.add(args.get(3));
				highLevelArgsList.add(args.get(5));
				if (highLevelArgs != null) {
					highLevelArgsList.add(highLevelArgs);
				} else {
					highLevelArgsList.add("");
				}
				highLevelArgsList.add(userId);
				return getDivisionWiseSummaryList(connection, failureList, highLevelArgsList, get_alerts_high_3);
			}
		} catch(ParseException px) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC") + " Exception details: " + px.getMessage(), px);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC"), px));
			return null;
		}
	}

	/**
	 * This is method for constructing the Tier2 Object
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return List
	 */
	public List getMediumLevel(Connection connection, List failureList, List args, String userId){
		List midLevelArgsList = new ArrayList();
		String midLevelArgs = null;
		String startDate =(String) args.get(0);
		String endDate = (String) args.get(1);
		String dateOption =(String) args.get(2);
		String cntrlPtCode = (String) args.get(3);
		String dashboardType = (String) args.get(4);
		Calendar calendar = Calendar.getInstance();
		Date date2 = null;
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		
		try {
			if (endDate == null || "".equals(endDate)) {
				calendar.setTime(dateFormat.parse(startDate));
				calendar.add(Calendar.DAY_OF_YEAR, 1);
				date2 = new Date(calendar.getTimeInMillis());
				midLevelArgs = " AND	alert_rule_run_dt >= to_date('" + startDate + "','MM/dd/yyyy')";
				midLevelArgs += " AND	alert_rule_run_dt < to_date('" + dateFormat.format(date2) + "','MM/dd/yyyy')";
			} else if  (dateOption.equals("file")){
				midLevelArgs = " AND	proc_date >= to_date('" + startDate + "','MM/dd/yyyy')";
				midLevelArgs += " AND	proc_date <= to_date('" + endDate + "','MM/dd/yyyy')";	
			} else {
				midLevelArgs = " AND	alert_rule_run_dt >= to_date('" + startDate + "','MM/dd/yyyy')";
				midLevelArgs += " AND	alert_rule_run_dt <= to_date('" + endDate + "','MM/dd/yyyy')";
			}
			if (dashboardType.equals("2")){
				midLevelArgsList.add(args.get(5));
				if (midLevelArgs != null) {
					midLevelArgsList.add(midLevelArgs);
				} else {
					midLevelArgsList.add("");
				}
				midLevelArgsList.add(userId);
				return getDivisionWiseSummaryList(connection, failureList, midLevelArgsList, get_alerts_mid_2);
			} else {
				midLevelArgsList.add(args.get(3));
				midLevelArgsList.add(args.get(5));
				if (midLevelArgs != null) {
					midLevelArgsList.add(midLevelArgs);
				} else {
					midLevelArgsList.add("");
				}
				midLevelArgsList.add(userId);
				return getDivisionWiseSummaryList(connection, failureList, midLevelArgsList, get_alerts_mid_3);
			}
		} catch(ParseException px) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC") + " Exception details: " + px.getMessage(), px);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC"), px));
			return null;
		}
	}

	/**
	 * This is method for constructing the Tier1 Object
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return List
	 */
	public List getLowLevel(Connection connection, List failureList ,List args, String userId){
		List lowLevelArgsList = new ArrayList();
		String lowLevelArgs = null;
		String startDate =(String) args.get(0);
		String endDate = (String) args.get(1);
		String dateOption =(String) args.get(2);
		String cntrlPtCode = (String) args.get(3);
		String dashboardType = (String) args.get(4);
		Calendar calendar = Calendar.getInstance();
		Date date2 = null;
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		
		try {
			if (endDate == null || "".equals(endDate)) {
				calendar.setTime(dateFormat.parse(startDate));
				calendar.add(Calendar.DAY_OF_YEAR, 1);
				date2 = new Date(calendar.getTimeInMillis());
				lowLevelArgs = " AND	alert_rule_run_dt >= to_date('" + startDate + "','MM/dd/yyyy')";
				lowLevelArgs += " AND	alert_rule_run_dt < to_date('" + dateFormat.format(date2) + "','MM/dd/yyyy')";
			} else if  (dateOption.equals("file")){
				lowLevelArgs = " AND	proc_date >= to_date('" + startDate + "','MM/dd/yyyy')";
				lowLevelArgs += " AND	proc_date <= to_date('" + endDate + "','MM/dd/yyyy')";	
			} else {
				lowLevelArgs = " AND	alert_rule_run_dt >= to_date('" + startDate + "','MM/dd/yyyy')";
				lowLevelArgs += " AND	alert_rule_run_dt <= to_date('" + endDate + "','MM/dd/yyyy')";
			}
			if (dashboardType.equals("2")){
				lowLevelArgsList.add(args.get(5));
				if (lowLevelArgs != null) {
					lowLevelArgsList.add(lowLevelArgs);
				} else {
					lowLevelArgsList.add("");
				}
				lowLevelArgsList.add(userId);
				return getDivisionWiseSummaryList(connection, failureList, lowLevelArgsList, get_alerts_low_2);
			} else {
				lowLevelArgsList.add(args.get(3));
				lowLevelArgsList.add(args.get(5));
				if (lowLevelArgs != null) {
					lowLevelArgsList.add(lowLevelArgs);
				} else {
					lowLevelArgsList.add("");
				}
				lowLevelArgsList.add(userId);
				return getDivisionWiseSummaryList(connection, failureList, lowLevelArgsList, get_alerts_low_3);
			}
		} catch(ParseException px) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC") + " Exception details: " + px.getMessage(), px);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC"), px));
			return null;
		}
	}

	/**
	 * This is method for constructing the None Object
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return List
	 */
	public List getNoIssueCnt(Connection connection, List failureList, List args, String userId){
		List noIssueArgsList = new ArrayList();
		String noIssueArgs = null;
		String startDate =(String) args.get(0);
		String endDate = (String) args.get(1);
		String dateOption =(String) args.get(2);
		String cntrlPtCode = (String) args.get(3);
		String dashboardType = (String) args.get(4);
		Calendar calendar = Calendar.getInstance();
		Date date2 = null;
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		
		try {
			if (endDate == null || "".equals(endDate)) {
				calendar.setTime(dateFormat.parse(startDate));
				calendar.add(Calendar.DAY_OF_YEAR, 1);
				date2 = new Date(calendar.getTimeInMillis());
				noIssueArgs = " AND	alert_rule_run_dt >= to_date('" + startDate + "','MM/dd/yyyy')";
				noIssueArgs += " AND	alert_rule_run_dt < to_date('" + dateFormat.format(date2) + "','MM/dd/yyyy')";
			} else if  (dateOption.equals("file")){
				noIssueArgs = " AND	proc_date >= to_date('" + startDate + "','MM/dd/yyyy')";
				noIssueArgs += " AND	proc_date <= to_date('" + endDate + "','MM/dd/yyyy')";	
			} else {
				noIssueArgs = " AND	alert_rule_run_dt >= to_date('" + startDate + "','MM/dd/yyyy')";
				noIssueArgs += " AND	alert_rule_run_dt <= to_date('" + endDate + "','MM/dd/yyyy')";
			}
			if (dashboardType.equals("2")){
				noIssueArgsList.add(args.get(5));
				if (noIssueArgs != null) {
					noIssueArgsList.add(noIssueArgs);
				} else {
					noIssueArgsList.add("");
				}
				noIssueArgsList.add(userId);
				if (dateOption.equals("file")) {
					return getDivisionWiseSummaryList(connection, failureList, noIssueArgsList, get_alerts_no_issue_2);
				} else {
					return getDivisionWiseSummaryListWithProcDate(connection, failureList, noIssueArgsList, get_alerts_no_issue_2_1);
				}
			} else {
				noIssueArgsList.add(args.get(3));
				noIssueArgsList.add(args.get(5));
				if (noIssueArgs != null) {
					noIssueArgsList.add(noIssueArgs);
				} else {
					noIssueArgsList.add("");
				}
				noIssueArgsList.add(userId);
				if (dateOption.equals("file")) {
					return getDivisionWiseSummaryList(connection, failureList, noIssueArgsList, get_alerts_no_issue_3);
				} else {
					return getDivisionWiseSummaryListWithProcDate(connection, failureList, noIssueArgsList, get_alerts_no_issue_3_1);
				}
			}
		} catch(ParseException px) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC") + " Exception details: " + px.getMessage(), px);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC"), px));
			return null;
		}

	}

	/**
	 * This is method for constructing the NotRun Object
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return List
	 */
	public List getNotRun(Connection connection, List failureList, List args ){
		String notRunArgs = null;
		StringBuffer notRunArgsBuffer = new StringBuffer();
		Calendar calendar = Calendar.getInstance();
		String startDate = (String) args.get(0);
		String endDate = (String)args.get(1);
		String dateOption = (String)args.get(2);
		String cntrlPt = (String)args.get(3);
		String alertRules = (String)args.get(5);
		List notRunArgsList = new ArrayList();
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		
		try{
			String[] alertRulesArray = alertRules.split(",");
			if (alertRulesArray != null) {
				int alertRulesArraySize = alertRulesArray.length;
				int counter = 0;
				for (counter=0; counter<alertRulesArraySize; counter++) {
					notRunArgsBuffer.append("SELECT " + alertRulesArray[counter] + " alert_rule, division, division_desc, 0 ")
						.append("FROM rabc_division ")
						.append("WHERE division NOT IN ")
						.append("(SELECT	a.alert_key1 ")
						.append("FROM rabc_dash_presn a, rabc_cntrl_pt_alert b, rabc_division c ");
					if (endDate == null || "".equals(endDate)) {
						Date date2 = new Date();
						calendar.setTime(dateFormat.parse(startDate));
						calendar.add(Calendar.DAY_OF_YEAR, 1);
						date2 = new Date(calendar.getTimeInMillis());
						notRunArgsBuffer.append(" WHERE	alert_rule_run_dt >= to_date('"+startDate+"','MM/dd/yyyy')")
							.append(" AND alert_rule_run_dt < to_date('"+dateFormat.format(date2)+"','MM/dd/yyyy')");
					} else{
						if (dateOption.equals("file")){
							notRunArgsBuffer.append(" WHERE	proc_date >= to_date('"+startDate+"','MM/dd/yyyy')")
								.append(" AND proc_date <= to_date('"+endDate+"','MM/dd/yyyy')");
						} else {
							notRunArgsBuffer.append(" WHERE	alert_rule_run_dt >= to_date('"+startDate+"','MM/dd/yyyy')")
								.append(" AND alert_rule_run_dt <= to_date('"+endDate+"','MM/dd/yyyy')");
						}
					}
					notRunArgsBuffer.append(" AND b.cntrl_pt_cd = '" + cntrlPt + "' ")
						.append("AND a.alert_rule = " + alertRulesArray[counter] + " ")
						.append("AND a.alert_rule = b.alert_rule) ");
					if (counter < alertRulesArraySize-1) {
						notRunArgsBuffer.append("UNION ");
					}
				}
				if (notRunArgsBuffer.length() > 0) {
					notRunArgsBuffer.append("ORDER BY alert_rule, division_desc");
				}
			}
			notRunArgs = notRunArgsBuffer.toString();
			notRunArgsList.add(notRunArgs);
		} catch(ParseException px) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC") + " Exception details: " + px.getMessage(), px);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC"), px));
		}
		return getDivisionWiseSummaryList(connection, failureList,notRunArgsList, get_NotRun_3);
	}
	
	/**
	 * This is method for constructing the Warning Status Object
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return List
	 */
	public List getWarningStatus(Connection connection, List failureList, List args, String userId){
		List warningStatusArgsList = new ArrayList();
		String warningStatusArgs = null;
		String startDate =(String) args.get(0);
		String endDate = (String) args.get(1);
		String dateOption =(String) args.get(2);
		String cntrlPtCode = (String) args.get(3);
		String dashboardType = (String) args.get(4);
		Calendar calendar = Calendar.getInstance();
		Date date2 = null;
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		
		try {
			if (endDate == null || "".equals(endDate)) {
				calendar.setTime(dateFormat.parse(startDate));
				calendar.add(Calendar.DAY_OF_YEAR, 1);
				date2 = new Date(calendar.getTimeInMillis());
				warningStatusArgs = " AND	alert_rule_run_dt >= to_date('" + startDate + "','MM/dd/yyyy')";
				warningStatusArgs += " AND	alert_rule_run_dt < to_date('" + dateFormat.format(date2) + "','MM/dd/yyyy')";
			} else if  (dateOption.equals("file")){
				warningStatusArgs = " AND	proc_date >= to_date('" + startDate + "','MM/dd/yyyy')";
				warningStatusArgs += " AND	proc_date <= to_date('" + endDate + "','MM/dd/yyyy')";	
			} else {
				warningStatusArgs = " AND	alert_rule_run_dt >= to_date('" + startDate + "','MM/dd/yyyy')";
				warningStatusArgs += " AND	alert_rule_run_dt <= to_date('" + endDate + "','MM/dd/yyyy')";
			}
			if (dashboardType.equals("2")) {
				warningStatusArgsList.add(args.get(5));
				if (warningStatusArgs != null) {
					warningStatusArgsList.add(warningStatusArgs);
				} else {
					warningStatusArgsList.add("");
				}
				warningStatusArgsList.add(userId);
				return getDivisionWiseSummaryList(connection, failureList, warningStatusArgsList, get_alerts_warning_2);
			} else {
				warningStatusArgsList.add(args.get(3));
				warningStatusArgsList.add(args.get(5));
				if (warningStatusArgs != null) {
					warningStatusArgsList.add(warningStatusArgs);
				} else {
					warningStatusArgsList.add("");
				}
				warningStatusArgsList.add(userId);
				return getDivisionWiseSummaryList(connection, failureList, warningStatusArgsList, get_alerts_warning_3);
			}
		} catch(ParseException px) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC") + " Exception details: " + px.getMessage(), px);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC"), px));
			return null;
		}
	}
	
	/**
	 * This is method for constructing the Pending Status Object
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return List
	 */
	public List getPendingStatus(Connection connection, List failureList, List args, String userId){
		List pendingStatusArgsList = new ArrayList();
		String pendingStatusArgs = null;
		String startDate =(String) args.get(0);
		String endDate = (String) args.get(1);
		String dateOption =(String) args.get(2);
		String cntrlPtCode = (String) args.get(3);
		String dashboardType = (String) args.get(4);
		Calendar calendar = Calendar.getInstance();
		Date date2 = null;
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		
		try {
			if (endDate == null || "".equals(endDate)) {
				calendar.setTime(dateFormat.parse(startDate));
				calendar.add(Calendar.DAY_OF_YEAR, 1);
				date2 = new Date(calendar.getTimeInMillis());
				pendingStatusArgs = " AND	alert_rule_run_dt >= to_date('" + startDate + "','MM/dd/yyyy')";
				pendingStatusArgs += " AND	alert_rule_run_dt < to_date('" + dateFormat.format(date2) + "','MM/dd/yyyy')";
			} else if  (dateOption.equals("file")){
				pendingStatusArgs = " AND	proc_date >= to_date('" + startDate + "','MM/dd/yyyy')";
				pendingStatusArgs += " AND	proc_date <= to_date('" + endDate + "','MM/dd/yyyy')";	
			} else {
				pendingStatusArgs = " AND	alert_rule_run_dt >= to_date('" + startDate + "','MM/dd/yyyy')";
				pendingStatusArgs += " AND	alert_rule_run_dt <= to_date('" + endDate + "','MM/dd/yyyy')";
			}
			if (dashboardType.equals("2")) {
				pendingStatusArgsList.add(args.get(5));
				if (pendingStatusArgs != null) {
					pendingStatusArgsList.add(pendingStatusArgs);
				} else {
					pendingStatusArgsList.add("");
				}
				pendingStatusArgsList.add(userId);
				return getDivisionWiseSummaryList(connection, failureList, pendingStatusArgsList, get_alerts_pending_2);
			} else {
				pendingStatusArgsList.add(args.get(3));
				pendingStatusArgsList.add(args.get(5));
				if (pendingStatusArgs != null) {
					pendingStatusArgsList.add(pendingStatusArgs);
				} else {
					pendingStatusArgsList.add("");
				}
				pendingStatusArgsList.add(userId);
				return getDivisionWiseSummaryList(connection, failureList, pendingStatusArgsList, get_alerts_pending_3);
			}
		} catch(ParseException px) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC") + " Exception details: " + px.getMessage(), px);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC"), px));
			return null;
		}
	}
	
	/**
	 * This is method for constructing the Closed Status Object
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return List
	 */
	public List getClosedStatus(Connection connection, List failureList, List args, String userId){
		List closedStatusArgsList = new ArrayList();
		String closedStatusArgs = null;
		String startDate =(String) args.get(0);
		String endDate = (String) args.get(1);
		String dateOption =(String) args.get(2);
		String cntrlPtCode = (String) args.get(3);
		String dashboardType = (String) args.get(4);
		Calendar calendar = Calendar.getInstance();
		Date date2 = null;
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		
		try {
			if (endDate == null || "".equals(endDate)) {
				calendar.setTime(dateFormat.parse(startDate));
				calendar.add(Calendar.DAY_OF_YEAR, 1);
				date2 = new Date(calendar.getTimeInMillis());
				closedStatusArgs = " AND	alert_rule_run_dt >= to_date('" + startDate + "','MM/dd/yyyy')";
				closedStatusArgs += " AND	alert_rule_run_dt < to_date('" + dateFormat.format(date2) + "','MM/dd/yyyy')";
			} else if  (dateOption.equals("file")){
				closedStatusArgs = " AND	proc_date >= to_date('" + startDate + "','MM/dd/yyyy')";
				closedStatusArgs += " AND	proc_date <= to_date('" + endDate + "','MM/dd/yyyy')";	
			} else {
				closedStatusArgs = " AND	alert_rule_run_dt >= to_date('" + startDate + "','MM/dd/yyyy')";
				closedStatusArgs += " AND	alert_rule_run_dt <= to_date('" + endDate + "','MM/dd/yyyy')";
			}
			if (dashboardType.equals("2")) {
				closedStatusArgsList.add(args.get(5));
				if (closedStatusArgs != null) {
					closedStatusArgsList.add(closedStatusArgs);
				} else {
					closedStatusArgsList.add("");
				}
				closedStatusArgsList.add(userId);
				return getDivisionWiseSummaryList(connection, failureList, closedStatusArgsList, get_alerts_closed_2);
			} else {
				closedStatusArgsList.add(args.get(3));
				closedStatusArgsList.add(args.get(5));
				if (closedStatusArgs != null) {
					closedStatusArgsList.add(closedStatusArgs);
				} else {
					closedStatusArgsList.add("");
				}
				closedStatusArgsList.add(userId);
				return getDivisionWiseSummaryList(connection, failureList, closedStatusArgsList, get_alerts_closed_3);
			}
		} catch(ParseException px) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC") + " Exception details: " + px.getMessage(), px);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC"), px));
			return null;
		}
	}
	
	/**
	 * This is method for retrieving the list of divisionWiseAlertSummary objects
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param baseSQL
	 * @return List
	 */
	private List getDivisionWiseSummaryList(Connection connection, List failureList, List args, String baseSQL){
		List divisionWiseAlertSummaryList = new ArrayList();
		DivisionWiseAlertSummary divisionWiseAlertSummary = null;
		Statement statement = null;
		ResultSet rs = null;
		String prepareStatement = null;
		try{
			MessageFormat mf = new MessageFormat(baseSQL);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("DivisionWiseAlertSummaryService.getDivisionWiseSummaryList() - Executing SQL statement: "+ prepareStatement);
			statement = connection.createStatement();
			rs = statement.executeQuery(prepareStatement);

			if (rs != null) {
				while(rs.next()){
					divisionWiseAlertSummary = buidDivisionWiseAlertSummary(rs);
					divisionWiseAlertSummaryList.add(divisionWiseAlertSummary);
				}
			}
		} catch(SQLException sqle){
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sqle.getMessage(), sqle);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sqle));
		} finally{
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(statement, failureList, logger);
		}
		return divisionWiseAlertSummaryList;
	}

	/**
	 * This is method for constructing the divisionWiseAlertSummary object
	 * 
	 * @param resultSet
	 * @return DivisionWiseAlertSummary
	 * @throws SQLException
	 */
	private DivisionWiseAlertSummary buidDivisionWiseAlertSummary(ResultSet resultSet) throws SQLException {
		DivisionWiseAlertSummary divisionWiseAlertSummary = new DivisionWiseAlertSummary();
		divisionWiseAlertSummary.setDashboardKey(resultSet.getString(1));
		divisionWiseAlertSummary.setDivisionCode(resultSet.getString(2));
		divisionWiseAlertSummary.setDivisionDesc(RABCConstantsLists.getRABCConstantsLists().getText(resultSet.getString(3), true));
		divisionWiseAlertSummary.setCount(resultSet.getInt(4));
		return divisionWiseAlertSummary;
	}
	
	/**
	 * This is method for retrieving the list of divisionWiseAlertSummary objects
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param baseSQL
	 * @return List
	 */
	private List getDivisionWiseSummaryListWithProcDate(Connection connection, List failureList, List args, String baseSQL){
		List divisionWiseAlertSummaryList = new ArrayList();
		DivisionWiseAlertSummary divisionWiseAlertSummary = null;
		Statement statement = null;
		ResultSet rs = null;
		String prepareStatement = null;
		String currentDashboardKey = null;
		String previousDashboardKey = null;
		String currentDivisionCode = null;
		String previousDivisionCode = null;
		String currentDivisionDesc = null;
		String previousDivisionDesc = null;
		int divisionWiseCount = 0;
		List fileDateWiseAlertSummaryList = new ArrayList();
		FileDateWiseAlertSummary fileDateWiseAlertSummary = null;
		Date procDate = null;
		int count = 0;
		try{
			MessageFormat mf = new MessageFormat(baseSQL);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("DivisionWiseAlertSummaryService.getDivisionWiseSummaryListWithProcDate() - Executing SQL statement: "+ prepareStatement);
			statement = connection.createStatement();
			rs = statement.executeQuery(prepareStatement);

			if (rs != null) {
				while(rs.next()){
					currentDashboardKey = rs.getString(1);
					currentDivisionCode = rs.getString(2);
					currentDivisionDesc = rs.getString(3);
					currentDivisionDesc = RABCConstantsLists.getRABCConstantsLists().getText(currentDivisionDesc, true);
					procDate = rs.getDate(4);
					count = rs.getInt(5);
					if ((fileDateWiseAlertSummaryList.size() > 0) && ((!currentDashboardKey.equals(previousDashboardKey)) 
							|| (!currentDivisionCode.equals(previousDivisionCode)))) {
						divisionWiseAlertSummary = new DivisionWiseAlertSummary();
						divisionWiseAlertSummary.setDashboardKey(previousDashboardKey);
						divisionWiseAlertSummary.setDivisionCode(previousDivisionCode);
						divisionWiseAlertSummary.setDivisionDesc(previousDivisionDesc);
						divisionWiseAlertSummary.setFileDateWiseAlertSummaryList(fileDateWiseAlertSummaryList);
						divisionWiseAlertSummary.setCount(divisionWiseCount);
						divisionWiseAlertSummaryList.add(divisionWiseAlertSummary);
						fileDateWiseAlertSummaryList = new ArrayList();
						divisionWiseCount = 0;
					}
					fileDateWiseAlertSummary = new FileDateWiseAlertSummary();
					fileDateWiseAlertSummary.setProcDate(new MyDate(procDate));
					fileDateWiseAlertSummary.setCount(count);
					fileDateWiseAlertSummaryList.add(fileDateWiseAlertSummary);
					divisionWiseCount += count;
					previousDashboardKey = currentDashboardKey;
					previousDivisionCode = currentDivisionCode;
					previousDivisionDesc = currentDivisionDesc;
				}
				divisionWiseAlertSummary = new DivisionWiseAlertSummary();
				divisionWiseAlertSummary.setDashboardKey(previousDashboardKey);
				divisionWiseAlertSummary.setDivisionCode(previousDivisionCode);
				divisionWiseAlertSummary.setDivisionDesc(previousDivisionDesc);
				divisionWiseAlertSummary.setFileDateWiseAlertSummaryList(fileDateWiseAlertSummaryList);
				divisionWiseAlertSummary.setCount(divisionWiseCount);
				divisionWiseAlertSummaryList.add(divisionWiseAlertSummary);
			}
		} catch(SQLException sqle){
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sqle.getMessage(), sqle);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sqle));
		} finally{
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(statement, failureList, logger);
		}
		return divisionWiseAlertSummaryList;
	}
}
