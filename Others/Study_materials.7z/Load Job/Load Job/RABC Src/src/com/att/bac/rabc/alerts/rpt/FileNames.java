/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.rpt;

import java.util.Date;

import com.att.bac.rabc.MyDate;

/**
 * This class handles the attributes required
 * to represent each row on page 15.
 * 
 * @author Nalina Pandiyan - NP5434
 */
public class FileNames {
	private String fileId;
	private String divisionName;
	private String fileName;
	private MyDate fileCreationDate;
	private String rowClr;
	
	/**
	 * @return Returns the divisionName.
	 */
	public String getDivisionName() {
		return divisionName;
	}
	
	/**
	 * @param divisionName The divisionName to set.
	 */
	public void setDivisionName(String divisionName) {
		this.divisionName = divisionName;
	}
	
	/**
	 * @return Returns the fileCreationDate.
	 */
	public MyDate getFileCreationDate() {
		return fileCreationDate;
	}
	
	/**
	 * @param fileCreationDate The fileCreationDate to set.
	 */
	public void setFileCreationDate(Date fileCreationDate) {
		if (fileCreationDate == null) 
			this.fileCreationDate = null;
		else
			this.fileCreationDate = new MyDate(fileCreationDate);
	}
	
	/**
	 * @return Returns the fileName.
	 */
	public String getFileName() {
		return fileName;
	}
	
	/**
	 * @param fileName The fileName to set.
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
	/**
	 * @return Returns the fileId.
	 */
	public String getFileId() {
		return fileId;
	}
	
	/**
	 * @param fileType The fileType to set.
	 */
	public void setFileId(String fileType) {
		this.fileId = fileType;
	}
	
	/**
	 * @return Returns the rowClr.
	 */
	public String getRowClr() {
		return rowClr;
	}
	
	/**
	 * @param rowClr The rowClr to set.
	 */
	public void setRowClr(String rowClr) {
		this.rowClr = rowClr;
	}
}
