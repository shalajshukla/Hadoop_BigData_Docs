/*
 * Module description: 
 * 
 * Data object representing RABC_SVC_ORD_AGE_MW table
 * 
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 *
 * Modification History:                                     
 * SBCUID		Date			Description                         	    	
 * ------		--------		-----------
 * SH8512		20060817		Initial version for PMT 270828
 *
 */
package com.att.bac.rabc.load.so.sw;


public class USOCData {

	private String busType;
	private String usoc;
	private long usocCt;
	private double usocAmt;
	
	
	public String getUsoc() {
		return usoc;
	}

	public void setUsoc(String usoc) {
		this.usoc = usoc;
	}


	public long getUsocCt() {
		return usocCt;
	}

	public void setUsocCt(long usocCt) {
		this.usocCt = this.usocCt + usocCt;
	}

	public double getUsocAmt() {
		return usocAmt;
	}
	
	public void setUsocAmt(double usocAmt) {
		this.usocAmt = this.usocAmt + usocAmt;
	}


	public String getBusType() {
		return busType;
	}
	public void setBusType(String busType) {
		this.busType = busType;
	}
}
