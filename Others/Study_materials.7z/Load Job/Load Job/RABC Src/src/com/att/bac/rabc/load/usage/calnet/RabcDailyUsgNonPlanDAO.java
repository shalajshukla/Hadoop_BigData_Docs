/* Created by Gaurav Bhargava (GB0741) on Dec 19, 2006.
Copyright 2006-2008 AT&T Knowledge Ventures. All rights reserved. */

package com.att.bac.rabc.load.usage.calnet;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.att.bac.rabc.load.calnet.CalnetDAO;
import com.att.bac.rabc.load.calnet.CalnetDTO;
import com.att.bac.rabc.load.calnet.CalnetException;

/**
 * Data Access Object class for RABC_DAILY_USG_NONPLAN_ACTVT table.
 * It is used to perform database operation on this table.
 * @author GB0741
 */
public class RabcDailyUsgNonPlanDAO extends CalnetDAO{

	private static final String INSERT_SQL = "INSERT INTO RABC_DAILY_USG_NONPLAN_ACTVT " +
			"(RUN_DATE,DIVISION,CYCLE,AGENCY_ID,USG_RCD_CLS,TOT_MINS_OF_USE,TOT_MSG_CT, " +
			"TOT_BLG_CHGS,TOT_OTHR_CHGS,TOT_ECC_SRCG,TOT_OPER_SRCG,TOT_PSSC_SRCG,TOT_LOCL_TAX," +
			"AMT_PER_UNIT,BUS_RES_IND) " +
			"VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

	/**
	 * Returns the insert statement used to insert a record into
	 * RABC_DAILY_USG_NONPLAN_ACTVT table.
	 * @return Returns the insert statement
	 */
	protected String getInsertSql(){
		return INSERT_SQL;
	}

	/**
	 * Reads the field values from passed DTO object and sets as corresponding parameters of the PreparedStatement
	 * @param pstmt - PreparedStatement object for setting the parameters.
	 * @param dataTransferObject - CalnetDTO for reading the field values.
	 * @throws CalnetException Throws exception when there is an error in setting the parameter.
	 */
	protected void setValues(PreparedStatement pstmt, CalnetDTO dataTransferObject)
				throws CalnetException{
		RabcDailyUsgNonPlan dailyNonPlan= (RabcDailyUsgNonPlan)dataTransferObject;
		try{
			pstmt.setDate(1, new Date(dailyNonPlan.getRunDate().getTime()));
			pstmt.setString(2, dailyNonPlan.getDivision());
			pstmt.setInt(3,dailyNonPlan.getCycle());
			pstmt.setString(4, dailyNonPlan.getAgencyID());
			pstmt.setInt(5, dailyNonPlan.getUsgRcdCls());
			pstmt.setDouble(6, dailyNonPlan.getTotMinsOfUse());
			pstmt.setLong(7, dailyNonPlan.getTotMsgCt());
			pstmt.setDouble(8, dailyNonPlan.getTotBlgChgs());
			pstmt.setDouble(9, dailyNonPlan.getTotOthrChgs());
			pstmt.setDouble(10, dailyNonPlan.getTotEccSrcg());
			pstmt.setDouble(11, dailyNonPlan.getTotOperSrcg());
			pstmt.setDouble(12, dailyNonPlan.getTotPsscSrcg());
			pstmt.setDouble(13, dailyNonPlan.getTotLoclTax());
			pstmt.setDouble(14, dailyNonPlan.getAmtPerUnit());
			pstmt.setString(15, dailyNonPlan.getBusResInd());
		}catch(SQLException ex){
			throw new CalnetException("Error setting values in prepared statement: Agency ID"
											+ dailyNonPlan.getAgencyID() + ex.getMessage(), ex);
		}
	}
}
