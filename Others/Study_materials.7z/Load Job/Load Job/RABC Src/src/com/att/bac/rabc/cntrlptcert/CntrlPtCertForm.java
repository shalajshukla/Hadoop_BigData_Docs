/* Component Name: RABCPPG00595
 * Module Name: CntrlPtCertForm.java
 * Created on Mar 20, 2006
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.cntrlptcert;

import java.util.ArrayList;
import java.util.Date;

import org.apache.struts.action.ActionForm;

/**CntrlPtCertForm is java representation for the Control Process Certification pages
 * 
 * @author ml2195
 */
public class CntrlPtCertForm extends ActionForm {
	private static final long serialVersionUID = 0L;
	
	// Main web page fields 
	private String    dispatch;
	private String    loginUserID;
	private String    region;
	private String    userAccess;
	private String    startDate;
	private String    endDate;
	private String	  toCertifyEndDate;
	private String	  state;
	private String    stateDesc;
	private String    process;
	private String	  certInd;
	private String    issueInd;
	private ArrayList stateList;
	private ArrayList processList;	
	private ArrayList cntrlPtCertViewList;
	private String    jsAlertMsg;
		
	
	// Detail web page fields  
	private int    	  certNum;
	private String 	  runDate;
	private double 	  creditRevImpact;
	private double 	  debitRevImpact;
	private double 	  lostRevImpact;
	private double 	  alertMsgRevImpact;
	private double 	  alertMsgLostRevImpact;
	private Date   	  timeStamp;
	private ArrayList cntrlPtCertCommentList;
	
	private int    commentCertNum;
	private String commentUserID;
	private String commentCertInd;
	private Date   commentTimeStamp;
	private String commentSubject;
	private String commentDetail;
	private String forwardType;
	
	// Temporary fields for soft reset 
	private String tempCertInd;
	private String tempIssueInd;
	private double tempCreditRevImpact;
	private double tempDebitRevImpact;
	private double tempLostRevImpact;
	private ArrayList regionList;	
	private ArrayList regionWiseAccessList;
	private String selectedRegion;
	private ArrayList certNumList;
	private String endRunDate;
	
	// Variables added for calendar page
	private String procDates;
	private String billRounds;
	private String holidayIndicators;
	private String loadedDataDates;
	
	// Class constructor
	public CntrlPtCertForm()
	{
		dispatch = "";
		region = "";
		loginUserID = "";
		userAccess = "";
		startDate = "";
		endDate = "";
		toCertifyEndDate = "";
		state = "";
		process = "";
		certInd = "";
		issueInd = "";		
		stateList = new ArrayList();
		processList = new ArrayList();
		cntrlPtCertViewList = new ArrayList();
		jsAlertMsg = "";
		
		certNum = 0;
		runDate = "";		
		creditRevImpact = 0;
		debitRevImpact = 0;
		lostRevImpact = 0;
		alertMsgRevImpact = 0;
		alertMsgLostRevImpact = 0;
		timeStamp = new Date();
		cntrlPtCertCommentList = new ArrayList();
		
		commentCertNum = 0;
		commentUserID = "";
		commentCertInd = "";
		commentTimeStamp = new Date();
		commentSubject = "";
		commentDetail = "";
		forwardType = "";
		
		tempCertInd = "";
		tempIssueInd = "";
		tempCreditRevImpact = 0;
		tempDebitRevImpact = 0;
		tempLostRevImpact = 0;
		regionList = new ArrayList();
		certNumList = new ArrayList();
		endRunDate ="";
		regionWiseAccessList = new ArrayList();
	}
	
	
	
	public String getBillRounds() {
		return billRounds;
	}



	public void setBillRounds(String billRounds) {
		this.billRounds = billRounds;
	}



	public String getHolidayIndicators() {
		return holidayIndicators;
	}



	public void setHolidayIndicators(String holidayIndicators) {
		this.holidayIndicators = holidayIndicators;
	}



	public String getLoadedDataDates() {
		return loadedDataDates;
	}



	public void setLoadedDataDates(String loadedDataDates) {
		this.loadedDataDates = loadedDataDates;
	}



	public String getProcDates() {
		return procDates;
	}



	public void setProcDates(String procDates) {
		this.procDates = procDates;
	}



	/**
	 * @return Returns the dispatch.
	 */
	public String getDispatch() {
		return dispatch;
	}
	/**
	 * @param dispatch Sets the dispatch.
	 */
	public void setDispatch(String dispatch) {
		this.dispatch = dispatch;
	}
	
	
	
	/**
	 * @return Returns the region.
	 */
	public String getRegion() {
		return region;
	}


	/**
	 * @param region The region to set.
	 */
	public void setRegion(String region) {
		this.region = region;
	}


	/**
	 * @return Returns the login user ID.
	 */
	public String getLoginUserID() {
		return loginUserID;
	}	
	/**
	 * @param loginUserID Sets the login user ID.
	 */
	public void setLoginUserID(String userID) {
		this.loginUserID = userID;
	}
	
	

	/**
	 * @return Returns the login user access.
	 */
	public String getUserAccess() {
		return userAccess;
	}	
	/**
	 * @param userAccess Sets the login user access.
	 */
	public void setUserAccess(String userAccess) {
		this.userAccess = userAccess;
	}
	
	
	
	/**
	 * @return Returns the start date.
	 */
	public String getStartDate() {
		return startDate;
	}		
	/**
	 * @param startDate Sets the start date 
	 */
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	
	
	
	/**
	 * @return Returns the end date.
	 */
	public String getEndDate() {
		return endDate;
	}		
	/**
	 * @param endDate Sets the end date 
	 */
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}	
	
	
	
	
	/**
	 * @return Returns the end date to be certified.
	 */
	public String getToCertifyEndDate() {
		return toCertifyEndDate;
	}		
	/**
	 * @param endDate Sets the end date to be certified 
	 */
	public void setToCertifyEndDate(String toCertifyEndDate) {
		this.toCertifyEndDate = toCertifyEndDate;
	}	
	
	
	
	/**
	 * @return Returns the state.
	 */
	public String getState() {
		return state;
	}
	/**
	 * @param State Sets the state
	 */
	public void setState(String state) {
		this.state = state;
	}
	
	
	
	/**
	 * @return Returns the state description.
	 */
	public String getStateDesc() {
		return stateDesc;
	}
	/**
	 * @param State Sets the state description
	 */
	public void setStateDesc(String stateDesc) {
		this.stateDesc = stateDesc;
	}
	
	
	/**
	 * @return Returns the process.
	 */
	public String getProcess() {
		return process;
	}	
	/**
	 * @param process Sets the process
	 */
	public void setProcess(String process) {
		this.process = process;
	}
	
	
	
	/**
	 * @return Returns the certified indicator.
	 */
	public String getCertInd() {
		return certInd;
	}	
	/**
	 * @param certInd Sets the certified indicator
	 */
	public void setCertInd(String cert) {
		this.certInd = cert;
	}
	
	
	/**
	 * @return Returns the issue found indicator.
	 */
	public String getIssueInd() {
		return issueInd;
	}	
	/**
	 * @param issueInd Sets the issue found indicator 
	 */
	public void setIssueInd(String issue) {
		this.issueInd = issue;
	}	


	/**
	 * @return Returns the list of states.
	 */
	public String [] getStateList() {
		if (this.stateList.isEmpty()) {
			String [] none = new String[1];
			none[0] = "No states found";
			return none;
		} else {
			return (String[]) stateList.toArray(new String[0]);
		}
	}	
	/**
	 * @param stateList Sets the list of states.
	 */
	public void setStateList(String state) {
		this.stateList.add(state);
	}
	
	
	
	/**
	 * @return Returns the list of processes.
	 */
	public String [] getProcessList() {
		if (this.processList.isEmpty()) {
			String [] none = new String[1];
			none[0] = "No processes found";
			return none;
		} else {
			return (String[]) processList.toArray(new String[0]);
		}
	}	
	/**
	 * @param processList Sets the list of processes.
	 */
	public void setProcessList(String process) {
		this.processList.add(process);
	}
	
	
	
	/**
	 * @return Returns the list of control processes.
	 */
	public ArrayList getCntrlPtCertViewList() {
			return (this.cntrlPtCertViewList);
	}	
	/**
	 * @param cntrlPtCertViewList Sets the list of control processes.
	 */
	public void setCntrlPtCertViewList(ArrayList cntrlPtCertViewList) {
		this.cntrlPtCertViewList = cntrlPtCertViewList;
	}

	
	
	/**
	 * @return Returns the JavaScript Alert Message code.
	 */
	public String getJSAlertMsg() {
		return jsAlertMsg;
	}
	/**
	 * @param jsAlertMsg Sets the JavaScript Alert Message code.
	 */
	public void setJSAlertMsg(String jsAlertMsg) {
		this.jsAlertMsg = jsAlertMsg;
	}
	
	
	/**
	 * 
	 * @return Returns the certification number
	 */
	public int getCertNum() {
		return certNum;
	}
	/**
	 * 
	 * @param certNum Sets the certification number
	 */
	public void setCertNum(int certNum) {
		this.certNum = certNum;
	}

	
	/**
	 * 
	 * @return Returns the run date.
	 */
	public String getRunDate() {
		return runDate;
	}
	/**
	 * 
	 * @param runDate Sets the run date.
	 */
	public void setRunDate(String runDate) {
		this.runDate = runDate;
	}
	
	
	/**
	 * 
	 * @return Returns the credit revenue impact amount
	 */
	public double getCreditRevImpact() {
		return creditRevImpact;
	}
	/**
	 * 
	 * @param creditRevImpact Sets the credit revenue impact amount
	 */
	public void setCreditRevImpact(double creditRevImpact) {
		this.creditRevImpact = creditRevImpact;
	}
	
	
	/**
	 * 
	 * @return Returns the debit revenue impact amount
	 */
	public double getDebitRevImpact() {
		return debitRevImpact;
	}
	/**
	 * 
	 * @param debitRevImpact Sets the debit revenue impact amount
	 */
	public void setDebitRevImpact(double debitRevImpact) {
		this.debitRevImpact = debitRevImpact;
	}
	
	
	/**
	 * 
	 * @return Returns the lost revenue impact amount
	 */
	public double getLostRevImpact() {
		return lostRevImpact;
	}
	/**
	 * 
	 * @param lostRevImpact Sets the lost revenue impact amount
	 */
	public void setLostRevImpact(double lostRevImpact) {
		this.lostRevImpact = lostRevImpact;
	}
	
	
	
	/**
	 * 
	 * @return  Returns the alert message revenue impact amount
	 */
	public double getAlertMsgRevImpact() {
		return alertMsgRevImpact;
	}
	/**
	 * 
	 * @param alertMsgRevImpact Sets the alert message revenue impact amount
	 */
	public void setAlertMsgRevImpact(double alertMsgRevImpact) {
		this.alertMsgRevImpact = alertMsgRevImpact;
	}
	
	
	
	/**
	 * 
	 * @return Returns the alert message lost revenue impact amount
	 */
	public double getAlertMsgLostRevImpact() {
		return alertMsgLostRevImpact;
	}
	/**
	 * 
	 * @param alertMsgLostRevImpact Sets the alert message lost revenue impact amount
	 */
	public void setAlertMsgLostRevImpact(double alertMsgLostRevImpact) {
		this.alertMsgLostRevImpact = alertMsgLostRevImpact;
	}
	
	
	
	/**
	 * 
	 * @return Returns the time stamp.
	 */
	public Date getTimeStamp() {
		return timeStamp;
	}
	/**
	 * 
	 * @param timeStamp Sets the time stamp
	 */
	public void setTimeStamp(Date timeStamp) {
		this.timeStamp = timeStamp;
	}
	
	
	
	/**
	 * @return Returns the list of Comments.
	 */
	public ArrayList getCntrlPtCertCommentList() {
			return (this.cntrlPtCertCommentList);
	}	
	/**
	 * @param cntrlPtCertCommentList Sets the list of comments.
	 */
	public void setCntrlPtCertCommentList(ArrayList cntrlPtCertCommentList) {
		this.cntrlPtCertCommentList = cntrlPtCertCommentList;
	}
	
	
	
	/**
	 * 
	 * @return Returns the certification number from the comment table.
	 */
	public int getCommentCertNum() {
		return commentCertNum;
	}
	/**
	 * 
	 * @param commentCertNum Sets the certification number in the comment table
	 */
	public void setCommentCertNum(int commentCertNum) {
		this.commentCertNum = commentCertNum;
	}
	
	
	
	/**
	 * 
	 * @return Returns the user ID from the comment table
	 */
	public String getCommentUserID() {
		return commentUserID;
	}
	/**
	 * 
	 * @param commentUserID Sets the user ID in the comment table
	 */
	public void setCommentUserID(String commentUserID) {
		this.commentUserID = commentUserID;
	}
	
	
	
	/**
	 * 
	 * @return  Returns the certified indicator in the comment table
	 */
	public String getCommentCertInd() {
		return commentCertInd;
	}
	/**
	 * 
	 * @param commentCertInd  Sets the certified indicator in the comment table
	 */
	public void setCommentCertInd(String commentCertInd) {
		this.commentCertInd = commentCertInd;
	}
	
	
	
	/**
	 * 
	 * @return  Returns the time stamp from the comment table
	 */
	public Date getCommentTimeStamp() {
		return commentTimeStamp;
	}
	/**
	 * 
	 * @param commentTimeStamp  Sets the time stamp in the comment table
	 */
	public void setCommentTimeStamp(Date commentTimeStamp) {
		this.commentTimeStamp = commentTimeStamp;
	}
	
	
	
	/**
	 * 
	 * @return  Returns the subject in the comment table
	 */
	public String getCommentSubject() {
		return commentSubject;
	}
	/**
	 * 
	 * @param commentSubject Sets the subject in the comment table
	 */
	public void setCommentSubject(String commentSubject) {
		this.commentSubject = commentSubject;
	}
	
	
	
	/**
	 * 
	 * @return  Returns the comment from the comment table 
	 */
	public String getCommentDetail() {
		return commentDetail;
	}
	/**
	 * 
	 * @param commentDetail Sets the comment in the comment table
	 */
	public void setCommentDetail(String commentDetail) {
		this.commentDetail = commentDetail;
	}
	
	
	
	/**
	 * @return Returns the tempCertInd.
	 */
	public String getTempCertInd() {
		return tempCertInd;
	}	
	/**
	 * @param certInd Set tempCertInd
	 */
	public void setTempCertInd(String cert) {
		this.tempCertInd = cert;
	}
	
	
	
	/**
	 * @return Returns the tempIssueInd.
	 */
	public String getTempIssueInd() {
		return tempIssueInd;
	}	
	/**
	 * @param issueInd Set tempIssueInd 
	 */
	public void setTempIssueInd(String issue) {
		this.tempIssueInd = issue;
	}	
	
	
	
	/**
	 * 
	 * @return Returns the tempCreditRevImpact
	 */
	public double getTempCreditRevImpact() {
		return tempCreditRevImpact;
	}
	/**
	 * 
	 * @param tempCreditRevImpact Set tempCreditRevImpact
	 */
	public void setTempCreditRevImpact(double tempCreditRevImpact) {
		this.tempCreditRevImpact = tempCreditRevImpact;
	}
	
	
	
	/**
	 * 
	 * @return Returns tempDebitRevImpact
	 */
	public double getTempDebitRevImpact() {
		return tempDebitRevImpact;
	}
	/**
	 * 
	 * @param tempDebitRevImpact Set tempDebitRevImpact
	 */
	public void setTempDebitRevImpact(double tempDebitRevImpact) {
		this.tempDebitRevImpact = tempDebitRevImpact;
	}
	
	
	/**
	 * 
	 * @return  returns the tempLostRevImpact
	 */
	public double getTempLostRevImpact() {
		return tempLostRevImpact;
	}
	/**
	 * 
	 * @param tempLostRevImpact Set tempLostRevImpact
	 */
	public void setTempLostRevImpact(double tempLostRevImpact) {
		this.tempLostRevImpact = tempLostRevImpact;
	}


	/**
	 * @return Returns the forwardType.
	 */
	public String getForwardType() {
		return forwardType;
	}


	/**
	 * @param forwardType The forwardType to set.
	 */
	public void setForwardType(String forwardType) {
		this.forwardType = forwardType;
	}
	
	/**
	 * @return the regionList
	 */
	public ArrayList getRegionList() {
		return regionList;
	}

	/**
	 * @param regionList Sets the list of regions.
	 */
	public void setRegionList(ArrayList regionList) {
		this.regionList = regionList;
	}
	
	/**
	 * @return the regionWiseAccessList
	 */
	public String getRegionWiseAccessList() {
		if (!regionWiseAccessList.isEmpty()){
			String regionWiseAccess = "";
			int size = regionWiseAccessList.size();
			for (int i=0;i<size;i++){
				if (i==0){
					regionWiseAccess += (String)regionWiseAccessList.get(i);
				}else {
					regionWiseAccess += ";" + (String)regionWiseAccessList.get(i);
				}
			}
			return regionWiseAccess;
		}else {
			return "";
		}
		
	}

	/**
	 * @param regionWiseAccessList the regionWiseAccessList to set
	 */
	public void setRegionWiseAccessList(String regionWiseAccess) {
		if(!regionWiseAccessList.contains(regionWiseAccess)){
			this.regionWiseAccessList.add(regionWiseAccess);
		}
	}

	/**
	 * @return Returns the selectedRegion.
	 */
	public String getSelectedRegion() {
		return selectedRegion;
	}
	/**
	 * @param selectedRegion The selectedRegion to set.
	 */
	public void setSelectedRegion(String selectedRegion) {
		this.selectedRegion = selectedRegion;
	}
	/**
	 * @return Returns the endRunDate.
	 */
	public String getEndRunDate() {
		return endRunDate;
	}
	/**
	 * @param endRunDate The endRunDate to set.
	 */
	public void setEndRunDate(String endRunDate) {
		this.endRunDate = endRunDate;
	}


	/**
	 * @return the certNumList
	 */
	public ArrayList getCertNumList() {
		return certNumList;
	}

	/**
	 * @param certNumList the certNumList to set
	 */
	public void addCertNum(int certNum) {
		this.certNumList.add(new Integer(certNum));
	}
	
	
}
