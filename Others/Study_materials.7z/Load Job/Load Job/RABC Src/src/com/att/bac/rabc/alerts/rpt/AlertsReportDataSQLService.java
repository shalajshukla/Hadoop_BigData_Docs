/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.rpt;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.text.MessageFormat;
import java.text.ParseException;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.att.bac.rabc.DataTblDdl;
import com.att.bac.rabc.DataTblDdlDAO;
import com.att.bac.rabc.MyDate;
import com.att.bac.rabc.RABCConstantsLists;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;

/**
 * This class represents the Service which handles processing of 
 * various SQL requests for AlertsReportDataSQLService (page 12).
 * 
 * @author Nalina Pandiyan - NP5434
 */
public class AlertsReportDataSQLService {
	private static final Logger logger = Logger.getLogger(AlertsReportDataSQLService.class);
	public static final String DEFAULT_LABEL_RESOURCES = "com.att.bac.rabc.LabelResources";
	private static ResourceBundle labelProperties;
	
	private AlertReportParameters alertReportParameters = null;
	private Connection connection = null;
	private List failures = null;

	private List qryAlertRulePresnElemList = null;
	private List qryKeyColList = null;
	// The following list contains Column Names
	private List columns = null;
	// The following list contains column Names used to build qryGetData object
	private List columnNames = new ArrayList();
	private List columnNames1 = new ArrayList();
	private List presnIdQueries = new ArrayList();
	private List qryGetDataList = null;
	List columnTypeInfo = null;
	
	private final static int NEXT_ROW = 0;
	private final static int INSERT = 1;
	
	// SQLs
	private static final String qryAlertRuleSQL = "SELECT 	bar.alert_rule as ALERT_RULE "
								  +",bar.presn_id as PRESN_ID "
								  +",bar.parti_ref_id as PARTI_REF_ID "
								  +",bar.alert_time_ind as ALERT_TIME_IND "
								  +",nvl(bar.division_name_key_lvl,0) as DIVISION_NAME_KEY_LVL, "
								  +"bar.alert_key_lvl as ALERT_KEY_LVL "
								  +"FROM rabc_alert_rule bar, rabc_presn_id bpi "
								  +"WHERE bar.alert_rule = ''{0}'' "
								  +"and bar.presn_id = bpi.presn_id";

	private static final String qryDivisionNamesListSQL = "SELECT distinct {0} as DIVISIONNAMES "
								 +"FROM  rabc_alert_hist h"
								 +" WHERE h.parti_ref_id in ({1}) and h.PRESN_CD IN (''A'', ''B'') "
								 +"{2}";

	private static final String qryAlertRulePresnElemSQL = "SELECT	Distinct a.presn_id ,a.parti_ref_id ,a.presn_name ,a.presn_seq_num ,g.presn_seq_num AS sumy_presn_seq_num ,a.data_tbl "
								+",a.data_ddl_name ,a.presn_elem_tot_ind ,a.presn_unit_ind ,nvl(a.presn_sum_ind,''Y'') AS presn_sum_ind ,f.tbl_proc_date_ddl_name "
								+",b.link_tbl_key_name as B_LINK_TBL_KEY_NAME,c.link_tbl_key_name  as C_LINK_TBL_KEY_NAME,d.link_ddl_name  as D_LINK_DDL_NAME,e.link_ddl_name  as E_LINK_DDL_NAME "
								+",decode(a.header_link_ind,''Y'',a.header_link_num,'''') header_link_num "
								+",decode(a.header_desc_ind,''Y'',a.header_mouse_over_num,'''') header_mouse_over_num "
								+",decode(a.data_link_ind,''Y'',a.data_link_num,'''') data_link_num "
								+",decode(a.data_desc_ind,''Y'',a.data_mouse_over_num,'''') data_mouse_over_num "
								+",decode(a.graph_presn_ind,''Y '',''Y'',''N'') graph_presn_ind "
								+",a.exec_presn_seq_num ,r.data_key_lvl , "
								+"r.key1_ddl_name ,r.key1_header ,r.key1_hd_link_ind ,r.key1_hd_link_num ,r.key1_hd_parm_ind,r.key1_data_link_ind ,r.key1_data_link_num , "
								+"r.key1_desc_ind ,r.key1_mouse_over_num , "
								+"r.key2_ddl_name ,r.key2_header ,r.key2_hd_link_ind ,r.key2_hd_link_num ,r.key2_hd_parm_ind ,r.key2_data_link_ind ,r.key2_data_link_num "
								+",r.key2_desc_ind ,r.key2_mouse_over_num "
								+",r.key3_ddl_name ,r.key3_header ,r.key3_hd_link_ind ,r.key3_hd_link_num ,r.key3_hd_parm_ind ,r.key3_data_link_ind ,r.key3_data_link_num "
								+",r.key3_desc_ind ,r.key3_mouse_over_num  "
								+",r.key4_ddl_name ,r.key4_header ,r.key4_hd_link_ind ,r.key4_hd_link_num ,r.key4_hd_parm_ind ,r.key4_data_link_ind ,r.key4_data_link_num "
								+",r.key4_desc_ind ,r.key4_mouse_over_num "
								+",r.key5_ddl_name ,r.key5_header ,r.key5_hd_link_ind ,r.key5_hd_link_num ,r.key5_hd_parm_ind ,r.key5_data_link_ind ,r.key5_data_link_num "
								+",r.key5_desc_ind ,r.key5_mouse_over_num "
								+",DECODE(r.file_seq_num_ind,''Y'',1,0) AS seqCnt ,d.link_to_pgm data_link_to_pgm ,p.presn_id_desc "
								+" FROM rabc_alert_rule_presn_elem a ,rabc_alert_rule_presn_rule r  ,rabc_mouse_over_link b ,rabc_mouse_over_link c ,rabc_web_data_link d "
								+",rabc_web_data_link e ,rabc_data_tbl_ddl f ,rabc_alert_sumy_presn g ,rabc_presn_id p "
								+"where a.presn_id = r.presn_id (+) and a.presn_id = p.presn_id (+) and a.webid = r.webid (+)  "
								+"and a.exec_presn_seq_num = r.exec_presn_seq_num (+) and a.header_link_num = e.link_num (+) "
								+"and a.data_link_num = d.link_num (+) and a.header_mouse_over_num = c.mouse_over_num (+) "
								+"and a.data_mouse_over_num = b.mouse_over_num (+) and a.presn_id = b.presn_id (+) "
								+"and a.presn_id = c.presn_id (+) and a.presn_id = d.presn_id (+) and a.presn_id = e.presn_id (+)  "
								+"and a.webid = b.webid (+) and a.webid = c.webid (+) and a.webid = d.webid (+) and a.webid = e.webid (+) "
								+"{0} "
								+"and a.webid = ''{1}'' and a.data_tbl = f.alert_proc_tbl (+) "
								+"and a.presn_id = g.asoc_presn_id  and a.webid = g.webid "
								+"order by a.exec_presn_seq_num, a.presn_seq_num ";
	
	private static final String qryGetMaxColSQL = "SELECT DISTINCT a.presn_seq_num ,a.presn_name "
								+"FROM	rabc_alert_rule_presn_elem a, (select distinct presn_name ,exec_presn_seq_num "
								+"from 	rabc_alert_rule_presn_elem "
								+"where 	presn_id in ( {0} ) "
								+"and webid = ''{1}'' "
								+"order by exec_presn_seq_num ) b "
								+"WHERE	a.exec_presn_seq_num = b.exec_presn_seq_num "
								+"AND	a.presn_id in ( {0} ) AND "
								+"a.webid = ''{1}'' "
								+"ORDER BY a.presn_seq_num ";

	private static final String qryProcDateSQL = "select unique * from rabc_data_tbl_ddl where alert_proc_tbl = ''{0}''";
	
	private static final String qryGetAlertRuleSQL = "SELECT a.presn_id ,a.parti_ref_id ,a.alert_time_ind ,b.tot_ind  "
								+"FROM 	rabc_alert_rule a ,rabc_alert_sumy_presn b "
								+"WHERE	a.presn_id = b.asoc_presn_id "
								+"and b.asoc_presn_id in ({0}) "
								+"and b.webid = ''{1}'' "
								+"and a.alert_rule = b.alert_rule";

	private static final String qryPrevDateSQL = "select * from {0} where parti_ref_id = {1} and proc_date < to_date(''{2}'',''MM/DD/YYYY'') "
								+"{3} and alert_trend_time = ( select distinct alert_trend_time from {0} "
								+"where parti_ref_id = {1} and {4} is null and proc_date = to_date(''{2}'',''MM/DD/YYYY'') {3})";
	
	
	private static final String qrySumyPresnRules = "select alert_rule,presn_id as asoc_presn_id from rabc_alert_rule where {0}";
	
	private static final String qryDynamicSqlCount = "select count(*) from ( {0} )";
	private static final String qryDynamicSql = "select * from (select data1.*, rownum rn from ( {0} ) data1 ) {1}";
	
	private final static String getDefaultDivision = "SELECT DIVISION FROM RABC_USER_DEFAULT_DIVISION WHERE USER_ID = ''{0}''";
	
	private final static String getDefaultLineCount = "SELECT LINE_CT FROM RABC_USER_DEFAULT_RPT_LINE WHERE USER_ID = ''{0}''";
	
	
	/**
	 * This method is used to return the object of AlertsReportDataSQLService class.
	 * 
	 * @return AlertsReportDataSQLService
	 */
	public static AlertsReportDataSQLService getAlertsReportDataSQLService() {
		return new AlertsReportDataSQLService();
	}

	/**
	 * This method is used to configure the label resources properties file.
	 * 
	 */
	public AlertsReportDataSQLService() {
		try {
			labelProperties = ResourceBundle.getBundle(DEFAULT_LABEL_RESOURCES);
		} catch (MissingResourceException e) {
			logger.error("Unable to configure properties file. Exception details: " + e.getMessage(), e);
		}
	}
	
	/**
	 * This is a method to get the label for the passed key.
	 * 
	 * @param key
	 * @return String
	 */
	public static String getLabel(String key) {
		try {
			return labelProperties.getString(key);
		} catch (MissingResourceException e) {
			logger.error("Unable to configure properties file. Exception details: " + e.getMessage(), e);
			return null;
		}
	}

	/**
	 * @param qryAlertRulePresnElemList The qryAlertRulePresnElemList to set.
	 */
	public void setQryAlertRulePresnElemList(List qryAlertRulePresnElemList) {
		this.qryAlertRulePresnElemList = qryAlertRulePresnElemList;
	}

	/**
	 * @param connection The connection to set.
	 */
	public void setConnection(Connection connection) {
		this.connection = connection;
	}

	/**
	 * @param failures The failures to set.
	 */
	public void setFailures(List failures) {
		this.failures = failures;
	}

	/**
	 * @param alertReportParameters The alertReportParameters to set.
	 */
	public void setAlertDataParameters(AlertReportParameters alertReportParameters) {
		this.alertReportParameters = alertReportParameters;
	}

	/**
	 * @return Returns the columns.
	 */
	public List getColumns() {
		return columns;
	}

	/**
	 * @param columns The columns to set.
	 */
	public void setColumns(List columns) {
		this.columns = columns;
	}

	/**
	 * @return Returns the qryGetDataList.
	 */
	public List getQryGetDataList() {
		return qryGetDataList;
	}

	/**
	 * @param qryGetDataList The qryGetDataList to set.
	 */
	public void setQryGetDataList(List qryGetDataList) {
		this.qryGetDataList = qryGetDataList;
	}

	/**
	 * @param qryKeyColList The qryKeyColList to set.
	 */
	public void setQryKeyColList(List qryKeyColList) {
		this.qryKeyColList = qryKeyColList;
	}

	/**
	 * This method is used to get alert rule information which executes the query qryAlertRuleSQL.
	 */
	public void getAlertRuleInfo() {
		Statement stmt = null;
		ResultSet rs = null;
		String qryAlertRuleSQLStmt = null;
		try {
			logger.debug("Executing query qryAlertRuleSQL ...");
			MessageFormat mf = new MessageFormat(qryAlertRuleSQL);
			
			qryAlertRuleSQLStmt = mf.format(new String[]{alertReportParameters.getAlertRule()});
			logger.debug("qryAlertRuleSQLStmt statement = " + qryAlertRuleSQLStmt);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qryAlertRuleSQLStmt);
			if (rs != null) {
				while (rs.next()) {
					alertReportParameters.setPresnId(new Integer(rs.getInt("PRESN_ID")));
					alertReportParameters.setPartiRefId(new Integer(rs.getInt("PARTI_REF_ID")));
					alertReportParameters.addPartiRefId(alertReportParameters.getPartiRefId());
					alertReportParameters.setDivisionNameKeyLvl(new Integer(rs.getInt("DIVISION_NAME_KEY_LVL")));
					alertReportParameters.setAlertKeyLvl(new Integer(rs.getInt("ALERT_KEY_LVL")));
					return;
				}
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryAlertRuleSQLStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryAlertRuleSQLStmt}), sx));
			return;
		} finally{
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
	}

	/**
	 * Method prepares where condition for alertReportParameters.
	 * 
	 * @return String
	 */
	public String prepareWhereCondition() {
		String whereCondition = "";
		if((alertReportParameters.getFileSeqNum()!=null) && (alertReportParameters.getFileSeqNum().intValue() > 0)){
			whereCondition += "and h.file_seq_num= " + alertReportParameters.getFileSeqNum().toString();
		}
		whereCondition += " and h.proc_date = to_date('" + alertReportParameters.getProcDate().toString() + "','mm/dd/yyyy')";
		return whereCondition;
	}

	/**
	 * It executes qryDivisionNamesListStmt query for the all DivisionNameList. 
	 * 
	 * @return String
	 */
	public String getDivisionNameList() {
		String divisions = "";
		String whereCondition =  null; 
		Statement stmt = null;
		ResultSet rs = null;

		whereCondition = prepareWhereCondition();
		MessageFormat mf= new MessageFormat(qryDivisionNamesListSQL);
		int index = (alertReportParameters.getDivisionNameKeyLvl().intValue()<=0?1:alertReportParameters.getDivisionNameKeyLvl().intValue());
		String qryDivisionNamesListStmt = mf.format(new String[] {"alert_Key" + index,
																	alertReportParameters.getPartiRefId().toString(),
																	whereCondition });
		try {
			logger.debug("Executing qryDivisionNamesListStmt query .... " + qryDivisionNamesListStmt);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qryDivisionNamesListStmt);
			if (rs!= null) {
				while (rs.next()) {
					divisions = divisions + "'" + rs.getString("DIVISIONNAMES") + "',"; 
				}
				if (!divisions.equals("") && ((divisions.length() - 2) > 0))
				divisions = divisions.substring(0, divisions.length() - 1);
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryDivisionNamesListStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryDivisionNamesListStmt}), sx));
		} finally{
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
		
		return divisions;
	}

	/**
	 * Method executes qryqrySumyPresnRules for each alert rule.
	 */
	public void executeQrySumyPresnRules() {
		Statement stmt = null;
		ResultSet rs = null;
		String qrySumyPresnRuleStmt = null;
		String totRule = "";
		String arg_0 = "";
		String alertRule = alertReportParameters.getAlertRule();
		String asocPresnIds = "";
		String alertRules = "";
		String tmpAlertRule = "";
		String presnId = "";
		if(alertReportParameters.getAllInfoIndicator().equals("Y")){
			if(alertRule.indexOf("-DAILY")!=-1){
				totRule ="Y";
			}else{
				totRule ="N";
			}
			if(totRule.equals("Y")){
				arg_0 = "alert_rule = '" + alertRule + "'";
			}else{
				arg_0 = "alert_rule = '" + alertRule + "' or alert_rule = '" + alertRule + "-DAILY'";
			}
		}else{
			arg_0 = "alert_rule = '" + alertRule + "'";
		}
		try {
			logger.debug("Executing query qryqrySumyPresnRules ...");
			MessageFormat mf = new MessageFormat(qrySumyPresnRules);
			
			qrySumyPresnRuleStmt= mf.format(new String[]{arg_0});
			logger.debug("qrySumyPresnRuleStmt statement = " + qrySumyPresnRuleStmt);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qrySumyPresnRuleStmt);
			if (rs != null) {
				while (rs.next()) {
					tmpAlertRule = rs.getString("alert_rule");
					presnId= rs.getString("asoc_presn_id");
					alertReportParameters.addAlertRule(tmpAlertRule);
					alertReportParameters.addPresnId(new Integer(presnId));
					alertReportParameters.addAsocPresnID(new Integer(presnId));
				}
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qrySumyPresnRuleStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qrySumyPresnRuleStmt}), sx));
		} finally{
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
	}

	/**
	 * Method executes qryAlertRulePresnElemSQLStmt query.
	 */
	public void executeQryAlertRulePresnElem() {
		Statement stmt = null;
		ResultSet rs = null;
		MessageFormat mf= new MessageFormat(qryAlertRulePresnElemSQL);
		int seqCnt = 0;
		QryAlertRulePresnElem qryAlertRulePresnElem = null;
		
		String arg_0 = "";
		
		if (!alertReportParameters.getAsocPresnIDs().equals("")) {
			arg_0 = "and a.presn_id in (" + alertReportParameters.getAsocPresnIDs() + ") ";
		}
		String qryAlertRulePresnElemSQLStmt = mf.format(new String[] {arg_0, alertReportParameters.getWebPageId()});
		try {															
			logger.debug("Executing qryAlertRulePresnElemSQLStmt query .... " + qryAlertRulePresnElemSQLStmt);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qryAlertRulePresnElemSQLStmt);
			if (rs != null) {
				while (rs.next()) {
					qryAlertRulePresnElem = buildQryAlertRulePresnElem(rs);
					seqCnt += qryAlertRulePresnElem.getSeqCnt();
					// unique tables
					updateUniqueTables(qryAlertRulePresnElem.getDataTbl());
					if (qryAlertRulePresnElem.getDataKeyLvl() > 0) {
						updateQryKeyCol(qryAlertRulePresnElem);
					}
					qryAlertRulePresnElemList.add(qryAlertRulePresnElem);
				}
				alertReportParameters.setTotCnt(qryAlertRulePresnElemList.size());
				alertReportParameters.setSeqCnt(seqCnt);
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryAlertRulePresnElemSQLStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryAlertRulePresnElemSQLStmt}), sx));
		} finally{
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
		
		return;
		
	}

	/**
	 * Method updates UniqueTables for the passed string.
	 * 
	 * @param dataTbl
	 */
	private void updateUniqueTables(String dataTbl) {
		List uniqueTables = alertReportParameters.getUniqueTables();
		if (uniqueTables == null) {
			uniqueTables = new ArrayList();
			uniqueTables.add(dataTbl);
			alertReportParameters.setUniqueTables(uniqueTables);
			return;
		}
		int i = 0;
		int size = uniqueTables.size();
		for(i = 0; i < size; i++) {
			if (dataTbl.equals((String)uniqueTables.get(i))) {
				return;
			}
		}
		uniqueTables.add(dataTbl);
	}

	/**
	 *  Method creates the new QryKeyCol for the passed element.
	 * 
	 * @param qryAlertRulePresnElem
	 */
	private void updateQryKeyCol(QryAlertRulePresnElem qryAlertRulePresnElem) {
		int i = 0;

		// Construct new qryKeyCol struct
		QryKeyColStruct qryKeyColStruct = new QryKeyColStruct();
		qryKeyColStruct.presnId = qryAlertRulePresnElem.getPresnId();
		for(i = 0; i < 5; i++)
			qryKeyColStruct.keyHeader[i] = qryAlertRulePresnElem.getKeyHeaderAt(i);
		for(i = 0; i < 5; i++)
			qryKeyColStruct.keyDdlName[i] = qryAlertRulePresnElem.getKeyDdlNameAt(i);
		qryKeyColStruct.dataKeyLvl = qryAlertRulePresnElem.getDataKeyLvl();
		qryKeyColStruct.execPresnSeqNum = qryAlertRulePresnElem.getExecPresnSeqNum();
		qryKeyColStruct.presnSeqNum = qryAlertRulePresnElem.getPresnSeqNum();

		// check whether it is added or not
		if (notSelected(qryKeyColStruct)) {
			addAtCorrectPosition(qryKeyColStruct);
		}
	}

	/**
	 * Private method returns boolean value whether qryKeyColStructInput is selected or not.
	 * 
	 * @param qryKeyColStructInput
	 * @return boolean
	 */
	private boolean notSelected(QryKeyColStruct qryKeyColStructInput) {
		int i = 0;
		QryKeyColStruct qryKeyColStruct = null; 
		int size = qryKeyColList.size();
		for(i = 0; i < size; i++) {
			qryKeyColStruct = (QryKeyColStruct) qryKeyColList.get(i);
			if (qryKeyColStruct.equals(qryKeyColStructInput)) return false;
		}
		return true;
	}

	/**
	 * Private method returns the value depending upon received object.
	 * 
	 * @param inputParameters
	 * @param currentParameters
	 * @return int
	 */
	private int decideForAsc(List inputParameters, List currentParameters) {
		if (inputParameters.isEmpty()) {
			logger.warn("Received empty list in order by logic....");
			return NEXT_ROW;
		}
		for (int i=0; i < inputParameters.size(); i++) {
			Object obj = inputParameters.get(i);
			if (obj != null) {
				if (obj instanceof String) {
					String inputStr = (String) obj;
					String currentStr = (String) currentParameters.get(i);
					if (currentStr == null) {
						logger.warn("Received null object in current Parameter List....");
						return NEXT_ROW;
					}
					if (inputStr.compareTo(currentStr) < 0) return INSERT;
					if (inputStr.compareTo(currentStr) > 0) return NEXT_ROW;
					// process next key
				} else {
					if (obj instanceof Integer) {
						Integer inputInt = (Integer) obj;
						Integer currentInt = (Integer) currentParameters.get(i);
						if (currentInt == null) {
							logger.warn("Received null object in current Parameter List....");
							return NEXT_ROW;
						}
						if (inputInt.intValue() < currentInt.intValue()) return INSERT;
						if (inputInt.intValue() > currentInt.intValue()) return NEXT_ROW;
						// process next key					
					} else {
						if (obj instanceof Date) {
							MyDate inputDate = new MyDate((Date)obj);
							if (currentParameters.get(i) == null) {
								logger.warn("Received null object in current Parameter List....");
								return NEXT_ROW;
							}
							MyDate currentDate = new MyDate((Date)currentParameters.get(i));
							if (inputDate.compareTo(currentDate) < 0) return INSERT;
							if (inputDate.compareTo(currentDate) > 0) return NEXT_ROW;
							// process next key
						} else {
							logger.warn("Received unsupported object type in Order By logic .....");
							return NEXT_ROW;							
						}
					}
				}
			}
		} // end of for loop
		return NEXT_ROW;
	}

	/**
	 * This method is used to add seq num at correct position.
	 * 
	 * @param qryKeyColStructNew
	 */
	private void addAtCorrectPosition(QryKeyColStruct qryKeyColStructNew) {
		int i = 0;
		int option = 0;
		int size = qryKeyColList.size();
		QryKeyColStruct qryKeyColStruct = null; 
		List currentColumnList = new ArrayList();
		List newColumnList = new ArrayList();

		// exec_presn_seq_num
		newColumnList.add(new Integer(qryKeyColStructNew.execPresnSeqNum));
		// presn_seq_num
		newColumnList.add(new Integer(qryKeyColStructNew.presnSeqNum));
		for(i=0; i < size; i++) {
			qryKeyColStruct = (QryKeyColStruct) qryKeyColList.get(i);

			currentColumnList.clear();
			// exec_presn_seq_num
			currentColumnList.add(new Integer(qryKeyColStruct.execPresnSeqNum));

			// presn_seq_num
			currentColumnList.add(new Integer(qryKeyColStruct.presnSeqNum));

			option = decideForAsc(newColumnList, currentColumnList);
			if (option == INSERT) {
				qryKeyColList.add(i, qryKeyColStructNew);
				return;
			}
		}
		qryKeyColList.add(qryKeyColStructNew);
		return;
	}

	/**
	 * Private method which sets the element in QryAlertRulePresnElem.
	 * 
	 * @param rs
	 * @return QryAlertRulePresnElem
	 * @throws SQLException
	 */
	private QryAlertRulePresnElem buildQryAlertRulePresnElem(ResultSet rs) throws SQLException {
		QryAlertRulePresnElem qryAlertRulePresnElem = new QryAlertRulePresnElem();

		qryAlertRulePresnElem.setPresnId(rs.getInt("PRESN_ID"));
		qryAlertRulePresnElem.setPartiRefId(rs.getInt("PARTI_REF_ID"));
		qryAlertRulePresnElem.setPresnName(rs.getString("PRESN_NAME"));
		qryAlertRulePresnElem.setPresnSeqNum(rs.getInt("PRESN_SEQ_NUM"));
		qryAlertRulePresnElem.setSumyPresnSeqNum(rs.getInt("SUMY_PRESN_SEQ_NUM"));
		qryAlertRulePresnElem.setDataTbl(rs.getString("DATA_TBL"));
		qryAlertRulePresnElem.setDataDdlName(rs.getString("DATA_DDL_NAME"));
		qryAlertRulePresnElem.setPresnElemTotInd(rs.getString("PRESN_ELEM_TOT_IND"));
		qryAlertRulePresnElem.setPresnUnitInd(rs.getString("PRESN_UNIT_IND"));
		qryAlertRulePresnElem.setPresnSumInd(rs.getString("PRESN_SUM_IND"));
		qryAlertRulePresnElem.setTblProcDateDdlName(rs.getString("TBL_PROC_DATE_DDL_NAME"));
		qryAlertRulePresnElem.setBlinkTblKeyName(rs.getString("B_LINK_TBL_KEY_NAME"));
		qryAlertRulePresnElem.setClinkTblKeyName(rs.getString("C_LINK_TBL_KEY_NAME"));;
		qryAlertRulePresnElem.setDlinkDdlName(rs.getString("D_LINK_DDL_NAME"));
		qryAlertRulePresnElem.setElinkDdlName(rs.getString("E_LINK_DDL_NAME"));
		qryAlertRulePresnElem.setHeaderLinkNum(rs.getInt("HEADER_LINK_NUM"));
		qryAlertRulePresnElem.setHeaderMouseOverNum(rs.getInt("HEADER_MOUSE_OVER_NUM"));
		qryAlertRulePresnElem.setDataLinkNum(rs.getInt("DATA_LINK_NUM"));
		qryAlertRulePresnElem.setDataMouseOverNum(rs.getInt("DATA_MOUSE_OVER_NUM"));
		qryAlertRulePresnElem.setGraphPresnInd(rs.getString("GRAPH_PRESN_IND"));
		qryAlertRulePresnElem.setExecPresnSeqNum(rs.getInt("EXEC_PRESN_SEQ_NUM"));
		qryAlertRulePresnElem.setDataKeyLvl(rs.getInt("DATA_KEY_LVL"));
		qryAlertRulePresnElem.setKeyDdlNameAt(0, rs.getString("KEY1_DDL_NAME")); 
		qryAlertRulePresnElem.setKeyDdlNameAt(1, rs.getString("KEY2_DDL_NAME")); 
		qryAlertRulePresnElem.setKeyDdlNameAt(2, rs.getString("KEY3_DDL_NAME")); 
		qryAlertRulePresnElem.setKeyDdlNameAt(3, rs.getString("KEY4_DDL_NAME")); 
		qryAlertRulePresnElem.setKeyDdlNameAt(4, rs.getString("KEY5_DDL_NAME")); 
		qryAlertRulePresnElem.setKeyHeaderAt(0, rs.getString("KEY1_HEADER")); 
		qryAlertRulePresnElem.setKeyHeaderAt(1, rs.getString("KEY2_HEADER")); 
		qryAlertRulePresnElem.setKeyHeaderAt(2, rs.getString("KEY3_HEADER")); 
		qryAlertRulePresnElem.setKeyHeaderAt(3, rs.getString("KEY4_HEADER")); 
		qryAlertRulePresnElem.setKeyHeaderAt(4, rs.getString("KEY5_HEADER")); 
		qryAlertRulePresnElem.setKeyHdLinkIndAt(0, rs.getString("KEY1_HD_LINK_IND")); 
		qryAlertRulePresnElem.setKeyHdLinkIndAt(1, rs.getString("KEY2_HD_LINK_IND")); 
		qryAlertRulePresnElem.setKeyHdLinkIndAt(2, rs.getString("KEY3_HD_LINK_IND")); 
		qryAlertRulePresnElem.setKeyHdLinkIndAt(3, rs.getString("KEY4_HD_LINK_IND")); 
		qryAlertRulePresnElem.setKeyHdLinkIndAt(4, rs.getString("KEY5_HD_LINK_IND")); 
		qryAlertRulePresnElem.setKeyHdLinkNumAt(0, rs.getInt("KEY1_HD_LINK_NUM")); 
		qryAlertRulePresnElem.setKeyHdLinkNumAt(1, rs.getInt("KEY2_HD_LINK_NUM")); 
		qryAlertRulePresnElem.setKeyHdLinkNumAt(2, rs.getInt("KEY3_HD_LINK_NUM")); 
		qryAlertRulePresnElem.setKeyHdLinkNumAt(3, rs.getInt("KEY4_HD_LINK_NUM")); 
		qryAlertRulePresnElem.setKeyHdLinkNumAt(4, rs.getInt("KEY5_HD_LINK_NUM")); 
		qryAlertRulePresnElem.setKeyHdParmIndAt(0, rs.getString("KEY1_HD_PARM_IND")); 
		qryAlertRulePresnElem.setKeyHdParmIndAt(1, rs.getString("KEY2_HD_PARM_IND")); 
		qryAlertRulePresnElem.setKeyHdParmIndAt(2, rs.getString("KEY3_HD_PARM_IND")); 
		qryAlertRulePresnElem.setKeyHdParmIndAt(3, rs.getString("KEY4_HD_PARM_IND")); 
		qryAlertRulePresnElem.setKeyHdParmIndAt(4, rs.getString("KEY5_HD_PARM_IND")); 
		qryAlertRulePresnElem.setKeyDataLinkIndAt(0, rs.getString("KEY1_DATA_LINK_IND")); 
		qryAlertRulePresnElem.setKeyDataLinkIndAt(1, rs.getString("KEY2_DATA_LINK_IND")); 
		qryAlertRulePresnElem.setKeyDataLinkIndAt(2, rs.getString("KEY3_DATA_LINK_IND")); 
		qryAlertRulePresnElem.setKeyDataLinkIndAt(3, rs.getString("KEY4_DATA_LINK_IND")); 
		qryAlertRulePresnElem.setKeyDataLinkIndAt(4, rs.getString("KEY5_DATA_LINK_IND")); 
		qryAlertRulePresnElem.setKeyDataLinkNumAt(0, rs.getInt("KEY1_DATA_LINK_NUM")); 
		qryAlertRulePresnElem.setKeyDataLinkNumAt(1, rs.getInt("KEY2_DATA_LINK_NUM")); 
		qryAlertRulePresnElem.setKeyDataLinkNumAt(2, rs.getInt("KEY3_DATA_LINK_NUM")); 
		qryAlertRulePresnElem.setKeyDataLinkNumAt(3, rs.getInt("KEY4_DATA_LINK_NUM")); 
		qryAlertRulePresnElem.setKeyDataLinkNumAt(4, rs.getInt("KEY5_DATA_LINK_NUM")); 
		qryAlertRulePresnElem.setKeyDescIndAt(0, rs.getString("KEY1_DESC_IND")); 
		qryAlertRulePresnElem.setKeyDescIndAt(1, rs.getString("KEY2_DESC_IND")); 
		qryAlertRulePresnElem.setKeyDescIndAt(2, rs.getString("KEY3_DESC_IND")); 
		qryAlertRulePresnElem.setKeyDescIndAt(3, rs.getString("KEY4_DESC_IND")); 
		qryAlertRulePresnElem.setKeyDescIndAt(4, rs.getString("KEY5_DESC_IND")); 
		qryAlertRulePresnElem.setKeyMouseOverNumAt(0, rs.getInt("KEY1_MOUSE_OVER_NUM")); 
		qryAlertRulePresnElem.setKeyMouseOverNumAt(1, rs.getInt("KEY2_MOUSE_OVER_NUM")); 
		qryAlertRulePresnElem.setKeyMouseOverNumAt(2, rs.getInt("KEY3_MOUSE_OVER_NUM")); 
		qryAlertRulePresnElem.setKeyMouseOverNumAt(3, rs.getInt("KEY4_MOUSE_OVER_NUM")); 
		qryAlertRulePresnElem.setKeyMouseOverNumAt(4, rs.getInt("KEY5_MOUSE_OVER_NUM")); 
		qryAlertRulePresnElem.setSeqCnt(rs.getInt("SEQCNT"));
		qryAlertRulePresnElem.setDataLinkToPgm(rs.getString("DATA_LINK_TO_PGM"));
		qryAlertRulePresnElem.setPresnIdDesc(rs.getString("PRESN_ID_DESC"));
		
		return qryAlertRulePresnElem;
	}

	/**
	 * This method processes QryKeyCol.
	 */
	public void processQryKeyCol() {
		int i = 0;
		int j = 0;
		int foundAt;
		int option = 0;
		int size = qryKeyColList.size();
		int maxKeyCol = 0;
		QryKeyColStruct qryKeyColStruct = null;
		
		for(i = 0; i < size; i++) {
			qryKeyColStruct = (QryKeyColStruct) qryKeyColList.get(i);
			for(j = 0; j < qryKeyColStruct.dataKeyLvl; j++) {
				foundAt = foundAt(qryKeyColStruct.keyHeader[j]);
				if (foundAt == -1) {
					// key column not found add it
					columns.add(qryKeyColStruct.keyHeader[j]);
				}
			}
			if (qryKeyColStruct.dataKeyLvl > maxKeyCol) {
				maxKeyCol = qryKeyColStruct.dataKeyLvl;
			}
		}
		// Number of Keys
		//alertReportParameters.setMaxKeyCol(maxKeyCol);
		alertReportParameters.setNbrOfKeys(columns.size());
	}

	/**
	 * This method returns 0 if keyColumn is null/"" and
	 * returns -1 if not found.
	 * 
	 * @param keyColumn
	 * @return int
	 */
	private int foundAt(String keyColumn) {
		if (keyColumn == null) return 0;
		if (keyColumn.equals("")) return 0;

		int i = 0;
		int size = columns.size();
		for(i = 0; i < size; i++) 
			if (keyColumn.equals((String)columns.get(i))) return i;

		// not found	
		return -1;
	}

	/**
	 * Method executes qryGetMaxColSQLStmt query to process data columns.
	 */
	public void processDataColumns() {				
		String presnName;
		String presnSeqNum;
		Statement stmt = null;
		ResultSet rs = null;

		MessageFormat mf= new MessageFormat(qryGetMaxColSQL);
	
		String qryGetMaxColSQLStmt = mf.format(new String[] {alertReportParameters.getAsocPresnIDs(), alertReportParameters.getWebPageId()});
		try {															
			logger.debug("Executing qryGetMaxColSQLStmt query .... " + qryGetMaxColSQLStmt);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qryGetMaxColSQLStmt);
			if (rs != null) {
				while (rs.next()) {
					presnName = rs.getString("PRESN_NAME");
					presnSeqNum = rs.getString("PRESN_SEQ_NUM");
					if (presnName != null) {
						processColumn(presnName + "~" + presnSeqNum);
					}
				}
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryGetMaxColSQLStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryGetMaxColSQLStmt}), sx));
		} finally{
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
		
		return;
		
	}
	
	/**
	 * Method processes the column for the passed element.
	 * 
	 * @param dataColumn
	 */
	private void processColumn(String dataColumn) {
		if (dataColumn.equals("")) return;

		int i = 0;
		int seqColPosition = -1;
		int size = columns.size();
		boolean found = false;
		String sequenceNbrCol = getLabel("alertData.label.seqNumber");
		String columnName;
		for(i = 0; i < size; i++) {
			columnName = (String)columns.get(i);
			if (dataColumn.equals(columnName)) found = true;
			
			String actualColumnName = columnName;
			if (columnName.indexOf("~")!=-1){
				actualColumnName = columnName.substring(0,columnName.indexOf("~"));
			} 
			if (sequenceNbrCol.equals(actualColumnName)) seqColPosition = i;
		}
		if (found) return;
		
		// not found
		String actualDataColumnName = dataColumn;
		if (dataColumn.indexOf("~")!=-1){
			actualDataColumnName = dataColumn.substring(0,dataColumn.indexOf("~"));
		} 
		if (actualDataColumnName.equalsIgnoreCase(getLabel("alertData.label.alertItem"))) {
			if (seqColPosition != -1) {
				columns.add(seqColPosition, dataColumn);
			} else {
				columns.add(dataColumn);
			}
		} else {
			columns.add(dataColumn);
		}
	}
	/**
	 * This method builds dynamic queries to process each table.
	 */
	public void buildDynamicQueries() {
		int i, j, k, l, m;
		List uniqueTables = alertReportParameters.getUniqueTables();
		int sizeOfUniqueTables = uniqueTables.size();
		int sizeOfUniquePresnId;
		int sizeOfTblCols;
		int sizeOfColumns = columns.size();
		int keyCnt = 0;
		String sum1;
		String sum2;
		String colFileSeqNum;
		boolean rabcTable = false;
		boolean colFound = false;
		int partiRefId; 
		String alertTimeInd; 
		String totInd;
		String thisTable;
		String thisProcDate;
		String thisProcDateMonth;
		String thisProcDateYear;
		String thisProcDateBillround;
		String hdrName;
		String key1DDL = "";
		String key2DDL = "";
		String key3DDL = "";
		String key4DDL = "";
		String key5DDL = "";
		StringBuffer tmpKeyTested = new StringBuffer();
		DataTblDdlDAO dataTblDdlDAO = null;
		DataTblDdl dataTblDdl = null;
		List args = new ArrayList();
		List dataTblDdls = null;
		List uniquePresnIds = new ArrayList();
		List alertRuleInfoList = new ArrayList();
		List tblColList = new ArrayList();
		UniquePresnIDStruct uniquePresnIDStruct = null;
		AlertRuleInfoStruct alertRuleInfoStruct = null;
		TblColStruct tblColStruct = null;
		StringBuffer sqlTblQry = new StringBuffer();
		StringBuffer sqlGroupBy = new StringBuffer();
		StringBuffer sqlTblQry2 = new StringBuffer();
		StringBuffer keyWhere = new StringBuffer();
		int recordCount = 0;		
		int nbrOfKeys = alertReportParameters.getNbrOfKeys();
		alertReportParameters.setNbrOfColumns(new Integer(sizeOfColumns));
		for (i = 0; i < sizeOfUniqueTables; i++) {
			// process each table
			thisTable = (String) uniqueTables.get(i);
			sqlGroupBy.setLength(0); 
			sum1 = "";
			sum2 = "";
			colFileSeqNum = "file_seq_num";
			
			if ((thisTable.equals("RABC_EXTRCT_SUMY_DATA")) |
				(thisTable.equals("RABC_CALC_ALERT_DATA")) |
				(thisTable.equals("RABC_ALERT_HIST"))) {
				rabcTable = true;
			} else {
				rabcTable = false;	
				sqlGroupBy.append(" GROUP BY ");
				sum1 = "sum(";
				sum2 = ")";
				colFileSeqNum = "seq_num";
			}
			if (rabcTable) {
				thisProcDate = "proc_date";
			} else {
				if (dataTblDdlDAO == null) dataTblDdlDAO = new DataTblDdlDAO();
				args.clear();
				args.add(thisTable);				
				dataTblDdls = dataTblDdlDAO.get(connection, failures, args, qryProcDateSQL);
				if (!failures.isEmpty()) return;
				dataTblDdl = (DataTblDdl) dataTblDdls.get(0);
				thisProcDate = dataTblDdl.getTblProcDateDdlName();
				thisProcDateMonth = dataTblDdl.getTblBillRndDdlMon();
				thisProcDateYear = dataTblDdl.getTblBillRndDdlYear();
				thisProcDateBillround = dataTblDdl.getTblBillRndDdlName();
			}
			// get unique presn IDs for this table
			uniquePresnIds.clear();
			alertRuleInfoList.clear();
			getUniquePresnIds(uniquePresnIds, thisTable);
			// read alert rule info for each unique presn id in one go, instead of going each time to database 
			getAlertRuleInfo(alertRuleInfoList, uniquePresnIds);
			
			sizeOfUniquePresnId = uniquePresnIds.size();
			for(j = 0; j < sizeOfUniquePresnId; j++) {
				uniquePresnIDStruct = (UniquePresnIDStruct) uniquePresnIds.get(j);
				alertRuleInfoStruct = getAlertRuleInfo(alertRuleInfoList, uniquePresnIDStruct.presnId);
				if (alertRuleInfoStruct != null) {
					partiRefId = alertRuleInfoStruct.partiRefId;
					alertTimeInd = alertRuleInfoStruct.alertTimeInd;
					totInd = alertRuleInfoStruct.totInd;
				} else {
					partiRefId = -1;
					alertTimeInd = "";
					totInd = "";					
				}
				tblColList.clear();
				getTblCols(tblColList,thisTable,uniquePresnIDStruct.presnId);

				sqlTblQry.append("SELECT distinct ");
				sqlTblQry.append("'" + uniquePresnIDStruct.presnId + "' PRESN_ID, ");
				sqlTblQry.append("to_char(" + thisProcDate + ",'MM/DD/YYYY') FILE_PROCESS_DATE");
				
				if (!rabcTable) sqlGroupBy.append(thisProcDate);

				keyCnt = 0;
				tmpKeyTested.setLength(0);
				colFound = false;
				sizeOfTblCols = tblColList.size();
				for(k = 0; k < nbrOfKeys; k++) {	
					hdrName = (String) columns.get(k);
					for(l = 0; l < sizeOfTblCols; l++) {
						tblColStruct = (TblColStruct)tblColList.get(l); 
						for(m = 0; m < 5; m++) {
							if ((hdrName.equals(tblColStruct.keyHeader[m])) && 
								(keyCnt <= nbrOfKeys) && 
								(tmpKeyTested.indexOf(hdrName) == -1)) {
								colFound = true;
								keyCnt=keyCnt+1;
								tmpKeyTested.append("," + hdrName);
								hdrName = hdrName.replace(' ','_');
								if (m == 0) key1DDL = tblColStruct.keyDdlName[m];
								if (m == 1) key2DDL = tblColStruct.keyDdlName[m];
								if (m == 2) key3DDL = tblColStruct.keyDdlName[m];
								if (m == 3) key4DDL = tblColStruct.keyDdlName[m];
								if (m == 4) key5DDL = tblColStruct.keyDdlName[m];
								sqlTblQry.append(", "+ tblColStruct.keyDdlName[m] + " AS " + hdrName);
								sqlTblQry.append(", "+ tblColStruct.keyDdlName[m] + " AS " + "key"+(m+1));
								columnNames.add(hdrName);
								columnNames.add("key"+(m+1));
								columnNames1.add(hdrName);
								columnNames1.add("key"+(m+1));
								if (!rabcTable) sqlGroupBy.append(","+tblColStruct.keyDdlName[m]);
							}
						} // end of m loop
					} // end of TblCols loop
					if ((!colFound) && 
						(keyCnt <= nbrOfKeys) && 
						(tmpKeyTested.indexOf(hdrName) == -1)) {
						logger.warn("Logic - needs to verify");
						hdrName = hdrName.replace(' ','_');
						sqlTblQry.append(", '' AS " + hdrName);
						sqlTblQry.append(", '' AS " + "key5");
						columnNames.add(hdrName);
						columnNames.add("key5");
						columnNames1.add(hdrName);
						columnNames1.add("key5");
					}					
				} // end of Nbr Of Keys loop
				// <!--- Handle sequence number --->
				if (rabcTable) {
					sqlTblQry.append(", "+ colFileSeqNum +" AS Sequence_Number");
				} else {
					sqlTblQry.append(", "+ colFileSeqNum +" AS Sequence_Number");
					sqlGroupBy.append(","+ colFileSeqNum);
				}

				// Loop through data column
				colFound = false;
				tmpKeyTested.setLength(0);
				String sequenceNbrCol = getLabel("alertData.label.seqNumber");
				int nbrofStdColumns = alertReportParameters.getNbrStdColumns().intValue();
				for(k = nbrOfKeys + nbrofStdColumns; k < sizeOfColumns; k++) {
					String dataColumn = (String) columns.get(k);
					hdrName = new String(dataColumn);
					String hdrSeqNum = null;
					if (dataColumn.indexOf("~")!=-1){
						hdrName = dataColumn.substring(0,dataColumn.indexOf("~"));
						hdrSeqNum = dataColumn.substring(dataColumn.indexOf("~")+1,dataColumn.length());
					}
					
					if (!hdrName.equals(sequenceNbrCol)) {
						// the above if condition is required because data column 'Alert Item' exist just before sequence column
						// and we need not process sequence column in this loop as it is handled above.
						for(l = 0; l < sizeOfTblCols; l++) {
							tblColStruct = (TblColStruct)tblColList.get(l);
							if ((hdrName.equals(tblColStruct.presnName)) && (hdrSeqNum!=null && hdrSeqNum.equals(Integer.toString(tblColStruct.presnSeqNum)))) {
								colFound = true;
								if (rabcTable) {
									hdrName = hdrName.replace(' ','_');
									hdrName = hdrName.replace('.','_');
									sqlTblQry.append(", to_char(" + tblColStruct.dataDdlName + ")  AS datacol" + l);
									sqlTblQry.append(", '" + tblColStruct.dataDdlName + "'  AS datacol" + l + "_D");
									if (hdrSeqNum!=null){
										columnNames.add(hdrName + "~" + hdrSeqNum);
										columnNames.add(hdrName + "~" + hdrSeqNum + "_D");
									} else {
										columnNames.add(hdrName);
										columnNames.add(hdrName + "_D");
									}
									columnNames1.add("datacol" + l);
									columnNames1.add("datacol" + l + "_D");
								} else {
									if (tblColStruct.presnSumInd.equals("Y")) {
										// <!--- column is to be summed --->
										hdrName = hdrName.replace(' ','_');
										hdrName = hdrName.replace('.','_');
										sqlTblQry.append(", " + sum1 + tblColStruct.dataDdlName + sum2 + " AS datacol" + l);
										sqlTblQry.append(", '" + tblColStruct.dataDdlName + "'  AS datacol" + l+"_D");
										if (hdrSeqNum!=null){
											columnNames.add(hdrName + "~" + hdrSeqNum);
											columnNames.add(hdrName + "~" + hdrSeqNum + "_D");
										} else {
											columnNames.add(hdrName);
											columnNames.add(hdrName + "_D");
										}
										columnNames1.add("datacol" + l);
										columnNames1.add("datacol" + l + "_D");							
									} else {
										// <!--- column needs to be in the group by clause --->
										hdrName = hdrName.replace(' ','_');
										hdrName = hdrName.replace('.','_');
										sqlTblQry.append(", " + tblColStruct.dataDdlName + " AS datacol" + l);
										sqlTblQry.append(", '" + tblColStruct.dataDdlName + "'  AS datacol" + l +"_D");
										hdrName = hdrName.replace(' ','_');
										sqlGroupBy.append("," + hdrName);
										if (hdrSeqNum!=null){
											columnNames.add(hdrName + "~" + hdrSeqNum);
											columnNames.add(hdrName + "~" + hdrSeqNum + "_D");
										} else {
											columnNames.add(hdrName);
											columnNames.add(hdrName + "_D");
										}
										columnNames1.add("datacol" + l);
										columnNames1.add("datacol" + l + "_D");								
									}
								}
								tmpKeyTested.append("," + hdrName.replace(' ','_'));
							}
						} // end of tbl cols loop
						if (!colFound) {
							logger.warn("Logic - column not found. Needs Verification");
							hdrName.trim();
							hdrName = hdrName.replace(' ','_');
							hdrName = hdrName.replace('.','_');
							sqlTblQry.append(", '' AS " + hdrName);
							sqlTblQry.append(", '' AS " + hdrName+"_D");
							if (hdrSeqNum!=null){
								columnNames.add(hdrName + "~" + hdrSeqNum);
								columnNames.add(hdrName + "~" + hdrSeqNum + "_D");
							} else {
								columnNames.add(hdrName);
								columnNames.add(hdrName + "_D");
							}
							columnNames1.add(hdrName);
							columnNames1.add(hdrName + "_D");
						}
					}
				} //  end of data column loop
				sqlTblQry.append(", '"+ thisTable + "' AS ThisTable");				
				sqlTblQry.append(", '"+ uniquePresnIDStruct.partiRefId + "' AS ThisPartiRefID");				
				sqlTblQry.append(", '"+ thisProcDate + "' AS ThisProcDate");
				sqlTblQry.append(", '"+ totInd + "' AS ThisTotInd");
				sqlTblQry.append(", '"+ alertTimeInd + "' AS ThisAlertTimeInd");
				if ((totInd.equals("Y")) && (alertReportParameters.getAllInfoIndicator().equals("Y"))) {
					sqlTblQry2.append(sqlTblQry.toString());
					sqlTblQry2.append(" , 'Y' AS ThisPrevTotInd  FROM ");
					sqlTblQry2.append(thisTable);
					sqlTblQry2.append(" WHERE 1 = 1 ");
				}
				sqlTblQry.append(" , 'N' AS ThisPrevTotInd  FROM ");
				sqlTblQry.append(thisTable);
				sqlTblQry.append(" WHERE 1 = 1 ");
				// <!--- Creating the Where --->
				int tmpLen = keyWhere.length();
				if (tmpLen > 0) keyWhere.delete(0,tmpLen-1);
				if (alertReportParameters.getDivisionNameKeyLvl().intValue() > 0) {
					keyWhere.append(" and EXTRCT_KEY");
					keyWhere.append(alertReportParameters.getDivisionNameKeyLvl());
					keyWhere.append(" in (");
					//keyWhere.append(alertReportParameters.getKey1s());
					if ((alertReportParameters.getDivisionName().equals("ALL")) && (alertReportParameters.getDivisionNameKeyLvl().intValue() > 0)) {
						keyWhere.append(alertReportParameters.getDivisionNameList());
					}else{
						keyWhere.append(alertReportParameters.getKey1s());
					}
					keyWhere.append(" )");
				}
				if ((alertReportParameters.getDivisionNameKeyLvl().intValue() != 1) && 
					(alertReportParameters.getAlertKeyLvl().intValue() != 0) && 
					(!alertReportParameters.getKeysAt(0).equals(""))) {
					if (!key1DDL.equals("")) {
						keyWhere.append(" and " + key1DDL + " = '" + alertReportParameters.getKeysAt(0) + "'");						
					}
				}
				if ((alertReportParameters.getDivisionNameKeyLvl().intValue() != 2) && 
					(alertReportParameters.getAlertKeyLvl().intValue() != 0) && 
					(!alertReportParameters.getKeysAt(1).equals(""))) {
					if (!key2DDL.equals("")) {
						keyWhere.append(" and " + key2DDL + " = '" + alertReportParameters.getKeysAt(1) + "'");						
					}
				}
				if ((alertReportParameters.getDivisionNameKeyLvl().intValue() != 3) && 
					(alertReportParameters.getAlertKeyLvl().intValue() != 0) && 
					(!alertReportParameters.getKeysAt(2).equals(""))) {
					if (!key3DDL.equals("")) {
						keyWhere.append(" and " + key3DDL + " = '" + alertReportParameters.getKeysAt(2) + "'");						
					}
				}
				if ((alertReportParameters.getDivisionNameKeyLvl().intValue() != 4) && 
					(alertReportParameters.getAlertKeyLvl().intValue() != 3) && 
					(!alertReportParameters.getKeysAt(3).equals(""))) {
					if (!key4DDL.equals("")) {
						keyWhere.append(" and " + key4DDL + " = '" + alertReportParameters.getKeysAt(3) + "'");						
					}
				}
				if ((alertReportParameters.getDivisionNameKeyLvl().intValue() != 5) && 
					(alertReportParameters.getAlertKeyLvl().intValue() != 0) && 
					(!alertReportParameters.getKeysAt(4).equals(""))) {
					if (!key5DDL.equals("")) {
						keyWhere.append(" and " + key5DDL + " = '" + alertReportParameters.getKeysAt(4) + "'");						
					}
				}
				sqlTblQry.append(" and to_char(" + thisProcDate + ",'MM/DD/YYYY') = '" + alertReportParameters.getProcDate().toString() + "' ");
				if ((totInd.equals("Y")) && (alertReportParameters.getAllInfoIndicator().equals("Y"))) {
					sqlTblQry2.append("and (proc_date,alert_trend_time) = ( select distinct max(#thisProcDate#), alert_trend_time from");
					sqlTblQry2.append(thisTable);
					sqlTblQry2.append(" where parti_ref_id = ");
					sqlTblQry2.append(uniquePresnIDStruct.partiRefId);
					sqlTblQry2.append(" and ");
					sqlTblQry2.append(colFileSeqNum);
					sqlTblQry2.append(" is null and proc_date < to_date(' ");
					sqlTblQry2.append(alertReportParameters.getProcDate().toString());
					sqlTblQry2.append("','MM/DD/YYYY') ");
					if (keyWhere.length() != 0) {
						sqlTblQry2.append(keyWhere.toString());						
					}
					sqlTblQry2.append(" and alert_trend_time = ( select distinct alert_trend_time from ");
					sqlTblQry2.append(thisTable);
					sqlTblQry2.append(" where parti_ref_id = ");
					sqlTblQry2.append(uniquePresnIDStruct.partiRefId);
					sqlTblQry2.append(" and ");
					sqlTblQry2.append(colFileSeqNum);
					sqlTblQry2.append(" is null and proc_date = to_date(' ");
					sqlTblQry2.append(alertReportParameters.getProcDate().toString());
					sqlTblQry2.append("','MM/DD/YYYY') ");
					if (keyWhere.length() != 0) {
						sqlTblQry2.append(keyWhere.toString());						
					}
					sqlTblQry2.append(" ) group by alert_trend_time ) ");

					args.clear();
					args.add(thisTable);
					args.add(new Integer((uniquePresnIDStruct.partiRefId)).toString());
					args.add(alertReportParameters.getProcDate().toString());
					if (keyWhere.length() != 0) {
						args.add(keyWhere.toString());						
					} else {
						args.add(new String(""));
					}
					args.add(colFileSeqNum);
					recordCount = executeQryPrevDate(args);
				}
				if (rabcTable) {
					sqlTblQry.append(" and parti_ref_id = ");
					sqlTblQry.append(uniquePresnIDStruct.partiRefId);
					if ((totInd.equals("Y")) && (alertReportParameters.getAllInfoIndicator().equals("Y"))) {
						sqlTblQry2.append(" and parti_ref_id = ");
						sqlTblQry2.append(uniquePresnIDStruct.partiRefId);						
					}
					if ((thisTable.equals("RABC_EXTRCT_SUMY_DATA")) || (thisTable.equals("RABC_ALERT_HIST"))) {
						sqlTblQry.append(" and presn_cd in ('A', 'B') ");
						if ((totInd.equals("Y")) && (alertReportParameters.getAllInfoIndicator().equals("Y"))) {
							sqlTblQry2.append(" and presn_cd in ('A', 'B') ");
						}
					}
				}
				// <!--- If file sequence number present ==> handle criteria here --->
				if ((alertReportParameters.getFileSeqNum().intValue() > 0) || (totInd.equals("Y"))) {
					if (totInd.equals("Y")) {
						sqlTblQry.append(" and (");
						sqlTblQry.append(colFileSeqNum);
						sqlTblQry.append(" is null) ");
						if (alertReportParameters.getAllInfoIndicator().equals("Y")) {
							sqlTblQry2.append(" and (");
							sqlTblQry2.append(colFileSeqNum);
							sqlTblQry2.append(" is null) ");							
						}						
					} else {
						if (alertReportParameters.getFileSeqNum().intValue() > 0) {
							sqlTblQry.append(" and ");
							sqlTblQry.append(colFileSeqNum);
							sqlTblQry.append(" = ");
							sqlTblQry.append(alertReportParameters.getFileSeqNum().toString() + " ");
						}
					}
				}
				if (keyWhere.length() != 0) {
					sqlTblQry.append(keyWhere.toString());						
				}
				if ((keyWhere.length() != 0) && (totInd.equals("Y")) && (alertReportParameters.getAllInfoIndicator().equals("Y"))) {
					sqlTblQry2.append(keyWhere.toString());
				}

				sqlTblQry.append(sqlGroupBy.toString());
				presnIdQueries.add(sqlTblQry.toString());
				if ((recordCount > 0) && (totInd.equals("Y")) && (alertReportParameters.getAllInfoIndicator().equals("Y"))) {
					presnIdQueries.add(sqlTblQry2.toString());					
				}
			} // end of unique presn id loop
		} // end of unique table loop
	}

	/**
	 * This method executes the query for previous date.
	 * 
	 * @param args
	 * @return int
	 */
	private int executeQryPrevDate(List args) {
		Statement stmt = null;
		ResultSet rs = null;
		String qryPrevDateSQLStmt = null;
		try {
			MessageFormat mf = new MessageFormat(qryPrevDateSQL);
			qryPrevDateSQLStmt = mf.format((String[])args.toArray());
			logger.debug("qryPrevDateSQLStmt statement = " + qryPrevDateSQLStmt);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qryPrevDateSQLStmt);
			if (rs == null) {
				return 0;
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryPrevDateSQLStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryPrevDateSQLStmt}), sx));
			return 0;
		} finally{
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
		
		return 1;
	}

	/**
	 * This method is used to get the AlertRuleInfoStruct for the passed list and presnid.
	 * 
	 * @param alertRuleInfoList
	 * @param presnId
	 * @return AlertRuleInfoStruct
	 */
	private AlertRuleInfoStruct getAlertRuleInfo(List alertRuleInfoList, int presnId) {
		int i = 0;
		int size = alertRuleInfoList.size();
		AlertRuleInfoStruct alertRuleInfoStruct = null;
		
		for(i = 0; i < size; i++) {
			alertRuleInfoStruct = (AlertRuleInfoStruct) alertRuleInfoList.get(i);
			if (alertRuleInfoStruct.presnId == presnId) return alertRuleInfoStruct; 
		}
		return null;
	}

	/**
	 * Private method executes qryGetAlertRuleSQLStmt query 
	 * to get the alert rule info for the alertRuleInfoList and uniquePresnIds.
	 * 
	 * @param alertRuleInfoList
	 * @param uniquePresnIds
	 */
	private void getAlertRuleInfo(List alertRuleInfoList, List uniquePresnIds) {
		int i;
		int sizeOfUniquePresnId = uniquePresnIds.size();
		UniquePresnIDStruct uniquePresnIDStruct = null;;
		Statement stmt = null;
		ResultSet rs = null;
		String presnIdInString = "";
		
		for(i = 0; i < sizeOfUniquePresnId - 1; i++) {
			uniquePresnIDStruct = (UniquePresnIDStruct) uniquePresnIds.get(i);
			presnIdInString = presnIdInString + "'" + uniquePresnIDStruct.presnId + "',"; 
		}
		uniquePresnIDStruct = (UniquePresnIDStruct) uniquePresnIds.get(sizeOfUniquePresnId - 1);
		presnIdInString = presnIdInString + "'" + uniquePresnIDStruct.presnId + "'";
		
		MessageFormat mf= new MessageFormat(qryGetAlertRuleSQL);
		String qryGetAlertRuleSQLStmt = mf.format(new String[] {presnIdInString, alertReportParameters.getWebPageId()});
		try {															
			logger.debug("Executing qryGetAlertRuleSQLStmt query .... " + qryGetAlertRuleSQLStmt);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qryGetAlertRuleSQLStmt);
			if (rs != null) {
				while (rs.next()) {
					alertRuleInfoList.add((AlertRuleInfoStruct)buildAlertRuleInfoStruct(rs));
				}
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryGetAlertRuleSQLStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryGetAlertRuleSQLStmt}), sx));
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
	}

	/**
	 * Private method is used to return AlertRuleInfoStruct.
	 * 
	 * @param rs
	 * @return AlertRuleInfoStruct
	 * @throws SQLException
	 */
	private AlertRuleInfoStruct buildAlertRuleInfoStruct(ResultSet rs) throws SQLException {
		AlertRuleInfoStruct alertRuleInfoStruct = new AlertRuleInfoStruct();
		alertRuleInfoStruct.presnId = rs.getInt("PRESN_ID");
		alertRuleInfoStruct.partiRefId = rs.getInt("PARTI_REF_ID");
		alertRuleInfoStruct.totInd = rs.getString("TOT_IND");
		alertRuleInfoStruct.alertTimeInd = rs.getString("ALERT_TIME_IND");
		
		return alertRuleInfoStruct; 
	}

	/**
	 * Private method is used to get UniquePresnIds for the passed list and table.
	 * 
	 * @param uniquePresnIds
	 * @param thisTable
	 */
	private void getUniquePresnIds(List uniquePresnIds, String thisTable) {
		QryAlertRulePresnElem qryAlertRulePresnElem = null;
		
		int i = 0;
		int j = 0;
		int size = qryAlertRulePresnElemList.size();
		UniquePresnIDStruct uniquePresnIDStructNew = null;
		UniquePresnIDStruct uniquePresnIDStructCurrent = null;
		int sizeOfUniquePresnIds;
		boolean found = false;
		
		for(i = 0; i < size; i++) {
			qryAlertRulePresnElem = (QryAlertRulePresnElem) qryAlertRulePresnElemList.get(i);
			if (thisTable.equals(qryAlertRulePresnElem.getDataTbl())) {
				uniquePresnIDStructNew = new UniquePresnIDStruct();
				uniquePresnIDStructNew.presnId = qryAlertRulePresnElem.getPresnId();
				uniquePresnIDStructNew.partiRefId = qryAlertRulePresnElem.getPartiRefId();
				
				sizeOfUniquePresnIds = uniquePresnIds.size();
				found = false;
				for(j = 0; j < sizeOfUniquePresnIds; j++) {
					uniquePresnIDStructCurrent = (UniquePresnIDStruct) uniquePresnIds.get(j);
					if (uniquePresnIDStructCurrent.equals(uniquePresnIDStructNew)) {
						found = true;
					}
				}
				if (!found) {
					// not found hence add
					uniquePresnIds.add(uniquePresnIDStructNew);
				}
			}
		}
	}

	/**
	 * Private method is used to get TblCols for the passed tblColList, thisTable and presnId.
	 * 
	 * @param tblColList
	 * @param thisTable
	 * @param presnId
	 */
	private void getTblCols(List tblColList, String thisTable, int presnId) {
		QryAlertRulePresnElem qryAlertRulePresnElem = null;
		
		int i = 0;
		int j = 0;
		int size = qryAlertRulePresnElemList.size();
		TblColStruct tblColStructNew = null;
		TblColStruct tblColStructCurrent = null;
		int sizeOfTblCol;
		boolean found = false;
		
		for(i = 0; i < size; i++) {
			qryAlertRulePresnElem = (QryAlertRulePresnElem) qryAlertRulePresnElemList.get(i);
			if ((thisTable.equals(qryAlertRulePresnElem.getDataTbl())) && (qryAlertRulePresnElem.getPresnId() == presnId)) {
				tblColStructNew = new TblColStruct();
				tblColStructNew.dataTbl = qryAlertRulePresnElem.getDataTbl();
				tblColStructNew.dataDdlName  = qryAlertRulePresnElem.getDataDdlName();
				tblColStructNew.presnName = qryAlertRulePresnElem.getPresnName();

				for(j = 0; j < 5; j++)
					tblColStructNew.keyHeader[j] = qryAlertRulePresnElem.getKeyHeaderAt(j);
				for(j = 0; j < 5; j++)
					tblColStructNew.keyDdlName[j] = qryAlertRulePresnElem.getKeyDdlNameAt(j);

				tblColStructNew.presnUnitInd = qryAlertRulePresnElem.getPresnUnitInd();
				tblColStructNew.presnSumInd = qryAlertRulePresnElem.getPresnSumInd();
				tblColStructNew.presnSeqNum = qryAlertRulePresnElem.getPresnSeqNum();

				sizeOfTblCol = tblColList.size();
				found = false;
				for(j = 0; j < sizeOfTblCol; j++) {
					tblColStructCurrent = (TblColStruct) tblColList.get(j);
					if (tblColStructCurrent.equals(tblColStructNew)) {
						found = true;
					}
				}
				if (!found) {
					// not found hence add at correct position
					addAtCorrectPosition(tblColList, tblColStructNew);
				}
			}
		}
	}
	
	/**
	 * This method is used to add the seq num at correct position.  
	 * 
	 * @param tblColList
	 * @param tblColStructNew
	 */
	private void addAtCorrectPosition(List tblColList, TblColStruct tblColStructNew) {
		int i = 0;
		int option = 0;
		int size = tblColList.size();
		TblColStruct tblColStruct = null; 
		List currentColumnList = new ArrayList();
		List newColumnList = new ArrayList();

		// data_tbl
		newColumnList.add(tblColStructNew.dataTbl);
		// presn_seq_num
		newColumnList.add(new Integer(tblColStructNew.presnSeqNum));
		for(i=0; i < size; i++) {
			tblColStruct = (TblColStruct) tblColList.get(i);

			currentColumnList.clear();
			// data_tbl
			currentColumnList.add(tblColStruct.dataTbl);
			// presn_seq_num
			currentColumnList.add(new Integer(tblColStruct.presnSeqNum));

			option = decideForAsc(newColumnList, currentColumnList);
			if (option == INSERT) {
				tblColList.add(i, tblColStructNew);
				return;
			}
		}
		tblColList.add(tblColStructNew);
		return;
	}

	/**
	 * This method executes qryDynamicSqlStmt query.
	 */
	public void executeQryGetData() {
		MessageFormat mf = null;
		Statement stmt = null;
		ResultSet rs = null;
		String qryDynamicSqlStmt = null;
		int i = 0;
		int size = presnIdQueries.size();
		int nbrOfKeys = alertReportParameters.getNbrOfKeys();
		String colName;
		StringBuffer qryGetDataSQL = new StringBuffer();
		for (i = 0; i < size - 1; i++) {
			qryGetDataSQL.append((String)presnIdQueries.get(i));
			qryGetDataSQL.append(" UNION ALL ");
		}
		qryGetDataSQL.append((String)presnIdQueries.get(size - 1));
		qryGetDataSQL.append(" ORDER BY ");
		for (i = 0; i < nbrOfKeys - 1; i++) {
			colName = (String)columns.get(i);
			qryGetDataSQL.append(colName.replace(' ','_'));
			qryGetDataSQL.append(",");
		}
		colName = (String)columns.get(nbrOfKeys - 1);
		qryGetDataSQL.append(colName.replace(' ','_'));
		qryGetDataSQL.append(", Sequence_Number");
		qryGetDataSQL.append(", File_Process_Date desc");
		if (alertItemFound()) {
			qryGetDataSQL.append(", Alert_Item desc");
		}
		
		setPages(qryGetDataSQL.toString());
		
		String [] args = new String[2];
		args[0] = qryGetDataSQL.toString();
		int pageSize = alertReportParameters.getPageSize();
		int page = alertReportParameters.getPage();
		int startIndex = ((page - 1) * pageSize) + 1;
		int endIndex = ((page - 1) * pageSize) + pageSize;
		if (alertReportParameters.getDispatch() == null) {
			args[1] = " where rn between " + startIndex + " and " + endIndex;
    	} else {
	    	if ("createReport".equals(alertReportParameters.getDispatch()) || "emailReport".equals(alertReportParameters.getDispatch())) {
	    		args[1] = " ";
			} else {
				args[1] = " where rn between " + startIndex + " and " + endIndex;
			}
    	}
		alertReportParameters.setPageshow(page);
		
		try {															
			mf = new MessageFormat(qryDynamicSql);
			qryDynamicSqlStmt = mf.format(args);
			logger.debug("Executing qryDynamicSqlStmt query .... " + qryDynamicSqlStmt);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qryDynamicSqlStmt);
			if (rs != null) {
				ResultSetMetaData rsmd = rs.getMetaData();
				i = 0;
				size = rsmd.getColumnCount();
				columnTypeInfo = new ArrayList();
				ColumnTypeInfoStruct columnTypeInfoStruct = null;
				for(i = 1; i <= size; i++) {
					columnTypeInfoStruct = new ColumnTypeInfoStruct();
					columnTypeInfoStruct.columnName = rsmd.getColumnName(i);
					columnTypeInfoStruct.columnJavaType = rsmd.getColumnClassName(i);
					columnTypeInfo.add(columnTypeInfoStruct);
				}
				QryGetData qryGetData = null;
				
				while (rs.next()) {
					qryGetData = (QryGetData)buildQryGetData(rs);
					qryGetDataList.add(qryGetData);
					alertReportParameters.addPresnId(new Integer(qryGetData.getPresnId()));
				}
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryDynamicSqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryDynamicSqlStmt}), sx));
		} catch (ParseException e) {
			logger.error("Error in parsing the date. Exception details: " + e.getMessage(), e);
			failures.add(new RABCException("Error in parsing the date. Exception details: " + e.getMessage(), e));
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}		
	}

	/**
	 * This method sets the pages for the passed dynamic query.
	 * 
	 * @param dynamicQuery
	 */
	private void setPages(String dynamicQuery) {
		Statement stmt = null;
		ResultSet rs = null;
		MessageFormat mf = null;
		String [] args = {dynamicQuery};
		String qryDynamicSqlCountStmt = null;
		int pageSize = alertReportParameters.getPageSize();
		int totalRows =0;
		
		try {
			mf = new MessageFormat(qryDynamicSqlCount);
			qryDynamicSqlCountStmt = mf.format(args);
			logger.debug("qryDynamicSqlCount =" + qryDynamicSqlCountStmt);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qryDynamicSqlCountStmt);
			if (rs != null && rs.next()) {
				totalRows = rs.getInt(1);
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryDynamicSqlCountStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {qryDynamicSqlCountStmt}), sx));
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
		
		int pages = totalRows / pageSize;
		if ((totalRows % pageSize) != 0) {
			pages++;
		}
		if ((totalRows <= pageSize) || (pageSize == 0)) {
			alertReportParameters.setPages(0); // don't show page related buttons
		}
		alertReportParameters.setPages(pages);
	}

	/**
	 * This method returns boolean for alertItemFound.
	 * 
	 * @return boolean
	 */
	private boolean alertItemFound() {
		int i = 0;
		int size = columns.size();
		String colName = null;
		for(i = 0; i< size; i++) {
			colName = (String) columns.get(i);
			if (colName.equals(getLabel("alertData.label.alertItem"))) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Private method executes the query to extract value for each column.
	 * 
	 * @param rs
	 * @return QryGetData
	 * @throws SQLException
	 * @throws ParseException
	 */
	private QryGetData buildQryGetData(ResultSet rs) throws SQLException, ParseException {
		QryGetData qryGetData = new QryGetData();
		qryGetData.setFileProcessDate(new MyDate(rs.getString("FILE_PROCESS_DATE")));
		qryGetData.setPresnId(rs.getInt("PRESN_ID"));
		qryGetData.setThisTable(rs.getString("THISTABLE"));
		qryGetData.setThisPartiRefId(rs.getInt("THISPARTIREFID"));
		qryGetData.setThisProcDate(rs.getString("THISPROCDATE"));
		qryGetData.setSequenceNumber(rs.getInt("SEQUENCE_NUMBER"));
		qryGetData.setThisPrevTotInd(rs.getString("THISPREVTOTIND"));
		qryGetData.setThisTotInd(rs.getString("THISTOTIND"));
		qryGetData.setThisAlertTimeInd(rs.getString("THISALERTTIMEIND"));
		int i = 0;
		int size = columnNames1.size();
		List qryGetDataColumnValues = qryGetData.getColumnValues();
		List qryGetDataColumnNames = qryGetData.getColumnNames();
		ColumnTypeInfoStruct columnTypeInfoStruct = null;
		String colName = null;
		String colName1 = null;
		logger.debug("Extract value for each column");
		for(i = 0; i < size; i++) {
			colName = (String) columnNames.get(i);
			colName1 = (String) columnNames1.get(i);
			columnTypeInfoStruct = getColumTypeInfoStruct(colName1);
			if (columnTypeInfoStruct.columnJavaType.equals("java.lang.String")) {
				qryGetDataColumnValues.add(rs.getString(colName1));
			}
			if (columnTypeInfoStruct.columnJavaType.equals("int")) {
				qryGetDataColumnValues.add(new Integer(rs.getInt(colName1)));
			}
			if (columnTypeInfoStruct.columnJavaType.equals("java.lang.Date")) {
				qryGetDataColumnValues.add(rs.getDate(colName1));
			}
			if (columnTypeInfoStruct.columnJavaType.equals("java.lang.Double")) {
				qryGetDataColumnValues.add(new Double(rs.getDouble(colName1)));
			}
			if (columnTypeInfoStruct.columnJavaType.equals("java.lang.Long")) {
				qryGetDataColumnValues.add(new Long(rs.getLong(colName1)));
			}
			qryGetDataColumnNames.add(colName);
		}
		
		return qryGetData;
	}

	/**
	 * This method is used to get ColumnTypeInfoStruct to return ColumnTypeInfoStruct.
	 * 
	 * @param colName
	 * @return ColumnTypeInfoStruct
	 */
	private ColumnTypeInfoStruct getColumTypeInfoStruct(String colName) {
		int i = 0;
		int size = columnTypeInfo.size();
		ColumnTypeInfoStruct columnTypeInfoStruct = null;
		for(i = 0; i < size; i++) {
			columnTypeInfoStruct = (ColumnTypeInfoStruct) columnTypeInfo.get(i);
			if (columnTypeInfoStruct.columnName.equals(colName.toUpperCase())) return columnTypeInfoStruct; 
		}
		logger.warn("Column Java Type Info not found...Needs Verification");
		return null;
	}

	/**
	 * This method handles QryKeyColStruct.
	 */
	protected class QryKeyColStruct {
		int presnId;
		String[] keyHeader = {"","","","",""};
		String[] keyDdlName = {"","","","",""};
		int dataKeyLvl;
		int execPresnSeqNum;
		int presnSeqNum;
		
		/**
		 * This method returns boolean value depend upon qryKeyColStructInput.
		 * 
		 * @param qryKeyColStructInput
		 * @return boolean
		 */
		public boolean equals(QryKeyColStruct qryKeyColStructInput) {
			int i = 0;
			if (this.presnId != qryKeyColStructInput.presnId) return false;
			for (i = 0; i < 5; i++) {
				if (this.keyHeader[i]!=null && !this.keyHeader[i].equals(qryKeyColStructInput.keyHeader[i])) return false;
				if (this.keyDdlName[i]!=null && !this.keyDdlName[i].equals(qryKeyColStructInput.keyDdlName[i])) return false;				
			}
			if (this.dataKeyLvl != qryKeyColStructInput.dataKeyLvl) return false;
			if (this.execPresnSeqNum != qryKeyColStructInput.execPresnSeqNum) return false;
			if (this.presnSeqNum != qryKeyColStructInput.presnSeqNum) return false;
			return true;
		}
	}

	/**
	 * This method handles TblColStruct.
	 */
	private class TblColStruct {
		String dataTbl;
		String dataDdlName;
		String presnName;
		String[] keyHeader = {"","","","",""};
		String[] keyDdlName = {"","","","",""};
		String presnUnitInd;
		String presnSumInd;	
		int presnSeqNum;
		
		/**
		 * This method returns boolean value depend upon tblColStructInput.
		 * 
		 * @param tblColStructInput
		 * @return boolean
		 */
		public boolean equals(TblColStruct tblColStructInput) {
			int i = 0;
			if (!this.dataTbl.equals(tblColStructInput.dataTbl)) return false;
			for (i = 0; i < 5; i++) {
				if (this.keyHeader[i]!=null && !this.keyHeader[i].equals(tblColStructInput.keyHeader[i])) return false;
				if (this.keyDdlName[i]!=null && !this.keyDdlName[i].equals(tblColStructInput.keyDdlName[i])) return false;
			}
			if (!this.dataDdlName.equals(tblColStructInput.dataDdlName)) return false;
			if (!this.presnName.equals(tblColStructInput.presnName)) return false;
			if (!this.presnUnitInd.equals(tblColStructInput.presnUnitInd)) return false;
			if (!this.presnSumInd.equals(tblColStructInput.presnSumInd)) return false;
			if (this.presnSeqNum != tblColStructInput.presnSeqNum) return false;
			return true;
		}
	}

	/**
	 * This method handles UniquePresnIDStruct.
	 */
	private class UniquePresnIDStruct {
		int presnId;
		int partiRefId;
		
		/**
		 * This method returns boolean value depend upon uniquePresnIDStructInput.
		 * 
		 * @param uniquePresnIDStructInput
		 * @return boolean
		 */
		public boolean equals(UniquePresnIDStruct uniquePresnIDStructInput) {
			int i = 0;
			if (this.presnId != uniquePresnIDStructInput.presnId) return false;
			if (this.partiRefId != uniquePresnIDStructInput.partiRefId) return false;
			return true;
		}
	}

	/**
	 * This method handles AlertRuleInfoStruct.
	 */
	private class AlertRuleInfoStruct {
		int presnId;
		int partiRefId;
		String alertTimeInd;
		String totInd;
	}
	
	/**
	 * This method handles ColumnTypeInfoStruct.
	 */
	private class ColumnTypeInfoStruct {
		String columnName;
		String columnJavaType;
	}

	/**
	 * Method to return the default division.
	 * 
	 * @param connection
	 * @param failures
	 * @param userId
	 * @return String
	 */
	protected String getDefaultDivision(Connection connection, List failures, String userId) {
		String defaultDivision = null;
		String selectSQL = getDefaultDivision;
		List args = new ArrayList();
		args.add(userId);
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		try{
			MessageFormat mf = new MessageFormat(selectSQL);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			if (rs != null && rs.next()) {
				defaultDivision = rs.getString(1);
			} else {
				defaultDivision = "";
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
		return defaultDivision;
	}
	
	/**
	 * Method to return the default line count.
	 * 
	 * @param connection
	 * @param failureList
	 * @param userId
	 * @return int
	 */
	protected int getDefaultLineCount(Connection connection, List failureList, String userId) {
		int defaultLineCount = 0;
		String selectSQL = getDefaultLineCount;
		List args = new ArrayList();
		args.add(userId);
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		try{
			MessageFormat mf = new MessageFormat(selectSQL);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			if (rs != null && rs.next()) {
				defaultLineCount = rs.getInt(1);
			} else {
				defaultLineCount = RABCConstantsLists.getRABCConstantsLists().getPageSize();
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
		return defaultLineCount;
	}
}
