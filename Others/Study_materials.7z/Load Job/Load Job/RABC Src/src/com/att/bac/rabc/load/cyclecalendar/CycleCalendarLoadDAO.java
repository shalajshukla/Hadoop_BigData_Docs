package com.att.bac.rabc.load.cyclecalendar;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;
import com.att.bac.util.JDBCUtil;

/**
 * This is a Data Access Object(DAO) class which interact with database and
 * insert records for different regions of RABC in RABC_CYCLE_CALENDAR table.
 * 
 * @author kb629p
 */
public class CycleCalendarLoadDAO {

	private Logger logger = Logger.getLogger(CycleCalendarLoadDAO.class);

	/**
	 * Insert West Region File data in RABC_CYCLE_CALENDAR table.
	 * 
	 * To Avoid duplication of records, firstly data is deleted from table according to PROC_DT column and then whole file is inserted.
	 * 
	 * @return DB insert status
	 * */
	public boolean recordInsertionWest(Connection connection,
			List<CycleCalendarData> recordList) {
		boolean success = true;
		String insertQuery = null;
		String deleteQuery = null;
		CycleCalendarData cycleCalData = null;
		PreparedStatement delPrepStmt = null;
		PreparedStatement insPrepStmt = null;

		try {
			deleteQuery= "delete from RABC_CYCLE_CALENDAR WHERE PROC_DT >= to_date(?,'mm/dd/yyyy')";
			insertQuery = "insert into RABC_CYCLE_CALENDAR(CYCLE, BILL_RND, PROC_DT, BILL_RND_DT) values(to_number(?),to_number(?),to_date(?,'mm/dd/yyyy'),to_date(?,'mm/dd/yyyy'))";
			delPrepStmt = connection.prepareStatement(deleteQuery);
			insPrepStmt = connection.prepareStatement(insertQuery);
			
			CycleCalendarData cycleCalendarData = recordList.get(0); 
			String firstDate = cycleCalendarData.getProcDate();
			delPrepStmt.setString(1, firstDate);
			delPrepStmt.executeUpdate();

			for (int i = 0; i < recordList.size(); i++) {
				cycleCalData = recordList.get(i);
				insPrepStmt.setString(1, cycleCalData.getCycle());
				insPrepStmt.setString(2, cycleCalData.getBillRnd());
				insPrepStmt.setString(3, cycleCalData.getProcDate());
				insPrepStmt.setString(4, cycleCalData.getBillRndDate());
				insPrepStmt.addBatch();
				if(i%1000 == 0) 
					insPrepStmt.executeBatch();
			}
			insPrepStmt.executeBatch();
		} catch (SQLException sqlErr) {
			logger.error("Error while insertion of West CYCLE CALENDAR Records:" + sqlErr);
			success = false;
		} finally {
			JDBCUtil.closeStatement(delPrepStmt);
			JDBCUtil.closeStatement(insPrepStmt);
		}
		return success;
	}

	/**
	 * Insert SouthWest Region File data in RABC_CYCLE_CALENDAR table.
	 * 
	 * To Avoid duplication of records, firstly data is deleted from table according to PROC_DT column and then whole file data is inserted.
	 * 
	 * @return DB insert status
	 * */
	public boolean recordInsertionSouthWest(Connection connection,
			List<CycleCalendarData> recordList) {
		boolean success = true;
		String insertQuery = null;
		String deleteQuery = null;
		CycleCalendarData cycleCalData = null;
		PreparedStatement delPrepStmt = null;
		PreparedStatement insPrepStmt = null;

		try {
			deleteQuery= "delete from RABC_CYCLE_CALENDAR WHERE PROC_DT >= to_date(?,'mm/dd/yyyy')";
			insertQuery = "insert into RABC_CYCLE_CALENDAR(BILL_RND, PROC_DT, BILL_RND_DT) values(to_number(?),to_date(?,'mm/dd/yyyy'),to_date(?,'mm/dd/yyyy'))";
			delPrepStmt = connection.prepareStatement(deleteQuery);
			insPrepStmt = connection.prepareStatement(insertQuery);
			
			CycleCalendarData cycleCalendarData = recordList.get(0); 
			String firstDate = cycleCalendarData.getProcDate();
			delPrepStmt.setString(1, firstDate);
			delPrepStmt.executeUpdate();

			for (int i = 0; i < recordList.size(); i++) {
				cycleCalData = recordList.get(i);
				insPrepStmt.setString(1, cycleCalData.getBillRnd());
				insPrepStmt.setString(2, cycleCalData.getProcDate());
				insPrepStmt.setString(3, cycleCalData.getBillRndDate());
				insPrepStmt.addBatch();
				if(i%1000 == 0) 
					insPrepStmt.executeBatch();
			}
			insPrepStmt.executeBatch();
		} catch (SQLException sqlErr) {
			logger.error("Error while insertion of SouthWest CYCLE CALENDAR Records:" + sqlErr);
			success = false;
		} finally {
			JDBCUtil.closeStatement(delPrepStmt);
			JDBCUtil.closeStatement(insPrepStmt);
		}
		return success;
	}

	/**
	 * Insert MidWest Region File data in RABC_CYCLE_CALENDAR table.
	 * 
	 * To Avoid duplication of records, firstly data is deleted from table according to PROC_DT column and then whole file data is inserted.
	 * 
	 * @return DB insert status
	 * */
	public boolean recordInsertionMidWest(Connection connection,
			List<CycleCalendarData> recordList) {
		boolean success = true;
		String deleteQuery = null;
		String insertQuery = null;
		CycleCalendarData cycleCalData = null;
		PreparedStatement delPrepStmt = null;
		PreparedStatement insPrepStmt = null;

		try {
			deleteQuery= "delete from RABC_CYCLE_CALENDAR WHERE PROC_DT >= to_date(?,'mm/dd/yyyy')";
			insertQuery = "insert into RABC_CYCLE_CALENDAR(BILL_RND, PROC_DT, BILL_RND_DT, PROC_DT_IND) values(to_number(?),to_date(?,'mm/dd/yyyy'),to_date(?,'mm/dd/yyyy'),?)";
			delPrepStmt = connection.prepareStatement(deleteQuery);
			insPrepStmt = connection.prepareStatement(insertQuery);
			
			CycleCalendarData cycleCalendarData = recordList.get(0); 
			String firstDate = cycleCalendarData.getProcDate();
			delPrepStmt.setString(1, firstDate);
			delPrepStmt.executeUpdate();

			for (int i = 0; i < recordList.size(); i++) {
				cycleCalData = recordList.get(i);
				insPrepStmt.setString(1, cycleCalData.getBillRnd());
				insPrepStmt.setString(2, cycleCalData.getProcDate());
				insPrepStmt.setString(3, cycleCalData.getBillRndDate());
				insPrepStmt.setString(4, cycleCalData.getProcDateIndicator());
				insPrepStmt.addBatch();
				if(i%1000 == 0) 
					insPrepStmt.executeBatch();
			}
			insPrepStmt.executeBatch();
		} catch (SQLException sqlErr) {
			logger.error("Error while insertion of MidWest CYCLE CALENDAR Records:" + sqlErr);
			success = false;
		} finally {
			JDBCUtil.closeStatement(delPrepStmt);
			JDBCUtil.closeStatement(insPrepStmt);
		}
		return success;
	}

	/**
	 * Insert SouthEast Region File data in RABC_CYCLE_CALENDAR table.
	 * 
	 * To Avoid duplication of records, firstly data is deleted from table according to PROC_DT column and then whole file data is inserted.
	 * 
	 * @return DB insert status
	 * */
	public boolean recordInsertionSouthEast(Connection connection,
			List<CycleCalendarData> recordList) {
		boolean success = true;
		String deleteQuery;
		String insertQuery = null;
		CycleCalendarData cycleCalData = null;
		PreparedStatement delPrepStmt = null;
		PreparedStatement insPrepStmt = null;

		try {
			deleteQuery= "delete from RABC_CYCLE_CALENDAR WHERE PROC_DT >= to_date(?,'mm/dd/yyyy')";
			insertQuery = "insert into RABC_CYCLE_CALENDAR(BILL_RND, PROC_DT, BILL_RND_DT) values(to_number(?),to_date(?,'mm/dd/yyyy'),to_date(?,'mm/dd/yyyy'))";
			delPrepStmt = connection.prepareStatement(deleteQuery);
			insPrepStmt = connection.prepareStatement(insertQuery);
			
			CycleCalendarData cycleCalendarData = recordList.get(0); 
			String firstDate = cycleCalendarData.getProcDate();
			delPrepStmt.setString(1, firstDate);
			delPrepStmt.executeUpdate();

			for (int i = 0; i < recordList.size(); i++) {
				cycleCalData = recordList.get(i);
				insPrepStmt.setString(1, cycleCalData.getBillRnd());
				insPrepStmt.setString(2, cycleCalData.getProcDate());
				insPrepStmt.setString(3, cycleCalData.getBillRndDate());
				insPrepStmt.addBatch();
				if(i%1000 == 0) 
					insPrepStmt.executeBatch();
			}
			insPrepStmt.executeBatch();
		} catch (SQLException sqlErr) {
			logger.error("Error while insertion of SouthEast CYCLE CALENDAR Records:" + sqlErr);
			success = false;
		} finally {
			JDBCUtil.closeStatement(delPrepStmt);
			JDBCUtil.closeStatement(insPrepStmt);
		}
		return success;
	}

}
