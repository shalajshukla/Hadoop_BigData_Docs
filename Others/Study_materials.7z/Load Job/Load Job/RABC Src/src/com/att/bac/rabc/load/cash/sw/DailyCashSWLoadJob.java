/* Created on Sep 24, 2006 by Daniel Baker (db8237). 
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.load.cash.sw;

import java.io.File;
import java.net.UnknownHostException;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import com.att.bac.rabc.util.EmcisEventLogger;
import com.att.bac.rabc.load.occ.sw.DailyOCCSWData;
import com.att.bac.util.NetUtil;
import com.att.carat.util.JDBCUtil;
import com.sbc.bac.rabc.load.FilePatternLoadJob;
import com.sbc.bac.rabc.load.PrepareTableForRerun;
import com.sbc.bac.rabc.load.RabcLoadJobTrig;
import com.sbc.bac.rabc.load.RetrieveStaticInfo;
import com.sbc.bac.rabc.load.StaticErrorMsgKeys;

/**
 * @author db8237
 * 
 * Subclass of FilePatternLoadJob, which will process a delimited file.
 */
public class DailyCashSWLoadJob extends FilePatternLoadJob {
	
//	 Array of tables accessed by this Load Job, used during backout for reruns
	private static final String[] tableNames = {"RABC_DAILY_ADJ_ACTVT", "RABC_DAILY_BAL_TRSFR_ACTVT",
		"RABC_DAILY_DEPOSIT_ACCT", "RABC_DAILY_DEPOSIT_ACTVT", "RABC_DAILY_PYMT_ACTVT", "RABC_DAILY_OCC_CASH_ACTVT"};
	
//	 Array of valid values for BUS_TYPE
	private static final String[] busTypes = {"RRES", "RES", "RBUS", "BUS"};
	
// SQL for accessing table RABC_DAILY_ADJ_ACTVT
	private static final StringBuffer insertAdjustmentSQL = new StringBuffer("INSERT INTO RABC_DAILY_ADJ_ACTVT " +
			"(RUN_DATE, DIVISION, BUS_TYPE, TRN_CD, ADJ_REASON_CD, ADJ_CLS_CD, ADJ_CT_DB, ADJ_AMT_DB, ADJ_CT_CR, ADJ_AMT_CR) " +
			"VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ");
	private static final StringBuffer updateDebitAdjustmentSQL = new StringBuffer("UPDATE RABC_DAILY_ADJ_ACTVT " +
			"SET ADJ_CT_DB = ADJ_CT_DB + ? , ADJ_AMT_DB = ADJ_AMT_DB + ? " + 
			"WHERE RUN_DATE = ? AND DIVISION = ? AND BUS_TYPE = ? AND TRN_CD = ? AND ADJ_REASON_CD = ? AND ADJ_CLS_CD = ?");
	private static final StringBuffer updateCreditAdjustmentSQL = new StringBuffer("UPDATE RABC_DAILY_ADJ_ACTVT " +
			"SET ADJ_CT_CR = ADJ_CT_CR + ? , ADJ_AMT_CR = ADJ_AMT_CR + ? " + 
			"WHERE RUN_DATE = ? AND DIVISION = ? AND BUS_TYPE = ? AND TRN_CD = ? AND ADJ_REASON_CD = ? AND ADJ_CLS_CD = ?");
// SQL for accessing table RABC_DAILY_BAL_TRSFR_ACTVT
	private static final StringBuffer insertBalanceTransferSQL = new StringBuffer("INSERT INTO RABC_DAILY_BAL_TRSFR_ACTVT " +
			"(RUN_DATE, DIVISION, BUS_TYPE, BTN, BAL_TRSFR_AMT_DB, BAL_TRSFR_AMT_CR) " +
			"VALUES(?, ?, ?, ?, ?, ?) ");
	private static final StringBuffer updateDebitBalanceTransferSQL = new StringBuffer("UPDATE RABC_DAILY_BAL_TRSFR_ACTVT " +
			"SET BAL_TRSFR_AMT_DB = BAL_TRSFR_AMT_DB + ? " + 
			"WHERE RUN_DATE = ? AND DIVISION = ? AND BUS_TYPE = ? AND BTN = ?");
	private static final StringBuffer updateCreditBalanceTransferSQL = new StringBuffer("UPDATE RABC_DAILY_BAL_TRSFR_ACTVT " +
			"SET BAL_TRSFR_AMT_CR = BAL_TRSFR_AMT_CR + ? " + 
			"WHERE RUN_DATE = ? AND DIVISION = ? AND BUS_TYPE = ? AND BTN = ?");
//	 SQL for accessing table RABC_DAILY_DEPOSIT_ACCT
	private static final StringBuffer insertDepositSQL = new StringBuffer("INSERT INTO RABC_DAILY_DEPOSIT_ACCT " +
			"(RUN_DATE, DIVISION, BUS_TYPE, BTN, BAL_DEP_AMT) " +
			"VALUES(?, ?, ?, ?, ?) ");
	private static final StringBuffer selectDepositSummarySQL = new StringBuffer("SELECT COUNT(*) FROM RABC_DAILY_DEPOSIT_ACCT " +
			"WHERE RUN_DATE = ? AND DIVISION = ? AND BUS_TYPE = ?");
//	 SQL for accessing table RABC_DAILY_DEPOSIT_ACTVT
	private static final StringBuffer insertDepositSummarySQL = new StringBuffer("INSERT INTO RABC_DAILY_DEPOSIT_ACTVT " +
			"(RUN_DATE, DIVISION, BUS_TYPE, EXCESS_DEP_CT) " +
			"VALUES(?, ?, ?, ?) ");
// SQL for accessing table RABC_DAILY_PYMT_ACTVT
	private static final StringBuffer insertPaymentSQL = new StringBuffer("INSERT INTO RABC_DAILY_PYMT_ACTVT " +
			"(RUN_DATE, DIVISION, BUS_TYPE, PYMT_TOT_CT, PYMT_TOT_AMT) " +
			"VALUES(?, ?, ?, ?, ?) ");
// SQL for accessing table RABC_DAILY_OCC_CASH_ACTVT
	private static final StringBuffer insertOCCSQL = new StringBuffer("INSERT INTO RABC_DAILY_OCC_CASH_ACTVT " +
			"(RUN_DATE, DIVISION, BUS_TYPE, OCC_CD, OCC_TYPE, ECBR_IND, OCC_CT_CR, OCC_AMT_CR, OCC_CT_DB, OCC_AMT_DB) " +
			"VALUES(?, ?, ?, ?, ?, ?, ?, ? , ?, ?) ");

//  PMT#M169 #M5 issue code change SQL for getting deposit amount from RABC_DEPOSIT_ACCT 
	private static final StringBuffer amountDepositedSQL= new StringBuffer( " SELECT BAL_DEP_AMT FROM RABC_DAILY_DEPOSIT_ACCT " +
			" WHERE RUN_DATE = ? AND DIVISION = ? AND BUS_TYPE = ?" );	

// Prepared Statements
	private PreparedStatement insertAdjustment;
	private PreparedStatement updateDebitAdjustment;
	private PreparedStatement updateCreditAdjustment;
	private PreparedStatement insertBalanceTransfer;
	private PreparedStatement updateDebitBalanceTransfer;
	private PreparedStatement updateCreditBalanceTransfer;
	private PreparedStatement insertDeposit;
	private PreparedStatement selectDepositSummary;
	private PreparedStatement insertDepositSummary;
	private PreparedStatement insertPayment;
	private PreparedStatement insertOCC;
	private PreparedStatement amountDeposited;	// added for #M5
	
// Common variables
	private ArrayList triggers = new ArrayList();
	private ArrayList adjustments = new ArrayList();
	private ArrayList balanceTransfers = new ArrayList();
	private File currentFile;
	private String division;
	private String runDate;
	private Date sqlRunDate;
	private boolean backupRecovery;
	private boolean trailerProcessed;
	private boolean firstRecord;
	private int lineCount;
	DateFormat yyyyDDD = new SimpleDateFormat("yyyyDDD");
	DateFormat MMddyyyy = new SimpleDateFormat("MMddyyyy");
	private ResultSet rs,rs1; //#M5
	
	private int actvtBatchCounter;
	private HashMap occActvtMap;
	boolean isCashOccActvt;
	boolean dep;
	
	private String fileName, fileToken, region;
    /**
     * Runs prior to processing. Sets up all necessary prepared statements.
     * 
     * @return false if an error is encountered during set up, otherwise true
     */
	public boolean preprocess() {
		super.preprocess();

		try {
			insertAdjustment = connection.prepareStatement(insertAdjustmentSQL.toString());
			updateDebitAdjustment = connection.prepareStatement(updateDebitAdjustmentSQL.toString());
			updateCreditAdjustment = connection.prepareStatement(updateCreditAdjustmentSQL.toString());
			insertBalanceTransfer = connection.prepareStatement(insertBalanceTransferSQL.toString());
			updateDebitBalanceTransfer = connection.prepareStatement(updateDebitBalanceTransferSQL.toString());
			updateCreditBalanceTransfer = connection.prepareStatement(updateCreditBalanceTransferSQL.toString());
			insertDeposit = connection.prepareStatement(insertDepositSQL.toString());
			selectDepositSummary = connection.prepareStatement(selectDepositSummarySQL.toString());
			amountDeposited = connection.prepareStatement(amountDepositedSQL.toString()); // PMT #M169 M5
			insertDepositSummary = connection.prepareStatement(insertDepositSummarySQL.toString());
			insertPayment = connection.prepareStatement(insertPaymentSQL.toString());
			insertOCC = connection.prepareStatement(insertOCCSQL.toString());
			
			
		} catch (SQLException e) {
			severe(StaticErrorMsgKeys.PREPROCESS_ERROR + e.getMessage(), e);
			return false;
		}
		return true;
	}
	
    /**
     * Runs prior to file processing. Initializes application variables.
     * 
     * @return false if an error is encountered during initialization, otherwise true
     */
	public boolean preprocessFile(File file) {
		boolean success = super.preprocessFile(file);
		fileToken = file.getName().substring(file.getName().indexOf("RA130F01"),file.getName().indexOf("RA130F01")+ 8);
		fileName = file.getName();
		region   =	file.getName().substring(0,2);
		
		if (success) {
			try {
				triggers = new ArrayList();
				adjustments = new ArrayList();
				balanceTransfers = new ArrayList();
				backupRecovery = false;
				trailerProcessed = false;
				firstRecord = true;
				lineCount = 0;

				if (RabcLoadJobTrig.IsOriginalFileLoaded(connection, file, file.getName().length())) {
					backupRecovery = true;
				}
			} catch (Exception e) {
				severe(StaticErrorMsgKeys.PREPROCESSFILE_ERROR + StaticErrorMsgKeys.FILE_NAME_PARSING_ERROR + e, e);
				return false;
			}
		}
		currentFile = file;
		occActvtMap = new HashMap();
		isCashOccActvt = false;
		actvtBatchCounter = 0;
		dep = false;
		return success;
	}

    /**
     * Parses the most recently read line of the input file, determines what type of record it is, and passes it
     * to the appropriate routine for processing.
     * 
     * @param line
     *   The most recently read line of the input file.
     * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob
     * @throws Exception
     *   if any unhandled Exception is encountered, if the TRAILER record is not the last record on the processing file,
     *   if the HEADER record is not he first record on the processing file, and also if the DATE record does not
     *   immediately follow the HEADER record.
     */
	protected int parseLine(String line) throws Exception {
		String[] fields = line.split("[ ]*;[ ]*");
		
		if (trailerProcessed) {									// trailer must be last record on file
			throw new Exception("TRAILER was not the last record on currently processing file: " + currentFile.getName());
		}
		
		if (firstRecord) {										// header must be first record on file
			firstRecord = false;
			if ("HEADER".equalsIgnoreCase(fields[0])) {
				division = fields[2];
				return SUCCESS;
			} else {
				throw new Exception("HEADER was not the first record on currently processing file: " + currentFile.getName());
			}
		}
		
		if ("TRAILER".equalsIgnoreCase(fields[0])) {
			trailerProcessed = true;
			return processTrailerRecord(fields);
		}
		
		lineCount++;											// only header and trailer are uncounted
		
		if (lineCount == 1) {									// date record must be second record on file
			if ("RA13DATE".equalsIgnoreCase(fields[0])) {
				return processDateRecord(fields);
			} else {
				throw new Exception("DATE record did not immediately follow the HEADER on currently processing file: " + currentFile.getName());
			}
		}
		
		if ("RA13ADJM".equalsIgnoreCase(fields[0])) {
			if (!triggers.contains("SWCASHAD")) {
				triggers.add("SWCASHAD");
			}
			return processAdjustmentRecord(fields);
		}
		
		if ("RA13BALT".equalsIgnoreCase(fields[0])) {
			if (!triggers.contains("SWCASHTR")) {
				triggers.add("SWCASHTR");
			}
			return processBalanceTransferRecord(fields);
		}
		
		if ("RA13DEPO".equalsIgnoreCase(fields[0])) {
			if (fields[1].equals("01")) {
				if (!triggers.contains("SWCASHDP")) {
					triggers.add("SWCASHDP");
				}
				return insertDepositRecord(fields);
			} else {
				return SUCCESS;
			}
		}
		
		if ("RA13PYMT".equalsIgnoreCase(fields[0])) {
			if (!triggers.contains("SWCASHPT")) {
				triggers.add("SWCASHPT");
			}
			return insertPaymentRecord(fields);
		}
		
		if ("RA13OCCS".equalsIgnoreCase(fields[0])) {
			if (checkOccRecordFormat(fields)){
				return insertOCCRecord(fields);
			}else {
				return SKIPPED;
			}
		}

		warning(StaticErrorMsgKeys.INVAID_RECORD_TYPE + fields[0] + fields[1]);
		return ERROR;
	}
	
    /**
     * Processes the most recently read line of the input file, once it has been identified as a Date record.
     * 
     * @param fields
     *   an Array of the fields in the most recently read line of the input file.
     * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob
     */
	private int processDateRecord(String[] fields) {
		try {
			sqlRunDate = new Date(yyyyDDD.parse(fields[2]).getTime());
			runDate = MMddyyyy.format(sqlRunDate);
			
		} catch (ParseException e) {
			severe(StaticErrorMsgKeys.PARSELINE_ERROR + "Error occurred while parsing Date on file: " + e, e);
			return ERROR;
		}
		
		if (backupRecovery) {
			for (int i = 0; i < tableNames.length; i++) {
				if (!PrepareTableForRerun.deleteTableData(connection, tableNames[i], division, sqlRunDate)) {
					severe("Error occurred attempting to backup and recover for rerun for table: " + tableNames[i]);
					return ERROR;
				}
			}
		}
		
		return SUCCESS;
	}
	
    /**
     * Processes the most recently read line of the input file, once it has been identified as a Trailer record.
     * Validates that the number of records processed is equal to the record count on the Trailer record.
     * Header and trailer records are the only records not included in the line count.
     *  
     * @param fields
     *   an Array of the fields in the most recently read line of the input file.
     * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob
     * @throws Exception
     *   if the line count on the trailer does not match the number of lines processed
     */
	private int processTrailerRecord(String[] fields) throws Exception {
		int totalRecords = Integer.parseInt(fields[5]);
		
		if (totalRecords == lineCount) {
			return SUCCESS;
		}
		
		throw new Exception("Record count mismatch, trailer record shows " + totalRecords + ", but " + lineCount + " records exist on file " + currentFile.getName());
	}
	
	/**
	 * Processes the most recently read line of the input file, once it has been identified as record for insertion
	 * to the RABC_DAILY_ADJ_ACTVT table.
	 * 
	 * @param fields
	 *   an Array of the fields in the most recently read line of the input file.
	 * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob
	 */
	private int processAdjustmentRecord(String[] fields) {
		
		/*
		 * UAT Issue dated 04012007: Additional call to check the format of the record 
		 */
		if (!checkAdjustmentRecordFormat(fields)){
			return SKIPPED;
		}else{
				if (adjustmentRecordExists(fields)) {
					double adj_amt = Double.parseDouble(fields[8]) / 1000000;
					if (fields[1].equals("01")) {
						if(adj_amt >=0 ){
							return updateCreditAdjustmentRecord(fields);
						}else {
							return updateDebitAdjustmentRecord(fields);
						}
					}else{
						if(adj_amt < 0 ){
							return updateDebitAdjustmentRecord(fields);
						}else {
							return updateCreditAdjustmentRecord(fields);
						}
					}
				}else {
					return insertAdjustmentRecord(fields);
				}
		}
	}
	/**
	 * This is the method to check the format of the record.
	 * 
	 * @param fields
	 * @return boolean
	 */
	private boolean checkAdjustmentRecordFormat(String[] fields){
		if (fields.length !=9){
			return false;
		}
		
		if (fields[4]==null || "".equals(fields[4].trim())){
			return false;
		}
		
		return true;
	}
	
	/**
	 * Rolls through ArrayList adjustments, looking for a match to the values in the most recently read line of the
	 * input file. If no match is found, then the values are added to adjustments.
	 * 
	 * @param fields
	 *   an Array of the fields in the most recently read line of the input file.
	 * @return true if a match was found in adjustments, false otherwise.
	 */
	private boolean adjustmentRecordExists(String[] fields) {
		String[] current = new String[4];
		
		current[0] = getBusType(fields[2], fields[3]);							// BUS_TYPE
		current[1] = fields[4];													// TRN_CD
		current[2] = fields[5];													// ADJ_REASON_CD
		current[3] = fields[6];													// ADJ_CLS_CD
		
		for (int i = 0; i < adjustments.size(); i++) {
			String[] entry = (String[]) adjustments.get(i);
			if (entry[0].equalsIgnoreCase(current[0])
					&& entry[1].equalsIgnoreCase(current[1])
					&& entry[2].equalsIgnoreCase(current[2])
					&& entry[3].equalsIgnoreCase(current[3])) {
				return true;
			}
		}
		
		adjustments.add(current);
		return false;
	}
	
    /**
     * Performs an Insert to table RABC_DAILY_ADJ_ACTVT, using the data from the most recently read line
     * of the input file.
     * 
     * @param fields
     *   an Array of the fields in the most recently read line of the input file.
     * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob.
     */
	private int insertAdjustmentRecord(String[] fields) {
		try {
			insertAdjustment.setDate(1, sqlRunDate);							// RUN_DATE
			insertAdjustment.setString(2, division);							// DIVISION
			insertAdjustment.setString(3, getBusType(fields[2], fields[3]));	// BUS_TYPE
			insertAdjustment.setString(4, fields[4]);						// TRN_CD
			
			
			/* Required changes for PMT# M169 issue number M8
			 * Set Default Value 'NA' for ADJ_REASON_CD and Z for ADJ_CLS_CD 
			 */
			if((("").equals(fields[5])) || fields[5].equals(null)){
			insertAdjustment.setString(5,"NA");			// ADJ_REASON_CD
			}else{
				insertAdjustment.setString(5,fields[5]);		
			}
			if((("").equals(fields[6])) || fields[6].equals(null)){
				
				insertAdjustment.setString(6,"Z");			   // ADJ_CLS_CD
			}else{
				insertAdjustment.setString(6,fields[6]);		// ADJ_CLS_CD
			}
				
			/* Closed requirement for PMT# M169 issue # M8*/				
			
			if (fields[1].equals("01") || fields[1].equals("02")) {
				double adj_amt_db = Double.parseDouble(fields[8]) / 1000000;
				if (adj_amt_db >= 0){
					insertAdjustment.setLong(7, 0);										// ADJ_CT_DB
					insertAdjustment.setDouble(8, 0);									// ADJ_AMT_DB
					insertAdjustment.setLong(9, Long.parseLong(fields[7]) / 1000000);	// ADJ_CT_CR
					insertAdjustment.setDouble(10, adj_amt_db);							// ADJ_AMT_CR
				}else{
					insertAdjustment.setLong(7, Long.parseLong(fields[7]) / 1000000);	// ADJ_CT_DB
					insertAdjustment.setDouble(8, adj_amt_db);	// ADJ_AMT_DB
					insertAdjustment.setLong(9, 0);									// ADJ_CT_CR
					insertAdjustment.setDouble(10, 0);								// ADJ_AMT_CR
				}
			}	
				
			insertAdjustment.addBatch();
			
			if (lineCount % 1000 == 0) {
				performBatchExecute();
			}
		} catch (SQLException sqle) {
			severe(StaticErrorMsgKeys.INSERT_ERROR + "from method insertAdjustmentRecord(String[] fields)" + sqle.getMessage(), sqle);
			return ERROR;
		}
		
		return SUCCESS;
	}
	
    /**
     * Performs an Update to table RABC_DAILY_ADJ_ACTVT, using the data from the most recently read line
     * of the input file. Sums ADJ_CT_DB and ADJ_AMT_DB to the amounts in the existing record.
     * 
     * @param fields
     *   an Array of the fields in the most recently read line of the input file.
     * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob.
     */
	private int updateDebitAdjustmentRecord(String[] fields) {
		try {
			updateDebitAdjustment.setLong(1, Long.parseLong(fields[7]) / 1000000);	// ADJ_CT_DB
			updateDebitAdjustment.setDouble(2, Double.parseDouble(fields[8]) / 1000000);	// ADJ_AMT_DB
			updateDebitAdjustment.setDate(3, sqlRunDate);						// RUN_DATE
			updateDebitAdjustment.setString(4, division);						// DIVISION
			updateDebitAdjustment.setString(5, getBusType(fields[2], fields[3]));	// BUS_TYPE
			updateDebitAdjustment.setString(6, fields[4]);						// TRN_CD
			
			
			/* Required changes for PMT# M169 issue number M8
			 * Set Default Value 'NA' for ADJ_REASON_CD and Z for ADJ_CLS_CD 
			 */
			
			if((("").equals(fields[5])) || fields[5].equals(null))
			{
				updateDebitAdjustment.setString(7,"NA");			// ADJ_REASON_CD
			}else{
				updateDebitAdjustment.setString(7,fields[5]);		
			}			
			//updateDebitAdjustment.setString(7, fields[5]);						// ADJ_REASON_CD
			
			if((("").equals(fields[6])) || fields[6].equals(null)){
				
				updateDebitAdjustment.setString(8,"Z");			   // ADJ_CLS_CD
			}else{
				updateDebitAdjustment.setString(8,fields[6]);		// ADJ_CLS_CD
			}			
			//updateDebitAdjustment.setString(8, fields[6]);						// ADJ_CLS_CD
			
			/* Closed requirement for PMT# M169 issue # M8*/
			
			updateDebitAdjustment.addBatch();
			
			if (lineCount % 1000 == 0) {
				performBatchExecute();
			}
		} catch (SQLException sqle) {
			severe(StaticErrorMsgKeys.INSERT_ERROR + "from method updateDebitAdjustmentRecord(String[] fields)" + sqle.getMessage(), sqle);
			return ERROR;
		}
		return SUCCESS;
	}
	
    /**
     * Performs an Update to table RABC_DAILY_ADJ_ACTVT, using the data from the most recently read line
     * of the input file. Sums ADJ_CT_CR and ADJ_AMT_CR to the amounts in the existing record.
     * 
     * @param fields
     *   an Array of the fields in the most recently read line of the input file.
     * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob.
     */
	private int updateCreditAdjustmentRecord(String[] fields) {
		try {
			updateCreditAdjustment.setLong(1, Long.parseLong(fields[7]) / 1000000);	// ADJ_CT_CR
			updateCreditAdjustment.setDouble(2, Double.parseDouble(fields[8]) / 1000000);	// ADJ_AMT_CR
			updateCreditAdjustment.setDate(3, sqlRunDate);						// RUN_DATE
			updateCreditAdjustment.setString(4, division);						// DIVISION
			updateCreditAdjustment.setString(5, getBusType(fields[2], fields[3]));	// BUS_TYPE
			updateCreditAdjustment.setString(6, fields[4]);						// TRN_CD
			
			//updateCreditAdjustment.setString(7, fields[5]);						// ADJ_REASON_CD
			
			/* Required changes for PMT# M169 issue number M8
			 * Set Default Value 'NA' for ADJ_REASON_CD and Z for ADJ_CLS_CD 
			 */
			
			if((("").equals(fields[5])) || fields[5].equals(null))
			{
				updateCreditAdjustment.setString(7,"NA");			// ADJ_REASON_CD
			}else{
				updateCreditAdjustment.setString(7,fields[5]);		
			}			

			
			//updateCreditAdjustment.setString(8, fields[6]);						// ADJ_CLS_CD
			
			if((("").equals(fields[6])) || fields[6].equals(null)){
				
				updateCreditAdjustment.setString(8,"Z");			   // ADJ_CLS_CD
			}else{
				updateCreditAdjustment.setString(8,fields[6]);		// ADJ_CLS_CD
			}			
			//updateDebitAdjustment.setString(8, fields[6]);						// ADJ_CLS_CD
			
			/* Closed requirement for PMT # M169 issue # M8*/

			
			updateCreditAdjustment.addBatch();
			
			if (lineCount % 1000 == 0) {
				performBatchExecute();
			}
		} catch (SQLException sqle) {
			severe(StaticErrorMsgKeys.INSERT_ERROR + "from method updateCreditAdjustmentRecord(String[] fields) " + sqle.getMessage(), sqle);
			return ERROR;
		}
		return SUCCESS;
	}
	
	/**
	 * Processes the most recently read line of the input file, once it has been identified as record for insertion
	 * to the RABC_DAILY_BAL_TRSFR_ACTVT table.
	 * 
	 * @param fields
	 *   an Array of the fields in the most recently read line of the input file.
	 * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob
	 */
	private int processBalanceTransferRecord(String[] fields) {
		
		if (fields[4]==null || "".equals(fields[4].trim())){
			return SKIPPED;
		}else{
			if (balanceTransferRecordExists(fields)) {
				double bal_amt = Double.parseDouble(fields[5]) / 1000000;
				if (fields[1].equals("01")) {
					if(bal_amt >= 0){
						return updateCreditBalanceTransferRecord(fields);
					}else{
						return updateDebitBalanceTransferRecord(fields);
					}
				}else {
					if(bal_amt < 0){
						return updateDebitBalanceTransferRecord(fields);
					}else{
						return updateCreditBalanceTransferRecord(fields);
					}
				}
					
			} else {
				return insertBalanceTransferRecord(fields);
			}
	}
	}
	
	/**
	 * Rolls through ArrayList balanceTransfers, looking for a match to the values in the most recently read line
	 * of the input file. If no match is found, then the values are added to balanceTransfers.
	 * 
	 * @param fields
	 *   an Array of the fields in the most recently read line of the input file.
	 * @return true if a match was found in adjustments, false otherwise.
	 */
	private boolean balanceTransferRecordExists(String[] fields) {
		String[] current = new String[4];
		
		current[0] = getBusType(fields[2], fields[3]);							// BUS_TYPE
		current[1] = fields[4];													// BTN
		
		for (int i = 0; i < balanceTransfers.size(); i++) {
			String[] entry = (String[]) balanceTransfers.get(i);
			if (entry[0].equalsIgnoreCase(current[0])
					&& entry[1].equalsIgnoreCase(current[1])) {
				return true;
			}
		}
		
		balanceTransfers.add(current);
		return false;
	}
	
    /**
     * Performs an Insert to table RABC_DAILY_BAL_TRSFR_ACTVT, using the data from the most recently read line
     * of the input file.
     * 
     * @param fields
     *   an Array of the fields in the most recently read line of the input file.
     * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob.
     */
	private int insertBalanceTransferRecord(String[] fields) {
		try {
			insertBalanceTransfer.setDate(1, sqlRunDate);						// RUN_DATE
			insertBalanceTransfer.setString(2, division);						// DIVISION
			insertBalanceTransfer.setString(3, getBusType(fields[2], fields[3]));	// BUS_TYPE
			insertBalanceTransfer.setString(4, fields[4]);						// BTN
			
			if (fields[1].equals("01") || fields[1].equals("02")) {				// Debit record
				double bal_tr_amt = Double.parseDouble(fields[5]) / 1000000;
				if(bal_tr_amt >= 0){
					insertBalanceTransfer.setDouble(5, 0);							// BAL_TRSFR_AMT_DB
					insertBalanceTransfer.setDouble(6, Double.parseDouble(fields[5]) / 1000000);	// BAL_TRSFR_AMT_CR
				}else{
					insertBalanceTransfer.setDouble(5, Double.parseDouble(fields[5]) / 1000000);	// BAL_TRSFR_AMT_DB
					insertBalanceTransfer.setDouble(6, 0);							// BAL_TRSFR_AMT_CR
				}
			}
			
			insertBalanceTransfer.addBatch();
			
			if (lineCount % 1000 == 0) {
				performBatchExecute();
			}
		} catch (SQLException sqle) {
			severe(StaticErrorMsgKeys.INSERT_ERROR + "from method insertBalanceTransferRecord(String[] fields)" + sqle.getMessage(), sqle);
			return ERROR;
		}
		
		return SUCCESS;
	}
	
    /**
     * Performs an Update to table RABC_DAILY_BAL_TRSFR_ACTVT, using the data from the most recently read line
     * of the input file. Sums BAL_TRSFR_AMT_DB to the amount in the existing record.
     * 
     * @param fields
     *   an Array of the fields in the most recently read line of the input file.
     * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob.
     */
	private int updateDebitBalanceTransferRecord(String[] fields) {
		try {
			updateDebitBalanceTransfer.setDouble(1, Double.parseDouble(fields[5]) / 1000000);	// BAL_TRSFR_AMT_DB
			updateDebitBalanceTransfer.setDate(2, sqlRunDate);					// RUN_DATE
			updateDebitBalanceTransfer.setString(3, division);					// DIVISION
			updateDebitBalanceTransfer.setString(4, getBusType(fields[2], fields[3]));		// BUS_TYPE
			updateDebitBalanceTransfer.setString(5, fields[4]);					// BTN
			
			updateDebitBalanceTransfer.addBatch();
			
			if (lineCount % 1000 == 0) {
				performBatchExecute();
			}
		} catch (SQLException sqle) {
			severe(StaticErrorMsgKeys.INSERT_ERROR + "from method updateDebitBalanceTransferRecord(String[] fields)" + sqle.getMessage(), sqle);
			return ERROR;
		}
		return SUCCESS;
	}
	
    /**
     * Performs an Update to table RABC_DAILY_BAL_TRSFR_ACTVT, using the data from the most recently read line
     * of the input file. Sums BAL_TRSFR_AMT_CR to the amount in the existing record.
     * 
     * @param fields
     *   an Array of the fields in the most recently read line of the input file.
     * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob.
     */
	private int updateCreditBalanceTransferRecord(String[] fields) {
		try {
			updateCreditBalanceTransfer.setDouble(1, Double.parseDouble(fields[5]) / 1000000);	// BAL_TRSFR_AMT_CR
			updateCreditBalanceTransfer.setDate(2, sqlRunDate);					// RUN_DATE
			updateCreditBalanceTransfer.setString(3, division);					// DIVISION
			updateCreditBalanceTransfer.setString(4, getBusType(fields[2], fields[3]));		// BUS_TYPE
			updateCreditBalanceTransfer.setString(5, fields[4]);				// BTN
			
			updateCreditBalanceTransfer.addBatch();
			
			if (lineCount % 1000 == 0) {
				performBatchExecute();
			}
		} catch (SQLException sqle) {
			severe(StaticErrorMsgKeys.INSERT_ERROR + "from method updateCreditBalanceTransferRecord(String[] fields)" + sqle.getMessage(), sqle);
			return ERROR;
		}
		return SUCCESS;
	}
	
    /**
     * Performs an Insert to table RABC_DAILY_DEPOSIT_ACTVT, using the data from the most recently read line
     * of the input file.
     * 
     * @param fields
     *   an Array of the fields in the most recently read line of the input file.
     * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob.
     */
	private int insertDepositRecord(String[] fields) {
		
		if (fields[4]==null || "".equals(fields[4].trim())){
			return SKIPPED;
		}else{
			try {
				insertDeposit.setDate(1, sqlRunDate);								// RUN_DATE
				insertDeposit.setString(2, division);								// DIVISION
				insertDeposit.setString(3, getBusType(fields[2], fields[3]));		// BUS_TYPE
				insertDeposit.setString(4, fields[4]);								// BTN
				insertDeposit.setDouble(5, Double.parseDouble(fields[5]) / 1000000);	// BAL_DEP_AMT
				
				insertDeposit.addBatch();
				dep = true;
				if (lineCount % 1000 == 0) {
					performBatchExecute();
				}
			} catch (SQLException sqle) {
				severe(StaticErrorMsgKeys.INSERT_ERROR + "from method insertDepositRecord(String[] fields)" + sqle.getMessage(), sqle);
				return ERROR;
			}
			
			return SUCCESS;
		}
	}
	
    /**
     * Performs an Insert to table RABC_DAILY_PYMT_ACTVT, using the data from the most recently read line
     * of the input file.
     * 
     * @param fields
     *   an Array of the fields in the most recently read line of the input file.
     * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob.
     */
	private int insertPaymentRecord(String[] fields) {
		try {
			insertPayment.setDate(1, sqlRunDate);								// RUN_DATE
			insertPayment.setString(2, division);								// DIVISION
			insertPayment.setString(3, getBusType(fields[2], fields[3]));		// BUS_TYPE
			insertPayment.setLong(4, Long.parseLong(fields[4]) / 1000000);		// PYMT_TOT_CT
			insertPayment.setDouble(5, Double.parseDouble(fields[5]) / 1000000);	// PYMT_TOT_AMT
			
			insertPayment.addBatch();
			
			if (lineCount % 1000 == 0) {
				performBatchExecute();
			}
		} catch (SQLException sqle) {
			severe(StaticErrorMsgKeys.INSERT_ERROR + "from method insertPaymentRecord(String[] fields)" + sqle.getMessage(), sqle);
			return ERROR;
		}
		
		return SUCCESS;
	}
	
    /**
     * Performs an Insert to table RABC_DAILY_OCC_CASH_ACTVT, using the data from the most recently read line
     * of the input file.
     * 
     * @param fields
     *   an Array of the fields in the most recently read line of the input file.
     * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob.
     */
	private int insertOCCRecord(String[] fields) throws Exception {
		String wrInd = fields[4].trim();
		//it will be retail if blank
		if (wrInd.equals("")){
			wrInd="R";
		}
		String occRecCd = fields[2].trim();
		if ("".equals(occRecCd)){
			occRecCd = " ";
		}
		String crbrInd = fields[7].trim();
		
		DailyOCCSWData occActvt = new DailyOCCSWData();
		occActvt.setRunDate(MMddyyyy.parse(runDate));
		occActvt.setDivision(division);
		occActvt.setBus_type(getBusType(fields[3].trim(),wrInd));
		occActvt.setEcbrInd(fields[6].trim());
		occActvt.setFileId("");
		occActvt.setOccCd(occRecCd);
		occActvt.setOccType(fields[5].trim());
		long totalCount		= Long.parseLong(fields[8].trim())/1000000;
		double totalAmount	= Double.parseDouble(fields[9].toString().trim())/1000000;
		
		/*
		 * Check whether the object of DailyOccActvt type is present in the hash map
		 */
		DailyOCCSWData actvtObjRef = null;
		actvtObjRef = (DailyOCCSWData) occActvtMap.get(occActvt);
		
		if (actvtObjRef != null) {
			if (crbrInd.equals("1")){
				long newOccCtDb		= actvtObjRef.getOccChargeCnt() + totalCount;
				double newOccAmtDb	= actvtObjRef.getOccChargeAmt() + totalAmount;
				actvtObjRef.setOccChargeCnt(newOccCtDb);
				actvtObjRef.setOccChargeAmt(newOccAmtDb);
			}else {
				long newOccCtDb		= actvtObjRef.getOccCreditCnt() + totalCount;
				double newOccAmtDb	= actvtObjRef.getOccCreditAmt() + totalAmount;
				actvtObjRef.setOccCreditCnt(newOccCtDb);
				actvtObjRef.setOccCreditAmt(newOccAmtDb);
			}
			occActvtMap.put(actvtObjRef, actvtObjRef);
		} else {
			if (crbrInd.equals("1")){
				occActvt.setOccChargeCnt(totalCount);
				occActvt.setOccChargeAmt(totalAmount);
			}else {
				occActvt.setOccCreditCnt(totalCount);
				occActvt.setOccCreditAmt(totalAmount);
			}
			occActvtMap.put(occActvt, occActvt);
		}

		return SUCCESS;
	}
	
	/**
	 * This is the method to check the format of the record.
	 * 
	 * @param fields
	 * @return boolean
	 */
	private boolean checkOccRecordFormat(String[] fields){
		// For Credit Charge Indicator
		if ("".equals(fields[7].trim()) || !fields[7].trim().matches("[12]")){
			return false;
		}
		
		return true;
	}
	
    /**
     * Performs a select against table RABC_DAILY_DEPOSIT_ACCT for each valid value of BUS_TYPE, to retrieve a row
     * count. Then performs an insert into table RABC_DAILY_DEPOSIT_ACTVT, containing the retrieved count. If no
     * matching rows are present on RABC_DAILY_DEPOSIT_ACCT the select will return a count of '0', as a result a row
     * will ALWAYS be inserted into RABC_DAILY_DEPOSIT_ACTVT for every valid value of BUS_TYPE. This function must
     * only occur after performBatchExecute() has succesfully completed, in order to ensure that the appropriate
     * data is present in table RABC_DAILY_DEPOSIT_ACCT to be retrieved by the select.
     * 
     * @throws SQLException
	 *   if an SQLException is encountered while performing the database calls necessary to update the Deposit
	 *   Summary, then the exception is passed back, unaltered, to the calling function for handling.
     */
	private void updateDepositSummary() throws SQLException {
		for (int i = 0; i < busTypes.length; i++) {
			selectDepositSummary.setDate(1, sqlRunDate);						// RUN_DATE
			selectDepositSummary.setString(2, division);						// DIVISION
			selectDepositSummary.setString(3, busTypes[i]);						// BUS_TYPE
			
//		 PMT #M169 M5 issue coding start  
			
			//String amountDeposited = " SELECT BAL_DEP_AMT FROM RABC_DAILY_DEPOSIT_ACCT " +
			//" WHERE RUN_DATE = sqlRunDate AND DIVISION = division AND BUS_TYPE = busTypes[i] " ;
			
			amountDeposited.setDate(1, sqlRunDate);						// RUN_DATE
			amountDeposited.setString(2, division);						// DIVISION
			amountDeposited.setString(3, busTypes[i]);					// BUS_TYPE
			
			rs1 = amountDeposited.executeQuery();
			
			//double d = Double.valueOf(rs1).doubleValue();   // to convert string value in to double 
		//System.out.println("got...."+rs1.next());
			
			while (rs1.next())
			{
			 double d= rs1.getDouble(1);
			if (d >=1000.00){						
				rs = selectDepositSummary.executeQuery();
				if (rs.next()){
					insertDepositSummary.setDate(1, sqlRunDate);					// RUN_DATE
					insertDepositSummary.setString(2, division);					// DIVISION
					insertDepositSummary.setString(3, busTypes[i]);					// BUS_TYPE
					insertDepositSummary.setLong(4, rs.getLong(1));					// EXCESS_DEP_CT
					insertDepositSummary.executeUpdate();
				}
			}else{
				rs = selectDepositSummary.executeQuery();
				if (rs.next()){
					insertDepositSummary.setDate(1, sqlRunDate); 					// RUN_DATE
					insertDepositSummary.setString(2, division); 					// DIVISION
					insertDepositSummary.setString(3, busTypes[i]);					// BUS_TYPE
					insertDepositSummary.setLong(4, 0); 							// EXCESS_DEP_CT
					insertDepositSummary.executeUpdate();
					}
				}
			}				
//				
//				rs = selectDepositSummary.executeQuery();
//				if (rs.next())
//				{
//				insertDepositSummary.setDate(1, sqlRunDate); 					// RUN_DATE
//				insertDepositSummary.setString(2, division); 					// DIVISION
//				insertDepositSummary.setString(3, busTypes[i]);					// BUS_TYPE
//				insertDepositSummary.setLong(4, 0); 							// EXCESS_DEP_CT
//				insertDepositSummary.executeUpdate();
//				}
//								
				// PMT #169 M5 issue coding end  
		}
	}

	
	/**
	 * Determines and returns the appropriate BusType value based upon the CusType and WholesaleRetail values.
	 * 
	 * @param cusType
	 *   Customer Type from the currently processing line.
	 * @param wholesaleRetail
	 *   Wholesale/Retail indicator from the currently processing line.
	 * @return a String containing the determined BusType.
	 */
	private String getBusType(String cusType, String wholesaleRetail) {
		if ("".equals(cusType) || cusType.substring(0,1).equals("1")) {
			if (wholesaleRetail.equalsIgnoreCase("W")) {
				return busTypes[0];												// RRES
			} else {
				return busTypes[1];												// RES
			}
		} else {
			if (wholesaleRetail.equalsIgnoreCase("W")) {
				return busTypes[2];												// RBUS
			} else {
				return busTypes[3];												// BUS
			}
		}
	}
	
	/**
	 * Performs the .executeBatch() operation on all of the appropriate PreparedStatement objects.
	 * 
	 * @throws SQLException
	 *   if an SQLException is encountered while performing the batch executes, then the exception is passed back,
	 *   unaltered, to the calling function for handling.
	 */
	private void performBatchExecute() throws SQLException {
		
		// Table RABC_DAILY_ADJ_ACTVT will be receiving both Inserts and Updates. Batch Inserts MUST occur first!
		insertAdjustment.executeBatch();
		updateDebitAdjustment.executeBatch();
		updateCreditAdjustment.executeBatch();
		
		// Table RABC_DAILY_BAL_TRSFR_ACTVT will be receiving both Inserts and Updates. Batch Inserts MUST occur first!
		insertBalanceTransfer.executeBatch();
		updateDebitBalanceTransfer.executeBatch();
		updateCreditBalanceTransfer.executeBatch();
		
		// Insert a dummy record into the RABC_DAILY_DEPOSIT_ACCT when there were no deposits made
		if (dep==false){
			insertDummyDeposits();
		}
		insertDeposit.executeBatch();											// RABC_DAILY_DEPOSIT_ACTVT
		insertPayment.executeBatch();											// RABC_DAILY_PYMT_ACTVT
		insertOCC.executeBatch();												// RABC_DAILY_OCC_CASH_ACTVT
	}
	
	/**
	 * Iterate through the entire map occActvtMap and insert entries into the RABC_DAILY_OCC_ACTVT table
	 * 
	 * @throws SQLException
	 */
	private void executeOccBatch() throws SQLException {
		Set occActvtSet			= occActvtMap.keySet();
		Iterator occActvtIterator = occActvtSet.iterator();
		
		while (occActvtIterator.hasNext()) {
			DailyOCCSWData occActvt = (DailyOCCSWData) occActvtIterator.next();
			insertOCC.setDate(1, sqlRunDate);									// RUN_DATE
			insertOCC.setString(2, division);									// DIVISION
			insertOCC.setString(3, occActvt.getBus_type());						// BUS_TYPE
			insertOCC.setString(4, occActvt.getOccCd());						// OCC_CD
			insertOCC.setString(5, occActvt.getOccType());						// OCC_TYPE
			insertOCC.setString(6, occActvt.getEcbrInd());						// EBCR_IND
			insertOCC.setLong(7, occActvt.getOccCreditCnt());					// OCC_CT_CR
			insertOCC.setDouble(8, occActvt.getOccCreditAmt());					// OCC_AMT_CR
			insertOCC.setLong(9, occActvt.getOccChargeCnt());					// OCC_CT_CR
			insertOCC.setDouble(10, occActvt.getOccChargeAmt());				// OCC_AMT_CR
			
			insertOCC.addBatch();
			actvtBatchCounter++;
			
			if (actvtBatchCounter % 1000 == 0) {
				insertOCC.executeBatch();
			}
			isCashOccActvt = true;
		}
		
		insertOCC.executeBatch();
		
		// Add the trigger only if the inserts happened successfully
		if (isCashOccActvt){
			if (!triggers.contains("SWCASHOC")) {
				triggers.add("SWCASHOC");
			}
		}
	}
	
	/**
	 * Insert a dummy record into the RABC_DAILY_DEPOSIT_ACCT table for BUS_TYPE = RES and BTN = 9999999999999
	 */
	private void insertDummyDeposits() throws SQLException {
		insertDeposit.setDate(1, sqlRunDate);								// RUN_DATE
		insertDeposit.setString(2, division);								// DIVISION
		insertDeposit.setString(3, getBusType("", ""));					// BUS_TYPE
		insertDeposit.setString(4, "9999999999999");						// BTN
		insertDeposit.setDouble(5, 0.0);									// BAL_DEP_AMT
		insertDeposit.addBatch();
	}
	
	/**
	 * Processes once the file has been completely processed. Performs final batch execution of database calls. 
	 * Inserts Triggers for each data type that was processed during this run.
	 * 
	 * @param file
	 *   the currently processing file.
	 * @param success
	 *   the success so far for the application
	 * @return success for the application.
	 */
	public boolean postprocessFile(File file, boolean success) {
		try{
			
			//Log the file information to EMCIS_EVENT_LOG and EMCIS_EVENT_LOG_DETAIL
			EmcisEventLogger emcisLogger = new EmcisEventLogger();
			String event_id = "RABC_"+fileToken+"_"+region;
            String host = NetUtil.getLocalHostName();
            String hostIP = NetUtil.getLocalIpAddress();
			int sequence = emcisLogger.getEMCISSequence(connection);
			emcisLogger.insertEventLog(connection, sequence, event_id, sqlRunDate, host, hostIP);
			emcisLogger.insertEventLogDetail(connection, sequence, "FileName", fileName);
		}catch (UnknownHostException e) {
            severe("Error getting EMCIS host information ", e);
        }
		if (success) {
			try {
				performBatchExecute();
				executeOccBatch();			// For OCC records
				updateDepositSummary();		// Must occur AFTER the successful completion of performBatchExecute() 
				
				if (!insertTrigger()) {
					severe(	StaticErrorMsgKeys.POSTPROCESSFILE_ERROR
							+ StaticErrorMsgKeys.TIGGER_TABLE_INSERT_ERROR);
					success = false;
				}
			} catch (SQLException sqle) {
				severe(StaticErrorMsgKeys.INSERT_ERROR + "from method postprocessFile(String[] fields)" + sqle.getMessage(), sqle);
				success = false;
			}
		}
		return super.postprocessFile(file, success);
	}
	
	/**
	 * Inserts Triggers for each data type that was processed during this run.
	 * 
	 * @return true if all triggers were inserted, false otherwise.
	 */
	private boolean insertTrigger() {
		String recovery = null;
		
		if (lineCount > 0) {
			try {
				String query = "SELECT to_char(BILL_RND,'00') FROM RABC_CYCLE_CALENDAR WHERE PROC_DT = to_date('" + runDate + "','MMddyyyy')";
				String billRnd = RetrieveStaticInfo.getBillRnd(connection, query);
				if ("00".equals(billRnd) || "".equals(billRnd)){
					billRnd = "0";
				}
				
				if (backupRecovery) {
					recovery = "Y";
				}
				
				for (int i = 0; i < triggers.size(); i++) {
					if (!RabcLoadJobTrig.insertTrigger(connection, currentFile.getName().substring(5, currentFile.getName().length()), currentFile.getName(), (String) triggers.get(i), division, runDate , recovery, billRnd)) {
						return false;
					}
				}
			} catch (SQLException e) {
				severe(StaticErrorMsgKeys.POSTPROCESSFILE_ERROR + StaticErrorMsgKeys.NORECORD_RABC_CYCLE_CALENDAR + e, e);
				return false;
			}
		}
		return true;
	}
	
	/**
	 * Processes at the end of the application. Closes all open PreparedStatements and ResultSets.
	 * 
	 * @param success
	 *   the success of the application thus far
	 * @return success for the application.
	 */
	public boolean postprocess(boolean success) {
		JDBCUtil.closePreparedStatement(insertAdjustment);
		JDBCUtil.closePreparedStatement(updateDebitAdjustment);
		JDBCUtil.closePreparedStatement(updateCreditAdjustment);
		JDBCUtil.closePreparedStatement(insertBalanceTransfer);
		JDBCUtil.closePreparedStatement(updateDebitBalanceTransfer);
		JDBCUtil.closePreparedStatement(updateCreditBalanceTransfer);
		JDBCUtil.closePreparedStatement(insertDeposit);
		JDBCUtil.closePreparedStatement(selectDepositSummary);
		JDBCUtil.closePreparedStatement(insertDepositSummary);
		JDBCUtil.closePreparedStatement(insertPayment);
		JDBCUtil.closePreparedStatement(insertOCC);
		
		JDBCUtil.closeResultSet(rs);
		JDBCUtil.closeResultSet(rs1);	// Code added for PMT #M169 issue no #M5 	
		
		return super.postprocess(success);
	}

}
