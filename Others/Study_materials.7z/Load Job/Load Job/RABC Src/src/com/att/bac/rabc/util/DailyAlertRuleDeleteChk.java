package com.att.bac.rabc.util;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import com.att.carat.util.JDBCUtil;
//changes done for M168 by as635b
//import com.sbc.bac.load.Application;
//import com.sbc.bac.load.TimedLoadJob;
import com.att.carat.load.Application;
import com.att.carat.load.TimedLoadJob;

import com.sbc.bac.rabc.load.StaticFieldKeys;

public class DailyAlertRuleDeleteChk extends TimedLoadJob {
	
	/**
	 * This job cleans up any "DELETED" alert rules with "NO" data in RABC_EXTRCT_SUMY_DATA .. 
	 * This job runs once everyday in after hours and cleans up any Pending alert rules with matching Criteria     
	 */
	
	private PreparedStatement deleteAlertRule;
	private PreparedStatement getAlertList;
	private String tblListByAlertRule = null;
	private String tblListByPresnId = null;
	private String tblListByPartiRefId = null;
	
	protected boolean configure(Application application, Properties properties) {
        boolean success = super.configure(application, properties);
        if (!success) 
        	return false;

        tblListByAlertRule = properties.getProperty("tblListByAlertRule").trim();
        if (tblListByAlertRule == null){
        	severe(" Config parameter tableList not defined!! ");
        	return false;
        }

        tblListByPresnId = properties.getProperty("tblListByPresnId").trim();
        if (tblListByPresnId == null){
        	severe(" Config parameter tableList not defined!! ");
        	return false;
        }
        
        tblListByPartiRefId = properties.getProperty("tblListByPartiRefId").trim();
        if (tblListByPartiRefId == null){
        	severe(" Config parameter tableList not defined!! ");
        	return false;
        }
        
        return true;
	}
	
	
	protected boolean action() {
		
		boolean status = true;
		ResultSet ruleList = null;
		int alertCnt = 0;
		
		try {
			getAlertList = connection.prepareStatement(" SELECT alert_rule, presn_id, parti_ref_id FROM rabc_alert_rule " +
					"	WHERE alert_rule_status = 'DELETED' " +
					"	AND parti_ref_id NOT IN (SELECT DISTINCT parti_ref_id FROM rabc_extrct_sumy_data) ");
			
			ruleList = getAlertList.executeQuery();
			StringBuffer rules = new StringBuffer(" where ALERT_RULE in (");
			StringBuffer presnID = new StringBuffer(" where PRESN_ID in (");
			StringBuffer partiRefId = new StringBuffer(" where PARTI_REF_ID in (");
			
			while(ruleList.next()){
					rules.append("'").append(ruleList.getString("alert_rule").trim()).append("', ");
					presnID.append("'").append(ruleList.getString("presn_id").trim()).append("', ");
					partiRefId.append("'").append(ruleList.getString("parti_ref_id").trim()).append("', ");
				alertCnt++;
			}
			
			if (alertCnt > 0) {
				rules.deleteCharAt(rules.lastIndexOf(",")).append(")");
				presnID.deleteCharAt(presnID.lastIndexOf(",")).append(")");
				partiRefId.deleteCharAt(partiRefId.lastIndexOf(",")).append(")");
				
				status = deleteAlertByRule(rules.toString());
				status = status && deleteAlertByPresnId(presnID.toString());
				status = status && deleteAlertByPartiRefId(partiRefId.toString());

				if (status)
					deleteAlertRule = connection
					.prepareStatement(" DELETE rabc_alert_rule  " + presnID.toString() );
			deleteAlertRule.executeUpdate();
			}
			
			JDBCUtil.closeResultSet(ruleList);
			
		}catch (SQLException e) {
			severe(e.getMessage(), e);

			status = false;
		}
		
		return status;
	}
	
	private boolean deleteAlertByRule(String check){
	
		boolean status = true;
		// Expected configuration file will contain a ";" semicolan separated table list
		String[] clnupTableList = tblListByAlertRule.split(StaticFieldKeys.SEMICOLON);

		int tblIdx = 0;
		while (clnupTableList.length > tblIdx) {
		
			if (clnupTableList[tblIdx].trim() != null && !clnupTableList[tblIdx].trim().equals(""))
			try {
				deleteAlertRule = connection.prepareStatement(" DELETE "
						+ clnupTableList[tblIdx].trim() + check);
				deleteAlertRule.executeUpdate();
			} catch (SQLException e) {
				severe(e.getMessage(), e);
				status = false;
				break;
			}
			tblIdx++;
		}
		
		return status;
	}
	
	private boolean deleteAlertByPresnId(String check){

		
		boolean status = true;
		// Expected configuration file will contain a ";" semicolan separated table list
		String[] clnupTableList = tblListByPresnId.split(StaticFieldKeys.SEMICOLON);

		int tblIdx = 0;
		
		while (clnupTableList.length > tblIdx) {
			if (clnupTableList[tblIdx].trim() != null && !clnupTableList[tblIdx].trim().equals(""))
			try {
				deleteAlertRule = connection.prepareStatement(" DELETE "
						+ clnupTableList[tblIdx].trim() + check);
				deleteAlertRule.executeUpdate();
			} catch (SQLException e) {
				severe(e.getMessage(), e);
				status = false;
				break;
			}
			tblIdx++;
		}
		
		return status;
		
	}

	private boolean deleteAlertByPartiRefId(String check){

		boolean status = true;
		// Expected configuration file will contain a ";" semicolan separated table list
		String[] clnupTableList = tblListByPartiRefId.split(StaticFieldKeys.SEMICOLON);

		int tblIdx = 0;
		
		while (clnupTableList.length > tblIdx) {
			if (clnupTableList[tblIdx].trim() != null && !clnupTableList[tblIdx].trim().equals(""))
			try {
				deleteAlertRule = connection.prepareStatement(" DELETE "
						+ clnupTableList[tblIdx].trim() + check);
				deleteAlertRule.executeUpdate();
			} catch (SQLException e) {
				severe(e.getMessage(), e);
				status = false;
				break;
			}
			tblIdx++;
		}
		
		return status;
	}

	protected boolean postprocess(boolean success) {
	
			JDBCUtil.closePreparedStatement(getAlertList);
			JDBCUtil.closePreparedStatement(deleteAlertRule);
		
		success = super.postprocess(success);
		
		return success;
	}
	
}
