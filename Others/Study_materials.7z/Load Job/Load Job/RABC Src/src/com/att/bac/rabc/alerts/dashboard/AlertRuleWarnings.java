/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.dashboard;

/**
 * This class represents the data object that holds the attributes required
 * to represent the AlertRule Warnings.
 * 
 * @author Sandhya Chinala - SC3837
 */
public class AlertRuleWarnings {

	private String alertDate;
	private String division;
	private String alertRule;
	private String dataItem;
	private double revenueImpact;
	private String rootCauseCategory;
	private String status;
	private String comments;
	private double unrecoverableRevenue;
	private String alertKey2;
	private String alertKey3;
	private String alertKey4;
	private String alertKey5;
	private String alertData2;
	private String alertData3;
	private String alertData4;
	private String alertData5;
	private int keyRow = 0;
		
	/**
	 * @return Returns the alertDate.
	 */
	public String getAlertDate() {
		return alertDate;
	}
	/**
	 * @param alertDate The alertDate to set.
	 */
	public void setAlertDate(String alertDate) {
		this.alertDate = alertDate;
	}
	/**
	 * @return Returns the alertRule.
	 */
	public String getAlertRule() {
		return alertRule;
	}
	/**
	 * @param alertRule The alertRule to set.
	 */
	public void setAlertRule(String alertRule) {
		this.alertRule = alertRule;
	}
	/**
	 * @return Returns the dataItem.
	 */
	public String getDataItem() {
		return dataItem;
	}
	/**
	 * @param dataItem The dataItem to set.
	 */
	public void setDataItem(String dataItem) {
		this.dataItem = dataItem;
	}
	/**
	 * @return Returns the division.
	 */
	public String getDivision() {
		return division;
	}
	/**
	 * @param division The division to set.
	 */
	public void setDivision(String division) {
		this.division = division;
	}
	/**
	 * @return Returns the revenueImpact.
	 */
	public double getRevenueImpact() {
		return revenueImpact;
	}
	/**
	 * @param revenueImpact The revenueImpact to set.
	 */
	public void setRevenueImpact(double revenueImpact) {
		this.revenueImpact = revenueImpact;
	}
	/**
	 * @return Returns the rootCauseCategory.
	 */
	public String getRootCauseCategory() {
		return rootCauseCategory;
	}
	/**
	 * @param rootCauseCategory The rootCauseCategory to set.
	 */
	public void setRootCauseCategory(String rootCauseCategory) {
		this.rootCauseCategory = rootCauseCategory;
	}
	/**
	 * @return Returns the status.
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status The status to set.
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	
	/**
	 * @return Returns the comments.
	 */
	public String getComments() {
		return comments;
	}
	/**
	 * @param comments The comments to set.
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}
	
	/**
	 * @return Returns the unrecoverableRevenue.
	 */
	public double getUnrecoverableRevenue() {
		return unrecoverableRevenue;
	}
	/**
	 * @param unrecoverableRevenue The unrecoverableRevenue to set.
	 */
	public void setUnrecoverableRevenue(double unrecoverableRevenue) {
		this.unrecoverableRevenue = unrecoverableRevenue;
	}
	/**
	 * @return Returns the alertData2.
	 */
	public String getAlertData2() {
		return alertData2;
	}
	/**
	 * @param alertData2 The alertData2 to set.
	 */
	public void setAlertData2(String alertData2) {
		this.alertData2 = alertData2;
	}
	/**
	 * @return Returns the alertData3.
	 */
	public String getAlertData3() {
		return alertData3;
	}
	/**
	 * @param alertData3 The alertData3 to set.
	 */
	public void setAlertData3(String alertData3) {
		this.alertData3 = alertData3;
	}
	/**
	 * @return Returns the alertData4.
	 */
	public String getAlertData4() {
		return alertData4;
	}
	/**
	 * @param alertData4 The alertData4 to set.
	 */
	public void setAlertData4(String alertData4) {
		this.alertData4 = alertData4;
	}
	/**
	 * @return Returns the alertData5.
	 */
	public String getAlertData5() {
		return alertData5;
	}
	/**
	 * @param alertData5 The alertData5 to set.
	 */
	public void setAlertData5(String alertData5) {
		this.alertData5 = alertData5;
	}
	/**
	 * @return Returns the alertKey2.
	 */
	public String getAlertKey2() {
		return alertKey2;
	}
	/**
	 * @param alertKey2 The alertKey2 to set.
	 */
	public void setAlertKey2(String alertKey2) {
		this.alertKey2 = alertKey2;
	}
	/**
	 * @return Returns the alertKey3.
	 */
	public String getAlertKey3() {
		return alertKey3;
	}
	/**
	 * @param alertKey3 The alertKey3 to set.
	 */
	public void setAlertKey3(String alertKey3) {
		this.alertKey3 = alertKey3;
	}
	/**
	 * @return Returns the alertKey4.
	 */
	public String getAlertKey4() {
		return alertKey4;
	}
	/**
	 * @param alertKey4 The alertKey4 to set.
	 */
	public void setAlertKey4(String alertKey4) {
		this.alertKey4 = alertKey4;
	}
	/**
	 * @return Returns the alertKey5.
	 */
	public String getAlertKey5() {
		return alertKey5;
	}
	/**
	 * @param alertKey5 The alertKey5 to set.
	 */
	public void setAlertKey5(String alertKey5) {
		this.alertKey5 = alertKey5;
	}
	/**
	 * @return Returns the keyRow.
	 */
	public int getKeyRow() {
		return keyRow;
	}
	/**
	 * @param keyRow The keyRow to set.
	 */
	public void setKeyRow(int keyRow) {
		this.keyRow = keyRow;
	}
}
