/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.dashboard;

import java.util.ArrayList;
import java.util.List;

/**
 * This class represents the data object that holds the attributes required
 * to represent the System Messages.  
 * 
 * @author Abhilash - AC6957
 */
public class SystemMessages {
	private int msgNum;
	private String alertRule;
	private String fileDate;
	private Integer fileSeqNum;
	private Integer systemErrorCode;
	private String status;
	private Double dollarImpact;
	private String systemMessageDescription;
	private String keylevels;
	private String division;
	private List rootCauseCategoryList = new ArrayList();
	private String systemErrorCodeMouseOver;
	

	/**
	 * @return Returns the alertRule.
	 */
	public String getAlertRule() {
		return alertRule;
	}
	/**
	 * @param alertRule The alertRule to set.
	 */
	public void setAlertRule(String alertRule) {
		this.alertRule = alertRule;
	}
	/**
	 * @return Returns the dollarImpact.
	 */
	public Double getDollarImpact() {
		return dollarImpact;
	}
	/**
	 * @param dollarImpact The dollarImpact to set.
	 */
	public void setDollarImpact(Double dollarImpact) {
		this.dollarImpact = dollarImpact;
	}
	/**
	 * @return Returns the fileDate.
	 */
	public String getFileDate() {
		return fileDate;
	}
	/**
	 * @param fileDate The fileDate to set.
	 */
	public void setFileDate(String fileDate) {
		this.fileDate = fileDate;
	}
	/**
	 * @return Returns the fileSeqNum.
	 */
	public Integer getFileSeqNum() {
		return fileSeqNum;
	}
	/**
	 * @param fileSeqNum The fileSeqNum to set.
	 */
	public void setFileSeqNum(Integer fileSeqNum) {
		this.fileSeqNum = fileSeqNum;
	}

	/**
	 * @return Returns the status.
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status The status to set.
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return Returns the systemErrorCode.
	 */
	public Integer getSystemErrorCode() {
		return systemErrorCode;
	}
	/**
	 * @param systemErrorCode The systemErrorCode to set.
	 */
	public void setSystemErrorCode(Integer systemErrorCode) {
		this.systemErrorCode = systemErrorCode;
	}
	/**
	 * @return Returns the systemMessageDescription.
	 */
	public String getSystemMessageDescription() {
		return systemMessageDescription;
	}
	/**
	 * @param systemMessageDescription The systemMessageDescription to set.
	 */
	public void setSystemMessageDescription(String systemMessageDescription) {
		this.systemMessageDescription = systemMessageDescription;
	}
	
	/**
	 * @return Returns the rootCauseCategoryList.
	 */
	public List getRootCauseCategoryList() {
		return rootCauseCategoryList;
	}
	/**
	 * @param rootCauseCategoryt The rootCauseCategoryList to add.
	 */
	public void addRootCauseCategory(String rootCauseCategory) {
		this.rootCauseCategoryList.add(rootCauseCategory);
	}
	/**
	 * @return Returns the msgNum.
	 */
	public int getMsgNum() {
		return msgNum;
	}
	/**
	 * @param msgNum The msgNum to set.
	 */
	public void setMsgNum(int msgNum) {
		this.msgNum = msgNum;
	}
	
	/**
	 * @return Returns the keylevels.
	 */
	public String getKeylevels() {
		return keylevels;
	}
	/**
	 * @param keylevels The keylevels to set.
	 */
	public void setKeylevels(String keylevels) {
		this.keylevels = keylevels;
	}
	/**
	 * @return Returns the division.
	 */
	public String getDivision() {
		return division;
	}
	/**
	 * @param division The division to set.
	 */
	public void setDivision(String division) {
		this.division = division;
	}
	/**
	 * @return the systemErrorCodeMouseOver
	 */
	public String getSystemErrorCodeMouseOver() {
		return systemErrorCodeMouseOver;
	}
	/**
	 * @param systemErrorCodeMouseOver the systemErrorCodeMouseOver to set
	 */
	public void setSystemErrorCodeMouseOver(String systemErrorCodeMouseOver) {
		this.systemErrorCodeMouseOver = systemErrorCodeMouseOver;
	}
}
