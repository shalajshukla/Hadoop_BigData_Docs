/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/

package com.att.bac.rabc.alerts.dashboard;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.Format;
import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.att.bac.rabc.DateUtil;
import com.att.bac.rabc.ExcelReport;
import com.att.bac.rabc.PickList;
import com.att.bac.rabc.ProgressBar;
import com.att.bac.rabc.RABCConstantsLists;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;

/**
 * This class represents the Service that holds the Alert Dashboard List.
 * The methods in this class are called by the action class.
 * They internaly calls the DAO classes to do the required manipulation and returns the 
 * result to the action class.
 * This paricular service class serves the business logic to populate the
 * Dashboard Component.
 * 
 * @author Sandhya Chinala - SC3837
 */
public class AlertDashboardService {
	private static final Logger logger = Logger.getLogger(AlertDashboardService.class);
	private static AlertDashboardService alertDashboardService;
	
	private final String query_getCycle = "SELECT CYCLE,BILL_RND,PROC_DT,BILL_RND_DT "
										+ "FROM rabc_cycle_calendar {0}";
	
	private final String query_convertForDisplay = "SELECT cntrl_pt_desc convertedDescription "
		+ "FROM rabc_cntrl_pt_trans " 
		+ "WHERE cntrl_pt_code = ''{0}''";

	private final String get_cntrl_pts = "SELECT T.cnrtPtCode, T.cnrtPtDesc, T.process  FROM ( "
		+ "SELECT rownum rn, t.* FROM ( "
		+ "SELECT b.cntrl_pt_code cnrtPtCode, "
		+ "b.cntrl_pt_desc cnrtPtDesc, "
		+ "a.process process, "
		+ "sum(severe_lvl_high_ct) 		severe_lvl_high_ct, " 
		+ "sum(severe_lvl_mid_ct)		severe_lvl_mid_ct, " 
		+ "sum(severe_lvl_low_ct)		severe_lvl_low_ct " 
		+ "FROM rabc_process a, rabc_cntrl_pt_trans b, rabc_dash_presn c, rabc_cntrl_pt_alert d "
		+ "WHERE a.cntrl_pt_cd = b.cntrl_pt_code "
		+ "AND c.alert_rule = d.alert_rule "
		+ "AND b.cntrl_pt_code = d.cntrl_pt_cd "
		+ "AND c.alert_rule in (select alert_rule from rabc_alert_rule where UPPER(alert_rule_status) = ''ACTIVE'') "
		+ "AND {0} "
		+ "GROUP BY b.cntrl_pt_code, b.cntrl_pt_desc, a.process "
		+ "UNION "
		+ "SELECT cnrtPtCode, cnrtPtDesc, process, 0 severe_lvl_high_ct, 0 severe_lvl_mid_ct, 0 severe_lvl_low_ct "
		+ "FROM ( "
		+ "SELECT distinct b.cntrl_pt_code cnrtPtCode, b.cntrl_pt_desc cnrtPtDesc, a.process process "
		+ "FROM rabc_process a, rabc_cntrl_pt_trans b, rabc_cntrl_pt_alert c "
		+ "WHERE a.cntrl_pt_cd = b.cntrl_pt_code "
		+ "AND b.cntrl_pt_code = c.cntrl_pt_cd "
		+ "AND c.alert_rule in (select alert_rule from rabc_alert_rule where UPPER(alert_rule_status) = ''ACTIVE'') "
		+ "MINUS "
		+ "SELECT cnrtPtCode, cnrtPtDesc, process from ( "
		+ "SELECT b.cntrl_pt_code cnrtPtCode, b.cntrl_pt_desc cnrtPtDesc, a.process process, "
		+ "sum(severe_lvl_high_ct) 		severe_lvl_high_ct, " 
		+ "sum(severe_lvl_mid_ct)		severe_lvl_mid_ct, " 
		+ "sum(severe_lvl_low_ct)		severe_lvl_low_ct "
		+ "FROM rabc_process a, rabc_cntrl_pt_trans b, rabc_dash_presn c, rabc_cntrl_pt_alert d "
		+ "WHERE a.cntrl_pt_cd = b.cntrl_pt_code "
		+ "AND c.alert_rule = d.alert_rule "
		+ "AND b.cntrl_pt_code = d.cntrl_pt_cd "
		+ "AND c.alert_rule in (select alert_rule from rabc_alert_rule where UPPER(alert_rule_status) = ''ACTIVE'') "
		+ "AND {0} "
		+ "GROUP BY b.cntrl_pt_code, b.cntrl_pt_desc, a.process )) "
		+ "{1} ) t "
		+ ") T {2}";
	
	private final String getTotalCntrlPts = "SELECT count(*) "
		+ "FROM ( "
		+ "SELECT distinct b.cntrl_pt_code cnrtPtCode, "
		+ "b.cntrl_pt_desc cnrtPtDesc, "
		+ "a.process process "
		+ "FROM rabc_process a, rabc_cntrl_pt_trans b, rabc_cntrl_pt_alert c "
		+ "WHERE a.cntrl_pt_cd = b.cntrl_pt_code "
		+ "AND b.cntrl_pt_code = c.cntrl_pt_cd "
		+ "AND c.alert_rule in (select alert_rule from rabc_alert_rule where UPPER(alert_rule_status) = ''ACTIVE'') "
		+ ") ";
	
	private final String get_alerts = "SELECT T.alertRule, T.cnrtPtCode "
		+ "FROM ( "
		+ "SELECT rownum rn, t.alertRule alertRule, t.cnrtPtCode cnrtPtCode "
		+ "FROM ( " 
		+ "SELECT b.alert_rule alertRule, "
		+ "b.cntrl_pt_cd cnrtPtCode, "
		+ "sum(severe_lvl_high_ct) 		severe_lvl_high_ct," 
		+ "sum(severe_lvl_mid_ct)		severe_lvl_mid_ct," 
		+ "sum(severe_lvl_low_ct)		severe_lvl_low_ct " 
		+ "FROM rabc_dash_presn a, rabc_cntrl_pt_alert b, rabc_alert_rule c "
		+ "{0} "
		+ "AND a.alert_rule = b.alert_rule "
		+ "AND b.alert_rule = c.alert_rule "
		+ "AND UPPER(c.alert_rule_status) = ''ACTIVE'' "
		+ "and c.ALERT_RULE in (select a.ALERT_RULE from RABC_UPDATE_GRP a, RABC_ALERT_GRP_USER b where a.ALERT_GRP = b.ALERT_GRP and b.USER_ID = ''{1}'') "
		+ "GROUP BY b.cntrl_pt_cd, b.alert_rule "
		+ "{2} ) t "
		+ ") T {3}";
	
	private final String getTotalAlertRules = "SELECT count(*) "
		+ "FROM ( "
		+ "SELECT b.alert_rule alertRule, "
		+ "b.cntrl_pt_cd cnrtPtCode, "
		+ "sum(severe_lvl_high_ct) 		severe_lvl_high_ct," 
		+ "sum(severe_lvl_mid_ct)		severe_lvl_mid_ct," 
		+ "sum(severe_lvl_low_ct)		severe_lvl_low_ct " 
		+ "FROM rabc_dash_presn a, rabc_cntrl_pt_alert b, rabc_alert_rule c "
		+ "{0} "
		+ "AND a.alert_rule = b.alert_rule "
		+ "AND b.alert_rule = c.alert_rule "
		+ "AND UPPER(c.alert_rule_status) = ''ACTIVE'' "
		+ "and c.ALERT_RULE in (select a.ALERT_RULE from RABC_UPDATE_GRP a, RABC_ALERT_GRP_USER b where a.ALERT_GRP = b.ALERT_GRP and b.USER_ID = ''{1}'') "
		+ "GROUP BY b.cntrl_pt_cd, b.alert_rule) ";

	private final String get_total_2 = "SELECT sum(a.severe_lvl_high_ct) tot_high_ct, " 
		+ "sum(a.severe_lvl_mid_ct)	tot_mid_ct, " 
		+ "sum(a.severe_lvl_low_ct)	tot_low_ct, " 
		+ "sum(a.severe_lvl_no_issue_ct) tot_no_issue_ct, "
		+ "sum(a.warn_ct) tot_warn_ct, "
		+ "sum(a.pend_ct) tot_pend_ct "
		+ "FROM	rabc_dash_presn a, rabc_cntrl_pt_alert b, rabc_alert_rule c " 
		+ "WHERE a.alert_rule = b.alert_rule  {0} "
		+ "AND b.alert_rule = c.alert_rule "
		+ "and UPPER(c.alert_rule_status) = ''ACTIVE'' "
		+ "AND (severe_lvl_high_ct > 0 " 
		+ "OR severe_lvl_mid_ct > 0 " 
		+ "OR severe_lvl_low_ct > 0 " 
		+ "OR severe_lvl_no_issue_ct > 0)";
	
	private final String get_total_closed_2 = "SELECT sum(clsd_ct) tot_clsd_ct " 
		+ "FROM	rabc_dash_presn a, rabc_cntrl_pt_alert b, rabc_alert_rule c " 
		+ "WHERE a.alert_rule = b.alert_rule  {0} "
		+ "AND b.alert_rule = c.alert_rule "
		+ "and UPPER(c.alert_rule_status) = ''ACTIVE'' "
		+ "AND clsd_ct > 0";
											
	private final String get_overallTotal_3 = "SELECT sum(severe_lvl_high_ct) severe_lvl_high_ct, " 
		+ "sum(severe_lvl_mid_ct) severe_lvl_mid_ct, " 
		+ "sum(severe_lvl_low_ct) severe_lvl_low_ct, "
		+ "sum(severe_lvl_no_issue_ct) tot_no_issue_ct, "
		+ "sum(warn_ct)	tot_warn_ct, "
		+ "sum(pend_ct)	tot_pend_ct "
		+ "FROM  rabc_cntrl_pt_alert a, rabc_dash_presn b, rabc_alert_rule c " 
		+ "{0} and a.cntrl_pt_cd = ''{1}'' "  
		+ "AND a.alert_rule = b.alert_rule "
		+ "AND a.alert_rule = c.alert_rule "
		+ "and UPPER(c.alert_rule_status) = ''ACTIVE'' "
		+ "AND (severe_lvl_high_ct > 0 " 
		+ "OR severe_lvl_mid_ct > 0 " 
		+ "OR severe_lvl_low_ct > 0 " 
		+ "OR severe_lvl_no_issue_ct > 0)";
	
	private final String get_overallTotal_closed_3 = "SELECT sum(clsd_ct) tot_clsd_ct "
		+ "FROM  rabc_cntrl_pt_alert a, rabc_dash_presn b, rabc_alert_rule c " 
		+ "{0} and a.cntrl_pt_cd = ''{1}'' "  
		+ "AND a.alert_rule = b.alert_rule "
		+ "AND a.alert_rule = c.alert_rule "
		+ "and UPPER(c.alert_rule_status) = ''ACTIVE'' "
		+ "AND clsd_ct > 0";
												
	private final String get_details_2 = "SELECT  a.cntrl_pt_cd, " 
		+ "sum(severe_lvl_high_ct) 		severe_lvl_high_ct, " 
		+ "sum(severe_lvl_mid_ct)		severe_lvl_mid_ct, " 
		+ "sum(severe_lvl_low_ct)		severe_lvl_low_ct, " 
		+ "sum(severe_lvl_no_issue_ct)	severe_lvl_no_issue_ct, "
		+ "sum(clsd_ct)	clsd_ct " 
		+ "FROM	rabc_cntrl_pt_alert a, rabc_dash_presn  b, rabc_alert_rule c " 
		+ "{0} "
		+ "AND a.alert_rule = b.alert_rule "
		+ "AND a.alert_rule = c.alert_rule "
		+ "AND UPPER(c.alert_rule_status) = ''ACTIVE'' "
		+ "AND (severe_lvl_high_ct > 0 " 
		+ "OR severe_lvl_mid_ct > 0 " 
		+ "OR severe_lvl_low_ct > 0 " 
		+ "OR severe_lvl_no_issue_ct > 0 "
		+ "OR clsd_ct > 0) "
		+ "GROUP BY a.cntrl_pt_cd " 
		+ "ORDER BY a.cntrl_pt_cd";
									
	private final String get_details_3 = "SELECT a.cntrl_pt_cd, a.alert_rule, "  
		+ "sum(severe_lvl_high_ct) 		severe_lvl_high_ct, " 
		+ "sum(severe_lvl_mid_ct)		severe_lvl_mid_ct, "
		+ "sum(severe_lvl_low_ct)		severe_lvl_low_ct, "
		+ "sum(clsd_ct)					clsd_ct " 
		+ "FROM	rabc_cntrl_pt_alert a, rabc_dash_presn  b, rabc_alert_rule c "
		+ "{0} "
		+ "AND a.cntrl_pt_cd = ''{1}'' " 
		+ "AND a.alert_rule = b.alert_rule "
		+ "AND a.alert_rule = c.alert_rule "
		+ "AND UPPER(c.alert_rule_status) = ''ACTIVE'' "
		+ "AND (severe_lvl_high_ct > 0 " 
		+ "OR severe_lvl_mid_ct > 0 " 
		+ "OR severe_lvl_low_ct > 0 "
		+ "OR clsd_ct > 0) "
		+ "GROUP BY a.cntrl_pt_cd, a.alert_rule " 
		+ "ORDER BY a.cntrl_pt_cd";
	
	private final String getDefaultLineCount = "SELECT LINE_CT FROM RABC_USER_DEFAULT_RPT_LINE WHERE USER_ID = ''{0}''";
	
	private final String getPreviousDay = "select max(proc_dt) from rabc_cycle_calendar where proc_dt < to_date(''{0}'', ''MM/dd/yyyy'') and proc_dt_ind is null";
	
	/**
	 * Synchronized method to return the instance of AlertDashboardService object.
	 * It checks the existance of the instance of AlertDashboardService and if it does not exists
	 * then creates one instance of AlertDashboardService and returns otherwise it returns the
	 * existing instance of AlertDashboardService.
	 * 
	 * @return AlertDashboardService
	 */
	public static synchronized AlertDashboardService getAlertDashboardService(){
		if (alertDashboardService == null) {
			alertDashboardService = new AlertDashboardService();
		}
		return alertDashboardService;
	}
	
	/**
	 * Method to return the list of cycles.
	 * It calls the CycleCalendarDAO to get the list of cycles.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return List
	 */
	protected List getCycleCalendarList(Connection connection, List failureList, List args ){
		List cycleCalendarList = new ArrayList();
		List cycleList = new ArrayList();
		CycleCalendar cycleCalendar= null;
		List cycleArgsList = new ArrayList();
		
		String startDate = (String) args.get(0);
		String endDate = (String) args.get(1);
		
		if((startDate != null && !"".equals(startDate)) && (endDate == null || "".equals(endDate))) {
			cycleArgsList.add("where proc_dt = to_date('" + startDate + "','MM/dd/yyyy')");
		} else if((startDate != null && !"".equals(startDate))  && (endDate != null && !"".equals(endDate)) && startDate.equals(endDate)) {
			cycleArgsList.add("where proc_dt  = to_date('" + startDate + "','MM/dd/yyyy')");
		} else if((startDate != null && !"".equals(startDate))  && (endDate != null && !"".equals(endDate)) && (!startDate.equals(endDate))) {
			cycleArgsList.add("where proc_dt  between  to_date('" + startDate + "','MM/dd/yyyy') and to_date('" + endDate + "','MM/dd/yyyy')");
		} else {
			cycleArgsList.add(" ");
		}
		
		cycleCalendarList = new CycleCalendarDAO().get(connection, failureList, cycleArgsList, query_getCycle);
		if (!failureList.isEmpty()) {
			return null;
		}
		
		if (cycleCalendarList != null) {
			int i = 0;
			int cycleCalendarListSize = cycleCalendarList.size();
			for (i=0; i<cycleCalendarListSize; i++) {
				cycleCalendar = (CycleCalendar)cycleCalendarList.get(i);
				cycleList.add(new Integer(cycleCalendar.getCycle()));
			}
		}
		return cycleList;
	}
	
	/**
	 * Method to return the list of the total count of all the alerts.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return List
	 */
	protected List getTotalList(Connection connection, List failureList, List args, String userId ) {
		List totalList = new ArrayList();
		String totalArgs= null;
		List totalArgsList = new ArrayList();
		String sqlStmt = null;
		Statement statement = null;
		ResultSet rs = null;
		String prepareStatement = null;
		Calendar calendar = Calendar.getInstance();
		
		/*
		 * Obtain the arguments from the argument list
		 */
		String startDate =(String) args.get(0);
		String endDate = (String) args.get(1);
		String dateOption =(String) args.get(2);
		String cntrlPtCode = (String) args.get(3);
		String dashboardType = (String) args.get(4);
		Date date2 = null;
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		
		try{
			if(dashboardType.equals("2")) {
				sqlStmt = get_total_2;
				
				/*
				 * Form the where clause argument
				 */
				if (endDate == null || "".equals(endDate)) {
					calendar.setTime(dateFormat.parse(startDate));
					calendar.add(Calendar.DAY_OF_YEAR, 1);
					date2 = new Date(calendar.getTimeInMillis());
					totalArgs = " AND	alert_rule_run_dt >= to_date('" + startDate + "','MM/dd/yyyy')";
					totalArgs += " AND	alert_rule_run_dt < to_date('" + dateFormat.format(date2) + "','MM/dd/yyyy')";
				} else if  (dateOption.equals("file")){
					totalArgs = " AND	proc_date >= to_date('" + startDate + "','MM/dd/yyyy')";
					totalArgs += " AND	proc_date <= to_date('" + endDate + "','MM/dd/yyyy')";	
				} else {
					totalArgs = " AND	alert_rule_run_dt >= to_date('" + startDate + "','MM/dd/yyyy')";
					totalArgs += " AND	alert_rule_run_dt <= to_date('" + endDate + "','MM/dd/yyyy')";
				}
				if (totalArgs != null){
					totalArgsList.add(totalArgs);
				} else {
					totalArgsList.add(" ");
				}
			} else if(dashboardType.equals("3")) {
				sqlStmt = get_overallTotal_3;
				
				/*
				 * Form the where clause argument
				 */
				if (endDate == null || "".equals(endDate)) {
					calendar.setTime(dateFormat.parse(startDate));
					calendar.add(Calendar.DAY_OF_YEAR, 1);
					date2 = new Date(calendar.getTimeInMillis());
					if (dateOption.equals("file")) { 
						totalArgs = " WHERE	proc_date >= to_date('" + startDate + "', 'MM/dd/yyyy')";
						totalArgs += " AND	proc_date < to_date('" + dateFormat.format(date2) + "', 'MM/dd/yyyy')";
					} else {
						totalArgs = " WHERE	alert_rule_run_dt >= to_date('" + startDate+"','MM/dd/yyyy')";
						totalArgs += " AND	alert_rule_run_dt < to_date('" + dateFormat.format(date2) + "','MM/dd/yyyy')";
					}
				} else {
					if (dateOption.equals("file")){
						totalArgs = "WHERE	proc_date >= to_date('" + startDate + "', 'MM/dd/yyyy')";
						totalArgs += " AND	proc_date <= to_date('" + endDate + "', 'MM/dd/yyyy')";
					} else {
						totalArgs = "WHERE	alert_rule_run_dt >= to_date('" + startDate + "', 'MM/dd/yyyy')";
						totalArgs += " AND	alert_rule_run_dt <= to_date('" + endDate + "', 'MM/dd/yyyy')";
					}
				}		
				if (totalArgs != null) {
					totalArgsList.add(totalArgs);
				} else {
					totalArgsList.add("");
				}
				totalArgsList.add(cntrlPtCode);
			}
			totalArgsList.add(userId);
			MessageFormat mf = new MessageFormat(sqlStmt);
			prepareStatement = mf.format((String[])totalArgsList.toArray(new String[totalArgsList.size()]));
			logger.debug("AlertDashboardService.getTotals() - Executing SQL statement: "+ prepareStatement);
			statement = connection.createStatement();
			rs = statement.executeQuery(prepareStatement);
			
			if (rs != null) {
				while(rs.next()) {
					totalList.add(new Integer(rs.getInt(1)));
					totalList.add(new Integer(rs.getInt(2)));
					totalList.add(new Integer(rs.getInt(3)));
					totalList.add(new Integer(rs.getInt(4)));
					totalList.add(new Integer(rs.getInt(5)));
					totalList.add(new Integer(rs.getInt(6)));
				}
			}
		} catch(SQLException sqle){
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sqle.getMessage(),sqle);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sqle));
		} catch(ParseException px) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC") + " Exception details: " + px.getMessage(), px);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC"), px));
		} finally{
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(statement, failureList, logger);
		}
		return totalList;
	}
	
	
	/**
	 * Method to return the list of the total count of the closed alerts.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return List
	 */
	protected List getTotalClosedList(Connection connection, List failureList, List args,String userId) {
		List totalList = new ArrayList();
		String totalArgs= null;
		List totalArgsList = new ArrayList();
		String sqlStmt = null;
		Statement statement = null;
		ResultSet rs = null;
		String prepareStatement = null;
		Calendar calendar = Calendar.getInstance();
		
		/*
		 * Obtain the arguments from the argument list
		 */
		String startDate =(String) args.get(0);
		String endDate = (String) args.get(1);
		String dateOption =(String) args.get(2);
		String cntrlPtCode = (String) args.get(3);
		String dashboardType = (String) args.get(4);
		Date date2 = null;
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		
		try{
			if(dashboardType.equals("2")) {
				sqlStmt = get_total_closed_2;
				
				/*
				 * Form the where clause argument
				 */
				if (endDate == null || "".equals(endDate)) {
					calendar.setTime(dateFormat.parse(startDate));
					calendar.add(Calendar.DAY_OF_YEAR, 1);
					date2 = new Date(calendar.getTimeInMillis());
					totalArgs = " AND	alert_rule_run_dt >= to_date('" + startDate + "','MM/dd/yyyy')";
					totalArgs += " AND	alert_rule_run_dt < to_date('" + dateFormat.format(date2) + "','MM/dd/yyyy')";
				} else if  (dateOption.equals("file")){
					totalArgs = " AND	proc_date >= to_date('" + startDate + "','MM/dd/yyyy')";
					totalArgs += " AND	proc_date <= to_date('" + endDate + "','MM/dd/yyyy')";	
				} else {
					totalArgs = " AND	alert_rule_run_dt >= to_date('" + startDate + "','MM/dd/yyyy')";
					totalArgs += " AND	alert_rule_run_dt <= to_date('" + endDate + "','MM/dd/yyyy')";
				}
				if (totalArgs != null){
					totalArgsList.add(totalArgs);
				} else {
					totalArgsList.add(" ");
				}
			} else if(dashboardType.equals("3")) {
				sqlStmt = get_overallTotal_closed_3;
				
				/*
				 * Form the where clause argument
				 */
				if (endDate == null || "".equals(endDate)) {
					calendar.setTime(dateFormat.parse(startDate));
					calendar.add(Calendar.DAY_OF_YEAR, 1);
					date2 = new Date(calendar.getTimeInMillis());
					if (dateOption.equals("file")) { 
						totalArgs = " WHERE	proc_date >= to_date('" + startDate + "', 'MM/dd/yyyy')";
						totalArgs += " AND	proc_date < to_date('" + dateFormat.format(date2) + "', 'MM/dd/yyyy')";
					} else {
						totalArgs = " WHERE	alert_rule_run_dt >= to_date('" + startDate+"','MM/dd/yyyy')";
						totalArgs += " AND	alert_rule_run_dt < to_date('" + dateFormat.format(date2) + "','MM/dd/yyyy')";
					}
				} else {
					if (dateOption.equals("file")){
						totalArgs = "WHERE	proc_date >= to_date('" + startDate + "', 'MM/dd/yyyy')";
						totalArgs += " AND	proc_date <= to_date('" + endDate + "', 'MM/dd/yyyy')";
					} else {
						totalArgs = "WHERE	alert_rule_run_dt >= to_date('" + startDate + "', 'MM/dd/yyyy')";
						totalArgs += " AND	alert_rule_run_dt <= to_date('" + endDate + "', 'MM/dd/yyyy')";
					}
				}		
				if (totalArgs != null) {
					totalArgsList.add(totalArgs);
				} else {
					totalArgsList.add("");
				}
				totalArgsList.add(cntrlPtCode);
			}
			totalArgsList.add(userId);
			MessageFormat mf = new MessageFormat(sqlStmt);
			prepareStatement = mf.format((String[])totalArgsList.toArray(new String[totalArgsList.size()]));
			logger.debug("AlertDashboardService.getTotals() - Executing SQL statement: "+ prepareStatement);
			statement = connection.createStatement();
			rs = statement.executeQuery(prepareStatement);
			
			/*
			 * Here we are not specifying the column names since we are actually using aliases
			 */
			if (rs != null) {
				while(rs.next()) {
					totalList.add(new Integer(rs.getInt(1)));
				}
			}
		} catch(SQLException sqle){
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sqle.getMessage(), sqle);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sqle));
		} catch(ParseException px) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC") + " Exception details: " + px.getMessage(), px);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC"), px));
		} finally{
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(statement, failureList, logger);
		}
		return totalList;
	}
	
	/**
	 * A method to return the control point description of given control point code
	 * 
	 * @param connection
	 * @param failureList
	 * @param cntrlPtCode
	 * @return String
	 */
	protected String queryConvertForDisplay(Connection connection, List failureList, String cntrlPtCode){
		String cntrlPtDesc = null;
		Statement statement = null;
		ResultSet rs = null;
		String prepareStatement = null;
		List cntrlPtCodeList = new ArrayList();
		cntrlPtCodeList.add(cntrlPtCode);
		try{
			MessageFormat mf = new MessageFormat(query_convertForDisplay);
			prepareStatement = mf.format((String[])cntrlPtCodeList.toArray(new String[cntrlPtCodeList.size()]));
			logger.debug("AlertDashboardService.queryConvertForDisplay() - Executing SQL statement: "+ prepareStatement);
			statement = connection.createStatement();
			rs = statement.executeQuery(prepareStatement);

			if (rs != null && rs.next()) {
				cntrlPtDesc = rs.getString(1);
			}
		} catch(SQLException sqle) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sqle.getMessage(), sqle);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sqle));
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(statement, failureList, logger);
		}
		return cntrlPtDesc;
	}
	
	/**
	 * A method to return the List of AlertDashboard objects 
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param progressBar
	 * @return List
	 */
	protected List getAlertDashboardList(Connection connection, List failureList, List args, ProgressBar progressBar, String userId) {
		AlertDashboard alertDashboard = new AlertDashboard();
		List alertDashboardList = new ArrayList();
		String dashboardType = (String) args.get(4);
		int i = 0;
		int j = 0;
		
		int size = 0;
		List tempList = null;
		HashMap highLevelWiseWarningMap = new HashMap();
		HashMap mediumLevelWiseWarningMap = new HashMap();
		HashMap lowLevelWiseWarningMap = new HashMap();
		HashMap noneLevelWiseWarningMap = new HashMap();
		HashMap notRunLevelWiseWarningMap = new HashMap();
		HashMap warningStatusLevelWiseWarningMap = new HashMap();
		HashMap pendingStatusLevelWiseWarningMap = new HashMap();
		HashMap closedStatusLevelWiseWarningMap = new HashMap();
		String currentDashboardKey = null;
		String previousDashboardKey = null;
		
		List levelWiseWarningList = new ArrayList();
		LevelWiseWarnings highLevelWiseWarnings = null;
		LevelWiseWarnings mediumLevelWiseWarnings = null;
		LevelWiseWarnings lowLevelWiseWarnings = null;
		LevelWiseWarnings noneLevelWiseWarnings = null;
		LevelWiseWarnings notRunLevelWiseWarnings = null;
		LevelWiseWarnings warningStatusWiseWarnings = null;
		LevelWiseWarnings pendingStatusWiseWarnings = null;
		LevelWiseWarnings closedStatusWiseWarnings = null;
		int count = 0;
		
		/*
		 * Dashboard objects constructed differently depending on whether the request is for page 2 or 3
		 */
		if(dashboardType.equals("2")) {
			List cntrlPtTransList = getCntrlPts(connection, failureList, args);
			if ((cntrlPtTransList != null) && (cntrlPtTransList.size() > 0)) {
				/*
				 * Call the private method  getControlPoints(cntrlPtTransList) to get a string that contains
				 * all the distinct control points seperated by comma of the returned list control points.
				 */
				String controlPoints = getControlPoints(cntrlPtTransList);
				if (controlPoints.equals("")) {
					controlPoints = "''";
				} else {
					controlPoints = controlPoints.substring(0, controlPoints.length()-1);
				}
				List args1 = new ArrayList();
				for (i=0; i<=4; i++) {
					args1.add(args.get(i));
				}
				args1.add(controlPoints);
				
				List highLevelList = DivisionWiseAlertSummaryService.getDivisionWiseAlertSummaryService().getHighLevel(connection,failureList,args1,userId);
				if (!failureList.isEmpty()) {
					return null;
				}
				if (highLevelList != null) {
					tempList = new ArrayList();
					size = highLevelList.size();
					for (i=0; i<size; i++) {
						currentDashboardKey = ((DivisionWiseAlertSummary)highLevelList.get(i)).getDashboardKey();
						if ((tempList.size() > 0) && (!currentDashboardKey.equals(previousDashboardKey))) {
							highLevelWiseWarningMap.put(previousDashboardKey, tempList);
							tempList = new ArrayList();
						}
						tempList.add((DivisionWiseAlertSummary)highLevelList.get(i));
						previousDashboardKey = currentDashboardKey;
					}
					highLevelWiseWarningMap.put(previousDashboardKey, tempList);
				}
				
				progressBar.setProgressPercent(progressBar.getPercent() + 10);
				
				List mediumLevelList = DivisionWiseAlertSummaryService.getDivisionWiseAlertSummaryService().getMediumLevel(connection,failureList,args1,userId);
				if (!failureList.isEmpty()) {
					return null;
				}
				if (mediumLevelList != null) {
					tempList = new ArrayList();
					size = mediumLevelList.size();
					for (i=0; i<size; i++) {
						currentDashboardKey = ((DivisionWiseAlertSummary)mediumLevelList.get(i)).getDashboardKey();
						if ((tempList.size() > 0) && (!currentDashboardKey.equals(previousDashboardKey))) {
							mediumLevelWiseWarningMap.put(previousDashboardKey, tempList);
							tempList = new ArrayList();
						}
						tempList.add((DivisionWiseAlertSummary)mediumLevelList.get(i));
						previousDashboardKey = currentDashboardKey;
					}
					mediumLevelWiseWarningMap.put(previousDashboardKey, tempList);
				}
				
				progressBar.setProgressPercent(progressBar.getPercent() + 10);
				
				List lowLevelList = DivisionWiseAlertSummaryService.getDivisionWiseAlertSummaryService().getLowLevel(connection,failureList,args1,userId);
				if (!failureList.isEmpty()) {
					return null;
				}
				if (lowLevelList != null) {
					tempList = new ArrayList();
					size = lowLevelList.size();
					for (i=0; i<size; i++) {
						currentDashboardKey = ((DivisionWiseAlertSummary)lowLevelList.get(i)).getDashboardKey();
						if ((tempList.size() > 0) && (!currentDashboardKey.equals(previousDashboardKey))) {
							lowLevelWiseWarningMap.put(previousDashboardKey, tempList);
							tempList = new ArrayList();
						}
						tempList.add((DivisionWiseAlertSummary)lowLevelList.get(i));
						previousDashboardKey = currentDashboardKey;
					}
					lowLevelWiseWarningMap.put(previousDashboardKey, tempList);
				}
				
				progressBar.setProgressPercent(progressBar.getPercent() + 10);
				
				List noneList = DivisionWiseAlertSummaryService.getDivisionWiseAlertSummaryService().getNoIssueCnt(connection,failureList,args1,userId);
				if (!failureList.isEmpty()) {
					return null;
				}
				if (noneList != null) {
					tempList = new ArrayList();
					size = noneList.size();
					for (i=0; i<size; i++) {
						currentDashboardKey = ((DivisionWiseAlertSummary)noneList.get(i)).getDashboardKey();
						if ((tempList.size() > 0) && (!currentDashboardKey.equals(previousDashboardKey))) {
							noneLevelWiseWarningMap.put(previousDashboardKey, tempList);
							tempList = new ArrayList();
						}
						tempList.add((DivisionWiseAlertSummary)noneList.get(i));
						previousDashboardKey = currentDashboardKey;
					}
					noneLevelWiseWarningMap.put(previousDashboardKey, tempList);
				}
				
				progressBar.setProgressPercent(progressBar.getPercent() + 10);
				
				List warningStatusList = DivisionWiseAlertSummaryService.getDivisionWiseAlertSummaryService().getWarningStatus(connection,failureList,args1,userId);
				if (!failureList.isEmpty()) {
					return null;
				}
				if (warningStatusList != null) {
					tempList = new ArrayList();
					size = warningStatusList.size();
					for (i=0; i<size; i++) {
						currentDashboardKey = ((DivisionWiseAlertSummary)warningStatusList.get(i)).getDashboardKey();
						if ((tempList.size() > 0) && (!currentDashboardKey.equals(previousDashboardKey))) {
							warningStatusLevelWiseWarningMap.put(previousDashboardKey, tempList);
							tempList = new ArrayList();
						}
						tempList.add((DivisionWiseAlertSummary)warningStatusList.get(i));
						previousDashboardKey = currentDashboardKey;
					}
					warningStatusLevelWiseWarningMap.put(previousDashboardKey, tempList);
				}
				
				progressBar.setProgressPercent(progressBar.getPercent() + 10);
				
				List pendingStatusList = DivisionWiseAlertSummaryService.getDivisionWiseAlertSummaryService().getPendingStatus(connection,failureList,args1, userId);
				if (!failureList.isEmpty()) {
					return null;
				}
				if (pendingStatusList != null) {
					tempList = new ArrayList();
					size = pendingStatusList.size();
					for (i=0; i<size; i++) {
						currentDashboardKey = ((DivisionWiseAlertSummary)pendingStatusList.get(i)).getDashboardKey();
						if ((tempList.size() > 0) && (!currentDashboardKey.equals(previousDashboardKey))) {
							pendingStatusLevelWiseWarningMap.put(previousDashboardKey, tempList);
							tempList = new ArrayList();
						}
						tempList.add((DivisionWiseAlertSummary)pendingStatusList.get(i));
						previousDashboardKey = currentDashboardKey;
					}
					pendingStatusLevelWiseWarningMap.put(previousDashboardKey, tempList);
				}
				
				List closedStatusList = DivisionWiseAlertSummaryService.getDivisionWiseAlertSummaryService().getClosedStatus(connection,failureList,args1, userId);
				if (!failureList.isEmpty()) {
					return null;
				}
				if (closedStatusList != null) {
					tempList = new ArrayList();
					size = closedStatusList.size();
					for (i=0; i<size; i++) {
						currentDashboardKey = ((DivisionWiseAlertSummary)closedStatusList.get(i)).getDashboardKey();
						if ((tempList.size() > 0) && (!currentDashboardKey.equals(previousDashboardKey))) {
							closedStatusLevelWiseWarningMap.put(previousDashboardKey, tempList);
							tempList = new ArrayList();
						}
						tempList.add((DivisionWiseAlertSummary)closedStatusList.get(i));
						previousDashboardKey = currentDashboardKey;
					}
					closedStatusLevelWiseWarningMap.put(previousDashboardKey, tempList);
				}
				
				progressBar.setProgressPercent(progressBar.getPercent() + 10);
				
				List cntrlPtLinkList = getDetails(connection,failureList,args);
				int cntrlPtTransListSize = cntrlPtTransList.size();
				PickList pickList = null;
				for (i=0; i<cntrlPtTransListSize; i++) {
					levelWiseWarningList = new ArrayList();
					highLevelWiseWarnings = new LevelWiseWarnings();
					mediumLevelWiseWarnings = new LevelWiseWarnings();
					lowLevelWiseWarnings = new LevelWiseWarnings();
					noneLevelWiseWarnings = new LevelWiseWarnings();
					notRunLevelWiseWarnings = new LevelWiseWarnings();
					warningStatusWiseWarnings = new LevelWiseWarnings();
					pendingStatusWiseWarnings = new LevelWiseWarnings();
					closedStatusWiseWarnings = new LevelWiseWarnings();
					
					pickList = (PickList)cntrlPtTransList.get(i);
					alertDashboard = new AlertDashboard();
					alertDashboard.setType(pickList.getValue2() + " - " + pickList.getValue1());
					alertDashboard.setProcessPointCode(pickList.getValue2());
					alertDashboard.setProcessPoint(RABCConstantsLists.getRABCConstantsLists().getText(pickList.getValue2(), false));
					alertDashboard.setControlPointCode(pickList.getKey());
					alertDashboard.setCntrlPtDesc(RABCConstantsLists.getRABCConstantsLists().getText(pickList.getValue1(), false));
					alertDashboard.setMouseOver(RABCConstantsLists.getRABCConstantsLists().getText(pickList.getValue1().replace('_', ' '), true));
					
					/*
					 * Check whether you need to show the link to go to page 3
					 */
					alertDashboard.setShowLink(cntrlPtLinkList.contains(pickList.getKey()));
					
					if (highLevelWiseWarningMap.containsKey(pickList.getKey())) {
						highLevelList = (List) highLevelWiseWarningMap.get(pickList.getKey());
						if (highLevelList != null) {
							size = highLevelList.size();
							count = 0;
							for (j=0; j<size; j++){
								highLevelWiseWarnings.addDivisionWiseAlertSummary((DivisionWiseAlertSummary)highLevelList.get(j));
								count += ((DivisionWiseAlertSummary)highLevelList.get(j)).getCount();
							}
							highLevelWiseWarnings.setCount(count);
						}
					}
					levelWiseWarningList.add(highLevelWiseWarnings);
					
					if (mediumLevelWiseWarningMap.containsKey(pickList.getKey())) {
						mediumLevelList = (List) mediumLevelWiseWarningMap.get(pickList.getKey());
						if (mediumLevelList != null) {
							size = mediumLevelList.size();
							count = 0;
							for (j=0; j<size; j++){
								mediumLevelWiseWarnings.addDivisionWiseAlertSummary((DivisionWiseAlertSummary)mediumLevelList.get(j));
								count += ((DivisionWiseAlertSummary)mediumLevelList.get(j)).getCount();
							}
							mediumLevelWiseWarnings.setCount(count);
						}					
					}
					levelWiseWarningList.add(mediumLevelWiseWarnings);
					
					if (lowLevelWiseWarningMap.containsKey(pickList.getKey())) {
						lowLevelList = (List) lowLevelWiseWarningMap.get(pickList.getKey());
						if (lowLevelList != null) {
							size = lowLevelList.size();
							count = 0;
							for (j=0; j<size; j++){
								lowLevelWiseWarnings.addDivisionWiseAlertSummary((DivisionWiseAlertSummary)lowLevelList.get(j));
								count += ((DivisionWiseAlertSummary)lowLevelList.get(j)).getCount();
							}
							lowLevelWiseWarnings.setCount(count);
						}
					}
					levelWiseWarningList.add(lowLevelWiseWarnings);
					
					if (noneLevelWiseWarningMap.containsKey(pickList.getKey())) {
						noneList = (List) noneLevelWiseWarningMap.get(pickList.getKey());
						if (noneList != null) {
							size = noneList.size();
							count = 0;
							for (j=0; j<size; j++){
								noneLevelWiseWarnings.addDivisionWiseAlertSummary((DivisionWiseAlertSummary)noneList.get(j));
								count += ((DivisionWiseAlertSummary)noneList.get(j)).getCount();
							}
							noneLevelWiseWarnings.setCount(count);
						}
					}
					levelWiseWarningList.add(noneLevelWiseWarnings);
					
					if (warningStatusLevelWiseWarningMap.containsKey(pickList.getKey())) {
						warningStatusList = (List) warningStatusLevelWiseWarningMap.get(pickList.getKey());
						if (warningStatusList != null) {
							size = warningStatusList.size();
							count = 0;
							for (j=0; j<size; j++){
								warningStatusWiseWarnings.addDivisionWiseAlertSummary((DivisionWiseAlertSummary)warningStatusList.get(j));
								count += ((DivisionWiseAlertSummary)warningStatusList.get(j)).getCount();
							}
							warningStatusWiseWarnings.setCount(count);
						}
					}
					levelWiseWarningList.add(warningStatusWiseWarnings);
					
					if (pendingStatusLevelWiseWarningMap.containsKey(pickList.getKey())) {
						pendingStatusList = (List) pendingStatusLevelWiseWarningMap.get(pickList.getKey());
						if (pendingStatusList != null) {
							size = pendingStatusList.size();
							count = 0;
							for (j=0; j<size; j++){
								pendingStatusWiseWarnings.addDivisionWiseAlertSummary((DivisionWiseAlertSummary)pendingStatusList.get(j));
								count += ((DivisionWiseAlertSummary)pendingStatusList.get(j)).getCount();
							}
							pendingStatusWiseWarnings.setCount(count);
						}
					}
					levelWiseWarningList.add(pendingStatusWiseWarnings);
					
					if (closedStatusLevelWiseWarningMap.containsKey(pickList.getKey())) {
						closedStatusList = (List) closedStatusLevelWiseWarningMap.get(pickList.getKey());
						if (closedStatusList != null) {
							size = closedStatusList.size();
							count = 0;
							for (j=0; j<size; j++){
								closedStatusWiseWarnings.addDivisionWiseAlertSummary((DivisionWiseAlertSummary)closedStatusList.get(j));
								count += ((DivisionWiseAlertSummary)closedStatusList.get(j)).getCount();
							}
							closedStatusWiseWarnings.setCount(count);
						}
					}
					levelWiseWarningList.add(closedStatusWiseWarnings);
					
					if (levelWiseWarningList != null) {
						int levelWiseWarningListSize = levelWiseWarningList.size();
						for (j=0; j<levelWiseWarningListSize; j++){
							alertDashboard.addLevelWiseWarning((LevelWiseWarnings)levelWiseWarningList.get(j));
						}
					}
					
					/*
					 * Add dashboard object to list
					 */
					alertDashboardList.add(alertDashboard);
				}
			}
		} else 	if(dashboardType.equals("3")) {
			List alertsList = getAlerts(connection,failureList,args,userId);
			if ((alertsList != null) && (alertsList.size() > 0)) {
				/*
				 * Call the private method  getControlPoints(cntrlPtTransList) to get a string that contains
				 * all the distinct control points seperated by comma of the returned list control points.
				 */
				String alertRules = getAlertRules(alertsList);
				if (alertRules.equals("")) {
					alertRules = "''";
				} else {
					alertRules = alertRules.substring(0, alertRules.length()-1);
				}
				List args1 = new ArrayList();
				for (i=0; i<=4; i++) {
					args1.add(args.get(i));
				}
				args1.add(alertRules);
				
				List highLevelList = DivisionWiseAlertSummaryService.getDivisionWiseAlertSummaryService().getHighLevel(connection,failureList,args1,userId);
				if (!failureList.isEmpty()) {
					return null;
				}
				if (highLevelList != null) {
					tempList = new ArrayList();
					size = highLevelList.size();
					for (i=0; i<size; i++) {
						currentDashboardKey = ((DivisionWiseAlertSummary)highLevelList.get(i)).getDashboardKey();
						if ((tempList.size() > 0) && (!currentDashboardKey.equals(previousDashboardKey))) {
							highLevelWiseWarningMap.put(previousDashboardKey, tempList);
							tempList = new ArrayList();
						}
						tempList.add((DivisionWiseAlertSummary)highLevelList.get(i));
						previousDashboardKey = currentDashboardKey;
					}
					highLevelWiseWarningMap.put(previousDashboardKey, tempList);
				}
				
				progressBar.setProgressPercent(progressBar.getPercent() + 10);
				
				List mediumLevelList = DivisionWiseAlertSummaryService.getDivisionWiseAlertSummaryService().getMediumLevel(connection,failureList,args1,userId);
				if (!failureList.isEmpty()) {
					return null;
				}
				if (mediumLevelList != null) {
					tempList = new ArrayList();
					size = mediumLevelList.size();
					for (i=0; i<size; i++) {
						currentDashboardKey = ((DivisionWiseAlertSummary)mediumLevelList.get(i)).getDashboardKey();
						if ((tempList.size() > 0) && (!currentDashboardKey.equals(previousDashboardKey))) {
							mediumLevelWiseWarningMap.put(previousDashboardKey, tempList);
							tempList = new ArrayList();
						}
						tempList.add((DivisionWiseAlertSummary)mediumLevelList.get(i));
						previousDashboardKey = currentDashboardKey;
					}
					mediumLevelWiseWarningMap.put(previousDashboardKey, tempList);
				}
				
				progressBar.setProgressPercent(progressBar.getPercent() + 10);
				
				List lowLevelList = DivisionWiseAlertSummaryService.getDivisionWiseAlertSummaryService().getLowLevel(connection,failureList,args1,userId);
				if (!failureList.isEmpty()) {
					return null;
				}
				if (lowLevelList != null) {
					tempList = new ArrayList();
					size = lowLevelList.size();
					for (i=0; i<size; i++) {
						currentDashboardKey = ((DivisionWiseAlertSummary)lowLevelList.get(i)).getDashboardKey();
						if ((tempList.size() > 0) && (!currentDashboardKey.equals(previousDashboardKey))) {
							lowLevelWiseWarningMap.put(previousDashboardKey, tempList);
							tempList = new ArrayList();
						}
						tempList.add((DivisionWiseAlertSummary)lowLevelList.get(i));
						previousDashboardKey = currentDashboardKey;
					}
					lowLevelWiseWarningMap.put(previousDashboardKey, tempList);
				}
				
				progressBar.setProgressPercent(progressBar.getPercent() + 10);
				
				List noneList = DivisionWiseAlertSummaryService.getDivisionWiseAlertSummaryService().getNoIssueCnt(connection,failureList,args1,userId);
				if (!failureList.isEmpty()) {
					return null;
				}
				if (noneList != null) {
					tempList = new ArrayList();
					size = noneList.size();
					for (i=0; i<size; i++) {
						currentDashboardKey = ((DivisionWiseAlertSummary)noneList.get(i)).getDashboardKey();
						if ((tempList.size() > 0) && (!currentDashboardKey.equals(previousDashboardKey))) {
							noneLevelWiseWarningMap.put(previousDashboardKey, tempList);
							tempList = new ArrayList();
						}
						tempList.add((DivisionWiseAlertSummary)noneList.get(i));
						previousDashboardKey = currentDashboardKey;
					}
					noneLevelWiseWarningMap.put(previousDashboardKey, tempList);
				}
				
				List notRunList = DivisionWiseAlertSummaryService.getDivisionWiseAlertSummaryService().getNotRun(connection,failureList,args1);
				if (!failureList.isEmpty()) {
					return null;
				}
				if (notRunList != null) {
					tempList = new ArrayList();
					size = notRunList.size();
					for (i=0; i<size; i++) {
						currentDashboardKey = ((DivisionWiseAlertSummary)notRunList.get(i)).getDashboardKey();
						if ((tempList.size() > 0) && (!currentDashboardKey.equals(previousDashboardKey))) {
							notRunLevelWiseWarningMap.put(previousDashboardKey, tempList);
							tempList = new ArrayList();
						}
						tempList.add((DivisionWiseAlertSummary)notRunList.get(i));
						previousDashboardKey = currentDashboardKey;
					}
					notRunLevelWiseWarningMap.put(previousDashboardKey, tempList);
				}
				
				progressBar.setProgressPercent(progressBar.getPercent() + 10);
				
				List warningStatusList = DivisionWiseAlertSummaryService.getDivisionWiseAlertSummaryService().getWarningStatus(connection,failureList,args1,userId);
				if (!failureList.isEmpty()) {
					return null;
				}
				if (warningStatusList != null) {
					tempList = new ArrayList();
					size = warningStatusList.size();
					for (i=0; i<size; i++) {
						currentDashboardKey = ((DivisionWiseAlertSummary)warningStatusList.get(i)).getDashboardKey();
						if ((tempList.size() > 0) && (!currentDashboardKey.equals(previousDashboardKey))) {
							warningStatusLevelWiseWarningMap.put(previousDashboardKey, tempList);
							tempList = new ArrayList();
						}
						tempList.add((DivisionWiseAlertSummary)warningStatusList.get(i));
						previousDashboardKey = currentDashboardKey;
					}
					warningStatusLevelWiseWarningMap.put(previousDashboardKey, tempList);
				}
				
				progressBar.setProgressPercent(progressBar.getPercent() + 10);
				
				List pendingStatusList = DivisionWiseAlertSummaryService.getDivisionWiseAlertSummaryService().getPendingStatus(connection,failureList,args1, userId);
				if (!failureList.isEmpty()) {
					return null;
				}
				if (pendingStatusList != null) {
					tempList = new ArrayList();
					size = pendingStatusList.size();
					for (i=0; i<size; i++) {
						currentDashboardKey = ((DivisionWiseAlertSummary)pendingStatusList.get(i)).getDashboardKey();
						if ((tempList.size() > 0) && (!currentDashboardKey.equals(previousDashboardKey))) {
							pendingStatusLevelWiseWarningMap.put(previousDashboardKey, tempList);
							tempList = new ArrayList();
						}
						tempList.add((DivisionWiseAlertSummary)pendingStatusList.get(i));
						previousDashboardKey = currentDashboardKey;
					}
					pendingStatusLevelWiseWarningMap.put(previousDashboardKey, tempList);
				}
				
				List closedStatusList = DivisionWiseAlertSummaryService.getDivisionWiseAlertSummaryService().getClosedStatus(connection,failureList,args1, userId);
				if (!failureList.isEmpty()) {
					return null;
				}
				if (closedStatusList != null) {
					tempList = new ArrayList();
					size = closedStatusList.size();
					for (i=0; i<size; i++) {
						currentDashboardKey = ((DivisionWiseAlertSummary)closedStatusList.get(i)).getDashboardKey();
						if ((tempList.size() > 0) && (!currentDashboardKey.equals(previousDashboardKey))) {
							closedStatusLevelWiseWarningMap.put(previousDashboardKey, tempList);
							tempList = new ArrayList();
						}
						tempList.add((DivisionWiseAlertSummary)closedStatusList.get(i));
						previousDashboardKey = currentDashboardKey;
					}
					closedStatusLevelWiseWarningMap.put(previousDashboardKey, tempList);
				}
				
				progressBar.setProgressPercent(progressBar.getPercent() + 10);
				
				List alertRuleLinkList = getDetails(connection,failureList,args);
				int alertsListSize = alertsList.size();
				String alertRule = null;
				for(i=0; i<alertsListSize; i++) {
					levelWiseWarningList = new ArrayList();
					highLevelWiseWarnings = new LevelWiseWarnings();
					mediumLevelWiseWarnings = new LevelWiseWarnings();
					lowLevelWiseWarnings = new LevelWiseWarnings();
					noneLevelWiseWarnings = new LevelWiseWarnings();
					notRunLevelWiseWarnings = new LevelWiseWarnings();
					warningStatusWiseWarnings = new LevelWiseWarnings();
					pendingStatusWiseWarnings = new LevelWiseWarnings();
					closedStatusWiseWarnings = new LevelWiseWarnings();
					
					alertRule = (String)alertsList.get(i);
					alertDashboard = new AlertDashboard();
					alertDashboard.setType(alertRule);
					
					/*
					 * Check whether you need to show the link to go to alert report detail page
					 */
					alertDashboard.setShowLink(alertRuleLinkList.contains(alertRule));
					
					if (highLevelWiseWarningMap.containsKey(alertRule)) {
						highLevelList = (List) highLevelWiseWarningMap.get(alertRule);
						if (highLevelList != null) {
							size = highLevelList.size();
							count = 0;
							for (j=0; j<size; j++){
								highLevelWiseWarnings.addDivisionWiseAlertSummary((DivisionWiseAlertSummary)highLevelList.get(j));
								count += ((DivisionWiseAlertSummary)highLevelList.get(j)).getCount();
							}
							highLevelWiseWarnings.setCount(count);
						}
					}
					levelWiseWarningList.add(highLevelWiseWarnings);
					
					if (mediumLevelWiseWarningMap.containsKey(alertRule)) {
						mediumLevelList = (List) mediumLevelWiseWarningMap.get(alertRule);
						if (mediumLevelList != null) {
							size = mediumLevelList.size();
							count = 0;
							for (j=0; j<size; j++){
								mediumLevelWiseWarnings.addDivisionWiseAlertSummary((DivisionWiseAlertSummary)mediumLevelList.get(j));
								count += ((DivisionWiseAlertSummary)mediumLevelList.get(j)).getCount();
							}
							mediumLevelWiseWarnings.setCount(count);
						}					
					}
					levelWiseWarningList.add(mediumLevelWiseWarnings);
					
					if (lowLevelWiseWarningMap.containsKey(alertRule)) {
						lowLevelList = (List) lowLevelWiseWarningMap.get(alertRule);
						if (lowLevelList != null) {
							size = lowLevelList.size();
							count = 0;
							for (j=0; j<size; j++){
								lowLevelWiseWarnings.addDivisionWiseAlertSummary((DivisionWiseAlertSummary)lowLevelList.get(j));
								count += ((DivisionWiseAlertSummary)lowLevelList.get(j)).getCount();
							}
							lowLevelWiseWarnings.setCount(count);
						}
					}
					levelWiseWarningList.add(lowLevelWiseWarnings);
					
					if (noneLevelWiseWarningMap.containsKey(alertRule)) {
						noneList = (List) noneLevelWiseWarningMap.get(alertRule);
						if (noneList != null) {
							size = noneList.size();
							count = 0;
							for (j=0; j<size; j++){
								noneLevelWiseWarnings.addDivisionWiseAlertSummary((DivisionWiseAlertSummary)noneList.get(j));
								count += ((DivisionWiseAlertSummary)noneList.get(j)).getCount();
							}
							noneLevelWiseWarnings.setCount(count);
						}
					}
					levelWiseWarningList.add(noneLevelWiseWarnings);
					
					if (notRunLevelWiseWarningMap.containsKey(alertRule)) {
						notRunList = (List) notRunLevelWiseWarningMap.get(alertRule);
						if (notRunList != null) {
							size = notRunList.size();
							for (j=0; j<size; j++){
								notRunLevelWiseWarnings.addDivisionWiseAlertSummary((DivisionWiseAlertSummary)notRunList.get(j));
							}
						}
					}
					levelWiseWarningList.add(notRunLevelWiseWarnings);
					
					if (warningStatusLevelWiseWarningMap.containsKey(alertRule)) {
						warningStatusList = (List) warningStatusLevelWiseWarningMap.get(alertRule);
						if (warningStatusList != null) {
							size = warningStatusList.size();
							count = 0;
							for (j=0; j<size; j++){
								warningStatusWiseWarnings.addDivisionWiseAlertSummary((DivisionWiseAlertSummary)warningStatusList.get(j));
								count += ((DivisionWiseAlertSummary)warningStatusList.get(j)).getCount();
							}
							warningStatusWiseWarnings.setCount(count);
						}
					}
					levelWiseWarningList.add(warningStatusWiseWarnings);
					
					if (pendingStatusLevelWiseWarningMap.containsKey(alertRule)) {
						pendingStatusList = (List) pendingStatusLevelWiseWarningMap.get(alertRule);
						if (pendingStatusList != null) {
							size = pendingStatusList.size();
							count = 0;
							for (j=0; j<size; j++){
								pendingStatusWiseWarnings.addDivisionWiseAlertSummary((DivisionWiseAlertSummary)pendingStatusList.get(j));
								count += ((DivisionWiseAlertSummary)pendingStatusList.get(j)).getCount();
							}
							pendingStatusWiseWarnings.setCount(count);
						}
					}
					levelWiseWarningList.add(pendingStatusWiseWarnings);
					
					if (closedStatusLevelWiseWarningMap.containsKey(alertRule)) {
						closedStatusList = (List) closedStatusLevelWiseWarningMap.get(alertRule);
						if (closedStatusList != null) {
							size = closedStatusList.size();
							count = 0;
							for (j=0; j<size; j++){
								closedStatusWiseWarnings.addDivisionWiseAlertSummary((DivisionWiseAlertSummary)closedStatusList.get(j));
								count += ((DivisionWiseAlertSummary)closedStatusList.get(j)).getCount();
							}
							closedStatusWiseWarnings.setCount(count);
						}
					}
					levelWiseWarningList.add(closedStatusWiseWarnings);
					
					if (levelWiseWarningList != null) {
						int levelWiseWarningListSize = levelWiseWarningList.size();
						for (j=0; j<levelWiseWarningListSize; j++){
							alertDashboard.addLevelWiseWarning((LevelWiseWarnings)levelWiseWarningList.get(j));
						}
					}
					
					alertDashboardList.add(alertDashboard);
				}
			}
		}
		return alertDashboardList;
	}

	/**
	 * Public method to return the total count of alert rules.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return int
	 */
	public int getTotalAlertRules(Connection connection, List failureList, List args, String userId) {
		int totalAlertRules = 0;
		List alertsArgsList = new ArrayList();
		String alertsArgs = null;		
		String startDate =(String) args.get(0);
		String endDate =(String) args.get(1);
		String dateOption =(String) args.get(2);
		String cntrlPtCode = (String) args.get(3);
		
		Statement statement = null;
		ResultSet rs = null;
		String prepareStatement = null;
		
		if (cntrlPtCode != null){
			alertsArgs = " where cntrl_pt_cd = '"+cntrlPtCode+"' and ";
		} else {
			alertsArgs = " where ";
		}
		if((startDate != null && !"".equals(startDate))  && (endDate == null || "".equals(endDate))){
			if (dateOption.equals("file")) {
				alertsArgs += " proc_dt = to_date('"+startDate+"','MM/dd/yyyy') ";	
			}else{
				alertsArgs +=" alert_rule_run_dt = to_date('"+startDate+"', 'MM/dd/yyyy') ";
			}
		} else {
			if (dateOption.equals("file")) {
				alertsArgs += " proc_date >= to_date('"+startDate+"','MM/dd/yyyy') and "; 
				alertsArgs += " proc_date <= to_date('"+endDate+"','MM/dd/yyyy') ";
			} else {
				alertsArgs += " alert_rule_run_dt >= to_date('"+startDate+"','MM/dd/yyyy') and "; 
				alertsArgs += " alert_rule_run_dt <= to_date('"+endDate+"','MM/dd/yyyy') ";
			}
		}
		if (alertsArgs != null ) {
			alertsArgsList.add(alertsArgs);
		} else {
			alertsArgsList.add(" ");
		}
		alertsArgsList.add(userId);
		try{
			MessageFormat mf = new MessageFormat(getTotalAlertRules);
			prepareStatement = mf.format((String[])alertsArgsList.toArray(new String[alertsArgsList.size()]));
			logger.debug("AlertDashboardService.getTotalCntrlPts() - Executing SQL statement: "+ prepareStatement);
			statement = connection.createStatement();
			rs = statement.executeQuery(prepareStatement);

			if (rs != null) {
				while(rs.next()){
					totalAlertRules = rs.getInt(1);
				}
			}
		} catch(SQLException sqle){
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sqle.getMessage(), sqle);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sqle));
		} finally{
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(statement, failureList, logger);
		}
		return totalAlertRules;
	}
	
	/**
	 * A private method to return the list of alert rules.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return List
	 */
	private List getAlerts(Connection connection, List failureList, List args,String userId) {
		List alertsList = new ArrayList();
		List alertsArgsList = new ArrayList();
		String alertsArgs = null;		
		String startDate =(String) args.get(0);
		String endDate =(String) args.get(1);
		String dateOption =(String) args.get(2);
		String cntrlPtCode = (String) args.get(3);
		String sortItem = (String) args.get(5);
    	String sortOrder = (String) args.get(6);
    	String dispatch = (String) args.get(7);
    	int pageSize = ((Integer)args.get(8)).intValue();
    	int page = ((Integer)args.get(10)).intValue();
    	int pages = ((Integer)args.get(11)).intValue();
    	
		Statement statement = null;
		ResultSet rs = null;
		String prepareStatement = null;
		
		int startCounter = (page - 1) * pageSize + 1;
		int endCounter = page * pageSize;
		
		if (cntrlPtCode != null){
			alertsArgs = " where cntrl_pt_cd = '"+cntrlPtCode+"' and ";
		} else {
			alertsArgs = " where ";
		}
		if((startDate != null && !"".equals(startDate))  && (endDate == null || "".equals(endDate))){
			if (dateOption.equals("file")) {
				alertsArgs += " proc_dt = to_date('"+startDate+"','MM/dd/yyyy') ";	
			}else{
				alertsArgs +=" alert_rule_run_dt = to_date('"+startDate+"', 'MM/dd/yyyy') ";
			}
		} else {
			if (dateOption.equals("file")) {
				alertsArgs += " proc_date >= to_date('"+startDate+"','MM/dd/yyyy') and "; 
				alertsArgs += " proc_date <= to_date('"+endDate+"','MM/dd/yyyy') ";
			} else {
				alertsArgs += " alert_rule_run_dt >= to_date('"+startDate+"','MM/dd/yyyy') and "; 
				alertsArgs += " alert_rule_run_dt <= to_date('"+endDate+"','MM/dd/yyyy') ";
			}
		}
		if (alertsArgs != null ) {
			alertsArgsList.add(alertsArgs);
		} else {
			alertsArgsList.add(" ");
		}
		//filter by current group
		alertsArgsList.add(userId);
		if ((sortItem != null) && !("".equals(sortItem))) {
			alertsArgsList.add("order by " + sortItem + " " + sortOrder + ", alertRule");
		} else {
			alertsArgsList.add("order by alertRule");
		}
		/*if (dispatch == null) {
			alertsArgsList.add("where T.rn between " + startCounter + " and " + endCounter);
    	} else {
	    	if ("createReport".equals(dispatch) || "emailReport".equals(dispatch)) {
	    		alertsArgsList.add("");
			} else {
				alertsArgsList.add("where T.rn between " + startCounter + " and " + endCounter);
			}
    	}*/
		alertsArgsList.add("");
		try{
			MessageFormat mf = new MessageFormat(get_alerts);
			prepareStatement = mf.format((String[])alertsArgsList.toArray(new String[alertsArgsList.size()]));
			logger.debug("AlertDashboardService.getAlerts() - Executing SQL statement: "+ prepareStatement);
			statement = connection.createStatement();
			rs = statement.executeQuery(prepareStatement);

			if (rs != null) {
				while(rs.next()){
					alertsList.add(rs.getString(1));
				}
			}
		} catch(SQLException sqle){
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sqle.getMessage(), sqle);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sqle));
		} finally{
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(statement, failureList, logger);
		}
		return alertsList;
	}

	/**
	 * Public method to return the total count of control points.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return int
	 */
	public int getTotalCntrlPts(Connection connection, List failureList, List args) {
		int totalCntrlPts = 0;
		List cntrlPtArgsList = new ArrayList();	
		Statement statement = null;
		ResultSet rs = null;
		String prepareStatement = null;
    	
		try{
			MessageFormat mf = new MessageFormat(getTotalCntrlPts);
			prepareStatement = mf.format((String[])cntrlPtArgsList.toArray(new String[cntrlPtArgsList.size()]));
			logger.debug("AlertDashboardService.getTotalCntrlPts() - Executing SQL statement: "+ prepareStatement);
			statement = connection.createStatement();
			rs = statement.executeQuery(prepareStatement);

			if (rs != null) {
				while(rs.next()){
					totalCntrlPts = rs.getInt(1);
				}
			}
		} catch(SQLException sqle){
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sqle.getMessage(), sqle);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sqle));
		} finally{
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(statement, failureList, logger);
		}
		return totalCntrlPts;
	}
	
	/**
	 * A private method to return the list of process point wise control points.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return List
	 */
	private List getCntrlPts(Connection connection, List failureList, List args) {
		List cntrlPtList = new ArrayList();
		List cntrlPtArgsList = new ArrayList();
		String cntrlPtArgs = null;
		Statement statement = null;
		ResultSet rs = null;
		String prepareStatement = null;
		
		String startDate =(String) args.get(0);
		String endDate =(String) args.get(1);
		String dateOption =(String) args.get(2);
		String sortItem = (String) args.get(5);
    	String sortOrder = (String) args.get(6);
		String dispatch = (String) args.get(7);
		int pageSize = ((Integer)args.get(8)).intValue();
    	int page = ((Integer)args.get(10)).intValue();
    	int pages = ((Integer)args.get(11)).intValue();
    	
		int startCounter = (page - 1) * pageSize + 1;
		int endCounter = page * pageSize;
		
		if((startDate != null && !"".equals(startDate))  && (endDate == null || "".equals(endDate))){
			if (dateOption.equals("file")) {
				cntrlPtArgs = " proc_dt = to_date('"+startDate+"','MM/dd/yyyy') ";	
			}else{
				cntrlPtArgs =" alert_rule_run_dt = to_date('"+startDate+"', 'MM/dd/yyyy') ";
			}
		} else {
			if (dateOption.equals("file")) {
				cntrlPtArgs = " proc_date >= to_date('"+startDate+"','MM/dd/yyyy') and "; 
				cntrlPtArgs += " proc_date <= to_date('"+endDate+"','MM/dd/yyyy') ";
			} else {
				cntrlPtArgs = " alert_rule_run_dt >= to_date('"+startDate+"','MM/dd/yyyy') and "; 
				cntrlPtArgs += " alert_rule_run_dt <= to_date('"+endDate+"','MM/dd/yyyy') ";
			}
		}
		if (cntrlPtArgs != null ) {
			cntrlPtArgsList.add(cntrlPtArgs);
		} else {
			cntrlPtArgsList.add(" ");
		}
    	
    	if ((sortItem != null) && !("".equals(sortItem))) {
    		cntrlPtArgsList.add("order by process, " + sortItem + " " + sortOrder + ", cnrtPtDesc");
		} else {
			cntrlPtArgsList.add("order by process, cnrtPtDesc");
		}
    	
    	/*if (dispatch == null) {
    		cntrlPtArgsList.add("where T.rn between " + startCounter + " and " + endCounter);
    	} else {
	    	if ("createReport".equals(dispatch) || "emailReport".equals(dispatch)) {
	    		cntrlPtArgsList.add("");
			} else {
				cntrlPtArgsList.add("where T.rn between " + startCounter + " and " + endCounter);
			}
    	}*/
    	cntrlPtArgsList.add("");
    	
    	try{
			MessageFormat mf = new MessageFormat(get_cntrl_pts);
			prepareStatement = mf.format((String[])cntrlPtArgsList.toArray(new String[cntrlPtArgsList.size()]));
			logger.debug("AlertDashboardService.getCntrlPts() - Executing SQL statement: "+ prepareStatement);
			statement = connection.createStatement();
			rs = statement.executeQuery(prepareStatement);
			if (rs != null) {
				while(rs.next()){
					cntrlPtList.add(new PickList(rs.getString(1), rs.getString(2), rs.getString(3)));
				}
			}
		} catch(SQLException sqle){
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sqle.getMessage(), sqle);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sqle));
		} finally{
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(statement, failureList, logger);
		}
    	
		return cntrlPtList;
	}

	/**
	 * A private method to return the list of control points or alert rules
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return List
	 */
	private List getDetails(Connection connection, List failureList, List args) {
		List detailsList = new ArrayList();
		String detailsArgs = null;
		List detailsArgsList = new ArrayList();
		String startDate =(String) args.get(0);
		String endDate =(String) args.get(1);
		String dateOption =(String) args.get(2);
		String cntrlPtCode = (String) args.get(3);
		String dashboardType = (String) args.get(4);
		String sqlStmt = null;
		Statement statement = null;
		ResultSet rs = null;
		String prepareStatement = null;
		Calendar calendar = Calendar.getInstance();
		Date date2 = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		
		try{
			if (dashboardType.equals("2")) {
				sqlStmt = get_details_2;
				if (endDate == null || "".equals(endDate)){
					calendar.setTime(dateFormat.parse(startDate));
					calendar.add(Calendar.DAY_OF_YEAR, 1);
					date2 = new Date(calendar.getTimeInMillis());
					detailsArgs = " WHERE	alert_rule_run_dt >= to_date('" + startDate + "','MM/dd/yyyy')";
					detailsArgs += " AND alert_rule_run_dt < to_date('" + dateFormat.format(date2) + "','MM/dd/yyyy')";
				} else {
					if (dateOption.equals("file")){
						detailsArgs = " WHERE	proc_date >= to_date('" + startDate + "', 'MM/dd/yyyy')";
						detailsArgs += " AND		proc_date <= to_date('" + endDate + "', 'MM/dd/yyyy')";
					} else {
						detailsArgs = " WHERE	alert_rule_run_dt >= to_date('" + startDate + "', 'MM/dd/yyyy')";
						detailsArgs += " AND		alert_rule_run_dt <= to_date('" + endDate + "', 'MM/dd/yyyy')";
					}	
				}
				if(detailsArgs != null){
					detailsArgsList.add(detailsArgs);
				} else {
					detailsArgsList.add("");
				}
			} else if (dashboardType.equals("3")) {
				sqlStmt = get_details_3;
				if (endDate == null || "".equals(endDate)){
					calendar.setTime(dateFormat.parse(startDate));
					calendar.add(Calendar.DAY_OF_YEAR, 1);
					date2 = new Date(calendar.getTimeInMillis());
					if (dateOption.equals("file")){ 
						detailsArgs = " WHERE	proc_date >= to_date('" + startDate + "', 'MM/dd/yyyy')";
						detailsArgs += " AND		proc_date < to_date('" + dateFormat.format(date2) + "', 'MM/dd/yyyy')";
					} else {
						detailsArgs = " WHERE	alert_rule_run_dt >= to_date('" + startDate + "','MM/dd/yyyy')";
						detailsArgs += " AND alert_rule_run_dt < to_date('" + dateFormat.format(date2)+ "','MM/dd/yyyy')";
					}
				} else {	
					if (dateOption.equals("file")){
						detailsArgs = " WHERE	proc_date >= to_date('" + startDate + "', 'MM/dd/yyyy')";
						detailsArgs += " AND		proc_date <= to_date('" + endDate + "', 'MM/dd/yyyy')";
					} else {
						detailsArgs = " WHERE	alert_rule_run_dt >= to_date('" + startDate + "', 'MM/dd/yyyy')";
						detailsArgs += " AND		alert_rule_run_dt <= to_date('" + endDate + "', 'MM/dd/yyyy')";
					}
				}
				if(detailsArgs != null){
					detailsArgsList.add(detailsArgs);
				} else {
					detailsArgsList.add("");
				}
				detailsArgsList.add(cntrlPtCode);
			}

			MessageFormat mf = new MessageFormat(sqlStmt);
			prepareStatement = mf.format((String[])detailsArgsList.toArray(new String[detailsArgsList.size()]));
			logger.debug("AlertDashboardService.getDetails() - Executing SQL statement: "+ prepareStatement);
			statement = connection.createStatement();
			rs = statement.executeQuery(prepareStatement);

			if (rs != null) {
				while(rs.next()) {
					if (dashboardType.equals("2")) {
						detailsList.add(rs.getString(1));
					} else if (dashboardType.equals("3")) {
						detailsList.add(rs.getString(2));
					}
				}
			}	
		} catch(SQLException sqle){
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sqle.getMessage(), sqle);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sqle));
		} catch(ParseException px) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC") + " Exception details: " + px.getMessage(), px);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC"), px));
		} finally{
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(statement, failureList, logger);
		}
		return detailsList;
	}
	
	/**
	 * A method to generate the excel report.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param displayHead
	 * @param report
	 * @param progressBar
	 */
	public void getExcelReport(Connection connection, List failureList, List args, String displayHead, ExcelReport report, ProgressBar progressBar,String userId) {
		int counter = 0;
		int counter1 = 0;
		int counter2 = 0;
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Format currTimeformat = new SimpleDateFormat("HH:mm:ss");
		Date today = new Date(System.currentTimeMillis());
		Date yesterday = DateUtil.getPreviousDay(today);
		String currTime = currTimeformat.format(today);
		String todayDate = dateFormat.format(today);
		String yesterdayDate = dateFormat.format(yesterday);
		String startDate = (String) args.get(0);
		String endDate = (String) args.get(1);
		String dateOption = (String) args.get(2);
		String cntrlPtCode = (String) args.get(3);
		String dashboardType = (String) args.get(4);
		String region = (String) args.get(9);
		String cycle = "";
		List alertDashboardList = null;
		AlertDashboard alertDashboard = null;
		List levelWiseWarningList =  null;
		LevelWiseWarnings levelWiseWarnings = null;
		List divisionWiseAlertSummaryList = null;
		DivisionWiseAlertSummary divisionWiseAlertSummary = null;
		String cntrlPtDesc = null;
		String currentProcessPoint = null;
		String previousProcessPoint = null;
		
		if ("WE".equalsIgnoreCase(region)) {
			/*
			 * Call method getCycleCalendarList(connection, failureList, args) to get the list of cycles.
			 */
			List cycleList = alertDashboardService.getCycleCalendarList(connection, failureList, args);
			
			progressBar.setProgressPercent(progressBar.getPercent() + 10);
			
			if (cycleList != null) {
				int cycleListSize = cycleList.size();
				if (cycleListSize > 0) {
					if (cycleListSize == 1) {
						cycle = ((new StringBuffer())
							.append("Cycle(s): ")
							.append(((Integer)cycleList.get(0)).toString()))
							.toString();
					} else {
						cycle = ((new StringBuffer())
							.append("Cycle(s): ")
							.append(((Integer)cycleList.get(0)).toString())
							.append(" - ")
							.append(((Integer)cycleList.get(cycleListSize-1)).toString()))
							.toString();
					}
				} else {
					cycle = "";
				}
			} else {
				cycle = "";
			}
		}
		
		/*
		 * Get the control point description in case of Alert Dashboard by control point.
		 */
		if (dashboardType.equals("3")) {
			cntrlPtDesc = alertDashboardService.queryConvertForDisplay(connection, failureList, cntrlPtCode);
		}
		
		progressBar.setProgressPercent(progressBar.getPercent() + 10);
		
		/*
		 * Call the method getAlertDashboardList(connection, failureList, args) to get 
		 * the list of Alert Dashboard objects.
		 */
		alertDashboardList = alertDashboardService.getAlertDashboardList(connection, failureList, args, progressBar,userId);
		
		try {
			if (alertDashboardList != null) {
				report.beginReport();
					report.beginTable();
						report.beginRow();
							report.addRaw("<td nowrap align=\"center\" colspan=\"8\">");
								report.addRaw("<b>Alert Dashboard</b>");
							report.addRaw("</td>");
						report.endRow();
						
						report.beginRow();							
							if ("file".equals(dateOption)) {
								if ("range".equals(displayHead)) {
									report.addRaw("<td nowrap align=\"center\" colspan=\"8\">");
										report.addRaw("<b>From File Dates: " + startDate + " - " + endDate + "   " + cycle + "</b>");
									report.addRaw("</td>");
								} else {
									if ("curr".equals(displayHead)) {
										report.addRaw("<td nowrap align=\"center\" colspan=\"8\">");
											report.addRaw("<b>For File Date: " + startDate + " As of: " + currTime + "   " + cycle + "</b>");
										report.addRaw("</td>");
									} else {
										report.addRaw("<td nowrap align=\"center\" colspan=\"8\">");
											report.addRaw("<b>For File Date: " + startDate + "   " + cycle + "</b>");
										report.addRaw("</td>");
									}
								}
							} else if ("run".equals(dateOption)) {
								if ("range".equals(displayHead)) {
									report.addRaw("<td nowrap align=\"center\" colspan=\"8\">");
										report.addRaw("<b>From Alert Run Dates: " + startDate + " - " + endDate + "   " + cycle + "</b>");
									report.addRaw("</td>");
								} else {
									if ("curr".equals(displayHead)) {
										report.addRaw("<td nowrap align=\"center\" colspan=\"8\">");
											report.addRaw("<b>For Alert Run Date: " + startDate + " As of: " + currTime + "   " + cycle + "</b>");
										report.addRaw("</td>");
									} else {
										report.addRaw("<td nowrap align=\"center\" colspan=\"8\">");
											report.addRaw("<b>For Alert Run Date: " + startDate + "   " + cycle + "</b>");
										report.addRaw("</td>");
									}
								}
							}
						report.endRow();
						
						report.beginRow();
						report.endRow();
						
						report.addRaw("<table width=100% border=1>");
							report.beginRow();
								if(dashboardType.equals("2")) {
									report.addHeader("All Warnings");
								} else {
									report.addHeader(cntrlPtDesc);
								}
								report.addHeader("Tier3");
								report.addHeader("Tier2");
								report.addHeader("Tier1");
								report.addHeader("No Issue");
								if (dashboardType.equals("3")) {
									if ((todayDate.equals(startDate)) || (yesterdayDate.equals(startDate))) {
										report.addHeader("Not Run");
									}
								}
								report.addHeader("Warning");
								report.addHeader("Pending");
								report.addHeader("Closed");
							report.endRow();
							
							if(alertDashboardList.size() == 0) {
								report.beginRow();
									if(dashboardType.equals("2")) {
										report.addRaw("<td nowrap align=\"center\" colspan=\"8\">");
											report.addRaw("<b>No data available.</b>");
										report.addRaw("</td>");
									} else {
										report.addRaw("<td nowrap align=\"center\" colspan=\"9\">");
											report.addRaw("<b>No Alert Rule Data Available.</b>");
										report.addRaw("</td>");
									}
								report.endRow();
							} else {
								int alertDashboardListSize = alertDashboardList.size();
								for (counter=0; counter<alertDashboardListSize; counter++) {
									alertDashboard  = (AlertDashboard) alertDashboardList.get(counter);
									if (dashboardType.equals("2")) {
										currentProcessPoint = alertDashboard.getProcessPoint();
										if (!currentProcessPoint.equals(previousProcessPoint)) {
											report.beginRow();
												report.addColumn(currentProcessPoint, "#FFFFFF", true, "left");
												report.addRaw("<td colspan=\"7\">&nbsp;</td>");
											report.endRow();
											previousProcessPoint = currentProcessPoint;
										}
									}
									report.beginRow();
										if (dashboardType.equals("2")) {
											report.addColumn("      " + alertDashboard.getCntrlPtDesc(), "#FFFFFF", false, "left");
										} else {
											report.addColumn(alertDashboard.getType(), "#FFFFFF", false, "left");
										}
										levelWiseWarningList = alertDashboard.getLevelWiseWarningList();
										if (levelWiseWarningList != null) {
											int levelWiseWarningListSize = levelWiseWarningList.size();
											if (levelWiseWarningListSize > 0) {
												for (counter1 = 0; counter1<levelWiseWarningListSize; counter1++) {
													levelWiseWarnings = (LevelWiseWarnings) levelWiseWarningList.get(counter1);
													if (dashboardType.equals("3")) {
														if (counter1 == 4) {
															if ((todayDate.equals(startDate)) || (yesterdayDate.equals(startDate))) {
																report.addRaw("<td nowrap align=\"left\">");
															}
														} else {
															report.addRaw("<td nowrap align=\"left\">");
														}
													} else {
														report.addRaw("<td nowrap align=\"left\">");
													}
													divisionWiseAlertSummaryList = levelWiseWarnings.getDivisionWiseAlertSummaryList();
													if (divisionWiseAlertSummaryList != null) {
														int divisionWiseAlertSummaryListSize = divisionWiseAlertSummaryList.size();
														if (divisionWiseAlertSummaryListSize > 0) {
															for (counter2 = 0; counter2<divisionWiseAlertSummaryListSize; counter2++) {
																divisionWiseAlertSummary = (DivisionWiseAlertSummary) divisionWiseAlertSummaryList.get(counter2);
																if (dashboardType.equals("2")) {
																	if (counter1 == 3 && ("run".equalsIgnoreCase(dateOption))) {
																		//report.addRaw(divisionWiseAlertSummary.getDivisionDesc() + " - " + divisionWiseAlertSummary.getProcDte().toString() + " - " + divisionWiseAlertSummary.getCount());
																		report.addRaw(divisionWiseAlertSummary.getDivisionDesc() + " - " + divisionWiseAlertSummary.getCount());
																	} else {
																		report.addRaw(divisionWiseAlertSummary.getDivisionDesc() + " - " + divisionWiseAlertSummary.getCount());
																	}
																} else {
																	if (counter1 == 4) {
																		if ((todayDate.equals(startDate)) || (yesterdayDate.equals(startDate))) {
																			report.addRaw(divisionWiseAlertSummary.getDivisionDesc());
																		}
																	} else {
																		if (counter1 == 3 && ("run".equalsIgnoreCase(dateOption))) {
																			//report.addRaw(divisionWiseAlertSummary.getDivisionDesc() + " - " + divisionWiseAlertSummary.getProcDate().toString() + " - " + divisionWiseAlertSummary.getCount());
																			report.addRaw(divisionWiseAlertSummary.getDivisionDesc() + " - " + divisionWiseAlertSummary.getCount());
																		} else {
																			report.addRaw(divisionWiseAlertSummary.getDivisionDesc() + " - " + divisionWiseAlertSummary.getCount());
																		}
																	}
																}
																report.addBreak();
															}
														}
													}
													if (dashboardType.equals("3")) {
														if (counter1 == 4) {
															if ((todayDate.equals(startDate)) || (yesterdayDate.equals(startDate))) {
																report.addRaw("</td>");
															}
														} else {
															report.addRaw("</td>");
														}
													} else {
														report.addRaw("</td>");
													}
												}
											}
										}
									report.endRow();
								}
							}
						report.addRaw("</table>");
					report.endTable();
				report.endReport();
			}
		} catch (IOException iox) {
			logger.error("Error in creting the excel report. Exception details: " + iox.getMessage(), iox);
		  	failureList.add(new RABCException("Error in creting the excel report.", iox));
		}	
	}
	
	/**
	 * Private method to return the string having all the alert rules seperated by comma.
	 * 
	 * @param alertRuleList
	 * @return String
	 */
	private String getAlertRules(List alertRuleList) {
	     String result = null;
	     int counter = 0;
	     StringBuffer resultBuffer = new StringBuffer();
	     if (alertRuleList != null) {
	     	int size = alertRuleList.size();
	     	for(counter=0; counter<alertRuleList.size(); counter++) {
	     		if(resultBuffer.indexOf("'"+(String)alertRuleList.get(counter)+"'") == -1) {
		     		resultBuffer.append('\'').append((String)alertRuleList.get(counter)).append('\'').append(',');
		     	}
	     	}
	     }
	     result = resultBuffer.toString();
	     return result;
	 }
	
	/**
	 * Private method to return the string having all the control points seperated by comma.
	 * 
	 * @param cntrlPtList
	 * @return String
	 */
	private String getControlPoints(List cntrlPtList) {
	     String result = null;
	     int counter = 0;
	     StringBuffer resultBuffer = new StringBuffer();
	     if (cntrlPtList != null) {
	     	int size = cntrlPtList.size();
	     	for(counter=0; counter<size; counter++) {
	     		if(resultBuffer.indexOf(((PickList)cntrlPtList.get(counter)).getKey()) == -1) {
	     			resultBuffer.append('\'').append(((PickList)cntrlPtList.get(counter)).getKey()).append('\'').append(',');
		     	}
	     	}
	     }
	     result = resultBuffer.toString();
	     return result;
	 }
	
	/**
	 * Method to return the default line count.
	 * 
	 * @param connection
	 * @param failureList
	 * @param userId
	 * @return int
	 */
	protected int getDefaultLineCount(Connection connection, List failureList, String userId) {
		int defaultLineCount = 0;
		String selectSQL = getDefaultLineCount;
		List args = new ArrayList();
		args.add(userId);
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		try{
			MessageFormat mf = new MessageFormat(selectSQL);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			if (rs != null && rs.next()) {
				defaultLineCount = rs.getInt(1);
			} else {
				defaultLineCount = RABCConstantsLists.getRABCConstantsLists().getPageSize();
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		
		return defaultLineCount;
	}
	
	/**
	 * A method which returns a date before today date in RABC_CYCLE_CALENDAR table which is not a holiday.
	 * 
	 * @param todayDate
	 * @return Date
	 */
	protected Date getPreviousDay(Connection connection, List failureList, Date todayDate) {
		Date previousDayDate = null;
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		String selectSQL = getPreviousDay;
		List args = new ArrayList();
		args.add(dateFormat.format(todayDate));
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		try{
			MessageFormat mf = new MessageFormat(selectSQL);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			if (rs != null && rs.next()) {
				previousDayDate = rs.getDate(1);
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		
		return previousDayDate;
	}
}
