/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/

package com.att.bac.rabc.alerts.rpt;

import java.util.ArrayList;
import java.util.List;

/**
 * This class represents the data object that holds the attributes required
 * to represent the Alert Row (Control Alert Detail) page.
 * 
 * @author Nalina Pandiyan - NP5434
 */
public class AlertRow {
	private String rowColor;
	private int showRow; 
	private List columnData = new ArrayList(); // alertCell Object

	/**
	 * Default constructor which sets the default showrow attribute
	 */
	public AlertRow() {
		this.showRow = 1;
	}

	/**
	 * @return Returns the columnData.
	 */
	public List getColumnData() {
		return columnData;
	}
	
	/**
	 * @param alertCell The alertCell to set
	 */
	public void addColumnData(AlertCell alertCell) {
		this.columnData.add(alertCell);
	}
	/**
	 * @return Returns the rowColor.
	 */
	public String getRowColor() {
		return rowColor;
	}

	/**
	 * @param rowColor The rowColor to set.
	 */
	public void setRowColor(String rowColor) {
		this.rowColor = rowColor;
	}

	/**
	 * @return Returns the showRow.
	 */
	public int getShowRow() {
		return showRow;
	}
	/**
	 * @param showRow The showRow to set.
	 */
	public void setShowRow(int showRow) {
		this.showRow = showRow;
	}
}
