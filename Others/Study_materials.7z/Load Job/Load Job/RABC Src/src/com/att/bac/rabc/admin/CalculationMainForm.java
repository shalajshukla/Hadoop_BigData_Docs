/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.admin;

import java.util.List;

import org.apache.struts.action.ActionForm;


/**
 * Module description: 
 * 
 * This is a Main calculation page Form Bean for the Calculation definition Component from side menu.
 *  
 * @author Umesh Deole - UD7153
 *
 */
public class CalculationMainForm extends ActionForm {

	List calculationNameList ;
	String calculationNum=null;
	private String dispatch = null;
	
	/*
	 * Variables added for calendar page
	 */
	private String procDates;
	private String billRounds;
	private String holidayIndicators;
	private String loadedDataDates;
	
	/**
	 * @return billRounds
	 */
	public String getBillRounds() {
		return billRounds;
	}
	
	/**
	 * @param billRounds
	 */
	public void setBillRounds(String billRounds) {
		this.billRounds = billRounds;
	}
	
	/**
	 * @return holidayIndicators
	 */
	public String getHolidayIndicators() {
		return holidayIndicators;
	}
	
	/**
	 * @param holidayIndicators
	 */
	public void setHolidayIndicators(String holidayIndicators) {
		this.holidayIndicators = holidayIndicators;
	}
	
	/**
	 * @return loadedDataDates
	 */
	public String getLoadedDataDates() {
		return loadedDataDates;
	}
	
	/**
	 * 
	 * @param loadedDataDates
	 */
	public void setLoadedDataDates(String loadedDataDates) {
		this.loadedDataDates = loadedDataDates;
	}
	
	/**
	 * @return procDates
	 */
	public String getProcDates() {
		return procDates;
	}

	/**
	 * @param procDates
	 */
	public void setProcDates(String procDates) {
		this.procDates = procDates;
	}

	/**
	 * @return Returns the calculationNum.
	 */
	public String getCalculationNum() {
		return calculationNum;
	}
	/**
	 * @param calculationNum The calculationNum to set.
	 */
	public void setCalculationNum(String calculationNum) {
		this.calculationNum = calculationNum;
	}
	/**
	 * @return Returns the calculationNameList.
	 */
	public List getCalculationNameList() {
		return calculationNameList;
	}
	/**
	 * @param calculationNameList The calculationNameList to set.
	 */
	public void setCalculationNameList(List calculationNameList) {
		this.calculationNameList = calculationNameList;
	}
	/**
	 * @return Returns the dispatch.
	 */
	public String getDispatch() {
		return dispatch;
	}
	/**
	 * @param dispatch The dispatch to set.
	 */
	public void setDispatch(String dispatch) {
		this.dispatch = dispatch;
	}
}
