/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.icbs.load;

import java.io.File;
import java.net.UnknownHostException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import com.att.bac.rabc.util.EmcisEventLogger;
import com.att.bac.util.NetUtil;
import com.sbc.bac.rabc.load.FilePatternLoadJob;
import com.sbc.bac.rabc.load.PrepareTableForRerun;
import com.sbc.bac.rabc.load.RabcLoadJobTrig;
import com.sbc.bac.rabc.load.RetrieveStaticInfo;
import com.sbc.bac.rabc.load.StaticErrorMsgKeys;
import com.sbc.bac.rabc.load.StaticFieldKeys;

/**
 * This is a Load job for loading ICBS return data for West region into RABC_ICBS_RETURN.
 *
 * @author Shailesh Hemdev - SH8512
 */
public class WestDailyReturn extends FilePatternLoadJob {
	private static final SimpleDateFormat MMDDYYYY_FORMAT = new SimpleDateFormat("MMddyyyy");
	private static final SimpleDateFormat YYYYDDD_FORMAT = new SimpleDateFormat("yyyyddd");

	private static final String RABC_ICBS_RETURN = "RABC_ICBS_RETURN";
	private static final String RABC_TRIG = "RABC_TRIG";

	private static final String FILE_ID = "WEICBSRT";

	private static final String fieldSeperator = StaticFieldKeys.SEMICOLON;

	private PreparedStatement insertReturn;

	private String runDate;
	private java.sql.Date sqlRunDate;
	private String division, fileName, fileToken;
	private String backoutRecovery = null;
	private File currentFile;

	private int recordCount;
	private int batchCounter;

	/*
	 * HashMap variables to contain the groups for various tables.
	 */
	private HashMap icbsReturnMap;

	/*
	 * boolean variables indicating whether trigger to be inserted for that file id.
	 */
	boolean isReturn;

	/*
	 * boolean variables indicating whether the file to be processed or not.
	 */
	boolean isHeaderExists;
	boolean isTrailerExists;
	boolean isDateRecordExists;
	boolean isRecordCountMatches;

	/**
	 * Overriding preprocess() method.
	 * It is executed prior to processing the load job.
	 * Forms the actual prepared statements which need to be fired on to the database.
	 *
	 * @see com.sbc.bac.load.LoadJob#preprocess()
	 */
	public boolean preprocess() {
		boolean success = super.preprocess();

		if (success) {
			try {
				insertReturn = connection.prepareStatement("  INSERT INTO RABC_ICBS_RETURN (RUN_DATE, DIVISION,ENTITY_CD, DATA_FILE, RTN_CD, TOT_RTN_CT_DB, TOT_RTN_AMT_DB,TOT_RTN_CT_CR, TOT_RTN_AMT_CR) VALUES(?, ?, ?, ?, ?, ?, ?, ? ,? ) ");
			} catch (SQLException e) {
				severe(StaticErrorMsgKeys.PREPROCESS_ERROR + e.getMessage(), e);
				success = false;
			}
		}

		return success;
	}

	/**
	 * Overriding preprocessFile(file) method.
	 * It is executed prior to processing the file to be loaded.
	 * It includes the following steps:
	 * 	1) Marks the backoutRecovery flag to "Y" if this file has already been processed earlier.
	 * 	2) Initializes the global variables with default values.
	 *
	 * @see com.sbc.bac.load.FileDBLoadJob#preprocessFile(java.io.File)
	 */
	public boolean preprocessFile(File file) {
		boolean success = super.preprocessFile(file);
		fileName = file.getName();
		fileToken = "RA170F01";
		if (success) {
			try {
				/*
				 * Check whether this file has been processed before and if yes,
				 * mark the backoutRecovery flag to "Y".
				 */
				if (RabcLoadJobTrig.IsOriginalFileLoaded(connection, file, file.getName().length())) {
					backoutRecovery = "Y";
				}
			} catch (Exception e) {
				severe(StaticErrorMsgKeys.PREPROCESSFILE_ERROR + e.getMessage(), e);
				success = false;
			}
		}

		/*
		 * Initialize the global variables with default values.
		 */
		currentFile = file;
		recordCount = 0;
		isHeaderExists = false;
		isTrailerExists = false;
		isDateRecordExists=false;
		isRecordCountMatches = false;
		batchCounter = 0;
		icbsReturnMap = new HashMap();
		isReturn = false;

		return success;
	}

	/**
	 * Overriding parseLine(line) method.
	 * It accepts a single line and checks whether it is header, trailer, date or detail record.
	 * Depending upon the record type, it calls the respective internal private methods to process the line.
	 *
	 * @see com.sbc.bac.load.FileDBLoadJob#parseLine(java.lang.String)
	 */
	protected int parseLine(String line) throws Exception {
		boolean status = true;
		String recordIndicator = getRecordType(line);

		if ("HEADER".equalsIgnoreCase(recordIndicator)) {
			isHeaderExists = true;
			status = processHeader(line);
		} else if ("DATE".equalsIgnoreCase(recordIndicator)) {
			if (!isHeaderExists) {
				throw new Exception("Either header record is not present in the file or it is not the first record.");
			} else {
				isDateRecordExists = true;
				recordCount++;
				status = processCycleRecord(line);
			}
		}else if ("TRAILER".equalsIgnoreCase(recordIndicator)) {
			if (!isHeaderExists) {
				throw new Exception("Either header record is not present in the file or it is not the first record.");
			}else if (!isDateRecordExists){
				throw new Exception("Either date record is not present in the file or it is not the second record.");
			}else {
				isTrailerExists = true;
				status = processTrailer(line);
			}
		}  else if ("ERROR".equalsIgnoreCase(recordIndicator)) {
			if (!isHeaderExists) {
				throw new Exception("Either header record is not present in the file or it is not the first record.");
			} else if (!isDateRecordExists) {
				throw new Exception("Either date record is not present in the file or it is not the second record.");
			} else if (isTrailerExists) {
				throw new Exception("Trailer record is not the last record.");
			} else {
				recordCount++;
				status = processErrorRecord(line);
			}
		} else {
			recordCount++;
			status = false;
		}

		if (status) {
			return SUCCESS;
		} else {
			return ERROR;
		}
	}

	/**
	 * Private method to return the record type of the line to be processed.
	 *
	 * @param line
	 * @return String
	 * @throws Exception
	 */
	private String getRecordType(String line) throws Exception {
		String recordType = null;

		String [] lineFields = line.split(fieldSeperator);

		if (lineFields.length > 1) {
			String firstField			= lineFields[0].trim();
			String secondField			= lineFields[1].trim();

			if ("HEADER".equals(firstField)) {
				recordType = "HEADER";
			} else if ("TRAILER".equals(firstField)) {
				recordType = "TRAILER";
			} else {
				if ("RA17ICBS".equals(firstField)) {
					if ("01".equals(secondField)) {
						recordType = "DATE";
					} else if ("02".equals(secondField)) {
						recordType = "ERROR";
					} else if ("03".equals(secondField)) {
						recordType = "ERROR";
					}else if ("04".equals(secondField)) {
						recordType = "ERROR";
					}else if ("05".equals(secondField)) {
						recordType = "ERROR";
					}
				}
			}
		}

		return recordType;
	}

	/**
	 * Private method to process the header record.
	 *
	 * @param line
	 * @return boolean
	 * @throws Exception
	 */
	private boolean processHeader(String line) throws Exception {
		boolean success = false;

		String [] lineFields = line.split(fieldSeperator);

		/*
		 * Populate the instance variable for division.
		 */
		if (lineFields.length > 2) {
			division = lineFields[2].trim();
			division = getDivision(division);
			success = true;
		}

		return success;
	}

	/**
	 * Private method to process the trailer record.
	 * It checks that whether the total number of records (excluding header and trailer records)
	 * in the file is eqaul to the count in the trailer record or not.
	 *
	 * @param line
	 * @return boolean
	 * @throws Exception
	 */
	private boolean processTrailer(String line) throws Exception {
		boolean success = false;
		int trailerCount = 0;

		String [] lineFields = line.split(fieldSeperator);

		if (lineFields.length > 5) {
			trailerCount = Integer.parseInt(lineFields[5].trim());
			success = true;
		}

		if (success) {
			if (trailerCount == recordCount) {
				isRecordCountMatches = true;
			}
		}

		return success;
	}

	/**
	 * Private method to process the date record. It does the following steps:
	 * 	1) Retrieves the cycle date from the date record.
	 * 	2) Deletes the records matching with the date and division retrieved form the file from the table
	 * 	   RABC_ICBS_RETURN if the backoutRecovery flag is "Y", i.e. this file has already been processed earlier.
	 *
	 * @param line
	 * @return boolean
	 * @throws Exception
	 */
	private boolean processCycleRecord(String line) throws Exception {
		boolean success = false;

		String [] lineFields = line.split(fieldSeperator);

		/*
		 * Populate the instance variable for runDate.
		 */
		if (lineFields.length > 2) {
			runDate = lineFields[2].trim();
			success = true;
		}

		if (success) {
			sqlRunDate = new java.sql.Date(YYYYDDD_FORMAT.parse(runDate).getTime());
			runDate = MMDDYYYY_FORMAT.format(YYYYDDD_FORMAT.parse(runDate));

			String runDatequery = "SELECT PROC_DT FROM RABC_CYCLE_CALENDAR WHERE PROC_DT = to_date('" + runDate + "','MMddyyyy')";
			boolean isRunDateExists	= RetrieveStaticInfo.isProcDateExists(connection, runDatequery);

			if (!isRunDateExists) {
				throw new Exception("The cycle date " + runDate + " does not exist in RABC_CYCLE_CALENDAR table.");
			}

			if ("Y".equals(backoutRecovery)) {
				if (!PrepareTableForRerun.deleteTableData(connection, RABC_ICBS_RETURN, division, sqlRunDate)) {
					throw new Exception("Error occurred attempting to backup and recover for rerun for table: " + RABC_ICBS_RETURN);
				}
			}
		}

		return success;
	}

	/**
	 * Private method to process the deatil records.
	 * It does the following steps:
	 * 	1) Retrieves the fields from the line.
	 * 	2) Does conversion of data from String to appropriate data types as well as interpretation for amount.
	 * 	3) Creates the objects of ICBSReturn type.
	 * 	4) Populates the hash map with those objects.
	 *
	 * @param line
	 * @return boolean
	 * @throws Exception
	 */
	private boolean processErrorRecord(String line) throws Exception {
		boolean success = false;

		String [] lineFields = line.split(fieldSeperator);

		if (lineFields.length == 7) {
			String recordType		= lineFields[0].trim();
			String seqNumber		= lineFields[1].trim();
			String entityCode		= getEntityCode(lineFields[2].trim());
			String recordId			= lineFields[3].trim();
			String returnCode		= lineFields[4].trim();
			String totalMsgCnt		= lineFields[5].trim();
			String totalMsgAmt		= lineFields[6].trim();

			if (!"".equals(entityCode)) {
				success = true;

				/*
				 * Format the count & amount values
				 */
				long totalCount				= Long.parseLong(totalMsgCnt.substring(0,totalMsgCnt.length()-6));
				String amountUnitPart		= totalMsgAmt.substring(0,totalMsgAmt.length()-8);
				String amountDecimalPart 	= totalMsgAmt.substring(amountUnitPart.length(),totalMsgAmt.length());
				String actualAmount			= amountUnitPart + "." + amountDecimalPart;
				double totalAmount			= Double.parseDouble(actualAmount);

				/*
				 * Get the Return Code
				 */
				String rtnCd = null;
				if (returnCode.length() > 4) {
					rtnCd = returnCode.substring(0, 4);
				} else {
					rtnCd = returnCode;
				}

				/*
				 * Get the Data File
				 */
				String dataFile	= null;
				if ("02".equals(seqNumber) || "03".equals(seqNumber)){
					dataFile = "IBIXC";
				}else if ("04".equals(seqNumber) || "05".equals(seqNumber)) {
					dataFile = "IBADJ";
				}else if ("10".equals(seqNumber) || "11".equals(seqNumber)) {
					dataFile = "IBEMS";
				}

				/*
				 * Create an object of ICBSReturn type
				 */
				ICBSReturn icbsReturn = new ICBSReturn();
				icbsReturn.setRunDate(MMDDYYYY_FORMAT.parse(runDate));
				icbsReturn.setDivision(division);
				icbsReturn.setEntityCd(entityCode);
				icbsReturn.setDataFile(dataFile);
				icbsReturn.setRtnCd(rtnCd);

				/*
				 * Check whether the above object is present in the hash map
				 */
				ICBSReturn icbsObjRef = null;
				icbsObjRef = (ICBSReturn) icbsReturnMap.get(icbsReturn);

				if (icbsObjRef!=null){
					long newRtnCnt;
					double newRtnAmt;

					if (totalAmount < 0) {
						newRtnCnt = icbsObjRef.getTotRtnCntCr() + totalCount;
						newRtnAmt = icbsObjRef.getTotRtnAmtCr() + totalAmount;
						icbsObjRef.setTotRtnCntCr(newRtnCnt);
						icbsObjRef.setTotRtnAmtCr(newRtnAmt);
					} else {
						newRtnCnt = icbsObjRef.getTotRtnCntDb() + totalCount;
						newRtnAmt = icbsObjRef.getTotRtnAmtDb() + totalAmount;
						icbsObjRef.setTotRtnCntDb(newRtnCnt);
						icbsObjRef.setTotRtnAmtDb(newRtnAmt);
					}
					icbsReturnMap.put(icbsObjRef,icbsObjRef);
				} else {
					if (totalAmount < 0) {
						icbsReturn.setTotRtnCntCr(totalCount);
						icbsReturn.setTotRtnAmtCr(totalAmount);
					} else {
						icbsReturn.setTotRtnCntDb(totalCount);
						icbsReturn.setTotRtnAmtDb(totalAmount);
					}
					icbsReturnMap.put(icbsReturn,icbsReturn);
				}
			}
		}

		return success;
	}

	/**
	 * Private method to return the entity code  to be inserted into the table.
	 *
	 * @param entityCd
	 * @return String
	 */
	private String getEntityCode(String entityCd) {
		String entityCode = entityCd;

		if (entityCd.length() > 5) {
			entityCode = entityCd.substring(3, entityCd.length()-3);
			if (entityCode.length() > 8) {
				entityCode = entityCode.substring(0, 8);
			}
		}

		return entityCode;
	}

	/**
	 * Overriding postProcessFile(file, success) method.
	 * It is executed post to processing the file to be loaded.
	 * It includes the following steps:
	 * 	1) It checks whether the header and trailer records exists and
	 * 	   whether the total number of records (excluding header and trailer records)
	 * 	   in the file is eqaul to the count in the trailer record.
	 * 	   If it is then prcoceeds to next step else return false.
	 * 	2) Loop through the map icbsReturnMap and insert entries into RABC_ICBS_RETURN table.
	 * 	3) Makes the entries into RABC_TRIG table.
	 *
	 * @see com.sbc.bac.load.FileDBLoadJob#postprocessFile(java.io.File, boolean)
	 */
	public boolean postprocessFile(File file, boolean success) {
		try{

			//Log the file information to EMCIS_EVENT_LOG and EMCIS_EVENT_LOG_DETAIL
			EmcisEventLogger emcisLogger = new EmcisEventLogger();
			String event_id = "RABC_"+fileToken+"_WE";
            String host = NetUtil.getLocalHostName();
            String hostIP = NetUtil.getLocalIpAddress();
			int sequence = emcisLogger.getEMCISSequence(connection);
			emcisLogger.insertEventLog(connection, sequence, event_id, sqlRunDate, host, hostIP);
			emcisLogger.insertEventLogDetail(connection, sequence, "FileName", fileName);

		}catch (UnknownHostException e) {
            severe("Error getting EMCIS host information ", e);
        }
		if (success) {
			if (!isTrailerExists) {
				severe("Trailer record is not present in the file.");
				success = false;
			} else if (!isRecordCountMatches) {
				severe("Total number of records in the file is not eqaul to the count in the trailer record.");
				success = false;
			} else {
				try {
					/*
					 * Iterate through the entire hash map and insert entries into the RABC_ICBS_RETURN table
					 */
					Set icbsReturnSet			= icbsReturnMap.keySet();
					Iterator icbsReturnIterator = icbsReturnSet.iterator();

					while (icbsReturnIterator.hasNext()){
						batchCounter++;

						ICBSReturn icbsReturn = (ICBSReturn)icbsReturnIterator.next();
						insertReturn.setDate(1,sqlRunDate);
						insertReturn.setString(2, division);
						insertReturn.setString(3,icbsReturn.getEntityCd());
						insertReturn.setString(4,icbsReturn.getDataFile());
						insertReturn.setString(5,icbsReturn.getRtnCd());
						insertReturn.setLong(6,icbsReturn.getTotRtnCntDb());
						insertReturn.setDouble(7,icbsReturn.getTotRtnAmtDb());
						insertReturn.setLong(8,icbsReturn.getTotRtnCntCr());
						insertReturn.setDouble(9,icbsReturn.getTotRtnAmtCr());
						insertReturn.addBatch();

						if (batchCounter % 1000 == 0){
							insertReturn.executeBatch();
						}
						isReturn = true;
					}

					/*
					 * Execute the last batch
					 */
					insertReturn.executeBatch();

					/*
					 * Call the private method to make the entries into RABC_TRIG table
					 */
					if (!insertTrigger()) {
						success = false;
					}
				} catch (SQLException sqle){
					severe(StaticErrorMsgKeys.INSERT_ERROR + sqle.getMessage(), sqle);
					success = false;
				}
			}
		}

		return super.postprocessFile(file, success);
	}

	/**
	 * Private method to insert entry into RABC_TRIG table.
	 *
	 * @return boolean
	 */
	private boolean insertTrigger() {
		try {
			String query 	= "SELECT to_char(BILL_RND,'00') FROM RABC_CYCLE_CALENDAR WHERE BILL_RND_DT = to_date('" + runDate + "','MMddyyyy') and bill_rnd != 0 and bill_rnd is not null";
			String billRnd	= RetrieveStaticInfo.getBillRnd(connection, query);
			if ("0".equals(billRnd) || "00".equals(billRnd) || "".equals(billRnd.trim())){
				billRnd = "0";
			}

			/*
			 * Check whether there were any return record inserted, if yes then insert into trigger
			 */
			if (isReturn) {
				if(!RabcLoadJobTrig.insertTrigger(connection, currentFile.getName().substring(4,currentFile.getName().length()), currentFile.getName(), FILE_ID, division, runDate , backoutRecovery, billRnd, RABC_TRIG)) {
					return false;
				}
			}
		} catch (Exception e) {
			severe(StaticErrorMsgKeys.POSTPROCESSFILE_ERROR + StaticErrorMsgKeys.TIGGER_TABLE_INSERT_ERROR + e.getMessage(), e);
			return false;
		}

		return true;
	}

	/**
	 * Overriding postProcess(success) method.
	 * It is executed post to processing the load job.
	 * It includes the following steps:
	 * 	1) Closes statements that were opened for this load job.
	 *
	 * @see com.sbc.bac.load.LoadJob#postprocess(boolean)
	 */
	public boolean postprocess(boolean success) {
		try {
			insertReturn.close();
		} catch (SQLException e) {
			severe(StaticErrorMsgKeys.POSTPROCESS_ERROR + StaticErrorMsgKeys.SQL_CLOSE_ERROR + e.getMessage(), e);
			success = false;
		}

		return super.postprocess(success);
	}
	
	/**
	 * Method returns the division
	 * @param division
	 * @return
	 */
	private String getDivision(String division){
		if ("F".equals(division)){
			return "PN";
		}else if ("S".equals(division)){
			return "PS";
		}else {
			return "PN";
		}
	}
}
