/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.admin.adhoc.rpt;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;
import com.att.bac.rabc.ConnectionManager;
import com.att.bac.rabc.ProgressBar;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.Tree;
import com.att.bac.rabc.TreeService;

/**
 * Module description: 
 * 
 * This is an Adhoc definition Page Action class. 
 *
 * @author Umesh Deole - UD7153
 */
public class AdhocReportDefinitionAction extends DispatchAction {
	private static final Logger logger = Logger.getLogger(AdhocReportDefinitionAction.class);
	AdhocReportDefinitionService adhocReportDefinitionService = AdhocReportDefinitionService.getAdhocReportDefinitionService();
	
	/**
	 * Dispatch action method to handle the request to define new Adhoc Report.
	 * This method is executed when the user clicks on "new Report" button from the adhoc main page
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward newReport(ActionMapping mapping,ActionForm form,HttpServletRequest request, HttpServletResponse response){
		AdhocReportDefinitionForm adhocReportDefinitionForm = (AdhocReportDefinitionForm) form;
		HttpSession session = request.getSession();
		ProgressBar progressBar = new ProgressBar(session);
		adhocReportDefinitionForm.setOperation("new");
		AdhocReportDefinition adhocReportDefinition = new AdhocReportDefinition();
		ActionForward forward = null ;
		List failureList = new ArrayList();
		List args = new ArrayList();
		
		args.add((String)request.getSession().getAttribute("bacUserID")) ;
		progressBar.setProgressPercent(10);
		
		/* Step 1 
		 *  Call the private method to populate the default values required for Step 1 
		 *  and add it to adhocReportDefinition object
		 */
		populateOptionValuesStep1(adhocReportDefinition,failureList,args,progressBar,(String)request.getSession().getAttribute("region"));

		/*
		 * set the setAdhocReportDefinition to the form
		 */
		adhocReportDefinitionForm.setAdhocReportDefinition(adhocReportDefinition);
		
		progressBar.setProgressPercent(100);
		if (!failureList.isEmpty()){
			request.setAttribute("failures", failureList);
			forward = mapping.findForward("error");
		}else{
		
			forward = mapping.findForward("AdhocReportDefinitionStep1");
		}	
		return forward;
	}

	/**
	 * Dispatch action method to handle the request to update Adhoc Report.
	 * This method is executed when the user clicks on "Update Report" button from the adhoc main page
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward updateReport(ActionMapping mapping,ActionForm form,HttpServletRequest request, HttpServletResponse response){
		AdhocReportDefinitionForm adhocReportDefinitionForm = (AdhocReportDefinitionForm) form;
		HttpSession session = request.getSession();
		ProgressBar progressBar = new ProgressBar(session);
		AdhocReportDefinition adhocReportDefinition = new AdhocReportDefinition();
		adhocReportDefinitionForm.setOperation("update");
		ActionForward forward = null ;
			
		/*
		 * Collect the parameters passed which in this case would be the report id
		 */
		String reportId = null;
		reportId = (String)request.getAttribute("presnId");

		List failureList = new ArrayList();
		List args = new ArrayList();
		
		args.add((String)request.getSession().getAttribute("bacUserID")) ;//args[0] - logged in user id , args[1] - report id , args[2] - current section
		
		/*
		 * args[0] - logged in user id , args[1] - report id , args[2] - current section
		 */  
		args.add(reportId);
		progressBar.setProgressPercent(10);

		Connection connection = null ; 
		try {
			connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
			progressBar.setProgressPercent(20);
			String activeSectionStr = adhocReportDefinitionService.getActiveSectionStr(connection,adhocReportDefinition,failureList,args);
			progressBar.setProgressPercent(30);
			String[] sectionArr = activeSectionStr.split("~");
			args.add(sectionArr[0]);
			
			// USE DEBUG build the adhocReportDefinition object for respective report   
			adhocReportDefinition = adhocReportDefinitionService.getAdhocReportDefinition(connection,failureList,args,progressBar,(String)request.getSession().getAttribute("region"));	
			adhocReportDefinition.setActiveSectionStr(activeSectionStr);
			
			/*
			 * Following code is changed adhocReportDefinition.setCurrentSection(Integer.parseInt(sectionArr[0])) to 
			 * adhocReportDefinition.setCurrentSection(sectionArr[dropdownvalue-1]);
			 * The dropdown values should be 1,2,3 etc regardless of exec_seq .then add the following line also
			 * adhocReportDefinition.setSectionIndex(dropdownvalue-1);
			 * In the testAndSave  method , if it is an update report , call the save method and go to main page 
			 */
			adhocReportDefinition.setCurrentSection(Integer.parseInt(sectionArr[0]));

		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
			forward = mapping.findForward("error");
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
			forward = mapping.findForward("error");
		} catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
            forward = mapping.findForward("error");
		} finally {
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		progressBar.setProgressPercent(100);
		
		/*
		 * Set the list options for page 1
		 */
		adhocReportDefinitionForm.setAdhocReportDefinition(adhocReportDefinition);
		
		forward = mapping.findForward("AdhocReportDefinitionStep1");
		if (!failureList.isEmpty()){
			request.setAttribute("failures", failureList);
			forward = mapping.findForward("error");
		}
		return forward;
	}
	
	/**
	 * Dispatch action method to handle the request to copy Adhoc Report.
	 * This method is executed when the user clicks on "Copy Report" button from the adhoc main page
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward copyReport(ActionMapping mapping,ActionForm form,HttpServletRequest request, HttpServletResponse response){
		AdhocReportDefinitionForm adhocReportDefinitionForm = (AdhocReportDefinitionForm) form;
		HttpSession session = request.getSession();
		ProgressBar progressBar = new ProgressBar(session);
		AdhocReportDefinition adhocReportDefinition = new AdhocReportDefinition();
		adhocReportDefinitionForm.setOperation("update");
		ActionForward forward = null ;
			
		/*
		 * Collect the parameters passed which in this case would be the report id
		 */
		String reportId = null;
		reportId = (String)request.getAttribute("presnId");
		
		//copy is same as update , only difference is data is being inserted in the case of copy
		forward = updateReport(mapping,form,request,response);

		//set the copy attribute to true and do the same step as of update
		adhocReportDefinitionForm.getAdhocReportDefinition().setCopyReport(true);
		adhocReportDefinitionForm.setOperation("copy");
		return forward;
	}
	
	/**
	 * Dispatch action method to handle the request to take user to next step.
	 * This method is executed when the user clicks on "Next" button on Step 2 / step 3 
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward nextStep(ActionMapping mapping,ActionForm form,HttpServletRequest request, HttpServletResponse response){
		
		AdhocReportDefinitionForm adhocReportDefinitionForm = (AdhocReportDefinitionForm) form;
		HttpSession session = request.getSession();
		ProgressBar progressBar = new ProgressBar(session);
		AdhocReportDefinition adhocReportDefinition = adhocReportDefinitionForm.getAdhocReportDefinition();
		
		/*
		 * If the entire logic is successfully executed based on size of failure list, then have the conditions to 
		 * re direct to respective page
		 */
		List failureList = new ArrayList();
		
		List args = new ArrayList();
		
		List permissionArgs = new ArrayList();
		permissionArgs.add((String)request.getSession().getAttribute("bacUserID")) ;
		
		progressBar.setProgressPercent(10);
		
		Connection connection = null ; 
		
		ActionForward forward = null ;

		if (adhocReportDefinition.getCurrentSection()==0)
		{
			adhocReportDefinition.setCurrentSection(1);
		}	
	
		// if current step is 1, then build step 2 object, update visible flag and goto step2
		try {
			connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
			progressBar.setProgressPercent(20);
			if ("1".equals(adhocReportDefinitionForm.getStepNumber())) {

				/** Step 2 
				 *  1. Build the adhocReportStep2 
				 *  2. Add it to adhocReportStep2List 
				 *  3. Add this list to adhocReportDefinition Object
				 */
				AdhocReportDefinitionService adhocReportDefinitionService  = AdhocReportDefinitionService.getAdhocReportDefinitionService();
				// If the user has unchecked the report section checkbox 
				if ((adhocReportDefinitionForm.getDelRptId()!=null) && (!"".equals(adhocReportDefinitionForm.getDelRptId()))){
					List delArgs = new ArrayList();	
					delArgs.add(Integer.toString(adhocReportDefinition.getPresnId()));
					delArgs.add(adhocReportDefinitionForm.getDelRptId());
					adhocReportDefinitionService.deleteReportSection(connection, delArgs,failureList);
					progressBar.setProgressPercent(30);
					request.setAttribute("presnId",Integer.toString(adhocReportDefinition.getPresnId()));
					// written explicit commit to commit the transaction after deleteing report section 
					if (!failureList.isEmpty()){
						try {
							connection.rollback();
						}catch(SQLException sx) {
						   logger.error(RABCMessages.getMessage("ERR_SQL_ROLLBACK_EXEC") + " Exception details: " + sx.getMessage(), sx);
						   failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_ROLLBACK_EXEC"), sx));
						} 
					}else {
						// No errors; commit the transaction
						try {
							connection.commit();
						}catch(SQLException sx) {
						   logger.error(RABCMessages.getMessage("ERR_SQL_COMMIT_EXEC") + " Exception details: " + sx.getMessage(), sx);
						   failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_COMMIT_EXEC"), sx));
						} 
					}
					forward = updateReport(mapping,form,request,response);
				}else{
						//do the duplicate check only for new and copy report
						if ((adhocReportDefinition.getPresnId()==0)||(adhocReportDefinition.isCopyReport())){
							boolean isDuplicate = adhocReportDefinitionService.isDuplicateReportName(connection,args,failureList,adhocReportDefinition);
							adhocReportDefinitionForm.setDuplicateReportName(isDuplicate);
						}
						progressBar.setProgressPercent(30);
						if (adhocReportDefinitionForm.isDuplicateReportName()){
							//if duplicate , go to step1 and display the message
							
							forward = mapping.findForward("AdhocReportDefinitionStep1");
							progressBar.setProgressPercent(80);
						}else{
							TreeService treeService = new TreeService();
							Tree tree = treeService.generateTree(connection, failureList, args, (String)request.getSession().getAttribute("region"));
							adhocReportDefinitionForm.setTableTree(tree);
							
							String billRndTableStr = "" ; 
							billRndTableStr = adhocReportDefinitionService.getBillRndTableStr((String)request.getSession().getAttribute("region")) ;
							adhocReportDefinitionForm.setBillRndTableStr(billRndTableStr) ;
							
							progressBar.setProgressPercent(60);
							
							/* if the user check the "new section" check box add the following line here
							 * adhocReportDefinition.setSectionIndex(adhocReportDefinition.getNbrRptSections()-1);
							 * the above line point the section index to the last 
							 * adhocReportDefinition.setNbrRptSections(adhocReportDefinition.getNbrRptSections()+1);
							 * the above line increment the number of sections
							 */
							
							String activeSectionStr = adhocReportDefinition.getActiveSectionStr();
							
							String[] sectionArr = activeSectionStr.split("~");
							
							if ("Y".equals(adhocReportDefinition.getNewSection()) && (("update".equals(adhocReportDefinitionForm.getOperation())) || (adhocReportDefinitionForm.getAdhocReportDefinition().isCopyReport()))) {
								adhocReportDefinition.setNbrRptSections(adhocReportDefinition.getNbrRptSections()+1) ;
								if (! (adhocReportDefinitionForm.getAdhocReportDefinition().isCopyReport()))
									adhocReportDefinition.setSectionIndex(sectionArr.length);
								
							} else {
								if ("update".equals(adhocReportDefinitionForm.getOperation())) { // check for new section chek box when completed coding for update 
									adhocReportDefinition.setCurrentSection(Integer.parseInt(sectionArr[Integer.parseInt(adhocReportDefinition.getSectionToEdit())-1]));
									adhocReportDefinition.setSectionIndex(Integer.parseInt(adhocReportDefinition.getSectionToEdit())-1);
								}
								
							}
							progressBar.setProgressPercent(70);
							
							//if the number of report sections entered by the user is more, we 
							//have to add the remaining step2 and step3 objects to the list 
							
							if (adhocReportDefinition.getNbrRptSections()>adhocReportDefinition.getAdhocReportStep2List().size())
							{
								int cur_section = 1 ;
								int sectionIndexTemp = 0 ;
								cur_section = adhocReportDefinition.getCurrentSection();
								sectionIndexTemp = 	adhocReportDefinition.getSectionIndex();
								
								for (int i=adhocReportDefinition.getAdhocReportStep2List().size();i<adhocReportDefinition.getNbrRptSections();i++) {
									AdhocReportStep2 adhocReportStep2 = new AdhocReportStep2();
									AdhocReportStep3 adhocReportStep3 = new AdhocReportStep3();

									adhocReportDefinition.addAdhocReportStep2List(adhocReportStep2);
									adhocReportDefinition.addAdhocReportStep3List(adhocReportStep3);
									if ("".equals(activeSectionStr)){
										adhocReportDefinition.setCurrentSection(i+1);
										adhocReportDefinition.setActiveSectionStr(adhocReportDefinition.getActiveSectionStr()+(i+1)+"~");
									}else{
										adhocReportDefinition.setCurrentSection(Integer.parseInt(sectionArr[sectionArr.length-1])+1);
										adhocReportDefinition.setActiveSectionStr(adhocReportDefinition.getActiveSectionStr()+(Integer.parseInt(sectionArr[sectionArr.length-1])+1)+"~");
									}
									adhocReportDefinition.setSectionIndex(i);
									
									populateOptionValuesStep2(adhocReportDefinition,failureList,args) ;
									adhocReportDefinitionService.populateOptionValuesStep3(adhocReportDefinition,connection,failureList,args) ;
								}
								if (("new".equals(adhocReportDefinitionForm.getOperation())) || adhocReportDefinitionForm.getAdhocReportDefinition().isCopyReport()) {
									adhocReportDefinition.setCurrentSection(cur_section);
									adhocReportDefinition.setSectionIndex(sectionIndexTemp);
								}
							}
							progressBar.setProgressPercent(80);
							
							if (("update".equals(adhocReportDefinitionForm.getOperation()))) {
								adhocReportDefinition.setKeyHeaderStr(adhocReportDefinitionService.getkeyHeaderStr(adhocReportDefinition,failureList,args));
								adhocReportDefinition.setKeyHeaderStrHidden(adhocReportDefinitionService.getkeyHeaderStr(adhocReportDefinition,failureList,args));
							}
							
							/*
							 * Update / Get details of current step 2 object
							 * Since we are only considering current Step 2 object during update as well we will not touch 
							 * objects which have their columnDetails value as null
							 */
							
							adhocReportDefinitionForm.setAdhocReportDefinition(adhocReportDefinition);
							forward = mapping.findForward("AdhocReportDefinitionStep2");
							progressBar.setProgressPercent(90);
						}
				}
			}
			// if current step is 2, then build step 3 object update visible flag and goto step3
			else if ("2".equals(adhocReportDefinitionForm.getStepNumber())){
			
				//find whether the user has the permission to save the report 
				permissionArgs.add("UR") ;
				String hasPermission  = adhocReportDefinitionService.getPermissionAdhocReport(connection,permissionArgs,failureList);
				adhocReportDefinitionForm.setSaveEnabled(hasPermission);
				progressBar.setProgressPercent(30);
				adhocReportDefinitionForm.setFileSequenceIndicator(((AdhocReportStep3)adhocReportDefinition.getAdhocReportStep3List().get(adhocReportDefinition.getSectionIndex())).getFileSequenceIndicator());
				//add the data to the object manually . this is need to be done because of the
				//compatibility with javascript 
				((AdhocReportStep2)adhocReportDefinition.getAdhocReportStep2List().get(adhocReportDefinition.getSectionIndex())).setData(adhocReportDefinitionForm.getData());
				
				String colString = ((AdhocReportStep2)adhocReportDefinition.getAdhocReportStep2List().get(adhocReportDefinition.getSectionIndex())).getData();
				progressBar.setProgressPercent(40);
				
				//get the list of distinct table names submitted from step2
				List tableList =adhocReportDefinitionService.extractTableNames(connection,failureList,colString);
				progressBar.setProgressPercent(60);
				
				//set it into the step3 object
				((AdhocReportStep3)adhocReportDefinition.getAdhocReportStep3List().get(adhocReportDefinition.getSectionIndex())).setTableList(tableList);
				
				//based on the tables and columns selected from step2 , build the adhoc keys in step3
				adhocReportDefinitionService.buildAdhocKey(adhocReportDefinition,connection,failureList,(String)request.getSession().getAttribute("region"));
				progressBar.setProgressPercent(80);
				
				//set if the filesequence indicator is disabled ot not
				//((AdhocReportStep3)adhocReportDefinition.getAdhocReportStep3List().get(adhocReportDefinition.getSectionIndex())).setIsFileSequenceIndicatorDisabled(adhocReportDefinitionService.getIsFileSequenceIndicatorDisabled(adhocReportDefinition,failureList));
				//enable and disable adhocReport step 3 objects like File Seq # Ind , layout ,Report Duration Time
				adhocReportDefinitionService.enableDisableStep3FormElements(adhocReportDefinition,failureList,(String)request.getSession().getAttribute("region"));
				
				adhocReportDefinitionForm.setAdhocReportDefinition(adhocReportDefinition);
				progressBar.setProgressPercent(90);
				forward = mapping.findForward("AdhocReportDefinitionStep3");

			}
			else {
				forward = mapping.findForward("AdhocReportDefinitionStep1");
			}
		
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch(Exception e){
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		progressBar.setProgressPercent(100);
		
		if (!failureList.isEmpty()){
			request.setAttribute("failures", failureList);
			forward =  mapping.findForward("error");
		}
		return forward;
	}

	/**
	 * Dispatch action method to take user to previous step.
	 * This method is executed when the user clicks on "Back" button on Step 2 / step 3 
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward back(ActionMapping mapping,ActionForm form,HttpServletRequest request, HttpServletResponse response){
		AdhocReportDefinitionForm adhocReportDefinitionForm = (AdhocReportDefinitionForm) form;
		HttpSession session = request.getSession();
		ProgressBar progressBar = new ProgressBar(session);
		AdhocReportDefinition adhocReportDefinition = adhocReportDefinitionForm.getAdhocReportDefinition();
		
		ActionForward forward = null ;
		
		
		if (! ("new".equals(adhocReportDefinitionForm.getOperation())) && "2".equals(adhocReportDefinitionForm.getStepNumber()) && "Y".equals(adhocReportDefinition.getNewSection())) {

			List adhocReportStep2TempList = new ArrayList();  
			List adhocReportStep3TempList = new ArrayList();  
			
			adhocReportDefinition.setNbrRptSections(adhocReportDefinition.getNbrRptSections()-1) ;
			
			int i = 0 ;
			
			for ( i = 0 ; i < adhocReportDefinition.getNbrRptSections() ; i++){
				adhocReportStep2TempList.add(adhocReportDefinition.getAdhocReportStep2List().get(i)) ;
			}
			
			for (i = 0 ; i < adhocReportDefinition.getNbrRptSections() ; i++){
				adhocReportStep3TempList.add(adhocReportDefinition.getAdhocReportStep3List().get(i)) ;
			}
			
			adhocReportDefinition.getAdhocReportStep2List().clear() ;
			adhocReportDefinition.getAdhocReportStep3List().clear() ;
			
			for (i = 0 ; i < adhocReportStep2TempList.size() ; i++){
				AdhocReportStep2 adhocReportStep2 = (AdhocReportStep2)adhocReportStep2TempList.get(i);
				adhocReportDefinition.addAdhocReportStep2List(adhocReportStep2) ;
			}
			
			for (i = 0 ; i < adhocReportStep3TempList.size() ; i++){
				AdhocReportStep3 adhocReportStep3 = (AdhocReportStep3)adhocReportStep3TempList.get(i);
				adhocReportDefinition.addAdhocReportStep3List(adhocReportStep3) ;
			}
			
			String activeSectionStr = adhocReportDefinition.getActiveSectionStr().substring(0, (adhocReportDefinition.getActiveSectionStr().length()-2));
			adhocReportDefinition.setActiveSectionStr(activeSectionStr) ;
			
			if (adhocReportDefinition.getNbrRptSections() > 1 ) {
				if ((adhocReportDefinition.isCopyReport())) {
				adhocReportDefinition.setCurrentSection(adhocReportDefinition.getCurrentSection());
				adhocReportDefinition.setSectionIndex(adhocReportDefinition.getSectionIndex());
				}else {
				adhocReportDefinition.setCurrentSection(adhocReportDefinition.getCurrentSection()-1);
				adhocReportDefinition.setSectionIndex(adhocReportDefinition.getSectionIndex()-1);
				}
			}else {
				adhocReportDefinition.setCurrentSection(1) ;
				adhocReportDefinition.setSectionIndex(0) ;
			}

			forward = mapping.findForward("AdhocReportDefinitionStep1");
			
		} else if ("3".equals(adhocReportDefinitionForm.getStepNumber())){
			forward = mapping.findForward("AdhocReportDefinitionStep2");
		} else {
			forward = mapping.findForward("AdhocReportDefinitionStep1");
		}
		
		progressBar.setProgressPercent(100);
		
		return forward;
	}
	
	/**
	 * Dispatch action method to test the adhoc report after defining all section.
	 * This method is executed when the user clicks on "Test" on step 3  
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward test(ActionMapping mapping,ActionForm form,HttpServletRequest request, HttpServletResponse response){
		AdhocReportDefinitionForm adhocReportDefinitionForm = (AdhocReportDefinitionForm) form;
		HttpSession session = request.getSession();
		ProgressBar progressBar = new ProgressBar(session);
		AdhocReportDefinition adhocReportDefinition = adhocReportDefinitionForm.getAdhocReportDefinition();
		
		if (request.getParameter("fileSequenceIndicator") == null ){
			((AdhocReportStep3)adhocReportDefinition.getAdhocReportStep3List().get(adhocReportDefinition.getSectionIndex())).setFileSequenceIndicator("N") ;
		} else {
			((AdhocReportStep3)adhocReportDefinition.getAdhocReportStep3List().get(adhocReportDefinition.getSectionIndex())).setFileSequenceIndicator(request.getParameter("fileSequenceIndicator"));
		}
		
		ActionForward forward;
		Connection connection = null;
		List failureList = new ArrayList();
		List args = new ArrayList(); 
		
		try {
			connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
			connection.setAutoCommit(false);
			progressBar.setProgressPercent(10);
			
			// Marks the transaction
			adhocReportDefinitionService.test(connection, failureList, adhocReportDefinition, progressBar, (String)request.getSession().getAttribute("region"));
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch (Exception e){
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		}finally {
			// If update did not occur properly then failure list would not be empty; rollback the transaction
			if (!failureList.isEmpty()){
				try {
					connection.rollback();
				}catch(SQLException sx) {
				   logger.error(RABCMessages.getMessage("ERR_SQL_ROLLBACK_EXEC") + " Exception details: " + sx.getMessage(), sx);
				   failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_ROLLBACK_EXEC"), sx));
				} 
			}else {
				// No errors; commit the transaction
				try {
					connection.commit();
				}catch(SQLException sx) {
				   logger.error(RABCMessages.getMessage("ERR_SQL_COMMIT_EXEC") + " Exception details: " + sx.getMessage(), sx);
				   failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_COMMIT_EXEC"), sx));
				} 
			}
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		progressBar.setProgressPercent(100);
		
		/*
		 * Decide to which page you want to take the user to
		 */		
		if (!failureList.isEmpty()){
			forward = mapping.findForward("error");
		}else{
			return mapping.findForward("AdhocReportDefinitionStep3");
		}
		return forward;
	}
	
	/**
	 * Dispatch action method to save the adhoc report after defining all sections.
	 * This method is executed when the user clicks on "Save" on step 3  
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */	
	public ActionForward save(ActionMapping mapping,ActionForm form,HttpServletRequest request, HttpServletResponse response){
		AdhocReportDefinitionForm adhocReportDefinitionForm = (AdhocReportDefinitionForm) form;
		HttpSession session = request.getSession();
		ProgressBar progressBar = new ProgressBar(session);
		AdhocReportDefinition adhocReportDefinition = adhocReportDefinitionForm.getAdhocReportDefinition();
		ActionForward forward;
		Connection connection = null;
		List failureList = new ArrayList();
		List args = new ArrayList();
		progressBar.setProgressPercent(10);
		  
		try {
			connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
			connection.setAutoCommit(false);
			progressBar.setProgressPercent(30);
			
			// Marks the transaction
			//Update the report status = active only when user clicks on save of last report section 
			if ((adhocReportDefinition.getSectionIndex()+1) == adhocReportDefinition.getNbrRptSections()){
				adhocReportDefinitionService.save(connection, failureList, adhocReportDefinition);
				progressBar.setProgressPercent(80);
			}
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			// If update did not occur properly then failure list would not be empty; rollback the transaction
			if (!failureList.isEmpty()){
				try {
					connection.rollback();
				}catch(SQLException sx) {
				   logger.error(RABCMessages.getMessage("ERR_SQL_ROLLBACK_EXEC") + " Exception details: " + sx.getMessage(), sx);
				   failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_ROLLBACK_EXEC"), sx));
				} 
			}else {
				// No errors; commit the transaction
				try {
					connection.commit();
				}catch(SQLException sx) {
				   logger.error(RABCMessages.getMessage("ERR_SQL_COMMIT_EXEC") + " Exception details: " + sx.getMessage(), sx);
				   failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_COMMIT_EXEC"), sx));
				} 
			}
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		progressBar.setProgressPercent(90);
		
		/*
		 * Decide to which page you want to take the user to
		 */		
		adhocReportDefinition.setSectionIndex(adhocReportDefinition.getSectionIndex()+1);
		
		if (!failureList.isEmpty()){
			forward = mapping.findForward("error");
		}else if ((adhocReportDefinition.getSectionIndex())<adhocReportDefinition.getNbrRptSections()){
			String activeSectionStr = "" ;
			activeSectionStr = adhocReportDefinition.getActiveSectionStr() ;

			if (activeSectionStr.equals("")){
				adhocReportDefinition.setCurrentSection(adhocReportDefinition.getSectionIndex()+1);
			}else{
				String[] arr = activeSectionStr.split("~");			
				adhocReportDefinition.setCurrentSection(Integer.parseInt(arr[adhocReportDefinition.getSectionIndex()]));
			}
			adhocReportDefinitionForm.setStepNumber("1");
			forward=nextStep(mapping,form,request, response);

		}else{
			adhocReportDefinitionForm.setDispatch("AdhocSave");
			forward = mapping.findForward("AdhocSave");
		}
		progressBar.setProgressPercent(100);
		
		return forward;
	}
	
	/**
	 * Dispatch action method to test and save the adhoc report after defining all sections.
	 * This method is executed when the user clicks on "Save" on step 3 in update mode  
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */	
	public ActionForward testAndSave(ActionMapping mapping,ActionForm form,HttpServletRequest request, HttpServletResponse response){
		AdhocReportDefinitionForm adhocReportDefinitionForm = (AdhocReportDefinitionForm) form;
		HttpSession session = request.getSession();
		ProgressBar progressBar = new ProgressBar(session);
		AdhocReportDefinition adhocReportDefinition = adhocReportDefinitionForm.getAdhocReportDefinition();
		ActionForward forward;
		Connection connection = null;
		List failureList = new ArrayList();
		List args = new ArrayList();
		
		if (request.getParameter("fileSequenceIndicator") == null ){
			((AdhocReportStep3)adhocReportDefinition.getAdhocReportStep3List().get(adhocReportDefinition.getSectionIndex())).setFileSequenceIndicator("N") ;
		} else {
			((AdhocReportStep3)adhocReportDefinition.getAdhocReportStep3List().get(adhocReportDefinition.getSectionIndex())).setFileSequenceIndicator(request.getParameter("fileSequenceIndicator"));
		}
		
		try {
			connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
			connection.setAutoCommit(false);
			progressBar.setProgressPercent(10);
			
			// Marks the transaction
			adhocReportDefinitionService.test(connection, failureList, adhocReportDefinition, progressBar, (String)request.getSession().getAttribute("region"));
			//	Update the report status = active only when user clicks on save of last report section
			if ("update".equals(adhocReportDefinitionForm.getOperation())) {
				adhocReportDefinitionService.save(connection, failureList, adhocReportDefinition);
				if (adhocReportDefinitionForm.getAdhocReportDefinition().getSectionIndex() == 0) {
					adhocReportDefinitionService.updatePresnId(connection, failureList, adhocReportDefinition);
				}
			} else if ((adhocReportDefinition.getSectionIndex()+1) == adhocReportDefinition.getNbrRptSections()){
				adhocReportDefinitionService.save(connection, failureList, adhocReportDefinition);
			}
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch (Exception e){
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		}finally {
			// If update did not occur properly then failure list would not be empty; rollback the transaction
			if (!failureList.isEmpty()){
				try {
					connection.rollback();
				}catch(SQLException sx) {
				   logger.error(RABCMessages.getMessage("ERR_SQL_ROLLBACK_EXEC") + " Exception details: " + sx.getMessage(), sx);
				   failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_ROLLBACK_EXEC"), sx));
				} 
			}else {
				// No errors; commit the transaction
				try {
					connection.commit();
				}catch(SQLException sx) {
				   logger.error(RABCMessages.getMessage("ERR_SQL_COMMIT_EXEC") + " Exception details: " + sx.getMessage(), sx);
				   failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_COMMIT_EXEC"), sx));
				} 
			}
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		progressBar.setProgressPercent(100);
		
		/*
		 * Decide to which page you want to take the user to
		 */		
		
		adhocReportDefinition.setSectionIndex(adhocReportDefinition.getSectionIndex()+1);
		
		if (!failureList.isEmpty()){
			forward = mapping.findForward("error");
		}  else if (adhocReportDefinitionForm.getAdhocReportDefinition().isCopyReport() && (adhocReportDefinition.getSectionIndex())<adhocReportDefinition.getNbrRptSections()){
			//adhocReportDefinition.setCurrentSection(adhocReportDefinition.getCurrentSection()+1);
			String activeSectionStr = adhocReportDefinition.getActiveSectionStr() ;
			String[] arr = activeSectionStr.split("~");			
			adhocReportDefinition.setCurrentSection(Integer.parseInt(arr[adhocReportDefinition.getSectionIndex()]));
			
			adhocReportDefinitionForm.setStepNumber("1");
			forward=nextStep(mapping,form,request, response);
			//forward = mapping.findForward("AdhocReportDefinitionStep2");
		}else{
			
			forward = mapping.findForward("AdhocReportDefinitionStep3");
		}
		
		return forward;
	}

    /**
     * It is Private internal method used across the action class to populate default values for the various parameters
     * 
     * @param adhocReportDefinition
     * @param failureList
     * @param args
     * @param progressBar
     * @param region
     */
    private void populateOptionValuesStep1(AdhocReportDefinition adhocReportDefinition,List failureList,List args,ProgressBar progressBar,String region) {
    
    	/*
		 * Call setter methods of the above class to set the default level attributes Step 1 
		*/
    	Connection connection = null ;
    	try {
    		connection = ConnectionManager.getConnection(region);
    		progressBar.setProgressPercent(20);
    		
    		adhocReportDefinition.setPresnDesc("");
			adhocReportDefinition.setRptType("") ;
			adhocReportDefinition.setReportTypeList(adhocReportDefinitionService.getReportTypeList(region));
			adhocReportDefinition.setDataNode("") ;
			adhocReportDefinition.setDataSourceList(adhocReportDefinitionService.getDataSourceList(region));
			adhocReportDefinition.setAlertGroup(adhocReportDefinition.getAlertGroup()) ;
			
			adhocReportDefinition.setUserDirectorySelected("");
			adhocReportDefinition.setUserDirRadioOption("useDefault");
			adhocReportDefinition.setUserDirNameText("");
			
			List userDirectoryList = adhocReportDefinitionService.getuserDirectoryList(connection, failureList, args) ;
			adhocReportDefinition.setUserDirectoryList(userDirectoryList);
			
			progressBar.setProgressPercent(30);
			
			adhocReportDefinition.setAlertGroupList(adhocReportDefinitionService.getAlertGroupList(connection,failureList,args)) ;
			progressBar.setProgressPercent(50);
			
			adhocReportDefinition.setHeader1("") ;
			adhocReportDefinition.setHeader2("") ;
			adhocReportDefinition.setHeader3("") ;
			adhocReportDefinition.setNbrRptSections(1) ;
			
			adhocReportDefinition.setReportTypeList(adhocReportDefinitionService.getReportTypeList(region));
			adhocReportDefinition.setSortList(adhocReportDefinitionService.getSortList());
			adhocReportDefinition.setUnitList(adhocReportDefinitionService.getUnitList());
			progressBar.setProgressPercent(60);
			
			AdhocMainPageService adhocService = new AdhocMainPageService();
			
			// Get the existing adhoc reports and store them in arraylist
			List result = adhocService.getReportNameList(connection,failureList,args) ;
			progressBar.setProgressPercent(80);
			adhocReportDefinition.setReportLinkList(result);
			adhocReportDefinition.setMouseOverList(adhocReportDefinitionService.getMouseOverList(connection,failureList,args));
			progressBar.setProgressPercent(90);
			
    	} catch(SQLException sx) {
			   logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			   failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failureList, logger);
		}
    }
    
	/**
	 * This method is called when the user makes any changes to the views
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward reloadTable(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		AdhocReportDefinitionForm  adhocReportDefinitionForm = (AdhocReportDefinitionForm) form;
		AdhocReportDefinition adhocReportDefinition = adhocReportDefinitionForm.getAdhocReportDefinition();
		Connection connection = null;
		HttpSession session = null;
		Tree tableTree;
		
		/*
		 * Initialize lists of arguments as well as failures
		 */
		List failureList = new ArrayList();
		List args = new ArrayList();
		session = request.getSession(true);
		
		try{
			connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
			TreeService treeService = new TreeService();
			tableTree = treeService.generateTree(connection, failureList, args, (String)request.getSession().getAttribute("region"));
			adhocReportDefinitionForm.setTableTree(tableTree);
		} catch(SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
		} catch(Exception e){
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}) + " Exception details: " + e.getMessage(), e);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
		} finally {
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		
		if (!failureList.isEmpty()){
			request.setAttribute("failures", failureList);
			return mapping.findForward("error");
		} else {
			return mapping.findForward("AdhocReportDefinitionStep2");
		}
	}

	/**
	 * This is a private method used to populate blank column data string for new report case 
	 * @param adhocReportDefinition
	 * @param failureList
	 * @param args
	 */
	private void populateOptionValuesStep2(AdhocReportDefinition adhocReportDefinition,List failureList,List args) {
    	 ((AdhocReportStep2)adhocReportDefinition.getAdhocReportStep2List().get(adhocReportDefinition.getSectionIndex())).setData("");
    }
     
    /**
     * Dispatch action method to display the adhoc report layout 1 screen.
     * This method is executed when user clicks on hyper link on AdhocLayout1 radio button on step 3. 
     * 
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return ActionForward
     */
    public ActionForward AdhocLayout1(ActionMapping mapping,ActionForm form,HttpServletRequest request, HttpServletResponse response){
    	return mapping.findForward("AdhocLayout1");
    }
    
    /**
     * Dispatch action method to display the adhoc report layout 2 screen.
     * This method is executed when user clicks on hyper link on AdhocLayout2 radio button on step 3. 
     * 
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return ActionForward
     */
    public ActionForward AdhocLayout2(ActionMapping mapping,ActionForm form,HttpServletRequest request, HttpServletResponse response){
    	return mapping.findForward("AdhocLayout2");
    }
    
    /**
     * Dispatch action method to display the adhoc report layout 3 screen.
     * This method is executed when user clicks on hyper link on AdhocLayout3 radio button on step 3. 
     * 
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return ActionForward
     */
    public ActionForward AdhocLayout3(ActionMapping mapping,ActionForm form,HttpServletRequest request, HttpServletResponse response){
    	return mapping.findForward("AdhocLayout3");
    }
    
    /**
     * Dispatch action method to display the adhoc report layout 4 screen.
     * This method is executed when user clicks on hyper link on AdhocLayout4 radio button on step 3. 
     * 
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return ActionForward
     */
    public ActionForward AdhocLayout4(ActionMapping mapping,ActionForm form,HttpServletRequest request, HttpServletResponse response){
    	return mapping.findForward("AdhocLayout4");
    }
    
}
