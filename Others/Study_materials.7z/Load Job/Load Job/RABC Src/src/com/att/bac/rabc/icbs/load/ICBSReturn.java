/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.icbs.load;

import java.util.Date;

import com.sbc.bac.rabc.load.HashCodeUtil;

/**
 * This is a data object representing record in RABC_ICBS_RETURN.
 * 
 * @author Shailesh Hemdev - SH8512
 */
public class ICBSReturn {
	private Date runDate;
	private String division;
	private String entityCd;
	private String dataFile;
	private String rtnCd;
	private long totRtnCntDb;
	private double totRtnAmtDb;
	private long totRtnCntCr;
	private double totRtnAmtCr;
	
	/**
	 * @return Returns the dataFile.
	 */
	public String getDataFile() {
		return dataFile;
	}
	/**
	 * @param dataFile The dataFile to set.
	 */
	public void setDataFile(String dataFile) {
		this.dataFile = dataFile;
	}
	/**
	 * @return Returns the division.
	 */
	public String getDivision() {
		return division;
	}
	/**
	 * @param division The division to set.
	 */
	public void setDivision(String division) {
		this.division = division;
	}
	/**
	 * @return Returns the entityCd.
	 */
	public String getEntityCd() {
		return entityCd;
	}
	/**
	 * @param entityCd The entityCd to set.
	 */
	public void setEntityCd(String entityCd) {
		this.entityCd = entityCd;
	}
	/**
	 * @return Returns the rtnCd.
	 */
	public String getRtnCd() {
		return rtnCd;
	}
	/**
	 * @param rtnCd The rtnCd to set.
	 */
	public void setRtnCd(String rtnCd) {
		this.rtnCd = rtnCd;
	}
	/**
	 * @return Returns the runDate.
	 */
	public Date getRunDate() {
		return runDate;
	}
	/**
	 * @param runDate The runDate to set.
	 */
	public void setRunDate(Date runDate) {
		this.runDate = runDate;
	}
	
	/**
	 * @return Returns the totRtnAmtCr.
	 */
	public double getTotRtnAmtCr() {
		return totRtnAmtCr;
	}
	/**
	 * @param totRtnAmtCr The totRtnAmtCr to set.
	 */
	public void setTotRtnAmtCr(double totRtnAmtCr) {
		this.totRtnAmtCr = totRtnAmtCr;
	}
	/**
	 * @return Returns the totRtnAmtDb.
	 */
	public double getTotRtnAmtDb() {
		return totRtnAmtDb;
	}
	/**
	 * @param totRtnAmtDb The totRtnAmtDb to set.
	 */
	public void setTotRtnAmtDb(double totRtnAmtDb) {
		this.totRtnAmtDb = totRtnAmtDb;
	}
	/**
	 * @return Returns the totRtnCntCr.
	 */
	public long getTotRtnCntCr() {
		return totRtnCntCr;
	}
	/**
	 * @param totRtnCntCr The totRtnCntCr to set.
	 */
	public void setTotRtnCntCr(long totRtnCntCr) {
		this.totRtnCntCr = totRtnCntCr;
	}
	/**
	 * @return Returns the totRtnCntDb.
	 */
	public long getTotRtnCntDb() {
		return totRtnCntDb;
	}
	/**
	 * @param totRtnCntDb The totRtnCntDb to set.
	 */
	public void setTotRtnCntDb(long totRtnCntDb) {
		this.totRtnCntDb = totRtnCntDb;
	}
	
	/**
	 * Equals method overridden for this object so that it can be stored in a hash map where the key 
	 * would be combination of the following 4 attributes:
	 * run date
	 * division
	 * entity code
	 * data file
	 * return code
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object o) {
		// Do a quick check for an identical object reference
	    if (this == o) {
	      return true;
	    }
	    if (!(o instanceof ICBSReturn)) {
	    	return false;
	    }else{
	    	if (((ICBSReturn)o).getRunDate().getTime() == this.getRunDate().getTime()
				&& ((ICBSReturn)o).getDivision().equalsIgnoreCase(this.getDivision())
				&& ((ICBSReturn)o).getEntityCd().equalsIgnoreCase(this.getEntityCd())	
				&& ((ICBSReturn)o).getDataFile().equalsIgnoreCase(this.getDataFile())
				&& ((ICBSReturn)o).getRtnCd().equalsIgnoreCase(this.getRtnCd())
				) 
	    	{
	    		return true;
	    	} else {
	    		return false;
	    	}
	    }
	}
	
	/**
	 * Hash code method overridden for this object to categorize this object in sets 
	 * so that the hash collections can search this object efficiently.
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		int hashCode = HashCodeUtil.SEED;
		hashCode = HashCodeUtil.hash( hashCode, this.getEntityCd());
		hashCode = HashCodeUtil.hash( hashCode, this.getDataFile());
	    return hashCode;
	}
}
