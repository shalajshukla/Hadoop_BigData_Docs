/*
 * Copyright  2002-2006 AT&T Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.adhoc.aria;

import com.sbc.bac.aria.ARIADataPoint;
import com.sbc.bac.aria.ARIASimpleColumn;


/**
 * Custom simple column to keep track of dto index
 * 
 * <p>
 * <hr>
 * <h3>Release History</h3>
 * <p>
 * <ul>
 * 
 * <li>jb6494 Aug 11, 2006 Created class.
 * 
 * </ul>
 * <p>
 * 
 */
public class ARIASimpleColumnRABC extends ARIASimpleColumn implements IAdhocDTOIndex {
    private int dtoIndex = -1;


    /**
     * Construct a column with the given parms.
     * 
     * @param point
     * @param name
     * @param strFormat
     */
    public ARIASimpleColumnRABC(ARIADataPoint point, String name, String strFormat, int dtoIndex) {
        super(point, name, strFormat);
        this.dtoIndex = dtoIndex;
    }


    /**
     * Constructor
     * 
     * @param point
     * @param name
     * @param strFormat
     * @param outputPattern
     */
    public ARIASimpleColumnRABC(ARIADataPoint point, String name, String strFormat, String outputPattern, int dtoIndex) {
        super(point, name, strFormat, outputPattern);
        this.dtoIndex = dtoIndex;
    }


    /*
     * (non-Javadoc)
     * 
     * @see com.att.bac.rabc.adhoc.aria.IAdhocDTOIndex#getDtoIndex()
     */
    public int getDtoIndex() {
        return dtoIndex;
    }

}
