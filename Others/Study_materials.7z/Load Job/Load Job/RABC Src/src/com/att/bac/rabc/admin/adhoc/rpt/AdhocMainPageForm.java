/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.admin.adhoc.rpt;

import org.apache.struts.action.ActionForm;

import java.util.List;

/**
 * Module description: 
 * 
 * This is a Main page Form Bean for the Adhoc report definition component. 
 *
 * @author Anup Thomas - AT1862
 */
public class AdhocMainPageForm extends ActionForm {
	/*
	 * Variables to represent the fields on Adhoc Report Main page.
	 */
	List reportNameList ;
	String reportId=null;
	private String dispatch = null;
	private boolean hasPermission ; 
	private String message;
	
	/*
	 * Variables added for calendar page
	 */
	private String procDates;
	private String billRounds;
	private String holidayIndicators;
	private String loadedDataDates;
	
	/**
	 * @return billRounds
	 */
	public String getBillRounds() {
		return billRounds;
	}
	
	/**
	 * @param billRounds
	 */
	public void setBillRounds(String billRounds) {
		this.billRounds = billRounds;
	}
	
	/**
	 * @return holidayIndicators
	 */
	public String getHolidayIndicators() {
		return holidayIndicators;
	}
	
	/**
	 * @param holidayIndicators
	 */
	public void setHolidayIndicators(String holidayIndicators) {
		this.holidayIndicators = holidayIndicators;
	}
	
	/**
	 * @return loadedDataDates
	 */
	public String getLoadedDataDates() {
		return loadedDataDates;
	}
	
	/**
	 * 
	 * @param loadedDataDates
	 */
	public void setLoadedDataDates(String loadedDataDates) {
		this.loadedDataDates = loadedDataDates;
	}
	
	public String getProcDates() {
		return procDates;
	}
	public void setProcDates(String procDates) {
		this.procDates = procDates;
	}
	/**
	 * @return Returns the hasPermission.
	 */
	public boolean isHasPermission() {
		return hasPermission;
	}
	/**
	 * @param hasPermission The hasPermission to set.
	 */
	public void setHasPermission(boolean hasPermission) {
		this.hasPermission = hasPermission;
	}
	/**
	 * @return Returns the reportId.
	 */
	public String getReportId() {
		return reportId;
	}
	/**
	 * @param reportId The reportId to set.
	 */
	public void setReportId(String reportId) {
		this.reportId = reportId;
	}
	/**
	 * @return Returns the reportNameList.
	 */
	public List getReportNameList() {
		return reportNameList;
	}
	/**
	 * @param reportNameList The reportNameList to set.
	 */
	public void setReportNameList(List reportNameList) {
		this.reportNameList = reportNameList;
	}
	/**
	 * @return Returns the dispatch.
	 */
	public String getDispatch() {
		return dispatch;
	}
	/**
	 * @param dispatch The dispatch to set.
	 */
	public void setDispatch(String dispatch) {
		this.dispatch = dispatch;
	}
	/**
	 * @return Returns the message.
	 */
	public String getMessage() {
		return message;
	}
	/**
	 * @param message The message to set.
	 */
	public void setMessage(String message) {
		this.message = message;
	}
}
