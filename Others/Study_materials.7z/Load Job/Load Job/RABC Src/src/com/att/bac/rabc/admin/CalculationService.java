/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */
package com.att.bac.rabc.admin;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;

/**
 * Module description:
 * 
 * This is a service class which contains the business logic to create and update the calculation. 
 * 
 * @author Vijay Dubey - VD3159
 *
 */
public class CalculationService {
	private static final Logger logger = Logger.getLogger(CalculationService.class);
	private static CalculationService calculationService;
	
	/*
	 * Variables to represent the sql statements.
	 */
	private  final String getCalculation = "SELECT PRESN_CALC_NAME, PRESN_CALC_NUM, CALC_ELEM_FORMULA, "
		+ "CALC_ELEM_USER_VIEW, CALC_DIV_IND, CALC_ELEM_DISPLAY, CALC_DISPLAY_ELEM, PRESN_FORMAT_CODE,CALC_TBL,CALC_ELEM_SQL_FORMULA "
		+ "FROM RABC_PRESN_CALC_ELEM "
		+ "WHERE PRESN_CALC_NUM = {0} ";
	
	private final String checkCalculationNameExists = "SELECT PRESN_CALC_NAME FROM RABC_PRESN_CALC_ELEM "
										+ "WHERE PRESN_CALC_NAME = ''{0}''";
		
	private final String getMaxCalcNum = "SELECT MAX(PRESN_CALC_NUM) FROM RABC_PRESN_CALC_ELEM";
	
	private final String insertCalculation = "INSERT INTO RABC_PRESN_CALC_ELEM "
		+ "(PRESN_CALC_NAME, PRESN_CALC_NUM, CALC_ELEM_FORMULA, CALC_ELEM_USER_VIEW, "
		+ "CALC_ELEM_DISPLAY, CALC_DISPLAY_ELEM, CALC_DIV_IND, PRESN_FORMAT_CODE,CALC_TBL,CALC_ELEM_SQL_FORMULA)"
		+ "VALUES (''{0}'', {1}, ''{2}'', ''{3}'', ''{4}'', ''{5}'' ,'''', ''{6}'',''{7}'',''{8}'')";
	
	private final String insertCalculation1 = "INSERT INTO RABC_PRESN_CALC_ELEM "
		+ "(PRESN_CALC_NAME, PRESN_CALC_NUM, CALC_ELEM_FORMULA, CALC_ELEM_USER_VIEW, "
		+ "CALC_ELEM_DISPLAY, CALC_DISPLAY_ELEM, CALC_DIV_IND, PRESN_FORMAT_CODE,CALC_TBL,CALC_ELEM_SQL_FORMULA)"
		+ "VALUES (''{0}'', {1}, ''{2}'', ''{3}'', ''{4}'', ''{5}'' ,'''', null,''{6}'',''{7}'')";
	
	private final String updateCalculation = "UPDATE RABC_PRESN_CALC_ELEM "
		+ "SET PRESN_CALC_NAME = ''{0}'', "
		+ "CALC_ELEM_FORMULA = ''{1}'', "
		+ "CALC_ELEM_USER_VIEW = ''{2}'', "
		+ "CALC_ELEM_DISPLAY = ''{3}'', "
		+ "CALC_DISPLAY_ELEM = ''{4}'', "
		+ "PRESN_FORMAT_CODE = ''{5}'', "
		+ "CALC_TBL = ''{6}'', "
		+ "CALC_ELEM_SQL_FORMULA = ''{7}'' "
		+ "WHERE PRESN_CALC_NUM = {8} ";
	
	private final String updateCalculation1 = "UPDATE RABC_PRESN_CALC_ELEM "
		+ "SET PRESN_CALC_NAME = ''{0}'', "
		+ "CALC_ELEM_FORMULA = ''{1}'', "
		+ "CALC_ELEM_USER_VIEW = ''{2}'', "
		+ "CALC_ELEM_DISPLAY = ''{3}'', "
		+ "CALC_DISPLAY_ELEM = ''{4}'', "
		+ "PRESN_FORMAT_CODE = null, "
		+ "CALC_TBL = ''{5}'', "
		+ "CALC_ELEM_SQL_FORMULA = ''{6}'' "
		+ "WHERE PRESN_CALC_NUM = {7} ";
	
	private  final String getCalculationNames = "SELECT PRESN_CALC_NAME, PRESN_CALC_NUM, CALC_ELEM_FORMULA, "
		+ "CALC_ELEM_USER_VIEW, CALC_DIV_IND, CALC_ELEM_DISPLAY, CALC_DISPLAY_ELEM, PRESN_FORMAT_CODE,CALC_TBL,CALC_ELEM_SQL_FORMULA "
		+ "FROM RABC_PRESN_CALC_ELEM " ;

	/**
	 * Synchronized method to return the instance of CalculationService object.
	 * It checks the existance of the instance of CalculationService and if it does not exists
	 * then creates one instance of CalculationService and returns otherwise it returns the
	 * existing instance of CalculationService.
	 * 
	 * @return CalculationService
	 */
	public static synchronized CalculationService getViewCalculationService() {
		if (calculationService == null){
			calculationService = new CalculationService();
		}	
		return calculationService;
	}
	
	/**
	 * This method is used to get the PresnCalcElem object given the calc name as one of the arguments
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return PresnCalcElem
	 */
	public PresnCalcElem getCalculation(Connection connection, List failureList, List args) {
		List calcList = new PresnCalcElemDAO().get(connection, failureList, args, getCalculation);
		if (!failureList.isEmpty()) {
			return null;
		}
		if (!calcList.isEmpty()){
			return (PresnCalcElem)calcList.get(0);
		}else {
			return null;
		}
	}

	/**
	 * This method is used to get the caluclation name list.  
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return List
	 */
	public List getCalculationNames(Connection connection, List failureList, List args) {
		List calcList = new PresnCalcElemDAO().get(connection, failureList, args, getCalculationNames);
		if (!failureList.isEmpty()) {
			return null;
		}
		return calcList;
	}
	
	/**
	 * This method is used to return the maximum calc number from RABC_PRESN_CALC_ELEM table.
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return int
	 */
	public int getMaxCalcNum(Connection connection, List failureList, List args) {
		int maxCalcNum = 0;		
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			MessageFormat mf = new MessageFormat(getMaxCalcNum);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("To get maximum calculation number - Executing SQL statement: "+ prepareStatement);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			if (rs != null && rs.next()) {
				maxCalcNum = rs.getInt(1);
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
			return 0;
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		return maxCalcNum;
	}
	
	/**
	 * This methoid is used to check the dupliacte entry for calculation name - used prior to insert. 
	 * @param connection
	 * @param failureList
	 * @param argList
	 * @return true/false
	 */
	protected boolean checkCalculationNameExists(Connection connection, List failureList, List argList) {
		List calcNames = new ArrayList() ;
		String calcName ; 
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		try{
			MessageFormat mf = new MessageFormat(checkCalculationNameExists);
			prepareStatement = mf.format((String[])argList.toArray(new String[argList.size()]));
			//prepareStatement = mf.format(argList.get(0));
			logger.debug("To get calculation names - Executing SQL statement: "+ prepareStatement);
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			while (rs.next()) {
				calcName = rs.getString(1);
				calcNames.add(calcName) ;
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
			return false;
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
	
		//List calcList = new PresnCalcElemDAO().get(connection, failureList, argList, checkCalculationNameExists);
		if (!failureList.isEmpty()) {
			return false ;
		}
		if (!calcNames.isEmpty()){
			return true ; 
		}else {
			return false ;
		}
	}
	
	/**
	 * This method is used to insert a new calculation record into RABC_PRESN_CALC_ELEM table.
	 * @param connection
	 * @param failureList
	 * @param args
	 */
	public void insertCalculation(Connection connection, List failureList, List args) {
		PresnCalcElem presnCalcElem = (PresnCalcElem) args.get(0);
		String prepareStatement = null;
		Statement stmt = null;
		String query = null;
		List insertArgs = new ArrayList();
		if (presnCalcElem.getPresnFormatCode() != null && !("".equals(presnCalcElem.getPresnFormatCode()))) {
			query = insertCalculation;
			insertArgs.add((String)presnCalcElem.getPresnCalcName());
			insertArgs.add((new Integer(presnCalcElem.getPresnCalcNum())).toString());
			insertArgs.add((String)presnCalcElem.getCalcElemFormula());
			insertArgs.add((String)presnCalcElem.getCalcElemUserView());
			insertArgs.add((String)presnCalcElem.getCalcElemDisplay());
			insertArgs.add((String)presnCalcElem.getCalcDisplayElem());
			insertArgs.add((String)presnCalcElem.getPresnFormatCode());
			insertArgs.add((String)presnCalcElem.getCalcTbl());
			insertArgs.add((String)presnCalcElem.getCalcElemSqlFormula()) ;
		} else {
			query = insertCalculation1;
			insertArgs.add((String)presnCalcElem.getPresnCalcName());
			insertArgs.add((new Integer(presnCalcElem.getPresnCalcNum())).toString());
			insertArgs.add((String)presnCalcElem.getCalcElemFormula());
			insertArgs.add((String)presnCalcElem.getCalcElemUserView());
			insertArgs.add((String)presnCalcElem.getCalcElemDisplay());
			insertArgs.add((String)presnCalcElem.getCalcDisplayElem());
			insertArgs.add((String)presnCalcElem.getCalcTbl());
			insertArgs.add((String)presnCalcElem.getCalcElemSqlFormula()) ;
		}
		try{
			MessageFormat mf = new MessageFormat(query);
			prepareStatement = mf.format((String[])insertArgs.toArray(new String[insertArgs.size()]));
			logger.debug("To insert calculation - Executing SQL statement: "+ prepareStatement);
			stmt = connection.createStatement();
			stmt.executeUpdate(prepareStatement);
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
		} finally {
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
	}
	
	/**
	 * This method is used to update an existing calculation into RABC_PRESN_CALC_ELEM table.
	 * @param connection
	 * @param failureList
	 * @param args
	 */
	public void updateCalculation(Connection connection, List failureList, List args) {
		PresnCalcElem presnCalcElem = (PresnCalcElem) args.get(0);
		String prepareStatement = null;
		Statement stmt = null;
		String query = null;
		List updateArgs = new ArrayList();
		if (presnCalcElem.getPresnFormatCode() != null && !("".equals(presnCalcElem.getPresnFormatCode()))) {
			query = updateCalculation;
			updateArgs.add((String)presnCalcElem.getPresnCalcName());
			updateArgs.add((String)presnCalcElem.getCalcElemFormula());
			updateArgs.add((String)presnCalcElem.getCalcElemUserView());
			updateArgs.add((String)presnCalcElem.getCalcElemDisplay());
			updateArgs.add((String)presnCalcElem.getCalcDisplayElem());
			updateArgs.add((String)presnCalcElem.getPresnFormatCode());
			updateArgs.add((String)presnCalcElem.getCalcTbl());
			updateArgs.add((String)presnCalcElem.getCalcElemSqlFormula()) ;
			updateArgs.add((new Integer(presnCalcElem.getPresnCalcNum())).toString());
		} else {
			query = updateCalculation1;
			updateArgs.add((String)presnCalcElem.getPresnCalcName());
			updateArgs.add((String)presnCalcElem.getCalcElemFormula());
			updateArgs.add((String)presnCalcElem.getCalcElemUserView());
			updateArgs.add((String)presnCalcElem.getCalcElemDisplay());
			updateArgs.add((String)presnCalcElem.getCalcDisplayElem());
			updateArgs.add((String)presnCalcElem.getCalcTbl());
			updateArgs.add((String)presnCalcElem.getCalcElemSqlFormula()) ;
			updateArgs.add((new Integer(presnCalcElem.getPresnCalcNum())).toString());
		}
		try{
			MessageFormat mf = new MessageFormat(query);
			prepareStatement = mf.format((String[])updateArgs.toArray(new String[updateArgs.size()]));
			logger.debug("To update calculation - Executing SQL statement: "+ prepareStatement);
			stmt = connection.createStatement();
			stmt.executeUpdate(prepareStatement);
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
		} finally {
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
	}
}
