/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/

package com.att.bac.rabc.alerts.dashboard;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.text.MessageFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.att.bac.rabc.ExcelReport;
import com.att.bac.rabc.ProgressBar;
import com.att.bac.rabc.RABCConstantsLists;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.alerts.status.AlertReportDetail;

/**
 * This class represents the Service that create the list of SystemMessages objects.
 * 
 * @author Abhilash - AC6957
 */
public class SystemMessagesService {
	private static SystemMessagesService systemMessagesService;
	private static final Logger logger = Logger.getLogger(SystemMessagesService.class);	

	protected static final String getMessageList =  "select * from ( "
													+"  select rownum rn, T.outMsgNo outMsgNo, T.outProcDate outProcDate, "
													+"  T.outAlertRule outAlertRule, T.outFileSeqNum outFileSeqNum, "
													+"  T.outDivisionName outDivisionName, T.outAlertGrp outAlertGrp, "
													+"  T.outRevenueImpact outRevenueImpact, "
													+"  T.outStatus outStatus, T.outRootCatgyCd outRootCatgyCd, "
													+"  T.outError outError, T.outMsg outMsg, T.Key1 Key1, "
													+"  T.Key2 Key2, T.Key3 Key3, T.Key4 Key4, "
													+"  T.Key5 Key5 from ( "
													+"  select bams.msg_num as outMsgNo, bams.proc_date as outProcDate, "
												    +"  bams.alert_rule as outAlertRule, bams.file_seq_num as outFileSeqNum, "
												    +"  bams.alert_data1 as outDivisionName, bams.alert_grp  as outAlertGrp, "
												    +"  to_char(bams.alert_revenue,'999999999999999.99') as outRevenueImpact, "
												    +"  bams.alert_status as outStatus, bams.alert_root_catgy_cd as outRootCatgyCd, "
												    +"  bams.alert_sys_err_cd as outError, bams.alert_msg as outMsg, bams.alert_data1 as Key1, "
												    +"  bams.alert_data2 as Key2, bams.alert_data3 as Key3, bams.alert_data4 as Key4, "
												    +"  bams.alert_data5 as Key5 "
												    +"  from rabc_alert_msg bams, rabc_alert_rule bar, rabc_presn_id bpi where"
												    +"  bar.alert_rule = bams.alert_rule and bar.presn_id = bpi.presn_id and {0}";

	protected static final String getMessageList1 = "select * from ( " 
													+"  select rownum rn, T.outMsgNo outMsgNo, T.outProcDate outProcDate, "
													+"  T.outAlertRule outAlertRule, T.outFileSeqNum outFileSeqNum, "
													+"  T.outDivisionName outDivisionName, T.outAlertGrp outAlertGrp, "
													+"  T.outRevenueImpact outRevenueImpact, "
													+"  T.outStatus outStatus, T.outRootCatgyCd outRootCatgyCd, "
													+"  T.outError outError, T.outMsg outMsg, T.Key1 Key1, "
													+"  T.Key2 Key2, T.Key3 Key3, T.Key4 Key4, "
													+"  T.Key5 Key5 from ( "
													+"  select bams.msg_num as outMsgNo, bams.proc_date as outProcDate, "
												    +"  bams.alert_rule as outAlertRule, bams.file_seq_num as outFileSeqNum, "
												    +"  bams.alert_data1 as outDivisionName, bams.alert_grp  as outAlertGrp, "
												    +"  to_char(bams.alert_revenue,'999999999999999.99') as outRevenueImpact, "
												    +"  bams.alert_status as outStatus, bams.alert_root_catgy_cd as outRootCatgyCd, "
												    +"  bams.alert_sys_err_cd as outError, bams.alert_msg as outMsg, bams.alert_data1 as Key1, "
												    +"  bams.alert_data2 as Key2, bams.alert_data3 as Key3, bams.alert_data4 as Key4, "
												    +"  bams.alert_data5 as Key5 "
												    +"  from rabc_alert_msg bams, rabc_alert_rule bar, rabc_presn_id bpi, "
												    +" (select alert_rule from RABC_CNTRL_PT_ALERT where CNTRL_PT_CD =''{0}'') BCPT "
												    +" where bams.alert_rule = bcpt.alert_rule and  "
												    +"  bar.alert_rule = bams.alert_rule and bar.presn_id = bpi.presn_id and {1} ";
	
	protected static final String getTotalMessages =  "  select  count(*) "
												   +"  from rabc_alert_msg bams, rabc_alert_rule bar, rabc_presn_id bpi where"
												   +"  bar.alert_rule = bams.alert_rule and bar.presn_id = bpi.presn_id and {0}";
	
	protected static final String getTotalMessages1 =  "  select  count(*) "
												   +"  from rabc_alert_msg bams, rabc_alert_rule bar, rabc_presn_id bpi "
												   +",(select alert_rule from RABC_CNTRL_PT_ALERT where CNTRL_PT_CD =''{0}'') BCPT "
												   +" where bams.alert_rule = bcpt.alert_rule and  "
												   +"  bar.alert_rule = bams.alert_rule and bar.presn_id = bpi.presn_id and {1} ";

	protected static final String  getErrorDSC  =   "  SELECT distinct(SYS_ERR_CD_DESC),sys_err_cd  from rabc_sys_err_cd  where sys_err_cd in ( {0} )";

	private final String qMsgCodes = "select msg_num, alert_root_catgy_cd from rabc_warn_cd where msg_num in ( {0} ) "
									+ "order by msg_num, alert_root_catgy_cd";
	
	protected static final  String getdivkeys = "select alert_rule, DIVISION_NAME_KEY_LVL  divlvl from rabc_alert_rule where alert_rule in ( {0} )";
	
	private final static String getDefaultLineCount = "SELECT LINE_CT FROM RABC_USER_DEFAULT_RPT_LINE WHERE USER_ID = ''{0}''";
	
	private static final String query_getCycle = "select cycle, bill_rnd, proc_dt, bill_rnd_dt " 
									+ "from rabc_cycle_calendar {0}";
	
	private static final String getSysErrDesc = " SELECT distinct(SYS_ERR_CD_DESC) from rabc_sys_err_cd  where sys_err_cd = {0}";

	/**
	 * Synchronized method to return the instance of SystemMessagesService object.
	 * It checks the existance of the instance of SystemMessagesService and if it does not exists
	 * then creates one instance of SystemMessagesService and returns otherwise it returns the
	 * existing instance of SystemMessagesService.
	 * 
	 * @return SystemMessagesService
	 */
	public static SystemMessagesService getSystemMessagesService(){
		if (systemMessagesService == null) {
			systemMessagesService = new SystemMessagesService();
		}
		return systemMessagesService;
	}

	/**
	 * This is a method which returns the List of SystemMessages objects
	 * 
	 * @param connection
	 * @param failureList
	 * @param systemMessagesParameters
	 * @param args
	 * @param progressBar
	 * @return List
	 */
	public List getSystemMessagesList(Connection connection, List failureList, SystemMessagesParameters systemMessagesParameters,
			List args, ProgressBar progressBar) {

		String getMessage = null;
		String controlPoint = null;
		String alertRule = null;
		String[] params = null;
		if(systemMessagesParameters.getControlPoint() != null  ){
			if( !(systemMessagesParameters.getControlPoint().equals("")) ){
				controlPoint = systemMessagesParameters.getControlPoint();
			}
		}
		if(systemMessagesParameters.getAlertRule() != null){
			if( !(systemMessagesParameters.getAlertRule().equals("")) ){
				alertRule = systemMessagesParameters.getAlertRule();
			}
		}
			
		params = new String [2];
		args.add(6, "N");
		
		//Validating cntrlPoint NOT EQUALS null && alertRule  EQUALS null and selecting the approriate query.
		if( (controlPoint != null) && (alertRule == null) ){
			getMessage = getMessageList1;
			params[0] = controlPoint;
			params[1] = getQueryForMessageList(connection, failureList, systemMessagesParameters, args);
		}else{
			getMessage = getMessageList;
			params[0] = getQueryForMessageList(connection, failureList, systemMessagesParameters, args);
		}
	
		progressBar.setProgressPercent(progressBar.getPercent() + 10);
		progressBar.setProgressPercent(progressBar.getPercent() + 10);
		
		/*
		 * 1) Execute query getSystemMessages List
		 * 2) Call another private method updatesystemMessagesList() for this which will return Updated List of SystemMessages objects
		 */
		List systemMessagesList = getSystemMessages(connection, failureList, params,  getMessage);
		progressBar.setProgressPercent(progressBar.getPercent() + 10);
		if (!failureList.isEmpty()) {
			// Exception occurred, hence return
			return null;
		}
		/*
		 * method to retieve all the MsgNums
		 */
		String messageNumbers = getMsgNums(systemMessagesList);
		if (messageNumbers.equals("")) {
			messageNumbers = "''";
		} else {
			messageNumbers = messageNumbers.substring(0, messageNumbers.length()-1);
		}
		
		/*
		 * method to retieve all the errorCodes
		 */
		String errorCodes = getErrorCodes(systemMessagesList);
		if (errorCodes.equals("")) {
			errorCodes = "''";
		} else {
			errorCodes = errorCodes.substring(0, errorCodes.length()-1);
		}
		
		String alertRules = getAlertRules(systemMessagesList);
		if (alertRules.equals("")) {
			alertRules = "''";
		} else {
			alertRules = alertRules.substring(0, alertRules.length()-1);
		}
		
		
		 /*
		 * Using list of message numbers obtained from above, get the root catgy cd from 
		 * rabc_warn_cd. Call another private method for this which will be passed following 
		 * arguments
		 * 1) Connection & failureList
		 * 2)String messageNumbers 
		 */
		HashMap msgNumWiseRootCatgyCdMap = getMsgNnmWiseRootCatgyCd(connection, failureList, messageNumbers);
		if (!failureList.isEmpty()) {
			// Exception occurred, hence return
			return null;
		}
		progressBar.setProgressPercent(progressBar.getPercent() + 10);
		
		/*	Private method
		 * 1) Execute query qVarTypes
		 * 2) Call a private method which will return a map of System Message Description 
		 */
		HashMap errorCodeWiseDescrptionMap = geterrorCodeWiseDescription(connection, failureList, errorCodes);
		if (!failureList.isEmpty()) {
			// Exception occurred, hence return
			return null;
		}
		
		// Code added to fix BG#09 on 14th November 2006
		if (systemMessagesParameters.getSystemErrorType()!=null && !"".equals(systemMessagesParameters.getSystemErrorType().trim())){
			String sysErrDesc = getSysErrTypeDesc(connection, failureList, systemMessagesParameters.getSystemErrorType());
			if (sysErrDesc!=null){
				systemMessagesParameters.setSystemErrorDesc(sysErrDesc);
			}
		}	
		// Code Fix ends
		
		progressBar.setProgressPercent(progressBar.getPercent() + 10);
		
		/*	Private method to return Map of alert rule wise key levels
		 * 1) Get the alert rule key levels using list of alert rules created above [getacctinstkeys]
		 * 2) Loop through keys for all rules; if at least 1 rule has keyLevels > 0 then we will show this column I guess ??
		 */
		HashMap alertRuleWiseKeyLevelsMap = getAlertRuleWiseKeyLevels(connection, failureList, alertRules);
		if (!failureList.isEmpty()) {
			// Exception occurred, hence return
			return null;
		}
		progressBar.setProgressPercent(progressBar.getPercent() + 10);
		
		/*
		 * Private method  updatesystemMessagesList()
		 * Pass all the maps
		 * Method will loop through the systemMessagesList & for every object
		 * update the pending values
		 */
		systemMessagesList = updatesystemMessagesList(systemMessagesList,msgNumWiseRootCatgyCdMap, errorCodeWiseDescrptionMap, alertRuleWiseKeyLevelsMap );
				
		progressBar.setProgressPercent(progressBar.getPercent() + 10);
		return systemMessagesList;
	
	}

	/**
	 * This is a method to update the systemMessagesList using the respective hash maps
	 * like msgNumWiseRootCatgyCdMap, alertRuleWiseKeyLevelsMap, errorCodeWiseDescrptionMap.
	 * 
	 * @param systemMessagesList
	 * @param msgNumWiseRootCatgyCdMap
	 * @param errorCodeWiseDescrptionMap
	 * @param alertRuleWiseKeyLevelsMap
	 * @return List
	 */
	private List updatesystemMessagesList(List systemMessagesList, HashMap msgNumWiseRootCatgyCdMap,	HashMap errorCodeWiseDescrptionMap, HashMap alertRuleWiseKeyLevelsMap){
		
		List newSystemMessagesList = new ArrayList();
		SystemMessages systemMessages = null;
		
		List suppInfo = null;
		
		for (int i=0; i<systemMessagesList.size(); i++) {
			
			systemMessages = (SystemMessages)systemMessagesList.get(i);
			int msgNum = systemMessages.getMsgNum();
			Integer errorCode = systemMessages.getSystemErrorCode();
			String alertRule = systemMessages.getAlertRule();
			
			if (msgNumWiseRootCatgyCdMap.containsKey(new Integer(msgNum))) {
				List rootCtgyList = (List) msgNumWiseRootCatgyCdMap.get(new Integer(msgNum));
				for (int j=0; j<rootCtgyList.size(); j++) {
					systemMessages.addRootCauseCategory((String)rootCtgyList.get(j));
				}
			}
			
			/*if (alertRuleWiseAlertItemsMap.containsKey(alertRule)) {
				newAlertReportDetail.setAlertItem((String)alertRuleWiseAlertItemsMap.get(alertRule));
			}*/
			if (errorCodeWiseDescrptionMap.containsKey(errorCode.toString())) {
				//systemMessages.setSystemMessageDescription((String)errorCodeWiseDescrptionMap.get(errorCode.toString()));
				systemMessages.setSystemErrorCodeMouseOver((String)errorCodeWiseDescrptionMap.get(errorCode.toString()));
			}
			
			if(systemMessages.getSystemMessageDescription()==null ||systemMessages.getSystemMessageDescription().equals("")){
				systemMessages.setSystemMessageDescription("no data");
			}
			
			if (alertRuleWiseKeyLevelsMap.containsKey(alertRule)) {
				
				systemMessages.setKeylevels(((Integer)(alertRuleWiseKeyLevelsMap.get(alertRule))).toString());
			}
			
			newSystemMessagesList.add(systemMessages);
			
		}
		
		return newSystemMessagesList;
	}
	
	/**
	 * Method to return the string having all the message nos seperated by comma.
	 * 
	 * @param systemMessagesList
	 * @return String
	 */
	private String getMsgNums(List systemMessagesList) {
	     String result = "";
	     StringBuffer resultBuffer = new StringBuffer();
	     if (systemMessagesList != null) {
		     for(int i=0; i<systemMessagesList.size(); i++) {
		        if(resultBuffer.indexOf(new Integer(((SystemMessages)systemMessagesList.get(i)).getMsgNum()).toString()) == -1) { 
			     	resultBuffer.append('\'').append(((SystemMessages)systemMessagesList.get(i)).getMsgNum()).append('\'').append(',');
		        }
		     }
	     }
	     result = resultBuffer.toString();
	     return result;
	 }
	
	/**
	 * Private method to return the string having all the ErrorCode Description seperated by comma.
	 * 
	 * @param systemMessagesList
	 * @return String
	 */
	private String getErrorCodes(List systemMessagesList) {
	     String result = "";
	     StringBuffer resultBuffer = new StringBuffer();
	     if (systemMessagesList != null) {
		     for(int i=0; i<systemMessagesList.size(); i++) {
		     	if(resultBuffer.indexOf( (((SystemMessages)systemMessagesList.get(i)).getSystemErrorCode()).toString()) == -1) {
		     		resultBuffer.append('\'').append(((SystemMessages)systemMessagesList.get(i)).getSystemErrorCode()).append('\'').append(',');
		     	}
		     }
	     }
	     result = resultBuffer.toString();
	     return result;
	 }
	
	/*
	 * Method to return the string having all the alert rules seperated by comma.
	 */
	
	/**
	 * Private method to return the string having all the alert rules seperated by comma.
	 * 
	 * @param systemMessagesList
	 * @return String
	 */
	private String getAlertRules(List systemMessagesList) {
	     String result = "";
	     StringBuffer resultBuffer = new StringBuffer();
	     if (systemMessagesList != null) {
		     for(int i=0; i<systemMessagesList.size(); i++) {
		     	if(resultBuffer.indexOf(((SystemMessages)systemMessagesList.get(i)).getAlertRule()) == -1) {
		     		resultBuffer.append('\'').append(((SystemMessages)systemMessagesList.get(i)).getAlertRule()).append('\'').append(',');
		     	}
		     }
	     }
	     result = resultBuffer.toString();
	     return result;
	 }
	
	/**
	 * This is a method which use the string of message numbers as IN clause to get msgNum wise root catgy cd
	 * 
	 * @param connection
	 * @param failureList
	 * @param messageNumbers
	 * @return HashMap
	 */
	private HashMap getMsgNnmWiseRootCatgyCd(Connection connection, List failureList, String messageNumbers){
		HashMap msgNumWiseRootCatgyCdMap = new HashMap();
		
		String selectSQL = qMsgCodes;
		List args = new ArrayList();
		args.add(messageNumbers);
		
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		
		int currentMsgNo = 0;
		int previousMsgNo = 0;
		String rootCtgy = null;
		List rootCtgyList = new ArrayList();
		
		try{
			MessageFormat mf = new MessageFormat(selectSQL);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			while(rs.next()) {
				currentMsgNo = rs.getInt(1);
				rootCtgy = rs.getString(2);
				if (rootCtgyList.size()>0 && currentMsgNo != previousMsgNo) {
					msgNumWiseRootCatgyCdMap.put(new Integer(previousMsgNo), rootCtgyList);
					rootCtgyList = new ArrayList();
				}
				rootCtgyList.add(rootCtgy);
				previousMsgNo = currentMsgNo;
			}
			msgNumWiseRootCatgyCdMap.put(new Integer(previousMsgNo), rootCtgyList);
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
			return null;
		} finally{
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		
		return msgNumWiseRootCatgyCdMap;
	}
	
	/**
	 * This is a method which use the errorCode as IN clause to get System Message Description to 
	 * form a HashMap of errorCode wise Description items 
	 * 
	 * @param connection
	 * @param failureList
	 * @param errorCodes
	 * @return HashMap
	 */
	private HashMap geterrorCodeWiseDescription(Connection connection, List failureList, String errorCodes){
		HashMap errorCodeWiseDescription = new HashMap();
		
		String selectSQL = getErrorDSC;
		List args = new ArrayList();
		args.add(errorCodes);
		
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		
		try{
			MessageFormat mf = new MessageFormat(selectSQL);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			while(rs.next()) {
				errorCodeWiseDescription.put(rs.getString(2), rs.getString(1));
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
			return null;
		} finally{
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		
		return errorCodeWiseDescription;
	}

	/**
	 * This is a method which use the string of alert rules as IN clause to get alertRule wise key levels 
	 * to form a HashMap of alertRule wise key levels
	 * 
	 * @param connection
	 * @param failureList
	 * @param alertRules
	 * @return HashMap
	 */
	private HashMap getAlertRuleWiseKeyLevels(Connection connection, List failureList, String alertRules){
		HashMap alertRuleWiseKeyLevelsMap = new HashMap();
		
		String selectSQL = getdivkeys;
		List args = new ArrayList();
		args.add(alertRules);
		
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		
		try{
			MessageFormat mf = new MessageFormat(selectSQL);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			while(rs.next()) {
				alertRuleWiseKeyLevelsMap.put(rs.getString(1), new Integer(rs.getInt(2)));
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
			return null;
		} finally{
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		
		return alertRuleWiseKeyLevelsMap;
	}
		
	/**
	 * Private method which will return list of SystemMessages objects.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param query
	 * @return List
	 */
	private List getSystemMessages(Connection connection, List failureList, String[] args, String query){
		SystemMessages systemMessages = new SystemMessages();
		List systemMessagesList = new ArrayList();
		AlertReportDetail alertReportDetail = null;
		String selectSQL = query;
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		
		try{
			MessageFormat mf = new MessageFormat(selectSQL);
			prepareStatement = mf.format(args);
			logger.debug("To get SystemMessages List - Executing SQL statement: "+ prepareStatement);
			stmt =  connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			if (rs != null) {
				while(rs.next()){
					systemMessages = buildSystemMessages(rs);
					systemMessagesList.add(systemMessages);
				}
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
			return null;
		} finally{
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		
		return systemMessagesList;
	}
	
	/**
	 * Private method to set the attributes of alertReportDetail Object.
	 * This method will accept the resultset.
	 * 
	 * @param rs
	 * @return SystemMessages
	 * @throws SQLException
	 */
	private SystemMessages buildSystemMessages(ResultSet rs) throws SQLException {
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		SystemMessages systemMessages = new SystemMessages();
		systemMessages.setAlertRule(rs.getString("outAlertRule"));
		systemMessages.setFileDate(dateFormat.format(rs.getDate("outProcDate")));
		String fileSeqNum = rs.getString("outFileSeqNum");
		if (fileSeqNum != null) {
			systemMessages.setFileSeqNum(new Integer(fileSeqNum));
		} else {
			systemMessages.setFileSeqNum(null);
		}
		String systemErrorCode = rs.getString("outError");
		if (systemErrorCode != null) {
			systemMessages.setSystemErrorCode(new Integer(systemErrorCode));
		} else {
			systemMessages.setSystemErrorCode(null);
		}
		systemMessages.setSystemMessageDescription(rs.getString("outMsg")); 
		systemMessages.setStatus(rs.getString("outStatus"));
		String outRevenueImpact = rs.getString("outRevenueImpact");
		if (outRevenueImpact != null) {
			systemMessages.setDollarImpact(new Double(outRevenueImpact));
		} else {
			systemMessages.setDollarImpact(null);
		}
		systemMessages.setMsgNum(rs.getInt("outMsgNo"));
		String divisionName = "" ; 
		divisionName = rs.getString("outDivisionName") ;
		if (divisionName == null) {
			divisionName = "" ; 
		}
		systemMessages.setDivision(divisionName);

		return systemMessages;
	}

	/**
	 * Method to generate the "WHERE" clause based on different input fields.
	 * 
	 * @param connection
	 * @param failureList
	 * @param systemMessagesParameters
	 * @param args
	 * @return String
	 */
	public String getQueryForMessageList(Connection connection,List failureList,SystemMessagesParameters systemMessagesParameters,
			List args) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Calendar calendar = Calendar.getInstance();
		List sysMessageList = new ArrayList();
		String MessageListQuery = " ";
		String startDate = null;
		String endDate = null;
		String datetype = null;
		String webPageId = null;
		String fromPage = null;
		Date tempDate = null;
		
		String sortItem = (String) args.get(0);
		String sortOrder = (String) args.get(1);
		String dispatch = (String) args.get(2);
		int pageSize = ((Integer)args.get(3)).intValue();
		int page = ((Integer)args.get(4)).intValue();
    	int pages = ((Integer)args.get(5)).intValue();
    	String countYN = (String) args.get(6);
    	
		int startCounter = (page - 1) * pageSize + 1;
		int endCounter = page * pageSize;
		
		//If the Start Date and EndDate is blank ; set End Date as todays date and Start Date 90 days prior to todays date.
		if (((systemMessagesParameters.getStartDate() == null) || (systemMessagesParameters.getStartDate()).equals("")) && ((systemMessagesParameters.getEndDate() == null) || (systemMessagesParameters.getEndDate()).equals(""))) {
    		tempDate = new Date(System.currentTimeMillis());
    		endDate = dateFormat.format(tempDate);
    		calendar.setTime(tempDate);
    		calendar.add(Calendar.DAY_OF_YEAR, -90);
    		tempDate = new Date(calendar.getTimeInMillis());
    		startDate = dateFormat.format(tempDate);
    	} else {
    		startDate = systemMessagesParameters.getStartDate();
    		endDate = systemMessagesParameters.getEndDate();
    	}
		
		if(systemMessagesParameters.getDateType()  ==  null || systemMessagesParameters.getDateType().equals("")){
			datetype =  "run";
		}else{
			datetype = systemMessagesParameters.getDateType();
		}
		if (systemMessagesParameters.getWebPageId() == null || systemMessagesParameters.getWebPageId().equals("")) {
			webPageId = "RABCPSF00003";
		}else{
			webPageId = systemMessagesParameters.getWebPageId();
		}
		
		fromPage = webPageId;
		
		systemMessagesParameters.setFromPage(fromPage);
		
		String upEndDate = systemMessagesParameters.getUpEndDate();
		String upStartDate = systemMessagesParameters.getUpStartDate();
		String alertRule = systemMessagesParameters.getAlertRule();
		String divisionName = systemMessagesParameters.getDivision();
		String alertInstant = systemMessagesParameters.getAlertInstant();
		String rootCatgyCd = systemMessagesParameters.getRootCatgyCd();
		String alertGrp = systemMessagesParameters.getAlertGroup();
		String revenueImpactValue = systemMessagesParameters.getRevenueImpactValue();
		String revenueImpactIndicator = systemMessagesParameters.getRevenueImpactIndicator();	
		String alertRuleTiming = systemMessagesParameters.getAlertRuleTiming();
		String alertRuleTimingInd = systemMessagesParameters.getAlertRuleTimingIndicator();
		String sysErrorType = systemMessagesParameters.getSystemErrorType();
		String alertStatus = systemMessagesParameters.getAlertStatus();
		String fileSeqNum = systemMessagesParameters.getFileSeqNum(); 
		String svrlevel = systemMessagesParameters.getSeverelvl();
		
		String lastDate = null;
		if( fromPage != null) {
			if ( ((endDate != null) && (startDate != null) ) ) {
				if(!(endDate.equals("")) && !(startDate.equals("")) ){
					if(datetype.equals("file")) {
						MessageListQuery += "(bams.proc_date >= to_date('"+ startDate +"','MM/DD/YYYY') and bams.proc_date < to_date(' "+ endDate +"','MM/DD/YYYY') + 1) and ";
					} else {
						MessageListQuery += "(bams.ALERT_RULE_RUN_DT >= to_date('"+ startDate +"','MM/DD/YYYY') and bams.ALERT_RULE_RUN_DT < to_date('"+ endDate +"','MM/DD/YYYY') + 1) and ";
					}
				}
			}
		}

		if (upEndDate != null && upStartDate != null){
			if(!(upEndDate.equals("")) && !(upStartDate.equals("")) ){
				MessageListQuery += "(bams.time_stamp >= to_date('"+ upStartDate +"','MM/DD/YYYY') and bams.time_stamp < to_date('"+ upEndDate +"','MM/DD/YYYY') + 1) and ";
			}
		}

		if (alertRule != null){
			if(!alertRule.equals("")){
				MessageListQuery +=  " bar.alert_rule = '" + alertRule +"' and ";
			}
		}

		if (divisionName != null){
			if(!divisionName.equals("")){
				MessageListQuery +=  " bams.alert_data1 = '" + divisionName +"' and ";
			}
		}

		if (alertInstant != null){
			if(!alertInstant.equals("")){
				MessageListQuery +=  " bams.alert_data2 = '" + alertInstant +"' and ";
			}
		}

		if (rootCatgyCd != null){
			if(!rootCatgyCd.equals("")){
			MessageListQuery +=  " bams.msg_num in (select distinct msg_num from rabc_warn_cd where alert_root_catgy_cd = '"+ rootCatgyCd + "' ) and ";
			}
		}

		if (alertGrp != null){
			if(!alertGrp.equals("")){
				MessageListQuery +=  " bams.alert_grp = '" + alertGrp +"' and ";
			}
		}

		if ((revenueImpactValue != null) && (!revenueImpactValue.equals(""))) {
			double revenueImpactValue1 = (new Double(revenueImpactValue.trim())).doubleValue();
			if (revenueImpactIndicator != null){
				if (revenueImpactIndicator.equals("Greater than") ){
					MessageListQuery +=	" abs(bams.alert_revenue) > "+revenueImpactValue1+"	and ";
				} else if( revenueImpactIndicator.equals("Equal to") ){
					MessageListQuery +=" abs(bams.alert_revenue) = "+revenueImpactValue1+" 	and ";
				} else if( revenueImpactIndicator.equals("Less than") ){
					MessageListQuery +=" abs(bams.alert_revenue) < "+revenueImpactValue1+" 	and ";
				}
			}
    	}

		if (alertRuleTiming != null){
			if ( (alertRuleTiming.equals("B")) ||  (alertRuleTiming.equals("D")) ){
				MessageListQuery +="bams.alert_time_ind = '"+alertRuleTiming+"' and ltrim(rtrim(bams.alert_time_value,' '),'0 ') = ltrim('"+alertRuleTimingInd+"','0') and ";
			}else {
				MessageListQuery +="bams.alert_time_ind is null and ";
			}
		}

		if (sysErrorType != null){
			if(!sysErrorType.equals("")){
				MessageListQuery +=  " bams.alert_sys_err_cd = '" + sysErrorType +"' and ";
			}
		}

		if (alertStatus != null){
			if(!alertStatus.equals("")){
				MessageListQuery +=  "  upper(bams.alert_status) = upper('" + alertStatus +"') and ";
			}
		}
		
		if( fromPage != null){
			if ( fromPage.equals("RABCPSF00002") ||  fromPage.equals("RABCPSF00003") ){
				MessageListQuery +=  " Upper(alert_status) in ('WARNING','PENDING') and  ";
			}
		}	
		
		MessageListQuery +=  "bams.alert_severe_lvl_ind = 'S' ";
		
		if(countYN.equals("N")){
			if ((sortItem != null) && !("".equals(sortItem))) {
				MessageListQuery += "order by " + sortItem + " " + sortOrder + ", bams.file_seq_num " + sortOrder;
			}
			
			if (dispatch == null) {
				MessageListQuery += " ) T ) t  where t.rn between " + startCounter + " and " + endCounter;
	    	} else {
		    	if ("createReport".equals(dispatch) || "emailReport".equals(dispatch)) {
		    		MessageListQuery += " ) T ) t " ;
				} else {
					MessageListQuery += " ) T ) t where t.rn between " + startCounter + " and " + endCounter ;
				}
	    	}
		}
		return MessageListQuery;
	}

	/**
	 * Method to generate the excel report of SystemMessages. Internaly, it calls the service class method
	 * to get the list of SystemMessages objects and by looping through that list it pouplates the excel report.
	 * 
	 * @param failureList
	 * @param systemMessagesParameters
	 * @param systemMessagesList
	 * @param report
	 * @throws FileNotFoundException
	 */
	public void getExcelReport(List failureList, SystemMessagesParameters systemMessagesParameters, List systemMessagesList,ExcelReport report) throws FileNotFoundException {
		NumberFormat numberFormat = new DecimalFormat(",##0");
		NumberFormat dollarFormat = new DecimalFormat("$ ,##0.00");
		int counter = 0;
		String startDate = null;
		String endDate =  null;
		String dateType = null;
		String cntrlPoint = null;
		String  alertRule = null;
		String alertRuleTiming = null;
		String divisionName = null;
		String severelvl = null;
		String revenueImpactValue = null;
		String revenueImpactInd = null;
		String alertStatus = null;
		String rootcatgycd = null;
		String alertgrp = null;
		String syserrortype = null;
		String upStartDate = null;
		String upEndDate =  null;
		
		try {
			
			if (systemMessagesList != null) {
				int systemMessagesListSize = systemMessagesList.size();
				if(systemMessagesParameters.getStartDate() != null){ 
					startDate = systemMessagesParameters.getStartDate();
				}
				if(systemMessagesParameters.getEndDate() != null){ 
					endDate = systemMessagesParameters.getEndDate();
				}
				if(systemMessagesParameters.getDateType() != null){ 
					dateType = systemMessagesParameters.getDateType();
				}
				if(systemMessagesParameters.getControlPoint() != null){ 
					cntrlPoint = systemMessagesParameters.getControlPoint();
				}
				if(systemMessagesParameters.getAlertRule() != null){ 
					alertRule = systemMessagesParameters.getAlertRule();
				}
				if(systemMessagesParameters.getAlertRuleTiming() != null){ 
					alertRuleTiming = systemMessagesParameters.getAlertRuleTiming();
				}
				if(systemMessagesParameters.getDivision() != null){ 
					divisionName = systemMessagesParameters.getDivision();
				}
				if(systemMessagesParameters.getSeverelvl() != null){ 
					severelvl = systemMessagesParameters.getSeverelvl();
				}
				if(systemMessagesParameters.getRevenueImpactValue() != null) { 
					revenueImpactValue = systemMessagesParameters.getRevenueImpactValue();
				}
				if(systemMessagesParameters.getRevenueImpactIndicator() != null) { 
					revenueImpactInd = systemMessagesParameters.getRevenueImpactIndicator();
				}
				if(systemMessagesParameters.getAlertStatus() != null){ 
					alertStatus = systemMessagesParameters.getAlertStatus();
				}
				if(systemMessagesParameters.getRootCatgyCd() != null){ 
					rootcatgycd = systemMessagesParameters.getRootCatgyCd();
				}
				if(systemMessagesParameters.getAlertGroup() != null){ 
					alertgrp = systemMessagesParameters.getAlertGroup();
				}
				if(systemMessagesParameters.getSystemErrorType() != null){ 
					syserrortype = systemMessagesParameters.getSystemErrorType();
				}
				if(systemMessagesParameters.getUpStartDate() != null){ 
					upStartDate = systemMessagesParameters.getSystemErrorType();
				}
				if(systemMessagesParameters.getUpEndDate() != null){ 
					upEndDate = systemMessagesParameters.getSystemErrorType();
				}
				
				
				report.beginReport();
				
				report.addRaw("<font size=+2><b>System Messages</b><BR></font>");
				
				if(dateType.equals("file")){
					report.addRaw("<font size=+1>From File Dates: "+startDate+"</font>");
				}else {
					report.addRaw("<font size=+1>From Alert Run Dates: "+startDate+"</font>");
				}
				if(  (endDate != null) ){
					if(  !(endDate.equals(""))   &&  !(endDate.equals(startDate)) ){
						report.addRaw("<font size=+1> - "+endDate+"</font>");
					}
				}
				
				report.addBreak();
				report.beginTable();
				
				if (systemMessagesParameters.getWebPageId().equals("RABCPSF00009")) {
					report.beginRow();						
					report.addLabel("Report Criteria:");
					if(  (endDate != null)   &&  (startDate!= null) ){
						if ( !(startDate.equals("")) && !(endDate.equals(""))) {
							if(dateType.equals("file")){
								report.addLabel("File Dates:");
							}else {
								report.addLabel("Alert Run Dates:");
							}	
							report.addLabel(startDate + " - " + endDate);
							report.endRow();
						}
					}
				
					if( upStartDate != null   && upEndDate != null ){	
						if( !upStartDate.equals("")   && !upEndDate.equals("") ){
							report.beginRow();		
							report.addRaw("<td nowrap><b>Last Update Dates:</b> "+upStartDate+" - "+upEndDate+"</td>");
							report.endRow();
						}
					}
					
					if( cntrlPoint != null ){
						if(!cntrlPoint.equals("")){
							report.beginRow();	
							report.addColumn("Control Point:"+cntrlPoint);
							report.endRow();
						}
					}
					
					if( alertRule != null ){
						if(!alertRule.equals("")){
							report.beginRow();	
							report.addColumn("Alert Rule:"+alertRule);
							report.endRow();
						}
					}
					
					if( alertRuleTiming != null ){
						if(!alertRuleTiming.equals("")){
							report.beginRow();	
							String timeValue = "";
							if ("B".equals(alertRuleTiming)){
								timeValue = "Bill Cycle - " + systemMessagesParameters.getAlertRuleTimingIndicator();
							}else if ("R".equals(alertRuleTiming)) {
								timeValue = "Record" ;
							} else if ("D".equals(alertRuleTiming)){
								if ("1".equals(systemMessagesParameters.getAlertRuleTimingIndicator())){
									timeValue = "Call Day Week - Sun";
								} else if ("2".equals(systemMessagesParameters.getAlertRuleTimingIndicator())){
									timeValue = "Call Day Week - Mon";
								} else if ("3".equals(systemMessagesParameters.getAlertRuleTimingIndicator())){
									timeValue = "Call Day Week - Tue";
								} else if ("4".equals(systemMessagesParameters.getAlertRuleTimingIndicator())){
									timeValue = "Call Day Week - Wed";
								} else if ("5".equals(systemMessagesParameters.getAlertRuleTimingIndicator())){
									timeValue = "Call Day Week - Thu";
								} else if ("6".equals(systemMessagesParameters.getAlertRuleTimingIndicator())){
									timeValue = "Call Day Week - Fri";
								}else if ("7".equals(systemMessagesParameters.getAlertRuleTimingIndicator())){
									timeValue = "Call Day Week - Sat";
								}
							}
							report.addColumn("Time Value: " + timeValue);
							report.endRow();
						}
					}
					
					if( divisionName != null ){
						if(!divisionName.equals("")){
							report.beginRow();	
							report.addColumn("Division Name: "+divisionName);
							report.endRow();
						}
					}
					
					if( severelvl != null ){
						if(!severelvl.equals("")){
							report.beginRow();	
							report.addColumn("Severity Level: "+severelvl);
							report.endRow();
						}
					}
					
					if ((revenueImpactValue != null) && (!revenueImpactValue.trim().equals(""))) {
						double revenueImpactValue1 = (new Double(revenueImpactValue.trim())).doubleValue();
						report.beginRow();	
						report.addColumn("Revenue Impact: "+ revenueImpactInd + " " + dollarFormat.format(revenueImpactValue1));
						report.endRow();
					}
					
					if( alertStatus != null ){
						if(!alertStatus.equals("")){
						report.beginRow();	
						report.addColumn("Alert Status: "+alertStatus);
						report.endRow();
						}
					}
					
					if( rootcatgycd != null ){
						if(!rootcatgycd.equals("")){
							report.beginRow();	
							report.addColumn("Root Category: "+rootcatgycd);
							report.endRow();
						}
					}
					
					if( alertgrp != null ){
						if(!alertgrp.equals("")){
							report.beginRow();	
							report.addColumn("Alert Group: "+alertgrp);
							report.endRow();
						}
					}
					if( syserrortype != null ){
						if(!syserrortype.equals("")){
						report.beginRow();
						report.addColumn("System Error: "+syserrortype);
						report.endRow();
						}
					}
					report.beginRow();
					report.endRow();
				}
				
				report.beginRow();
				report.addColumn("Total Messages:", "#FFFFFF", true, "left");
				report.addColumn(numberFormat.format(systemMessagesListSize), "#FFFFFF", false, "left");
				report.endRow();
				
				report.beginRow();
				report.endRow();
				report.endTable();
				
				report.addRaw("<table width=100% border=2>");
				report.beginRow();
				report.addRaw("<th>File Date</th>");
				report.addRaw("<th>Alert Rule</th>");
				report.addRaw("<th>Seq.<br>Num.</th>");
				report.addRaw("<th>System<br>Error Code</th>");
				report.addRaw("<th>System Message <br>Description</th>");
				report.addRaw("<th>Status</th>");
				report.addRaw("<th>Dollar<br>Impact</th>");
				report.addRaw("<th>Root Cause<br>Category</th>");
				report.endRow();
				
				if( systemMessagesListSize > 0 ){
					for(counter=0; counter<systemMessagesListSize; counter++) {
						
						SystemMessages  systemMessages  = (SystemMessages) systemMessagesList.get(counter);
						
						report.beginRow();
						report.addRaw("<td align=center valign=middle>"+systemMessages.getFileDate()+"&nbsp;</td>");
						report.addRaw("<td valign=middle>"+systemMessages.getAlertRule()+"&nbsp;</td>");
						if ((systemMessages.getFileSeqNum() != null) && (!systemMessages.getFileSeqNum().equals(""))) {
							report.addRaw("<td valign=middle>"+systemMessages.getFileSeqNum()+"&nbsp;</td>");
						} else {
							report.addRaw("<td valign=middle>&nbsp;</td>");
						}
						if ((systemMessages.getSystemErrorCode() != null) && (!systemMessages.getSystemErrorCode().equals(""))) {
							report.addRaw("<td align=center valign=middle>"+systemMessages.getSystemErrorCode()+"&nbsp;</td>");
						} else {
							report.addRaw("<td valign=middle>&nbsp;</td>");
						}
						report.addRaw("<td valign=middle>"+systemMessages.getSystemMessageDescription()+"&nbsp;</td>");
						report.addRaw("<td align=center valign=middle>"+systemMessages.getStatus()+"&nbsp;</td>");
						
						if ((systemMessages.getDollarImpact() != null) && (!systemMessages.getDollarImpact().equals(""))) {
							report.addRaw("<td align=right valign=middle>$ "+systemMessages.getDollarImpact()+"&nbsp;</td>");
						} else {
							report.addRaw("<td valign=middle>&nbsp;</td>");
						}
						
						if(systemMessages.getRootCauseCategoryList().size() > 0){
							int rootCatgyCount = systemMessages.getRootCauseCategoryList().size();
							report.addRaw("<td align=center valign=middle>");
								for(int i=0; i<systemMessages.getRootCauseCategoryList().size(); i++) {
									report.addRaw( (String) systemMessages.getRootCauseCategoryList().get(i) +"&nbsp;<br>");
								}
								report.addRaw("&nbsp;</td>");
						}else{
							report.addRaw("<td align=center valign=middle>&nbsp;</TD>");
						}
						
						report.endRow();
					}	
				}else{
					report.beginRow();
					report.addRaw("<td colspan='8' align='center'>None Found.</td>");
					report.endRow();
				}
				report.addRaw("</table>");
				
				report.endReport();
			}
			
		} catch (IOException iox) {
			logger.error("Error in creting the excel report. Exception details: " + iox.getMessage(), iox);
		  	failureList.add(new RABCException("Error in creting the excel report.", iox));
		}
	}

	/**
	 * Method to return the total count of SystemMessages objects.
	 * 
	 * @param systemMessagesForm
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return int
	 */
	protected int getTotalMessages(SystemMessagesParameters systemMessagesParameters,  Connection connection, List failureList, List args) {
		
		String getMessage = null;
		String controlPoint = null;
		String alertRule = null;
		String[] params = null;
		args.add(6, "Y");
		/*
		 * Call the private method getQueryForMessageList(connection, failureList, systemMessagesParameters, args) to
		 *  populate the the String with the arguments required to execute the query.
		 */

		if(systemMessagesParameters.getControlPoint() != null  ){
			if( !(systemMessagesParameters.getControlPoint().equals("")) ){
				controlPoint = systemMessagesParameters.getControlPoint();
			}
		}
		if(systemMessagesParameters.getAlertRule() != null){
			if( !(systemMessagesParameters.getAlertRule().equals("")) ){
				alertRule = systemMessagesParameters.getAlertRule();
			}
		}
			
		params = new String [2];	
		if( (controlPoint != null) && (alertRule == null) ){
			getMessage = getTotalMessages1;
			params[0] = controlPoint;
			params[1] = getQueryForMessageList(connection, failureList, systemMessagesParameters, args);
		}else{
			getMessage = getTotalMessages;
			params[0] = getQueryForMessageList(connection, failureList, systemMessagesParameters, args);
		}		
	
		
		/*
		 * Call the private method getTotalMessagesCount(connection, failureList, params, getMessage) to
		 * return the total count of SystemMessages objects.
		 */
		int totalMessageCount = getTotalMessagesCount(connection, failureList, params, getMessage);
		
		
		if (!failureList.isEmpty()) {
			// Exception occurred, hence return
			return 0;
		}
		
		return totalMessageCount;
	}

	/**
	 * Private method which will return list of total messages count of SystemMessages objects.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @param query
	 * @return int
	 */
	private int getTotalMessagesCount(Connection connection, List failureList, String[] args, String query){
		SystemMessages systemMessages = new SystemMessages();
		List systemMessagesList = new ArrayList();
		AlertReportDetail alertReportDetail = null;
		String selectSQL = query;
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		int totalCount = 0;
		
		try{
			MessageFormat mf = new MessageFormat(selectSQL);
			prepareStatement = mf.format(args);
			logger.debug("To get SystemMessages List - Executing SQL statement: "+ prepareStatement);
			stmt =  connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			if (rs != null) {
				while(rs.next()){
					totalCount = rs.getInt(1);
				}
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
		} finally{
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}		
		return totalCount;
	}
	
	/**
	 * Method to return the default line count.
	 * 
	 * @param connection
	 * @param failureList
	 * @param userId
	 * @return int
	 */
	protected int getDefaultLineCount(Connection connection, List failureList, String userId) {
		int defaultLineCount = 0;
		String selectSQL = getDefaultLineCount;
		List args = new ArrayList();
		args.add(userId);
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		try{
			MessageFormat mf = new MessageFormat(selectSQL);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			if (rs != null && rs.next()) {
				defaultLineCount = rs.getInt(1);
			} else {
				defaultLineCount = RABCConstantsLists.getRABCConstantsLists().getPageSize();
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
		} finally {
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		
		return defaultLineCount;
	}
	
	/**
	 * Method to return the list of Cycles for the entered file start date and end date.
	 * It calls the CycleCalendarDAO class to get the list of cycles.
	 * 
	 * @param connection
	 * @param failureList
	 * @param args
	 * @return List
	 */
	protected List getCycleCalendarList(Connection connection, List failureList, SystemMessagesParameters systemMessagesParameters) {
		List cycleList = new ArrayList();
		List cycleArgsList = new ArrayList();
		String query = query_getCycle;
		String startDate = systemMessagesParameters.getStartDate();
		String endDate = systemMessagesParameters.getEndDate();
		
		if((startDate != null && !"".equals(startDate)) && (endDate == null || "".equals(endDate))) {
			cycleArgsList.add("where proc_dt = to_date('"+startDate+"','MM/DD/YYYY')");
		} else if((startDate != null && !"".equals(startDate))  && (endDate != null && !"".equals(endDate)) && startDate.equals(endDate)) {
			cycleArgsList.add("where proc_dt  = to_date('"+startDate+"','MM/DD/YYYY')");
		} else if((startDate != null && !"".equals(startDate))  && (endDate != null && !"".equals(endDate)) && (!startDate.equals(endDate))) {
			cycleArgsList.add("where proc_dt  between  to_date('"+startDate+"','MM/DD/YYYY') and to_date('"+endDate+"','MM/DD/YYYY')");
		} else {
			cycleArgsList.add("");
		}
		cycleList = new CycleCalendarDAO().get(connection, failureList, cycleArgsList, query);
		if (!failureList.isEmpty()) {
			return null;
		}
		return cycleList;
	}
	
	/**
	 * Private method to get the description corresponding to the system error code
	 * @param connection
	 * @param failureList
	 * @param sysErrType
	 * @return
	 */
	private String getSysErrTypeDesc(Connection connection, List failureList, String sysErrType){
		String sysErrDesc = null;
		
		String selectSQL = getSysErrDesc;
		List args = new ArrayList();
		args.add(sysErrType);
		
		String prepareStatement = null;
		Statement stmt = null;
		ResultSet rs = null;
		
		try{
			MessageFormat mf = new MessageFormat(selectSQL);
			prepareStatement = mf.format((String[])args.toArray(new String[args.size()]));
			stmt = connection.createStatement();
			rs = stmt.executeQuery(prepareStatement);
			while(rs.next()) {
				sysErrDesc = " - " + rs.getString(1);
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}) + " Exception details: " + sx.getMessage(), sx);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {prepareStatement}), sx));
			return null;
		} finally{
			SQLHelper.closeResultSet(rs, failureList, logger);
			SQLHelper.closeStatement(stmt, failureList, logger);
		}
		
		return sysErrDesc;
	}
}
