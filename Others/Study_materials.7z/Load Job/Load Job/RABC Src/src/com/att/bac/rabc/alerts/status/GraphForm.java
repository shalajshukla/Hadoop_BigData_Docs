/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.alerts.status;

import java.util.ArrayList;
import java.util.List;

import org.apache.struts.action.ActionForm;

import com.att.bac.rabc.PickList;

/**
 * This is an action form to represent graph page.
 * It holds the attributes to be represented on the data graph as well as percent graph.
 * 
 * @author Shailesh Hemdev - SH8512
 */
public class GraphForm extends ActionForm {
	private GraphParameters graphParameters;
	private String percentGraphFlg = "N";
	private PercentGraph percentGraph;
	private DataGraph dataGraph;
	private String dispatch;
	private String percentGraphTitle;
	private String percentGraphSelectionCriteria;
	private String dataGraphTitle;
	private String dataGraphSelectionCriteria;
	private String percentGraphXAxisTitle;
	private String percentGraphYAxisTitle;
	private String dataGraphXAxisTitle;
	private String dataGraphYAxisTitle;
	private List key1List;
	private String procDate;
	
	/**
	 * Default constructor which sets the graph parameters and key1 list.
	 */
	public GraphForm() {
		GraphParameters graphParameters = new GraphParameters();
		this.setGraphParameters(graphParameters);
		this.key1List = new ArrayList();
	}

	/**
	 * @return Returns the dispatch.
	 */
	public String getDispatch() {
		return dispatch;
	}
	/**
	 * @param dispatch The dispatch to set.
	 */
	public void setDispatch(String dispatch) {
		this.dispatch = dispatch;
	}
	/**
	 * @return Returns the graphParameters.
	 */
	public GraphParameters getGraphParameters() {
		return graphParameters;
	}
	/**
	 * @param graphParameters The graphParameters to set.
	 */
	public void setGraphParameters(GraphParameters graphParameters) {
		this.graphParameters = graphParameters;
	}

	/**
	 * @return Returns the percentGraph.
	 */
	public PercentGraph getPercentGraph() {
		return percentGraph;
	}
	/**
	 * @param percentGraph The percentGraph to set.
	 */
	public void setPercentGraph(PercentGraph percentGraph) {
		this.percentGraph = percentGraph;
	}
	
	/**
	 * @return Returns the percentGraphFlg.
	 */
	public String getPercentGraphFlg() {
		return percentGraphFlg;
	}
	/**
	 * @param percentGraphFlg The percentGraphFlg to set.
	 */
	public void setPercentGraphFlg(String percentGraphFlg) {
		this.percentGraphFlg = percentGraphFlg;
	}
	
	/**
	 * @return Returns the title.
	 */
	public String getPercentGraphTitle() {
		return percentGraphTitle;
	}
	/**
	 * @param title The title to set.
	 */
	public void setPercentGraphTitle(String title) {
		this.percentGraphTitle = title;
	}
	
	/**
	 * @return Returns the selectionCriteria.
	 */
	public String getPercentGraphSelectionCriteria() {
		return percentGraphSelectionCriteria;
	}
	/**
	 * @param selectionCriteria The selectionCriteria to set.
	 */
	public void setPercentGraphSelectionCriteria(String selectionCriteria) {
		this.percentGraphSelectionCriteria = selectionCriteria;
	}
	
	/**
	 * @return Returns the dataGraphSelectionCriteria.
	 */
	public String getDataGraphSelectionCriteria() {
		return dataGraphSelectionCriteria;
	}
	/**
	 * @param dataGraphSelectionCriteria The dataGraphSelectionCriteria to set.
	 */
	public void setDataGraphSelectionCriteria(String dataGraphSelectionCriteria) {
		this.dataGraphSelectionCriteria = dataGraphSelectionCriteria;
	}
	/**
	 * @return Returns the dataGraphTitle.
	 */
	public String getDataGraphTitle() {
		return dataGraphTitle;
	}
	/**
	 * @param dataGraphTitle The dataGraphTitle to set.
	 */
	public void setDataGraphTitle(String dataGraphTitle) {
		this.dataGraphTitle = dataGraphTitle;
	}
	/**
	 * @return Returns the key1List.
	 */
	public List getKey1List() {
		return key1List;
	}
	/**
	 * @param key1List The key1List to set.
	 */
	public void addKey1(PickList key1) {
		this.key1List.add(key1);
	}
	
	/**
	 * @return Returns the dataGraph.
	 */
	public DataGraph getDataGraph() {
		return dataGraph;
	}
	/**
	 * @param dataGraph The dataGraph to set.
	 */
	public void setDataGraph(DataGraph dataGraph) {
		this.dataGraph = dataGraph;
	}
	
	/**
	 * @return Returns the dataGraphXAxisTitle.
	 */
	public String getDataGraphXAxisTitle() {
		return dataGraphXAxisTitle;
	}
	/**
	 * @param dataGraphXAxisTitle The dataGraphXAxisTitle to set.
	 */
	public void setDataGraphXAxisTitle(String dataGraphXAxisTitle) {
		this.dataGraphXAxisTitle = dataGraphXAxisTitle;
	}
	/**
	 * @return Returns the dataGraphYAxisTitle.
	 */
	public String getDataGraphYAxisTitle() {
		return dataGraphYAxisTitle;
	}
	/**
	 * @param dataGraphYAxisTitle The dataGraphYAxisTitle to set.
	 */
	public void setDataGraphYAxisTitle(String dataGraphYAxisTitle) {
		this.dataGraphYAxisTitle = dataGraphYAxisTitle;
	}
	/**
	 * @return Returns the percentGraphXAxisTitle.
	 */
	public String getPercentGraphXAxisTitle() {
		return percentGraphXAxisTitle;
	}
	/**
	 * @param percentGraphXAxisTitle The percentGraphXAxisTitle to set.
	 */
	public void setPercentGraphXAxisTitle(String percentGraphXAxisTitle) {
		this.percentGraphXAxisTitle = percentGraphXAxisTitle;
	}
	/**
	 * @return Returns the percentGraphYAxisTitle.
	 */
	public String getPercentGraphYAxisTitle() {
		return percentGraphYAxisTitle;
	}
	/**
	 * @param percentGraphYAxisTitle The percentGraphYAxisTitle to set.
	 */
	public void setPercentGraphYAxisTitle(String percentGraphYAxisTitle) {
		this.percentGraphYAxisTitle = percentGraphYAxisTitle;
	}
	
	/**
	 * @return Returns the procDate.
	 */
	public String getProcDate() {
		return procDate;
	}
	/**
	 * @param procDate The procDate to set.
	 */
	public void setProcDate(String procDate) {
		this.procDate = procDate;
	}
}
