/* Created on Sep 28, 2006 by Daniel Baker (db8237). 
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.load.bill.sw;

import java.io.File;
import java.net.UnknownHostException;
import java.sql.CallableStatement;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import com.att.bac.rabc.util.EmcisEventLogger;
import com.att.bac.util.NetUtil;
import com.att.carat.util.JDBCUtil;
import com.sbc.bac.rabc.load.FilePatternLoadJob;
import com.sbc.bac.rabc.load.PrepareTableForRerun;
import com.sbc.bac.rabc.load.RabcLoadJobTrig;
import com.sbc.bac.rabc.load.RetrieveStaticInfo;
import com.sbc.bac.rabc.load.StaticErrorMsgKeys;

/**
 * @author db8237
 * 
 * Subclass of FilePatternLoadJob, which will process a delimited file.
 */
public class BPP2SWLoadJob extends FilePatternLoadJob {
	
// Array of tables accessed by this Load Job, used during backout for reruns
	private static final String[] tableNames = {"RABC_ACCT_ZERO_BLG_SUMY", "RABC_ISG_BLG_SUMY",
		"RABC_BPI_BLG_SUMY", "RABC_TOT_BLG_SUMY", "RABC_TOP_OCC_BLG_ACCT", "RABC_TOP_ADJ_BLG_ACCT",
		"RABC_TOP_RECUR_CHRG_ACCT", "RABC_NON_PYMT_BLG_ACCT", "RABC_TOP_BPI_ACCT", "RABC_ACCT_BLG_DTL",
		"RABC_TOP_PYMT_ACCT", "RABC_TOP_TEN_BLG_ACCT", "RABC_TOP_LPC_ACCT", "RABC_TOP_ISG_BLG_ACCT",
		"RABC_TOP_ISG_ADJ_ACCT", "RABC_ACCT_BLG_DTL_AVG","RABC_TOP_TEN_TX_COST_RCVRY","RABC_TX_COST_RCVRY_SUMY"};
	
// SQL for accessing table RABC_ACCT_ZERO_BLG_SUMY
	private static final StringBuffer insertAcctZeroSQL = new StringBuffer("INSERT INTO RABC_ACCT_ZERO_BLG_SUMY " +
			"(RUN_DATE, DIVISION, ACCT_TYPE_CODE, ACCT_ZERO_BLG_CT, BLG_MM, BLG_YEAR, BILL_RND) " +
			"VALUES(?, ?, ?, ?, ?, ?, ?) ");
// SQL for accessing table RABC_ISG_BLG_SUMY
	private static final StringBuffer insertISGSQL = new StringBuffer("INSERT INTO RABC_ISG_BLG_SUMY " +
			"(RUN_DATE, DIVISION, CUST_TYPE, TCC_ID, CUR_BLG_AMT_DB, CUR_BLG_AMT_CR, BILL_RND, ACCT_CT_DB, ACCT_CT_CR) " +
			"VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?) ");
// SQL for accessing table RABC_BPI_BLG_SUMY
	private static final StringBuffer insertBPISQL = new StringBuffer("INSERT INTO RABC_BPI_BLG_SUMY " +
			"(RUN_DATE, DIVISION, CUST_TYPE, CONVERGENT_CD, EBAT_CD, CUR_BLG_AMT_DB, CUR_BLG_AMT_CR, CUST_CT, BILL_RND) " +
			"VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?) ");
// SQL for accessing table RABC_TOT_BLG_SUMY
	//Added two columns for PMT #M169
	private static final StringBuffer insertTotBlgSQL = new StringBuffer("INSERT INTO RABC_TOT_BLG_SUMY " +
			"(RUN_DATE, DIVISION, BUS_TYPE, RECUR_CHRG_AMT, CURR_BLG_AMT_DB, CURR_BLG_AMT_CR, CURR_OCC_CR, " +
			"CURR_OCC_DB, BAL_DUE_AMT, LPC_AMT, ADJ_AMT_DB, ADJ_AMT_CR, TAXES_DB_AMT, TAXES_CR_AMT, SRCG_AMT_DB, " +
			"SRCG_AMT_CR, LOCAL_TOLL, LOCAL_USG_AMT, IEC_ADJ_AMT, IEC_AMT, PYMT_AMT, FED_TAX_AMT, ST_LOCAL_TAX_AMT, " +
			"FED_LD_FEE_AMT, LIFE_LINE_SRCG_AMT, DA_TOLL_AMT, BILL_RND, CUST_CT, FED_TAX_LOCL_AMT, ST_LOCAL_TAX_LOCL) " +
			"VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ");
	//Added two columns for PMT #M169
	private static final StringBuffer updateTotBlgSQL = new StringBuffer("UPDATE RABC_TOT_BLG_SUMY " +
			"SET RECUR_CHRG_AMT = RECUR_CHRG_AMT + ? , CURR_BLG_AMT_DB = CURR_BLG_AMT_DB + ? , " +
			"CURR_BLG_AMT_CR = CURR_BLG_AMT_CR + ? , CURR_OCC_CR = CURR_OCC_CR + ? , " +
			"CURR_OCC_DB = CURR_OCC_DB + ? , BAL_DUE_AMT = BAL_DUE_AMT + ? , LPC_AMT = LPC_AMT + ? , " +
			"ADJ_AMT_DB = ADJ_AMT_DB + ? , ADJ_AMT_CR = ADJ_AMT_CR + ? , TAXES_DB_AMT = TAXES_DB_AMT + ? , " +
			"TAXES_CR_AMT = TAXES_CR_AMT + ? , SRCG_AMT_DB = SRCG_AMT_DB + ? , SRCG_AMT_CR = SRCG_AMT_CR + ? , " +
			"LOCAL_TOLL = LOCAL_TOLL + ? , LOCAL_USG_AMT = LOCAL_USG_AMT + ? , IEC_ADJ_AMT = IEC_ADJ_AMT + ? , " +
			"IEC_AMT = IEC_AMT + ? , PYMT_AMT = PYMT_AMT + ? , FED_TAX_AMT = FED_TAX_AMT + ? , " +
			"ST_LOCAL_TAX_AMT = ST_LOCAL_TAX_AMT + ? , FED_LD_FEE_AMT = FED_LD_FEE_AMT + ? , " +
			"LIFE_LINE_SRCG_AMT = LIFE_LINE_SRCG_AMT + ? , DA_TOLL_AMT = DA_TOLL_AMT + ? , " + 
			"CUST_CT = CUST_CT + ? , FED_TAX_LOCL_AMT = FED_TAX_LOCL_AMT + ?, ST_LOCAL_TAX_LOCL = ST_LOCAL_TAX_LOCL + ? " + 
			"WHERE RUN_DATE = ? AND DIVISION = ? AND BUS_TYPE = ? AND BILL_RND = ?");
	
//	 SQL for accessing table RABC_TOP_OCC_BLG_ACCT
	private static final StringBuffer insertTopOCCSQL = new StringBuffer("INSERT INTO RABC_TOP_OCC_BLG_ACCT " +
			"(RUN_DATE, DIVISION, BTN, CUST_TYPE_CD, ACCT_FINL_IND, OCC_BLG_AMT, PREV_BLG_AMT, CURR_BLG_AMT, BILL_RND) " +
			"VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?) ");
// SQL for accessing table RABC_TOP_ADJ_BLG_ACCT
	private static final StringBuffer insertTopAdjSQL = new StringBuffer("INSERT INTO RABC_TOP_ADJ_BLG_ACCT " +
			"(RUN_DATE, DIVISION, BTN, CUST_TYPE_CD, ACCT_FINL_IND, ADJ_BLG_AMT, PREV_BLG_AMT, CURR_BLG_AMT, BILL_RND) " +
			"VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?) ");
// SQL for accessing table RABC_TOP_RECUR_CHRG_ACCT
	private static final StringBuffer insertTopRecurSQL = new StringBuffer("INSERT INTO RABC_TOP_RECUR_CHRG_ACCT " +
			"(RUN_DATE, DIVISION, BTN, CUST_TYPE_CD, ACCT_FINL_IND, RECUR_CHRG_AMT, PREV_BLG_AMT, " +
			"CURR_BLG_AMT, BILL_RND) " +
			"VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?) ");
//	 SQL for accessing table RABC_NON_PYMT_BLG_ACCT
	private static final StringBuffer insertNonPymtSQL = new StringBuffer("INSERT INTO RABC_NON_PYMT_BLG_ACCT " +
			"(RUN_DATE, DIVISION, BTN, CUST_TYPE_CD, ACCT_FINL_IND, LAST_PYMT_DATE, LAST_PYMT_AMT, CURR_BLG_AMT, TOT_BLG_AMT, BILL_RND) " +
			"VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ");
	private static final StringBuffer deleteNonPymtSQL = new StringBuffer("DELETE FROM RABC_NON_PYMT_BLG_ACCT " +
			"WHERE DIVISION = ? AND BILL_RND = ?");
//	 SQL for accessing table RABC_TOP_BPI_ACCT
	private static final StringBuffer insertTopBPISQL = new StringBuffer("INSERT INTO RABC_TOP_BPI_ACCT " +
			"(RUN_DATE, DIVISION, BTN, CUST_TYPE_CD, ACCT_FINL_IND, CURR_BLG_AMT, BILL_RND) " +
			"VALUES(?, ?, ?, ?, ?, ?, ?) ");
//	 SQL for accessing table RABC_ACCT_BLG_DTL
	private static final StringBuffer insertAcctDtlSQL = new StringBuffer("INSERT INTO RABC_ACCT_BLG_DTL " +
			"(RUN_DATE, DIVISION, BTN, CLS_CD, CUST_TYPE, ACCT_STATUS, BLG_CRO_CD, PREV_BLG_AMT, RECUR_CHRG_AMT, " +
			"CURR_BLG_AMT_DB, CURR_BLG_AMT_CR, CURR_OCC_CR, CURR_OCC_DB, BAL_DUE_AMT, LPC_AMT, ADJ_AMT_DB, " +
			"ADJ_AMT_CR, TAXES_DB, TAXES_CR, SRCG_AMT_DB, SRCG_AMT_CR, LOCAL_TOLL_AMT, LOCAL_USG_AMT, IEC_ADJ_AMT, " +
			"IEC_AMT, PYMT_AMT, FED_TAX_AMT, ST_LOCAL_TAX_AMT, FED_LD_FEE_AMT, LIFE_LINE_SRCG_AMT, BILL_RND, DA_TOLL_AMT) " +	
			"VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ");
	private static final StringBuffer selectAverageAcctDtlSQL = new StringBuffer("SELECT " +
			"DIVISION, BTN, AVG(PREV_BLG_AMT), AVG(RECUR_CHRG_AMT), AVG(CURR_BLG_AMT_DB), " +
			"AVG(CURR_BLG_AMT_CR), AVG(CURR_OCC_CR), AVG(CURR_OCC_DB), AVG(BAL_DUE_AMT), AVG(LPC_AMT), " +
			"AVG(ADJ_AMT_DB), AVG(ADJ_AMT_CR), AVG(TAXES_DB), AVG(TAXES_CR), AVG(SRCG_AMT_DB), AVG(SRCG_AMT_CR), " +
			"AVG(LOCAL_TOLL_AMT), AVG(LOCAL_USG_AMT), AVG(IEC_ADJ_AMT), AVG(IEC_AMT), AVG(PYMT_AMT), " +
			"AVG(FED_TAX_AMT), AVG(ST_LOCAL_TAX_AMT), AVG(FED_LD_FEE_AMT), AVG(LIFE_LINE_SRCG_AMT) ,AVG(DA_TOLL_AMT)" +
			"FROM RABC_ACCT_BLG_DTL " +
			"WHERE DIVISION = ? AND BTN IN " +
			"(SELECT BTN FROM RABC_ACCT_BLG_DTL WHERE RUN_DATE = ? AND DIVISION = ? ) " +
			"GROUP BY DIVISION, BTN");
	private static final StringBuffer selectAcctDtlSQL = new StringBuffer("SELECT * FROM RABC_ACCT_BLG_DTL " +
			"WHERE RUN_DATE = ? AND DIVISION = ? AND BTN = ? ");
//	 SQL for accessing table RABC_TOP_PYMT_ACCT
	private static final StringBuffer insertTopPymtSQL = new StringBuffer("INSERT INTO RABC_TOP_PYMT_ACCT " +
			"(RUN_DATE, DIVISION, BTN, CUST_TYPE_CD, ACCT_FINL_IND, PYMT_AMT, PREV_BLG_AMT, CURR_BLG_AMT, BILL_RND) " +
			"VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?) ");
//	 SQL for accessing table RABC_TOP_TEN_BLG_ACCT
	private static final StringBuffer insertTopTenSQL = new StringBuffer("INSERT INTO RABC_TOP_TEN_BLG_ACCT " +
			"(RUN_DATE, DIVISION, BILL_RND, RANK, BTN, BAL_DUE_AMT, CUR_BLG_AMT) " +
			"VALUES(?, ?, ?, ?, ?, ?, ?) ");
//	 SQL for accessing table RABC_TOP_LPC_ACCT
	private static final StringBuffer insertTopLPCSQL = new StringBuffer("INSERT INTO RABC_TOP_LPC_ACCT " +
			"(RUN_DATE, DIVISION, BTN, CUST_TYPE_CD, ACCT_FINL_IND, LPC_AMT, PREV_BLG_AMT, BILL_RND) " +
			"VALUES(?, ?, ?, ?, ?, ?, ?, ?) ");
//	 SQL for accessing table RABC_TOP_ISG_BLG_ACCT
	private static final StringBuffer insertTopISGBlgSQL = new StringBuffer("INSERT INTO RABC_TOP_ISG_BLG_ACCT " +
			"(RUN_DATE, DIVISION, TCC_ID, BTN, CUST_TYPE_CD, ACCT_FINL_IND, CURR_ISG_BLG_AMT, CURR_ISG_ADJ_AMT, BILL_RND) " +
			"VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?) ");
// SQL for accessing table RABC_TOP_ISG_ADJ_ACCT
	private static final StringBuffer insertTopISGAdjSQL = new StringBuffer("INSERT INTO RABC_TOP_ISG_ADJ_ACCT " +
			"(RUN_DATE, DIVISION, TCC_ID, BTN, CUST_TYPE_CD, ACCT_FINL_IND, CURR_ISG_BLG_AMT, CURR_ISG_ADJ_AMT, BILL_RND) " +
			"VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?) ");
//	 SQL for accessing table RABC_ACCT_BLG_DTL_AVG
	private static final StringBuffer insertAcctDtlAvgSQL = new StringBuffer("INSERT INTO RABC_ACCT_BLG_DTL_AVG " +
			"(RUN_DATE, DIVISION, BTN, PREV_BLG_AMT_AVG, RECUR_CHRG_AMT_AVG, CURR_BLG_AMT_DB_AVG, " +
			"CURR_BLG_AMT_CR_AVG, CURR_OCC_CR_AVG, CURR_OCC_DB_AVG, BAL_DUE_AMT_AVG, LPC_AMT_AVG, " +
			"ADJ_AMT_DB_AVG, ADJ_AMT_CR_AVG, TAXES_DB_AVG, TAXES_CR_AVG, SRCG_AMT_DB_AVG, SRCG_AMT_CR_AVG, " +
			"LOCAL_TOLL_AMT_AVG, LOCAL_USG_AMT_AVG, IEC_ADJ_AMT_AVG, IEC_AMT_AVG, PYMT_AMT_AVG, " +
			"FED_TAX_AMT_AVG, ST_LOCAL_TAX_AMT_AVG, FED_LD_FEE_AMT_AVG, LIFE_LINE_SRCG_AMT_AVG, DA_TOLL_AMT_AVG ) " +
			"VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ");
	//SQL for accessing table RABC_TOP_TEN_TX_COST_RCVRY
	private static final StringBuffer insertTopBotTxCostRecvSQL = new StringBuffer("INSERT INTO RABC_TOP_TEN_TX_COST_RCVRY (RANK_ID,RUN_DATE, DIVISION,BILL_RND,CUST_TYPE_CD,ENTITY_CD, BTN,TX_SCR_RCVRY_AMT) VALUES(?,?,?,?,?,?,?,?) ");
	//SQL for accessing table RABC_TX_COST_RCVRY_SUMY
	private static final String callTxCostRecovrSummProc= "{call PROC_RABC_TX_COST_RCVRY_SUMY(?,?,?,?,?,?)}";
	//private static final StringBuffer insertTxCostRecovrSummSQL = new StringBuffer("insert into RABC_TX_COST_RCVRY_SUMY(RUN_DATE, DIVISION, BILL_RND, ENTITY_CD,TX_SCR_RCVRY_AMT) values(?,?,?,?, ?)");
	
	// Static variable for baselining of non payments
	private static final int PYMT_BASELINE_DAYS = 90;
	
// Prepared Statements
	private PreparedStatement insertAcctZero;
	private PreparedStatement insertISG;
	private PreparedStatement insertBPI;
	private PreparedStatement insertTotBlg;
	private PreparedStatement updateTotBlg;
	private PreparedStatement insertTopOCC;
	private PreparedStatement insertTopAdj;
	private PreparedStatement insertTopRecur;
	private PreparedStatement insertNonPymt;
	private PreparedStatement deleteNonPymt;
	private PreparedStatement insertTopBPI;
	private PreparedStatement insertAcctDtl;
	private PreparedStatement selectAverageAcctDtl;
	private PreparedStatement selectAcctDtl;
	private PreparedStatement insertTopPymt;
	private PreparedStatement insertTopTen;
	private PreparedStatement insertTopLPC;
	private PreparedStatement insertTopISGBlg;
	private PreparedStatement insertTopISGAdj;
	private PreparedStatement insertAcctDtlAvg;
	private PreparedStatement insertTopTenTX;
	//private PreparedStatement insertCostRecvSummTX;
	private CallableStatement insertTxCostRecovrSumm;
	
// Common variables
	private ArrayList triggers;
	private ArrayList totBlgSumy;
	private ArrayList acctDtl;
	private File currentFile;
	private String division;
	private java.sql.Date sqlRunDate;
	private String runDate;
	private long billRnd;
	private boolean backupRecovery;
	private boolean trailerProcessed;
	private boolean firstRecord;
	private int lineCount;
	private long rank;
	private DateFormat yyyyDDD = new SimpleDateFormat("yyyyDDD");
	private DateFormat MMddyyyy = new SimpleDateFormat("MMddyyyy");
	private DateFormat yyyyMMdd = new SimpleDateFormat("yyyyMMdd");
	private ResultSet rs;
	private String fileName, fileToken, region;
	private int aff1,aff2,aff3,aff4,aff5,aff6;
	private boolean topRes;
	private boolean topBus;
	private boolean bottomRes;
	private boolean bottomBus;
    /**
     * Runs prior to processing. Sets up all necessary prepared statements.
     * 
     * @return false if an error is encountered during set up, otherwise true
     */
	public boolean preprocess() {
		super.preprocess();

		try {
			insertAcctZero = connection.prepareStatement(insertAcctZeroSQL.toString());
			insertISG = connection.prepareStatement(insertISGSQL.toString());
			insertBPI = connection.prepareStatement(insertBPISQL.toString());
			insertTotBlg = connection.prepareStatement(insertTotBlgSQL.toString());
			updateTotBlg = connection.prepareStatement(updateTotBlgSQL.toString());
			insertTopOCC = connection.prepareStatement(insertTopOCCSQL.toString());
			insertTopAdj = connection.prepareStatement(insertTopAdjSQL.toString());
			insertTopRecur = connection.prepareStatement(insertTopRecurSQL.toString());
			insertNonPymt = connection.prepareStatement(insertNonPymtSQL.toString());
			deleteNonPymt = connection.prepareStatement(deleteNonPymtSQL.toString());
			insertTopBPI = connection.prepareStatement(insertTopBPISQL.toString());
			insertAcctDtl = connection.prepareStatement(insertAcctDtlSQL.toString());
			selectAverageAcctDtl = connection.prepareStatement(selectAverageAcctDtlSQL.toString());
			selectAcctDtl = connection.prepareStatement(selectAcctDtlSQL.toString());
			insertTopPymt = connection.prepareStatement(insertTopPymtSQL.toString());
			insertTopTen = connection.prepareStatement(insertTopTenSQL.toString());
			insertTopLPC = connection.prepareStatement(insertTopLPCSQL.toString());
			insertTopISGBlg = connection.prepareStatement(insertTopISGBlgSQL.toString());
			insertTopISGAdj = connection.prepareStatement(insertTopISGAdjSQL.toString());
			insertAcctDtlAvg = connection.prepareStatement(insertAcctDtlAvgSQL.toString());
			insertTopTenTX=connection.prepareStatement(insertTopBotTxCostRecvSQL.toString());
			insertTxCostRecovrSumm=connection.prepareCall(callTxCostRecovrSummProc);
			//insertCostRecvSummTX=connection.prepareStatement(insertTxCostRecovrSummSQL.toString());
		} catch (SQLException e) {
			severe(StaticErrorMsgKeys.PREPROCESS_ERROR + e.getMessage(), e);
			return false;
		}
		return true;
	}
	
    /**
     * Runs prior to file processing. Initializes application variables.
     * 
     * @return false if an error is encountered during initialization, otherwise true
     */
	public boolean preprocessFile(File file) {
		boolean success = super.preprocessFile(file);
		fileToken = file.getName().substring(file.getName().indexOf("RA210F01"),file.getName().indexOf("RA210F01")+ 8);
		fileName = file.getName();
		region   =	file.getName().substring(0,2);
		if (success) {
			try {
				triggers = new ArrayList();
				totBlgSumy = new ArrayList();
				acctDtl = new ArrayList();
				backupRecovery = false;
				trailerProcessed = false;
				firstRecord = true;
				lineCount = 0;
				rank = 0;
				topRes=true;
				topBus=true;
				bottomRes=true;
				bottomBus=true;
				if (RabcLoadJobTrig.IsOriginalFileLoaded(connection, file, file.getName().length())) {
					backupRecovery = true;
				}
			} catch (Exception e) {
				severe(StaticErrorMsgKeys.PREPROCESSFILE_ERROR + StaticErrorMsgKeys.FILE_NAME_PARSING_ERROR + e, e);
				return false;
			}
		}
		currentFile = file;
		return success;
	}

    /**
     * Parses the most recently read line of the input file, determines what type of record it is, and passes it
     * to the appropriate routine for processing.
     * 
     * @param line
     *   The most recently read line of the input file.
     * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob
     * @throws Exception
     *   if any unhandled Exception is encountered, if the TRAILER record is not the last record on the processing file,
     *   if the HEADER record is not he first record on the processing file, and also if the DATE record does not
     *   immediately follow the HEADER record.
     */
	protected int parseLine(String line) throws Exception {
		String[] fields = line.split("[ ]*;[ ]*");
		
		if (trailerProcessed) {									// trailer must be last record on file
			throw new Exception("TRAILER was not the last record on currently processing file: " + currentFile.getName());
		}
		
		if (firstRecord) {										// header must be first record on file
			firstRecord = false;
			if ("HEADER".equalsIgnoreCase(fields[0])) {
				division = fields[2];
				return SUCCESS;
			} else {
				throw new Exception("HEADER was not the first record on currently processing file: " + currentFile.getName());
			}
		}
		
		if ("TRAILER".equalsIgnoreCase(fields[0])) {
			trailerProcessed = true;
			return processTrailerRecord(fields);
		}
		
		lineCount++;											// header and trailer records are not counted
		
		if (lineCount == 1) {									// date record must be second record on file
			if ("RA21BPP2".equalsIgnoreCase(fields[0]) && "04".equalsIgnoreCase(fields[1])) {
				return processDateRecord(fields);
			} else {
				throw new Exception("DATE record did not immediately follow the HEADER on currently processing file: " + currentFile.getName());
			}
		}
		
		if ("RA21BPP2".equalsIgnoreCase(fields[0])) {
			if ("01".equalsIgnoreCase(fields[1])) {
				if (billRnd > 0) {
					if (!triggers.contains("SWBLGOO") ) {
						triggers.add("SWBLGOO");
					}
				}
				return insertAcctZeroRecord(fields);
			}
			
			if ("02".equalsIgnoreCase(fields[1]) || "05".equalsIgnoreCase(fields[1])) {
				// Skip if TCC_ID is blank
				if (fields[4]==null || "".equals(fields[4].trim())) {
					return SKIPPED;
				}
				
				if (billRnd > 0) {
					if (!triggers.contains("SWBLGISG")) {
						triggers.add("SWBLGISG");
					}
				}
				return insertISGRecord(fields);
			}
			
			if ("10".equalsIgnoreCase(fields[1])) {
				boolean proceed = checkBPIRecord(fields);
				if (proceed && billRnd > 0) {
					if (!triggers.contains("SWBLGBPI")) {
						triggers.add("SWBLGBPI");
					}
				}
				if (proceed){
					return insertBPIRecord(fields);
				}
			}
			
			if ("19".equalsIgnoreCase(fields[1]) || "20".equalsIgnoreCase(fields[1])) {
				if (billRnd > 0) {
					if (!triggers.contains("SWBLGSUM")) {
						triggers.add("SWBLGSUM");
					}
				}
				return processTotBlgRecord(fields);
			}
			
			if ("28".equalsIgnoreCase(fields[1])) {
				// Skip if BTN is blank
				if (fields[3]==null || "".equals(fields[3].trim())){
					return SKIPPED;
				}
				return insertTopOCCRecord(fields);
			}
			
			if ("29".equalsIgnoreCase(fields[1])) {
				// Skip if BTN is blank
				if (fields[3]==null || "".equals(fields[3].trim())){
					return SKIPPED;
				}
				return insertTopAdjRecord(fields);
			}
			
			if ("30".equalsIgnoreCase(fields[1])) {
				//	Skip if BTN is blank
				if (fields[3]==null || "".equals(fields[3].trim())){
					return SKIPPED;
				}
				return insertTopRecurRecord(fields);
			}
			
			if ("32".equalsIgnoreCase(fields[1])) {
				//	Skip if BTN is blank or LAST_PYMT_DT is blank or 0 OR Total Charges is blank
				if (fields[3]==null || "".equals(fields[3].trim())|| fields[9]==null || "".equals(fields[9].trim()) || "00000000".equals(fields[9].trim()) || fields[12]==null || "".equals(fields[12].trim())){
					return SKIPPED;
				}
				
				// Skip the record if Total Charges is 0
				if (Double.parseDouble(fields[12])==0){
					return SKIPPED;
				}
				
				// Skip the record if the LAST_PYMT_DT is after the PYMT Baseline date which RUN_DATE - 90
				if (isAfterBaselineDate(fields[9],PYMT_BASELINE_DAYS)){
					return SKIPPED;
				}
				
				return insertNonPymtRecord(fields);
			}
			
			if ("37".equalsIgnoreCase(fields[1])) {
				//	Skip if BTN is blank
				if (fields[3]==null || "".equals(fields[3].trim())){
					return SKIPPED;
				}
				return insertTopBPIRecord(fields);
			}
			
			if ("38".equalsIgnoreCase(fields[1])) {
				//	Skip if BTN is blank
				if (fields[3]==null || "".equals(fields[3].trim())){
					return SKIPPED;
				}
				return insertAcctDtlRecord(fields);
			}
			
			if ("39".equalsIgnoreCase(fields[1])) {
				//	Skip if BTN is blank
				if (fields[3]==null || "".equals(fields[3].trim())){
					return SKIPPED;
				}
							
				return insertTopPymtRecord(fields);
			}
			
			if ("40".equalsIgnoreCase(fields[1])) {
				//	Skip if BTN is blank
				if (fields[3]==null || "".equals(fields[3].trim())){
					return SKIPPED;
				}
				
				if (insertTopTenRecord(fields) == SUCCESS) {	// If the insert to RABC_TOP_TEN_BLG_ACCT was good
					acctDtl.add(fields);						// Store for possible insertion to RABC_ACCT_BLG_DTL following batch processing
					return SUCCESS;
				} else {
					return ERROR;
				}
			}
			
			if ("41".equalsIgnoreCase(fields[1])) {
				//	Skip if BTN is blank
				if (fields[3]==null || "".equals(fields[3].trim())){
					return SKIPPED;
				}
				return insertTopLPCRecord(fields);
			}
	
			if ("42".equalsIgnoreCase(fields[1].trim()) || "43".equalsIgnoreCase(fields[1].trim()) || "06".equalsIgnoreCase(fields[1].trim())) {
				// if division values are T (Dallas), N (Houston), and X San Antonio)
				if (division.equals("T") || division.equals("N") || division.equals("X")) {
					if ("42".equalsIgnoreCase(fields[1].trim())
							|| "43".equalsIgnoreCase(fields[1].trim())) {
						// Skip if BTN is blank
						if (fields[5] == null || "".equals(fields[5].trim())) {
							return SKIPPED;
						}
						return insertTopBottomCostRcvryRecord(fields);
					}
					if ("06".equalsIgnoreCase(fields[1].trim())) {
						// Skip if BTN is blank
						if (fields[3] == null || "".equals(fields[3].trim())) {
							return SKIPPED;
						}
						return insertCostRecoverySummary(fields);
					}
				} else {
					return SUCCESS;
				}
			}
					
			if ("98".equalsIgnoreCase(fields[1])) {
				//	Skip if TCC_ID or BTN is blank
				if (fields[2]==null || "".equals(fields[2].trim()) || fields[3]==null || "".equals(fields[3].trim()) || fields[9]==null || "".equals(fields[9].trim()) || fields[11]==null || "".equals(fields[11].trim())){
					return SKIPPED;
				}
				
				if (Long.parseLong(fields[9])==0 && Long.parseLong(fields[10])==0){
					return SKIPPED;
				}
				
				return insertTopISGBlgRecord(fields);
			}
			
			if ("99".equalsIgnoreCase(fields[1])) {
				//	Skip if TCC_ID or BTN is blank
				if (fields[2]==null || "".equals(fields[2].trim()) || fields[3]==null || "".equals(fields[3].trim()) || fields[9]==null || "".equals(fields[9].trim()) || fields[11]==null || "".equals(fields[11].trim())){
					return SKIPPED;
				}
				
				if (Long.parseLong(fields[9])==0 && Long.parseLong(fields[10])==0){
					return SKIPPED;
				}
				
				return insertTopISGAdjRecord(fields);
			}
		
		}
		
		warning(StaticErrorMsgKeys.INVAID_RECORD_TYPE + fields[0] + fields[1]);
		return ERROR;
	}
	
    /**
     * Processes the most recently read line of the input file, once it has been identified as a Date record.
     * 
     * @param fields
     *   an Array of the fields in the most recently read line of the input file.
     * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob
     */
	private int processDateRecord(String[] fields) {
		try {
			sqlRunDate = new Date(yyyyDDD.parse(fields[2]).getTime());
			runDate = yyyyMMdd.format(sqlRunDate);
			billRnd = getBillRnd(runDate);
			
		} catch (ParseException e) {
			severe(StaticErrorMsgKeys.PARSELINE_ERROR + "Error occurred while parsing Date on file: " + e, e);
			return ERROR;
		} catch (SQLException sqle) {
			severe("SQL Error encountered while attempting to acquire BILL_RND in method processDateRecord(String[] fields):" + sqle.getMessage(), sqle);
			return ERROR;
		}
		
		if (backupRecovery) {
			for (int i = 0; i < tableNames.length; i++) {
				if (!PrepareTableForRerun.deleteTableData(connection, tableNames[i], division, sqlRunDate)) {
					severe("Error occurred attempting to backup and recover for rerun for table: " + tableNames[i]);
					return ERROR;
				}
			}
		}
		
		return SUCCESS;
	}
	
    /**
     * Processes the most recently read line of the input file, once it has been identified as a Trailer record.
     * Validates that the number of records processed is equal to the record count on the Trailer record.
     * Header and trailer records are the only records not included in the line count.
     * 
     * @param fields
     *   an Array of the fields in the most recently read line of the input file.
     * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob
     * @throws Exception
     *   if the line count on the trailer does not match the number of lines processed
     */
	private int processTrailerRecord(String[] fields) throws Exception {
		int totalRecords = Integer.parseInt(fields[5]);
		
		if (totalRecords == lineCount) {
			return SUCCESS;
		}
		
		throw new Exception("Record count mismatch, trailer record shows " + totalRecords + ", but " + lineCount + " records exist on file " + currentFile.getName());
	}
	
    /**
     * Performs an Insert to table RABC_ACCT_ZERO_BLG_SUMY, using the data from the most recently read line
     * of the input file.
     * 
     * @param fields
     *   an Array of the fields in the most recently read line of the input file.
     * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob.
     */
	//added for PMT390711
	private int insertTopBottomCostRcvryRecord(String[] fields) throws Exception
	{
		try {
			int rankId=1;
			if(fields[1].trim().equals("42") && topRes && fields[3].trim().equals("1"))//for top 10 records of CUST_TYPE_CD(RES)
			{
				aff1=1;
				aff2=1;
				aff3=1;
				aff4=1;
				aff5=1;
				aff6=1;
				topRes=false;
			}
			if(fields[1].trim().equals("42") && topBus && fields[3].trim().equals("2"))//for top 10 records of CUST_TYPE_CD(BUS)
			{
				aff1=1;
				aff2=1;
				aff3=1;
				aff4=1;
				aff5=1;
				aff6=1;
				topBus=false;
			}
			if(fields[1].trim().equals("43") && bottomRes && fields[3].trim().equals("1"))// for bottom 10 records of CUST_TYPE_CD(RES)
			{
				aff1=1;
				aff2=1;
				aff3=1;
				aff4=1;
				aff5=1;
				aff6=1;
				bottomRes=false;
			}
			if(fields[1].trim().equals("43") && bottomBus && fields[3].trim().equals("2"))// for bottom 10 records of CUST_TYPE_CD(BUS)
			{
				aff1=1;
				aff2=1;
				aff3=1;
				aff4=1;
				aff5=1;
				aff6=1;
				bottomBus=false;
			}
			//check for Affiliate types
			if(fields[4].trim().equals("00000000"))          //Non Telco
			{
				rankId=aff1;
				aff1++;
			}
			else if(fields[4].trim().equals("00438M00"))     //Telco 
			{
				rankId=aff2;
				aff2++;
			}
			else if(fields[4].trim().equals("00438100"))
			{
				rankId=aff3;
				aff3++;
			}
			else if(fields[4].trim().equals("00478100"))
			{
				rankId=aff4;
				aff4++;
			}
			else if(fields[4].trim().equals("07717M00"))
			{
				rankId=aff5;
				aff5++;
			}
			else if(fields[4].trim().equals("07727100"))
			{
				rankId=aff6;
				aff6++;
			}
		insertTopTenTX.setInt(1, rankId);	
		insertTopTenTX.setDate(2, sqlRunDate);//MMDDCCYY
		insertTopTenTX.setString(3, division);
		insertTopTenTX.setInt(4, (int) billRnd);
		
		if(fields[3].trim().equals("1"))     //CUST_TYPE_CD 
		insertTopTenTX.setString(5,"R")	;
		else if(fields[3].trim().equals("2"))
		insertTopTenTX.setString(5,"B")	;
		
		insertTopTenTX.setString(6, fields[4].trim());//Affliate or Entity_cd
		insertTopTenTX.setString(7, fields[5].trim());//BTN
		insertTopTenTX.setDouble(8, Double.parseDouble(fields[6].trim())==0.0?0.0:Double.parseDouble(fields[6].trim())/1000000);//TX_SCR_RCVRY_AMNT
		insertTopTenTX.addBatch();
		} 
		catch (SQLException sqle) {
			severe(StaticErrorMsgKeys.INSERT_ERROR + "from method insertTopCostRcvryRecord(String[] fields)" + sqle.getMessage(), sqle);
			return ERROR;
	}
		return SUCCESS;
	}
	//added for PMT390711
	public int insertCostRecoverySummary(String[] fields)
	{
		try{
			
			insertTxCostRecovrSumm.setDate(1, sqlRunDate);//RUN_DATE
			insertTxCostRecovrSumm.setString(2, division);
			insertTxCostRecovrSumm.setInt(3, (int) billRnd);
			
			if(fields[3].trim().equals("1"))     //CUST_TYPE_CD 
			insertTxCostRecovrSumm.setString(4,"R")	;
			else if(fields[3].trim().equals("2"))
			insertTxCostRecovrSumm.setString(4,"B")	;
			 
			insertTxCostRecovrSumm.setString(5,fields[4].trim());//Affliate or Entity_cd
			insertTxCostRecovrSumm.setDouble(6, Double.parseDouble(fields[5].trim())==0.0?0.0:Double.parseDouble(fields[5].trim())/1000000);//TX_SCR_RCVRY_AMNT
			insertTxCostRecovrSumm.addBatch();
		}
		catch (SQLException sqle) {
			severe(StaticErrorMsgKeys.INSERT_ERROR + "from method insertTopCostRcvryRecord(String[] fields)" + sqle.getMessage(), sqle);
			return ERROR;
		}
		return SUCCESS;
	}
	
	private int insertAcctZeroRecord(String[] fields) {
		try {
			insertAcctZero.setDate(1, sqlRunDate);									// RUN_DATE
			insertAcctZero.setString(2, division);									// DIVISION
			insertAcctZero.setString(3, fields[3]);									// ACCT_TYPE_CODE
			insertAcctZero.setLong(4, Long.parseLong(fields[4]) / 1000000);			// ACCT_ZERO_BLG_CT
			insertAcctZero.setString(5, runDate.substring(4, 6));					// BLG_MM
			insertAcctZero.setString(6, runDate.substring(0, 4));					// BLG_YEAR
			insertAcctZero.setLong(7, billRnd);										// BILL_RND
			
			insertAcctZero.addBatch();
		} catch (SQLException sqle) {
			severe(StaticErrorMsgKeys.INSERT_ERROR + "from method insertAcctZeroRecord(String[] fields)" + sqle.getMessage(), sqle);
			return ERROR;
		}
		
		return SUCCESS;
	}
	
	/**
	 * Performs an Insert to table RABC_ISG_BLG_SUMY, using the data from the most recently read line
	 * of the input file.
	 * 
	 * @param fields
	 *   an Array of the fields in the most recently read line of the input file.
	 * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob.
	 */
	private int insertISGRecord(String[] fields) {
		try {
			insertISG.setDate(1, sqlRunDate);										// RUN_DATE
			insertISG.setString(2, division);										// DIVISION
			insertISG.setString(3, fields[3]);										// CUST_TYPE
			insertISG.setString(4, fields[4]);										// TCC_ID
			// Made changes for ticket Number #135603593
			if("02".equalsIgnoreCase(fields[1])){
			insertISG.setDouble(5, Double.parseDouble(fields[6]) / 1000000);		// CUR_BILLING_AMT_DB
			insertISG.setDouble(6, 0);					//CUR_BILLING_AMT_CR
			insertISG.setLong(8, Long.parseLong(fields[5]) / 1000000);	  //ACCT_CT_DB
			insertISG.setLong(9, 0);	 								//ACCT_CT_CR
			}// CUR_BILLING_AMT_CR
			else if("05".equalsIgnoreCase(fields[1])){
			insertISG.setDouble(5, 0);		// CUR_BILLING_AMT_DB
			insertISG.setDouble(6, Double.parseDouble(fields[6]) / 1000000);		// CUR_BILLING_AMT_CR
			insertISG.setLong(9, Long.parseLong(fields[5]) / 1000000);		//ACCT_CT_CR
			insertISG.setLong(8, 0);										//ACCT_CT_DB
			}
			
			insertISG.setLong(7, billRnd);											// BILL_RND
			
			insertISG.addBatch();
		} catch (SQLException sqle) {
			severe(StaticErrorMsgKeys.INSERT_ERROR + "from method insertISGRecord(String[] fields)" + sqle.getMessage(), sqle);
			return ERROR;
		}
		
		return SUCCESS;
	}
	
	/**
	 * Performs an Insert to table RABC_BPI_BLG_SUMY, using the data from the most recently read line
	 * of the input file.
	 * 
	 * @param fields
	 *   an Array of the fields in the most recently read line of the input file.
	 * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob.
	 */
	private int insertBPIRecord(String[] fields) { 
		try {
			insertBPI.setDate(1, sqlRunDate);										// RUN_DATE
			insertBPI.setString(2, division);										// DIVISION
			insertBPI.setString(3, fields[3]);										// CUST_TYPE
			insertBPI.setString(4, fields[4]);										// CONVERGENT_CD
			insertBPI.setString(5, fields[5]);										// EBAT_CD
			insertBPI.setDouble(6, Double.parseDouble(fields[7]) / 1000000);		// CUR_BLG_AMT_DB
			insertBPI.setDouble(7, Double.parseDouble(fields[8]) / 1000000);		// CUR_BLG_AMT_CR
			insertBPI.setLong(8, Long.parseLong(fields[6]) / 1000000);				// CUST_CT
			insertBPI.setLong(9, billRnd);											// BILL_RND
			
			insertBPI.addBatch();
		} catch (SQLException sqle) {
			severe(StaticErrorMsgKeys.INSERT_ERROR + "from method insertBPIRecord(String[] fields)" + sqle.getMessage(), sqle);
			return ERROR;
		}
		
		return SUCCESS;
	}
	
	/**
	 * Processes the most recently read line of the input file, once it has been identified as record for insertion
	 * to the RABC_TOT_BLG_SUMY table.
	 *
	 * @param fields
	 *   an Array of the fields in the most recently read line of the input file.
	 * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob
	 */
	private int processTotBlgRecord(String[] fields) {
		
		try {
			if (totBlgRecordExists(fields)) {
				return updateTotBlgRecord(fields);
			} else {
				return insertTotBlgRecord(fields);
			}
		} catch (SQLException sqle) {
			severe(StaticErrorMsgKeys.INSERT_ERROR + "from method totBlgRecordExists(String[] fields)" + sqle.getMessage(), sqle);
			return ERROR;
		}
	}
	
	/**
	 * Rolls through ArrayList totBlgSumy, looking for a match to the values in the most recently read line of the
	 * input file. If no match is found, then the values are added to totBlgSumy.
	 * 
	 * @param fields
	 *   an Array of the fields in the most recently read line of the input file.
	 * @return true if a match was found in totBlgSumy, false otherwise.
	 * @throws SQLException
	 *   if an error is encountered during database processing.
	 */
	private boolean totBlgRecordExists(String[] fields) throws SQLException {
		String[] current = new String[2];
		
		if (fields[1].equals("19")) {
			current[0] = getBusType(fields[4], fields[3]);							// BUS_TYPE
		} else {
			current[0] = "FNL";														// BUS_TYPE
		}
		
		current[1] = Long.toString(billRnd);										// BILL_RND
		
		for (int i = 0; i < totBlgSumy.size(); i++) {
			String[] entry = (String[]) totBlgSumy.get(i);
			if (entry[0].equalsIgnoreCase(current[0])								// BUS_TYPE
					&& entry[1].equalsIgnoreCase(current[1])) {						// BILL_RND
				return true;
			}
		}
		
		totBlgSumy.add(current);
		return false;
	}
	
	/**
	 * Performs an Insert to table RABC_TOT_BLG_SUMY, using the data from the most recently read line
	 * of the input file.
	 * 
	 * @param fields
	 *   an Array of the fields in the most recently read line of the input file.
	 * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob.
	 */
	private int insertTotBlgRecord(String[] fields) {
		try {
			insertTotBlg.setDate(1, sqlRunDate);									// RUN_DATE
			insertTotBlg.setString(2, division);									// DIVISION
			if (fields[1].equals("19")) {
				insertTotBlg.setString(3, getBusType(fields[4], fields[3]));		// BUS_TYPE
			} else {
				insertTotBlg.setString(3, "FNL");									// BUS_TYPE			
			}
			insertTotBlg.setDouble(4, Double.parseDouble(fields[7]) / 1000000);		// RECUR_CHRG_AMT
			insertTotBlg.setDouble(5, Double.parseDouble(fields[10]) / 1000000);		// CUR_BLG_AMT_DB
			insertTotBlg.setDouble(6, Double.parseDouble(fields[11]) / 1000000);	// CUR_BLG_AMT_CR
			insertTotBlg.setDouble(7, Double.parseDouble(fields[8]) / 1000000);		// CUR_OCC_CR
			insertTotBlg.setDouble(8, Double.parseDouble(fields[9]) / 1000000);		// CUR_OCC_DB
			insertTotBlg.setDouble(9, Double.parseDouble(fields[12]) / 1000000);	// BAL_DUE_AMT
			insertTotBlg.setDouble(10, Double.parseDouble(fields[13]) / 1000000);	// LPC_AMT
			insertTotBlg.setDouble(11, Double.parseDouble(fields[14]) / 1000000);	// ADJ_AMT_DB
			insertTotBlg.setDouble(12, Double.parseDouble(fields[15]) / 1000000);	// ADJ_AMT_CR
			insertTotBlg.setDouble(13, Double.parseDouble(fields[27]) / 1000000);	// TAXES_DB_AMT
			insertTotBlg.setDouble(14, Double.parseDouble(fields[28]) / 1000000);	// TAXES_CR_AMT
			insertTotBlg.setDouble(15, Double.parseDouble(fields[25]) / 1000000);	// SRCG_AMT_DB
			insertTotBlg.setDouble(16, Double.parseDouble(fields[26]) / 1000000);	// SRCG_AMT_CR
			insertTotBlg.setDouble(17, Double.parseDouble(fields[19]) / 1000000);	// LOCAL_TOLL
			insertTotBlg.setDouble(18, Double.parseDouble(fields[20]) / 1000000);	// LOCAL_USG_AMT
			insertTotBlg.setDouble(19, Double.parseDouble(fields[17]) / 1000000);	// IEC_ADJ_AMT
			insertTotBlg.setDouble(20, Double.parseDouble(fields[16]) / 1000000);	// IEC_AMT
			insertTotBlg.setDouble(21, Double.parseDouble(fields[18]) / 1000000);	// PYMT_AMT
			insertTotBlg.setDouble(22, Double.parseDouble(fields[21]) / 1000000);	// FED_TAX_AMT
			insertTotBlg.setDouble(23, Double.parseDouble(fields[22]) / 1000000);	// ST_LOCAL_TAX_AMT
			insertTotBlg.setDouble(24, Double.parseDouble(fields[23]) / 1000000);	// FED_LD_FEE_AMT
			insertTotBlg.setDouble(25, Double.parseDouble(fields[24]) / 1000000);	// LIFE_LINE_SRCG_AMT
			insertTotBlg.setDouble(26, Double.parseDouble(fields[29]) /1000000);	// DA_TOLL_AMT
			insertTotBlg.setLong(28, Long.parseLong(fields[6]) /1000000);     // CUST_CT
		    		
			insertTotBlg.setLong(27, billRnd);										// BILL_RND
			
			//Added two columns for PMT #M169
			insertTotBlg.setDouble(29, Double.parseDouble(fields[30]) /1000000);	// FED_TAX_LOCL_AMT
			insertTotBlg.setDouble(30, Double.parseDouble(fields[31]) /1000000);     // ST_LOCAL_TAX_LOCL
			
		    
		    insertTotBlg.addBatch();
		} catch (SQLException sqle) {
			severe(StaticErrorMsgKeys.INSERT_ERROR + "from method insertTotBlgRecord(String[] fields)" + sqle.getMessage(), sqle);
			return ERROR;
		}
		
		return SUCCESS;
	}
	
	/**
	 * Performs an Update to table RABC_TOT_BLG_SUMY, using the data from the most recently read line
	 * of the input file. Sums RECUR_CHRG_AMT, CUR_BLG_AMT_DB, CUR_BLG_AMT_CR, CUR_OCC_CR, CUR_OCC_DB, 
	 * BAL_DUE_AMT, LPC_AMT, ADJ_AMT, TAXES_DB, TAXES_CR, SRCG_AMT_DB, SRCG_AMT_CR, LOCAL_TOLL, 
	 * LOCAL_USG_AMT, IEC_ADJ_AMT, IEC_AMT, PYMT_AMT, FED_TAX_AMT, ST_LOCAL_TAX_AMT, FED_LD_FEE_AMT, and
	 * LIFE_LINE_SRCG_AMT to the amounts in the existing record.
	 * 
	 * @param fields
	 *   an Array of the fields in the most recently read line of the input file.
	 * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob.
	 */
	private int updateTotBlgRecord(String[] fields) {
		try {
			updateTotBlg.setDouble(1, Double.parseDouble(fields[7]) / 1000000);		// RECUR_CHRG_AMT
			updateTotBlg.setDouble(2, Double.parseDouble(fields[10]) / 1000000);		// CUR_BLG_AMT_DB
			updateTotBlg.setDouble(3, Double.parseDouble(fields[11]) / 1000000);	// CUR_BLG_AMT_CR
			updateTotBlg.setDouble(4, Double.parseDouble(fields[8]) / 1000000);		// CUR_OCC_CR
			updateTotBlg.setDouble(5, Double.parseDouble(fields[9]) / 1000000);		// CUR_OCC_DB
			updateTotBlg.setDouble(6, Double.parseDouble(fields[12]) / 1000000);	// BAL_DUE_AMT
			updateTotBlg.setDouble(7, Double.parseDouble(fields[13]) / 1000000);	// LPC_AMT
			updateTotBlg.setDouble(8, Double.parseDouble(fields[14]) / 1000000);	// ADJ_AMT_DB
			updateTotBlg.setDouble(9, Double.parseDouble(fields[15]) / 1000000);	// ADJ_AMT_CR
			updateTotBlg.setDouble(10, Double.parseDouble(fields[27]) / 1000000);	// TAXES_DB_AMT
			updateTotBlg.setDouble(11, Double.parseDouble(fields[28]) / 1000000);	// TAXES_CR_AMT
			updateTotBlg.setDouble(12, Double.parseDouble(fields[25]) / 1000000);	// SRCG_AMT_DB
			updateTotBlg.setDouble(13, Double.parseDouble(fields[26]) / 1000000);	// SRCG_AMT_CR
			updateTotBlg.setDouble(14, Double.parseDouble(fields[19]) / 1000000);	// LOCAL_TOLL
			updateTotBlg.setDouble(15, Double.parseDouble(fields[20]) / 1000000);	// LOCAL_USG_AMT
			updateTotBlg.setDouble(16, Double.parseDouble(fields[17]) / 1000000);	// IEC_ADJ_AMT
			updateTotBlg.setDouble(17, Double.parseDouble(fields[16]) / 1000000);	// IEC_AMT
			updateTotBlg.setDouble(18, Double.parseDouble(fields[18]) / 1000000);	// PYMT_AMT
			updateTotBlg.setDouble(19, Double.parseDouble(fields[21]) / 1000000);	// FED_TAX_AMT 
			updateTotBlg.setDouble(20, Double.parseDouble(fields[22]) / 1000000);	// ST_LOCAL_TAX_AMT
			updateTotBlg.setDouble(21, Double.parseDouble(fields[23]) / 1000000);	// FED_LD_FEE_AMT
			updateTotBlg.setDouble(22, Double.parseDouble(fields[24]) / 1000000);	// LIFE_LINE_SRCG_AMT
			//Added two columns for PMT #M169
			updateTotBlg.setDouble(25, Double.parseDouble(fields[30]) / 1000000);	// FED_TAX_LOCL_AMT
			updateTotBlg.setDouble(26, Double.parseDouble(fields[31]) / 1000000);	// ST_LOCAL_TAX_LOCL
			
			updateTotBlg.setDate(27, sqlRunDate);									// RUN_DATE
			updateTotBlg.setString(28, division);									// DIVISION
			updateTotBlg.setDouble(23, Double.parseDouble(fields[29]) / 1000000);	// DA_TOLL_AMT
			updateTotBlg.setLong(24, Long.parseLong(fields[6]) / 1000000);	// CUST_CT
			
			
			if (fields[1].equals("19")) {
				updateTotBlg.setString(29, getBusType(fields[4], fields[3]));		// BUS_TYPE
			} else {
				updateTotBlg.setString(29, "FNL");									// BUS_TYPE			
			}
			updateTotBlg.setLong(30, billRnd);										// BILL_RND
			
			
			
			updateTotBlg.addBatch();
		} catch (SQLException sqle) {
			severe(StaticErrorMsgKeys.INSERT_ERROR + "from method updateTotBlgRecord(String[] fields)" + sqle.getMessage(), sqle);
			return ERROR;
		}
		return SUCCESS;
	}
	/**
	 * Performs an Insert to table RABC_TOP_OCC_BLG_ACCT, using the data from the most recently read line
	 * of the input file.
	 * 
	 * @param fields
	 *   an Array of the fields in the most recently read line of the input file.
	 * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob.
	 */
	private int insertTopOCCRecord(String[] fields) {
		try {
			insertTopOCC.setDate(1, sqlRunDate);									// RUN_DATE
			insertTopOCC.setString(2, division);									// DIVISION
			insertTopOCC.setString(3, fields[3]);									// BTN
			insertTopOCC.setString(4, fields[7]);									// CUST_TYPE_CD
			insertTopOCC.setString(5, fields[6]);									// ACCT_FINAL_IND
			insertTopOCC.setDouble(6, Double.parseDouble(fields[9]) / 1000000);		// OCC_BLG_AMT
			insertTopOCC.setDouble(7, Double.parseDouble(fields[10]) / 1000000);	// PREV_BLG_AMT
			insertTopOCC.setDouble(8, Double.parseDouble(fields[11]) / 1000000);	// CURR_BLG_AMT
			insertTopOCC.setLong(9, billRnd);										// BILL_RND
			
			insertTopOCC.addBatch();
		} catch (SQLException sqle) {
			severe(StaticErrorMsgKeys.INSERT_ERROR + "from method insertTopOCCRecord(String[] fields)" + sqle.getMessage(), sqle);
			return ERROR;
		}
		
		return SUCCESS;
	}
	
	/**
	 * Performs an Insert to table RABC_TOP_ADJ_BLG_ACCT, using the data from the most recently read line
	 * of the input file.
	 * 
	 * @param fields
	 *   an Array of the fields in the most recently read line of the input file.
	 * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob.
	 */
	private int insertTopAdjRecord(String[] fields) {
		try {
			insertTopAdj.setDate(1, sqlRunDate);									// RUN_DATE
			insertTopAdj.setString(2, division);									// DIVISION
			insertTopAdj.setString(3, fields[3]);									// BTN
			insertTopAdj.setString(4, fields[7]);									// CUST_TYPE_CD
			insertTopAdj.setString(5, fields[6]);									// ACCT_FINAL_IND
			insertTopAdj.setDouble(6, Double.parseDouble(fields[9]) / 1000000);		// ADJ_BLG_AMT
			insertTopAdj.setDouble(7, Double.parseDouble(fields[10]) / 1000000);	// PREV_BLG_AMT
			insertTopAdj.setDouble(8, Double.parseDouble(fields[11]) / 1000000);	// CURR_BLG_AMT
			insertTopAdj.setLong(9, billRnd);										// BILL_RND
			
			insertTopAdj.addBatch();
		} catch (SQLException sqle) {
			severe(StaticErrorMsgKeys.INSERT_ERROR + "from method insertTopAdjRecord(String[] fields)" + sqle.getMessage(), sqle);
			return ERROR;
		}
		
		return SUCCESS;
	}
	
	/**
	 * Performs an Insert to table RABC_TOP_RECUR_CHRG_ACCT , using the data from the most recently read line
	 * of the input file.
	 * 
	 * @param fields
	 *   an Array of the fields in the most recently read line of the input file.
	 * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob.
	 */
	private int insertTopRecurRecord(String[] fields) {
		try {
			insertTopRecur.setDate(1, sqlRunDate);									// RUN_DATE
			insertTopRecur.setString(2, division);									// DIVISION
			insertTopRecur.setString(3, fields[3]);									// BTN
			insertTopRecur.setString(4, fields[7]);									// CUST_TYPE_CD
			insertTopRecur.setString(5, fields[6]);									// ACCT_FINAL_IND
			insertTopRecur.setDouble(6, Double.parseDouble(fields[9]) / 1000000);	// RECUR_CHRG_AMT
			insertTopRecur.setDouble(7, Double.parseDouble(fields[10]) / 1000000);	// PREV_BLG_AMT
			insertTopRecur.setDouble(8, Double.parseDouble(fields[11]) / 1000000);	// CURR_BLG_AMT
			insertTopRecur.setLong(9, billRnd);										// BILL_RND
			
			insertTopRecur.addBatch();
		} catch (SQLException sqle) {
			severe(StaticErrorMsgKeys.INSERT_ERROR + "from method insertTopRecurRecord(String[] fields)" + sqle.getMessage(), sqle);
			return ERROR;
		}
		
		return SUCCESS;
	}
	

	/**
	 * Performs an Insert to table RABC_NON_PYMT_BLG_ACCT, using the data from the most recently read line
	 * of the input file.
	 * 
	 * @param fields
	 *   an Array of the fields in the most recently read line of the input file.
	 * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob.
	 */
	private int insertNonPymtRecord(String[] fields) {
		try {
			insertNonPymt.setDate(1, sqlRunDate);									// RUN_DATE
			insertNonPymt.setString(2, division);									// DIVISION
			insertNonPymt.setString(3, fields[3]);									// BTN
			insertNonPymt.setString(4, fields[7]);									// CUST_TYPE_CD
			insertNonPymt.setString(5, fields[6]);									// ACCT_FINAL_IND
			insertNonPymt.setDate(6, new Date(yyyyMMdd.parse(fields[9]).getTime()));	// LAST_PYMT_DATE
			insertNonPymt.setDouble(7, Double.parseDouble(fields[10]) / 1000000);	// LAST_PYMT_AMT
			insertNonPymt.setDouble(8, Double.parseDouble(fields[11]) / 1000000);	// CURR_BLG_AMT
			insertNonPymt.setDouble(9, Double.parseDouble(fields[12]) / 1000000);	// TOT_BLG_AMT
			insertNonPymt.setLong(10, billRnd);										// BILL_RND
			
			insertNonPymt.addBatch();
		} catch (SQLException sqle) {
			severe(StaticErrorMsgKeys.INSERT_ERROR + "from method insertNonPymtRecord(String[] fields)" + sqle.getMessage(), sqle);
			return ERROR;
		} catch (ParseException e) {
			severe(StaticErrorMsgKeys.PARSELINE_ERROR + "Error occurred while parsing Date in method insertNonPymtRecord(String[] fields) on file: " + e, e);
			return ERROR;
		}
		
		return SUCCESS;
	}
	
	/**
	 * Method to add days to this date. Will be used as an adjust() function to return date corresponding to 
	 * +/- no of days from this date.
	 * 
	 * @param target
	 * @param days
	 * @return DATE
	 */
	private java.util.Date doAdd(java.util.Date target, int days) {
        Calendar now = Calendar.getInstance();
        Calendar working = null;;
        working = (Calendar) now.clone();
        working.setTime(target);             
        working.add(Calendar.DAY_OF_YEAR, days);
        target.setTime(working.getTimeInMillis());
        return target;
	}

	/**
	 * The method to check the date for the passed pymtBaselineDays and lastPymt
	 * @param lastPymtDate
	 * @param pymtBaselineDays
	 * @return
	 * @throws ParseException
	 */
	public boolean isAfterBaselineDate(String lastPymtDate,int pymtBaselineDays) throws ParseException{
        boolean result = false;

        java.util.Date pymtBaselineDate = doAdd(yyyyMMdd.parse(runDate),-pymtBaselineDays);
        java.util.Date date = yyyyMMdd.parse(lastPymtDate);
                
        if (date.compareTo(pymtBaselineDate)>=0) {
        	result = true;
         } else {
         	result = false;
        }
        
        return result;
	}

	
	/**
	 * Performs a Delete to table RABC_NON_PYMT_BLG_ACCT, deleting all rows based on division and the BILL_RND of the
	 * overall file.
	 * 
	 * @throws SQLException
	 *   if an SQLException is encountered while perform the batch executes, then the exception is passed back
	 *   to the calling function for handling.
	 */
	private void deleteNonPymtRecords() throws SQLException {
		deleteNonPymt.setString(1, division);									// DIVISION
		deleteNonPymt.setLong(2, billRnd);										// BILL_RND
		
		deleteNonPymt.executeUpdate();
	}
	
	/**
	 * Performs an Insert to table RABC_TOP_BPI_ACCT, using the data from the most recently read line
	 * of the input file.
	 * 
	 * @param fields
	 *   an Array of the fields in the most recently read line of the input file.
	 * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob.
	 */
	private int insertTopBPIRecord(String[] fields) {
		try {
			insertTopBPI.setDate(1, sqlRunDate);									// RUN_DATE
			insertTopBPI.setString(2, division);									// DIVISION
			insertTopBPI.setString(3, fields[3]);									// BTN
			insertTopBPI.setString(4, fields[7]);									// CUST_TYPE_CD
			insertTopBPI.setString(5, fields[6]);									// ACCT_FINL_IND
			insertTopBPI.setDouble(6, Double.parseDouble(fields[9]) / 1000000);		// CURR_BLG_AMT
			insertTopBPI.setLong(7, billRnd);										// BILL_RND
			
			insertTopBPI.addBatch();
		} catch (SQLException sqle) {
			severe(StaticErrorMsgKeys.INSERT_ERROR + "from method insertTopBPIRecord(String[] fields)" + sqle.getMessage(), sqle);
			return ERROR;
		}
		
		return SUCCESS;
	}
	
	/**
	 * Performs an Insert to table RABC_ACCT_BLG_DTL, using the data from the most recently read line
	 * of the input file.
	 * 
	 * @param fields
	 *   an Array of the fields in the most recently read line of the input file.
	 * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob.
	 */
	private int insertAcctDtlRecord(String[] fields) {
		try {
			insertAcctDtl.setDate(1, sqlRunDate);									//RUN_DATE
			insertAcctDtl.setString(2, division);									//DIVISION
			insertAcctDtl.setString(3, fields[3]);									//BTN
			insertAcctDtl.setString(4, fields[9]);									//CLS_CD
			insertAcctDtl.setString(5, fields[7].substring(0, 1));									//CUST_TYPE
			insertAcctDtl.setString(6, fields[6]);									//ACCT_STATUS
			insertAcctDtl.setString(7, fields[8]);									//BLG_CRO_CD
			insertAcctDtl.setDouble(8, Double.parseDouble(fields[23]) / 1000000);	//PREV_BLG_AMT
			insertAcctDtl.setDouble(9, Double.parseDouble(fields[11]) / 1000000);	//RECUR_CHRG_AMT
			insertAcctDtl.setDouble(10, Double.parseDouble(fields[16]) / 1000000);	//CURR_BLG_AMT_DB
			insertAcctDtl.setDouble(11, Double.parseDouble(fields[17]) / 1000000);	//CURR_BLG_AMT_CR
			insertAcctDtl.setDouble(12, Double.parseDouble(fields[15]) / 1000000);	//CURR_OCC_CR
			insertAcctDtl.setDouble(13, Double.parseDouble(fields[14]) / 1000000);	//CURR_OCC_DB
			insertAcctDtl.setDouble(14, Double.parseDouble(fields[18]) / 1000000);	//BAL_DUE_AMT
			insertAcctDtl.setDouble(15, Double.parseDouble(fields[10]) / 1000000);	//LPC_AMT
			insertAcctDtl.setDouble(16, Double.parseDouble(fields[12]) / 1000000);	//ADJ_AMT_DB
			insertAcctDtl.setDouble(17, Double.parseDouble(fields[13]) / 1000000);	//ADJ_AMT_CR
			insertAcctDtl.setDouble(18, Double.parseDouble(fields[31]) / 1000000);	//TAXES_DB
			insertAcctDtl.setDouble(19, Double.parseDouble(fields[32]) / 1000000);	//TAXES_CR
			insertAcctDtl.setDouble(20, Double.parseDouble(fields[29]) / 1000000);	//SRCG_AMT_DB
			insertAcctDtl.setDouble(21, Double.parseDouble(fields[30]) / 1000000);	//SRCG_AMT_CR
			insertAcctDtl.setDouble(22, Double.parseDouble(fields[19]) / 1000000);	//LOCAL_TOLL_AMT
			insertAcctDtl.setDouble(23, Double.parseDouble(fields[20]) / 1000000);	//LOCAL_USG_AMT
			insertAcctDtl.setDouble(24, Double.parseDouble(fields[21]) / 1000000);	//IEC_ADJ_AMT
			insertAcctDtl.setDouble(25, Double.parseDouble(fields[22]) / 1000000);	//IEC_AMT
			insertAcctDtl.setDouble(26, Double.parseDouble(fields[24]) / 1000000);	//PYMT_AMT
			insertAcctDtl.setDouble(27, Double.parseDouble(fields[25]) / 1000000);	//FED_TAX_AMT
			insertAcctDtl.setDouble(28, Double.parseDouble(fields[26]) / 1000000);	//ST_LOCAL_TAX_AMT
			insertAcctDtl.setDouble(29, Double.parseDouble(fields[27]) / 1000000);	//FED_LD_FEE_AMT
			insertAcctDtl.setDouble(30, Double.parseDouble(fields[28]) / 1000000);	//LIFE_LINE_SRCG_AMT
			insertAcctDtl.setLong(31, billRnd);										//BILL_RND
			insertAcctDtl.setDouble(32, Double.parseDouble(fields[33]) / 1000000);	//DA_TOLL_AMT
			
			
			insertAcctDtl.addBatch();
		} catch (SQLException sqle) {
			severe(StaticErrorMsgKeys.INSERT_ERROR + "from method insertAcctDtlRecord(String[] fields)" + sqle.getMessage(), sqle);
			return ERROR;
		}
		
		return SUCCESS;
	}
	
	/**
	 * Performs an Insert to table RABC_TOP_PYMT_ACCT, using the data from the most recently read line
	 * of the input file.
	 * 
	 * @param fields
	 *   an Array of the fields in the most recently read line of the input file.
	 * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob.
	 */
	private int insertTopPymtRecord(String[] fields) {
		try {
			insertTopPymt.setDate(1, sqlRunDate);									// RUN_DATE
			insertTopPymt.setString(2, division);									// DIVISION
			insertTopPymt.setString(3, fields[3]);									// BTN
			insertTopPymt.setString(4, fields[7]);									// CUST_TYPE_CD
			insertTopPymt.setString(5, fields[6]);									// ACCT_FINAL_IND
			insertTopPymt.setDouble(6, Double.parseDouble(fields[10]) / 1000000);	// PYMT_AMT
			insertTopPymt.setDouble(7, Double.parseDouble(fields[11]) / 1000000);	// PREV_BLG_AMT
			insertTopPymt.setDouble(8, Double.parseDouble(fields[12]) / 1000000);	// CURR_BLG_AMT
			insertTopPymt.setLong(9, billRnd);										// BILL_RND
			
			insertTopPymt.addBatch();
		} catch (SQLException sqle) {
			severe(StaticErrorMsgKeys.INSERT_ERROR + "from method insertTopPymtRecord(String[] fields)" + sqle.getMessage(), sqle);
			return ERROR;
		}
		
		return SUCCESS;
	}
	
	/**
	 * Performs an Insert to table RABC_TOP_TEN_BLG_ACCT, using the data from the most recently read line
	 * of the input file, increasing RANK by one for each row inserted.
	 * 
	 * @param fields
	 *   an Array of the fields in the most recently read line of the input file.
	 * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob.
	 */
	private int insertTopTenRecord(String[] fields) {
		try {
			rank = rank + 1;
			insertTopTen.setDate(1, sqlRunDate);									//RUN_DATE
			insertTopTen.setString(2, division);									//DIVISION
			insertTopTen.setLong(3, billRnd);										//BILL_RND
			insertTopTen.setLong(4, rank);											//RANK
			insertTopTen.setString(5, fields[3]);									//BTN
			insertTopTen.setDouble(6, Double.parseDouble(fields[18]) / 1000000);	//BAL_DUE_AMT

			// CURR_BLG_AMT_DB + CURR_BLG_AMT_CR = CUR_BLG_AMT; 
			double d = Double.parseDouble(fields[16]) + Double.parseDouble(fields[17]);
			insertTopTen.setDouble(7, d / 1000000);									//CURR_BLG_AMT
			
			insertTopTen.addBatch();
		} catch (SQLException sqle) {
			severe(StaticErrorMsgKeys.INSERT_ERROR + "from method insertTopTenRecord(String[] fields)" + sqle.getMessage(), sqle);
			return ERROR;
		}
		
		return SUCCESS;
	}
	
	/**
	 * Performs an Insert to table RABC_TOP_LPC_ACCT, using the data from the most recently read line
	 * of the input file.
	 * 
	 * @param fields
	 *   an Array of the fields in the most recently read line of the input file.
	 * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob.
	 */
	private int insertTopLPCRecord(String[] fields) {
		try {
			insertTopLPC.setDate(1, sqlRunDate);									// RUN_DATE
			insertTopLPC.setString(2, division);									// DIVISION
			insertTopLPC.setString(3, fields[3]);									// BTN
			insertTopLPC.setString(4, fields[7]);									// CUST_TYPE_CD
			insertTopLPC.setString(5, fields[6]);									// ACCT_FINAL_IND
			insertTopLPC.setDouble(6, Double.parseDouble(fields[10]) / 1000000);	// LPC_AMT
			insertTopLPC.setDouble(7, Double.parseDouble(fields[11]) / 1000000);	// PREV_BLG_AMT
			insertTopLPC.setLong(8, billRnd);										// BILL_RND
			
			insertTopLPC.addBatch();
		} catch (SQLException sqle) {
			severe(StaticErrorMsgKeys.INSERT_ERROR + "from method insertTopLPCRecord(String[] fields)" + sqle.getMessage(), sqle);
			return ERROR;
		}
		
		return SUCCESS;
	}
	
	/**
	 * Performs an Insert to table RABC_TOP_ISG_BLG_ACCT, using the data from the most recently read line
	 * of the input file.
	 * 
	 * @param fields
	 *   an Array of the fields in the most recently read line of the input file.
	 * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob.
	 */
	private int insertTopISGBlgRecord(String[] fields) {
		try {
			insertTopISGBlg.setDate(1, sqlRunDate);									// RUN_DATE
			insertTopISGBlg.setString(2, division);									// DIVISION
			insertTopISGBlg.setString(3, fields[2]);								// TCC_ID
			insertTopISGBlg.setString(4, fields[3]);								// BTN
			insertTopISGBlg.setString(5, fields[7]);								// CUST_TYPE_CD
			insertTopISGBlg.setString(6, fields[6]);								// ACCT_FINAL_IND
			insertTopISGBlg.setDouble(7, Double.parseDouble(fields[9]) / 1000000);	// CURR_ISG_BLG_AMT
			insertTopISGBlg.setDouble(8, Double.parseDouble(fields[11]) / 1000000);	// CURR_ISG_ADJ_AMT
			insertTopISGBlg.setLong(9, billRnd);									// BILL_RND
			
			insertTopISGBlg.addBatch();
		} catch (SQLException sqle) {
			severe(StaticErrorMsgKeys.INSERT_ERROR + "from method insertTopISGBlgRecord(String[] fields)" + sqle.getMessage(), sqle);
			return ERROR;
		}
		
		return SUCCESS;
	}
	
	/**
	 * Performs an Insert to table RABC_TOP_ISG_ADJ_ACCT, using the data from the most recently read line
	 * of the input file.
	 * 
	 * @param fields
	 *   an Array of the fields in the most recently read line of the input file.
	 * @return an integer value denoting success or failure, defined in com.sbc.bac.load.FileDBLoadJob.
	 */
	private int insertTopISGAdjRecord(String[] fields) {
		try {
			insertTopISGAdj.setDate(1, sqlRunDate);									// RUN_DATE
			insertTopISGAdj.setString(2, division);									// DIVISION
			insertTopISGAdj.setString(3, fields[2]);								// TCC_ID
			insertTopISGAdj.setString(4, fields[3]);								// BTN
			insertTopISGAdj.setString(5, fields[7]);								// CUST_TYPE_CD
			insertTopISGAdj.setString(6, fields[6]);								// ACCT_FINAL_IND
			insertTopISGAdj.setDouble(7, Double.parseDouble(fields[9]) / 1000000);	// CURR_ISG_BLG_AMT
			insertTopISGAdj.setDouble(8, Double.parseDouble(fields[11]) / 1000000);	// CURR_ISG_ADJ_AMT
			insertTopISGAdj.setLong(9, billRnd);									// BILL_RND
			
			insertTopISGAdj.addBatch();
		} catch (SQLException sqle) {
			severe(StaticErrorMsgKeys.INSERT_ERROR + "from method insertTopISGAdjRecord(String[] fields)" + sqle.getMessage(), sqle);
			return ERROR;
		}
		
		return SUCCESS;
	}
	
    /**
     * Performs a select against table RABC_ACCT_BLG_DTL to retrieve averages by BTN for data inserted prior to
     * this run. Then performs an insert into table RABC_ACCT_BLG_DTL_AVG, containing the retrieved averages.
     * 
     * @throws SQLException
	 *   if an SQLException is encountered while performing the database calls necessary to update the Account
	 *   Averages, then the exception is passed back, unaltered, to the calling function for handling.
     */
	private void insertAcctDtlAvgRecords() throws SQLException {
		selectAverageAcctDtl.setString(1, division);	//DIVISION	
		selectAverageAcctDtl.setDate(2, sqlRunDate);	//RUN_DATE
		selectAverageAcctDtl.setString(3, division);	//DIVISION	
		
		rs = selectAverageAcctDtl.executeQuery();
		
		while (rs.next()) {
			insertAcctDtlAvg.setDate(1, sqlRunDate);								//RUN_DATE
			insertAcctDtlAvg.setString(2, rs.getString(1));							//DIVISION
			insertAcctDtlAvg.setString(3, rs.getString(2));							//BTN
			insertAcctDtlAvg.setDouble(4, rs.getDouble(3));							//PREV_BLG_AMT_AVG
			insertAcctDtlAvg.setDouble(5, rs.getDouble(4));							//RECUR_CHRG_AMT_AVG
			insertAcctDtlAvg.setDouble(6, rs.getDouble(5));							//CURR_BLG_AMT_DB_AVG
			insertAcctDtlAvg.setDouble(7, rs.getDouble(6));							//CURR_BLG_AMT_CR_AVG
			insertAcctDtlAvg.setDouble(8, rs.getDouble(7));							//CURR_OCC_CR_AVG
			insertAcctDtlAvg.setDouble(9, rs.getDouble(8));							//CURR_OCC_DB_AVG
			insertAcctDtlAvg.setDouble(10, rs.getDouble(9));						//BAL_DUE_AMT_AVG
			insertAcctDtlAvg.setDouble(11, rs.getDouble(10));						//LPC_AMT_AVG
			insertAcctDtlAvg.setDouble(12, rs.getDouble(11));						//ADJ_AMT_DB_AVG
			insertAcctDtlAvg.setDouble(13, rs.getDouble(12));						//ADJ_AMT_CR_AVG
			insertAcctDtlAvg.setDouble(14, rs.getDouble(13));						//TAXES_DB_AVG
			insertAcctDtlAvg.setDouble(15, rs.getDouble(14));						//TAXES_CR_AVG
			insertAcctDtlAvg.setDouble(16, rs.getDouble(15));						//SRCG_AMT_DB_AVG
			insertAcctDtlAvg.setDouble(17, rs.getDouble(16));						//SRCG_AMT_CR_AVG
			insertAcctDtlAvg.setDouble(18, rs.getDouble(17));						//LOCAL_TOLL_AMT_AVG
			insertAcctDtlAvg.setDouble(19, rs.getDouble(18));						//LOCAL_USG_AMT_AVG
			insertAcctDtlAvg.setDouble(20, rs.getDouble(19));						//IEC_ADJ_AMT_AVG
			insertAcctDtlAvg.setDouble(21, rs.getDouble(20));						//IEC_AMT_AVG
			insertAcctDtlAvg.setDouble(22, rs.getDouble(21));						//PYMT_AMT_AVG
			insertAcctDtlAvg.setDouble(23, rs.getDouble(22));						//FED_TAX_AMT_AVG
			insertAcctDtlAvg.setDouble(24, rs.getDouble(23));						//ST_LOCAL_TAX_AMT_AVG
			insertAcctDtlAvg.setDouble(25, rs.getDouble(24));						//FED_LD_FEE_AMT_AVG
			insertAcctDtlAvg.setDouble(26, rs.getDouble(25));						//LIFE_LINE_SRCG_AMT_AVG
			insertAcctDtlAvg.setDouble(27, rs.getDouble(26));						//DA_TOLL_AMT_AVG
			
			
			insertAcctDtlAvg.executeUpdate();
		}
	}
	
    /**
     * Performs selects of the TopTen BTNs against table RABC_ACCT_BLG_DTL, using row information stored in
     * ArrayList acctDtl. If the BTN was not already inserted with this run, then the row is inserted
     * to RABC_ACCT_BLG_DTL.
     * 
     * @throws SQLException
	 *   if an SQLException is encountered while performing the database calls necessary to check for duplicates
	 *   and perform necessary inserts, then the exception is passed back, unaltered, to the calling function
	 *   for handling.
     */
	private void insertAcctDtlFromTopTen() throws SQLException{
		for (int i = 0; i < acctDtl.size(); i++) {
			String[] fields = (String[]) acctDtl.get(i);
			
			selectAcctDtl.setDate(1, sqlRunDate);										// RUN_DATE
			selectAcctDtl.setString(2, division);										// DIVISION
			selectAcctDtl.setString(3, fields[3]);										// BTN
			
			rs = selectAcctDtl.executeQuery();
			
			if (!rs.next()) {
				insertAcctDtl.setDate(1, sqlRunDate);									//RUN_DATE
				insertAcctDtl.setString(2, division);									//DIVISION
				insertAcctDtl.setString(3, fields[3]);									//BTN
				insertAcctDtl.setString(4, fields[9]);									//CLS_CD
				insertAcctDtl.setString(5, fields[7]);									//CUST_TYPE
				insertAcctDtl.setString(6, fields[6]);									//ACCT_STATUS
				insertAcctDtl.setString(7, fields[8]);									//BLG_CRO_CD
				insertAcctDtl.setDouble(8, Double.parseDouble(fields[23]) / 1000000);	//PREV_BLG_AMT
				insertAcctDtl.setDouble(9, Double.parseDouble(fields[11]) / 1000000);	//RECUR_CHRG_AMT
				insertAcctDtl.setDouble(10, Double.parseDouble(fields[16]) / 1000000);	//CURR_BLG_AMT_DB
				insertAcctDtl.setDouble(11, Double.parseDouble(fields[17]) / 1000000);	//CURR_BLG_AMT_CR
				insertAcctDtl.setDouble(12, Double.parseDouble(fields[15]) / 1000000);	//CURR_OCC_CR
				insertAcctDtl.setDouble(13, Double.parseDouble(fields[14]) / 1000000);	//CURR_OCC_DB
				insertAcctDtl.setDouble(14, Double.parseDouble(fields[18]) / 1000000);	//BAL_DUE_AMT
				insertAcctDtl.setDouble(15, Double.parseDouble(fields[10]) / 1000000);	//LPC_AMT
				insertAcctDtl.setDouble(16, Double.parseDouble(fields[12]) / 1000000);	//ADJ_AMT_DB
				insertAcctDtl.setDouble(17, Double.parseDouble(fields[13]) / 1000000);	//ADJ_AMT_CR
				insertAcctDtl.setDouble(18, Double.parseDouble(fields[31]) / 1000000);	//TAXES_DB
				insertAcctDtl.setDouble(19, Double.parseDouble(fields[32]) / 1000000);	//TAXES_CR
				insertAcctDtl.setDouble(20, Double.parseDouble(fields[29]) / 1000000);	//SRCG_AMT_DB
				insertAcctDtl.setDouble(21, Double.parseDouble(fields[30]) / 1000000);	//SRCG_AMT_CR
				insertAcctDtl.setDouble(22, Double.parseDouble(fields[19]) / 1000000);	//LOCAL_TOLL_AMT
				insertAcctDtl.setDouble(23, Double.parseDouble(fields[20]) / 1000000);	//LOCAL_USG_AMT
				insertAcctDtl.setDouble(24, Double.parseDouble(fields[21]) / 1000000);	//IEC_ADJ_AMT
				insertAcctDtl.setDouble(25, Double.parseDouble(fields[22]) / 1000000);	//IEC_AMT
				insertAcctDtl.setDouble(26, Double.parseDouble(fields[24]) / 1000000);	//PYMT_AMT
				insertAcctDtl.setDouble(27, Double.parseDouble(fields[25]) / 1000000);	//FED_TAX_AMT
				insertAcctDtl.setDouble(28, Double.parseDouble(fields[26]) / 1000000);	//ST_LOCAL_TAX_AMT
				insertAcctDtl.setDouble(29, Double.parseDouble(fields[27]) / 1000000);	//FED_LD_FEE_AMT
				insertAcctDtl.setDouble(30, Double.parseDouble(fields[28]) / 1000000);	//LIFE_LINE_SRCG_AMT
				insertAcctDtl.setLong(31, billRnd);										//BILL_RND
				insertAcctDtl.setDouble(32, Double.parseDouble(fields[33]) / 1000000);	//DA_TOLL_AMT
				
				insertAcctDtl.executeUpdate();
			}
		}
	}
	
	/**
	 * Performs the appropriate database query to retrieve the BillRnd value associated with the provided Date.
	 * 
	 * @param billRndDate
	 *   an String containing a Date in format 'yyyyMMdd', for which we want to retrieve the BillRnd.
	 * @return a long containing the retrieved BillRnd value.
	 * @throws SQLException
	 *   if a database error is encountered while retrieving the BillRnd.
	 */
	private long getBillRnd(String billRndDate) throws SQLException {
		String query = "SELECT to_char(BILL_RND,'00') FROM RABC_CYCLE_CALENDAR WHERE PROC_DT = to_date('" + billRndDate + "','yyyyMMdd')";
		String billRnd = RetrieveStaticInfo.getBillRnd(connection, query);
		if ("00".equals(billRnd) || "".equals(billRnd)){
			billRnd = "0";
		}
		return Long.parseLong(billRnd);
	}
	
	/**
	 * Determines and returns the appropriate BusType value based upon the Class Code and Wholesale/Retail values.
	 * 
	 * @param clsCode
	 *   Class Code from the currently processing line.
	 * @param wholesaleRetail
	 *   Wholesale/Retail indicator from the currently processing line.
	 * @return a String containing the determined BusType.
	 */
	private String getBusType(String clsCode, String wholesaleRetail) {
		if (clsCode.equals("0")) {
			if (wholesaleRetail.equalsIgnoreCase("W")) {
				return "RRES";
			} else {
				return "RES";
			}
		} else {
			if (wholesaleRetail.equalsIgnoreCase("W")) {
				return "RBUS";
			} else {
				return "BUS";
			}
		}
	}
	
	/** This is the method to check whether BillRoundDate,CustType,
	  * ConvCode and EBAT code is null or blank.
    * 
    * @param fields
    * @return boolean
    */
   private boolean checkBPIRecord(String[] fields){
   		// Skip if Bill Round Date is blank
   		if (fields[2]==null || "".equals(fields[2].trim())){
       		return false;
   		}
       
   		// Skip if EBAT Indicator is blank
	   	if (fields[5]==null || "".equals(fields[5].trim())){
	   		return false;
	   	}
   	
   		return true;
   }
   

	/**
	 * Performs the .executeBatch() operation on all of the appropriate PreparedStatement objects.
	 * 
	 * @throws SQLException
	 *   if an SQLException is encountered while perform the batch executes, then the exception is passed back
	 *   to the calling function for handling.
	 */
	private void performBatchExecute() throws SQLException {
		insertAcctZero.executeBatch();												// RABC_ACCT_ZERO_BLG_SUMY
		insertISG.executeBatch();													// RABC_ISG_BLG_SUMY
		insertBPI.executeBatch();													// RABC_BPI_BLG_SUMY
		
	// Table RABC_TOT_BLG_SUMY will be receiving both Inserts and Updates. Batch Inserts MUST occur first!
		insertTotBlg.executeBatch();
		updateTotBlg.executeBatch();
		
		insertTopOCC.executeBatch();												// RABC_TOP_OCC_BLG_ACCT
		insertTopAdj.executeBatch();												// RABC_TOP_ADJ_BLG_ACCT
		insertTopRecur.executeBatch();												// RABC_TOP_CURR_BLG_ACCT
		insertNonPymt.executeBatch();												// RABC_NON_PYMT_BLG_ACCT
		insertTopBPI.executeBatch();												// RABC_TOP_BPI_ACCT
		insertAcctDtl.executeBatch();												// RABC_ACCT_BLG_DTL
		insertTopPymt.executeBatch();												// RABC_TOP_PYMT_ACCT
		insertTopTen.executeBatch();												// RABC_TOP_TEN_BLG_ACCT
		insertTopLPC.executeBatch();												// RABC_TOP_LPC_ACCT
		insertTopISGBlg.executeBatch();												// RABC_TOP_ISG_BLG_ACCT
		insertTopISGAdj.executeBatch();												// RABC_TOP_ISG_ADJ_ACCT
		insertTopTenTX.executeBatch();												//RABC_TOP_TEN_TX_COST_RCVRY
		insertTxCostRecovrSumm.executeBatch();
		//insertCostRecvSummTX.executeBatch();										//RABC_TX_COST_RCVRY_SUMY
	}
	
	/**
	 * Processes once the file has been completely processed. Performs final batch execution of database calls. 
	 * Inserts Triggers for each data type that was processed during this run.
	 * 
	 * @param file
	 *   the currently processing file.
	 * @param success
	 *   the success so far for the application
	 * @return success for the application.
	 */
	public boolean postprocessFile(File file, boolean success) {
		try{
			//Log the file information to EMCIS_EVENT_LOG and EMCIS_EVENT_LOG_DETAIL
			EmcisEventLogger emcisLogger = new EmcisEventLogger();
			String event_id = "RABC_"+fileToken+"_"+region;
            String host = NetUtil.getLocalHostName();
            String hostIP = NetUtil.getLocalIpAddress();
			int sequence = emcisLogger.getEMCISSequence(connection);
			emcisLogger.insertEventLog(connection, sequence, event_id, sqlRunDate, host, hostIP);
			emcisLogger.insertEventLogDetail(connection, sequence, "FileName", fileName);

		}catch (UnknownHostException e) {
            severe("Error getting EMCIS host information ", e);
        }
		if (success) {
			try {
				deleteNonPymtRecords();		// MUST occur BEFORE execution of performBatchExecute()
				performBatchExecute();
				insertAcctDtlFromTopTen();  // MUST occur AFTER execution of performBatchExecute()
				insertAcctDtlAvgRecords();	// MUST occur AFTER rule 38 and 40 records have been inserted
				
				if (!insertTrigger()) {
					severe(
						StaticErrorMsgKeys.POSTPROCESSFILE_ERROR
							+ StaticErrorMsgKeys.TIGGER_TABLE_INSERT_ERROR);
					success = false;
				}
			} catch (SQLException sqle) {
				severe(StaticErrorMsgKeys.INSERT_ERROR + "from method postprocessFile(File file, boolean success)" + sqle.getMessage(), sqle);
				success = false;
			}
		}
		return super.postprocessFile(file, success);
	}
	
	/**
	 * Inserts Triggers for each data type that was processed during this run.
	 * 
	 * @return true if all triggers were inserted, false otherwise.
	 */
	private boolean insertTrigger() {
		String recovery = null;
		
		if (lineCount > 0) {
			if (backupRecovery) {
				recovery = "Y";
			}
			
			for (int i = 0; i < triggers.size(); i++) {
				if (!RabcLoadJobTrig.insertTrigger(connection, currentFile.getName().substring(5, currentFile.getName().length()), currentFile.getName(), (String) triggers.get(i), division, MMddyyyy.format(sqlRunDate) , recovery, Long.toString(billRnd))) {
					return false;
				}
			}
		}
		return true;
	}
	
	/**
	 * Processes at the end of the application. Closes all open PreparedStatements and ResultSets.
	 * 
	 * @param success
	 *   the success of the application thus far
	 * @return success for the application.
	 */
	public boolean postprocess(boolean success) {
		JDBCUtil.closePreparedStatement(insertAcctZero);
		JDBCUtil.closePreparedStatement(insertISG);
		JDBCUtil.closePreparedStatement(insertBPI);
		JDBCUtil.closePreparedStatement(insertTotBlg);
		JDBCUtil.closePreparedStatement(updateTotBlg);
		JDBCUtil.closePreparedStatement(insertTopOCC);
		JDBCUtil.closePreparedStatement(insertTopAdj);
		JDBCUtil.closePreparedStatement(insertTopRecur);
		JDBCUtil.closePreparedStatement(insertNonPymt);
		JDBCUtil.closePreparedStatement(deleteNonPymt);
		JDBCUtil.closePreparedStatement(insertTopBPI);
		JDBCUtil.closePreparedStatement(insertAcctDtl);
		JDBCUtil.closePreparedStatement(selectAverageAcctDtl);
		JDBCUtil.closePreparedStatement(selectAcctDtl);
		JDBCUtil.closePreparedStatement(insertTopPymt);
		JDBCUtil.closePreparedStatement(insertTopTen);
		JDBCUtil.closePreparedStatement(insertTopLPC);
		JDBCUtil.closePreparedStatement(insertTopISGBlg);
		JDBCUtil.closePreparedStatement(insertTopISGAdj);
		JDBCUtil.closePreparedStatement(insertAcctDtlAvg);
		JDBCUtil.closePreparedStatement(insertTopTenTX);
		//JDBCUtil.closePreparedStatement(insertCostRecvSummTX);
		JDBCUtil.closeCallableStatement(insertTxCostRecovrSumm);
		
		JDBCUtil.closeResultSet(rs);
		
		return super.postprocess(success);
	}

}
