/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.admin;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.att.bac.rabc.ConnectionManager;
import com.att.bac.rabc.ProgressBar;
import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.StaticDataLoader;

/**
 * This is an Main Action class for the calculation definition Component used for side menu link.
 *  
 * @author Umesh Deole - UD7153
 *
 */
public class CalculationMainAction extends DispatchAction {
	private static final Logger logger = Logger.getLogger(CalculationMainAction.class);
	private CalculationService calculationService = CalculationService.getViewCalculationService();

	/**
	 * Default dispatch action method to handle the request for calculation navigation from side menu.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @see org.apache.struts.actions.DispatchAction#unspecified(org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public ActionForward unspecified(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		
		CalculationMainForm calculationMainForm = (CalculationMainForm) form;
		HttpSession session = request.getSession(true);
		ProgressBar progressBar = new ProgressBar(session);
		ActionForward forward = null ;
		Connection connection = null ;
		List failureList = new ArrayList();
		progressBar.setProgressPercent(10);
		
		try {
			// Get the connection from the available pool
			connection = ConnectionManager.getConnection((String)request.getSession().getAttribute("region"));
			progressBar.setProgressPercent(20);

			List args = new ArrayList();
			progressBar.setProgressPercent(40);
			
			// Get the existing calculation name and store them in arraylist
			List result = calculationService.getCalculationNames(connection,failureList,args);
			progressBar.setProgressPercent(80);
			
			// Set the calculation names to form 
			calculationMainForm.setCalculationNameList(result);
			/*
			 * Update calendar attributes
			 */
			calculationMainForm.setBillRounds(StaticDataLoader.getBillRounds((String)request.getSession().getAttribute("region")));
			calculationMainForm.setProcDates(StaticDataLoader.getProcDates((String)request.getSession().getAttribute("region")));
			calculationMainForm.setHolidayIndicators(StaticDataLoader.getHolidayIndicators((String)request.getSession().getAttribute("region")));
			calculationMainForm.setLoadedDataDates(StaticDataLoader.getLoadedDataDatesByRegion((String)request.getSession().getAttribute("region")));
			
			if (!failureList.isEmpty()){
				request.setAttribute("failures", failureList);
				forward =  mapping.findForward("error");
			}
			else {
				forward =  mapping.findForward("CalculationMainPage");
			}
			progressBar.setProgressPercent(90);

		} catch(SQLException sx) {
			 logger.error(RABCMessages.getMessage("ERR_CONN_EXEC") + " Exception details: " + sx.getMessage(), sx);
			 failureList.add(new RABCException(RABCMessages.getMessage("ERR_CONN_EXEC"), sx));
			 forward = mapping.findForward("error");
		} catch(NamingException ne) {
			logger.error(RABCMessages.getMessage("ERR_NAMING_EXEC") + " Exception details: " + ne.getMessage(), ne);
			failureList.add(new RABCException(RABCMessages.getMessage("ERR_NAMING_EXEC"), ne));
			forward = mapping.findForward("error");
		} catch(Exception e) {
			logger.error(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General exception "}) + " Exception details: " + e.getMessage(), e);
            failureList.add(new RABCException(RABCMessages.getMessage("ERR_GEN_EXEC", new String[] {"General Exception"}), e));
			forward = mapping.findForward("error");
		} finally {
			SQLHelper.closeConnection(connection, failureList, logger);
		}
		progressBar.setProgressPercent(100);
		  
		return forward ;
	}
	
	/**
	 * Dispatch action method used to load the calculation page. 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward load(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response){
		CalculationMainForm calculationMainForm = (CalculationMainForm) form;
		HttpSession session = request.getSession();
		ProgressBar progressBar = new ProgressBar(session);
		ActionForward forward = null ;
		
		forward =  mapping.findForward("CalculationPage");
		
		return forward ;
	}
}
