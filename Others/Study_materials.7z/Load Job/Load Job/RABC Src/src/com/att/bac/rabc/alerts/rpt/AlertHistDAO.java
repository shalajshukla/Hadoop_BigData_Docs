/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.alerts.rpt;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.ArrayList;
import java.text.MessageFormat;

import org.apache.log4j.Logger;

import com.att.bac.rabc.SQLHelper;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.RABCException;


/**
 * This is a DAO that performs SELECT, INSERT and UPDATE on RABC_ALERT_HIST table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class AlertHistDAO {
	private static final Logger logger = Logger.getLogger(AlertHistDAO.class);

	/**
	 * Returns the list of AlertHist objects.
	 * 
	 * @param conn 
	 * @param failures
	 * @param args
	 * @param baseSQL
	 * @return List
	 */
	public List get(Connection conn, List failures, List args, String baseSQL) {
		List alertHistList = null;
		AlertHist alertHist = null;
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		
		try
		{	
			if (!args.isEmpty())  {
				MessageFormat mf = new MessageFormat(baseSQL);
				sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			}
			else 
				sqlStmt = baseSQL;
			logger.debug("AlertHistDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			alertHistList = new ArrayList();
			while (rs.next()) {
				alertHistList.add(buildAlertHist(rs));
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return null;
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
		
		return alertHistList;
	}

	/**
	 * Private method to build AlertHist object and return it to caller.
	 * 
	 * @param rs
	 * @return AlertHist
	 * @throws SQLException
	 */
	private AlertHist buildAlertHist(ResultSet rs) throws SQLException {
		String value = null;
		AlertHist alertHist = new AlertHist();
		
		alertHist.setPartiRefId(rs.getInt("PARTI_REF_ID"));
		alertHist.setProcDate(rs.getDate("PROC_DATE"));
		alertHist.setFileSeqNum(rs.getInt("FILE_SEQ_NUM"));
		
		value = rs.getString("ALERT_TREND_TIME");
		alertHist.setAlertTrendTime((value==null?"":value));
		value = rs.getString("ALERT_KEY1");
		alertHist.setAlertKeyAt(0,(value==null?"":value));
		value = rs.getString("ALERT_KEY2");
		alertHist.setAlertKeyAt(1,(value==null?"":value));
		value = rs.getString("ALERT_KEY3");
		alertHist.setAlertKeyAt(2,(value==null?"":value));
		value = rs.getString("ALERT_KEY4");
		alertHist.setAlertKeyAt(3,(value==null?"":value));
		value = rs.getString("ALERT_KEY5");
		alertHist.setAlertKeyAt(4,(value==null?"":value));
		value = rs.getString("ALERT_ITEM");
		alertHist.setAlertItem((value==null?"":value));
		
		alertHist.setAlertAvg(rs.getDouble("ALERT_AVG"));
		alertHist.setAlertHigh(rs.getDouble("ALERT_HIGH"));
		alertHist.setAlertLow(rs.getDouble("ALERT_LOW"));
		alertHist.setVariancePct(rs.getDouble("VARIANCE_PCT"));
		alertHist.setVarianceData(rs.getDouble("VARIANCE_DATA"));
		alertHist.setAlertData(rs.getDouble("ALERT_DATA"));
		alertHist.setAlertActualData(rs.getDouble("ALERT_ACTUAL_DATA"));
		alertHist.setPresnCd(rs.getString("PRESN_CD"));
		return alertHist;
	}

	/**
	 * Execute the insert or update statement on RABC_ALERT_HIST table.
	 * 
	 * @param conn
	 * @param failures
	 * @param args
	 * @param baseSQL
	 */
	public void executeUpdate(Connection conn, List failures, List args, String baseSQL) {
		int rowsUpdated = 0;
		Statement stmt = null;
		String sqlStmt = null;
		
		try
		{
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("AlertHistDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rowsUpdated = stmt.executeUpdate(sqlStmt);
			logger.debug("SQL - Execution complete."+ String.valueOf(rowsUpdated) + "  rows updated");
			
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return;
		} finally {
			SQLHelper.closeStatement(stmt, failures, logger);
		}
	}
	
}
