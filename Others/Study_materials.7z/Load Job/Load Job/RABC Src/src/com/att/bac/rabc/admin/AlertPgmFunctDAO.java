/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
*/
package com.att.bac.rabc.admin;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.att.bac.rabc.RABCException;
import com.att.bac.rabc.RABCMessages;
import com.att.bac.rabc.SQLHelper;

/**
 * This is a DAO that performs SELECT, INSERT and UPDATE on RABC_ALERT_PGM_FUNCT table.
 * 
 * @author Vijay Dubey - VD3159
 */
public class AlertPgmFunctDAO {
	private static final Logger logger = Logger.getLogger(AlertPgmFunctDAO.class);

	/**
	 * Returns the list of AlertPgmFunct objects.
	 * 
	 * @param conn 
	 * @param failures
	 * @param args
	 * @param baseSQL
	 * @return List
	 */
	public List get(Connection conn, List failures, List args, String baseSQL) {
		List alertPgmFunctList = null;
		AlertPgmFunct alertPgmFunct = null;
		Statement stmt = null;
		String sqlStmt = null;
		ResultSet rs = null;
		
		try
		{
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("AlertPgmFunctDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sqlStmt);
			alertPgmFunctList = new ArrayList();
			while (rs.next()) {
				alertPgmFunctList.add(buildAlertPgmFunct(rs));
			}
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return null;
		} finally {
			SQLHelper.closeResultSet(rs, failures, logger);
			SQLHelper.closeStatement(stmt, failures, logger);
		}
		
		return alertPgmFunctList;
	}

	/**
	 * Private method to build AlertPgmFunct object and return it to caller.
	 * 
	 * @param rs
	 * @return AlertPgmFunct
	 * @throws SQLException
	 */
	private AlertPgmFunct buildAlertPgmFunct(ResultSet rs) throws SQLException {
		AlertPgmFunct alertPgmFunct = new AlertPgmFunct();
		
		alertPgmFunct.setPgmId(rs.getString("PGM_ID"));
		alertPgmFunct.setPgmDesc(rs.getString("PGM_DESC"));
		alertPgmFunct.setFunctCd(rs.getString("FUNCT_CD"));
		alertPgmFunct.setAlertGrpType(rs.getString("ALERT_GRP_TYPE"));
		return alertPgmFunct;
	}

	/**
	 * Execute the insert or update statement on RABC_ALERT_PGM_FUNCT  table.
	 * 
	 * @param conn
	 * @param failures
	 * @param args
	 * @param baseSQL
	 */
	public void executeUpdate(Connection conn, List failures, List args, String baseSQL) {
		int rowsUpdated = 0;
		Statement stmt = null;
		String sqlStmt = null;
		
		try
		{
			MessageFormat mf = new MessageFormat(baseSQL);
			sqlStmt = mf.format((String[])args.toArray(new String[args.size()]));
			logger.debug("AlertPgmFunctDAO - Executing SQL statement: "+ sqlStmt);
			stmt = conn.createStatement();
			rowsUpdated = stmt.executeUpdate(sqlStmt);
			logger.debug("SQL - Execution complete."+ String.valueOf(rowsUpdated) + "  rows updated");
		} catch (SQLException sx) {
			logger.error(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}) + " Exception details: " + sx.getMessage(), sx);
			failures.add(new RABCException(RABCMessages.getMessage("ERR_SQL_EXEC", new String[] {sqlStmt}), sx));
			return;
		} finally {
			SQLHelper.closeStatement(stmt, failures, logger);
		}
	}

}
