/*
 * Copyright 2002-2006 ATT Knowledge Ventures. All rights reserved.
 */

package com.att.bac.rabc.admin.adhoc.rpt;

/**
 * Module description: 
 * 
 * This is an adhoc report step 2 object used to hold the column data and it's error messages.
 *
 * @author Umesh Deole- UD7153
 */
public class AdhocReportStep2 {
	// columnDetails will format as - "view_name(orRABC_PARTI_DESC.PARTI_DESC):data_tbl:data_ddl_name(or RABC_EXTRCT_TBL_DEF.#getColumnVars.DATA_DDL_NAME#_Name):data_ddl_name:(#tname#.#datatbl#):(#datatbl#.#dcn#):presn_name:calculation:presn_calc_num:graph_presn_ind:presn_ord_ind:presn_suppress_ind:data_desc_ind:mouseover:data_link_ind:data_link_num:presn_unit_ind:presn_sum_ind:PRESN_FORMAT_CODE:delete"
	// each column details will be separated by semicolon . 

	private String data=null;
	private String dataValidationErrorMessage;

	/**
	 * @return Returns the dataValidationErrorMessage.
	 */
	public String getDataValidationErrorMessage() {
		return dataValidationErrorMessage;
	}
	/**
	 * @param dataValidationErrorMessage The dataValidationErrorMessage to set.
	 */
	public void setDataValidationErrorMessage(String dataValidationErrorMessage) {
		this.dataValidationErrorMessage = dataValidationErrorMessage;
	}
	/**
	 * @return Returns the data.
	 */
	public String getData() {
		return data;
	}
	/**
	 * @param data The data to set.
	 */
	public void setData(String data) {
		this.data = data;
	}
}
