package com.att.bac.rabc.load.cyclecalendar.calnet;

import java.io.File;
import java.io.FileFilter;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.att.carat.load.Application;
import com.att.carat.load.FileDBLoadJob;

/**
 * Load job to load Cycle Calendar file data into CALNET 2's AUDINV_CYCLE table.
 * 
 * @author kb629p
 */
public class CycleCalendarLoadJob extends FileDBLoadJob implements FileFilter {

	private Logger logger = Logger.getLogger(CycleCalendarLoadJob.class);
	
	private static final String checkPattern="02/29";

	/** Number of lines **/
	protected int lineNumber = 0;
	private Pattern filePattern = Pattern.compile("^ES[0-9]{5}\\.DAT\\.CARATPF\\.Z002\\.CNETCAL\\.DATA\\.D[0-9]{7}\\.T[0-9]{6}.*");

	List<CycleCalendarData> recordList = new ArrayList<CycleCalendarData>();

	/**
	 * Configures parent and prints out next run time
	 * 
	 * @see com.sbc.bac.load.FileDBLoadJob#configure()
	 */
	protected boolean configure(Application application,
			Properties configuration) {
		logger.info("Loading configuration for application: "
				+ configuration.getProperty("name"));
		boolean success = super.configure(application, configuration);
		return success;
	}

	/**
	 * Overriding accept(file) method. It checks the file name pattern and
	 * returns the boolean value.
	 * 
	 * @see java.io.FileFilter#accept(java.io.File)
	 */
	@Override
	public boolean accept(File file) {
		boolean result = filePattern.matcher(file.getName()).matches();
		return result;
	}

	/**
	 * Overriding preprocessFile() method. It is executed prior to processing
	 * the load job.
	 * 
	 * @see com.sbc.bac.load.FileDBLoadJob#preprocessFile()
	 */
	protected boolean preprocessFile(File file) {
		super.preprocessFile(file);
		return true;
	}

	/**
	 * Overriding parseLine(line) method. It accepts a single line and add data
	 * in the list by calling method parseMethod().
	 * 
	 * @see com.sbc.bac.load.FileDBLoadJob#parseLine(java.lang.String)
	 */
	@Override
	protected int parseLine(String line) throws Exception {
		// Increment the line number
		lineNumber++;
		return parseRecord(line);
	}

	/**
	 * Fetch a line records from file and set in CycleCalendarData Object which
	 * is then added in list
	 */
	protected int parseRecord(String line) {
		CycleCalendarData cycleCalData = new CycleCalendarData();

		if (line != null) {
			String[] str = line.split(";");
			if (str.length > 1) {
				if(checkBillAndProcDate(str[3].trim(), str[2].trim()) == SKIPPED)
					return SKIPPED;
				cycleCalData.setCycle(str[0].trim());
				cycleCalData.setBillRound(str[1].trim());
				cycleCalData.setProcDate(str[2].trim());
				cycleCalData.setBillRoundDate(str[3].trim());
				recordList.add(cycleCalData);
			}
		}
		return SUCCESS;
	}

	/**
	 * Executes after the file has been processed and loaded in the list
	 */
	/**
	 * Overriding postProcessFile(file, success) method. It is executed post to
	 * processing the file to be loaded. It calls recordInsertionWest method of
	 * class CycleCalendarLoadDAO to insert records in table AUDINV_CYCLE.
	 * 
	 * @see com.sbc.bac.load.FileDBLoadJob#postprocessFileOpt(java.io.File,
	 *      boolean)
	 */
	protected int postprocessFileOpt(File file, int success) {
		CycleCalendarLoadDAO cycleCalLoadDAO = new CycleCalendarLoadDAO();
		boolean daoResult = true;
		if (success != ERROR) {
			if (recordList.size() > 0)
				daoResult = cycleCalLoadDAO.recordInsertion(connection,
						recordList);
		} else
			daoResult = false;
		reset();
		int i = 0;
		if (daoResult == false)
			i = super.postprocessFileOpt(file, ERROR);
		else
			i = super.postprocessFileOpt(file, success);
		return i;
	}

	private void reset() {
		lineNumber = 0;
		recordList.clear();
	}
	
	/*This method is introduced as LOAD is getting invalid dates from MVS TXT files.
	 * e.g. files containing "02/29/2007", "02/29/2009", "02/29/2011", etc.
	 * So this method will ignore such invalid dates.
	 */
	private int checkBillAndProcDate(String billRndDate, String procDate) {
		int year;
		if(billRndDate.contains(checkPattern)) {
			year = Integer.parseInt(billRndDate.substring(6,10));
			if(!isLeapYear(year))
				return SKIPPED;
		}
		if(procDate.contains(checkPattern)) {
			year = Integer.parseInt(procDate.substring(6,10));
			if(!isLeapYear(year))
				return SKIPPED;
		}		
		return SUCCESS;
	}
	
	// To check if the year is a leap year or not
	private boolean isLeapYear(int year) {
		if (year % 400 == 0)
		     return true;
		 else if (year % 100 == 0)
		     return false;
		 else if (year % 4 == 0)
		     return true;
		 else
			 return false;
	}
}
