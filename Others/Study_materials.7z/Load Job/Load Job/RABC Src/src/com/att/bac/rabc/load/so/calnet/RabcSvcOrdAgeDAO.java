/* Created by Gaurav Bhargava (GB0741) on Dec 8, 2006.
Copyright 2006-2008 AT&T Knowledge Ventures. All rights reserved. */

package com.att.bac.rabc.load.so.calnet;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.att.bac.rabc.load.calnet.CalnetException;
import com.att.carat.util.JDBCUtil;

/**
 * Data Access Object class for RABC_SVC_ORD_AGE table.
 * It is used to perform database operation on this table.
 * @author GB0741
 */
public class RabcSvcOrdAgeDAO {

	private static final String AGE_CYCLE_QUERY = "Insert Into RABC_SVC_ORD_AGE ( " +
	"Select RUN_DATE, DIVISION, AGENCY_ID, " +
	"Sum(Case when AGE_CYCLE<=3 then 1 else 0 end) As STEP1, " +
	"Sum(Case when AGE_CYCLE>3 and AGE_CYCLE<=7 then 1 else 0 end) As STEP2, " +
	"Sum(Case when AGE_CYCLE>7 and AGE_CYCLE<=14 then 1 else 0 end) As STEP3, " +
	"Sum(Case when AGE_CYCLE>14 then 1 else 0 end) As STEP4, " +
	"CYCLE from RABC_SVC_ORD_INFO where RUN_DATE= ? and DIVISION = ? group by RUN_DATE, DIVISION, AGENCY_ID, CYCLE)";

	/**
	 * It is used to insert the records into RABC_SVC_ORD_AGE table.
	 * @param connection, the DB connection to execute insert query.
	 * @param sqlRunDate, division -> Parameters to sql query
	 * @return boolean indicating success or failure.
	 * @throws CalnetException
	 */
	protected boolean insertRecords(Connection connection, Date sqlRunDate,
			String division) throws CalnetException {
		boolean success = false;
		PreparedStatement avgPrepStmt = null;
		try {
			avgPrepStmt = connection.prepareStatement(AGE_CYCLE_QUERY);
			avgPrepStmt.setDate(1, sqlRunDate);
			avgPrepStmt.setString(2, division);
			avgPrepStmt.executeUpdate();
			success = true;
		} catch (SQLException ex) {
			throw new CalnetException(
					"Error inserting values in RABC_SVC_ORD_AGE", ex);
		}finally{
			JDBCUtil.closePreparedStatement(avgPrepStmt);
		}
		return success;
	}
}
