package com.att.bac.rabc.util;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;

import com.att.carat.util.JDBCUtil;
//import com.sbc.bac.load.Application;
//import com.sbc.bac.load.TimedLoadJob;
import com.att.carat.load.Application;
import com.att.carat.load.TimedLoadJob;
import com.sbc.bac.rabc.load.StaticFieldKeys;

public class RabcPendingAdhocDel  extends TimedLoadJob {

	/**
	 * This job cleans up any "Pending" alert rules .. Alert rule will be put in Pending when it is created as "test" 
	 * and never changed to status ACTIVE ..
	 * This job runs once everyday in after hours and cleans up any Pending alert rules ..     
	 */
	
	private PreparedStatement deletePresnID;
	private String tableList = null;
	
	protected boolean configure(Application application, Properties properties) {
        boolean success = super.configure(application, properties);
        if (!success) 
        	return false;
        
        // Expected configuration file will contain a ";" semicolan separated table list
        tableList = properties.getProperty("tableList");
        if (tableList == null){
        	severe(" Config parameter tableList not defined!! ");
        	return false;
        }
        return true;
	}
	
	
	protected boolean action() {
		
		boolean status = true;
		
		String[] clnupTableList = tableList.split(StaticFieldKeys.SEMICOLON);

		int tblIdx = 0;
		String pendingPresnId = " where presn_id in (select presn_id from rabc_presn_id where  upper(ADHOC_RPT_STATUS) = 'PENDING') ";
		while (clnupTableList.length > tblIdx) {

			if(clnupTableList[tblIdx].trim() != null && !clnupTableList[tblIdx].trim().equals(""))
			try {
				deletePresnID = connection.prepareStatement(" DELETE "
						+ clnupTableList[tblIdx].trim() + pendingPresnId);
				deletePresnID.executeUpdate();
			} catch (SQLException e) {
				severe(e.getMessage(),e);
				status = false;
				break;
			}
			tblIdx++;
		}

		if (status)
			try {
				deletePresnID = connection
						.prepareStatement(" DELETE RABC_PRESN_ID where presn_id in ( select presn_id from rabc_presn_id where  upper(ADHOC_RPT_STATUS) = 'PENDING') ");
				deletePresnID.executeUpdate();
			} catch (SQLException e) {
				severe(e.getMessage(), e);
				status = false;
			}

		return status;
	}
	
	protected boolean postprocess(boolean success) {
		
		JDBCUtil.closePreparedStatement(deletePresnID);
	
		success = super.postprocess(success);
	
		return success;
	}

}
