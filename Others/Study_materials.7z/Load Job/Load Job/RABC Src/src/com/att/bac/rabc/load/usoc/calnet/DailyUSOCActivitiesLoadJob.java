/* Created by Peter Foo (pf7941) on Dec 1, 2006.
 Copyright 2006-2008 AT&T Knowledge Ventures. All rights reserved. */

package com.att.bac.rabc.load.usoc.calnet;

import java.io.File;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import com.att.bac.rabc.load.calnet.CalnetException;
import com.att.bac.rabc.load.calnet.CalnetLoadJob;
import com.att.bac.rabc.util.EmcisEventLogger;
import com.att.carat.util.NetUtil;
import com.sbc.bac.rabc.load.StaticErrorMsgKeys;
import com.sbc.bac.rabc.load.StaticFieldKeys;

/**
 * This job reads files whose name fits the pattern: WE.[CI].C[0-9]{4}.XT34USOC.* . It parses the
 * file line by line and inserts the records into the RABC_DAILY_USOC_ACTVT table.
 * 
 * @author pf7941
 * 
 */
public class DailyUSOCActivitiesLoadJob extends CalnetLoadJob {

	private List dailyUSOCActivityList = new ArrayList();
	private static final int DENOMINATOR_1 = 100000;
	private static final int DENOMINATOR_2 = 1000000;

	public String getFileId() {
		return "XT34USOC";
	}

	public String getTable() {
		return "RABC_DAILY_USOC_ACTVT";
	}

	/**
	 * Processes a line from the file. A DailyUSOCActivity object is created to hold the data from
	 * each line. The DailyUSOCActivity object is then placed into the arrayList dailyUSOCActivityList.
	 * 
	 * @see com.att.bac.rabc.load.calnet.CalnetLoadJob#processRecord(java.lang.String)
	 */
	protected int processRecord(String line) throws Exception {
		lineCount++;
		StringTokenizer DataLine = new StringTokenizer(line, StaticFieldKeys.SEMICOLON);
		// ignore File Id
		DataLine.nextToken();
		// AGENCY-ID
		String agencyId = DataLine.nextToken().trim();
		// ignore USOC-COUNT, DIVISION
		DataLine.nextToken();
		DataLine.nextToken();
		// USOC
		String usoc = DataLine.nextToken().trim();
		// CYCLE
		int cycle = Integer.parseInt(DataLine.nextToken().trim());
		// ignore BILL-ROUND, BILL-YEAR, BILL-MONTH
		DataLine.nextToken();
		DataLine.nextToken();
		DataLine.nextToken();
		// DataLine.nextToken();
		// USOC_ACCESSIBLE-IND
		String usocAccsInd = DataLine.nextToken().trim();
		// ignore USOC-NAME
		DataLine.nextToken();
		DataLine.nextToken();

		// QTY-1
		long fullChgTotCt = Long.parseLong(DataLine.nextToken().trim())/DENOMINATOR_1;
		// AMT-1
		long fullChgTotAmt = Long.parseLong(DataLine.nextToken().trim())/DENOMINATOR_2;
		// QTY-2
		long dsct50PctTotCt = Long.parseLong(DataLine.nextToken().trim())/DENOMINATOR_1;
		// AMT-2
		long dsct50PctTotAmt = Long.parseLong(DataLine.nextToken().trim())/DENOMINATOR_2;
		// QTY-3
		long dsct100PctTotCt = Long.parseLong(DataLine.nextToken().trim())/DENOMINATOR_1;
		// AMT-3
		long dsct100PctTotAmt = Long.parseLong(DataLine.nextToken().trim())/DENOMINATOR_2;
		// QTY-4
		long dsctOthPctTotCt = Long.parseLong(DataLine.nextToken().trim())/DENOMINATOR_1;
		// AMT-4
		long dsctOthPctTotAmt = Long.parseLong(DataLine.nextToken().trim())/DENOMINATOR_2;

		// Create a DailyUSOCActivity object and add it to a List, which will be used to insert data
		// into the database as a batch.
		DailyUSOCActivity d = new DailyUSOCActivity();
		d.setRunDate(sqlRunDate);
		d.setDivision(division);
		d.setAgencyId(agencyId);
		d.setUsoc(usoc);
		d.setCycle(cycle);
		d.setUsocAccsInd(usocAccsInd);
		d.setFullChgTotCt(fullChgTotCt);
		d.setFullChgTotAmt(fullChgTotAmt);
		d.setDsct50PctTotCt(dsct50PctTotCt);
		d.setDsct50PctTotAmt(dsct50PctTotAmt);
		d.setDsct100PctTotCt(dsct100PctTotCt);
		d.setDsct100PctTotAmt(dsct100PctTotAmt);
		d.setDsctOthPctTotCt(dsctOthPctTotCt);
		d.setDsctOthPctTotAmt(dsctOthPctTotAmt);
		dailyUSOCActivityList.add(d);

		return SUCCESS;
	}

	/** 
	 * Inserts the elements of dailyUSOCActivityList into the table via the DAO class.
	 * After the elements are inserted, dailyUSOCActivityList is cleared.
	 * @see com.sbc.bac.load.FileDBLoadJob#postprocessFile(java.io.File, boolean)
	 **/
	public boolean postprocessFile(File file, boolean success) {
		try{
			EmcisEventLogger emcisLogger = new EmcisEventLogger();
			String event_id = "RABC_"+getFileId()+"_WE";
            String host = NetUtil.getLocalHostName();
            String hostIP = NetUtil.getLocalIpAddress();
			int sequence = emcisLogger.getEMCISSequence(connection);
			emcisLogger.insertEventLog(connection, sequence, event_id, sqlRunDate, host, hostIP);
			emcisLogger.insertEventLogDetail(connection, sequence, "FileName", file.getName());
		}catch (UnknownHostException e) {
            severe("Error getting EMCIS host information ", e);
        }
		DailyUSOCActivityDAO dao = new DailyUSOCActivityDAO();
		if (success) {
			try {
				// Insert the records into the table.
				success = dao.insertBatchOfRecords(connection, dailyUSOCActivityList, 1000);
			}
			catch (CalnetException e) {
				severe(StaticErrorMsgKeys.INSERT_ERROR + e.getMessage(), e);
				success = false;
			}
		}
		dailyUSOCActivityList.clear();
		return super.postprocessFile(file, success);
	}

}
