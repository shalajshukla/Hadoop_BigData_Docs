package com.test.azure;

import com.microsoft.azure.storage.*;
import com.microsoft.azure.storage.blob.*;

import java.io.*;
import java.net.URL;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream;
import org.apache.commons.compress.compressors.gzip.GzipParameters;
import org.apache.commons.compress.compressors.z.ZCompressorInputStream;

public class AzureBlobStorageTest {

    public static final String storageConnectionString =
            "DefaultEndpointsProtocol=https;" +
                    "AccountName=blobpocspark;" +
                    "AccountKey=k/9mYEZAahSsOZxGDfTJ+v2WyH5ljys11G/nrgnvY9tHGm9Tu/FEyioyM12Jw6YtxswUyq674e1ma/l5/G4VLA==";

    /*String storageConnectionString =
            RoleEnvironment.getConfigurationSettings().get("StorageConnectionString");*/

    public static void main(String[] args) {
        //createContainer();
       //uploadBlob();
        //deleteBlob();
       // downloadAndReadBlob();
       // downloadFileUsingURI();
       // deleteBlobDirectory();
       // uploadBlobFromLocal();
        //writeFileToBlob();
       // readFileFromBlob();
       // uncompressZfile ();
       // uncompressGZfile();
        uncompressZipfile ();
    }

    public static void createContainer () {
        try
        {
            // Retrieve storage account from connection-string.
            CloudStorageAccount storageAccount = CloudStorageAccount.parse(storageConnectionString);

            // Create the blob client.
            CloudBlobClient blobClient = storageAccount.createCloudBlobClient();

            // Get a reference to a container.
            // The container name must be lower case
            CloudBlobContainer container = blobClient.getContainerReference("mycontainer");

            // Create the container if it does not exist.
            container.createIfNotExists();

            // Create a permissions object.
            BlobContainerPermissions containerPermissions = new BlobContainerPermissions();

// Include public access in the permissions object.
            containerPermissions.setPublicAccess(BlobContainerPublicAccessType.CONTAINER);

// Set the permissions on the container.
            container.uploadPermissions(containerPermissions);
            System.out.println("container created successfully");
        }
        catch (Exception e)
        {
            // Output the stack trace.
            e.printStackTrace();
        }
    }
    public static void uncompressZfile () {
        try {
            CloudStorageAccount storageAccount = CloudStorageAccount.parse(storageConnectionString);
            CloudBlobClient blobClient = storageAccount.createCloudBlobClient();
            CloudBlobContainer container = blobClient.getContainerReference("mycontainer");
            zUnCompression(container,"WALGRN_20170929.BILLING.T1.data.transmission.dat_20170930_024411.Z");
            //getBlobProperties (container,"WALGRN_20170929.BILLING.T1.data.transmission.dat_20170930_024411");
        }catch (Exception e){
            // Output the stack trace.
            e.printStackTrace();
        }

    }
    public static void uncompressGZfile () {
        try {
            CloudStorageAccount storageAccount = CloudStorageAccount.parse(storageConnectionString);
            CloudBlobClient blobClient = storageAccount.createCloudBlobClient();
            CloudBlobContainer container = blobClient.getContainerReference("mycontainer");
            gzUnCompression(container,"RSi_WGUS_STR_1506_WIC_UPC_DAILY#.20170926.txt.gz");
        }catch (Exception e){
            // Output the stack trace.
            e.printStackTrace();
        }

    }
    public static void uncompressZipfile () {
        try {
            CloudStorageAccount storageAccount = CloudStorageAccount.parse(storageConnectionString);
            CloudBlobClient blobClient = storageAccount.createCloudBlobClient();
            CloudBlobContainer container = blobClient.getContainerReference("mycontainer");
            System.out.println(" start writing "+new java.util.Date());
            zipUnCompress(container,"sample1.zip");
            System.out.println(" end writing "+new java.util.Date());
        }catch (Exception e){
            // Output the stack trace.
            e.printStackTrace();
        }

    }
    public static Map<String,Object> zUnCompression(CloudBlobContainer container, String blockReferencePath) throws Exception  {

        Map<String, Object> fileMapp = new HashMap<>();

        //fetch file name from full file path
        Path p = Paths.get(blockReferencePath);
        String fullFileName = p.getFileName().toString();
        int x= fullFileName.lastIndexOf(".");
        String fileName =fullFileName.substring(0,x);

        try{
            CloudBlockBlob inputBlob = container.getBlockBlobReference(blockReferencePath);
            BufferedInputStream iin = new BufferedInputStream(inputBlob.openInputStream());
            ZCompressorInputStream zIn = new ZCompressorInputStream(iin);

            CloudBlockBlob outputBlob = container.getBlockBlobReference(fileName);

            try (BlobOutputStream blobOutputStream = outputBlob.openOutputStream()) {
                System.out.println(" start writing "+new java.util.Date());
                final byte[] buffer = new byte[1000];
                int n = 0;
                while (-1 != (n = zIn.read(buffer))) {
                    blobOutputStream.write(buffer, 0, n);
                }
                System.out.println(" end writing "+new java.util.Date());
            }



            zIn.close();
            outputBlob.downloadAttributes();
            //outputBlob = container.getBlockBlobReference(fileName);
            System.out.println( " blob meta data " +outputBlob.getMetadata());
            System.out.println(" blob name "+outputBlob.getName());
            System.out.println( " blob length " +outputBlob.getProperties().getLength());
            System.out.println( " last modified time " +outputBlob.getProperties().getLastModified().getTime());
            System.out.println( " last modified date " +outputBlob.getProperties().getLastModified());
            //DirectoryEntry de = client.getDirectoryEntry(destLocation + fileName);

            /*fileMapp.put("filePath", fileName);
            fileMapp.put("fileSize", outputBlob.getProperties().getLength());
            fileMapp.put("lastModifiedDate", outputBlob.getProperties().getLastModified().getTime());*/

            System.out.println(" end method "+new java.util.Date());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return fileMapp;
    }

    public static List<Map<String,Object>> zipUnCompress( CloudBlobContainer container , String blockReferencePath) throws Exception {

        byte[] buffer = new byte[1024];

        List<Map<String,Object>> listfileMap = new ArrayList<>();
        CloudBlockBlob inputBlob = container.getBlockBlobReference(blockReferencePath);

        //get the zip file content
        ZipInputStream zis = new ZipInputStream(inputBlob.openInputStream());
        //get the zipped file list entry
        ZipEntry ze = zis.getNextEntry();

        while (ze != null) {
            if(ze.isDirectory()) {
                System.out.println(ze.getName() + " is direcotry");
                ze = zis.getNextEntry();
                continue;
            }

            Path path = Paths.get(ze.getName()) ;
            String fileName = path.getFileName().toString();

            Map<String,Object> fileMap = new HashMap<>();
            System.out.println(" filename " + fileName+ " fileSize "+ze.getSize() + " lastmodifieddate "+ze.getTime());
            fileMap.put("filePath",fileName);
            fileMap.put("fileSize",ze.getSize());
            fileMap.put("lastModifiedDate",ze.getTime());

            listfileMap.add(fileMap);

            CloudBlockBlob outputBlob = container.getBlockBlobReference(fileName);

            try (BlobOutputStream blobOutputStream = outputBlob.openOutputStream()) {
                int len;
                while ((len = zis.read(buffer)) > 0) {
                    blobOutputStream.write(buffer, 0, len);
                }
            }
            ze = zis.getNextEntry();
        }

        zis.closeEntry();
        zis.close();


        return listfileMap;

    }
    public static Map<String,Object> gzUnCompression(CloudBlobContainer container , String blockReferencePath)  {



        Map<String, Object> fileMapp = new HashMap<>();


        try{
            CloudBlockBlob inputBlob = container.getBlockBlobReference(blockReferencePath);
            BufferedInputStream iin = new BufferedInputStream(inputBlob.openInputStream());
            GzipCompressorInputStream gzIn = new GzipCompressorInputStream(iin);
            GzipParameters parameters = gzIn.getMetaData();

            String fileName =parameters.getFilename();
            CloudBlockBlob outputBlob = container.getBlockBlobReference(fileName);
            try (BlobOutputStream blobOutputStream = outputBlob.openOutputStream()) {
                System.out.println(" start writing "+new java.util.Date());
                final byte[] buffer = new byte[1000];
                int n = 0;
                while (-1 != (n = gzIn.read(buffer))) {
                    blobOutputStream.write(buffer, 0, n);
                }
                System.out.println(" finish writing "+new java.util.Date());
            }

            outputBlob.downloadAttributes();
            //outputBlob = container.getBlockBlobReference(fileName);
            System.out.println( " blob meta data " +outputBlob.getMetadata());
            System.out.println(" blob name "+outputBlob.getName());
            System.out.println( " blob length " +outputBlob.getProperties().getLength());
            System.out.println( " last modified time " +outputBlob.getProperties().getLastModified().getTime());
            System.out.println( " last modified date " +outputBlob.getProperties().getLastModified());

            fileMapp.put("filePath",parameters.getFilename());
            fileMapp.put("fileSize",outputBlob.getProperties().getLength());
            fileMapp.put("lastModifiedDate",parameters.getModificationTime());


            gzIn.close();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return fileMapp;
    }
    public static void getBlobProperties (CloudBlobContainer container, String fileName) {
        try {
            CloudBlockBlob blob = container.getBlockBlobReference(fileName);
            blob.downloadAttributes();
           /* System.out.println( " blob meta data " +outputBlob.getMetadata());
            System.out.println(" blob name "+outputBlob.getName());
            System.out.println( " blob length " +outputBlob.getProperties().getLength());
            System.out.println("Get blob properties");*/
            BlobProperties properties = blob.getProperties();
            System.out.printf("Blob type: %s%n", properties.getBlobType());
            System.out.printf("Cache control: %s%n", properties.getCacheControl());
            System.out.printf("Content disposition: %s%n", properties.getContentDisposition());
            System.out.printf("Content encoding: %s%n", properties.getContentEncoding());
            System.out.printf("Content language: %s%n", properties.getContentLanguage());
            System.out.printf("Content type: %s%n", properties.getContentType());
            System.out.printf("Last modified: %s%n", properties.getLastModified());
            System.out.printf("Lease state: %s%n", properties.getLeaseState());
            System.out.printf("Lease status: %s%n", properties.getLeaseStatus());
            //System.out.println( " last modified time " +outputBlob.getProperties().getLastModified().getTime());
            System.out.println( " last modified date " +blob.getProperties().getLastModified());
            System.out.println( " blob length " +blob.getProperties().getLength());
        } catch(Exception e ){
            e.printStackTrace();
        }
    }
    public static void uploadBlobFromLocal () {
        final String filePath = "C:\\RSI_POC\\bigFile.txt";
        System.out.println(new java.util.Date());
        try
        {
            // Retrieve storage account from connection-string.
            CloudStorageAccount storageAccount = CloudStorageAccount.parse(storageConnectionString);

            // Create the blob client.
            CloudBlobClient blobClient = storageAccount.createCloudBlobClient();

            // Retrieve reference to a previously created container.
            CloudBlobContainer container = blobClient.getContainerReference("mycontainer");

            // Create or overwrite the "myimage.jpg" blob with contents from a local file.
            CloudBlockBlob blob = container.getBlockBlobReference("bigFile/bigFile.txt");
            File source = new File(filePath);
            System.out.println(new java.util.Date());
            try (InputStream in = new FileInputStream(source)) {
                blob.upload(in, source.length());
            }
            System.out.println(new java.util.Date());
            System.out.println(" file uploaded successfuly");


            // can access from spark spark.read.json("wasb://mycontainer@blobpocspark.blob.core.windows.net/query.json")
        }catch (Exception e)
        {
            // Output the stack trace.
            e.printStackTrace();
        } finally {
            try
            {
                Files.deleteIfExists(Paths.get(filePath));
                System.out.println("Deletion successful.");
            } catch(IOException e){
                e.printStackTrace();
            }
        }
    }
    public static void writeFileToBlob () {
        try
        {
            // Retrieve storage account from connection-string.
            CloudStorageAccount storageAccount = CloudStorageAccount.parse(storageConnectionString);

            // Create the blob client.
            CloudBlobClient blobClient = storageAccount.createCloudBlobClient();

            // Retrieve reference to a previously created container.
            CloudBlobContainer container = blobClient.getContainerReference("mycontainer");


            String text = "just a sampe text \n just a sample text";

            CloudBlockBlob blob = container.getBlockBlobReference("Test.txt");
            try(BlobOutputStream blobOutputStream = blob.openOutputStream()) {
                blobOutputStream.write(text.getBytes("UTF-8"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static void readFileFromBlob () {
        try
        {
            // Retrieve storage account from connection-string.
            CloudStorageAccount storageAccount = CloudStorageAccount.parse(storageConnectionString);

            // Create the blob client.
            CloudBlobClient blobClient = storageAccount.createCloudBlobClient();

            // Retrieve reference to a previously created container.
            CloudBlobContainer container = blobClient.getContainerReference("mycontainer");

            Iterable<ListBlobItem> blobItems = container.listBlobs( "csvs",  true);


            // Loop through each blob item in the container.
            for (ListBlobItem blobItem : blobItems) {
                String path =blobItem.getParent().getPrefix();
                int count = path.length() - path.replace("/", "").length();
                if(count > 1) {
                  continue;
                }
                if (blobItem instanceof CloudBlob) {
                    // Download the item and save it to a file with the same name.
                    CloudBlob blob = (CloudBlob) blobItem;
                    try(InputStream in = blob.openInputStream()
                        ; BufferedReader reader = new BufferedReader(new InputStreamReader(in))) {

                        String line;

                        while ((line = reader.readLine()) != null) {
                            System.out.println(line);
                        }
                    }

                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    public static void uploadBlob () {
        final String filePath = "filename.txt";
        try
        {
            // Retrieve storage account from connection-string.
            CloudStorageAccount storageAccount = CloudStorageAccount.parse(storageConnectionString);

            // Create the blob client.
            CloudBlobClient blobClient = storageAccount.createCloudBlobClient();

            // Retrieve reference to a previously created container.
            CloudBlobContainer container = blobClient.getContainerReference("mycontainer");


            String text = "just a sampe text \n just a sample text";
            try (PrintWriter out = new PrintWriter(filePath)) {
                out.println(text);
            }
            // Define the path to a local file.


            // Create or overwrite the "myimage.jpg" blob with contents from a local file.
            CloudBlockBlob blob = container.getBlockBlobReference("csvs/20180309/test1/query.json");
            File source = new File(filePath);
            try (InputStream in = new FileInputStream(source)) {
                blob.upload(in, source.length());
            }

            System.out.println(" file uploaded successfuly");


            // can access from spark spark.read.json("wasb://mycontainer@blobpocspark.blob.core.windows.net/query.json")
        }catch (Exception e)
        {
            // Output the stack trace.
            e.printStackTrace();
        } finally {
            try
            {
                Files.deleteIfExists(Paths.get(filePath));
                System.out.println("Deletion successful.");
            } catch(IOException e){
                e.printStackTrace();
            }
        }
    }

    public static void listBlob () {
        try
        {
            // Retrieve storage account from connection-string.
            CloudStorageAccount storageAccount = CloudStorageAccount.parse(storageConnectionString);

            // Create the blob client.
            CloudBlobClient blobClient = storageAccount.createCloudBlobClient();

            // Retrieve reference to a previously created container.
            CloudBlobContainer container = blobClient.getContainerReference("mycontainer");

            // Loop over blobs within the container and output the URI to each of them.
            for (ListBlobItem blobItem : container.listBlobs()) {
                System.out.println(blobItem.getUri());
            }
        }
        catch (Exception e)
        {
            // Output the stack trace.
            e.printStackTrace();
        }
    }
    public static void downloadFileUsingURI () {

        try
        {
            // Retrieve storage account from connection-string.
            CloudStorageAccount storageAccount = CloudStorageAccount.parse(storageConnectionString);

            // Create the blob client.
            CloudBlobClient blobClient = storageAccount.createCloudBlobClient();

            // Retrieve reference to a previously created container.
            CloudBlobContainer container = blobClient.getContainerReference("mycontainer");

            Iterable<ListBlobItem> blobItems = container.listBlobs( "csvs",  true);;

            // Loop through each blob item in the container.
            for (ListBlobItem blobItem : blobItems) {
                // If the item is a blob, not a virtual directory.
                System.out.println(blobItem);
                System.out.println(blobItem.getUri());

                URL website = new URL(blobItem.getUri().toString());
                ReadableByteChannel rbc = Channels.newChannel(website.openStream());


                if (blobItem instanceof CloudBlob) {
                    // Download the item and save it to a file with the same name.
                    CloudBlob blob = (CloudBlob) blobItem;
                    String fileName= Paths.get(blob.getName()).getFileName().toString();
                    FileOutputStream fos = new FileOutputStream("c://mydownloads//"+fileName);
                    fos.getChannel().transferFrom(rbc, 0, Long.MAX_VALUE);
                }
            }
        }
        catch (Exception e)
        {
            // Output the stack trace.
            e.printStackTrace();
        }

    }
    public static void downloadAndReadBlob () {
        long currentTime = System.currentTimeMillis();
        new File("C:\\"+currentTime ).mkdir();
        String rootLocalPath = "C:\\"+currentTime+"\\";
        try
        {
            // Retrieve storage account from connection-string.
            CloudStorageAccount storageAccount = CloudStorageAccount.parse(storageConnectionString);

            // Create the blob client.
            CloudBlobClient blobClient = storageAccount.createCloudBlobClient();

            // Retrieve reference to a previously created container.
            CloudBlobContainer container = blobClient.getContainerReference("mycontainer");

            Iterable<ListBlobItem> blobItems = container.listBlobs( "csvs",  true);



            String localPath = rootLocalPath;
            // Loop through each blob item in the container.
            for (ListBlobItem blobItem : blobItems) {
                // If the item is a blob, not a virtual directory.

                System.out.println(blobItem.getUri());
                System.out.println(blobItem.getParent().getPrefix());
                String path =blobItem.getParent().getPrefix();
                int count = path.length() - path.replace("/", "").length();
                System.out.println(count);

                if(count > 1) {
                    //
                    String pathToBuild = path.substring(path.indexOf("/"));
                    System.out.println(pathToBuild);

                    new File(localPath+pathToBuild ).mkdirs();
                    localPath = localPath+pathToBuild;
                }
                 if (blobItem instanceof CloudBlob) {
                // Download the item and save it to a file with the same name.
                    CloudBlob blob = (CloudBlob) blobItem;
                    String fileName= Paths.get(blob.getName()).getFileName().toString();
                    try (OutputStream os = new FileOutputStream(localPath+ fileName)){
                         blob.download(os);
                     }
                }
            }
        } catch (Exception e) {
            // Output the stack trace.
            e.printStackTrace();
        }


        File folder =  new File(rootLocalPath);
        File[] listOfFiles = folder.listFiles();
        StringBuilder vendorKeyBuilder = new StringBuilder();
        try {
            for (File file : listOfFiles) {
                if (file.isFile()) {
                    try (InputStream in = new FileInputStream(file);BufferedReader reader = new BufferedReader(new InputStreamReader(in))) {
                        String line;
                        while ((line = reader.readLine()) != null) {
                            vendorKeyBuilder.append(line).append(",");
                        }
                    }
                    //file.delete();
                }
            }
            if (vendorKeyBuilder.length()>0) {
                vendorKeyBuilder.deleteCharAt(vendorKeyBuilder.length() - 1);
            }
            delete(folder);
            System.out.println(vendorKeyBuilder.toString());
        } catch (Exception e) {

        }


    }
    private static void delete(File file) throws IOException {

        for (File childFile : file.listFiles()) {

            if (childFile.isDirectory()) {
                delete(childFile);
            } else {
                if (!childFile.delete()) {
                    throw new IOException();
                }
            }
        }

        if (!file.delete()) {
            throw new IOException();
        }
    }

    public static void deleteBlob() {
        try
        {
            // Retrieve storage account from connection-string.
            CloudStorageAccount storageAccount = CloudStorageAccount.parse(storageConnectionString);

            // Create the blob client.
            CloudBlobClient blobClient = storageAccount.createCloudBlobClient();

            // Retrieve reference to a previously created container.
            CloudBlobContainer container = blobClient.getContainerReference("mycontainer");

            // Retrieve reference to a blob named "myimage.jpg".
            CloudBlockBlob blob = container.getBlockBlobReference("csvs");

            // Delete the blob.
          //  blob.deleteIfExists();
            blob.delete();
            System.out.println("blob deleted successfully");

        }catch (Exception e){
            // Output the stack trace.
            e.printStackTrace();
        }
    }
    public static void deleteBlobDirectory() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
        try
        {
            // Retrieve storage account from connection-string.
            CloudStorageAccount storageAccount = CloudStorageAccount.parse(storageConnectionString);

            // Create the blob client.
            CloudBlobClient blobClient = storageAccount.createCloudBlobClient();

            // Retrieve reference to a previously created container.
            CloudBlobContainer container = blobClient.getContainerReference("mycontainer");

            Iterable<ListBlobItem> blobItems = container.listBlobs( "csvs",  true);
            LocalDate today = LocalDate.now();
            // Loop through each blob item in the container.
            for (ListBlobItem blobItem : blobItems) {
                String fullPath = blobItem.getParent().getPrefix();
                String [] folderArray = fullPath.split("/");
                for (String folder : folderArray){
                    LocalDate date = null;
                    try {
                        date = LocalDate.parse(folder, formatter);
                    } catch(DateTimeParseException e){

                    }
                    if (date != null && ChronoUnit.DAYS.between(date, today) >= 2) {
                        Iterable<ListBlobItem> blobItems1 = container.listBlobs( fullPath,  true);
                        for (ListBlobItem blobItem1 : blobItems1) {
                            if (blobItem1 instanceof CloudBlob) {
                                CloudBlob blob = (CloudBlob) blobItem;
                                System.out.println("delete it... " + blob.getName());
                                blob.deleteIfExists();
                            }
                        }

                    }
                }
          }

        }catch (Exception e){
            // Output the stack trace.
            e.printStackTrace();
        }
    }
    public void deleteBlobContainer () {
        try
        {
            // Retrieve storage account from connection-string.
            CloudStorageAccount storageAccount = CloudStorageAccount.parse(storageConnectionString);

            // Create the blob client.
            CloudBlobClient blobClient = storageAccount.createCloudBlobClient();

            // Retrieve reference to a previously created container.
            CloudBlobContainer container = blobClient.getContainerReference("mycontainer");

            // Delete the blob container.
            container.deleteIfExists();
        }
        catch (Exception e)
        {
            // Output the stack trace.
            e.printStackTrace();
        }
    }
}
