package com.cron.scheduler;

import io.vertx.core.Vertx;
import io.vertx.core.eventbus.EventBus;
import io.vertx.core.eventbus.MessageConsumer;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;

public class CronTimer {

    static void scheduling(Vertx vertx) {
        EventBus eventBus = vertx.eventBus();
        // Consumer of the timer events
        MessageConsumer<JsonObject> consumer = eventBus.consumer("scheduler:timer");
        // Listens and prints timer events. When timer completes stops the Vertx
        consumer.handler (
                message -> {
                    JsonObject event = message.body();
                    if (event.getString("event").equals("complete")) {
                        System.out.println("completed");
                        vertx.close();
                    }
                    else {
                        System.out.println(event);
                    }
                }
        );
        JsonObject mondayTimer = (new JsonObject()).put("type", "cron")
                .put("seconds", "0").put("minutes", "30").put("hours", "8")
                .put("days of month", "*").put("months", "*")
                .put("days of week", "Monday");

        JsonObject fridayTimer = (new JsonObject()).put("type", "cron")
                .put("seconds", "0").put("minutes", "30").put("hours", "17")
                .put("days of month", "*").put("months", "*")
                .put("days of week", "Friday");

        JsonArray combination = (new JsonArray()).add(mondayTimer).add(fridayTimer);
        JsonObject timer = (new JsonObject()).put("type", "cron").put("timers", combination);
        // Create new timer
        /*eventBus.send (
                "chime",
                (new JsonObject()).put("operation", "create").put("name", "scheduler:timer")
                     .put("description", timer),
                ar -> {
                      if (ar.succeeded()) {
                             System.out.println("Scheduling started: " + ar.result().body());
                      }
                      else {
                             System.out.println("Message failed: " + ar.cause());
                             vertx.close();
                      }
                }
         );*/
       /* eventBus.send (
               "chime",
               (new JsonObject()).put("operation", "create").put("name", "scheduler:timer")
                     .put("description", (new JsonObject())
                    		 .put("type", "cron")
                    		 .put("seconds", "0")
                    		 .put("minutes", "19")
                    		 .put("hours", "18")
                    		 .put("days of month", "*")
                    		 .put("months", "*")
                    		 .put("days of week", "Monday,Tuesday")
                     		 ),
               ar -> {
                     if (ar.succeeded()) {
                            System.out.println("Scheduling started: " + ar.result().body());
                     }
                     else {
                            System.out.println("Message failed: " + ar.cause());
                            vertx.close();
                     }
               }
        );*/
        // run on every minute at 8 second on monday and tuesday , year 2017
        /*eventBus.send (
                "chime",
                (new JsonObject()).put("operation", "create").put("name", "scheduler:timer")
                      .put("description", (new JsonObject())
                     		 .put("type", "cron")
                     		 .put("seconds", "08")
                     		 .put("minutes", "*")
                     		 .put("hours", "*")
                     		 .put("days of month", "*")
                     		 .put("months", "*")
                     		 .put("days of week", "Tuesday,Monday")
                     		.put("years", "2017")
                      		 ),
                ar -> {
                      if (ar.succeeded()) {
                             System.out.println("Scheduling started: " + ar.result().body());
                      }
                      else {
                             System.out.println("Message failed: " + ar.cause());
                             vertx.close();
                      }
                }
         );*/
        eventBus.send (
                "chime",
                (new JsonObject()).put("operation", "create").put("name", "scheduler:timer")
                        .put("description", (new JsonObject())
                                .put("type", "cron")
                                .put("seconds", "*")
                                .put("minutes", "36")
                                .put("hours", "*")
                                .put("days of month", "*")
                                .put("months", "*")
                                .put("days of week", "Monday,Tuesday")
                                .put("years", "2017")
                        ),
                ar -> {
                    if (ar.succeeded()) {
                        System.out.println("Scheduling started: " + ar.result().body());
                    }
                    else {
                        System.out.println("Message failed: " + ar.cause());
                        vertx.close();
                    }
                }
        );

    }

    public static void main(String[] args) {
        Vertx vertx = Vertx.vertx();
        // deploying Chime
        vertx.deployVerticle("ceylon:herd.schedule.chime/0.2.0", res -> {
            if (res.succeeded()) {
                // Chime has been successfully deployed - start scheduling
                scheduling(vertx);
            } else {
                System.out.println("Deployment failed! " + res.cause());
                vertx.close();
            }
        });
    }

}

