
select a.username
,a.machinename
,a.machineid
,a.ipaddress
,a.domainname
,a.pcmlogeventid
,a.modulename
,a.filename
,a.productname
,a.companyname
,a.description
,a.text
,a.activetime
,a.datetime
,from_unixtime(unix_timestamp(substr(DateTime,1,19), 'yyyy-MM-dd HH:mm:ss'),'yyyy-MM-dd HH:00:00') as TimeSlot
,cast(to_date(from_unixtime(unix_timestamp(substr(DateTime,1,10), 'yyyy-MM-dd'),'yyyy-MM-dd')) as date) as Date
from ApplicationSwitchData asj
LATERAL VIEW json_tuple (asj.json,'UserName','MachineName','MachineID','IPAddress','DomainName','PCMLogEventID','ModuleName','FileName','ProductName','CompanyName','Description','Text','ActiveTime','DateTime')a
as username,machinename,machineid,ipaddress,domainname,pcmlogeventid,modulename,filename,productname,companyname,description,text,activetime,datetime;

INFO  : Compiling command(queryId=hive_20170517023636_38a9cc9d-489f-42d2-9a4c-48aaf174e565): select a.username
,a.machinename
,a.machineid
,a.ipaddress
,a.domainname
,a.pcmlogeventid
,a.modulename
,a.filename
,a.productname
,a.companyname
,a.description
,a.text
,a.activetime
,a.datetime
,from_unixtime(unix_timestamp(substr(DateTime,1,19), 'yyyy-MM-dd HH:mm:ss'),'yyyy-MM-dd HH:00:00') as TimeSlot
,cast(to_date(from_unixtime(unix_timestamp(substr(DateTime,1,10), 'yyyy-MM-dd'),'yyyy-MM-dd')) as date) as Date
from ApplicationSwitchData asj
LATERAL VIEW json_tuple (asj.json,'UserName','MachineName','MachineID','IPAddress','DomainName','PCMLogEventID','ModuleName','FileName','ProductName','CompanyName','Description','Text','ActiveTime','DateTime')a
as username,machinename,machineid,ipaddress,domainname,pcmlogeventid,modulename,filename,productname,companyname,description,text,activetime,datetime
INFO  : Semantic Analysis Completed
INFO  : Returning Hive schema: Schema(fieldSchemas:[FieldSchema(name:a.username, type:string, comment:null), FieldSchema(name:a.machinename, type:string, comment:null), FieldSchema(name:a.machineid, type:string, comment:null), FieldSchema(name:a.ipaddress, type:string, comment:null), FieldSchema(name:a.domainname, type:string, comment:null), FieldSchema(name:a.pcmlogeventid, type:string, comment:null), FieldSchema(name:a.modulename, type:string, comment:null), FieldSchema(name:a.filename, type:string, comment:null), FieldSchema(name:a.productname, type:string, comment:null), FieldSchema(name:a.companyname, type:string, comment:null), FieldSchema(name:a.description, type:string, comment:null), FieldSchema(name:a.text, type:string, comment:null), FieldSchema(name:a.activetime, type:string, comment:null), FieldSchema(name:a.datetime, type:string, comment:null), FieldSchema(name:timeslot, type:string, comment:null), FieldSchema(name:date, type:date, comment:null)], properties:null)
INFO  : Completed compiling command(queryId=hive_20170517023636_38a9cc9d-489f-42d2-9a4c-48aaf174e565); Time taken: 0.105 seconds
INFO  : Executing command(queryId=hive_20170517023636_38a9cc9d-489f-42d2-9a4c-48aaf174e565): select a.username
,a.machinename
,a.machineid
,a.ipaddress
,a.domainname
,a.pcmlogeventid
,a.modulename
,a.filename
,a.productname
,a.companyname
,a.description
,a.text
,a.activetime
,a.datetime
,from_unixtime(unix_timestamp(substr(DateTime,1,19), 'yyyy-MM-dd HH:mm:ss'),'yyyy-MM-dd HH:00:00') as TimeSlot
,cast(to_date(from_unixtime(unix_timestamp(substr(DateTime,1,10), 'yyyy-MM-dd'),'yyyy-MM-dd')) as date) as Date
from ApplicationSwitchData asj
LATERAL VIEW json_tuple (asj.json,'UserName','MachineName','MachineID','IPAddress','DomainName','PCMLogEventID','ModuleName','FileName','ProductName','CompanyName','Description','Text','ActiveTime','DateTime')a
as username,machinename,machineid,ipaddress,domainname,pcmlogeventid,modulename,filename,productname,companyname,description,text,activetime,datetime
INFO  : Query ID = hive_20170517023636_38a9cc9d-489f-42d2-9a4c-48aaf174e565
INFO  : Total jobs = 1
INFO  : Launching Job 1 out of 1
INFO  : Starting task [Stage-1:MAPRED] in serial mode
INFO  : Number of reduce tasks is set to 0 since there's no reduce operator
INFO  : number of splits:104
INFO  : Submitting tokens for job: job_1493041409055_0074
INFO  : The url to track the job: http://mac55:8088/proxy/application_1493041409055_0074/
INFO  : Starting Job = job_1493041409055_0074, Tracking URL = http://mac55:8088/proxy/application_1493041409055_0074/
INFO  : Kill Command = /opt/cloudera/parcels/CDH-5.8.2-1.cdh5.8.2.p0.3/lib/hadoop/bin/hadoop job  -kill job_1493041409055_0074
INFO  : Hadoop job information for Stage-1: number of mappers: 104; number of reducers: 0
INFO  : 2017-05-17 02:36:54,871 Stage-1 map = 0%,  reduce = 0%
INFO  : 2017-05-17 02:37:14,792 Stage-1 map = 1%,  reduce = 0%, Cumulative CPU 84.67 sec
INFO  : 2017-05-17 02:37:21,943 Stage-1 map = 2%,  reduce = 0%, Cumulative CPU 96.12 sec
INFO  : 2017-05-17 02:37:32,158 Stage-1 map = 3%,  reduce = 0%, Cumulative CPU 115.73 sec
INFO  : 2017-05-17 02:37:52,577 Stage-1 map = 4%,  reduce = 0%, Cumulative CPU 147.08 sec
INFO  : 2017-05-17 02:38:10,934 Stage-1 map = 5%,  reduce = 0%, Cumulative CPU 163.49 sec
INFO  : 2017-05-17 02:38:25,205 Stage-1 map = 6%,  reduce = 0%, Cumulative CPU 176.02 sec
INFO  : 2017-05-17 02:38:31,318 Stage-1 map = 7%,  reduce = 0%, Cumulative CPU 181.8 sec
INFO  : 2017-05-17 02:38:46,600 Stage-1 map = 8%,  reduce = 0%, Cumulative CPU 196.11 sec
INFO  : 2017-05-17 02:39:09,014 Stage-1 map = 9%,  reduce = 0%, Cumulative CPU 220.04 sec
INFO  : 2017-05-17 02:39:12,071 Stage-1 map = 10%,  reduce = 0%, Cumulative CPU 222.77 sec
INFO  : 2017-05-17 02:39:18,183 Stage-1 map = 11%,  reduce = 0%, Cumulative CPU 228.46 sec
INFO  : 2017-05-17 02:39:31,426 Stage-1 map = 12%,  reduce = 0%, Cumulative CPU 254.83 sec
INFO  : 2017-05-17 02:40:07,091 Stage-1 map = 13%,  reduce = 0%, Cumulative CPU 290.97 sec
INFO  : 2017-05-17 02:40:12,184 Stage-1 map = 14%,  reduce = 0%, Cumulative CPU 296.67 sec
INFO  : 2017-05-17 02:40:24,417 Stage-1 map = 15%,  reduce = 0%, Cumulative CPU 319.96 sec
INFO  : 2017-05-17 02:40:30,532 Stage-1 map = 16%,  reduce = 0%, Cumulative CPU 326.77 sec
INFO  : 2017-05-17 02:40:40,735 Stage-1 map = 17%,  reduce = 0%, Cumulative CPU 336.73 sec
INFO  : 2017-05-17 02:40:55,053 Stage-1 map = 18%,  reduce = 0%, Cumulative CPU 364.93 sec
INFO  : 2017-05-17 02:40:57,090 Stage-1 map = 19%,  reduce = 0%, Cumulative CPU 366.21 sec
INFO  : 2017-05-17 02:41:05,252 Stage-1 map = 20%,  reduce = 0%, Cumulative CPU 377.88 sec
INFO  : 2017-05-17 02:41:10,351 Stage-1 map = 21%,  reduce = 0%, Cumulative CPU 397.56 sec
INFO  : 2017-05-17 02:41:16,480 Stage-1 map = 22%,  reduce = 0%, Cumulative CPU 409.27 sec
INFO  : 2017-05-17 02:41:57,228 Stage-1 map = 23%,  reduce = 0%, Cumulative CPU 472.89 sec
INFO  : 2017-05-17 02:42:10,473 Stage-1 map = 24%,  reduce = 0%, Cumulative CPU 496.78 sec
INFO  : 2017-05-17 02:42:12,513 Stage-1 map = 25%,  reduce = 0%, Cumulative CPU 500.26 sec
INFO  : 2017-05-17 02:42:18,623 Stage-1 map = 26%,  reduce = 0%, Cumulative CPU 504.7 sec
INFO  : 2017-05-17 02:42:29,831 Stage-1 map = 27%,  reduce = 0%, Cumulative CPU 520.38 sec
INFO  : 2017-05-17 02:42:30,849 Stage-1 map = 28%,  reduce = 0%, Cumulative CPU 521.61 sec
INFO  : 2017-05-17 02:42:38,993 Stage-1 map = 29%,  reduce = 0%, Cumulative CPU 532.83 sec
INFO  : 2017-05-17 02:43:06,493 Stage-1 map = 30%,  reduce = 0%, Cumulative CPU 558.45 sec
INFO  : 2017-05-17 02:43:08,532 Stage-1 map = 31%,  reduce = 0%, Cumulative CPU 559.62 sec
INFO  : 2017-05-17 02:43:15,663 Stage-1 map = 32%,  reduce = 0%, Cumulative CPU 567.45 sec
INFO  : 2017-05-17 02:43:20,757 Stage-1 map = 33%,  reduce = 0%, Cumulative CPU 577.5 sec
INFO  : 2017-05-17 02:43:50,299 Stage-1 map = 34%,  reduce = 0%, Cumulative CPU 623.46 sec
INFO  : 2017-05-17 02:44:00,484 Stage-1 map = 35%,  reduce = 0%, Cumulative CPU 638.16 sec
INFO  : 2017-05-17 02:44:05,575 Stage-1 map = 36%,  reduce = 0%, Cumulative CPU 643.39 sec
INFO  : 2017-05-17 02:44:15,766 Stage-1 map = 37%,  reduce = 0%, Cumulative CPU 656.89 sec
INFO  : 2017-05-17 02:44:17,803 Stage-1 map = 38%,  reduce = 0%, Cumulative CPU 660.7 sec
INFO  : 2017-05-17 02:44:35,119 Stage-1 map = 39%,  reduce = 0%, Cumulative CPU 686.6 sec
INFO  : 2017-05-17 02:44:42,263 Stage-1 map = 40%,  reduce = 0%, Cumulative CPU 695.94 sec
INFO  : 2017-05-17 02:44:46,360 Stage-1 map = 41%,  reduce = 0%, Cumulative CPU 708.08 sec
INFO  : 2017-05-17 02:44:49,449 Stage-1 map = 42%,  reduce = 0%, Cumulative CPU 712.88 sec
INFO  : 2017-05-17 02:45:02,736 Stage-1 map = 43%,  reduce = 0%, Cumulative CPU 757.01 sec
INFO  : 2017-05-17 02:45:14,983 Stage-1 map = 44%,  reduce = 0%, Cumulative CPU 776.02 sec
INFO  : 2017-05-17 02:45:25,167 Stage-1 map = 45%,  reduce = 0%, Cumulative CPU 785.95 sec
INFO  : 2017-05-17 02:45:38,430 Stage-1 map = 46%,  reduce = 0%, Cumulative CPU 814.52 sec
INFO  : 2017-05-17 02:45:40,468 Stage-1 map = 47%,  reduce = 0%, Cumulative CPU 819.67 sec
INFO  : 2017-05-17 02:45:49,667 Stage-1 map = 48%,  reduce = 0%, Cumulative CPU 839.81 sec
INFO  : 2017-05-17 02:45:53,743 Stage-1 map = 49%,  reduce = 0%, Cumulative CPU 846.45 sec
INFO  : 2017-05-17 02:46:01,890 Stage-1 map = 50%,  reduce = 0%, Cumulative CPU 853.72 sec
INFO  : 2017-05-17 02:46:12,118 Stage-1 map = 51%,  reduce = 0%, Cumulative CPU 875.07 sec
INFO  : 2017-05-17 02:46:15,177 Stage-1 map = 52%,  reduce = 0%, Cumulative CPU 877.64 sec
INFO  : 2017-05-17 02:46:21,294 Stage-1 map = 53%,  reduce = 0%, Cumulative CPU 900.83 sec
INFO  : 2017-05-17 02:46:34,534 Stage-1 map = 54%,  reduce = 0%, Cumulative CPU 915.77 sec
INFO  : 2017-05-17 02:46:52,870 Stage-1 map = 55%,  reduce = 0%, Cumulative CPU 935.41 sec
INFO  : 2017-05-17 02:47:04,083 Stage-1 map = 56%,  reduce = 0%, Cumulative CPU 944.9 sec
INFO  : 2017-05-17 02:47:10,193 Stage-1 map = 57%,  reduce = 0%, Cumulative CPU 953.43 sec
INFO  : 2017-05-17 02:47:28,529 Stage-1 map = 58%,  reduce = 0%, Cumulative CPU 987.71 sec
INFO  : 2017-05-17 02:47:34,641 Stage-1 map = 59%,  reduce = 0%, Cumulative CPU 998.06 sec
INFO  : 2017-05-17 02:47:57,049 Stage-1 map = 60%,  reduce = 0%, Cumulative CPU 1024.57 sec
INFO  : 2017-05-17 02:48:05,194 Stage-1 map = 61%,  reduce = 0%, Cumulative CPU 1033.36 sec
INFO  : 2017-05-17 02:48:10,287 Stage-1 map = 62%,  reduce = 0%, Cumulative CPU 1038.28 sec
INFO  : 2017-05-17 02:48:17,424 Stage-1 map = 63%,  reduce = 0%, Cumulative CPU 1045.66 sec
INFO  : 2017-05-17 02:48:25,571 Stage-1 map = 64%,  reduce = 0%, Cumulative CPU 1061.41 sec
INFO  : 2017-05-17 02:48:32,721 Stage-1 map = 65%,  reduce = 0%, Cumulative CPU 1072.53 sec
INFO  : 2017-05-17 02:48:42,934 Stage-1 map = 66%,  reduce = 0%, Cumulative CPU 1097.6 sec
INFO  : 2017-05-17 02:48:45,997 Stage-1 map = 67%,  reduce = 0%, Cumulative CPU 1108.03 sec
INFO  : 2017-05-17 02:48:59,265 Stage-1 map = 68%,  reduce = 0%, Cumulative CPU 1136.95 sec
INFO  : 2017-05-17 02:49:10,478 Stage-1 map = 69%,  reduce = 0%, Cumulative CPU 1147.74 sec
INFO  : 2017-05-17 02:49:13,531 Stage-1 map = 70%,  reduce = 0%, Cumulative CPU 1150.64 sec
INFO  : 2017-05-17 02:49:56,308 Stage-1 map = 71%,  reduce = 0%, Cumulative CPU 1196.86 sec
INFO  : 2017-05-17 02:50:02,420 Stage-1 map = 72%,  reduce = 0%, Cumulative CPU 1205.94 sec
INFO  : 2017-05-17 02:50:16,709 Stage-1 map = 73%,  reduce = 0%, Cumulative CPU 1227.41 sec
INFO  : 2017-05-17 02:50:20,784 Stage-1 map = 75%,  reduce = 0%, Cumulative CPU 1231.04 sec
INFO  : 2017-05-17 02:50:38,121 Stage-1 map = 76%,  reduce = 0%, Cumulative CPU 1263.8 sec
INFO  : 2017-05-17 02:50:44,234 Stage-1 map = 77%,  reduce = 0%, Cumulative CPU 1270.05 sec
INFO  : 2017-05-17 02:51:03,588 Stage-1 map = 78%,  reduce = 0%, Cumulative CPU 1288.65 sec
INFO  : 2017-05-17 02:51:11,747 Stage-1 map = 79%,  reduce = 0%, Cumulative CPU 1307.14 sec
INFO  : 2017-05-17 02:51:12,766 Stage-1 map = 80%,  reduce = 0%, Cumulative CPU 1310.09 sec
INFO  : 2017-05-17 02:51:19,904 Stage-1 map = 81%,  reduce = 0%, Cumulative CPU 1323.94 sec
INFO  : 2017-05-17 02:51:43,335 Stage-1 map = 82%,  reduce = 0%, Cumulative CPU 1358.06 sec
INFO  : 2017-05-17 02:51:49,459 Stage-1 map = 83%,  reduce = 0%, Cumulative CPU 1368.83 sec
INFO  : 2017-05-17 02:51:51,497 Stage-1 map = 84%,  reduce = 0%, Cumulative CPU 1371.16 sec
INFO  : 2017-05-17 02:51:55,575 Stage-1 map = 85%,  reduce = 0%, Cumulative CPU 1381.88 sec
INFO  : 2017-05-17 02:52:05,759 Stage-1 map = 86%,  reduce = 0%, Cumulative CPU 1404.96 sec
INFO  : 2017-05-17 02:52:11,870 Stage-1 map = 87%,  reduce = 0%, Cumulative CPU 1411.27 sec
INFO  : 2017-05-17 02:52:32,241 Stage-1 map = 88%,  reduce = 0%, Cumulative CPU 1442.06 sec
INFO  : 2017-05-17 02:52:44,486 Stage-1 map = 89%,  reduce = 0%, Cumulative CPU 1455.89 sec
INFO  : 2017-05-17 02:52:49,592 Stage-1 map = 90%,  reduce = 0%, Cumulative CPU 1477.29 sec
INFO  : 2017-05-17 02:52:54,693 Stage-1 map = 91%,  reduce = 0%, Cumulative CPU 1483.12 sec
INFO  : 2017-05-17 02:53:12,008 Stage-1 map = 92%,  reduce = 0%, Cumulative CPU 1502.32 sec
INFO  : 2017-05-17 02:53:21,178 Stage-1 map = 93%,  reduce = 0%, Cumulative CPU 1511.18 sec
INFO  : 2017-05-17 02:53:32,385 Stage-1 map = 94%,  reduce = 0%, Cumulative CPU 1521.95 sec
INFO  : 2017-05-17 02:53:37,475 Stage-1 map = 95%,  reduce = 0%, Cumulative CPU 1525.13 sec
INFO  : 2017-05-17 02:53:41,550 Stage-1 map = 96%,  reduce = 0%, Cumulative CPU 1528.13 sec
INFO  : 2017-05-17 02:53:46,639 Stage-1 map = 97%,  reduce = 0%, Cumulative CPU 1530.85 sec
INFO  : 2017-05-17 02:53:56,830 Stage-1 map = 98%,  reduce = 0%, Cumulative CPU 1540.7 sec
INFO  : 2017-05-17 02:54:21,286 Stage-1 map = 99%,  reduce = 0%, Cumulative CPU 1556.36 sec
INFO  : 2017-05-17 02:54:25,358 Stage-1 map = 100%,  reduce = 0%, Cumulative CPU 1558.78 sec
INFO  : MapReduce Total cumulative CPU time: 25 minutes 58 seconds 780 msec
INFO  : Ended Job = job_1493041409055_0074
INFO  : MapReduce Jobs Launched: 
INFO  : Stage-Stage-1: Map: 104   Cumulative CPU: 1558.78 sec   HDFS Read: 28334727858 HDFS Write: 20058776589 SUCCESS
INFO  : Total MapReduce CPU Time Spent: 25 minutes 58 seconds 780 msec
INFO  : Completed executing command(queryId=hive_20170517023636_38a9cc9d-489f-42d2-9a4c-48aaf174e565); Time taken: 1059.493 seconds
INFO  : OK

=============================================================================================================

select a.username
,a.machinename
,a.machineid
,a.ipaddress
,a.domainname
,a.pcmlogeventid
,a.modulename
,a.filename
,a.productname
,a.companyname
,a.description
,a.text
,a.activetime
,a.datetime
,from_unixtime(unix_timestamp(substr(DateTime,1,19), 'yyyy-MM-dd HH:mm:ss'),'yyyy-MM-dd HH:00:00') as TimeSlot
,cast(to_date(from_unixtime(unix_timestamp(substr(DateTime,1,10), 'yyyy-MM-dd'),'yyyy-MM-dd')) as date) as Date 
from
(
select json_tuple (asj.json,'UserName','MachineName','MachineID','IPAddress','DomainName','PCMLogEventID','ModuleName','FileName','ProductName','CompanyName','Description','Text','ActiveTime','DateTime')
as (username,machinename,machineid,ipaddress,domainname,pcmlogeventid,modulename,filename,productname,companyname,description,text,activetime,datetime)
from applicationswitchdata asj) a


INFO  : Compiling command(queryId=hive_20170517021212_f3795f7a-2d7e-42ee-b9d3-3ce906b7b845): select a.username
,a.machinename
,a.machineid
,a.ipaddress
,a.domainname
,a.pcmlogeventid
,a.modulename
,a.filename
,a.productname
,a.companyname
,a.description
,a.text
,a.activetime
,a.datetime
,from_unixtime(unix_timestamp(substr(DateTime,1,19), 'yyyy-MM-dd HH:mm:ss'),'yyyy-MM-dd HH:00:00') as TimeSlot
,cast(to_date(from_unixtime(unix_timestamp(substr(DateTime,1,10), 'yyyy-MM-dd'),'yyyy-MM-dd')) as date) as Date 
from
(
select json_tuple (asj.json,'UserName','MachineName','MachineID','IPAddress','DomainName','PCMLogEventID','ModuleName','FileName','ProductName','CompanyName','Description','Text','ActiveTime','DateTime')
as (username,machinename,machineid,ipaddress,domainname,pcmlogeventid,modulename,filename,productname,companyname,description,text,activetime,datetime)
from applicationswitchdata asj) a
INFO  : Semantic Analysis Completed
INFO  : Returning Hive schema: Schema(fieldSchemas:[FieldSchema(name:a.username, type:string, comment:null), FieldSchema(name:a.machinename, type:string, comment:null), FieldSchema(name:a.machineid, type:string, comment:null), FieldSchema(name:a.ipaddress, type:string, comment:null), FieldSchema(name:a.domainname, type:string, comment:null), FieldSchema(name:a.pcmlogeventid, type:string, comment:null), FieldSchema(name:a.modulename, type:string, comment:null), FieldSchema(name:a.filename, type:string, comment:null), FieldSchema(name:a.productname, type:string, comment:null), FieldSchema(name:a.companyname, type:string, comment:null), FieldSchema(name:a.description, type:string, comment:null), FieldSchema(name:a.text, type:string, comment:null), FieldSchema(name:a.activetime, type:string, comment:null), FieldSchema(name:a.datetime, type:string, comment:null), FieldSchema(name:timeslot, type:string, comment:null), FieldSchema(name:date, type:date, comment:null)], properties:null)
INFO  : Completed compiling command(queryId=hive_20170517021212_f3795f7a-2d7e-42ee-b9d3-3ce906b7b845); Time taken: 0.128 seconds
INFO  : Executing command(queryId=hive_20170517021212_f3795f7a-2d7e-42ee-b9d3-3ce906b7b845): select a.username
,a.machinename
,a.machineid
,a.ipaddress
,a.domainname
,a.pcmlogeventid
,a.modulename
,a.filename
,a.productname
,a.companyname
,a.description
,a.text
,a.activetime
,a.datetime
,from_unixtime(unix_timestamp(substr(DateTime,1,19), 'yyyy-MM-dd HH:mm:ss'),'yyyy-MM-dd HH:00:00') as TimeSlot
,cast(to_date(from_unixtime(unix_timestamp(substr(DateTime,1,10), 'yyyy-MM-dd'),'yyyy-MM-dd')) as date) as Date 
from
(
select json_tuple (asj.json,'UserName','MachineName','MachineID','IPAddress','DomainName','PCMLogEventID','ModuleName','FileName','ProductName','CompanyName','Description','Text','ActiveTime','DateTime')
as (username,machinename,machineid,ipaddress,domainname,pcmlogeventid,modulename,filename,productname,companyname,description,text,activetime,datetime)
from applicationswitchdata asj) a
INFO  : Query ID = hive_20170517021212_f3795f7a-2d7e-42ee-b9d3-3ce906b7b845
INFO  : Total jobs = 1
INFO  : Launching Job 1 out of 1
INFO  : Starting task [Stage-1:MAPRED] in serial mode
INFO  : Number of reduce tasks is set to 0 since there's no reduce operator
INFO  : number of splits:104
INFO  : Submitting tokens for job: job_1493041409055_0073
INFO  : The url to track the job: http://mac55:8088/proxy/application_1493041409055_0073/
INFO  : Starting Job = job_1493041409055_0073, Tracking URL = http://mac55:8088/proxy/application_1493041409055_0073/
INFO  : Kill Command = /opt/cloudera/parcels/CDH-5.8.2-1.cdh5.8.2.p0.3/lib/hadoop/bin/hadoop job  -kill job_1493041409055_0073
INFO  : Hadoop job information for Stage-1: number of mappers: 104; number of reducers: 0
INFO  : 2017-05-17 02:12:46,263 Stage-1 map = 0%,  reduce = 0%
INFO  : 2017-05-17 02:13:07,087 Stage-1 map = 1%,  reduce = 0%, Cumulative CPU 91.74 sec
INFO  : 2017-05-17 02:13:10,156 Stage-1 map = 2%,  reduce = 0%, Cumulative CPU 99.75 sec
INFO  : 2017-05-17 02:13:20,405 Stage-1 map = 3%,  reduce = 0%, Cumulative CPU 116.32 sec
INFO  : 2017-05-17 02:13:29,613 Stage-1 map = 4%,  reduce = 0%, Cumulative CPU 128.2 sec
INFO  : 2017-05-17 02:13:42,946 Stage-1 map = 5%,  reduce = 0%, Cumulative CPU 155.11 sec
INFO  : 2017-05-17 02:14:12,516 Stage-1 map = 6%,  reduce = 0%, Cumulative CPU 182.76 sec
INFO  : 2017-05-17 02:14:13,536 Stage-1 map = 7%,  reduce = 0%, Cumulative CPU 183.34 sec
INFO  : 2017-05-17 02:14:21,689 Stage-1 map = 8%,  reduce = 0%, Cumulative CPU 191.75 sec
INFO  : 2017-05-17 02:14:45,122 Stage-1 map = 9%,  reduce = 0%, Cumulative CPU 214.1 sec
INFO  : 2017-05-17 02:14:52,254 Stage-1 map = 10%,  reduce = 0%, Cumulative CPU 222.09 sec
INFO  : 2017-05-17 02:15:03,475 Stage-1 map = 11%,  reduce = 0%, Cumulative CPU 240.19 sec
INFO  : 2017-05-17 02:15:12,661 Stage-1 map = 12%,  reduce = 0%, Cumulative CPU 256.9 sec
INFO  : 2017-05-17 02:15:16,741 Stage-1 map = 13%,  reduce = 0%, Cumulative CPU 267.05 sec
INFO  : 2017-05-17 02:15:22,873 Stage-1 map = 14%,  reduce = 0%, Cumulative CPU 271.75 sec
INFO  : 2017-05-17 02:15:38,155 Stage-1 map = 15%,  reduce = 0%, Cumulative CPU 313.05 sec
INFO  : 2017-05-17 02:15:46,336 Stage-1 map = 16%,  reduce = 0%, Cumulative CPU 329.26 sec
INFO  : 2017-05-17 02:16:11,862 Stage-1 map = 17%,  reduce = 0%, Cumulative CPU 372.31 sec
INFO  : 2017-05-17 02:16:20,018 Stage-1 map = 18%,  reduce = 0%, Cumulative CPU 380.49 sec
INFO  : 2017-05-17 02:16:25,119 Stage-1 map = 19%,  reduce = 0%, Cumulative CPU 384.41 sec
INFO  : 2017-05-17 02:16:36,354 Stage-1 map = 20%,  reduce = 0%, Cumulative CPU 403.64 sec
INFO  : 2017-05-17 02:16:54,711 Stage-1 map = 21%,  reduce = 0%, Cumulative CPU 425.56 sec
INFO  : 2017-05-17 02:17:02,861 Stage-1 map = 22%,  reduce = 0%, Cumulative CPU 433.61 sec
INFO  : 2017-05-17 02:17:05,917 Stage-1 map = 23%,  reduce = 0%, Cumulative CPU 436.62 sec
INFO  : 2017-05-17 02:17:15,089 Stage-1 map = 24%,  reduce = 0%, Cumulative CPU 462.48 sec
INFO  : 2017-05-17 02:17:20,183 Stage-1 map = 25%,  reduce = 0%, Cumulative CPU 473.82 sec
INFO  : 2017-05-17 02:17:47,693 Stage-1 map = 26%,  reduce = 0%, Cumulative CPU 507.88 sec
INFO  : 2017-05-17 02:17:52,789 Stage-1 map = 27%,  reduce = 0%, Cumulative CPU 513.58 sec
INFO  : 2017-05-17 02:18:00,938 Stage-1 map = 28%,  reduce = 0%, Cumulative CPU 523.25 sec
INFO  : 2017-05-17 02:18:09,088 Stage-1 map = 29%,  reduce = 0%, Cumulative CPU 531.82 sec
INFO  : 2017-05-17 02:18:12,156 Stage-1 map = 30%,  reduce = 0%, Cumulative CPU 535.83 sec
INFO  : 2017-05-17 02:18:22,421 Stage-1 map = 31%,  reduce = 0%, Cumulative CPU 554.65 sec
INFO  : 2017-05-17 02:18:27,531 Stage-1 map = 32%,  reduce = 0%, Cumulative CPU 569.24 sec
INFO  : 2017-05-17 02:18:36,702 Stage-1 map = 33%,  reduce = 0%, Cumulative CPU 584.02 sec
INFO  : 2017-05-17 02:18:51,987 Stage-1 map = 34%,  reduce = 0%, Cumulative CPU 607.74 sec
INFO  : 2017-05-17 02:18:58,105 Stage-1 map = 35%,  reduce = 0%, Cumulative CPU 627.29 sec
INFO  : 2017-05-17 02:19:07,278 Stage-1 map = 36%,  reduce = 0%, Cumulative CPU 637.34 sec
INFO  : 2017-05-17 02:19:13,397 Stage-1 map = 37%,  reduce = 0%, Cumulative CPU 655.53 sec
INFO  : 2017-05-17 02:19:31,779 Stage-1 map = 38%,  reduce = 0%, Cumulative CPU 686.71 sec
INFO  : 2017-05-17 02:19:41,965 Stage-1 map = 39%,  reduce = 0%, Cumulative CPU 695.43 sec
INFO  : 2017-05-17 02:19:58,273 Stage-1 map = 40%,  reduce = 0%, Cumulative CPU 718.33 sec
INFO  : 2017-05-17 02:20:00,311 Stage-1 map = 41%,  reduce = 0%, Cumulative CPU 722.18 sec
INFO  : 2017-05-17 02:20:02,349 Stage-1 map = 42%,  reduce = 0%, Cumulative CPU 723.99 sec
INFO  : 2017-05-17 02:20:08,496 Stage-1 map = 43%,  reduce = 0%, Cumulative CPU 731.14 sec
INFO  : 2017-05-17 02:20:16,643 Stage-1 map = 44%,  reduce = 0%, Cumulative CPU 749.63 sec
INFO  : 2017-05-17 02:20:28,902 Stage-1 map = 45%,  reduce = 0%, Cumulative CPU 777.3 sec
INFO  : 2017-05-17 02:20:31,960 Stage-1 map = 46%,  reduce = 0%, Cumulative CPU 784.38 sec
INFO  : 2017-05-17 02:20:43,208 Stage-1 map = 47%,  reduce = 0%, Cumulative CPU 815.68 sec
INFO  : 2017-05-17 02:20:45,248 Stage-1 map = 48%,  reduce = 0%, Cumulative CPU 818.85 sec
INFO  : 2017-05-17 02:20:54,431 Stage-1 map = 49%,  reduce = 0%, Cumulative CPU 834.84 sec
INFO  : 2017-05-17 02:21:12,810 Stage-1 map = 50%,  reduce = 0%, Cumulative CPU 869.45 sec
INFO  : 2017-05-17 02:21:24,052 Stage-1 map = 51%,  reduce = 0%, Cumulative CPU 885.31 sec
INFO  : 2017-05-17 02:21:34,237 Stage-1 map = 52%,  reduce = 0%, Cumulative CPU 895.28 sec
INFO  : 2017-05-17 02:21:42,383 Stage-1 map = 53%,  reduce = 0%, Cumulative CPU 903.68 sec
INFO  : 2017-05-17 02:21:48,493 Stage-1 map = 54%,  reduce = 0%, Cumulative CPU 910.32 sec
INFO  : 2017-05-17 02:21:59,716 Stage-1 map = 55%,  reduce = 0%, Cumulative CPU 920.72 sec
INFO  : 2017-05-17 02:22:06,850 Stage-1 map = 56%,  reduce = 0%, Cumulative CPU 935.11 sec
INFO  : 2017-05-17 02:22:15,003 Stage-1 map = 57%,  reduce = 0%, Cumulative CPU 946.85 sec
INFO  : 2017-05-17 02:22:34,351 Stage-1 map = 58%,  reduce = 0%, Cumulative CPU 984.52 sec
INFO  : 2017-05-17 02:22:49,629 Stage-1 map = 59%,  reduce = 0%, Cumulative CPU 1002.18 sec
INFO  : 2017-05-17 02:22:54,719 Stage-1 map = 60%,  reduce = 0%, Cumulative CPU 1007.21 sec
INFO  : 2017-05-17 02:23:17,124 Stage-1 map = 61%,  reduce = 0%, Cumulative CPU 1029.35 sec
INFO  : 2017-05-17 02:23:21,197 Stage-1 map = 62%,  reduce = 0%, Cumulative CPU 1033.89 sec
INFO  : 2017-05-17 02:23:33,473 Stage-1 map = 63%,  reduce = 0%, Cumulative CPU 1054.5 sec
INFO  : 2017-05-17 02:23:39,620 Stage-1 map = 64%,  reduce = 0%, Cumulative CPU 1067.5 sec
INFO  : 2017-05-17 02:23:40,641 Stage-1 map = 65%,  reduce = 0%, Cumulative CPU 1070.75 sec
INFO  : 2017-05-17 02:23:52,873 Stage-1 map = 66%,  reduce = 0%, Cumulative CPU 1090.03 sec
INFO  : 2017-05-17 02:24:06,111 Stage-1 map = 67%,  reduce = 0%, Cumulative CPU 1116.07 sec
INFO  : 2017-05-17 02:24:22,408 Stage-1 map = 68%,  reduce = 0%, Cumulative CPU 1134.37 sec
INFO  : 2017-05-17 02:24:25,470 Stage-1 map = 69%,  reduce = 0%, Cumulative CPU 1138.74 sec
INFO  : 2017-05-17 02:24:34,663 Stage-1 map = 70%,  reduce = 0%, Cumulative CPU 1158.46 sec
INFO  : 2017-05-17 02:24:39,755 Stage-1 map = 71%,  reduce = 0%, Cumulative CPU 1163.14 sec
INFO  : 2017-05-17 02:24:45,913 Stage-1 map = 72%,  reduce = 0%, Cumulative CPU 1171.36 sec
INFO  : 2017-05-17 02:25:00,217 Stage-1 map = 73%,  reduce = 0%, Cumulative CPU 1205.61 sec
INFO  : 2017-05-17 02:25:23,661 Stage-1 map = 74%,  reduce = 0%, Cumulative CPU 1229.62 sec
INFO  : 2017-05-17 02:25:32,829 Stage-1 map = 75%,  reduce = 0%, Cumulative CPU 1237.49 sec
INFO  : 2017-05-17 02:25:37,925 Stage-1 map = 76%,  reduce = 0%, Cumulative CPU 1242.47 sec
INFO  : 2017-05-17 02:25:44,038 Stage-1 map = 77%,  reduce = 0%, Cumulative CPU 1260.93 sec
INFO  : 2017-05-17 02:25:49,134 Stage-1 map = 78%,  reduce = 0%, Cumulative CPU 1265.46 sec
INFO  : 2017-05-17 02:26:08,747 Stage-1 map = 79%,  reduce = 0%, Cumulative CPU 1303.81 sec
INFO  : 2017-05-17 02:26:12,825 Stage-1 map = 80%,  reduce = 0%, Cumulative CPU 1307.7 sec
INFO  : 2017-05-17 02:26:19,955 Stage-1 map = 82%,  reduce = 0%, Cumulative CPU 1321.89 sec
INFO  : 2017-05-17 02:26:25,054 Stage-1 map = 83%,  reduce = 0%, Cumulative CPU 1334.63 sec
INFO  : 2017-05-17 02:26:40,336 Stage-1 map = 84%,  reduce = 0%, Cumulative CPU 1360.61 sec
INFO  : 2017-05-17 02:26:55,617 Stage-1 map = 85%,  reduce = 0%, Cumulative CPU 1380.19 sec
INFO  : 2017-05-17 02:27:02,748 Stage-1 map = 86%,  reduce = 0%, Cumulative CPU 1388.2 sec
INFO  : 2017-05-17 02:27:04,788 Stage-1 map = 87%,  reduce = 0%, Cumulative CPU 1393.15 sec
INFO  : 2017-05-17 02:27:08,862 Stage-1 map = 88%,  reduce = 0%, Cumulative CPU 1397.59 sec
INFO  : 2017-05-17 02:27:28,232 Stage-1 map = 89%,  reduce = 0%, Cumulative CPU 1439.8 sec
INFO  : 2017-05-17 02:27:35,376 Stage-1 map = 90%,  reduce = 0%, Cumulative CPU 1458.68 sec
INFO  : 2017-05-17 02:27:39,451 Stage-1 map = 91%,  reduce = 0%, Cumulative CPU 1470.94 sec
INFO  : 2017-05-17 02:27:41,489 Stage-1 map = 92%,  reduce = 0%, Cumulative CPU 1475.13 sec
INFO  : 2017-05-17 02:27:59,822 Stage-1 map = 93%,  reduce = 0%, Cumulative CPU 1496.52 sec
INFO  : 2017-05-17 02:28:01,857 Stage-1 map = 94%,  reduce = 0%, Cumulative CPU 1497.73 sec
INFO  : 2017-05-17 02:28:08,988 Stage-1 map = 95%,  reduce = 0%, Cumulative CPU 1502.65 sec
INFO  : 2017-05-17 02:28:17,132 Stage-1 map = 96%,  reduce = 0%, Cumulative CPU 1507.13 sec
INFO  : 2017-05-17 02:28:23,240 Stage-1 map = 97%,  reduce = 0%, Cumulative CPU 1510.92 sec
INFO  : 2017-05-17 02:28:33,423 Stage-1 map = 98%,  reduce = 0%, Cumulative CPU 1517.23 sec
INFO  : 2017-05-17 02:28:52,769 Stage-1 map = 99%,  reduce = 0%, Cumulative CPU 1531.8 sec
INFO  : 2017-05-17 02:29:00,923 Stage-1 map = 100%,  reduce = 0%, Cumulative CPU 1536.8 sec
INFO  : MapReduce Total cumulative CPU time: 25 minutes 36 seconds 800 msec
INFO  : Ended Job = job_1493041409055_0073 
INFO  : MapReduce Jobs Launched: 
INFO  : Stage-Stage-1: Map: 104   Cumulative CPU: 1536.8 sec   HDFS Read: 28334612002 HDFS Write: 20058776589 SUCCESS
INFO  : Total MapReduce CPU Time Spent: 25 minutes 36 seconds 800 msec
INFO  : Completed executing command(queryId=hive_20170517021212_f3795f7a-2d7e-42ee-b9d3-3ce906b7b845); Time taken: 980.751 seconds
INFO  : OK