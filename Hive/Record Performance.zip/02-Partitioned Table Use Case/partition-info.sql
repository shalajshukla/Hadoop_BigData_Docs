select username,modulename,sum(activetime) from postimportformattedapplicationswitchdata
where date='2016-05-25'
group by username,modulename;


select username,modulename,sum(activetime) from postimportwithoutpart
where date='2016-05-25'
group by username,modulename;


select username,modulename,sum(activetime) from postimportformattedapplicationswitchdata
where date between'2016-05-25' and '2016-05-31'
group by username,modulename;

select username,modulename,sum(activetime) from postimportwithoutpart
where date between'2016-05-25' and '2016-05-31'
group by username,modulename;

hive> show partitions postimportformattedapplicationswitchdata;
OK
date=2016-05-25
date=2016-05-26
date=2016-05-27
date=2016-05-28
date=2016-05-30
date=2016-05-31
date=2016-06-01
date=2016-06-02
date=2016-06-03
date=2016-06-06
date=2016-06-07
date=2016-06-08
date=2016-06-09
date=2016-06-10
date=2016-06-11
date=2016-06-12
date=2016-06-13
date=2016-06-14
date=2016-06-15
date=2016-06-16
date=2016-06-17
date=2016-06-19
date=2016-06-20
date=2016-06-21
date=2016-06-22
date=2016-06-23
date=2016-06-24
date=2016-06-25
date=2016-06-26
date=2016-06-27
date=2016-06-28
date=2016-06-29
date=2016-06-30
date=2016-07-01
date=2016-07-02
date=2016-07-03
date=2016-07-04
date=2016-07-05
date=2016-07-06
date=2016-07-07
date=2016-07-08
date=2016-07-09
date=2016-07-10
date=2016-07-11
date=2016-07-12
date=2016-07-13
date=2016-07-14
date=2016-07-15
date=2016-07-16
date=2016-07-17
date=2016-07-18
date=2016-07-19
