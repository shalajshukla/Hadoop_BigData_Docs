CREATE TABLE TempApplication_text
(
UserName string,
MachineName string,
MachineID string,
IPAddress string,
DomainName string,
PCMLogEventID string,
ModuleName string,
FileName string,
ProductName string,
CompanyName string,
Description string,
Text string,
ActiveTime double,
DateTime timestamp,
TimeSlot timestamp,
Date Date
)

INSERT OVERWRITE TABLE TempApplication_text
select a.username
,a.machinename
,a.machineid
,a.ipaddress
,a.domainname
,a.pcmlogeventid
,a.modulename
,a.filename
,a.productname
,a.companyname
,a.description
,a.text
,a.activetime
,a.datetime
,from_unixtime(unix_timestamp(substr(DateTime,1,19), 'yyyy-MM-dd HH:mm:ss'),'yyyy-MM-dd HH:00:00') as TimeSlot
,cast(to_date(from_unixtime(unix_timestamp(substr(DateTime,1,10), 'yyyy-MM-dd'),'yyyy-MM-dd')) as date) as Date
from ApplicationSwitchData asj
LATERAL VIEW json_tuple (asj.json,'UserName','MachineName','MachineID','IPAddress','DomainName','PCMLogEventID','ModuleName','FileName','ProductName','CompanyName','Description','Text','ActiveTime','DateTime')a
as username,machinename,machineid,ipaddress,domainname,pcmlogeventid,modulename,filename,productname,companyname,description,text,activetime,datetime;

hive> dfs -du -s -h /user/hive/warehouse/esplus.db/tempapplication_text;
18.5 G  55.6 G  /user/hive/warehouse/esplus.db/tempapplication_text

create table TempApplication_orc like TempApplication_text stored as ORC tblproperties ("orc.compress"="ZLIB");
SET hive.exec.compress.output=true;
INSERT OVERWRITE TABLE TempApplication_orc select * from TempApplication_text

hive> INSERT OVERWRITE TABLE TempApplication_orc select * from TempApplication_text
    > ;
Query ID = root_20170414020000_7e59a3c7-fd65-44d0-a85d-9af14d8478b1
Total jobs = 1
Launching Job 1 out of 1
Number of reduce tasks is set to 0 since theres no reduce operator
Starting Job = job_1490094830773_0683, Tracking URL = http://mac55:8088/proxy/application_1490094830773_0683/
Kill Command = /opt/cloudera/parcels/CDH-5.8.2-1.cdh5.8.2.p0.3/lib/hadoop/bin/hadoop job  -kill job_1490094830773_0683
Hadoop job information for Stage-1: number of mappers: 63; number of reducers: 0
2017-04-14 02:01:00,297 Stage-1 map = 0%,  reduce = 0%
2017-04-14 02:01:11,714 Stage-1 map = 1%,  reduce = 0%, Cumulative CPU 16.62 sec
2017-04-14 02:01:14,790 Stage-1 map = 3%,  reduce = 0%, Cumulative CPU 56.85 sec
2017-04-14 02:01:15,838 Stage-1 map = 4%,  reduce = 0%, Cumulative CPU 74.35 sec
2017-04-14 02:01:16,863 Stage-1 map = 6%,  reduce = 0%, Cumulative CPU 85.41 sec
2017-04-14 02:01:18,909 Stage-1 map = 7%,  reduce = 0%, Cumulative CPU 95.62 sec
2017-04-14 02:01:19,931 Stage-1 map = 10%,  reduce = 0%, Cumulative CPU 104.48 sec
2017-04-14 02:01:20,957 Stage-1 map = 11%,  reduce = 0%, Cumulative CPU 111.54 sec
2017-04-14 02:01:22,013 Stage-1 map = 13%,  reduce = 0%, Cumulative CPU 115.34 sec
2017-04-14 02:01:23,099 Stage-1 map = 14%,  reduce = 0%, Cumulative CPU 125.8 sec
2017-04-14 02:01:24,166 Stage-1 map = 15%,  reduce = 0%, Cumulative CPU 129.81 sec
2017-04-14 02:01:26,223 Stage-1 map = 16%,  reduce = 0%, Cumulative CPU 145.2 sec
2017-04-14 02:01:27,273 Stage-1 map = 18%,  reduce = 0%, Cumulative CPU 148.56 sec
2017-04-14 02:01:28,309 Stage-1 map = 19%,  reduce = 0%, Cumulative CPU 154.36 sec
2017-04-14 02:01:29,367 Stage-1 map = 21%,  reduce = 0%, Cumulative CPU 161.75 sec
2017-04-14 02:01:33,775 Stage-1 map = 22%,  reduce = 0%, Cumulative CPU 173.12 sec
2017-04-14 02:01:37,108 Stage-1 map = 25%,  reduce = 0%, Cumulative CPU 201.0 sec
2017-04-14 02:01:39,191 Stage-1 map = 27%,  reduce = 0%, Cumulative CPU 217.96 sec
2017-04-14 02:01:40,221 Stage-1 map = 28%,  reduce = 0%, Cumulative CPU 222.83 sec
2017-04-14 02:01:43,335 Stage-1 map = 29%,  reduce = 0%, Cumulative CPU 234.19 sec
2017-04-14 02:01:46,450 Stage-1 map = 31%,  reduce = 0%, Cumulative CPU 260.03 sec
2017-04-14 02:01:48,493 Stage-1 map = 33%,  reduce = 0%, Cumulative CPU 273.31 sec
2017-04-14 02:01:49,517 Stage-1 map = 35%,  reduce = 0%, Cumulative CPU 282.83 sec
2017-04-14 02:01:51,654 Stage-1 map = 37%,  reduce = 0%, Cumulative CPU 300.88 sec
2017-04-14 02:01:53,703 Stage-1 map = 39%,  reduce = 0%, Cumulative CPU 311.06 sec
2017-04-14 02:01:54,723 Stage-1 map = 40%,  reduce = 0%, Cumulative CPU 315.5 sec
2017-04-14 02:01:55,745 Stage-1 map = 41%,  reduce = 0%, Cumulative CPU 324.32 sec
2017-04-14 02:01:58,873 Stage-1 map = 45%,  reduce = 0%, Cumulative CPU 347.5 sec
2017-04-14 02:01:59,899 Stage-1 map = 46%,  reduce = 0%, Cumulative CPU 351.21 sec
2017-04-14 02:02:01,990 Stage-1 map = 48%,  reduce = 0%, Cumulative CPU 371.09 sec
2017-04-14 02:02:03,025 Stage-1 map = 49%,  reduce = 0%, Cumulative CPU 373.54 sec
2017-04-14 02:02:04,093 Stage-1 map = 50%,  reduce = 0%, Cumulative CPU 382.85 sec
2017-04-14 02:02:05,164 Stage-1 map = 52%,  reduce = 0%, Cumulative CPU 392.53 sec
2017-04-14 02:02:07,223 Stage-1 map = 53%,  reduce = 0%, Cumulative CPU 406.22 sec
2017-04-14 02:02:09,286 Stage-1 map = 56%,  reduce = 0%, Cumulative CPU 417.92 sec
2017-04-14 02:02:10,422 Stage-1 map = 57%,  reduce = 0%, Cumulative CPU 422.16 sec
2017-04-14 02:02:11,598 Stage-1 map = 58%,  reduce = 0%, Cumulative CPU 430.94 sec
2017-04-14 02:02:12,686 Stage-1 map = 59%,  reduce = 0%, Cumulative CPU 439.81 sec
2017-04-14 02:02:14,759 Stage-1 map = 60%,  reduce = 0%, Cumulative CPU 446.99 sec
2017-04-14 02:02:15,793 Stage-1 map = 62%,  reduce = 0%, Cumulative CPU 458.73 sec
2017-04-14 02:02:18,857 Stage-1 map = 63%,  reduce = 0%, Cumulative CPU 475.52 sec
2017-04-14 02:02:20,894 Stage-1 map = 66%,  reduce = 0%, Cumulative CPU 492.16 sec
2017-04-14 02:02:21,913 Stage-1 map = 67%,  reduce = 0%, Cumulative CPU 503.72 sec
2017-04-14 02:02:23,953 Stage-1 map = 69%,  reduce = 0%, Cumulative CPU 526.42 sec
2017-04-14 02:02:25,174 Stage-1 map = 71%,  reduce = 0%, Cumulative CPU 533.89 sec
2017-04-14 02:02:26,228 Stage-1 map = 72%,  reduce = 0%, Cumulative CPU 538.67 sec
2017-04-14 02:02:28,280 Stage-1 map = 73%,  reduce = 0%, Cumulative CPU 548.52 sec
2017-04-14 02:02:29,332 Stage-1 map = 75%,  reduce = 0%, Cumulative CPU 556.4 sec
2017-04-14 02:02:30,386 Stage-1 map = 76%,  reduce = 0%, Cumulative CPU 562.94 sec
2017-04-14 02:02:31,513 Stage-1 map = 77%,  reduce = 0%, Cumulative CPU 568.1 sec
2017-04-14 02:02:32,537 Stage-1 map = 78%,  reduce = 0%, Cumulative CPU 577.53 sec
2017-04-14 02:02:33,557 Stage-1 map = 79%,  reduce = 0%, Cumulative CPU 580.87 sec
2017-04-14 02:02:35,687 Stage-1 map = 82%,  reduce = 0%, Cumulative CPU 604.48 sec
2017-04-14 02:02:36,735 Stage-1 map = 83%,  reduce = 0%, Cumulative CPU 608.61 sec
2017-04-14 02:02:38,840 Stage-1 map = 85%,  reduce = 0%, Cumulative CPU 618.65 sec
2017-04-14 02:02:39,905 Stage-1 map = 86%,  reduce = 0%, Cumulative CPU 621.49 sec
2017-04-14 02:02:42,018 Stage-1 map = 87%,  reduce = 0%, Cumulative CPU 634.48 sec
2017-04-14 02:02:43,133 Stage-1 map = 88%,  reduce = 0%, Cumulative CPU 641.14 sec
2017-04-14 02:02:45,474 Stage-1 map = 91%,  reduce = 0%, Cumulative CPU 658.57 sec
2017-04-14 02:02:47,728 Stage-1 map = 94%,  reduce = 0%, Cumulative CPU 669.31 sec
2017-04-14 02:02:51,414 Stage-1 map = 95%,  reduce = 0%, Cumulative CPU 684.07 sec
2017-04-14 02:02:52,538 Stage-1 map = 97%,  reduce = 0%, Cumulative CPU 687.37 sec
2017-04-14 02:02:59,007 Stage-1 map = 98%,  reduce = 0%, Cumulative CPU 700.28 sec
2017-04-14 02:03:01,315 Stage-1 map = 99%,  reduce = 0%, Cumulative CPU 702.39 sec
2017-04-14 02:03:04,426 Stage-1 map = 100%,  reduce = 0%, Cumulative CPU 704.79 sec
MapReduce Total cumulative CPU time: 11 minutes 44 seconds 790 msec
Ended Job = job_1490094830773_0683
Stage-4 is filtered out by condition resolver.
Stage-3 is selected by condition resolver.
Stage-5 is filtered out by condition resolver.
Starting Job = job_1490094830773_0684, Tracking URL = http://mac55:8088/proxy/application_1490094830773_0684/
Kill Command = /opt/cloudera/parcels/CDH-5.8.2-1.cdh5.8.2.p0.3/lib/hadoop/bin/hadoop job  -kill job_1490094830773_0684
Hadoop job information for Stage-3: number of mappers: 3; number of reducers: 0
2017-04-14 02:03:14,008 Stage-3 map = 0%,  reduce = 0%
2017-04-14 02:03:18,197 Stage-3 map = 33%,  reduce = 0%, Cumulative CPU 1.23 sec
2017-04-14 02:03:21,420 Stage-3 map = 67%,  reduce = 0%, Cumulative CPU 3.73 sec
2017-04-14 02:03:23,565 Stage-3 map = 75%,  reduce = 0%, Cumulative CPU 5.34 sec
2017-04-14 02:03:26,789 Stage-3 map = 79%,  reduce = 0%, Cumulative CPU 5.78 sec
2017-04-14 02:03:30,009 Stage-3 map = 84%,  reduce = 0%, Cumulative CPU 6.02 sec
2017-04-14 02:03:32,155 Stage-3 map = 89%,  reduce = 0%, Cumulative CPU 6.25 sec
2017-04-14 02:03:35,374 Stage-3 map = 92%,  reduce = 0%, Cumulative CPU 6.52 sec
2017-04-14 02:03:38,595 Stage-3 map = 97%,  reduce = 0%, Cumulative CPU 6.74 sec
2017-04-14 02:03:40,700 Stage-3 map = 100%,  reduce = 0%, Cumulative CPU 6.91 sec
MapReduce Total cumulative CPU time: 6 seconds 910 msec
Ended Job = job_1490094830773_0684
Loading data to table esplus.tempapplication_orc
Table esplus.tempapplication_orc stats: [numFiles=3, numRows=43286880, totalSize=474426275, rawDataSize=66424850658]
MapReduce Jobs Launched:
Stage-Stage-1: Map: 63   Cumulative CPU: 704.79 sec   HDFS Read: 19912446875 HDFS Write: 474507192 SUCCESS
Stage-Stage-3: Map: 3   Cumulative CPU: 6.91 sec   HDFS Read: 476486989 HDFS Write: 474426275 SUCCESS
Total MapReduce CPU Time Spent: 11 minutes 51 seconds 700 msec
OK
Time taken: 172.345 seconds


hive> dfs -du -s -h /user/hive/warehouse/esplus.db/tempapplication_orc;
452.4 M  1.3 G  /user/hive/warehouse/esplus.db/tempapplication_orc


==========================================================================================================================

insert into table TempApplication_text
select   a.username
,a.machinename
,a.machineid
,a.ipaddress
,a.domainname
,a.pcmlogeventid
,a.modulename
,a.filename
,a.productname
,a.companyname
,a.description
,a.text
,a.activetime
,b.timeslot as datetime
,b.timeslot
,a.date
from
 (
select   username, machinename, machineid, ipaddress,domainname,pcmlogeventid,modulename,filename,productname,datetime
,companyname,description,text,activetime,timeslot,date
,row_number() over (partition by lower(username) order by datetime) as row_number  
from TempApplication_text
where lower(modulename) NOT IN ('startwindowsswitch','stopwindowsswitch')
AND DateTime is not null AND DateTime <> ''
AND Username is not null AND Username <> '' AND length(trim(Username)) > 0
 ) a
left join
 (
select   username, machinename, machineid, ipaddress,domainname,pcmlogeventid,modulename,filename,productname,datetime
,companyname,description,text,activetime,timeslot,date
,row_number() over (partition by lower(username) order by datetime) as row_number
from TempApplication_text
where lower(modulename) NOT IN ('startwindowsswitch','stopwindowsswitch')
AND DateTime is not null AND DateTime <> ''
AND Username is not null AND Username <> '' AND length(trim(Username)) > 0
) b
on b.row_number =a.row_number +1
and lower(a.username)=lower(b.username);

========================================================================================================================
hive> insert into table TempApplication_text
    > select   a.username
    > ,a.machinename
    > ,a.machineid
    > ,a.ipaddress
    > ,a.domainname
    > ,a.pcmlogeventid
    > ,a.modulename
    > ,a.filename
    > ,a.productname
    > ,a.companyname
    > ,a.description
    > ,a.text
    > ,a.activetime
    > ,b.timeslot as datetime
    > ,b.timeslot
    > ,a.date
    > from
    >  (
    > select   username, machinename, machineid, ipaddress,domainname,pcmlogeventid,modulename,filename,productname,datetime
    > ,companyname,description,text,activetime,timeslot,date
    > ,row_number() over (partition by lower(username) order by datetime) as row_number
    > from TempApplication_text
    > where lower(modulename) NOT IN ('startwindowsswitch','stopwindowsswitch')
    > AND DateTime is not null AND DateTime <> ''
    > AND Username is not null AND Username <> '' AND length(trim(Username)) > 0
    >  ) a
    > left join
    >  (
    > select   username, machinename, machineid, ipaddress,domainname,pcmlogeventid,modulename,filename,productname,datetime
    > ,companyname,description,text,activetime,timeslot,date
    > ,row_number() over (partition by lower(username) order by datetime) as row_number
    > from TempApplication_text
    > where lower(modulename) NOT IN ('startwindowsswitch','stopwindowsswitch')
    > AND DateTime is not null AND DateTime <> ''
    > AND Username is not null AND Username <> '' AND length(trim(Username)) > 0
    > ) b
    > on b.row_number =a.row_number +1
    > and lower(a.username)=lower(b.username)
    > ;
Query ID = root_20170413235656_7f821121-2a91-47d1-8197-d4d0a43d8e27
Total jobs = 4
Launching Job 1 out of 4
Number of reduce tasks not specified. Estimated from input data size: 297
In order to change the average load for a reducer (in bytes):
  set hive.exec.reducers.bytes.per.reducer=<number>
In order to limit the maximum number of reducers:
  set hive.exec.reducers.max=<number>
In order to set a constant number of reducers:
  set mapreduce.job.reduces=<number>
Starting Job = job_1490094830773_0674, Tracking URL = http://mac55:8088/proxy/application_1490094830773_0674/
Kill Command = /opt/cloudera/parcels/CDH-5.8.2-1.cdh5.8.2.p0.3/lib/hadoop/bin/hadoop job  -kill job_1490094830773_0674
Hadoop job information for Stage-1: number of mappers: 62; number of reducers: 297
2017-04-13 23:56:39,234 Stage-1 map = 0%,  reduce = 0%
2017-04-13 23:56:53,065 Stage-1 map = 1%,  reduce = 0%, Cumulative CPU 47.9 sec
2017-04-13 23:56:58,209 Stage-1 map = 3%,  reduce = 0%, Cumulative CPU 84.1 sec
2017-04-13 23:57:01,874 Stage-1 map = 5%,  reduce = 0%, Cumulative CPU 101.45 sec
2017-04-13 23:57:03,925 Stage-1 map = 6%,  reduce = 0%, Cumulative CPU 104.85 sec
2017-04-13 23:57:05,097 Stage-1 map = 7%,  reduce = 0%, Cumulative CPU 118.74 sec
2017-04-13 23:57:07,168 Stage-1 map = 8%,  reduce = 0%, Cumulative CPU 127.86 sec
2017-04-13 23:57:08,192 Stage-1 map = 9%,  reduce = 0%, Cumulative CPU 136.93 sec
2017-04-13 23:57:10,267 Stage-1 map = 11%,  reduce = 0%, Cumulative CPU 153.96 sec
2017-04-13 23:57:13,376 Stage-1 map = 16%,  reduce = 0%, Cumulative CPU 179.01 sec
2017-04-13 23:57:15,442 Stage-1 map = 17%,  reduce = 0%, Cumulative CPU 184.86 sec
2017-04-13 23:57:16,467 Stage-1 map = 18%,  reduce = 0%, Cumulative CPU 190.18 sec
2017-04-13 23:57:17,493 Stage-1 map = 19%,  reduce = 0%, Cumulative CPU 191.99 sec
2017-04-13 23:57:18,529 Stage-1 map = 21%,  reduce = 0%, Cumulative CPU 197.08 sec
2017-04-13 23:57:21,596 Stage-1 map = 22%,  reduce = 0%, Cumulative CPU 202.63 sec
2017-04-13 23:57:22,620 Stage-1 map = 23%,  reduce = 0%, Cumulative CPU 206.42 sec
2017-04-13 23:57:24,667 Stage-1 map = 24%,  reduce = 0%, Cumulative CPU 224.23 sec
2017-04-13 23:57:25,689 Stage-1 map = 25%,  reduce = 0%, Cumulative CPU 225.84 sec
2017-04-13 23:57:32,969 Stage-1 map = 26%,  reduce = 0%, Cumulative CPU 270.47 sec
2017-04-13 23:57:34,048 Stage-1 map = 27%,  reduce = 0%, Cumulative CPU 279.68 sec
2017-04-13 23:57:35,089 Stage-1 map = 28%,  reduce = 0%, Cumulative CPU 280.41 sec
2017-04-13 23:57:37,174 Stage-1 map = 30%,  reduce = 0%, Cumulative CPU 298.08 sec
2017-04-13 23:57:39,224 Stage-1 map = 31%,  reduce = 0%, Cumulative CPU 304.53 sec
2017-04-13 23:57:42,295 Stage-1 map = 34%,  reduce = 0%, Cumulative CPU 342.22 sec
2017-04-13 23:57:43,317 Stage-1 map = 36%,  reduce = 0%, Cumulative CPU 353.01 sec
2017-04-13 23:57:44,340 Stage-1 map = 38%,  reduce = 0%, Cumulative CPU 357.01 sec
2017-04-13 23:57:45,377 Stage-1 map = 42%,  reduce = 0%, Cumulative CPU 363.88 sec
2017-04-13 23:57:49,473 Stage-1 map = 43%,  reduce = 0%, Cumulative CPU 374.49 sec
2017-04-13 23:57:52,563 Stage-1 map = 44%,  reduce = 0%, Cumulative CPU 383.04 sec
2017-04-13 23:57:55,150 Stage-1 map = 45%,  reduce = 0%, Cumulative CPU 406.49 sec
2017-04-13 23:57:58,425 Stage-1 map = 46%,  reduce = 0%, Cumulative CPU 441.52 sec
2017-04-13 23:58:01,499 Stage-1 map = 49%,  reduce = 0%, Cumulative CPU 460.54 sec
2017-04-13 23:58:03,543 Stage-1 map = 50%,  reduce = 0%, Cumulative CPU 465.39 sec
2017-04-13 23:58:04,567 Stage-1 map = 51%,  reduce = 0%, Cumulative CPU 475.81 sec
2017-04-13 23:58:05,596 Stage-1 map = 52%,  reduce = 0%, Cumulative CPU 480.42 sec
2017-04-13 23:58:07,644 Stage-1 map = 54%,  reduce = 0%, Cumulative CPU 498.16 sec
2017-04-13 23:58:08,667 Stage-1 map = 56%,  reduce = 0%, Cumulative CPU 503.0 sec
2017-04-13 23:58:09,703 Stage-1 map = 57%,  reduce = 0%, Cumulative CPU 506.15 sec
2017-04-13 23:58:10,780 Stage-1 map = 59%,  reduce = 0%, Cumulative CPU 513.79 sec
2017-04-13 23:58:11,838 Stage-1 map = 60%,  reduce = 0%, Cumulative CPU 519.94 sec
2017-04-13 23:58:12,881 Stage-1 map = 62%,  reduce = 0%, Cumulative CPU 522.65 sec
2017-04-13 23:58:13,921 Stage-1 map = 65%,  reduce = 0%, Cumulative CPU 532.02 sec
2017-04-13 23:58:19,106 Stage-1 map = 67%,  reduce = 0%, Cumulative CPU 550.73 sec
2017-04-13 23:58:23,596 Stage-1 map = 68%,  reduce = 0%, Cumulative CPU 578.01 sec
2017-04-13 23:58:26,675 Stage-1 map = 69%,  reduce = 0%, Cumulative CPU 615.33 sec
2017-04-13 23:58:27,696 Stage-1 map = 72%,  reduce = 0%, Cumulative CPU 621.17 sec
2017-04-13 23:58:28,718 Stage-1 map = 73%,  reduce = 0%, Cumulative CPU 627.48 sec
2017-04-13 23:58:29,740 Stage-1 map = 74%,  reduce = 0%, Cumulative CPU 631.32 sec
2017-04-13 23:58:31,781 Stage-1 map = 75%,  reduce = 0%, Cumulative CPU 649.52 sec
2017-04-13 23:58:32,812 Stage-1 map = 76%,  reduce = 0%, Cumulative CPU 656.53 sec
2017-04-13 23:58:33,846 Stage-1 map = 79%,  reduce = 0%, Cumulative CPU 663.63 sec
2017-04-13 23:58:34,888 Stage-1 map = 80%,  reduce = 0%, Cumulative CPU 671.43 sec
2017-04-13 23:58:35,910 Stage-1 map = 82%,  reduce = 0%, Cumulative CPU 677.99 sec
2017-04-13 23:58:36,931 Stage-1 map = 84%,  reduce = 0%, Cumulative CPU 686.58 sec
2017-04-13 23:58:37,952 Stage-1 map = 86%,  reduce = 0%, Cumulative CPU 690.31 sec
2017-04-13 23:58:38,977 Stage-1 map = 87%,  reduce = 0%, Cumulative CPU 696.38 sec
2017-04-13 23:58:40,001 Stage-1 map = 88%,  reduce = 0%, Cumulative CPU 704.51 sec
2017-04-13 23:58:41,036 Stage-1 map = 90%,  reduce = 0%, Cumulative CPU 708.69 sec
2017-04-13 23:58:43,137 Stage-1 map = 91%,  reduce = 0%, Cumulative CPU 712.72 sec
2017-04-13 23:58:47,883 Stage-1 map = 92%,  reduce = 0%, Cumulative CPU 731.17 sec
2017-04-13 23:58:51,479 Stage-1 map = 93%,  reduce = 0%, Cumulative CPU 752.31 sec
2017-04-13 23:58:52,630 Stage-1 map = 94%,  reduce = 0%, Cumulative CPU 754.93 sec
2017-04-13 23:58:53,698 Stage-1 map = 94%,  reduce = 1%, Cumulative CPU 760.09 sec
2017-04-13 23:58:54,779 Stage-1 map = 95%,  reduce = 1%, Cumulative CPU 765.78 sec
2017-04-13 23:58:55,853 Stage-1 map = 96%,  reduce = 1%, Cumulative CPU 768.43 sec
2017-04-13 23:58:56,884 Stage-1 map = 97%,  reduce = 1%, Cumulative CPU 772.49 sec
2017-04-13 23:58:59,015 Stage-1 map = 99%,  reduce = 1%, Cumulative CPU 779.23 sec
2017-04-13 23:59:05,538 Stage-1 map = 100%,  reduce = 1%, Cumulative CPU 786.43 sec
2017-04-13 23:59:07,650 Stage-1 map = 100%,  reduce = 2%, Cumulative CPU 790.76 sec
2017-04-13 23:59:08,850 Stage-1 map = 100%,  reduce = 3%, Cumulative CPU 824.65 sec
2017-04-13 23:59:11,261 Stage-1 map = 100%,  reduce = 4%, Cumulative CPU 843.73 sec
2017-04-13 23:59:20,326 Stage-1 map = 100%,  reduce = 5%, Cumulative CPU 867.62 sec
2017-04-13 23:59:26,657 Stage-1 map = 100%,  reduce = 6%, Cumulative CPU 890.29 sec
2017-04-13 23:59:32,774 Stage-1 map = 100%,  reduce = 7%, Cumulative CPU 898.24 sec
2017-04-13 23:59:47,304 Stage-1 map = 100%,  reduce = 8%, Cumulative CPU 918.93 sec
2017-04-13 23:59:56,179 Stage-1 map = 100%,  reduce = 9%, Cumulative CPU 941.54 sec
2017-04-14 00:00:02,334 Stage-1 map = 100%,  reduce = 10%, Cumulative CPU 956.95 sec
2017-04-14 00:00:17,350 Stage-1 map = 100%,  reduce = 11%, Cumulative CPU 982.23 sec
2017-04-14 00:00:31,623 Stage-1 map = 100%,  reduce = 12%, Cumulative CPU 1003.58 sec
2017-04-14 00:00:39,941 Stage-1 map = 100%,  reduce = 13%, Cumulative CPU 1015.72 sec
2017-04-14 00:00:49,780 Stage-1 map = 100%,  reduce = 14%, Cumulative CPU 1036.91 sec
2017-04-14 00:01:14,877 Stage-1 map = 100%,  reduce = 15%, Cumulative CPU 1063.74 sec
2017-04-14 00:01:25,115 Stage-1 map = 100%,  reduce = 16%, Cumulative CPU 1086.46 sec
2017-04-14 00:01:30,980 Stage-1 map = 100%,  reduce = 17%, Cumulative CPU 1103.52 sec
2017-04-14 00:01:37,639 Stage-1 map = 100%,  reduce = 18%, Cumulative CPU 1125.11 sec
2017-04-14 00:01:39,999 Stage-1 map = 100%,  reduce = 19%, Cumulative CPU 1130.19 sec
2017-04-14 00:01:47,362 Stage-1 map = 100%,  reduce = 20%, Cumulative CPU 1149.91 sec
2017-04-14 00:01:54,658 Stage-1 map = 100%,  reduce = 21%, Cumulative CPU 1166.4 sec
2017-04-14 00:01:57,326 Stage-1 map = 100%,  reduce = 22%, Cumulative CPU 1177.56 sec
2017-04-14 00:02:04,495 Stage-1 map = 100%,  reduce = 23%, Cumulative CPU 1199.7 sec
2017-04-14 00:02:13,570 Stage-1 map = 100%,  reduce = 24%, Cumulative CPU 1219.53 sec
2017-04-14 00:02:29,600 Stage-1 map = 100%,  reduce = 25%, Cumulative CPU 1241.35 sec
2017-04-14 00:02:40,767 Stage-1 map = 100%,  reduce = 26%, Cumulative CPU 1258.91 sec
2017-04-14 00:02:52,354 Stage-1 map = 100%,  reduce = 27%, Cumulative CPU 1278.78 sec
2017-04-14 00:03:01,918 Stage-1 map = 100%,  reduce = 28%, Cumulative CPU 1299.83 sec
2017-04-14 00:03:18,366 Stage-1 map = 100%,  reduce = 29%, Cumulative CPU 1320.1 sec
2017-04-14 00:03:29,418 Stage-1 map = 100%,  reduce = 30%, Cumulative CPU 1342.36 sec
2017-04-14 00:03:35,608 Stage-1 map = 100%,  reduce = 31%, Cumulative CPU 1358.19 sec
2017-04-14 00:03:39,327 Stage-1 map = 100%,  reduce = 32%, Cumulative CPU 1370.48 sec
2017-04-14 00:03:53,187 Stage-1 map = 100%,  reduce = 33%, Cumulative CPU 1391.03 sec
2017-04-14 00:04:13,392 Stage-1 map = 100%,  reduce = 34%, Cumulative CPU 1410.78 sec
2017-04-14 00:04:25,143 Stage-1 map = 100%,  reduce = 35%, Cumulative CPU 1433.5 sec
2017-04-14 00:04:40,122 Stage-1 map = 100%,  reduce = 36%, Cumulative CPU 1449.37 sec
2017-04-14 00:04:52,044 Stage-1 map = 100%,  reduce = 37%, Cumulative CPU 1465.57 sec
2017-04-14 00:05:01,036 Stage-1 map = 100%,  reduce = 38%, Cumulative CPU 1488.5 sec
2017-04-14 00:05:11,353 Stage-1 map = 100%,  reduce = 39%, Cumulative CPU 1516.12 sec
2017-04-14 00:05:16,519 Stage-1 map = 100%,  reduce = 40%, Cumulative CPU 1530.23 sec
2017-04-14 00:05:32,843 Stage-1 map = 100%,  reduce = 41%, Cumulative CPU 1547.72 sec
2017-04-14 00:05:46,331 Stage-1 map = 100%,  reduce = 42%, Cumulative CPU 1563.28 sec
2017-04-14 00:06:00,427 Stage-1 map = 100%,  reduce = 43%, Cumulative CPU 1586.35 sec
2017-04-14 00:06:05,635 Stage-1 map = 100%,  reduce = 44%, Cumulative CPU 1602.3 sec
2017-04-14 00:06:12,385 Stage-1 map = 100%,  reduce = 45%, Cumulative CPU 1620.76 sec
2017-04-14 00:06:19,612 Stage-1 map = 100%,  reduce = 46%, Cumulative CPU 1643.83 sec
2017-04-14 00:06:26,175 Stage-1 map = 100%,  reduce = 47%, Cumulative CPU 1663.37 sec
2017-04-14 00:06:29,428 Stage-1 map = 100%,  reduce = 48%, Cumulative CPU 1676.42 sec
2017-04-14 00:06:37,384 Stage-1 map = 100%,  reduce = 49%, Cumulative CPU 1699.76 sec
2017-04-14 00:06:45,668 Stage-1 map = 100%,  reduce = 50%, Cumulative CPU 1721.66 sec
2017-04-14 00:06:59,757 Stage-1 map = 100%,  reduce = 51%, Cumulative CPU 1737.67 sec
2017-04-14 00:07:24,176 Stage-1 map = 100%,  reduce = 52%, Cumulative CPU 1759.75 sec
2017-04-14 00:07:36,490 Stage-1 map = 100%,  reduce = 53%, Cumulative CPU 1778.17 sec
2017-04-14 00:07:54,398 Stage-1 map = 100%,  reduce = 54%, Cumulative CPU 1798.86 sec
2017-04-14 00:08:07,629 Stage-1 map = 100%,  reduce = 55%, Cumulative CPU 1820.6 sec
2017-04-14 00:08:18,860 Stage-1 map = 100%,  reduce = 56%, Cumulative CPU 1838.91 sec
2017-04-14 00:08:27,640 Stage-1 map = 100%,  reduce = 57%, Cumulative CPU 1863.74 sec
2017-04-14 00:08:34,056 Stage-1 map = 100%,  reduce = 58%, Cumulative CPU 1884.04 sec
2017-04-14 00:08:46,004 Stage-1 map = 100%,  reduce = 59%, Cumulative CPU 1901.22 sec
2017-04-14 00:08:51,126 Stage-1 map = 100%,  reduce = 60%, Cumulative CPU 1912.62 sec
2017-04-14 00:09:08,283 Stage-1 map = 100%,  reduce = 61%, Cumulative CPU 1936.63 sec
2017-04-14 00:09:25,276 Stage-1 map = 100%,  reduce = 62%, Cumulative CPU 1954.21 sec
2017-04-14 00:09:36,035 Stage-1 map = 100%,  reduce = 63%, Cumulative CPU 1981.86 sec
2017-04-14 00:09:48,362 Stage-1 map = 100%,  reduce = 64%, Cumulative CPU 1999.64 sec
2017-04-14 00:09:53,639 Stage-1 map = 100%,  reduce = 65%, Cumulative CPU 2014.67 sec
2017-04-14 00:10:01,939 Stage-1 map = 100%,  reduce = 66%, Cumulative CPU 2032.16 sec
2017-04-14 00:10:04,394 Stage-1 map = 100%,  reduce = 67%, Cumulative CPU 2048.09 sec
2017-04-14 00:10:11,528 Stage-1 map = 100%,  reduce = 68%, Cumulative CPU 2066.84 sec
2017-04-14 00:10:22,334 Stage-1 map = 100%,  reduce = 69%, Cumulative CPU 2081.4 sec
2017-04-14 00:10:39,147 Stage-1 map = 100%,  reduce = 70%, Cumulative CPU 2100.52 sec
2017-04-14 00:10:45,002 Stage-1 map = 100%,  reduce = 71%, Cumulative CPU 2122.24 sec
2017-04-14 00:10:49,925 Stage-1 map = 100%,  reduce = 72%, Cumulative CPU 2143.67 sec
2017-04-14 00:10:58,576 Stage-1 map = 100%,  reduce = 73%, Cumulative CPU 2159.43 sec
2017-04-14 00:11:06,482 Stage-1 map = 100%,  reduce = 74%, Cumulative CPU 2179.09 sec
2017-04-14 00:11:15,055 Stage-1 map = 100%,  reduce = 75%, Cumulative CPU 2194.44 sec
2017-04-14 00:11:29,794 Stage-1 map = 100%,  reduce = 76%, Cumulative CPU 2217.43 sec
2017-04-14 00:11:37,087 Stage-1 map = 100%,  reduce = 77%, Cumulative CPU 2237.8 sec
2017-04-14 00:11:39,744 Stage-1 map = 100%,  reduce = 78%, Cumulative CPU 2254.0 sec
2017-04-14 00:12:01,280 Stage-1 map = 100%,  reduce = 79%, Cumulative CPU 2273.32 sec
2017-04-14 00:12:10,471 Stage-1 map = 100%,  reduce = 80%, Cumulative CPU 2290.47 sec
2017-04-14 00:12:20,154 Stage-1 map = 100%,  reduce = 81%, Cumulative CPU 2309.79 sec
2017-04-14 00:12:27,507 Stage-1 map = 100%,  reduce = 82%, Cumulative CPU 2330.39 sec
2017-04-14 00:12:32,787 Stage-1 map = 100%,  reduce = 83%, Cumulative CPU 2347.61 sec
2017-04-14 00:12:41,342 Stage-1 map = 100%,  reduce = 84%, Cumulative CPU 2363.65 sec
2017-04-14 00:12:59,148 Stage-1 map = 100%,  reduce = 85%, Cumulative CPU 2387.84 sec
2017-04-14 00:13:09,085 Stage-1 map = 100%,  reduce = 86%, Cumulative CPU 2406.36 sec
2017-04-14 00:13:29,216 Stage-1 map = 100%,  reduce = 87%, Cumulative CPU 2429.02 sec
2017-04-14 00:13:46,398 Stage-1 map = 100%,  reduce = 88%, Cumulative CPU 2445.86 sec
2017-04-14 00:13:54,243 Stage-1 map = 100%,  reduce = 89%, Cumulative CPU 2460.38 sec
2017-04-14 00:14:05,280 Stage-1 map = 100%,  reduce = 90%, Cumulative CPU 2484.34 sec
2017-04-14 00:14:20,233 Stage-1 map = 100%,  reduce = 91%, Cumulative CPU 2501.77 sec
2017-04-14 00:14:30,849 Stage-1 map = 100%,  reduce = 92%, Cumulative CPU 2520.47 sec
2017-04-14 00:14:36,652 Stage-1 map = 100%,  reduce = 93%, Cumulative CPU 2538.8 sec
2017-04-14 00:14:44,064 Stage-1 map = 100%,  reduce = 94%, Cumulative CPU 2553.07 sec
2017-04-14 00:14:51,433 Stage-1 map = 100%,  reduce = 95%, Cumulative CPU 2577.17 sec
2017-04-14 00:14:59,328 Stage-1 map = 100%,  reduce = 96%, Cumulative CPU 2597.93 sec
2017-04-14 00:15:09,550 Stage-1 map = 100%,  reduce = 97%, Cumulative CPU 2619.47 sec
2017-04-14 00:15:14,487 Stage-1 map = 100%,  reduce = 98%, Cumulative CPU 2636.68 sec
2017-04-14 00:15:22,049 Stage-1 map = 100%,  reduce = 99%, Cumulative CPU 2653.8 sec
2017-04-14 00:16:23,088 Stage-1 map = 100%,  reduce = 100%, Cumulative CPU 2690.54 sec
MapReduce Total cumulative CPU time: 44 minutes 50 seconds 540 msec
Ended Job = job_1490094830773_0674
Launching Job 2 out of 4
Number of reduce tasks not specified. Estimated from input data size: 297
In order to change the average load for a reducer (in bytes):
  set hive.exec.reducers.bytes.per.reducer=<number>
In order to limit the maximum number of reducers:
  set hive.exec.reducers.max=<number>
In order to set a constant number of reducers:
  set mapreduce.job.reduces=<number>
Starting Job = job_1490094830773_0675, Tracking URL = http://mac55:8088/proxy/application_1490094830773_0675/
Kill Command = /opt/cloudera/parcels/CDH-5.8.2-1.cdh5.8.2.p0.3/lib/hadoop/bin/hadoop job  -kill job_1490094830773_0675
Hadoop job information for Stage-4: number of mappers: 62; number of reducers: 297
2017-04-14 00:16:43,605 Stage-4 map = 0%,  reduce = 0%
2017-04-14 00:16:59,351 Stage-4 map = 1%,  reduce = 0%, Cumulative CPU 51.31 sec
2017-04-14 00:17:03,437 Stage-4 map = 2%,  reduce = 0%, Cumulative CPU 68.81 sec
2017-04-14 00:17:06,504 Stage-4 map = 3%,  reduce = 0%, Cumulative CPU 79.93 sec
2017-04-14 00:17:07,528 Stage-4 map = 4%,  reduce = 0%, Cumulative CPU 84.2 sec
2017-04-14 00:17:08,702 Stage-4 map = 6%,  reduce = 0%, Cumulative CPU 88.1 sec
2017-04-14 00:17:10,746 Stage-4 map = 7%,  reduce = 0%, Cumulative CPU 97.27 sec
2017-04-14 00:17:12,789 Stage-4 map = 9%,  reduce = 0%, Cumulative CPU 104.42 sec
2017-04-14 00:17:13,910 Stage-4 map = 11%,  reduce = 0%, Cumulative CPU 111.47 sec
2017-04-14 00:17:15,954 Stage-4 map = 12%,  reduce = 0%, Cumulative CPU 119.41 sec
2017-04-14 00:17:16,974 Stage-4 map = 13%,  reduce = 0%, Cumulative CPU 124.26 sec
2017-04-14 00:17:18,001 Stage-4 map = 15%,  reduce = 0%, Cumulative CPU 128.02 sec
2017-04-14 00:17:19,023 Stage-4 map = 17%,  reduce = 0%, Cumulative CPU 134.86 sec
2017-04-14 00:17:20,052 Stage-4 map = 20%,  reduce = 0%, Cumulative CPU 142.08 sec
2017-04-14 00:17:21,073 Stage-4 map = 21%,  reduce = 0%, Cumulative CPU 145.39 sec
2017-04-14 00:17:24,151 Stage-4 map = 22%,  reduce = 0%, Cumulative CPU 150.46 sec
2017-04-14 00:17:25,186 Stage-4 map = 24%,  reduce = 0%, Cumulative CPU 153.82 sec
2017-04-14 00:17:28,307 Stage-4 map = 25%,  reduce = 0%, Cumulative CPU 171.3 sec
2017-04-14 00:17:31,406 Stage-4 map = 26%,  reduce = 0%, Cumulative CPU 197.37 sec
2017-04-14 00:17:34,476 Stage-4 map = 27%,  reduce = 0%, Cumulative CPU 220.37 sec
2017-04-14 00:17:37,540 Stage-4 map = 30%,  reduce = 0%, Cumulative CPU 238.5 sec
2017-04-14 00:17:39,581 Stage-4 map = 32%,  reduce = 0%, Cumulative CPU 245.24 sec
2017-04-14 00:17:40,602 Stage-4 map = 34%,  reduce = 0%, Cumulative CPU 250.55 sec
2017-04-14 00:17:42,650 Stage-4 map = 35%,  reduce = 0%, Cumulative CPU 255.63 sec
2017-04-14 00:17:43,674 Stage-4 map = 36%,  reduce = 0%, Cumulative CPU 260.74 sec
2017-04-14 00:17:44,694 Stage-4 map = 38%,  reduce = 0%, Cumulative CPU 264.03 sec
2017-04-14 00:17:46,744 Stage-4 map = 40%,  reduce = 0%, Cumulative CPU 272.02 sec
2017-04-14 00:17:47,765 Stage-4 map = 41%,  reduce = 0%, Cumulative CPU 274.21 sec
2017-04-14 00:17:49,524 Stage-4 map = 42%,  reduce = 0%, Cumulative CPU 289.94 sec
2017-04-14 00:17:53,604 Stage-4 map = 43%,  reduce = 0%, Cumulative CPU 303.23 sec
2017-04-14 00:17:54,626 Stage-4 map = 46%,  reduce = 0%, Cumulative CPU 309.05 sec
2017-04-14 00:17:55,650 Stage-4 map = 49%,  reduce = 0%, Cumulative CPU 323.02 sec
2017-04-14 00:17:56,671 Stage-4 map = 50%,  reduce = 0%, Cumulative CPU 326.55 sec
2017-04-14 00:17:57,697 Stage-4 map = 51%,  reduce = 0%, Cumulative CPU 335.26 sec
2017-04-14 00:17:58,749 Stage-4 map = 52%,  reduce = 0%, Cumulative CPU 342.18 sec
2017-04-14 00:18:00,826 Stage-4 map = 55%,  reduce = 0%, Cumulative CPU 350.26 sec
2017-04-14 00:18:01,876 Stage-4 map = 56%,  reduce = 0%, Cumulative CPU 354.24 sec
2017-04-14 00:18:04,983 Stage-4 map = 57%,  reduce = 0%, Cumulative CPU 361.38 sec
2017-04-14 00:18:06,004 Stage-4 map = 58%,  reduce = 0%, Cumulative CPU 369.91 sec
2017-04-14 00:18:10,510 Stage-4 map = 60%,  reduce = 0%, Cumulative CPU 395.29 sec
2017-04-14 00:18:11,565 Stage-4 map = 64%,  reduce = 0%, Cumulative CPU 417.85 sec
2017-04-14 00:18:13,612 Stage-4 map = 65%,  reduce = 0%, Cumulative CPU 422.7 sec
2017-04-14 00:18:17,690 Stage-4 map = 66%,  reduce = 0%, Cumulative CPU 434.31 sec
2017-04-14 00:18:19,733 Stage-4 map = 67%,  reduce = 0%, Cumulative CPU 448.23 sec
2017-04-14 00:18:20,751 Stage-4 map = 69%,  reduce = 0%, Cumulative CPU 452.1 sec
2017-04-14 00:18:21,775 Stage-4 map = 72%,  reduce = 0%, Cumulative CPU 460.63 sec
2017-04-14 00:18:22,799 Stage-4 map = 76%,  reduce = 0%, Cumulative CPU 471.87 sec
2017-04-14 00:18:23,820 Stage-4 map = 78%,  reduce = 0%, Cumulative CPU 475.3 sec
2017-04-14 00:18:25,866 Stage-4 map = 80%,  reduce = 0%, Cumulative CPU 482.63 sec
2017-04-14 00:18:26,888 Stage-4 map = 81%,  reduce = 0%, Cumulative CPU 484.36 sec
2017-04-14 00:18:27,922 Stage-4 map = 83%,  reduce = 0%, Cumulative CPU 488.8 sec
2017-04-14 00:18:28,952 Stage-4 map = 84%,  reduce = 0%, Cumulative CPU 491.12 sec
2017-04-14 00:18:31,103 Stage-4 map = 85%,  reduce = 0%, Cumulative CPU 498.72 sec
2017-04-14 00:18:34,231 Stage-4 map = 86%,  reduce = 0%, Cumulative CPU 518.48 sec
2017-04-14 00:18:35,251 Stage-4 map = 87%,  reduce = 0%, Cumulative CPU 522.9 sec
2017-04-14 00:18:37,297 Stage-4 map = 88%,  reduce = 0%, Cumulative CPU 537.24 sec
2017-04-14 00:18:40,363 Stage-4 map = 90%,  reduce = 0%, Cumulative CPU 547.61 sec
2017-04-14 00:18:41,414 Stage-4 map = 90%,  reduce = 1%, Cumulative CPU 549.95 sec
2017-04-14 00:18:43,972 Stage-4 map = 93%,  reduce = 1%, Cumulative CPU 558.17 sec
2017-04-14 00:18:45,006 Stage-4 map = 95%,  reduce = 1%, Cumulative CPU 560.39 sec
2017-04-14 00:18:46,062 Stage-4 map = 97%,  reduce = 1%, Cumulative CPU 566.12 sec
2017-04-14 00:18:49,193 Stage-4 map = 98%,  reduce = 1%, Cumulative CPU 570.52 sec
2017-04-14 00:18:51,381 Stage-4 map = 99%,  reduce = 1%, Cumulative CPU 572.83 sec
2017-04-14 00:18:54,589 Stage-4 map = 100%,  reduce = 1%, Cumulative CPU 575.26 sec
2017-04-14 00:18:56,690 Stage-4 map = 100%,  reduce = 2%, Cumulative CPU 587.44 sec
2017-04-14 00:18:58,904 Stage-4 map = 100%,  reduce = 4%, Cumulative CPU 624.94 sec
2017-04-14 00:19:01,242 Stage-4 map = 100%,  reduce = 5%, Cumulative CPU 638.33 sec
2017-04-14 00:19:06,901 Stage-4 map = 100%,  reduce = 6%, Cumulative CPU 651.65 sec
2017-04-14 00:19:10,094 Stage-4 map = 100%,  reduce = 7%, Cumulative CPU 669.81 sec
2017-04-14 00:19:12,304 Stage-4 map = 100%,  reduce = 8%, Cumulative CPU 678.14 sec
2017-04-14 00:19:13,591 Stage-4 map = 100%,  reduce = 9%, Cumulative CPU 698.42 sec
2017-04-14 00:19:14,892 Stage-4 map = 100%,  reduce = 10%, Cumulative CPU 707.23 sec
2017-04-14 00:19:17,059 Stage-4 map = 100%,  reduce = 11%, Cumulative CPU 723.88 sec
2017-04-14 00:19:18,136 Stage-4 map = 100%,  reduce = 12%, Cumulative CPU 732.57 sec
2017-04-14 00:19:22,786 Stage-4 map = 100%,  reduce = 13%, Cumulative CPU 751.15 sec
2017-04-14 00:19:23,934 Stage-4 map = 100%,  reduce = 14%, Cumulative CPU 763.56 sec
2017-04-14 00:19:25,005 Stage-4 map = 100%,  reduce = 15%, Cumulative CPU 782.79 sec
2017-04-14 00:19:26,053 Stage-4 map = 100%,  reduce = 16%, Cumulative CPU 786.53 sec
2017-04-14 00:19:28,163 Stage-4 map = 100%,  reduce = 18%, Cumulative CPU 805.73 sec
2017-04-14 00:19:32,336 Stage-4 map = 100%,  reduce = 19%, Cumulative CPU 821.82 sec
2017-04-14 00:19:34,615 Stage-4 map = 100%,  reduce = 20%, Cumulative CPU 826.47 sec
2017-04-14 00:19:35,804 Stage-4 map = 100%,  reduce = 21%, Cumulative CPU 847.53 sec
2017-04-14 00:19:36,977 Stage-4 map = 100%,  reduce = 22%, Cumulative CPU 859.85 sec
2017-04-14 00:19:39,134 Stage-4 map = 100%,  reduce = 23%, Cumulative CPU 874.04 sec
2017-04-14 00:19:41,604 Stage-4 map = 100%,  reduce = 24%, Cumulative CPU 883.36 sec
2017-04-14 00:19:45,955 Stage-4 map = 100%,  reduce = 25%, Cumulative CPU 906.63 sec
2017-04-14 00:19:47,041 Stage-4 map = 100%,  reduce = 26%, Cumulative CPU 910.25 sec
2017-04-14 00:19:49,139 Stage-4 map = 100%,  reduce = 28%, Cumulative CPU 937.15 sec
2017-04-14 00:19:51,240 Stage-4 map = 100%,  reduce = 29%, Cumulative CPU 951.07 sec
2017-04-14 00:19:55,632 Stage-4 map = 100%,  reduce = 30%, Cumulative CPU 973.18 sec
2017-04-14 00:19:56,698 Stage-4 map = 100%,  reduce = 31%, Cumulative CPU 985.11 sec
2017-04-14 00:19:58,912 Stage-4 map = 100%,  reduce = 33%, Cumulative CPU 1002.12 sec
2017-04-14 00:20:02,400 Stage-4 map = 100%,  reduce = 34%, Cumulative CPU 1022.01 sec
2017-04-14 00:20:03,443 Stage-4 map = 100%,  reduce = 35%, Cumulative CPU 1035.39 sec
2017-04-14 00:20:05,529 Stage-4 map = 100%,  reduce = 36%, Cumulative CPU 1048.47 sec
2017-04-14 00:20:07,694 Stage-4 map = 100%,  reduce = 37%, Cumulative CPU 1062.44 sec
2017-04-14 00:20:08,781 Stage-4 map = 100%,  reduce = 38%, Cumulative CPU 1075.22 sec
2017-04-14 00:20:10,853 Stage-4 map = 100%,  reduce = 39%, Cumulative CPU 1084.52 sec
2017-04-14 00:20:12,966 Stage-4 map = 100%,  reduce = 40%, Cumulative CPU 1102.12 sec
2017-04-14 00:20:15,214 Stage-4 map = 100%,  reduce = 41%, Cumulative CPU 1119.42 sec
2017-04-14 00:20:17,593 Stage-4 map = 100%,  reduce = 42%, Cumulative CPU 1131.17 sec
2017-04-14 00:20:18,972 Stage-4 map = 100%,  reduce = 43%, Cumulative CPU 1135.54 sec
2017-04-14 00:20:20,036 Stage-4 map = 100%,  reduce = 44%, Cumulative CPU 1153.17 sec
2017-04-14 00:20:23,239 Stage-4 map = 100%,  reduce = 45%, Cumulative CPU 1167.43 sec
2017-04-14 00:20:24,351 Stage-4 map = 100%,  reduce = 46%, Cumulative CPU 1172.03 sec
2017-04-14 00:20:27,628 Stage-4 map = 100%,  reduce = 47%, Cumulative CPU 1195.22 sec
2017-04-14 00:20:28,680 Stage-4 map = 100%,  reduce = 48%, Cumulative CPU 1204.22 sec
2017-04-14 00:20:29,786 Stage-4 map = 100%,  reduce = 49%, Cumulative CPU 1218.85 sec
2017-04-14 00:20:31,915 Stage-4 map = 100%,  reduce = 50%, Cumulative CPU 1228.79 sec
2017-04-14 00:20:32,957 Stage-4 map = 100%,  reduce = 51%, Cumulative CPU 1242.05 sec
2017-04-14 00:20:35,087 Stage-4 map = 100%,  reduce = 52%, Cumulative CPU 1253.11 sec
2017-04-14 00:20:38,300 Stage-4 map = 100%,  reduce = 54%, Cumulative CPU 1279.45 sec
2017-04-14 00:20:40,411 Stage-4 map = 100%,  reduce = 55%, Cumulative CPU 1292.47 sec
2017-04-14 00:20:42,543 Stage-4 map = 100%,  reduce = 56%, Cumulative CPU 1305.57 sec
2017-04-14 00:20:44,654 Stage-4 map = 100%,  reduce = 57%, Cumulative CPU 1319.85 sec
2017-04-14 00:20:48,140 Stage-4 map = 100%,  reduce = 58%, Cumulative CPU 1339.52 sec
2017-04-14 00:20:49,374 Stage-4 map = 100%,  reduce = 59%, Cumulative CPU 1352.44 sec
2017-04-14 00:20:50,526 Stage-4 map = 100%,  reduce = 60%, Cumulative CPU 1360.49 sec
2017-04-14 00:20:52,682 Stage-4 map = 100%,  reduce = 61%, Cumulative CPU 1372.58 sec
2017-04-14 00:20:54,771 Stage-4 map = 100%,  reduce = 62%, Cumulative CPU 1390.25 sec
2017-04-14 00:20:57,899 Stage-4 map = 100%,  reduce = 63%, Cumulative CPU 1403.6 sec
2017-04-14 00:21:00,074 Stage-4 map = 100%,  reduce = 64%, Cumulative CPU 1410.88 sec
2017-04-14 00:21:02,235 Stage-4 map = 100%,  reduce = 66%, Cumulative CPU 1437.58 sec
2017-04-14 00:21:05,491 Stage-4 map = 100%,  reduce = 68%, Cumulative CPU 1463.55 sec
2017-04-14 00:21:08,609 Stage-4 map = 100%,  reduce = 69%, Cumulative CPU 1474.59 sec
2017-04-14 00:21:11,804 Stage-4 map = 100%,  reduce = 70%, Cumulative CPU 1488.69 sec
2017-04-14 00:21:14,134 Stage-4 map = 100%,  reduce = 71%, Cumulative CPU 1511.38 sec
2017-04-14 00:21:15,340 Stage-4 map = 100%,  reduce = 72%, Cumulative CPU 1515.78 sec
2017-04-14 00:21:16,425 Stage-4 map = 100%,  reduce = 73%, Cumulative CPU 1535.95 sec
2017-04-14 00:21:18,573 Stage-4 map = 100%,  reduce = 74%, Cumulative CPU 1543.99 sec
2017-04-14 00:21:20,723 Stage-4 map = 100%,  reduce = 75%, Cumulative CPU 1564.14 sec
2017-04-14 00:21:22,830 Stage-4 map = 100%,  reduce = 76%, Cumulative CPU 1569.12 sec
2017-04-14 00:21:24,968 Stage-4 map = 100%,  reduce = 77%, Cumulative CPU 1586.98 sec
2017-04-14 00:21:26,031 Stage-4 map = 100%,  reduce = 78%, Cumulative CPU 1595.37 sec
2017-04-14 00:21:27,068 Stage-4 map = 100%,  reduce = 79%, Cumulative CPU 1608.77 sec
2017-04-14 00:21:29,222 Stage-4 map = 100%,  reduce = 80%, Cumulative CPU 1625.89 sec
2017-04-14 00:21:32,428 Stage-4 map = 100%,  reduce = 81%, Cumulative CPU 1640.42 sec
2017-04-14 00:21:34,602 Stage-4 map = 100%,  reduce = 82%, Cumulative CPU 1654.51 sec
2017-04-14 00:21:36,337 Stage-4 map = 100%,  reduce = 83%, Cumulative CPU 1670.6 sec
2017-04-14 00:21:37,441 Stage-4 map = 100%,  reduce = 84%, Cumulative CPU 1674.76 sec
2017-04-14 00:21:39,713 Stage-4 map = 100%,  reduce = 85%, Cumulative CPU 1693.32 sec
2017-04-14 00:21:41,927 Stage-4 map = 100%,  reduce = 86%, Cumulative CPU 1706.82 sec
2017-04-14 00:21:43,024 Stage-4 map = 100%,  reduce = 87%, Cumulative CPU 1711.49 sec
2017-04-14 00:21:45,143 Stage-4 map = 100%,  reduce = 88%, Cumulative CPU 1724.26 sec
2017-04-14 00:21:48,579 Stage-4 map = 100%,  reduce = 89%, Cumulative CPU 1740.54 sec
2017-04-14 00:21:50,786 Stage-4 map = 100%,  reduce = 90%, Cumulative CPU 1756.81 sec
2017-04-14 00:21:52,074 Stage-4 map = 100%,  reduce = 91%, Cumulative CPU 1760.26 sec
2017-04-14 00:21:53,367 Stage-4 map = 100%,  reduce = 92%, Cumulative CPU 1769.15 sec
2017-04-14 00:21:54,470 Stage-4 map = 100%,  reduce = 93%, Cumulative CPU 1784.01 sec
2017-04-14 00:21:57,685 Stage-4 map = 100%,  reduce = 94%, Cumulative CPU 1801.78 sec
2017-04-14 00:21:59,812 Stage-4 map = 100%,  reduce = 95%, Cumulative CPU 1817.58 sec
2017-04-14 00:22:03,039 Stage-4 map = 100%,  reduce = 96%, Cumulative CPU 1833.76 sec
2017-04-14 00:22:04,208 Stage-4 map = 100%,  reduce = 97%, Cumulative CPU 1837.81 sec
2017-04-14 00:22:05,310 Stage-4 map = 100%,  reduce = 98%, Cumulative CPU 1856.03 sec
2017-04-14 00:22:06,406 Stage-4 map = 100%,  reduce = 99%, Cumulative CPU 1864.97 sec
2017-04-14 00:22:08,508 Stage-4 map = 100%,  reduce = 100%, Cumulative CPU 1882.87 sec
MapReduce Total cumulative CPU time: 31 minutes 22 seconds 870 msec
Ended Job = job_1490094830773_0675
Stage-7 is filtered out by condition resolver.
Stage-2 is selected by condition resolver.
Launching Job 3 out of 4
Number of reduce tasks not specified. Estimated from input data size: 315
In order to change the average load for a reducer (in bytes):
  set hive.exec.reducers.bytes.per.reducer=<number>
In order to limit the maximum number of reducers:
  set hive.exec.reducers.max=<number>
In order to set a constant number of reducers:
  set mapreduce.job.reduces=<number>
Starting Job = job_1490094830773_0676, Tracking URL = http://mac55:8088/proxy/application_1490094830773_0676/
Kill Command = /opt/cloudera/parcels/CDH-5.8.2-1.cdh5.8.2.p0.3/lib/hadoop/bin/hadoop job  -kill job_1490094830773_0676
Hadoop job information for Stage-2: number of mappers: 75; number of reducers: 315
2017-04-14 00:22:24,054 Stage-2 map = 0%,  reduce = 0%
2017-04-14 00:22:37,651 Stage-2 map = 1%,  reduce = 0%, Cumulative CPU 28.71 sec
2017-04-14 00:22:39,694 Stage-2 map = 2%,  reduce = 0%, Cumulative CPU 51.46 sec
2017-04-14 00:22:41,938 Stage-2 map = 3%,  reduce = 0%, Cumulative CPU 60.34 sec
2017-04-14 00:22:42,958 Stage-2 map = 4%,  reduce = 0%, Cumulative CPU 62.76 sec
2017-04-14 00:22:45,001 Stage-2 map = 5%,  reduce = 0%, Cumulative CPU 71.09 sec
2017-04-14 00:22:47,067 Stage-2 map = 6%,  reduce = 0%, Cumulative CPU 78.89 sec
2017-04-14 00:22:48,087 Stage-2 map = 7%,  reduce = 0%, Cumulative CPU 86.5 sec
2017-04-14 00:22:51,333 Stage-2 map = 8%,  reduce = 0%, Cumulative CPU 103.23 sec
2017-04-14 00:22:53,670 Stage-2 map = 10%,  reduce = 0%, Cumulative CPU 117.26 sec
2017-04-14 00:22:54,692 Stage-2 map = 11%,  reduce = 0%, Cumulative CPU 121.88 sec
2017-04-14 00:22:55,711 Stage-2 map = 12%,  reduce = 0%, Cumulative CPU 127.32 sec
2017-04-14 00:22:56,741 Stage-2 map = 13%,  reduce = 0%, Cumulative CPU 132.99 sec
2017-04-14 00:22:57,764 Stage-2 map = 16%,  reduce = 0%, Cumulative CPU 145.79 sec
2017-04-14 00:22:59,805 Stage-2 map = 17%,  reduce = 0%, Cumulative CPU 152.38 sec
2017-04-14 00:23:01,849 Stage-2 map = 18%,  reduce = 0%, Cumulative CPU 154.65 sec
2017-04-14 00:23:03,887 Stage-2 map = 19%,  reduce = 0%, Cumulative CPU 159.42 sec
2017-04-14 00:23:07,969 Stage-2 map = 20%,  reduce = 0%, Cumulative CPU 174.23 sec
2017-04-14 00:23:11,036 Stage-2 map = 21%,  reduce = 0%, Cumulative CPU 185.93 sec
2017-04-14 00:23:12,060 Stage-2 map = 22%,  reduce = 0%, Cumulative CPU 194.99 sec
2017-04-14 00:23:14,109 Stage-2 map = 23%,  reduce = 0%, Cumulative CPU 199.57 sec
2017-04-14 00:23:16,157 Stage-2 map = 24%,  reduce = 0%, Cumulative CPU 214.5 sec
2017-04-14 00:23:18,227 Stage-2 map = 25%,  reduce = 0%, Cumulative CPU 239.39 sec
2017-04-14 00:23:20,267 Stage-2 map = 27%,  reduce = 0%, Cumulative CPU 249.5 sec
2017-04-14 00:23:21,292 Stage-2 map = 29%,  reduce = 0%, Cumulative CPU 255.68 sec
2017-04-14 00:23:24,360 Stage-2 map = 30%,  reduce = 0%, Cumulative CPU 265.95 sec
2017-04-14 00:23:25,385 Stage-2 map = 31%,  reduce = 0%, Cumulative CPU 271.79 sec
2017-04-14 00:23:26,411 Stage-2 map = 32%,  reduce = 0%, Cumulative CPU 273.51 sec
2017-04-14 00:23:27,429 Stage-2 map = 33%,  reduce = 0%, Cumulative CPU 289.6 sec
2017-04-14 00:23:28,449 Stage-2 map = 34%,  reduce = 0%, Cumulative CPU 297.36 sec
2017-04-14 00:23:30,495 Stage-2 map = 35%,  reduce = 0%, Cumulative CPU 300.13 sec
2017-04-14 00:23:33,552 Stage-2 map = 36%,  reduce = 0%, Cumulative CPU 306.88 sec
2017-04-14 00:23:36,618 Stage-2 map = 38%,  reduce = 0%, Cumulative CPU 330.91 sec
2017-04-14 00:23:39,677 Stage-2 map = 39%,  reduce = 0%, Cumulative CPU 350.44 sec
2017-04-14 00:23:42,740 Stage-2 map = 41%,  reduce = 0%, Cumulative CPU 361.78 sec
2017-04-14 00:23:43,760 Stage-2 map = 42%,  reduce = 0%, Cumulative CPU 372.33 sec
2017-04-14 00:23:45,800 Stage-2 map = 43%,  reduce = 0%, Cumulative CPU 381.01 sec
2017-04-14 00:23:48,855 Stage-2 map = 44%,  reduce = 0%, Cumulative CPU 390.64 sec
2017-04-14 00:23:49,876 Stage-2 map = 45%,  reduce = 0%, Cumulative CPU 393.71 sec
2017-04-14 00:23:51,913 Stage-2 map = 48%,  reduce = 0%, Cumulative CPU 407.53 sec
2017-04-14 00:23:52,934 Stage-2 map = 49%,  reduce = 0%, Cumulative CPU 411.26 sec
2017-04-14 00:23:54,972 Stage-2 map = 51%,  reduce = 0%, Cumulative CPU 422.94 sec
2017-04-14 00:23:58,029 Stage-2 map = 52%,  reduce = 0%, Cumulative CPU 431.19 sec
2017-04-14 00:23:59,048 Stage-2 map = 53%,  reduce = 0%, Cumulative CPU 434.4 sec
2017-04-14 00:24:01,085 Stage-2 map = 54%,  reduce = 0%, Cumulative CPU 440.93 sec
2017-04-14 00:24:04,143 Stage-2 map = 55%,  reduce = 0%, Cumulative CPU 456.63 sec
2017-04-14 00:24:07,201 Stage-2 map = 56%,  reduce = 0%, Cumulative CPU 469.01 sec
2017-04-14 00:24:09,240 Stage-2 map = 57%,  reduce = 0%, Cumulative CPU 478.13 sec
2017-04-14 00:24:13,816 Stage-2 map = 58%,  reduce = 0%, Cumulative CPU 495.58 sec
2017-04-14 00:24:14,834 Stage-2 map = 59%,  reduce = 0%, Cumulative CPU 502.38 sec
2017-04-14 00:24:16,870 Stage-2 map = 61%,  reduce = 0%, Cumulative CPU 512.26 sec
2017-04-14 00:24:18,927 Stage-2 map = 62%,  reduce = 0%, Cumulative CPU 551.98 sec
2017-04-14 00:24:20,993 Stage-2 map = 63%,  reduce = 0%, Cumulative CPU 561.19 sec
2017-04-14 00:24:24,104 Stage-2 map = 64%,  reduce = 0%, Cumulative CPU 575.49 sec
2017-04-14 00:24:25,132 Stage-2 map = 65%,  reduce = 0%, Cumulative CPU 581.74 sec
2017-04-14 00:24:26,151 Stage-2 map = 66%,  reduce = 0%, Cumulative CPU 591.66 sec
2017-04-14 00:24:27,168 Stage-2 map = 67%,  reduce = 0%, Cumulative CPU 599.15 sec
2017-04-14 00:24:29,209 Stage-2 map = 68%,  reduce = 0%, Cumulative CPU 616.46 sec
2017-04-14 00:24:30,230 Stage-2 map = 69%,  reduce = 0%, Cumulative CPU 624.01 sec
2017-04-14 00:24:33,290 Stage-2 map = 71%,  reduce = 0%, Cumulative CPU 633.43 sec
2017-04-14 00:24:36,369 Stage-2 map = 72%,  reduce = 0%, Cumulative CPU 652.04 sec
2017-04-14 00:24:37,423 Stage-2 map = 73%,  reduce = 0%, Cumulative CPU 667.95 sec
2017-04-14 00:24:38,485 Stage-2 map = 74%,  reduce = 0%, Cumulative CPU 670.39 sec
2017-04-14 00:24:39,512 Stage-2 map = 75%,  reduce = 0%, Cumulative CPU 677.56 sec
2017-04-14 00:24:40,548 Stage-2 map = 76%,  reduce = 0%, Cumulative CPU 685.5 sec
2017-04-14 00:24:42,668 Stage-2 map = 77%,  reduce = 0%, Cumulative CPU 692.39 sec
2017-04-14 00:24:43,727 Stage-2 map = 78%,  reduce = 0%, Cumulative CPU 711.43 sec
2017-04-14 00:24:46,867 Stage-2 map = 79%,  reduce = 0%, Cumulative CPU 721.97 sec
2017-04-14 00:24:49,240 Stage-2 map = 80%,  reduce = 0%, Cumulative CPU 729.39 sec
2017-04-14 00:24:50,379 Stage-2 map = 81%,  reduce = 0%, Cumulative CPU 744.42 sec
2017-04-14 00:24:52,632 Stage-2 map = 82%,  reduce = 0%, Cumulative CPU 757.04 sec
2017-04-14 00:24:56,017 Stage-2 map = 84%,  reduce = 0%, Cumulative CPU 777.97 sec
2017-04-14 00:24:59,666 Stage-2 map = 86%,  reduce = 0%, Cumulative CPU 795.16 sec
2017-04-14 00:25:02,301 Stage-2 map = 87%,  reduce = 0%, Cumulative CPU 804.92 sec
2017-04-14 00:25:08,420 Stage-2 map = 88%,  reduce = 0%, Cumulative CPU 820.53 sec
2017-04-14 00:25:11,684 Stage-2 map = 90%,  reduce = 0%, Cumulative CPU 849.9 sec
2017-04-14 00:25:13,850 Stage-2 map = 92%,  reduce = 0%, Cumulative CPU 863.61 sec
2017-04-14 00:25:17,421 Stage-2 map = 93%,  reduce = 0%, Cumulative CPU 880.01 sec
2017-04-14 00:25:20,870 Stage-2 map = 94%,  reduce = 0%, Cumulative CPU 899.16 sec
2017-04-14 00:25:25,230 Stage-2 map = 95%,  reduce = 0%, Cumulative CPU 919.52 sec
2017-04-14 00:25:27,354 Stage-2 map = 96%,  reduce = 0%, Cumulative CPU 930.34 sec
2017-04-14 00:25:29,423 Stage-2 map = 97%,  reduce = 0%, Cumulative CPU 935.79 sec
2017-04-14 00:25:30,479 Stage-2 map = 98%,  reduce = 0%, Cumulative CPU 945.65 sec
2017-04-14 00:25:33,595 Stage-2 map = 98%,  reduce = 1%, Cumulative CPU 955.91 sec
2017-04-14 00:25:35,692 Stage-2 map = 99%,  reduce = 1%, Cumulative CPU 960.59 sec
2017-04-14 00:25:51,509 Stage-2 map = 100%,  reduce = 1%, Cumulative CPU 993.51 sec
2017-04-14 00:25:53,647 Stage-2 map = 100%,  reduce = 2%, Cumulative CPU 1005.96 sec
2017-04-14 00:25:54,856 Stage-2 map = 100%,  reduce = 3%, Cumulative CPU 1023.29 sec
2017-04-14 00:26:02,606 Stage-2 map = 100%,  reduce = 4%, Cumulative CPU 1054.44 sec
2017-04-14 00:26:19,161 Stage-2 map = 100%,  reduce = 5%, Cumulative CPU 1074.29 sec
2017-04-14 00:26:49,446 Stage-2 map = 100%,  reduce = 6%, Cumulative CPU 1092.8 sec
2017-04-14 00:27:14,060 Stage-2 map = 100%,  reduce = 7%, Cumulative CPU 1119.58 sec
2017-04-14 00:27:20,617 Stage-2 map = 100%,  reduce = 8%, Cumulative CPU 1143.27 sec
2017-04-14 00:27:23,694 Stage-2 map = 100%,  reduce = 9%, Cumulative CPU 1151.35 sec
2017-04-14 00:27:33,855 Stage-2 map = 100%,  reduce = 10%, Cumulative CPU 1171.81 sec
2017-04-14 00:27:45,285 Stage-2 map = 100%,  reduce = 11%, Cumulative CPU 1189.17 sec
2017-04-14 00:28:01,245 Stage-2 map = 100%,  reduce = 12%, Cumulative CPU 1208.09 sec
2017-04-14 00:28:26,754 Stage-2 map = 100%,  reduce = 13%, Cumulative CPU 1227.8 sec
2017-04-14 00:28:43,796 Stage-2 map = 100%,  reduce = 14%, Cumulative CPU 1244.59 sec
2017-04-14 00:28:50,995 Stage-2 map = 100%,  reduce = 15%, Cumulative CPU 1262.31 sec
2017-04-14 00:28:58,660 Stage-2 map = 100%,  reduce = 16%, Cumulative CPU 1284.67 sec
2017-04-14 00:29:01,100 Stage-2 map = 100%,  reduce = 17%, Cumulative CPU 1300.76 sec
2017-04-14 00:29:04,748 Stage-2 map = 100%,  reduce = 18%, Cumulative CPU 1318.53 sec
2017-04-14 00:29:12,243 Stage-2 map = 100%,  reduce = 19%, Cumulative CPU 1335.37 sec
2017-04-14 00:29:25,806 Stage-2 map = 100%,  reduce = 20%, Cumulative CPU 1354.81 sec
2017-04-14 00:29:39,902 Stage-2 map = 100%,  reduce = 21%, Cumulative CPU 1377.57 sec
2017-04-14 00:29:59,750 Stage-2 map = 100%,  reduce = 22%, Cumulative CPU 1394.08 sec
2017-04-14 00:30:16,079 Stage-2 map = 100%,  reduce = 23%, Cumulative CPU 1414.71 sec
2017-04-14 00:30:22,222 Stage-2 map = 100%,  reduce = 24%, Cumulative CPU 1429.96 sec
2017-04-14 00:30:33,268 Stage-2 map = 100%,  reduce = 25%, Cumulative CPU 1451.88 sec
2017-04-14 00:30:44,278 Stage-2 map = 100%,  reduce = 26%, Cumulative CPU 1474.55 sec
2017-04-14 00:30:54,692 Stage-2 map = 100%,  reduce = 27%, Cumulative CPU 1494.05 sec
2017-04-14 00:31:02,131 Stage-2 map = 100%,  reduce = 28%, Cumulative CPU 1509.13 sec
2017-04-14 00:31:20,131 Stage-2 map = 100%,  reduce = 29%, Cumulative CPU 1528.53 sec
2017-04-14 00:31:37,874 Stage-2 map = 100%,  reduce = 30%, Cumulative CPU 1548.09 sec
2017-04-14 00:31:54,276 Stage-2 map = 100%,  reduce = 31%, Cumulative CPU 1564.08 sec
2017-04-14 00:32:04,612 Stage-2 map = 100%,  reduce = 32%, Cumulative CPU 1583.74 sec
2017-04-14 00:32:14,931 Stage-2 map = 100%,  reduce = 33%, Cumulative CPU 1602.37 sec
2017-04-14 00:32:21,346 Stage-2 map = 100%,  reduce = 34%, Cumulative CPU 1621.77 sec
2017-04-14 00:32:31,712 Stage-2 map = 100%,  reduce = 35%, Cumulative CPU 1638.04 sec
2017-04-14 00:32:42,389 Stage-2 map = 100%,  reduce = 36%, Cumulative CPU 1654.48 sec
2017-04-14 00:32:54,265 Stage-2 map = 100%,  reduce = 37%, Cumulative CPU 1673.66 sec
2017-04-14 00:33:07,916 Stage-2 map = 100%,  reduce = 38%, Cumulative CPU 1692.95 sec
2017-04-14 00:33:19,759 Stage-2 map = 100%,  reduce = 39%, Cumulative CPU 1708.84 sec
2017-04-14 00:33:35,556 Stage-2 map = 100%,  reduce = 40%, Cumulative CPU 1733.22 sec
2017-04-14 00:33:45,679 Stage-2 map = 100%,  reduce = 41%, Cumulative CPU 1748.82 sec
2017-04-14 00:33:56,822 Stage-2 map = 100%,  reduce = 42%, Cumulative CPU 1764.24 sec
2017-04-14 00:34:04,175 Stage-2 map = 100%,  reduce = 43%, Cumulative CPU 1781.4 sec
2017-04-14 00:34:18,061 Stage-2 map = 100%,  reduce = 44%, Cumulative CPU 1807.11 sec
2017-04-14 00:34:26,585 Stage-2 map = 100%,  reduce = 45%, Cumulative CPU 1820.26 sec
2017-04-14 00:34:35,151 Stage-2 map = 100%,  reduce = 46%, Cumulative CPU 1838.39 sec
2017-04-14 00:34:53,279 Stage-2 map = 100%,  reduce = 47%, Cumulative CPU 1857.79 sec
2017-04-14 00:35:07,760 Stage-2 map = 100%,  reduce = 48%, Cumulative CPU 1875.51 sec
2017-04-14 00:35:25,136 Stage-2 map = 100%,  reduce = 49%, Cumulative CPU 1895.53 sec
2017-04-14 00:35:32,984 Stage-2 map = 100%,  reduce = 50%, Cumulative CPU 1916.03 sec
2017-04-14 00:35:45,489 Stage-2 map = 100%,  reduce = 51%, Cumulative CPU 1934.85 sec
2017-04-14 00:35:52,849 Stage-2 map = 100%,  reduce = 52%, Cumulative CPU 1949.12 sec
2017-04-14 00:36:07,600 Stage-2 map = 100%,  reduce = 53%, Cumulative CPU 1971.69 sec
2017-04-14 00:36:26,453 Stage-2 map = 100%,  reduce = 54%, Cumulative CPU 1988.76 sec
2017-04-14 00:36:42,860 Stage-2 map = 100%,  reduce = 55%, Cumulative CPU 2006.3 sec
2017-04-14 00:37:00,579 Stage-2 map = 100%,  reduce = 56%, Cumulative CPU 2027.15 sec
2017-04-14 00:37:11,439 Stage-2 map = 100%,  reduce = 57%, Cumulative CPU 2044.67 sec
2017-04-14 00:37:17,557 Stage-2 map = 100%,  reduce = 58%, Cumulative CPU 2065.05 sec
2017-04-14 00:37:26,576 Stage-2 map = 100%,  reduce = 59%, Cumulative CPU 2080.56 sec
2017-04-14 00:37:48,166 Stage-2 map = 100%,  reduce = 60%, Cumulative CPU 2102.03 sec
2017-04-14 00:37:59,505 Stage-2 map = 100%,  reduce = 61%, Cumulative CPU 2123.32 sec
2017-04-14 00:38:20,520 Stage-2 map = 100%,  reduce = 62%, Cumulative CPU 2141.5 sec
2017-04-14 00:38:32,755 Stage-2 map = 100%,  reduce = 63%, Cumulative CPU 2158.46 sec
2017-04-14 00:38:40,697 Stage-2 map = 100%,  reduce = 64%, Cumulative CPU 2176.16 sec
2017-04-14 00:38:51,648 Stage-2 map = 100%,  reduce = 65%, Cumulative CPU 2200.74 sec
2017-04-14 00:38:58,818 Stage-2 map = 100%,  reduce = 66%, Cumulative CPU 2212.69 sec
2017-04-14 00:39:15,030 Stage-2 map = 100%,  reduce = 67%, Cumulative CPU 2234.11 sec
2017-04-14 00:39:29,023 Stage-2 map = 100%,  reduce = 68%, Cumulative CPU 2251.71 sec
2017-04-14 00:39:43,933 Stage-2 map = 100%,  reduce = 69%, Cumulative CPU 2270.45 sec
2017-04-14 00:39:58,304 Stage-2 map = 100%,  reduce = 70%, Cumulative CPU 2287.93 sec
2017-04-14 00:40:07,708 Stage-2 map = 100%,  reduce = 71%, Cumulative CPU 2308.89 sec
2017-04-14 00:40:24,918 Stage-2 map = 100%,  reduce = 72%, Cumulative CPU 2327.07 sec
2017-04-14 00:40:28,520 Stage-2 map = 100%,  reduce = 73%, Cumulative CPU 2345.45 sec
2017-04-14 00:40:38,555 Stage-2 map = 100%,  reduce = 74%, Cumulative CPU 2361.89 sec
2017-04-14 00:40:50,403 Stage-2 map = 100%,  reduce = 75%, Cumulative CPU 2383.83 sec
2017-04-14 00:41:06,308 Stage-2 map = 100%,  reduce = 76%, Cumulative CPU 2402.32 sec
2017-04-14 00:41:16,065 Stage-2 map = 100%,  reduce = 77%, Cumulative CPU 2426.66 sec
2017-04-14 00:41:25,056 Stage-2 map = 100%,  reduce = 78%, Cumulative CPU 2437.8 sec
2017-04-14 00:41:32,249 Stage-2 map = 100%,  reduce = 79%, Cumulative CPU 2453.45 sec
2017-04-14 00:41:47,584 Stage-2 map = 100%,  reduce = 80%, Cumulative CPU 2477.54 sec
2017-04-14 00:41:54,843 Stage-2 map = 100%,  reduce = 81%, Cumulative CPU 2494.14 sec
2017-04-14 00:42:01,231 Stage-2 map = 100%,  reduce = 82%, Cumulative CPU 2505.55 sec
2017-04-14 00:42:09,755 Stage-2 map = 100%,  reduce = 83%, Cumulative CPU 2525.83 sec
2017-04-14 00:42:23,336 Stage-2 map = 100%,  reduce = 84%, Cumulative CPU 2546.03 sec
2017-04-14 00:42:35,543 Stage-2 map = 100%,  reduce = 85%, Cumulative CPU 2563.65 sec
2017-04-14 00:42:51,294 Stage-2 map = 100%,  reduce = 86%, Cumulative CPU 2584.03 sec
2017-04-14 00:43:00,367 Stage-2 map = 100%,  reduce = 87%, Cumulative CPU 2599.6 sec
2017-04-14 00:43:06,780 Stage-2 map = 100%,  reduce = 88%, Cumulative CPU 2615.63 sec
2017-04-14 00:43:11,868 Stage-2 map = 100%,  reduce = 89%, Cumulative CPU 2637.04 sec
2017-04-14 00:43:17,479 Stage-2 map = 100%,  reduce = 90%, Cumulative CPU 2665.89 sec
2017-04-14 00:43:20,994 Stage-2 map = 100%,  reduce = 91%, Cumulative CPU 2681.45 sec
2017-04-14 00:43:29,552 Stage-2 map = 100%,  reduce = 92%, Cumulative CPU 2697.99 sec
2017-04-14 00:43:40,711 Stage-2 map = 100%,  reduce = 93%, Cumulative CPU 2716.47 sec
2017-04-14 00:43:47,901 Stage-2 map = 100%,  reduce = 94%, Cumulative CPU 2732.74 sec
2017-04-14 00:44:06,651 Stage-2 map = 100%,  reduce = 95%, Cumulative CPU 2754.59 sec
2017-04-14 00:44:24,751 Stage-2 map = 100%,  reduce = 96%, Cumulative CPU 2776.55 sec
2017-04-14 00:44:38,165 Stage-2 map = 100%,  reduce = 97%, Cumulative CPU 2790.28 sec
2017-04-14 00:44:44,152 Stage-2 map = 100%,  reduce = 98%, Cumulative CPU 2811.51 sec
2017-04-14 00:44:53,551 Stage-2 map = 100%,  reduce = 99%, Cumulative CPU 2827.91 sec
2017-04-14 00:45:29,851 Stage-2 map = 100%,  reduce = 100%, Cumulative CPU 2856.32 sec
MapReduce Total cumulative CPU time: 47 minutes 36 seconds 320 msec
Ended Job = job_1490094830773_0676
Loading data to table esplus.tempapplication_text
Table esplus.tempapplication_text stats: [numFiles=419, numRows=85911023, totalSize=39373335020, rawDataSize=39287423997]
MapReduce Jobs Launched:
Stage-Stage-1: Map: 62  Reduce: 297   Cumulative CPU: 2690.91 sec   HDFS Read: 19915045407 HDFS Write: 18656851374 SUCCESS
Stage-Stage-4: Map: 62  Reduce: 297   Cumulative CPU: 1882.87 sec   HDFS Read: 19914448766 HDFS Write: 2457246153 SUCCESS
Stage-Stage-2: Map: 75  Reduce: 315   Cumulative CPU: 2856.32 sec   HDFS Read: 21117090388 HDFS Write: 19468109505 SUCCESS
Total MapReduce CPU Time Spent: 0 days 2 hours 3 minutes 50 seconds 100 msec
OK
Time taken: 2961.959 seconds


hive> dfs -du -s -h /user/hive/warehouse/esplus.db/tempapplication_text;
36.7 G  110.0 G  /user/hive/warehouse/esplus.db/tempapplication_text




insert into table TempApplication_orc
select   a.username
,a.machinename
,a.machineid
,a.ipaddress
,a.domainname
,a.pcmlogeventid
,a.modulename
,a.filename
,a.productname
,a.companyname
,a.description
,a.text
,a.activetime
,b.timeslot as datetime
,b.timeslot
,a.date
from
 (
select   username, machinename, machineid, ipaddress,domainname,pcmlogeventid,modulename,filename,productname,datetime
,companyname,description,text,activetime,timeslot,date
,row_number() over (partition by lower(username) order by datetime) as row_number  
from TempApplication_orc
where lower(modulename) NOT IN ('startwindowsswitch','stopwindowsswitch')
AND DateTime is not null AND DateTime <> ''
AND Username is not null AND Username <> '' AND length(trim(Username)) > 0
 ) a
left join
 (
select   username, machinename, machineid, ipaddress,domainname,pcmlogeventid,modulename,filename,productname,datetime
,companyname,description,text,activetime,timeslot,date
,row_number() over (partition by lower(username) order by datetime) as row_number
from TempApplication_orc
where lower(modulename) NOT IN ('startwindowsswitch','stopwindowsswitch')
AND DateTime is not null AND DateTime <> ''
AND Username is not null AND Username <> '' AND length(trim(Username)) > 0
) b
on b.row_number =a.row_number +1
and lower(a.username)=lower(b.username);

hive> insert into table TempApplication_orc
    > select   a.username
    > ,a.machinename
    > ,a.machineid
    > ,a.ipaddress
    > ,a.domainname
    > ,a.pcmlogeventid
    > ,a.modulename
    > ,a.filename
    > ,a.productname
    > ,a.companyname
    > ,a.description
    > ,a.text
    > ,a.activetime
    > ,b.timeslot as datetime
    > ,b.timeslot
    > ,a.date
    > from
    >  (
    > select   username, machinename, machineid, ipaddress,domainname,pcmlogeventid,modulename,filename,productname,datetime
    > ,companyname,description,text,activetime,timeslot,date
    > ,row_number() over (partition by lower(username) order by datetime) as row_number
    > from TempApplication_orc
    > where lower(modulename) NOT IN ('startwindowsswitch','stopwindowsswitch')
    > AND DateTime is not null AND DateTime <> ''
    > AND Username is not null AND Username <> '' AND length(trim(Username)) > 0
    >  ) a
    > left join
    >  (
    > select   username, machinename, machineid, ipaddress,domainname,pcmlogeventid,modulename,filename,productname,datetime
    > ,companyname,description,text,activetime,timeslot,date
    > ,row_number() over (partition by lower(username) order by datetime) as row_number
    > from TempApplication_orc
    > where lower(modulename) NOT IN ('startwindowsswitch','stopwindowsswitch')
    > AND DateTime is not null AND DateTime <> ''
    > AND Username is not null AND Username <> '' AND length(trim(Username)) > 0
    > ) b
    > on b.row_number =a.row_number +1
    > and lower(a.username)=lower(b.username);
Query ID = root_20170414020404_e9d8cb7a-98e7-477c-8d40-f0a9bca7a571
Total jobs = 4
Launching Job 1 out of 4
Number of reduce tasks not specified. Estimated from input data size: 8
In order to change the average load for a reducer (in bytes):
  set hive.exec.reducers.bytes.per.reducer=<number>
In order to limit the maximum number of reducers:
  set hive.exec.reducers.max=<number>
In order to set a constant number of reducers:
  set mapreduce.job.reduces=<number>
Starting Job = job_1490094830773_0685, Tracking URL = http://mac55:8088/proxy/application_1490094830773_0685/
Kill Command = /opt/cloudera/parcels/CDH-5.8.2-1.cdh5.8.2.p0.3/lib/hadoop/bin/hadoop job  -kill job_1490094830773_0685
Hadoop job information for Stage-1: number of mappers: 2; number of reducers: 8
2017-04-14 02:04:51,543 Stage-1 map = 0%,  reduce = 0%
2017-04-14 02:05:51,933 Stage-1 map = 0%,  reduce = 0%, Cumulative CPU 138.69 sec
2017-04-14 02:06:19,497 Stage-1 map = 17%,  reduce = 0%, Cumulative CPU 206.62 sec
2017-04-14 02:06:45,043 Stage-1 map = 46%,  reduce = 0%, Cumulative CPU 270.63 sec
2017-04-14 02:07:02,407 Stage-1 map = 52%,  reduce = 0%, Cumulative CPU 315.97 sec
2017-04-14 02:07:05,486 Stage-1 map = 56%,  reduce = 0%, Cumulative CPU 322.88 sec
2017-04-14 02:07:08,546 Stage-1 map = 60%,  reduce = 0%, Cumulative CPU 329.63 sec
2017-04-14 02:07:11,607 Stage-1 map = 65%,  reduce = 0%, Cumulative CPU 336.4 sec
2017-04-14 02:07:14,667 Stage-1 map = 67%,  reduce = 0%, Cumulative CPU 343.17 sec
2017-04-14 02:07:34,062 Stage-1 map = 85%,  reduce = 0%, Cumulative CPU 369.75 sec
2017-04-14 02:07:37,134 Stage-1 map = 88%,  reduce = 0%, Cumulative CPU 372.81 sec
2017-04-14 02:07:40,197 Stage-1 map = 90%,  reduce = 0%, Cumulative CPU 375.84 sec
2017-04-14 02:07:43,267 Stage-1 map = 94%,  reduce = 0%, Cumulative CPU 378.84 sec
2017-04-14 02:07:46,339 Stage-1 map = 96%,  reduce = 0%, Cumulative CPU 381.63 sec
2017-04-14 02:07:49,403 Stage-1 map = 98%,  reduce = 0%, Cumulative CPU 383.13 sec
2017-04-14 02:07:55,537 Stage-1 map = 100%,  reduce = 0%, Cumulative CPU 385.5 sec
2017-04-14 02:08:11,013 Stage-1 map = 100%,  reduce = 8%, Cumulative CPU 390.08 sec
2017-04-14 02:08:12,315 Stage-1 map = 100%,  reduce = 17%, Cumulative CPU 392.58 sec
2017-04-14 02:08:35,668 Stage-1 map = 100%,  reduce = 23%, Cumulative CPU 399.38 sec
2017-04-14 02:08:41,740 Stage-1 map = 100%,  reduce = 29%, Cumulative CPU 405.45 sec
2017-04-14 02:09:15,011 Stage-1 map = 100%,  reduce = 36%, Cumulative CPU 412.65 sec
2017-04-14 02:09:18,526 Stage-1 map = 100%,  reduce = 42%, Cumulative CPU 418.81 sec
2017-04-14 02:09:20,875 Stage-1 map = 100%,  reduce = 55%, Cumulative CPU 430.89 sec
2017-04-14 02:09:25,930 Stage-1 map = 100%,  reduce = 61%, Cumulative CPU 438.88 sec
2017-04-14 02:09:27,131 Stage-1 map = 100%,  reduce = 68%, Cumulative CPU 444.56 sec
2017-04-14 02:09:46,277 Stage-1 map = 100%,  reduce = 69%, Cumulative CPU 463.41 sec
2017-04-14 02:10:15,948 Stage-1 map = 100%,  reduce = 70%, Cumulative CPU 481.74 sec
2017-04-14 02:10:41,889 Stage-1 map = 100%,  reduce = 71%, Cumulative CPU 499.47 sec
2017-04-14 02:11:07,854 Stage-1 map = 100%,  reduce = 72%, Cumulative CPU 518.26 sec
2017-04-14 02:11:24,405 Stage-1 map = 100%,  reduce = 73%, Cumulative CPU 540.07 sec
2017-04-14 02:11:48,228 Stage-1 map = 100%,  reduce = 74%, Cumulative CPU 558.18 sec
2017-04-14 02:12:18,280 Stage-1 map = 100%,  reduce = 75%, Cumulative CPU 575.81 sec
2017-04-14 02:12:42,171 Stage-1 map = 100%,  reduce = 76%, Cumulative CPU 590.98 sec
2017-04-14 02:13:07,484 Stage-1 map = 100%,  reduce = 77%, Cumulative CPU 608.66 sec
2017-04-14 02:13:27,804 Stage-1 map = 100%,  reduce = 78%, Cumulative CPU 627.45 sec
2017-04-14 02:13:36,792 Stage-1 map = 100%,  reduce = 79%, Cumulative CPU 643.61 sec
2017-04-14 02:13:45,789 Stage-1 map = 100%,  reduce = 80%, Cumulative CPU 658.8 sec
2017-04-14 02:13:51,411 Stage-1 map = 100%,  reduce = 81%, Cumulative CPU 671.35 sec
2017-04-14 02:14:01,923 Stage-1 map = 100%,  reduce = 82%, Cumulative CPU 685.18 sec
2017-04-14 02:14:21,251 Stage-1 map = 100%,  reduce = 83%, Cumulative CPU 699.69 sec
2017-04-14 02:14:59,935 Stage-1 map = 100%,  reduce = 84%, Cumulative CPU 716.03 sec
2017-04-14 02:15:30,055 Stage-1 map = 100%,  reduce = 85%, Cumulative CPU 731.03 sec
2017-04-14 02:16:03,607 Stage-1 map = 100%,  reduce = 86%, Cumulative CPU 748.24 sec
2017-04-14 02:16:34,644 Stage-1 map = 100%,  reduce = 87%, Cumulative CPU 762.68 sec
2017-04-14 02:17:04,371 Stage-1 map = 100%,  reduce = 88%, Cumulative CPU 778.5 sec
2017-04-14 02:17:34,484 Stage-1 map = 100%,  reduce = 89%, Cumulative CPU 793.69 sec
2017-04-14 02:18:10,266 Stage-1 map = 100%,  reduce = 90%, Cumulative CPU 809.05 sec
2017-04-14 02:18:40,228 Stage-1 map = 100%,  reduce = 91%, Cumulative CPU 823.13 sec
2017-04-14 02:19:09,684 Stage-1 map = 100%,  reduce = 92%, Cumulative CPU 839.46 sec
2017-04-14 02:19:58,779 Stage-1 map = 100%,  reduce = 93%, Cumulative CPU 858.6 sec
2017-04-14 02:20:06,464 Stage-1 map = 100%,  reduce = 94%, Cumulative CPU 870.66 sec
2017-04-14 02:20:13,955 Stage-1 map = 100%,  reduce = 95%, Cumulative CPU 888.23 sec
2017-04-14 02:20:26,154 Stage-1 map = 100%,  reduce = 96%, Cumulative CPU 906.71 sec
2017-04-14 02:21:07,385 Stage-1 map = 100%,  reduce = 97%, Cumulative CPU 920.09 sec
2017-04-14 02:21:22,742 Stage-1 map = 100%,  reduce = 98%, Cumulative CPU 932.42 sec
2017-04-14 02:22:01,546 Stage-1 map = 100%,  reduce = 99%, Cumulative CPU 947.13 sec
2017-04-14 02:22:57,580 Stage-1 map = 100%,  reduce = 100%, Cumulative CPU 966.68 sec
MapReduce Total cumulative CPU time: 16 minutes 6 seconds 680 msec
Ended Job = job_1490094830773_0685
Launching Job 2 out of 4
Number of reduce tasks not specified. Estimated from input data size: 8
In order to change the average load for a reducer (in bytes):
  set hive.exec.reducers.bytes.per.reducer=<number>
In order to limit the maximum number of reducers:
  set hive.exec.reducers.max=<number>
In order to set a constant number of reducers:
  set mapreduce.job.reduces=<number>
Starting Job = job_1490094830773_0686, Tracking URL = http://mac55:8088/proxy/application_1490094830773_0686/
Kill Command = /opt/cloudera/parcels/CDH-5.8.2-1.cdh5.8.2.p0.3/lib/hadoop/bin/hadoop job  -kill job_1490094830773_0686
Hadoop job information for Stage-4: number of mappers: 2; number of reducers: 8
2017-04-14 02:23:15,654 Stage-4 map = 0%,  reduce = 0%
2017-04-14 02:24:16,244 Stage-4 map = 17%,  reduce = 0%, Cumulative CPU 138.67 sec
2017-04-14 02:24:30,581 Stage-4 map = 46%,  reduce = 0%, Cumulative CPU 172.68 sec
2017-04-14 02:24:42,868 Stage-4 map = 54%,  reduce = 0%, Cumulative CPU 203.88 sec
2017-04-14 02:24:45,944 Stage-4 map = 63%,  reduce = 0%, Cumulative CPU 209.98 sec
2017-04-14 02:24:47,989 Stage-4 map = 67%,  reduce = 0%, Cumulative CPU 216.71 sec
2017-04-14 02:25:01,289 Stage-4 map = 83%,  reduce = 0%, Cumulative CPU 234.6 sec
2017-04-14 02:25:04,355 Stage-4 map = 88%,  reduce = 0%, Cumulative CPU 237.75 sec
2017-04-14 02:25:07,422 Stage-4 map = 94%,  reduce = 0%, Cumulative CPU 240.79 sec
2017-04-14 02:25:10,488 Stage-4 map = 100%,  reduce = 0%, Cumulative CPU 243.79 sec
2017-04-14 02:25:21,921 Stage-4 map = 100%,  reduce = 13%, Cumulative CPU 246.95 sec
2017-04-14 02:25:23,188 Stage-4 map = 100%,  reduce = 17%, Cumulative CPU 247.58 sec
2017-04-14 02:25:25,916 Stage-4 map = 100%,  reduce = 23%, Cumulative CPU 251.76 sec
2017-04-14 02:25:27,401 Stage-4 map = 100%,  reduce = 29%, Cumulative CPU 252.44 sec
2017-04-14 02:25:30,898 Stage-4 map = 100%,  reduce = 48%, Cumulative CPU 259.09 sec
2017-04-14 02:25:33,222 Stage-4 map = 100%,  reduce = 49%, Cumulative CPU 259.42 sec
2017-04-14 02:25:34,376 Stage-4 map = 100%,  reduce = 62%, Cumulative CPU 277.68 sec
2017-04-14 02:25:36,673 Stage-4 map = 100%,  reduce = 65%, Cumulative CPU 292.77 sec
2017-04-14 02:25:37,894 Stage-4 map = 100%,  reduce = 71%, Cumulative CPU 301.51 sec
2017-04-14 02:25:40,348 Stage-4 map = 100%,  reduce = 74%, Cumulative CPU 317.15 sec
2017-04-14 02:25:42,729 Stage-4 map = 100%,  reduce = 75%, Cumulative CPU 321.01 sec
2017-04-14 02:25:43,897 Stage-4 map = 100%,  reduce = 76%, Cumulative CPU 322.34 sec
2017-04-14 02:25:46,513 Stage-4 map = 100%,  reduce = 77%, Cumulative CPU 345.49 sec
2017-04-14 02:25:48,906 Stage-4 map = 100%,  reduce = 79%, Cumulative CPU 353.01 sec
2017-04-14 02:25:51,292 Stage-4 map = 100%,  reduce = 80%, Cumulative CPU 356.89 sec
2017-04-14 02:25:52,488 Stage-4 map = 100%,  reduce = 81%, Cumulative CPU 367.57 sec
2017-04-14 02:25:55,051 Stage-4 map = 100%,  reduce = 82%, Cumulative CPU 371.71 sec
2017-04-14 02:25:56,216 Stage-4 map = 100%,  reduce = 83%, Cumulative CPU 376.0 sec
2017-04-14 02:25:58,627 Stage-4 map = 100%,  reduce = 84%, Cumulative CPU 381.03 sec
2017-04-14 02:26:01,026 Stage-4 map = 100%,  reduce = 85%, Cumulative CPU 382.69 sec
2017-04-14 02:26:04,641 Stage-4 map = 100%,  reduce = 86%, Cumulative CPU 386.71 sec
2017-04-14 02:26:10,499 Stage-4 map = 100%,  reduce = 87%, Cumulative CPU 391.87 sec
2017-04-14 02:26:16,662 Stage-4 map = 100%,  reduce = 88%, Cumulative CPU 402.18 sec
2017-04-14 02:26:22,688 Stage-4 map = 100%,  reduce = 89%, Cumulative CPU 408.13 sec
2017-04-14 02:26:31,047 Stage-4 map = 100%,  reduce = 90%, Cumulative CPU 412.52 sec
2017-04-14 02:26:38,151 Stage-4 map = 100%,  reduce = 91%, Cumulative CPU 418.97 sec
2017-04-14 02:26:44,479 Stage-4 map = 100%,  reduce = 92%, Cumulative CPU 423.86 sec
2017-04-14 02:26:50,496 Stage-4 map = 100%,  reduce = 93%, Cumulative CPU 428.63 sec
2017-04-14 02:26:56,501 Stage-4 map = 100%,  reduce = 94%, Cumulative CPU 433.46 sec
2017-04-14 02:27:02,436 Stage-4 map = 100%,  reduce = 95%, Cumulative CPU 439.04 sec
2017-04-14 02:27:10,692 Stage-4 map = 100%,  reduce = 96%, Cumulative CPU 444.83 sec
2017-04-14 02:27:16,670 Stage-4 map = 100%,  reduce = 97%, Cumulative CPU 449.51 sec
2017-04-14 02:27:23,701 Stage-4 map = 100%,  reduce = 98%, Cumulative CPU 454.23 sec
2017-04-14 02:27:32,315 Stage-4 map = 100%,  reduce = 99%, Cumulative CPU 459.67 sec
2017-04-14 02:27:41,041 Stage-4 map = 100%,  reduce = 100%, Cumulative CPU 464.88 sec
MapReduce Total cumulative CPU time: 7 minutes 44 seconds 880 msec
Ended Job = job_1490094830773_0686
Stage-7 is filtered out by condition resolver.
Stage-2 is selected by condition resolver.
Launching Job 3 out of 4
Number of reduce tasks not specified. Estimated from input data size: 315
In order to change the average load for a reducer (in bytes):
  set hive.exec.reducers.bytes.per.reducer=<number>
In order to limit the maximum number of reducers:
  set hive.exec.reducers.max=<number>
In order to set a constant number of reducers:
  set mapreduce.job.reduces=<number>
Starting Job = job_1490094830773_0687, Tracking URL = http://mac55:8088/proxy/application_1490094830773_0687/
Kill Command = /opt/cloudera/parcels/CDH-5.8.2-1.cdh5.8.2.p0.3/lib/hadoop/bin/hadoop job  -kill job_1490094830773_0687
Hadoop job information for Stage-2: number of mappers: 77; number of reducers: 315
2017-04-14 02:27:53,177 Stage-2 map = 0%,  reduce = 0%
2017-04-14 02:28:05,889 Stage-2 map = 1%,  reduce = 0%, Cumulative CPU 45.61 sec
2017-04-14 02:28:08,957 Stage-2 map = 2%,  reduce = 0%, Cumulative CPU 72.5 sec
2017-04-14 02:28:15,127 Stage-2 map = 4%,  reduce = 0%, Cumulative CPU 109.82 sec
2017-04-14 02:28:17,173 Stage-2 map = 5%,  reduce = 0%, Cumulative CPU 111.47 sec
2017-04-14 02:28:18,501 Stage-2 map = 8%,  reduce = 0%, Cumulative CPU 134.75 sec
2017-04-14 02:28:19,535 Stage-2 map = 9%,  reduce = 0%, Cumulative CPU 136.94 sec
2017-04-14 02:28:21,589 Stage-2 map = 11%,  reduce = 0%, Cumulative CPU 159.02 sec
2017-04-14 02:28:23,771 Stage-2 map = 12%,  reduce = 0%, Cumulative CPU 164.65 sec
2017-04-14 02:28:26,840 Stage-2 map = 13%,  reduce = 0%, Cumulative CPU 190.44 sec
2017-04-14 02:28:29,913 Stage-2 map = 14%,  reduce = 0%, Cumulative CPU 212.91 sec
2017-04-14 02:28:30,935 Stage-2 map = 15%,  reduce = 0%, Cumulative CPU 221.39 sec
2017-04-14 02:28:31,958 Stage-2 map = 16%,  reduce = 0%, Cumulative CPU 222.48 sec
2017-04-14 02:28:34,005 Stage-2 map = 17%,  reduce = 0%, Cumulative CPU 236.29 sec
2017-04-14 02:28:35,028 Stage-2 map = 18%,  reduce = 0%, Cumulative CPU 238.51 sec
2017-04-14 02:28:37,068 Stage-2 map = 19%,  reduce = 0%, Cumulative CPU 261.84 sec
2017-04-14 02:28:39,111 Stage-2 map = 20%,  reduce = 0%, Cumulative CPU 275.33 sec
2017-04-14 02:28:40,134 Stage-2 map = 21%,  reduce = 0%, Cumulative CPU 278.57 sec
2017-04-14 02:28:42,191 Stage-2 map = 22%,  reduce = 0%, Cumulative CPU 288.81 sec
2017-04-14 02:28:43,229 Stage-2 map = 23%,  reduce = 0%, Cumulative CPU 292.54 sec
2017-04-14 02:28:46,306 Stage-2 map = 24%,  reduce = 0%, Cumulative CPU 307.22 sec
2017-04-14 02:28:48,412 Stage-2 map = 25%,  reduce = 0%, Cumulative CPU 316.32 sec
2017-04-14 02:28:49,443 Stage-2 map = 26%,  reduce = 0%, Cumulative CPU 319.48 sec
2017-04-14 02:28:50,476 Stage-2 map = 27%,  reduce = 0%, Cumulative CPU 327.84 sec
2017-04-14 02:28:53,545 Stage-2 map = 28%,  reduce = 0%, Cumulative CPU 338.24 sec
2017-04-14 02:28:56,677 Stage-2 map = 29%,  reduce = 0%, Cumulative CPU 367.75 sec
2017-04-14 02:28:57,698 Stage-2 map = 31%,  reduce = 0%, Cumulative CPU 374.89 sec
2017-04-14 02:28:58,724 Stage-2 map = 32%,  reduce = 0%, Cumulative CPU 377.7 sec
2017-04-14 02:29:02,833 Stage-2 map = 33%,  reduce = 0%, Cumulative CPU 400.14 sec
2017-04-14 02:29:05,899 Stage-2 map = 34%,  reduce = 0%, Cumulative CPU 418.78 sec
2017-04-14 02:29:06,919 Stage-2 map = 35%,  reduce = 0%, Cumulative CPU 424.84 sec
2017-04-14 02:29:07,939 Stage-2 map = 36%,  reduce = 0%, Cumulative CPU 431.43 sec
2017-04-14 02:29:08,960 Stage-2 map = 37%,  reduce = 0%, Cumulative CPU 435.25 sec
2017-04-14 02:29:10,936 Stage-2 map = 39%,  reduce = 0%, Cumulative CPU 443.67 sec
2017-04-14 02:29:12,978 Stage-2 map = 41%,  reduce = 0%, Cumulative CPU 448.17 sec
2017-04-14 02:29:14,596 Stage-2 map = 42%,  reduce = 0%, Cumulative CPU 448.17 sec
2017-04-14 02:29:15,633 Stage-2 map = 43%,  reduce = 0%, Cumulative CPU 460.12 sec
2017-04-14 02:29:16,657 Stage-2 map = 45%,  reduce = 0%, Cumulative CPU 470.4 sec
2017-04-14 02:29:18,708 Stage-2 map = 46%,  reduce = 0%, Cumulative CPU 476.14 sec
2017-04-14 02:29:21,802 Stage-2 map = 47%,  reduce = 0%, Cumulative CPU 485.69 sec
2017-04-14 02:29:24,897 Stage-2 map = 48%,  reduce = 0%, Cumulative CPU 502.3 sec
2017-04-14 02:29:27,964 Stage-2 map = 49%,  reduce = 0%, Cumulative CPU 516.03 sec
2017-04-14 02:29:28,983 Stage-2 map = 50%,  reduce = 0%, Cumulative CPU 523.05 sec
2017-04-14 02:29:31,023 Stage-2 map = 52%,  reduce = 0%, Cumulative CPU 539.08 sec
2017-04-14 02:29:33,064 Stage-2 map = 53%,  reduce = 0%, Cumulative CPU 548.34 sec
2017-04-14 02:29:34,085 Stage-2 map = 54%,  reduce = 0%, Cumulative CPU 554.52 sec
2017-04-14 02:29:36,126 Stage-2 map = 55%,  reduce = 0%, Cumulative CPU 559.99 sec
2017-04-14 02:29:38,168 Stage-2 map = 56%,  reduce = 0%, Cumulative CPU 567.15 sec
2017-04-14 02:29:39,194 Stage-2 map = 57%,  reduce = 0%, Cumulative CPU 569.43 sec
2017-04-14 02:29:40,222 Stage-2 map = 58%,  reduce = 0%, Cumulative CPU 575.47 sec
2017-04-14 02:29:41,242 Stage-2 map = 59%,  reduce = 0%, Cumulative CPU 578.54 sec
2017-04-14 02:29:43,295 Stage-2 map = 60%,  reduce = 0%, Cumulative CPU 585.49 sec
2017-04-14 02:29:45,344 Stage-2 map = 61%,  reduce = 0%, Cumulative CPU 596.45 sec
2017-04-14 02:29:48,413 Stage-2 map = 62%,  reduce = 0%, Cumulative CPU 620.86 sec
2017-04-14 02:29:50,456 Stage-2 map = 63%,  reduce = 0%, Cumulative CPU 628.04 sec
2017-04-14 02:29:51,490 Stage-2 map = 65%,  reduce = 0%, Cumulative CPU 635.1 sec
2017-04-14 02:29:54,584 Stage-2 map = 66%,  reduce = 0%, Cumulative CPU 658.17 sec
2017-04-14 02:29:56,636 Stage-2 map = 67%,  reduce = 0%, Cumulative CPU 676.62 sec
2017-04-14 02:29:57,679 Stage-2 map = 68%,  reduce = 0%, Cumulative CPU 682.85 sec
2017-04-14 02:29:59,721 Stage-2 map = 71%,  reduce = 0%, Cumulative CPU 713.1 sec
2017-04-14 02:30:00,741 Stage-2 map = 72%,  reduce = 0%, Cumulative CPU 716.04 sec
2017-04-14 02:30:01,761 Stage-2 map = 73%,  reduce = 0%, Cumulative CPU 718.88 sec
2017-04-14 02:30:02,781 Stage-2 map = 74%,  reduce = 0%, Cumulative CPU 737.75 sec
2017-04-14 02:30:03,799 Stage-2 map = 75%,  reduce = 0%, Cumulative CPU 740.25 sec
2017-04-14 02:30:04,820 Stage-2 map = 76%,  reduce = 0%, Cumulative CPU 744.42 sec
2017-04-14 02:30:05,840 Stage-2 map = 77%,  reduce = 0%, Cumulative CPU 752.17 sec
2017-04-14 02:30:07,880 Stage-2 map = 78%,  reduce = 0%, Cumulative CPU 761.32 sec
2017-04-14 02:30:10,973 Stage-2 map = 79%,  reduce = 0%, Cumulative CPU 773.89 sec
2017-04-14 02:30:12,003 Stage-2 map = 80%,  reduce = 0%, Cumulative CPU 778.24 sec
2017-04-14 02:30:15,259 Stage-2 map = 81%,  reduce = 0%, Cumulative CPU 796.2 sec
2017-04-14 02:30:17,996 Stage-2 map = 82%,  reduce = 0%, Cumulative CPU 827.09 sec
2017-04-14 02:30:20,219 Stage-2 map = 84%,  reduce = 0%, Cumulative CPU 833.63 sec
2017-04-14 02:30:21,276 Stage-2 map = 86%,  reduce = 0%, Cumulative CPU 840.91 sec
2017-04-14 02:30:23,647 Stage-2 map = 88%,  reduce = 0%, Cumulative CPU 857.05 sec
2017-04-14 02:30:26,978 Stage-2 map = 90%,  reduce = 0%, Cumulative CPU 873.13 sec
2017-04-14 02:30:28,078 Stage-2 map = 91%,  reduce = 0%, Cumulative CPU 881.38 sec
2017-04-14 02:30:29,186 Stage-2 map = 92%,  reduce = 0%, Cumulative CPU 884.48 sec
2017-04-14 02:30:31,403 Stage-2 map = 93%,  reduce = 0%, Cumulative CPU 892.9 sec
2017-04-14 02:30:34,956 Stage-2 map = 94%,  reduce = 0%, Cumulative CPU 906.12 sec
2017-04-14 02:30:38,393 Stage-2 map = 95%,  reduce = 0%, Cumulative CPU 917.49 sec
2017-04-14 02:30:40,507 Stage-2 map = 96%,  reduce = 0%, Cumulative CPU 931.15 sec
2017-04-14 02:30:41,529 Stage-2 map = 96%,  reduce = 1%, Cumulative CPU 931.58 sec
2017-04-14 02:30:43,573 Stage-2 map = 97%,  reduce = 1%, Cumulative CPU 947.99 sec
2017-04-14 02:30:48,817 Stage-2 map = 98%,  reduce = 1%, Cumulative CPU 972.55 sec
2017-04-14 02:30:54,945 Stage-2 map = 99%,  reduce = 1%, Cumulative CPU 993.72 sec
2017-04-14 02:30:58,011 Stage-2 map = 100%,  reduce = 1%, Cumulative CPU 999.86 sec
2017-04-14 02:31:00,080 Stage-2 map = 100%,  reduce = 2%, Cumulative CPU 1005.43 sec
2017-04-14 02:31:02,169 Stage-2 map = 100%,  reduce = 3%, Cumulative CPU 1029.56 sec
2017-04-14 02:31:04,364 Stage-2 map = 100%,  reduce = 4%, Cumulative CPU 1052.18 sec
2017-04-14 02:31:09,000 Stage-2 map = 100%,  reduce = 5%, Cumulative CPU 1085.17 sec
2017-04-14 02:31:14,657 Stage-2 map = 100%,  reduce = 6%, Cumulative CPU 1101.64 sec
2017-04-14 02:31:16,822 Stage-2 map = 100%,  reduce = 7%, Cumulative CPU 1117.46 sec
2017-04-14 02:31:17,910 Stage-2 map = 100%,  reduce = 8%, Cumulative CPU 1135.57 sec
2017-04-14 02:31:20,041 Stage-2 map = 100%,  reduce = 9%, Cumulative CPU 1170.34 sec
2017-04-14 02:31:23,540 Stage-2 map = 100%,  reduce = 10%, Cumulative CPU 1178.13 sec
2017-04-14 02:31:28,107 Stage-2 map = 100%,  reduce = 11%, Cumulative CPU 1198.36 sec
2017-04-14 02:31:29,182 Stage-2 map = 100%,  reduce = 12%, Cumulative CPU 1208.4 sec
2017-04-14 02:31:30,244 Stage-2 map = 100%,  reduce = 13%, Cumulative CPU 1227.66 sec
2017-04-14 02:31:33,530 Stage-2 map = 100%,  reduce = 14%, Cumulative CPU 1257.57 sec
2017-04-14 02:31:39,840 Stage-2 map = 100%,  reduce = 15%, Cumulative CPU 1277.7 sec
2017-04-14 02:31:40,957 Stage-2 map = 100%,  reduce = 16%, Cumulative CPU 1300.59 sec
2017-04-14 02:31:45,967 Stage-2 map = 100%,  reduce = 17%, Cumulative CPU 1321.6 sec
2017-04-14 02:31:48,064 Stage-2 map = 100%,  reduce = 18%, Cumulative CPU 1337.15 sec
2017-04-14 02:31:52,356 Stage-2 map = 100%,  reduce = 19%, Cumulative CPU 1372.6 sec
2017-04-14 02:31:58,523 Stage-2 map = 100%,  reduce = 20%, Cumulative CPU 1393.92 sec
2017-04-14 02:31:59,572 Stage-2 map = 100%,  reduce = 21%, Cumulative CPU 1404.72 sec
2017-04-14 02:32:02,000 Stage-2 map = 100%,  reduce = 22%, Cumulative CPU 1424.81 sec
2017-04-14 02:32:03,305 Stage-2 map = 100%,  reduce = 23%, Cumulative CPU 1439.77 sec
2017-04-14 02:32:05,978 Stage-2 map = 100%,  reduce = 24%, Cumulative CPU 1466.31 sec
2017-04-14 02:32:13,709 Stage-2 map = 100%,  reduce = 25%, Cumulative CPU 1495.57 sec
2017-04-14 02:32:15,008 Stage-2 map = 100%,  reduce = 26%, Cumulative CPU 1502.64 sec
2017-04-14 02:32:18,297 Stage-2 map = 100%,  reduce = 27%, Cumulative CPU 1523.94 sec
2017-04-14 02:32:19,355 Stage-2 map = 100%,  reduce = 28%, Cumulative CPU 1547.43 sec
2017-04-14 02:32:23,731 Stage-2 map = 100%,  reduce = 29%, Cumulative CPU 1562.81 sec
2017-04-14 02:32:26,926 Stage-2 map = 100%,  reduce = 30%, Cumulative CPU 1580.94 sec
2017-04-14 02:32:29,086 Stage-2 map = 100%,  reduce = 31%, Cumulative CPU 1605.0 sec
2017-04-14 02:32:31,220 Stage-2 map = 100%,  reduce = 32%, Cumulative CPU 1619.92 sec
2017-04-14 02:32:33,798 Stage-2 map = 100%,  reduce = 33%, Cumulative CPU 1648.19 sec
2017-04-14 02:32:37,528 Stage-2 map = 100%,  reduce = 34%, Cumulative CPU 1661.16 sec
2017-04-14 02:32:39,707 Stage-2 map = 100%,  reduce = 35%, Cumulative CPU 1682.35 sec
2017-04-14 02:32:43,001 Stage-2 map = 100%,  reduce = 36%, Cumulative CPU 1701.0 sec
2017-04-14 02:32:45,151 Stage-2 map = 100%,  reduce = 37%, Cumulative CPU 1721.04 sec
2017-04-14 02:32:49,404 Stage-2 map = 100%,  reduce = 38%, Cumulative CPU 1744.89 sec
2017-04-14 02:32:51,643 Stage-2 map = 100%,  reduce = 39%, Cumulative CPU 1767.02 sec
2017-04-14 02:32:54,813 Stage-2 map = 100%,  reduce = 40%, Cumulative CPU 1784.98 sec
2017-04-14 02:32:55,906 Stage-2 map = 100%,  reduce = 41%, Cumulative CPU 1802.94 sec
2017-04-14 02:32:59,110 Stage-2 map = 100%,  reduce = 42%, Cumulative CPU 1816.51 sec
2017-04-14 02:33:03,488 Stage-2 map = 100%,  reduce = 43%, Cumulative CPU 1839.55 sec
2017-04-14 02:33:05,691 Stage-2 map = 100%,  reduce = 44%, Cumulative CPU 1864.07 sec
2017-04-14 02:33:06,774 Stage-2 map = 100%,  reduce = 45%, Cumulative CPU 1876.32 sec
2017-04-14 02:33:10,165 Stage-2 map = 100%,  reduce = 46%, Cumulative CPU 1899.24 sec
2017-04-14 02:33:13,482 Stage-2 map = 100%,  reduce = 47%, Cumulative CPU 1917.52 sec
2017-04-14 02:33:18,224 Stage-2 map = 100%,  reduce = 48%, Cumulative CPU 1946.44 sec
2017-04-14 02:33:19,292 Stage-2 map = 100%,  reduce = 49%, Cumulative CPU 1954.54 sec
2017-04-14 02:33:21,678 Stage-2 map = 100%,  reduce = 50%, Cumulative CPU 1973.19 sec
2017-04-14 02:33:23,937 Stage-2 map = 100%,  reduce = 51%, Cumulative CPU 1993.77 sec
2017-04-14 02:33:28,435 Stage-2 map = 100%,  reduce = 52%, Cumulative CPU 2015.78 sec
2017-04-14 02:33:31,899 Stage-2 map = 100%,  reduce = 53%, Cumulative CPU 2038.32 sec
2017-04-14 02:33:35,111 Stage-2 map = 100%,  reduce = 54%, Cumulative CPU 2054.92 sec
2017-04-14 02:33:36,182 Stage-2 map = 100%,  reduce = 55%, Cumulative CPU 2069.36 sec
2017-04-14 02:33:38,365 Stage-2 map = 100%,  reduce = 56%, Cumulative CPU 2088.4 sec
2017-04-14 02:33:41,499 Stage-2 map = 100%,  reduce = 57%, Cumulative CPU 2108.88 sec
2017-04-14 02:33:48,365 Stage-2 map = 100%,  reduce = 58%, Cumulative CPU 2147.48 sec
2017-04-14 02:33:49,449 Stage-2 map = 100%,  reduce = 59%, Cumulative CPU 2155.82 sec
2017-04-14 02:33:50,501 Stage-2 map = 100%,  reduce = 60%, Cumulative CPU 2167.48 sec
2017-04-14 02:33:55,262 Stage-2 map = 100%,  reduce = 61%, Cumulative CPU 2189.95 sec
2017-04-14 02:33:59,122 Stage-2 map = 100%,  reduce = 62%, Cumulative CPU 2211.9 sec
2017-04-14 02:34:01,247 Stage-2 map = 100%,  reduce = 63%, Cumulative CPU 2224.99 sec
2017-04-14 02:34:03,526 Stage-2 map = 100%,  reduce = 64%, Cumulative CPU 2245.15 sec
2017-04-14 02:34:08,248 Stage-2 map = 100%,  reduce = 65%, Cumulative CPU 2271.72 sec
2017-04-14 02:34:10,445 Stage-2 map = 100%,  reduce = 66%, Cumulative CPU 2287.01 sec
2017-04-14 02:34:13,662 Stage-2 map = 100%,  reduce = 67%, Cumulative CPU 2308.33 sec
2017-04-14 02:34:16,067 Stage-2 map = 100%,  reduce = 68%, Cumulative CPU 2328.28 sec
2017-04-14 02:34:19,262 Stage-2 map = 100%,  reduce = 69%, Cumulative CPU 2348.18 sec
2017-04-14 02:34:21,344 Stage-2 map = 100%,  reduce = 70%, Cumulative CPU 2364.39 sec
2017-04-14 02:34:24,814 Stage-2 map = 100%,  reduce = 71%, Cumulative CPU 2393.49 sec
2017-04-14 02:34:28,243 Stage-2 map = 100%,  reduce = 72%, Cumulative CPU 2411.03 sec
2017-04-14 02:34:30,436 Stage-2 map = 100%,  reduce = 73%, Cumulative CPU 2435.04 sec
2017-04-14 02:34:32,605 Stage-2 map = 100%,  reduce = 74%, Cumulative CPU 2448.38 sec
2017-04-14 02:34:34,761 Stage-2 map = 100%,  reduce = 75%, Cumulative CPU 2462.24 sec
2017-04-14 02:34:37,913 Stage-2 map = 100%,  reduce = 76%, Cumulative CPU 2487.25 sec
2017-04-14 02:34:40,287 Stage-2 map = 100%,  reduce = 77%, Cumulative CPU 2512.52 sec
2017-04-14 02:34:42,829 Stage-2 map = 100%,  reduce = 78%, Cumulative CPU 2529.21 sec
2017-04-14 02:34:46,286 Stage-2 map = 100%,  reduce = 79%, Cumulative CPU 2558.18 sec
2017-04-14 02:34:47,367 Stage-2 map = 100%,  reduce = 80%, Cumulative CPU 2564.52 sec
2017-04-14 02:34:49,595 Stage-2 map = 100%,  reduce = 81%, Cumulative CPU 2584.42 sec
2017-04-14 02:34:52,998 Stage-2 map = 100%,  reduce = 82%, Cumulative CPU 2605.47 sec
2017-04-14 02:34:56,218 Stage-2 map = 100%,  reduce = 83%, Cumulative CPU 2637.39 sec
2017-04-14 02:34:57,280 Stage-2 map = 100%,  reduce = 84%, Cumulative CPU 2643.24 sec
2017-04-14 02:35:02,681 Stage-2 map = 100%,  reduce = 85%, Cumulative CPU 2665.14 sec
2017-04-14 02:35:05,818 Stage-2 map = 100%,  reduce = 86%, Cumulative CPU 2691.08 sec
2017-04-14 02:35:06,925 Stage-2 map = 100%,  reduce = 87%, Cumulative CPU 2703.83 sec
2017-04-14 02:35:09,121 Stage-2 map = 100%,  reduce = 88%, Cumulative CPU 2722.94 sec
2017-04-14 02:35:10,206 Stage-2 map = 100%,  reduce = 89%, Cumulative CPU 2738.45 sec
2017-04-14 02:35:17,791 Stage-2 map = 100%,  reduce = 90%, Cumulative CPU 2767.31 sec
2017-04-14 02:35:21,010 Stage-2 map = 100%,  reduce = 91%, Cumulative CPU 2794.57 sec
2017-04-14 02:35:22,068 Stage-2 map = 100%,  reduce = 92%, Cumulative CPU 2801.2 sec
2017-04-14 02:35:24,219 Stage-2 map = 100%,  reduce = 93%, Cumulative CPU 2812.25 sec
2017-04-14 02:35:26,383 Stage-2 map = 100%,  reduce = 94%, Cumulative CPU 2863.1 sec
2017-04-14 02:35:31,020 Stage-2 map = 100%,  reduce = 95%, Cumulative CPU 2884.56 sec
2017-04-14 02:35:35,225 Stage-2 map = 100%,  reduce = 96%, Cumulative CPU 2916.99 sec
2017-04-14 02:35:36,256 Stage-2 map = 100%,  reduce = 97%, Cumulative CPU 2929.41 sec
2017-04-14 02:35:38,719 Stage-2 map = 100%,  reduce = 98%, Cumulative CPU 2943.38 sec
2017-04-14 02:35:43,212 Stage-2 map = 100%,  reduce = 99%, Cumulative CPU 2963.66 sec
2017-04-14 02:35:48,502 Stage-2 map = 100%,  reduce = 100%, Cumulative CPU 2992.0 sec
MapReduce Total cumulative CPU time: 49 minutes 52 seconds 0 msec
Ended Job = job_1490094830773_0687
Loading data to table esplus.tempapplication_orc
Table esplus.tempapplication_orc stats: [numFiles=318, numRows=85911023, totalSize=2156777415, rawDataSize=131895225586]
MapReduce Jobs Launched:
Stage-Stage-1: Map: 2  Reduce: 8   Cumulative CPU: 966.68 sec   HDFS Read: 470780695 HDFS Write: 18656826570 SUCCESS
Stage-Stage-4: Map: 2  Reduce: 8   Cumulative CPU: 464.88 sec   HDFS Read: 153545770 HDFS Write: 2457221209 SUCCESS
Stage-Stage-2: Map: 77  Reduce: 315   Cumulative CPU: 2992.04 sec   HDFS Read: 21117360191 HDFS Write: 1682380435 SUCCESS
Total MapReduce CPU Time Spent: 0 days 1 hours 13 minutes 43 seconds 600 msec
OK
Time taken: 1901.608 seconds

hive> dfs -du -s -h /user/hive/warehouse/esplus.db/tempapplication_orc;
2.0 G  6.0 G  /user/hive/warehouse/esplus.db/tempapplication_orc

=================================================================================================================================


